# R147：共同 Q* 容量与保留 high 余量的时间分配

状态：QC1–QC6 给一个任意原来源 ν 上的真实已付分支；主分支只登记一次费用 48Λ√n Wβ。它不覆盖全部原剩余，QC7 明列补集。没有重证空间 score 方差、改换 β/ν 或假设坐标独立。

## QC1. 原合同与历史筛查

固定合法有限截断中的实际 ω,V,j,x,y 及原共同参数。以下 Q*=（K₁+K₂+J）/3 是 RT128 原三核的算术平均，绝不是逐坐标混合、逐来源核选择或核上确界。FIRST 和 high 保留为

\[
\int Q^*(v)\,d\nu(v)\le q,\qquad p e_g\ge2Kq,
\qquad \tau_j\le t\le h\le g.
\tag{QC1}
\]

原后验是 Π_t=w_t1_{Z_t}ν/e_t；ρ 是共同原 α/储备构造所得的终端余量，0≤ρ≤1，整窗固定。定义

\[
E_+=S_g\cap\{\rho>0\},\quad
\mu(dv)=\frac{Q^*(v)}q\,d\nu(v),\quad
r_t(v)=\frac{KQ^*(v)}{p w_t(v)},\quad
L_t=\frac{Kq}{p e_t}.
\tag{QC2}
\]

这里 ρ 沿原定义在不合资格的 good 来源上为零；E₊ 包含所有实际 ρ>0 的终端 good 来源，不能因某时刻 score=0 删除 CORE。μ 是同一份 FIRST 容量，μ(全空间)≤1。原 Z_t 嵌套、w_t 单调给 e_t≥e_h≥e_g，故

\[
0<L_t\le L_h:=\frac{Kq}{p e_h}\le L_g:=\frac{Kq}{p e_g}\le\frac12,
\qquad d\Pi_t=L_t\,\frac{1_{Z_t}}{r_t}\,d\mu.
\tag{QC3}
\]

所有这些量在原 ν 上定义；μ、E₊、ρ、L_h、L_g 及后文分配函数在外 hard 来源 z 积分前固定，不能随 z、内 bad 来源 u 或积分时间重新选择。E₊⊂Z_g⊂Z_t；原乘积权在 E₊ 上满足 d r_t/dlog t=k_t r_t，r_t 连续、绝对连续且不减。q=0、ν=0 或 e_h=0 的零交通行按原约定先剔除，不计算零商；实际正软核保证非零行 Q*>0。

历史筛查：R119 quantitative_future.md 的 FA5–18 已支付 r_t≥K B_FA δ_t 的支，且已知 ∫r_t dΠ_t≤1/2。因此只重新设 r_t≳n² 的逐 t 门可能完全落入旧 FA 支，不登记为新进展。R122 weighted_suffix_integration_private.md 第2节已有静态捕获系数的普通 FTC。下面的新付款对象明确取旧已付支补集，并使用固定共同 μ 的分配预算、实际 high 余量和整窗消源后接合 JT13；有限定向历史检查没有发现同一完整分支，亦不声称穷尽全部历史。

## QC2. 一份共同容量的分配定理

量词：对每条上述实际合法行，取一个整窗固定、可测、μ 几乎处处有限的函数 a(v)≥0，使

\[
\int_{E_+}a(v)\,d\mu(v)\le1.
\tag{QC4}
\]

它可以依赖该共同实际行及 v，但不得随 t、u 或外 z 重选。固定任意 L_*∈[L_h,1/2]，因而 L_t≤L_*；本轮主结算统一选择 L_*=L_g，L_*=L_h 仅为可选理论增强。选定任意 N>0，定义该分配的门

\[
\mathcal A_a(t,v)=
\left\{v\in E_+,\quad
\frac{\rho(v)}{r_t(v)}\le\frac{a(v)}{2N L_*}\right\}.
\tag{QC5}
\]

a=0 时 E₊ 上该门为空。则对任意原 bad 域 D_t⊂Z_t，保留 δ_t(v,u)=[k_t(v)−k_t(u)]₊，有

\[
\boxed{\int_\tau^h\!\int\!\int
\rho(v)\delta_t(v,u)1_{\mathcal A_a(t,v)}1_{D_t}(u)
\,d\Pi_t(u)d\Pi_t(v)\frac{dt}{t}
\le\frac1{2N}.}
\tag{QC6}
\]

任意原 Ψ、FA、history、low-c、其余合法资格门或先前已付支补集与该支相交后，仍服从此上界。它不要求这些门在时间上单调。

证明：先仅以 δ_t(v,u)≤k_t(v) 和 Π_t(D_t)≤1 积分 u。准确换测度 QC3 后，用 L_t≤L_*。对固定 v∈E₊ 且 a(v)>0，令 b(v)=2N L_* ρ(v)/a(v)>0。绝对连续链式法则给

\[
\rho(v)\int_\tau^h\frac{k_t(v)}{r_t(v)}
 1_{\{r_t(v)\ge b(v)\}}\frac{dt}{t}
=\rho(v)\left[\frac1{\max\{r_\tau(v),b(v)\}}-
                       \frac1{r_h(v)}\right]_+
\le\frac{a(v)}{2N L_*}.
\tag{QC7}
\]

平台 k_t=0 和阈值等号均无额外通量。乘 L_* 后对同一 μ 积分，再用 QC4 即得 QC6。这里只用非负 Tonelli；ν 可以任意相关。两份后验的 e_t 从未同时删除：bad 概率积分先有界，good 后验准确产生 L_t/r_t。

## QC3. 本轮主支：全部正余量 good 的共同质量

设

\[
m=\mu(E_+),\qquad M_\rho=\int_{E_+}\rho\,d\mu.
\tag{QC8}
\]

m=0 时 E₊ 上 ν 质量为零，正交通为零。m>0 时 Mρ>0，取唯一主分配 a=1/m，QC4 等号成立。得到主门

\[
\boxed{\mathcal A_m=\{v\in E_+:\ r_t(v)\ge2N L_g m\rho(v)\}.}
\tag{QC9}
\]

它包含 base 门 r_t≥Nmρ，也包含原未使用共享质量的门 r_t≥Nρ，故这三者只付最大支的一份费用。主门中的 q 不再造成虚假的大比例：

\[
2L_gm=\frac{2K}{p e_g}\int_{E_+}Q^*\,d\nu,
\qquad
\boxed{\mathcal A_m\iff
Q^*(v)e_g\ge2N\rho(v)w_t(v)\int_{E_+}Q^*\,d\nu.}
\tag{QC10}
\]

最后一个等价式的 p、K、q 也消去，但 e_g、原 Q*、原来源 ν 与真实 wt 必须保留。这是门的恒等式，不是额外归一假设。

shared capacity 的具体含义：对原终端 bad 域 D₀，有 E₊∩D₀=∅，且

\[
m+\mu(D_0)+\mu((E_+\cup D_0)^c)=\mu(\mathbb R^n)\le1.
\tag{QC11}
\]

因而 bad Q 质量、ρ=0 或其余支持质量以及 FIRST 松弛共同减小 m；这些不是独立的新预算。共同 α 仅通过原 ρ 和 E₊ 进入，未重选或假设 uniform α。一般输入不保证 m 或 L_g 一致小。

## QC4. 替代分配与禁止重复收费

a=ρ/Mρ 给另一合法门 r_t≥2N L_g Mρ，同样有 QC6。固定一个整窗且全来源共用的 λ∈[0,1]，取

\[
a_\lambda(v)=(1-\lambda)/m+\lambda\rho(v)/M_\rho
\]

也满足 QC4，从而同一价格支付 QC5 的该门。λ 可依赖共同实际行，但不能逐来源选最有利端点而省略 QC4 检查。两端门的并集一般必须收费两份，或先作确切去重再证明共享 QC4；点态取两阈值的最小值不自动只花一份。本文主结算只选 QC9，替代门及其数值不追加为免费覆盖。

可选理论增强是取 L_*=L_h≤L_g：同一证明允许将主门中的 L_g、e_g 分别换成 L_h、e_h，所得门更大。本轮主稿、数值及补集统一使用较保守的 L_g 门，只登记该门的一份费用；不以 L_g 数值宣称 L_h 分支已检验。

## QC5. 原 dx、hard、时间及唯一 j 的全价

定义 P_m 为原 RT2 正交通在原未付支内额外加 QC9 的部分。保留原 β_V(dy)、实际 dx、原 p/q、外 hard 来源、aω、全部合法 hard 资格、Ψ/χ_FA、ρ、high、C_J、原 j 选择及实际时间窗；如果当前台账已限制 low-c，则 P_m 继续限制该门。不得在定义中以简化全域替换原门。原负项、futurebad/Ndel 和全部旧已付项不参加此次正费用。

先对每个外 z，仅在证明上删除其余值≤1的正门，但保留原 aω(x,y,z)。QC6 对所有 z 用同一个分配，故原真实 hard 帽

\[
q^{-1}\int h_R(x-z)a_\omega(x,y,z)\,d\nu(z)\le16/3
\]

给整份来源和整窗的共同帽 8/(3N)。这一帽已含 dt/t；不能再乘 log2，也不能把尚未积分的逐 t 帽称作整窗帽。

此后才能合并原唯一 j：Σ_j1_{j(x)=j}≤1，所选 p 受固定比例带的 R140 JT13 包络支配，

\[
\int\sup_{s,L\in[a,b]}P_{s,L}(x-y)\,dx
\le3(2n+3)D_n,\qquad D_n=1+\frac\pi2\sqrt n\le3\sqrt n.
\]

因此原完整费用为

\[
\boxed{2\Lambda P_m
\le\frac{16\Lambda(2n+3)D_n}{N}W_\beta.}
\tag{QC12}
\]

取 N=2n+3，得到

\[
\boxed{2\Lambda P_m\le16\Lambda D_n W_\beta
\le48\Lambda\sqrt n\,W_\beta.}
\tag{QC13}
\]

β 始终是原外来源，Wβ=EΣV∥βV∥。这里没有把 ν 换成 β，没有假设 β 密度有界，没有独立按 j、层或来源花 FIRST 容量。证明先完成实际整窗与三来源消去，再付实际接收包络；其他绝对尺度带沿原台账处理，QC13 不授权跨带免费求上确界。

## QC6. 有限数值筛查的准确意义

同目录 numeric_margin.json（SHA256：0f504950a5b4d7dc94e362171c0153c114fc601194e16e5df1d6f220c958798b）的最终 slack 筛查采用 N=2n+3 和 L_g，未新增核、来源或积分。按数值代理报告，原 FA strict interior 的 I1 initial 6/6、expanded 27/27 个正点均通过 slack-m；P1 pressure 15/15 通过；P1 initial 44/68、expanded 270/399 通过，余下分别为 24/129 个 far 来源转 good 的点。P1 剩余点 ρscore 权占比约 1.37×10⁻¹⁶ / 1.22×10⁻¹⁶，主 G1/G2/G3 全通过。检查有 L_t≤L_g，且 2L_gm 的 q 消去数值残差≤2×10⁻⁸⁰。

这些仅为冻结有限模型与已有时间采样的点权统计，不是 dt/t 积分覆盖率。I1 原 FAclosed 的已采样点权覆盖仅约 49.37%，早端余量仍实际存在；不能从 strict-interior 的通过率推出全时间窗闭合。理论 QC13 与这些统计无关。

## QC7. 准确补集与结论边界

只将主门 QC9 与旧未付正支相交并收费一次。该原正支的未覆盖部分准确满足

\[
v\in E_+,\qquad
r_t(v)<2(2n+3)L_gm\rho(v),
\]

亦即

\[
Q^*(v)e_g<2(2n+3)\rho(v)w_t(v)\int_{E_+}Q^*\,d\nu.
\tag{QC14}
\]

其余原门、外硬来源、两份后验、时间、dx、j 与原共同 α 一律保留。ρ=0 来源无正余量；不合本稿合法原 hard/high/terminal 合同的其他台账项沿旧分解保留。QC14 没有已证的统一根阶费用，不能把近乎全部有限点权覆盖写成任意输入全体已付。本轮实际推进是 QC9 这个共享容量与 high 余量门的完整根阶付款，不是对全剩余的一般闭合。
