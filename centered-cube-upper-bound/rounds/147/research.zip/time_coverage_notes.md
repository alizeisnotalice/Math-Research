# R147 original finite-model whole-time gate coverage

Computed complete saved FA time intervals for all179 original necessary-positive receivers: I1=11,P1=168. This replaces sampled-time occupancy with analytic integration on the original finite time model. It introduces no new receiver/dx samples or kernel calculations. Prior time_gate_check files were left frozen.

The new gate does **not** cover the whole original traffic. In finite-record sums with the original outer factor p·hardmass/q:

- whole=.02827172001671602208;
- gate-covered (“paid” field)=.02310364010128994607;
- residual=.00516807991542607601, or18.2800335896% of whole.

These sums are over the selected receiver records, preserving their original distributions and stages; they are not dx integrals, probability-weighted estimates, or a FULL certification. “Paid” names membership in the candidate gate, not a numerical proof of the analytic payment theorem.

## Original gate and interval semantics

For each original receiver, μQ_i=Q_iν_i/q, Gplus={terminalgood_i andρ_i>0}, m=ΣGplus μQ_i, e_g=Σν_i saved_wg_i, Lg=Kq/(p e_g), N=2n+3. The sole tested new gate is

`r_t(i)=KQ_i/(p w_i(t)) ≥2N Lg mρ_i`.

All Q,q,ν,ρ,p and terminal labels remain their original common frozen values. Q is not replaced by J, μQ is not renormalized, and m is not reduced to currently active positive-score sources. Rebuilding m,Lg agrees with numeric_margin's saved32-digit values to relative4.88e−32. The exact entry-power equation after common p,q,K cancellation is

`t_entry^k_i = c_i / [Q_i e_g/(2Nρ_i ΣGplus Qν)]`.

The unreduced and reduced rational cap expressions were checked equal. Full/empty/partial classification uses exact Fraction comparisons to lo^k_i,hi^k_i before any root is evaluated. Isolated equality endpoints have zero integral. Positive original δ implies k_i>0;ρ0 sources contribute no accepted caps, so no root or division byρ0 is introduced.

R142 traffic.FA_caps already includes its original good/bad,ρ>0,Ψ and positive δ tests. Each such annotation was independently checked against R136's original Ψ and score segment. The saved printed FA endpoints were retained as exact decimal rational inputs and intersected with that saved score segment's high-precision domain. No endpoint needed clipping in this selected dataset. This does not reconstruct the unprinted exact high-precision original FA geometry; it integrates the frozen accepted time intervals.

There were690 original FA caps:504 fully covered,151 partially covered,35 empty intersections with the new gate. All179 original receivers and every cap remain in JSON.

## Existing primitive, conservation and precision

The two-score formula and three-score primitive are the already proved R142/R143 formulas. R143 numeric_flux.py was imported only for its guarded pure primitive; R142 time_primitive_check.py was not imported because it has top-level file-writing execution. No primitive was replaced by quadrature.

For every cap the calculation separately evaluates the original integral

`ρ_iν_iν_j ∫ δ w_iw_j/e_t² dt/t`

over full interval, gate-covered interval and residual interval. Whole=covered+residual is checked independently, not forced by defining residual as a subtraction. All179 records ran at80 and120 digits. Maximum relative precision change is4.85218e−80; maximum receiver-level conservation residual is2.14973e−121. All integrated values are nonnegative. Whole outer-factor F agrees with original R142 F_raw (I1), or its audited R142 closed-form oracle (P1), to relative4.60457e−16, well below the predeclared1e−8 tolerance.

These are high-precision closed-form evaluations, not a machine interval certificate for kernels, FA endpoints or roots. The exact algebraic root powers, original endpoints, entry values and both native80/120 row integrals are retained for reproduction.

## Three original stages and all-case results

|original stage/case|receivers|whole finite-record F sum|residual F sum|residual/whole|strictly positive residual records|
|---|---:|---:|---:|---:|---:|
|initial/I1|2|0.00529904410851|0.00110750361048|0.209000640078|2|
|initial/P1|25|7.31921236966e-10|1.17244550388e-26|1.6018738693e-17|24|
|pressure/I1|0|0|0|—|0|
|pressure/P1|5|3.23665537841e-07|0|0|0|
|expanded/I1|9|0.0229723447196|0.00406057630495|0.176759331906|9|
|expanded/P1|138|6.79116640129e-09|5.49715919494e-26|8.09457296452e-18|129|
|I1|11|0.0282713888281|0.00516807991543|0.182802477333|11|
|P1|168|3.3118862548e-07|6.66960469882e-26|2.01383869665e-19|153|

I1 has11/11 records with positive residual, with case-level fraction18.2802477333%. P1 has153/168 strictly positive residuals, but their total is only6.66960e−26 against whole3.311886e−7, a fraction2.01384e−19. In P1 all G1/G2/G3 accepted source traffic is covered for the whole saved time; its residual is exclusively the tiny B source. The five original pressure records have exactly zero residual in this frozen model. Positive-record counts alone would therefore overstate the practical size of P1's residual.

## Concrete early-time failure

The largest receiver residual fraction is I1 id244, original initial/p record:25.7582868307%. Its full F=.00279560439613692592, gate-covered F=.00207550459712910543, residual F=.000720099799007820493. Original accepted FA intervals start atτ=.5 and end near.628034991114724. The new gate only enters later:

|pair|entry time|pair residual fraction|
|---|---:|---:|
|G1→G4|.528281213435220741|.251995040621884|
|G2→G4|.550837197652421715|.441918453095207|
|G3→G4|.539660545902713699|.349172221734445|

Thus covering the geometric midpoint or terminal part does not imply whole-time coverage. These intervals have positive time length and positive analytic traffic, not merely endpoint failures. The issue survives integration of the original FA/Ψ traffic.

Source-separated finite-record residual fractions are:

|case/source|whole F|residual F|residual/whole|
|---|---:|---:|---:|
|I1/G1|0.0267628790846|0.00470828621261|0.175925998011|
|I1/G2|0.000140270008207|6.03108151741e-05|0.429962298747|
|I1/G3|0.00136823973527|0.000399482887639|0.291968488665|
|P1/G1|3.31172336922e-07|0|0|
|P1/G2|1.60199417962e-15|0|0|
|P1/G3|1.62869551478e-11|0|0|
|P1/B|6.78078672389e-26|6.66960469882e-26|0.983603373827|

## Execution and scope

The frozen menu was all179 records, processed in original initial→pressure→expanded order; no expansion or parameter search followed the results. The first complete run used65-digit display strings, hiding the difference between80/120-digit calculations in the precision summary. A second attempt changed serialization but also inadvertently referenced an undefined precision variable in the summary and stopped at27 rows before writing output. The final third attempt fixes only summary formatting and preserves native80/120 values. Two complete runs, one aborted formatting attempt, identical gate/receivers/intervals/primitive; execution history is saved explicitly. No mathematical failure or data exclusion is hidden.

The result establishes candidate-gate time coverage in the saved finite model and isolates a real I1 early-time residual. It does not establish dx integrals, exact actual-kernel labels or arbitraryν/history, nor prove payment of the gate-covered branch or its complement. In particular, the nonzero early-time residual remains an explicit obligation for the main proof. All four files are delivered; no Git/PDF/other-file edits, and work stops.

## Authorized portability-only follow-up

After the result freeze above, `--input-root` was added before input-path construction and primitive import; its default remains the original input directory. The fourth producer attempt (third complete run) used the explicit argument and reproduced every mathematical record, summary, stratum, source total and input hash identically. The earlier execution paragraph describes the pre-portability freeze. Final JSON records mpmath1.3.0 and the updated execution history. No mathematical menu or numerical result changed.

Final script SHA256: `878a5fe04b08a139ad3cefe526d35c99fc1c7f0f889e1d1f010109c1963b6a13`.
Final JSON SHA256: `589b2a37ffca9a5c0a801c435c8d4918f0fd6a1d16fec519ef2dc088cbf3c0de`.
