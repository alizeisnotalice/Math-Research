#!/usr/bin/env python3
"""R147 saved-Q posterior margin thresholds; no kernel/receiver/time integration."""
import json,hashlib,math,time,datetime,argparse
from pathlib import Path
from decimal import Decimal as D,localcontext,getcontext
getcontext().prec=80
from collections import defaultdict
ROOT=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--input-root',default='/Users/zhengzhihao/Desktop/T/output');args=ap.parse_args();BASE=Path(args.input_root)
SPECS={'score':(ROOT/'r146_numeric_score.json','6e103db84e39cdd9bc8a874083f83a83bb1d5797ab180f4b86c1482940821879'),'receiver':(BASE/'centered_cube_round142_20261015/numeric_receiver.json','c46a90467707b9d05ae03cb17d0f63e60bf7709dfd5c717550e3d3278957ae55'),'source':(BASE/'centered_cube_round136_20261014/active_traffic_v2.json','1090fb2356abe035a997eb851a2f0252a3abe3edbeaf978e99900a38906392de')}
MAIN=['n','n+1','2(n+1)'];SUPP=['(n+1)^2','(16/3)(n+1)^2']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def quant(values):
 v=sorted(x for x in values if x is not None)
 if not v:return {'N':0}
 out={'N':len(v)}
 for p in [0,.1,.5,.9,.99,1]:
  z=(len(v)-1)*p;i=int(z);out[str(p)]=v[i]+(v[min(i+1,len(v)-1)]-v[i])*(z-i)
 return out
def clean(x):
 if isinstance(x,D):return format(x,'.32g')
 if isinstance(x,dict):return {str(k):clean(v) for k,v in x.items()}
 if isinstance(x,list):return [clean(v) for v in x]
 return x
start=time.monotonic();data={};hashes={}
for k,(p,expected) in SPECS.items():
 hashes[k]=sha(p);assert hashes[k]==expected,(k,hashes[k]);data[k]=json.loads(p.read_text())
score=data['score'];source={c['id']:c for c in data['source']['cases']};wanted={(r['case'],r['id']) for r in score['receiver_times']};receiver={}
for cid,c in data['receiver']['cases'].items():
 for r in c['records']:
  if (cid,r['id']) in wanted:receiver[(cid,r['id'])]=r
assert len(receiver)==179 and len(score['samples'])==2070
models={m['time_id']:m for m in score['time_models']};checks={'receiver_N':179,'time_model_N':6,'receiver_time_N':537,'source_margin_N':3222,'max_Pi_vs_saved32_abs_error':0.,'max_e_vs_saved32_relative_error':0.,'max_identity_abs_residual':0.,'max_mass_residual':0.,'muQ_mass_max':0.,'muQ_mass_gt_one':[],'max_log_margin_identity_abs_residual':0.,'max_80_vs120_relative_change':0.,'rho_zero_sources':0,'negative_Delta_sources':[],'near_threshold_sources':[],'max_Q_average_relative_error':0.,'shared_mass_time_dependence_max':0.,'max_Lg':0.,'max_Lg_half_positive_excess':0.,'max_L_t_vs_Lg_positive_excess':0.,'max_q_cancellation_abs_residual':0.}

def margin_table(rt,precision):
 cid=rt['case'];r=receiver[(cid,rt['id'])];src=source[cid];m=models[rt['time_id']];case=data['receiver']['cases'][cid]
 with localcontext() as ctx:
  ctx.prec=precision;n=case['n'];nu=[D(x['numerator'])/D(x['denominator']) for x in case['nu_exact']];w=list(map(D,m['w']));e=sum(nu[i]*w[i] for i in range(6));pi=[nu[i]*w[i]/e for i in range(6)];Q=list(map(lambda x:D(str(x)),r['Q']));p=D(str(r['p']));q=D(str(r['q']));K=D(src['parameters']['K']);wg=[D(a['wg']) for a in src['atoms']];eg=sum(nu[i]*wg[i] for i in range(6));Lg=K*q/(p*eg);mu=[Q[i]*nu[i]/q for i in range(6)];L=K*q/(p*e);Gplus=[i for i in range(6) if r['good'][i] and r['rho'][i]>0];shared_m=sum((mu[i] for i in Gplus),D(0));shared_Mrho=sum((mu[i]*D(str(r['rho'][i])) for i in Gplus),D(0));Nstar=D(2*n+3);thresholds={'n':D(n),'n+1':D(n+1),'2(n+1)':D(2*(n+1)),'(n+1)^2':D((n+1)**2),'(16/3)(n+1)^2':D(16)/3*(n+1)**2};ss=[]
  for i in range(6):
   rho=D(str(r['rho'][i]));rtv=K*Q[i]/(p*w[i]);rg=K*Q[i]/(p*wg[i]);delta=(w[i]/wg[i]).ln();flags={key:{'threshold':v,'r_t_ge_threshold':rtv>=v,'r_t_ge_threshold_times_rho':rtv>=v*rho if rho>0 else None,'r_g_ge_threshold_times_rho':rg>=v*rho if rho>0 else None} for key,v in thresholds.items()};rat=rtv/rho if rho>0 else None;rgrat=rg/rho if rho>0 else None;near=min(abs(rtv-v*rho)/max(abs(rtv),abs(v*rho)) for v in thresholds.values()) if rho>0 else None
   ss.append({'source_index':i,'source':src['atoms'][i]['name'],'Pi':pi[i],'muQ':mu[i],'w_t':w[i],'w_g':wg[i],'Q':Q[i],'rho':rho,'r_t':rtv,'r_g':rg,'Delta':delta,'r_t_over_r_g':rtv/rg,'r_t_over_rho':rat,'r_g_over_rho':rgrat,'rho_zero':rho==0,'log_margin_identity_residual':rtv.ln()-rg.ln()+delta,'posterior_identity_residual':pi[i]-L*mu[i]/rtv,'thresholds':flags,'shared_mass_branches':{'Nstar':Nstar,'original_r_t_ge_Nstar_rho':rtv>=Nstar*rho if rho>0 else None,'shared_m_r_t_ge_Nstar_m_rho':rtv>=Nstar*shared_m*rho if rho>0 else None,'shared_Mrho_r_t_ge_Nstar_Mrho':rtv>=Nstar*shared_Mrho if rho>0 else None,'slack_2Lg_shared_m_r_t_ge_2Nstar_Lg_m_rho':rtv>=2*Lg*Nstar*shared_m*rho if rho>0 else None},'min_relative_threshold_distance':near})
  return {'receiver_time_id':rt['receiver_time_id'],'case':cid,'id':rt['id'],'stage':rt['stage'],'distribution':rt['distribution'],'time_id':rt['time_id'],'n':n,'p':p,'q':q,'K':K,'e_rebuilt':e,'L':L,'muQ_mass':sum(mu),'Gplus':Gplus,'shared_m':shared_m,'shared_Mrho':shared_Mrho,'e_g':eg,'Lg':Lg,'two_Lg_shared_m':2*Lg*shared_m,'q_cancellation_residual':2*Lg*shared_m-2*K*sum((Q[i]*nu[i] for i in Gplus),D(0))/(p*eg),'Nstar':Nstar,'Pi_mass':sum(pi),'e_vs_saved_relative_error':abs(e-D(m['e']))/e,'Pi_vs_saved_max_abs_error':max(abs(pi[i]-D(m['pi'][i])) for i in range(6)),'sources':ss}
margin_tables=[];margin_byid={}
for rt in score['receiver_times']:
 r=receiver[(rt['case'],rt['id'])];assert all(r['gates'].values()) and r['traffic']['positive_raw'];lo=margin_table(rt,80);hi=margin_table(rt,120);margin_byid[rt['receiver_time_id']]=lo;margin_tables.append(lo);checks['max_Lg']=max(checks['max_Lg'],float(lo['Lg']));checks['max_Lg_half_positive_excess']=max(checks['max_Lg_half_positive_excess'],float(max(lo['Lg']-D('.5'),D(0))));checks['max_L_t_vs_Lg_positive_excess']=max(checks['max_L_t_vs_Lg_positive_excess'],float(max(lo['L']-lo['Lg'],D(0))));checks['max_q_cancellation_abs_residual']=max(checks['max_q_cancellation_abs_residual'],float(abs(lo['q_cancellation_residual'])));checks['max_Pi_vs_saved32_abs_error']=max(checks['max_Pi_vs_saved32_abs_error'],float(lo['Pi_vs_saved_max_abs_error']));checks['max_e_vs_saved32_relative_error']=max(checks['max_e_vs_saved32_relative_error'],float(lo['e_vs_saved_relative_error']));checks['max_mass_residual']=max(checks['max_mass_residual'],float(abs(lo['Pi_mass']-1)));checks['muQ_mass_max']=max(checks['muQ_mass_max'],float(lo['muQ_mass']))
 if lo['muQ_mass']>1:checks['muQ_mass_gt_one'].append([lo['case'],lo['id'],lo['time_id'],str(lo['muQ_mass']-1)])
 for a,b in zip(lo['sources'],hi['sources']):
  checks['max_identity_abs_residual']=max(checks['max_identity_abs_residual'],float(abs(a['posterior_identity_residual'])));checks['max_log_margin_identity_abs_residual']=max(checks['max_log_margin_identity_abs_residual'],float(abs(a['log_margin_identity_residual'])));checks['rho_zero_sources']+=a['rho_zero']
  for metric in ['r_t','r_g','Delta','Pi','muQ']:
   if b[metric]:checks['max_80_vs120_relative_change']=max(checks['max_80_vs120_relative_change'],float(abs(a[metric]-b[metric])/abs(b[metric])))
  if a['Delta']<0:checks['negative_Delta_sources'].append([lo['receiver_time_id'],a['source_index'],str(a['Delta'])])
  if a['min_relative_threshold_distance'] is not None and a['min_relative_threshold_distance']<D('1e-10'):checks['near_threshold_sources'].append([lo['receiver_time_id'],a['source_index'],str(a['min_relative_threshold_distance'])])
mass_byreceiver={}
for tab in margin_tables:
 key=(tab['case'],tab['id']);current=(tab['shared_m'],tab['shared_Mrho'],tab['Lg'])
 if key in mass_byreceiver:checks['shared_mass_time_dependence_max']=max(checks['shared_mass_time_dependence_max'],*(float(abs(a-b)) for a,b in zip(current,mass_byreceiver[key])))
 else:mass_byreceiver[key]=current
with localcontext() as ctx:
 ctx.prec=80
 for r in receiver.values():
  for i in range(6):
   qv=D(str(r['Q'][i]));qa=sum(D(str(r[k][i])) for k in ['K1','K2','J'])/3;checks['max_Q_average_relative_error']=max(checks['max_Q_average_relative_error'],float(abs(qv-qa)/qv))
observations=[]
for s in score['samples']:
 tab=margin_byid[s['receiver_time_id']];r=receiver[(s['case'],s['id'])];v=s['v'];u=s['u'];sv=tab['sources'][v];src=source[s['case']];eligible=bool(r['good'][v] and r['bad'][u] and src['pairs'][v*6+u]['Psi'] and sv['rho']>0)
 observations.append({'sample_id':len(observations),'receiver_time_id':s['receiver_time_id'],'case':s['case'],'id':s['id'],'stage':tab['stage'],'distribution':tab['distribution'],'time_id':s['time_id'],'time_label':models[s['time_id']]['label'],'v':v,'u':u,'v_name':s['v_name'],'u_name':s['u_name'],'necessary_good_bad_rho_Psi':eligible,'scoreweight':D(s['scoreweight']),'rho_scoreweight':D(s['rho_scoreweight']),'original_FA_closed':s['saved_FA_closed'],'original_FA_strict_interior':s['saved_FA_strict_interior'],'printed_time_saved_cap_closed':s['actual_saved_cap_closed'],'printed_time_saved_cap_strict_interior':s['actual_saved_cap_strict_interior'],'saved_low_c_over_eta':s['saved_low_c_over_eta']})
MASKS=['all','original_FA_closed','original_FA_strict_interior','printed_time_saved_cap_closed','printed_time_saved_cap_strict_interior']
def summary(obs):
 out={'sample_N':len(obs),'receiver_N':len({(s['case'],s['id']) for s in obs}),'receiver_time_N':len({s['receiver_time_id'] for s in obs})}
 if not obs:return out
 vals=[margin_byid[s['receiver_time_id']]['sources'][s['v']] for s in obs];out['margin_quantiles']={k:quant([float(v[k]) if v[k] is not None else None for v in vals]) for k in ['r_t','r_g','Delta','r_t_over_r_g','r_t_over_rho','r_g_over_rho']};out['masks']={}
 for mask in MASKS:
  ss=[s for s in obs if s['necessary_good_bad_rho_Psi'] and (mask=='all' or s[mask])];total=sum((s['rho_scoreweight'] for s in ss),D(0));entry={'sample_N':len(ss),'receiver_N':len({(s['case'],s['id']) for s in ss}),'point_rho_scoreweight_sum':total,'thresholds':{}}
  for key in MAIN+SUPP:
   tests={}
   for flag in ['r_t_ge_threshold','r_t_ge_threshold_times_rho','r_g_ge_threshold_times_rho']:
    hit=[s for s in ss if margin_byid[s['receiver_time_id']]['sources'][s['v']]['thresholds'][key][flag]];weight=sum((s['rho_scoreweight'] for s in hit),D(0));tests[flag]={'covered_sample_N':len(hit),'covered_sample_fraction':len(hit)/len(ss) if ss else None,'covered_point_weight_fraction':float(weight/total) if total else None,'residual_point_weight_fraction':float((total-weight)/total) if total else None}
   entry['thresholds'][key]=tests
  sharedtests={}
  for branch in ['original_r_t_ge_Nstar_rho','shared_m_r_t_ge_Nstar_m_rho','shared_Mrho_r_t_ge_Nstar_Mrho','slack_2Lg_shared_m_r_t_ge_2Nstar_Lg_m_rho']:
   hit=[s for s in ss if margin_byid[s['receiver_time_id']]['sources'][s['v']]['shared_mass_branches'][branch]];weight=sum((s['rho_scoreweight'] for s in hit),D(0));sharedtests[branch]={'covered_sample_N':len(hit),'covered_sample_fraction':len(hit)/len(ss) if ss else None,'covered_point_weight_fraction':float(weight/total) if total else None,'residual_point_weight_fraction':float((total-weight)/total) if total else None}
  entry['Nstar_2nplus3_shared_mass']=sharedtests
  out['masks'][mask]=entry
 return out
strata={stage:{cid:summary([s for s in observations if s['stage']==stage and s['case']==cid]) for cid in ['I1','P1']} for stage in ['initial','pressure','expanded']};sourcesummary={cid+'/'+name:summary([s for s in observations if s['case']==cid and s['v_name']==name]) for cid in ['I1','P1'] for name in sorted({s['v_name'] for s in observations if s['case']==cid})};timesummary={cid+'/'+label:summary([s for s in observations if s['case']==cid and s['time_label']==label]) for cid in ['I1','P1'] for label in ['lo_right','geometric_mid','hi_left']}
# Explicit residual examples concern original FA strict-interior observations only.
residuals=[]
for s in observations:
 sv=margin_byid[s['receiver_time_id']]['sources'][s['v']]
 if s['necessary_good_bad_rho_Psi'] and s['original_FA_strict_interior'] and not sv['thresholds']['n+1']['r_t_ge_threshold_times_rho']:
  residuals.append({'sample_id':s['sample_id'],'case':s['case'],'id':s['id'],'stage':s['stage'],'time_label':s['time_label'],'v_name':s['v_name'],'u_name':s['u_name'],'r_t':sv['r_t'],'r_g':sv['r_g'],'rho':sv['rho'],'r_t_over_rho':sv['r_t_over_rho'],'rho_scoreweight':s['rho_scoreweight']})
out={'status':'completed_saved_Q_time_margin_diagnostic','execution_count':4,'execution_history':'First frozen menu; shared m/Mrho declared before second run; final high-gate slack2Lg shared-m strategy declared before third run; fourth run fixes default Decimal context to80 for point-weight summaries only. Same179 receivers/2070 observations, no added strategy/time/kernel/integration; earlier outputs superseded.','point_weight_decimal_precision_digits':80,'executed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'input_sha256':hashes,'plan_sha256':sha(ROOT/'numeric_margin_plan.md'),'script_sha256':sha(Path(__file__)),'scope':'Existing179 receivers,537 receiver-times,2070 point samples only; no kernel, sampling, integration or whole-time minimum. Candidate-covered branch is not certified paid.','checks':checks,'shared_mass_main_strategy':'Nstar=2n+3 with Gplus=all terminalgood rho>0; original r>=Nstar rho, shared r>=Nstar m rho, shared r>=Nstar Mrho, final slack r>=2Lg Nstar m rho. Lg=Kq/(p eg)<=1/2 checked. No free score-based deletion, Lh menu or renormalisation; analytic payment pending audit.','main_thresholds':MAIN,'supplementary_pending_constant_thresholds':SUPP,'weight_semantics':'Finite sums of saved point rho delta Pi_vPi_u, not dt or dx integrals. Original and printed-time saved-cap FA flags separate.','muQ_semantics':'Q nu/q subprobability checked, never renormalised; Pi rebuilt from saved32-digit w and exact same nu.','strata':strata,'source_strata':sourcesummary,'time_strata':timesummary,'receiver_time_margins':margin_tables,'sample_references':observations,'original_FA_interior_residual_Nplus1_examples':residuals[:12],'original_FA_interior_residual_Nplus1_count':len(residuals),'elapsed_seconds':time.monotonic()-start}
(ROOT/'numeric_margin.json').write_text(json.dumps(clean(out),ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n')
print(json.dumps({'status':out['status'],'checks':checks,'Nplus1_original_FA_interior_residual_samples':len(residuals),'elapsed_seconds':out['elapsed_seconds']},ensure_ascii=False))
