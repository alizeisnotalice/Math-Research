# R147：共同 Q 归一化下的单一 λ 上证书

本稿给出一个保留原共同来源与实际 ρ 的一般代数上证书，比先独立取来源上确界更精细；它不是完整接收外预算。证书可用于本轮 shared/slack 主分支的精确补集，不归一化剩余来源、不重算 α。以下先陈述命题，再给有限原记录检查与未付几何接口。

## 1. 精确共同约束与当前剩余域

固定原实际行、合法时间 t 与共同 ν。写
\[
Q_v=Q_x^*(v)=\tfrac13[P_{s,L}(x-v)+P_{s,L^+}(x-v)+J_b(x-v)],
\quad d\mu(v)=Q_vd\nu(v)/q,
\]
\[
r_v=\frac{KQ_v}{p_xw_t(v)},\quad
L_t=\frac{Kq}{p_xe_t},\quad
 d\Pi_t=1_{Z_t}\frac{L_t}{r_v}d\mu.
\tag{QE1}
\]
所有商限于原正有限域；严格 soft 给 Q>0。原零交通行另按零处理。FIRST 给 μ 为子概率，原 high 给 \(L_t\le1/2\)。因而
\[
\int d\Pi_t=1,\qquad
\boxed{\int r_vd\Pi_t(v)=L_t\mu(Z_t)\le L_t.}
\tag{QE2}
\]
这是一份共同 moment 预算，不是给每个来源各一份。终端 good 满足 \(r_{g,v}=KQ_v/(p_xw_g(v))\ge1\)，terminal bad 满足 \(r_{g,u}<1\)，且
\(r_v=r_{g,v}w_g(v)/w_t(v)\)。不把 terminal 下界错误移到时间 t。

正端始终使用原
\[
\rho_v=\left(1-\frac{DK_{0,v}+\alpha J_v}{TA_v}\right)_+,
\qquad \alpha=\mathcal R/Q_J,
\tag{QE3}
\]
及原 A=0/强制清零约定。令 \(E_+=G\cap\{\rho>0\}\)，\(L_g=Kq/(p_xe_g)\le1/2\)，
\[
m=\int_{E_+}d\mu,\qquad N=2n+3,
\qquad E_-=E_+\cap\{r_v<2NL_gm\rho_v\}.
\tag{QE4}
\]
其中 E+、m、Lg 按原整行固定，m 不是 μ(Zg)，不按 t 或 score 重新选源。E− 正是本轮主分支的补集；B=D0 为原 terminal bad，两者互斥。不对 E− 的 ν、μ 或 Π重新归一。

在 E−×B 上置
\[
H(v,u)=\rho_v[k_t(v)-k_t(u)]_+\psi(v,u),\qquad0\le\psi\le1,
\quad P_- =\iint_{E_-\times B}H\,d\Pi_t(v)d\Pi_t(u).
\tag{QE5}
\]
ψ可保留原 Ψ、FA 及剩余正门；取 ψ=1 是明确的正放松，不改变负项。

## 2. 一般上证书及证明

对一个**全行共用**的 \(\lambda\ge0\)，令
\[
C_\lambda=\mathop{\mathrm{ess\,sup}}_{E_-\times B}
\frac{H(v,u)}{(1+\lambda r_v)(1+\lambda r_u)},
\qquad U_\lambda=\frac{(1+\lambda L_t)^2}{4}C_\lambda.
\]
空交通域按 Cλ=0。则
\[
\boxed{P_-\le\inf_{\lambda\ge0}U_\lambda\le
U_0=\tfrac14\mathop{\mathrm{ess\,sup}}_{E_-\times B}H.}
\tag{QE6}
\]
证明：记
\(a_\lambda=\int_{E_-}(1+\lambda r)d\Pi_t\)、
\(b_\lambda=\int_B(1+\lambda r)d\Pi_t\)。由互斥性及 QE2，
\[
a_\lambda+b_\lambda\le1+\lambda L_t,
\qquad
P_-\le C_\lambda a_\lambda b_\lambda
\le C_\lambda(a_\lambda+b_\lambda)^2/4\le U_\lambda.
\]
两个端点不能分别领取完整共同 Q 质量。若使用实际 μ(Zt)，可在同一证明中把 Lt 改成 Lt μ(Zt)，但不能把它同 QE4 的 good 活跃质量 m 混淆。

无需优化参数即可取 \(\lambda=1/L_t\)，得到
\[
\boxed{P_-\le\mathop{\mathrm{ess\,sup}}_{E_-\times B}
 H(v,u)\frac{L_t^2}{(L_t+r_v)(L_t+r_u)}.}
\tag{QE7}
\]
它直接保留实际 ρ，且与原 common α 为同一值，没有独立优化每个来源的 α。若对所有当前来源对都有
\((L_t+r_v)(L_t+r_u)\ge4(1+\epsilon)L_t^2\)，QE7 就比 U0 至少小 \((1+\epsilon)^{-1}\)；此条件只是一个可检充分条件，不假定一般成立。不同来源对的最优 λ 可能冲突，**不得**把 QE6 的 inf–sup 换成 sup–inf。

λ 是同一逐行代数不等式的自由参数，不是物理尺度或重新选择的来源。实际应用可仅取 λ=1/Lt，或取事先固定的可数 λLt 网格，避免选择可测性问题；这个代数选择不授权冻结实际 s,L,R,H,g,T。若由来源上确界得出的 Uλ 仍依 x、ν、j，则原外账依旧存在。

## 3. 必要约束优化的范围

QE6 可视为对概率变量 Π、共同 moment \(\int r\,d\Pi\le L_t\) 的二次上证书，但证明本身没有改动实际 Π。原 r、score、good/bad、ρ 与 α 均以同一个实际行评价。假想地在这些特征固定后改变 Π，只是必要约束外放松，通常无法保持原 Q、e、q、α 及来源位置的联合实现性，因此不能把松弛最优点称为 FULL 来源几何。

尤其，即使 terminal good 有 rg≥1，t时刻 r=rg wg/wt 仍可很小；必要约束没有给正的统一成本下界，QE6 不保证每行都严格改善。共同 α 对 source 核的额外关联没有被删除为自由 α，但本证书也没有证明它能把一般 Uλ 的外价降为根阶。当前进展限于真实可用且可检的共同归一上证书。

## 4. 冻结后的有限检查：最终补集

正式证据为同目录 `q_extremal_plan.md`、`q_extremal_check.py`、`q_extremal_check.json`。脚本先写入并冻结 SHA，随后只执行一次，输入改变或输出已存在时拒绝运行。未重算原核，未扩展来源菜单。此前有一次临时探索使用不同的基础补集 r<(n+1)ρ；这里只披露该历史，不用其统计描述当前余部。

正式输入是数值代理最终 `numeric_margin.json`（SHA `0f504950a5b4d7dc94e362171c0153c114fc601194e16e5df1d6f220c958798b`）和冻结 `r146_numeric_score.json`。当前补集按 QE4 用保存十进制数的 Fraction 严格比较，原 ρ 保留；检查所有 E−×bad 正 score pair，Ψ/FA 明确正放松。正式网格固定为 λ=0 或 λ=10^(k/4)/Lt，k=−32,…,32，共66个全行共同 λ，与探索相同，未扩大。网格最小值是已评价的上帽，不是连续 infλ 的认证。

537个 receiver-time 行中352行补集正交通域非空，185行为空。352个非空行的网格上帽都严格小于 U0；以下 ratio 为网格帽/U0，保留原三个阶段：

| 原样本组 | 总行数 | 非空行数 | ratio 最小 / 中位 / 最大 |
|---|---:|---:|---:|
| I1 initial | 6 | 2 | 0.37970 / 0.41246 / 0.44522 |
| I1 expanded | 27 | 9 | 0.34189 / 0.38385 / 0.42147 |
| P1 initial | 75 | 53 | 0.008883 / 0.072397 / 0.46030 |
| P1 pressure | 15 | 0 | 空交通域，不形成 ratio |
| P1 expanded | 414 | 288 | 0.008042 / 0.074461 / 0.50601 |

补集标签不一致0，浮点上界违例0；每个非空 case/stage 预定选第一行和相对改善最强行，去重后7行，以已选 λ 的十进制打印值形成合法有理 λ，再用 Fraction 精确检查共同质量帽、逐边支配、AM–GM、最终上界及相对 U0 的严格改善，全部通过。它们认证的是保存十进制数据的有限代数，**不是**真实核或原标签的区间认证。例 I1 receiver_time_id=0：U0≈0.762156，证书≈0.289391，实际正放松交通≈0.0128565；P1 receiver_time_id=302：U0≈2，证书≈0.0160832，实际正放松交通约3.95×10⁻²⁴。后例同时说明证书可以显著改善 U0 而仍远离实际交通，不能由相对改善推断一般 sharpness。

原 FA 内部当前剩余记录153点，与输入数值代理一致；它不是153个独立接收点，也不是全窗积分。对同一物理 receiver 的不同时间记录没有免费合并费用。输出 `q_extremal_check.json` SHA为 `03d49ef3c7e98f57e01c55e798ff4eaa25d03511e3cb3b8a788295f25d63be23`；完整输入、脚本和计划 SHA 均保存在输出。

初探给出一般 QE6；已有样本压力检查发现它在最终补集上仍有严格的有限上帽改善；扩大到一般输入只保留解析证书，不外推样本维数阶或接收预算。

## 5. RT2 回代与未付内容

令 P− 尚未乘 2Λ。QE6 的实际使用是把原 terminal 剩余正槽替换为
\[
2\Lambda\mathbb E\sum_{V,j}\int q^{-1}p_xh_R(x-z)
\,U_\lambda(x,y,z,t)\,dx\,d\beta(y)d\nu(z)\frac{dt}{t},
\tag{QE8}
\]
保留全部原 history、时间窗、旧已付补集和层级资格。两份 \(w/e_t\) 已在 QE5 的 Π²中使用；来源上确界不等于来源费用已消尽，Uλ仍含实际 r、ρ、Lt。只有得到相应统一可付款帽后才可按原合同处理唯一 j 与尺度。

尚须证明 QE8 不超过 \(\varepsilon X+C_\varepsilon\sqrt n\log^A(2+n)W_\beta\)。精确欠缺的是在共同 Q 的真实三核混合、原门及同一 ν 下，控制剩余低成本来源对的上确界随接收点变化的外价；不能用 independently attainable r 或 ρ 的极值替代该联合几何。原主分支付款不再领取一次，原 Ψ 内负项、futurebad、Ndel及其余未覆盖资格原位保留。本稿不声称一般目标闭合。
