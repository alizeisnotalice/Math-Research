# R147 exact time-gate checks

All 21 frozen time cases and 8 common-source budget cases passed with exact Fraction arithmetic. Dimensions tested:1,2,4,8,16,32. No quadrature, approximate roots, old posterior/channel records, or new receiver samples were used. This is a finite algebra and endpoint audit, not a FULL/general theorem established by numerics.

## Direct piece certificate

At every threshold breakpoint, w=∏min(1,a_i/t) is continuous. On each open segment w=c t^(−k), so dw=−kw dt/t and r=C/w is nondecreasing. For fixed ρ>0, let cap=C/(Nρ). Direct integration gives

`J_segment=(ρ/C)[min(w_lo,cap)−w_hi]_+`.

The sum of these independently constructed segment values was checked against

`J=[min(ρ/r_τ,1/N)−ρ/r_h]_+`.

Each value is between0 and1/N. The exact residual was zero in every case. For a partial gate, its start solves t^k=c/cap; JSON stores this rational right-hand side, degree and exact rational isolating interval, without needing a floating time root.

All eight gate types occurred: constant empty, constant equality, constant full, empty, endpoint-only at h, full, partial, and ρ-zero traffic. Seven partial segments required an algebraic start equation. Boundary equality was interpreted with the closed gate r≥Nρ; isolated times carry no dt/t mass, and a whole constant equality segment has k=0, hence zero integral. A threshold equal to a window endpoint affects only k at a measure-zero point and was retained in the endpoint checks.

Key exact cases:

- id1: n1,a=1/2,window[1/4,2],ρ=1/2,C=1,N=2. Gate is on equality throughout the first constant segment and full afterward; J=3/8.
- id2 has equality only at h (r_h=Nρ), so J=0, despite the endpoint belonging to the closed gate.
- id4 has constant w=1 and r=Nρ on the entire window, but k=0 and J=0.
- id5 has ρ=0 and gives J=0 without dividing byρ. The gate itself holds, while its traffic is zero.
- id7: n2,a=(1/2,1/2),window[1/4,2],ρ=1/2,N=3,cap=17/32. The start is t=sqrt(8/17); J=5/17 exactly.
- id8 has the gate start exactly at a score breakpoint t=1/2 and J=31/160.
- id9 is genuinely empty, including the terminal time. id10 is a constant full gate with zero score.
- ids11/12 useρ=1 and10^-6 and C scaled by the frozen C=Nρcap rule. Both have J=63/325; the equality does not assert that varyingρ with fixed C leaves J unchanged.

Every time case is listed below; all use N=n+1. Threshold vectors, complete rational windows, C, endpoint ratios, equality points and each piece integral are in JSON and the prewritten plan.

|id|stage|n|ρ|J (display)|gate segments|
|---:|---|---:|---:|---:|---|
|1|initial|1|1/2|0.375|constant_equality, full|
|2|initial|1|1/2|0|constant_empty_gate, endpoint_only_hi|
|3|initial|1|1/2|0.3|constant_empty_gate, partial|
|4|initial|2|1/2|0|constant_equality|
|5|initial|2|0|0|rho_zero_traffic, rho_zero_traffic, rho_zero_traffic|
|6|initial|2|1/2|0.151041666667|constant_full_gate, full, full|
|7|pressure|2|1/2|0.294117647059|constant_empty_gate, partial|
|8|pressure|4|1/2|0.19375|endpoint_only_hi, full, full|
|9|pressure|4|1/2|0|constant_empty_gate, empty|
|10|pressure|4|1/2|0|constant_full_gate|
|11|pressure|4|1|0.193846153846|partial, full, full|
|12|pressure|4|1/1000000|0.193846153846|partial, full, full|
|13|expanded|8|2/3|0.111099667019|full, full, full, full|
|14|expanded|8|2/3|0.111088225285|partial, full, full, full|
|15|expanded|8|2/3|0|empty, empty, empty, endpoint_only_hi|
|16|expanded|16|2/3|0.0588235244196|full, full, full, full|
|17|expanded|16|2/3|0.0588235194274|partial, full, full, full|
|18|expanded|16|2/3|0|empty, empty, empty, endpoint_only_hi|
|19|expanded|32|2/3|0.030303030303|full, full, full, full|
|20|expanded|32|2/3|0.030303030303|partial, full, full, full|
|21|expanded|32|2/3|0|empty, empty, empty, endpoint_only_hi|

## Common-source budget and normalization

For every source i, C_i=KQ_i/p, μQ_i=ν_iQ_i/q, e_t=Σν_iw_i(t), L_t=Kq/(p e_t). Each source ν is a common probability measure, and μQ is a subprobability because q≥ΣνQ; μQ was never renormalized. The exact identity `Σ_i L_t μQ_i/r_i(t)=1` was checked at every common segment endpoint. This checks that q,p,Q,ν and C belong to the same finite model.

The high condition was imposed at h by p=λKq/e_h with λ≥2. Since e_t is nonincreasing, the full window has L_t≤L_h=1/λ≤1/2. The verified source certificate is

`cap=(1/2)Σ_i μQ_i J_i ≤ μQ_total/(2N) ≤1/(2N)`.

This source cap is not asserted to equal the actual L-weighted integral. On the common threshold partition, L is nondecreasing and all gate integrands are nonnegative. Using L_lo/L_hi times the exact per-source J_i,segment gives strict rational lower/upper bounds for

`A=∫_τ^h L_t Σ_i μQ_i [ρ_i k_i(t)/r_i(t)]1{r_i(t)≥Nρ_i} dt/t`.

Thus `A_lower≤A≤A_upper≤cap` was checked exactly. No approximate integration of A is hidden in the source certificate. The following ratios use target=1/(2N).

|source menu|n|μQ total|L_h|cap/target|A_lower/target|A_upper/target|
|---|---:|---:|---:|---:|---:|---:|
|four_source|1|1|0.5|0|0|0|
|four_source|2|0.8|0.33333333|0|0|0|
|four_source|4|1|0.5|0.0595512686098|0.0479761745862|0.0595512686098|
|four_source|8|0.8|0.33333333|0.42622348708|0.270321269942|0.284051711697|
|four_source|16|1|0.5|0.683665772389|0.536332668381|0.675765598774|
|four_source|32|0.8|0.33333333|0.547368397887|0.114852277579|0.364464377357|
|near_saturation|4|1|0.5|0.989734378979|0.900598999801|0.989734378979|
|near_saturation|16|1|0.5|0.99|0.961989139754|0.99|

The two near-saturation cases were specified algebraically before execution, not optimized after seeing the results. Their first source has r_τ=N,ρ=1; a tiny decaying source and a constant source satisfy the same commonν/high condition. At n16, cap/target≈.99 and the true L-weighted integral is at least .961989139754 of the target. This shows the finite cap need not have a large numerical slack. It does not establish a sharp universal constant or an original-geometry realization.

## Scope and execution

The time formula requires positive C,N, positive thresholds, a fixed full window and fixedρ. All are met here. No time-varyingρ, moving endpoint, nonmonotone r, posterior renormalization after deletion, or adaptive receiver selection was tested. The source aggregation uses only the declared high bound and μQ subprobability; it does not show that this time branch exhausts the original traffic, nor pay the complementary low gate, history/scale/source geometry, futurebad or Ndel.

The producer executed once; all29 cases and all exact assertions passed, with no failure or recovery. Script/plan SHA256 and exact rational outputs are saved in JSON. Only these four owned files were written; no Git/PDF/old-file edits. Work stops at delivery.
