#!/usr/bin/env python3
"""Finite saved-row diagnostic for the shared-lambda certificate; no kernel calls."""
from pathlib import Path
from fractions import Fraction
import hashlib
import json
import math
import statistics
import re
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parent
PLAN = ROOT / 'q_extremal_plan.md'
INPUT_NAMES = ['numeric_margin.json', 'r146_numeric_score.json']
GRID_K = list(range(-32, 33))
BRANCH_KEY = 'slack_2Lg_shared_m_r_t_ge_2Nstar_Lg_m_rho'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def frac(x):
    return Fraction(str(x))

def execute():
    plan = PLAN.read_text()
    expected = {}
    for name in INPUT_NAMES:
        hit = re.search(re.escape(name) + r' SHA256: ([0-9a-f]{64})', plan)
        if not hit:
            raise RuntimeError('Missing frozen input SHA: ' + name)
        expected[name] = hit.group(1)
        if sha(ROOT/name) != expected[name]:
            raise RuntimeError('Input changed: ' + name)
    script_hit = re.search(r'q_extremal_check.py SHA256: ([0-9a-f]{64})', plan)
    if not script_hit or script_hit.group(1) != sha(Path(__file__)):
        raise RuntimeError('Script differs from frozen plan')
    margin = json.loads((ROOT/'numeric_margin.json').read_text())
    scoredata = json.loads((ROOT/'r146_numeric_score.json').read_text())
    original = {r['receiver_time_id']: r for r in scoredata['receiver_times']}
    models = scoredata['time_models']
    references = {}
    for row in margin['sample_references']:
        references.setdefault(row['receiver_time_id'], []).append(row)
    records, exact_contexts = [], {}
    mismatch = 0
    for row in margin['receiver_time_margins']:
        rid = row['receiver_time_id']
        old, src = original[rid], row['sources']
        scores = models[row['time_id']]['score']
        N = int(row['Nstar'])
        assert N == 2*row['n']+3
        threshold_factor = 2*N*frac(row['Lg'])*frac(row['shared_m'])
        good = []
        for i,s in enumerate(src):
            eligible = bool(old['good'][i]) and frac(s['rho'])>0 and frac(s['r_t'])<threshold_factor*frac(s['rho'])
            if bool(old['good'][i]) and frac(s['rho'])>0:
                saved_eligible = not s['shared_mass_branches'][BRANCH_KEY]
                mismatch += int(eligible != saved_eligible)
            if eligible:
                good.append(i)
        bad = [i for i in range(len(src)) if old['bad'][i]]
        assert not set(good).intersection(bad)
        edges = [(float(src[v]['rho'])*(scores[v]-scores[u]),float(src[v]['r_t']),float(src[u]['r_t']),v,u)
                 for v in good for u in bad if scores[v]>scores[u]]
        L = float(row['L'])
        record = dict(receiver_time_id=rid,case=row['case'],id=row['id'],stage=row['stage'],time_id=row['time_id'],n=row['n'],N=N,
                      L=row['L'],Lg=row['Lg'],shared_m=row['shared_m'],remaining_good_indices=good,edge_count=len(edges))
        if not edges:
            record.update(independent_cap=0.0,lambda_grid_cap=0.0,positive_relaxation=0.0,ratio_to_independent=None,chosen_lambda='0',chosen_grid_k=None)
        else:
            base = max(e[0] for e in edges)/4
            candidates = [(0.0,None)] + [(10**(k/4)/L,k) for k in GRID_K]
            values = [((1+la*L)**2/4*max(h/((1+la*r)*(1+la*s)) for h,r,s,_,_ in edges),la,k) for la,k in candidates]
            best,la,k = min(values,key=lambda x:x[0])
            actual = sum(h*float(src[v]['Pi'])*float(src[u]['Pi']) for h,_,_,v,u in edges)
            record.update(independent_cap=base,lambda_grid_cap=best,positive_relaxation=actual,ratio_to_independent=best/base,
                          chosen_lambda=str(la),chosen_grid_k=k,float_bound_violation=actual>best+1e-12)
            exact_contexts[rid]=(row,good,bad,scores,edges,record)
        for flag in ['original_FA_closed','original_FA_strict_interior']:
            refs=[s for s in references.get(rid,[]) if s['v'] in good and s[flag]]
            record[flag+'_remaining_sample_count']=len(refs)
            record[flag+'_remaining_rho_pointweight']=sum(float(s['rho_scoreweight']) for s in refs)
        records.append(record)
    summary={}
    for case,stage in sorted({(r['case'],r['stage']) for r in records}):
        rr=[r for r in records if r['case']==case and r['stage']==stage]
        nonempty=[r for r in rr if r['edge_count']]
        ratios=[r['ratio_to_independent'] for r in nonempty]
        summary[case+'/'+stage]=dict(rows=len(rr),nonempty_rows=len(nonempty),zero_rows=len(rr)-len(nonempty),
            strictly_improved_rows=sum(x<1-1e-10 for x in ratios),
            ratio_min=min(ratios) if ratios else None,ratio_median=statistics.median(ratios) if ratios else None,ratio_max=max(ratios) if ratios else None,
            float_bound_violations=sum(r.get('float_bound_violation',False) for r in rr))
    # At most two saved rows per stage: first, and greatest relative improvement.
    selected=set()
    for key in summary:
        case,stage=key.split('/')
        rr=[r for r in records if r['case']==case and r['stage']==stage and r['edge_count']]
        if rr:
            selected.add(rr[0]['receiver_time_id'])
            selected.add(min(rr,key=lambda r:r['ratio_to_independent'])['receiver_time_id'])
    rational=[]
    for rid in sorted(selected):
        row,good,bad,scores,edges,record=exact_contexts[rid]
        src=row['sources']; la=frac(record['chosen_lambda']); L=frac(row['L'])
        h=lambda i: 1+la*frac(src[i]['r_t'])
        aa=sum((h(v)*frac(src[v]['Pi']) for v in good),Fraction())
        bb=sum((h(u)*frac(src[u]['Pi']) for u in bad),Fraction())
        C=max(frac(src[v]['rho'])*(scores[v]-scores[u])/(h(v)*h(u)) for _,_,_,v,u in edges)
        actual=sum((frac(src[v]['rho'])*(scores[v]-scores[u])*frac(src[v]['Pi'])*frac(src[u]['Pi']) for _,_,_,v,u in edges),Fraction())
        cap=C*(1+la*L)**2/4
        base=max(frac(src[v]['rho'])*(scores[v]-scores[u]) for _,_,_,v,u in edges)/4
        checks=dict(common_mass_bound=aa+bb<=1+la*L,edge_bound=actual<=C*aa*bb,
                    amgm=4*aa*bb<=(aa+bb)**2,final_upper=actual<=cap,strict_improvement=cap<base)
        rational.append(dict(receiver_time_id=rid,case=row['case'],stage=row['stage'],chosen_lambda=str(la),
                             cap_approx=float(cap),base_approx=float(base),actual_approx=float(actual),checks=checks,
                             interpretation='Exact Fraction arithmetic on saved decimal inputs and selected rational lambda; not a true-kernel interval certificate.'))
    assert mismatch==0
    assert all(all(r['checks'].values()) for r in rational)
    out=dict(status='saved_decimal_finite_row_diagnostic',execution_count=1,
        executed_utc=datetime.now(timezone.utc).isoformat(),script_sha256=sha(Path(__file__)),plan_sha256=sha(PLAN),input_sha256=expected,
        exploration_history=['One prior ephemeral exploratory run on the different base complement r_t<(n+1)rho; it is not currentremaining.'],
        branch='Eminus=terminal_good and rho>0 and r_t<2*(2n+3)*Lg*shared_m*rho; shared_m=mu(terminal_good and rho>0), unchanged by t/score.',
        positive_relaxation='All positive-score Eminus x original terminal bad edges; actual rho retained, Psi/FA relaxed only for this upper bound.',
        grid=dict(lambda_rule='lambda=0 or 10**(k/4)/L_t',k_min=-32,k_max=32,count=66,scope='one common lambda per entire receiver-time row, never per pair'),
        numerical_scope='Grid minimum is an evaluated upper bound, not a computed continuous infimum; saved floating kernel inputs are not FULL or interval-certified.',
        checks=dict(branch_label_mismatches=mismatch,float_bound_violations=sum(r.get('float_bound_violation',False) for r in records),
                    rational_checked_rows=len(rational),all_rational_checks_pass=all(all(r['checks'].values()) for r in rational)),
        summary=summary,rows=records,rational_checks=rational)
    target=ROOT/'q_extremal_check.json'
    if target.exists():
        raise RuntimeError('Output exists; do not overwrite a recorded execution silently')
    target.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(dict(checks=out['checks'],summary=summary,output_sha256=sha(target)),ensure_ascii=False,indent=2))

if __name__=='__main__':
    execute()
