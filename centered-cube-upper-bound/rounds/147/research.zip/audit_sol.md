# R147 Sol 独立先审：完整 Q 的有效裕量与共享质量

状态：未读本轮作者稿。只核原 R117 JG3–4、R128 RT4–5、R122 逐来源 FTC 的必要片段，及上一轮冻结 SJ 的原 Q 定义；本轮只写本文件，不改他人文件，不运行 Git。

## 1. 同一原量的精确换测度

固定原实际 \(\omega,V,j,x,y\)、全部接收参数和整条原远窗。令
\[
Q_v=Q_x^*(v)=[P_{s,L}(x-v)+P_{s,L^+}(x-v)+J_b(x-v)]/3,
\quad d\mu_Q(v)=Q_vd\nu(v)/q,
\]
\[
r_t(v)=\frac{KQ_v}{p\,w_t(v)},\qquad
L_t=\frac{Kq}{pe_t}.
\]
Q 是原三核平均，不能换成 J 或捕获核 \(K_0\)。FIRST 给 \(\mu_Q(\mathbb R^n)\le1\)，所以它是**子概率**。原 \(\nu\)、q、Q、p 在随后 t 积分及外 hard z 积分中固定；它们可以依已经固定的接收行。

在原正有限商域，准确身份为
\[
\boxed{d\Pi_t=L_t\,1_{Z_t}\,d\mu_Q/r_t.}
\]
若定义 \(\mu_{Q,t}=1_{Z_t}\mu_Q\) 才可省略 \(1_{Z_t}\)。它不是“重新用删源后质量归一化 Q”的概率。

原 high 为 \(pe_g\ge2Kq\)。由 \(t\le g\)、原非增删源资格及 \(w_t\ge w_g\)，有 \(e_t\ge e_g\)，故 \(0<L_t\le1/2\)。对任意非负 f，
\[
\int f r_t\,d\Pi_t=L_t\int_{Z_t}f\,d\mu_Q,
\quad
\int_{Z_t}\frac{f}{r_t}d\mu_Q=L_t^{-1}\int f\,d\Pi_t.
\]
特别 \(\mathbb E_{\Pi_t}r_t\le L_t\le1/2\)，\(\int_{Z_t}r_t^{-1}d\mu_Q=1/L_t\)。这两个不同测度的矩不能互换。一般负矩 \(\mathbb E_{\Pi_t}r_t^{-1}\) 没有从 high 得到统一帽。

## 2. terminal 裕量不能直接作当前 r 的下界

明确采用 logarithmic terminal margin
\[
a_g(v)=\log\frac{KQ_v}{pw_g(v)},\quad
\Delta_t(v)=\log\frac{w_t(v)}{w_g(v)}\ge0.
\]
则 \(\log r_t=a_g-\Delta_t\)。terminal good 只给 \(a_g\ge0\)，不给整条窗 \(r_t\ge1\)。更粗但正确的是 \(r_t\ge w_g/w_t\ge(t/g)^n\)；宽窗下这可以很小。若作者采用线性 margin \(A_g=KQ_v/(pw_g)-1\)，对应公式应为 \(r_t=(1+A_g)e^{-\Delta_t}\)，不能混用加法。

一般 threshold Markov \(\Pi_t\{r_t\ge R\}\le L_t/R\) 是上述旧 high/FIRST 的直接后果。R117 JG4 已明确 terminal bad 的后验质量至少一半，等价于 terminal good 质量至多一半；因此 \(r_g\ge1\) 的半质量结论不是本轮新定理。R128 RT4 的原 FA 为 \(r_t<K B_{FA}\delta\)，是上门，不能改作本轮需要的下门。

原正交通含 \(\rho_vd\Pi_t=L_t\rho_vd\mu_Q/r_t\)。因此有利于保留小 \(\rho\) 来源的自然下门是 \(r_t\ge N\rho_v\)，等价于 \(r_t/\rho_v\ge N\)（仅在 \(\rho_v>0\) 上），**不是** \(\rho_vr_t\ge N\)。后者也是一个更窄的可估子支，但不能拿来覆盖前者或全部原正来源。

## 3. 独立核验主代理转发的 time-flux 候选

仍固定完整实际接收行。原 terminal \(\rho_v\in[0,1]\) 在整条窗不重算，且
\[
-d(1/r_t)=\frac{k_t(v)}{r_t(v)}\frac{dt}{t}.
\]
这是原 \(w_t\) 的逐来源连续 FTC；严格坐标阈值不令 w 跳跃。r 非减，原 \(Z_t\) 删除只能降低正项。对于 \(\rho_v>0\)、固定 N>0，
\[
\rho_v\int_\tau^h\frac{k_t(v)}{r_t(v)}
1_{\{r_t(v)\ge N\rho_v\}}\frac{dt}{t}\le\frac1N.
\]
边界等号仅影响零时间质量；\(\rho=0\) 原贡献为零，不形成商。

原 pair 门、\(\Psi\)、FA 和额外 history 只在取得正上界时放松。由 \(\delta\le k_t(v)\) 及 bad posterior 质量至多 1，先对原两来源和**完整实际时间窗**积分，得到
\[
\int\!\iint\rho_v\delta1_{\{r_t\ge N\rho_v\}}d\Pi_t(u)d\Pi_t(v)\frac{dt}{t}
\le\frac12\int d\mu_Q(v)\,\frac1N\le\frac1{2N}.
\]
此式未冻结接收参数：它们本来在固定 x 上随 t 固定；也未要求不同 j 的 \(\nu\)、\(\mu_Q\) 相同。若原模型另有随 t 重选参数，或 \(\rho\) 随 t 变化，本 FTC 阈值证明不能照搬，必须另证。

随后只用一次原实际 hard 帽 \(q^{-1}\int h_Ra_\omega d\nu(z)\le16/3\)。外 hard 来源和全部时间已经消尽，得到逐实际 \(j,x,y\) 不含 p 的共同数值 \(8/(3N)\)。此后才用唯一 j 与 JT13 的同带接收包络，而非再次乘时间 \(\log2\)：
\[
2\Lambda P_N\le16\Lambda\frac{(2n+3)D_n}{N}W_\beta,
\qquad D_n\le3\sqrt n.
\]
取 N=n+1 即 \(\le120\Lambda\sqrt nW_\beta\)。常数及次序正确。付款仅针对原正交通与新下门的交集，须先去掉全部旧已付正支；不能据此覆盖其阈值补集或改原负项。

## 4. 共享原质量的两个增强下门

令 \(E_+=G\cap\{\rho>0\}\) 是原 terminal 来源集合，固定在 t 和外 hard z 积分之前，定义
\[
m=\mu_Q(E_+),\qquad M_\rho=\int_{E_+}\rho_vd\mu_Q(v).
\]
两者均取同一原 q、Q、\(\nu\)、G、\(\rho\)，不按来源 v 独立重选。若 m 或 \(M_\rho\) 为零，相应原正交通由换测度身份直接为零，不计算分母。

对 m>0 的下门 \(r_t\ge Nm\rho_v\)，逐 v 的 FTC 为 \(\rho\int k/r\le1/(Nm)\)，之后对同一个 \(\mu_Q(E_+)\) 积分恰消 m。对 \(M_\rho>0\) 的下门 \(r_t\ge NM_\rho\)，逐 v 为 \(\rho\int k/r\le\rho/(NM_\rho)\)，同源积分恰消 \(M_\rho\)。两种完整正子支均得到 **time-source 帽 \(1/(2N)\)**，故同样的外付款公式成立。

这不是为每个 v 发一份 \(\mu_Q\) 容量；同一固定总量在外 μ 积分中只取消一次。也不能按时间片、score 层或候选来源子集分别归一化后免费求和。若两个下门取并集，可分别付款或先作不交划分，安全价格是两笔之和，不能免费逐来源挑选较好的证明。

取 N=2n+3，每个下门分别有 \(2\Lambda P\le16\Lambda D_nW_\beta\le48\Lambda\sqrt nW_\beta\)。其实际价值还须核查：新下门在原旧已付补集、\(\Psi\) 与 FA 的真实交集上是否有非零贡献，覆盖何种旧难例；不能只报删门后的命中率。

## 5. 限定历史去重与成功标准

限定检索实际命中 R117 JG3–4 的原完整 Q/high/terminal 半质量、R128 RT4–5 的原 FA 上门及三测试 FIRST、R122 的旧逐来源 FTC，以及 R135 terminal 储备小条带的 FTC 付款。它们证明基本归一及 FTC 方法已有。此限定核心检索未命中第 4 节两个具体共享质量下门；不宣称已经遍历 R117–146 全史，也不把“未命中”当作新颖性定理。

本轮可接受成果是上述同原测度、同原 Q 的具体下门付款及其完整补集；若数值能严格映射原合法记录且显示它覆盖既有 low/FA 正交通，可登记可验证新分支。一般目标还需对两个下门之外的原剩余、全部层级总价、futurebad、\(N_{del}\) 与原 \(\Psi\) 内负账各保留一次。原 FA 定义不改，\(Q^*\) 不换 J，共同 \(\nu\) 不另行删源重算。先审结束，等待指定作者及新数值后审。

## 6. 最终主门保留原 high slack 的独立检查

主代理后续转发主门 \(r_t\ge2NL_gm\rho_v\)，其中 \(L_g=Kq/(pe_g)\)、N=2n+3。它保持第 4 节相同的固定 \(E_+,m\)，不是按当前 score 重选来源。

原逐行 \(L_t\le L_g\)，故不用统一粗帽 1/2，而有
\[
\int\!\iint\rho_v\delta1_{\{r_t\ge2NL_gm\rho_v\}}d\Pi_t^2\frac{dt}{t}
\le L_g\int_{E_+}\rho_vd\mu_Q(v)
\int\frac{k_t(v)}{r_t(v)}1_{\{r_t\ge2NL_gm\rho_v\}}\frac{dt}{t}
\le\frac1{2N}.
\]
最后一步是逐来源 FTC 后的 \(L_g\mu_Q(E_+)/(2NL_gm)\)，只取消一次同源 m。原正有限域 \(L_g>0\)；m=0 时原正交通为零。该主门的时间/来源帽及第 4 节 \(48\Lambda\sqrt n\) 外价通过。它与旧半质量上界一致，但利用真实 \(L_g\) 可覆盖更多来源；此数值大小不能按当前来源另行优化。

## 7. numeric_margin 冻结实现及独立复核

已先读 `numeric_margin.py`、计划和 JSON，再读说明；未以作者摘要代替代码。最终绑定 SHA-256：

- py：`a136275cc1710f779a49bfa95b339a066a1493101cfd1777f7047cdb6e8a9618`
- plan：`ecd5a9ca9a1210d5a24d63ca1969dfd1d918e1109fcce585bfd49c472e719477`
- json：`0f504950a5b4d7dc94e362171c0153c114fc601194e16e5df1d6f220c958798b`
- notes：`c909aca82d155b1322097210056844d00b3984509a7247de9da1fe008fa02591`

JSON 内 plan/script SHA 已核对。代码的 Gplus 精确定义为同 receiver **全部 terminal good 且 \(\rho>0\)** 来源，未用当前 k、\(\delta\)、FA 或样本 v 过滤；positive CORE 即使当前 score 为零仍在 m 中。m、\(M_\rho\)、\(L_g\) 用原 Q、同一 R142 exact ν、原 R136 \(w_g\)、原 q 计算，三个时间值相同；主 flag 为 \(r_t\ge2NL_gm\rho\)，不是 \(\rho r_t\) 下门。

本审计另外用 Fraction 对 2517 个 \(\rho>0\) source/receiver-time 的**同一保存输入**核主 flag。由取消 q、K、p 后的有理条件
\[
Q_v e_g\ge2Nw_t(v)\rho_v\sum_{a\in E_+}Q_a\nu_a
\]
直接比较，全部与保存 flag 一致。此检查未新增点、kernel、时间积分或菜单，也未重跑 producer。它验证保存 Q/\(\rho\) 与 32 位 w 的代数，不把 80/120 位运算稳定性称为真实核区间精度。

代码明确区分原 FA_closed／strict-interior 与 printed-time saved-cap closed／strict-interior，沿用上一轮已审端点差异。点权使用旧 \(\rho\delta\Pi_v\Pi_u\) 的有限点值，不含 dt/t、dx 或抽样密度归一；补充阈值和早期 N+1 的残余示例没有冒充最终主门补集。

**未覆盖 I1 早端已如实保留。** 代码/JSON 独立核到原 FA_closed 的 I1 lo_right 33 点主门覆盖为 0、剩余点权比例 1；几何中点 33 点全覆，hi_left 原 closed 记录为 0。按原 FA_closed 合并时 I1 初探/扩大仍约 50.63% 点权未覆，不能因中点全覆宣称原时间窗付清。P1 far B 来源的严格正残余也未因 float 覆盖率接近 1 而清零。

执行账四次及最后一次 Decimal 汇总精度修订已公开，最终 JSON 的 \(\mu_Q\) 总质量、\(L_g\le1/2\)、\(L_t\le L_g\)、共享质量不随时间、原 Q 三分量平均检查均按保存输入通过。6 个 posterior time-models、179 receiver、537 receiver-times、2070 重复 pair/time 保存记录的口径未变。数值声明范围通过，未发现需更正的实现问题。

## 8. 共同 λ 证书的独立推导与作者稿初审

在读本轮作者稿前，独立固定实际一行、当前 t 和互斥 \(G'\)、B，令 \(H=\rho_v\delta\psi\ge0\)。对**全行同一个** \(\lambda\ge0\)，设
\[
a_\lambda=\int_{G'}(1+\lambda r)d\Pi_t,\quad
b_\lambda=\int_B(1+\lambda r)d\Pi_t,\quad
C_\lambda=\operatorname{ess\,sup}_{G'\times B}\frac{H}{(1+\lambda r_v)(1+\lambda r_u)}.
\]
由互斥和同一份 moment，\(a_\lambda+b_\lambda\le1+\lambda L_t\)，所以
\[
P\le C_\lambda a_\lambda b_\lambda
\le\frac{(1+\lambda L_t)^2}{4}C_\lambda.
\]
可对完整右端再取 inf；不能逐 pair 选 λ 后仍使用同一个共同 moment 帽。\(\lambda=1/L_t\) 给作者的 QE7，系数正确。

随后已读 `q_extremal.md` 当前稿。QE1 保留 \(1_{Z_t}\)，QE4 用本轮主门的严格补集、同一个 terminal m 与 \(L_g\)，B 为原 \(D_0\)，两端互斥；QE5 保留实际 \(\rho\)，FA/\(\Psi\) 只明确正放松。QE6–7 符合上述独立证明。可用实际 \(L_t\mu_Q(Z_t)\) 紧化 moment，但它与 good 活跃 m 不同，作者已区分。

QE8 的上确界仍依原接收 x、共同 ν、\(\rho\)、\(L_t\) 与 j，完整 hard/\(\beta\)/time/层级外价未被消除。作者明确尚无这个 sup 的一般付款；不能把 λ 的共同上证书视为新的根阶支付。待作者最终稿和正式 check 冻结后仅作绑定后审，不扩展数值菜单。

## 9. q_extremal 正式稿与检查程序最终绑定

最终 SHA-256：

- `q_extremal.md`：`fb6aa9e240f2d83238c74f7ae806341603afdc5f8f3139192b1309012c4c5dfb`
- `q_extremal_check.py`：`40a6463752e7c0a2f311d74b19dae2071ce7dd40d5583596f604e554051eecdf`
- `q_extremal_plan.md`：`70ed7b71ba9ccae5cda21ed5725742620e627852ce68e3eed337450592856320`
- `q_extremal_check.json`：`03d49ef3c7e98f57e01c55e798ff4eaa25d03511e3cb3b8a788295f25d63be23`

本次核对正文最终第 4 节、计划、正式程序与输出。JSON 内 input/script/plan SHA 均对应当前冻结文件。正式程序准确使用主门严格补集 \(r_t<2(2n+3)L_gm\rho\)，检查标签匹配；G− 来自原 good/\(\rho>0\) 子集，bad 是同一原 posterior 的 terminal bad，两者没有重归一。score 从同一个冻结 time-model 读取，实际 \(\rho\) 保留；\(\Psi\)/FA 被明示正放松，故 `positive_relaxation` 不冒充原带门交通。

实现对每个完整 receiver-time 先形成全部正 score edges，再对每个 λ 取整个 edge supremum，最后才在 66 个共同 λ 上取最小。没有逐 pair 选 λ、inf–sup 换序或将不同好项拼接。网格仅生成一个已评价上帽，不是连续 inf 的认证。选定 7 行的 Fraction 检查以已选 λ 的打印值作为一个有理共同 λ，确实分别检查共同质量帽、逐边支配、AM–GM 和最终上界；这些是保存 decimal 输入的有限代数检查。

从输出独立核到：537 行、352 非空行，352 行浮点网格上帽均小于 U0；分支标签不匹配和浮点上界违例均 0；7 行 Fraction 所列检查全通过。程序/计划及正文都保留探索使用旧补集的运行历史，正式统计没有复用该旧补集。原 FA 内部剩余 153 条是重复 source/time 点记录，未称作独立 receiver 或 dt/dx 积分。

**最终判定：通过声明范围，无需更正。** QE6–7 是同一原测度、共同 moment 的合法上证书；有限补集点上有可审数值改善，但其 sup 的完整接收外价仍未支付，不新增一般根阶付款。第 6 节主分支的解析付款与第 7 节真实旧点覆盖是另一个明确结果，不将二者的余部交给本证书自动核销。一般目标、完整补集及原负账继续保留。只修改本审计文件，没有新采样、producer 重跑、Git 或他人文件编辑；本次范围结束。
