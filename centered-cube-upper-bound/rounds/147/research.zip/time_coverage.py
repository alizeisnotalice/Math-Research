#!/usr/bin/env python3
"""Closed-form full-time coverage of the same179 saved original receivers."""
import sys,json,hashlib,time,datetime,importlib.util,argparse
from fractions import Fraction as F
from pathlib import Path
from collections import defaultdict
sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
import mpmath as mp
ROOT=Path(__file__).resolve().parent
ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--input-root',default='/Users/zhengzhihao/Desktop/T/output',help='Root containing the original centered_cube_round136/142/143 input directories');args=ap.parse_args();BASE=Path(args.input_root).expanduser().resolve()
PATHS=dict(source=BASE/'centered_cube_round136_20261014/active_traffic_v2.json',receiver=BASE/'centered_cube_round142_20261015/numeric_receiver.json',primitive=BASE/'centered_cube_round143_20261015/numeric_flux.py',oracle=BASE/'centered_cube_round142_20261015/time_primitive_check.json',margin=ROOT/'numeric_margin.json')
spec=importlib.util.spec_from_file_location('audited_closed_primitive',PATHS['primitive']);old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def fr(x):return F(str(x))
def jf(x):return F(int(x['numerator']),int(x['denominator']))
def mm(x):return mp.mpf(x.numerator)/x.denominator if isinstance(x,F) else mp.mpf(x)
def dec(x,n=65):return mp.nstr(mm(x),n)
def exact(x):return dict(numerator=str(x.numerator),denominator=str(x.denominator))
def integ(ss,nu,i,j,lo,hi):
 if hi<=lo:return mp.mpf(0)
 ks=ss['k'];cs=list(map(fr,ss['c']));levels=sorted(set(ks));assert ks[i]>ks[j];groups={k:sum(nu[v]*cs[v] for v in range(6) if ks[v]==k) for k in levels}
 if len(levels)==2:
  d=levels[1]-levels[0];assert ks[i]-ks[j]==d;A,B=map(mm,[groups[levels[1]],groups[levels[0]]]);z0,z1=lo**(-d),hi**(-d);return mm(nu[i]*nu[j]*cs[i]*cs[j])*(z0-z1)/((A*z0+B)*(A*z1+B))
 assert len(levels)==3 and levels==[0,8,16];d=8;A,B,C=[groups[k] for k in reversed(levels)];ix={(2,1):0,(2,0):1,(1,0):2}[(levels.index(ks[i]),levels.index(ks[j]))];pl=old.primitive(lo**d,A,B,C)[ix];ph=old.primitive(hi**d,A,B,C)[ix];return mm(nu[i]*nu[j]*cs[i]*cs[j])*(ph-pl)
def calculate(cid,r,c,nu,tab,precision,oracle):
 with mp.workdps(precision):
  n=c['n'];N=2*n+3;K=fr(c['parameters']['K']);p,q=map(fr,[r['p'],r['q']]);rho=list(map(fr,r['rho']));Q=list(map(fr,r['Q']));gp=[i for i in range(6) if r['good'][i] and rho[i]>0];Qmass=sum((nu[i]*Q[i] for i in gp),F(0));m=Qmass/q;eg=sum(nu[i]*fr(c['atoms'][i]['wg']) for i in range(6));Lg=K*q/(p*eg);whole=paid=residual=mp.mpf(0);caps=[];clipcount=0
  for cp in r['traffic']['FA_caps']:
   s=c['score_segments'][cp['segment']];i,j=cp['v'],cp['bad'];ks=s['k'];kv=ks[i];assert r['good'][i] and r['bad'][j] and rho[i]>0 and gp and c['pairs'][6*i+j]['Psi'] and kv-ks[j]==cp['delta']>0 and kv>0
   rawlo,rawhi=map(fr,[cp['lo'],cp['hi']]);lo,hi=max(rawlo,fr(s['lo'])),min(rawhi,fr(s['hi']));assert hi>lo;clipped=(rawlo!=lo or rawhi!=hi);clipcount+=clipped;cf=fr(s['c'][i]);Ci=K*Q[i]/p;T=2*N*Lg*m*rho[i];capw=Ci/T;cancel=Q[i]*eg/(2*N*rho[i]*Qmass);assert capw==cancel;power=cf/capw
   if power<=lo**kv:branch='full';entry=mm(lo)
   elif power>=hi**kv:branch='empty';entry=mm(hi)
   else:branch='partial';entry=mp.power(mm(power),mp.mpf(1)/kv)
   a,b=mm(lo),mm(hi);ww=mm(rho[i])*integ(s,nu,i,j,a,b);pp=mm(rho[i])*integ(s,nu,i,j,entry,b) if branch!='empty' else mp.mpf(0);rr=mm(rho[i])*integ(s,nu,i,j,a,entry) if branch!='full' else mp.mpf(0);assert min(ww,pp,rr)>=0;err=abs(ww-pp-rr)/max(ww,mp.mpf('1e-1000'));assert err<mp.mpf('1e-60');whole+=ww;paid+=pp;residual+=rr
   caps.append(dict(segment=cp['segment'],v=i,u=j,v_name=c['atoms'][i]['name'],u_name=c['atoms'][j]['name'],delta=cp['delta'],rho=str(rho[i]),original_FA_lo=str(rawlo),original_FA_hi=str(rawhi),effective_lo=str(lo),effective_hi=str(hi),score_domain_clipped=clipped,removed_time_length=str((lo-rawlo)+(rawhi-hi)),gate=branch,gate_threshold=dec(T),entry_power_degree=kv,entry_power_exact=exact(power),effective_entry=dec(entry),whole=dec(ww),paid=dec(pp),residual=dec(rr),residual_fraction=dec(rr/ww) if ww else None,conservation_relative=dec(err,25)))
  err=abs(whole-paid-residual)/max(whole,mp.mpf('1e-1000'));assert err<mp.mpf('1e-60');factor=p*fr(r['hardmass'])/q;W,P,R=[mm(factor)*x for x in [whole,paid,residual]];ref=fr(oracle[r['id']]['F_raw']) if cid=='P1' else fr(r['traffic']['F_raw']);reldiff=abs(W-mm(ref))/W if W else mp.mpf(0);assert reldiff<mp.mpf('1e-8');marginerr=max(abs(mm(m)-mp.mpf(tab['shared_m']))/max(mm(m),mp.mpf('1e-1000')),abs(mm(Lg)-mp.mpf(tab['Lg']))/mm(Lg));assert marginerr<mp.mpf('1e-28')
  return dict(case=cid,id=r['id'],n=n,stage=r['stage'],distribution=r['distribution'],precision=precision,main_gates_pass=all(r['gates'].values()),accepted_original_positive=r['traffic']['positive_raw'],Gplus=gp,m_exact=exact(m),m=dec(m),Lg_exact=exact(Lg),Lg=dec(Lg),muQ_total=dec(sum(nu[i]*Q[i]/q for i in range(6))),N=N,e_g=dec(eg),margin_rebuild_max_relative=dec(marginerr,25),internal_whole=dec(whole,precision),internal_paid=dec(paid,precision),internal_residual=dec(residual,precision),outer_saved_factor=dec(factor),F_whole=dec(W,precision),F_paid=dec(P,precision),F_residual=dec(R,precision),residual_fraction=dec(residual/whole) if whole else None,conservation_relative=dec(err,25),baseline_reference=str(ref),baseline_relative_difference=dec(reldiff,25),score_endpoint_clip_count=clipcount,uncertain=r['uncertain'],caps=caps)
def summarize(rows):
 W=sum((mp.mpf(r['F_whole']) for r in rows),mp.mpf(0));P=sum((mp.mpf(r['F_paid']) for r in rows),mp.mpf(0));R=sum((mp.mpf(r['F_residual']) for r in rows),mp.mpf(0));return dict(receiver_count=len(rows),finite_record_F_whole_sum=dec(W),finite_record_F_paid_sum=dec(P),finite_record_F_residual_sum=dec(R),finite_record_residual_fraction=dec(R/W) if W else None,positive_residual_receiver_count=sum(mp.mpf(r['F_residual'])>0 for r in rows),max_receiver_residual_fraction=max([float(r['residual_fraction']) for r in rows] or [0]),max_baseline_relative_difference=max([float(r['baseline_relative_difference']) for r in rows] or [0]),max_80_120_relative_change=max([float(r['precision_check_max_relative']) for r in rows] or [0]),raw_FA_endpoint_clip_count=sum(r['score_endpoint_clip_count'] for r in rows))
def main():
 start=time.monotonic();mp.mp.dps=140;data={k:json.loads(p.read_text()) for k,p in PATHS.items() if k!='primitive'};src={c['id']:c for c in data['source']['cases']};tabs={}
 for t in data['margin']['receiver_time_margins']:tabs.setdefault((t['case'],t['id']),t)
 assert len(tabs)==179;oracle={r['id']:r for r in data['oracle']['records']};selected=[]
 for cid,cc in data['receiver']['cases'].items():
  for r in cc['records']:
   if (cid,r['id']) in tabs:selected.append((cid,r,cc))
 assert len(selected)==179;selected.sort(key=lambda x:({'initial':0,'pressure':1,'expanded':2}[x[1]['stage']],x[0],x[1]['id']));rows=[]
 for cid,r,cc in selected:
  assert all(r['gates'].values()) and r['traffic']['positive_raw'];nu=list(map(jf,cc['nu_exact']));args=(cid,r,src[cid],nu,tabs[(cid,r['id'])]);low=calculate(*args,80,oracle);high=calculate(*args,120,oracle);errs=[]
  for key in ['internal_whole','internal_paid','internal_residual','F_whole','F_paid','F_residual']:
   a,b=mp.mpf(low[key]),mp.mpf(high[key]);errs.append(abs(a-b)/max(abs(b),mp.mpf('1e-1000')) if b else abs(a))
  change=max(errs);assert change<mp.mpf('1e-40');high['precision_check_max_relative']=dec(change,30);high['low80']={k:low[k] for k in ['internal_whole','internal_paid','internal_residual','F_whole','F_paid','F_residual','conservation_relative']};rows.append(high)
  if len(rows) in [27,32,179]:print('completed',len(rows),summarize(rows),flush=True)
 out=dict(status='completed_closed_form',producer_execution_count=4,completed_producer_count=3,execution_history='Initial successful run printed row integrals at65 digits, hiding 80/120 differences below display precision. Second attempt changed row serialization to native80/120 but a broad replacement also touched summary code and raised NameError at27 rows before writing output. Third run repairs summary formatting, preserves native80/120 comparisons, and completes identical179 receivers/gate/primitive/intervals; no kernel or menu change. Fourth run adds only --input-root portability before PATHS/primitive import, records mpmath version, and repeats the same computation.',input_root=str(BASE),mpmath_version=mp.__version__,scope='Full saved time on original FA caps for same179 necessary-positive receivers; no kernels,new dx/receiver sampling,quadrature,FULL or dx-integral inference',input_sha256={k:sha(p) for k,p in PATHS.items()},script_sha256=sha(Path(__file__)),plan_sha256=sha(ROOT/'time_coverage_plan.md'),precision_digits=[80,120],summary=summarize(rows),strata={},records=rows,max_residual_examples=sorted([dict(case=r['case'],id=r['id'],stage=r['stage'],distribution=r['distribution'],residual_fraction=r['residual_fraction'],F_whole=r['F_whole'],F_paid=r['F_paid'],F_residual=r['F_residual']) for r in rows],key=lambda r:mp.mpf(r['residual_fraction']),reverse=True)[:12],elapsed_seconds=time.monotonic()-start,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 for stage in ['initial','pressure','expanded']:
  for cid in ['I1','P1']:out['strata'][stage+'/'+cid]=summarize([r for r in rows if r['stage']==stage and r['case']==cid])
 for cid in ['I1','P1']:out['strata'][cid]=summarize([r for r in rows if r['case']==cid])
 for dist in sorted(set(r['distribution'] for r in rows)):out['strata']['distribution/'+dist]=summarize([r for r in rows if r['distribution']==dist])
 sources=defaultdict(lambda:[mp.mpf(0),mp.mpf(0),mp.mpf(0)])
 for r in rows:
  for cp in r['caps']:
   key=r['case']+'/'+cp['v_name'];factor=mp.mpf(r['outer_saved_factor'])
   for i,k in enumerate(['whole','paid','residual']):sources[key][i]+=factor*mp.mpf(cp[k])
 out['source_strata']={k:dict(F_whole=dec(v[0]),F_paid=dec(v[1]),F_residual=dec(v[2]),residual_fraction=dec(v[2]/v[0]) if v[0] else None) for k,v in sources.items()};(ROOT/'time_coverage.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print('FINAL',out['summary'],'seconds',out['elapsed_seconds'],flush=True)
if __name__=='__main__':main()
