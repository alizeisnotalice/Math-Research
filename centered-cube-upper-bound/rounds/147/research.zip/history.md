# R147 限定查重：测试核子概率与原终端余权的时间通量门

**查重结论：限定 R117–146 的相关文档中，未定位到准确分支 \(r_t\ge N\rho_v\) 的完整根阶付款。** 最近已付结果是 R119 的 \(r_t\ge KB_{FA}\delta_t\) 门；最近时间工具是 R135 AF3–10 的下降通量/人为面积权。二者都不能把本轮原终端 ρ 门直接认作旧已付支。可登记的新增范围仅是所有旧已付正支补集内的该门，尤其旧 FA 不足域中的 \(N\rho_v\le r_t<KB_{FA}\delta_t\)；不重复登记交集。

## 1. 检索和实读范围

仅按测试比、似然、ρ、score、FTC/通量、归一化及付款关键词定向检索 R117–145 的相关 score/high/flux/future/joint/time/capacity 文件；追读 R119 `quantitative_future.md`、`statement_audit.md`、`proof_audit.md` 的准确门与费用，R130 `joint_source_budget.md` JSB1–6，R134 `fa_time_geometry.md` FT1–7，R135 `area_flux.md` AF1–14，R136 `ordered_score_capacity.md` OS1–13，R140 `joint_transport.md` JT12–14，R143 `flux_prior_audit.md` FPA1–3。R146 作者已经归档：只从 `rounds/146/research.zip` 内存读取 `scale_joint.md` 与 `round_report.md`，没有解压或更改原包。未通读全史，不将未命中升级为全库不存在。

已读 A01 安装技能及 `references/method.md`、`provenance.md`。这里只用其正分母、零行和共同归一化检查，不引用未读外部论文或 CCT/SOS 定理；本轮不需外文定理。

## 2. 最邻近旧式及差别

| 旧位置 | 准确公式/已付量 | 与本轮的边界 |
|---|---|---|
| [R119 quantitative_future.md:56](/Users/zhengzhihao/Desktop/T/output/centered_cube_round119_20261014/quantitative_future.md:56)，FA6、FA9–15；同轮 `proof_audit.md` 数学 PASS | \(\ell_t=Q/(pw_t)\)，\(\ell_t\ge B\delta_t\)；同一 Q 的 FIRST 预算给时点源对≤\(1/(2KB)\)，全远时 signed 价≤\(4\Lambda\log2\,X/(KB)\)。选择 \(B=B_{FA}\) 付既有 ε_FA X 槽。 | 本轮 \(r_t=K\ell_t\)，故旧门正是 \(r_t\ge KB_{FA}\delta_t\)。它用 score 门直接消去一份 wt，未写 \(r_t\ge N\rho_v\) 或全时间 \(1/N\) 通量。旧 FA 同时覆盖 terminal good 和 futuredeleted，不能在本轮 terminal 支外误删 futurebad。 |
| [R134 fa_time_geometry.md:14](/Users/zhengzhihao/Desktop/T/output/centered_cube_round134_20261014/fa_time_geometry.md:14)，FT1–7 | \(\ell_t=L_g e^{-\Delta}\)，good 与 FA 不足门给 \(1/K\le L_g<B\delta e^\Delta\)；低面积层有显式时间价格 Φ_n(D)。 | 夹层不是高 Δ 衰减，也没有以真实 ρ 为同 t 测试比阈值的通量付款。 |
| [R135 area_flux.md:36](/Users/zhengzhihao/Desktop/T/output/centered_cube_round135_20261014/area_flux.md:36)，AF3–10 | \(-dw_t=k_tw_tdt/t\)；\(\int k_tw_tf(\Delta)dt/t=w_g\int e^zf(z)dz\)。若人为 \(f=e^{-a\Delta}1_{\Delta\ge d}\)、a>1，则有 AF10 完整 X 价。 | 作者明确 f 不来自原 ρ，不能删 f 付款原项。AF11–12确认 terminal ρ 固定；AF14 若改用归一化势会增加 \(H E_\Pi k\) 及删除误差。本轮通过固定 Q 子概率和 \(1/r_t\) 通量处理，不能被称为重证 AF10 人为权。基础 FTC 本身仍是旧工具。 |
| [R136 ordered_score_capacity.md:57](/Users/zhengzhihao/Desktop/T/output/centered_cube_round136_20261014/ordered_score_capacity.md:57)，OS6–13 | bad score 平均后留下 \(mW_m/e_t\)；借 \(K_0/(Tw_g)\) 几何层后对 good 的 \(k_tw_t\) 做 FTC，仍有 \(Q_J/e_g^2\) 和余量平方/逆 J 的外费用。 | 已知道“把 m 留给 FTC”，但不是全 Q、\(\mu_Q\) 与 \(r_t\ge N\rho_v\) 的同次门；没有登记本轮准确支付款。 |
| [R140 joint_transport.md:177](/Users/zhengzhihao/Desktop/T/output/centered_cube_round140_20261015/joint_transport.md:177)，JT13–14 | \(\int\sup_{s,L\in[a,b]}P_{s,L}(x-y)dx\le3(2n+3)D_n\)，\(D_n\le3\sqrt n\)。消尽三来源且有共同数值帽之后才可合并唯一 j；时间窗均在[a,b]。 | 接收包络和唯一 j 处理本身均为旧工具。本轮若已取得**整时间**帽，不应再把它误当 JT14 的时点帽乘一遍 log2；应直接使用 JT13 回代。 |
| R146 归档 `scale_joint.md` SJ2、SJ5、SJ10–13 | 完整 \(Q^*=(K_1+K_2+J)/3\) 的 good/bad 区间，以及窄带/带权宽似然尾分解；真实来源/接收费用未付。 | 仍为两个来源的 \(Q_vw_g(u)/(Q_uw_g(v))\) 比及门质量问题，未出现本轮单来源 \(r_t\ge N\rho_v\) FTC 截尾；R146报告明确无新增根阶付款。 |

R130 JSB2–6 的共同 logK 平均也只给 pair 对数间隔的阈值穿越概率，未提供本轮确定 K 下的原生 ρ 通量支。R143 FPA 的完整 cut/covariance 流另有反向边、删源和 Ψ 缺边，不能把其单位端点当作本轮 \(1/N\) 门帽。

## 3. 本轮准确候选为何不同；共同归一化检查

固定一条原合法实际行及固定 terminal good 来源 v。要求同一 p>0、q>0、Q(v)>0、\(e_t\ge e_g>0\)、\(0\le\rho_v\le1\)；ρ、p、Q 在整段 t 中固定，ν 不重选。定义
\[
d\mu_Q(v)=Q(v)d\nu(v)/q,\qquad
r_t(v)=\frac{KQ(v)}{p w_t(v)},\qquad
L_t=\frac{Kq}{pe_t}\le\frac12.
\tag{NH1}
\]
FIRST 给 \(\mu_Q(\mathbb R^n)\le1\)：这是**次概率测度**，不得重新归一化后丢其质量。准确恒等式为
\[
d\Pi_t(v)=1_{Z_t}(v)\frac{L_t}{r_t(v)}d\mu_Q(v).
\tag{NH2}
\]
第一份 Π 的 bad 端可在正上界中用 \(\delta_t\le k_t(v)\)、\(\Pi_t(D_0)\le1\) 消去；另一份通过 NH2 保留。两份 e 的去向分别明确，不是假定 e 绝对下界。

因为 \(d r_t/d\log t=k_t r_t\)，ρ>0 时对完整原窗有
\[
\int_\tau^h\frac{\rho_vk_t(v)}{r_t(v)}
1_{\{r_t(v)\ge N\rho_v\}}\frac{dt}{t}
=\rho_v\left[\frac1{\max(r_\tau(v),N\rho_v)}-
\frac1{r_h(v)}\right]_+
\le\frac1N.
\tag{NH3}
\]
r 的平台上 k=0，不需严格可逆；阈值有限折点对连续时间积分无额外原子。ρ=0 直接取零，不能用0/0。比这完整窗更小的原正时间门可删作上界；本门只加给欲付款正项，原负项不附该门。terminal 支持使 v 在整窗存活；futurebad 不借用此固定终端合同。NH3 是本轮准确新候选的短检查，不将其基本微积分另记为新定理。

再按同一 \(\mu_Q\) 积分，NH2、L≤1/2、μQ质量≤1给整时间内源帽 \(1/(2N)\)。先在原 actual x 用一次 hard 帽16/3，得到 \(8/(3N)\)。此时所有三来源与时间已消尽，才删其余正门，合并唯一 j 并用 JT13。其 signed 价为
\[
2\Lambda\frac8{3N}\,3(2n+3)D_nW_\beta
=16\Lambda\frac{2n+3}{N}D_nW_\beta.
\tag{NH4}
\]
N=n+1 时 \((2n+3)/(n+1)\le5/2\)，从而≤\(120\Lambda\sqrt nW_\beta\)。这里没有额外 dt/t、log2、j菜单，也不能在 raw 外测度已付 hard 后再乘16/3。本段确认常数和旧回代接口的区别；最终是否合法覆盖本轮全部 qualification，仍以作者及两份独审的原域核对为准，不以历史未命中代替该审查。

A01 的实际用途仅是 NH1–2 正分母/零行/同一归一化：保持原整份 Q、q、ν、p、wt、et；不为每个来源另选 Q/q，不将 μQ 改为 Π 或 Jν/QJ，不把各 j 的概率认成相同概率。原正软核排除有限位置 Q=0；若使用扩展零核模型，必须先取零交通或只在正密度支持上形成商，不能用未定义抵消。没有使用分式优化或外部 CCT 定理。

## 4. 与旧付款的精确交叠和完整补集

令 Ω_old 是进入本轮前所有已付正支的并集。只在其补集的原 terminal 正交通上新增
\[
E_N=\{\rho_v>0,\delta_t>0,r_t(v)\ge N\rho_v\}.
\]
就 R119 FA 门而言：

- 旧 FA 已付：\(r_t\ge KB_{FA}\delta_t\)。与 E_N 的交集条件为 \(r_t\ge\max(N\rho_v,KB_{FA}\delta_t)\)，不能第二次登记。
- 原 FA 不足域中的新候选：\(N\rho_v\le r_t<KB_{FA}\delta_t\)，仍需保留原 Ψ、ρ、terminal资格、history及全部旧已付补集；只有它在本轮实际域中有贡献时才减少剩余量。
- terminal 剩余：原 Ω_old 补集内 \(r_t<N\rho_v\) 的原正项。它还满足原 FA 不足门 \(r_t<KB_{FA}\delta_t\)。两阈值无一般同序，不能把任一低门自动删掉。ρ=0或δ=0行本来零贡献。

N门与旧 FA 门不互相包含：当 δ 很小而ρ较大，可能先命中旧 FA；当δ较大而ρ较小，本门可先命中。原来已付的 high-c、core、capture 等也须先去重；本报告未重审这些各自预算，不能把 E_N 的整个泛域统称全部“新付”。

原 futurebad、Ndel、Ψ内负项及其全部 time/history照旧各保留一次；本轮不借 NH3 返还已消费 N_Z。本检索没有验证新增分支在既有数值点中的覆盖率，更不以样本命中替代一般原域证明。

**新颖性边界：** 旧 FTC、旧高测试比 FIRST 容量、旧 hard 帽与旧唯一 j/JT13 均已存在；限定历史未定位到“固定原终端ρ作为同 t 测试比门槛→1/N整窗帽→根阶Wβ”的准确组合。可将这个在原旧付款补集上的组合列为待最终原域审定的新分支付款，不能说新的归一化理论或一般闭合。只写本文件，无Git、无其他文件修改，交付停止。
