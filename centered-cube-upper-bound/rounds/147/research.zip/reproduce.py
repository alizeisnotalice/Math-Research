#!/usr/bin/env python3
"""Reproduce R147 in a fresh directory using archived inputs; keep frozen results intact."""
import argparse,json,shutil,subprocess,sys,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--rounds',type=Path,required=True);ap.add_argument('--destination',type=Path,required=True);a=ap.parse_args();dst=a.destination.resolve();dst.mkdir(parents=True,exist_ok=False)
stems=['numeric_margin','time_gate_check','q_extremal_check','time_coverage']
for stem in stems: shutil.copy2(ROOT/(stem+'.py'),dst/(stem+'.py'))
for name in ['numeric_margin_plan.md','time_gate_check_plan.md','q_extremal_plan.md','time_coverage_plan.md']:shutil.copy2(ROOT/name,dst/name)
items=[(139,'active_traffic_v2.json','centered_cube_round136_20261014/active_traffic_v2.json'),(142,'numeric_receiver.json','centered_cube_round142_20261015/numeric_receiver.json'),(142,'time_primitive_check.json','centered_cube_round142_20261015/time_primitive_check.json'),(143,'numeric_flux.py','centered_cube_round143_20261015/numeric_flux.py')]
for n,member,rel in items:
 with zipfile.ZipFile(a.rounds/str(n)/'research.zip') as z:
  p=dst/'inputs'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(member))
with zipfile.ZipFile(a.rounds/'146/research.zip') as z:(dst/'r146_numeric_score.json').write_bytes(z.read('numeric_score.json'))
def norm(x):
 if isinstance(x,dict):return {k:norm(v) for k,v in x.items() if k not in {'elapsed_seconds','executed_utc','finished_utc','started_utc','input_root'}}
 if isinstance(x,list):return [norm(v) for v in x]
 return x
for stem in stems:
 args=[sys.executable,str(dst/(stem+'.py'))]
 if stem in ['numeric_margin','time_coverage']:args+=['--input-root',str(dst/'inputs')]
 subprocess.run(args,check=True)
 result=dst/(stem+'.json');frozen=ROOT/(stem+'.json')
 assert norm(json.loads(result.read_text()))==norm(json.loads(frozen.read_text())),stem
 if stem=='numeric_margin':
  shutil.copy2(result,dst/'numeric_margin.replayed.json')
  shutil.copy2(frozen,result) # Downstream inputs are SHA-bound to the frozen timestamped JSON.
 print('VERIFIED',stem,flush=True)
print('PASS all four deterministic outputs, excluding execution timestamps/durations and relocatable input_root')
