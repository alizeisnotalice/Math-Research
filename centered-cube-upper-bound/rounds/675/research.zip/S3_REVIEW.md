# R675 S3 independent bounded mathematical review

Verdict: PASS within the precise scope below. No mandatory mathematical correction was found in that scope. This does not certify the general upper bound or supply a terminal/source-reuse payment.

## Source binding and scope

Reviewed source SHA-256 values:

- REPORT.tex: c59bba3675ca18d066d8e3d64955842a351afb8d7551147c761629487ee6d466
- S2_ALLOCATION.md: 3630b4a8a97125f0245d2861397b388e725b6a451aacae1b65d071258330efde

Derived the deletion/capture constant before reading the author files. Independently recomputed the prefix/suffix mass bookkeeping, reserve limitation and dual-charge identity while checking their formulations in REPORT section 3 and section 6 (the dual paragraph is actually the last paragraph of section 6), and S2 sections 2–5. The latter checks were independent algebraic verification but were not fully blinded to the author text. The inherited short-sample theorem and prefix growth inequality were accepted exactly as supplied in the review contract. Their historical proofs were not reopened. REPORT sections 4–5 cap normalization/geometric payment were outside this review and are not certified here. The other reviewer's cap work is not repeated.

This was an analytic audit. No numerical experiment was rerun, no MATLAB/Git/PDF task was undertaken, and no source file was edited. Only this review file was written.

## 1. Robust deletion and the shared receiver union

Write D=d nu for the one deletion debit, 0<=d<=1/5. The retained rate is (1-d)nu>=4nu/5=mu. For each original assigned witness the retained captured rate is at least (4/5-d)nu. Therefore its probability of belonging to one retained sampled parent is at least

    (4/5-d)/(1-d) >= 3/4.

The inequality is exact, with equality at d=1/5. One common iid k-tuple serves the entire unchanged receiver group. If all its sampled parents contain z_h, then the expanded intersection contains X_h, since X_h is contained in z_h+c0 beta Q. Thus disjointness of the actual X_h and Tonelli give

    (3/4)^k v_a <= E|expanded intersection|
                 <= 3 N_a exp(-2k),
    v_a <= 3 N_a exp(-(2-log(4/3))k).

No independence among different receivers' detection events is required. The common seed, retained genuine owner portions, parent-radius condition and retained rate threshold are all preserved by one such deletion.

One deletion vector per anchor yields nonnegative coefficients and exact objective sum_i d_i b_i(e)=sum_a v_a=Vrem. Clearing multiple arrangement-cell representatives requires deleting every parent meeting their union, with exact debit Q_a(E)=sum_i t_i,a 1{A_i meets E}; separate per-point low loads do not renew the deletion allowance. The report correctly declines to transfer the old high-part estimate to the changed normalization.

Receiver-specific restriction is separately valid before deletion: its rate is at least mu, all retained parents contain the actual witness, and |X_h|<=3 N_h exp(-2k) follows from the supplied theorem with deterministic capture. After spending the full anchor deletion allowance, that restricted population is guaranteed only 3nu/5<mu, so the two applications cannot be spliced. Direct witness-based rate-nu profiles are a different valid construction, as S2 explicitly states.

## 2. Prefix, suffix, reserve and the terminal mass

Let sigma=nu-mu=tau/16 and epsilon=exp(-sigma/c). The supplied prefix growth inequality gives M(mu)/M(nu)<=epsilon. Splitting the prefix into p(mu) and p(nu)-p(mu) gives an exact convex decomposition of normalized kernels, each integrating to one. Consequently the old prefix contributes at most epsilon of each receiver's objective, while the new increment contributes at least 1-epsilon. Summing over the unchanged actual receiver pieces proves the stated Vrem bookkeeping. The small old coefficient does not pay the increment.

The suffix p(nu)-p(sigma) has rate nu-sigma=mu and mass

    Q=M(nu)-M(sigma)>=(1-exp(-mu/c))M(nu).

Since sigma<mu, its overlap with the old mu-prefix has mass M(mu)-M(sigma), whose fraction of Q is at most epsilon/(1-exp(-mu/c)). Thus its last sigma increment carries at least 1-epsilon/(1-exp(-mu/c)) of its normalized objective. This verifies the qualitative suffix concentration statement; it does not assert the stronger prefix fraction 1-epsilon for the suffix. S2 uses the correct denominator.

The actual reserve is T-nu>tau/16-2c>0 for n>=256. In particular any extra amount up to tau/16-2c is available, but the lower reserve alone does not guarantee an additional full sigma=tau/16 step. The current wording claims only further finite extensions and is consistent with that distinction. Since T<=tau, repeated fixed positive-size extensions have finite total available rate. Neither the report nor S2 claims that the final transport component is globally paid. No terminal estimate follows merely from a vanishing old-prefix fraction.

## 3. Dual charge

For f>=0 in L1, finite positive parent volumes d_i and G_i=int_Ai f>=d_i, all G_i are finite and positive. With N_a=sum_i d_i s_i,a>0, direct integration gives

    int c_a = (v_a/N_a) sum_i (d_i s_i,a/G_i) G_i
            = (v_a/N_a) N_a = v_a.

The q-load bound gives sum_i q_i G_i<=tau int f, by Tonelli. It does not bound the anchor-dependent reuse factors in sum_a c_a. For q_i>0 these factors are sum_a (v_a/N_a)(s_i,a/q_i); terms with q_i=0 vanish. No missing control of that weighted reuse is hidden inside the charge identity. The final paragraph correctly records an exact allocation identity and an unsuccessful global connection, rather than an improved packing bound.

## Disposition

PASS for the robust joint price, the one-budget quantifier, restriction/deletion separation, prefix/suffix objective transfers, positive-but-finite reserve, and dual-charge identity/unpaid-reuse status. No actual-contract counterexample, general packing theorem, cap-profile theorem or new terminal payment is certified by this review.
