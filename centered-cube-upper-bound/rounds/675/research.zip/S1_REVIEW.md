# R675 cap profile 独立审查：最终限定范围

**PASS，无剩余必须修改项。** 本文件最终签署范围为作者A1的cap构造、主REPORT(8)–(17)及它们与原完整账的接口。先独立重推关键式，再实际读取A1/REPORT对照。stream disconnect前未持久化的推导没有冒充已交付；已保存恢复检查点后完成本次比对。robust/prefix-suffix/dual段由另一个独立Sol负责最终签署，本文件不宣称单人覆盖全部主稿。

## 1. 完整合同与cap存在性

实际n≥256、τ=16384√n、ν=5τ/16、c=c₀ⁿ≤32/31。原R670强合同是T(J)>3τ/8−2c=ν+τ/16−2c，且T≤τ，不是只给T>ν。由此Δ=T−ν>τ/16−2c≥τ/32=:Δ₀。

对正q标签，g(D)=Σqᵢmin(1,D/dᵢ)从0连续上升到T，在D<最大正q体积时严格递增。故g(D)=ν有唯一0<D<dmax解，ties不会导致多值；零q可略。所选tᵢ是真实Fi内可实现的portion，不改原q/I/Poisson。必须重新用这个profile做80%capture并形成同一Vrem的新partition，不能沿用旧group而不核overlap。

## 2. 真实容量、负boundary term与exact P

令H(u)=Σ_{dᵢ≤u}|Fi|。common seed z及Fi真不交给H(u)≤cu。以di=D的atoms归small，tail retained rate为

r_D=D∫_(D,∞)u⁻²dH(u)
   =−H(D)/D+2D∫_D^∞H(u)u⁻³du
   ≤2c−H(D)/D。

finite family使∞边界为0。负的H(D)/D项不可丢作正费用。设h=H(D)/D，则

M=H(D)+DΣ_{dᵢ>D}qᵢ， Δ=Σ_{dᵢ>D}qᵢ−r_D，

P=M/D=Δ+γ， γ=h+r_D∈(0,2c]。

严格正来自D<dmax的正q tail。因此ΔD<M≤(Δ+2c)D，并且

tᵢ/M=qᵢ/[P·max(dᵢ,D)]≤(32/τ)qᵢ/max(dᵢ,D)。

这些式子与REPORT(8)–(11)一致，未把generic scalar capacity当成已实例化cube geometry。

## 3. 固定tail系数的真实objective

small mass=H(D)≤cD，所以small/M≤c/Δ₀。n≥256给τ/32≥8192，因而c/Δ₀≤1/7936。每个anchor的tail profile rate≤2c，但其owner mass fraction≥7935/7936。

对新实际payments va/Ma求和，fixed original-family tail subvector确有

Σdi b_i^tail≥(7935/7936)Vrem。

这是固定系数objective分解；不与R674随x选high/low的field分解混淆。cap profile可有许多partial标签，因此不能继承旧one-partial L2误差界；但R674 high theorem和moment诊断本来允许任意合法ν-profile。重新capture后的sameν/source≥β/commonpoint/真实Fi条件满足，故旧high moment对新groups合法，给termwise low-tail integral≥(1−1/7936−δ_n)Vrem。没有混用旧分组或旧μ数据。

删全部tail的rate≤2c≤ν/5，故与另签的robust lemma接口合法，保留small质量H(D)给REPORT(14)的va≤ξH(D)。该单group价不能再乘到一个已求和的receiver union体积上：仍缺occupied density或source reuse预算。

## 4. 真几何localization与恒空far分支

ν>2c使H(D)>0，否则ν=r_D≤2c。因所有来源半径≥β，R=D^(1/n)≥2β。captured witness在small部分的重叠rate至少4ν/5−2c>0，所以有small parent同时含seed与该witness。small source半径≤R/2，故二者距离≤R；真实Ya⊂Q(za,R+c₀β)。这是真containment，不把整个enlarged cube当actual receiver。

然而原G始终有si<nα<nβ≤nR/2。因此拟议si≥nR的far antecedent对每个实际source恒空。作者与REPORT已明确撤回其“新付款”解释；本轮不能把真但vacuous的far implication算进展，也未擅自改阈值另开路线。

## 5. 完整tail核与原总账

对tail di>D_a，ti/Ma=qi/(P_a di)，故REPORT(17)的exact核为

L_tail(x)=Σi [qi1Ai(x)/di]Σ_{a:i∈Ja,di>D_a}va/P_a。

stronger逐source column bound足以用原qload付款，但不是必要条件，实际q-weighted pointwise average亦可。两者均未证。actual receivers不交与上一节localization仅给constant-to-n的enlargement包络；单groupξ不能当作该union的density multiplier。

原完整账保持V₀≤Cadm[U+(Kfar+Kup)U/τ+Vrem]、P₀≥U/τ。cap没有新paid branch，dominant tail尚未有全空间Cτ界，因此没有新global payment或Cn阶改善。

## 6. 前置审查的量词门槛

原目标只需每个input存在一个合适的合法profile/seed policy及完整packing；“对任意合法ν-profile都统一控整核”是更强命题。R674 high部分确对任意合法ν-profile成立，但目前没有全核普遍结论，也没有本轮真实几何反例否定它。任何依赖选择的估计须固定一套policy/partition后同时检查全部原空间cells，不能逐test point另选profile冒充一个packing。

若x与zh不共享label，仍保留za∈Ai∩Aj、x∈Ai、zh∈Aj、si,sj∈[β,nα)、Xh⊂zh+c₀shQ及gG≤1整个Bh。它们给two-parent localizations，但Ai∩Aj不等于admission所控的定向center capture；不能将该relation免费套成已付source triangle。A1 exact two-source identity本身正确，未给global预算。新的cap明确指定了profile，但没有解决seed次数或tail column。

## 7. 最终版本与证据范围

最终实际读取SHA-256：

- REPORT.tex：`c59bba3675ca18d066d8e3d64955842a351afb8d7551147c761629487ee6d466`
- A1_LOW_GEOMETRY.md：`e24948b4a78689398017c4f94427cdd1fa2fafc2394a31f6fb9ed5e7b50efd82`

已读DECISION_CHECK.py及实际结果metadata：7 checks、6 scalar probes、3 atomic capacity fixtures。它们不是actual source/receiver实例，也不是general证明；本代理未重跑实验。初次SymPy结构相等assert失败属于verifier问题，最终用zero-difference化简的记录不改变上述解析证明。

本文件最终只认证cap/A1/REPORT对应范围和已有总账接口；S2 robust/prefix-suffix/dual由另一个Sol独立负责。无剩余cap必改项。只写本S1，无spawn/Git/PDF/重复数值，交付停止。
