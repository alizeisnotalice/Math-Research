# R675 A1 — two-source traffic and a capped-profile checkpoint

## Outcome and precise scope

The complete R674 low-load kernel is not bounded here by an absolute multiple of tau. Nor is a complete alternative feasible packing constructed. The useful new checkpoint is a legal capped auxiliary profile with an exact normalization bound, followed by a rigorous diagnosis: almost all of its objective is forced into a tail of total rate at most 2c, and the proposed small-dilation payment branch is **empty in the actual frozen source range**. Consequently that branch provides no new paid receiver mass.

All statements below retain the actual disjoint receivers and owners. No original q, radius order, I_h, self convention, witness, saturation rule, or random history is changed. The capped profiles in Sections 2–4 require rebuilding the auxiliary capture groups; they are not estimates for unchanged old groups. Their partition still covers exactly the same V_rem. The original kernel is used in Section 1.

Use n>=256, a=32n, c0=1+1/a, c=c0^n<=32/31, tau=16384 sqrt(n), nu=5tau/16, mu=4nu/5=tau/4, and k=ceil(128 sqrt(n)). Within one fixed subinterval [alpha,beta), beta/alpha=2^(1/n), every source in G has beta<=s_i<n alpha and d_i=(2s_i)^n. Each seed z_a has its true complete pool J_a={i in G:z_a in A_i}. The unweakened R670 bound is

    T_a=sum_{J_a}q_i > 3tau/8-2c.

Source pieces F_i are genuinely disjoint, |F_i|=q_i d_i, and F_i lies in the small concentric box B_i. The original source load is at most tau a.e. Each actual X_h is in B_h, and g_G<=1 throughout B_h. These conditions are preserved, not replaced by an abstract incidence model.

## 1. The same original low kernel: exact two-source interaction and robust price

For an original rate-nu profile t_i,a, let

    M_a=sum_i d_i t_i,a,
    m_a(x)=sum_i t_i,a 1_Ai(x),
    W_a(h)=sum_i t_i,a 1_Ai(z_h)>=4nu/5.

Its actual group Y_a is a disjoint union of actual X_h. For every assigned h the following two-source identity is exact:

    m_a(x)/M_a
      =sum_{i,j} t_i,a t_j,a 1_Ai(x)1_Aj(z_h)/(M_a W_a(h)).       (1)

Multiplication by |X_h| and summation preserves the actual v_a/M_a factor. Both sources see the seed z_a; one sees x and the other sees z_h. They need not coincide. Formula (1) does not provide a new budget by itself.

There is a useful genuine mass constraint for the region m_a(x)<=nu/5. Delete all selected labels whose parents contain x, and set

    M_out,a(x)=sum_{i:x notin A_i} d_i t_i,a.

The remaining rate is S=nu-m_a(x)>=mu. Every target in the same original group retains witness overlap at least 4nu/5-m_a(x). Its proportion of the remaining rate is at least 3/4. The retained parents still share z_a and have radii at least beta; their real auxiliary owner pieces remain disjoint. Therefore the certified R673 same-sample joint estimate gives

    v_a <= xi M_out,a(x),
    xi=3 exp[-(2-log(4/3))k].                                  (2)

In particular,

    v_a m_a(x)/M_a <= xi m_a(x) M_out,a(x)/M_a.                 (3)

This prevents a low-rate set at x from receiving an arbitrarily large payment merely because it carries nearly all of M_a: its complement must still pay the whole receiver group in (2). However, the deleted label set depends on x. Different points cannot be assigned independent deletions in one fixed packing; their union can exhaust the profile. Also the complements in (2) share their own seeds, not x. Thus (2) has no supplied common-at-x cumulative owner budget. No minimax or simultaneous-avoidance conclusion is inferred.

## 2. A legal replacement profile with a uniform normalization margin

For each actual seed pool J, choose the unique D>0 such that

    t_i=q_i min(1,D/d_i),       sum_{i in J}t_i=nu.              (4)

Existence and uniqueness follow from continuity and strict increase before full saturation, because T=sum_J q_i>nu. Every t_i is a legitimate portion of the original q_i. Choose actual auxiliary subsets of F_i of volume d_i t_i. Greedily capture targets using these new profiles and the same 80-percent test. The seed captures itself, so the finite procedure gives a partition of all actual remaining targets, with unchanged V_rem. The R673 joint theorem still applies.

Put

    Delta=T-nu >tau/16-2c >=Delta0:=tau/32,
    M=sum_i d_i t_i=sum_i q_i min(d_i,D).

The removed rate is

    Delta=sum_{d_i>D}q_i(1-D/d_i).

Consequently

    M >=D sum_{d_i>D}q_i >=D Delta,
    t_i/M <= q_i/[Delta max(d_i,D)].                           (5)

This bound uses the actual retained-load margin from R670, not merely T>nu. It does not require a pointwise evaluation of the old a.e. load bound at a boundary witness.

The real common-seed geometry gives an additional constraint. Define

    H(u)=sum_{i in J:d_i<=u}|F_i|.

All pieces counted by H(u) lie in Q(z_a,c0 u^(1/n)/2). Their disjointness implies

    H(u)<=c u.                                                (6)

For the large-volume tail of (4), its retained rate r_D obeys the exact Stieltjes formula

    r_D=sum_{d_i>D}t_i
       =D integral_(D,infinity) u^(-2) dH(u)
       =-H(D)/D+2D integral_D^infinity H(u)u^(-3)du
       <=2c-H(D)/D <=2c.                                     (7)

Atoms at D belong to H(D), hence to the small part. The finite upper support gives no boundary term at infinity. This establishes (7) for the actual finite source family, without continuity assumptions on its radii or owner pieces.

## 3. What this normalization actually does to the objective

Write M_small=H(D) and M_tail=M-H(D). Equations (5)–(7) imply

    M_small/M <=c/Delta0,
    M_tail/M >=1-c/Delta0,
    sum_{d_i>D}t_i<=2c.                                      (8)

Since c/Delta0<=1/7936 for n>=256, at least 7935/7936 of the objective of this new kernel lies on the tail coefficients. This is a fixed coefficient split, not the x-dependent R674 high/low split. More precisely, for the new groups,

    b_i^tail=sum_{a:d_i>D_a}(v_a/M_a)t_i,a,
    sum_i d_i b_i^tail >=(1-1/7936)V_rem.                     (9)

The rate of each anchor's tail is at most 2c, although its normalized mass can be almost all of M_a. Thus the capped rule has not removed the low-rate, large-mass obstruction; it has isolated it quantitatively.

Deleting the entire tail uses rate at most 2c<=nu/5. The same argument as (2), now with a deletion fixed for each anchor, gives the stronger true-group price

    v_a <=xi H_a(D_a)<=xi cD_a.                              (10)

The small source family has rate nu-r_D>=mu and retains at least a 3/4 fraction of capture for every actual assigned target. It is the genuine price certificate for (10). The tail family itself has rate at most 2c and is not eligible for the short-sample theorem at threshold mu.

Combining (9) with the certified R674 moment diagnostic, applied to these legal new rate-nu profiles, also gives

    integral [tail load restricted to m_a(x)<.9nu]
       >=(1-c/Delta0-delta_n)V_rem,

where the restriction is termwise in a and delta_n=3nu(.9)^(1-k)e^(-2k). This is a scope diagnosis, not a new pointwise bound. Almost all transport remains in the low part.

## 4. Exact geometry of the tail, and why the attempted payment branch is empty

Let R_a=D_a^(1/n). Because nu>2c, (7) forces a nonempty small part d_i<=D_a. All source radii are at least beta, so

    R_a>=2beta.                                              (11)

For every captured target h, its overlap with the small part is positive. Choose a small source seeing both z_a and z_h. Then

    ||z_h-z_a||_infinity<=R_a,
    Y_a subset Q(z_a,R_a+c0 beta).                           (12)

This is true localization of the actual Y_a, not its replacement by the whole displayed cube. For any tail source i, z_a belongs to A_i. A possible small-dilation allocation would work for sources satisfying s_i>=nR_a. But such sources do not exist in the frozen near family:

    s_i<n alpha<n beta<=nR_a/2.                              (13)

An earlier exploratory proposal to count that far component as a new paid branch was therefore incorrect. It is withdrawn. The formal implication from small dilation and disjointness has an empty antecedent for every actual source in this task and pays zero new mass. It does not belong in the claimed progress.

The exact unpaid tail kernel has a useful form. Set P_a=M_a/D_a>=Delta0. Then

    L_tail(x)
      =sum_i [q_i 1_Ai(x)/d_i]
          sum_{a:i in J_a, d_i>D_a} v_a/P_a.                 (14)

It keeps the actual group volumes and all source reuse. The original q-load bound would pay (14) if the following stronger column estimate held uniformly:

    sum_{a:i in J_a, d_i>D_a} v_a/P_a <=C d_i.                (15)

Only the q-weighted pointwise average in (14) is necessary; (15) is not claimed necessary. Neither (15) nor that weaker average is proved here.

Actual receiver disjointness and (12) alone place the groups meeting source i in a fixed constant enlargement of A_i, because R_a<d_i^(1/n)=2s_i for tail incidences. Its volume has a constant-to-the-n factor. The per-group tiny bound (10) does not control how many disjoint occupied receiver pieces can use that enlargement, so it cannot simply multiply its total volume by xi. Source-center admission and g_G<=1 throughout every receiver box remain true but have not supplied this missing cumulative density estimate.

Thus the new precise remaining bridge is a collective bound for the actual disjoint receiver demands in (14), whose high-rate detection occurs through the small source pool at each seed while their payment is carried by a different, very-low-rate tail. It cannot be obtained by pretending the tail itself has high common load, by substituting the small pool's source mass for receiver mass, or by invoking the empty far branch (13).

## Verification and stop

The analytic statements above are the proofs; no finite experiment is used to certify source geometry. One local Python exact-Fraction calculation checked only the endpoint parameter inequalities at n=256 (they strengthen as n grows): tau=262144, nu=81920, Delta0=8192; c_bound/Delta0=1/7936; the robust capture lower bound with r=2c_bound is 31743/39679>=3/4; and tau/16-2c_bound-Delta0=253888/31>0. The scale incompatibility (13) was checked algebraically, not by sampling instances. No MATLAB session was opened.

No full low-load estimate or completed packing is claimed. This checkpoint identifies a more exact low-rate tail mechanism and its unpaid geometric sum, while explicitly rejecting a purported paid branch that is empty under the actual scale contract. No child agent, Git operation, PDF, modification of another file, or new abstract counterexample scan was used. Work stops here for review.
