# R675 S2 — robust genuine allocations, and the simultaneous rate budget that remains unpaid

**Proved quantitative local robustness.** For the current nu-profile and its SAME actual captured receiver union Y_a, removing ANY rate D_a<=nu/5 leaves a genuine common-point population of rate at least mu. Its remaining mass N_a satisfies

    v_a <= xi N_a,
    xi=3exp(-(2-log(4/3))k).                                 (1)

The factor 3/4 in this bound is uniform over the allowed deletions. It is stronger than using the looser 3/5 detection estimate.

This permits a real adaptive change of source-payment probabilities while keeping sum_i d_i b_i=Vrem. A single low-load cell can be cleared by a legal deletion. However a common choice of deletions for multiple cells must pay the UNION of their source rates, not reuse nu/5 at every point. No dimension-independent simultaneous rate-budget estimate or complete packing is proved here.

Receiver-specific restriction and direct full-J_h suffixes are also legal, as recorded below, but cannot be combined with (1) without checking their changed rate and normalization. The general Vrem packing target remains open.

Only this file is written; no original q, owner, parent, ordering, witness or receiver piece is changed. Auxiliary profiles obey their real q caps; final new packing coefficients are NOT required to obey those caps. Numerical work belongs to the parent. No child, Git or PDF task is introduced.

## 1. Current exact geometry

Use n>=256, tau=16384sqrt(n), mu=tau/4, nu=5tau/16 and k=ceil(128sqrt(n)). In an actual fixed subinterval B=[alpha,beta), the fixed ground set has beta<=s_i<n alpha. The actual seed profile has

    0<=t_i,a<=q_i,  support(t_a) subset J_a,
    sum_i t_i,a=nu,  M_a=sum_i d_i t_i,a.

Every profile parent contains its seed witness z_a. Actual target h assigned to a satisfies

    W_a(h)=sum_i t_i,a1_{A_i}(z_h)>=4nu/5.

The actual X_h are disjoint and are assigned exactly once to Y_a, v_a=|Y_a|. Each real X_h lies in z_h+c0s_h[-1,1]^n, and s_h<beta. The original all-space q load remains at most tau.

All selected rate portions are realizable inside the genuine F_i. Their disjointness across labels holds for one profile, not across different profiles.

## 2. Proof of the robust joint price

Choose deletion portions 0<=e_i,a<=t_i,a with total

    D_a=sum_i e_i,a<=nu/5.

Let s_i,a=t_i,a-e_i,a, T_a=nu-D_a, and N_a=sum_i d_i s_i,a. Then T_a>=4nu/5=mu, so N_a>0 and the certified R673 short-sample theorem applies with rate T_a, common point z_a and r=beta.

For every previously captured h,

    sum_i s_i,a1_{A_i}(z_h)>=4nu/5-D_a.

If d=D_a/nu in [0,1/5], its retained fraction is at least

    (4/5-d)/(1-d)>=3/4.                                    (2)

Indeed the left side decreases with d and equals 3/4 at d=1/5.

Use one k-tuple of iid labels of law s_i,a/T_a for the ENTIRE unchanged Y_a. Each h's witness lies in every sampled parent with probability at least (3/4)^k. On that event the sampled intersection enlarged by c0beta contains the actual X_h. Real receiver disjointness and the short-sample theorem give

    (3/4)^k v_a
       <=E |sampled intersection+c0beta[-1,1]^n|
       <=3N_a exp(-2k).

This proves (1). Different target success events need not be independent. There is no target-count fee, full-parent receiving envelope, or sum of individual upper prices.

This is robust for arbitrary fractional deletions satisfying the ONE stated total-rate budget. Neither the original source process nor the actual receiver assignment is modified.

## 3. A genuine new allocation and the exact multi-cell debit

For any simultaneous choice of one legal deletion vector e_a per anchor define

    b_i(e)=sum_a v_a s_i,a/N_a.                             (3)

Then b_i(e)>=0 and

    sum_i d_i b_i(e)=sum_a v_a=Vrem.                        (4)

Moreover v_a/N_a<=xi by (1), independently of how small N_a/M_a is. These are payment factors, not fractional-cover weights. The objective (4) does not scale or discard the actual receivers.

For one fixed x with m_a(x)=sum_i t_i,a1_{A_i}(x)<=nu/5, choose

    e_i,a=t_i,a1_{A_i}(x).

The deletion has legal total rate m_a(x), and that anchor's NEW load at x is zero. This is an exact feasible local allocation change, not a packing conclusion for the whole b(e).

For several positive-volume original arrangement cells, choose representatives E={x_1,...,x_K}. To clear this anchor at ALL of E using nonnegative source payments requires deleting every source whose parent contains at least one representative. The exact rate cost is

    Q_a(E)=sum_i t_i,a 1{A_i meets E}.                       (5)

Its removal is legal under (1) only if Q_a(E)<=nu/5. The valid elementary bound is

    Q_a(E)<=min(nu, sum_{x in E}m_a(x))
           <=min(nu, Knu/5)                                (6)

when each cell is individually low. Individual low-load conditions do NOT provide the desired single union-budget bound. Formula (6) is an upper envelope, not an asserted actual-input lower bound or an abstract counterexample.

The actual geometric step still needed is a simultaneous allocation controlling the full load without spending the deletion budget again at each crowded cell. No such estimate for (5), or a less restrictive load-reducing alternative, has been proved. Clearing every low cell is only one sufficient strategy; it is not declared necessary for the original packing goal.

Also the R674 high-load theorem does not automatically transfer to (3). The total retained rate and capture fraction have changed, and the denominator is N_a rather than M_a. One cannot compare objectives and silently retain the old high-part constant.

## 4. Receiver-specific support: valid construction, separate rate check

Independently, the original anchor profile can be restricted for each actual h:

    u_i,h=t_i,a1_{A_i}(z_h),
    R_h=sum_i u_i,h>=4nu/5=mu,
    N_h=sum_i d_i u_i,h.

The probability d_i u_i,h/N_h is supported on parents containing z_h, and

    b_i^rec=sum_h |X_h| u_i,h/N_h,
    sum_i d_i b_i^rec=Vrem.                                 (7)

Every term of this candidate's load at x uses the SAME parent containing x and z_h. The different-parent traffic present in the original kernel has been removed.

Although N_h/M_a is not uniformly controlled by rate capture, a fresh use of the existing theorem gives

    |X_h|<=3N_h exp(-2k).                                   (8)

All u_i,h parents contain z_h, have radii at least beta, and have genuine portions of total rate at least mu. Every sampled expanded intersection covers X_h deterministically. Equation (8) is a single-receiver theorem corollary; it does not pay accumulated source reuse.

One must NOT splice this support restriction into the anchor deletion construction without another check. After deleting up to nu/5, a captured h's further restricted rate is only guaranteed to be

    4nu/5-nu/5=3nu/5<mu.                                   (9)

The remaining anchor population still has rate at least mu and the joint detection fraction (2), so (1) is valid. But a per-h restricted population need not meet the theorem threshold. The joint denominator N_a and the receiver-specific denominator N_h are different quantities.

A clean direct alternative is to choose a rate-nu profile from each FULL actual J_h, all of whose parents already contain z_h. Deleting at most nu/5 from that direct profile leaves rate at least mu AND preserves receiver-specific support. This gives a genuine allocation with (8) after deletion, but its choices are now indexed by h. The same multi-cell union-rate and cumulative-owner-reuse questions remain unpaid.

## 5. Full-J_h large tails are legal, but local contraction transfers objective

The parent's changed-hypothesis observation is correct: direct profiles from J_h can be extended or replaced by larger-radius suffixes without losing witness containment. The old anchor capture-support defect is gone.

Here is the exact bookkeeping. Sort J_h by increasing d_i. Let p_h(t) be its canonical rate-t prefix and M_h(t)=sum_i d_i p_i,h(t). Actual common-point owner geometry gives

    M_h(t2)>=M_h(t1)exp((t2-t1)/c).                          (10)

On each affine segment M'_h=d_cut while genuine disjointness inside the common cutoff cube gives M_h<=c d_cut; integrate (log M_h)'>=1/c. This is the real geometric price relation, not a generic scalar assertion.

Set sigma=nu-mu=tau/16 and epsilon=exp(-sigma/c). Then r_h=M_h(mu)/M_h(nu)<=epsilon. The normalized nu-prefix kernel has the EXACT decomposition

    K_h,nu=r_h K_h,mu+(1-r_h)K_h,inc,                        (11)

where the increment is p_h(nu)-p_h(mu), of rate sigma, and every parent in all terms contains z_h. Each normalized kernel integrates to one. Thus the old prefix part is pointwise at most epsilon times its old load, but the increment carries at least

    (1-epsilon)Vrem                                       (12)

of the SAME actual objective. It cannot be discarded or called fresh source capacity.

There is also a legal rate-mu large-radius suffix p_h(nu)-p_h(sigma). Its mass Q_h obeys

    Q_h>=(1-exp(-mu/c))M_h(nu).

This suffix DOES meet the existing theorem threshold. Nevertheless its overlap with the old mu-prefix has mass fraction at most

    epsilon/(1-exp(-mu/c)),

so again almost all of its objective is on the last sigma increment. A local theorem for the whole suffix does not bound the global repeated use of that mass-dominant block. There is no claim that all suffixes are below threshold.

The stronger retained R670 estimate is T(J_h)>3tau/8-2c=nu+tau/16-2c. Thus there IS a uniform positive additional reserve beyond nu, and it can support further finite profile extensions. This reserve must be retained rather than weakened to a statement permitting T(J_h) to approach nu. On the other hand T(J_h)<=tau, so this is not an indefinitely extendible sequence of fixed-rate tails; any finite extension scheme still has to pay its terminal transport component. No such terminal global payment is proved here.

## 6. Proof status and stopping point

The robust joint result (1), the simultaneous-deletion cost (5), the receiver-specific construction (7), and the legal direct-tail decompositions are proved. They distinguish genuine changes in source probabilities from the old uniform normalization and retain exactly Vrem.

No geometric bound has been proved that pays the multi-cell union-rate debit while controlling the complete load of one SAME coefficient vector. Likewise no all-space payment for the mass-dominant direct tails is established. Original center admission, disjoint receiver pieces, genuine source owners and the low entire receiving boxes remain available; they have not been converted into this missing inequality.

No Hall/dual condition is merely substituted for that geometric work. The q cap applies only to auxiliary portions; it is not imposed on final b. The constructions above are sufficient candidate forms, not asserted necessary for every successful packing proof.

This is a bounded partial result and an accurate failed global connection, not a new complete quantitative packing bound. The parent handles any scalar verification and archive. No numerical output is claimed here, and no further route is opened.

