from pathlib import Path
import ast,hashlib,json,re
p=Path(__file__).resolve().parent
for n in ('DECISION_CHECK.py','verify.py'):ast.parse((p/n).read_text())
r=json.loads((p/'DECISION_RESULT.json').read_text())
assert r['precision_bits']==256
for name,count in [('checks',7),('probes',6),('capacity_fixtures',3)]:
 assert len(r[name])==count and all(x['pass'] for x in r[name])
assert r['script_sha256']==hashlib.sha256((p/'DECISION_CHECK.py').read_bytes()).hexdigest()
s=(p/'REPORT.tex').read_text();stack=[]
for m in re.finditer(re.escape(chr(92))+r'(begin|end)\{([^}]+)\}',s):
 if m[1]=='begin':stack.append(m[2])
 else:assert stack and stack.pop()==m[2]
assert not stack
assert s.count(chr(92)+'begin{document}')==s.count(chr(92)+'end{document}')==1
for review_name,names in [('S1_REVIEW.md',('REPORT.tex','A1_LOW_GEOMETRY.md')),('S3_REVIEW.md',('REPORT.tex','S2_ALLOCATION.md'))]:
 review=(p/review_name).read_text()
 for n in names:
  assert hashlib.sha256((p/n).read_bytes()).hexdigest() in review,(review_name,n)
if (p/'MANIFEST.json').exists():
 for n,v in json.loads((p/'MANIFEST.json').read_text())['members'].items():
  b=(p/n).read_bytes();assert len(b)==v['bytes'] and hashlib.sha256(b).hexdigest()==v['sha256']
print(json.dumps({'pass':True,'scope':'artifact integrity and saved calculations, not mathematical proof certification','manifest_checked':(p/'MANIFEST.json').exists()}))
