from pathlib import Path
from fractions import Fraction as F
import hashlib,json,platform
import sympy as sp
import flint
from flint import arb,ctx
ctx.prec=256
u,h,b,delta,D=sp.symbols('u h b delta D',positive=True)
p=(sp.Rational(4,5)-u)/(1-u)
checks=[]
def add(name,condition):
 assert condition,name
 checks.append({'name':name,'pass':True})
add('robust_capture_endpoint',sp.simplify(p.subs(u,sp.Rational(1,5))-sp.Rational(3,4))==0)
add('robust_capture_derivative',sp.simplify(sp.diff(p,u)+sp.Rational(1,5)/(1-u)**2)==0)
add('cap_mass_identity',sp.expand(D*h+D*(delta+b)-D*(delta+h+b))==0)
add('small_fraction_bound',sp.simplify(h/(delta+h+b)-h/delta+h*(b+h)/(delta*(b+delta+h)))==0)
add('cap_rate_mass_identity',sp.simplify((h+b)+(delta)-(delta+h+b))==0)
add('small_mass_endpoint',F(32,31)/8192==F(1,7936))
add('tail_rate_endpoint',2*F(32,31)/81920==F(1,39680))
c=F(32,31)
probes=[]
for stage,ns in [('initial',[256,1024]),('boundary',[16384,2**20]),('expanded',[2**32,2**48])]:
 for n in ns:
  root=arb(n).sqrt();tau=16384*root;nu=5*tau/16;d0=tau/32
  k=__import__('math').isqrt(16384*n)
  if k*k<16384*n:k+=1
  ca=arb(c.numerator)/c.denominator
  frac=ca/d0;rate=2*ca/nu
  logxi=arb(3).log()-(2-(arb(4)/3).log())*k
  ok=bool(tau/16-2*ca>=d0) and bool(frac<arb(1)/1000) and bool(rate<arb(1)/1000) and bool(logxi<0)
  assert ok
  probes.append({'stage':stage,'n':n,'k':k,'small_mass_fraction_upper':str(frac),'large_tail_mass_fraction_lower':str(1-frac),'large_tail_rate_fraction_upper':str(rate),'log_robust_price':str(logxi),'pass':ok})
# Exact finite atomic capacity fixtures only, not realizations of the full cube/history contract.
fixtures=[]
for ds,hs,cut in [([1,2,4],[F(1,2),F(1,2),F(1)],F(1)),([1,4,16,64],[F(1),F(2),F(8),F(32)],F(8)),([2**j for j in range(33)],[F(1)]+[F(2**(j-1)) for j in range(1,33)],F(2**16))]:
 H=F(0)
 for d,m in zip(ds,hs):H+=m;assert H<=d
 q=[m/d for m,d in zip(hs,ds)]
 T=sum(q);nu0=sum(qq*min(F(1),cut/d) for qq,d in zip(q,ds));gap=T-nu0
 mass=sum(qq*min(F(d),cut) for qq,d in zip(q,ds))
 small=sum(m for m,d in zip(hs,ds) if d<=cut)
 tailrate=sum(qq*cut/d for qq,d in zip(q,ds) if d>cut)
 alpha=small/cut+tailrate
 assert mass/cut==gap+alpha and alpha<=2
 fixtures.append({'points':len(ds),'cut':str(cut),'rate_gap':str(gap),'alpha':str(alpha),'mass_over_cut':str(mass/cut),'pass':True})
r={'scope':'symbolic identities, scalar interval decisions, and abstract radial-capacity atomic fixtures; not full source/receiver geometry or a general bound','python':platform.python_version(),'sympy':sp.__version__,'python_flint':flint.__version__,'precision_bits':ctx.prec,'checks':checks,'probes':probes,'capacity_fixtures':fixtures,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
Path(__file__).with_name('DECISION_RESULT.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({'checks':len(checks),'probes':len(probes),'capacity_fixtures':len(fixtures),'all_pass':True,'precision_bits':ctx.prec}))
