from pathlib import Path
from fractions import Fraction as Q
import json,sys,platform
import numpy as np
import scipy
from scipy.optimize import linprog
stored=json.load(open(Path(__file__).with_name('r535_increment_input.json')))
base=stored['base'];inputs=stored['inputs']
# Add three bounded tests where the all-request cut contains the shared sources.
from itertools import product
for weight in [Q(1,4),Q(7,25),Q(1,3)]:
 eps=Q(1,16)
 boxes=[((Q(0),Q(0)),(Q(1),Q(1))),((1-eps,Q(0)),(Q(5,2)-eps,Q(3,2))),((Q(1,2),1-eps),(Q(5,2),3-eps))]
 axes=[sorted({v[d] for box in boxes for v in box}) for d in [0,1]]
 pats={}
 for ix,iy in product(range(len(axes[0])-1),range(len(axes[1])-1)):
  pt=((axes[0][ix]+axes[0][ix+1])/2,(axes[1][iy]+axes[1][iy+1])/2)
  bits=tuple(all(l[d]<pt[d]<h[d] for d in [0,1]) for l,h in boxes)
  if not any(bits):continue
  pats[bits]=pats.get(bits,Q(0))+(axes[0][ix+1]-axes[0][ix])*(axes[1][iy+1]-axes[1][iy])
 masses={(True,False,True):Q(1),(False,True,True):Q(9,4),(False,False,True):Q(3,4)}
 assert all(p in pats and pats[p]>0 for p in masses)
 radii=[Q(1),Q(3,2),Q(2)];weights=[weight,Q(1,4),Q(1,4)];aa=[w/r**2 for w,r in zip(weights,radii)]
 for i in range(3):assert sum(m for p,m in masses.items() if p[i])==radii[i]**2
 for i in range(3):
  for j in range(i+1,3):
   ov=Q(1)
   for d in [0,1]:ov*=max(Q(0),min(boxes[i][1][d],boxes[j][1][d])-max(boxes[i][0][d],boxes[j][0][d]))
   assert 2*ov**2<min(radii[i]**2,radii[j]**2)**2
 D=[sum(aa[i] for i in range(3) if p[i]) for p in pats]
 base['results'].append({'parents':3,'depth':'internal-w='+str(weight),'patterns':[list(map(int,p)) for p in pats],'source_masses':[str(masses.get(p,Q(0))) for p in pats],'D':list(map(str,D)),'X':str(sum(weights))})
 inputs.append({'radii':list(map(str,radii)),'weights':list(map(str,weights))})
results=[]
for r,inp in zip(base['results'],inputs):
 N=r['parents'];radii=list(map(Q,inp['radii']));a=[ww/t**2 for ww,t in zip(map(Q,inp.get('weights',['1/4']*N)),radii)]
 bits=r['patterns'];mass=list(map(Q,r['source_masses']));D=list(map(Q,r['D']));caps=[m*d for m,d in zip(mass,D)]
 requests=[]
 for i in range(N):
  for j in range(i+1,N):
   overlap=sum((m for b,m in zip(bits,mass) if b[i] and b[j]),Q(0))
   if not overlap:continue
   allowed=[s for s,b in enumerate(bits) if b[j] and not b[i] and caps[s]>0]
   demand=2*a[i]*a[j]*overlap
   assert allowed
   requests.append({'small':i,'large':j,'demand':demand,'allowed':allowed})
 R=len(requests);best=Q(0);bestmask=0;cuts=[]
 for mask in range(1,1<<R):
  ids=[i for i in range(R) if mask>>i&1]
  union=sorted({s for i in ids for s in requests[i]['allowed']})
  demand=sum((requests[i]['demand'] for i in ids),Q(0));cap=sum((caps[s] for s in union),Q(0))
  ratio=demand/cap
  if ratio>best:best=ratio;bestmask=mask
  cuts.append((mask,ratio))
 edges=[(i,s) for i,q in enumerate(requests) for s in q['allowed']]
 eq=np.array([[int(i==k) for i,s in edges] for k in range(R)],dtype=float)
 ub=np.array([[int(s==t) for i,s in edges] for t in range(len(bits))],dtype=float)
 sol=linprog(np.zeros(len(edges)),A_eq=eq,b_eq=[float(q['demand']) for q in requests],A_ub=ub,b_ub=[float(best*c) for c in caps],bounds=(0,None),method='highs')
 assert sol.success
 flow=[Q(float(x)).limit_denominator(10**10) for x in sol.x]
 assert all(x>=0 for x in flow)
 for i,q in enumerate(requests):assert sum((v for (k,s),v in zip(edges,flow) if k==i),Q(0))==q['demand']
 loads=[sum((v for (i,s),v in zip(edges,flow) if s==t),Q(0)) for t in range(len(bits))]
 assert all(v<=best*c for v,c in zip(loads,caps))
 total=sum((q['demand'] for q in requests),Q(0));X=Q(r['X']);assert sum(caps)==X
 chosen=[i for i in range(R) if bestmask>>i&1]
 union={s for i in chosen for s in requests[i]['allowed']}
 inside=Q(0);selectedtotal=Q(0)
 for i in chosen:
  q=requests[i];b,c=q['small'],q['large']
  ov=sum((m for bit,m in zip(bits,mass) if bit[b] and bit[c]),Q(0))
  inm=sum((m for t,(bit,m) in enumerate(zip(bits,mass)) if t in union and bit[b] and bit[c]),Q(0))
  inside+=q['demand']*inm/ov;selectedtotal+=q['demand']
 out={'cut_inside_fraction':str(inside/selectedtotal),'parents':N,'depth':r['depth'],'capacity_weights':list(map(str,caps)),'requests':[dict(small=q['small'],large=q['large'],demand=str(q['demand']),allowed=q['allowed']) for q in requests],'optimal_capacity_multiplier':str(best),'cut_requests':chosen,'flow':[[i,s,str(v)] for (i,s),v in zip(edges,flow) if v],'total_demand':str(total),'X':str(X),'total_demand_over_X':str(total/X),'all_requests_cut':str(next(val for mask,val in cuts if mask==(1<<R)-1))}
 results.append(out)
 print(N,r['depth'],'K',best,float(best),'global',float(total/X),'cut',chosen,'inside',str(inside/selectedtotal),flush=True)
import sympy as sp
import flint
from flint import arb,ctx
ctx.prec=160
t=sp.symbols('t',positive=True)
assert sp.simplify(sp.diff(2/(sp.exp(t)-1),t)+2*sp.exp(t)/(sp.exp(t)-1)**2)==0
coefficient_balls=[]
for n in [1,2,4,16,64,256,1024]:
 tt=arb(n).sqrt()/4;val=2/(tt.exp()-1)
 assert val<8/arb(n).sqrt()
 coefficient_balls.append({'n':n,'coefficient_ball':str(val)})
Path(__file__).with_suffix('.json').write_text(json.dumps({'scope':'Finite weighted receiving-center source-increment allocation; exact Hall cut lower bounds and rational primal flow certify multiplier only in these finite inputs. Actual full continuous-center capacity theorem remains unproved.','environment':{'python':platform.python_version(),'executable':sys.executable,'numpy':np.__version__,'scipy':scipy.__version__},'coefficient_balls':coefficient_balls,'coefficient_scope':'Arb 160-bit finite checks; general bound 2/(exp(sqrt(n)/4)-1)<=8/sqrt(n) is proved analytically, not extrapolated.','flint':flint.__version__,'sympy':sp.__version__,'results':results},indent=2))
