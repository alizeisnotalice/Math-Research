# R450 — parent-column pooling, shared volume, and the exclusive-moment test

**Outcome.** Exact pooling of the original new source and clipping level improves the positive-mass matching problem at unchanged price. Shared volume has an explicit complete-coverage test, but that test is not automatic. A separate native exclusive-moment comparison is proved; its proposed n-sized source bound is a strong unproved second-moment statement, not a completed reduction to an easier known estimate.

## 1. Exact positive-mass projection and density hats

All fields and original P are those of R447. Define

    H_A(v)=1{m_v<m_A/K²} I_Av/m_v,   I_Av=f(Q_A∩Q_v),
    M_A=∫H_A(v)dv,    n_A(v)=H_A(v)/(h m_A),
    ν_A(dv)=n_A(v)dv,  μ_Ae=B_e ν_A.

These use actual Lebesgue centers and full-f matching. In particular 0≤H_A≤1 and M_A≤m_A An/q. Project the **original** P to

    σ(dA)ρ_Ae(v)dv.

With R447's actual gtilde and common ν_Az, its density is exactly

    ρ_Ae(v)=∫ c_A(z)/m_A 1{f(z)>t} gtilde(e,A,z,t,v)
                  ·[dν_Az/dv](v) dz dt.                         (1)

No own-low or history gate is removed from ρ. Define g_Ae=ρ_Ae/n_A on n_A>0 and zero otherwise. The original one-terminal bound and a_i≤B_e give ρ≤B_e n_A. Independently, the two-terminal hats and a0≤B_e give ρ≤B_e ν_A(E)n_A. Hence

    0≤g_Ae≤B_e min(1,M_A/(h m_A)).                            (2)

Zero H_A gives zero demand. The directional constants satisfy Σ_e B_e=S. The actual total demand r_Ae=∫ρ_Ae dv is also ≤B_e by the original static projection bound; this is not inferred by treating ν_A as a probability.

For any previous capacity column k_Ae(v) independent of z,t, pooling gives

    ∫(ρ_Ae−C k_Ae n_A)_+dv
       ≤∫ c_A(z)/m_A 1{f(z)>t}(gtilde−Ck_Ae)_+dν_Az dzdt.      (3)

Indeed the integrated old reference density is at most n_A: the own-low gate stays in the actual density and is dropped only in the auxiliary reference. Apply positive-part convexity to the exact source/level integral, then enlarge this reference. This proves genuinely increased possible coverage, without assuming a proportion of improvement.

The explicit column plan and original pullback from R447 apply: second marginal min(ρ,C k n_A)dv, original multiplier min(1,Ck n_A/ρ). All original records remain. This step does **not** preserve the signed U integral in an auxiliary plan, since U depends on z,t. It preserves and prices positive original mass, which is sufficient for the R slot.

## 2. Shared volume: native price and exact coverage condition

Let κ_Ae(w,v)∈[0,1] be jointly measurable and suppose, for every relevant parent and direction,

    ∫H_A(v)∫κ_Ae(w,v)dw dv ≤ m_A²/q².                       (4)

Only H-positive actual centers need be used. The capacity C κ μ_Ae⊗ν_A has mass at most C B_e/(h²q²), because H_A(w)≤1. Thus any original positive fraction obtained from this capacity costs

    C S ε0² Xq/s² ≤ C S ε0² An W/s².                         (5)

At C=sqrt(n), this is at most S ε0² sqrt(n)W. No individual terminal-mass-depth factor is charged. This class need not contain the old radial capacity with the same constant; (3) compares pooling for a fixed capacity, not arbitrary changes of capacity. Using old and new capacities together requires their summed price, followed by one original pullback.

Here is an explicit test for full coverage in class (4). Let H_A* be its decreasing Lebesgue rearrangement and

    F_A(l)=∫_0^l H_A*(r)dr,
    L_A(a)=inf{l:F_A(l)≥a},  0≤a≤M_A.

For C≥1 define a_Ae(v)=h m_A g_Ae(v)/(C B_e). By (2), a≤M_A; zero B_e contributes no demand. Full coverage is possible in (4) **if and only if**

    V_Ae:=∫H_A(v)L_A(a_Ae(v))dv ≤ m_A²/q².                  (6)

For sufficiency, use the same decreasing-H rank of w in every column and select its initial segment of length L_A(a(v)). Its H-integral is exactly a(v), so the resulting capacity has column density g_Ae with respect to ν_A. For necessity, the rearrangement inequality implies that any 0≤κ≤1 with H-integral at least a must have Lebesgue volume at least L_A(a); integrate against H_A(v).

The H-positive center support is bounded by the parent plus side b. Lebesgue measure is atomless, so equal-H layers can be split using the first coordinate as in R449. The rank, inverse F, and the selected kernel are jointly measurable; F is continuous. Zero a uses the empty set, and a=M uses the full H-positive support. This is a constructive one-variable criterion, not an appeal to infinite strong duality.

It is not automatically satisfied. Since H≤1, L_A(a)≥a, giving the necessary lower bound

    V_Ae ≥ h²m_A² r_Ae/(C B_e).                             (7)

Thus (6) already requires r_Ae≤C B_e/(h²q²). The hats (2) alone do not give that acceptance budget. The full H-profile also matters: a low-valued broad H can have L_A(a) much larger than a. This exact shared-cost test is not counted as a new global breakthrough or renamed as a paid deficit.

## 3. A native exclusive-moment route, with its full coefficient

The original retained static gate includes Z_A(y)>(4−ε0)h and C_A(y,z)<h. The original static pushforward is at most S σ(dA)π_A(dy)π_A(dz), with S used once. Let

    p_A(w)=I_Aw/m_A,
    M_ex=∫σ(dA)∫_{m_w<m_A/K} p_A(w)(1−p_A(w)) dw/m_w.       (8)

Tonelli with the two **actual** parent posteriors gives

    ∫π_A(dy)π_A(dz)[Z_A(y)−C_A(y,z)]
       =∫_{m_w<m_A/K}p_A(w)(1−p_A(w))dw/m_w.

Consequently the same original R, or any of its positive restrictions, obeys

    R ≤ S M_ex/[(3−ε0)h].                                  (9)

Original directions, acceptance and histories are only positively dominated here; no witness acquires their qualifications. If one could prove M_ex≤C n log^a(n+2)W/q, then (9) would give

    R≤ C S ε0 n log^a(n+2)W/[(3−ε0)s].                      (10)

That bound has not been proved.

## 4. Why the proposed moment is a strong source second moment

Let J(y)=∫c_A(y)dA/m_A and M2=∫f(y)J(y)²dy. Set

    M1=∫f(y)∫_{m_w<m_A/K}q_A ρ_y(dA)ρ_y(dw)dy.

Since 0≤p_A(w)<1/K on the strict far mass gate,

    (1−1/K)M1≤M_ex≤M1≤(λ/2)M2.                            (11)

The last inequality uses symmetry of the unweighted ordered pair and q_A≤λ, not a positive-kernel spectral claim.

For completeness, native actual-center mass-window capacity gives

    ρ_y{t/K≤m_A≤Kt}≤ B_K:=(1+2log K)/q.                   (12)

To prove it, capturing centers obey m_A≥q(2||A−y||∞)^n and m_A≥t/K; the upper mass bound confines them to (2||A−y||∞)^n≤Kt/q. Integrating the majorant 1/max(t/K,q(2dist)^n) gives (12). It includes whole mass atoms; there is no strict-endpoint deletion.

At each source the full J² pair domain is the disjoint union of the two strict far orders and the closed comparable-mass band. The latter has measure at most B_K J. Thus

    M2 ≤2M1/q+B_K∫fJ
       ≤2M_ex/[q(1−1/K)]+(M2+B_K²W)/2,

and hence

    M2≤4M_ex/[q(1−1/K)]+B_K²W.                            (13)

With log K=sqrt(n) and fixed λ/q, the desired nW/q bound on M_ex and an nW/q² bound on M2 have the same order up to the displayed O(n) term. This does not assert equivalence to the general weak-type theorem. In fact the M2 bound is strong enough to imply the octave/q-band conclusion directly:

    |E|=∫fJ≤sqrt(W M2),   Xq≤λ|E|.

It is therefore not an already solved unmarked condition. The subtracted p² part in (8) is at most a 1/K fraction of M1 and cannot by itself furnish the missing square-root gain. No original BH negative square credit is reused.

A narrow history check found R435 archived contract line 17 uses the normalized exclusive quantity (Z−C)/Z, with only its old X-scale bound. R382 archived `r382_clock.md` lines 69–76 discusses a different marked mass-variation identity and explicitly assumes no second moment. This check distinguishes those interfaces; it does not claim that no earlier archive ever mentioned (8).

## 5. Computation and status

The designated local Python ran `r450_mainproof_check.py`, with stdout `r450_mainproof.result.txt`: **75 exact Fraction assertions** in stages 9,48,18. They check source/level pooling with reference enlargement, inverse-profile full-coverage construction and its necessary cost, and the common-source incidence identities (11)–(13), including equal-mass atoms and closed bands. The finite band tests use their exact empirical window bound; the native constant in (12) is proved analytically.

These are finite interface/profile/incidence checks, not a native continuous selector or original-history realization. The status is: legitimate stronger pooling and a priced shared-volume class; no automatic full coverage; and the precise still-unproved source second-moment budget (8)–(13). No new unconditional payment of the complete R has been obtained, and the original remaining mother-ledger term is retained.
