# R450 — shared-volume cost and the actual external-source term

**Outcome.** This bounded attempt does not construct a shared-budget kernel
covering the original demand, and proves no additional payment. It checks
one proposed mechanism: account for the loss between receiver volume and
matched parent-source capture by assigning that loss to actual sources
outside the parent. The assignment is exact, but its cross-parent source
column is not controlled by the available original gates.

## 1. The attempted construction has a precise additional cost

Fix the original parent \(A\), its full mass \(m_A=f(Q_A)\), and
\[
H_A(w)=1_{\{m_w<m_A/K^2\}}\frac{I_{Aw}}{m_w},
\quad I_{Aw}=f(Q_A\cap Q_w).
\]
Consider any measurable \(0\le\kappa_A(w,v)\le1\) supported on the actual
small-mass receivers in both variables. It is an analysis kernel, not a
replacement of any original history. Write
\[
Q_A(\kappa)=\frac1{m_A^2}\int
 H_A(w)H_A(v)\kappa_A(w,v)\,dw\,dv,
\]
\[
\mathcal V_A(\kappa)=\int H_A(v)\int\kappa_A(w,v)\,dw\,dv.
\]
The proposed shared budget \(\mathcal V_A\le m_A^2/q^2\) implies
\(Q_A(\kappa)\le q^{-2}\). Its already certified source price, after the
two terminal hats and one stage/source summation, would be
\[
\frac{CS}{h^2q^2}X_q
\le\frac{CS\varepsilon_0^2A_n}{s^2}W.
\tag{1}
\]
For \(C=\sqrt n\), this is at most \(S\varepsilon_0^2\sqrt n\,W\).
Equation (1) is conditional on a feasible kernel supplying the actual
columns; it is not an existence proof or a new charge.

Full matching gives the exact decomposition
\[
\mathcal V_A(\kappa)
=m_A^2Q_A(\kappa)+\mathcal E_A(\kappa),
\tag{2}
\]
\[
\mathcal E_A(\kappa)=
\int H_A(v)\int\kappa_A(w,v)
              \frac{f(Q_w\setminus Q_A)}{m_w}\,dw\,dv\ge0.
\tag{3}
\]
Indeed \(1-I_{Aw}/m_w=f(Q_w\setminus Q_A)/m_w\) on the supported
small-mass receivers. All terms use the full original \(f\).
Thus shared volume does not become free merely by dropping the old
terminal marginal: even its source-capture part is the mass to be paid,
and the additional part is (3).

## 2. The exact source assignment, and where it fails to yield a budget

Positive Tonelli rewrites (3) as
\[
\mathcal E_A(\kappa)=\int_{x\notin Q_A}f(x)
 \left[\int H_A(v)\int
       \frac{\kappa_A(w,v)c_w(x)}{m_w}\,dw\,dv\right]dx.
\tag{4}
\]
This is a genuine external-source assignment, not a source-density
estimate based on a boundary volume. To use it globally one must
control the resulting source column after the original parent weight,
the factor \(m_A^{-2}\), and the demand-dependent choice of \(\kappa_A\)
are included:
\[
\int_{\{A:x\notin Q_A\}}\frac{\sigma(dA)}{m_A^2}
 \int H_A(v)\int
       \frac{\kappa_A(w,v)c_w(x)}{m_w}\,dw\,dv.
\tag{5}
\]
No suitable estimate for (5) was proved. In particular, giving an
external source a positive amount of mass is not the same as proving
that all parents together charge it only once.

The original high-rank/low-common restrictions concern the fixed
original pair \(y,z\). They have not been shown to control (5), whose
new source \(x\) may be outside the parent. That source does not inherit
the original history or relative-rank qualifications. The low
\(T_G,T_{\rm loc}\) gates also do not give a column bound for this
actual mass transfer. Keeping them in the demand is legitimate;
silently imposing them on the new source in (4) is not.

Accordingly this attempt stops at a concrete missing comparison:
construct a kernel which supplies the retained columns while jointly
controlling its captured-source term and the external-source reuse in
(5). Merely minimizing \(\mathcal V_A\) or postulating its budget would
assume the needed result. No new shared-deficit notation or iterative
history is introduced here.

## 3. Screening the proposed exclusive-source variance as a possible payment

For the parent's suggested alternative, use its original, weaker
strict cut \(m_w<m_A/K\), and put \(p_A(w)=I_{Aw}/m_A\).
Then \(0\le p_A(w)<1/K\). Define
\[
F=\int\sigma(dA)\int_{m_w<m_A/K}p_A(w)\frac{dw}{m_w},
\quad
Q=\int\sigma(dA)\int_{m_w<m_A/K}p_A(w)^2\frac{dw}{m_w}.
\]
The full-posterior exclusive moment is exactly \(F-Q\), and
\[
0\le Q\le F/K,\qquad Q\le X_q/(Kq).
\tag{6}
\]
For the second inequality, \(I_{Aw}^2/m_w\le I_{Aw}\), while the
native matched-center estimate gives
\[
\int_{m_w<m_A/K}I_{Aw}\,dw
=\int_{Q_A}f(x)\,
 |\{w:x\in Q_w,\ m_w<m_A/K\}|\,dx
\le\frac{m_A^2}{Kq}.
\]
Every such center lies in the cube of side
\((m_A/(Kq))^{1/n}\) centered at \(x\); no source density bound is used.
Consequently
\[
(1-1/K)F\le F-Q\le F.
\tag{7}
\]
This does not disprove the proposed \(O(nW/q)\) bound. It shows that
the factor \(p(1-p)\) itself supplies only an exponentially small
relative saving on this strict-mass branch. A bound of the required
size would still need a new geometric estimate for the large
first-moment term, with the actual gates if necessary. Neither (6)
nor (7) is counted again as a payment.

The direct positive term remains the concrete possible target
\[
F=\int f(y)\int\frac{c_A(y)}{R_A^n}
 \left[\int_{\{m_w<m_A/K\}}c_w(y)\frac{dw}{m_w}\right]dA\,dy.
\tag{8}
\]
Every mass in (8) still equals the full cube capture; it is not an
arbitrary-radius incidence model. The one-source native occupancy bound
applied separately to its two center integrals gives only the known
quadratic dimensional bound. Strict mass ordering does not itself
justify charging the same source once across these layers. A source
mass-growth or common-center estimate reducing this repetition was not
obtained in this bounded attempt. The parent's independent occupancy
comparison identifies such a bound with a genuine second-moment
geometric estimate, already strong enough for the root weak bound;
this attachment does not present (8) as a reduction in difficulty or
as evidence against that estimate.

## 4. Local computation and final scope

The specified Python executed `/tmp/r450_geometry_check.py`; stdout
is `/tmp/r450_geometry.result.txt`. Three finite full-source
incidence tables verify (2)–(3), including positive external mass,
and the relative estimate \(Q\le F/K\). The receiver weights are
finite bookkeeping weights, not Lebesgue-center realizations.
The native bound in (6) rests on the analytic center argument above,
not on those tables. No original history or whole-budget test is
claimed.

No new source fee or absorbable \(X_q\) term is obtained in this
attachment. The original complete demand and mother ledger remain
unchanged. The bounded attempt stops here.
