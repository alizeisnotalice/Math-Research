from fractions import Fraction as F
from itertools import product
counts=[0,0,0]
def ck(x,k):
    assert x
    counts[k]+=1
# Stage 1: pool actual new-source/level labels, then enlarge only reference.
for weights,gs,cap,extra in [([F(1,2),F(1,2)],[F(1),F(0)],F(1,2),F(0)),
                            ([F(1,3),F(2,3)],[F(3,4),F(1,8)],F(1,4),F(1,2)),
                            ([F(0),F(0)],[F(0),F(0)],F(1),F(1))]:
    rho=sum(w*g for w,g in zip(weights,gs));nlow=sum(weights);nref=nlow+extra
    old=sum(w*max(F(0),g-cap) for w,g in zip(weights,gs))
    pooled=max(F(0),rho-cap*nref)
    ck(pooled<=old,0)
    b=min(F(1),cap*nref/rho) if rho else F(0)
    ck(b*rho+pooled==rho,0)
    ck(rho<=nref,0)
# Stage 2: exact minimum-volume inverse of a decreasing step H.
def inv(prof,a):
    left=a;length=F(0);captured=F(0)
    for h,vol in sorted(prof,reverse=True):
        if not left:break
        take=min(vol,left/h)
        length+=take;captured+=h*take;left-=h*take
    assert left==0
    return length,captured
profiles=[[(F(1),F(1)),(F(1,2),F(2)),(F(1,4),F(4))],
          [(F(1,10),F(30))],[(F(1),F(3))]]
h,m,Be,C=F(6),F(1),F(1),F(2)
rows=[]
for prof in profiles:
    M=sum(x*v for x,v in prof)
    for frac in [F(0),F(1,6),F(1,2)]:
        g=frac
        ck(g<=Be*min(F(1),M/(h*m)),1)
        a=h*m*g/(C*Be)
        length,captured=inv(prof,a)
        ck(captured==a,1)
        ck(length>=a,1)
        r=g*M/(h*m)
        shared=M*length
        ck(shared>=h*h*m*m*r/(C*Be),1)
        for q in [F(1,2),F(1,3)]:
            budget=m*m/(q*q)
            if shared<=budget:
                ck(r<=C*Be/(h*h*q*q),1)
        rows.append((str(prof[0][0]),str(g),str(r),str(shared)))
# Stage 3: actual common-source incidence masses, not native center geometry.
f=[F(1),F(2),F(3)]
sets=[{0},{1},{0,1},{2},{0,2},{0,1,2}]
vol=[F(1,2),F(1,3),F(1,4),F(1,5),F(1,6),F(1,7)]
qvals=[F(1),F(3,2),F(1),F(3,2),F(1),F(3,2)]
masses=[sum(f[j] for j in cell) for cell in sets]
Js=[sum(vol[i]/masses[i] for i,cell in enumerate(sets) if y in cell) for y in range(3)]
J2=sum(f[y]*Js[y]**2 for y in range(3));W=sum(f)
for K in [F(3,2),F(2),F(3)]:
    Mex=M1=F(0)
    for A,w in product(range(6),repeat=2):
        if masses[w]>=masses[A]/K:continue
        I=sum(f[y] for y in sets[A]&sets[w]);p=I/masses[A]
        coeff=qvals[A]*vol[A]*vol[w]/masses[w]
        Mex+=coeff*p*(1-p);M1+=coeff*p
    ck((1-1/K)*M1<=Mex<=M1,2)
    far=near=F(0);B=F(0)
    for y in range(3):
        inds=[i for i,cell in enumerate(sets) if y in cell]
        for A in inds:
            band=sum(vol[w]/masses[w] for w in inds if masses[A]/K<=masses[w]<=K*masses[A])
            B=max(B,band)
            for w in inds:
                x=f[y]*vol[A]*vol[w]/(masses[A]*masses[w])
                if masses[w]<masses[A]/K:far+=x
                elif masses[A]/K<=masses[w]<=K*masses[A]:near+=x
    ck(J2==2*far+near,2)
    ck(near<=B*sum(f[y]*Js[y] for y in range(3)),2)
    ck(M1>=far,2)
    ck(Mex<=F(3,2)*J2/2,2)
    ck(J2<=4*Mex/(1-1/K)+B*B*W,2)
print('PASS',sum(counts),'Fraction assertions; stages',counts)
print('Profile rows (top H, g, parent demand, minimal shared volume):',rows)
print('Scope: exact pooling, step-profile inverse, and finite common-source incidence algebra.')
print('No native selector/full-history certification; native mass-window envelope is proved analytically.')
