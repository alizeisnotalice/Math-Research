from fractions import Fraction as F

mass = [F(18), F(17), F(5), F(2), F(3)]
parent = {0, 1, 2}
mA = sum(mass[j] for j in parent)
tables = [
    ([{3}, {4}, {2}], [F(1, 2), F(1, 3), F(1, 4)]),
    ([{2, 3}, {4}, {3, 4}], [F(1, 5), F(2, 5), F(3, 5)]),
    ([{2}, {2, 4}, {3}], [F(1, 7), F(2, 7), F(4, 7)]),
]
K = F(2)
for index, (captures, weights) in enumerate(tables, 1):
    m = [sum(mass[j] for j in c) for c in captures]
    I = [sum(mass[j] for j in c & parent) for c in captures]
    assert all(x < mA/K**2 for x in m)
    H = [I[i]/m[i] for i in range(len(m))]
    kappa = [[F(1, 1+i+j) for j in range(len(m))] for i in range(len(m))]
    volume = F(0)
    qrow = F(0)
    outside = F(0)
    for i in range(len(m)):
        for j in range(len(m)):
            base = weights[i]*weights[j]*H[j]*kappa[i][j]
            volume += base
            qrow += base*H[i]/mA**2
            outside += base*(m[i]-I[i])/m[i]
    assert volume == mA**2*qrow + outside
    first = sum(weights[i]*I[i]/mA/m[i] for i in range(len(m)))
    square = sum(weights[i]*(I[i]/mA)**2/m[i] for i in range(len(m)))
    assert square <= first/K
    assert (1-1/K)*first <= first-square <= first
    print(f"case {index}: shared-volume identity PASS; external={outside}; "
          f"exclusive relative bounds PASS")
print("Scope: finite matched-source bookkeeping; native center bound and original histories are not numerically certified.")
