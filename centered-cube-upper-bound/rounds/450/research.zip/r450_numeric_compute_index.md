# R450 计算索引

- 所有权：Sol medium，只写 `/tmp/r450_numeric*`；无repo、git、agent或别人文件修改。
- 接口阅读：`/tmp/r449_rearrangement.md` 和root冻结共享体积候选。脚本不依赖它们。
- 输入：单一有理H profile，3个独立有限容量目标；代码内置，不是native field或original history。
- 工具：指定数学Python3.12.14，Fraction和SymPy1.14.0；实际执行0.25s、RSS69,140,480 bytes。
- 结果：40精确检查PASS；共享hard-volume严格弱于逐列hard-volume；原归一的cost上界强含目标父行界；精确dual可拒绝容量不足，但不自动证明原覆盖。
- 输出：`r450_numeric.py`、`r450_numeric_certificate.json`、`r450_numeric_run.txt`、`r450_numeric_resources.txt`、`r450_numeric.md`、本index，全部 `/tmp/`。
- 状态：冻结、停止；未做无关扫描。
