#!/usr/bin/env python3
"""Finite hard-volume profile audit. No native field/history or optimization scan."""
from fractions import Fraction as Q
from pathlib import Path
import json,sys,platform
import sympy as sp
ROOT=Path(__file__).resolve().parent
checks=0
def ck(x):
 global checks
 assert x
 checks+=1
profile=[(Q(1),Q(1)),(Q(1,2),Q(2)),(Q(1,4),Q(4))] # density, real volume
M=sum((h*v for h,v in profile),Q(0))
def inverse(y):
 ck(0<=y<=M)
 rem=y; vol=Q(0); allocations=[]
 for h,v in profile:
  take=min(v,rem/h);vol+=take;rem-=take*h;allocations.append(take)
 ck(rem==0 and vol>=y)
 return vol,allocations
def dual(y):
 candidates=[Q(0)]+[1/h for h,v in profile]
 scores=[(lam*y-sum((max(Q(0),lam*h-1)*v for h,v in profile),Q(0)),lam) for lam in candidates]
 return max(scores)
cases=[dict(name='shared_strictly_weaker_than_column_hard_caps',y=['3/2','1/4'],b=['1','1'],V=['1','2']),
 dict(name='zero_column_and_normalized_reverse_implication',y=['0','2'],b=['1/2','1/3'],V=['1','1']),
 dict(name='dual_certifies_shared_budget_failure',y=['1/8','11/4'],b=['1','1'],V=['1','2'])]
rows=[]
for spec in cases:
 y,b,V=([Q(a) for a in spec[k]] for k in ('y','b','V'))
 primal=[inverse(a) for a in y]; certificates=[dual(a) for a in y]
 for (s,alloc),(d,lam),a in zip(primal,certificates,y):
  ck(s==d)
  ck(sum((h*z for (h,v),z in zip(profile,alloc)),Q(0))==a)
  ck(all(0<=z<=v for (h,v),z in zip(profile,alloc)))
 total=sum((w*s for w,(s,alloc) in zip(b,primal)),Q(0))
 budget=sum((w*cap for w,cap in zip(b,V)),Q(0))
 linear=sum((w*a for w,a in zip(b,y)),Q(0))
 ck(total>=linear)
 rows.append(dict(**spec,minimum_volume=[s for s,a in primal],allocation=[a for s,a in primal],
   dual_lambda=[l for d,l in certificates],dual_values=[d for d,l in certificates],
   cost=total,budget=budget,linear_lower=linear,shared_feasible=total<=budget,
   every_column_feasible=all(s<=cap for (s,a),cap in zip(primal,V))))
ck(rows[0]['shared_feasible'] and not rows[0]['every_column_feasible'])
ck(not rows[2]['shared_feasible'])
# Original normalization, with genuine H_v<=1 as finite column labels only.
h,mA,C,Be,q=Q(2),Q(3),Q(2),Q(1),Q(3)
dv=[Q(1),Q(2)]; b=list(map(Q,cases[1]['b']));y=list(map(Q,cases[1]['y']))
Hv=[w/d for w,d in zip(b,dv)]
ck(all(0<x<=1 for x in Hv))
A=h*h*mA*mA/(C*Be)
rho=[a*z/A for a,z in zip(y,Hv)]
RA=sum((r*d for r,d in zip(rho,dv)),Q(0))
ck(rows[1]['linear_lower']==A*RA)
parentbudget=mA*mA/(q*q)
ck(rows[1]['cost']<=parentbudget)
ck(RA<=C*Be/(h*h*q*q))
# General normalization identity, independent of sample values.
hs,ms,cs,bs,HvS,ds,rhos=sp.symbols('h m C Be Hv dv rho',positive=True)
yS=rhos*hs**2*ms**2/(cs*bs*HvS)
ck(sp.simplify(HvS*ds*yS-hs**2*ms**2*rhos*ds/(cs*bs))==0)
out=dict(scope='finite hard-volume capacity interface only; not native geometry/history, not a weak-L1 comparison',
 executable=sys.executable,python=platform.python_version(),sympy=sp.__version__,checks=checks,
 profile=[dict(H=a,volume=b) for a,b in profile],cases=rows,
 normalization=dict(h=h,mA=mA,C=C,Be=Be,q=q,delta_v=dv,Hv=Hv,rho=rho,RA=RA,
 parent_budget=parentbudget,target_bound=C*Be/(h*h*q*q)))
def enc(x):
 if isinstance(x,Q):return str(x)
 raise TypeError(type(x).__name__)
(ROOT/'r450_numeric_certificate.json').write_text(json.dumps(out,default=enc,indent=2)+'\n')
print('executable:',sys.executable,'Python:',platform.python_version(),'SymPy:',sp.__version__)
for row in rows:print(row['name'],'minimum_volume=',row['minimum_volume'],'lambda=',row['dual_lambda'],'cost=',row['cost'],'budget=',row['budget'],'linear_lower=',row['linear_lower'],'shared=',row['shared_feasible'],'columns=',row['every_column_feasible'])
print('normalization: RA=',RA,'target_bound=',out['normalization']['target_bound'],'parentbudget=',parentbudget)
print('PASS',checks,'exact checks; 3 cases; finite hard-volume interface only')
