# R450 independent final audit

FINAL PASS（限定范围）：通过精确正质量(A,e,v)投影、共享体积类的价格及inverse-profile覆盖判据；通过原exclusive矩支配、native闭窗及其与真实∫fJ²的双向比较。未证明共享覆盖、nW二阶矩目标或原R433整体根阶付款。本轮母账不变。无未解决修复项；root缺归档引用已改为mainproof§3。以下绑定最终13文件，PRE及其后理论审读保留。

## 1. 原投影、共享资源与循环守卫

原ρ_Ae(v)是原gtilde在完整source/level上的精确积分，actual own-low/current/future全部保留，I_Av=0列需求0。ν_A=H_A(v)dv/(hm_A)只扩大辅助reference，非概率。normalized原路径的一端wholeterminal帽给ρ≤B_e n_A；双终端帽与a0≤B_e另外给ρ≤B_eν_A(E)n_A，故g≤B_e min(1,M_A/(hm_A))。两条结论的来源不同，不能仅由rawμν推出概率帽。原static方向帽另给r_Ae≤B_e。

pooling正部不等式需保被投影reference总量≤n_A，作者已使用；RN乘原P保全部源/历史。仅为mass可投影z,t；signed U依z,t，稿未声称其辅助值也无代价被保留。

H_A(w)≤1使共享体积条件直接推出Q_Aκ≤1/q²，来源价格CSε₀²AnW/s²只一次S、无方向2。C=√n可读root价，但只有构造满足预算的κ才能调用。inverse-profile L_A(a)为取得capture a的最小真实w体积，有限正支撑上的可测rank切分达到；C≥1及上述double帽保证a≤M_A，零B_e/零列完整。全覆盖等价V_Ae≤m_A²/q²，但V_Ae≥h²m_A²r_Ae/(CB_e)，因此不能以未经证明的V预算暗含目标父行mass预算。

geometry的V_A=m_A²Q_A+external-source项精确成立，条件是κ支持两端smallmass实际receiver（H=I/m在那里）。外source转移公式保完整f与真实dw/dv，跨父column尚未控，未将新source赋原history。numeric区分hard-volume inverse和R449 weak-L1，未将二者互比或反用dual lower证明覆盖。

## 2. 排他矩、sharp闭窗与强目标

E_K=∫σ∫strict p_A(1−p_A)dw/m_w的Tonelli身份保同一完整π_A²，原实际static门Z−C>(3−ε₀)h及sourcewise S给R≤SE_K/[(3−ε₀)h]；没有将辅助记录刷新为原flow。strictp_A<1/K仅使1−p相对1差≤1/K，未给root小量。geometry的square≤F/K与native square≤X/(Kq)正确，不支付正一阶项。

最终采用无r的B_K=(1+2logK)/q。固定source与质量t窗[t/K,Kt]：u=(2dist∞)^n，捕获实际center满足m_A≥max(t/K,qu)，且u≤Kt/q。真实center体积变量积分1/max(t/K,qu)的core=1/q、shell=2logK/q，闭端点和positive-center mass plateau均保留，不丢原子、不独立选radius。PRE中含logr的radius带界仍为较松真式，最终由此sharp式替代。

令F0为无q_A的strictfar共同来源ρ⊗ρ量，则q(1−1/K)F0≤E_K≤λF0，∫fJ²=2F0+N_closed；closedband≤B_K∫fJ。J≤An/q使各项有限，Cauchy/Young严格得

∫fJ²≤4E_K/[q(1−1/K)]+B_K²W， E_K≤(λ/2)∫fJ²。

与作者M1含q_A的写法一致。∫fJ=|E|保真实Lebesgue中心，若另证q²∫fJ²≲n polylog W，Cauchy已直接给q|E|的root量级，X≤λ|E|保r依赖。因此此未证二阶矩是强条件，不是现成弱工具、原一般weak界的必要条件或新付款。root完整原母账/初始/删除/尺度及最终吸收均未改变。

## 3. 实际复现与范围

指定 `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python` 在新目录 `/var/folders/lq/2c4qbz2n0354_tnttkv_qsz00000gn/T/r450_audit_isolated_z0b00sef` 实际复跑三脚本，三stdout及numeric生成JSON逐字节一致。未改作者文件，资源仅原实跑记录，复现不重复计覆盖。

mainproof 75 Fraction(9/48/18)核pooling、step逆profile及finite共同source incidence；其band试验使用精确empirical窗帽，不把它冒充native常数。geometry3 finite full-source表核external identity/relative square，receiver权非Lebesgue模型。numeric40 exact检查为一个profile的3独立目标，primal切分与scalar dual相等、资源拒绝和原单位归一均正确；无LP或几何扫描。三类均非native selector/full-history或原需求覆盖证据；native窗及空间匹配界由解析论证承担。

## 4. SHA256 byte bindings

- `r450_main.md`: `086867813a6f3fe741ac1af0f6522cffdea9634dbec64ed9c143860cd7055c04`
- `r450_geometry.md`: `bb6d21991e902e94dd0e845382e50a3864187a03f86002800a5ca7039f4af25f`
- `r450_geometry_check.py`: `3e4100946dd0a02438ad324fbcaeea8f5f8d1d90327a789565a0102d405779b5`
- `r450_geometry.result.txt`: `df3dc0b1e0180027d2300a647ffcac57f88811b5e10a60c94bf997f0f684f827`
- `r450_mainproof.md`: `08e66189d3ea56a3761a6ebd59faa4eb3d11b87dc9ff28d9df5b2d90213aa141`
- `r450_mainproof_check.py`: `f7e470a2ad18e83a4ab67b3c26e448edf363c7c161a562663c23a5387ff90cf2`
- `r450_mainproof.result.txt`: `82f80710a402e0d49aa318496a47d048cf05669a3cce18a0cd09da6fcce79212`
- `r450_numeric.md`: `5927dceffb32949dbb7a60be7c1037ddc2b53b7458c16a333c570f52904435ea`
- `r450_numeric.py`: `ba868cd6c7e9f793d9d697fa4157bce967b4667a4c8f2f8fe7e0b2e5e0bb93be`
- `r450_numeric_certificate.json`: `03c3346c2a3eaa0fb5f015e9f895fec387988285791604be42cb0486235767d8`
- `r450_numeric_run.txt`: `51e99fc070b48dcfbc09e8dd3ebfffd0093f170f6219041f548bcca1a3050a78`
- `r450_numeric_resources.txt`: `3bfefef1b423d51e76bde9dcbf05eff25d5db6c435c31bcaf63c4fb1286e71e5`
- `r450_numeric_compute_index.md`: `630b4bcd20b92a8819ff8fda076758d7725e00561f854d8e395d2311057fbe82`

## 5. 独立 PRE 与受邀理论审读留档

# R450 independent audit — PRE

PRE ONLY。先按给定命题独立检查，并读取继承R447主证及R449重排；未读本轮作者新证明。结论：仅为原正质量R作(A,e,v)投影和RN拉回合法；共享体积条件给Q容量价也严格成立。但“存在覆盖原需求且满足该条件的κ”不是已证，须独立核其实际需求的资源成本，不能由容量上界反推。

## 1. 新投影的真实需求及零项

写H_A(v)=1_{m_v<m_A/K²} I_Av/m_v，I_Av=f(Q_A∩Q_v)。它是实际E上完整匹配密度，0≤H≤1，M_A=∫H_A dv≤m_AAn/q，正支撑在有限parent-overlap中心盒内。新参考

ν_A(dv)=H_A(v)dv/(h m_A)

有限，ν_A(E)≤An/(hq)，不称概率。原P的新终端投影对Σ_eσ(dA)ν_A(dv)绝对连续。其精确密度为

ĝ_e(A,v)= I_Av⁻¹∫_{Q_A∩Q_v}dz∫₀^{f(z)}dt
  1_{Z_v(z)≤h} gtilde(e,A,z,t,v)，

I_Av=0时取0。原stage i(t)、old-source已经精确汇总的接受/early/current/两路径/future权都在gtilde中；未将原g改为新posterior。严格mass门在H中；原新端own-low仍在需求，只有辅助reference不再含该源依赖门。积分一次level，不按stage重复f。实际R448概率合同可进一步给ĝ≤B_e，但这一概率帽不能单凭rawμν推得。

给定任意可测b(A,e,v)∈[0,1]，bP是原完整记录的正部分，质量恰∫bĝ ν_Aσ。原z,t,y及全部history继续存在，不给新来源/receiver资格。这里不要求在辅助计划中重现z,t边缘。

此降维只为质量R足够。原Urecord依z,t，故不能直接在辅助(A,e,w,v)上用“只依v”的旧公式宣称U值相同。若真要带U，须使用原P条件期望E[Urecord|A,e,v]并保其可积/参考费用；不能用新source或clipped平均替代。质量付款无需这个额外步骤。

## 2. 共享体积lemma及正确费用

对每个实际A（以及可选固定方向e），假设联合可测0≤κ_Ae(w,v)≤1且

B_Ae(κ):=∫_E H_A(v)[∫_E κ_Ae(w,v)dw]dv≤m_A²/q²。  (SV)

所有dw,dv均为同一真实E的Lebesgue measure，不是自由radius或center原子。则非负Tonelli及H_A(w)≤1直接给

Q_Aκ=m_A⁻²∫H_A(w)H_A(v)κ(w,v)dw dv≤B_Ae/m_A²≤1/q²。

这个方向正确，严格mass原子已含在H，零H列对需求及费用均无贡献。也可在κ仅有H_A(w)>0支撑时使用，不改变有效capture。

用μfree_Ae=B_eH_A(w)dw/(hm_A)及ν_A，列容量kκ_Ae(v)=B_e/(hm_A)∫H_A(w)κ_Ae(w,v)dw。显式单列计划与原bP拉回如R447，若乘子C>0，matched价

≤CS/(h²q²)X=CSε₀²X/s²≤CSε₀²AnW/s²。

C=√n时≤Sε₀²√nW，无Φ/Ψ。方向只是ΣB_e=S一次，不另乘2。新reference的全source平均只扩大辅助容量，原ĝ的own-low/history不变。若对同一方向提供不同κ，必须按其实际共享预算合并，不能每个核再领一次m_A²/q²。

## 3. 哪个覆盖命题是未证的；如何不循环

同原ĝ的显式缺额为∑_e∫σν_A(ĝ_e−Ckκ_Ae)_+。lemma(SV)只对已满足预算的κ定价；κ=0永远满足，不能因此声称覆盖。若任意按ĝ指定κ使Ck≥ĝ，还必须独立证明(SV)，其难度不能藏在“选择最优kernel”中。

可用R449已审实际H排序把这个义务变成准确可检验的资源条件。定义

F_A(l)=∫₀^l H_A*(r)dr，
V_A(r)=inf{l:F_A(l)≥r}（0≤r≤M_A），r>M_A时∞，V_A(0)=0。

它是获得capture r所需的最小实际w体积；同一joint-measurable rank按前V_A(r)体积选择达到。此不是weak-L1的J_A(V)，两类预算不能混用。

对B_e>0，为完全覆盖给定列ĝ_e所需capture为r_e(v)=h m_A ĝ_e(v)/(CB_e)。该共享类能完全覆盖的准确条件是

r_e(v)≤M_A（ν_A-a.e），
∫H_A(v)V_A(r_e(v))dv≤m_A²/q²。                    (COV)

两条件必要且足够：每列bathtub给体积下界，按可测rank前缀构造同时达到。I_Av=0列取r=0，B_e=0方向原需求亦0。这个判据消去κ存在性，保实际需求—captureprofile的相关结构，是可审核的非循环入口；本PRE没有证明原需求满足它。

尤其H≤1给V_A(r)≥r。若(COV)覆盖全部原ĝ，则它已强制每个A/e的条件质量满足

∫ĝ_e dν_A≤CB_e/(h²q²)。

积分即上节root source价。因此未经独立几何证明就假设(COV)或“需求覆盖后自动(SV)”，等于把所需实际交通节省藏进局部预算，且比一般集成root目标更强；这不是从(SV)lemma推出的新证明。一般root界也不必须经此逐父预算类成立。

建设性后审应寻找：原ĝ是否在高H捕获profile上具有足够低的inverse-volume成本，或能覆盖ĝ的一部分、并另将原真实未服务误差按εX+rootW结算。不能仅用raw/H总质量上界、无权邻域面积或把原ĝ换成B_e后声称资源足够。没有此比较时，尚未付的正部必须原样保留。

## 4. 原账与已有收益的保留

原R可直接使用本shared类的新一次列分拆及其缺额，或保R449较低/较高kernel组合的替代账。若把旧核和新核相加以保证matched不减，则应支付各自已证容量价之和；不能同时记旧matched质量又把整个新matched算第二份原R。

入口仍只替换64Λ₀Fhat R槽，C=√n时为64Λ₀Fhat[Sε₀²√nW+Dshared]。这里Dshared只是准确正部描述，不是被证明新余量预算；任务目标仍同原R。若再证该缺额≤εX+QεW，则对应增加64Λ₀Fhat εX、64Λ₀Fhat QεW并核原最终吸收，旧初始/删除/尺度与C433/V433不退款。不因无Φ价格就宣称整个原流已付。

## 5. 实际本机审查与停止

指定math-research-tools Python/Fraction实际核一个两receiver体积表：H=(1,1/2)，所需capture=(1/2,1)，top-H选择的sharedvolume与Q均为1；另核包含源own-low门的精确投影及放宽aux reference后的positivepart方向。仅有限资源/投影代数，不是原native/history样本或扫描，不作一般覆盖证据。

PRE结论：正质量投影及共享容量价成立；正确非循环义务是实际需求的可测capture-volume资源成本，而不是“已有容量价所以可覆盖”。当前未独立证明(COV)或其受控集成误差版本。停止，待冻结作者稿再FINAL。

## 6. PRE后受邀理论审读：排他捕获与来源二阶矩

PRE交付后按root指令读取root main、exclusive_target及冻结geometry/numeric说明；尚待Sol最终主证及完整白名单做FINAL。当前解析比较通过，不作为新付款。

令I2=∫fJ²，ρ_y(dA)=c_A(y)dA/m_A，
F_far=∫f(y)ρ_y(dA)ρ_y(dw)1_{m_A>K m_w}dy。

原E_K=∫σ(dA)∫strict p_A(w)(1−p_A(w))dw/m_w，p_A=I_Aw/m_A。Tonelli的独立full π_A(y)π_A(z)给E_K=∫σπ_A²(Z_A(y)−C_A(y,z))精确成立；非任意新source law。对strict far有p_A<1/K，故

q(1−1/K)F_far≤E_K≤λF_far。

原R433的实际static projection≤Sσπ_A²且原支撑Z−C>(3−ε₀)h，所以R433≤S E_K/[(3−ε₀)h]，无漏2或rankatom。

对固定来源y及M>0，闭窗M/K≤m_w≤KM使实际边长落在
L=(M/(Kλ))^(1/n)≤R_w≤U=(KM/q)^(1/n)。

真实selector层饼R_w⁻ⁿ=U⁻ⁿ+∫_{R_w}^U nt⁻ⁿ⁻¹dt，捕获y且R_w≤t的实际center域体积≤tⁿ，给闭窗ρ_y质量≤Bsym=[1+2logK+log(λ/q)]/q。base1/q保留，允许R plateau、闭边界及massatoms，不独立抽选半径。

ρ_y⊗ρ_y的strict远两方向与闭窗严格分割，因此I2=2F_far+N_closed，且N_closed≤Bsym∫fJ。I2有限由J≤An/q保证；∫fJ=|E|及Cauchy/Young给

I2≤2E_K/[q(1−1/K)]+Bsym√(WI2)
   ≤4E_K/[q(1−1/K)]+Bsym²W。

反向F_far≤I2/2，故E_K≤λI2/2。q带与source/receiver测度换算均正确。若证q²I2≲n polylog(n)W，Cauchy已直接给q|E|≤q√(WI2)为root量级，X≤λ|E|时也给相应r依赖。因而此二阶矩目标很强且未证；上述归约没有把原问题变成现成弱工具，也不显示一般估计不可能。

几何外source等式V_A=m_A²Q_A+E_A成立的必要范围是κ在smallmass receivers上，保证1−H_A(w)=f(Q_w\Q_A)/m_w；作者明列此支持。外source assignment跨父column未控。其exclusive square Q≤F/K与nativeQ≤X/(Kq)方向正确，不足付款Ffar的全来源重用。

numeric仅finite hard-volume profile；inverse-greedy与supλ[λy−∫(λH−1)+]的方向是mincost primal/dual，单个dual不能证明覆盖。其归一ρ是对dv的projectedmass density，与ĝ（对ν_A）通过ρ=ĝH_v/(hm_A)对应，故y=ρh²m_A²/(CB_eH_v)与PRE一致。不得将共享hard-volume与R449逐superlevel weak-L1互比；报告已说明。此时未跑未冻脚本，不将文稿计数当本审实际执行。
