# 第99轮：最优压力覆盖、共同内核支付与实际非线性 resolvent 最大值

日期：2026-10-12。目标仍为一般非负 L1 输入的中心轴平行立方体弱型常数 C_n ≤ sqrt(n)n^{o(1)}。本轮尚未完成该目标，保留一般 O(n log n) 基准。

本轮的三个一般进展分别是：对任意正 L1 来源构造有全局连续压力和饱和目标的正容量约束最优运输，并由其几何性质加一次有偿删帽恢复全尺度能量估计；在原捕获图和原尺度选择器上支付单位内核与有限网格内核，留下真实薄壳捕获余集；直接由局部变分证明实际非线性 resolvent 最大值的全输入弱型常数 1，以及 N 次隐式迭代的常数 N。这三条进展不能合并成未证明的根号阶结论。

方法限制也已严格保留：最优压力原帽本身不保证所需能量上界；共同内核支付后，薄壳的无条件包络仍花费线性维度；当前逐点 nonlinear-resolvent 桥梁尚不足以给出根号阶返回。私人下界模型、配方、程序和量化方法障碍留在本地，公开材料只保留定性失败信息，不将其称作原算子弱型下界。

协作配置为三个 Astra 证明路线、Astra 与 Sol 两个独立审核、两个 Sol 数值角色及一个 Sol 来源角色；决定性非线性瓶颈使用 Astra xhigh。命题先交独立反例筛查，再进行完整证明审查。主代理统一记号、独立阅读与复现，并单轮提交。技能仅按实际接口使用，技能清单和字节核验不代替文献全文或数学证明。

归档中的 sources、coverage、adaptive、nonlinear_maximal 均指本文合并后的逻辑模块；详细证明合并到 proof.md 与 proof.tex.txt，不额外复制为独立文件。

模块中提及的私人附录不包含在本公开归档内，仅保留定性失败说明及验证归属。


## 统一假设、全输入范围与完整回代账

设 Q(x,L)=x+[-L/2,L/2]^n，A_Lf=L^{-n}∫_Q f，μ=f dy，W=∫f，f≥0。空间接收测度始终是 dx。W=0 的正阈值事件为空，n=1 由既有一维界单独覆盖；本轮渐近账取 n≥2。

局部原事件仍使用同一输入、同一 λ、原可测最早硬接触 L_*(x)∈[1,2]，满足 A_{L_*}f=λ。保留原单位锚点、全窗口 P1 上门、原中间下限、原所选尺度粗门、包门及物理门。原中间强度的二进分层保持 O(log n) 层；绝不能用粗门的单尺度条件换成全窗口条件。来源限制后必须重新核验门，不继承原来的合格性。

完整老费用与新增费用在 adaptive 的式(13)中列出：

\[
\lambda|E_{\rm initial}|
\le [A_{\rm old}+C_{\rm ext}+\sqrt n+2\lceil\sqrt n\rceil]W
     +\lambda|F_2|.
\]

其中 A_old 含旧全来源极低费用，而单列 C_ext 是不同的捕获极低分支；两次都保留。F2 是原剩余事件扣去本轮两种明确已付内核分支，仍保留所有原门。其真实捕获超过半数位于相对宽度 O(n^{-1/2}) 的外壳，但需要的统一共同来源容量仍未知。实际局部完整预算必须再付已证的 O(log(n+2)) 全尺度返回；若另逐原强度层估计，保留实际 J_n=O(log n) 及重叠费用。不能将层数少或壳宽小直接等同于剩余预算小。

另一条独立的全尺度帽路线对同一任意 f 和每个 κ>0，构造 |U|≤3W/κ 及

\[
E_\kappa(f;U)\le {n\over1-2^{-n}}\,\kappa W\log(4n)\log(8n).
\]

代入第98轮已证的帽返回式，仍仅得 O(n log n)。这条路线已经全尺度，无须再人为增加局部分层因子；它也没有支付原 F2 的根号阶容量。保留同一捕获对上的压力联合约束，后续须利用其相关性或设计不同的有偿帽。

实际非线性 resolvent Jτ 的新定理对全部正 L1 输入成立：|{supτ Jτ^N f>Λ}|≤NW/Λ。N=1 常数为1。这个 N 是已证上界，不是最优常数的必要下界。一般热流最大值、一般 cube-to-flow 桥梁和有限步到真实流的统一误差尚未支付，不能通过 N→∞ 将增长的常数消去。

第98轮及更早已证工具继续保留。第88轮方差参数的子幂控制、一般子幂费用的共同删帽能量、来源根预算、全输入非线性桥梁等缺口未因本轮局部支付而关闭。数值证据的单位、真实输入数量和范围分别记录，不把重复执行当作新实验，不把有限测试升级为一般维数阶证明。


## S0. Exact result, with no moment or strict-convexity assumption

Let n≥1, 0≤f∈L¹(Rn), W=∫f>0, and v>0. Write μ=fdy and
\[
 c(y,z)=\tfrac12\|y-z\|_\infty^2,\qquad r=(W/v)^{1/n}.
\]
There exist a finite positive coupling π, a target density s, and globally defined continuous functions p,φ such that
\[
 (P_1)_\#\pi=\mu,\quad (P_2)_\#\pi=s\,dz,\quad0\le s\le v,
 \qquad\int s=W,                                                \tag{1}
\]
\[
 0\le p,\phi\le r^2/2,\quad \operatorname{Lip}_\infty(p),
 \operatorname{Lip}_\infty(\phi)\le r,\quad p\in L^1,
 \qquad \phi(y)=\inf_{z\in\mathbb R^n}[c(y,z)+p(z)].              \tag{2}
\]
Both the primal minimum and the following dual maximum are attained by this pair:
\[
 \min_{\gamma:\,P_1\gamma=\mu,\ P_2\gamma\le v\,dz}\int c\,d\gamma
 =\int c\,d\pi=\int\phi\,d\mu-v\int p.                         \tag{3}
\]
Here a feasible dual means p≥0, p∈L¹, a μ-integrable real φ, and φ(y)≤c(y,z)+p(z) pointwise; our pair additionally has (2). The optimal cost is finite even without any spatial second moment of f. The actual attained identities are
\[
 c(y,z)+p(z)=\phi(y)\quad\pi\text{-a.e.},\qquad
 s=v\quad\text{a.e. on }\Omega:=\{p>0\},\qquad
 |\Omega|\le W/v,\quad \|y-z\|_\infty\le r\quad\pi\text{-a.e.}   \tag{4}
\]
The set Ω is the open positivity set of the continuous pressure constructed here. No null-set modification of this representative is allowed when invoking its geometric depth. Neither a unique plan, a unique pressure, a transport map, nor differentiability of the max norm is asserted.

This is a capacity-cap construction, not the still-open target-strength exterior-energy estimate. Coverage owns the geometry and energy returns. The construction does not preserve any original hard/smooth/coarse gate, does not imply an order improvement for the cube maximal endpoint, and is not a signed-vector transport or nonlinear PDE superposition theorem.

## S1. Compact existence and duality by a finite-to-continuous proof

The only linear-programming external lemma used below is **finite balanced transport LP duality**: for finite nonnegative row/column masses of equal total mass and a finite cost matrix, the minimum over nonnegative matrices with these marginals equals the maximum of ∑α_i a_i+∑β_j b_j subject to α_i+β_j≤c_ij, and both are attained. This is ordinary finite LP strong duality, obtainable from finite-dimensional Farkas separation. We do not use a general infinite-dimensional minimax theorem. Compactness of finite measures on a compact metric space and Arzelà–Ascoli are the other standard topological tools.

Fix compact topological source support S⊂[−a,a]^n and mass W>0. We may use any r>0 with (2r)^n>W/v; ultimately take r=(W/v)^(1/n). Let
\[
 D=[-a-r,a+r]^n,\quad M=v|D|>W,
 \quad\widetilde\mu=\mu+(M-W)\delta_*,\quad\kappa=v1_Ddz.        \tag{5}
\]
The point * is isolated from S. On X=S⊔{*}, use cost c(y,z) for real y and cost 0 for *. This is a finite continuous cost on the compact metric product X×D. A coupling of μ̃ and κ restricts to a real-source plan whose target is s dz≤v1_Ddz. Conversely any such real plan extends by the dummy target measure κ−s dz. This is a positive-measure construction with equal total mass M; no density of the joint plan is required.

The compact balanced primal has a minimizer: its feasible set is nonempty (the product plan μ̃⊗κ/M), weakly compact, and the continuous bounded cost functional is continuous. Denote the minimum by P. We now prove its continuous dual attainment rather than importing an unverified book theorem.

Choose finite Borel partitions of S and D with max-norm cell diameter at most ε. Discard zero marginal-mass cells; choose x_i∈S and z_j∈D in their respective nonzero cells; keep the dummy point exact. The row masses are the actual μ-masses of source cells plus M−W, and column masses are the actual κ-masses of target cells. Set c_ij=c(x_i,z_j), c_*j=0, and let P_ε be the finite LP value.

In each real argument the cost on S×D is Lipschitz with constant
\[
 L=2a+r,\qquad 0\le c\le C=(2a+r)^2/2.
\]
Quantizing any compact coupling to these representatives changes cost by at most 2MLε and preserves its discrete marginals. Conversely, lift a discrete matrix by the product of the actual normalized source-cell and target-cell measures on each real cell pair; for a dummy pair use δ_* times the normalized target-cell measure. This preserves the full original marginals and has the same error bound. In particular
\[
 |P_\varepsilon-P|\le2ML\varepsilon.                            \tag{6}
\]
This controls all positive couplings, not just optimizers, and proves the required finite-to-continuous value convergence.

Normalize an attained finite dual by α_*=0, using the constant-shift invariance of the balanced objective, and set p_j=−β_j. The dummy constraints give p_j≥0. Complementarity with any finite optimal plan and strictly positive dummy mass gives at least one p_j=0. We can, without changing the optimum, take mutually transformed potentials
\[
 \alpha_i=\min_j(c_{ij}+p_j),\qquad
 p_j=\max(0,\max_i(\alpha_i-c_{ij})).                            \tag{7}
\]
Indeed the first replacement only increases real source potentials, while the second only decreases pressures, preserving feasibility; optimality and the positive cell masses force no objective change. Dummy complementarity still gives min_j p_j=0 after the replacements. Thus 0≤α_i,p_j≤C.

Extend the finite pair to the ACTUAL compact sets by
\[
 \phi_\varepsilon(x)=\min_j[c(x,z_j)+p_j],\quad
 p_\varepsilon(z)=\max(0,\sup_{x\in S}[\phi_\varepsilon(x)-c(x,z)]).
                                                                    \tag{8}
\]
The first extension equals α_i at x_i. For every x∈S, φ_ε(x)≤c(x,z_j)+p_j, so p_ε(z_j)≤p_j; the discrete maximizing source in (7), or the zero branch, gives the reverse inequality. Hence p_ε(z_j)=p_j exactly. Moreover feasibility gives φ_ε≤c+p_ε on S×D; minimizing over D and then choosing a minimizing target grid point proves
\[
 \phi_\varepsilon(x)=\inf_{z\in D}[c(x,z)+p_\varepsilon(z)]
 \quad\text{for every }x\in S.                                \tag{9}
\]
These functions are continuous, bounded between 0 and C, and Lipschitz with constant L on their respective sets. Extend the dummy source potential by 0. Comparing actual cell integrals to their representative values gives
\[
 \left|\int\phi_\varepsilon d\mu-\int p_\varepsilon d\kappa
       -P_\varepsilon\right|\le L\varepsilon(W+M)\le2ML\varepsilon.
\]
Arzelà–Ascoli gives a uniformly convergent subsequence on S and D. Its limit φ,p_D remains feasible, mutually transformed as in (8)–(9), and its dual value equals P by (6). Thus an attained continuous dual has been proved using a finite LP and explicitly paid uniform errors. No assertion of infinite dual attainment was hidden in a finite-grid computation.

Let π be the real-source part of any compact balanced optimal plan. Then its target is s≤v on D. The primal–dual gap equals the sum of the nonnegative real slack and dummy slack:
\[
 0=\int[c+p_D-\phi]d\pi+\int_D p_D(z)(v-s(z))dz.                \tag{10}
\]
Therefore real complementary equality and saturation on {p_D>0} follow. In particular |{p_D>0}|≤W/v. All identities are with the continuous pressure, so null-set holes have not been introduced.

## S2. Pointwise global representative and whole-space optimality

For every y∈S, the closed max-norm radius-r cube around y is inside D. Its volume is (2r)^n>W/v, hence it contains a point where p_D=0. Equations (9)–(10) imply
\[
 0\le\phi(y)\le r^2/2\quad(y\in S).                            \tag{11}
\]
Define on all of Rn
\[
 p(z)=\max(0,\sup_{y\in S}[\phi(y)-c(y,z)]).
\]
This agrees with p_D on D by (8) and its uniform limit. At and outside the boundary of D, the distance to every y∈S is at least r, so p=0 there. It is a genuine globally continuous pressure of compact support, and 0≤p≤r²/2. Every cone (b−||z−y||∞²/2)_+, with 0≤b≤r²/2, is r-Lipschitz: the scalar function (b−t²/2)_+ has slope magnitude at most sqrt(2b)≤r, and distance is 1-Lipschitz. Taking a supremum preserves this constant.

Set φ_global(y)=inf_{z∈Rn}[c(y,z)+p(z)] for every y∈Rn. It agrees with φ on ALL S: inside D the old infimum is φ by (9); points outside D have cost at least r²/2 and cannot reduce it. Choosing z=y gives φ_global≤p≤r²/2, and nonnegativity gives φ_global≥0. A minimizer always exists inside the closed radius-r cube around y. Translation of z in the infimum and the Lipschitz bound on p show Lip_∞φ_global≤r. We henceforth denote this global function by φ.

The same π has global pointwise feasible potentials with the same objective and complementary equalities. For any whole-space feasible plan γ of finite cost,
\[
 \int c\,d\gamma\ge\int\phi\,d\mu-\int p\,d(P_2\gamma)
 \ge\int\phi\,d\mu-v\int p.
\]
The inequality is also valid when cost is infinite; all dual terms are finite. Equality holds for π by (10). Thus the compact solution is a whole-space optimum and both extrema are attained. It is unnecessary to assume that an optimizer was initially confined to D; confinement has been obtained by a global certificate. The continuous representative supplies (1)–(4) for compact sources, including displacement≤r and ∫p≤r²W/(2v).

## S3. Full arbitrary-L¹ extension with pressure-tail settlement

Now let f be any positive L¹ source with W>0. Fix the SAME r=(W/v)^(1/n) throughout. Set μ_k=f1_[−k,k]^n dy and W_k=μ_k(Rn); discard initial k with W_k=0. Each compact proof uses this global r rather than (W_k/v)^(1/n), which is valid because (2r)^n>W_k/v. It gives π_k,s_k and globally defined continuous p_k,φ_k with
\[
 0\le p_k,\phi_k\le r^2/2,\quad\operatorname{Lip}_\infty p_k,
 \operatorname{Lip}_\infty\phi_k\le r,\quad
 |\{p_k>0\}|\le W_k/v,\quad d_\infty(y,z)\le r\ \pi_k\text{-a.e.}
                                                                    \tag{12}
\]
The source measures converge to μ in total variation. A diagonal Arzelà subsequence gives local uniform convergence p_k→p. The transform φ_k=inf(c+p_k) may always be restricted to ||z−y||∞≤r: choosing z=y gives at most r²/2, while all larger displacements cost strictly more. Uniform convergence of p_k on the needed compact neighborhood therefore gives local uniform φ_k→φ=inf(c+p), with all bounds and pointwise feasibility in (2). This infimum is attained in a compact radius-r cube.

Use max-norm cubes for all following tail statements. For R>r, the displacement bound implies
\[
 \int_{\|z\|_\infty>R}s_k(z)dz
 \le\mu_k\{\|y\|_\infty>R-r\}
 \le\mu\{\|y\|_\infty>R-r\}.                                 \tag{13}
\]
Thus target measures, and hence the joint plans along with their tight first marginals, are tight, with total masses W_k→W. A subsequence converges narrowly to a finite positive π whose first marginal is μ and whose second marginal is s dz≤v dz. The density constraint passes by testing nonnegative compact continuous functions; total mass and both marginals pass by tightness. The closed constraint ||y−z||∞≤r passes as well.

For any nonnegative compactly supported continuous test χ(y,z), local uniform convergence of the potentials and weak convergence of the plans pass the identity
∫χ(c+p_k−φ_k)dπ_k=0 to ∫χ(c+p−φ)dπ=0. The nonnegative continuous slack therefore vanishes π-a.e. This argument does not require convergence of cap indicators. To obtain saturation, take a compactly supported test in the open set Ω={p>0}. Its support has a strictly positive minimum of p, so it lies in {p_k>0} for all sufficiently large k. Since s_k=v there, weak convergence gives s=v a.e. on Ω. Pointwise positivity implies 1_Ω≤liminf 1_{p_k>0}; Fatou yields |Ω|≤W/v.

A separate tail estimate pays the potential integral at infinity. Because p_k vanishes off its positivity set and s_k=v on that set,
\[
 \int_{\|z\|_\infty>R}p_k(z)dz
 \le\frac{r^2}{2v}\int_{\|z\|_\infty>R}s_k(z)dz
 \le\frac{r^2}{2v}\mu\{\|y\|_\infty>R-r\}.                     \tag{14}
\]
The right side tends to zero uniformly in k. Local uniform convergence and (14) show p∈L¹, ∫p_k→∫p, and ∫p≤r²W/(2v). Bounded φ_k and total-variation source truncation, together with local uniform convergence and the source tail, give ∫φ_k dμ_k→∫φ dμ. Costs also converge: the bounded continuous function min(c,r²/2) equals c on every π_k and on π. Tight narrow convergence therefore gives ∫c dπ_k→∫c dπ.

Passing the compact identity (3), or using the limiting complementarity and saturation directly, proves (3) for the arbitrary-L¹ source. All costs and dual integrals are finite. No moment condition on y was used. Independently, there is always a finite-cost feasible plan: add to Y~μ a uniform displacement on the cube of full side r. The target density is f*Unif_r≤W/r^n=v and displacement≤r/2, so its cost is at most Wr²/8. Thus the attained optimum has that additional upper bound; this comparison does not imply that its individual displacements are all at most r/2.

This limit proves existence of one canonical continuous limiting representative and an optimal coupling; it does not prove uniqueness, convergence of the entire sequence, boundary regularity of Ω, convergence of exterior energies, or any cap-independent endpoint budget. Exterior estimates should be proved for the attained limit plan itself. If W=0, choose π=s=p=φ=0; r=0 is then harmless and the nonzero-mass arguments are not used. If v=0<W, no target of density≤v has mass W, so the problem is infeasible. v<0 is not an allowed ceiling.

## S4. Exact conditional geometry available to coverage

The existence theorem provides global pointwise feasibility, not merely a μ×Lebesgue-a.e. pair of potentials. If φ(y)>0 and ||z−y||∞<sqrt(2φ(y)), then p(z)≥φ(y)−c(y,z)>0. Hence the whole open radius-sqrt(2φ(y)) cube is in Ω. In the attained coupling, (4) gives
\[
 \|z-y\|_\infty\le\sqrt{2\phi(y)}
 \le\operatorname{dist}_\infty(y,\Omega^c)\quad\pi\text{-a.e.}
                                                                    \tag{15}
\]
For φ(y)=0, complementary equality forces c=0 and p(z)=0, so z=y. Ω has finite measure and therefore is not all of space; its complement is nonempty. The open-ball inclusion proves the distance inequality without a differentiable boundary. Ties in the squared max-norm cost do not affect (15); a coupling is sufficient. An arbitrary a.e. change to p could puncture Ω and invalidate this geometry, so the specific continuous representative is part of the theorem.

These are interface statements only. Coverage separately proves its energy consequences and pressures. A displacement/depth constraint does not by itself settle all-scale energy, kinetic cost, source concentration, or the maximal weak constant. No density relative to μ×dz of π is asserted.

## S5. Primary and skill reading receipt; source versus own proof

The current D01 SKILL.md, method, cube-interface and provenance were actually read this round, with the explicit read-only evidence root in the contract. It distinguishes ordinary positive static couplings from vector neutral plans, joint-density constraints, causal paths and semimartingale costs; its recorded sources do not automatically establish our target-density ceiling model. The old registry root was not repaired. No hash is being counted as proof reading.

Located bibliographic primary: Villani, *Optimal Transport: Old and New*, Springer, DOI 10.1007/978-3-540-71050-9, Chapter 5, Theorem 5.10. The publisher title/edition locator was verified. Browser fetch of the institutional book PDF failed on the size limit; a read-only in-memory PDF extraction succeeded (547 PDF pages), but the exact theorem and relevant proof pages have not yet been verified from that extraction. Search snippets and third-party transcriptions are not primary-proof reading. Consequently no conclusion above depends on claiming this theorem has been read: S1 supplies the compact proof explicitly from finite LP duality, and S2–S3 supply our own transfers. [Publisher locator](https://link.springer.com/book/10.1007/978-3-540-71050-9); [institutional primary-text locator](https://www.ceremade.dauphine.fr/~mischler/articles/VBook-O%26N.pdf).

A similarly named capacity-constrained transport paper can impose a ceiling on the JOINT density with both marginals fixed, which is a different problem. No theorem from that model is transferred here. No new primary reading of the retained heat, Finsler or partial-balayage papers is claimed this round.

The nonlinear-maximal author reported a new self-contained resolvent/obstacle proof and requested stopping the secondary search. That module owns its exact hypotheses, variational exchanges and weak constants. We did not import a linear Laplace identity, Hopf orbit average, or a general nonlinear maximal theorem. Our source role made no secondary primary-theorem assertion.

## S6. Verification and retained uncertainty

Both auditors received the compact dummy/localization, finite-grid-to-continuous, and arbitrary-L¹ limiting statements before these full proofs. The preliminary screening was conditional on the full proof. Subsequently both independent auditors completed full mathematical review of this Markdown and its matching TeX: PASS for S0–S6. The main agent independently read the complete proof and verified the final rendering corrections. These are proof-reading receipts; this source author did not execute a numerical program. The common R99 OT strategy's three-stage actual positive-L¹ primal/dual and exterior-energy checks are owned by the numerical and coverage modules. This source author did not execute their programs and makes no separate new numerical claim or reused R98 count. The decisive existence claim above is a continuous proof for all positive L¹ sources, with finite LP duality its explicitly stated standard finite-dimensional dependency.

Constants retained: exact cap-volume W/v; potential height r²/2; max-norm Lipschitz r; displacement r; finite cost upper Wr²/8; pressure integral≤r²W/(2v). The compact proof's approximation error is 2MLε with M=v(2a+2r)^n and L=2a+r, not a dimension-free computational complexity statement. Source support and input complexity disappear from the FINAL existence bounds only after the paid localization and limiting proof. General cube weak-type improvement remains OPEN.

## 1. Scope and conventions

The general target remains OPEN. We prove a dimension-free displacement/depth property of a capacity-constrained optimal coupling, retain its joint exterior receiver constraint, and pay for one additional cap to obtain an all-input estimate. The resulting weak bound is still O(n log n). The private appendix shows that an unmodified optimal pressure cap need not satisfy the desired energy estimate. This is a limitation of that cap mechanism, not a lower bound for the centered maximal operator or for every admissible cap.

Let n≥2, f≥0 belong to L1(R^n), W=∫f>0, and κ>0. Write

$$
Q(x,L)=x+[-L/2,L/2]^n,\qquad A_Lf(x)=L^{-n}\int_{Q(x,L)}f(y)\,dy,
\qquad E_\kappa(f;U)=\int_{U^c}\int_0^\infty(A_Lf(x)-\kappa)_+^2\,\frac{dL}{L}\,dx. \tag{1}
$$

All source measures, target measures, caps, and couplings below are fixed independently of x and L. All receiver integrations use Lebesgue measure. The same-round source module sources.md, §§S0–S6, proves the existence theorem for the positive coupling with cost c(y,z)=||y−z||∞²/2; our arguments use its precise conclusion, listed next. That self-contained proof passes from finite balanced transport LP duality to compact continuous dual attainment by actual-cell lifting with controlled error and Arzelà–Ascoli, then proves the global representative and arbitrary-L1 extension with tightness and pressure-tail settlement. Both independent auditors completed full Markdown and matching-TeX proof reviews of that theorem: PASS. This author also read the complete source proof. No unverified external compact-OT theorem is imported, and no source moment condition is needed. The general propositions below therefore apply to every nonnegative L1 input. The explicit private models additionally prove their own optimality directly.

For a target ceiling v>0 the required theorem supplies a positive plan π with first marginal fdy and second marginal sdz, 0≤s≤v, together with a globally defined continuous nonnegative pressure p∈L1 and its pointwise transform φ, satisfying

$$
\phi(y)=\inf_{z\in\mathbb R^n}\left\{\tfrac12\|y-z\|_\infty^2+p(z)\right\},\quad
\tfrac12\|y-z\|_\infty^2+p(z)=\phi(y)\quad\pi\text{-a.e.},\quad
s=v\ \text{a.e. on }\Omega=\{p>0\}. \tag{2}
$$

This entails |Ω|≤W/v. The representatives in (2) are essential: arbitrary almost-everywhere changes of p do not preserve the cap geometry. No uniqueness, transport map, strict convexity, or source second moment is assumed. W=0 is trivial and excluded only to avoid divisions.

## 2. Exact common-cap geometry

Put d(y,z)=||y−z||∞ and h(y)=dist∞(y,Ωc). Global feasibility gives p(w)≥φ(y)−||y−w||∞²/2 for every w. Therefore, whenever φ(y)>0, the open cube of radius sqrt(2φ(y)) centered at y lies in Ω. Complementarity and p≥0 then give

$$
d(y,z)\le\sqrt{2\phi(y)}\le h(y)\quad\pi\text{-a.e. on }\{\phi>0\};
\qquad \phi(y)=0\Longrightarrow d(y,z)=p(z)=0. \tag{3}
$$

The zero branch is a genuine identity branch. In particular it creates no positive-displacement occupation, even if h=0. Boundary points of an open cube do not affect the depth assertion.

There is additional joint structure, which should not be discarded when attempting a sharper estimate. If x∉Ω and y∈Q(x,L), then feasibility at the same point x yields 2φ(y)≤||x−y||∞²≤L²/4. For complementary pairs,

$$
d(y,z)^2+2p(z)\le L^2/4,\qquad \|x-z\|_\infty\le L,
\qquad z\in Q(x,2L)\cap\{p\le L^2/8\}. \tag{4}
$$

Both inequalities retain the same captured source and the same exterior center. Replacing this target intersection by all Q(x,2L) would cost a factor 2^n. We do not claim that its volume or occupation has a favorable uniform estimate. The private calculation tests the actual optimality condition, not merely the weaker inequality d≤h.

## 3. A specifically paid all-scale repair

Choose v=κ/2 and the same π, p, Ω once. Thus |Ω|≤2W/κ. Split actual source capture according to d≤L/(8n) and its complement. Every target coupled to a short captured source belongs to Q(x,L(1+1/(4n))). The target marginal bound applies to this submeasure, so the short part is at most

$$
\frac\kappa2\left(1+\frac1{4n}\right)^n\le\frac{e^{1/4}}2\kappa<\frac23\kappa. \tag{5}
$$

Define the actual long-displacement fields and their exterior occupations by

$$
N_L(x)=L^{-n}\int\mathbf1_{\{y\in Q(x,L)\}}\mathbf1_{\{d(y,z)>L/(8n)\}}\,d\pi(y,z),\qquad
\widehat N_L(x)=L^{-n}\int\mathbf1_{\{y\in Q(x,L)\}}\mathbf1_{\{d(y,z)>L/(16n)\}}\,d\pi(y,z), \tag{6}
$$

$$
M_0=\int_{\Omega^c}\int_0^\infty N_L(x)\,\frac{dL}{L}\,dx,\qquad
M_1=\int_{\Omega^c}\int_0^\infty\widehat N_L(x)\,\frac{dL}{L}\,dx. \tag{7}
$$

These are exact first moments, with units of source mass. They are not depth-log proxies or energy integrals. If an exterior receiver captures y, then L≥2h(y). A positive-displacement contribution to N must also have L<8nd. By (3), its scale window is contained in [2h,8nd), whose logarithmic length is at most log(4n). The corresponding window for the hatted field has length at most log(8n). For fixed y,L, the exterior receiver volume is at most L^n. Tonelli therefore proves

$$
M_0\le W\log(4n),\qquad M_1\le W\log(8n). \tag{8}
$$

All d=0 pairs contribute zero; there is no undefined logarithm at d=h=0. The argument also proves finiteness before any thresholding. It uses neither independent sources nor a covering multiplicity assumption.

For u∈[L,2L], a pair contributing to N_L also contributes to the hatted field at u: spatial capture persists and d>L/(8n)≥u/(16n). Thus, writing H(x)=∫_0^∞ hatted N_u(x)du/u,

$$
H(x)\ge N_L(x)\int_L^{2L}(L/u)^n\,\frac{du}{u}
=\frac{1-2^{-n}}n N_L(x),\qquad c_n=\frac n{1-2^{-n}}. \tag{9}
$$

If M1=0, (9) implies N=0 for almost every exterior receiver at every L, so Eκ(f;Ω)=0 and no added cap is needed. Otherwise define the single fixed added cap and union

$$
U=\Omega\cup\left\{x\in\Omega^c:H(x)>\kappa M_1/W\right\},\qquad |U|\le3W/\kappa. \tag{10}
$$

Chebyshev pays the additional W/κ exactly once. Outside U, (5) gives (A_Lf−κ)+≤N_L and (9) gives N_L²≤c_n H N_L. Integrating over all scales and receivers, retaining the actual cap exclusion, yields

$$
E_\kappa(f;U)\le c_n\kappa\frac{M_0M_1}{W}
\le c_n\kappa W\log(4n)\log(8n). \tag{11}
$$

The statement with the exact product can be better on particular inputs. No all-input subpower bound for that product has been proved. The persistence factor c_n remains of order n. A pressure cap arising from an explicit optimum has a fully explicit energy obstruction in the private appendix; the added H cap is an allowed repair with an explicitly paid volume, rather than an assumption that pressure optimality already bounds energy.

## 4. Complete return and remaining aggregate condition

Using the retained R98 cap-return inequality, which requires a cap for the same arbitrary f and every κ, a pair |U|≤A W/κ and Eκ≤BκW gives C_n≤4A+8sqrt(nAB/log2). Equations (10)–(11) supply

$$
A=3,\quad B=c_n\log(4n)\log(8n),\qquad
C_n\le12+8\sqrt{\frac{3n c_n\log(4n)\log(8n)}{\log2}}=O(n\log n). \tag{12}
$$

This uses the R98 return with its own assumptions, not the sharper R95 constant under a different presentation. The requested sqrt(n)n^{o(1)} estimate would require a new all-input payment beyond (11), for example c_n M0M1/W²=n^{o(1)} with the same bounded cap fee, or a different direct estimate that retains signed cancellation and the joint pressure sublevel in (4). It is not enough to call an exact occupation small, to select independent caps for each scale, or to sum independently chosen target budgets.

## 5. Numerical and review status

The numerical role completed the three actual stages for this strategy. Its atomic quadrature diagnostics are separated from exact positive-L1 certificates using actual exterior receiver volumes. The latter are rigorous lower certificates for the all-scale excess energy, not complete energy evaluations or upper bounds. Detailed recipes, counts, programs, quantitative outcomes, and hashes remain private. This author read the saved program and JSON and checked their reported counts and selected rational output rounding; no duplicate execution or independent code replay is claimed. The general formulas (3)–(12) and the private finite-q formulas were sent to both auditors before manuscript proof. Both independent auditors completed full mathematical review of this Markdown and the matching detailed TeX, including equations (1)–(24), the private continuum-source proofs, and the numerical scope statements: PASS. The source module's self-contained arbitrary-L1 existence theorem has also passed both full dual-format reviews, completing the general dependency.

## 1. Exact scope and retained input

There is a new unconditional common-column payment on the original capture graph. A unit-core branch costs `sqrt(n) W`; a finite mesh of additional common radii costs `2 ceil(sqrt(n)) W`. Their complement has more than half of its actual captured mass in a relative shell of width at most `log(2)/ceil(sqrt(n))`. These are paid reductions on the same input and original selector, not a root bound for the remaining event. The unrestricted moving-shell envelope still has mass `n log(2)`.

Let `mu=f dy`, `f>=0` in `L1(R^n)`, `W=mu(R^n)`, `lambda>0`, and
\[
 Q(x,L)=x+[-L/2,L/2]^n,\qquad A_Lf(x)=L^{-n}\mu(Q(x,L)).                 \tag{1}
\]
Let `F_rem` denote the original residual after the retained full-input and captured-low payments. Its original measurable earliest contact is `L_x in [1,2]`, with
\[
 A_{L_x}f(x)=\lambda,\qquad Q_x=Q(x,L_x).                              \tag{2}
\]
The original unit anchor, full-window `P_1`, middle, selected coarse, packet and physical gates all remain in its definition. No new gate is inferred at another radius. In particular, the coarse gate remains a statement at the original selected radius; no full-window coarse gate is used below.

All theorems below hold for every measurable subset of this event. In fact, the allocation proofs need only (2) and `L_x>=1`; this permits application to an unknown genuinely gated subset without declaring a larger set gated. Cube boundaries have zero `mu` mass. The case `W=0` has no positive-demand contact and is empty.

For a cut `B`, define its essential original capture neighborhood by
\[
 N_B^*=\{y:\int_B1_{Q_x}(y)\,dx>0\}.                                \tag{3}
\]
A nonnegative measurable kernel `a_x(y)` against the SAME source `mu`, with row mass `lambda`, support in `Q_x`, and column at most `C`, proves
`lambda |B| <= C mu(N_B^*)` for every cut: integrate the rows, use Tonelli, then the column bound. This is an explicit static positive coupling. D01 is used only to distinguish this feasible positive plan from signed transport, entropy likelihoods or process laws; no external dual-attainment theorem is imported.

## 2. A unit-core payment and its exact complement

For `T>0`, put
\[
 E_T=\{x\in F_{\rm rem}:A_1f(x)\ge\lambda/T\},\qquad
 a_x^{(1)}(y)=\frac{\lambda}{A_1f(x)}1_{Q(x,1)}(y).                    \tag{4}
\]
On `E_T`, the denominator is positive and the row integral is exactly `lambda`. The support is within `Q_x`. For every measurable `B subset E_T`,
\[
 \int_Ba_x^{(1)}(y)dx
 \le T|B\cap Q(y,1)|\le T.                                         \tag{5}
\]
Thus the same plan pays all cuts, with the stronger unit-capture neighborhood if desired. The measure in (5) is actual receiver Lebesgue volume, not a count of receivers or a conditional probability.

Set `T=sqrt(n)`. This adds at most `sqrt(n) W` to the retained ledger. It is not the already-paid original branch `A_1>=lambda/2`: its threshold is different, so its fee is added explicitly. It is also not the optional deletion of contacts near scale one. For `n<=4`, the original strict anchor can make this new branch empty; the bound remains valid.

On the remaining event `F_1=F_rem\E_T`, the original captured probability is
\[
 d\pi_x(y)=\frac{1_{Q_x}(y)d\mu(y)}{\lambda L_x^n},\qquad
 \pi_x(Q(x,1))<\frac1{T L_x^n}\le\frac1T.                            \tag{6}
\]
This hard-posterior statement is not a tilted-posterior estimate. If `F=Phi_1((x-y)/L_x)`, `Z_x=E_pi F>b_n`, then only
`E_pi[F 1_Q1]/Z_x <= M_0^n/(T L_x^n Z_x)` follows from `F<=M_0^n`. The possible exponential normalization is retained. The original joint `F,G` moments remain available but do not by themselves convert (6) to a common-column estimate.

## 3. Additional fixed radii: a paid narrow-shell reduction

Choose an integer `N>=1` and set `r_j=2^(j/N)`, `j=0,...,N`. After the unit-core deletion, define
\[
 E_{\rm grid}=\{x\in F_1:\exists j\in\{1,\ldots,N\},\ r_j\le L_x,
                       \ A_{r_j}f(x)\ge\lambda/2\}.                  \tag{7}
\]
Choose the smallest qualifying index `j(x)`. The finite choice is measurable. The allocation
\[
 a_x^{\rm grid}(y)=\frac{\lambda}{\mu(Q(x,r_{j(x)}))}
                    1_{Q(x,r_{j(x)})}(y)                            \tag{8}
\]
has exact row mass and original capture support. Each label has a separate column bound `2`: its normalization is at most `2 r_j^{-n}`, and `|Q(y,r_j)|=r_j^n`. Summing the `N` labels proves, simultaneously for every cut,
\[
 \lambda|B|\le2N\mu(N_B^*),\qquad B\subset E_{\rm grid}.             \tag{9}
\]
There is no probability normalization or packet-label entropy. There is, however, the explicit `N` label fee. The unit and grid branches are disjoint; their common columns may overlap, so the safe combined price is `T+2N`, not their maximum.

For the shell conclusion take `T>=2`, or retain separately the old original strict anchor `A_1<lambda/2`, which is already available here. On `F_2=F_1\E_grid`, `L_x` is not a grid radius: contact at such a radius would qualify (and `L_x=1` contradicts the old anchor). Let `j_-(x)` be its strict predecessor and `r_-(x)=r_{j_-(x)}`. The predecessor `j=0` obeys the old anchor; every other predecessor fails (7). Hence
\[
 \begin{split}
 &1\le r_-(x)<L_x<2^{1/N}r_-(x),\\
 &\pi_x(Q(x,r_-(x)))<\tfrac12(r_-(x)/L_x)^n<\tfrac12,\\
 &1-r_-(x)/L_x<1-2^{-1/N}\le(\log2)/N.                              \tag{10}
 \end{split}
\]
The actual captured mass of the outer shell is therefore strictly greater than half. This conclusion uses the SAME original selector and SAME source, without an independence claim. The joint soft gates can be retained exactly: write `F=Phi_1((x-y)/L_x)`, `G=Phi_theta((x-y)/L_x)`, and `M_0=sup phi_1`, so `E_pi F>b_n`, `E_pi G<alpha`, and `F<=M_0^n`. For every `eta>0`, positivity of `F` and a union bound give
\[
 E_{\pi_x}\big[F1_{S_x\cap\{G/F\le\eta\}}\big]
 >b_n-\frac{M_0^n}{2}(r_-(x)/L_x)^n-\frac\alpha\eta,
 \qquad S_x=Q_x\setminus Q(x,r_-(x)).                               \tag{10a}
\]
Indeed the deleted core costs less than `M_0^n(r_-/L)^n/2`, and the ratio-bad part costs at most `E_pi G/eta`. The right side of (10a) need not be positive. Thus more than half hard-captured shell mass does not automatically preserve useful tilted mass or pay a tilted common column. Choosing `N=ceil(sqrt(n))` pays an additional root-order branch and gives a width of order `n^{-1/2}`. More generally any fixed finite mesh is allowed with its displayed fee.

## 4. Exact residual allocation and the limitation of shell width

Set `S_x=Q_x\Q(x,r_-(x))` and `m_x=mu(S_x)>lambda L_x^n/2`. The actual original-source allocation
\[
 a_x^{\rm out}(y)=\lambda1_{S_x}(y)/m_x                              \tag{11}
\]
has row demand `lambda`. For `y in S_x`, put `u=2||x-y||_infty`; then `1<u<=L_x<=2` and
`lambda/m_x<2L_x^{-n}<=2u^{-n}`. Consequently every cut in `F_2` has common column at most
\[
 2\int_{1<2\|z\|_\infty\le2}(2\|z\|_\infty)^{-n}dz
       =2n\log2.                                                    \tag{12}
\]
The equality follows because the volume inside fullside radius `u` is `u^n`. It proves a valid fallback, not a root improvement.

In fact the source-independent shell envelope is unchanged by making a finite mesh finer. For `1<u<2` away from its finitely many radii, select `L=u`. Its predecessor is strictly below `u`, and the shell contains that boundary point. The supremum of `L^{-n}1_{Q(0,L)\Q(0,r_-(L))}` is exactly `u^{-n}` almost everywhere. Its integral is `n log2`. This is a deterministic envelope identity. It is not an actual original-gated input, operator lower bound or obstruction to optimized Hall allocations. The missing improvement must use the joint gates or common-source redistribution beyond this unrestricted envelope.

## 5. Complete original ledger and repeated uses

Use the retained constants
\[
\begin{gathered}
H_n=1+n\log2,\quad C_{\rm ext}=2H_n/\sqrt{n+2},\\
B_{\rm base}=4+2\log2\sqrt{7n/3},\quad
\theta=\log^{-2}(n+2),\quad\alpha=[10\log(n+2)]^{-1},\\
T_{\rm soft}=1+\log2\min\{2n,\sqrt{n(\theta^{-1}+4\theta/3)}\},\\
a_0=n^{-p_0},\quad\rho_0=n^{-1/2},\quad
P_{\rm dom}=(5+3\log(1/a_0))/\rho_0,\\
h_*=(16n^{3/2})^{-1},\quad E_*=e^{nh_*},\quad
B_*=1+E_*[1+(2n^2+n)h_*],\\
P_{\rm phys}=2[E_*+B_*+2(1+E_*)\sqrt n],\\
A_{\rm old}=B_{\rm base}+C_{\rm ext}+T_{\rm soft}/\alpha
                          +P_{\rm dom}+P_{\rm phys}.
\end{gathered}
\]
The physical union is paid once. The additional captured-low branch costs a SECOND `C_ext`, as in R97; its event differs from the older full-source extreme-low branch. Therefore
\[
 \lambda|E_{\rm initial}|
 \le(A_{\rm old}+C_{\rm ext}+T+2N)W+\lambda|F_2|.                    \tag{13}
\]
Using (12) gives the honest complete local fallback
`(A_old+C_ext+T+2N+2n log2)W`. The earlier canonical fallback can be smaller; neither is advertised as a new dimension-order improvement. Omitting the optional grid gives the unit branch alone with fee `T` and residual `F_1`. No additional full-window coarse or near-anchor fee is needed for these arguments. If separately used, those cost `T_soft/alpha` and `1+n log(1+1/sqrt(n))` respectively.

On a fixed input and fixed threshold, arbitrarily many disjoint receiver cuts of a branch may be joined before applying (5) or (9); they do not each require a new full-source fee. This is genuine common-column reuse. It does NOT apply for free to restricted inputs or changed thresholds. If `mu_i`, `lambda_i` are newly classified and `t_i=lambda_0/lambda_i`, the safe total branch cost is
\[
 \sum_{i<m}t_i(T_i+2N_i)W_i,                                       \tag{14}
\]
plus the retained old classification costs at every such input and the actual unfinished terminal demand. A general terminal fallback is `t_m H_n W_m`; no decay or summability is proved here. Empty receiver demand has zero terminal demand even when residual source mass is positive. All-scale return still multiplies the local bound by `O(log(n+2))`; any separate original-strength layering retains its actual `J_n=O(log n)` and overlap. Source restrictions require fresh original gates, not inherited qualification.

## 6. What is gained and what remains

The new result is an explicit all-source, all-cut feasible payment on common cores, with an additional paid true-shell reduction. It changes neither the original source nor the original selected cube. The remaining original joint-gated event has a stronger unit anchor, small mass at every eligible mesh anchor and more than half of its true hard capture in the narrow outer shell. A uniform root common-column estimate for that remaining class is still OPEN. In particular, no ratio-only allocation estimate, averaged fixed-mass transport estimate, posterior independence or source-root recursion is inferred.

## Actual resolvent maximal theorem

Let
\[
 E(v)=\frac12\int_{\mathbb R^n}\|\nabla v\|_1^2\,dx\quad(v\in H^1),
 \qquad E(v)=+\infty\quad(v\notin H^1),\qquad
 J_\tau=(I+\tau\partial_{L^2}E)^{-1}.
 \tag{R1}
\]
The actual crystalline flow associated with this energy was constructed in R98. Here the actual resolvent is characterized directly by
\[
 J_\tau g=\mathop{\rm argmin}_{v\in L^2}
       \left[E(v)+\frac1{2\tau}\|v-g\|_2^2\right].
 \tag{R2}
\]
Existence follows by the direct method, and strict convexity of the quadratic term gives uniqueness. No heat-kernel or Laplace representation is assumed.

**Theorem R.** For every integer \(N\ge1\), nonnegative \(f\in L^1(\mathbb R^n)\), and \(\Lambda>0\),
\[
 |\{\mathcal J_N^*f>\Lambda\}|\le N\frac{\|f\|_1}{\Lambda},
 \qquad \mathcal J_N^*f=\sup_{\tau>0}J_\tau^N f.
 \tag{R3}
\]
For \(N=1\) the constant is one, independent of dimension. The supremum uses the jointly measurable version specified below and equals the rational-parameter supremum. The same proof applies to any fixed norm in place of \(\|\cdot\|_1\), without an anisotropy fee: its decisive gradient exchanges are exact. This is an actual nonlinear resolvent theorem.

### Order, L1 extension, and all-parameter representatives

For \(u=J_\tau f\), \(v=J_\tau g\), \(d=u-v\), set
\[
 T_\varepsilon(d)=\min\{(d/\varepsilon)_+,1\}.
\]
This function belongs to \(H^1\cap L^2\). For \(0<\eta\le\varepsilon/2\), the competitors \(u'=u-\eta T_\varepsilon(d)\) and \(v'=v+\eta T_\varepsilon(d)\) satisfy
\(E(u')+E(v')\le E(u)+E(v)\). On \(0<d<\varepsilon\), the new gradients are the two convex combinations of the original gradients with coefficients \(\eta/\varepsilon\) and \(1-\eta/\varepsilon\); elsewhere they are unchanged. Convexity of the integrand proves this inequality. Adding the two minimizing inequalities therefore gives
\[
 \int dT_\varepsilon(d)\le
 \int(f-g)T_\varepsilon(d)+\eta\int T_\varepsilon(d)^2.
\]
Let \(\eta\downarrow0\), then \(\varepsilon\downarrow0\). For \(f,g\in L^1\cap L^2\), Fatou yields
\[
 \int(J_\tau f-J_\tau g)_+\le\int(f-g)_+.
 \tag{R4}
\]
For arbitrary ordered \(L^2\) inputs the prelimit right side after \(\eta\downarrow0\) is nonpositive, which proves order preservation as well. Since \(J_\tau0=0\), positivity follows. Applying (R4) in both orientations gives \(L^1\) contraction, and hence a unique continuous extension to \(L^1\), preserving order.

Parameter continuity must also be paid. If \(u=J_\tau h\), \(v=J_\sigma h\), monotonicity of the subgradient gives
\[
 \|u-v\|_2\le|\tau-\sigma|\|(h-v)/\sigma\|_2
 \le\frac{|\tau-\sigma|}{\sigma}\|h\|_2.
 \tag{R5}
\]
For the last inequality write \(h=v+\sigma\xi\), \(\xi\in\partial E(v)\), and use \(\langle\xi,v\rangle\ge0\). Combining (R5) with resolvent \(L^2\) contraction proves, on \([\ell,T]\),
\[
 \|J_\tau^N f-J_\sigma^N f\|_2
 \le (N/\ell)\|f\|_2|\tau-\sigma|.
 \tag{R6}
\]
An \(L^2\)-valued Lipschitz curve has a Bochner derivative on such an interval and an integral representation. The estimate
\(\|\int_\ell^T|u'(\tau,\cdot)|\,d\tau\|_2
 \le\int_\ell^T\|u'(\tau)\|_2\,d\tau\)
makes that representation pointwise absolutely continuous almost everywhere, even on this infinite-measure space. Patching countably many intervals and rational values supplies a jointly measurable version continuous in positive parameter outside one null set. Its supremum equals the rational supremum.

For general \(f\ge0\) in \(L^1\), use \(f_m=\min(f,m)\in L^1\cap L^2\). The versions \(J_\tau^Nf_m\) can be chosen increasing in \(m\) simultaneously for all parameters: first use order at rationals, then continuity. Their pointwise supremum is jointly measurable and lower semicontinuous in \(\tau\); at every fixed \(\tau\) it is the actual \(L^1\) extension by (R4). Its real and rational suprema agree. This specifies the version in (R3).

### One variational obstacle controls every parameter in a window

For now \(f\ge0\) belongs to \(L^1\cap L^2\). For \(\delta,\lambda>0\), minimize
\[
 \Phi_{\delta,\lambda}(w)
 =E(w)+\frac{\delta}{2}\|w\|_2^2+\lambda\|w\|_1-\langle f,w\rangle
 \quad\text{over }w\ge0.
 \tag{R7}
\]
The value is infinite outside \(H^1\cap L^1\). The lower bound
\[
 \Phi_{\delta,\lambda}(w)\ge
 E(w)+\frac{\delta}{4}\|w\|_2^2+\lambda\|w\|_1-\frac{\|f\|_2^2}{\delta}
\]
bounds a minimizing sequence. The positive cone, \(E\), and the integral of a nonnegative function are weakly lower semicontinuous in \(L^2\). For the last functional, strong lower semicontinuity follows from a pointwise subsequence and Fatou, and convexity gives weak lower semicontinuity. The direct method yields a unique minimizer \(w=w_{\delta,\lambda}\); the strictly convex quadratic term supplies uniqueness.

Set \(k_h=\min(w,h)\). The competitor \(w-k_h=(w-h)_+\) decreases both energy and squared \(L^2\) norm. Minimality implies \(\lambda\int k_h\le\int f k_h\). Divide by \(h\) and let \(h\downarrow0\), using monotone convergence on the left and dominated convergence against \(f\) on the right:
\[
 \lambda|\Omega_{\delta,\lambda}|
 \le\int_{\Omega_{\delta,\lambda}}f\le\|f\|_1,\qquad
 \Omega_{\delta,\lambda}=\{w_{\delta,\lambda}>0\}.
 \tag{R8}
\]

For \(0<\tau<1/\delta\), let \(q=\tau J_\tau f\). By 2-homogeneity, \(q\) minimizes \(E(q)+\|q-\tau f\|_2^2/(2\tau)\). Put \(\psi=(q-\tau\lambda-w)_+\). The competitors \(q-\psi\) and \(w+\psi\) are admissible. Sobolev truncation gives \(H^1\cap L^2\) membership, and
\[
 0\le\psi\le q1_{\{q>\tau\lambda\}}\le q^2/(\tau\lambda)
\]
gives the required \(L^1\) membership. Locality gives the exact identity
\[
 E(q-\psi)+E(w+\psi)=E(q)+E(w):
 \tag{R9}
\]
on \(\{\psi>0\}\) the gradients are exchanged, and elsewhere they are unchanged. Add the two minimizing inequalities. After cancellation, their potential difference is exactly
\[
 0\le-\left(\frac1\tau-\delta\right)
       \int\left(w\psi+\frac{\psi^2}{2}\right).
\]
Thus \(\psi=0\), proving
\[
 J_\tau f\le\lambda+w_{\delta,\lambda}/\tau
 \qquad(0<\tau<1/\delta).
 \tag{R10}
\]
One support therefore contains all strict level sets in this whole parameter window. For fixed \(T\), choose \(\delta<1/T\), enforce (R10) simultaneously at rational \(\tau\le T\), and use the continuous version and (R8). Let \(T\uparrow\infty\). This proves the constant-one case of (R3). There is no convergence or nesting assertion about the supports, and no union of separate fixed-time budgets.

### A fully paid finite-iterate repair

The next comparison is proved by admissible variations, without obstacle flux splitting and without treating a non-\(L^2\) constant shift as an admissible competitor. Suppose \(g\ge0\) lies in \(L^1\cap L^2\), \(u=J_\tau g\), and
\[
 g\le a\,w/\tau+b\lambda,\qquad a,b>0,\qquad 0<\tau\delta<1.
\]
Set
\[
 c=\frac{a}{1-\tau\delta},\quad d=b+c,\quad k=c/\tau,\quad
 \psi=(u-kw-d\lambda)_+.
\]
Use \(u-\psi\) in the resolvent problem and \(w+\psi/k\) in the obstacle problem. They are admissible, since
\(\psi\le u1_{\{u>d\lambda\}}\le u^2/(d\lambda)\).
Locality and homogeneity give
\[
 E(u-\psi)+k^2E(w+\psi/k)=E(u)+k^2E(w).
\]
Multiply the obstacle minimizing inequality by \(k^2\) and add the resolvent minimizing inequality. On \(\{\psi>0\}\), substitute \(u=kw+d\lambda+\psi\). The resulting potential difference is
\[
 \begin{aligned}
 D={}&\int\left[\frac{g-d\lambda}{\tau}
       -k\left(\frac1\tau-\delta\right)w+k\lambda-kf\right]\psi\\
 &-\frac12\left(\frac1\tau-\delta\right)\int\psi^2 .
 \end{aligned}
 \tag{R11}
\]
Minimality gives \(0\le D\). The bound on \(g\), the definitions of \(c,d\), and \(f\ge0\) make the square bracket nonpositive. Hence \(\psi=0\):
\[
 J_\tau g\le c\,w/\tau+d\lambda.
 \tag{R12}
\]
Starting from (R10), induction proves
\[
 J_\tau^N f\le a_N(\tau\delta)w/\tau+b_N(\tau\delta)\lambda,
 \quad a_N(r)=(1-r)^{-(N-1)},\quad
 b_N(r)=\sum_{j=0}^{N-1}(1-r)^{-j}.
 \tag{R13}
\]
For a fixed window \(\tau\le T\), choose \(0<\delta T<1\) and
\(\lambda=\Lambda/b_N(\delta T)\) in the obstacle. Outside its support, (R13) bounds every iterate by \(\Lambda\), because \(b_N\) increases. Thus
\[
 |\{\sup_{0<\tau\le T}J_\tau^Nf>\Lambda\}|
 \le b_N(\delta T)\|f\|_1/\Lambda.
\]
Let \(\delta\downarrow0\), using \(b_N(0)=N\), and then \(T\uparrow\infty\). Finally \(f_m\uparrow f\) gives \(\mathcal J_N^*f_m\uparrow\mathcal J_N^*f\) in the common version. Monotone convergence of strict level sets completes (R3) for all nonnegative \(L^1\) data.

### Exact unpaid continuation

The obstacle proves an actual all-input maximal theorem. The available finite-iterate weak bound is \(H_N\le N\); this is an upper bound, not a necessary cost. The actual flow maximum \(\mathcal S^*f=\sup_{t>0}S_tf\) remains unpaid. The exponential formula \(S_tf=\lim_{N\to\infty}J_{t/N}^Nf\) does not turn (R3), with its growing constant, into a finite maximal bound. Nor does it justify replacing all flow maxima by one finite \(N\), uniformly over all inputs.

A continuation needs either a smaller all-input iterate budget, with a proved general cube/flow comparison, or a direct flow hitting-set estimate. The original \(\sqrt n\,n^{o(1)}\) centered-cube goal stays open.

本轮完成了实际非负、紧支撑 L1 来源的有限维检验：同一连续运输计划和压力函数给出精确的源、目标、最优性及帽体积账；实际帽外的立方体平均能量另以真实 Lebesgue 体积和有理尺度窗口作证明型核验。原子积分仅列为浮点诊断，未用原子极限代替 L1 输入。

所有具体压力配方、程序、参数及量化下界目前属于 PRIVATE，不能从本稿提取到公开支撑包。公开可记录的方法区别是：证明帽的运输最优性，并不自动支付该帽外的能量；同一帽的检验也不能排除增加另一收费帽的修复。此处没有原始 Fnew 全门资格、一般弱型常数、所有帽的能量下界或一般维度指数拟合。总体目标仍 OPEN。

有限窗口下界以非负能量为对象：可丢弃未测窗口，但不能把零下界说成能量为零。浮点求积加密差不是误差证书。所有具体结果与复现入口保留在本地未公开材料中。

The fixed physical input admits an exact common-source allocation on its support interior. The allocation lies inside each original capture cube and retains true Lebesgue receiver volume. Thus unresolved gate membership does not prevent a conditional allocation theorem for the genuine gated subset.

The support boundary is paid separately: boundary receivers capture only a source collar near a face, and the canonical window envelope charges that collar's actual mass. Together these give a complete local demand payment for this fixed input. The boundary payment is an integrated source fee, not a uniform bound on every boundary column.

This is not a new general or all-scale weak estimate or a classification of the unresolved residual. No new coarse-low volume, success of the earlier ratio-only or noise allocation, or posterior independence is asserted. The original selected-high exclusion is retained separately and was not rerun.

The adaptive module supplies the general paid version: receivers with a sufficiently large unit-scale average can be assigned through that unit cube at the chosen common-column budget. Its source fee must be retained, and the remaining anchor becomes stronger. This does not settle the remaining common-source problem.

## Independent Astra audit: mathematical scope and evidence

The contract was read before author proofs. Precise candidate statements were screened independently, followed by full reading of all four theoretical Markdown modules and their matching detailed TeX: sources, coverage, adaptive and nonlinear maximal. The numerical and fixed-source reports and complete producers were also reviewed. Standard finite-dimensional LP duality and compactness tools are explicitly identified; no unread infinite-dimensional transport theorem or primary-paper proof is credited to this auditor.

The general transport theorem passes: it constructs an attained positive plan and a globally continuous pressure for arbitrary nonnegative L1 input, settles the pressure tails, and obtains a genuine common open cap and the stated displacement/depth relation. It does not itself pay exterior energy. Coverage's additional common height cap pays every scale but retains an order-n logarithmic return. Its private method-pressure conclusions concern the specified cap strategy, not all caps or the original weak constant.

The adaptive allocations give actual common-source, all-cut payments on the unchanged original graph. Unit-core and mesh-label fees add; old classifications, threshold returns and unfinished terminals remain. Hard shell mass does not automatically imply useful tilted mass, and the joint-score deficit may be nonpositive. The residual moving-shell envelope remains linear in dimension. The separately reviewed fixed-source local payment does not establish a uniform boundary column or an all-input/all-scale theorem, and it does not certify unresolved gate membership.

The nonlinear resolvent maximum has a genuine all-positive-L1 weak bound, with explicit finite-iterate cost. Both local variational exchanges, admissible competitors, support budgets and all-parameter versions were checked. Orbit-specific integral identities are not general nonlinear superposition rules. Costs of using the available iterate certificate are distinguished from lower bounds on the unknown optimal weak constant. The actual-flow maximal endpoint and the cube target remain open.

Independent temporary-copy replays were completed for the exact numerical producer, the final fixed-source producer, and the embedded nonlinear scalar diagnostic. The first reproduced every result byte without exclusions; the second reproduced every mathematical and descriptive field after only its two named timing exclusions; the last reproduced the recorded scalar output precision. These are replays, not new physical inputs. Rational lower certificates, floating diagnostics, source counts, scale bands and repeated executions remain distinct. Zero lower certificates are not zero energy. The separate public obstacle guard was fully read and its continuum mechanism checked; its execution is attributed to its actual executors, not to this auditor.

All concrete private recipes, programs and quantitative method-pressure outcomes remain outside this public region. No finite diagnostic establishes an asymptotic operator exponent. General square-root-order improvement is not proved. Final document assembly and archive extraction are separate integration checks, not implied by this mathematical review.

## Independent Sol audit

All finalized mathematical modules were independently screened before proofs, then fully reviewed in Markdown and matching detailed TeX. Relevant programs and evidence scopes were also checked: PASS. The general centered-cube target and the actual-flow maximal endpoint remain OPEN.

The attained positive capacity transport theorem is established for arbitrary nonnegative L1 sources through finite LP duality, controlled continuous lifting, canonical pressure representatives and fully paid tightness/tail limits. Its geometry does not itself pay exterior energy. The coverage repair pays one additional cap and returns O(n log n). Private pressure applies to a specified raw-cap selection, not every cap or the maximal weak norm.

The actual nonlinear resolvent maximum has constant-one weak type; finite iterates pay their iteration count. No all-input nonlinear Laplace representation or unpaid flow comparison is used. Original-capture common-core and finite-mesh branches pay their displayed source fees, retain all joint gates, and leave the moving-shell capacity unresolved. The unchanged private input has complete local payment, without asserting positive LOW volume or a general/all-scale theorem.

The standalone independent guard reconstructs one NEW actual positive-L1 regularized obstacle in four dimensions, including its supporting crystalline flux, variational residual, cap budget and five complete continuum spatial integrals. It ran successfully from an isolated copy in 0.016275083 seconds. This is distinct from author-program replay, the retained-source coordinate-period reconstruction, and scalar FLOAT diagnostics; it is not a PDE numerical solve or a rebuild of the producer's energy menu. Atomic diagnostics, finite-width L1 lower certificates, zero lower outputs and general proofs remain separately qualified. Private recipes and quantitative method lower conclusions are excluded from this public audit.

## 实际执行的主代理验证与复现

主代理在临时目录隔离复制并执行了四项最终程序，exit code 均为0、stderr为空。

- 私有最优压力帽证书：结果全部412874字节一致，没有忽略字段，外部耗时2.386180秒。该程序中的有理积分与定向对数下界是相应有限输入的精确证书；另列浮点积分不是区间证书。私人参数与量化结果不进入公开归档。
- 私有固定输入的共同捕获及边界修复证书：所有数学和描述性 JSON 字段一致，仅剔除按名称指定的计时字段，外部耗时0.030108秒。依赖复制后核对原文件哈希；没有运行旧门测试或增加随机样本。此项只覆盖其明示的固定输入及局部尺度窗口。
- 非线性模块：从报告提取原代码，九组标量参数行与记录精度一致，一次加密诊断通过，外部耗时0.296283秒。有限截尾、浮点积分与参数优化均未被称作严格全局极值或 PDE 求解；证明独立于该诊断。
- 独立公开障碍函数守卫：外部耗时0.014997秒。它从一个实际正 L1 来源与实际正正则化障碍的分段公式重建通量、五个全空间积分和删帽预算；无需作者程序或已保存结果。它不验证一般弱端点或帽外能量。代码在本文末尾，可用 Python 3 标准库直接复现。

每项策略的初探、已知压力和扩大范围在原模块中分开记录；后两阶段受到先前发现启发，未声称盲预注册。重复执行不增加输入数。公开独立守卫仅有一个实际来源，五个积分不是五个来源。

本轮使用更新后的64项数学工具条目体系，重点核查 A02 的界方向与误差预算、D01 的正运输及对偶条件、E03 的跨层支付、G03 的真实来源算子接口、N03 的几何余项边界；F04 的线性变换适用限制和 N04 的误差求和限制继续保留。数学结论由报告中的明示证明支持，不由技能名、哈希或定位到文献自动保证。

公开归档排除私人模型配方、私人程序和未发表的量化方法下界。详细 LaTeX 文本仅做静态控制字符、环境、括号、标签与引用检查；按照要求不编译，也不生成 PDF。一般根号阶上界仍未证明。


## 独立公开审核程序

```python
"""Independent R99 continuum obstacle certificate, standard library only.

One actual positive L1 source in R4, lambda=delta=1. Write r=||x||inf.
The obstacle is w=3/4-15r^2/8 for r<=1/2, w=(r^2+r^-2-2)/8
for 1/2<r<1, and zero elsewhere. Source f=16+w on the inner cube,
f=w on its outer shell, zero outside. This is not an author import, a
saved-result check, a PDE solver, or a reconstruction of numeric menus.

Off the null coordinate-tie set grad w has one active coordinate, and
z=w'(r)x/r has infinity norm |w'| and z dot grad w=|grad w|_1^2.
Thus z is a genuine crystalline supporting flux. Its matching traces and
zero boundary flux imply -div z+w+1-f=0 inside {w>0}, and this residual
equals 1 outside. Convexity and integration by parts therefore give
Phi(g)-Phi(w)>=||g-w||_2^2/2+integral_{r>=1}g for every admissible g>=0.
The certificate checks this actual regularized obstacle, not an endpoint
for arbitrary inputs, a resolvent numerical solve, or exterior energy.
"""
from fractions import Fraction as Q
import json


def add(*polys):
    out = {}
    for p in polys:
        for k, v in p.items():
            out[k] = out.get(k, Q(0)) + v
    return {k: v for k, v in out.items() if v}


def scale(p, c):
    return {k: c*v for k, v in p.items() if c*v}


def mul(p, q):
    out = {}
    for k, v in p.items():
        for j, u in q.items():
            out[k+j] = out.get(k+j, Q(0)) + v*u
    return {k: v for k, v in out.items() if v}


def derivative(p):
    return {k-1: k*v for k, v in p.items() if k}


def value(p, r):
    return sum((v*r**k for k, v in p.items()), Q(0))


def radial_integral(p, lo, hi):
    """Full R4 integral; result is rational + coefficient*log(2).

    |{||x||inf<r}|=(2r)^4, so the complete shell density is 64r^3.
    The sole logarithmic interval here has hi/lo=2.
    """
    rational, log2 = Q(0), Q(0)
    for k, v in p.items():
        exponent = k+3
        if exponent == -1:
            assert lo > 0 and hi == 2*lo
            log2 += 64*v
        else:
            power = exponent+1
            assert lo > 0 or power > 0
            rational += 64*v*(hi**power-lo**power)/power
    return rational, log2


def sum_integrals(*pairs):
    return tuple(sum((p[i] for p in pairs), Q(0)) for i in (0, 1))


def log2_interval():
    z, terms = Q(1, 3), 24
    lower = 2*sum((z**(2*j+1)/(2*j+1) for j in range(terms)), Q(0))
    remainder = 2*z**(2*terms+1)/((2*terms+1)*(1-z*z))
    return lower, lower+remainder


def main():
    half = Q(1, 2)
    inner = {0: Q(3, 4), 2: Q(-15, 8)}
    outer = {2: Q(1, 8), -2: Q(1, 8), 0: Q(-1, 4)}
    di, do = derivative(inner), derivative(outer)
    assert value(inner, half) == value(outer, half) == Q(9, 32)
    assert value(di, half) == value(do, half) == Q(-15, 8)
    assert value(outer, Q(1)) == value(do, Q(1)) == 0
    # Exact positivity identities, not samples at receiver centers.
    assert mul({2: Q(1)}, outer) == scale(mul({2: Q(1), 0: Q(-1)},
                                                           {2: Q(1), 0: Q(-1)}), Q(1, 8))
    assert di == {1: Q(-15, 4)} and value(inner, half) > 0
    # Full divergence includes all four coordinates; no missing transverse volume.
    neg_div_i = scale(add(derivative(di), mul({-1: Q(3)}, di)), Q(-1))
    neg_div_o = scale(add(derivative(do), mul({-1: Q(3)}, do)), Q(-1))
    assert neg_div_i == {0: Q(15)} and neg_div_o == {0: Q(-1)}
    fi = add(inner, {0: Q(16)})
    fo = outer
    assert add(neg_div_i, inner, {0: Q(1)}, scale(fi, Q(-1))) == {}
    assert add(neg_div_o, outer, {0: Q(1)}, scale(fo, Q(-1))) == {}
    mass = sum_integrals(radial_integral(fi, Q(0), half),
                         radial_integral(fo, half, Q(1)))
    obstacle_l1 = sum_integrals(radial_integral(inner, Q(0), half),
                                radial_integral(outer, half, Q(1)))
    gradient_l2 = sum_integrals(radial_integral(mul(di, di), Q(0), half),
                                radial_integral(mul(do, do), half, Q(1)))
    obstacle_l2 = sum_integrals(radial_integral(mul(inner, inner), Q(0), half),
                                radial_integral(mul(outer, outer), half, Q(1)))
    source_work = sum_integrals(radial_integral(mul(fi, inner), Q(0), half),
                               radial_integral(mul(fo, outer), half, Q(1)))
    assert mass == (Q(17), Q(0)) and obstacle_l1 == (Q(1), Q(0))
    assert gradient_l2 == (Q(6), Q(0))
    assert obstacle_l2 == (Q(-27, 64), Q(1))
    assert source_work == (Q(7)-Q(27, 64), Q(1))
    assert source_work[0]-obstacle_l2[0]-obstacle_l1[0] == gradient_l2[0]
    assert source_work[1]-obstacle_l2[1]-obstacle_l1[1] == gradient_l2[1]
    lo, hi = log2_interval()
    assert Q(0) < lo-Q(27, 64) < hi-Q(27, 64) < Q(1)
    cap_volume = (2*Q(1))**4
    assert cap_volume == 16 <= mass[0]
    print(json.dumps({
        'status': 'PASS', 'actual_source_instances': 1, 'dimension': 4,
        'source_mass': str(mass[0]), 'cap_volume': str(cap_volume),
        'obstacle_L1': str(obstacle_l1[0]), 'gradient_L2_squared': str(gradient_l2[0]),
        'energy': str(gradient_l2[0]/2), 'obstacle_L2_squared': 'log(2)-27/64',
        'source_work': '7+log(2)-27/64', 'whole_space_continuum_integrals': 5,
        'author_imports': 0, 'PDE_solves': 0, 'receiver_energy_rebuilds': 0,
        'scope': 'one actual regularized crystalline obstacle and its exact cap budget'
    }, sort_keys=True))


if __name__ == '__main__':
    main()
```
