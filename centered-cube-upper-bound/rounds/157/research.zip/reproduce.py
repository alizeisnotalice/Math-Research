#!/usr/bin/env python3
"""Reproduce R157 exact certificates and finite saved-data classifications."""
from pathlib import Path
import argparse,zipfile,shutil,subprocess,sys,json
p=argparse.ArgumentParser();p.add_argument('--rounds',type=Path,required=True);p.add_argument('--detail',type=Path,required=True);p.add_argument('--destination',type=Path,required=True);a=p.parse_args()
src=Path(__file__).resolve().parent;dst=a.destination.resolve()
if dst.exists():raise SystemExit('Use a new destination')
dst.mkdir(parents=True)
for n in ['fullscore_scope.py','exact_checks.py','contract.md']:shutil.copy2(src/n,dst/n)
with zipfile.ZipFile(a.rounds/'139/research.zip') as z:
 names=[n for n in z.namelist() if Path(n).name=='active_traffic_v2.json'];assert len(names)==1
 (dst/'active_traffic_v2.json').write_bytes(z.read(names[0]))
def run(args):
 r=subprocess.run([sys.executable,*map(str,args)],cwd=dst,capture_output=True,text=True)
 if r.returncode:raise RuntimeError(r.stderr+r.stdout)
 print(r.stdout.strip())
base=['--detail',a.detail.resolve(),'--template',dst/'active_traffic_v2.json']
run(['fullscore_scope.py',*base,'--output',dst/'fullscore_scope.json'])
run(['exact_checks.py',*base,'--scope-json',dst/'fullscore_scope.json','--scope-source',dst/'fullscore_scope.py','--output',dst/'exact_checks.json'])
for n in ['fullscore_scope.json','exact_checks.json']:assert (src/n).read_bytes()==(dst/n).read_bytes(),n
j=json.loads((dst/'exact_checks.json').read_text());assert j['status']=='PASS'
print('REPLAY_PASS; both JSON byte-identical; no new kernel or receiver points')
