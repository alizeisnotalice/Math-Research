# R157 定向历史范围核验

## 结论

在定向检查的 R148 与 R151 原文中，没有找到“固定来源集合 (B_0)、(w_z=\prod_i\min(1,C_i/z))、初始全分数集合 (G=\{\max_i C_i<z_0\})，并将其全部存活归一化后验向 (z\uparrow1) 的完整接收付款”这一整条已证命题。R151 有 closely related 的 score-cut 输运恒等式和付款接口，但对象及账本不同；它不能直接登记为上述付款的重复结论，也不能自动补上空间接收价格。

## 最接近的已有结果：R151 score transport

归档成员：`rounds/151/research.zip:score_transport.md`，§1–4（尤其 ST2–ST10）。固定原合法行 ξ=(ω,V,j,x,y)，原 (Z_t,w_t,e_t,Π_t)，以及互斥的 good/bad 组 (E_*,D_0\subset Z_g)。对每个切口 (r=0,\ldots,n-1)，定义

\[
A_r(t)=\int_{E_*}\rho_vw_t(v)1_{k_t(v)>r}\,d\nu(v),\quad
B_r(t)=\int_{D_0}w_t(v)1_{k_t(v)\le r}\,d\nu(v).
\]

ST6 给出 (dA_r=-K^A_r,d\log t+dI^G_r)、(dB_r=-K^B_r,d\log t-dI^D_r)，且 (K^A_r\ge(r+1)A_r)、(K^B_r\le rB_r)。ST9–ST10 由正则化势得到

\[
\int \frac{A_rB_r}{e_t^2}\,d\log t
\le4d_r\{\Phi_r(\tau)-\Phi_r(h)+J_r\}.
\]

这确实包含 score 传输和阈值注入的全时间记账，但每个切口两边都被 score 阈值筛选，且付款是终端势差、good/bad 阈值注入及调和因子 (d_r) 的和；不是“一个全分数 (G) 对整个补集”的通量 ≤1 直接付款。ST6 也明确要求两组存活于 (Z_t)；若含后来被删来源，需另加删除测度。ST4/ST12 的最终费用仍落在原共同 μ=Q*ν/q 的边界/阈值逆矩上，报告明确说未证明一般根阶外价。故：相关工具已有，但所问的特定固定 (G) 结论及其空间结账未在 R151 作为该完整命题证明。

## 近软接收包络 CS10 的准确合同

归档成员：`rounds/148/research.zip:source_cs10.md`，CS5，公式 CS9–CS10；独审在同 ZIP 的 `source_cs10_review.md`。变量写作 softness σ 与物理尺度 (R\in[a,b])，且 (b/a\le2)。令 (d\in(0,1/2))，σ 区间为 **([1-d,1])**，即 (1-\sigma\le d)。原文的接收包络是

\[
\int \sup_{1-d\le\sigma\le1,\ a\le R\le b}P_{\sigma,R}(x)\,dx
\le 1+10\sqrt n\,d+\log2\,[2nd+\sqrt{28n}
+d\{10\sqrt n\sqrt{28n+n^2d^2}+6n+10nd\sqrt n\}].
\tag{CS10}
\]

因此 (D) 的参数是 (d=1-\sigma\)，不是 (\sqrt{1-\sigma})。取旧远带阈值 (d_n=1000\sqrt{\log(n+2)/n}) 时，CS10 右侧为 (O(\sqrt n\log(n+2)))；这是 R148 已登记的 near-one strip 付款。CS10 是对整个近软参数带及原尺度带的空间上确界核积分合同，不含 (G)、(B_0)、(z)-时间或 (\eta^{-2}) 删除比较；不能单独推出题述组合价格。

## 范围差异与状态

- 题述的归一化固定 (B_0) 通量若 (G) 在全窗内存活、且在 (G) 上 (k_z=n)，其连续归一化微分可化为 (G\times G^c) 的 (n-k_u) 交叉积分，并由单调质量总降幅给出至多 1。这一特定化简没有在上述两归档中以该 (G,B_0,z_0) 及整条接收付款的形式被定位到；本核验不认证它与原变量/所有时间端点的兼容性。
- R151 对固定存活的两组做 score-cut 分层，和该通量机制相近，但保留逐切口注入/势端点，并且未给无条件的“总通量 1”取代其付款账本。
- 将“原删除以 \(\eta^{-2}\) 比较”与时间积分后接 CS10 得到 (O(\eta^{-2}\sqrt n\log n))（或其他目标阶）的组合，在所查的 R148/R151 成员中未找到。它是待主代理核验的候选组合，不是历史已证结论。
- 审计标签：R151 ST4–ST12 与 R148 CS10 各自有归档的审核/范围状态；上述跨命题拼接未审核、未认证。CS10 的 soft-band (d_n<1/2) 及 R148 large-dimension 条件仍须满足；小维数需调用 CS5 的 separate finite-dimensional envelope，不能冒用 CS10。
