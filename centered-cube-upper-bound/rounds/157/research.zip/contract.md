# 第157轮研究合同

目标仍为一般中心立方体极大算子的 n^(1/2+o(1)) 一致弱型上界；本轮只在已有未付域内增加可审核几何预算，不声称补集闭合。

原对象：p=P_{s,L}(x-y)，Q*=(K1+K2+J)/3，K1=P_{s,L}(x-v)，K2=P_{s,L+}(x-v)，J=P_{1,b}(x-v)，L+=min(b,(1+1/n)L)。保留原rho、共同alpha、来源nu及外beta和真实dx。原比例窗R117 JG为a/cj≤t≤bcj，故z=cjt/b∈[a/b,cj²]⊂[a/b,1]；b/a≤2。不得由更弱的t≥a直接推出此公共z下界。

职责与候选：
- Astra：相邻尺度薄壳的完整接收/时间价，及多数坐标在L+外时真实s因子和J共同储备的后续接口。只写exterior_joint.md。
- Sol辅助：固定满score来源群的精确质量下降、移动群的进入账。只写fullscore_flow.md。
- Sol独审：先盲审源时命题及回代，再审最终证明与薄壳命题。只写flow_audit.md。
- Sol数值：精确q门与有理源时身份三阶段验证、旧数据结果复核。只写exact_checks.py/json/md。
- Luna代码：旧点保存数据的满score/时间/soft门相容性，保留真实维数和cj,b。只写fullscore_scope.py/json/md。
- Luna历史：R151相关身份及R148 CS10精确范围；已交付停止。
主代理负责最终LaTeX、复现、归档与逐轮提交；任务未完成不提交。

固定群命题：G={maxCi<z0}不依接收点x和j；mu_z=w_znu/Ez，w_z=prod min(1,Ci/z)。z≥z0有 -d mu_z(G)/dlogz=∫G∫(n-ku)dmu²。原删除比较是eta^-2。近soft包络参数d=1-s，而非sqrt(1-s)。移动满score群须保留进入通量，不能将其归零。

薄壳命题：N_L-N_L+个已激活坐标处于L/2<|x_i-v_i|≤L+/2。辅助尺度网格H/L≤exp(1/n)，扩大壳每坐标概率≤2/n。必须将soft、scale、time、j和eta全部支付，不能只报告固定核概率。q门用精确binom(n,q)(2/n)^q≤n^-4选取。

工具使用：已重新阅读E01和N04技能与课题接口；仅采用保留全部流入/终端费用的记账纪律，本文身份自行证明。不引用未核验的占用测度强对偶或未证熵下降。来源独立性不假设，产品独立仅用于固定接收核坐标。数值是有限证据，不证明一般FULL历史可实现。

一般剩余问题：多数坐标在L+外、远soft、低保留质量、移动满score进入费用及原历史负账均须继续支付。
