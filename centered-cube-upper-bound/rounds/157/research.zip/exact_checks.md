# R157 必要有限精确证书

状态：exact_checks.json status=PASS。只核整数q门、固定群有理源时身份、两份eta的代数比较及旧数据保存统计。0新kernel、0新receiver，不认证一般几何、原树历史、eta保留条件或FULL。先前156矩方案仍暂停。

## q门三阶段

对于n>=8，n^(−4)<1，所以P_nq=min(1,binom(n,q)(2/n)^q)<=n^(−4)等价于整数不等式

    binom(n,q)*2^q*n^4 <= n^q.

递推binom(n,q+1)=binom(n,q)(n−q)/(q+1)，同时递推2^q和n^q，从q=0起逐个精确比较，遇首个通过停止；所有更早q都已实际失败，不靠浮点或未经检验的单调性宣称最小。JSON保存首个通过、前一个失败、后一个（若合法）、更早失败数及搜索布尔轨迹SHA；不输出庞大无谓的完整大整数轨迹。

1. n=8..64共57个最小q；代表值n8→q8、n16→q10、n32→q12、n64→q14。
2. 对以上n全部q=0..n检索原阈值等号，实际等号数0；另有170个合法相邻q比较。比较实现使用<=；已删除无数学证书内容的普通整数同义比较器测试，只保原阈值真实数据。q=n且无q+1时不制造非法邻居。
3. 扩大精确递推：

| n | 最小q |
|---:|---:|
|128|16|
|256|17|
|512|19|
|1024|20|
|10000|24|
|100000|28|
|1000000|31|

n=1..7明确单列SMALL_N_RULE_NOT_APPLIED、q=null，不用此规则。尤其旧I1的真实n4不能套该n>=8 q规则；不能因旧文件grid key为8就把它提升成八维压力证据。

## 固定满score群源时身份

使用有限有理Ci向量和nu：五来源分别含全1/8、交替1/4与1/8、首坐标1/2其余3/8、首坐标3/4其余1/4、全7/8，基本nu比例1:2:3:4:5。G={maxCi<z0}严格固定；w_i(z)=Π min(1,Cij/z)，mu_i=nu_i w_i/E。z>=z0且i∈G时k_i=n。

实际以**商法则**精确计算dw_i/dz=−k_i w_i/z和dmu_i/dz，再独立构造右侧双重和，核

    −z*d mu(G)/dz = Σ_(v∈G) Σ_u (n−k_u)mu_v mu_u.

没有用有限差分或把右侧当作左侧定义。每个threshold左右分别使用k_left=#{Ci<z}、k_right=#{Ci<=z}；mu本身连续，同刻多阈值全部一起处理。G边界maxCi=z0严格排除，不把进入通量归零：本任务只测试固定G，没有用移动G(z)代替它。

三阶段共17模型：初探n∈{1,2,4}×z0∈{1/4,1/2,3/4}共9；阈值n4、z0∈{1/8,1/4,1/2,3/4,1}共5（z0=1/2另令第5来源nu=0并重新总归一化）；扩大n∈{8,16,64}、z0=1/2共3。每模型在z0..1的全部相关阈值及段中点，左右各检查，共250条单侧身份。108条位于某个阈值等号，143条左侧严格正，包含G空/全群、同刻阈值、零来源质量和异质坐标，不是只测恒零身份。

## 两份eta删除比较

这是原Pi_v、Pi_u各自条件化到**相同任意Z**，不是把G条件化，也不改源时身份。令M=mu(Z)>0，Pi_i=1_Z mu_i/M，eta<=M。对非负双源矩阵A，核

    Σ Aij Pi_i Pi_j <= eta^(−2) Σ Aij mu_i mu_j.

在17模型的z=z0上，各取Z={0},{0,1},{0,2,4},全部来源，矩阵取确定非对称非负表Aij=(((i+1)(j+3)) mod11)/7和支撑在Z×Z的1矩阵，eta∈{M,M/2,3M/4}。408个精确矩阵比较全通过。51个支撑矩阵例有M<1：左侧1，而若错误只乘eta^(−1)，右侧M<1；eta^(−2)在eta=M时精确等于1。这说明两份删除不能少计一份。没有额外提出端点抵消解释。

## Luna旧数据结果独立复核

在实现方交付完成后才读取fullscore_scope.py/json。另用本程序独立重建source/segment及计数，不import或调用其程序，核源码/JSON SHA绑定及两份固定输入：151 detail SHA `6c2180637b013ccfb255b25de7af9070c62a8077c8716e91aa0574b5bfa07df9`，136 SHA `1090fb2356abe035a997eb851a2f0252a3abe3edbeaf978e99900a38906392de`。

实际来源case I1的n字段为4；六源position/threshold向量均长4；全部8376行的x/xq均长4、good/rho长度均6。逐行均没有显式n字段（8376条），故维度依据是原case和真实坐标元数据，不是summary或point_records键。键4/8是网格分辨率。原b=1、cj=1、s=1/4均保留；C_i=cj*threshold_i/b，z=cj*t/b。

5342 pair全验证k_v=n=4、saved good/rho>0、u为saved bad且delta正确。来源计数v0:1539、v1:1601、v2:1575、v4:627；segment0:4163、segment1:1179，其余0。basic z0=1/4、1/2均5342条通过，z0=3/4的**中点**计数为0；原fullscore的178个分组字段与实现方完全一致，包括原分辨率、source、segment以及保存I/加权I的精确十进制重聚合。

独立增加完整segment时间分类，避免把中点统计升级成时间积分：G(1/2)对全部条目成立，全部原segment的下端z>=1/2，因此其时间门在整段成立；而z0=3/4有1179条所在segment跨过阈值，另4163条的segment整体在门前。中点计数0**不能**推出这1179条截断后的时间交通为0；本轮没有重新截断或重算saved I。实现方endpoint_time表亦只是把查询z0选为segment中点的兼容性，未认证整条saved I在端点时刻的密度。

最终另核实际薄壳：L=9/10、Lplus=min(b,(1+1/n)L)=1。N_L按活跃坐标中|x_i−v_i|>L/2计outside，N_Lplus同理，S=N_L−N_Lplus；独立核S也恰为L/2<|x_i−v_i|<=Lplus/2的活跃坐标数。实际S=0/1/2/3/4条目数为4885/409/48/0/0。付款候选正门按最终数学合同是**S>=q_n**，本n4的小维特殊q_n=1，所以457条（409+48）符合此几何门，补集S<1为4885条。457条全在segment0、全在分辨率m8，来源索引v0=294、v2=163；不能把m8写成实际n8。所有source/segment/grid及保存I分组均独立匹配，合计208个字段检查PASS。

Luna此前把门反写为S<=1，给出的5294=4885+409属于相反语义，已撤回；不是本轮正确的正门计数。最终源码SHA `68673fb5ccae02d4442d4686839d33d42150e1e710f2c93aab9c3946d09a27a8`、JSON SHA `bc1df81af6e852db07c80b4ccc5a2a7f2332b593a8fae96a9e7c1048e8a76c52`已核绑定。此n4特殊q=1**不是**前述n>=8的n^(−4)最小q证书；P_(4,1)=1，不能冒称<=4^(−4)。457只是几何/score门的saved条目数，不认证其eta、soft、时间/j共同化或FULL付款。

s=1/4，近soft d=1/4要求s>=3/4、d=1/8要求s>=7/8，二者都不满足；它是远soft旧压力，不是新近soft条件已覆盖。加权字段只是保存的p/I/纠正权重重聚合一致，未认证midpoint误差、原真实dx/历史、eta或FULL。因此主结论保留saved条目counts和维数，不把有限求积当证书。

## 实际运行、接口与冻结

只用Python标准库Fraction/math/JSON，无随机seed（seed=null）、无新软件。实际解释器 `/opt/homebrew/opt/python@3.14/bin/python3.14`，PYTHONPATH未设置。两次完整producer调用均实际exit0/PASS，无失败。第一次完成q/flow/eta及原fullscore复核；待Luna最终修正shell正门、补便携路径后，第二次合并复现并新增shell208字段核验，同时删除同义比较器测试。没有为每次中间元数据更新重跑数学。整数文本解析限制关闭以支持保存精确分数，不影响数学值。

    /opt/homebrew/opt/python@3.14/bin/python3.14 exact_checks.py

默认保存同目录exact_checks.json；可显式传--output、--detail、--template、--scope-json、--scope-source，输入内容SHA仍严格核验。JSON约207KB；大n只给必要整数最小性证书，没有逐维空间网格。

冻结SHA256：

- exact_checks.py：`093476d6b47235ff6377ed56d58e06543dd3edd081f7493c63af86c05ed8e934`
- exact_checks.json：`14d50580c48113307e3ef50094c36257edcdc43b24fddf0973f76da6cbf2d60e`

这些有限身份与不等式不证明一般原history可实现，不替代薄壳soft/scale/time/j/eta付款独审；近soft外及移动群进入费用等一般余部仍由主证明处理。完成后停止。
