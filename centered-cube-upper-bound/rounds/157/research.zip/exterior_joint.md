# R157：相邻尺度薄壳的真实接收预算与两尺度盒外共同储备

本文只在原未付正域内增加一个一般来源测度下的条件付款。薄壳分支得到完整的 soft、尺度、时间、唯一 j 和真实 dx 费用；多数坐标在两个尺度盒外的部分仍未闭合。只写本文件，不改原核、来源、共同 α 或历史负账。

## EJ1. 精确对象及先行命题

沿用原 p=P_{s,L}(x-y)、K₁=P_{s,L}(x-v)、K₂=P_{s,L⁺}(x-v)、J=P_{1,b}(x-v)、Q*=(K₁+K₂+J)/3，其中 L⁺=min(b,(1+1/n)L)。所有尺度在共同 [a,b]，b/a≤2；真实一维密度 p_s=(1-s)h₁+sφ，φ=h₁*w，p_s≤1，且偶、径向不增。来源 ν 不作独立性假设，外测度仍是原 β。

本轮待证并将在 EJ2–EJ6 证明的命题是：在原合法交通中，若至少 q 个已激活 score 坐标仅在 L 盒外而在 L⁺ 盒内，且实际删除保留率 η≥η₀>0，则完整交通由 EJ5 的真实接收价支付。精确选择 q=q_n 后，其价为维数根阶。它不要求来源处于 L 盒内，也不要求多数坐标被捕获。

原完整时间窗必须保留。已核原 `rounds/117/research.zip:proof.md` JG2（原第47行）：
\[
 \tau_j=a/c_j\le t\le bc_j,\qquad 0<c_j\le1.
\tag{EJ1}
\]
因此 z=c_jt/b 满足 a/b≤z≤c_j²≤1，dt/t=dz/z。仅由 t≥a 不能得到这个共同下端。下文的 log2 正来自 EJ1。

固定原 (ω,V,y) 的未删底集 B₀=D_V(y)∩T₀(y)。记
\[
 C_i(v)=C(|y_i-v_i|/b),\quad
 w_z(v)=\prod_i\min(1,C_i(v)/z),\quad
 k_z(v)=\#\{i:C_i(v)<z\},\quad
 E_z=\int_{B_0}w_zd\nu,\quad d\mu_z=1_{B_0}w_zd\nu/E_z.
\tag{EJ2}
\]
ν(B₀)=0 的行无交通；否则原有限来源及 C_i>0 保证 0<E_z<∞。实际 Z_{j,t} 仍依 j,t，
\[
 d\Pi_{j,t}=\eta_j(z)^{-1}1_{Z_{j,t}}d\mu_z,
 \qquad \eta_j(z)=\mu_z(Z_{j,bz/c_j}).
\tag{EJ3}
\]
只在原合法窗口且 η_j≥η₀ 的实际子支比较；0<η₀≤1。没有把 Z 换成共同集合。原 hard 资格仅使用一次，其 16/3 与外 2Λ 合为 32Λ/3。

## EJ2. 薄壳及其固定接收概率

令 I_z(v)={i:C_i(v)<z}，并定义
\[
 N_H(x,v,z)=\#\{i\in I_z(v):|x_i-v_i|>H/2\},
 \quad S_L=N_L-N_{L^+}.
\tag{EJ4}
\]
故 S_L 准确统计 L/2<|x_i-v_i|≤L⁺/2 的激活坐标。边界按此约定，不混用严格/非严格门。

取仅用于估计的向上尺度网格，公比 exp(1/n)，并包含最后一点 b。点数不超过 2+n log(b/a)。每个 L 有网格 H≥L，H/L≤exp(1/n)。由 p_s 的径向单调性，
\[
 P_{s,L}(x-y)\le eP_{s,H}(x-y)<3P_{s,H}(x-y).
\tag{EJ5}
\]
原薄壳包含于扩大壳
\[
 He^{-1/n}/2<|x_i-v_i|\le(1+1/n)H/2.
\tag{EJ6}
\]
它的总一维长度为 H(1+1/n-e^{-1/n})≤2H/n。接收密度每坐标≤1/H，故固定 s,H 下该事件概率≤2/n。将激活坐标放宽到所有 n 个坐标，乘积接收核的坐标独立性及并集界给
\[
 P_{n,q}:=\min\{1,\binom nq(2/n)^q\},\qquad
 \int_{A_{H,q}(v)}P_{s,H}(x-y)dx\le P_{n,q}.
\tag{EJ7}
\]
这里 A_{H,q}(v) 是至少 q 个坐标满足 EJ6 的事件。来源 ν 的坐标不需要独立。扩大壳不需随 H 嵌套；EJ6 的逐点包含已经足够。

## EJ3. soft 与尺度选择的全部价

事件 A_{H,q} 不依 s。为清楚列出 selector 费用，重述已审 Fisher 估计的短证明：对于两个概率密度 h₁,φ，
\[
 \int\frac{(\phi-h_1)^2}{p_s}\le\frac1{s(1-s)}.
\]
可由逐点 (φ-h₁)²/p_s≤φ/s+h₁/(1-s) 得到。乘积 score 的均值为零，交叉项积分消失，故
\[
 \int\frac{(\partial_sP_{s,H})^2}{P_{s,H}}dx
 \le\frac n{s(1-s)}.
\]
Cauchy–Schwarz、EJ7 和关于 s 的点态微积分给
\[
 \int_{A_{H,q}}\sup_{0\le s\le1}P_{s,H}dx
 \le P_{n,q}+\pi\sqrt n\sqrt{P_{n,q}}.
\tag{EJ8}
\]
端点 s=0,1 由连续延拓和可积导数控制，未额外假设它们具有有限 Fisher 信息。网格求和与 EJ5 因而给
\[
 \int\sup_{\substack{0\le s\le1\\a\le L\le b}}
 P_{s,L}(x-y)1_{\{S_L\ge q\}}dx
 \le3(2+n\log2)(P_{n,q}+\pi\sqrt n\sqrt{P_{n,q}}).
\tag{EJ9}
\]
这是真正的全参数接收包络，非固定参数概率冒充 selector 后的估计。

## EJ4. 来源、时间与唯一 j 的次序

在原正交通中先用 δ(v,u)=(k_v-k_u)_+≤k_v≤n、原 bad 后验质量≤1 积掉 u；在这一步原其他正门可放松为1，ρ≤1，但不修改原 ρ。只剩 v 的一份后验，故 EJ3 仅花 η₀⁻¹：
\[
 \iint\rho_v\delta(v,u)1_{\{S_L(v)\ge q\}}d\Pi(v)d\Pi(u)
 \le n\eta_0^{-1}\int1_{\{S_L(v)\ge q\}}d\mu_z(v).
\tag{EJ10}
\]
这里 u 的积分若还保留更多 history/good/bad 门，只会更小。

逐原 j 先换元 t=bz/c_j，再放宽合法 z 窗到 [a/b,1]，并继续保留原唯一 1_{j(x)=j}。此时 w_z、μ_z、k_z、薄壳包络才不依 j。对各 x 的唯一 j 求和后应用 EJ9，再用 μ_z 总质量1和 ∫_{a/b}¹dz/z≤log2。不得先把 Π_j 当作共同后验，也不得对每个 j 各领一次接收预算。外 β 与原预先标签聚合保留，质量记作原 W_β；没有令 β=ν。

## EJ5. 完整付款及精确阈值

记 P_shell,q 为在所有旧已付域的补集内，另交 η≥η₀、S_L≥q 的实际正交通，则
\[
 \boxed{2\Lambda P_{\rm shell,q}
 \le32\Lambda\eta_0^{-1}n\log2(2+n\log2)
 (P_{n,q}+\pi\sqrt n\sqrt{P_{n,q}})W_\beta.}
\tag{EJ11}
\]
该价已经包含 soft、尺度、来源、time、唯一 j、dx 与原 hard；没有重复 hard 因子，也没有 η₀⁻²。

当 n≥8，令 q_n 为满足
\[
 \binom n{q_n}(2/n)^{q_n}\le n^{-4}
\tag{EJ12}
\]
的最小整数 1≤q_n≤n。存在性由 q=n 得到：n≥8 时 n−4≥n/2 且 2≤√n，所以 2ⁿ≤n^{n−4}。于是 P≤n⁻⁴、√P≤n⁻²。用 log2<1、π<4，
\[
 n(n+2)n^{-4}\le\sqrt n,\qquad
 4n(n+2)n^{-2}\sqrt n\le5\sqrt n,
\]
从 EJ11 得
\[
 \boxed{2\Lambda P_{\rm shell,q_n}
 \le192\Lambda\eta_0^{-1}\sqrt n\,W_\beta\quad(n\ge8).}
\tag{EJ13}
\]
n<8 时取 q_n=1，EJ11 用 P≤1 直接给 2¹⁴Λη₀⁻¹√n W_β；例如除去 √n 后的系数不超过 32·7·9·5<2¹⁴。这只是有限小维常数。

由 binom(n,q)≤(en/q)^q，对充分大 n 取 q=ceil(8 log n/log log n)≤n，有 log(q/(2e))≥(log log n)/2，故满足 EJ12。因此 q_n=O(log n/log log n)。准确有限维门始终是 EJ12，不用这个渐近表达代替。

## EJ6. 对多数失捕获域的作用与互斥剩余

本付款允许 N_L 很大；它只要求其中至少 q_n 个处于相邻尺度薄壳。未付款的 η≥η₀、S_L<q_n 子支满足
\[
 N_{L^+}=N_L-S_L\ge N_L-q_n+1.
\tag{EJ14}
\]
故当 N_L≈k 且 k≫q_n 时，余下多数失捕获也发生在 L⁺，不是只在两个近邻尺度之间错位。按顺序与旧已付域取补集后，本轮互斥分为低 η、η≥η₀ 且薄壳已付、η≥η₀ 且薄壳未付。EJ13 不给第三部分费用。没有根据有限保存点宣称其 FULL 覆盖率。

## EJ7. 两尺度同时盒外的实际 s 因子

固定原实际 x,j,y,t,v，设
\[
 I=\{i:C_i(v)<z,\ |x_i-v_i|>L^+/2\},\quad r=|I|=N_{L^+}.
\]
对 H₁=L、H₂=L⁺ 和 i∈I，硬因子准确为零，故
\[
 K_h=s^r\widetilde K_{h,I},\quad
 \widetilde K_{h,I}=H_h^{-n}
 \prod_{i\in I}\phi((x_i-v_i)/H_h)
 \prod_{i\notin I}p_s((x_i-v_i)/H_h),\quad h=1,2.
\tag{EJ15}
\]
s=0、r>0 时取此乘积定义，K_h=0，不作除以 s。还有 s^r≤exp(−r(1−s))。I 依实际 x,z,v；不能把上述选择后的 tildeK 作为固定归一概率核。

为不拆坏原三核 good 门，令 χ_h=K_h/(K₁+K₂+J)、χ_J=J/(K₁+K₂+J)。J>0，三个责任精确和为1。若 K 表示原 good 门中的共同常数，即 p w_g≤KQ*，则在原 good 域
\[
 p\rho\chi_h\le\frac K{3w_g}\rho K_h,
 \qquad p\rho\chi_J\le\frac K{3w_g}\rho J.
\tag{EJ16}
\]
所有 good/history 资格仍按原完整 Q* 定义，未按分量重选。

EJ15 是实际的双核抑制，但尚不能独立支付：EJ16 后保留来源比 w_t/(e_t w_g) 及 bad score。FIRST 控制的是原 K_h（由 Q* 帽可得 ∫K_hν≤3q），不是 ∫tildeK_{h,I}ν。再把已使用的原核质量乘 s^r 会重复领取同一抑制；对接收依赖 I 也没有自动归一帽。这是一个准确剩余来源/接收控制，不能用固定参数概率替代。

## EJ8. 同一 α 的 J 聚合扣减与其尚欠外价

保留实际 ρ=[1−(DK₀+αJ)/(TΔ)]_+，Δ=w_τ−w_h。对固定原行定义 E 为上述尚未付、原 good、ρ>0 且 TΔ>0 的来源域。α≥0 沿原值，允许 E 依 α。取非负实际权
\[
 b_v=\frac{w_t(v)}{e_t w_g(v)}
 \int\delta(v,u)\,\mathcal M(x,j,y,t,v,u)\,d\Pi_t(u),
\tag{EJ17}
\]
其中 0≤mathcal M≤1 保留所需原 bad/history 正门；若其还牵涉已放松的外 hard 变量，可先删去该门，以此定义一个合法正上界。E 与 b_v 不要求与 α 独立。下列结论同样适用于任何此类非负权。

记
\[
 Z=\int_Eb_vJ_vd\nu,\quad
 C_0=\int_Eb_v\frac{DK_{0,v}J_v}{T\Delta_v}d\nu,\quad
 W=\int_Eb_vT\Delta_vd\nu,\quad
 M_2=\int_Eb_v\frac{J_v^2}{T\Delta_v}d\nu.
\tag{EJ18}
\]
当 Z,W 有限且 W>0 时，在 E 上 ρ 的正部已打开；α>0 时 αM₂≤Z、C₀≤Z，故所有扣减有意义，Cauchy–Schwarz 给
\[
 \boxed{\int_Eb_v\rho_vJ_vd\nu
 =Z-C_0-\alpha M_2
 \le Z-C_0-\alpha Z^2/W.}
\tag{EJ19}
\]
α=0 时直接取 Z−C₀，不定义可能出现的 0·∞。W=0 时因 TΔ>0，b_vν 在 E 上为零，Z 及交通均为零。若所列矩无有限性，不作 ∞−∞；先在固定原 ν、α、ρ、E、b_v 上截断非负积分应用原积分表达，不能据此声称未验证的全局有限二次扣减。本式只是有限矩分支的一般来源不等式。

EJ19 的 C₀ 保留真实 K₀/J 配对，二次扣减保留同一接收点的共同 α，而非逐来源优化。Z,C₀,W 及其支持均可依 α，所以禁止将右端视为固定系数的 α 优化问题。它不是 AB2 的逆 J 矩估计。

若 dΓ 表示原 ω,V,j 标签及 dβ(y) 的聚合，并保留其中唯一 j(x) 选择、原时间窗和实际参数，则 EJ16、EJ17 后的 J 责任支仍需支付的明确外式为
\[
 2\Lambda P_J\le\frac{32\Lambda}{9}
 \int d\Gamma\int dx\int\frac{dt}{t}
 K\,[Z-C_0-\alpha Z^2/W],
\tag{EJ20}
\]
只在 EJ19 有效分支使用，W=0 取零，α=0 按上段约定。系数 32/9 是一次 hard 后的 32/3 再乘三核责任的 1/3；K 仍是原实际共同参数，未当作免费常数删除。EJ20 的右端非负并支配实际对应支，但本轮没有证明它为根阶。完整一般剩余正是 EJ15 的实际带权双核项和 EJ20 的共同储备接收积分；它们仍须按原 dx、β、时间及唯一 j 联合控制。

## EJ9. 有界交付范围

新付款是 EJ11–EJ13，直接处理相邻尺度薄壳，含所有自适应接收费用。新剩余定位是 EJ14–EJ20，不记作第二份已付预算。本轮另一作者的固定满 score 群通量可支付相应时间因子，但其远 soft 接收包络仍需另证；本文不重复其身份，也不将近 soft 包络当作全 soft 根阶。一般上界、低保留质量、原历史负项及多数坐标远离两个盒的核心部分仍未闭合。
