# R157 finite full-score and z0 scope check

## Model and coordinate definitions

The saved R151 receiver dataset is the I1 model with actual dimension `n=4`; its `point_records` keys `4` and `8` denote grid resolutions, not dimensions. Every `xq` has four coordinates, every I1 source has four thresholds, and R151's archived `receiver_probe.json` declares `n=4`. R136 contains other-dimensional cases, but no corresponding R151 point/pair-term data was used. In particular, no `k=4` source was mislabeled as full-score in an n=8 model.

For each source coordinate, R136 stores `A_i=b*C_i/c_j`. This run uses the actual I1 constants `b=1`, `c_j=1`, so reconstructed `C_i=c_j*A_i/b=A_i`. At each R136 score segment midpoint `t`, it forms `z=c_j*t/b`, computes `k_v=#{i:A_i(v)<t}`, and checks that against the archived segment `k[v]`. The full-score filter is `max_i C_i(v)<z0`, together with the requested time gate `z>=z0`. The strict group inequality and non-strict time inequality are kept distinct.

All 5,342 saved pair terms have `k_v=n=4` at their segment midpoint and their source is marked good with saved `rho>0`. They occur only in segments 0 and 1: 4,163 and 1,179 terms; segment 2 has none. The source maxima `max_i C_i(v)` and pair counts are: G1 0.1583240247 (1,539), G2 0.0499613069 (1,601), G3 0.1583240247 (1,575), G4 0.6280349911 (0), B 0.0051559369 (627), and CORE 0.7892964896 (0).

## Fixed thresholds and endpoint checks

| z0 | Pair terms satisfying `v in G(z0)` and `z>=z0` | Segment split | Saved I sum |
|---:|---:|---|---:|
| 1/4 | 5,342 | seg 0: 4,163; seg 1: 1,179 | 64.86440618396 |
| 1/2 | 5,342 | seg 0: 4,163; seg 1: 1,179 | 64.86440618396 |
| 3/4 | 0 | none | 0 |

The arithmetic midpoints give `z≈0.5640174956`, `0.7086657404`, and `0.8678055208` in segments 0–2. The exact `z=z0` time-endpoint check accepts all 4,163 saved terms in segment 0 at its own midpoint z0 and all 1,179 terms in segment 1; there are no segment-2 pair terms. At the strict group boundary `z0=max_i C_i(v)`, the source is excluded as required. The output records, source by source, the corresponding strict-boundary rejection counts (1,539 G1, 1,601 G2, 1,575 G3, and 627 B; G4 and CORE have no pair terms).

For the full denominator-16 mesh `z0=k/16`, k=0,…,16, nonzero counts are: 1/16 and 1/8 each 2,228; 3/16 through 9/16 each 5,342; 5/8 and 11/16 each 1,179; all other mesh points have zero. The JSON provides exact counts, saved-I sums, p-weighted saved-I sums, and source/segment splits at every mesh value. Those p-weighted quantities use saved midpoint p and `dx_weight_corrected`; they are quadrature diagnostics only.

R136's saved soft parameter is `s=1/4`. The near-soft gates `1-d<=s` fail for both d=1/4 (requires s>=3/4) and d=1/8 (requires s>=7/8).

## Scope limits

This finds finite geometry-compatible saved pair terms for z0=1/4 and 1/2. It does not certify eta, any continuous traffic integral, near-soft coverage, or FULL coverage. Pair-term roles and values are saved float64 diagnostics; no kernel was re-evaluated. The time and group checks use existing R136 thresholds and segment definitions only.

## Reproducibility

- Producer: [fullscore_scope.py](fullscore_scope.py), standard-library Fraction/JSON code.
- Output: [fullscore_scope.json](fullscore_scope.json).
- R151 receiver point input SHA-256: `6c2180637b013ccfb255b25de7af9070c62a8077c8716e91aa0574b5bfa07df9`.
- R136 template input SHA-256: `1090fb2356abe035a997eb851a2f0252a3abe3edbeaf978e99900a38906392de`.
- Producer SHA-256: `68673fb5ccae02d4442d4686839d33d42150e1e710f2c93aab9c3946d09a27a8`.
- JSON SHA-256: `bc1df81af6e852db07c80b4ccc5a2a7f2332b593a8fae96a9e7c1048e8a76c52`.
- The JSON binds the producer SHA and records five successful producer invocations, zero failures, zero new kernel evaluations, and zero new receiver/grid points. The fifth invocation corrected the reversed q-gate interpretation; the earlier 5,294 `S<=1` result was not valid for the requested lower-threshold gate.

## Thin-shell extension on the same saved coordinates

The portable producer also counts the requested old-point thin-shell quantity using only each pair's active score coordinates `C_i(v)<z` and exact saved `xq`/R136 source coordinates. For I1, `n=4`, `b=1`, and `L=9/10`; hence `Lplus=min(b,(1+1/n)L)=1`, so the shell is `9/20 < |x_i-v_i| <= 1/2`. It computes `S=N_L-N_Lplus` with `N_H` the number of active-score coordinates outside `Q_H(x)`; this is exactly the requested count of active coordinates in the thin shell. The supplied small-dimension threshold is `q_n=1`, so the finite test is `S>=1` (at least one active coordinate lies in the shell).

| S | Pair terms | Saved I sum | Source counts (G1,G2,G3,G4,B,CORE) | Segment counts (0,1,2) |
|---:|---:|---:|---|---|
| 0 | 4,885 | 43.8539666737 | 1,245; 1,601; 1,412; 0; 627; 0 | 3,706; 1,179; 0 |
| 1 | 409 | 19.2267052577 | 256; 0; 153; 0; 0; 0 | 409; 0; 0 |
| 2 | 48 | 1.7837342526 | 38; 0; 10; 0; 0; 0 | 48; 0; 0 |
| 3 | 0 | 0 | 0 for every source | 0 for every segment |
| 4 | 0 | 0 | 0 for every source | 0 for every segment |

Thus the corrected `q_n=1` gate includes 457 of 5,342 saved pair terms, with saved I sum about 21.0104395103; all 457 are from G1/G3 (294/163), segment 0, and grid resolution m=8. The earlier 5,294 figure incorrectly counted `S<=1`; it is withdrawn. This is a finite coordinate count over saved pair rows; it does not certify the eta condition or any spatial payment. The JSON also splits counts by m=4/m=8 grid resolution.

The producer is portable: `python3 fullscore_scope.py --detail <R151-json> --template <R136-json> --output <result-json>`; all three options are `Path` arguments with the original paths as defaults. It writes no machine paths into the result, only input hashes.
