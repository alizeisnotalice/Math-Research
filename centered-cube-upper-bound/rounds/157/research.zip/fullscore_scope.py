#!/usr/bin/env python3
"""Finite full-score / z0 compatibility check on saved R151 I1 pair terms."""
from collections import Counter, defaultdict
from fractions import Fraction as F
from pathlib import Path
import argparse, hashlib, json

HERE=Path(__file__).resolve().parent
R151=Path('/Users/zhengzhihao/Desktop/T/output/centered_cube_round151_20261015/receiver_probe_points.json')
R136=Path('/Users/zhengzhihao/Desktop/T/output/centered_cube_round136_20261014/active_traffic_v2.json')
OUT=HERE/'fullscore_scope.json'

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def f(x): return x if isinstance(x,F) else F(str(x))
def fs(x): return f'{x.numerator}/{x.denominator}'
def add(dst,term,row):
    dst['terms']+=1;dst['I']+=f(term['I'])
    dst['p_weighted_I']+=f(row['p'])*f(row['dx_weight_corrected'])*f(term['I'])

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--detail',type=Path,default=R151,help='R151 receiver_probe_points.json')
    parser.add_argument('--template',type=Path,default=R136,help='R136 active_traffic_v2.json')
    parser.add_argument('--output',type=Path,default=OUT,help='destination JSON path')
    args=parser.parse_args()
    point_data=json.loads(args.detail.read_text())
    full136=json.loads(args.template.read_text())
    case=next(c for c in full136['cases'] if c['id']=='I1')
    n=int(case['n']); b=f(case['parameters']['b']); s=f(case['parameters']['s']); cj=f(case['derived']['cj'])
    L=f(case['parameters']['L']); Lplus=min(b,(1+F(1,n))*L); q_n=1 if n==4 else None
    atoms=case['atoms']; A=[[f(x) for x in a['thresholds']] for a in atoms]
    C=[[cj*x/b for x in row] for row in A]
    positions=[[f(x) for x in a['position']] for a in atoms]
    segs=case['score_segments']
    seg_info=[]
    for si,seg in enumerate(segs):
        lo,hi=f(seg['lo']),f(seg['hi']);t=(lo+hi)/2;z=cj*t/b
        k=[sum(x<t for x in row) for row in A]
        assert k==[int(x) for x in seg['k']],(si,k,seg['k'])
        seg_info.append({'segment':si,'lo':fs(lo),'hi':fs(hi),'t_mid':fs(t),'z_mid':fs(z),'k_by_source':k})
    # Stage 1: fixed requested thresholds. Stage 3: the full denominator-16 mesh,
    # including endpoints 0 and 1 so strict/open-boundary behavior is visible.
    basic=[F(1,4),F(1,2),F(3,4)]
    dyadic=[F(k,16) for k in range(17)]
    pair_count_by_source=Counter(); pair_count_by_segment=Counter()
    basic_stats={fs(z0):{'terms':0,'I':F(0),'p_weighted_I':F(0),'by_grid':defaultdict(lambda:{'terms':0,'I':F(0),'p_weighted_I':F(0)}),'by_source':Counter(),'by_segment':Counter()} for z0 in basic}
    dyadic_stats={fs(z0):{'terms':0,'I':F(0),'p_weighted_I':F(0),'by_grid':defaultdict(lambda:{'terms':0,'I':F(0),'p_weighted_I':F(0)}),'by_source':Counter(),'by_segment':Counter()} for z0 in dyadic}
    endpoint_time={str(i):{'z0':seg_info[i]['z_mid'],'terms':0,'I':F(0),'by_source':Counter()} for i in range(len(segs))}
    endpoint_G={}
    for v in range(len(atoms)):
        z0=max(C[v]);endpoint_G[str(v)]={'z0':fs(z0),'terms_at_source':0,'strict_G_rejected_terms':0}
    total_pair=0; total_fullscore=0; rho_good_pair_invariant=0
    shell_by_S={r:{'terms':0,'I':F(0),'by_source':Counter(),'by_segment':Counter(),'by_grid':Counter()} for r in range(n+1)}
    qn_pass={'terms':0,'I':F(0),'by_source':Counter(),'by_segment':Counter(),'by_grid':Counter()}
    for grid,rows in point_data['point_records'].items():
        for row in rows:
            for term in row['pair_terms']:
                total_pair+=1
                v=int(term['v']);si=int(term['segment']);seg=segs[si]
                t=(f(seg['lo'])+f(seg['hi']))/2;z=cj*t/b
                k_v=sum(x<t for x in A[v])
                assert k_v==int(seg['k'][v])==n,('not full-score pair term',grid,row['index'],si,v,k_v,n)
                total_fullscore+=1
                assert row['good'][v] and float(row['rho'][v])>0
                rho_good_pair_invariant+=1
                z0max=max(C[v])
                pair_count_by_source[v]+=1;pair_count_by_segment[si]+=1
                x=[f(q) for q in row['xq']]
                score_active=[C[v][j]<z for j in range(n)]
                assert score_active==[A[v][j]<t for j in range(n)]
                outside_L=sum(score_active[j] and abs(x[j]-positions[v][j])>L/2 for j in range(n))
                outside_Lplus=sum(score_active[j] and abs(x[j]-positions[v][j])>Lplus/2 for j in range(n))
                shell=sum(score_active[j] and L/2<abs(x[j]-positions[v][j])<=Lplus/2 for j in range(n))
                assert shell==outside_L-outside_Lplus
                sval=f(term['I']); sb=shell_by_S[shell]
                sb['terms']+=1;sb['I']+=sval;sb['by_source'][v]+=1;sb['by_segment'][si]+=1;sb['by_grid'][grid]+=1
                if shell>=q_n:
                    qn_pass['terms']+=1;qn_pass['I']+=sval;qn_pass['by_source'][v]+=1;qn_pass['by_segment'][si]+=1;qn_pass['by_grid'][grid]+=1
                for z0,stats in [(q,basic_stats[fs(q)]) for q in basic]+[(q,dyadic_stats[fs(q)]) for q in dyadic]:
                    in_G=z0max<z0
                    time_ok=z>=z0
                    if in_G and time_ok:
                        val=f(term['I']);weighted=f(row['p'])*f(row['dx_weight_corrected'])*val
                        stats['terms']+=1;stats['I']+=val;stats['p_weighted_I']+=weighted
                        g=stats['by_grid'][grid];g['terms']+=1;g['I']+=val;g['p_weighted_I']+=weighted
                        stats['by_source'][v]+=1;stats['by_segment'][si]+=1
                if z==f(seg_info[si]['z_mid']):
                    ep=endpoint_time[str(si)]
                    assert z>=z and z0max<z
                    ep['terms']+=1;ep['I']+=f(term['I']);ep['by_source'][v]+=1
                endpoint_G[str(v)]['terms_at_source']+=1
                # At z0=max_i C_i(v), strict G is false for this source.
                assert not (z0max<z0max)
                if z>=z0max:
                    endpoint_G[str(v)]['strict_G_rejected_terms']+=1

    def pack(stats):
        return {key:{'terms':v['terms'],'I_sum':fs(v['I']),'p_weighted_I_sum':fs(v['p_weighted_I']),
                     'by_grid':{m:{'terms':g['terms'],'I_sum':fs(g['I']),'p_weighted_I_sum':fs(g['p_weighted_I'])} for m,g in v['by_grid'].items()},
                     'by_source':{str(i):n for i,n in sorted(v['by_source'].items())},
                     'by_segment':{str(i):n for i,n in sorted(v['by_segment'].items())}}
                for key,v in stats.items()}
    endpoint_time_packed={k:{'z0':v['z0'],'terms_at_z_equal_z0':v['terms'],'I_sum':fs(v['I']),'by_source':{str(i):n for i,n in sorted(v['by_source'].items())}} for k,v in endpoint_time.items()}
    shell_packed={str(r):{'terms':v['terms'],'I_sum':fs(v['I']),'by_source':{str(i):c for i,c in sorted(v['by_source'].items())},'by_segment':{str(i):c for i,c in sorted(v['by_segment'].items())},'by_grid':{str(i):c for i,c in sorted(v['by_grid'].items())}} for r,v in shell_by_S.items()}
    qn_packed={'q_n':q_n,'condition':'S >= q_n','terms':qn_pass['terms'],'I_sum':fs(qn_pass['I']),'by_source':{str(i):c for i,c in sorted(qn_pass['by_source'].items())},'by_segment':{str(i):c for i,c in sorted(qn_pass['by_segment'].items())},'by_grid':{str(i):c for i,c in sorted(qn_pass['by_grid'].items())}}
    out={'status':'completed_finite_saved_fullscore_scope','scope':'R151 saved I1 pair terms only; no kernel evaluations or receiver points','producer_sha256':sha(Path(__file__)),'inputs':{'R151_receiver_probe_points_sha256':sha(args.detail),'R136_active_traffic_sha256':sha(args.template)},'model':{'case':'I1','n':n,'threshold_vector_lengths':[len(q) for q in A],'point_record_keys_are_grid_resolution_not_dimension':True,'b':fs(b),'cj':fs(cj),'s':fs(s),'L':fs(L),'Lplus':fs(Lplus),'q_n':q_n,'near_soft_gates':{'d=1/4_requires_s_at_least_3/4':s>=F(3,4),'d=1/8_requires_s_at_least_7/8':s>=F(7,8)}},'score_segments':seg_info,'coordinate_definition':{'stored_A_i':'b*C_i/cj','reconstructed_C_i':'cj*A_i/b','z':'cj*t/b','full_score_group':'max_i C_i(v) < z0','time_gate':'z >= z0','kv':'count_i(A_i(v) < t); verified equal to saved segment k[v]','shell_S':'count only coordinates with C_i(v)<z and L/2 < abs(x_i-v_i) <= Lplus/2; equivalently active outside-Q_L count minus active outside-Q_Lplus count'},'totals':{'pair_terms':total_pair,'pair_terms_verified_full_score_kv_eq_n':total_fullscore,'pair_terms_verified_good_and_saved_rho_positive':rho_good_pair_invariant,'pair_terms_by_source':{str(i):pair_count_by_source[i] for i in range(len(atoms))},'pair_terms_by_segment':{str(i):pair_count_by_segment[i] for i in range(len(segs))}},'basic_z0':pack(basic_stats),'dyadic_denominator_16_all_endpoints':pack(dyadic_stats),'endpoint_tests':{'time_gate_equality_z_eq_z0':endpoint_time_packed,'strict_G_boundary_z0_eq_max_C_source':endpoint_G},'thin_shell_by_S':shell_packed,'thin_shell_q_n_pass':qn_packed,'execution':{'producer_invocations_total':5,'failed_invocations':0,'final_completed_invocation':5,'new_kernel_evaluations':0,'new_receiver_points':0,'new_grid_points':0},'limitations':['only R151 I1 has saved point/pair data; its actual model dimension is n=4, and point_records keys 4/8 are mesh resolutions, not n=4/n=8 cases','R136 also contains other dimensions, but no corresponding R151 saved pair terms were used or imputed','all pair-term roles and I values are saved float64 diagnostics; this is finite geometry compatibility, not a certificate of traffic integrals','no eta condition, near-soft universal bound, or FULL coverage is certified']}
    args.output.write_text(json.dumps(out,separators=(',',':'))+'\n')
    print('n',n,'pair terms',total_pair,'basic passing',[(k,v['terms']) for k,v in out['basic_z0'].items()],'shell q_n',qn_packed['terms'],'json sha',sha(args.output),'bytes',args.output.stat().st_size)

if __name__=='__main__': main()
