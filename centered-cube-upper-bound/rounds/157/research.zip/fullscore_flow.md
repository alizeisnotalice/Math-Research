# R157 满 score 群通量：固定群、连续进入与准确费用

状态：作者候选，供独立核验；不登记新的完整交通付款。以下只用固定共同底集上的真实来源权重和基础绝对连续/Tonelli。结论覆盖任意有限正来源测度，不要求离散来源、有限阈值层或固定接收尺度。满 score 流量本身可无层数因子地累计；来源陆续进入的归一质量是必须保留的一笔费用，不能免费设为常数。

## FF1. 先审命题：固定群身份需要 z≥z₀

设 (B₀,ν) 为有限非零正测度空间，n≥1，C_i:B₀→(0,1] 可测。对 z>0 定义

\[
w_z(v)=\prod_{i=1}^n\min\{1,C_i(v)/z\},\quad
E_z=\int_{B_0}w_z\,d\nu>0,\quad d\mu_z=E_z^{-1}w_zd\nu,
\]
\[
k_z(v)=\#\{i:C_i(v)<z\},\quad \bar k_z=\int k_zd\mu_z,\quad
M(v)=\max_i C_i(v),\quad P(v)=\prod_iC_i(v).
\tag{FF1}
\]

固定 z₀>0，令 G={M<z₀}。**只有在 z≥z₀ 的范围，G 上恒有 k_z=n**，因而目标身份正确：

\[
\boxed{
-\frac{d}{d\log z}\mu_z(G)
=\int_G\int_{G^c}(n-k_z(u))d\mu_z(u)d\mu_z(v)
=\mu_z(G)(n-\bar k_z)\ge0
}\tag{FF2}
\]

等式在 z≥z₀ 几乎处处成立。若 z<z₀，只能用一般协方差身份，不能把 G 上 score 换成 n。z₀>1 时 G=B₀，z≥z₀ 时两边均为零。

证明及阈值：以 s=log z 为变元。每个固定 v 的 w_{e^s}(v) 局部绝对连续，且在至多 n 个坐标阈值外

\[
\partial_sw_{e^s}(v)=-k_{e^s}(v)w_{e^s}(v),\quad
|\partial_sw_{e^s}(v)|\le n.
\]

有限 ν 及 Tonelli 给 E_s 和任意固定可测 A 的 N_A(s)=∫_A w_sdν 局部绝对连续；紧 s 区间上 E 有正下界。因此

\[
\frac{d}{ds}\mu_s(A)=\mu_s(A)\bar k_s-\int_Ak_s\,d\mu_s.
\tag{FF3}
\]

FF2 由 G 上 k=n 得到。此论证不要求 ν 可数或 M 的分布有密度。各点有限阈值的并集可以不可数；Tonelli 仍保证“对几乎所有 s，对 ν 几乎所有 v 导数成立”。即使 ν 在某阈值上有正质量，w 和固定群后验质量仍连续，没有阈值原子；导数仅在该时刻可跳。

所以对任意 z₀≤a<b<∞，

\[
\boxed{\int_a^b\int_G\int_{G^c}(n-k_z(u))d\mu_z^2\frac{dz}{z}
=\mu_a(G)-\mu_b(G)\le\mu_a(G)\le1.}
\tag{FF4}
\]

端点包含与否不影响 dz/z 积分；右端是连续的固定群后验值。此式没有时间 log(b/a) 或阈值层数因子。

## FF2. 移动满 score 群的准确 BV 账

为获得右连续版本，定义 F_z={M≤z}，h(z)=μ_z(F_z)。严格满 score 群是 {M<z}；两者仅在 ν(M=z)>0 的阈值处不同，这类 z 至多可数，所以不改变任何 dz/z 流量积分。保留端点账时必须指定使用哪个版本；本节一律用闭群 F_z。

令

\[
A(z)=\int_{\{M\le z\}}P(v)d\nu(v),\quad
H(z)=z^nE_z=\int_{B_0}\prod_i\min\{z,C_i(v)\}\,d\nu(v).
\tag{FF5}
\]

H 连续、正、局部绝对连续且单调不减；A 是右连续非减 BV 函数。因为 F_z 上 w_z=P/z^n，

\[
h(z)=A(z)/H(z),\qquad
\frac{d\log H}{d\log z}=n-\bar k_z\quad\text{a.e.}
\tag{FF6}
\]

定义进入测度（相对于 z 或 log z 的 Borel 测度均可，推前关系相同）

\[
\boxed{
\mathcal I(J)=\int_{\{v:M(v)\in J\}}
\frac{w_{M(v)}(v)}{E_{M(v)}}d\nu(v)
=\int_J\frac1{H(r)}dA(r).
}\tag{FF7}
\]

这里 `w_M=P/M^n`，并未在进入时重算底集或改变 ν。对于 0<a<b<∞，I((a,b]) 有限，例如 ≤ν(B₀)/E_b。它包含离散阈值原子、连续进入和奇异连续进入，三类均由同一个正测度处理。

BV 乘积法则（H 连续、AC）给精确身份

\[
\boxed{dh=d\mathcal I-\mathcal D(z)\frac{dz}{z},\qquad
\mathcal D(z)=h(z)(n-\bar k_z)
=\int_{F_z}\int_{F_z^c}(n-k_z(u))d\mu_z^2\ge0\quad\text{a.e.}}
\tag{FF8}
\]

在阈值原子 r，`Δh(r)=I({r})=∫_{M=r}w_r/E_r dν`；H 无跳跃，故分母没有前/后态歧义。h 在非原子部分可增可减，不可将它整体当作单调函数。

积分得到

\[
\boxed{\int_a^b\mathcal D(z)\frac{dz}{z}
=h(a)-h(b)+\mathcal I((a,b])
\le h(a)+\mathcal I((a,b]).}
\tag{FF9}
\]

初值 h(a) 已包括 M=a 的来源，进入量只计 a<M≤b。若改用严格初始群 {M<a}，必须另加 μ_a(M=a)；若终点取 b−，进入测度及终态也同步改为 (a,b) 与 h(b−)。终点 M=b 的进入原子与 h(b) 同时出现而准确抵消，不制造正通量。

## FF3. 分层不会另收层数；进入质量如何上界

任取有限分层 a=r₀<r₁<⋯<r_N=b，令 B_l={r_{l−1}<M≤r_l}，从 r_l 起才累计该群的满 score 通量。每个固定群使用 FF4：

\[
\sum_l\int_{r_l}^{b}\int_{B_l}\int_{B_l^c}(n-k_z(u))d\mu_z^2\frac{dz}{z}
\le\sum_l\mu_{r_l}(B_l)
\le\mathcal I((a,b]).
\tag{FF10}
\]

最后一步来自对 M(v)≤r_l，`w_{r_l}(v)/E_{r_l}=P(v)/H(r_l)≤P(v)/H(M(v))`。所以层数只影响分组方式，不是额外常数。极细层乃至连续分层由 FF7–FF9 直接处理，不能另给每层一份单位概率预算。

可直接核验的进入上界有三种，均保留原来源尺度信息：

\[
\boxed{
\mathcal I((a,b])\le\min\left\{
\frac{\nu(a<M\le b)}{E_b},\quad
\frac{A(b)-A(a)}{H(a)},\quad
1-h(a)+\log\frac{H(b)}{H(a)}
\right\}.
}\tag{FF11}
\]

前两项分别用 w_M≤1、E_M≥E_b，以及 H(M)≥H(a)。第三项由 FF8、h≤1 和

\[
\int_a^b\mathcal D\frac{dz}{z}
\le\int_a^b(n-\bar k_z)\frac{dz}{z}
=\log\frac{H(b)}{H(a)}\le n\log(b/a)
\tag{FF12}
\]

得到。因此 FF9 的流量上界也可直接取

\[
\int_a^b\mathcal D\frac{dz}{z}
\le\min\{h(a)+\mathcal I((a,b]),\log(H(b)/H(a))\}.
\tag{FF13}
\]

另有 `D≤n h(1−h)≤n/4`，故可以再与 `(n/4)log(b/a)` 比较；这是一个真实但可能很粗的时间跨度价，不是“无层数”等于“无费用”。

FF11 没有给无条件的维数无关常数；其中来源质量比和 H 的端点比都是真实待核的量。对于原合法窗，不需要研究 a↓0 来处理固定初始群：下一节给出严格正的共同下端点。

若 a↓0，FF7–FF9 只能先在正下端点成立再取极限；I((0,b]) 允许为 +∞。不得用 μ 的概率归一化跳过该极限。若 z≥1，所有 Ci≤1，除 z=1 的单点阈值外 k=n，H 恒定，没有新进入也没有正通量。

## FF4. 带非恒定外乘子的合法形式

若实际接收分析给非负有界、连续 BV 标量 B(z)，FF8 的分部积分为

\[
\int_{(a,b]}B(z)\mathcal D(z)\frac{dz}{z}
=B(a)h(a)-B(b)h(b)
+\int_{(a,b]}B(z)d\mathcal I(z)
+\int_{(a,b]}h(z-)dB(z),
\tag{FF14}
\]

本式使用 B 连续以避免共同跳项；不擅自推广到任意同时跳跃的乘子。若 B 非增，最后一项非正，因此

\[
\int B\mathcal D\,dz/z\le B(a)h(a)+\int B\,d\mathcal I.
\tag{FF15}
\]

任意可测 B 仍可用 `ess sup B·(h(a)+I)`，但必须实际支付该上确界。FF15 说明“初始质量+进入质量”对非恒定接收乘子应按进入时的真实 B 计价，不能只使用无权 I 后丢掉乘子。

## FF5. 原 Z_{j,t}、η² 与一般尺度接收：付款边界

实读 `rounds/117/research.zip` 内 `proof.md` 第47–52行 JG2，原合法窗是

\[
 a_{\rm scale}/c_j\le t\le Bc_j.
\]

因 z=c_jt/B，全部 j 的合法时间都满足

\[
 \boxed{z_*:=a_{\rm scale}/B\le z\le c_j^2\le1.}
\tag{FF16a}
\]

因此可以统一固定 `G_*={M<z_*}`，无须逐 j 重选群，也没有该固定群的新进入账。在 [z_*,1] 上 FF4 直接给累计通量≤μ_{z_*}(G_*)≤1。原比例带 B/a_scale≤2 时 z_*≥1/2。这个固定群没有覆盖随后 z∈(z_*,1] 才达到满 score 的来源；后者仍由 FF7–FF9 的进入账处理。禁止把“后来进入群”并入固定群却继续沿用无进入的单位帽。

R156 原定义给共同底集 B₀=D_V(y)∩T₀(y)，μ_z=widehatΠ_z；原删块 Z_{j,t} 仍依 j。合法时间上

\[
d\Pi_{j,t}=\eta_j(z)^{-1}1_{Z_{j,t}}d\mu_z.
\tag{FF16}
\]

对于满 score good 来源 v 和任意 bad 来源 u，原正差是 `(k(v)−k(u))_+=n−k(u)`。保持两份后验的真实比较，任意额外正门≤1 后有

\[
\boxed{\iint1_{\{M(v)<z\}}(k_z(v)-k_z(u))_+\,d\Pi_{j,t}^2
\le\eta_j(z)^{-2}\mathcal D(z).}
\tag{FF17}
\]

原 source block 可在不等式后删除；不可把 Z_j 免费视为共同底集，也不可将 η^{-2}误写为 η^{-1}。若只知 η≥η₀>0，则付 η₀^{-2}；否则保留原 η_j(z)^{-2} 及其原 j 依赖，FF9 的无权帽不能直接吸收它。

在已经限定 η≥η₀、且实际 soft/尺度范围有共同真实接收包络常数

\[
\mathcal E_n=\int\sup_{\text{合法 }s,L}P_{s,L}(x-y)dx,
\]

可以依次做 FF17、保留唯一 j、共同 z 变元、放松原窗口、FF9，得到满 score 子交通的条件上界

\[
\boxed{
2\Lambda P_{\rm fullscore,\eta_0}
\le\frac{32\Lambda}{3}\eta_0^{-2}\mathcal E_n\,
\mathbb E\sum_V\int
\{h_{V,y}(a)+\mathcal I_{V,y}((a,b_z])\}\,d\beta_V(y).
}\tag{FF18}
\]

此处 z 域 [a,b_z] 必须确实包含原合法时间域；a 是 z 下端点，与原接收尺度带的 a_scale 不混同。若原域下端可趋零，应使用上一节的单调极限及可能无限的进入量。FF18 使用合同合法的外 hard16/3 一次；原系数32Λ/3不变，β仍是β。其成立不要求固定接收尺度，也不要求任何坐标被 receiver 捕获；原 good/bad、ρ 和 history 只在非负上界中放松，没有反向制造资格。

对上述 **固定初始群 G_***，FF18 中的 `h(a)+I` 可直接替换为 `μ_{z_*}(G_*)≤1`，得到

\[
2\Lambda P_{G_*,\eta_0}
\le\frac{32\Lambda}{3}\eta_0^{-2}\mathcal E_n W_\beta.
\tag{FF19}
\]

这是满 score 初始群的条件接收上界；不附加后来进入群。对后来进入群使用 FF18 时，可统一取 a=z_*、b_z=1，并按 FF11 核验新进入费。

可以取合同 JT13 的 `E_n≤3(2n+3)D_n`，或在已合法限定的 near-soft 带取 CS10 的相应完整选择价。选择价必须写出来：JT13 本身为 O(n^{3/2})，不能因为来源流量无层数因子就改称根阶；若采用 CS10，还需保留其 softness 带及其他原残余边界。FF18 不自动支付全部盒外交通，仅支付其中 **满 score** good 来源部分；低于满 score 的来源没有 FF2 的极值 score 符号。

本流量路线的唯一新增未付来源费用是 **归一进入质量** FF7（若 η无正下帽，则是连同原 η^{-2} 的加权进入/流量费用）。它没有被“每层初始概率≤1”解决。接收选择价、原 hard 合法性和 η²在 FF18 已显式列为条件/乘子；它们并未由本引理消失。要得到一般根阶或 n^{1/2+o(1)} 预算，仍须用原来源几何证明 FF18 中进入费及适用接收选择价的共同预算，不能把右端改名为已付能量。

完成本有界推导后停止；只写本文件，不改其他作者或 Git。
