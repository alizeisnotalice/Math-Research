#!/usr/bin/env python3
"""R157 finite exact q/flow/two-eta checks and independent saved-scope audit."""
from fractions import Fraction as F
from pathlib import Path
from collections import Counter
import argparse,hashlib,json,math,sys
sys.set_int_max_str_digits(0)
ROOT=Path(__file__).resolve().parent

def sha(b):return hashlib.sha256(b).hexdigest()
def enc(x):
    if isinstance(x,F):return f'{x.numerator}/{x.denominator}'
    if isinstance(x,dict):return {str(k):enc(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)):return [enc(v) for v in x]
    return x

def q_min(n):
    assert n>=8;comb=p2=npow=1;trace=[]
    for q in range(n+1):
        lhs=comb*p2*n**4;rhs=npow;trace.append((q,lhs<=rhs))
        if lhs<=rhs:
            assert all(not x[1] for x in trace[:-1])
            def at(r):return dict(q=r,lhs=math.comb(n,r)*2**r*n**4,rhs=n**r,passes=math.comb(n,r)*2**r*n**4<=n**r)
            return dict(n=n,q=q,certificate=at(q),previous=at(q-1) if q else None,next=at(q+1) if q<n else None,earlier_failures=q,trace_sha256=sha(json.dumps(trace).encode()))
        comb=comb*(n-q)//(q+1);p2*=2;npow*=n
    raise AssertionError('q existence failed')

def flow_model(n,z0,zero_mass=False):
    C=[[F(1,8)]*n,[F(1,8) if j%2 else F(1,4) for j in range(n)],[F(1,2) if j==0 else F(3,8) for j in range(n)],[F(3,4) if j==0 else F(1,4) for j in range(n)],[F(7,8)]*n]
    mass=[F(1),F(2),F(3),F(4),F(0) if zero_mass else F(5)];total=sum(mass);nu=[v/total for v in mass]
    G=[max(cs)<z0 for cs in C];cuts=sorted({z0,F(1)}|{x for cs in C for x in cs if z0<=x<=1});pts=sorted(set(cuts)|{(a+b)/2 for a,b in zip(cuts,cuts[1:])});rows=[]
    for z in pts:
        w=[math.prod((min(F(1),c/z) for c in cs),start=F(1)) for cs in C];e=sum(a*b for a,b in zip(nu,w));mu=[a*b/e for a,b in zip(nu,w)];assert sum(mu)==1
        for side in ['left','right']:
            k=[sum(c<z if side=='left' else c<=z for c in cs) for cs in C]
            assert all(not G[i] or k[i]==n for i in range(5))
            # Independent quotient-rule derivative of nu*w/e, not finite difference.
            dw=[-k[i]*w[i]/z for i in range(5)];de=sum(nu[i]*dw[i] for i in range(5));dmu=[nu[i]*dw[i]/e-nu[i]*w[i]*de/(e*e) for i in range(5)]
            lhs=-z*sum(dmu[i] for i in range(5) if G[i]);rhs=sum(mu[i]*mu[j]*(n-k[j]) for i in range(5) if G[i] for j in range(5));assert lhs==rhs and lhs>=0
            rows.append(dict(z=z,side=side,k=k,mu=mu,G_mass=sum(mu[i] for i in range(5) if G[i]),minus_dG_dlogz=lhs,double_integral=rhs,threshold_equalities=sum(c==z for cs in C for c in cs)))
    return dict(n=n,z0=z0,C=C,nu=nu,G=G,rows=rows,zero_mass=zero_mass)

def eta_checks(models):
    count=0;bad_single=0;example=None
    for model in models:
        mu=next(r['mu'] for r in model['rows'] if r['z']==model['z0'])
        for Z in [[0],[0,1],[0,2,4],list(range(5))]:
            mass=sum(mu[i] for i in Z);assert mass>0;pi=[mu[i]/mass if i in Z else F(0) for i in range(5)]
            for kind in ['general','supported']:
                A=[[F(((i+1)*(j+3))%11,7) if kind=='general' else F(i in Z and j in Z) for j in range(5)] for i in range(5)]
                left=sum(A[i][j]*pi[i]*pi[j] for i in range(5) for j in range(5));unconditional=sum(A[i][j]*mu[i]*mu[j] for i in range(5) for j in range(5))
                for eta in [mass,mass/2,3*mass/4]:assert left<=unconditional/(eta*eta);count+=1
                if kind=='supported' and mass<1:
                    assert left==1 and unconditional==mass*mass and left>unconditional/mass;bad_single+=1
                    if example is None:example=dict(n=model['n'],z0=model['z0'],mu=mu,Z=Z,eta=mass,matrix=A,conditioned_bilinear=left,eta_inverse_bound=unconditional/mass,eta_square_inverse_bound=unconditional/(mass*mass))
    return dict(status='PASS',nonnegative_matrix_checks=count,single_eta_counterexamples=bad_single,example=example,meaning='Original two Pi factors conditioned on same arbitrary Z; unrelated to G conditioning')

def old_scope(detail,template,scope_json,scope_source):
    pb=detail.read_bytes();sb=template.read_bytes();outb=scope_json.read_bytes();out=json.loads(outb)
    assert sha(pb)=='6c2180637b013ccfb255b25de7af9070c62a8077c8716e91aa0574b5bfa07df9';assert sha(sb)=='1090fb2356abe035a997eb851a2f0252a3abe3edbeaf978e99900a38906392de';assert out['producer_sha256']==sha(scope_source.read_bytes())
    src=next(c for c in json.loads(sb)['cases'] if c['id']=='I1');n=src['n'];assert n==4;atoms=src['atoms'];assert all(len(a['position'])==len(a['thresholds'])==n for a in atoms)
    b,cj,s=F(src['parameters']['b']),F(src['derived']['cj']),F(src['parameters']['s']);C=[[cj*F(x)/b for x in a['thresholds']] for a in atoms];L=F(src['parameters']['L']);Lp=min(b,(1+F(1,n))*L);assert L==F(9,10) and Lp==1
    shell={str(i):dict(terms=0,I=F(0),sources=Counter(),segments=Counter(),grids=Counter()) for i in range(n+1)}
    segs=src['score_segments'];mids=[(F(t['lo'])+F(t['hi']))/2 for t in segs]
    zcuts=sorted({F(1,4),F(1,2),F(3,4)}|{F(j,16) for j in range(17)});stats={z:dict(terms=0,I=F(0),pI=F(0),sources=Counter(),segments=Counter(),grids={}) for z in zcuts};fulltime={z:dict(entire_segment=0,partial_segment=0,no_segment=0,G_rejected=0) for z in zcuts};source=Counter();segment=Counter();rows=0;dimmeta=Counter();pairs=0
    for grid,rs in json.loads(pb)['point_records'].items():
        for row in rs:
            rows+=1;assert len(row['xq'])==len(row['x'])==n
            for field in ['good','rho']:assert len(row[field])==len(atoms)
            if 'n' in row:assert row['n']==n;dimmeta['explicit_n_rows']+=1
            else:dimmeta['n_field_absent_rows']+=1
            for term in row['pair_terms']:
                pairs+=1;v,u,si=term['v'],term['u'],term['segment'];t=mids[si];z=cj*t/b;kv=sum(F(x)<t for x in atoms[v]['thresholds']);assert kv==n==segs[si]['k'][v] and row['good'][v] and row['rho'][v]>0
                assert not row['good'][u] and term['delta']==kv-segs[si]['k'][u]>0
                source[v]+=1;segment[si]+=1;value=F(str(term['I']))
                xx=list(map(F,row['xq']));pp=list(map(F,atoms[v]['position']));active=[c<z for c in C[v]];assert sum(active)==kv
                NL=sum(active[j] and abs(xx[j]-pp[j])>L/2 for j in range(n));NLp=sum(active[j] and abs(xx[j]-pp[j])>Lp/2 for j in range(n));S=NL-NLp
                assert S==sum(active[j] and L/2<abs(xx[j]-pp[j])<=Lp/2 for j in range(n))
                sh=shell[str(S)];sh['terms']+=1;sh['I']+=value;sh['sources'][str(v)]+=1;sh['segments'][str(si)]+=1;sh['grids'][grid]+=1
                pw=F(str(row['p']))*F(row['dx_weight_corrected'])*value
                lo=cj*F(segs[si]['lo'])/b;hi=cj*F(segs[si]['hi'])/b
                for z0 in zcuts:
                    if max(C[v])<z0:
                        fulltime[z0]['entire_segment' if lo>=z0 else ('no_segment' if hi<=z0 else 'partial_segment')]+=1
                        if z>=z0:
                            st=stats[z0];st['terms']+=1;st['I']+=value;st['pI']+=pw;st['sources'][str(v)]+=1;st['segments'][str(si)]+=1
                            g=st['grids'].setdefault(grid,[0,F(0),F(0)]);g[0]+=1;g[1]+=value;g[2]+=pw
                    else:fulltime[z0]['G_rejected']+=1
    checks=0
    for category in ['basic_z0','dyadic_denominator_16_all_endpoints']:
        for ztxt,ss in out[category].items():
            st=stats[F(ztxt)];assert st['terms']==ss['terms'] and st['I']==F(ss['I_sum']) and st['pI']==F(ss['p_weighted_I_sum']);checks+=3
            assert dict(st['sources'])==ss['by_source'] and dict(st['segments'])==ss['by_segment'];checks+=2
            for grid,g in st['grids'].items():assert g[0]==ss['by_grid'][grid]['terms'] and g[1]==F(ss['by_grid'][grid]['I_sum']) and g[2]==F(ss['by_grid'][grid]['p_weighted_I_sum']);checks+=3
    assert pairs==out['totals']['pair_terms']==out['totals']['pair_terms_verified_full_score_kv_eq_n'];assert out['model']['n']==n and out['model']['threshold_vector_lengths']==[n]*len(atoms)
    for si,sh in shell.items():
        got=out['thin_shell_by_S'][si]
        assert sh['terms']==got['terms'] and sh['I']==F(got['I_sum']) and dict(sh['sources'])==got['by_source'] and dict(sh['segments'])==got['by_segment'] and dict(sh['grids'])==got['by_grid'];checks+=5
    positive=out['thin_shell_q_n_pass'];assert positive['q_n']==1 and positive['condition']=='S >= q_n'
    def shell_group(predicate):
        st=dict(terms=0,I=F(0),sources=Counter(),segments=Counter(),grids=Counter())
        for si,ss in shell.items():
            if predicate(int(si)):
                st['terms']+=ss['terms'];st['I']+=ss['I']
                for k in ['sources','segments','grids']:st[k].update(ss[k])
        return st
    paid=shell_group(lambda r:r>=1);complement=shell_group(lambda r:r<1)
    assert positive['terms']==paid['terms'] and F(positive['I_sum'])==paid['I'] and positive['by_source']==dict(paid['sources']) and positive['by_segment']==dict(paid['segments']) and positive['by_grid']==dict(paid['grids']);checks+=5
    assert s==F(1,4) and not out['model']['near_soft_gates']['d=1/4_requires_s_at_least_3/4'] and not out['model']['near_soft_gates']['d=1/8_requires_s_at_least_7/8']
    assert stats[F(1,2)]['terms']==pairs and fulltime[F(1,2)]['entire_segment']==pairs
    return dict(status='PASS_SAVED_SCOPE_ONLY',source_sha256=sha(scope_source.read_bytes()),json_sha256=sha(outb),actual_dimension=n,grid_keys_are_resolution=True,rows=rows,row_dimension_metadata=dict(dimmeta),pairs=pairs,by_source=dict(source),by_segment=dict(segment),s=s,b=b,cj=cj,basic_counts={str(z):stats[z]['terms'] for z in [F(1,4),F(1,2),F(3,4)]},field_checks=checks,thin_shell=dict(L=L,Lplus=Lp,N_definition='outside count among active coordinates',histogram=shell,q_special_small_n=1,paid_gate='S >= q_n',paid=paid,complement=complement,not_an_n_to_minus4_q_certificate=True),full_segment_time_classification=fulltime,limitations=['Saved midpoint classifications at other z0 do not split stored I at time boundary','G(1/2) and time gate hold on every entire saved segment, but s=1/4 is not near soft','p/I/roles and weighted sums are inherited saved diagnostics, not dx error/eta/FULL certificates'])

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=ROOT/'exact_checks.json');ap.add_argument('--detail',type=Path,default=Path('/Users/zhengzhihao/Desktop/T/output/centered_cube_round151_20261015/receiver_probe_points.json'));ap.add_argument('--template',type=Path,default=Path('/Users/zhengzhihao/Desktop/T/output/centered_cube_round136_20261014/active_traffic_v2.json'));ap.add_argument('--scope-json',type=Path,default=ROOT/'fullscore_scope.json');ap.add_argument('--scope-source',type=Path,default=ROOT/'fullscore_scope.py');args=ap.parse_args()
    small=[dict(n=n,status='SMALL_N_RULE_NOT_APPLIED',q=None) for n in range(1,8)];initial=[q_min(n) for n in range(8,65)];large=[q_min(n) for n in [128,256,512,1024,10000,100000,1000000]]
    equal=[];adjacent=0
    for rec in initial:
        n=rec['n']
        for q in range(n+1):
            a=math.comb(n,q)*2**q*n**4;b=n**q
            if a==b:equal.append([n,q])
        for cc in [rec['previous'],rec['certificate'],rec['next']]:
            if cc:assert cc['passes']==(cc['lhs']<=cc['rhs']);adjacent+=1
    flow_initial=[flow_model(n,z0) for n in [1,2,4] for z0 in [F(1,4),F(1,2),F(3,4)]]
    flow_boundary=[flow_model(4,z0,zero_mass=z0==F(1,2)) for z0 in [F(1,8),F(1,4),F(1,2),F(3,4),F(1)]]
    flow_expanded=[flow_model(n,F(1,2)) for n in [8,16,64]];models=flow_initial+flow_boundary+flow_expanded
    result=dict(status='PASS',scope='Finite exact q/flow/two-eta algebra and saved-scope counts only; no general geometry/FULL certificate',source_sha256=sha(Path(__file__).read_bytes()),contract_sha256=sha((ROOT/'contract.md').read_bytes()),seed=None,execution=dict(producer_invocations=2,new_kernel_evaluations=0,new_receiver_points=0),q_stages=dict(small_n=small,initial=initial,threshold_pressure=dict(actual_equalities=equal,adjacent_comparisons=adjacent),expanded=large),flow_stages=dict(initial=flow_initial,threshold_and_zero_mass=flow_boundary,expanded=flow_expanded),flow_summary=dict(models=len(models),one_sided_derivative_checks=sum(len(x['rows']) for x in models),threshold_equalities=sum(r['threshold_equalities']>0 for x in models for r in x['rows'])),two_eta=eta_checks(models),saved_scope_audit=old_scope(args.detail,args.template,args.scope_json,args.scope_source))
    args.output.write_text(json.dumps(enc(result),ensure_ascii=False,indent=2)+'\n');print(json.dumps(dict(status='PASS',q_large=[(r['n'],r['q']) for r in large],flow=result['flow_summary'],saved_dimension=result['saved_scope_audit']['actual_dimension'],saved_pairs=result['saved_scope_audit']['pairs'])))
if __name__=='__main__':main()
