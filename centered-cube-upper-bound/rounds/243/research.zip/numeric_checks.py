#!/usr/bin/env python3
"""True disjoint radial fibers, joint node Holder, constants; not FULL."""
import argparse,hashlib,json,math
from fractions import Fraction as F
from pathlib import Path
import mpmath as mp
ROOT=Path(__file__).resolve().parent

def mf(x):return mp.mpf(x.numerator)/x.denominator if isinstance(x,F) else mp.mpf(x)
def enc(x):return mp.nstr(x,50)
def data(n,kind):
 gamma=F(n+1,n)
 if kind=='one':b=F(1);K=0;cap=False
 elif kind=='gamma':b=gamma;K=1;cap=False
 elif kind=='narrow':b=1+F(1,10*n);K=0;cap=True
 else:
  b=F(2);K=int(mp.floor(mp.log(2)/mp.log(mf(gamma))));cap=True
  if n<=32:assert gamma**K<b<gamma**(K+1)
 h=n*mp.log(mf(gamma));x=n*mp.log(mf(b));A=-mp.expm1(-h);D=x-K*h;Oc=-mp.expm1(-D) if cap else mp.mpf(0)
 assert 1<=b<=2 and K>=0 and (not cap or D>0)
 return dict(n=n,gamma=gamma,b=b,K=K,cap=cap,h=h,x=x,A=A,Oc=Oc)
def occupancy(d,alpha):
 K=d['K'];h=d['h'];q=mp.exp(-alpha*h);regular=d['A']*q*(-mp.expm1(-alpha*h*K))/(-mp.expm1(-alpha*h)) if K else mp.mpf(0);cap=d['Oc']*mp.exp(-alpha*d['x']) if d['cap'] else mp.mpf(0);weighted=1+regular+cap;unweighted=1+K*d['A']+d['Oc'];bound=1-mp.expm1(-alpha*d['x'])/alpha;return weighted,unweighted,bound

def moments(K,q,m):
 # Closed finite geometric moments via k^m-(k-1)^m; O(m^2), no K-loop.
 tail=q**(K+1);vals=[(1-tail)/(1-q)]
 for power in range(1,m+1):
  total=sum(mp.mpf(math.comb(power,j))*(-1)**(power-j+1)*(vals[j]-(1 if j==0 else 0)) for j in range(power));vals.append((total-K**power*tail)/(1-q))
 return vals[m]
def shells_exact(n,kind):
 gamma=F(n+1,n)
 if kind=='one':b=F(1)
 elif kind=='gamma':b=gamma
 elif kind=='narrow':b=1+F(1,10*n)
 else:b=F(2)
 radii=[F(1)]
 while radii[-1]*gamma<=b:radii.append(radii[-1]*gamma)
 if radii[-1]<b:radii.append(b)
 Os=[F(1)]+[1-(u/v)**n for u,v in zip(radii,radii[1:])];return radii,Os

def radial(c,dps):
 with mp.workdps(dps):
  n=c['n'];d=data(n,c['bkind']);alpha=mf(c['alpha']);w,uw,bound=occupancy(d,alpha);assert w<=bound*(1+mp.mpf(10)**(-dps+8)) and uw<=1+d['x']
  out={k:enc(v) for k,v in dict(alpha=alpha,h=d['h'],b=mf(d['b']),weighted_occupancy=w,unweighted_occupancy=uw,finite_capacity_bound=bound,capacity_ratio=w/bound,unweighted_log_bound=1+d['x'],unweighted_excess_over_one=uw-1).items()};out.update(regular_last_index=d['K'],has_unique_cap=d['cap'],actual_fiber_count=d['K']+1+int(d['cap']))
  if n<=32:
   radii,Os=shells_exact(n,c['bkind']);brute=sum(mf(o)*mp.exp(-alpha*n*mp.log(mf(R))) for R,o in zip(radii,Os));assert abs(brute-w)<mp.mpf(10)**(-dps+10)*max(1,w);out['independent_Fraction_shell_count']=len(Os);out['independent_weighted_sum']=enc(brute);out['exact_unweighted_fraction']=str(sum(Os));exponent=F(c['alpha'])*n
   if exponent.denominator==1:out['exact_weighted_fraction']=str(sum(o/R**exponent.numerator for R,o in zip(radii,Os)))
  return out

def joint(c,dps):
 with mp.workdps(dps):
  n=c['n'];r=mf(c['r']);alpha=r/(4*(1-r));d=data(n,'two');h=d['h'];K=d['K'];q=mp.exp(-r*h);F1=moments(K,q,1);regular=d['A']**(1-r)*h*F1/4;cap=d['Oc']**(1-r)*d['x']*mp.exp(-r*d['x'])/4 if d['cap'] else mp.mpf(0);lhs=regular+cap
  power=int(mp.nint(1/r));assert abs(power-1/r)<mp.mpf('1e-30');Q=h**power*moments(K,mp.exp(-3*h/4),power)+(d['x']**power*mp.exp(-3*d['x']/4) if d['cap'] else 0);weighted,unweighted,finitebound=occupancy(d,alpha);holder=weighted**(1-r)*Q**r/4;Qbound=6*(8/(3*mp.e*r))**(1/r);universal=4/r**2
  assert lhs<=holder*(1+mp.mpf(10)**(-dps+10)) and Q<=Qbound and weighted<=4/r and lhs<=universal
  out={k:enc(v) for k,v in dict(r=r,alpha=alpha,normalized_actual_node_sum=lhs,weighted_same_partition=weighted,unweighted_same_partition=unweighted,weighted_finite_bound=finitebound,Q_actual=Q,Q_j0_bound=Qbound,joint_Holder_rhs=holder,actual_over_Holder=lhs/holder,universal_4_over_r2=universal,actual_over_universal=lhs/universal).items()};out.update(one_orientation=True,j=0,regular_last_index=K,unique_cap=d['cap'],physical_relation='L=R=M (j0), tie selects only one orientation; Omega_i exactly same radial fibers as capacity',source_factor='Normalized by (B rho)^r; no second receiver copy introduced')
  if n<=32:
   radii,Os=shells_exact(n,'two');direct=sum(n*mp.log(mf(R))/4*mf(o)**(1-r)*mp.exp(-r*n*mp.log(mf(R))) for R,o in zip(radii,Os));directQ=sum((n*mp.log(mf(R)))**power*mp.exp(-3*n*mp.log(mf(R))/4) for R in radii);assert abs(direct-lhs)<mp.mpf(10)**(-dps+10)*max(1,lhs) and abs(directQ-Q)<mp.mpf(10)**(-dps+10)*max(1,Q);out.update(independent_direct_node_sum=enc(direct),independent_direct_Q=enc(directQ))
  return out

def constants(rtext,dps):
 with mp.workdps(dps):
  r=mf(rtext);h=mp.log(2);j=1/(1-mp.exp(-h/2));M=1/(1-mp.exp(-3*h/8))+1;count=2*j*M;coefficient=8/(3*mp.e)*(12*r)**r;assert r<=mp.mpf('.5') and j<4 and M<6 and count<48 and coefficient<=4
  return {k:enc(v) for k,v in dict(r=r,j_bound_at_log2=j,regular_plus_cap_bound_at_log2=M,two_orientation_product=count,combined_safe_count=48,quadratic_coefficient=coefficient,safe_coefficient=4,final_24_Lambda_e5=24*(mp.mpf(128)/119)*mp.e**5).items()}
def generalp(pkey,rtext,dps):
 with mp.workdps(dps):
  p=mf(pkey) if pkey!='pn' else max(mp.mpf('.5'),1-1/mp.log(1000002));t=1-p;r=mf(rtext);h=mp.log(2);resource=1+2*(1-r)/(t*r);resourcebound=2/(t*r);jsum=1/(1-mp.exp(-t*h));jbound=5/(2*t);Mnonzero=mp.exp(-h/4)/(1-mp.exp(-h/4))+1;coefficient=2/mp.e*(35*r/2)**r;assert p<1 and r<=mp.mpf('.5') and resource<=resourcebound and jsum<=jbound and Mnonzero<7 and coefficient<=4
  return {k:enc(v) for k,v in dict(p=p,t=t,r=r,resource=resource,resource_bound=resourcebound,j_sum_at_log2=jsum,j_bound=jbound,nonzero_regular_plus_independent_cap=Mnonzero,M_bound=7,node_coefficient=coefficient,node_bound=coefficient/(t*r*r),safe_node_bound=4/(t*r*r),final_safe_24_Lambda_e5_over_t=24*(mp.mpf(128)/119)*mp.e**5/t).items()}

def precision_check(rows,fields):
 maxima=[]
 with mp.workdps(100):
  for row in rows:
   diffs={name:abs(mf(row['mp40'][name])-mf(row['mp70'][name]))/(abs(mf(row['mp70'][name])) if mf(row['mp70'][name]) else 1) for name in fields};maximum=max(diffs.values());assert maximum<mp.mpf('1e-25');row['precision_relative_differences']={k:enc(v) for k,v in diffs.items()};row['precision_relative_max']=enc(maximum);maxima.append(maximum)
 return max(maxima)

def main(output,contract):
 rm=[dict(stage='initial',n=n,bkind='two',alpha=alpha) for n in (2,8,32) for alpha in ('.01','.1','1')];rm +=[dict(stage='boundary',n=n,bkind=kind,alpha=alpha) for n,kind in [(2,'one'),(2,'gamma'),(16,'narrow')] for alpha in ('.000001','.5')];rm +=[dict(stage='expanded',n=n,bkind='two',alpha=alpha) for n in (512,4096,1000000) for alpha in ('.000001','.1','1')];rrows=[dict(configuration=c,mp40=radial(c,40),mp70=radial(c,70)) for c in rm]
 jm=[dict(n=n,r=r) for n in (2,32,512,1000000) for r in ('.5','.25','.1')];jrows=[dict(configuration=c,mp40=joint(c,40),mp70=joint(c,70)) for c in jm];cm=['.001','.01','.1','.25','.49','.5'];crows=[dict(r=r,mp40=constants(r,40),mp70=constants(r,70)) for r in cm];gm=[(p,r) for p in ('.5','.9','pn') for r in ('.01','.5')];grows=[dict(p=p,r=r,mp40=generalp(p,r,40),mp70=generalp(p,r,70)) for p,r in gm]
 for row in rrows:assert row['mp40']['regular_last_index']==row['mp70']['regular_last_index'] and row['mp40']['actual_fiber_count']==row['mp70']['actual_fiber_count']
 for row in jrows:assert row['mp40']['regular_last_index']==row['mp70']['regular_last_index']
 precision_maxima={'radial':precision_check(rrows,['weighted_occupancy','unweighted_occupancy','finite_capacity_bound']),'joint':precision_check(jrows,['normalized_actual_node_sum','joint_Holder_rhs','Q_actual']),'fixed_constants':precision_check(crows,['two_orientation_product','quadratic_coefficient','final_24_Lambda_e5']),'general_constants':precision_check(grows,['resource','j_sum_at_log2','node_coefficient','final_safe_24_Lambda_e5_over_t'])}
 payload=dict(source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),contract_sha256=hashlib.sha256(Path(contract).read_bytes()).hexdigest(),precision_summary={k:enc(v) for k,v in precision_maxima.items()},maximum_precision_relative_difference=enc(max(precision_maxima.values())),precision_metric='abs(mp40-mp70)/abs(mp70), denominator1 only if mp70 zero; evaluated100dps from saved50-digit outputs (40dps values retain their computed rounding, not50 correct digits); agreement diagnostic not interval error',scope='Finite true Lebesgue radial receiver fibers plus normalized node/common-source Holder and constants; not FULL/history/general source moment/root closure.',partition='a1,z0; Omega0=Q1(0), Omega_k=Q_Rk(0) minus Q_Rprev(0); gamma1+1/n grid capped atb once. Selector frozen around origin, evaluated hardz0; fibers disjoint up to null boundaries. O0=1,Ok=1-(Rprev/Rk)^n.',radial_capacity_rows=rrows,joint_node_rows=jrows,fixed_p_constants=crows,general_p_constants=grows,counts=dict(real_partition_capacity_cases=len(rrows),same_partition_joint_node_cases=len(jrows),fixed_p_constant_cases=len(crows),general_p_constant_cases=len(grows)),large_n_method='Closed geometric sums and O(m²) finite geometric moment recursion m=1/r<=10. No K-loop at large n; smalln Fraction shell/direct node sums independently check. All numerical transcendental evaluations ordinary40/70dps, not interval proof.',orientation_guard='Actual j0 left sums have one orientation and same original fibers;48 appears only as universal analytic bound already counting two orientations, never as duplicated receiver data.')
 Path(output).write_text(json.dumps(payload,indent=2,sort_keys=True)+'\n');print(payload['counts'])
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--output',default=str(ROOT/'numeric_checks.json'));p.add_argument('--contract',default=str(ROOT/'task_contract.md'));a=p.parse_args();main(a.output,a.contract)
