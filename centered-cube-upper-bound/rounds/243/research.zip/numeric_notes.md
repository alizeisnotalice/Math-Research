# R243 numerical notes

Final executed scope:48 cases, with40/70dps refinement, exact smalln shell checks and closed large-n sums.

Use one frozen true radial receiver partition at origin0, evaluated at hardz0. InnerQ1 and each successive gamma-grid cube shell are disjoint; a unique capped endpoint is added only if needed. Twenty-four weighted-capacity cases include tinyalpha, b=a, narrow window, exact regular endpoint and n through10^6. Twelve j0 node cases use the SAME partition and one orientation. Finite geometric-moment recurrences avoid traversing large node counts; smalln exact Fraction shell geometry/direct sums independently cross-check. Six fixed-p constants and six general-p constants complete48 cases. No FULL/history realizability or unpaid general source-moment bound is inferred.

## Actual final menu and exact receiver partition

All48 cases actually ran:24 true radial-partition capacity cases,12 same-partition j0 node Holder cases,6 fixed-p constants and6 general-p constants. Initial radial n=2,8,32 withb2 andalpha=.01/.1/1; boundary radial(n,b)=(2,1),(2,gamma),(16,1+1/(10n)) withalpha1e-6/.5; expanded n512/4096/10^6,b2,alpha1e-6/.1/1. This covers no outer shell, an exact regular endpoint with no duplicate cap, a very narrow window, tiny positivealpha, and a large actual grid.

The receiver selector is frozen around origin0; the hard anchor is evaluated atz0. Omega0=Q1(0), and Omega_k=Q_Rk(0)\Q_Rprev(0), with R_k upward gamma-grid nodes and at most one unique capb. These are genuine disjoint Lebesgue receiver fibers up to null boundaries. O0=1 and O_k=1-(Rprev/Rk)^n are exact integrals of the normalized hard kernel assigned to that fiber. The selector is not reselected for y,v,u or time. This is a finite geometric model, not a claimed original terminal leaf/FIRST/FULL/history realization.

Let h=nloggamma,K be the last regular index,A=1-exp(-h),xcap=nlogb. The regular O_k equalsA, and cap occupation is1-exp[-(xcap-Kh)]. Thus the weighted occupation is evaluated by a finite geometric sum, while the unweighted occupation is1+KA+Ocap. The finite right side is1+[1-exp(-alpha xcap)]/alpha, not merely1+1/alpha. Stable expm1 handles narrow/tinyalpha cases. At large n the integer K is determined independently at40/70dps and checked to agree; its floor is not called an interval certificate. Exact endpoint gamma cases use the known K=1 and capfalse rather than numerically rounding into a duplicate cap.

For n<=32 a separate Fraction construction forms actual radii and exact shell occupations, directly sums their numerical weights, and checks the closed form. The unweighted Fraction is retained; weighted sums are also exact Fractions wheneveralpha*n is integral. Final output uses50 displayed digits to retain the actual rounding in the40dps work values, rather than truncating both runs to32 digits. Major fields are compared at100dps by abs(value40-value70)/abs(value70), denominator1 only when value70 iszero. Observed maximum relative precision change is2.60072731538502e-34, in the finite geometric-moment/joint calculations. Per-class maxima: radial6.12508587434605e-37; fixed constants3.84762832461000e-41; general constants1.24172062189385e-40. The extra displayed digits do not make a40dps computation50-digit accurate; these differences are precision-refinement diagnostics, not rigorous true errors or interval certificates.

### Explicit exact failure of unweighted normalization

At n2,a1,b2, actual radii are1,3/2,2, and occupations are1,5/9,7/16. Their sum is287/144>1 despite disjoint receiver fibers. This exactly disproves the tempting unweighted claim sumO<=1; it does not contradict the weighted theorem. The stated general unweighted logarithmic bound1+nlog(b/a) remains in the JSON. At n10^6,b2 the closed unweighted sum is438153.75119833085 over693149 genuine fibers. Weighted sums are316061.22569119293 foralpha1e-6,7.01041351146827 foralpha.1, and1.3678796251110863 foralpha1. A very smallalpha need not give a small constant; its explicit1/alpha charge is preserved. These are raw finite values, not a fitted dimension theorem.

## Same receiver fibers and joint node Holder

The12 joint cases use n2/32/512/10^6,r=.5/.25/.1, the SAME b2 radial fibers and j0 physical nodes L=R=M=R_i. A fixed tie selects exactly one orientation. The true node input isO_i from those fibers, never an independent optimized occupation array and never a second copy of the receiver domain. X_i=nlogR_i, innerX0=0 contributes zero traffic. The script evaluates

    sum_i X_i/4 O_i^(1-r) exp(-rX_i)

and the exact joint-node Holder RHS usingalpha=r/[4(1-r)] andQ=sum X_i^(1/r)exp(-3X_i/4). The weighted resource includes the inner fiber once. For r=.5/.25/.1,1/r is2/4/10. An O(m^2) finite-geometric-moment recurrence computes sum_{k=0}^K k^m q^k with noK loop, so large nodes are not enumerated. Smalln separately uses Fraction shell occupations and directX sums to check BOTH the node sum andQ. This independently checks that the closed recurrence and the physical fibers match.

All joint Holder inequalities and the coarse4/r^2 bound pass. Maximum actual/Holder is.7986901144 and maximum actual/(4/r^2) is.04922813248. The left sums are normalized by(B rho)^r; they are conditional tests of the provided node estimate, not an actual full-posterior traffic simulation or a payment of the remaining source integral. Our one-orientation example is a subset of the two-orientation universal proof. The factor48 is used only in the analytic upper constant; it is NEVER applied to duplicate our actual receiver data.

## Constant and general-p endpoint checks

Fixed-p r=.001,.01,.1,.25,.49,.5 checks the uniform h>=log2 estimates. The regularM block with an independent cap is below6; thej block is below4; their two-orientation product is below48. The resulting coefficient(8/(3e))(12r)^r is<=4, maximum sampled value2.4029784472806815. r0 is excluded; the boundaryr=.5 is included. The24Lambda exp5 coefficient is evaluated withLambda128/119. No additional orientation factor is restored after48.

Six general-p constant cases takep=.5/.9/p_n(n=10^6),r=.01/.5,t=1-p>0. They check the exact resource upper comparison1+2(1-r)/(tr)<=2/(tr), thej bound sum exp(-tjh)<=5/(2t), and the NONZERO regularX exponential sum plus one independent cap<=7. The regularX0 slot is excluded in this latter estimate because its trueX^(1/r) coefficient iszero. They evaluate[2/e](35r/2)^r/(tr^2)<=4/(tr^2) and retain the entire safe24Lambda exp5/(1-p) source-price coefficient. Maximum sampled numerator coefficient is2.1764041245323544<4. This is a constants verification, not a general-p same-source traffic simulation or permission to takep1. At p=.5 the main proof's sharper fixed-p24Lambda exp5 remains distinct from the weaker general-p safety coefficient.

## Three-stage evidence and remaining scope

Exploration, boundary pressure and enlarged parameter ranges above were all executed, not just proposed. Only actual runs are listed. No old soft kernel/slab grids were repeated. These true dx fibers and their common-node Holder confirm the claimed selector-resource mechanism on this finite model; they do not establish original FULL realizability, a source-rank assumption, a general root rate, or the final unproved H_N^2 source budget. In particular quadratic source price is not automatically Wnu. The full-original posterior remains an analytic assumption of the parent proof, not a newly restricted numerical posterior.

## Reproduction and precision

Existing Python3.12.14 with vendor mpmath1.3.0; standard Fraction/math plus mpmath only, no installation. All transcendental evaluations are ordinary40/70dps; no interval proof is claimed. Source and adjacent frozen-contract hashes bind the output. Large-n checks use closed sums; only n<=32 uses the explicit shell loop.

Run from the extracted package directory containing numeric_checks.py and task_contract.md (or from the final checkpoint directory after archive creation).

```sh
PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor \
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 \
numeric_checks.py \
--output /tmp/r243_numeric_replay.json \
--contract task_contract.md
```

The executable is `/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3`. mpmath is `/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor/mpmath`; no NumPy dependency. Script and contract paths may be relocated; runtime/output path do not enter JSON.

## Frozen final replay

Complete separate-output replay was byte-identical: 139509 JSON bytes; actual wall.05s,user.05s,system.00s. Counts:24 real partition capacities,12 same-partition joint nodes,6 fixed-p constants,6 general-p constants. Largest observed40/70 relative precision change is 2.6007273153850199179598880821413538220601894129375e-34. SHA256 source `f5bdcc2e36093d8516663138e32b76d13cb3d89957d6bcbbfe464be49824175c`; JSON `f8c6bed1bce79087760c587b010dac4355528158d528104b595e9a654277a9d8`; contract `62db81f126f2924f5d9cce6c18967155716e333eb405fc587131e28a1a28485d`. Runtime and output paths are absent from JSON.
