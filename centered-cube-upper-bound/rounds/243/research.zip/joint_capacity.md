# R243：保实际节点 partition 的联合接收容量与全补域二次价

本轮证明一条无维数损失的**带权实际硬核占用界**，并把它用在原 R242 低 J 补域的全部交通上。相对于同一 N 上取 δ=1 的旧价格，它将先逐节点扩大 receiver 域所得的三次对数来源费用降为二次；没有增加新的已付来源门，也没有裁剪原 posterior。

一般根阶输入预算仍未证明。新的二次来源价不能自动当成 Wν；本稿明确区分已付的联合 selector 费用与最后仍未付的全局来源积分。

## JC1. 原对象与真正的 receiver partition

固定原有限截断和同一外资料 (ω,V)。沿 R237–242 保 0<a≤b≤2a、q,K>0、ν≤β≤f、原 FIRST/FULL/capture/history/large-n 资格。跨 j 使用同一 β,ν,a,b,q,D。原 hard z 不是 posterior 槽；Π_t,e_t,Z_t 始终由完整原 ν 定义。

所用物理选择器确为源无关的 receiver 函数：R107 integration.md:9–17 原定义 s(x)、L_s(x)、R(x)；R112 astra_joint.md:11–15 继承它们；R128 proof.md:606、637 保原唯一 1_{j(x)=j}，j 由 min(L,R)/sqrt(LR) 决定。R229 adaptive_geometry.md AG1–2 只在这些物理选择器上作确定性向上舍入。因此固定平局规则后

\[
 i(x)=(\epsilon(x),j(x),M^*(x))
\]

不依软来源 y、hard z、辅助 v,u 或 clock t。两朝向分别给 (L_i,R_i)=(M_i,c_i²M_i) 或反向，c_i=γ^−j、γ=1+1/n；上端截 b 的节点也保持此精确比例。

原正 receiver 的 Q_R(x) 整体位于唯一 terminal leaf V（R107:109–120）；在预冻结叶和原共同 receiver 域 E_V 内，定义

\[
 \Omega_i=E_V\cap\{x:i(x)=i\}.
\]

这些集合可测且两两不交。所有依 y 的 high pe、heavy、历史或其它 source gate 留在原 χ 内，或在非负上界中明确放松；**不把它们投影成 Ω_i**。原 half-column 所需的 capture 支持继续保留。下面的 I_i 可正放掉 capture，但这不授权在 half-column QG 中删除所需支持。

对 fixed z 记

\[
 O_i(z)=\int_{\Omega_i}h_{R_i}(x-z)dx,\qquad
 I_i(y,z)=\int_{\Omega_i}h_{R_i}(x-z)P_{s(x),L_i}(x-y)dx.
\]

不声称 ∑_i O_i≤1。区别于此前逐节点扩大到共同 Ω 的做法，本稿将这些真实 Ω_i 留到节点联合 Hölder 之后。

## JC2. 带权 actual hard-adjoint 容量

对于任何可测不交 Ω_i、固定尺度 R_i∈[a,b] 和 α>0，恒有

\[
 \boxed{\sum_i(a/R_i)^{\alpha n}O_i(z)
 \le1+\frac{1-(a/b)^{\alpha n}}\alpha
 \le1+\frac1\alpha.} \tag{JC2.1}
\]

证明令 d(x)=2||x−z||∞。由不交性，点态

\[
 \sum_i1_{\Omega_i}(x)(a/R_i)^{\alpha n}h_{R_i}(x-z)
 \le \frac{a^{\alpha n}1_{d(x)\le b}}
             {\max(a,d(x))^{(1+\alpha)n}}.
\]

d 的球是完整边长 d 的 cube，体积 d^n。真实 dx 积分给内核部分1和外层

\[
 n a^{\alpha n}\int_a^b r^{-1-\alpha n}dr
 =\frac{1-(a/b)^{\alpha n}}\alpha.
\]

这证明 JC2.1。它使用同一 hard z 和真实 receiver partition，未改变 hard 来源 ν，也不是把可变 R(x) 核当成归一化核。α↓0 的右侧为1+nlog(b/a)，所以无权情形的线性维数费用仍然存在；本轮的改善来自与原衰减相匹配的正 α，而非无权归一化。

## JC3. 准确低 J 补域与同源实际 FIRST

采用 R242 的

\[
 J_z(y)=\max\{E_z(y),G_{\sharp,z}(y),T_z(y)\},\quad
 p_n=\max\{1/2,1-1/\log(n+2)\},\quad
 \rho_D(z)=\beta(D(z))/(qa^n).
\]

本稿全部左侧是原来源集

\[
 N_z=\{y\in D(z):J_z(y)<\log_+\rho_D(z)/p_n\}. \tag{JC3.1}
\]

这是 R242 已付门的完整互补，含未饱和与饱和阈值行，不再选择其中一个更容易的子集。N_z 在 fixed hard z 后、x/y/v/u/j/M/t 之前冻结。定义显式来源量

\[
 m_N(z)=\int_{N_z}e^{-J_z(y)/2}\beta(dy),\qquad
 \rho_N(z)=m_N(z)/(qa^n).
\]

实际 FIRST 给每个真实纤维

\[
 \int_{N_z}I_i(y,z)\beta(dy)\le q O_i(z). \tag{JC3.2}
\]

它在每个 receiver x 上使用原实际 s(x)，没有给 soft 菜单单元授 FIRST。虽然形式上每个 i 都有此式，最终不是逐 i 独立收费，而由 JC2 合并其真实 O_i。

## JC4. 保纤维的原节点上界

记 B=e⌈π√n⌉、h=nlogγ≥log2>2/3、l=jh、M0=a/c²、X=nlog(M/M0)、Z=(X−U)_+。每节点原有效 clock 长度≤Z/n，0≤Z≤X。

R242 的同源窗口包络在任何 receiver 子集上都成立：

\[
 I_i\le BM^{-n}e^{2l}e^{-J_z(y)}.
\]

原半阶列保其 capture 后，R238–242 的共同 soft 菜单和 fixed-node QG 给 (BM^−n)；同底测度插值给 J_{θ,i}≤(BM^−n)^(2θ)I_i^(1−2θ)。

在本轮只取一般 fractional 参数中的 p=1/2：令

\[
 0<r\le1/2,\qquad\theta=r/4,\qquad\eta=r/2.
\]

此处 p 仅是用于估计整个 N 的辅助 Hölder 参数，不改变定义 N 的 p_n。由 I_i^(1−2θ)=I_i^(1−r)I_i^η、上述包络与 JC3.2，

\[
 \int_N I_i^{1-2\theta}d\beta
 \le(BM^{-n}e^{2l})^\eta(qO_i)^{1-r}m_N^r.
\]

半列上界一致于辅助 v,u；先在原完整同一 Π_t⊗Π_t 上使用 ∫δ_t dΠ_t²≤n/4，再积原 β|N，并使用真实 clock 范围。包括列外分母 q、尚未乘 good 因子和物理/三腿外费的节点价为

\[
 \boxed{\mathcal T_{i,z}^{N}\le
 \frac X4(B\rho_N)^r O_i(z)^{1-r}
 e^{-r(l+X)}.} \tag{JC4}
\]

这就是 R242 节点式保实际 O_i 的版本：e^−4θl=e^−rl、e^−rX。原 high/history/time 等依源条件只会删正项；不能将它们加入源无关 partition 后再假定可交换。Π_t 不依 receiver x 的原资格仍是 receiver-first 操作的前提。

## JC5. 联合节点 Hölder：严格消去一层费用

固定 z、r，令 α=r/[4(1−r)]、a_i=(a/R_i)^(αn)。由 JC2，

\[
 \sum_i a_iO_i\le1+1/\alpha\le4/r.
\]

对节点索引 i 作一次 Hölder，

\[
 \begin{aligned}
 &\sum_i O_i^{1-r}\frac X4e^{-r(l+X)}\\
 &\le\left(\sum_i a_iO_i\right)^{1-r}
 \left[\sum_i4^{-1/r}X^{1/r}e^{-l-X}
                  a_i^{-(1-r)/r}\right]^r.
 \end{aligned} \tag{JC5.1}
\]

两朝向都有 nlog(R_i/a)≤2l+X。因 α(1−r)/r=1/4，方括号内去掉4^−1/r后的项≤X^(1/r)e^−l/2−3X/4。这保留两朝向的正确尺度，不把 R_i 一律改成 M 或 a。

对正规 X=kh 及最多一个独立 capped endpoint，

\[
 X^{1/r}e^{-3X/4}
 \le\left(\frac8{3er}\right)^{1/r}e^{-3X/8}.
\]

这是 u e^−au 的最大值公式。正规几何和≤1/(1−e^−3h/8)≤5，独立 cap≤1，所以节点 X 和≤6[8/(3er)]^(1/r)。j 和为

\[
 \sum_{j\ge0}e^{-jh/2}\le(1-2^{-1/2})^{-1}<4.
\]

再按两朝向上计，故方括号（未含4^−1/r）≤48[8/(3er)]^(1/r)。空节点无贡献；cap 即使重复上计也只增正项。综上

\[
 \begin{aligned}
 \sum_i O_i^{1-r}\frac X4e^{-r(l+X)}
 &\le\frac8{3er^2}(12r)^r\\
 &\le\frac4{r^2}\qquad(0<r\le1/2).
 \end{aligned} \tag{JC5.2}
\]

例如最后一步用 r^r≤1、12^r≤sqrt12、e>8/3 即可。所用48已经包含两朝向；后文外费不得再乘2。

因此对整个原 N，不留下未知 selector 算子范数或未付节点占用和，已经严格得到

\[
 \boxed{\sum_i\mathcal T_{i,z}^{N}
 \le4r^{-2}(B\rho_N)^r.} \tag{JC5.3}
\]

此前逐节点将 O_i 替为共同 Δ 再分开求和产生 r^−3；这里实际 partition 与原衰减支付了其中一层。这个 r^−2 结论不要求低 J 域非空、低阈值未饱和或任何新的源集中假设。

## JC6. 原完整补域的二次来源价

对非零原行定义

\[
 H_N(z)=1+\log_+\rho_N(z)+\log B+\log_+K,
 \quad r_z=1/H_N(z),\quad\theta_z=r_z/4.
\]

B≥e 给 H_N≥2，故 r≤1/2。r、θ、α 都在 fixed hard z 的原来源数据上冻结，早于 receiver、辅助槽、节点与时间。m_N=0 则原 N 行为零，先置零。

含原 good 因子的指数满足

\[
 (K/3)^{r/4}(B\rho_N)^r\le e.
\]

由 JC5.3 每条测试腿的节点总价≤4e H_N²。原两朝向已在48内，只恢复2Λe⁴与三条原测试腿，得

\[
 \boxed{P_{\rm farclock}^{N}(U)\le
 24\Lambda e^5\,\mathbb E\sum_V\int_V H_N(z)^2\nu_V(dz).} \tag{JC6}
\]

该式对所有 U≥0 一致；U=0 只覆盖原当前 far-clock 全有效窗。它保留原真实 dx、原来源与全部原资格，没有给每个来源壳层或每种 r 另领一份预算，也没有再做 top-k 或使用已耗负信用。K 若依外资料则其费用就在相应 H_N 内；若按原已认证参数族预固定常数，则可在 H_N 中相应固定。

JC6 是对任务指定的整个原低 J 补域的新无条件估计，不是再挑一个可付子集。降幂比较限于同一 N 上取 δ=1 的旧价格，且不含免费的 ∑O_i≤1 假设。它不逐输入支配所有旧 δ 加权的 δH_δ³ 界；旧界仍可保留，并对同一原交通取合法较小者，不将两种上界相加当成额外信用。

## JC7. 仍未闭合的唯一来源步骤

没有证明 JC6 右侧≤n^(1/2+o(1))||f||1。R237 source ledger 的 ν≤β≤α、原不交叶预算只付 E∑ν(V)，而 logρ 的祖先总上界已有 nlog n 量级；将其直接代入 JC6 仍不足以证明根阶，甚至可能大于旧线性费用。这里不能把“二次”误报为一般维数阶改善。

现在最早尚缺的具体步骤是，对同一实际 N、同一 original β 与 hard ν，证明

\[
 \mathbb E\sum_V\int H_N(z)^2\nu_V(dz)
 \lesssim \sqrt n\,\operatorname{polylog}(n)\|f\|_1,
\]

或在 JC4 之前利用剩余原 capture/高层 score/source 关系给更强的共同接收量。这个显示的来源条件是缺口，不是本轮成果。已证且不含未知来源算子条件的成果是 JC2 与 JC5.3，以及它们对整个补域的严格回代 JC6。

与此前节点全放松相比，下一步不应再重新支付 j/M 菜单的三次费用。必须针对实际共同来源密度尾或保留在 JC4 前的源相关几何，而不能裁剪 full Π、把 hard z 当 posterior，或将 β 当成具有 ν 的 rank。

## JC8. 本机检查和交付范围

本机 Python/mpmath45 位实际检查12个真实径向 selector partition：n∈{2,8,32,512}，a=1,b=2，R_k 从1按1+1/n增长并截2，内 Q_1 与各相邻 cube 壳分别选择对应向上 R_k；α∈{.01,.1,1}。精确积分为

\[
 1+\sum_k R_k^{-\alpha n}[1-(R_{k-1}/R_k)^n].
\]

全部小于 JC2.1，最大比为0.8341485100633637134176982。另对 r=k/50，k=1,…,25，实际核验 (8/(3e))(12r)^r≤4；25项全部通过，最大系数2.402978447280681469854481。

这些是核占用与常数检查，不是 FULL、history 或根阶主目标的数值证据。严格证明在 JC2–6。作者仅修改 joint_capacity.md，不改他人文件或原 sources，不提交仓库；本轮到此交付，不延长为其它子集探索。
