# R243: shared actual receiver resource, for every source exponent p<1

This auxiliary note owns only this file. Its completed route is the
general-p extension of the actual-selector partition argument; the
other author treats the sharper special case p=1/2. The general
arbitrary-input root weak theorem remains open. This note proves a
quadratic original-source price and an explicit logarithmic-cubed
payment for the single R242 source gate, not another unknown dual norm.

## SR1. Actual selectors and the partition's source independence

Freeze original finite data (omega,V), sources nu<=beta<=f dx,
0<a<=b<=2a and q,K>0. Use the same original receiver domain Omega,
actual common softness s(x), FIRST, capture, history and full-nu
posteriors as R242. Fix original hard z before x,y,v/u,j,M,t.
F_z subset D_V(z) is a measurable source subset frozen at this level.

The physical index i=(orientation,j,M) is assigned by the **original
receiver selectors**, with preassigned boundary ties. It depends on x
and fixed outer data, not on y,z or auxiliary v/u. This is inherited
from the original definitions, not a new selection assumption:

| Original source | Actual statement used |
|---|---|
| [R107 integration.md:9–17](/Users/zhengzhihao/Desktop/T/output/centered_cube_round107_20261013/integration.md:9) | The original s(x), L_s(x), R(x) and complete f are fixed; the physical selectors are receiver functions. |
| [R107:109–120](/Users/zhengzhihao/Desktop/T/output/centered_cube_round107_20261013/integration.md:109) | The whole Q_R(x) belongs to a unique pre-frozen terminal V on positive rows; original y also belongs there. At most one V-row is nonzero for a receiver. |
| [R128 proof.md:604–609,637](/Users/zhengzhihao/Desktop/T/output/centered_cube_round128_20261014/proof.md:604) | The original mother already has the unique 1_{j(x)=j}; its band is determined by min(L,R)/sqrt(LR). |
| [R229 adaptive_geometry.md:18–32](/Users/zhengzhihao/Desktop/T/output/centered_cube_round229_20261016_final_checkpoint/adaptive_geometry.md:18) | Both physical selectors and softness are L(x),R(x),s(x); the three target legs use L(x), min(b,gamma L(x)), and fixed b. |

Consequently the actual upward node cover, with its already proved
physical fee e^4, yields disjoint measurable sets Omega_i subset Omega.
For each target leg the physical partition is the same. It is not the
posterior-selected soft menu, and it introduces no extra soft index.

High pe, heavy, terminal good/bad, original source histories and
source-dependent capture gates must not be projected into a supposedly
source-independent Omega_i. Keep them in the original joint factor,
or make a documented positive relaxation to the receiver domain above.
The static capture needed by half QG remains. This is exactly where
the source-independence qualification matters in the proof below.

## SR2. The actual common hard-column resource

Let R_i in [a,b] be the fixed hard scale at index i, and put

    O_i(z)=integral_{Omega_i} h_Ri(x-z)dx,
    w_i=(a/R_i)^{alpha n}, alpha>0.

Then the shared, genuine Lebesgue column estimate is

    sum_i w_i O_i(z)
       <=1+[1-(a/b)^{alpha n}]/alpha<=1+1/alpha.        (SR1)

Proof: disjointness leaves at most one summand at each receiver. Thus
the sum is at most the full-space integral of

    sup_{a<=R<=b} a^{alpha n}R^{-(1+alpha)n}1_{Q_R(z)}(x).

On Q_a(z) this is a^-n, of integral one. For a<2||x-z||_infty<=b its
maximizer is R=2||x-z||_infty. Cube-volume differentiation gives
n a^{alpha n} integral_a^b s^{-alpha n-1}ds,
which is exactly the second term of SR1. No source mass or receiver
volume is substituted for this column. The same sum includes both
physical orientations; disjointness is across the full original index.

This elementary proof records the precise shared resource being used;
it does not duplicate the other author's separate p=1/2 source budget.

## SR3. General-p node inequality on the actual partition

Use R242's source score J=max(E,G_sharp,T), the common menu
B=e ceil(pi sqrt n), gamma=1+1/n, h=n log gamma in [log2,1],
c=gamma^-j, M0=a/c^2, X=n log(M/M0), Z=(X-U)_+, U>=0.
For a fixed 0<=p<1 and 0<r<=1/2 set

    t=1-p, theta=tr/2, eta=pr,
    m_p(z)=integral_{F_z}e^{-pJ(y-z)}beta(dy),
    rho_p(z)=m_p(z)/(q a^n).                            (SR2)

These satisfy theta>0, eta>=0, 2theta+eta=r<=1. The narrower r<=1/2
is imposed only for the convenient uniform summation constants below.

On each actual Omega_i, the R242 pointwise window bound and original
actual-soft FIRST give the same node inequality with **its own** O_i:

    T_i^F(z) <=(Z/4)(B rho_p)^r O_i(z)^{1-r}
                            e^{-4theta jh-rX}.         (SR3)

Here the actual overlap is integral_{Omega_i}h_Ri P_actual,L*. Its
source integral is <=q O_i, and its combined pointwise upper bound
is BM^-n exp(2jh-J). The original source Holder and half-column step
are uniform in theta. Their auxiliary-v-independent majorant is used
before Gini on the same complete Pi_t(y) tensor Pi_t(y), and only
then is beta integrated. Neither posterior nor e_t is changed by
Omega_i or F_z. R242 FB3–4 prove this exact order and all zero-row
conventions; the partition merely preserves a domain which those
positive bounds were previously allowed to enlarge.

The same F_z, beta, nu, a,b,q and J occur across all i. If these were
reselected per physical node, the common rho_p in SR3 could not be
pulled out and this theorem would not apply as stated.

## SR4. Index Holder keeps the common receiver resource

Choose alpha=theta/(1-r)>0 in SR1. Since R_i<=M and
M=a exp(2jh/n+X/n),

    w_i >= exp[-alpha(2jh+X)].

Use Z<=X in SR3. After factoring (w_i O_i)^{1-r}, the residual
exponent is bounded above by -tr jh-r(1+p)X/2 (equality for R_i=M;
the R_i=c^2M orientation can have a more negative exponent). Holder over the finite actual
index family, with exponents 1/(1-r),1/r, therefore gives

    sum_i(K/3)^theta T_i^F(z)
      <=(1/4)(K/3)^theta(B rho_p)^r
        [sum_i w_i O_i]^{1-r}
        [sum_i X^{1/r}e^{-tjh-(1+p)X/2}]^r.           (SR4)

It is this sum-before-discarding-domain step which saves one power of
the source logarithm. It is not obtained by applying a different FIRST
to each node and then labeling those resources disjoint after the fact.

## SR5. Explicit node tail, cap endpoint, and both orientations

Let A be the second sum in SR4. Since (1+p)/2>=1/2,

    X^{1/r}e^{-(1+p)X/2}
      <=[4/(er)]^{1/r}e^{-X/4}.

The original X=0 term is exactly zero and is omitted. For the regular
positive nodes X=kh, k>=1, sum e^{-kh/4}<=4/h<=6. The one possible
independent capped endpoint contributes at most one in this majorant.
Thus each orientation costs at most 7[4/(er)]^{1/r}, both orientations
at most 14 times that quantity. All legal node families are positive
subsets of this enlarged one. Independently,

    sum_{j>=0}e^{-tjh}<=1+1/(th)<=5/(2t).

Hence

    A<=[35/t][4/(er)]^{1/r}.                           (SR5)

The shared resource satisfies

    1+1/alpha=1+2(1-r)/(tr)<=2/(tr).

Substitution into SR4 yields the explicit per-leg, both-orientations
bound

    sum_i(K/3)^theta T_i^F(z)
       <=[2/(e t r^2)](35r/2)^r
                         (K/3)^theta(B rho_p)^r
       <=[4/(t r^2)](K/3)^theta(B rho_p)^r.            (SR6)

For the last conservative constant, when r<=1/2 the factor
(35r/2)^r is at most max(1,sqrt(35)/2)=sqrt(35)/2; its resulting
coefficient sqrt(35)/e is <4. All summation and cap costs are now
explicit. One must not multiply SR6 by two again for orientations.

## SR6. Quadratic source budget for every p<1

For m_p>0 put

    H_p(z)=1+log_+rho_p(z)+log B+log_+K,
    r_z=1/H_p(z), theta_z=(1-p)/(2H_p(z)).

Because B>=e, H_p>=2 and r_z<=1/2. Also
(K/3)^theta_z(B rho_p)^{r_z}<=e. These choices depend only on the
frozen original anchor data, before receiver, soft y, auxiliary,
physical index and time variables. The full original far traffic on
the source restriction F thus satisfies

    P_far^F(U) <= [24Lambda e^5/(1-p)]
          E sum_V integral H_p(z)^2 nu_V(dz),          (SR7)

where Lambda=128/119. This restores physical e^4, the original 2Lambda,
and three legs: 6Lambda e^4. The two orientations were already included
in SR5. On m_p=0 the original source integral vanishes before a logarithm
or normalized row is formed. F_z may be the whole D_V(z), the original
unpaid near-J source set, or any other once-retained frozen source
subset; SR7 does not require its weighted mass to be small.

For p varying with original outer data or z, its factor 1/(1-p) stays
inside the corresponding unchanged source integral. The safe result
is for p<1. There is no free p=1 endpoint: theta=0 would remove the
summable j factor and alpha from SR1. The special p=1/2 proof in the
other author's manuscript has a sharper constant; it can be retained
as a separate alternative for the same quantity, without adding its
price to SR7.

This is a new unconditional quadratic bound for the original joint
near-source traffic in terms of its explicit weighted source mass.
It is not a general input estimate for that mass on all data. No
inverse posterior weight, heavy floor, source exchange, beta rank or
unused negative credit is hidden in SR7.

The quadratic-versus-cubic comparison is with the old delta=1 price
for the same source set and exponent. An older occupation-sensitive
delta H_delta^3 bound can be stronger when delta is small; retain the
minimum of those separately valid bounds for the same original quantity,
rather than claiming SR7 dominates every occupation certificate.

## SR7. The R242 enlarged source gate now costs logarithmic cubed

For p>0 retain the one R242 source gate

    F_{p,z}={y in D_V(z):J(y-z)>=log_+rho_D(z)/p},
    rho_D(z)=beta(D_V(z))/(q a^n).

It has rho_p<=1. The full posterior is not restricted to this set.
With the legal common original choice K=1 from R241, choose

    L_n=max{2,log(n+2)}, p_n=1-1/L_n.

Then SR7 and the actual source ledger E sum_V nu_V(V)<=||f||_1 give

    P_far^{F_pn}(U) <=24Lambda e^5 L_n
               [1+log(e ceil(pi sqrt n))]^2 ||f||_1. (SR8)

This is O(log^3(n+2))||f||_1, with every constant displayed. It is a
complete payment for that source-defined original far-clock subset,
not a claim of FULL realization, a uniform positive proportion, or
coverage of all traffic. The same gate approaches threshold log rho_D,
and the new partition argument removes one logarithm from the R242
logarithmic-fourth price without tuning that gate again.

On the complementary original near source set, SR7 supplies a genuine
quadratic moment bound with its own m_p; no automatic root price for
all inputs is inferred. Low-pe and other mother-ledger branches remain.

## SR8. Actual finite mathematical diagnostics

Python/mpmath 1.3.0 at 70 digits was actually run on 36 general-p
infinite-series/cap and index-Holder costs and 12 genuine disjoint
two-dimensional receiver-column cases. The return was

    checks 48 A_bound_ratio 0.2599923715888647036045
    fee_ratio 0.2402649849344551748999
    partition_ratio 0.3554620920783753747191 PASS

These are local arithmetic/geometry diagnostics, not FULL histories or
interval certificates. The analytic inequalities above establish the
uniform result; no n-order is fitted to the data.

```python
import mpmath as m
m.mp.dps=70
checks=0;ma=m.mpf(0);mf=m.mpf(0);ms=m.mpf(0)
for n in [2,1000,1000000]:
    h=n*m.log(1+m.mpf(1)/n)
    for p in map(m.mpf,['0','.5','.9','.99']):
        t=1-p;b=(1+p)/2
        for r in map(m.mpf,['.05','.2','.5']):
            th=t*r/2;al=th/(1-r);k=1/r
            Msum=h**k*m.polylog(-k,m.exp(-b*h))+(1/(m.e*b*r))**k
            A=2*Msum/(1-m.exp(-t*h))
            bound=35/t*(4/(m.e*r))**k
            assert A<=bound*(1+m.mpf('1e-55'));ma=max(ma,A/bound)
            fee=(1+1/al)**(1-r)*A**r/4
            coarse=4/(t*r*r)
            assert fee<=coarse;mf=max(mf,fee/coarse);checks+=1
# Actual disjoint rectangles, legal a=1,b=2 hard radii, fixed z.
rects=[(-1,m.mpf('-.2'),1),(m.mpf('-.2'),m.mpf('.3'),m.mpf('1.5')),(m.mpf('.3'),1,2)]
zx=m.mpf('.1');zy=m.mpf('.2')
for p in map(m.mpf,['0','.5','.9','.99']):
    for r in map(m.mpf,['.05','.2','.5']):
        al=(1-p)*r/(2*(1-r));S=m.mpf(0)
        for l,u,R in rects:
            R=m.mpf(R)
            width=max(0,min(u,zx+R/2)-max(l,zx-R/2))
            height=max(0,min(1,zy+R/2)-max(-1,zy-R/2))
            O=width*height/R**2;S+=R**(-2*al)*O
        bound=1+(1-m.power(2,-2*al))/al
        assert S<=bound;ms=max(ms,S/bound);checks+=1
print('checks',checks,'A_bound_ratio',m.nstr(ma,22),'fee_ratio',m.nstr(mf,22),'partition_ratio',m.nstr(ms,22),'PASS')
```

No other file, Git operation, PDF or further exploratory task is part
of this bounded delivery.
