import sys,time,platform,json,hashlib,functools
from pathlib import Path
import sympy as sp,flint
from flint import arb,ctx
ctx.prec=256;START=time.monotonic();COMPARISONS=0
EMBEDDED_JSON='[{"L0_exact":"1/2 - sqrt(2)/4","N":2,"X_exact":"3/2 - sqrt(2)/4","masses":["1/2","1/2"],"name":"R540_two_source_contact","positions":[["0","0"],["sqrt(2)/4 + 1/2","0"]],"roots":[{"mask":1,"mass":"1/2","w_exact":"1/2"},{"mask":2,"mass":"1/2","w_exact":"1/2"},{"mask":3,"mass":"1","w_exact":"1/2 - sqrt(2)/4"}],"source_capture_label_unique":true,"source_grid_shape":[3,3],"source_occupied_cells":5},{"L0_exact":"-1023*sqrt(15)/100000 - 3069*sqrt(10)/500000 + 123783/500000","N":3,"X_exact":"-sqrt(15)/40 - sqrt(10)/100 + 2033/2000","masses":["2/5","3/10","3/10"],"name":"asymmetric_three_source","positions":[["0","0"],["2/5","1/50"],["9/20","7/100"]],"roots":[{"mask":1,"mass":"2/5","w_exact":"1/5 - sqrt(10)/100"},{"mask":6,"mass":"3/5","w_exact":"61/200 - sqrt(15)/40"},{"mask":7,"mass":"1","w_exact":"1023/2000"}],"source_capture_label_unique":true,"source_grid_shape":[12,12],"source_occupied_cells":121},{"L0_exact":"-60198517*sqrt(3)/84672000 - 861599*sqrt(21)/8467200 - 1908337*sqrt(10)/14112000 - 909217*sqrt(5)/9408000 - 107*sqrt(30)/7200 - sqrt(15)/480 + 551*sqrt(7)/70560 + 2287*sqrt(70)/705600 + sqrt(210)/288 + 29*sqrt(105)/2880 + 7902029*sqrt(6)/169344000 + 11876159*sqrt(14)/169344000 + 14551*sqrt(35)/225792 + 944353/2116800 + 10547503*sqrt(2)/28224000 + 403691*sqrt(42)/3386880","N":4,"X_exact":"-3*sqrt(3)/10 - 3*sqrt(14)/32 - sqrt(5)/8 - sqrt(35)/32 - sqrt(21)/32 - 9*sqrt(6)/160 + 3*sqrt(10)/160 + sqrt(2)/2 + 773/400","masses":["1/2","1/4","1/8","1/8"],"name":"four_source_multiscale","positions":[["0","0"],["13/20","1/20"],["3/4","2/5"],["-1/5","1/2"]],"roots":[{"mask":1,"mass":"1/2","w_exact":"-13*sqrt(10)/160 - sqrt(3)/8 - sqrt(6)/16 - sqrt(5)/16 + sqrt(35)/32 + sqrt(42)/32 + 37/160 + 23*sqrt(2)/80"},{"mask":2,"mass":"1/4","w_exact":"-9*sqrt(6)/80 - 3*sqrt(3)/20 + sqrt(21)/32 + sqrt(42)/32 + 257/800"},{"mask":3,"mass":"3/4","w_exact":"-sqrt(42)/16 - 249/800 + 3*sqrt(3)/80 + 31*sqrt(14)/160"},{"mask":4,"mass":"1/8","w_exact":"-sqrt(3)/16 + 1/16 + 7*sqrt(2)/80"},{"mask":6,"mass":"3/8","w_exact":"-sqrt(21)/16 - 1/25 + 7*sqrt(14)/160 + 19*sqrt(6)/160"},{"mask":7,"mass":"7/8","w_exact":"153/160 - 37*sqrt(14)/160"},{"mask":8,"mass":"1/8","w_exact":"-sqrt(5)/16 + 1/16 + sqrt(2)/8"},{"mask":9,"mass":"5/8","w_exact":"-sqrt(35)/16 - 1/80 + sqrt(14)/16 + sqrt(10)/10"},{"mask":11,"mass":"7/8","w_exact":"51/80 - 13*sqrt(14)/80"},{"mask":15,"mass":"1","w_exact":"1/40"}],"source_capture_label_unique":true,"source_grid_shape":[21,19],"source_occupied_cells":297},{"L0_exact":"-268334161264540289869*sqrt(14)/607162876276320000000 - 585372863301470951423*sqrt(6)/1691382298198320000000 - 446297744832287771*sqrt(3)/1204688246580000000 - 31908195415047044857*sqrt(26)/338276459639664000000 - 8433711942834739367/25693741509089062500 - 109893222787*sqrt(29)/2238531750000 - 503005821529*sqrt(2639)/100286222400000 - 61*sqrt(7917)/21168 - 6572335945051*sqrt(406)/585002964000000 - 4917802709*sqrt(78)/199311840000 - 810804606433*sqrt(42)/34879572000000 - 208202236615777*sqrt(93)/15318641754000000 - 137615187221*sqrt(754)/30085866720000 - 10614197*sqrt(2262)/4120900000 - 233232507301*sqrt(2418)/102124278360000 - 2131949297*sqrt(21)/95823000000 - 8509085269*sqrt(434)/1787174871300 - 11357*sqrt(18879)/19440000 - 155*sqrt(15834)/259584 - 15398060627*sqrt(273)/3487957200000 - 251719321*sqrt(2821)/204248556720 - 6018381*sqrt(6293)/7653100000 - 28125464558293*sqrt(62)/3574349742600000 - 216179*sqrt(1131)/146016000 - 144695081*sqrt(31)/17597925000 - 29132157811*sqrt(12586)/78557137200000 - 40133*sqrt(35061)/201840000 - 150441*sqrt(163618)/1749280000 - 27689*sqrt(1798)/42050000 - 9282625859*sqrt(174)/4450572000000 - 20654771054639*sqrt(899)/23828998284000000 - 970013*sqrt(5278)/3577392000 - 2880347*sqrt(5394)/13624200000 - 9955703*sqrt(806)/19639284300 - 173773603903*sqrt(403)/612745670160000 - 66838909*sqrt(91)/116265240000 - 113*sqrt(1209)/3888000 - sqrt(16926)/126360000 + 1697*sqrt(11687)/20184000 + 132349*sqrt(651)/157950000 + 98219*sqrt(23374)/655980000 + 43971662652363757*sqrt(13)/6443361135993600000 + 91469*sqrt(2697)/168200000 + 39370535237*sqrt(186)/13092856200000 + 87511*sqrt(609)/28224000 + 1643869265083*sqrt(87)/188036667000000 + 330564201089*sqrt(377)/66857481600000 + 41599*sqrt(1302)/12150000 + 37785413231*sqrt(217)/3927856860000 + 361976471*sqrt(1218)/67076100000 + 1004487511*sqrt(546)/93012192000 + 4885372354297704683*sqrt(58)/50596906356360000000 + 1820925011640009937*sqrt(203)/30358143813816000000 + 49302307239957954023*sqrt(39)/338276459639664000000 + 162385847520440099*sqrt(2)/233165467080000000 + 451619674136534463607*sqrt(7)/986639673949020000000 + 3006232688591866711*sqrt(182)/32216805679968000000","N":6,"X_exact":"-5*sqrt(3)/32 - 43*sqrt(14)/640 - 3*sqrt(93)/128 - 3*sqrt(78)/128 - sqrt(42)/32 - sqrt(62)/40 - 31*sqrt(13)/640 - 21*sqrt(6)/320 - 3*sqrt(7)/160 + 3*sqrt(26)/320 + 29*sqrt(2)/160 + 797/320","masses":["1/2","1/4","1/8","1/16","1/32","1/32"],"name":"six_source_multiscale","positions":[["0","0"],["3/5","0"],["4/5","1/10"],["1/10","3/5"],["13/20","2/5"],["9/10","3/5"]],"roots":[{"mask":1,"mass":"1/2","w_exact":"-3*sqrt(3)/20 - sqrt(6)/16 + 13*sqrt(2)/160 + 3*sqrt(13)/64 + sqrt(39)/32 + 39/160"},{"mask":2,"mass":"1/4","w_exact":"-13*sqrt(14)/160 - 199/1600 - 7*sqrt(6)/160 + 3*sqrt(26)/160 + sqrt(39)/64 + 3*sqrt(58)/160 + sqrt(203)/64"},{"mask":3,"mass":"3/4","w_exact":"-1493/3200 - sqrt(42)/32 - sqrt(39)/32 - 7*sqrt(2)/64 - sqrt(13)/160 + 3*sqrt(78)/128 + 5*sqrt(29)/128 + sqrt(203)/64 + sqrt(14)/16 + 91*sqrt(3)/640"},{"mask":4,"mass":"1/8","w_exact":"-19/128 - 3*sqrt(6)/80 - sqrt(26)/80 - sqrt(14)/64 - sqrt(3)/32 + sqrt(2)/20 + sqrt(39)/64 + sqrt(182)/128 + sqrt(7)/16"},{"mask":6,"mass":"3/8","w_exact":"-sqrt(39)/32 + sqrt(26)/80 + sqrt(6)/20 + 51/400"},{"mask":7,"mass":"7/8","w_exact":"-sqrt(203)/32 - sqrt(14)/40 + 79/400 + sqrt(58)/20"},{"mask":8,"mass":"1/16","w_exact":"1/16"},{"mask":9,"mass":"9/16","w_exact":"21/160 - 3*sqrt(13)/160"},{"mask":11,"mass":"13/16","w_exact":"-3*sqrt(78)/64 - sqrt(13)/16 + 9*sqrt(6)/80 + 301/800"},{"mask":16,"mass":"1/32","w_exact":"-3/32 - sqrt(26)/64 - sqrt(14)/128 - sqrt(13)/128 + sqrt(2)/20 + sqrt(7)/32 + sqrt(182)/128"},{"mask":19,"mass":"25/32","w_exact":"-5*sqrt(29)/128 - 15*sqrt(3)/128 - sqrt(58)/80 - 9*sqrt(6)/320 - 27/1600 + 7*sqrt(2)/64 + 3*sqrt(93)/128 + sqrt(899)/128"},{"mask":22,"mass":"13/32","w_exact":"-sqrt(182)/64 - 29/800 + sqrt(26)/160 + 9*sqrt(7)/80"},{"mask":23,"mass":"29/32","w_exact":"-9*sqrt(58)/160 - sqrt(899)/128 + sqrt(62)/40 + 789/1600"},{"mask":27,"mass":"27/32","w_exact":"-3*sqrt(93)/64 - 9*sqrt(6)/160 + 3*sqrt(62)/80 + 531/1600"},{"mask":31,"mass":"31/32","w_exact":"1159/1600 - 7*sqrt(62)/80"},{"mask":32,"mass":"1/32","w_exact":"1/32"},{"mask":54,"mass":"7/16","w_exact":"247/400 - 9*sqrt(7)/40"},{"mask":63,"mass":"1","w_exact":"1/25"}],"source_capture_label_unique":true,"source_grid_shape":[58,54],"source_occupied_cells":2583}]'
PROVENANCE={'source_filename': '/tmp/r546_flow_numeric.json', 'source_sha256': 'e64e82c1b4f49c616d2cce208e0b125f6475870992eb25b8ab0fc4ac780d3ca8', 'embedded_data_sha256': '32dc9e841ef9456dbfc57f1ee22463f1dff577812f721ef22a22d1b70d0d7b9e', 'provenance': 'Exact root-center areas copied from the four R546 complete Lebesgue receiving-grid inputs; no all-grid reconstruction rerun. Source states/root partition already verified there. Embedded inputs make this file self-contained.'}
DATA=json.loads(EMBEDDED_JSON)
assert hashlib.sha256(EMBEDDED_JSON.encode()).hexdigest()==PROVENANCE["embedded_data_sha256"]
def cmp(a, b):
    global COMPARISONS
    COMPARISONS += 1
    v = ev(a) - ev(b)
    if v > 0:
        return 1
    if v < 0:
        return -1
    if sp.simplify(a - b) == 0:
        return 0
    raise ArithmeticError(str(a - b))

def ev(e):
    e = sp.sympify(e)
    if e.is_Rational:
        return arb(int(e.p)) / int(e.q)
    if e.is_Add:
        return sum((ev(t) for t in e.args), arb(0))
    if e.is_Mul:
        a = arb(1)
        for t in e.args:
            a *= ev(t)
        return a
    if e.is_Pow:
        a, p = e.args
        if p.is_Rational:
            return ev(a).root(int(p.q)) ** int(p.p)
    raise ValueError(str(e))

def unique(v):
    a = sorted(v, key=functools.cmp_to_key(cmp))
    out = []
    for x in a:
        if not out or cmp(x, out[-1]) != 0:
            out.append(x)
    return out

def cert(v):
    v = sp.expand(v)
    return dict(exact=str(v), arb256=str(ev(v)), float=float(v))

def ex(v):return sp.expand(v)
def interval_sign(v):
 z=ev(v)
 if z>0:return 1
 if z<0:return -1
 assert sp.simplify(v)==0
 return 0

def solve(inp):
 N=inp['N'];m=list(map(sp.Rational,inp['masses']));w={r['mask']:sp.sympify(r['w_exact']) for r in inp['roots']};mass={r['mask']:sp.Rational(r['mass']) for r in inp['roots']};X=ex(sum(w.values()));assert ex(X-sp.sympify(inp['X_exact']))==0
 Di=[ex(sum(ws/mass[S] for S,ws in w.items() if S>>i&1)) for i in range(N)];order=sorted(range(N),key=functools.cmp_to_key(lambda i,j:cmp(Di[j],Di[i])));groups=[]
 for i in order:
  if not groups or cmp(Di[i],Di[groups[-1][0]])!=0:groups.append([i])
  else:groups[-1].append(i)
 prefixes=[0];mask=0
 for group in groups:
  for i in group:mask|=1<<i
  prefixes.append(mask)
 h=(arb(1)/(4*arb(2).sqrt())).exp();q=(-arb(2).sqrt()/4).exp();bound=2*q*ev(X);pairs=[]
 for S in sorted(w):
  for T in sorted(w):
   if mass[T]<=mass[S]:continue
   z=ev(sp.sqrt(mass[T]/mass[S]))-h
   if z<0:continue
   assert z>0
   inter=sum(m[i] for i in range(N) if S>>i&1 and T>>i&1);coef=ex(2*w[S]*w[T]/(mass[S]*mass[T]));pairs.append((S,T,inter,coef))
 L0=ex(sum(coef*i0*(1-i0/mass[T]) for S,T,i0,coef in pairs));assert ex(L0-sp.sympify(inp['L0_exact']))==0
 rows=[]
 for k,H in enumerate(prefixes):
  O=R=Scharge=sp.Integer(0);zero_mH=0
  for S,T,i0,coef in pairs:
   iH=sum(m[i] for i in range(N) if S>>i&1 and T>>i&1 and H>>i&1);mH=sum(m[i] for i in range(N) if T>>i&1 and H>>i&1)
   assert 0<=iH<=i0 and 0<=iH<=mH<=mass[T]
   O+=coef*iH;Scharge+=coef*iH*i0/mass[T]
   if mH:R+=coef*iH**2/mH
   else:assert iH==0;zero_mH+=1
  O,R,Scharge=map(ex,[O,R,Scharge]);L=ex(O-R);Tcharge=ex(O-Scharge);identity=ex(Tcharge-L-R+Scharge);assert identity==0
  diff=ex(Tcharge-L);absdiff=diff if interval_sign(diff)>=0 else -diff;gapR=bound-ev(R);gapS=bound-ev(Scharge);gapdiff=bound-ev(absdiff);gapT=ex(L0-Tcharge)
  assert interval_sign(R)>=0 and interval_sign(Scharge)>=0 and interval_sign(L)>=0 and interval_sign(Tcharge)>=0
  assert gapR>0 and gapS>0 and gapdiff>0 and interval_sign(gapT)>=0
  inside=[Di[i] for i in range(N) if H>>i&1];outside=[Di[i] for i in range(N) if not H>>i&1]
  interval=dict(lower_inclusive=cert(max(outside,key=functools.cmp_to_key(cmp))) if outside else None,upper_exclusive=cert(min(inside,key=functools.cmp_to_key(cmp))) if inside else None,unbounded_below=not outside,unbounded_above=not inside,convention='H={i:D_i>t}; t in [max_excluded_D,min_included_D), with missing endpoints infinite.')
  rows.append(dict(prefix_index=k,H_mask=H,H_sources_zero_based=[i for i in range(N) if H>>i&1],strict_threshold_interval=interval,O_H=cert(O),R_H=cert(R),L_H=cert(L),S_H=cert(Scharge),T_H=cert(Tcharge),T_minus_L=cert(diff),R_minus_S=cert(ex(R-Scharge)),identity_residual_exact=str(identity),L0_minus_T_H=cert(gapT),zero_mH_pair_count=zero_mH,arb256_checks=dict(R_nonnegative=True,S_nonnegative=True,two_q_X_minus_R=str(gapR),two_q_X_minus_S=str(gapS),two_q_X_minus_abs_T_minus_L=str(gapdiff),R_and_S_at_most_two_q_X=True,abs_T_minus_L_at_most_two_q_X=True,T_at_most_L0=True)))
 print(inp['name'],'prefixes',len(rows),'Dgroups',groups,'Rmax',max(r['R_H']['float'] for r in rows),'Smax',max(r['S_H']['float'] for r in rows),'diffmax',max(abs(r['T_minus_L']['float']) for r in rows),flush=True)
 return dict(name=inp['name'],N=N,positions=inp['positions'],masses=inp['masses'],source_grid_shape=inp['source_grid_shape'],source_occupied_cells=inp['source_occupied_cells'],root_center_areas=inp['roots'],X=cert(X),D_i=[cert(v) for v in Di],descending_load_tie_groups_zero_based=groups,prefix_count=len(rows),same_parent_separated_pair_count=len(pairs),L0=cert(L0),two_q_X_arb256=str(bound),prefixes=rows,full_prefix_equalities=dict(O_full_minus_R_full_equals_L0=ex(sp.sympify(rows[-1]['L_H']['exact'])-L0)==0,R_full_equals_S_full=rows[-1]['R_H']['exact']==rows[-1]['S_H']['exact'],T_full_equals_L0=ex(sp.sympify(rows[-1]['T_H']['exact'])-L0)==0))
results=[solve(inp) for inp in DATA]
out=dict(command=sys.executable+' '+str(Path(__file__).resolve()),versions=dict(python=platform.python_version(),sympy=sp.__version__,python_flint=flint.__version__),precision_bits=256,seed=None,constants=dict(h='exp(1/(4*sqrt(2)))',q='exp(-sqrt(2)/4)',lambda_value=1),total_true_threshold_prefixes=sum(r['prefix_count'] for r in results),input_provenance=PROVENANCE,scope='Four R546 existing exact continuous-center root-area inputs, no new geometry, no receiving-grid rerun, no scan. Only genuine H={D>t} prefixes that never split tied loads, including empty/full. Parent pairs are the same complete scale-separated positive upper envelope, not exact original core.',definitions='lambda=1; VB=mS, VC=mT; i0=mass(S intersect T), iH=mass(S intersect T intersect H), mH=mass(T intersect H). O=2 sum wS*wT*iH/(mS*mT); R=2 sum wS*wT*iH^2/(mH*mS*mT), 0/0=0; Scharge=2 sum wS*wT*iH*i0/(mS*mT^2); L=O-R; T=O-Scharge.',normalization_bridge_scope='Finite exact verification of T-L=R-S, 0<=R,S<=2qX, |T-L|<=2qX, T<=L0. This does not pay the remaining main quantity T or establish a new Acore estimate; the analytical normalized replacement is handled by the main proof.',algebraic_comparisons=COMPARISONS,elapsed_seconds=time.monotonic()-START,results=results)
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2))
