# R273 independent high-gate screen

**Verdict: PASS for the algebra and PASS for the original qualification, provided high is retained from the original mother quantity before source Cauchy.** This is not a post hoc constraint on R272's already enlarged A_theta. Q remains unpaid. This screen preceded author-proof reading.

Authoritative R272 frozen main read/bound:
`/Users/zhengzhihao/Desktop/T/output/centered_cube_round272_20261017_final_checkpoint/proof.tex.txt`
SHA256 `f24fdeab20327988094c4b96f8ad45be1f3d4d5eccde8d1ba295afac0c9182eb`.

## 1. Original terminal-high qualification

The necessary original snippets were directly read:

- R128 `proof.md`, lines 604–626: actual mother measure and original positive remainder retain 1_(A_hi) outside the clock, with both original posteriors and their original carriers.
- R223 frozen `negative_contract.md`, lines 7–14: common high indication belongs to the actual row; positive and negative ledgers must not be interchanged.
- R222 frozen `source_occupancy.md`, lines 37–52: high and actual j/clock/history are retained within the original hard conditional average; they are not free after it has been enlarged to one.
- R224 frozen `traffic_reentry.md`, lines 35–45, especially line 41: the original high condition is explicitly p_y(x)e_g(y)≥2Kq, not merely a bound at some other clock time. Same-x FIRST is integral p_y β≤q. Its lines 39–40 retain common-leaf receiver accounting and unique j.
- R259 frozen `source_bridge.md`, lines 43–51: independently records the same terminal high gate and e_t≥e_g for legal t≤g.

The terminal hard gate z∈Z_g and near-weight bound remain the R271/R272 original qualifications, established from R114 S4; near alone does not produce that gate. Source FIRST needs only ρ≤β≤α≤f. The hard cap uses ν≤f separately, and no ν≤β premise is needed.

## 2. The mixed high/degree cap

At fixed actual x,y,j, keep high and the terminal-supported raw near hard density H from R272. On the nonzero response e_g>0. With eta=1−d/(2b),

    theta=eta R^n H J_e≤eta R^n H/e_g,
    (H/R^n)theta≤eta H²/e_g
       ≤eta H²p_y/(2Kq)
       ≤[8eta/(3K)] H p_y.                         (H1)

The final step uses H≤(16/3)q. The H=0 response is zero before any degree division. The inequality holds on core and halo alike: it does not require x∈Q_R(y). The physical R factor has been removed by the actual degree/terminal-high comparison, not a guessed window enlargement.

One must return to the original high mother quantity (or an upper expression that still explicitly retains high). Repeating the original source Cauchy with 1_high gives the sharpened residual A_(theta,hi). It is not legitimate to take R272's source-expanded A_theta and assert that all its added y values satisfy high. Other positive capture/history indicators may be kept or positively removed only after preserving the hypotheses used in (H1). The complete original posterior law and time-static actual target kernels remain unchanged.

## 3. Anchor relocation and the proposed X-price

Set delta=3d/b≤3/(8sqrt(n)), delta'=exp(delta)−1. The already screened pure-loss transfer gives

    T_y≤exp(delta)T_z^0+3q delta',
    Q=E sum_V integral_E integral ν(dz)h_(R(x))(x−z)T_z^0(x)dx.

The 3q is the original actual future-FIRST cap on the three target kernels, including J=P_(1,b); it is not a cap at replacement soft nodes. Apply (H1), enlarge the terminal/near gates positively as needed, and use source FIRST integral p_y ρ≤q. The main term is bounded by

    A_(theta,hi),main≤[8eta q/(3K)]exp(delta) Q.       (H2)

For the additive error, H≤4lambda and the same source FIRST give

    A_error≤[8eta/(3K)]·3q delta' integral_E integral p_y H dρ dx
           ≤[32eta lambda q²/K]delta' |E|.          (H3)

The common original leaf receiver qualification is retained when summing this volume. One original Young inequality, with the R272 exterior Lambda²K/(eta q lambda epsilon), gives exactly

    Pρ≤[epsilon+32Lambda²delta'/epsilon]X
          +[8Lambda²exp(delta)/(3lambda epsilon)]Q.  (H4)

The error coefficient uses q≤lambda, and all K/eta/q cancellations are correct. The displayed extra X coefficient must be kept as written; it is not automatically the same epsilon X for an arbitrary fixed n and arbitrarily small epsilon. Any later small-X absorption must state its dimension/error choices. No negative credit is used.

## 4. Stronger genuine source price for the additive error

There is a stronger alternative to (H3), also valid without a common-core restriction. Enlarge H by (h_R*ν)(x), which is independent of y. Then

    integral p_y H dρ≤q(h_R*ν)(x),
    A_error≤[8eta q²/K]delta' integral_E(h_(R(x))*ν)(x)dx.

The same actual R(x) lies in [a,b]. Its true Lebesgue adjoint envelope is

    sup_(a≤R≤b) h_R(u)
      =a^(−n) if 2||u||∞≤a,
       (2||u||∞)^(−n) if a<2||u||∞≤b,
       0 otherwise.

Its exact integral is 1+nlog(b/a): the core contributes one and the radial shell contributes integral_a^b n dr/r. Tonelli therefore proves

    A_error≤[8eta q²/K]delta'[1+nlog(b/a)] Wν.         (H5)

This is a real adaptive-scale price, not the false assertion integral h_(R(x))(x−z)dx≤1. On summing leaves, ν is the original hard source once per leaf; no j menu is replicated. Substitution after the same single Young bound yields

    Pρ≤epsilon X+[8Lambda²exp(delta)/(3lambda epsilon)]Q
        +[8Lambda²(q/lambda)/epsilon]
             delta'[1+nlog(b/a)] Wν.                (H6)

For all n≥1, q≤lambda and b/a≤2,

    8(q/lambda)delta'[1+nlog(b/a)]
      ≤3exp(3/8)(1+log2)sqrt(n).

Hence the additive relocation error has a genuine root-order original Wν source price. It no longer requires the X-error absorption in (H4). These are alternative bounds on the same error, not two costs that should both be charged.

The original hard-source mass can be compared further only on its actual ledger. R224 `traffic_reentry.md`, line 46, explicitly documents the disjoint terminal-leaf support and ν_V≤1_V f, hence Wν≤||f||_1 for that same leaf family. This uses actual source support rather than ν≤β. Q still retains the two raw hard sources, the actual selectors and pure-loss ratio, and has not been bounded by this calculation. No general closure follows.

## 5. Auxiliary time-high variant (not needed to identify the original gate)

The directly checked original gate is terminal-high. Independently, if a different application has only a time gate 1_{p_y e_t≥2Kq}, then the corresponding continuous inverse-degree integral is at most p_y/(2Kq): its pushed-forward variable 1/e_t only traverses the interval up to that cap, while deletions remove intervals. This proves an analogous high-restricted-clock bound, including jumps over the threshold. It must be built from that original time-high gate, not retrofitted to a gate-dropped residual. It does not replace the original terminal gate used above.

## 6. Actually executed bounded arithmetic check

Executed 36 exact Fraction configurations of the mixed high/terminal-degree cap, including varying q,K,p_y,H, and both exterior cancellations. This is algebra evidence, not actual FIRST/cube/FULL certification. Code:

```python
from fractions import Fraction as F
eta=F(15,16);lam=F(1);checks=0
for q in (F(3,4),F(7,8),F(1)):
    for K in (F(1),F(4)):
        for py in (F(1),F(2)):
            for H in (F(1,2),F(2),F(4)):
                eg=max(eta*H,2*K*q/py);e0=2*eg
                Je=1/eg-1/e0;theta=eta*H*Je
                assert H*theta<=F(8,3)*eta/K*H*py
                base=K/(eta*q*lam)
                assert base*(F(8,3)*eta*q/K)==F(8,3)/lam
                assert base*(32*eta*lam*q*q/K)==32*q
                checks+=1
print('PASS',checks,'exact high-gate mixed-cap and exterior-cancellation configurations')
```

# Addendum: exact inherited loading rather than discarding all anchor geometry

**Independent verdict: PASS.** This statement was screened before reading any author proof.

On an actual terminal-high, nonzero valid row define

    chi(x,y)=3K H(x,y)J_e(x,y)/(8p_y(x)).

Set chi=0 on rows outside high, on H=0/empty clock and other invalid zero-response rows, before division. High has p_y>0 and e_g>0. There is an exact factorization

    chi=[3H/(16q)] [2Kq/(p_y e_g)] [e_g J_e] in [0,1].   (L1)

The three bounds use respectively H≤(16/3)q, original terminal-high, and the exact continuous inverse-degree ledger. More strongly, e_gJ_e≤1−e_g/e_tau. The useful source conversion is the exact identity

    (H/R^n)theta=[8eta/(3K)]H p_y chi.                  (L2)

This retains the data discount; replacing chi by one is only a subsequent upper bound.

At the same actual receiver selector define the inherited loading

    ell(x,z)=q^(-1) integral ρ(dy)p_y(x)chi(x,y)1_high
                       1_{||y−z||_1≤d/2}1_(Z_g(y))(z).

It obeys 0≤ell≤q^(-1)integral p_yρ≤1. It may depend on x, the original seed/leaf, actual j,g,L,R,s, the full ν-based degrees, and K. This causes no independence problem: it is an inherited measurable edge weight, not a newly frozen source measure or a posterior law. Original finite-tree/raw-process measurability supplies the ordinary Tonelli hypotheses.

Expand the exact H in (L2), then apply the one-logLip anchor bound to Phi_y. Since the actual T_z^0 depends on z and x but not on y after that transfer, positive Tonelli gives

    A_(theta,hi)≤[8eta q/(3K)]
                   [exp(delta) Q_ell+3q delta' L_ell],   (L3)

    L_ell=E sum_V integral_E integral ν(dz)h_(R(x))(x−z)ell(x,z)dx,
    Q_ell=E sum_V integral_E integral ν(dz)h_(R(x))(x−z)ell(x,z)
                        integral K_Sigma(x,v)Phi_(z,c_jg)(v)ν(dv)dx.

The high, near and terminal-source gates stay inside ell. There is no assumption x∈Q_R(y), so core and halo are handled together at this step. All original actual selectors in the two integrals are the same; no pointwise sourcewise new selector is chosen.

As ell≤1,

    L_ell≤[1+nlog(b/a)]Wν,   Q_ell≤Q.

After the single original source Cauchy/Young estimate, the exact coefficients therefore are

    Pρ≤epsilon X+[8Lambda²exp(delta)/(3lambda epsilon)]Q_ell
          +[8Lambda²(q/lambda)/epsilon]
                    delta'[1+nlog(b/a)]Wν.              (L4)

This improves the unweighted Q by an honest inherited loading, and the error is a genuine root-order hard-source fee as in (H6). There is still no bound proved for Q_ell. K cancels from the **explicit exterior coefficients**, but remains in chi, high and ell, and potentially in the selected remaining class. Thus Q_ell is not certified independent of K. Neither the loading nor its cap can be silently treated as a free fixed-source allocation or as a normalization/exchange of Π.

Actually checked the factorization and exact identity (L2) on the same 36 Fraction parameter cases used above, with this additional executed code. These are algebra checks, not 36 new physical models.

```python
from fractions import Fraction as F
eta=F(15,16);checks=0
for q in (F(3,4),F(7,8),F(1)):
    for K in (F(1),F(4)):
        for p in (F(1),F(2)):
            for H in (F(1,2),F(2),F(4)):
                eg=max(eta*H,2*K*q/p);Je=F(1,2)/eg
                chi=3*K*H*Je/(8*p)
                factors=(3*H/(16*q),2*K*q/(p*eg),eg*Je)
                assert all(0<=f<=1 for f in factors)
                assert chi==factors[0]*factors[1]*factors[2]
                assert eta*H*H*Je==F(8,3)*eta/K*H*p*chi
                checks+=1
print('PASS',checks,'exact loading-factor/identity checks on the same parameter family')
```
