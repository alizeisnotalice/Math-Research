#!/usr/bin/env python3
"""R273 bounded exact loading/interface arithmetic; not physical FULL."""
import argparse,hashlib,json
from fractions import Fraction as F
from pathlib import Path

def sf(x):return str(F(x))
def check(N,stage,n,eta,K,q):
 Y={2:3,4:4,8:5}[N];R=F(3,2);Rn=R**n
 nu=[F(z+1,N*(N+1)) for z in range(N)];h=[1/Rn]*N
 terminal=[int(z%3!=2) for z in range(N)]
 near=[[int((y+z)%3!=0) for z in range(N)] for y in range(Y)]
 gate=[[near[y][z]*terminal[z] for z in range(N)] for y in range(Y)]
 P=[F(y+1,Y*(Y+1)) for y in range(Y)];assert sum(P)==F(1,2)<=1
 p=[F(y+1,3) for y in range(Y)];T=[F(y+2,5) for y in range(Y)]
 H=[sum(h[z]*nu[z]*gate[y][z] for z in range(N)) for y in range(Y)]
 eg=[max(eta*Rn*H[y],2*K*q/p[y]) for y in range(Y)]
 Je=[1/(2*e) for e in eg];rho=[q*P[y]/p[y] for y in range(Y)]
 chi=[3*K*H[y]*Je[y]/(8*p[y]) for y in range(Y)]
 rows=[]
 for y in range(Y):
  factors=[3*H[y]/(16*q),2*K*q/(p[y]*eg[y]),eg[y]*Je[y]]
  assert all(0<=v<=1 for v in factors) and factors[0]*factors[1]*factors[2]==chi[y]
  assert H[y]<=16*q/3 and eta*Rn*H[y]<=eg[y] and p[y]*eg[y]>=2*K*q
  assert p[y]*rho[y]==q*P[y]
  rows.append({'y':y,'P':sf(P[y]),'p':sf(p[y]),'rho':sf(rho[y]),'T':sf(T[y]),'H_from_same_gate':sf(H[y]),'e_g':sf(eg[y]),'J_e':sf(Je[y]),'chi':sf(chi[y]),'three_factors':list(map(sf,factors)),'three_factor_product':sf(factors[0]*factors[1]*factors[2])})
 loading=[sum(P[y]*chi[y]*gate[y][z] for y in range(Y)) for z in range(N)];assert all(0<=ell<=1 for ell in loading)
 theta=[eta*Rn*H[y]*Je[y] for y in range(Y)]
 original=sum(rho[y]*(H[y]/Rn)*theta[y]*T[y] for y in range(Y))
 expanded=8*eta*q/(3*K)*sum(h[z]*nu[z]*sum(P[y]*chi[y]*gate[y][z]*T[y] for y in range(Y)) for z in range(N))
 direct_H=sum(eta*rho[y]*H[y]**2*Je[y]*T[y] for y in range(Y));assert original==expanded==direct_H
 return {'stage':stage,'source_count':N,'receiver_slots':Y,'n':n,'eta':sf(eta),'K':sf(K),'q':sf(q),'R':sf(R),'nu':list(map(sf,nu)),'h':list(map(sf,h)),'near':near,'terminal':terminal,'gate_near_times_terminal':gate,'FIRST_P_sum':sf(sum(P)),'FIRST_p_rho_sum':sf(sum(p[y]*rho[y] for y in range(Y))),'loading_by_source':list(map(sf,loading)),'max_loading':sf(max(loading)),'receiver_rows':rows,'Ahi_original':sf(original),'Ahi_expanded_loading':sf(expanded),'Ahi_expanded_H_square':sf(direct_H),'identity_residual_exact':sf(original-expanded)}

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));args=parser.parse_args()
 rows=[check(2,'initial',2,F(15,16),F(256),F(1)),check(4,'stress',8,F(31,32),F(4096),F(3,2)),check(8,'expanded',32,F(63,64),F(512),F(2))]
 out={'schema':'R273-exact-loading-v1','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'counts':{'source_models':3,'stage_models':{'initial':1,'stress':1,'expanded':1},'receiver_factor_checks':sum(r['receiver_slots'] for r in rows),'source_loading_checks':sum(r['source_count'] for r in rows),'Ahi_identities':3},'cases':rows,'scope':['Pure exact Fraction interface arithmetic, not actual geometric FIRST/high/source/history/FULL qualifications. h_z,nu_z are rational common slots, and H_y uses the identical near/terminal gate matrix in all expressions.','P weights total1/2, rho_y=qP_y/p_y, hence sum p_y rho_y=q/2<=q. chi is the product of three displayed factors each<=1.','J_e=1/(2e_g),a strict boundary relaxation rather than a claimed finite-clock realization. n,R are retained in theta=eta R^n H J_e and cancel in the displayed Ahi identity.','Ahi_original=sum rho_y (H_y/R^n)theta_y T_y; expanded=(8eta q/(3K))sum_z h_z nu_z sum_y P_y chi_y gate_yz T_y. No payment of a dense complement or universal theorem inferred.']}
 args.output.write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps({'counts':out['counts'],'max_loadings':[r['max_loading'] for r in rows]}))
if __name__=='__main__':main()
