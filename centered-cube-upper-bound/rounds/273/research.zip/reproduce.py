#!/usr/bin/env python3
"""Verify hashes, replay the readable exact audit, and replay finite checks."""
import argparse, hashlib, json, re, subprocess, sys, tempfile
from pathlib import Path

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--check-only',action='store_true')
    args=ap.parse_args()
    root=Path(__file__).resolve().parent
    manifest=json.loads((root/'manifest.json').read_text())
    for name,value in manifest['sha256'].items():
        assert sha(root/name)==value, name
    print('PASS manifest hashes')
    blocks=re.findall(r'```python\n(.*?)```',(root/'screen.md').read_text(),re.S)
    assert len(blocks)==2
    for code in blocks:
        exec(compile(code,'screen.md','exec'),{'__name__':'__main__'})
    if args.check_only:
        return
    with tempfile.TemporaryDirectory(prefix='r273-replay-') as temp:
        for stem in ['numeric_checks','loading_checks']:
            out=Path(temp)/(stem+'.json')
            subprocess.run([sys.executable,str(root/(stem+'.py')),'--output',str(out)],check=True)
            assert out.read_bytes()==(root/(stem+'.json')).read_bytes(),stem
            print('PASS byte-identical replay',stem)

if __name__=='__main__':
    main()
