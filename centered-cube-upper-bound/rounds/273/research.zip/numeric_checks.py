#!/usr/bin/env python3
"""R273 exact high/hard interface and ordinary scalar price arithmetic."""
import argparse,hashlib,json
from pathlib import Path
from fractions import Fraction as F
import mpmath as mp

def enc(x):return mp.nstr(x,100)
def mm(x):
 x=F(x);return mp.mpf(x.numerator)/x.denominator

def exact():
 rows=[]
 for idx,n in enumerate([1,8,64,512]):
  for profile in ['saturated_high','hard_dominant','zero_H','zero_Je']:
   q=[F(1,1000),F(1),F(10**6),F(3,2)][idx];K=[F(1),F(256),F(4096),F(256)][idx];p=F(1);eta=[F(1,2),F(7,8),F(1),F(1,2)][idx];R=F(1) if profile=='saturated_high' else F(3,2)
   H=F(0) if profile=='zero_H' else 16*q/3 if profile=='saturated_high' else 4*q/3
   eg=max(2*K*q/p,eta*R**n*H);Je=F(0) if profile=='zero_Je' else 1/eg;theta=eta*R**n*H*Je
   assert p*eg>=2*K*q and eta*R**n*H<=eg and H<=16*q/3 and Je<=1/eg and 0<=theta<=1
   lhs=(H/R**n)*theta;rhs=8*eta/(3*K)*H*p;assert lhs<=rhs
   rows.append({'stage':'initial' if n<=8 else 'stress' if n==64 else 'expanded','n':n,'profile':profile,'q':str(q),'K':str(K),'p':str(p),'eta':str(eta),'R':str(R),'H':str(H),'e_g':str(eg),'J_e':str(Je),'theta_eta_Rn_H_Je':str(theta),'high_margin':str(p*eg-2*K*q),'hard_support_margin':str(eg-eta*R**n*H),'source_H_cap_margin':str(16*q/3-H),'lhs_exact':str(lhs),'rhs_exact':str(rhs),'margin_exact':str(rhs-lhs)})
 return rows

def numeric(dps):
 with mp.workdps(dps):
  Lam=mp.mpf(128)/119;rows=[];rho_menu=[F(0),F(1,10**6),F(1,100),F(1,10)]
  for n in [1,8,64,512,4096,65536,10**6,10**8]:
   delta=3/(8*mp.sqrt(n));A=32*Lam**2*mp.expm1(delta);B=8*Lam**2*mp.exp(delta)/3;eps=mp.sqrt(A)
   rootfee=8*Lam**2*mp.expm1(delta)*(1+n*mp.log(2))/mp.sqrt(n)
   options=[]
   for rhoF in rho_menu:
    rho=mm(rhoF);combined=A+B*rho;e=mp.sqrt(combined);opt=2*e
    assert abs(e+combined/e-opt)<mp.mpf('1e-40')
    options.append({'rho_Q_over_lambda_X_exact':str(rhoF),'epsilon_optimal_unconstrained':enc(e),'epsilon_less_than_one':e<1,'minimal_total_coefficient':enc(opt),'absorbs_below_one':opt<1,'absorption_margin':enc(1-opt)})
   rows.append({'stage':'initial' if n<=64 else 'stress' if n<=65536 else 'expanded','n':n,'delta':enc(delta),'A_32Lambda2_expm1delta':enc(A),'B_8Lambda2_expdelta_over3':enc(B),'epsilon_X_optimal':enc(eps),'X_coefficient_at_optimum':enc(2*eps),'remaining_Q_coefficient_times_lambda':enc(B/eps),'X_coefficient_absorbs_below_one':2*eps<1,'root_source_error_coefficient_q_over_lambda1':enc(rootfee),'root_source_error_formula':'8 Lambda^2 (q/lambda) expm1(delta) (1+n log2)/sqrt(n)','combined_options':options})
  thresholds=[]
  for rhoF in rho_menu:
   rho=mm(rhoF);limit=mp.mpf(3)/(32*Lam**2)
   if rho>=limit:
    thresholds.append({'rho_exact':str(rhoF),'possible_absorption_for_some_finite_n':False,'strict_rho_limit':enc(limit)});continue
   dstar=mp.log((32*Lam**2+mp.mpf('.25'))/(32*Lam**2+8*Lam**2*rho/3));critical=(3/(8*dstar))**2;nmin=int(mp.floor(critical))+1
   def cost(n):
    d=3/(8*mp.sqrt(n));return 2*mp.sqrt(32*Lam**2*mp.expm1(d)+8*Lam**2*mp.exp(d)*rho/3)
   assert cost(nmin)<1 and (nmin==1 or cost(nmin-1)>=1)
   thresholds.append({'rho_exact':str(rhoF),'possible_absorption_for_some_finite_n':True,'delta_strict_upper':enc(dstar),'real_n_strict_lower':enc(critical),'first_integer_n_with_total_coefficient_below_one':nmin,'cost_at_nmin':enc(cost(nmin)),'cost_at_previous_n':enc(cost(nmin-1)) if nmin>1 else None})
  return {'Lambda':enc(Lam),'cases':rows,'absorption_thresholds':thresholds,'rho_limit_exact':str(F(3,32)/F(128,119)**2)}

def fields(obj,path=''):
 out={}
 if isinstance(obj,dict):
  for k,v in obj.items():
   if isinstance(v,str) and not k.endswith('_exact') and k not in ['stage','root_source_error_formula']:
    try:out[path+k]=mp.mpf(v)
    except ValueError:pass
   elif isinstance(v,(dict,list)):out.update(fields(v,path+k+'/'))
 elif isinstance(obj,list):
  for i,v in enumerate(obj):out.update(fields(v,path+str(i)+'/'))
 return out

def main():
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));args=p.parse_args();ex=exact();lo=numeric(50);hi=numeric(80)
 with mp.workdps(120):
  x=fields(lo);y=fields(hi);assert x.keys()==y.keys();diff={k:abs(x[k]-y[k])/max(1,abs(y[k])) for k in x};worst=max(diff,key=diff.get);md=enc(diff[worst]);assert diff[worst]<mp.mpf('1e-42')
 out={'schema':'R273-interface-price-v1','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'counts':{'exact_high_hard_cases':len(ex),'scalar_dimension_cases_per_precision':8,'scalar_stages':{'initial':3,'stress':3,'expanded':2},'epsilon_optimization_cases_per_precision':32,'absorption_threshold_cases_per_precision':4,'precision_fields_compared':len(diff)},'exact_cases':ex,'mp50':lo,'mp80':hi,'precision_max_relative_difference':md,'precision_worst_field':worst,'scope':['theta is specifically eta R^n H J_e, not a free gate. Exact rational cases preserve high, hard-support, H cap and J_e assumptions; no claim those assumptions arise from an original geometric input.','Scalar inequality prices use Lambda128/119,delta3/(8sqrt n),a1,b/a2. epsilon optimization is unconstrained positive; epsilon<1 and coefficient<1 qualifications are separately reported.','The combined epsilon table sets rho=Q/(lambda X) with X>0. Root-source-error coefficient sets q/lambda1; the general factor q/lambda remains displayed. No source functional or FULL model is constructed.','50/80 ordinary mpmath and integer thresholds are arithmetic diagnostics, not directed intervals, universal finite-n proof, or fitted dimension-order evidence. Dense complement and other original budgets are not certified.']}
 args.output.write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps({'counts':out['counts'],'maxdiff':md,'worst':worst}))
if __name__=='__main__':main()
