# R273 final independent integration audit

**Verdict: PASS. No necessary mathematical correction found in the reviewed main proof.** The all-near anchor-relocation error has the stated root-order original hard-source price. The loaded principal quantity Q_ell is still unproved and no general closure is certified.

Reviewed main: `/tmp/r273_proof.tex.txt`

SHA256: `18ef07f72c391df3f98528be1fb47ebb41caa1889d16b7feaaa4a2aef32f99de`.

Independent pre-author statement screen: `/tmp/r273_screen.md`, SHA256 `4c70c444419642d70015fbb3265a2d6f03547dfdddfb61e5ace3931c6a61f8a2`. The R272 frozen main SHA `f24fdeab20327988094c4b96f8ad45be1f3d4d5eccde8d1ba295afac0c9182eb` was independently checked for the inherited clock/source interface.

## Findings

1. **Original high and qualified rebuilding: PASS.** The main explicitly returns to the original positive mother with high intact and repeats the Cauchy step, rather than imposing high on R272's gate-dropped A_theta. Besides the directly read R224 TR1–2 and R259 source contract, this final review directly read R117 `joint_geometry.md` lines 34–54: JG4 line 42 defines the actual high gate p e_g≥2Kq, JG3/line 39 confirms the same actual three current/future targets, and JG5 retains that gate outside the auxiliary clock. The terminal degree is therefore the correct one. The original terminal hard-source carrier, complete Π law, source slots, history and good-upper-score orientation are not exchanged. Source FIRST uses ρ≤β≤α≤f; hard domination uses ν≤f separately, without needing ν≤β.

2. **Clock and exact loading, (2)–(6): PASS.** The inherited positive continuous inverse-degree ledger yields J_e≤1/e_g and theta=eta R^n H J_e≤1. On a legal high row p_y,e_g are positive. The loading factorization

       chi=[3H/(16q)] [2Kq/(p_y e_g)] [e_gJ_e]

   is exact and all three factors lie in [0,1]. Zero-response/invalid rows are handled before division and set to zero; no 0 times infinity is evaluated. The equality (H/R^n)theta=(8eta/(3K))H p_y chi has the right physical powers and is valid without a common-core condition. Expanding the same original H gives the displayed ell, with 0≤ell≤1 by the correct source-FIRST slot. Its dependence on receiver x,j,g, sources, K and actual terminal gates is honestly retained; it is not a new posterior or a fixed source allocation.

3. **One original Young step: PASS.** Three target terms cost three; clock Cauchy costs one. The exterior 2Lambda sqrt(K/3), source Cauchy and common-leaf receiver budget give exactly Lambda²K/(eta q lambda epsilon)A_hi in (3). The actual j mask is used pointwise and creates no j count. Core, halo and target terms are not each charged another epsilon X. No original signed negative credit is spent.

4. **All-near transfer and coefficients, (7)–(8): PASS.** The clipped-log pure ratio is one-Lipschitz in log C, so the near anchor displacement costs one logLip6 and delta=3d/b, not a comparison of two independently moved weights. D_Z/w_g≤Phi remains valid for removed target sources. Actual future FIRST gives the target sum cap 3q, including J=P_(1,b), with no auxiliary-node FIRST. Tonelli then yields precisely

       A_hi≤(8eta q/(3K))[exp(delta)Q_ell+3q(exp(delta)−1)L_ell].

   The loaded principal quantity includes the original near and terminal hard-source support through ell. No x∈Q_R(y) restriction is used, so the transfer covers halo too; this does not mean halo's principal traffic has been paid. The loading, and hence Q_ell, still depends on K even though K cancels in the explicit exterior coefficients.

5. **Real adaptive hard-source error budget, (9)–(12): PASS.** The true hard-envelope integral is exactly 1+nlog(b/a), from its full-side cube core plus n dr/r shell. This correctly accounts for receiver-dependent R(x); it is not the false unit adjoint normalization. Together with ell≤1 and the original once-per-leaf hard source, it gives L_ell≤N_n W_nu. The alternative 4X bound uses original hardband and common-leaf receiver disjointness and is correctly treated as an alternative estimate of the same error, not a second charge.

   Substitution in the one original Young estimate gives the exact (11) coefficients: 8Lambda² exp(delta)/(3lambda epsilon) for Q_ell and 8Lambda²(q/lambda)(exp(delta)−1)[1+nlog(b/a)]/epsilon for W_nu. All K/eta/q cancellations are correct. The inequality exp(delta)−1≤delta exp(delta), delta≤3/(8sqrt(n)) and q≤lambda yields the displayed bound 3exp(3/8)(1+log2)sqrt(n) for every n≥1. This pays the relocation error without any dimension-dependent X absorption. The original disjoint-leaf domination ν_V≤1_V f is precisely the provenance needed for the optional W_nu≤||f||_1 comparison; it is not copied to overlapping ancestors, j labels or arbitrary transported sources.

6. **Main scope and remaining global gap: PASS.** Q_ell≤Q is only a positive comparison, not a reason Q_ell is paid. A fixed-source/adaptive kernel column, ell≤1, or the absence of explicit K in a coefficient does not prove its required source total. The main keeps this sufficient budget unproved, permits retaining sharper D_Z where useful, and preserves all other original signed/source branches. No unverified tree/Carleson theorem is needed for the elementary proof actually given.

## Evidence boundary

The independent screen contains actually executed 36 Fraction mixed-high/exterior checks and further loading-factor identities on that same 36-parameter family, with code. They are bounded algebra checks, not additional physical/FULL instances. The final review read the complete hash-bound main and necessary original JG3–5 lines; it did not repeat physical numerical suites or modify any repository file.
