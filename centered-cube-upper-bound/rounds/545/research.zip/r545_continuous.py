import sys,time,platform,json,functools
from pathlib import Path
import sympy as sp,flint
from flint import arb,ctx
ctx.prec=256;START=time.monotonic();COMPARISONS=0

def ev(e):
 e=sp.sympify(e)
 if e.is_Rational:return arb(int(e.p))/int(e.q)
 if e.is_Add:return sum((ev(t) for t in e.args),arb(0))
 if e.is_Mul:
  a=arb(1)
  for t in e.args:a*=ev(t)
  return a
 if e.is_Pow:
  a,p=e.args
  if p.is_Rational:return ev(a).root(int(p.q))**int(p.p)
 raise ValueError(str(e))
def cmp(a,b):
 global COMPARISONS
 COMPARISONS+=1;v=ev(a)-ev(b)
 if v>0:return 1
 if v<0:return -1
 if sp.simplify(a-b)==0:return 0
 raise ArithmeticError(str(a-b))
def unique(v):
 a=sorted(v,key=functools.cmp_to_key(cmp));out=[]
 for x in a:
  if not out or cmp(x,out[-1])!=0:out.append(x)
 return out
def cert(v):
 v=sp.expand(v);return dict(exact=str(v),arb256=str(ev(v)),float=float(v))
def solve(name,x,w):
 x=[[sp.sympify(v) for v in p] for p in x];w=list(map(sp.Rational,w));N=len(w);rect=[];mass={}
 for S in range(1,1<<N):
  ids=[i for i in range(N) if S>>i&1];ms=sum(w[i] for i in ids);mass[S]=ms;half=sp.sqrt(ms)/2
  low=[max((x[i][j] for i in ids),key=functools.cmp_to_key(cmp))-half for j in range(2)];high=[min((x[i][j] for i in ids),key=functools.cmp_to_key(cmp))+half for j in range(2)]
  if all(cmp(high[j],low[j])>0 for j in range(2)):rect.append((S,low,high))
 edges=[unique([r[k][j] for r in rect for k in (1,2)]) for j in range(2)]
 def rank(v,j):return next(i for i,e in enumerate(edges[j]) if cmp(e,v)==0)
 ranks=[(S,[rank(low[j],j) for j in range(2)],[rank(high[j],j) for j in range(2)]) for S,low,high in rect]
 weights={};cells=[];capture_exclusion_checks=0;equal_root_ties=0
 for ix in range(len(edges[0])-1):
  for iy in range(len(edges[1])-1):
   covering=[S for S,lo,hi in ranks if lo[0]<=ix<hi[0] and lo[1]<=iy<hi[1]]
   if not covering:continue
   mmax=max(mass[S] for S in covering);best=[S for S in covering if mass[S]==mmax];equal_root_ties+=int(len(best)>1);assert len(best)==1;S=best[0];half=sp.sqrt(mass[S])/2
   lo=[edges[0][ix],edges[1][iy]];hi=[edges[0][ix+1],edges[1][iy+1]];outside=[]
   for i in range(N):
    if S>>i&1:
     # Entire cell closure lies in the center box capturing each selected source.
     assert all(cmp(lo[j],x[i][j]-half)>=0 and cmp(x[i][j]+half,hi[j])>=0 for j in range(2))
    else:
     # Center box that captures extra atom has no intersection with open cell.
     widths=[min([hi[j],x[i][j]+half],key=functools.cmp_to_key(cmp))-max([lo[j],x[i][j]-half],key=functools.cmp_to_key(cmp)) for j in range(2)];signs=[cmp(v,0) for v in widths];assert min(signs)<=0;capture_exclusion_checks+=1;outside.append(dict(source=i,intersection_width_signs=signs))
   cellarea=(hi[0]-lo[0])*(hi[1]-lo[1]);assert cmp(cellarea,0)>0;weights[S]=weights.get(S,0)+cellarea
   cells.append(dict(x_interval=[str(lo[0]),str(hi[0])],y_interval=[str(lo[1]),str(hi[1])],all_covering_witness_masks=covering,outermost_capture_mask=S,extra_source_exclusion=outside))
 weights={S:sp.expand(v) for S,v in weights.items()};X=sp.expand(sum(weights.values()));Di=[sp.expand(sum(v/mass[S] for S,v in weights.items() if S>>i&1)) for i in range(N)];A=sp.expand(sum(w[i]*Di[i]**2 for i in range(N)));Apair=0
 for S,ws in weights.items():
  for T,wt in weights.items():Apair+=ws*wt*sum(w[i] for i in range(N) if S>>i&1 and T>>i&1)/(mass[S]*mass[T])
 assert sp.simplify(A-Apair)==0
 h=(arb(1)/(4*arb(2).sqrt())).exp();q=(-arb(2).sqrt()/4).exp();pairs=[];Asep=R=0;ratio_checks=[]
 for S,ws in sorted(weights.items()):
  for T,wt in sorted(weights.items()):
   if mass[T]<=mass[S]:continue
   margin=ev(sp.sqrt(mass[T]/mass[S]))-h
   separated=bool(margin>0)
   assert separated or margin<0
   ratio_checks.append(dict(S=S,T=T,ratio_minus_h_arb256=str(margin),separated=separated))
   if not separated:continue
   overlap=sum(w[i] for i in range(N) if S>>i&1 and T>>i&1);aa=2*ws*wt*overlap/(mass[S]*mass[T]);rr=2*ws*wt*overlap**2/(mass[S]*mass[T]**2);Asep+=aa;R+=rr;pairs.append(dict(S=S,T=T,intersection_mass=str(overlap),Asep_term=cert(aa),R_term=cert(rr)))
 Asep=sp.expand(Asep);R=sp.expand(R);L=sp.expand(Asep-R);bound=2*q*ev(X);gap=bound-ev(R);assert gap>0
 return dict(name=name,N=N,positions=[[str(v) for v in p] for p in x],masses=[str(v) for v in w],positive_receiving_rectangles=len(rect),grid_shape=[len(e)-1 for e in edges],occupied_open_cells=len(cells),unique_maximum_witness_each_cell=equal_root_ties==0,extra_source_exclusion_check_count=capture_exclusion_checks,roots=[dict(mask=S,mass=str(mass[S]),radius=str(sp.sqrt(mass[S])),center_area=cert(v)) for S,v in sorted(weights.items())],X=cert(X),D_i=[cert(v) for v in Di],A=cert(A),A_pair_identity_residual=str(sp.simplify(A-Apair)),Asep=cert(Asep),R=cert(R),L=cert(L),separated_pair_count=len(pairs),separated_pairs=pairs,radius_ratio_classification=ratio_checks,R_bound=dict(two_q_X_arb256=str(bound),two_q_X_minus_R_arb256=str(gap),strictly_positive_gap=bool(gap>0)),exact_grid_cells=cells)
b=(1+sp.sqrt(sp.Rational(1,2)))/2
inputs=[('one_source',[[0,0]],[1]),('R540_two_source_contact',[[0,0],[b,0]],[sp.Rational(1,2)]*2),('asymmetric_three_source',[[0,0],[sp.Rational(2,5),sp.Rational(1,50)],[sp.Rational(9,20),sp.Rational(7,100)]],[sp.Rational(2,5),sp.Rational(3,10),sp.Rational(3,10)])]
results=[]
for args in inputs:
 r=solve(*args);results.append(r);print(r['name'],'cells',r['occupied_open_cells'],'X',r['X']['float'],'A',r['A']['float'],'R',r['R']['float'],'bound',r['R_bound']['two_q_X_arb256'],flush=True)
out=dict(command=sys.executable+' '+str(Path(__file__).resolve()),versions=dict(python=platform.python_version(),sympy=sp.__version__,python_flint=flint.__version__),precision_bits=256,seed=None,scope='Exactly three fixed existing two-dimensional inputs. Full Lebesgue center area partition by all positive-volume receiving rectangle endpoints, not finite center sampling, quadrature, weighted-center relaxation, or coefficient LP. All scale-separated ordered label pairs are included regardless of low overlap: this is the declared positive upper envelope of the original core.',constants=dict(h='exp(1/(4*sqrt(2)))',h_arb256=str((arb(1)/(4*arb(2).sqrt())).exp()),q='exp(-sqrt(2)/4)',q_arb256=str((-arb(2).sqrt()/4).exp())),proof_of_capture_label='For a maximal-mass covering S at y, any extra source captured by Q(y,sqrt(mS)) would make y belong to H_(S union extra), with strictly larger mass. Distinct equal-mass maximal witnesses likewise contradict maximality via their union. Grid boundaries have area zero; every open cell has one exact maximal capture label.',algebraic_comparisons=COMPARISONS,elapsed_seconds=time.monotonic()-START,results=results)
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2))
