#!/usr/bin/env python3
"""Reconstruct and check a selected profile; no batch runs by default."""
import os
for name in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[name]='1'
import argparse,hashlib,json,math,sys
from fractions import Fraction as F
from pathlib import Path
import profile,profile_dp
ROOT=Path(__file__).resolve().parent

def read():
 return sum((json.loads((ROOT/name).read_text())['cases'] for name in ('summary_512.json','summary_initial44.json')),[])
def source(case):
 if case['origin']=='canonical_control':
  ds=[((F(0),),F(4)),((F(1),),F(2)),((F(4),),F(4))]
  fs=[((F(-31,8),),(F(-29,8),),F(10)),((F(1,8),),(F(3,8),),F(16)),((F(29,8),),(F(31,8),),F(6)),((F(61,8),),(F(63,8),),F(10))]
 else:
  ds,fs=profile.mk(case['n'],case['N'],case['seed']);factor=F(case['centres_factor']);ds=[(tuple(v*factor for v in c),r) for c,r in ds]
 return ds,fs
def digest(ds,fs):
 d={'boxes':[{'center':list(map(str,c)),'radius':str(r)} for c,r in ds], 'source':[{'lo':list(map(str,l)),'hi':list(map(str,h)),'density':str(q)} for l,h,q in fs]}
 return hashlib.sha256(json.dumps(d,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--list',action='store_true',help='list recorded cases without solving');ap.add_argument('--seed',type=int,action='append',help='case seed (repeatable)');ap.add_argument('--origin',help='disambiguate repeated seed between initial runs');args=ap.parse_args();cases=read()
 if args.list:
  for c in cases:print(c['origin'],c['n'],c['N'],c['seed'],'connected='+str(c['connected']),'ratio='+repr(c['ratio']))
  return
 if not args.seed:ap.print_help();return
 for seed in args.seed:
  found=[c for c in cases if c['seed']==seed and (not args.origin or c['origin']==args.origin)]
  if len(found)!=1:raise SystemExit(f'seed {seed}: found {len(found)} cases; select --origin (see --list)')
  c=found[0];ds,fs=source(c);h=digest(ds,fs)
  if h!=c['input_sha256']:raise SystemExit('input hash mismatch: generator or runtime differs')
  # Cartesian-grid sizes over 5M use exactly equivalent mask DP, not a sampled cell set.
  engine=profile_dp if c['full_grid_cells']>5000000 else profile
  r=engine.calc(ds,fs,c['n'],seed)
  if r['status']!='complete':raise SystemExit(f"solver did not complete: {r['status']}")
  ok=all(math.isclose(r[k]['objective'],c[k],rel_tol=1e-8,abs_tol=1e-8) for k in ('P0','P1')) and F(r['M'])==F(c['M']) and F(r['receiver_union'])==F(c['V'])
  print(json.dumps({'seed':seed,'origin':c['origin'],'input_sha256':h,'P0':r['P0']['objective'],'P1':r['P1']['objective'],'M':r['M'],'V':r['receiver_union'],'ratio':r['ratio'],'patterns':r['patterns'],'status':'PASS' if ok else 'MISMATCH'},indent=2))
  if not ok:raise SystemExit(1)
if __name__=='__main__':main()
