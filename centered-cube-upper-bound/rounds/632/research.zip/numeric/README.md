# Reproducible finite same-source profile experiments

This bundle records the existing finite P0/P1 experiments. P0 minimizes a nonnegative source's total mass under true f(D_j) lower bounds; P1 additionally imposes the four true outer-box masses f((1+δ)D_j) as upper caps, δ=1/4,1/2,1,2. Sources are rational, possibly overlapping box-density mixtures; coordinates are not assumed independent. Receiver volume V is the union of D_j/a with a=max(2n,8). These numerical finite-profile results do not imply a canonical threshold or a general maximal-operator bound. Exact LP proofs are maintained separately by the certificate team.

`summary_512.json` contains all 512 expanded inputs and floating outputs (509 connected); `summary_initial44.json` records the original 44 runs, including one explicitly specified canonical control. Each record contains n, N, seed, source-generator hash, center scaling, input hash, connected status, P0, P1, M, V, constraints residuals, resources and incidence counts. `manifest.json` stores a SHA-256 digest for each bundle file and every reconstructed input. Multiple records can share a seed if they use different center scaling; use `--origin` to disambiguate.

The original `profile.py` already compressed source-region incidence patterns by intersecting per-axis masks and deduplicating. It had a conservative precondition rejecting full Cartesian grids above five million. `profile_dp.py` removes that gate, calls `dp_patterns.py` to retain positive-volume interval representatives, and aborts before solving if a per-worker pattern set exceeds one million. The compression preserves every feasible incidence pattern; it is an exact finite-box computation, not a new estimate or an assumption on f. The independent full-grid comparison and original detailed evidence remain outside this bundle.

Requires Python 3.12, NumPy and SciPy with HiGHS. Recorded execution used Python 3.12.14, NumPy 2.5.4 and SciPy 1.18.1. From this folder:

```
python reproduce.py --list
python reproduce.py --seed 63200
python reproduce.py --seed 730104 --origin expanded512
```

No cases run by default. Each selected case is reconstructed from its seed and checked against its input SHA-256 before solving. The explicit control source is embedded in reproduce.py. Output reports floating P0/P1, M, V, ratio and PASS when matching saved values within 1e-8. Numerical solver versions may produce different primal/dual optimizers despite equal objective values. `profile_dp.py` uses inclusion–exclusion for receiver volume; for direct library use it is intended for the recovered small-N high-dimensional instances. The CLI automatically chooses it only for previously large Cartesian grids.

Original raw datasets remain separate; this portability bundle avoids repeated cell arrays and full source JSON, which are reconstructed from the recorded seed and generator. SHA-256 establishes identity and not mathematical validity.
