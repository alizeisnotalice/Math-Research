import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS'): os.environ[k]='1'
import json, time, resource, sys, platform, math, itertools, random, hashlib
from fractions import Fraction as F
from dp_patterns import dp_patterns
import numpy as np, scipy
from scipy.optimize import linprog
from scipy.sparse import csc_matrix

def volint(lo,hi,l,h):
 v=F(1)
 for x,y,z,w in zip(lo,hi,l,h):v*=max(F(0),min(y,w)-max(x,z))
 return v

def mk(n,N,seed):
 rng=random.Random(seed); radii=[F(1),F(3,2),F(2),F(3)]; ds=[]
 for j in range(N):
  r=radii[j%4]; ctr=tuple(F(rng.randrange(-6,7),2) for _ in range(n)); ds.append((ctr,r))
 # background plus correlated, spatially distinct box mixture
 fs=[(tuple([F(-8)]*n),tuple([F(8)]*n),F(1,128))]
 for k in range(4):
  center=[F(rng.randrange(-6,7),2) for _ in range(n)]; widths=[F(rng.randrange(2,7),2) for _ in range(n)]; fs.append((tuple(x-w for x,w in zip(center,widths)),tuple(x+w for x,w in zip(center,widths)),F(k+1,8)))
 return ds,fs

def box(c,r):return (tuple(x-r for x in c),tuple(x+r for x in c))
def calc(ds,fs,n,seed):
 wall=time.monotonic(); cpu=time.process_time(); N=len(ds); delta=[F(0),F(1,4),F(1,2),F(1),F(2)]
 bs=[box(c,r*(1+d)) for c,r in ds for d in delta]; m=len(bs)
 rhs=[sum((volint(l,h,fl,fh)*q for fl,fh,q in fs),F(0)) for l,h in bs]
 M=sum((math.prod(h-l for l,h in zip(fl,fh))*q for fl,fh,q in fs),F(0))
 edges=[sorted({x for lo,hi in bs for x in (lo[k],hi[k])}) for k in range(n)]
 counts=[len(e)-1 for e in edges]; total=math.prod(counts)
 base={'n':n,'N':N,'seed':seed,'cells_full_grid':total,'grid_dimensions':counts,'M':str(M),'boxes':[{'center':list(map(str,c)),'radius':str(r)} for c,r in ds],'source':[{'lo':list(map(str,l)),'hi':list(map(str,h)),'density':str(q)} for l,h,q in fs],'rhs':list(map(str,rhs))}

 # Exact coordinatewise DP: full incidence set without materializing Cartesian grid.
 dp,info=dp_patterns(bs,n,1000000)
 if dp is None:return {**base,**info,'status':'pattern_limit','wall_seconds':time.monotonic()-wall,'cpu_seconds':time.process_time()-cpu,'rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
 pats=sorted(dp);p=len(pats)
 rr=[];cc=[]
 for col,mask in enumerate(pats):
  while mask:
   v=mask & -mask; rr.append(v.bit_length()-1);cc.append(col);mask-=v
 A=csc_matrix((np.ones(len(rr)),(rr,cc)),shape=(m,p)); y=np.array([float(z) for z in rhs]); ix=np.arange(0,m,5); up=np.array([i for i in range(m) if i%5]); ones=np.ones(p)
 p0=linprog(ones,A_ub=-A[ix,:],b_ub=-y[ix],bounds=(0,None),method='highs')
 p1=linprog(ones,A_ub=scipy.sparse.vstack([-A[ix,:],A[up,:]],format='csc'),b_ub=np.r_[-y[ix],y[up]],bounds=(0,None),method='highs')
 a=max(2*n,8);recv=[box(c,r/a) for c,r in ds];union=F(0)
 # Inclusion-exclusion is practical for n=7,N=3,4; 4D N=8 too.
 for subset_size in range(1,N+1):
  for group in itertools.combinations(recv,subset_size):
   volume=F(1)
   for k in range(n):
    volume*=max(F(0),min(z[1][k] for z in group)-max(z[0][k] for z in group))
    if not volume:break
   union+=(1 if subset_size%2 else -1)*volume
 def rec(sol):
  if not sol.success:return {'success':False,'message':sol.message}
  pred=A@sol.x
  return {'success':True,'objective':sol.fun,'lower_max_violation':max(0.,float(np.max(y[ix]-pred[ix]))),'upper_max_violation':max(0.,float(np.max(pred[up]-y[up]))),'nonzero_variables':int(np.count_nonzero(sol.x>1e-9)),'active_variables':[[str(pats[i]),float(sol.x[i])] for i in np.flatnonzero(sol.x>1e-9)]}
 z0=rec(p0);z1=rec(p1)
 return {**base,'status':'complete','patterns':p,'dp_stage_patterns':info['sizes'],'P0':z0,'P1':z1,'ratio':p1.fun/p0.fun if p0.success and p1.success and p0.fun else None,'P0_over_M':p0.fun/float(M) if p0.success else None,'P1_over_M':p1.fun/float(M) if p1.success else None,'receiver_union':str(union),'a':a,'averages':[str(rhs[5*j]/math.prod(h-l for l,h in zip(*bs[5*j]))) for j in range(N)],'wall_seconds':time.monotonic()-wall,'cpu_seconds':time.process_time()-cpu,'rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
