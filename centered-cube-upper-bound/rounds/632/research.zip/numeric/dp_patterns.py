from itertools import product

def layers(boxes,n):
 out=[]
 for k in range(n):
  e=sorted({v for lo,hi in boxes for v in (lo[k],hi[k])});d={0:None}
  for l,h in zip(e,e[1:]):
   mid=(l+h)/2; mask=sum(1<<j for j,(lo,hi) in enumerate(boxes) if lo[k]<mid<hi[k]);d.setdefault(mask,(l,h))
  out.append(d)
 return out

def dp_patterns(boxes,n,limit=1000000):
 states={(1<<len(boxes))-1:()}; sizes=[]
 for layer in layers(boxes,n):
  new={}
  for bits,rep in states.items():
   for mask,interval in layer.items():
    v=bits&mask
    if v and v not in new:new[v]=rep+(interval,)
    if len(new)>limit:return None,{'status':'pattern_limit','completed_dimensions':len(sizes),'partial_patterns':len(new),'sizes':sizes}
  states=new;sizes.append(len(states))
 return states,{'status':'complete','sizes':sizes,'patterns':len(states)}

def brute(boxes,n):
 e=[sorted({v for lo,hi in boxes for v in (lo[k],hi[k])}) for k in range(n)];s=set()
 for points in product(*[[(x+y)/2 for x,y in zip(z,z[1:])] for z in e]):
  mask=sum(1<<j for j,(lo,hi) in enumerate(boxes) if all(l<z<h for l,z,h in zip(lo,points,hi)))
  if mask:s.add(mask)
 return s
