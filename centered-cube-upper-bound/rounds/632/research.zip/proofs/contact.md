# R632：完整 contact 与共同 future parent 的联合容量检查点

2026-10-28。只读 CONTRACT 与 R630/631 research.zip 内 REPORT、contact/transfer/flux 证明；未改仓库、未运行历史数值、未启动子代理。主代理要求保存现有核心公式后停止。

**结论：没有取得一般性新上界、严格吸收或根阶 source 列容量。** 新覆盖的现有结论仍只支付 Lebesgue 接收并集。将它用于 relocation 的 parent center 集合，单独回代仍为 O(n log n)，无净维数收益。本检查点新增的是一个准确的 parent 内联合正负分解，明确 fresh 条件中可以取消的部分和不能凭归一化获得的容量；它是结构恒等式，不是新的付款估计。

## 1. 必须支付的完整联合不等式

继承 smooth compact f≥0、μ=f dx、M=∫f、K⊂E1 紧、τ=3/4、I=[13/16,15/16]、H_I=7/64。所有旧接触保留真实 outer future 条件和 a0=m_r/V'。对原来源 y、原方向 u∈(-1,1)^n，令

    A_y,u(v)=μQ(y-r(v)u,r(v)),  G_y,u={A_y,u(v)>τv},
    B_y,u=|G_y,u|,
    q_y,u=∫_{T(y,u), B_y,u/v>L}(β-a0)dv/v.

冻结的完整账为

    |K| ≤ (60/7)L M + H_L(K),
    H_L(K)=H_I^{-1}∫dμ(y) E_u q_y,u.

需要证明、而尚未证明的是

    H_L(K) ≤ θ|K| + A_n M,   θ<1,
    ((60/7)L+A_n)/(1-θ) = O(sqrt(n) polylog n).        (J)

若先转到 Eτ，则需要 H_L≤q_*|Eτ|+A_nM 且 q_*<τ；真实吸收系数为 q_*/τ。新覆盖单独给 |Eτ|≤U_n M/τ、U_n=O(n log n)，因此仅得到 ((60/7)L+A_n+q_*U_n/τ)M。q_*=O(1) 时没有根阶收益。若靠 fresh 条件核的正支配，另付 γ_L=(1-5/(2L))^{-1}，故 q_geom 必须小于 τ/γ_L=3/4-15/(8L)。

## 2. 同一 parent 内的准确 fresh 分解

以下固定真实 parent (X,W)，R=W^{1/n}/2、P=Q(X,R)、m_P=μ(P)，并保留 source 条件方向

    a_y=(y-X)/R.

对每个 y∈P，按原完整接触集合定义 v_c(y,a_y)、P_c(y,a_y)、B_y,a_y、J_y,a_y=G_y,a_y∩[B_y,a_y/2,∞)、h_y,a_y=|J_y,a_y|。没有重选方向、重选 source 或移除 future 条件。置

    g_P(y)=1_{W∈J_y,a_y} q_y,a_y / h_y,a_y,
    ν_P(dy)=1_P(y)dμ(y)/m_P,
    λ_P(y)=μ(P_c(y,a_y))/m_P.

仅在 g_P(y)>0 的行使用 λ；其余行可置 λ=0。嵌套性给 P_c⊂P，完整 contact 等号和 W∈J 给

    0≤λ_P(y)≤ b1 B_y,a_y/(L τ W) ≤ δ_L:=5/(2L)<1.

因此对原 incoming 的式 (7)，逐点准确改写为

    J_L(P,z)= 1_P(z)/(H_I W)
               ∫ν_P(dy) g_P(y)
                 [1-1_{P_c(y,a_y)}(z)]/[1-λ_P(y)].    (2.1)

这是原 incoming；实际 f 已进入 ν_P，g_P 仍含原 B、原 q、原方向和全部尺度。没有用 parent 体积代替 μ，也没有用体积比例估计 fresh 来源质量。

记 bar(g)_P=∫g_P dν_P。代数恒等式

    (1-χ)/(1-λ)=1+(λ-χ)/(1-λ)

给出完整联合分解

    J_L(P,z)=J_0(P,z)+Δ_P(z),
    J_0(P,z)=1_P(z) bar(g)_P/(H_I W),
    Δ_P(z)=1_P(z)/(H_I W)
            ∫ν_P(dy) g_P(y)
              [λ_P(y)-1_{P_c(y,a_y)}(z)]/[1-λ_P(y)]. (2.2)

且对每个固定 parent 精确有

    ∫Δ_P(z)dμ(z)=0.                                  (2.3)

证明只需 ∫_P1_{P_c(y,a_y)}dμ=m_Pλ_P(y)，随后 Tonelli。相应的绝对值 bound 是

    ∫|Δ_P(z)|dμ(z)
       ≤ 2δ_L ∫J_0(P,z)dμ(z).                        (2.4)

这里用到 ∫|λ-1_Pc|dν_P=2λ(1-λ)，在取绝对值后再积分仍保留了该行内的归一化抵消。因此 fresh 与未条件化 parent 分配的全局 L1 差至多 (5/L)H_L；这是相对原未知 heavy 总量的误差，不是一份 O(M/L) 的独立预算。

保留正负项还给出更明确的测试函数式：对有界 η，令 bar(η)_P=∫ηdν_P；若 λ_P(y)>0，令 bar(η)_Pc 为 μ 在原 P_c 内的均值。则

    ∫η(z)Δ_P(z)dμ(z)
      = m_P/(H_I W) ∫ν_P(dy)
          g_P(y) λ_P(y)/(1-λ_P(y))
          [bar(η)_P-bar(η)_Pc].                       (2.5)

λ=0 的行贡献定义为零。式 (2.5) 的符号取决于原接触账与真实 source 分布的联合关系。fresh 概率接近一，只说明与 parent 内真实 μ 平均相近；它不证明净收缩。

特别地，简单删除 (2.2) 的负项只恢复已知 γ_L 支配：

    J_L(P,z)≤γ_L J_0(P,z).

由于 (2.3)，对全 source 求和时 fresh 修正没有负的总质量信用：

    ∫dμ(z)∫dX dW J_L(P,z)
      =∫dμ(z)∫dX dW J_0(P,z)=H_L(K).                (2.6)

故仅以“fresh 排除了旧 core”宣称全局 θ<1，在这个准确公式下没有依据。需要同时获得 source 列容量或将 (2.5) 与一个已经可付的非恒定势函数结合。

## 3. 新覆盖尚缺的准确性质

未条件化部分的 source 列为

    C_0(z)=H_I^{-1}∫_{z∈Q(X,W^{1/n}/2)}
                         bar(g)_P dX dW/W.           (3.1)

新覆盖控制 parent center 的 Lebesgue 并集，不控制 (3.1) 的连续尺度权重 bar(g)_P/W。这个权重含 q_y,a_y/h_y,a_y，不能从 parent center 属于 Eτ 这一支持信息删掉。新 cover 的特殊合法选择及冻结增量负载也没有在这里出现；目前没有证明 (3.1) 受该同一次选择的负载支配。

一个足以闭合、但本检查点未证明的联合 source 估计是：对所有上述原 f、K 和全部真实尺度，存在固定 θ<1 和根阶 A_n，使

    ∫dX dW [J_0(P,z)+Δ_P(z)]
       ≤ A_n + θ S_K(z)       for μ-a.e. z,           (C)

其中

    S_K(z)=H_I^{-1} E_u∫_{T(z,u)}(β-a0)dv/v,
    ∫S_K dμ=|K|.

对 (C) 积分立即得到 (J)。这里 S_K 用完整 contact（含 light），不是在新来源上另领 M，也不是将任意受控函数充作原接触边际。式 (C) 精确标出所需的 same-input、same-contact 列支配。它本身只是充分条件；没有将其改名视为证明。

另一个较强且足够的目标是 C_0(z)+∫Δ_P(z)dX dW≤A_n，但本轮同样无证明。单独的 weak-type 并集界对任意 scale density 不给这种容量；因此必须再用 g_P 中的原 future-contact 结构，不能只调用覆盖常数。

## 4. moving-clock 与角向正负账保持完整

本分解发生在 source relocation 的同一 parent 内，并未替代 R631 的角向 IBP。若以后尝试从 angular/clock 方向估计 g_P 或 Δ，仍须使用共同 finite cutoff 的

    D=B0+A-W_bulk-R-N,
    N=(1/n)∫φ Φ(P_future) h'(B_m/v)
                      (u·∇_u B_m)/v dμ dΩ.

真实 u、B_m 的 moving normalizer 项 N、future envelope、receiver mask 和共同尺度 cutoff 都必须保留。这里 W_bulk 是 R631 负 bulk，不是 parent volume W。已知 plateau 上 A 与 W_bulk 分别按 log(1/V0) 发散而精确抵消；不能删 W_bulk 后将新覆盖用在 A 上，也不能从 B_m→B 的 L1 收敛推 N 可付。

上面的 Δ 同样有自己的正负取消，不能混同为 R631 的 A-W_bulk 抵消，或声称其中一个替另一个付款。本检查点没有取得两种取消的联动估计。

## 5. 实际验证、影响与停止点

新恒等式 (2.2) 的标量分解和 δ_L=5/(2L) 已用本机 SymPy 精确验证；命令使用 /Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python，运行约 0.165 秒。未重跑 R630/631 样本、未复算覆盖参数族。该符号核验只验证代数；(2.3)–(2.6) 的证明见本文 Tonelli/条件均值推导。

实际影响：一般弱型常数仍只有新 cover 已提供的 O(n log n) 量级；本文件没有新的维数改善。准确缺口是对带完整 q/h_J 权重的 (3.1) 及其 signed fresh 修正 (2.5)，取得同一原输入下的 (C) 或等价可吸收估计。当前既没有统一列帽，也没有从原 future/clock 条件推出 (2.5) 可提供 θ<1 的符号收益。检查点已保存，停止。
