# R632：共同选择、真实重复信用与完整族预算的接口

2026-10-28。本支线只处理选择与重复收益；未修改 repository，未创建子代理，未重跑旧几何样本。已读冻结合同、`ccu_r632_cover_adaptive.md`、`ccu_r632_cover_history.md` 以及 R617/R619 的 README 和归档 REPORT.tex。

**结论：尚未证明任意完整族的根阶预算，也未证明低共同来源比例下的统一收缩。** 本次可核验的新整理是：真实重复信用全部保留后，多见证净收益有一个精确的“几何新增覆盖减实际新增捕获减资格松弛”公式。它明确指出什么能减少完整证书，及为何重复信用不能另作可循环的本金。与 R619 的正则来源合并后，可写出不遗漏 cover、tail、source slack、ε 吸收的根阶充分判据；该判据中的跨 clique、跨尺度估计仍未证明。

## 1. 全部供给族与一次共同选择

记全部供给小立方体为 B_j，见证星为 A_j=aB_j，完整接收集合 U=∪B_j，V=|U|。R619 对这个完整族产生正 packing 权 λ_j 和一个真实 L¹ 辅助来源 μ，满足

\[
 Q=\sum_j\lambda_j|A_j|,\qquad M=\mu(\mathbb R^n)=Q+\epsilon V,
 \qquad \lambda_j[\mu(A_j)-|A_j|]=\epsilon v_j.
\tag{1}
\]

此处 v_j 是 R619 在完整族固定顺序下的正接收增量。它与随后覆盖选择的增量不能混写。共同来源比例与已有严格合并预算是

\[
 \kappa=\frac{\sum_jv_j\mu(A_j)}{VM},\qquad
 \kappa V\le PM,\qquad P=(1+1/a)^n.
\tag{2}
\]

固定目标尺度 H_n=√n log^A(n+2)，先取

\[
 \vartheta_n=H_n^{-1},\qquad \epsilon=(2PH_n)^{-1}.
\tag{3}
\]

若构造所得 κ≥ϑ_n，R619 已给完整族结论 V≤2PH_n Q。剩余任务只在 κ<ϑ_n 的完整交织族上进行，不能以分离组件的数量稀释 κ，也不能只证明一个 source 点或一个 clique 的预算。

对同一个 μ 和完整族，只选定一次合法完整覆盖历史 H：固定参数后运行原最大合格半径算法至终止（等价地，固定阈值下按半径非增作永久拒绝扫描），固定破平局，真实接收增量 E_i、u_i=|E_i| 和 w_i=u_i/|A_i|，所有资格均为该历史的真实累积资格。令

\[
 V_H=\sum_{i\in H}u_i,\quad
 W_H(x)=\sum_{i\in H}w_i\mathbf1_{A_i}(x),\quad
 \mathcal D_H=\sum_{i\in H}u_i\left(\frac{\mu(A_i)}{|A_i|}-1\right).
\tag{4}
\]

由于 (1) 的每个星都是 μ 的合法见证，\(\mathcal D_H\ge0\)，且准确有

\[
 \int W_H\,d\mu-\mathcal D_H=V_H.
\tag{5}
\]

覆盖系数可取原已证 \(c_H=1+A_{n,a}/\tau\)，或有完整证书的更小系数，满足 V≤c_H V_H。**不能事后增加 coverage multiplier 并继续引用未加权资格。** 本文所有公式均使用原实际 w、原资格和原已证覆盖系数；没有重写权重。

下文随 x 改变的 T_x 是同一历史上的证明见证集合，允许按 R617 作可测选择；它不改变 H，也不意味着可以按 source 点分别选择不同覆盖历史。

## 2. 精确净收益：重复信用的全部结算

固定 H 和一个 source 点 x，照 R617 冻结 prefix J、candidate suffix、全部 tail、末见证 k_*、r_0、s 及几何测度 ν。对 T 含 k_*，写

\[
 U_x(T)=|T|\tau+q_{\rm tail}+\nu(D_T)-O(T)\ge W_H(x),
\]

其中 \(D_T=\bigcap_{k\in T}G_k^c\)，\(c_T(j)=\sum_{k\in T}A_{jk}\)，\(A_{jk}=\mathbf1_{bB_j}(y_k)\)，\(O(T)=\sum_{j\in J}w_j(c_T(j)-1)_+\)。全部 tail 在优化期间保持不变。

令 \(L_k^J=\sum_{j\in J}w_jA_{jk}\)。对新见证 k∉T，R617 的边际式可精确重写为

\[
 \boxed{\quad
 U_x(T)-U_x(T\cup\{k\})
 =\nu(D_T\cap G_k)
 -\sum_{j\in J:c_T(j)=0}w_jA_{jk}
 -(\tau-L_k^J).
 \quad}
\tag{6}
\]

证明只需将已捕获 prefix 的重复信用写成
\(\sum_{c_T(j)\ge1}w_jA_{jk}=L_k^J-\sum_{c_T(j)=0}w_jA_{jk}\)。完整资格还给 \(\tau-L_k^J\ge L_k^{\rm tail}\ge0\)。所以新增见证费不能因重复捕获而无条件消失；其剩余至少包含此前 tail 在该中心的真实负载。

这也是联合随机选择的精确式。设 E 为 optional candidates，独立纳入概率 p_k∈[0,1]，并强制纳入 k_*。令

\[
 F_p(B)=1-\prod_{k\in B\cap E}(1-p_k),\qquad
 \mathcal E_0=\{B:k_*\notin B\}.
\]

以 g(B) 表示 ν 的几何 capture-pattern 质量，以 a(A) 表示真实 prefix capture-pattern 权重。相对于 \(U_0=\tau+q_{\rm tail}+\nu(G_{k_*}^c)\)，**全部真实重复信用均计入后的准确期望收益**是

\[
 \boxed{\quad
 \mathcal G(p)
 =\sum_{B\in\mathcal E_0}g(B)F_p(B)
 -\sum_{A\in\mathcal E_0}a(A)F_p(A)
 -\sum_{k\in E}p_k(\tau-L_k^J).
 \quad}
\tag{7}
\]

对 prefix pattern A，末见证已捕获时，期望重复信用为 \(\sum_{k\in A\cap E}p_k\)；末见证未捕获时为 \(\sum p_k-F_p(A)\)。将二者与新增费用 \(\tau\sum p_k\) 合并即得 (7)。式 (7) 包含 R617 额外非负信用，没有只保留二阶 Bonferroni 项。

**(7) 的第一二项之差不能预设非负。** 实际增量上的几何 pattern B 满足 B⊂A，但 F_p 为递增函数；一次真实新捕获可能发生在几何 inner cap 之外。因此，旧 downward-set 支配不允许将 \(g-a\) 当作每个 pattern 非负的测度。未被末见证捕获的限制 \(\mathcal E_0\) 也不能删掉，否则会悄悄消去大半径外域费。

取 p_k=θw_k 并对几何 union 作二阶下界、丢弃额外信用，(7) 正好还原 R617 的 \(\mathcal G(p)\ge\theta D-\theta^2C\)。故 (7) 是一个严格更完整的可执行收益式，但尚无一般正的下界。

## 3. 完整族根阶预算的精确充分判据

对每个 x，令 \(J_H(x)=\max_{0\le\theta\le1/w_{\max}}(\theta D-\theta^2C)\)。固定同一 H 后，R617 保证

\[
 W_H(x)\le U_{0,H}(x)-J_H(x).
\]

将全部真实见证 slack 保留，得到

\[
 V\le c_H\left[\int(U_{0,H}-J_H)\,d\mu-\mathcal D_H\right].
\tag{8}
\]

以 \(\widehat\mu=\mu/M\) 归一化，并定义

\[
 \alpha_{\max}(x)=a^n w_{\max}(x)\le1,\quad
 \bar D=a^nD,\quad \bar C=a^{2n}C,
\]
\[
 d=\mathbb E_{\widehat\mu}(\bar D)_+,\quad
 c=\mathbb E_{\widehat\mu}\bar C,\quad
 e=\mathbb E_{\widehat\mu}[\alpha_{\max}(\bar D)_+]\le d.
\]

空 candidate pool 的三个量均为零。取
\(\theta=a^n(\bar D)_+/(2\bar C+\alpha_{\max}(\bar D)_+)\)，在零分母处取零；这是合法区间中的点。直接代入并用 Cauchy–Schwarz 得

\[
 J_H(x)\ge
 \frac{(\bar D)_+^2}{4\bar C+2\alpha_{\max}(\bar D)_+},
 \qquad
 \mathbb E_{\widehat\mu}J_H\ge\frac{d^2}{4c+2e}
 \ge\frac{d^2}{4c+2d}.
\tag{9}
\]

因此，在低 κ 分支中若能对**一个共同 μ-依赖合法 H**证明

\[
 \boxed{\quad
 c_H\left[
 \mathbb E_{\widehat\mu}U_{0,H}
 -\frac{\mathcal D_H}{M}
 -\frac{d^2}{4c+2e}\right]\le PH_n,
 \quad}
\tag{10}
\]

则 (8) 给 V≤PH_n M。再代入 (1)、(3)，而不是将 M 当成 Q，得到

\[
 V\le PH_n(Q+\epsilon V)=PH_nQ+V/2,
 \qquad V\le2PH_nQ.
\tag{11}
\]

这与高 κ 分支常数一致，且无额外完整族 cover 损失。一般形式为：若 (8) 的归一化右侧 ≤L_n，必须检查 εL_n<1，最终常数才是 L_n/(1−εL_n)。

式 (9) 的基本矩界由 proof 支线独立得到，本支线检查了合法 θ 和较强分母 e。式 (10) 是当前准确的**未证**共同选择目标，不是本轮已经付款的定理。使用 (7) 的准确收益代替 J_H 可以改善同一判据，但不能省略任何其它项。

## 4. 低 κ 与多见证收益间的真实断点

### 4.1 两类机制作用在不同的几何配对上

R617 在固定 x 的全部 prefix contributors 和 candidate witnesses 都含有 x。特别是其 optional candidate 对满足 \(A_k\cap A_\ell\ne\varnothing\)，并且同处一个 source clique。它的 D、C 和 (7) 记录这个 clique 内的捕获关系。

R619 的低 κ 非对角方向预算来自 \(A_j\cap A_k=\varnothing\) 的配对。这样的两星不可能同时进入任何固定 x 的 R617 contributor pool。因此不能把 \(\sum_i\Psi_i=1-\kappa\) 当作 D 的线性下界或 C 的二阶上界。它们的支持集合不同。

这不证明不能联合：真正可能的桥是利用跨 clique 的分离几何，控制同一 μ 下各局部 contributor 配置的总暴露。但该桥必须保留跨 clique 配对一致性、receiver 边缘以及实际半径。现有逐 source witness 最小化没有建立这个桥。两点 Hall 耦合也未提供一个全局多点 selector。

### 4.2 κ 的体积权与 W 的逆体积权不同

即使先只看 R619 的完整族，令 d_j=|A_j|、\(W_{\rm sup}=\sum_j(v_j/d_j)\mathbf1_{A_j}\)，则

\[
 \kappa V=\sum_j v_j\frac{\mu(A_j)}M,
 \qquad
 \mathbb E_{\widehat\mu}W_{\rm sup}
 =\sum_j\frac{v_j}{d_j}\frac{\mu(A_j)}M.
\tag{12}
\]

在 d_j∈[2^m,2^{m+1}) 的层，记该层 receiver 体积 V_m 和其 κ_m，则

\[
 \sum_m2^{-m-1}\kappa_mV_m
 \le\mathbb E_{\widehat\mu}W_{\rm sup}
 \le\sum_m2^{-m}\kappa_mV_m,
 \qquad \kappa V=\sum_m\kappa_mV_m.
\tag{13}
\]

这里没有可删除的尺度权。全局 κ 小只控制右边最后一个无逆尺度权的和。\(W_{\rm sup}\) 还不是选择后重新生成增量的 \(W_H\)；转到 H 需要再处理这一差别。多尺度交织族的困难恰在于不能由此支付前两个和，更不能支付依赖 prefix/tail 的 (7)。没有证明可和尺度费用之前，按层分别调用高 κ 合并会重复使用同一 source 质量。

### 4.3 “不断降低 envelope gap”不等于完整预算收缩

对固定 H，所有见证证书均满足 \(U_x(T)\ge W_H(x)\)。若使用准确覆盖比 \(\gamma_H=V/V_H\)，则有恒等式

\[
 \gamma_H\left[\int U_x(T_x)\,d\mu-\mathcal D_H\right]
 =V+\gamma_H\int[U_x(T_x)-W_H(x)]\,d\mu.
\tag{14}
\]

故只证明最后一项以统一比例下降，其极限固定点是 V 本身；它没有证明 V/M≤PH_n。其几何上限与实际负载之间的 gap 可以减少，但不能把每次减少重复结算为一个独立 source 收益。

若改选 H，必须重新计算真实增量、所有资格、c_H、U_0、tail 和 \(\mathcal D_H\)。不能仅把旧 H 的见证减少量相加。R628 已说明在任意合法历史层面，固定 W 的点态根阶界不成立；高 κ 分支可处理其共源星交情形，但这不补低 κ 交织族的 (10)。

本支线没有使用稀疏链、断开副本或单 source 的例子充作低 κ 难例，也没有声称它们反驳 (10)。真正的难例或证明必须同时保留完整 V/Q、低 κ、多尺度和相互交织，并针对同一次合法共同选择。

## 5. 后续有限计算的明确判据

不建议再做“低 κ 时是否经常 J>0”的泛泛搜索。小的正 J 既不保证 (10)，D≤0 也可能只是该完整族已很便宜。若测试一个具体候选选择规则，预先冻结 n、a、t、τ、H_n、ε、全部合法历史菜单和 candidate-pool 规则，必须输出如下完整量：

1. 同一完整族的 V、Q、M、κ，以及 (1) 的实际残差或严格证书；不能将 approximate KKT 当精确恒等式。
2. 对同一 H 的 c_H、\(\mathcal D_H\)、\(\mathbb E U_0\)、d、c、e，或用 (7) 积分得到的准确联合收益；μ 的全部有正质量 source cells 必须计入。
3. 主判据是 (10) 的左侧是否 ≤PH_n，或使用准确 (7) 后的同一完整判据。若不能认证 ≤，只记为该规则/菜单尚未付款；若严格证出 >，仅排除该固定菜单的该判据，不排除其它合法共同选择。
4. 任何“统一收缩”声称必须直接对完整 (8) 的归一化账成立，并显示 terminal 预算和所有历史重建费用。仅对 (14) 的 envelope gap 收缩不计为根阶机制。

本轮未向几何支线提交重型计算请求，因为尚没有能证明或否定上述跨 clique 桥的精确候选不等式。几何支线已收到暂停泛泛正收益计算的说明。

## 6. 实际本机代数核对

运行了新的轻量符号核对，未重算 R617/R619 旧实验。命令环境为 `OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 /Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python`。Python 3.12.14、SymPy 1.14.0。

输入为三个形式 optional Bernoulli 参数 p_0,p_1,p_2。枚举 compulsory capture 的 2 个值与 optional actual capture 的 8 个 masks，共 16 个 actual patterns；另枚举 8 个 geometric patterns。逐个对 8 个 Bernoulli outcomes 求准确期望，验证

\[
 \mathbb E(N+a_0-1)_+
 =\sum_{k\in A}p_k-(1-a_0)\left[1-\prod_{k\in A}(1-p_k)\right]
\]

及 union 概率式。24 个符号残差全部为零。实际 wall 0.01797 s，CPU 0.01568 s，峰值 RSS 68,108,288 bytes（macOS resource 口径），1 进程。它仅核对 (7) 的有限代数实现；一般证明在第 2 节，不作为任何维数阶证据。

**交付范围：** 精确收益结算 (6)–(7)、不漏费用的完整判据 (8)–(11)、跨 clique 与跨尺度断点 (12)–(14)。任意低 κ 交织多尺度完整族的根阶付款仍未闭合，不能以这份接口说明代替该定理。
