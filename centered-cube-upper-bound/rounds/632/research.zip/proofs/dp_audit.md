# R632：完整 incidence 压缩与有限 LP 方向独审

**结论：在有限个有界、非退化轴平行 D/O boxes 与非负 L1 来源的范围内，逐轴 interval-mask AND 压缩在任意有限维数 n 都准确保留源质量 LP。** 本次只读 `/tmp/ccu_r632_geometry/dp_patterns.py`、`profile_dp.py`、`export_dp.py`、`DP_RESULTS.md`，未重跑 512 cases；浮点最优性与既有证书不因本审核自动升级为严格认证。

**完整性证明。** 将全部 D/O boxes 编为 m 位。每轴全部端点将其有限坐标范围划为开正长度 intervals；轴 mask 的第 j 位表示该 interval 包含于第 j 个 box 的坐标投影。除有限端点超平面外，每个 x 的全维 incidence 恰为各轴 mask 的 bitwise AND。反之，各轴所选 intervals 的 Cartesian 积是正体积 cell，其 incidence 正是这个 AND。因此全部可实现非零 patterns 恰为逐轴 AND 集合。中间 mask 去重不丢后续模式：后续 AND 只依赖当前 bits，与此前具体代表无关；保留任一前缀代表即可。中间零 mask 永不能恢复非零，可立即删。任何非零模式都在每轴全端点范围内；该范围以外该轴 mask 全零，故无需无界 intervals。

**LP 等价与真实 L1 实现。** 对每个非零 pattern p 设一个非负质量变量 g_p、目标 Σ_p g_p。任意非负 L1 来源按 patterns 聚合得到相同全部 D/O 积分；反之，代码所存代表 cell C_p 有正有限体积，密度 Σ_p(g_p/|C_p|)1_{C_p} 是非负 L1，准确实现这些质量及总质量。代表 cells 无需保留原 f 的形状；这是辅助来源优化的等价实现，**不能由此把既有相关 f 改成乘积来源假设**。全零模式对全部约束贡献为零，目标系数为正，删除只降低质量而不改可行性，故可删。有限 boxes 的边界并为 Lebesgue 零集，对 L1 来源无影响；若允许原子测度，该边界理由不适用。

**方向。** 令 b_j=∫_{D_j}f_exact、c_k=∫_{O_k}f_exact，均由同一个原始相关 f_exact 求值。P0=min Σg，仅有 μ(D_j)≥b_j；P1 增加 μ(O_k)≤c_k。于是

\[
0\le P_0\le P_1\le\int_{\cup(D\cup O)}f_{exact}\le\|f_{exact}\|_1.
\]

最后上界由截断后的同一个 f_exact 可行给出；没有独立来源或丢相关假设。P1/P0 只反映这个有限约束组的最小来源代价变化，不等于弱型常数或一般维数阶。

**实现核查。** `layers` 在当前输入使用 Fraction 端点与精确 midpoint；`dp_patterns` 的 `v=bits&mask`、非零剪枝、逐层去重及正区间代表符合上述证明。初始 `0:None` 不会进入非零代表。`pattern_limit` 返回 `None`，调用方中止该案而非将部分集合当完整 LP。`profile_dp.py` 保留 D lower 与四种 O upper 全行；`export_dp.py` 只是重新排列 D/O 行并另用精确加权 mask DP 聚合原 f。LP 交给双精度 HiGHS，故其成功状态/小残差只属浮点证据；严格最优区间仍需独立可行原/对偶证书。

**Receiver 独立。** patterns 去重保留 incidence 与源质量自由度，**不保留每个 pattern 的 Lebesgue 体积**，不能拿代表 cell 体积代替 receiver union。代码另外按原中心、原半径与 a 构造 r/a receivers，并作有理 inclusion–exclusion，方向正确；其复杂度可指数增长但不限制数学上的任意有限 n 完整性。上述结论不补充任何全尺度、全族根阶几何付款。
