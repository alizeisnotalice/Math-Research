# R632：共同来源、多见证收益的联合 Jensen 与吸收接口

日期：2026-10-28。责任范围：独立读取 R617、R619 的 README/REPORT 后推导的联合公式；不改仓库，不重算数值。以下为**条件性充分接口，尚非一般付款定理**。一般中心立方体弱型根阶上界仍未证明。

## 1. 完整 family 与同一个真实辅助来源

对任意有限供给族 B_j=B(y_j,r_j)，取 A_j=aB_j，d_j=|A_j|。按固定顺序的真实接收增量为 I_j=B_j\setminus\bigcup_{i<j}B_i，v_j=|I_j|>0，V=\sum_jv_j=|\bigcup_jB_j|。R619 正则 packing 给出同一组 λ_j>0 与同一非负 L1 来源 μ，使

\[
 L_\lambda(x)=\sum_j\lambda_j1_{A_j}(x)\le1,\quad
 Q=\sum_j\lambda_jd_j,\quad
 M=\mu(\mathbb R^n)=Q+\epsilon V,
\]
\[
 \lambda_j[\mu(A_j)-d_j]=\epsilon v_j.
\]

此 μ 是全族构造出的真实辅助来源，不能随接收点或见证改变。原任意坏输入 f 满足 ηQ≤||f||_1，故所需全族目标是 V≤K_nQ，无额外 selected-cover 系数。

记
\[
 P=(1+1/a)^n,\qquad
 \kappa=\frac{\sum_jv_j\mu(A_j)}{VM}.
\]
R619 已证 κV≤PM。令 H_n=√n log^A(n+2)、θ_n=1/H_n，并**在构造 λ,μ 之前**固定 ε=1/(2PH_n)。若 κ≥θ_n，则
\[
 (\kappa-P\epsilon)V\le PQ,\qquad V\le2PH_nQ.
\]
当 a≥n 时 P≤e。缺口是低 κ 的相互交织完整组件；全局 κ 小不能单独视作难例。真正不交的 star 组件须分别结算再加总，不能用其数量制造障碍。

## 2. 一次合法历史下的真实多见证量

固定同一个 μ 与一次合法最大半径资格历史 H，参数 a>2t>2、b=a(1+1/t)、τ>0，真实 selected increments v_i^H 和冻结权
\[
 w_i=v_i^H/(2ar_i)^n,\quad
 \sum_{i<k}w_i1_{bB_i}(y_k)\le\tau.
\]
覆盖常数
\[
 C_{\rm cov}=1+(1+1/t+1/a)^n/\tau,
 \qquad V\le C_{\rm cov}V_H,\quad V_H=\sum_i v_i^H.
\]
对每个来源点 x，固定 R617 的候选 suffix、prefix J、完整 tail、r0、s 与强制末见证 k*。不能对每个 charged source 另选一条合法历史；在这一条历史内部，有限、可测的 witness subset T(x) 可以随 x 选取。

沿用 R617 的共同几何测度 ν、捕获集 G_k，D0=G_{k*}^c，以及
\[
 U_0(x)=\tau+Q_{\rm tail}(x)+\nu(D_0),
\]
\[
 B_k=\sum_{j\in J:A_{jk*}=1}w_jA_{jk},\quad
 b_k=\nu(D_0\cap G_k),\quad b_{k\ell}=\nu(D_0\cap G_k\cap G_\ell),
\]
\[
 D=\sum_{k\in E}w_k(b_k+B_k-\tau),\qquad
 C=\sum_{k<\ell\in E}w_kw_\ell b_{k\ell}\ge0.
\]
这里 E 为 optional witnesses，全部来自同一实际历史。真实下降保证为
\[
 J(x)=\max_{0\le\vartheta\le1/w_{\max}}
       (\vartheta D-\vartheta^2C),\qquad
 \min_{T\ni k*}U_x(T)\le U_0(x)-J(x).
\]
空 E 取 J=0。R617 额外重复信用可进一步增加收益；此处未把它假定为独立本金。

## 3. 独立联合 Jensen 命题（已证明的代数接口）

实际增量自动给
\[
 \alpha_k=a^nw_k=v_k^H/(2r_k)^n\le1.
\]
令 \bar D=a^nD、\bar C=a^{2n}C、αmax=max α_k≤1。用 z=ϑ/a^n 改写，允许区间为 0≤z≤1/αmax。若 \bar D>0，取
\[
 z=\frac{\bar D}{2\bar C+\alpha_{\max}\bar D}
\]
便满足上限，并给
\[
 J\ge\frac{\bar D^2(\bar C+\alpha_{\max}\bar D)}
              {(2\bar C+\alpha_{\max}\bar D)^2}
   \ge\frac{\bar D^2}{4\bar C+2\alpha_{\max}\bar D}
   \ge\frac{\bar D^2}{4\bar C+2\bar D}.
\]
若 \bar D≤0，取 z=0。所有 0/0 项约定为零。对同一来源概率 μ/M 定义
\[
 d=\frac1M\int(\bar D)_+\,d\mu,\qquad
 c=\frac1M\int\bar C\,d\mu.
\]
Cauchy–Schwarz（积分形式）给出
\[
 \boxed{\frac1M\int J\,d\mu\ge\frac{d^2}{4c+2d}}.
\]
其证明为 ∫X²/Y≥(∫X)²/∫Y，X=(\bar D)+、Y=4\bar C+2X。该命题保留真实单次 selection、实际权、末见证、全部 tail 与同一来源；它并未证明 d 正或 c 具有合适的全族上界。

## 4. 联合正负收益预算及准确吸收

设 h_i=μ(A_i)/d_i≥1。完整实际来源松弛为
\[
 D_\mu=\sum_{i\in H}v_i^H(h_i-1)\ge0,
 \qquad V_H=\int W_H\,d\mu-D_\mu.
\]
若 selected rows 来自上述同一个完整 family，则 R619 KKT 进一步给准确式
\[
 D_\mu=\epsilon\sum_{i\in H}
          \frac{v_i^Hv_i}{\lambda_i d_i}.
\]
这里 v_i 为原完整 family 的冻结增量，v_i^H 为这次 selection 的真实增量，两者不能混写。稀少标签的 1/λ_i 费用仍存在。

因此下面这一项是**充分但尚未得到统一证明**的低共同来源预算：存在一次 μ-adaptive 合法历史 H，使
\[
 \boxed{
 C_{\rm cov}\left[
 \frac1M\int U_0\,d\mu-\frac{D_\mu}{M}
 -\frac{d^2}{4c+2d}\right]\le L_n.
 }
\tag{Conditional joint budget}
\]
一旦该条件成立，真实覆盖与上述 Jensen 命题才推出
\[
 V\le L_nM=L_nQ+\epsilon L_nV.
\]
必须再验证 εL_n<1；结论准确为
\[
 \boxed{V\le\frac{L_n}{1-\epsilon L_n}Q.}
\]
取 L_n=PH_n 与前述 ε=1/(2PH_n)，则 εL_n=1/2，低 κ 分支也得到 V≤2PH_nQ，与已付款的高 κ 分支兼容。漏掉此吸收、在 μ 构造后再随意更换 ε、或容许未控制的 family-dependent L_n，均不能闭合。

真实不交组件可各自应用同一常数，再直接加总 V_h≤2PH_nQ_h。若需合并低分支的 Jensen 收益，正确的源质量权为 M_h；Cauchy 给
\[
 \sum_h M_h\frac{d_h^2}{4c_h+2d_h}
 \ge\frac{(\sum_hM_hd_h)^2}
          {\sum_hM_h(4c_h+2d_h)},
\]
无组件数因子，但这并不证明每个组件的条件预算。

## 5. 对 selection agent 独立公式的审核及决定性缺口

对固定 H，令 g(B) 为几何 capture-pattern 质量、a(A) 为实际 prefix pattern 质量、E0={A:k*∉A}。独立 optional 抽取概率 p_k，F_p(A)=1−∏_{k∈A}(1−p_k)。完整期望收益准确整理为
\[
 G(p)=g[F_p1_{E0}]-a[F_p1_{E0}]
      -\sum_{k\in E}p_k(\tau-L_k^J).
\]
这一式与 R617 直接期望展开一致：末见证已捕获行给线性重复信用；未捕获行的额外重复信用为 ΣpA−F_p，二者合成 ΣpL_k^J。**E0 限制必须保留**；捕获末见证的 prefix 可有大于几何截断半径的来源，不能无额外费用扩展支配。

固定历史还有准确恒等式
\[
 \int\min_TU_x(T)\,d\mu-D_\mu
 =V_H+\int[\min_TU_x(T)-W_H(x)]\,d\mu,
\]
右侧 gap 非负。故 witness 优化仅能缩小这条历史的 envelope gap；不能把实际 receiver 主项 V_H 当作已由收益支付。多轮收益至多望远镜消去原 gap。所谓 contraction 若没有根阶 terminal receiver 支付，就仍未闭合。

当前决定性缺口是：尚无几何定理把低 κ、真实曝光与一次合法 μ-adaptive 历史的 d,c、来源松弛、tail、覆盖及终端 receiver 项联结起来，从而证明上框的 conditional joint budget。Hall/LP 等价条件本身已在 R625 存在；本报告没有重包装为新付款。R628 的任意供应历史点态大 W 限制点态付款，并不否定同一输入上可选择更好见证或由真实松弛抵消的方案。

所有公式适用于有限但任意维数/规模/半径族；只有统一证出 full-family 常数并沿原紧子覆盖与内正则性恢复，才覆盖任意 L1、真实 Lebesgue receivers 和所有正尺度。没有固定有限样本、单壳或点态历史被当成该结论。本次按委派不新增数值运行；以上不声称计算认证或一般上界完成。
