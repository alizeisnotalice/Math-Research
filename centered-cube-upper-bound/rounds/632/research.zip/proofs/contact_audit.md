# R632 parent 分解独立终审（Sol high）

审核对象：`/tmp/ccu_r632_joint_contact.md` §2–3 新增的 fixed-parent 恒等式、零均值、L1 界和全局系数；不重新审核旧账，不运行历史样本或覆盖参数扫描，不改仓库。

**结论：接受该分解及其 stated 影响。未发现归一化因子或 incoming 条件遗漏；它没有提供新的付款或根阶容量。** 只需补明通常的零行/可积性约定：parent 以 dX dW 几乎处处解释；m_P=0 或 g_P≡0 的 parent 全部置零；以下逐 parent 有限等式限于 m_P>0、bar(g)_P<∞ 的 parent。由 ∫J_0=H_L≤|K|<∞，这些条件在实际非零 parent 上几乎处处充分，故不改变所有全局结论。

## 1. 原 incoming 与正确 m_P/W

固定 P=Q(X,R)、W=(2R)^n、m_P=μ(P)，ν_P=μ|P/m_P；全部定义都保留原 a_y=(y−X)/R。令 g_P(y)=1_{W∈J_{y,a_y}}q_{y,a_y}/h_{y,a_y}，F_new=m_P−μ(P_c)=m_P(1−λ_y)。原 incoming 是相对 dX dW dμ(z) 的密度

    J_L(P,z)=1_P(z)/(H_I W)∫_P g_P(y)1_{z∉P_c(y)} dμ(y)/F_new(y).

由于 dμ(y)=m_P dν_P(y)，m_P 恰与 F_new 的 m_P 抵消，得到原稿(2.1)，此处不能额外放一个 m_P，也不能额外除 m_P。对 z 积分时 m_P 恢复：

    ∫J_L(P,z)dμ(z)=m_P bar(g)_P/(H_I W)=I_L(X,W).

同样 ∫J_0 dμ=m_P bar(g)_P/(H_I W)。因此真实 m_P/W 在总接收收费中完整保留；未将 m_P 换成 Lebesgue W。g_P 中的 q/h_J、W∈J、原方向、完整 selected/future 与全尺度条件也均在，没有删去原 source 条件。

在 g_P(y)>0 的行，v_c≤B/L、μ(P_c)≤b1 B/L，W∈J 给 W≥B/2 且 m_P=A(W)>τW，所以 λ_y≤2b1/(τL)=5/(2L)=δ_L<1（L>5/2）。无 q 或无菜单的行设贡献零即可。

## 2. 分解、零均值与 L1 常数

标量恒等式

    (1−χ)/(1−λ)=1+(λ−χ)/(1−λ)

逐行给 J=J_0+Δ。对固定 y，∫_Pχ dμ=m_Pλ，因此该行 Δ 对 z 积分为零；在先证绝对可积后用 Fubini，得到 ∫Δ_P dμ=0。

关键的 L1 运算没有漏 γ_L：对 0≤λ<1，

    ∫_P|λ−1_{P_c}|dμ=2m_P λ(1−λ),
    ∫_P|(λ−1_{P_c})/(1−λ)|dμ=2m_Pλ.

先用三角不等式将 |∫_y| 放到 ∫_y| |，再对 z 积分，得

    ∫|Δ_P|dμ≤2m_P/(H_I W)∫g_P(y)λ_y dν_P(y)
               ≤2δ_L∫J_0(P,z)dμ(z).

故(2.4)正确。此处使用的是同一 parent、同一真实 μ 下的正负归一化取消；如果先粗略估 |λ−χ| 再乘 γ，就会人为损失系数，但原稿没有这样做。

## 3. 全局差与测试函数

对 parent 积分，∫dX dW∫J_0 dμ=∫dX dW I_L=H_L≤|K|，所以

    ∫dX dW∫|J_L−J_0|dμ≤2δ_L H_L=(5/L)H_L.

也因此，积分后的 source 列之差满足

    ∫|C_new(z)−C_0(z)|dμ(z)≤(5/L)H_L.

两种全局 L1 解释都成立。绝对可积由此获得；随后 signed Fubini 给 ∫(C_new−C_0)dμ=0，及 ∫C_0dμ=∫C_newdμ=H_L。没有产生负的总质量信用。

有界 η 的式(2.5)也正确：该行积分等于

    [m_P/(H_I W)]g_P(y) λ_y/(1−λ_y)
       ·[bar(η)_P−bar(η)_{P_c(y)}].

λ=0 行按零解释。其符号依赖 η 与真实来源/旧 core 的联合关系；未有这种估计前，不能把此式当作净收益。简单删除负项只给 J≤(1−δ_L)^{-1}J_0，仍是旧 γ_L 正支配。

## 4. 支付判断与待证容量

(5/L)H_L 是相对未知 heavy 的误差，不是 O(M/L)。即使 L 很大，它只说明 fresh 与 parent 内 μ 平均分配接近，不能把共同总质量 H_L 改成小于自身的量。

未条件化列仍是

    C_0(z)=H_I^{-1}∫1_{z∈P}bar(g)_P dX dW/W.

新 cover 的并集弱型界、其特殊冻结增量点态负载，都没有自动控制此处含原 q/h_J 的连续尺度权重。若以后证明同一 f、同一完整 contact 下 C_new(z)≤A_n+θS_K(z)（μ-a.e.，θ<1 统一，∫S_Kdμ=|K|），则确能推出 H_L≤A_nM+θ|K|；目前该列条件未证明。新 Δ 恒等式没有支付 R631 的 moving-normalizer/clock 角向项，也没有替代共同 A−W_bulk−R−N 取消。原稿对此区分准确。

**本次实际运行：** 使用本机 `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python`、SymPy 1.14.0，约0.15秒，精确核验标量分解、m_P/F_new 抵消、零均值、行 L1/(1−λ)=2λ 和 2δ=5/L；全部残差为0。严格测度论结论依据上述归一化和 Fubini 推导，符号运行不替代其证明。无新一般容量估计，终审完成停止。
