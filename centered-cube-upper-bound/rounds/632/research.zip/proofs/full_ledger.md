# R632 冻结联合总账与实际支付判据（独立审核，Sol high）

来源：R630/631 的 README、完整 REPORT、CONTACT_AUTHOR、relocation、angular 与 flux audit；已读本轮用户提示词及 CONTRACT。固定同一非负光滑紧支撑 f，dμ=f dx、M=∫f、K⊂E1 紧，τ0=3/4，I=[13/16,15/16]、H_I=7/64。以下没有新的根阶估计；是防止费用/量词误接的冻结合同。

**完整 contact 账。** v=(2r)^n，x=y−ru，A(v)=μQ(y−ru,r)，G={A>τ0v}、B=|G|；T 是保留真实 outer-level、β∈I、a0<β 及全部 future 条件的同一 selected 域。准确有

    |K| = H_I^{-1}∫dμ(y) E_u∫_T(β−a0)dv/v,
    |K| ≤ (60/7)L M + H_L(K),
    H_L = H_I^{-1}∫dμ E_u∫_{T,B/v>L}(β−a0)dv/v,    0≤H_L≤|K|.

light 的一次 M 已付，不能再把 heavy 的 dv/v 改为已付时钟的 dv/B。∫_G A′dv=τ0B 与 low-growth 1/7 归约是真实全尺度合同，但不授权删 outer trace、移动方向或为每 ray/level 再发 M。contact 完整界目前只在上述 smooth 范围认证；未来若有输入/尺度一致的完整弱型界，可用 strict 固定半径见证稳定性和 Fatou 恢复一般 L1，不需要且不能预称 contact 核收敛。

**新 cover 实际已付项。** 用 σ 区分覆盖阈值与 τ0。每个合法冻结增量选择满足

    |U|≤(1+A_{n,a}/σ)Σv_j,
    ∫f W_cov≤(σ+E_{n,a})M,
    A_{n,a}=(1+1/t+1/a)^n, E_{n,a}=a^{-n}+α^{-n}J_a.

其 pointwise source load 只属于该算法的特殊权重 w_j=v_j/(2ar_j)^n，不能直接换成 incoming 的权重。优化 σ、令 a→∞ 得一般 L1、全半径的 C_n≤U_n，U_n=nlog n−nloglog n+O(nloglog n/log n)。因此它确实支付真实 Lebesgue |E_s|≤U_nM/s；直接代入原账至多重获 H_L≤|K|≤U_nM，没有净根阶收益。重新选择 future cubes 后还须证明原 contact 收费被新冻结增量账支配，不能让不同被收费来源各用不同选择。

**future 转移保留的完整费用。** 对每个(y,u)共同选 W∈J=G∩[B/2,∞)，h_J≥B/2，v_c=sup T^h≤B/L，F_new=μ(P_W\P_{v_c})>(τ0/2−b1/L)B，b1=15/16，要求 L>5/2。定义 q(y,u)=∫_{T^h}(β−a0)dv/v；以下 incoming 相对 dX dW dμ(z) 为

    J_L(X,W,z)=(H_I W)^{-1}∫_{Q(X,R)}
        f(y) 1_{W∈J} q(y,u)/(h_J F_new)
        ·1_{z∈Q(X,R)\P_{v_c}}dy,
    R=W^{1/n}/2, u=(y−X)/R, C_new(z)=∫J_L dX dW,
    H_L=∫C_new(z)dμ(z),    support_X⊂E_{τ0}.

这只有总质量/row 归一，没有 source 列容量；新 cover 的 Lebesgue 界并不控制任意非负 incoming 在该集合上的密度。完整几何仍含旧 receiver x=X+(1−t)(y−X)、dy=(1−t)^{-n}dx、原 f(X+(x−X)/(1−t))，以及 fresh 条件至少一个 |b_i−(1−t_c)a_i|≥t_c；t_c^n≤2/L 不表示所有旧 t 都接近 t_c，也不允许用 boundary 体积支付 μ。

**唯一可计付款的三个充分判据及完整回代。** 以下必须对每个 f、全部 compact K、同一合法历史/选择成立；允许输入依赖的有利选择，但不能逐 source 各选一个历史。

1. 若 H_L≤θ|K|+A_nM、θ<1，则 C_n≤[(60/7)L+A_n]/(1−θ)。该商达到 √n·polylog n 才支付最终目标。
2. 若 H_L≤q_*|E_{τ0}|+A_nM，则直接用新 cover 得 C_n≤(60/7)L+A_n+(4q_*/3)U_n；q_*=O(1) 仍为 nlog n 量级。若改作未知 C_n 的递推，真实系数是 4q_*/3，必须 q_*<3/4，才有 C_n≤[(60/7)L+A_n]/(1−4q_*/3)。若由未 fresh 条件核支配取得 q_geom，还须 q_*=γ_L q_geom、γ_L=(1−5/(2L))^{-1}，即 q_geom<3/4−15/(8L)。q_geom≈1 无收缩；A_n 还必须包含该支配对所有质量/尾项实际产生的 γ_L 因子，不能只放大递推系数。直接预算若欲根阶，须 (L+A_n)+(q_*/τ0)U_n 本身根阶；阈值/条件化费用不可略去。
3. 直接证 ∫C_new dμ≤θ|K|+A_nM 亦足够；点态 C_new≤A_n 是更强的充分条件，不是必须条件。仅 row 归一、fresh 比例接近1、receiver 支持落在 Eτ、或对每 ray 分别有界，均不支付这个联合量。不能把该核迭代时重新领取 M；level k 的终端要带 (q_*/τ0)^k 并确实趋0。

**signed 路线与旧母账。** 有限共同 cutoff 的完整式为 H_I H_L(φ)=B0+A−W−R−N，0≤B0≤M/8（除以 H_I 为8M/7），N 含重尾时钟 normalizer 的角向导数，A 与负 bulk W 必须共同保留；plateau 上二者分别对数发散。新 cover 尚未支付该共同取消或 N；删除移动方向、future/receiver mask、时钟边界都不合法。R559 的 G²、J_ph、D_clk 等母账费用仍未付；若直接证明上述完整 contact 判据可另走完整接收证明，但不能声称已逐项支付母账。当前登记：接口核对完成；一般新估计0；根阶闭合0。

核算辅助：仅本机 Python Fraction 核 H_I=7/64、b1/H_I=60/7、(1/8)/H_I=8/7、2b1/τ0=5/2 与 τ0−2b1/L；未重算样本、未改仓库。已向 joint_contact_xhigh 发送独立条件卡，待按其具体机制交换审核。
