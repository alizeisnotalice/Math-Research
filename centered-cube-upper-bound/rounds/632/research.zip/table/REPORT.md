# 数值证书逐行复核

结果：21/21 行通过，维数 n=2–20、32、64。每行恰好执行一次原 `verify.py` 的有理运算 `certify`、`finite_certify`。重算并匹配 A、B 和 F 的区间端点、有限 a 的所有五个存储字段；验证 t>1、F_upper<U、a=2^256>2t、有限参数 bound<U，以及 2^n 和 n=7 固定参数。采用 Python Fraction、整数平方根和有理对数包围，未以浮点代替严格不等式。原验证器内置断言检查正性与顺序。

PDF 第 3 页的 21 组 n、t 和十进制 U 已逐项人工录入 `check_pdf_table.py`，以有理数精确比较与 table.json，21/21 一致。该人工录入需以原 PDF 图像复核；旧界 V_n、公开基准、降幅和论文覆盖定理本身不在此次核验范围。此为原验证器公式的独立逐行重新运行和字段对照，而非独立实现该数学推导，也不证明全局最优、渐近根阶或新上界。

运行环境：Python 3.12.14，macOS 27.2 arm64；最高并发 14 个子进程，各 BLAS 线程数 1。实际墙钟 0.1654 秒；各行子进程的用户 CPU 时间之和 0.8187 秒、系统 CPU 时间之和 0.0062 秒（不含进程启动或调度器）；单一子进程峰值 RSS 最大 24,363,008 字节（macOS ru_maxrss，非并发总峰值）。行级时间、返回码和输入 SHA-256 在 results.json；PDF SHA-256 为 28d79c22d79c5fa7ee6d526fac3b982ebfcbd97697b58a1a19dd1332156ed8dd。check_pdf_table.py SHA-256 为 b9ac62c634549d267c3e8a507a4dffe961f40f3a42ea53a9d05c2a7681021201。

复现：`/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r632_table/run_rows.py`；`/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r632_table/check_pdf_table.py`。重跑会重新核算行并覆盖 results.json。
