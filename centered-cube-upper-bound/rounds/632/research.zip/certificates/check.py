#!/usr/bin/env python3
"""Verify rational mass LP certificates by exact independent axis-mask AND.
Input uses D/O rational boxes, additive source boxes, alpha/beta and primal pattern masses.
"""
from fractions import Fraction as F
from math import prod
from pathlib import Path
from hashlib import sha256
import sys,json,time,resource

def q(x):
 if isinstance(x,(float,bool)): raise ValueError('float/bool forbidden')
 return F(x)
def box(z,n):
 if len(z)!=n: raise ValueError('wrong dimension')
 z=[(q(a),q(b)) for a,b in z]
 if any(a>=b for a,b in z): raise ValueError('bad box')
 return z
def overlap(a,b):return prod(max(F(0),min(y,v)-max(x,u)) for (x,y),(u,v) in zip(a,b))
def run(p):
 raw=Path(p).read_bytes(); data=json.loads(raw); n=data['dimension']; D=[box(z,n) for z in data['D']]; O=[box(z,n) for z in data['O']]; B=D+O; m=len(D); l=len(O); src=[(box(s['box'],n),q(s['density'])) for s in data['sources']]
 if n<=0 or any(v<0 for _,v in src): raise ValueError('invalid dimension or density')
 axis=[]
 for i in range(n):
  cut=sorted({x for z in B for x in z[i]}); pts=[cut[0]-1]+[(a+b)/2 for a,b in zip(cut,cut[1:])]+[cut[-1]+1]
  masks=set()
  for t in pts:
   mask=0
   for j,z in enumerate(B):
    if z[i][0]<t<z[i][1]: mask|=1<<j
   masks.add(mask)
  axis.append(masks)
 patterns={(1<<(m+l))-1}
 for masks in axis: patterns={p&s for p in patterns for s in masks}
 demand=[sum((density*overlap(z,s) for s,density in src),F(0)) for z in D]
 cap=[sum((density*overlap(z,s) for s,density in src),F(0)) for z in O]
 total=sum((v*prod(b-a for a,b in z) for z,v in src),F(0))
 if demand!=list(map(q,data['witness_lb'])) or cap!=list(map(q,data['outer_cap'])): raise ValueError('source profile mismatch')
 print('sha256',sha256(raw).hexdigest(),'n',n,'patterns',len(patterns),'axis_mask_counts',list(map(len,axis)),'source_total',total)
 for label,c in data['certificates'].items():
  a=list(map(q,c['alpha']));b=list(map(q,c['beta']));
  if len(a)!=m or len(b)!=l or any(x<0 for x in a+b) or (label=='P0' and any(b)): raise ValueError(label+' invalid dual sign/shape')
  for pat in patterns:
   coeff=sum((a[i] for i in range(m) if pat>>i&1),F(0))-sum((b[i] for i in range(l) if pat>>(m+i)&1),F(0))
   if coeff>1:raise ValueError(label+' dual fails '+str(pat)+' excess '+str(coeff-1))
  dual=sum((x*y for x,y in zip(a,demand)),F(0))-sum((x*y for x,y in zip(b,cap)),F(0))
  primal={}
  for key,val in c['primal'].items():
   if len(key)!=m+l or any(x not in '01' for x in key):raise ValueError('bad pattern')
   pat=sum(1<<i for i,x in enumerate(key) if x=='1'); v=q(val)
   if pat not in patterns or v<0:raise ValueError(label+' invalid primal mass/pattern')
   primal[pat]=primal.get(pat,F(0))+v
  pd=[sum((v for p,v in primal.items() if p>>i&1),F(0)) for i in range(m)]; po=[sum((v for p,v in primal.items() if p>>(m+i)&1),F(0)) for i in range(l)]
  errD=[(i,x-y) for i,(x,y) in enumerate(zip(pd,demand)) if x<y]; errO=[(i,y-x) for i,(x,y) in enumerate(zip(po,cap)) if x>y] if label=='P1' else []
  obj=sum(primal.values(),F(0)); print(label,'dual',dual,'primal',obj,'gap',obj-dual,'witness_deficits',errD,'cap_excess',errO)
  if dual>total:raise ValueError('dual exceeds source')
  if errD or errO or obj<dual:print(label,'PRIMAL FAIL: valid dual only')
  elif obj==dual:print(label,'EXACT OPTIMUM')
  else:print(label,'VALID BOUNDS ONLY')
if __name__=='__main__':
 w=time.perf_counter(); c=time.process_time();run(sys.argv[1]);print('python',sys.version.replace('\n',' '),'cpu_s',time.process_time()-c,'wall_s',time.perf_counter()-w,'peak_rss_bytes',resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
