# Canonical 1D family

Let D0=[-4,4], D1=[-1,3], D4=[0,8], O=[-2,4], and 0<δ<1/2. Use four uniform source blocks of length δ, with endpoints and total masses:

| block | interval | mass |
|---|---|---|
| A | [-4+δ/2,-4+3δ/2] | 2+2δ |
| B | [δ/2,3δ/2] | 4 |
| C | [4-3δ/2,4-δ/2] | 2-2δ |
| E | [8-3δ/2,8-δ/2] | 2+2δ |

The three D masses are 8,4,8, total mass is 10+2δ. The end of each D has a source-free inner band of width δ/2, hence at every r in (r_j−δ/2,r_j), the witness integral is its full value 2r_j>2r. For c=1, the outer gap 2r−μ([1−r,1+r]) at successive breakpoints r=2, 3−3δ/2, 3−δ/2, 5−3δ/2, 5−δ/2, 7−3δ/2, 7−δ/2 equals 0, 2−3δ, δ, 4−δ, 2−δ, 6−3δ, 4−3δ. All are nonnegative; between breakpoints the gap is affine and after the last it rises. For c=0 and c=4, no new mass enters until radius 8−3δ/2, where 2r≥16−3δ>10+2δ; after that the full total mass already gives the cap. Thus all outer caps hold and R*=4,2,4.

For every admissible measure, 1_D0+1_D4−1_O≤1 and the O cap give M≥8+8−6=10. Above family tends to 10, so inf=10. No canonical candidate attains 10: equality forces support in [-4,-2]∪[0,8] and μ(O)=6. For 0<h<1, the center 1 outer cap at r=3−h gives μ([4−h,4])≥2h. Hence μ([-4+h,4−h])≤8−2h, ruling out strict bad radii in (3,4) at center 0. Therefore R*(0)=4 is impossible at mass 10. Endpoint assertions are a.e.; input f is absolutely continuous.

family_check.py provides exact Fraction checks for three rational δ values; the full-parameter assertion follows from the displayed symbolic breakpoint analysis, not from these numerical instances.
