from fractions import Fraction as Q
import sys,time,resource
T=time.perf_counter(); C=time.process_time()
for d in [Q(1,8),Q(1,16),Q(1,32)]:
 P=[(Q(-4)+d/2,Q(-4)+3*d/2,2+2*d),(d/2,3*d/2,Q(4)),(Q(4)-3*d/2,Q(4)-d/2,2-2*d),(Q(8)-3*d/2,Q(8)-d/2,2+2*d)]
 def mass(c,r): return sum((m*max(Q(0),min(b,c+r)-max(a,c-r))/(b-a) for a,b,m in P),Q(0))
 for c,r in [(0,4),(1,2),(4,4)]:
  pts=sorted({Q(r)}|{abs(Q(c)-x) for a,b,m in P for x in (a,b) if abs(Q(c)-x)>=r})
  assert all(2*x-mass(c,x)>=0 for x in pts)
  assert mass(c,Q(r))==2*r
  assert mass(c,Q(r)-d/4)>2*(Q(r)-d/4)
  print('delta',d,'center',c,'outer_gaps',[(str(x),str(2*x-mass(c,x))) for x in pts], 'left_excess',mass(c,Q(r)-d/4)-2*(Q(r)-d/4))
print('python',sys.version.replace('\n',' '),'cpu_s',time.process_time()-C,'wall_s',time.perf_counter()-T,'peak_rss_bytes',resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
