# Exact certificates: seven frozen same-input profiles

Each P0 is minimum nonnegative source mass satisfying μ(D_j)≥f(D_j); P1 additionally imposes μ(O_l)≤f(O_l), with the same source f. All seven P0 and P1 values below have exact nonnegative primal and dual witnesses, and zero gap. Actual f(D), f(O), and total mass are recomputed independently from source-box intersections, including overlapping source blocks. This tests fixed real profiles, not a canonical level-one theorem or an asymptotic dimension bound.

| seed | n | patterns | f mass | P0 | P1 | primal and dual |
|---:|---:|---:|---:|---:|---:|---|
| 63605 | 2 | 2436 | 111/4 | 2809/128 | 2937/128 | exact zero gap |
| 63603 | 2 | 2434 | 17 | 1861/128 | 479/32 | exact zero gap |
| 63509 | 2 | 1312 | 131/8 | 1453/128 | 23/2 | exact zero gap |
| 730104 | 2 | 2847 | 31/2 | 943/128 | 48463095/4286464 | exact zero gap |
| 780001 | 2 | 1927 | 99/4 | 301/32 | 324883/22528 | exact zero gap |
| 770103 | 2 | 2834 | 59/4 | 457/64 | 1054993/97536 | exact zero gap |
| 760502 | 4 | 2168 | 839 | 1101/8 | 20063/128 | exact zero gap |

For each axis, checker partitions the real line at all D/O endpoints and constructs every one-axis membership mask, including unbounded tails. Taking all bitwise AND combinations independently reconstructs all full-dimensional incidence patterns including the zero pattern outside the finite boxes; the dual inequality is checked on every resulting pattern. Each nonzero primal pattern corresponds to an open positive-volume cell, so its mass can be realized by a nonnegative L1 density in a bounded sub-box. This approach does not use supplied pattern lists. In 2D the prior independently implemented Cartesian-cell checker agrees on all 3 older cases (2436,2434,1312 patterns). In 4D the axis mask counts are 48,51,43,51 and their ANDs give 2168 patterns; no large source-grid enumeration is used.

The dual signs are α,β≥0, inequality Σα1_D−Σβ1_O≤1, objective Σα f(D)−Σβ f(O); P0 requires β=0. Fraction arithmetic verifies all primal demand and cap residuals with their exact sign. Two new 2D P1 candidates initially failed: independent rational rounding of their floating primal produced negative demand residuals (and 730104 also cap violations); these candidates were rejected, not treated as numerical tolerances. Exact solution of the identified tight rational equations rebuilt each primal, which the separate checker then verified to have all residuals correct and exact gap zero. Validity is based solely on the final verifier, not the candidate solver, active-set guess, or floating values.

Status: **7 exact; 0 floating-only; 0 unresolved/failed final certificates**. The previously failed intermediate reconstructions and their negative residuals are described above; the final `check_*.txt` contains the accepted exact results.

All contents necessary to reproduce results are check.py and profile_SEED.json; the latter contains only rational boxes, additive source blocks, exact f-derived profiles and sparse primal/dual certificates, with no saved full-cell lists. Run `/usr/bin/python3 check.py profile_SEED.json` for each input. check.py depends only on the Python standard library. `canonical_family.md` contains the independent full-parameter one-dimensional canonical proof, and `family_check.py` supplies three supplementary rational test instances; these profiles are separate from that canonical family.

Actual final verifier commands used `/usr/bin/python3`, Python 3.9.6, Clang 21.0.0. Peak RSS values are macOS bytes. CPU / wall seconds / RSS bytes: 63605 0.311/0.313/14417920; 63603 0.309/0.310/14712832; 63509 0.093/0.093/13959168; 730104 0.838/0.840/15237120; 780001 0.314/0.315/14385152; 770103 0.876/0.881/15040512; 760502 0.081/0.081/14041088. Runs used at most two single-thread processes. Active-set rational reconstruction used Python 3.12.14 and SymPy 1.14.0: 730104 CPU 0.094 s, wall 0.097 s, RSS 71598080 bytes; 770103 CPU 0.107 s, wall 0.107 s, RSS 72941568 bytes. It is not required by the portable checker.

SHA-256 of check.py: ec91ddb8c31de757127463890035707798c4d5ef5f58083050e759d29bf54f9c. File hashes of all final inputs are in SHA256SUMS.
