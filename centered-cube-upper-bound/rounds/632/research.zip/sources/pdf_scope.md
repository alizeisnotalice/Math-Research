# R632 source/PDF formula and citation scope

Read-only comparison; no mathematical certification performed.

## Formula and seven-dimensional table match

The readable source is `/Users/zhengzhihao/Math-Research-centered-cube-work/cube-dim-7-bounds/paper/main.tex` (SHA-256 `8135adfb51470228ed18371c6c5f1a22caac0b35523b0cd49c50b13cfb9b386b`). In source lines 91–99, equations `eq:A` and `eq:B` define

\[
A_n(t)=(1+1/t)^n,\quad B_n(t)=1-((1+1/t)/2)^n+n\log t-\frac n2\int_1^t(1+1/(2t)-1/(2\rho))^{n-1}\,d\rho/\rho,
\]

and Theorem `thm:main` gives (C_n\le(\sqrt{A_n(t)}+\sqrt{B_n(t)})^2). The rendered native PDF page 2 (image SHA-256 `e246c7a5d80dafc01acc750f8e2fb68b17650dd62e2cc0f0d19f4677bffdf831`) visibly has the same (A_n,B_n) terms, same integral, and same theorem. PDF p.10 discusses formula-family (U_n=\inf_{t>1}F_n(t)) and limitations; it refers back to the earlier formula. So the central formula is the same version.

The seven-dimensional table entry is actually on native PDF **p.3** (not p.10 or p.11); its image SHA-256 is `9bb9dbbe89b89e05d8119d6b23c4392f59cd31cca29dcc7084b8030bdaa0c48e`. Row (n=7) shows (t=3391749/524288), (U=24.554960525965), old benchmark (V_7=24.554961) rounded, and “同参数”. Source table `/Users/zhengzhihao/Math-Research-centered-cube-work/cube-dim-7-bounds/paper/dimensions_table.tex` (SHA-256 `ef87f43eeafaf38473fd373a478ffb3cefafb6339bc4b12f5053a08f47e151ab`) has the same row. The revision report states the retained strict bound as (C_7<4910992105193/200000000000=24.554960525965) (`revision_v3/REPORT.md`, line 18). Thus formula, parameter, displayed (U), and the “same parameter” qualification align.

Scope caveat: this confirms the formula and (n=7) table record, not byte-for-byte identity of the entire PDF and current `main.tex`. Current `main.tex` also contains explicit newer large-dimension theorems in its abstract/body; the inspected PDF p.2 instead presents the formula-family asymptotic. Page 10 of the inspected PDF says the optimized fixed formula family still has leading coefficient 1 and cannot determine the true (C_n) asymptotic coefficient. Treat page-specific versions/claims accordingly.

## References on PDF p.11

Native PDF page 11 image SHA-256: `c5f64b4d2b903d7fda8cf8a395480d2605ca07d4bf981c2cfd4516a57b01450b`. The bibliography entries [1]–[6] are identifiable public sources:

1. Stein–Strömberg (1983), published journal article, DOI 10.1007/BF02384314.
2. Aldaz, *Kissing numbers and the centered maximal operator* (arXiv:1811.10478v2, 2020), public preprint.
3. Aldaz, *The weak type (1,1) bounds for the maximal function associated to cubes grow to infinity with the dimension* (Annals of Mathematics 173 (2011)), published article.
4. Aldaz, *The Stein–Strömberg covering theorem in metric spaces* (JMAA 449 (2017), DOI 10.1016/j.jmaa.2016.11.070); PDF says theorem 5.2 uses arXiv:1605.05596v2.
5. Melas (2003), *The best constant for the centered Hardy–Littlewood maximal inequality* (Annals of Mathematics 157), published article.
6. T. S. Tomar, *Bounds for the weak type (1,1) constant of the centred maximal operator over squares*, publicly released v4 preprint dated 22 Oct 2026, DOI 10.5281/zenodo.23554628.

Entry [7] is **not a public publication**: the PDF calls it “前期研究资料，中心立方体极大算子逐维上界的准确证书，2026年10月27日资料包快照，未发表,” and says the exact expressions, intervals, and source hashes are incorporated as supplementary material. On p.3 the internal [7] is used in the old (V_n) comparison for n≤8; for n≥9 the note says the public generic baseline is used. The paper's own references at the end of current `main.tex` only list Stein–Strömberg, Aldaz 2020, and Aldaz 2017; it does not include PDF entries [3], [5], [6], or internal [7].

## Page pointers and artifact hashes

- Requested native p.2 image: `/tmp/ccu_r632_pdf/native/page-02.png`, SHA-256 `e246c7a5d80dafc01acc750f8e2fb68b17650dd62e2cc0f0d19f4677bffdf831` — core formula/Theorem 1.
- Native p.3 image (additional, needed for n=7 table): `/tmp/ccu_r632_pdf/native/page-03.png`, SHA-256 above — full table row and [7] baseline scope.
- Requested native p.10 image: `/tmp/ccu_r632_pdf/native/page-10.png`, SHA-256 `18386962e784b44650964b2b898ce6ce247039f00bc537d25176446fb59ab460` — formula-family optimization and limits on interpreting (U_n).
- Requested native p.11 image: `/tmp/ccu_r632_pdf/native/page-11.png`, SHA-256 above — Appendix A and references [1]–[7].
