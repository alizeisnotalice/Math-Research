# R632 原始来源条件核验

范围：只核对 cover 引言中的 Stein–Strömberg (1983)、Aldaz arXiv:1605.05596v2 Theorem 5.2，以及 Bourgain cube strong-\(L^p\) 定理对 bounded-density 分支的适用范围。原始来源优先：SS 与 Aldaz v2 使用本机缓存 PDF；Bourgain 使用作者 arXiv 原文 HTML。没有核新根阶引理。

## 三项原定理与可用范围

| 来源与原文位置 | 原定理（准确量词） | 常数与维数依赖 | 对当前方体模型 |
|---|---|---|---|
| Stein–Strömberg (1983), Theorem 1, 印刷 p.260；证明 §2, pp.260–263（缓存 PDF p.2 起） | 对任意有界、开、凸、中心对称集合 (B\subset\mathbb R^n)，Lebesgue 中心极大算子 \(M_B\) 满足弱型 \((1,1)\)：\(\lambda\{|M_Bf|>\lambda\}\le c\,n\log n\,\|f\|_1/\lambda\)，(n>1)。半径在所有正值上取上确界。 | (c) 是绝对常数，与 (B,n) 无关；原文未给出可直接当作最优或显式数值的系数。 | 开轴平行立方体是此类 (B)，故支持 cover 中一般凸体 (O(n\log n)) 背景句。它是弱型端点几何覆盖结论，不是维数无关的强 (L^p) 结论。 |
| Aldaz (2017), Theorem 5.2, arXiv v2 印刷 p.14（证明续至 p.15） | 在 \(\mathbb R^d\) 的 Lebesgue 测度下，若球由任意范数定义，则对每个固定 \(\varepsilon>0\)，当 \(d\ge d(\varepsilon)\) 充分大时，\(\|M\|_{L^1\to L^{1,\infty}}\le(2+3\varepsilon)d\log d\)。 | 前导系数为所写的 \(2+3\varepsilon\)，没有额外未写的乘法常数；阈值 (d(\varepsilon)) 依赖固定 \(\varepsilon\)，原文不给统一显式阈值。不能令 \(\varepsilon=\varepsilon(d)\to0\) 并沿用此证明。 | 任意范数球包含轴平行立方体；支持 cover 中“固定 ε、充分大维数”的一般范数球弱型界。不是强型定理，也不提供全部有限维数同一显式界。 |
| Bourgain (arXiv:1212.2661), *On the Hardy–Littlewood maximal function for the cube*, Introduction, p.1 的定理（未编号） | 令 (B_\infty^{(n)}=[-1/2,1/2]^n)，\(M_Bf(x)=\sup_{t>0}|B|^{-1}\int_B|f(x+ty)|dy\)。定理断言对每个固定 \(p>1\)，\(\|M_{B_\infty^{(n)}}f\|_p\le C_p\|f\|_p\)，对所有维数 (n) 成立。 | (C_p) 只依赖 (p)，不依赖 (n)；文中不给用于这里的显式 (C_{4/3}) 数值。此处可取 (p=4/3)。 | 这是中心轴平行立方体、Lebesgue、所有 (t>0) 的全尺度结果。取 (t=2r)，平均正是本稿 (Q(x,r)=x+(-r,r)^n) 的平均。因而对任意 (g\in L^{4/3})（尤其 (g=\min(f,T))，若 (f\in L^1_+, T<\infty)），bounded-density 分支可调用维数无关的强 (L^{4/3}) 控制。 |

## 防混同结论

- Stein–Strömberg 的一般对称凸体 Theorem 1 是弱 (L^1)、增长为 (n\log n)；该文同一 §2 后续所述一般 (L^p) 估计也随 (n) 增长，不能把它改述成维数无关强型。
- Aldaz Theorem 5.2 是固定 \(\varepsilon\)、充分大维数的弱 (L^1) 结果；与 Bourgain 强 (L^p) 的对象、范数和端点都不同。
- Bourgain 的 1986 年一般凸体结果曾给维数无关强型范围 (p>3/2)；立方体特定论文 1212.2661 才证明 cube 情形对全部固定 (p>1)，所以 (4/3) 的调用必须引用这篇 cube-specific 定理。该定理不含 (p=1)，不推出强 (L^1) 或弱 (L^1) 端点，也不单独支付任意全 (L^1) 输入上的弱型覆盖/历史费用。对 bounded (g\in L^1)，可用 \(\|g\|_{4/3}^{4/3}\le\|g\|_\infty^{1/3}\|g\|_1\)，但后续仍须按本分支自己的推导把该估计接入。

## 原始来源

1. E. M. Stein and J. O. Strömberg, “Behavior of maximal functios in \(\mathbb R^n\) for large (n),” *Arkiv för Matematik* 21 (1983), 259–269, Theorem 1 p.260, §2 pp.260–263. [Springer DOI](https://doi.org/10.1007/BF02384314).（原刊题名拼写 `functios` 如此。）
2. J. M. Aldaz, “The Stein–Strömberg covering theorem in metric spaces,” *Journal of Mathematical Analysis and Applications* 449 (2017), 1741–1753, Theorem 5.2 p.14; 核对版本 arXiv:1605.05596v2. [原文 v2](https://arxiv.org/abs/1605.05596v2), [期刊 DOI](https://doi.org/10.1016/j.jmaa.2016.11.070).
3. J. Bourgain, “On the Hardy–Littlewood maximal function for the cube,” arXiv:1212.2661, Theorem in Introduction, p.1; 原文定义 (1.1)–(1.2). [作者原文](https://arxiv.org/abs/1212.2661).
