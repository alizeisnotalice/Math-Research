# 有限族有符号对偶与选择：技能条件摘录（R632）

**可直接由有限有理 LP 弱对偶认证（固定参数、固定有限模型）。** 固定一个输入点/场景 x、有限候选族和有理数据，明确目标方向、约束及乘子符号。对最小化、约束 gᵢ(z) ≤ 0，乘子 λᵢ ≥ 0；等式乘子自由。核验原可行解 z 与对偶可行乘子 (λ,ν)，则 q(λ,ν) = inf_z L(z,λ,ν) ≤ f(z)。若显式有限 LP 有原、对偶可行点且精确 gap 为零，即认证该 LP 的最优值；非零 gap 只给方向正确的界。有限混合 LP 的证书充分性不需 rank/Slater。外帽若是有限模型内明确的线性不等式，可按真实方向加约束及非负乘子；帽本身不证明它覆盖原始无限问题。候选、等式、符号、目标值与 gap 应用精确算术核验，浮点残差不作证书。来源：`/Users/zhengzhihao/.codex/skills/math-b01-lagrange-farkas/SKILL.md` 步骤1–2、4、9；`references/method.md` 同项。

**共同选择约束。** 若有限场景代表同一个真实输入，尺度、捕获节点、质量/对偶变量须建成共享变量；历史不可区分的场景决策须相等。有限情景图中每个信息块的诱导子图连通，足以由等式传递实现整块非前视；逐场景各自找可行或最优 LP 解，不等于存在一个共同合法选择。这里只认证已编码的有限模型：P-56 的连接性判据可用；一般逐 cut 独立取树不保证全局最少边。来源：`/Users/zhengzhihao/.codex/skills/math-a04-shared-nonanticipative-mip/SKILL.md` 步骤1–6及 `references/method.md`。

**仍需额外论证的跨层结论。** 若要把逐点 R*(x) 的有限族最优值/对偶界用于所有 x ∈ ℝⁿ 上的可测输入依赖选择，有限 LP 弱对偶本身不够：须给出参数可测空间、可行多值映射的图像/逆像可测性，以及所用选择定理要求的非空紧值、目标可测性或 Carathéodory 正则性。逐点最优解存在或逐点选取不蕴含可测选择。M04 只核验五个参数点上的有限选择器；一般可测最大值/选择定理仍未完成，不能把技能标题当作全维选择定理。若有限族是对连续尺度、中心或历史的截断，还须另证截断误差/极限交换；全无限指标的 liminf 尾与截距 inf 不能由有限采样认证，上确界可测性也不自动保证有索引达到。若有 signed/DC 或 min-max 结构，逐个对手参数分别选乘子（∀μ ∃λ）不构成共同乘子（∃λ ∀μ）；须另证量词交换/鞍点条件。来源：`/Users/zhengzhihao/.codex/skills/math-m04-measurable-supremum-selection/SKILL.md` 范围声明与步骤1–6、`references/method.md`；`/Users/zhengzhihao/.codex/skills/math-b01-lagrange-farkas/SKILL.md` 步骤6–8及其 `references/method.md`。

**适用边界。** 以上是技能明确允许的方法条件，不是对当前 R*(x) 的模型映射、全维可测选择、外帽有效性或任何新引理的验收。中心立方体接口要求列明真实输入/工具变量映射、假设、界方向及尚缺连接引理；目录名不构成定理。来源：三项技能各自 `references/cube-interface.md`；合同 `/tmp/ccu_r632_team/CONTRACT.md`。
