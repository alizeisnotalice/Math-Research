# R617 / R619 对象与量词对照（历史最终稿）

范围：仅依据 rounds/617、619 的 `REPORT.tex` 与 `AUDIT.md`（均取自相应 `research.zip`），未复核证明，也未读取更早历史。段号指最终稿中的段落/公式标签；压缩包内文件路径为 `rounds/617/research.zip::REPORT.tex` 等。

## R617：固定同一次 selection 上的接收点预算

**定义与固定输入。** REPORT §“Frozen common object”第13–42段、式(elig)、(U)：承接 R616 实际有限选择 (B_j=B(y_j,r_j))、实际增量 (I_j)、权 (w_j=|I_j|/(2ar_j)^n)，且每个所选中心满足原 selection eligibility Σ_{j<k} w_j 1_{bB_j}(y_k)≤τ)。对一个固定接收点 (x)，固定其贡献集合 (S_x)，末尾 (K) 项 (V)、强制末见证 (k_*)，prefix (J)、tail、(r_0,s,u_k) 等；所有候选子集 (T⊂V) 必须含 (k_*)，省略候选也不改变这些基准量。式(U)给该点的包络 (U(T)=|T|τ+Q+ν(D_T)-O(T))。AUDIT.md §1、§5（式(6)–(9)）逐项强调 prefix/tail 与同一 selection 不得随 mask 改选。

**D、C。** REPORT §“A quantitative joint-cost decrease”第44–76段，式(marg)–(extra)，特别是定义段第52–60段：令 (D_0=G_{k_*}^c)，可选见证 (E=V\setminus\{k_*})，(b_k=ν(D_0∩G_k))，(b_{kℓ}=ν(D_0∩G_k∩G_ℓ))，(B_k=Σ_{j∈J:A_{jk_*}=1}w_jA_{jk})。然后

\[
D=\sum_{k∈E} w_k(b_k+B_k-τ),\qquad C=\sum_{k<ℓ∈E}w_kw_ℓb_{kℓ}≥0.
\]

式(decrease)声称：对 (0≤θ≤1/w_{max})，存在一个合法实际见证集合 (T\ni k_*)，使 (U(T)≤U_0-θD+θ²C)。其 (D,C) 是固定 (x)、固定 selection/prefix/tail/(r_0,s)、固定候选池和**同一套实际权/捕获关系**计算的量；(D) 将新增几何捕获、对已由 (k_*) 捕获 prefix 项的重复信用与候选费用合在一起，(C) 是成对几何重叠罚项。这里对 optional witness 做的独立 Bernoulli 抽取只用于有限候选的存在性证明，REPORT 第69–70段明确不改变原 selection 或随机化输入。

**量词边界。** 式(decrease)是每个固定接收点合同内的存在性结论；参数、候选池、积分域均可能依赖 (x)。REPORT §“Actual radius and the full source integral”式(global)、第145–162段指出仍需对任意 (f) 证明完整 ∫|f(x)| 加权预算；有限样本 D>0/J>0 不是统一结论。AUDIT.md §7（末段）也说明真实增量 histogram 不等于原任意 L1 来源质量帽，需同一次 selection 和全源积分。

## R619：全有限家族的辅助源质量与 packing 量

**定义与固定输入。** REPORT §“The full object and the unsolved objective”第6–9段：任意有限 supplied cube family (B_j)，(A_j=aB_j)，(I_j) 是按给定顺序的真实 receiver 不交增量，(v_j=|I_j|)、(V=|U|=Σv_j)。删去零增量行后对保留家族构造 packing λ 和实际非负 L1 辅助源 μ。

REPORT §“A positive packing with precisely paid excess”第10–20段：对每个 ε>0 以带 (εΣv_j\log λ_j) 正则项求 packing；cell 乘子给出辅助源 μ，令 (M=μ(\mathbb R^n))、(Q=Σλ_jd_j)、(d_j=|A_j|)，满足

\[
M=Q+εV,\quad λ_j(μ(A_j)-d_j)=εv_j,\quad Q≤m_*≤Q+εV.
\]

REPORT §“A rigorous full-family regime”式(κ)（第34–43段，式(39)–(41)）：定义

\[
κ=\frac{Σ_j v_j μ(A_j)}{V M}∈(0,1], \qquad κV≤PM,\;P=(1+1/a)^n.
\]

此处 μ 是由本轮 packing/KKT 人工构造、覆盖该**完整保留有限家族**的辅助 source；不是输入 (f)，也不是对每个 (x) 另选的来源。λ 同样是整个家族的共同 packing。若预先设 (ε=θ_n/(2P))，只有在构造后证得 (κ≥θ_n) 的条件分支，才能推出 (V≤2P Q/θ_n)。R619 的 Hall coupling / directional Ψ 另是 source-cell pair 的全局分布（REPORT 式(30)–(33)），不改变 κ 定义。

## 是否同一对象；缺失桥

**不是同一对象，当前档案没有对象等式或可直接代入的映射。** R617 的 (D,C) 是在给定实际 selection 与接收点 (x) 下，对一批 witness 几何帽及 prefix 的带权局部减量系数；其权来自真实增量 (w_j)，其积分 ν 是归一化的几何测度。R619 的 κ 是“receiver 增量体积 (v_j) × 辅助源在整颗 star 上的质量 (μ(A_j))”的全族归一化相关量，依赖另行构造的 μ、全族 packing λ 与正则化 ε。无量词、权重或积分测度上的同一性：(D,C) 不含 μ，κ 不含 witness 集合、(G_k)、prefix-credit (B_k) 或二阶重叠 (b_{kℓ})。

若要连接，至少需新证一个统一桥：将每个 (x) 的合法同-selection 候选池及 (D,C) 减量，经可测选择和完整 ∫|f(x)| 积分，转成 R619 同一全局 μ/λ 下的 (κ) 下界（或等价地让 κ 约束这些点态减量），同时保留 ε excess、tail 和全部历史 eligibility 费用。R617 自身把这类 uniform source-integrated payoff 列为缺失；R619 则把低 κ、相互交织组件的付款列为缺口（REPORT 第43–44段）。现有报告没有完成此桥，故不能把 R617 的点态正 D 或有限实例收益认作 R619 的 (κ≥θ_n)，也不能反向将 R619 的条件性 κ-regime 当成 R617 对任意 (x) 的减量保证。
