s=[-3 -2.5 2;-2.5 -2 2.2;0 .5 1.8;.5 1 4.4;2.5 3 1.8;3 3.5 2;3.5 4 1.8;6 6.5 4.2];
xs=[0 1 4]; targets=[4 2 4];
for k=1:3
 x=xs(k); R=targets(k); pts=unique([0;abs(s(:,1)-x);abs(s(:,2)-x);R]);
 g=@(r) sum(max(0,min(s(:,2),x+r)-max(s(:,1),x-r)).*s(:,3))-2*r;
 vals=arrayfun(g,pts); cap=max(vals(pts>=R)); left=g(R-.25); equality=g(R);
 fprintf('x=%g R=%g max_tail_G=%.15g G(R)=%.15g G(R-0.25)=%.15g\n',x,R,cap,equality,left);
 assert(cap < 1e-12 && abs(equality)<1e-12 && left>0);
end
