for name = ["3d", "control"]
 load('profile_'+name+'.mat');
 n=size(B,1); m=zeros(n,1); v=zeros(n,1);
 for i=1:n
  v(i)=prod(B(i,2:2:end)-B(i,1:2:end));
  for j=1:size(S,1)
   lengths=max(0,min(B(i,2:2:end),S(j,2:2:2*dim))-max(B(i,1:2:end),S(j,1:2:2*dim)));
   m(i)=m(i)+S(j,end)*prod(lengths);
  end
 end
 fprintf('%s boxes=%d mass_error=%.12g volume_error=%.12g receiver_union=%.12g\n',name,n,max(abs(m-expectedMass(:))),max(abs(v-expectedVol(:))),unionExpected);
 assert(max(abs(m-expectedMass(:)))<1e-9 && max(abs(v-expectedVol(:)))<1e-9);
 if exist('linprog','file')==2
  lo=1:5:n; up=setdiff(1:n,lo); objective=ones(size(A,2),1); opts=optimoptions('linprog','Display','none');
  [z0,p0,e0]=linprog(objective,-A(lo,:),-m(lo),[],[],zeros(size(A,2),1),[],opts);
  [z1,p1,e1]=linprog(objective,[-A(lo,:);A(up,:)],[-m(lo);m(up)],[],[],zeros(size(A,2),1),[],opts);
  fprintf('linprog %s P0=%.12g P1=%.12g exit=%d,%d primal_violation=%.12g\n',name,p0,p1,e0,e1,max([0;m(lo)-A(lo,:)*z1;A(up,:)*z1-m(up)]));
 else
  fprintf('linprog unavailable\n');
 end
end
fprintf('MATLAB %s\n',version)
