from fractions import Fraction as F
import json,sys

def check(segs, xs):
    segs=[tuple(map(F,s)) for s in segs]
    def mass(x,r):
        return sum((max(F(0),min(b,x+r)-max(a,x-r))*v for a,b,v in segs),F(0))
    for x in map(F,xs):
        points=sorted({F(0)}|{abs(z-x) for a,b,v in segs for z in (a,b)})
        def g(r):return mass(x,r)-2*r
        bad=[]
        for a,b in zip(points,points[1:]):
            ga,gb=g(a),g(b)
            if ga>0 or gb>0:
                l=a if ga>=0 else a+(b-a)*(-ga)/(gb-ga)
                h=b if gb>=0 else a+(b-a)*ga/(ga-gb)
                if l<h: bad.append((l,h))
        assert g(points[-1])<=0
        star=max((h for l,h in bad),default=F(0))
        print('x=',x,'breakpoints=',[(str(r),str(g(r))) for r in points])
        print('strict bad pieces=',[(str(a),str(b)) for a,b in bad], 'r*=',star)
        if star:
            prior=[a for a,b in bad if b==star]
            delta=star-max(prior)
            assert delta>0 and g(star-delta/2)>0 and g(star)==0
            assert all(g(r)<=0 for r in points if r>=star)
            print('left-neighborhood radius=',delta,'midpoint margin=',g(star-delta/2),'tail slope=-2')
if __name__=='__main__':
    if len(sys.argv)>1:
        data=json.load(open(sys.argv[1]));check(data['segments'],data['centers'])
    else: check([(-4,-3,2),(0,1,4),(3,5,2)],[0,1,4])
