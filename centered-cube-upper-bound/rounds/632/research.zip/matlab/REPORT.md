# Independent 1D radius audit

Input for old example: /tmp/ccu_r632_cover_same_input.md; f=2 1[-4,-3]+4 1[0,1]+2 1[3,5], centers 0,1,4. Exact Python Fraction script check.py finds strict-bad last radii 2,2,2, with strict excess on (1,2) for each; all caps r>=2 follow by affine interpolation between endpoint distances and negative slope -2 at the tail. Thus original radii 4,2,4 are not all canonical.

Repaired input repaired.json transcribes /tmp/ccu_r632_certificates/result.md independently. Exact script finds radii 4,2,4, strict bad throughout (7/2,4), (3/2,2), (7/2,4); midpoint excess is 1/20 in each. All computed endpoint excesses at or beyond these radii are <=0; affine interpolation and tail slope -2 certify all larger radii. This is a finite exact verification, not a dimension-order theorem.

Commands: /usr/bin/time -l /Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r632_matlab/check.py [ /tmp/ccu_r632_matlab/repaired.json ]. Python 3.12.14; repaired run 0.03 s wall, 0.01 s user, 17,809,408 bytes maximum resident. No dense grid; fractions are exact.

MATLAB MCP previously reported jupyter.Idler failure. Installed /Applications/MATLAB_R2026a.app/bin/matlab supports -batch -singleCompThread. Independent batch command /usr/bin/time -l /Applications/MATLAB_R2026a.app/bin/matlab -batch "disp(version); disp(1+1)" -singleCompThread -sd /tmp/ccu_r632_matlab succeeded: 26.1.0.3312084 (R2026a) Update 4; output 2; 60.60 s wall, 4.90 user, 0.94 sys, max RSS 1,142,292,480 bytes. It used a separate process and did not change the existing MATLAB session. A second batch executes crosscheck.m for floating-point cross-validation; see its completion record below.

MATLAB cross-check command: /usr/bin/time -l /Applications/MATLAB_R2026a.app/bin/matlab -batch "run('/tmp/ccu_r632_matlab/crosscheck.m')" -singleCompThread -sd /tmp/ccu_r632_matlab. Completed exit 0, 17.07 s wall, 4.73 user, 0.76 sys, max RSS 1,148,813,312 bytes. Tail maxima of mass−2r were 0, 8.88178419700125e-16, 0; left midpoint excesses 0.0500000000000007, 0.0500000000000003, 0.0500000000000007. Floating values are cross-check only; exact justification is the Fraction computation.
