# R632 reproducibility and scope

General `C_n <= n^(1/2+o(1))` remains unproved. Read REPORT.tex and proofs/full_ledger.md first. The source PDF is the user's original, not a compiled output from this round.

All paths below are relative to the extracted archive. Python mathematical runtime used for exploration:
`/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python` (3.12.14, NumPy 2.5.4, SciPy 1.18.1, SymPy 1.14.0). Strict certificate checker needs only the standard library; its original author runs also record system Python 3.9.6.

## Strict certificates

From `certificates/`, run `python check.py profile_730104.json`, or substitute any of the seven profile files. The checker recomputes the full incidence set and actual source integrals, checks nonnegative primal/dual feasibility and exact zero gap. It does not trust floating solver status or a saved incidence list. `python family_check.py` checks three supplementary rational canonical instances; the general parameter proof is in `canonical_family.md` and proofs/canonical_audit.md.

From `table/`, run `python verify.py`. It checks all 21 rational paper-table certificates, including finite-a inequalities. The underlying theorem is independently audited in proofs/cover_core.md and proofs/cover_parameters.md. Reusing the original table verifier is not a second independent implementation of its mathematics.

## Numerical exploration

From `numeric/`, `python reproduce.py --list` lists the frozen cases without solving them. For a selected case run, for example, `python reproduce.py --seed 730104 --origin expanded512`, or `--seed 710700 --origin expanded512` for seven dimensions. Input reconstruction is hash-checked. Do not interpret successful floating reproduction as a strict certificate.

summary_512.json covers all 512 expanded candidates; summary_initial44.json covers the 44 initial and control runs. These records retain seeds, dimension, family size, source generator, center scaling, input hash, real receiver union, source mass, constraint residuals and resources. The large source-cell arrays and raw repeated input JSON remain locally available under /tmp/ccu_r632_geometry and are intentionally not archived. BATCH_RESULTS.md describes the original conservative skips; DP_RESULTS.md records their later completion. Final status is 512 executed, 509 connected; 125 connected seven-dimensional cases gave floating ratio one. No exponent is inferred.

## MATLAB

From `matlab/`, run `/Applications/MATLAB_R2026a.app/bin/matlab -batch "run('profile_check.m')" -singleCompThread -sd "$PWD"` for the two saved cross-check matrices, or run crosscheck.m for the repaired canonical example. These scripts were made path-relative for packaging; the report preserves original actual command paths. MATLAB needs Optimization Toolbox for linprog; without it the geometric cross-check still runs. These are floating checks. Run `python check.py repaired.json` for the separate exact one-dimensional radius calculation.

## Evidence distinctions and corrections

- Old equal-contact examples were not all canonical. The repaired full-parameter canonical result has infimum 10, not attained; it is one-dimensional mechanism evidence only.
- Finite profile caps use actual `f(O)` values, not the uniform canonical bound `|O|`. They are a different, explicitly labelled diagnostic.
- Two initially rounded primal LP witnesses failed exact signs. The final rational active-set reconstruction was independently checked; no tolerance was accepted.
- Original numerical profile code already intersected coordinate masks. The later implementation removed a conservative Cartesian-size rejection and retained representative cells; this is not a new geometric dimension estimate.
- Contact and selection formulas are exact identities or conditional interfaces. None pays the complete heavy/source-reuse budget.
- Some pre-interruption temporary experiments described in earlier context were no longer available. No such missing inputs or results are used as evidence in this archive.
- All agents finished their bounded tasks; completed agents are not counted as currently running. The three integration Astra agents used xhigh. Sol/Terra/Luna integration roles used high. Service-capacity failures were retried to save checkpoints.

SHA256SUMS.json binds the final archive members; this establishes identity, not mathematical validity. ROOT_CHECKS.json records actual checks of the packaged files. No PDF compilation was performed.
