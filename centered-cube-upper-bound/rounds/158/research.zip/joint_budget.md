# R158：两尺度盒外双核的实际责任吸收与共同 α 余额

有限结论：在原多数失捕获来源上，得到同时适用于所有实际 soft/尺度选择的逐点核比；它直接使双核责任成为原完整正交通的显式小比例，不需要先用 good 门除以 w_g，也不产生新的 η、时间或接收包络费用。共同 α 按原 producer 保留，并给出部分来源几何能够推出的准确余额下界。J 责任的真实接收费用仍未证明根阶；本文不把核归一化或新的矩记号当作付款。

## JB1. 候选、量词及原测度

固定任意维数 n≥1、原预先标签及合法行，a≤L≤L⁺≤b、b/a≤2，L⁺=min(b,(1+1/n)L)。原
\[
 p=P_{s,L}(x-y),\quad K_1=P_{s,L}(x-v),\quad
 K_2=P_{s,L^+}(x-v),\quad J=P_{1,b}(x-v),\quad
 Q_v=(K_1+K_2+J)/3
\tag{JB1}
\]
均保持不变，0≤s≤1。保留原 ν、β、j、time、删除后验 Π、good/bad/history 门及
\[
 A_v=T\Delta_v,\quad
 \rho_v=[1-(DK_{0,v}+\alpha J_v)/A_v]_+
\tag{JB2}
\]
在其原有效来源上的定义。A_v=0 或无有效来源的分支不使用该除法，其正交通为零。

令 r=N_{L⁺}(x,v,z) 为已激活 score 坐标中满足 |x_i-v_i|>L⁺/2 的个数。它是原实际计数，可以依 x,j,t,v；没有按辅助来源重选接收参数。

先筛选并将在下文证明的命题是：对任意原可测正交通子域 E，若 JB5 的实际 ε_v≤ε₀，则在同一原交通测度下
\[
 P_{12}(E)\le\frac{\varepsilon_0}{1+\varepsilon_0}P(E),\quad
 P_{12}(E)\le\varepsilon_0P_J(E),\quad
 P(E)\le(1+\varepsilon_0)P_J(E).
\tag{JB3}
\]
这里三个量仅按原三核责任分解，不改 ρ 或任何来源权。尤其多数坐标同时盒外、s≤1/4 的一段输入有指数小 ε₀。此命题本身不要求 η 下界或来源独立，也不需要先冻结 s,L 再付 selector。

## JB2. 一维核比：不把去掉 s 的核交给 FIRST

沿原 h₁=1_{[-1/2,1/2]}，φ=h₁*w，w(u)=∫₀¹exp(−|u|/r)dr。记
\[
 m_*:=\phi(1/2)
 =\int_0^1r(1-e^{-1/r})dr
 \ge(1-e^{-1})/2>1/4,\qquad
 c_s:=s+(1-s)/m_*.
\tag{JB4}
\]
φ 正、偶、径向不增。对任意 H≤b 及实数 ξ，若 |ξ|>H/2，则
p_s(ξ/H)=sφ(ξ/H)≤sφ(ξ/b)；若 |ξ|≤H/2，则 φ(ξ/b)≥m_*，且 φ(ξ/H)≤φ(ξ/b)，故 p_s(ξ/H)/φ(ξ/b)≤c_s。这包括硬核边界，且 c_s≥s。

对 H=L 或 L⁺，在计入 r 的每个坐标上均有 |x_i-v_i|>H/2。因此逐坐标相乘得到
\[
 \frac{K_H(x,v)}{J(x,v)}
 \le(b/H)^n s^r c_s^{n-r},\qquad
 \varepsilon_v:=\bigl[(b/L)^n+(b/L^+)^n\bigr]s^r c_s^{n-r},
 \qquad K_1+K_2\le\varepsilon_vJ.
\tag{JB5}
\]
s=0,r>0 时双核准确为零；r=0 时按空乘积 s⁰=1 定义，不作 0/0。J>0，所以核比处处定义。

JB5 保留真实尺度损失 (b/H)^n 和非失捕获坐标的 c_s^{n-r}。它同时适用于所有 s,L、x,v；无需为这些参数另选网格。与上一轮仅写 K_H=s^r tildeK 相比，它额外以同一真实 J 支配 tildeK 的剩余因子，给出有数值大小的统一核比。没有使用 ∫tildeKν≤q，也没有再次乘已经被 FIRST 使用过的 s^r。

## JB3. 明确的指数范围

由 b/H≤2、m_*>1/4，若 s≤1/4，则
\[
 \varepsilon_v\le2^{n+1}(1/4)^r4^{n-r}
 =2^{1+3n-4r}.
\tag{JB6}
\]
因此 r≥7n/8 时 ε_v≤2^{1-n/2}。更一般，r≥n-q 时
\[
 \varepsilon_v\le2^{1-n+4q}.
\tag{JB7}
\]
例如给定目标 ε₀>0，只要 4r≥3n+1+log₂(1/ε₀)，JB6 就给所需门。精确的 JB5 门通常更强，可直接按实际 s,L,L⁺,r 核验；JB6–7 仅为无需拟合的充分条件。

上一轮薄壳补集若另有 N_L≥n-q′，则 r=N_{L⁺}≥n-q′-q_n+1；可将该整数直接代入 JB7。这只利用已付薄壳的互斥补集，不重付薄壳。r≈k 并不自动等于 r≈n：当 score 总数 k 远小于 n，JB6 未给小量，不能略去其余 n-r 坐标损失。s>1/4 或 r 不足的部分也不由上述指数推论支付。

## JB4. 直接在原完整交通上吸收

定义原责任
\[
 \chi_{12}=\frac{K_1+K_2}{K_1+K_2+J},\qquad
 \chi_J=\frac{J}{K_1+K_2+J}.
\tag{JB8}
\]
它们只是原正被积函数上的乘子，χ₁₂+χ_J=1；原 good 资格仍由完整 Q_v 定义。由 JB5，
\[
 \chi_{12}\le\frac{\varepsilon_v}{1+\varepsilon_v},\qquad
 \chi_J\ge\frac1{1+\varepsilon_v},\qquad
 \chi_{12}\le\varepsilon_v\chi_J.
\tag{JB9}
\]
设 d𝔗 是含 p、ρ_v、δ(v,u)、两份原 Π、全部实际正门及原 dx,dβ,dt/t,j/标签和外 hard 权的非负交通测度。定义 P(E)=∫_E d𝔗，P₁₂(E)=∫_Eχ₁₂d𝔗，P_J(E)=∫_Eχ_Jd𝔗。点态 JB9 直接积分即得 JB3。任意一般来源测度下均由 Tonelli 成立；无限正量情形先截断同一个 d𝔗，再取单调极限。不能截断 ν 后重算 α、Π 或责任门来主张单调性。

所以 JB3 同时包含真实接收积分、原 time/j、全部选择器和删除来源；未使用 Π≤η⁻¹μ，故没有额外 η⁻¹ 或 η⁻²。ρ 与共同 α 全部保留，也不需要先花一次 16/3 hard 放松。这一点使它不同于把 EJ16 的 K_H/w_g 积分重新命名。

在 2Λ 的原费用单位中，JB3 原样成立：
\[
 2\Lambda P_{12}(E)\le\theta_0\,2\Lambda P(E),
 \qquad \theta_0=\varepsilon_0/(1+\varepsilon_0)<1.
\tag{JB10}
\]
若原总预算中的 X 已明确支配这一正交通，则可登记为 θ₀X 吸收；若 X 含尚未处理的有符号项而不具该支配关系，只能使用 JB3 的精确自比较，不能擅自称为 εX。无论采用哪种记账，J 责任 P_J(E) 都仍须支付。JB10 没有给原总目标一个免费的常数项。

## JB5. 共享 α 的真实 producer 与部分来源消耗

本节依据本轮 source_contract.md 摘录的原 producer 合同，使用完整共同量
\[
 Q_J=\int Jd\nu,\quad
 q\ge Q_J,\quad q\ge\int K_0d\nu,\quad
 U_v=1_{\{\text{原good},\Delta_v>0\}}\min(A_v,DK_{0,v}),\quad
 \alpha Q_J=Dq-\int U_vd\nu.
\tag{JB11}
\]
本节限 Q_J>0、原各量有限、D≥0 的合法行。Q_J=0 不作0/0，应回原零来源/未适用分支。U≤DK₀，且原 bad 集不含 U 的支持，所以准确有 αQ_J≥D∫_{D₀}K₀dν；这里不反转 U≤DK₀ 的方向。

设 A₀ 是消耗 U 的来源支持中一个原可测子集，满足 K₀≤κJ，κ≥0。其余实际消耗记
\[
 U_{\rm rest}=\int_{A_0^c}U_vd\nu.
\]
由同一个 producer，不改变任何来源权，
\[
 \boxed{\alpha\ge D(q/Q_J-\kappa)-U_{\rm rest}/Q_J
 \ge D(1-\kappa)-U_{\rm rest}/Q_J.}
\tag{JB12}
\]
证明只是 ∫_{A₀}U≤Dκ∫_{A₀}J≤DκQ_J 后代入 JB11。若几何仅对当前正在运输的来源 v 成立，U_rest 不能删除。若所有消耗来源都满足该核比，才有 α≥D(1−κ)。

JB5 的同一比较可应用到 K₀=P_{s,Hhat}，但须另外核 Hhat≤L⁺：此时那 r 个盒外坐标也在 Hhat 盒外，且 Hhat≥a，故 K₀/J≤2ⁿs^r c_s^{n-r}。只有对 A₀ 内所有来源逐一成立时才能用此 κ；不能由双核责任门自动推断 Hhat≤L⁺，也不能由当前来源的 r 推断其他消耗来源的 r。

例如在某完整消耗域上 Hhat≤L⁺、s≤1/4 且每个消耗来源 r≥7n/8，则 κ=2^{-n/2} 合法，α≥D(1−2^{-n/2})。这是实际可核的全消耗几何条件；本文未证明一般输入都满足，也未认证新的非空 FULL 实例。

## JB6. 双核小责任与共同储备在同一个上界中保留

若 JB12 的实际右端给 α≥a₀≥0，则在原 A_v>0 来源上
\[
 \rho_v\le R_v(a_0):=[1-(DK_{0,v}+a_0J_v)/A_v]_+.
\]
结合 JB9，逐点同时有
\[
 \rho_v\chi_{12}\le\frac{\varepsilon_v}{1+\varepsilon_v}R_v(a_0),
 \qquad
 \rho_v\chi_{12}\le\varepsilon_v\rho_v\chi_J,
 \qquad
 \rho_v\le(1+\varepsilon_v)\chi_JR_v(a_0).
\tag{JB13}
\]
因而 s^r 的实际小责任和 J/K₀ 共同储备可在同一原交通上使用；不分别重选 α，也不把 α 的下界当作另一个可独立调节的参数。可始终取 a₀=α，保留完整原 ρ；JB12 只解释哪些额外全消耗信息可给输入可核的下界。

JB13 的最后一式若用 ε_v≤ε₀ 积分，仍只将总责任价控制为 (1+ε₀) 倍的储备加权 J 责任价；没有声称其自身已为根阶。

## JB7. 原 J 外价与唯一尚欠控制

为列清 JB3 后实际未付的量，仍使用 R157 EJ17 的 b_v：
\[
 b_v=\frac{w_t(v)}{e_tw_g(v)}
 \int\delta(v,u)\mathcal M(x,j,y,t,v,u)d\Pi_t(u),\qquad0\le\mathcal M\le1.
\tag{JB14}
\]
E_v 支持原 good、ρ>0、A_v>0 及当前尚未付责任域。若某额外门含外 hard 变量，在放松 hard 前删去该正门。原 good 常数 K>0 是原外给固定参数；不拿实例 K=1 或64代替一般 K。

设
\[
 Z=\int_Eb_vJ_vd\nu,\quad C_0=\int_Eb_vDK_{0,v}J_v/A_v\,d\nu,
 \quad W=\int_Eb_vA_vd\nu.
\]
在 Z,W 有限、W>0 的分支，保留原 α 的已证 Cauchy–Schwarz 扣减给
\[
 \int_Eb_v\rho_vJ_vd\nu\le Z-C_0-\alpha Z^2/W.
\tag{JB15}
\]
W=0 时该正流为零；α=0 用 Z−C₀，不写0·∞。其他矩无限时保留原非负积分，不用 ∞−∞。E、b_v、Z,C₀,W 均可依 α；不得将 JB15 的右端当作系数固定的二次函数去优化 α。

设 𝔉_J(E) 是保留实际唯一 j、原时间窗、dx、dβ 及预先标签聚合的
\[
 \mathfrak F_J(E)=\frac{32\Lambda}{9}
 \int d\Gamma\int dx\int\frac{dt}{t}
 K\,[Z-C_0-\alpha Z^2/W].
\tag{JB16}
\]
它只在 JB15 有效分支按上述零支约定使用；其余分支使用相应非负原 J 积分。原一次 hard 帽与 EJ16 的三核责任给 2ΛP_J(E)≤𝔉_J(E)。于是本轮完成的真实费用节省准确为
\[
 \boxed{2\Lambda P(E)\le(1+\varepsilon_0)\mathfrak F_J(E),\qquad
 2\Lambda P_{12}(E)\le\varepsilon_0\mathfrak F_J(E),}
\tag{JB17}
\]
并同时有不经过 good 门除法的 JB10。

JB16 仍未支付。与上一轮相比，新成果不是只给这个积分换名：JB5–10 在完整原交通上给了显式、可任意指数小的双核责任系数，避免把 tildeK 交给 FIRST，也避免为双核另付接收 selector。这把相关多数盒外、远 soft 子域的主要价准确集中到保留原共同储备的 J 责任。尚欠的是证明 JB16（或保留两份原 Π 的等价 J 责任积分）在剩余域有 εX+C_ε√n polylog(n)W_β 上界；J 的固定尺度与 ∫Jν≤q 本身不足，因为 b_v 含原 w_t/(e_tw_g) 和 bad score，且所有矩随接收与原 j/time 变化。JB12 也仅给 α 下界，不支付这些来源权。

本文不声称一般根阶闭合，不重新证明薄壳或固定满 score 通量。有限交付到此停止。
