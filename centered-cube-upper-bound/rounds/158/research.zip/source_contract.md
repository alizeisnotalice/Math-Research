# R158 定向来源合同摘录

范围：只核对 R136/R151 的原实际源选择器与 R154 所用共同余额，以及 R128 的 √pJ Hellinger 项。本文是来源定位，不认证引理或 FULL 付款。

## 1. 原共同 α、good 门及来源余量

**原 producer 定义位置：**`rounds/151/research.zip:receiver_probe.py`，函数 `eval_batch`（行73–79附近）与 `one_point`；对应的 R136 上游参数生成在 `rounds/136/research.zip:centered_cube_round136_20261014/active_traffic_v2.py`（`K=D=1` 的实例行20–21、来源行33–35、输出 derived/atoms 行约87）。R154 对此合同的文字复述见 `rounds/154/research.zip:contract.md`「定义与允许工具」及 `joint_initial_budget.md` JI1。

固定合法行 ξ=(ω,V,j,x,y)，同一个来源测度 ν 和同一个 receiver x。令

\[
Q_v=\frac{K_{1,v}+K_{2,v}+J_v}{3},\quad
Q^*=\int Q_vd\nu,\quad Q_J=\int J_vd\nu,
\quad q=\max\left\{\int K_{0,v}d\nu,\int J_vd\nu,\int Q_vd\nu\right\}.
\]

其中 (K_0=P_{s,\widehat H}(x-v))、(K_1=P_{s,L}(x-v))、(K_2=P_{s,L^+}(x-v))、(J=P_{1,b}(x-v))，原共同核平均 (Q^*=(K_1+K_2+J)/3)。令 (p=P_{s,L}(x-y))。预先固定给定 (K>0) 后，good 条件是逐源

\[
G_v=1_{\{p\,w_g(v)\le KQ_v\}},
\]

bad 为严格反向 (p w_g(v)>KQ_v)。(K) 是原门的外给固定常数，不由 α 或接收行重新拟合；R136/R151 数值 producer 取实例 (K=1)，R128 固定 (K=64) 的有限 probe 明确说未认证其满足原理论允许值。故这里没有可从归档报告中抽出一个唯一“实际数值常数”替代原给定 (K)。

令 (\Delta_v=w_\tau(v)-w_h(v))，(E_v=G_v1_{\{\Delta_v>0\}})，并置 producer 的逐源消耗

\[
U_v=1_{E_v}\min\{T\Delta_v,DK_{0,v}\},\qquad
\alpha=\frac{Dq-\int U_vd\nu}{Q_J}\quad(Q_J>0).
\]

这是全来源的一次共同正部预算：它以全体 good 有效源的 (U_v) 总额扣减目标容量 (Dq)，再由同一 (Q_J) 定出一个共享系数；不是逐源 α_v，也不是冻结 ρ 后反解。合法行另检查 α≥0；numerical producer 将 `alpha_nonnegative` 作为 gate（R151 receiver_probe.py one_point）。若分子为零且 (Q_J>0)，α 可等于零；α<0 的行不满足该合法 gate。(Q_J=0) 时公式不定义，原接口须走零来源/未适用分支，不能写成0/0。R154 明确把 α=0 作为单独预算分支处理。

原剩余比例在有效 good 源上为

\[
\rho_v=\left(1-\frac{DK_{0,v}}{T\Delta_v}\right)_+
       -\frac{\alpha J_v}{T\Delta_v},
\]

并要求 ρ_v>0 的 source role 才进入 terminal-good。等价地 producer 用
\(\max(1-(U_v+\alpha J_v)/(T\Delta_v),0)\)，其中 (U_v=\min(T\Delta_v,DK_0))。全局余额恒等为

\[
\alpha Q_J+\int U_vd\nu=Dq,
\quad\text{从而}\quad
\alpha Q_J\ge D\int_{D_0}K_0d\nu
\]

在 good 消耗 (U_v\) 未用尽时由 (U_v\ge DK_0)；bad 源不计入 (U_v)。R154 contract 使用后一个不等式作为原共同余额合同，不能对坏集另选 α。

## 2. 时间、(T) 与 Δ 的来源

R136 `active_traffic_v2.py` 的实例化表达（参数输出 `derived`）为

\[
\gamma=1+1/n,\ c_j=\gamma^{-j},\ g=\sqrt{LR},\ \ell=1+\log n,
\quad \tau=a/c_j,\quad h=g e^{-u/n},
\]

\[
H_0=g c_j^{-1/2}(1-s+s\phi(1/2))\ell^{1/(2n)},\quad
\widehat H=\max(a,\min(b,H_0)),\quad
T=\frac{c_j^{n/2}}{g^n\sqrt\ell}.
\]

全程 (w_t(v)=\prod_i\min(1,\alpha_i(y,v)/t))，(w_g,w_\tau,w_h) 在生产器中按同一 α_i 源坐标算；故 Δ 是时间窗净下降 (w_\tau-w_h)，不是自由变量。原条件 (\tau<h\le g) 与祖链的 soft/scale/history 门保留；实际时间目标常在 ([\tau,h]) 上分段积分。上述 exact (T) 是 R136 抽象 I1/producer 的输入派生式，不能把某个样例参数称为新的普遍选择规则。

## 3. R154 的 (D\int_{D_0}K_0\le\alpha Q_J) 出处

这不是 R154 新设的预算；它来自上节 producer 的**同一共享 α 余额**和 sourcewise positive remainder 定义。若 (v\in D_0) 是原 bad 集，则 good 消耗的 (U_v) 不含它；按原分支中正余量要求，bad 所占的 (D K_0) 额度由共同剩余 αQ_J 支付，形成原逐行容量不等式。R154 `contract.md` 直接记为 αQ_J≥D∫_{D0}K0dν；JI1 再用它与 αV≤U 推出联合界。应保留同一个 (x,j,V,y,\nu,Q_J,\alpha,D)；不能把好坏行/接收点的容量相加后重选 α。数值实现每一行重新从 receiver 核计算 q、QJ、U_v、α、ρ，吻合该合同；但这只是 producer 实现证据。

## 4. 旧 Hellinger 源几何核与付款状态

归档：`rounds/128/research.zip:proof.md` §命题 H（RT8，约行677起）、RT8 的一维归一化（§4，约行706）及适用域/账本修订（§0、§9，约行585与864）。已证明的真实 (dx) 核不等式为

\[
\int_{\mathbb R^n}\sqrt{h_L(x-y)P_{1,b}(x-v)}\,dx
\le (1-2^{-34})^{n/2}
\left(\prod_i C(|y_i-v_i|/b)\right)^{1/2},
\quad b/2\le L\le b.
\]

其中 (h_L) 是真实硬立方平均核，(P_{1,b}) 是真实纯硬接收核；无 (h_R(x-z)) 条件化载体。归档记录 RT8 全参数解析证明通过独审，且纯 φ/C Hellinger 缺口可用。**尚未付款：**RT10 仅在把原软度下门去掉并取 (s=0) 的扩展模型、另保留其余帽与固定来源/时间合同后给条件费用；R128 §0 明确原实际要求 (s>1-2^{-1/n}>0)，故该实际扩展窗恒空。RT8 不含接收载体 (h_R(x-z))，不单独推出 R154/R158 所需的源积分付款，也不能把纯硬估计移植到原 (s>0) 交通。没有找到 R154 之后已支付该组合的记录。

## 审计界线

以上只做来源与字段合同定位。数值 R136/R151 的 (K=D=1) 选择、R128 的 (K=64) 探针、RT8 的核引理，以及 R154 的条件预算均各自保持其原标签；不因此认证所有合法行、α 存在条件、一般联合来源付款或 FULL 根阶结论。
