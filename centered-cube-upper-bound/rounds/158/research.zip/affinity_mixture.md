# R158：固定任意正源测度混合的接收核交叠界

本文件仅新增固定源测度混合引理，不修改已经冻结的 `affinity.md`。结论仍只是接收核工具；原问题的源权、`alpha`、`good` 门及共同选择约束须另行支付。

## 1. 命题及固定性的条件

沿用
\[
h=\mathbf1_{[-1/2,1/2]},\qquad
w(u)=\int_0^1e^{-|u|/r}\,dr,\qquad
\varphi=h*w,\qquad p_s=(1-s)h+s\varphi,
\]
以及
\[
P_{s,L}(x-y)=L^{-n}\prod_{i=1}^np_s((x_i-y_i)/L),\qquad
J_b(x-v)=b^{-n}\prod_{i=1}^n\varphi((x_i-v_i)/b).
\]
设 \(n\ge1\)，\(0<a\le b\)、\(b/a\le2\)，\(y\in\mathbb R^n\) 任意。令 \(\nu\) 是任意有限正 Borel 测度，\(M=\nu(\mathbb R^n)\)，并设
\[
J_\nu(x)=\int_{\mathbb R^n}J_b(x-v)\,\nu(dv).
\]
**同一个 \(\nu\) 必须在整个积分及参数上确界中固定，不得依赖接收点 \(x\)、选择器 \((s,L)\) 或另行选择的时间。** 它可以在不同源坐标间具有任意相关性。

以下固定参数界和远 soft 网格界不需要近 soft 包络输入：
\[
\boxed{\quad
\int\sqrt{P_{s,L}(x-y)J_\nu(x)}\,dx
\le2\sqrt M\exp\!\left(-\frac{n(1-s)^2}{1024}\right),
\quad 0\le s\le1,\quad a\le L\le b.\quad} \tag{1}
\]
\[
\boxed{\quad
\int\sup_{\substack{0\le s\le1-d\\a\le L\le b}}
\sqrt{P_{s,L}(x-y)J_\nu(x)}\,dx
\le4en^2\sqrt M\exp\!\left(-\frac{nd^2}{1024}\right),
\quad 0\le d\le1.\quad} \tag{2}
\]
结合题设已证明的全参数和近 soft 质量包络（第 4 节列出）后，所有整数 \(n\ge1\) 统一有
\[
\boxed{\quad
\int\sup_{\substack{0\le s\le1\\a\le L\le b}}
\sqrt{P_{s,L}(x-y)J_\nu(x)}\,dx
\le1024\,n^{1/4}\sqrt{\log(n+2)}\sqrt M.\quad} \tag{3}
\]
特别地，这些费用不依赖 \(\nu\) 的原子数、支持几何或坐标相关性。

## 2. 统一检验事件：混合后不要求坐标独立

若 \(M=0\)，所有结论平凡。以下先归一化到 \(M=1\)，最后乘回 \(\sqrt M\)。令
\[
\beta=\int_{-1/2}^{1/2}\varphi(u)\,du,
\qquad \kappa=1-\beta,
\qquad \varepsilon=1-s,
\]
并定义与源点 \(v\) 无关的统计量
\[
T(x)=\sum_{i=1}^n\mathbf1_{\{|x_i-y_i|\le b/2\}}.
\]
在概率分布 \(P_{s,L}(x-y)\,dx\) 下，各坐标独立，每个成功概率至少
\[
(1-s)+s\int_{-b/(2L)}^{b/(2L)}\varphi(u)\,du
\ge\varepsilon+(1-\varepsilon)\beta
=\beta+\kappa\varepsilon. \tag{4}
\]
这里使用 \(L\le b\)，硬核完全落在检验区间内。

另一方面，在每个固定 \(J_b(x-v)\,dx\) 下，各坐标独立，且第 \(i\) 个成功概率是 \(\varphi\) 在某个长度为 1 的区间上的积分。因为 \(\varphi\) 偶且在正半轴非增，该积分不超过中心区间的积分 \(\beta\)。这一事实可由 layer-cake 看出：任意固定长度的区间与每个中心超水平区间的交长都在中心重合时最大。因此每个固定源点下均有
\[
\mathbb E_{J_b(\cdot-v)}T\le n\beta. \tag{5}
\]

为使尾界自足，若 \(B_i\) 是相互独立的 Bernoulli 变量，则其中心化对数矩母函数满足
\[
\log\mathbb E e^{\lambda(B_i-\mathbb EB_i)}\le\lambda^2/8,
\qquad \lambda\in\mathbb R.
\]
确实，对数矩母函数在 0 处的值与一阶导数均为 0，其二阶导数是某个倾斜 Bernoulli 分布的方差，至多 \(1/4\)；积分两次即得。乘积、Markov 和取 \(\lambda=4t\) 给出两侧尾界
\[
\mathbb P\!\left(\sum_iB_i-\mathbb E\sum_iB_i\ge nt\right)\le e^{-2nt^2},
\quad
\mathbb P\!\left(\sum_iB_i-\mathbb E\sum_iB_i\le-nt\right)\le e^{-2nt^2},
\qquad t\ge0. \tag{6}
\]
不要求这些 Bernoulli 变量具有相同参数。

取同一个事件
\[
E=\left\{x:T(x)\ge n\left(\beta+\frac{\kappa\varepsilon}{2}\right)\right\}.
\]
阈值无需是整数。由 (4)—(6)，
\[
P_{s,L}(E^c)\le e^{-n\kappa^2\varepsilon^2/2},
\qquad
J_b(\cdot-v)(E)\le e^{-n\kappa^2\varepsilon^2/2}
\quad\text{对每个 }v. \tag{7}
\]
严格/非严格边界不造成问题：\(E^c\) 包含于相应的非严格下尾事件，\(E\) 包含于相应上尾事件；\(\varepsilon=0\) 时右边为 1，仍成立。

现在才对源变量积分。虽然混合分布的坐标通常不独立，但每个条件尾界统一于 \(v\)，故 Tonelli 给出
\[
J_\nu(E)
=\int J_b(\cdot-v)(E)\,\nu(dv)
\le e^{-n\kappa^2\varepsilon^2/2}. \tag{8}
\]
对 \(E\) 和 \(E^c\) 分别使用 Cauchy：
\[
\begin{aligned}
\int\sqrt{P_{s,L}J_\nu}
&\le\sqrt{P_{s,L}(E)J_\nu(E)}
+\sqrt{P_{s,L}(E^c)J_\nu(E^c)}\\
&\le2e^{-n\kappa^2\varepsilon^2/4}.
\end{aligned} \tag{9}
\]
整个过程没有对平方根使用反向 Jensen。

最后给出显式常数。若 \(U\sim h,W\sim w\) 独立，则 \(U+W\sim\varphi\)，且 \(|W|>1\) 蕴含 \(|U+W|>1/2\)，除去零测边界。所以
\[
\kappa\ge\mathbb P(|W|>1)
=\int_0^1 2r e^{-1/r}\,dr
\ge\tfrac12e^{-2}.
\]
于是
\[
\kappa^2/4\ge e^{-4}/16\ge1/1024
\]
（例如使用 \(e<11/4\)，故 \(e^4<64\)）。由 (9) 得到 (1)。

## 3. 同时支付两个连续参数的网格费用

令 \(S=1-d\)。将 \([0,S]\) 分成长度 \(\delta=s_1-s_0\le1/n\) 的相邻区间，每段只使用格点
\[
u=\frac{s_1}{1+\delta}.
\]
因为 \(s\in[s_0,s_1]\) 时
\[
p_s\le(1-s_0)h+s_1\varphi=(1+\delta)p_u,
\]
故 \(P_{s,L}\le eP_{u,L}\)。格点数至多 \(n\)，且全部满足 \(u\le S\)。若 \(S=0\)，改用单点 0，格点数仍至多 \(n\)。

尺度从 \(a\) 开始按比值 \(e^{1/n}\) 向上取格点，最后截在 \(b\)。格点数至多
\[
\lceil n\log(b/a)\rceil+1\le n+1.
\]
任意 \(L\) 有向上最近格点 \(H\)，满足 \(H/L\le e^{1/n}\)。每坐标偶单调性给出 \(P_{u,L}\le eP_{u,H}\)。因此逐点
\[
\sup_{s\le S,L}\sqrt{P_{s,L}J_\nu}
\le e\sum_{u,H}\sqrt{P_{u,H}J_\nu}.
\]
逐项应用 (1)，并用 \(1-u\ge d\)，得到
\[
\int\sup_{s\le S,L}\sqrt{P_{s,L}J_\nu}
\le2en(n+1)\sqrt M e^{-nd^2/1024}
\le4en^2\sqrt M e^{-nd^2/1024},
\]
即 (2)。特别地，\(1-s\ge D/\sqrt n\) 时整个连续族的费用是
\[
4en^2\sqrt M e^{-D^2/1024},\qquad0\le D\le\sqrt n.
\]
固定参数尾界没有直接被当成 selector 积分；有限网格的全部费用已显式保留。

## 4. 近 soft 拼接及小维数常数

本节使用题设已证明的两个质量包络：
\[
\int\sup_{s,L}P_{s,L}\le3(2n+3)(1+\pi\sqrt n/2), \tag{10}
\]
以及对 \(0\le d<1/2\)，
\[
\int\sup_{1-d\le s\le1,L}P_{s,L}
\le32\sqrt n(1+\sqrt n\,d)^2. \tag{11}
\]
由 \(\int J_\nu=M\) 和 Cauchy，近 soft 项至多
\[
\sqrt{32}\,n^{1/4}(1+\sqrt n\,d)\sqrt M.
\]
与 (2) 相加，得到
\[
\int\sup_{s,L}\sqrt{P_{s,L}J_\nu}
\le\left[\sqrt{32}\,n^{1/4}(1+\sqrt n\,d)
+4en^2e^{-nd^2/1024}\right]\sqrt M,
\qquad0\le d<1/2. \tag{12}
\]

令
\[
A=4096,\qquad d_*:=\sqrt{A\log(n+2)/n},
\qquad C_0:=\sqrt{15(1+\pi/2)}<7.
\]
若 \(d_*<1/2\)，在 (12) 取 \(d=d_*\)。远项小于 1，因为
\[
4en^2(n+2)^{-4}\le e/16<1;
\]
这里使用 \((n+2)^2\ge8n\)。由于 \(\log(n+2)>1\)、\(\sqrt A=64\)、\(\sqrt{32}<6\)，归一化后全项不超过
\[
\bigl[\sqrt{32}(1+64)+1\bigr]n^{1/4}\sqrt{\log(n+2)}
<391\,n^{1/4}\sqrt{\log(n+2)}.
\]
若 \(d_*\ge1/2\)，不使用 (11)，而由 (10) 和 Cauchy 得
\[
\int\sup_{s,L}\sqrt{P_{s,L}J_\nu}
\le C_0n^{3/4}\sqrt M.
\]
此时 \(n\le4A\log(n+2)\)，所以右边至多
\[
2C_0\sqrt A\,n^{1/4}\sqrt{\log(n+2)}\sqrt M
<896\,n^{1/4}\sqrt{\log(n+2)}\sqrt M.
\]
两分支均被常数 1024 支配，证明 (3)，并包括 \(d_*=1/2\) 的边界。

## 5. 与原来源权的接口限制

* 混合源的任意相关性不构成缺口：独立性只在每个固定 \(v\) 的条件核中使用，尾界再对同一个固定 \(\nu\) 积分。
* 不允许把 \(\nu\) 改成 \(\nu_x\)、\(\nu_{s,L}\) 或由另一个时间选择器产生的 \(\nu_t\)，再声称 (2)、(3) 已经支付该选择。事件概率估计和 \(\int J_\nu=M\) 均使用了固定测度。
* 本文件没有证明原问题中出现的 \(b_{v,\rho}\) 权重可以吸收到此 \(\nu\)。这种识别必须另证：权重在上述积分与上确界中固定、所得对象是同一个有限正源测度、且其总质量已有可用控制。特别是依赖接收点、参数选择或时间的权重，不能伪装成此处的固定 \(\nu\)。
* 即使 (3) 适用，也只支付这里的接收核交叠。它不自动控制原算子的源权、`alpha`、`good` 门或其共同选择约束，不等于一般中心立方体弱型主目标已闭合。

