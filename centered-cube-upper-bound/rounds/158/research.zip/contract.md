# R158研究合同

目标仍为一般中心立方体n^(1/2+o(1))一致弱型上界；本轮直接处理R157两尺度同时盒外的双核责任与原共同J来源。核工具不等于原交通付款。

原合同：h=1[-1/2,1/2],w(u)=∫0^1 exp(-|u|/r)dr,φ=h*w,p_s=(1-s)h+sφ。P为其n维产品核。L+=min(b,(1+1/n)L)，R128 proof第655行和R151 geometry_contract第38行明确原min定义；b/a≤2。Qv=(K1+K2+J)/3,J=P1,b，真实dx、外beta、来源nu、共同alpha、原所有资格和负账不改。

Astra文件joint_budget.md：证明实际双核/J逐点比，以及原完整正交通责任χ12与χJ的相对预算；保留alpha部分消费域外U_rest。不能在未证X包含时把相对预算写为epsilon X；J外价仍待证。
Sol作者affinity.md与affinity_mixture.md：先单源统一Hellinger缺口及所有s/L选择价，再推广为任意固定有限正来源ν混合。混合不得假设ν各坐标独立或反用sqrt的Jensen。来源不允许依x/selector/time；任何替换到原rho/b_v加权测度须另证合法。
Sol审查affinity_audit.md：先盲审两个命题及混合版，再读作者与主稿；核全部常数、硬端点、有限测度、原L+、相对交通和未付范围。
Sol数值exact_checks.py/json/md：有理区间和整数检查参数门/常数/责任/alpha部分预算，三阶段探索、边界、扩展；不算新kernel，不以有限代数当一般dx证明。
Luna来源source_contract.md：原alpha/K/时间及旧R128Hellinger适用范围。定位不是证明；U≤DK0和P1,b为纯soft两处初稿已纠正。
主代理负责主要推导、主LaTeX、复现和逐轮Git；其他人不git、不改他人文件，交付后停。

已重新读取D02 Gibbs有限域和F01几何平均核技能；没有把GP-BRANCH未定义接口或Gibbs广义变分当已证工具。本文Hellinger/混合测试/矩预算自行证明，不依外部强对偶。R148 CS10近soft和JT13全参数包络是已有已审输入，主稿逐项粗化CS10，所有源费用另列。
