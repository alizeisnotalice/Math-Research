# R158：接收核的统一 Hellinger 几何与合法 selector 费用

本文件只证明接收核工具，不证明一般中心立方体弱型主目标。源测度、来源权、`alpha`、`good` 门及与其他项的耦合费用，均须另行支付；没有使用来源变量独立性。

设
\[
h=\mathbf1_{[-1/2,1/2]},\quad
w(u)=\int_0^1e^{-|u|/r}\,dr,\quad
\varphi=h*w,\quad p_s=(1-s)h+s\varphi.
\]
有 \(\int w=\int_0^1 2r\,dr=1\)，故这些都是概率密度。\(w,\varphi,p_s\) 均为偶函数，并在正半轴非增。以下 \(n\ge1\) 为整数，\(0<a\le L\le b\)、\(b/a\le2\)，位置 \(y,v\in\mathbb R^n\) 任意，且
\[
P_{s,L}(x-y)=L^{-n}\prod_{i=1}^np_s((x_i-y_i)/L),\qquad
J_b(x-v)=b^{-n}\prod_{i=1}^n\varphi((x_i-v_i)/b).
\]

## 1. 被筛命题成立，具有显式普适常数

记
\[
\beta=\int_{-1/2}^{1/2}\varphi(u)\,du<1,
\qquad c=\frac1{512}.
\]
对所有 \(s\in[0,1]\)、\(L\in[b/2,b]\) 和实数 \(y,v\)，
\[
\boxed{\quad
\int_{\mathbb R}\sqrt{L^{-1}p_s((x-y)/L)\,b^{-1}\varphi((x-v)/b)}\,dx
\le1-c(1-s)^2.\quad} \tag{1}
\]

**证明。** 两个被积因子的平方根都是以自身中心为对称中心的非负单调函数。由 layer-cake，它们的卷积是中心区间交长的非负加权积分。两个给定长度的区间，其交长在中心重合时最大。因此左边在 \(y=v\) 时最大。这个论证可直接用 Tonelli 实施，不需要光滑性。

令中心重合，取 \(A=[y-b/2,y+b/2]\)。记两个概率分布为 \(Q_{s,L}\) 和 \(R_b\)。因为 \(L\le b\)，硬核在 \(A\) 内的质量为 1，且
\[
Q_{s,L}(A)
=(1-s)+s\int_{-b/(2L)}^{b/(2L)}\varphi(u)\,du
\ge(1-s)+s\beta,
\qquad R_b(A)=\beta.
\]
故 \(\operatorname{TV}(Q_{s,L},R_b)\ge(1-s)(1-\beta)\)，其中 TV 取 \(\tfrac12\|q-r\|_1\) 的约定。若 \(H=\int\sqrt{qr}\)，则 Cauchy 给出
\[
\operatorname{TV}(q,r)
\le\tfrac12\sqrt{\int(\sqrt q-\sqrt r)^2\int(\sqrt q+\sqrt r)^2}
=\sqrt{1-H^2}\le\sqrt{2(1-H)}.
\]
所以 \(H\le1-\tfrac12(1-\beta)^2(1-s)^2\)。

为给出显式常数，令 \(U\sim h,W\sim w\) 独立；\(U+W\sim\varphi\)。事件 \(|W|>1\) 必使 \(|U+W|>1/2\)，除去零测边界。因此
\[
1-\beta\ge\mathbb P(|W|>1)
=\int_0^1 2r e^{-1/r}\,dr
\ge\int_{1/2}^1e^{-2}\,dr
=\tfrac12e^{-2}.
\]
于是 \(\tfrac12(1-\beta)^2\ge e^{-4}/8\ge1/512=c\)（例如由 \(e<11/4\) 即知），得到 (1)。该证明是全域证明，且事实上只使用了 \(L\le b\)。证毕。

由 Tonelli 与张量积，立即得到固定参数结论
\[
\boxed{\quad
\int_{\mathbb R^n}\sqrt{P_{s,L}(x-y)J_b(x-v)}\,dx
\le(1-c(1-s)^2)^n
\le e^{-cn(1-s)^2}.\quad} \tag{2}
\]
以下单独支付连续参数选择费用，不把 (2) 误当成 selector 积分。

## 2. 同时支付 \(s,L\) 的有限网格

对任意 \(0\le d\le1\)，定义远 soft selector
\[
F_d=\int_{\mathbb R^n}\sup_{\substack{0\le s\le1-d\\a\le L\le b}}
\sqrt{P_{s,L}(x-y)J_b(x-v)}\,dx.
\]
则
\[
\boxed{\qquad F_d\le2en^2e^{-cnd^2}.\qquad} \tag{3}
\]
特别地，若 \(0\le D\le\sqrt n\)，则对 \(1-s\ge D/\sqrt n\) 的整个连续参数族，
\[
F_{D/\sqrt n}\le2en^2e^{-cD^2}. \tag{4}
\]
这里保留了实际的 \(O(n^2)\) 网格费用；当 \(D\) 固定时 (4) 不宣称整体随 \(n\) 衰减。

**\(s\) 网格。** 令 \(S=1-d\)，把 \([0,S]\) 分成长度 \(\delta\le1/n\) 的相邻区间，区间数至多 \(n\)。对每段 \([s_0,s_1]\)，只使用一个格点
\[
u=\frac{s_1}{1+\delta},\qquad \delta=s_1-s_0.
\]
对这一段中的所有 \(s\)，逐点有
\[
p_s\le(1-s_0)h+s_1\varphi=(1+\delta)p_u,
\qquad P_{s,L}\le(1+1/n)^nP_{u,L}\le eP_{u,L}.
\]
所有格点都满足 \(u\le s_1\le S\)，故不会损失远 soft 门 \(1-u\ge d\)。若 \(S=0\)，直接使用单点 \(u=0\)，仍有格点数至多 \(n\)。格点未必是区间端点，这不影响上述明确的逐点支配。

**尺度网格。** 从 \(a\) 开始，以相邻比 \(e^{1/n}\) 向上取尺度，并把末端截在 \(b\)。格点数至多
\(\lceil n\log(b/a)\rceil+1\le n+1\)。对任意 \(L\)，上方最近尺度 \(H\) 满足 \(1\le H/L\le e^{1/n}\)。由每坐标偶单调性，
\[
P_{u,L}(x-y)\le(H/L)^nP_{u,H}(x-y)\le eP_{u,H}(x-y).
\]
组合后 \(P_{s,L}\le e^2P_{u,H}\)。因此逐点
\[
\sup_{s\le S,L}\sqrt{P_{s,L}J_b}
\le e\sum_{u,H}\sqrt{P_{u,H}J_b}.
\]
对有限和积分，再逐项使用 (2) 与 \(1-u\ge d\)，即得 (3)。这同时处理任意依赖 \(x\) 的合法选择器 \(s(x),L(x)\)；没有交换上确界与积分的非法步骤。

## 3. 与已给近 soft 包络拼接：全 selector 为 \(O(n^{1/4}\sqrt{\log(n+2)})\)

本节**显式依赖题设已经证明的两个包络输入**：
\[
\int\sup_{s,L}P_{s,L}\le3(2n+3)(1+\pi\sqrt n/2), \tag{5}
\]
以及对 \(0\le d<1/2\)，
\[
\int\sup_{1-d\le s\le1,L}P_{s,L}
\le32\sqrt n(1+\sqrt n\,d)^2. \tag{6}
\]
位置平移不改变这些质量界。由 \(\int J_b=1\) 与 Cauchy，近 soft 部分满足
\[
\int\sup_{1-d\le s\le1,L}\sqrt{P_{s,L}(x-y)J_b(x-v)}\,dx
\le\sqrt{32}\,n^{1/4}(1+\sqrt n\,d). \tag{7}
\]
将全参数区间分成近、远两段，并使用 \(\sqrt{\max(A,B)}\le\sqrt A+\sqrt B\)，得到对每个 \(0\le d<1/2\) 都合法的明确界
\[
\boxed{\quad
F_0\le\sqrt{32}\,n^{1/4}(1+\sqrt n\,d)
+2en^2e^{-cnd^2}.\quad} \tag{8}
\]

下面也支付小维数费用，给出真正统一的常数。令
\[
A=4/c=2048,\quad
C_0=\sqrt{15(1+\pi/2)},
\quad
C=1024.
\]
则所有整数 \(n\ge1\) 均有
\[
\boxed{\quad
\int\sup_{s\in[0,1],\,L\in[a,b]}
\sqrt{P_{s,L}(x-y)J_b(x-v)}\,dx
\le C\,n^{1/4}\sqrt{\log(n+2)}.\quad} \tag{9}
\]

确切地，若 \(d_*:=\sqrt{A\log(n+2)/n}<1/2\)，在 (8) 中取 \(d=d_*\)。远项不超过
\[
2en^2(n+2)^{-4}\le2e/9<1,
\]
近项不超过 \(\sqrt{32}(1+\sqrt A)n^{1/4}\sqrt{\log(n+2)}\)，这里使用 \(\log(n+2)\ge\log3>1\)。若 \(d_*\ge1/2\)，不用 (6)，而由 (5) 直接 Cauchy 得
\[
F_0\le C_0n^{3/4}.
\]
此时 \(n\le4A\log(n+2)\)，所以
\[
F_0\le2C_0\sqrt A\,n^{1/4}\sqrt{\log(n+2)}.
\]
这包括边界 \(d_*=1/2\)，没有将只对 \(d<1/2\) 成立的 (6) 用到边界外。最后，\(C_0<7\)、\(\sqrt A<46\)、\(\sqrt{32}<6\)，所以两分支所需常数分别小于 \(283\) 和 \(644\)；所给统一常数 \(1024\) 足够。

## 4. 适用范围与剩余接口

* (1)—(4) 为本文件自足证明的接收核引理；(9) 还依赖已经给定的 (5)、(6)。
* 所有界统一于位置 \(y,v\)、允许的尺度窗及所有连续参数选择；它们没有假设来源测度独立，也没有隐去 selector 费用。
* (9) 是单个接收核与 \(J_b\) 的平方根交叠包络界。如何与源权、`alpha`、`good` 门和原算子约束相接，仍由主论证支付；本文件不把接收工具的成功等同于主目标闭合。

