#!/usr/bin/env python3
"""R158 finite constant/parameter certificates; no kernel or dx integration."""
from fractions import Fraction as F
from functools import lru_cache
from pathlib import Path
import argparse,hashlib,itertools,json,math,sys
sys.set_int_max_str_digits(0)
ROOT=Path(__file__).resolve().parent

def sha(b):return hashlib.sha256(b).hexdigest()
def enc(x):
    if isinstance(x,F):return f'{x.numerator}/{x.denominator}'
    if isinstance(x,dict):return {str(k):enc(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)):return [enc(v) for v in x]
    return x
@lru_cache(None)
def logbox(x,N=64):
    if x==1:return F(0),F(0)
    assert x>0
    if x<1:
        l,u=logbox(1/x,N);return -u,-l
    j=0;y=x
    while y>=2:y/=2;j+=1
    def atanh(v):
        a=F(0);t=v
        for k in range(N):a+=t/(2*k+1);t*=v*v
        return 2*a,2*a+2*t/((2*N+1)*(1-v*v))
    l,u=atanh((y-1)/(y+1));l2,u2=atanh(F(1,3));return l+j*l2,u+j*u2
@lru_cache(None)
def ebox(N=64):
    t=sum((F(1,math.factorial(k)) for k in range(N+1)),F(0));return t,t+F(2,math.factorial(N+1))
@lru_cache(None)
def pibox(N=64):
    def atan(x):
        a=sum(((-1)**j*x**(2*j+1)/(2*j+1) for j in range(N)),F(0));b=a+(-1)**N*x**(2*N+1)/(2*N+1);return min(a,b),max(a,b)
    a,b=atan(F(1,5)),atan(F(1,239));return 16*a[0]-4*b[1],16*a[1]-4*b[0]
def sqrtbox(q,digits=80):
    assert q>=0;d=10**digits;k=math.isqrt(q.numerator*d*d//q.denominator);l=F(k,d);u=l if l*l==q else F(k+1,d);assert l*l<=q<=u*u;return l,u

def classify(n,A=2048):
    for N in [64,128,256]:
        ll,lu=logbox(F(n+2),N)
        if n<=4*A*ll:return 'small',ll,lu,N
        if n>4*A*lu:return 'large',ll,lu,N
    raise AssertionError('branch unresolved')
def first_large(A=2048):
    lo=1;hi=4*A
    while classify(hi,A)[0]=='small':lo=hi;hi*=2
    while hi-lo>1:
        mid=(hi+lo)//2
        if classify(mid,A)[0]=='small':lo=mid
        else:hi=mid
    return hi

def A_case(n,A=2048,C=1024,far_coeff=2):
    branch,ll,lu,N=classify(n,A);rl,ru=sqrtbox(F(n));pi=pibox();ee=ebox()
    if branch=='small':
        # Exact upper interval for (bare Cauchy/(n^1/4 sqrt(log)))^2.
        upper=3*(2*n+3)*(1+pi[1]*ru/2)/(rl*ll);assert upper<=C*C
        return dict(n=n,branch=branch,log_interval=[ll,lu],log_N=N,normalized_square_upper=upper,target_square=C*C,branch_squared_test=f'n <={4*A} log(n+2)')
    rootlog=sqrtbox(ll)[0];rootA=sqrtbox(F(A))[1];root32=sqrtbox(F(32))[1];quarter=sqrtbox(rl)[0]
    far=far_coeff*ee[1]*n*n/F((n+2)**4);near_normalized=root32*(1/rootlog+rootA);normalized=near_normalized+far/(quarter*rootlog)
    assert A*lu/n<F(1,4) and far<1 and normalized<C
    return dict(n=n,branch=branch,log_interval=[ll,lu],log_N=N,d_square_interval=[A*ll/n,A*lu/n],far_selector_upper=far,near_normalized_upper=near_normalized,total_normalized_upper=normalized,target=C,branch_squared_test=f'n >{4*A} log(n+2), hence d<1/2')

def expminus_small(x,N=64):
    assert 0<=x<=2
    term=F(1);v=term
    for k in range(1,N+1):term*=x/k;v+=term
    remainder=term*x/F(N+1)/(1-x/F(N+2));return 1/(v+remainder),1/v

def B_finite():
    rows=[]
    for n in [1,2,4,8,16,32,64]:
        for s,m in itertools.product([F(0),F(1,16),F(1,8),F(1,4)],[F(1,4)+F(1,1024),F(1,2),F(1)]):
            cs=s+(1-s)/m;assert cs<=4
            for r in sorted({(7*n+7)//8,n}):
                ratio=2**n*s**r*cs**(n-r);assert ratio*ratio<=F(1,2**n)
                rows.append(dict(n=n,s=s,m_surrogate=m,r=r,cs=cs,ratio=ratio,ratio_squared=ratio*ratio,target_squared=F(1,2**n)))
            for q in sorted({0,1,(n+7)//8,n}):
                if q>n:continue
                r=n-q;ratio=2**n*s**r*cs**q;exponent=-n+4*q;target=F(2**exponent) if exponent>=0 else F(1,2**(-exponent));assert ratio<=target
                rows.append(dict(n=n,s=s,m_surrogate=m,q=q,r=r,ratio=ratio,dyadic_target=target))
    return rows

def responsibilities():
    out=[]
    for eps in [F(1,2**20),F(1,16),F(1),F(16),F(2**20)]:
        J=[F(1,3),F(1),F(7,2)];theta=[F(0),F(1,4),F(1)];Ksum=[eps*a*b for a,b in zip(J,theta)];W=[F(0),F(2,3),F(5,7)]
        chis=[a/(a+b) for a,b in zip(Ksum,J)]
        assert all(x<=eps/(1+eps) for x in chis)
        chiJ=[b/(a+b) for a,b in zip(Ksum,J)];P=sum(W);P12=sum(w*x for w,x in zip(W,chis));PJ=sum(w*x for w,x in zip(W,chiJ));assert P12+PJ==P and P12<=eps*PJ and P12<=eps/(1+eps)*P and P<=(1+eps)*PJ
        out.append(dict(epsilon=eps,J=J,K12=Ksum,unchanged_common_weights=W,chi12=chis,chi12_bound=eps/(1+eps),chiJ=chiJ,P=P,P12=P12,PJ=PJ))
    return out

def alpha_checks():
    count=0;missing_rest=0;example=None;witnesses=[]
    for D,QJ,kappa,theta,extra,t in itertools.product([F(1,2),F(1),F(3)],[F(1,4),F(2)],[F(0),F(1,4),F(1,2),F(1)],[F(0),F(1,2),F(1)],[F(0),F(1)],[F(0),F(1,2),F(1)]):
        q=QJ*(1+extra);US=theta*kappa*D*QJ;rest=t*(D*q-US);alpha=(D*q-US-rest)/QJ;lower=D*(1-kappa)-rest/QJ
        stronger=D*(q/QJ-kappa)-rest/QJ
        assert q>=QJ and US<=kappa*D*QJ and alpha>=0 and alpha>=stronger>=lower;count+=1
        if alpha<D*(1-kappa):
            missing_rest+=1
            if example is None:example=dict(D=D,QJ=QJ,q=q,kappa=kappa,US=US,Urest=rest,alpha=alpha,correct_lower=lower,stronger_lower=stronger,incorrect_rest_free_lower=D*(1-kappa))
    assert missing_rest>0
    return dict(checks=count,status='PASS_ABSTRACT_BUDGET_ONLY',omitted_rest_failures=missing_rest,omitted_rest_example=example,zero_D_branch='D=0 and total U=0 gives alpha=0',QJ_zero_branch='not divided; original separate contract required')

def bernoulli_distribution(probs):
    d=[F(1)]
    for p in probs:
        out=[F(0)]*(len(d)+1)
        for j,a in enumerate(d):out[j]+=a*(1-p);out[j+1]+=a*p
        d=out
    assert sum(d)==1
    return d

def mixture_tails():
    rows=[]
    for n,beta,s in itertools.product([2,4,8,16],[F(1,2),F(3,4),F(7,8)],[F(0),F(1,4),F(3,4),F(1)]):
        assert 1-beta>=F(1,16)
        delta=(1-s)*(1-beta);p=beta+delta;meanP=n*p;threshold=n*(beta+delta/2);cut=(threshold.numerator+threshold.denominator-1)//threshold.denominator
        probabilities=[[beta]*n,[beta/4]*n,[beta*F(i+1,n+1) for i in range(n)]];weights=[F(1,2),F(1,3),F(1,6)]
        conditional=[bernoulli_distribution(ps) for ps in probabilities];Q=[sum(w*dist[j] for w,dist in zip(weights,conditional)) for j in range(n+1)];P=bernoulli_distribution([p]*n)
        Pbad=sum(P[:cut]);Qgood=sum(Q[cut:]);condtails=[sum(d[cut:]) for d in conditional];tail_exp=expminus_small(n*delta*delta/2)
        assert Pbad<=tail_exp[0] and all(q<=tail_exp[0] for q in condtails) and Qgood<=tail_exp[0]
        assert all(sum(ps)<=n*beta for ps in probabilities)
        target=expminus_small(F(n,1024)*(1-s)**2)
        split_upper=sqrtbox(Pbad)[1]+sqrtbox(Qgood)[1];assert split_upper<=2*target[0]
        joint12=sum(w*ps[0]*ps[1] for w,ps in zip(weights,probabilities));m1=sum(w*ps[0] for w,ps in zip(weights,probabilities));m2=sum(w*ps[1] for w,ps in zip(weights,probabilities));assert joint12!=m1*m2
        rows.append(dict(n=n,beta_surrogate=beta,s=s,delta=delta,conditional_probabilities=probabilities,source_weights=weights,P_mean=meanP,conditional_Q_means=[sum(ps) for ps in probabilities],cut=cut,P_bad=Pbad,conditional_Q_tails=condtails,Q_mixture_tail=Qgood,tail_exp_interval=tail_exp,split_Cauchy_upper=split_upper,affinity_target_interval=[2*target[0],2*target[1]],unconditional_covariance=joint12-m1*m2,nonindependent_mixture=True))
    n=1024;beta=F(1,2);cut=768
    # One nonvacuous large-n binomial mixture; no 2^n patterns or dynamic PB table.
    qs=[sum((F(math.comb(n,j))*b**j*(1-b)**(n-j) for j in range(cut,n+1)),F(0)) for b in [beta,beta/4]]
    tail=(qs[0]+qs[1])/2;target=expminus_small(F(1));assert sqrtbox(tail)[1]<=2*target[0]<1
    return dict(status='PASS_SYNTHETIC_BERNOULLI_ONLY',small_cases=rows,large_binomial=dict(n=n,s=0,beta_surrogate=beta,cut=cut,source_weights=[F(1,2),F(1,2)],conditional_tails=qs,mixture_tail=tail,P_bad=0,split_upper=sqrtbox(tail)[1],affinity_target=[2*target[0],2*target[1]],Hoeffding_exp_128_not_evaluated=True),actual_phi=False,conditional_independence_only=True)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=ROOT/'exact_checks.json');args=ap.parse_args()
    ee,pi=ebox(),pibox();assert ee[1]<F(11,4) and ee[1]**4<64
    assert logbox(F(3))[0]>1
    C0sq=15*(1+pi[1]/2);assert C0sq<49 and 8192*C0sq<1024**2
    assert sqrtbox(F(32))[1]*(1+sqrtbox(F(2048))[1])+1<1024
    cut=first_large();initial=[A_case(n) for n in range(1,65)];boundary=[A_case(n) for n in range(cut-2,cut+3)];expanded=[A_case(n) for n in [128,256,1024,10000,100000,10**6,10**9,10**12]]
    scalar=[]
    for n,d in itertools.product([1,2,4,16,64],[F(0),F(1,8),F(1,4),F(1,2),F(1)]):
        x=F(n,512)*d*d;value=(1-F(1,512)*d*d)**n;lo,hi=expminus_small(x)
        assert value<=lo if x else value==lo==1
        scalar.append(dict(n=n,d=d,affinity_scalar_power=value,exp_minus_interval=[lo,hi]))
    b_rows=B_finite();b_pressure=[]
    for n in [1,3,7,8,9,15,16,63,64]:
        r=(7*n+7)//8;assert 6*n-8*r<=-n
        assert 6*n-8*(r-1)>-n
        b_pressure.append(dict(n=n,first_sufficient_r=r,previous_fails_coarse_exponent=True))
    b_big=[]
    for n in [128,1024,10000,10**6,10**12]:
        for r in sorted({(7*n+7)//8,n}):
            q=n-r;assert 6*n-8*r<=-n and 3*n-4*r<=-n+4*q
            b_big.append(dict(n=n,r=r,q=q,s_upper=F(1,4),sum_K12_over_J_epsilon='2^(1-n/2)',epsilon_squared_power_of_two=2-n,alternative_epsilon_power_of_two=1-n+4*q,integer_exponent_check=True))
    mixcut=first_large(4096);mixture_A=dict(final_constant=1024,c=F(1,1024),far_prefactor='4e n^2',A=4096,first_large_integer_n=mixcut,stages=dict(initial=[A_case(n,4096,1024,4) for n in [1,2,4,8,16,32,64]],boundary=[A_case(n,4096,1024,4) for n in range(mixcut-2,mixcut+3)],expanded=[A_case(n,4096,1024,4) for n in [128,1024,10000,100000,10**6,10**9,10**12]]),sqrt_mass_factors=[F(0),F(1,2),F(1),F(3)],synthetic_tails=mixture_tails())
    assert 16384*C0sq<1024**2 and sqrtbox(F(32))[1]*(1+sqrtbox(F(4096))[1])+1<1024
    assert (1-1/ee[0])/2>F(1,4)
    authors={name:sha((ROOT/name).read_bytes()) for name in ['affinity.md','affinity_mixture.md','joint_budget.md'] if (ROOT/name).exists()}
    result=dict(status='PASS',scope='Finite rational/interval constants and legal scalar parameter gates only; not actual affinity/kernel/dx/FULL certification',source_sha256=sha(Path(__file__).read_bytes()),author_files_sha256=authors,execution=dict(producer_invocations=3,new_kernel_evaluations=0,new_receiver_points=0),seed=None,A=dict(final_constant=1024,c=F(1,512),A=2048,far_prefactor='2e n^2',near_gate='d<1/2 with d=1-s',first_large_integer_n=cut,constant_checks=dict(e_interval=ee,pi_interval=pi,e4_upper=ee[1]**4,small_branch_normalized_square_upper=8192*C0sq,large_branch_uniform_normalized_upper=sqrtbox(F(32))[1]*(1+sqrtbox(F(2048))[1])+1),stages=dict(initial=initial,boundary=boundary,expanded=expanded),scalar_consequences=scalar),mixture_A=mixture_A,B=dict(m_assumption='actual phi(1/2)>1/4 is analytic premise; surrogate m values test algebra only',finite_tests=b_rows,threshold_pressure=b_pressure,expanded_symbolic=b_big,responsibility=responsibilities()),partial_alpha=alpha_checks(),certification=dict(log='Fraction atanh N64 explicit remainder, N128/256 if branch not separated',pi='Machin arctan N64 alternating remainder',e='factorial partial N64 with positive tail',roots='isqrt outward 80 decimal digits',large_n='integer exponent inequalities, no expanded 2^n output'),limitations=['One-dimensional affinity and m lower bound are proof inputs, not numerically integrated here','Both selector branch premises and original common source/weights remain separately audited','The partial alpha cap retains Urest; no actual source fields reconstructed'])
    args.output.write_text(json.dumps(enc(result),ensure_ascii=False,indent=2)+'\n');print(json.dumps(dict(status='PASS',A_cut=cut,A_counts={k:len(v) for k,v in result['A']['stages'].items()},scalar_A=len(scalar),B_finite=len(b_rows),B_big=len(b_big),alpha=result['partial_alpha']['checks'],rest_omission_failures=result['partial_alpha']['omitted_rest_failures'],authors=authors)))
if __name__=='__main__':main()
