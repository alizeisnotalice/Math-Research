# R158 有限常数/参数门精确证书

状态：exact_checks.json status=PASS。只核一般几何命题所需的常数算术、合法分支、有限概率代数及来源余额。0新kernel、0新receiver、0原dx积分。实际核affinity、m=phi(1/2)及选择器/来源付款命题由作者与独审负责，不能因为本表PASS就升级理论。156的原矩/空间试验未运行。

## A：只对齐最终1024常数

绑定冻结作者文件：affinity.md SHA `5bd20e5b7bf24eb5f4f8c9570914969f6457d4edfc8ed437e8ff08bc6695518d`，affinity_mixture.md SHA `a8011dd3f3ddfeb5fe7d0701096cc17d017a92af4c4933d8356862cc851c7b0a`。没有保留中间2048全selector候选或d<1/4版本。

单源最终输入c=1/512、远soft价2e n² exp(−cn d²)、A=2048、d*=sqrt(A log(n+2)/n)。混合最终输入c=1/1024、固定参数前因子2、远soft价4e n² exp(−cn d²)、A=4096；二者最终全selector常数均1024。near-soft用d=1−s，不是sqrt(1−s)。辅助尺度网格是exp(1/n)，不改原Q的Lplus=min(b,(1+1/n)L)。

三阶段：

| 对象 | 初探 | 分界压力 | 扩大 |
|---|---|---|---|
| 单源 | n=1..64，64条 | 首个large n前后各2，5条 | 128,256,1024,10000,100000,10^6,10^9,10^12，8条 |
| 固定混合 | n=1,2,4,8,16,32,64，7条 | 同样5条 | 128,1024,10000,100000,10^6,10^9,10^12，7条 |

以有理log区间分离 `n <=4A log(n+2)`（小支）和严格反向（大支），只在后者使用d*<1/2。首个large整数分别为93789、199984；前一整数仍是裸Cauchy支。程序从4A起倍增定位并二分，搜索过程中各次分支也有有理区间认证；全小n范围的方向由log3>1及n<=4A处理，后段唯一性可由n−4Alog(n+2)的导数正性核对。没有把浮点d与1/2比较当证书；边界归小支。

小支检查实际裸Cauchy平方上界

    3(2n+3)(1+pi sqrt(n)/2)/(sqrt(n)log(n+2)) <=1024².

并另核统一粗平方常数4A*15(1+pi/2)<1024²。大支用far=2e n²/(n+2)^4或4e版本，严格far<1；将near/目标归一化为sqrt(32)(1/sqrt(log(n+2))+sqrt(A))，加far/[n^(1/4)sqrt(log(n+2))]后检查<1024。另以log3>1核统一粗常数sqrt(32)(1+sqrt(A))+1<1024。

还保存25条标量后果：n∈{1,2,4,16,64}、d∈{0,1/8,1/4,1/2,1}，精确核(1−d²/512)^n<=exp(−nd²/512)的有理exp区间。它只是若一维aff上界成立后的标量后果，**没有**积分或认证实际一维aff。e区间同时核e<11/4、e^4<64，支持两个c的常数算术；m下界的e常数(1−e^(−1))/2>1/4亦严格核过。

## 固定相关混合：最小Bernoulli/Poisson-binomial压力

48条：n∈{2,4,8,16}、beta_surrogate∈{1/2,3/4,7/8}、s∈{0,1/4,3/4,1}。delta=(1−s)(1−beta)，P的坐标成功概率为beta+delta；三个条件来源分别有概率向量全beta、全beta/4、beta*(i+1)/(n+1)，固定来源权1/2、1/3、1/6。每个来源条件下用独立Bernoulli卷积，混合后不假设独立；48例均显存非零无条件坐标协方差，避免把相关来源误当产品源。

同一实阈值n(beta+delta/2)用ceil落实成整数事件。精确计算P下尾、各条件Q上尾和固定来源混合Q上尾；逐例核条件均值<=n beta、尾<=exp(−n delta²/2)，然后核分割Cauchy的上界sqrt(P_bad)+sqrt(Q_good)<=2exp(−n(1−s)²/1024)。每个beta_surrogate满足1−beta>=1/16，符合所用常数前提；这些**不是实际phi的beta数值**。

另一条非空小量压力：n1024、s0、beta_surrogate=1/2、两个齐次条件来源beta和beta/4各权1/2，用二项式有限和算N>=768的混合尾；P_bad=0，严格核sqrt(Q_tail)<=2/e<1。不枚举2^1024状态，也未计算高成本exp(−128)尾帽；JSON明确记该Hoeffding指数未算。本例只作有限混合概率证据，不提升成真实核认证。

混合全selector恢复sqrt(M)，程序记录M=0,1/4,1,9的平方根因子0,1/2,1,3；零质量不做归一化。一般M与任意固定来源相关性由作者证明处理。数值没有把nu换成nu_x、nu_selector或由时间新选的nu_t，也没有反向Jensen。

## B：原双核/J比例及责任方向

绑定joint_budget.md SHA `ca5e4a52a41a38e4725c1c5047772a51805c2131c5ebb161333755a0b96818ae`。B只核给定真实核比推论的代数，不评价K1/K2/J。

408个有限有理测试：n∈{1,2,4,8,16,32,64}，s∈{0,1/16,1/8,1/4}，m_surrogate∈{1/4+1/1024,1/2,1}。计算c_s=s+(1−s)/m<=4。r取去重{ceil(7n/8),n}，对单核粗比R=2^n s^r c_s^(n−r)核R²<=2^(−n)，故同界双核相加得到epsilon=2^(1−n/2)。另q取去重{0,1,ceil(n/8),n}、r=n−q，核R<=2^(−n+4q)，双核epsilon=2^(1−n+4q)。s=0,r=0按空乘积1，s=0,r>0为0，无0/0。

9个邻阈值压力n∈{1,3,7,8,9,15,16,63,64}：r=ceil7n/8的整数指数6n−8r<=−n成立，r−1不满足这个**粗充分指数门**；后者不是原实际kernel反例。扩大n∈{128,1024,10000,10^6,10^12}、r=ceil7n/8和n共10条，只保存整数指数，不展开百万/万亿维2^n。大n的epsilon平方指数和q版指数明确保留，避免浮点下溢成0。epsilon可能>=1的参数不冒称获得小量吸收。

责任用epsilon∈{2^(−20),1/16,1,16,2^20}五组，三来源J=(1/3,1,7/2)，K12=epsilon*theta*J，theta=(0,1/4,1)，原非负交通权W=(0,2/3,5/7)。定义chi12=K12/(K12+J)、chiJ=J/(K12+J)，P=ΣW、P12=ΣW chi12、PJ=ΣW chiJ。逐点核chi12<=epsilon/(1+epsilon)，同一权W严格核

    P12<=epsilon/(1+epsilon)*P,
    P12<=epsilon*PJ,
    P<=(1+epsilon)*PJ, P12+PJ=P.

不是用ΣW K12冒充原责任P12，也不重选alpha/rho或来源权。原任意非负交通权下的积分推广由一般证明负责；本表不提供J责任的根阶费用。

## partial alpha必须保Urest

432条精确抽象预算：D∈{1/2,1,3}，QJ∈{1/4,2}，kappa∈{0,1/4,1/2,1}，theta∈{0,1/2,1}，q=QJ或2QJ，US=theta*kappa*D*QJ，Urest∈{0,1/2,1}*(Dq−US)。全部满足q>=QJ、US<=kappa DQJ、总预算有限且alpha=(Dq−US−Urest)/QJ>=0。逐条核强弱两帽

    alpha>=D(q/QJ−kappa)−Urest/QJ
         >=D(1−kappa)−Urest/QJ.

删去Urest会在156条上失败。最小保存例D=1/2,QJ=q=1/4,kappa=0,US=0,Urest=1/16：alpha=1/4，正确下帽1/4，删rest的错误下帽1/2。没有将这些预算变量包装成真实source核或FULL实例；不能从当前运输来源核比推出所有消耗来源均同样小。D=0零消耗分支直接alpha0；QJ=0不除零，回原单独合同。

## 精度、执行及冻结

所有接受判据为整数/Fraction向外区间：log是64项atanh级数及显式尾，分界不分离可升128/256项；e用64阶阶乘正尾；pi用64项Machin交错余项；根式math.isqrt给80位十进制格并严格核平方方向，完全平方根返回等号。标量exp只在小有理参数用Taylor和及几何尾上界后取倒数。没有float接受，也没有实际kernel求积误差可声称已认证。

实际解释器 `/opt/homebrew/opt/python@3.14/bin/python3.14`，PYTHONPATH未设置，仅标准库：

    /opt/homebrew/opt/python@3.14/bin/python3.14 exact_checks.py

可用--output另存。实际完整调用3次、均exit0/PASS，无失败：第一次为单源/预算初稿；第二次加入作者定稿混合版并将责任按chi原交通定义修正后完整核；第三次只删除尚可能变动的audit文件哈希依赖、保留三份冻结作者文件的内容SHA后最终复现。没有重写作者文件；中间稿数值不作最终证明依赖。JSON约660KB，所有参数/区间或精确生成菜单都可由源码重建。

冻结SHA256：

- exact_checks.py：`15c772a803d0b238d52245e84dca2e478ed757575be6be6ffd6602dcb0a0ce7d`
- exact_checks.json：`7f5ed31524a7079d7ccd06f01b2bf78afa900f69556afca4af820a44690d4d43`

有限证据不认证原共同来源权可装入固定nu、不支付good/history/j/time、外hard或J责任剩余价，不宣布一般弱型主目标闭合。完成后停止。
