#!/usr/bin/env python3
"""Portable replay of R158 exact finite certificates; no kernel quadrature."""
from pathlib import Path
import argparse,shutil,subprocess,sys,json
ap=argparse.ArgumentParser();ap.add_argument('--destination',type=Path,required=True);a=ap.parse_args()
src=Path(__file__).resolve().parent;dst=a.destination.resolve()
if dst.exists():raise SystemExit('Use a new destination')
dst.mkdir(parents=True)
for name in ['exact_checks.py','affinity.md','affinity_mixture.md','joint_budget.md']:shutil.copy2(src/name,dst/name)
r=subprocess.run([sys.executable,str(dst/'exact_checks.py'),'--output',str(dst/'exact_checks.json')],cwd=dst,capture_output=True,text=True)
if r.returncode:raise RuntimeError(r.stderr+r.stdout)
print(r.stdout.strip())
assert (src/'exact_checks.json').read_bytes()==(dst/'exact_checks.json').read_bytes()
assert json.loads((dst/'exact_checks.json').read_text())['status']=='PASS'
print('REPLAY_PASS; JSON byte-identical; no kernel/receiver quadrature')
