# R513 必要来源与复现索引

起始专用clone /Users/zhengzhihao/Math-Research-centered-cube-work，main e498d07231818a464a23b9f7da0789f468f1cade，origin git@github.com:alizeisnotalice/Math-Research.git，工作区干净。上一轮已独审及推送属进展，本轮继续未付近层几何，未改目标为有限模型。

复用Astra high几何、Sol high独审、Sol medium数值，各自/tmp责任文件；只有主代理归档及git。主代理提出连续质量窗及原流直接Cauchy，独审先核量词再读作者。后续新建议不改变原历史过程，所有选择先于来源pair。

数学技能沿M01/M03的紧性/极值/亏损范围及L03精确证书区分。本轮没有引入新的外部强定理。连续最大场沿R512已独审的Prokhorov紧性和可测最大值定理，重新核当前H核连续、固定边缘、正质量下界及真实闭密度图。上一轮详细来源：[R512归档](https://github.com/alizeisnotalice/Math-Research/tree/main/centered-cube-upper-bound/rounds/512)。不从技能名称推断未知树或谱接口。

实际数学Python /Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python，数值脚本记录Python/SymPy/python-flint版本及Arb256。SymPy精确身份、有理比较、严格球和有限点审计分别说明；没有把区间含0当完整恒等证明。MATLAB未使用，不列证据。未安装软件，未编译PDF。

numeric前次通用SymPy化简慢的探索已终止，最终脚本采用显式log原函数并实际重跑通过；仅保最终必要代码与结果，不归档中间运行。六例n/a固定，所有真实B体积与旧/新ν权完整；fixed test字段不能认证自洽极值。主代理的126项真实连续源平均窗口检查和代理精确检查在正文代码围栏可重放；PRE独审重复不加作新成果。

重放提取proof/geometry中的python围栏，使用-I运行；numeric脚本生成同名JSON。比较规范化结果只排顶层seconds运行时间，其余字段逐项保留，stdout逐字一致。实际记录见replay，归档程序再次解压复现。

原硬标签跳跃的有限诊断用于验证平滑窗修复，不以此花大功夫否定一般路线。新结果的主要用途是保原来源地消除额外标签代价，并锁定有正确方向的真实边界收费。窗口平方与硬层下降递推需另建比较，不能无价并用。

本轮另阅读用户所附《Pro_486轮后联合估计攻坚建议_20261021.md》。其逐代直和能量与一次高捕获强度和累计停止费用的区分继续作为接口约束；本轮未把自然Palm链结论移植到连续窗极值，亦未声称完成该建议的B1/B2测试构造。附件是路线建议，不替代当前已审合同。
