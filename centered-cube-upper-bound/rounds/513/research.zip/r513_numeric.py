#!/usr/bin/env python3
"""R513 finite actual-shell score and discrete/smooth label H-kernel certificates."""
from pathlib import Path
import sys,platform,json,time
import sympy as sp
import flint
from flint import arb,ctx
ctx.prec=256
ROOT=Path(__file__).resolve().parent
u=sp.symbols('u',real=True)
checks=0

def ck(x):
 global checks
 assert bool(x)
 checks+=1

def ball(x):
 x=sp.sympify(x)
 if x.is_Rational:return arb(int(x.p))/int(x.q)
 if x.func==sp.Add:return sum((ball(y) for y in x.args),arb(0))
 if x.func==sp.Mul:
  z=arb(1)
  for y in x.args:z*=ball(y)
  return z
 if x.func==sp.Pow and x.args[1].is_Integer:return ball(x.args[0])**int(x.args[1])
 if x.func==sp.log:return ball(x.args[0]).log()
 raise ValueError(x)

def avg(expr):return sp.expand(2*sp.integrate(expr,(u,0,sp.Rational(1,2))))
def st(x):return ball(x).str(35,radius=True)

def model(n,a):
 w=sp.Rational(1,32*n);h=1+sp.Rational(1,4*n);g=h**n;V=2*w*sp.Rational(1,2)**(n-1)
 m=1+a*u;mp=1+a;D=a*(1-u);d=sp.log(mp/m)/sp.log(4)
 ck(g>sp.Rational(5,4) and g<sp.Rational(165,128))
 ck(1>=sp.Rational(4,5));ck((1+a/2)<=sp.Rational(8,5));ck(mp/g>=sp.Rational(4,5));ck(mp/g<=sp.Rational(8,5))
 # Fixed bounded test fields ell_0=1_inner, ell_1=1_outer, not self-consistent extremizers.
 p0=sp.Integer(1);p0new=1/g;p1=a*u;p1new=a/g
 ck(sp.simplify(p0new-p0/g)==0);ck(sp.simplify(p1new-p1/g-D/g)==0)
 cross_score=sp.simplify(p1new-p0/g);intersect_change=a*u-1
 ck(sp.simplify(cross_score-(intersect_change+D)/g)==0)
 same=m*(1-1/g)**2+D/g**2
 cross=m+mp/g**2
 smooth=m+mp/g**2-2*m*(1-d)/g
 expanded=m*(1-1/g)**2+D/g**2+2*m*d/g
 ck(sp.simplify(smooth-expanded)==0)
 def logmoment(p):
  v=1+a/2
  def primitive(z):return z**(p+1)*(sp.log(mp/z)/sp.Integer(p+1)+sp.Rational(1,(p+1)**2))
  return 2/a*(primitive(v)-primitive(sp.Integer(1)))/sp.log(4)
 smoothavg=avg(same)+2/g*logmoment(1);sameavg=avg(same);crossavg=avg(cross)
 normavg=avg(m*(1-1/g)**2);shellavg=avg(D/g**2);windowavg=2/g*logmoment(1)
 windowbound=avg(2*D/(g*sp.log(4)))
 ck(ball(smoothavg-sameavg)>0);ck(ball(crossavg-smoothavg)>0);ck(ball(windowbound-windowavg)>0)
 audits=[]
 for t in [sp.Integer(0),sp.Rational(1,4),sp.Rational(1,2)]:
  di=d.subs(u,t);bound=(D/(m*sp.log(4))).subs(u,t)
  ck(ball(bound-di)>0)
  # d<=1/2 is analytic from 1<=m<=m'<=2; audit ball includes exact endpoint .5.
  ck(ball(di)>=0);gap=sp.expand_log(sp.Rational(1,2)-di,force=True)
  ck(gap==0 or ball(gap)>0)
  oldformula=(m+mp/g**2-2*m*(1-d)/g).subs(u,t)
  newformula=expanded.subs(u,t)
  ck(sp.simplify(oldformula-newformula)==0)
  audits.append({'theta':t,'d_exact':di,'d_arb':st(di),'d_upper_D_over_m_log4_exact':bound,'smooth_norm_squared_arb':st(oldformula)})
 # Fixed-label score replacement cost at C=S=1 is at most D/g.
 # Here field1 attains it, field0 has zero weighted shell.
 result={'n':n,'outer_mass_a':a,'inner_mass':1,'W':mp,'w':w,'h':h,'g':g,'receiver_volume_exact':V,'parent_band_q':sp.Rational(4,5),'parent_band_lambda':sp.Rational(8,5),'parent_band_r':2,'q_R_range':[1,1+a/2],'q_Rprime':mp/g,'q_Rprime_arb':st(mp/g),'m_R_range':[1,1+a/2],'m_Rprime':mp,'shell_mass_range':[a/2,a],'relative_shell_mass_range':[a/(2*mp),a/mp],'relative_shell_mass_average':avg(D/mp),'dyadic_label_behavior':'original label 0, expanded label 1 (endpoint mprime=2)' if a==1 else 'both true dyadic labels 0; cross-label test is diagnostic only','score_field0_original':p0,'score_field0_expanded':p0new,'score_field1_original_theta':p1,'score_field1_expanded':p1new,'same_field1_scaled_score_change_theta':D/g,'cross_field0_to_field1_scaled_score_change':cross_score,'cross_field_intersection_change_theta':intersect_change,'same_field1_scaled_score_change_average':avg(D/g),'same_field1_scaled_score_change_integral_dB':V*avg(D/g),'cross_field_scaled_score_change_integral_dB':V*cross_score,'cross_intersection_field_abs_mass_average':avg(1-a*u),'kernel_same_label_squared_average_exact':sameavg,'kernel_cross_label_squared_average_exact':crossavg,'kernel_smooth_log4_squared_average_exact':smoothavg,'normalizer_squared_average_exact':normavg,'shell_squared_average_exact':shellavg,'window_extra_squared_average_exact':windowavg,'window_extra_shell_upper_average_exact':windowbound,'kernel_same_label_squared_average_arb':st(sameavg),'kernel_cross_label_squared_average_arb':st(crossavg),'kernel_smooth_log4_squared_average_arb':st(smoothavg),'normalizer_squared_average_arb':st(normavg),'window_extra_squared_average_arb':st(windowavg),'window_extra_shell_upper_average_arb':st(windowbound),'kernel_smooth_squared_integral_dB_exact':V*smoothavg,'kernel_smooth_squared_integral_old_nu_exact':V*(avg(m*same)+2/g*logmoment(2)),'kernel_smooth_squared_integral_new_nu_exact':V*mp/g*smoothavg,'audits':audits}
 print('MODEL n',n,'a',a,'epsilonavg',avg(D/mp),'same',st(sameavg),'cross',st(crossavg),'smooth',st(smoothavg),'window',st(windowavg),flush=True)
 return result

def main():
 start=time.perf_counter();models=[]
 v,mp_test=sp.symbols('v mp_test',positive=True)
 for power in [1,2]:
  primitive=v**(power+1)*(sp.log(mp_test/v)/sp.Integer(power+1)+sp.Rational(1,(power+1)**2))
  ck(sp.expand(sp.diff(primitive,v)-v**power*sp.log(mp_test/v))==0)
 for n in [4,16,64]:
  for a in [sp.Rational(1,32),sp.Integer(1)]:models.append(model(n,a))
 def serial(x):
  if isinstance(x,sp.Basic):return str(x)
  raise TypeError(type(x))
 out={'scope':'six fixed rational true-L1 box-source models; bounded fixed test score fields, not self-consistent extremizers; original and smooth H kernels','environment':{'executable':sys.executable,'python':platform.python_version(),'sympy':sp.__version__,'python_flint':flint.__version__,'arb_precision_bits':ctx.prec},'models':models,'checks':checks,'seconds':time.perf_counter()-start}
 (ROOT/'r513_numeric.json').write_text(json.dumps(out,default=serial,indent=2)+'\n')
 print('PASS finite actual-shell score and discrete/smooth H certificates; no general theorem')
if __name__=='__main__':main()
