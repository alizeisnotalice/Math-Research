# R513 独立几何：真实中心重排的合法性与单边亏损账

本稿承接 R513 连续质量窗，不重复极值存在或原余流回代。得到一个确实保中心边缘、在明确条件下留在原密度带的同步替代，以及它的完整 score 费用。费用可做到小量 X；尚未构造同时具有足够场变化的替代族，也没有一次 W 付款。因此没有完成 Qbar 或原近层预算。

## 1. 一般两盒：共同质量、来源损失与窗移动的准确分拆

令 U,V 为任意真实盒，质量 m=μ(U)>0、m'=μ(V)>0，共同质量 I=μ(U∩V)。取 γ>1，s=log_γ m、s'=log_γ m'，τ=min(|s'-s|,1)。对非负系数 a,b 定义

k_U=a 1_U(y)1_[s,s+1](σ)，k_V=b 1_V(y)1_[s',s'+1](σ)。

所有范数和内积均在 L²(μ×dσ)。窗口交集长 1−τ，故

\[
\boxed{\|k_U-k_V\|^2=a^2(m-I)+b^2(m'-I)+(a-b)^2I+2abI\tau.}\tag{G1}
\]

证明只需展开 a²m+b²m'−2abI(1−τ)。这保留两盒共同来源，不用 W²，也不选择依赖来源对的半径。

对任意固定场 0≤L≤C，记 ψ_U=〈k_U,L〉、ψ_V=〈k_V,L〉。a>0 时，有符号核 k_V−(b/a)k_U 的正、负部积分分别恰为

b[(m'−I)+Iτ]，b[(m−I)+Iτ]。

于是

\[
-Cb[(m-I)+I\tau]\le\psi_V-(b/a)\psi_U
\le Cb[(m'-I)+I\tau].\tag{G2}
\]

这在任意质量比成立，τ 已截在 1，不丢大质量比补集。系数相同 a=b 时，原到新亏损只收费旧盒失去的来源与共同来源的窗移动：

\[
\psi_U-\psi_V\le Ca[\mu(U\setminus V)+I\tau].\tag{G3}
\]

同中心扩张时 I=m，a=S/R^n、b=S/R'^n，G2 即主 proof 的单边公式；正的新壳质量无需再收费。

## 2. 一个确实保中心边缘的同步候选

固定辅助 t=S 的配置及其窗场 L；这里若使用 EX，配置必须是同一真实密度带 [q,λ] 的全局最大者，C=S[1+log(γr)]。原 t(B)≤S 的历史接受流不随下面替代重跑。

取可测中心包 U₀⊂E，以及保 dB|_(U₀) 的可测映射 T:U₀→U₀。不要求 T 单射，但要求推前 Lebesgue 测度准确不变。令 C_B=T(B)，并在真实中心 B 提议同一个半径

\[
R'_B=R_{C_B},\qquad D_B=Q(B,R_{C_B}),\qquad V_B=Q(C_B,R_{C_B}).
\]

这对 B 的所有来源共同选择；T 不能依赖 y、z 或旧 history。半径窗自动保持，但密度带不自动保持。记

\[
M_B=\mu(V_B),\quad M'_B=\mu(D_B),\quad
I_B=\mu(V_B\cap D_B),\quad
\Delta_B=\mu(V_B\triangle D_B).
\]

**精确合法条件**是 qR_(C_B)^n≤M'_B≤λR_(C_B)^n。若有统一 0<η<1 且 Δ_B≤ηM_B，则

\[
(1-\eta)M_B\le M'_B\le(1+\eta)M_B,\qquad
(1-\eta)q_{C_B}\le q'_B\le(1+\eta)q_{C_B}.\tag{G4}
\]

因此如下可核条件足以让候选仍在**原带**：

\[
q_{C_B}\in[q/(1-\eta),\lambda/(1+\eta)]\quad\text{且}\quad
\Delta_B\le\eta M_B.\tag{G5}
\]

G5 是充分条件，不是必要条件；核心区可能为空，例如 r=1。该部分绝不能当已付补集。没有核心区时，G4 仅保证扩大带 [(1−η)q,(1+η)λ]。扩大后的极值不是原极值，不能对原极值免费应用扩大带的 EX。

原两父交集 μ(Q_B∩Q_C) 或原两父对称差本身不等于这里的 Δ_B；新 cross 盒 D_B 的来源质量必须实际计入。不能用另一中心合法性替代 G4/G5。

## 3. 保中心边缘使整体 score 亏损具有实际小量 X 账

写 k(D_B) 与 k(V_B) 均采用系数 S/R_(C_B)^n 和各自真实质量窗。保边缘使

\[
\int_{U_0}k(V_B)\,dB=\int_{U_0}k(Q_B)\,dB,
\quad
\int_{U_0}\psi(V_B)\,dB=\int_{U_0}\psi(Q_B)\,dB.\tag{G6}
\]

因此同步替代场差准确是 ∫_(U₀)[k(D_B)−k(V_B)]dB；无需改变来源测度。若所有 D_B 满足原密度合法性，EX 和 G3 给出

\[
\boxed{\left\|\int_{U_0}[k(D_B)-k(Q_B)]dB\right\|^2
\le2CS\int_{U_0}\frac{\mu(V_B\setminus D_B)+I_B\tau_B}{R_{C_B}^n}\,dB,}
\tag{G7}
\]

其中 τ_B=min(|log_γ(M'_B/M_B)|,1)。证明：EX 左边由 G6 改写；整体亏损也由 G6 改写，再逐 B 用 G3。未在积分前擅自把 pointwise 亏损当非负；非负性来自合法同步替代的极值性。

若 Δ_B≤ηM_B，则

\[
\tau_B\le\omega_\gamma(\eta):=
\min\{-\log(1-\eta)/\log\gamma,1\}.
\]

从而右端至多

\[
2CS[\eta+\omega_\gamma(\eta)]X_{U_0},\qquad
X_{U_0}=\int_{U_0}q_B\,dB.\tag{G8}
\]

最后一步使用 T 保 dB；不能对任意非保测的配对如此换序。这是实际 O_γ(CSη)X 误差，小 η 时可按最终根阶账选择。若辅助最大配置与原输入比较，同原带仅有 X*≤rX_original，此 r 必须保留。

原 t 可变时，G1/G2 仍逐核成立，但 G6 在保持 t(B) 不动而只重排半径时一般不成立。要么另保 t 加权边缘并检查中心模型，要么如本节明确使用统一 S 的 raw 外支配。这里采用后者，不声称原 gate 同流变换。

## 4. 同中心候选的同带精确条件及窗口费

对嵌套扩张 R'≥R，写 g=(R'/R)^n、δ=μ(Q_R'\Q_R)/m。其合法性准确等价于

\[
\frac{gq}{q_B}-1\le\delta\le\frac{g\lambda}{q_B}-1,\quad a\le R'\le b.\tag{G9}
\]

若 δ≥0，左边可替换为 max(0,gq/q_B−1)。因此“薄壳、小质量变化”与合法性不是同一件事：在 q_B=q 处必须捕获至少 (g−1)m 才能扩张；在 q_B=λ 处则不能捕获多于 (g−1)m。这解释为何仅用窗连续性不能免费得到大量可行替代。

沿主 proof 的单边公式，真正未付的费是

\[
B_{\rm window}=\int_{U_0}q_B\min\{\log_\gamma(1+\delta_B),1\}\,dB.
\]

若额外控制 δ_B≤η，则确有 B_window≤log_γ(1+η)X_(U₀)，而不是一次 W。这一误差可按 η 缩小；但缩小位移也可能同时缩小可提取的场变化，尚无固定比例收缩。即使获得很小 score 亏损，EX 也只说明所选替代场差很小，不能反向推出原 Qbar 小。

## 5. 本轮精确未证步骤

G7 是一种真正合法条件下的小亏损同步重排；G5/G9 给可检查的密度条件，G8 给完整 X 费用。尚缺的是：从原实际跨中心重叠中构造共同的 T/U₀（或同中心半径规则），保证替代合法，并让这些同步场差以不超过多对数的重数控制原近层场，余中心包另有来源费或严格吸收费。当前没有这样的 coercivity 或补集预算。

也可把 G7 的右边准确换序成一次 μ 积分：

\[
\int \left[\int_{U_0}R_{C_B}^{-n}
\{1_{V_B\setminus D_B}(y)+\tau_B1_{V_B\cap D_B}(y)\}\,dB\right]d\mu(y).
\]

其内列尚未证明多对数帽；只用原 selector 的 A_n 帽仍为 O(n)。这说明缺的不是再定义一个余项，而是对同一可行重排同时证明来源列结算和足够的场变化。G7/G8 不提供这一步。身份映射 T=id 虽完全合法且亏损为零，却没有任何场变化，是此逻辑区分的最简单核查；不作为原目标反例。

## 6. 本机精确算术核验

已实际运行本机 math-research-tools Python，以 Fraction 检验 98 项等式/包含条件，结果为 `PASS 98 exact window identities and cross-box feasibility checks`。γ=4 时质量对 (1,1),(1,2),(1,4),(1,16) 的窗位移分别为 0,1/2,1,2，全部可用有理数精确计算。检验包括不同幅度、共同质量 0/一半/全部及 d≥1 截断。真实一维 f=1_[−3,3]、C=1/8、R_C=2、B=0 给 V=[−7/8,9/8]、D=[−1,1]，对称差质量 1/4，相对质量 1/8。此为代数和模型核验，一般维数命题的证明是第1—3节直接展开与换序。

```python
from fractions import Fraction as F
count=0
for m,mp,d in ((F(1),F(1),F(0)),(F(1),F(2),F(1,2)),
               (F(1),F(4),F(1)),(F(1),F(16),F(2))):
 for I in (F(0),min(m,mp)/2,min(m,mp)):
  for a in (F(1),F(1,2)):
   for b in (F(1),F(1,3)):
    tau=min(F(1),d);ov=1-tau
    assert a*a*m+b*b*mp-2*a*b*I*ov==a*a*(m-I)+b*b*(mp-I)+(a-b)**2*I+2*a*b*I*tau
    count+=1
    pos=mp-I+I*tau;neg=m-I+I*tau
    assert pos+neg==m+mp-2*I*ov
    count+=1
QC=(F(-7,8),F(9,8));D=(F(-1),F(1))
length=lambda Q:Q[1]-Q[0]
intersection=lambda Q,T:max(F(0),min(Q[1],T[1])-max(Q[0],T[0]))
mc=length(QC);md=length(D);i=intersection(QC,D);delta=mc+md-2*i
assert delta==F(1,4) and delta/mc==F(1,8);count+=1
assert (1-F(1,8))*mc<=md<=(1+F(1,8))*mc;count+=1
print('PASS',count,'exact window identities and cross-box feasibility checks')
```
