# R513：连续质量窗与保原余流的边界亏损公式

目标仍为完整一般根阶上界。本稿给出一项几何估计修复：取消硬质量层标签跳跃，以连续质量窗建立同一原余流的平方支配，并将合法嵌套半径替换的score亏损直接计在真实来源质量上。未证明整体边界费用或新的平方来源预算。

## 1. 固定原合同与连续窗

μ=f dx≥0，W<∞；原中心E，a≤R_B≤b≤2a，m_B=μQ(B,R_B)=q_BR_B^n，q≤q_B≤λ=rq，0≤t≤S，ν=tq_BdB。r固定，所有历史、来源及D_*保留，γ>1固定。零流单列。令
\[
s_B=\log_\gamma m_B,\quad I_B=[s_B,s_B+1],\qquad
L(y,\sigma)=\int_E t(B)R_B^{-n}1_{Q_B}(y)1_{I_B}(\sigma)dB.
\]
窗口长度为1，不需除以质量或另作概率归一。定义
\[
\overline Q=\int_{\mathbb R}\int L(y,\sigma)^2\,d\mu(y)d\sigma.
\]
对固定σ，参与的父质量位于[γ^(σ−1),γ^σ]，半径比≤(γr)^(1/n)，所以原接收中心包络给
\[
0\le L\le C=S[1+\log(\gamma r)],\qquad
\int L\,d\mu d\sigma=\nu(E).
\tag{1}
\]
源积分是μ，中心积分是真实Lebesgue；此帽不是任意扩大盒内的来源密度帽。

## 2. 与全部平移硬层的准确关系

对θ∈[0,1)，按s_B∈[j+θ,j+θ+1)分层，得原列ell_(j,θ)。对任意s,t，二者被同一平移层包含的θ测度恰为
\[
\int_0^1\sum_j1_{[j+\theta,j+\theta+1)}(s)1_{[j+\theta,j+\theta+1)}(t)d\theta=(1-|s-t|)_+.
\]
另一方面|[s,s+1]∩[t,t+1]|为相同三角核。由非负Tonelli，准确有
\[
\overline Q=\int_0^1\sum_j\int\ell_{j,\theta}(y)^2d\mu(y)d\theta
=\iint_{E\times E}\frac{t(B)t(C)\mu(Q_B\cap Q_C)}{R_B^nR_C^n}
(1-|\log_\gamma(m_B/m_C)|)_+\,dB\,dC.
\tag{2}
\]
因此保留了真实父质量、原共享半径和同一来源交集。硬边界对θ是零测，无须丢弃集中于特定质量的父流，也无需闭标签双选。式(2)不说任何固定θ的平方量≤Qbar；所需的是下一节直接回到原流。

## 3. 原完整余流的直接回代

沿已证原F内来源支配，对每条原接受记录保其父B标签，再乘1_IB(σ)。积分σ准确恢复该记录，总质量仍是R_*，窗口来源密度F(y,σ)≤2L(y,σ)。所有σ在
\[
[\log_\gamma(qa^n),\log_\gamma(\lambda b^n)+1]
\]
内，其长度
\[
D=1+\log_\gamma r+n\log_\gamma(b/a)=O_r(n).
\]
在μ×dσ上一次Cauchy给
\[
R_*\le2\sqrt{DW\overline Q}.\tag{3}
\]
这里没有选择有利θ后遗漏补集，也没有新增离散层数或额外log损失。原gate任意且非负；F≤2L是原逐父raw支配的同标签积分，不是重新生成历史。

对任意u>0，低列部分满足∫_(L<u)L²≤uν(E)≤uSX。若未来高列H_u=∫_(L≥u)L²≤B(n)W+δX，则
\[
R_*\le\varepsilon X+\frac{D(uS+\delta)}\varepsilon W+2\sqrt{DB(n)}W.
\tag{4}
\]
仍需B(n)多对数以及uS+δ的根阶适配。式(3)/(4)是完整原D_*的充分桥，但未证明其右边来源预算。

## 4. 连续窗极值不再需要闭质量标签外放松

为寻找几何极值，以t=S正支配原L，动作仅R∈[a,b]且qR^n≤m(B,R)≤λR^n；固定中心边缘dB|_E，μ仍为原来源。在H=L²(μ×dσ)中取
\[
k(B,R)(y,\sigma)=S R^{-n}1_{Q(B,R)}(y)1_{[\log_\gamma m(B,R),\log_\gamma m(B,R)+1]}(\sigma).
\]
在可行动作上m≥qa^n>0。作全空间连续延拓时可将log内m替换为max(m,qa^n/2)，在可行图上完全相同。立方体边界μ零、m连续以及两个区间对称差长度随端点变化连续，保证H核连续；||k||≤S a^-n√W。

R512已独审的固定中心边缘紧性、紧集有限维投影及尾质量控制，逐项适用于这个H核；真实密度可行图闭，动作空间紧，a.e.非空中心先删零集。因此Qbar的最大值在混合图测度上达到；对最大场L*取线性score的可测argmax，再用平方正余项，得到确定性共同半径的最大场。这里没有质量层标签，也不扩大真实q带；原t=S是唯一已声明的正提升。固定μ/E的极值存在仍不等于对任意μ的统一预算。

对任意真实可行替代R'(B)及中心包U，记ψ(B,R)=〈k(B,R),L*〉，则
\[
\left\|\int_U[k(B,R')-k(B,R)]dB\right\|_H^2
\le2\int_U[\psi(B,R)-\psi(B,R')]dB.
\tag{5}
\]
本稿第5节的score估计可对任意非负有界窗场使用；应用(5)时须是这个自洽极值场且两半径都在同一可行域。不能把测试场的计算冒作极值证据。X*≤rX_original仍是含X费用回原流的比较，不省略D层Cauchy及入口倍数。

## 5. 精确嵌套核差与真实质量亏损

固定中心，R'≥R，g=(R'/R)^n，m=μQ_R>0，Δ=μ(Q_R'\Q_R)，m'=m+Δ。记
\[
d=\log_\gamma(m'/m),\qquad\tau=\min(d,1).
\]
三角窗交集恰为1−τ，故严格有
\[
\|k_{R'}-k_R\|_H^2
=\frac{S^2}{R^{2n}}\left[m(1-g^{-1})^2+\frac{\Delta}{g^2}+\frac{2m\tau}{g}\right].
\tag{6}
\]
三项分别为归一系数改变、真实新增来源、质量窗移动；没有把薄壳体积当作Δ。硬标签一跳就正交的损失，在这里改为随log实际质量变化连续。

更精确地，保持同一来源，考虑有符号差k_R'−g^-1 k_R，其正部L¹(μ×dσ)质量为S R'^−n(Δ+mτ)，负部质量为S R'^−n mτ。因此对任意0≤L*≤C，
\[
-CS R'^{-n}m\tau\le\psi(R')-g^{-1}\psi(R)
\le CS R'^{-n}(\Delta+m\tau).
\tag{7}
\]
特别原到新score亏损满足
\[
\psi(R)-\psi(R')\le(1-g^{-1})\psi(R)+\frac{CSq_R}{g}\tau,
\qquad \tau\le\frac{\Delta}{m\log\gamma}.
\tag{8}
\]
新增来源在非负场上的贡献只会降低此亏损，故上界无需再加Δ项。式(8)正是原同步替换中需要的方向。d≥1也由τ=1覆盖，不能只挑有利小质量比后丢补集。

若在极值配置上R'(B)=hR(B)且g=h^n固定，所有替代真实合法，则(5)与(8)合并给
\[
\|h_U\|_H^2\le2(1-g^{-1})\int_U\psi(B,R_B)dB
+\frac{2CS}{g}\int_Uq_B\min\{\log_\gamma(m'_B/m_B),1\}\,dB.
\tag{9}
\]
第一项是明确的小乘法亏损；第二项仍是原中心实际边界质量的加权费用，未付独立W。仅知∫ψ=Qbar*会保留循环，不声称(9)已经闭合。

## 6. 可行性、账目及尚缺步骤

实际新密度准确为q'=q_R(1+Δ/m)/g。若0≤Δ/m≤η_0且1≤g≤G，原q带只保证q'∈[q/G,(1+η_0)λ]，不自动留在[q,λ]。把band扩大固定倍数可形成另一个有界问题，但其最大配置可能靠新边界；不能不断扩大后免费移用同一极值比较。

因此关键未付仍有两项：构造足够多保持真实密度带的替代，或支付不合法部分；证明(9)实际边界费用的独立来源预算，并把它强制控制到Qbar所需的方向。连续窗修复消除了人为标签跳跃，未解决来源集中与跨中心重复。R512原硬层下降尾仍是可用的原费用工具，但不能不证明对应关系就把其qhat递推搬给当前连续窗。

所用紧性及可测最大值原定理的条件与来源沿R512 proof第6节；本轮仅重新检查H核输入，不声称新的外部谱/稳定定理。全部旧母账、原入口正分母、初始/删除跳跃/未来来源/宽距离/低强度/极端比例/尺度拼接/极限继续保留。

## 7. 精确连续中心核验

以下用真实μ=q0·1_[−3,3]dy，q0=1,2,4，1至3个真实中心区间，每区间共享半径1或2，γ=4。log4(q0R)为半整数，故全部平移分层边界可精确枚举。逐配置核窗pair三角权与平均硬层能量相等、窗口积分守恒、连续支撑上的Cauchy。测试是有限真实模型；任意L1结论由前述Tonelli和Cauchy证明，不由枚举外推。

```python
from fractions import Fraction as F
from itertools import product
from math import floor
blocks=[(F(-1),F(-1,2)),(F(-1,2),F(0)),(F(0),F(1,2))]
count=0
for nb in (1,2,3):
 I=blocks[:nb];xs={F(-3),F(3)}
 for l,h in I:
  for R in (F(1),F(2)):xs.update([l-R/2,l+R/2,h-R/2,h+R/2])
 xs=sorted(xs)
 def col(b,R):
  l,h=I[b]
  return [max(F(0),min(h,y+R/2)-max(l,y-R/2))/R for y in xs]
 def inner(a,b):
  return sum((xs[i+1]-xs[i])*(2*a[i]*b[i]+a[i]*b[i+1]+a[i+1]*b[i]+2*a[i+1]*b[i+1])/6 for i in range(len(xs)-1))
 for q0,shift in [(F(1),F(0)),(F(2),F(1,2)),(F(4),F(1))]:
  for choice in product((1,2),repeat=nb):
   cols=[col(b,F(R)) for b,R in enumerate(choice)]
   s=[shift+(F(0) if R==1 else F(1,2)) for R in choice]
   window=q0*sum(inner(cols[b],cols[c])*max(F(0),1-abs(s[b]-s[c])) for b in range(nb) for c in range(nb))
   averaged=F(0)
   for theta in (F(1,4),F(3,4)):
    labels=[floor(x-theta) for x in s]
    averaged+=q0*sum(inner(cols[b],cols[c]) for b in range(nb) for c in range(nb) if labels[b]==labels[c])/2
   assert window==averaged;count+=1
   total=q0*sum(sum((xs[i+1]-xs[i])*(c[i]+c[i+1])/2 for i in range(len(xs)-1)) for c in cols)
   expected=q0*sum(h-l for l,h in I)
   assert total==expected;count+=1
   D=F(3,2);W=6*q0
   assert total**2<=D*W*window;count+=1
print('PASS',count,'exact continuous-source window averaging, conservation and Cauchy checks')
```
