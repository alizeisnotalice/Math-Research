#!/usr/bin/env python3
"""R247 exact D and finite full-posterior dynamic gates; no physical/FULL claim.
Tests include later-deleted sources: an enlarged algebraic class, whereas the
original local traffic lemma uses terminal-good slots. Numerical high alone
does not establish original FIRST, physical cube or history qualifications.
"""
from fractions import Fraction as F
from pathlib import Path
import argparse, hashlib, json
import mpmath as mp

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def enc(x): return mp.nstr(x,50)
def fm(x): return mp.mpf(x.numerator)/x.denominator
def src(m,g,T='1',death=None): return {'mass':F(m),'groups':[(F(a),k) for a,k in g],'T':F(T),'death':F(death) if death else None}
def weight(v,t):
    z=F(1)
    for a,k in v['groups']: z*=min(F(1),a/t)**k
    return z
def score(v,t): return sum(k for a,k in v['groups'] if a<t)
def live(v,t): return v['death'] is None or v['death']>t

def cases():
    return [
      ('initial','two_scores',2,[src('1',[('.5',2)]),src('1',[('3',2)])],1),
      ('initial','three_correlated',2,[src('1',[('.5',1),('1.5',1)],'2'),src('2',[('1.25',2)],'1'),src('1/3',[('3',2)],'1')],2),
      ('pressure','births_delete',4,[src('10',[('.8',1),('1',1),('1.2',1),('1.4',1)],'1','1.4'),src('7',[('.9',1),('1.1',1),('1.3',1),('1.5',1)],'3'),src('5',[('1.05',2),('1.55',2)],'1/4')],1),
      ('pressure','coincident_birth_delete',4,[src('1',[('.5',2),('1.25',2)],'3','1.25'),src('2',[('1.25',3),('2',1)],'1'),src('1/2',[('.75',1),('1.25',3)],'1/4','1.5')],1),
      ('pressure','thin_mass_and_Tzero',4,[src('1/1000000000000',[('.25',4)],'1000000'),src('1000000',[('1.125',2),('1.75',2)],'0'),src('1',[('3',4)],'1')],1),
      ('pressure','zero_T_and_zero_D',4,[src('1',[('.5',4)],'0'),src('3',[('3',4)],'0')],1),
      ('expanded','n16',16,[src('1/10',[('.25',4),('1',4),('1.5',4),('4',4)],'2'),src('1',[('.5',8),('1.25',4),('3',4)],'1','1.5'),src('10',[('.75',4),('1.5',8),('2.5',4)],'1/10'),src('3',[('1',4),('2',4),('3',4),('4',4)],'1')],2),
      ('expanded','n128',128,[src('1',[('.5',64),('1.25',64)],'3'),src('1/2',[('1.1',32),('1.5',96)],'1','1.5'),src('3',[('1.25',128)],'1/3'),src('1/100',[('3',128)],'1')],1)]

def setup(c):
    phase,name,n,vs,pfactor=c; tau,g=F(1),F(2)
    assert all(sum(k for _,k in v['groups'])==n for v in vs)
    knots=sorted({tau,g}|{a for v in vs for a,_ in v['groups'] if tau<a<g}|{v['death'] for v in vs if v['death'] and tau<v['death']<g})
    D=[F() for _ in vs]; intervals=[]; pointwise_checks=0
    for a,b in zip(knots,knots[1:]):
        mid=(a+b)/2; ids=[i for i,v in enumerate(vs) if live(v,mid)]
        kk={i:score(vs[i],mid) for i in ids}
        for i in ids:
            D[i]+=weight(vs[i],a)-weight(vs[i],b)
        masses={i:vs[i]['mass']*weight(vs[i],mid) for i in ids}; e=sum(masses.values(),F()); assert e>0
        for i in ids:
            avg=sum((masses[j]*max(kk[i]-kk[j],0)/e for j in ids),F())
            assert avg<=kk[i]; pointwise_checks+=1
        intervals.append((a,b,ids,kk))
    assert all(0<=d<=1 for d in D)
    cap=sum((v['mass']*v['T'] for v in vs),F()); q=cap or F(1)
    eg=sum((v['mass']*weight(v,g) for v in vs if live(v,g)),F()); assert eg>0
    K=F(256); p=2*K*q/eg*pfactor
    assert p*eg>=2*K*q
    for i,d in enumerate(D):
        if not d:
            assert all(score(vs[i],(a+b)/2)==0 for a,b,ids,_ in intervals if i in ids)
    exact={'phase':phase,'name':name,'n':n,'tau':'1','g':'2','K':str(K),'p':str(p),'q':str(q),'e_g':str(eg),'actual_high_slack':str(p*eg-2*K*q),'capacity':str(cap),'capacity_slack':str(q-cap),'sources':[{'mass':str(v['mass']),'T':str(v['T']),'groups':[[str(a),k] for a,k in v['groups']],'death':str(v['death']) if v['death'] else None,'D_exact':str(D[i]),'static_R':str(2*K*v['T']/(p*D[i])) if D[i] else '0'} for i,v in enumerate(vs)],'event_knots':[str(k) for k in knots],'pointwise_full_posterior_checks':pointwise_checks}
    return exact,intervals,D,q,cap,p,eg

def run(c,data,dps):
    ex,intervals,D,q,cap,p,eg=data; vs=c[3]; n=c[2]
    with mp.workdps(dps):
        total=mp.mpf(0); gated={H:{'dynamic':mp.mpf(0),'static':mp.mpf(0),'new_dynamic_only':mp.mpf(0)} for H in [1,2,8]}; roots=0; max_root_width=mp.mpf(0); max_root_residual=mp.mpf(0)
        for a,b,ids,kk in intervals:
            logs=[]
            for i in ids:
                cf=vs[i]['mass']
                for th,cnt in vs[i]['groups']:
                    if th<(a+b)/2: cf*=th**cnt
                logs.append(mp.log(fm(cf)))
            ua,ub=mp.log(fm(a)),mp.log(fm(b))
            def quantities(u):
                ls=[v-kk[i]*u for v,i in zip(logs,ids)]; shift=max(ls); raw=[mp.exp(z-shift) for z in ls]; den=sum(raw)
                pp={i:r/den for i,r in zip(ids,raw)}; e=mp.exp(shift)*den
                flows={i:pp[i]*sum(pp[j]*max(kk[i]-kk[j],0) for j in ids) for i in ids}
                return e,flows
            def integ(fun,left,right):
                if right<=left: return mp.mpf(0)
                pts=[left,right]
                for mult in [1,4,16,64]:
                    if left+mp.mpf(mult)/n<right: pts.append(left+mp.mpf(mult)/n)
                return mp.quad(fun,sorted(set(pts)))
            def weighted(u):
                e,flow=quantities(u)
                return sum(flow[i]*fm(vs[i]['T']/q/D[i])*e for i in ids if D[i])
            total+=integ(weighted,ua,ub)
            ea=sum((vs[i]['mass']*weight(vs[i],a) for i in ids),F()); eb=sum((vs[i]['mass']*weight(vs[i],b) for i in ids),F())
            for H in gated:
                for i in ids:
                    if not D[i] or not vs[i]['T'] or kk[i]==0: continue
                    threshold=H*q*D[i]/vs[i]['T']; end=ua
                    if threshold<=eb: end=ub
                    elif threshold<ea:
                        left,right=ua,ub
                        for _ in range(4*dps+32):
                            mid=(left+right)/2
                            if quantities(mid)[0]>=fm(threshold): left=mid
                            else: right=mid
                        end=(left+right)/2; roots+=1
                        max_root_width=max(max_root_width,right-left)
                        max_root_residual=max(max_root_residual,abs(quantities(end)[0]/fm(threshold)-1))
                    value=integ(lambda u:quantities(u)[1][i],ua,end)
                    gated[H]['dynamic']+=value
                    static=F(ex['sources'][i]['static_R'])>=H
                    if static: gated[H]['static']+=integ(lambda u:quantities(u)[1][i],ua,ub)
                    else: gated[H]['new_dynamic_only']+=value
        tol=mp.mpf(10)**(-dps+8); capbound=fm(cap/q)
        assert total<=capbound+tol
        for H,row in gated.items():
            assert row['dynamic']<=total/H+tol and row['dynamic']>=row['static']-tol
            assert abs(row['dynamic']-row['static']-row['new_dynamic_only'])<tol
        return {'weighted_integral':enc(total),'capacity_bound':enc(capbound),'weighted_slack':enc(capbound-total),'gates':{str(H):{**{k:enc(v) for k,v in row.items()},'Markov_bound':enc(mp.mpf(1)/H),'weighted_Markov_bound':enc(total/H)} for H,row in gated.items()},'root_count':roots,'max_root_log_bracket_width':enc(max_root_width),'max_root_relative_degree_residual':enc(max_root_residual)}

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json')); ap.add_argument('--contract',type=Path,default=Path(__file__).with_name('task_contract.md')); args=ap.parse_args()
    out={'source_sha256':sha(__file__),'contract_sha256':sha(args.contract),'scope':'Finite correlated positive atomic clocks, exact D; full posterior. No actual C geometry, L1/FULL or general source-budget conclusion. Monotone numerical gate roots are non-interval.','dependencies':{'python':'3.12.14','mpmath':mp.__version__},'cases':[]}; maximum=mp.mpf(0)
    for c in cases():
        data=setup(c); lo=run(c,data,40); hi=run(c,data,70)
        def flatten(row,prefix=''):
            r={}
            for k,v in row.items():
                key=prefix+k
                if isinstance(v,dict): r.update(flatten(v,key+'.'))
                elif isinstance(v,str): r[key]=v
            return r
        with mp.workdps(100):
            lf,hf=flatten(lo),flatten(hi); diffs={k:abs(mp.mpf(lf[k])-mp.mpf(hf[k]))/max(1,abs(mp.mpf(hf[k]))) for k in lf}; md=max(diffs.values()); assert md<mp.mpf('1e-25'); maximum=max(maximum,md)
        row=data[0]; row.update({'mp40':lo,'mp70':hi,'precision_max_scaled_difference':enc(md)}); out['cases'].append(row)
        print(c[1],hi['weighted_integral'],flush=True)
    out['counts']={'cases':len(out['cases']),'initial':2,'pressure':4,'expanded':2,'exact_D_slots':sum(len(c['sources']) for c in out['cases']),'pointwise_full_posterior_checks':sum(c['pointwise_full_posterior_checks'] for c in out['cases']),'gate_comparisons':3*len(out['cases'])}
    out['precision_summary']={'max_scaled_difference':enc(maximum),'normalizer':'max(1,abs(high)); enc50; not an interval error estimate'}
    args.output.write_text(json.dumps(out,sort_keys=True,ensure_ascii=False,indent=2)+'\n'); print(out['counts'])
if __name__=='__main__': main()
