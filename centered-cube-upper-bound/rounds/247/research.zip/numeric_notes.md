# R247：实际动态分母的有限clock验证

实际完成8例（初探2、压力4、扩大2），24个精确D槽、75个full-posterior中点检查和24组动态/静态门对照。保留完整的相同两份Π，不作坐标独立化。本例包含后来删除的来源；这是比原terminal-good槽更大的代数类。数值high条件不认证原FIRST、真实cube、history/capture或FULL。动态增量证明本数值实现非空，不能据此宣称FULL严格扩大非空或一般root闭合。

## 运行前方案和实际实施

先独立筛候选：同一Π下sum_u Pi_u(kv-ku)+<=kv，所以积分权T_v e_t/(qD_v)后可由原D积分归一至sum nuT/q。D=0槽没有连续正score贡献，定义比值0。一般论证由作者/独审负责，本文件只给可复现有限证据。

初探n=2：两score、三相关来源。压力n=4：birth/delete，同刻birth/delete，质量比达10^18且某T=0，以及全部T=0/D=0。扩大n=16、128的异质阈值、删除、质量和T。所有tau=1、g=2、K=256，具体正有理质量、阈值重复数、删除时间、静态T均明列JSON。q取sum nuT，若全T零则取1；静态容量为精确Fraction。没有把T=0来源从posterior删掉。

Fraction在全部birth/delete点分片：D_v=sum存活段[w_v(left)-w_v(right)]，核0<=D<=1；score零的段差为零。逐无事件中点精确检查sum_u Pi_u(kv-ku)+<=kv。D为0的槽另核所有其存活段score零。

动态门H取1、2、8，等价et>=HqD/T。et在每无事件段非增，故只可能是整个段、空段或前缀；用精确Fraction两端degree先分类，仅内根用log-time单调二分。平段和等号边界直接由两端处理，不靠网格采样是否命中。共有5个门内根（两精度分别5）；保最大log bracket宽及相对degree残差。这些是普通高精度求根诊断，不是有向区间证书。

## 结果

|配置|weighted fullpair积分（上界<=1）|
|---|---:|
|two_scores|0.4333838120|
|three_correlated|0.2778912738|
|births_delete|0.09247748616|
|coincident_birth_delete|0.5091973242|
|thin_mass_and_Tzero|6.768439581e-7|
|zero_T_and_zero_D|0|
|n16|0.1354240704|
|n128|0.7716843259|

全部同时通过更精确sum nuT/q上界，及动态门积分<=weighted/H<=1/H。每例p精确取2Kq/eg或其两倍，保p*eg>=2Kq，且整个窗et>=eg，因此actual-high标量条件确在全窗成立。比较静态R=2KT/(pD)与动态R=Tet/(qD)，静态门为动态门子集。如下新增积分不是重新计算q或改变来源：

- three_correlated：H1新增0.05847389151，H2新增0.05037168342，两者静态门均为零；
- births_delete：H1新增0.03474338222，H2新增0.004258558352；
- coincident_birth_delete：H8新增0.03019744483；
- n16：H8动态0.0006339100058、静态0.00006100096000、新增0.0005729090458。

其余对照新增0；全部24组核动态=静态+新增。这里量化的是固定有限clock的未加权正pair积分，不是原含hard/receiver/FIRST的FULL交通。

## 精度、运行与复现

每例真正双Π及动态gate在mp40/70独立运行，事件/门根均切开，另按1/n层细分积分。enc50保留40位计算的舍入差；最大字段差/max(1,abs(high))为4.000896423e-41。70位5个内根最大log bracket宽9.055679079e-72、最大相对degree残差1.811135816e-71。不能把这些普通多精度一致性当严格求积/求根误差。精确D、容量和中点不等式则使用Fraction。

最终脚本实际完整运行（初版、补求根记录版、补scope注释最终版均已完成），未增加模型/样本范围；未作额外timing replay。父级将用最终冻结文件作包外完整回放。JSON不含耗时、时间戳或绝对路径，绑定源码与冻结合同SHA；counts可直接用于driver。

本机Python为3.12.14，mpmath为1.3.0，后者从vendor路径加载。仅需标准库和mpmath，无numpy/scipy依赖。在解压的脚本/合同所在目录运行：

```sh
PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor /Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 numeric_checks.py --contract task_contract.md --output replay.json
cmp numeric_checks.json replay.json
```

CLI默认合同为相邻task_contract.md、输出numeric_checks.json，也接受--output和--contract迁移参数。没有读取R246脚本或旧JSON；只沿用部分有限模型声明方法。
