# 第247轮合同：实际动态分母与共同测试容量

目标仍为任意正L1输入的一般 n^(1/2+o(1)) 一致弱型上界。本轮不以局部付款代替闭合。用户新材料作为建议；保留第223轮以后已审工具，不重新开始旧路线。

## 准确候选
原当前正交通记dP，含2Λ、真实dx、β来源、hard ν来源、完整两份Π、原终端good/bad、history/capture及余权。Π_t=1_Z w_t ν/e_t，w_t=∏min(1,A_i/t)，k_t=#(A_i<t)。固定实际receiver x的测试T_x(v)≥0，对辅助t不变，∫Tν≤q。令D_v=∫τ^g1_Z k_v w_t dt/t。D=0无正交通，对其定义比值0。候选：

∫ [T_x(v)e_t(y)/(qD_v)] dP ≤ 2Λ(16/3)X。

若成立，则比值≥H的原交通≤2Λ(16/3)X/H；补域仍未付款。精确核验receiver属于不交叶、j唯一、T源依赖、删除和零分母。R226静态测试门已付，当前terminal-good槽D_Z=D；只检查动态e_t信息的实际增量，不重复登记旧支。

## 允许工具和边界
R223原母式；R226 BP1–8静态门/FTC与receiver不交资格；R237来源账目；R245加权能量；R246已审出生与删除账。FIRST为同一x的∫pβ≤q、∫Q*ν≤q。不可假设β≤√nν点态，不能用signed信用付正门，不能把aux v当hard z。所有无限情形通过非负Tonelli/单调截断，未证明总正交通有限时不交换signed极限。

## 分工、成功标准
Astra r217_peak负责residual_geometry.md，给完整原回代及历史差别。Sol r217_compare负责test_geometry.md，只核实际capture/near极值路线，无新预算则短记缺口。Sol r217_audit先独审命题，再读作者证明，负责audit.md。Sol r217_numeric负责numeric_checks.py/json、numeric_notes.md，三阶段有限非乘积clock、真实动态gate分根、Fraction D及40/70位复核。主代理负责proof.tex.txt、报告、完整复跑与归档。各agent不得改他人文件，不扩展任务。

成功仅指新估计经独审且原来源回代可付款；若只是旧门改写须明确。一般目标只有全分支根阶预算成立才完成。数值不认证有限clock来自FULL cube，更不能据数值猜渐近阶。使用本机Python/Fraction/mpmath与L03技能的证据边界，不声称浮点区间认证。不编译PDF。
