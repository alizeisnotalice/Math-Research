# R247：保实际度数的 cross-test FTC 付款

**结论。** 对原正交通，目标测试核与实际度数的乘积有下述已付联合一阶矩；由此得到全原 clock、全部实际 soft/尺度上的明确 εX 子交通预算。相对 R226 的静态 FTC 门，增量是保留 e_t(y) 而不先下放到 e_g(y) 再使用 high 的统一下界。未证明一般中间硬层或整个剩余量的根阶界；原 soft-cut 几何没有被假称为已解决的面预算。

## RG1. 准确原量与共同参数

固定原有限截断。对每个种子 ω，原 terminal leaves V 不交，真实正 receiver 集记 E_{ω,V}。R107 `integration.md:9–17` 明确 s(x)、L_s(x)、R(x) 是原物理选择器，q∈[3λ/4,λ] 是 E 上共同常数，X=λ|E|；`109–120` 明确 Q_R(x) 整体位于唯一 V，且每 x 至多一条非零叶行。因此保

\[
 E_{\omega,V}\subset E\cap V,\qquad
 \sum_V1_{E_{\omega,V}}\le1,\qquad
 \sum_j1_{\{j(x)=j\}}=1.
\]

j(x) 及 g(x)=√(L_s(x)R(x)) 不随 y、v、u 或 hard z 重新选择。设 τ_j=a/c_j；τ_j>g 的行为空。记

\[
 p_y=P_{s(x),L_s(x)}(x-y),\qquad
 \Pi_{y,t}(dv)=\frac{1_{Z_{j,t}(y)}(v)w_{j,t}(y,v)}{e_t(y)}\nu_V(dv).
\]

full e_t(y) 不限制到 good、bad 或任意新源集合。无效/零分母行的原正交通先置零。δ_t(v,u)=(k_{y,t}(v)−k_{y,t}(u))_+，其中 v 是原 terminal-good 槽；于是 δ_t≤k_{y,t}(v)。

把原 remaining 正门、capture、Ψ、FA、good/bad、所有此前已付分支的零余权合入 0≤κ_r(t,u,v)≤1，保 hard RN 因子 0≤a_ω≤1。原当前正测度准确写为

\[
\begin{split}
 d\mathcal P_{cur}
 ={}&2\Lambda\,\mathbb E_\omega\sum_{V,j}
 1_{E_{\omega,V}}(x)1_{\{j(x)=j\}}1_{high}
 \frac{p_yh_{R(x)}(x-z)a_\omega}{q}
 \,dx\,\beta_V(dy)\nu_V(dz)\\
 &\times1_{J_{far}(r)}(t)\kappa_r(t,u,v)\delta_t(v,u)
       \Pi_{y,t}(dv)\Pi_{y,t}(du)\frac{dt}{t}.
\end{split} \tag{RG1}
\]

J_far(r)⊂[τ_j,g(x)]。所有原 history 可以继续依 r；以下只作正上界。本文不变更该测度的来源，也不调用任何负信用。

令 T_x(v)≥0 是辅助 t 上静态的实际测试，满足每个原 receiver/叶

\[
 \int T_x(v)\nu_V(dv)\le q,\qquad
 \int p_y\beta_V(dy)\le q. \tag{RG2}
\]

主应用为

\[
 T_x(v)=Q_x^*(v)=\frac13\left[P_{s,L}(x-v)+P_{s,L^+}(x-v)+P_{1,b}(x-v)\right],
 \quad L^+=\min(b,\gamma L).
\]

其 s,L,L⁺ 取原 x 的共同实际参数，不依 source y 或 v 重选；R117 JG3 与原 FIRST 正是 RG2 的资格。没有使用 upward-soft 菜单或在扩大的 receiver 域重授 FIRST。

## RG2. 只计算正支持的整段权损失

定义静态于辅助 t 的

\[
 D_Z(x,y,v)=\int_{\tau_j}^{g(x)}
 1_{Z_{j,t}(y)}(v)k_{y,t}(v)w_{j,t}(y,v)\frac{dt}{t}.
 \tag{RG3}
\]

逐源 w_t 非增且 −∂logt w_t=k_tw_t，故

\[
 0\le D_Z\le w_{\tau_j}-w_g\le1.
\]

D_Z=0 时原对应正交通为零，按非负 Tonelli 理解，不定义除以零的比值。并发事件与 clock 端点不影响 dt/t 积分。这个定义不消费 signed 删除账。

R226 `boundary_payment.md` BP7d 已证：**当前 terminal-good 槽 v∈Z_g(y)** 在较早时刻一直存活，因此在当前非零正交通上

\[
 D_Z=w_{\tau_j}-w_g=:D.
\]

所以本文不把用 D_Z 替换 D 登记为新覆盖；保 Z 的写法仅使支持与零行资格明确。

## RG3. 已付联合一阶矩与动态门

在 D_Z>0 的有效原行上令

\[
 \mathscr R_t(x,y,v)=\frac{T_x(v)e_t(y)}{qD_Z(x,y,v)},
\]

其它零交通行置零。则

\[
 \boxed{\int \mathscr R_t\,d\mathcal P_{cur}\le8\Lambda X.} \tag{RG4}
\]

特别对任意 H>0，允许该门随原 t、y、v 变化，

\[
 \boxed{\mathcal P_{cur}\{T_x(v)e_t(y)\ge HqD_Z(x,y,v)\}
          \le\frac{8\Lambda}{H}X.} \tag{RG5}
\]

门在 D_Z=0 上取何种约定均不改变交通。简版把 D_Z 改成1也成立，但覆盖不更大。

**证明与删门顺序。** 先固定完整外行 x,y,z,j。用 \mathscr R_t 乘 RG1 的内层，被消去的是 v 槽的一个实际 e_t(y)，而 u 槽仍是原完整 Π_{y,t}。在有效时刻先用正性、δ≤k_v 及 ∫Π_{y,t}(du)=1，得到

\[
\begin{split}
 &\int_{J_{far}}\int\!\int
 \mathscr R_t\kappa_r\delta_t\Pi_{y,t}(dv)\Pi_{y,t}(du)\,d\log t\\
 &\le\int_{\{D_Z>0\}}
       \frac{T_x(v)}{qD_Z(x,y,v)}\nu_V(dv)
       \int_{\tau_j}^{g(x)}1_{Z_{j,t}(y)}(v)k_{y,t}(v)w_{j,t}(y,v)d\log t\\
 &\le q^{-1}\int T_x(v)\nu_V(dv)\le1. \tag{RG6}
\end{split}
\]

在得到不再含后验分母的第二行后，才把实际 J_far/high-heavy-time 等正限制扩大到 [τ_j,g]。无效时刻不需要新定义 Π；RG3 的非负权损失已经有独立定义。T_x、D_Z 可移出同一个 v 的 clock 积分；**动态门本身没有被当成静态源集合移出 FTC**。RG5 使用的是 1_{\mathscr R≥H}≤\mathscr R/H，然后 RG6，所以 R226 对任意逐时门的警告没有被绕过。

接着才回到真实 receiver/source 积分。对每个保留叶，由 RG2，

\[
 \int\frac{p_y}{q}\beta_V(dy)\int h_{R(x)}(x-z)\nu_V(dz)
 \le(h_{R(x)}*\nu_V)(x)
 \le(h_{R(x)}*f)(x)\le4\lambda. \tag{RG7}
\]

这里保住 E_{ω,V} 和 1_{j(x)=j}，故 ∑V,j 不复制这份 X；原 seed 仅取概率平均。RG7 积分至多4λ|E|=4X，再乘2Λ即得 RG4。也可使用 C0q≤C0λ 得安全常数2ΛC0X，C0=16/3；8Λ 使用原较精确的 hardband 4λ。没有仅凭 source measures 不交就删除 receiver 叶门。

证明没有交换 β 和 ν，也没有把 β−ν 强行并入 ν；它适用于原完整 β。未用硬 rank、soft 低 N、详细平衡、菜单或新的 source norm。原 source/history 条件保在 κ、a 中；放松它们只用于证明上界。

## RG4. 与已付静态 FTC 的精确关系

R226 BP5/BP7 已付的是静态门 T_x(v)≥r p_yD，原 high 为 p_y e_g(y)≥2Kq。较早时刻 e_t(y)≥e_g(y)，故在当前正交通上

\[
 \{T_x(v)\ge r p_yD\}\subset
 \{T_x(v)e_t(y)\ge2KrqD\}. \tag{RG8}
\]

因此新门包含对应旧静态门，不能把交集再次收费。实际相较“终端精确度数门”T_x(v)e_g(y)≥HqD 的扩大因子恰为 e_t(y)/e_g(y)。与统一静态阈值 H p_yD/(2K) 比较，当前目标阈值为

\[
 \frac{HqD}{e_t(y)},\qquad
 \frac{H p_yD/(2K)}{HqD/e_t(y)}
       =\frac{p_y e_t(y)}{2Kq}
       =\frac{p_y e_g(y)}{2Kq}\frac{e_t(y)}{e_g(y)}\ge1. \tag{RG9}
\]

所以保留的是实际 high 余裕及动态归一化信息，不是 D_Z 的另一次“改进”。几何参数上阈值可以更低，但本文没有认证新增交集在所有 FULL 输入上非空或有统一正比例，也没有穷尽历史所有可能等价重写。与已核 R226 的准确区别就是 RG9；旧 FA、其他已付门在当前 κ 中继续为零。

## RG5. 原量的独立 ε 份额与明确补域

选择一个新的独立份额 ε_new>0，取 H=8Λ/ε_new，则对当前余权

\[
 \mathcal P_{cur}[\mathscr R_t\ge H]\le\varepsilon_{new}X,
 \qquad
 \mathcal P_{left}=\mathcal P_{cur}[\mathscr R_t<H]. \tag{RG10}
\]

旧账已付份额不因事件包含关系被再次领取；应用可以直接从旧静态补域开始。补域非零行具有真实动态约束

\[
 Q_x^*(v)e_t(y)<HqD,
 \quad p_yw_g(y,v)\le KQ_x^*(v),
 \quad p_y e_g(y)\ge2Kq,
\]

从而

\[
 \frac{e_t(y)w_g(y,v)}{e_g(y)D}<\frac H2. \tag{RG11}
\]

RG11 是剩余实际权损失与归一化的关系，未据此证明 root 价。该子交通的 εX 支付覆盖所有实际 soft、尺度、selector 与整段时钟；没有新增源质量项、没有 √n 或菜单费用。但这不是整个未付中间硬层的 εX+根阶预算，也没有解决原 cut 与 coarea 来源面的联合几何。

## RG6. 可复现有限检查与范围

本轮正式套件为相邻 `numeric_checks.py`、`numeric_checks.json`，具体模型、运行方法和解释见 `numeric_notes.md`。实际完成8例（初探2、压力4、扩大2），24个精确 D 槽、75个 full-posterior 中点检查及24组动态/静态门对照。D、容量及中点不等式用 Fraction；实际双 Π 积分在 mp40/70 分别计算，并在事件点和动态门内根处分段。全部通过加权矩≤∫Tν/q及动态门≤该矩/H的检查；普通多精度积分与求根一致性不是区间认证。

正式模型包含删除来源，比原 terminal-good 槽更宽；数值 high 标量条件不认证原 FIRST、cube、history/capture 或 FULL。有限模型中的动态新增量不能据此升级为 FULL 新增交通的非空比例。一般付款由 RG6–7 的原测度证明给出，本节仅引用已归档可重放的有限证据，不另保初探计算为认证。

本稿仅修改 residual_geometry.md，无来源重建、无负账复用、无仓库提交；本轮以有限扩充分支与准确补域交付，到此停止。
