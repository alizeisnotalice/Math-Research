#!/usr/bin/env python3
"""R247 full relocated numerical replay and artifact integrity verification."""
import argparse,hashlib,json,os,shutil,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def verify():
    m=json.loads((ROOT/'manifest.json').read_text())
    for n,h in m.items():assert digest(ROOT/n)==h,n
    return len(m)
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--verify-only',action='store_true');ap.add_argument('--output-dir',type=Path);a=ap.parse_args();count=verify()
    if a.verify_only:print('verified',count,'manifest hashes');return
    if a.output_dir is None:ap.error('--output-dir required')
    out=a.output_dir.resolve()
    if out==ROOT or ROOT in out.parents:ap.error('output must be outside package')
    out.mkdir(parents=True,exist_ok=False)
    for n in ('numeric_checks.py','task_contract.md'):shutil.copyfile(ROOT/n,out/n)
    start=time.monotonic()
    r=subprocess.run([sys.executable,str(out/'numeric_checks.py'),'--output',str(out/'numeric_checks.json'),'--contract',str(out/'task_contract.md')],check=True,capture_output=True,text=True,env=os.environ.copy())
    assert (out/'numeric_checks.json').read_bytes()==(ROOT/'numeric_checks.json').read_bytes(),'entire JSON mismatch'
    j=json.loads((out/'numeric_checks.json').read_text())
    assert verify()==count
    receipt=dict(complete_replay=True,entire_json_byte_identical=True,manifest_hashes_before_and_after=count,counts=j['counts'],json_sha256=digest(out/'numeric_checks.json'),stdout=r.stdout.strip(),elapsed_seconds=time.monotonic()-start,scope='Finite correlated clocks, exact D and numerical moving gates only; not actual cube/FULL or the unresolved general root-order budget.')
    (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
if __name__=='__main__':main()
