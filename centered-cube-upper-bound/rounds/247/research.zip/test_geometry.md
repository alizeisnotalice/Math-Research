# R247: capture geometry and the normalized terminal-test correlation

This bounded note owns only this file. It identifies the exact joint
test estimate and checks the strongest immediate near-extremizer
implication of QG. The latter reduces to terminal-weight flatness;
it does not pay the large-correlation remainder. No new general
source/receiver payment is certified, and no negative credit is used.

## TG1. The actual joint quantity, before any source replacement

Fix an original row r=(omega,V,j,x,y,hard z,history), with
`p=P_s,L(x-y)`, `g=sqrt(LR)`, `S=Z_g`, `pi=Pi_g`, and the actual
`Q=(K1+K2+J)/3`. Keep the complete `e_t(y)` and both original Pi_t.
On high `pe_g>=2Kq`, original FIRST gives `integral Q dnu<=q`.
On a nonempty clock window, `Jfar subset [tau,h]` with `tau<=h<=g`.
Set

    G={v in S:p w_g(v)<=KQ(v)}, B=S minus G,
    sigma_Q(dv)=1_S Q(v)nu(dv)/q,
    A_Q(v)=e_gQ(v)/(q w_g(v)),
    R_t(v)=e_gw_t(v)/(e_tw_g(v)),
    psi_t(v)=1_G(v) integral_B kappa_t(v,u)
                             [k_t(v)-k_t(u)]_+ Pi_t(du).

Here kappa_t in [0,1] retains all original positive gates, including
capture, FA, suffix/history and actual time restriction. It may depend
on hard z. It does not restrict the denominator e_t. Let

    C_Q(r)=integral_{Jfar} integral_G psi_t(v)R_t(v)
                                          sigma_Q(dv)dt/t. (TG1)

On G, `A_Q>=pe_g/(Kq)>=2`; consequently the exact change of measure
`Pi_t|S=R_t pi=R_t sigma_Q/A_Q` proves

    P_I^rem <= E sum_{V,j} integral 1_high dT_I
                            [Kq/(pe_g)] C_Q(r)
              <=(1/2) E sum_{V,j} integral 1_high dT_I C_Q(r), (TG2)

where, without any hard cap,

    dT_I=1_I 1_{j(x)=j}q^-1 p h_R(x-z)a_omega
                              dx beta_V(dy)nu_V(dz).

This has the actual beta, hard nu, real dx, and two complete
posteriors. Its origin is R128 RT1--3 and R245 JS1--3, not a model
with independently selected source coordinates. Merely knowing
`sigma_Q(S)<=1` and `integral R_t dpi<=1` does not bound TG1.

## TG2. What QG nearness actually implies

Fix all physical parameters and y,v,z for a genuine leg a=1,2,3.
With K_a the corresponding fixed actual target kernel and chi_exc,a
its inherited fixed capture-exclusion indicator, define the full
half-density column, including its terminal inverse weight, by

    H_a=integral chi_exc,a(x') h_R(x'-z)
          sqrt(P_s,L(x'-y)K_a(x',v))/sqrt(w_g(y,v)) dx'.

Put

    m=min(L,R), M=max(L,R), zeta=c_jg/m in [1,gamma],
    omega_i=min(1,b C(|y_i-v_i|/b)/m),
    Delta_m=sum_i(1-omega_i),
    N_a=(g/c_j)^n H_a.

The comparison preceding R224 TR11 retains the slightly stronger
bound

    N_a<=zeta^{-n/2} exp[-kappa Delta_m/2] Phi_a,
    0<=Phi_a<=1, kappa=25/2^68.                       (TG3)

Indeed the one-coordinate factor is
`zeta^-1 D_m sqrt(omega_m/omega_(zeta m))`, and
`omega_m/omega_(zeta m)<=zeta`. Multiply, then use QG. The factor
Phi_a is the exact retained-minus-excluded product ratio when the
fixed-box capture formula is used; with no exclusion take Phi_a=1.
This is an integrated, fixed-parameter statement. It is not a
pointwise receiver bound and does not remove physical/menu fees.

If some N_a>=1-v, 0<v<1, then

    zeta^n<=(1-v)^-2,
    Delta_m<=d_v:=-2 log(1-v)/kappa,
    Phi_a>=1-v.                                      (TG4)

For d_v<1 every omega_i>=1-d_v, and
`sum log omega_i>=-Delta_m/(1-d_v)`. Therefore the actual terminal
weight, including its original band rather than exact-min weight,
satisfies

    w_g>=a_v:=(1-v)^2 exp[-d_v/(1-d_v)].              (TG5)

Thus very-near-unit QG columns give a bounded terminal likelihood
ratio. They do not by themselves yield a new Schur/source estimate.
For clarity its exact original positive consequence is short:
for any t-independent target subset N on which w_g>=a>0,

    integral_{tau}^{h} R_t(v) k_t(v)dt/t
       <=[w_tau(v)-w_h(v)]/w_g(v)<=a^-1-1;
    C_Q restricted to N<=a^-1-1.                     (TG6)

The first inequality uses the full `e_t>=e_g`, and the second uses
the actual `sigma_Q(S)<=1`. No auxiliary source is deleted. Combining
TG2, `integral dT_I<=T_small<=4X`, and the mother coefficient 2Lambda
gives

    2Lambda P_N<=4Lambda(a^-1-1)X.                  (TG7)

The union of the three near-column events has the same a_v and uses
the same Q-FIRST capacity once, so no extra factor three is needed.
For example, 0<epsilon<=1 and
`v=(kappa/12)log(1+epsilon/(4Lambda))` give
`a_v^-1-1<=epsilon/(4Lambda)` and hence epsilon X in TG7:
use `d_v<=4v/kappa<=1/2` and
`-log a_v<=4v+8v/kappa<=12v/kappa`.

This is only the terminal-flatness implication of the near-unit
condition. It is contained in a small whole-weight-ratio case and
does not estimate the test/degree correlation away from that case.
It is recorded for calibration, not registered as a new independent
paid slot or a general joint geometry breakthrough. No claim that
this very narrow near-unit event is nonempty under all original
strict-soft/history qualifications is required or made.

## TG3. Why actual B=0 has not paid the complementary correlation

The exact hard condition is
`B_hard(v)=1_{R<=L}1_{Q_R(x)}(v)=0`. It excludes Q_R(v) only on
R<=L. The stronger capture exclusion of Q_a(v) applies on H0>=a;
the lower-clamped H0<a case has the distinct original short-clock
qualification. These facts are R228 RG6--11 and must not be merged
into an unconditional hard-core exclusion on all orientations.

In the fixed-parameter captured column, TG4 requires Phi_a close to
one: the removed target box has *small* half-density overlap with
the hard z window. This is not a contradiction. The actual hard
source can be far from that target box. The original beta--hard-z
source-distance gate does not become a y--v or z--v proximity gate.
The y--hard-z spatial deficit from R242 likewise cannot be substituted
into omega_i(y,v).

The all-scale hard band bounds the inside hard-source mass and FIRST
bounds the target Q source response. Both are upper marginal caps.
Neither gives a lower bound on the excluded-box overlap under the
joint `h_R(x-z)nu(dz) Q(v)nu(dv)` with its true
`w_t/(e_t w_g)` factor. Exchanging the two nu slots also exchanges
these unequal weights and all original gates; its unmatched outward
flux is not negative credit (the exact accounting is already R229
source_transport ST3--9). Capture has not supplied the sign or
quantitative joint capacity needed to discard that difference.

The earliest remaining assertion is therefore a bound on TG1/TG2
with this genuine weighted source correlation, after the already
paid disjoint traffic has been removed. Replacing it by either
`sigma_Q(S) integral R_t dpi`, by a cropped e_t, or by an independent
coordinate law would remove exactly the unpaid correlation. No such
replacement has been proved here. The near-unit calculation does not
resolve this remainder. This bounded auxiliary route stops here;
no new numerical experiment or general payment is asserted.
