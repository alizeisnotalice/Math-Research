# R247 独立审计

## 命题先行筛查（未读作者证明）

首次目录尚无合同或作者稿。以下只据主代理给定的原母式审准确候选，不补造原资格。仅写audit.md，保他人文件，不Git/PDF/spawn。

### 简版与精确D加权资源

原dP=2Λ dT 1_high κ δ Π_t(y,dv)Π_t(y,du)dlogt，δ=(k(v)−k(u))_+，0≤κ≤1。T_x(v)≥0须在整条aux clock上固定，原完整ν上∫T_xν≤q；可以依已冻结原outer/V/x而不能在t/u积分后免费重选。取常数H>0，首先在门T_x(v)e_t(y)≥Hq上有1/e_t≤T_x/(Hq)。只放大正门，u的完整Π积分使∫δΠ_u≤k(v)，再逐v用∫k(v)w_t(v)dlogt≤1，得固定x,y,hard-z内层≤1/H。这里没有ν≤β交换、坐标独立或负信用。

强化：令D_Z(x,y,v)=∫_{τ_j}^{g(x)}1_{Z_t(y)}(v)k_t(v)w_t(v)dlogt，空窗取0。D_Z静态于被积分的aux时刻；依x,y,v及原过程可测，无须与x选择器独立。0≤D_Z≤1来自drop-Z后的w单调FTC。D_Z=0的原正流在相应v上为零：原δ≤k，valid时e_t有限正，原J_far只取该窗子域，故非负积分为零。须先证明这个零流结论，再将R=T_x e_t/(qD_Z)在D_Z=0上置0，不能用未定义的0/0。

在D_Z>0上，乘R只消掉v槽的一个e_t，保持另一份完整Π_u。积分u与正门后有

`∫R κδ Π_vΠ_u dlogt ≤ (1/q)∫ T_x(v)ν(dv) [D_Z^{-1}∫valid 1Z k w dlogt] ≤1`。

因此真实原量满足 `∫R dP≤2Λ C0 X`，门R≥H的原正交通≤`2Λ C0 X/H`，C0=16/3。外回代顺序为：固定x,y,hard-z先获≤1；原hardband积分hard-z一次得C0q；同x原FIRST积分p_yβ≤q；原dT的外1/q抵消一次，所以结果C0q≤C0λ。实际完整receiver赢家唯一非零V且每个(x,V)唯一j，并保原receiver-leaf门，合计体积≤|E|，外原概率种子平均不另收费Λ。若V/x纤维不互斥、把source门投影成新Ω、或将不同q/H无价提出，不能沿用该系数。

### 与R226的关系及增量限制

原high给p_y e_g≥2Kq，t≤g时e_t≥e_g。故静态门 `T_x≥H p_y D_Z/(2K)`蕴含R≥H。同价对应R226参数r=H/(2K)，旧系数16Λ/(3Kr)=32Λ/(3H)=2ΛC0/H。对原terminal-good v∈Z_g，原Z递减还给D_Z=w_τ−w_g；此D_Z不是在该实际good槽里另获删除改进（R226已有限定）。

新门可依实际e_t而随clock扩大；这是同一正量上可证明的含旧门加权资源，不能仅凭包含便声称实际FULL新增正流非空、整个残余闭合或可在旧付款上再领一次εX。应作为同价替换/并入原已付支；若旧支保留，新增费用只在不交补域分配。简版D=1门也包含于D_Z门，因为D_Z≤1。

T_x若取某节点backward-soft核，必须另证该节点FIRST；本引理不授此资格。取原Q_x*或合法current/future目标核可用已有容量。H=2ΛC0/ε给该门εX，Λ及ε依赖必须保留。全global闭合仍需付R<H补域及所有原别的未付分支。

命题先行结论：在以上完整原资格下PASS；等待作者稿审查，不认证一般根阶结论。


### 跨V/j资格的独立原文核验

本轮收到跨V求和警示后，独立实读R107 integration.md:9–17、109–120，R226 boundary_payment.md:126–161与R237 source_ledger.md的SL1原出处表。R107原L_s(x),R(x)是整个E上的共同物理选择器；109明确Q_R(x)整体位于唯一叶、原y也在该叶，120明确每x至多一个非零叶行，后续硬来源子测度保固定J2。BP8继承实际receiver域E_{ω,V}⊂E∩V，再用不交叶与唯一j。因此本次2ΛC0X回代不含隐藏V重数。

必须将该原receiver-leaf门保留到逐V的hardcap与y-FIRST完成以后：不能把每V receiver域都正放为完整E再逐V用C0q并求和。若改用共同R(x)及ΣVνV≤f的sum-hardcolumn作另一证明，亦须逐项验证共同selector，不能将Σsup换成supΣ。此处采用已核原唯一叶路线，不新增归约。原hard帽更精确为4λ时可保安全上界8ΛX，但本轮所请求2ΛC0X较弱且成立；该数值常数改进本身不登记为新增支。

同时实读R226 BP7d：actual terminal-good源全程存活，D_Z=w_τ−w_g；新门与旧门关系只涉及实际e_t/terminal e_g等动态信息。一般删源域的D_Z≤D不是本actual-good槽的新扩大证据。


## 辅助稿TG3–TG7的条件校准审查

本轮合同现已完整实读，与独筛定义和原域限制一致。先收到test_geometry.md，已有限完整读稿并重点核TG3–7，不重审R224标量QG全证明。

窄读R224 traffic_reentry.md:174–185，原逐坐标ζ^−1 D_m sqrt(ω_m/ω_{ζm})≤ζ^−1/2 D_m确保TG3的加强；H_a须是含原1/√w_g、h_R及固定捕获域的half列。N_a近1给ζ^n≤(1−v)^−2、Δ_m≤−2log(1−v)/κ、Φ_a≥1−v。d_v<1时逐坐标ω_i≥1−d_v及logω_i≥−(1−ω_i)/(1−d_v)，再用w_g≥ζ^−n∏ω_i，得TG5方向及常数正确。

在原τ≤h≤g和t静态目标集上，et≥eg、wh≥wg使 ∫R_tk_t≤(wτ−wh)/wg≤a^−1−1；σ_Q总质量≤1只用一次。TG2用good给A_Q下界正确。独立窄读R116 integration.md:3，dT原总质量为T_small，保原门的当前子母测度≤该量；结合T_small≤4X、TG2的1/2及原2Λ，正得TG7的4Λ(a^−1−1)X。ε选择的−log a≤12v/κ和d_v≤1/2亦正确。三腿近unit事件的并集同享一个终端flatness下界，使用同一Q-FIRST一次不需额外3倍。

该校准只限固定物理参数的近unit列、static于aux时间的原目标集，未把固定列界升级为自适应receiver积分。它属于已知小weight-ratio情形，不作为新一般付款；不宣称FULL新增近unit正交通非空。TG3对捕获仅按原B=0或H0≥a资格保留，没有把lower-clamp补域或不同源槽免费统一。对主动态门的审查仍等residual_geometry作者稿。


## 作者稿及主稿终审

**PASS：原动态加权矩、Markov子交通付款及完整原来源回代成立。未认证一般根阶、R<H补域付款或FULL严格新增正流非空。** task_contract、residual_geometry、test_geometry、proof、report、driver均已读最终版本；作者RG6已移除未归档初探数值，仅引用正式套件。

residual RG1–3保原当前余权与原两Π，D_Z=0先由非负积分证明零正流，才置R=0；一般无限输入可对正分母/比值作非负截断而不交换signed极限。R可依x,y,v,t，但乘R后的T_x及整段D静态于同一clock，故FTC次序合法。无效时不捏造Π：先在有效时消一分母，再将正损失积分放宽至完整[τ,g]。动态门没有被当作固定source集合挪到FTC外。

RG7用target-FIRST后再y-FIRST、hardband及原receiver-leaf门，精确保留原4λ时得到8ΛX；主proof使用较保守2ΛC0X亦成立。一般多个V不能各自放到完整E后求和，已实核原R107唯一非零叶与BP8继承资格，作者/主稿均明确保持E_{ω,V}直至原回代完成。没有菜单、坐标独立化或额外source norm，也未重复hard帽。

RG8/9与R226比较正确：旧门在r=H/(2K)时包含于新门，实际阈值改善由high slack及e_t/e_g组成；在原terminal-good上D_Z=D，所以没有再登记删源支持改善。应用于已经删除旧支后的当前余权，或者作为旧支同价替换，不能对交集再领预算。RG11从good、动态补门、high三式得到e_t w_g/(e_gD)<H/2，方向正确；这只是补域真实约束，不是补域已付结论。

主proof所有实际x选择器、原q、真实dx、β、hardν、完整两个e_t、high与原RN/余权均保留；只在证明正上界时放门。H=2ΛC0/ε给所述门εX，作者较强H=8Λ/ε也可用，常数优化不作额外几何成果。原N_Z已耗、N_del连续反向交通及其他负项均未动用。

辅助TG最终已补τ≤h≤g及H_a含原1/√w_g的明确公式；其近unit→terminal-flatness的窄校准通过，三腿并集同用一份Q容量。它不升级固定参数QG为自适应receiver预算，也不作为另一份独立新付款。剩余真实test/degree相关费用保留。

## 数值、报告与复现边界

本人只静审最终numeric_checks.py/JSON/notes，未重复完整运行。源码在全部birth/delete节点精确分片，D用Fraction端点权差，不删除T=0源；D=0分支和完整Π归一化正确。无事件段e_t非增，动态门以精确两端degree分类，仅内根作普通高精度log-time二分，再分片积分；门等号/平段、5个内根及后删源范围均明列。静态门包含由程序保留的high标量和e_t≥e_g核实，但有限原子模型不授FIRST/cube/FULL身份。后删源是扩大代数类，不算原terminal-good删源增量。

读取原始JSON核计数：8例=2初探+4压力+2扩维，24个D槽、75个posterior中点、24组gate对照，与源码及notes一致；内置源码/合同SHA与实文件一致。AST语法检查两脚本通过。mp40/70最大差按max(1,|high|)归一为4.000896423e−41，不能称小值的相对误差或向外舍入区间认证；enc50不等于50位正确数字。普通求根bracket/残差亦只作诊断。正式计算由数值作者实际完成，完整包外JSON重放由主代理随后执行，本审核不提前冒称该回执通过。

report准确表述新门及旧支同价替换、旧费用保留、FULL严格非空未证和R<H未付。reproduce.py先验manifest，将最终脚本和合同复制到包外新目录，完整重算并逐字节比JSON，再验manifest；回执写包外，保留普通finite-clock/非FULL范围。此前轮次的临时诊断不混入本轮正式证据。

## 最终受审版本与冻结

| 文件 | SHA256 |
|---|---|
| task_contract.md | `bf56834aa6f119a2e5e3a157ca9f2d1ac05e8621a1d859ba18863203fe34fea3` |
| proof.tex.txt | `cbb77beeafd1c23f877f603e62650e20bc82105f886ac694e53f034e0cc537be` |
| residual_geometry.md | `28fffae9fc58202c746432b59ebebddbedcf9a4252bbeee4b31adc8b66bc523b` |
| test_geometry.md | `2039191d8137f298445893f38e5b2fbe502d91aa90cbfd833783867085134a95` |
| numeric_checks.py | `445b8646322ea956b6869218cfee03769502d1a4b2c2216757a394e27f742465` |
| numeric_checks.json | `93e57daa0da73c2513b377f9f1f4635b780b6b1c2a481a611bb34e0cbd07f11c` |
| numeric_notes.md | `cd1cf5144190058f807e87977b21552c3ea10e011ad7cc68eee9aaae05d851c0` |
| report.md | `f2f6189598fec80cca1f76f65d8312150080dc0d0b1e0b990b5363c9255b16d0` |
| reproduce.py | `83f0e7182d6bb74f4d30adc1e53deaca719549164174c8c101cfed9c158b3f5c` |

至此audit最终冻结并停止写入。该动态子交通付款通过；一般正L1弱型目标、动态补域及其他原未付支仍未闭合。
