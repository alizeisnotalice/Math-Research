# R225：实际混合核的尺度变差、硬责任与来源加权shell

**结论范围。** 本稿给完整核族的精确分布导数与对任意可测 `(s(x),L(x))` 的 signed selector 恒等式，保实际hard责任及显式shell。固定soft的光滑score有根阶平方均值，硬通量质量为 `n(1−s)`；不能把固定soft的中心化直接授予自适应soft积分。公共soft菜单提供完全一般的有价正包络，硬费用仍保留为原来源/接收权加权shell。最后把该shell接入R224 TR3的两个移动腿，保原Π、高门、score及Young费用。没有新的整个一般根阶付款，不重复已付固定J。

已读本轮task_contract及R224冻结traffic_reentry.md。只改本文件，不Git/PDF/spawn。

## SV1 核、真实责任与一个完整Fisher常数

令 `a=b/2>0`（只用于本稿核族下端），`h=1_[−1/2,1/2]`，`w(u)=∫_0^1 exp(−|u|/r)dr`，`φ=h*w`，`f_s=(1−s)h+sφ`，

\[
 P_{s,L}(u)=L^{-n}\prod_{i=1}^nf_s(u_i/L),\qquad a\le L\le b,\quad0\le s\le1.
\]

原实际尺度若只用更小子窗，本稿的包络仍有效，但不对新下端授予原FIRST资格。定义固定坐标u处的可测latent责任

\[
 R_s(u)=\frac{s\phi(u)}{f_s(u)},\qquad H_s(u)=\frac{(1-s)h(u)}{f_s(u)},\qquad
 Z_\phi(u)=-1-u\frac{\phi'(u)}{\phi(u)}. \tag{SV1}
\]

f_s=0处两个责任取0；其余处R_s+H_s=1。它们是该**核本身**的soft/hard条件概率，不是原来源ν或score坐标的独立性假设。置

\[
 T_s(u)=\sum_iR_s(u_i)Z_\phi(u_i),\quad
 \mathcal H_s(u)=\sum_iH_s(u_i),\quad Z_s=T_s-\mathcal H_s. \tag{SV2}
\]

原φ的scale Fisher量有自足显式界

\[
 I_\phi=\int Z_\phi(u)^2\phi(u)du\le\frac{805}{27}. \tag{SV3}
\]

**证明。** φ为偶C¹正密度，`φ'(u)=w(u+1/2)−w(u−1/2)`。在核心内 `φ≥φ(1/2)≥3/16`：用
`φ(1/2)=∫_0^1r(1−e^(−1/r))dr`，限制r∈[1/2,1]并用e≥2即可；且|φ′|≤1。所以|φ′/φ|≤16/3。对u≥1/2，令c=u−1/2≥0，

\[
 \phi(u)=\int_0^1r(1-e^{-1/r})e^{-c/r}dr,\quad
 |\phi'(u)|\le\int_0^1e^{-c/r}dr.
\]

Chebyshev正相关给 `∫r e^(−c/r)dr≥(1/2)∫e^(−c/r)dr`，因而φ≥`(1/4)∫e^(−c/r)`，尾部|φ′/φ|≤4。故全局16/3成立。Tonelli算得 `∫u²w(u)du=∫_0^14r³dr=1`，与均匀h卷积后 `∫u²φ=13/12`。尾部指数衰减使分部积分合法，`∫uφ′=−1`、`∫Zφ φ=0`，于是

\[
 I_\phi=-1+\int u^2\frac{\phi'(u)^2}{\phi(u)}du
 \le-1+\frac{256}{9}\frac{13}{12}=\frac{805}{27}.
\]

这里的乘积/独立计算仅属于给定概率核，不赋予原ν或Π任何坐标独立性。

## SV2 精确分布导数：centered smooth、negative hard bulk、positive faces

对每个固定s,L及平移v，有Radon测度恒等式

\[
 \partial_{\log L}[P_{s,L}(x-v)dx]
 =P_{s,L}(x-v)Z_s((x-v)/L)dx+\mathsf B_{s,L,v}(dx), \tag{SV4}
\]

其中真实正硬面通量为

\[
 \mathsf B_{s,L,v}=
 \frac{1-s}{2}\sum_{i=1}^n\sum_{\epsilon=\pm1}
 \delta_{v_i+\epsilon L/2}(dx_i)
 \prod_{k\ne i}L^{-1}f_s((x_k-v_k)/L)dx_k. \tag{SV5}
\]

**证明。** 一维hard dilation满足 `∂logL[h_L dx]=−h_Ldx+(δ_(−L/2)+δ_(L/2))/2`；光滑φ dilation密度导数为 `φ_L Zφ(x/L)`。按真实混合系数相加，再对乘积逐坐标微分即得SV4。等价的弱式可对任意C_c¹测试积分验证。SV4的bulk精确为 `P T_s−P mathcalH_s`，不可只保前项而忘记其内在负补偿。该负bulk是核自身导数，不是可调用的旧signed交通信用。

在固定乘积密度 `∏f_s` 下，

\[
 \mathbb E T_s=0,\quad\mathbb E T_s^2\le nsI_\phi,\quad
 \mathbb E\mathcal H_s=n(1-s),\quad
 \mathsf B_{s,L,v}(\mathbb R^n)=n(1-s). \tag{SV6}
\]

前两式因 `∫R_s Zφ f_s=s∫Zφφ=0`、`R_s²f_s≤sφ`；不同坐标在这个固定核下独立。

还可保更准确的centered full continuous score：若latent变量Y在hard分量取−1、在soft分量取Zφ，则条件期望 `E(Y|u)=R_s Zφ−H_s`。故

\[
 \mathbb E Z_s=-n(1-s),\qquad
 \operatorname{Var}(Z_s)\le n[sI_\phi+s(1-s)]. \tag{SV7}
\]

由 `E X_+=(E|X|+EX)/2` 与Cauchy，正continuous mass满足

\[
 \int P_{s,L}(u)[Z_s(u/L)]_+du\le\min\{D_n(s),\tfrac12\sqrt{nsI_\phi}\},\qquad
 D_n(s):=\frac{\sqrt{n^2(1-s)^2+n[sI_\phi+s(1-s)]}-n(1-s)}2. \tag{SV8}
\]

最后一个较简界直接用 `(T−mathcalH)_+≤T_+` 和SV6；不声称由SV7的粗latent方差必推出它。s<1时还可由有理化保 `D_n(s)≤s[Iφ+(1−s)]/[4(1−s)]`。固定s的正尺度费用因此至多 `n(1−s)+min(D_n(s),sqrt(nsIφ)/2)`，而不是把全部score都估为n。

## SV3 精确selected shell：不需要selector光滑性

令 `r_i=2|u_i|`。定义非负显式shell密度

\[
 \mathsf S_{s,A}(u)=(1-s)\sum_i
 1_{\{a<r_i\le A\}}r_i^{-n}\prod_{k\ne i}f_s(u_k/r_i),\qquad a\le A\le b. \tag{SV9}
\]

ri=0项按零；边界取原closed hard core约定，a处已计入基准P_s,a，故下端严格、上端闭合。对几乎处处u（不在不同坐标ri相等的零测集合），对**全部**s,A同时有

\[
 P_{s,A}(u)=P_{s,a}(u)+
 \int_a^A P_{s,\ell}(u)T_s(u/\ell)\frac{d\ell}{\ell}
 -\int_a^A P_{s,\ell}(u)\mathcal H_s(u/\ell)\frac{d\ell}{\ell}
 +\mathsf S_{s,A}(u). \tag{SV10}
\]

**证明。** 固定u后，`ell↦P_s,ell(u)`在有限个ri之间光滑；每个ri的hard跳为SV9对应项，符号为正。其余导数正是SV4的bulk。对各段FTC并加跳即可；相等ri例外是几何零集，不靠selector光滑性消除。也可从SV5积分dell/ell：`δ(u_i∓ell/2)dell`的Jacobian是2，得到 `(1−s)ri^−n`，不能漏此因子。全区间shell质量精确为

\[
 \int\mathsf S_{s,b}(u)du=n(1-s)\log2. \tag{SV11}
\]

现在允许**任意可测实际**s=s(x)、A=A(x)∈[a,b]。SV10仍逐receiver成立：把该点的终端s(x)沿辅助ell积分冻结即可，不是对空间selector求导。对于任意有限正Borel源ν，平移后ν×dx的坏集合由Fubini为零；可取共同满测集，使全部s,A同时成立（亦可先可数稠密参数、利用各分段公式延拓）。因此SV10可以按原ν(dv)及任何实际可测 `0≤χ(x,v)≤1` 加权后积分，保s(x)、A(x)与权在原值。

这给真正的来源加权恒等式

\[
 \mathcal C_{\chi,s,A}
 =\mathcal C_{base}+\mathcal C_{smooth}-\mathcal C_{hardbulk}+\mathcal C_{shell},\quad
 \mathcal C_{shell}=\int dx\int\nu(dv)\chi(x,v)\mathsf S_{s(x),A(x)}(x-v). \tag{SV12}
\]

各项由SV10相应积分定义。特别负hardbulk不能免费丢掉后又称“真实硬责任已小”。但固定s的SV6–8不能无价套到s(x)选择后的空间积分，也不能把ν、χ重新归一化作FIRST输入。

## SV4 完整核族的可测正包络及显式费用

对固定s定义

\[
 \mathsf E_s(u)=P_{s,a}(u)+\int_a^bP_{s,\ell}(u)[Z_s(u/\ell)]_+\frac{d\ell}{\ell}
 +\mathsf S_{s,b}(u).
\]

SV10给 `sup_A P_s,A≤E_s`，并且

\[
 \|\mathsf E_s\|_1\le1+(\log2)\,[d_n(s)+n(1-s)],\qquad
 d_n(s)=\min\{D_n(s),\tfrac12\sqrt{nsI_\phi}\}. \tag{SV13}
\]

使用R220已证公共soft菜单S_n（r表示节点，区别原阈值q）：
`P_s,L≤4Σ_(r∈S_n)P_r,L`，`N_n≤8+4√n log(n−1)` (n≥2)。这里一个密度是n个affine因子，可各重复成两个半次幂，恰满足其m≤2n合同。因此对任意实际s(x),A(x)、实际χ≤1与ν，

\[
 \boxed{\mathcal C_{\chi,s,A}
 \le C_{sm}(n)\|\nu\|+\mathfrak B_\chi,\quad
 C_{sm}(n)=4\sum_{r\in S_n}[1+(\log2)d_n(r)],\quad
 \mathfrak B_\chi=4\sum_{r\in S_n}\int dx\int\nu(dv)\chi(x,v)\mathsf S_{r,b}(x-v).} \tag{SV14}
\]

receiver域可放在χ中。这个正包络是一般核族定理，不要求特殊输入或selector正则性。粗但完整的量级为
`C_sm≤4N_n[1+(log2)sqrt(nIφ)/2]=O(n log(n+1))`，以及
`Bχ≤4n(log2)Σ_r(1−r)||ν||≤4nN_n log2 ||ν||`；不把这些大于root的费用叫无害。更精确、可供原geometry使用的剩余就是SV14的**实际χ加权shell**，没有将它立即换成全部n硬费。SV12还可用于保留shell与hardbulk的内在补偿，而非仅看正shell。

全部signed源积分可先有限截断。其一般可积性也有具体保证：`P_s,ell R_s|Zφ|`、`P_s,ell H_s`及SV9逐项均是非负affine乘积，可用同一有限soft菜单作绝对上放，积分至多有限的 `O(n N_n(1+sqrt(Iφ)))||ν||`。因此SV12不是未定义的∞−∞；这只证明可积，不赋予根阶价。

## SV5 接回原allocated移动腿：保score的真实source权

本节a=1,2只表示R224两条移动腿（核下端仍为b/2）：`K_{a,x}(v)=P_{s(x),A_a(x)}(x−v)`，其中A1=L，A2=min(b,γL)，均在[b/2,b]。只处理原可测分配λ_a对应的正子交通及终端带T_d；已付λ_J部分不重复。R222真实η已付hard帽一次，不能再用hard核定理。

固定实际x,j,V,t，设

\[
 r_t(x,y,v)=\int\Pi_{y,t}(du)\,\eta(x,y,v,u,t)\frac{\delta_t(v,u)}n,\qquad0\le r_t\le1_{high,valid},
\]

\[
 \chi_t(x,v)=2K\int\beta_V(dy)\frac{1_{Z_t}(v)}{e_t(y)}r_t(x,y,v),\qquad0\le\chi_t\le1. \tag{SV15}
\]

无效行置零，不在e_t=0处除法。后一个界来自原同x的 `∫high β/e_t≤1/(2K)`。真实δ/n、两Π、capture/FA/history都在这个可测χ中，没有假设source坐标独立。原J_far和过程合法时钟若依y，也全部在r_t及χ_t中置零；以下外层时间区间只用依x的共同终端窗。

重复TR3的**加权**Cauchy（第一平方因子≤∫pβ≤q，第二平方因子恰含χ_t）给

\[
 \int\beta_V(dy)\int\Pi_{y,t}(dv)\,r_t
 \sqrt{\frac{p_yK_{a,x}(v)}{w_t(y,v)}}
 \le\sqrt{\frac q{2K}\int K_{a,x}(v)\chi_t(x,v)\nu_V(dv)}. \tag{SV16}
\]

令共同终端窗 `I_d(x)=[g(x)e^(−d/n),g(x)]`；实际T_d是其与原合法clock的交，后者已在χ_t置零。在I_d上，`wt/wg≤e^d`。将n仅作为δ/n的恢复系数，再对实际time、receiver、不交叶和种子同时作Cauchy；原j保到同x唯一后才合并。定义

\[
 \overline\chi_d(x,v)=\frac nd\int_{I_d(x)}\chi_t(x,v)\frac{dt}{t}\in[0,1],\quad
 \mathcal C_{a,d}=\mathbb E\sum_V\int_{E_{\omega,V}}dx\int\nu_V(dv)
 \overline\chi_d(x,v)K_{a,x}(v).
\]

则真实原allocated正子交通满足

\[
 \boxed{P^{alloc}_{a}(T_d)\le\frac{32\Lambda}{3\sqrt6}d e^{d/2}\sqrt{X\mathcal C_{a,d}}
 \le\varepsilon X+\frac{128\Lambda^2}{27\varepsilon}d^2e^d\mathcal C_{a,d}.} \tag{SV17}
\]

这里Wν没有被Wβ代替。C_{a,d}并非任意未知Schur常数：它的原真实权由SV15明确给出，SV12给exact boundary-minus-bulk selector身份，SV14进一步给全族显式上界

\[
 \mathcal C_{a,d}\le C_{sm}(n)W_\nu+
 4\mathbb E\sum_V\sum_{r\in S_n}\int_{E_{\omega,V}}dx\int\nu_V(dv)
 \overline\chi_d(x,v)\mathsf S_{r,b}(x-v). \tag{SV18}
\]

这正是需由high/FIRST/capture共同geometry控制的硬shell占用，边界尺度为`2|x_i−v_i|`，每个来源/接收权都仍可见。不能把auxiliary ell上的shell边界误当实际receiver参数A(x)的面，不能给节点kernel重算原χ，不能让SV8的固定soft中心化免费跨adaptive s。SV18在全族最坏上放后不达一般root；SV17的Young费用线性乘列价，不能再把其平方根称最后来源价。

## SV6 已证结果与停止点

已证：完整mixed核的责任分解、centered smooth及hard faces的正确分布量纲；任意可测selector的exact signed shell−bulk身份；包含实际source/receiver权的全族正包络；与原两Π/TR3的加权移动腿回代。未证：SV18实际shell与negative hardbulk的联合occupation为root，以及两移动腿一般来源总付款。本文不把固定s near1估计或任何特殊输入当最终成果，不再重复J付款或原负信用。

**实际工具核验。** 本机vendored mpmath1.3.0以25/40位对|u|≤64计算Iφ，使用`φ(u)=1−E3(1/2−u)−E3(1/2+u)`(0≤u≤1/2)、`φ(u)=E3(u−1/2)−E3(u+1/2)`(u≥1/2)，`φ′=E2(u+1/2)−E2(|u−1/2|)`。两次返回
`0.990165089539183653258653`、`0.9901650895391836532586530213921689752116`。
尾部严格解析上界为 `exp(1/2−64)[(1+4·64)²+8(1+4·64)+32]`，其普通高精度显示约`1.8017038528783934e−23`；求积未有向舍入，故这些只是有限计算证据，严格可用常数仍为805/27。另用Python Fraction实际完成75项责任/latent矩与方差断言、16组hard-only shell FTC恒等式，以及805/27和Young系数128/27的精确有理核验，全部通过；不认证FULL/history或一般source预算。
