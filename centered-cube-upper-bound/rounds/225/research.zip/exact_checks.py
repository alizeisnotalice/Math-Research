#!/usr/bin/env python3
"""Finite exact algebra checks only; not a general budget certificate."""
from fractions import Fraction as F
from math import comb
from pathlib import Path
import argparse,json

def run():
    cn=[]
    for n in (1,2,4,8,16,32,64):
        c=sum((F(comb(n,k))*F(k,n)**k*F(n-k,n)**(n-k) for k in range(n+1)),F(0))
        assert (c-2)**2<=16*n
        cn.append({'n':n,'C_n_exact':str(c),'display_float':float(c),'finite_check_C_n_le_2_plus_4sqrt_n':True})
    identities=[]
    for n in (1,2,3,4,8,16):
      for rho in (F(1,2),F(1),F(5,4),F(3,2),F(7,4),F(2),F(5,2)):
       for A in (F(1),F(9,8),F(5,4),F(3,2),F(7,4),F(2)):
        a=F(1);base=a**(-n) if rho<=a else F(0)
        shell=rho**(-n) if a<rho<=A else F(0)
        bulk=max(a,rho)**(-n)-A**(-n) if max(a,rho)<A else F(0)
        target=A**(-n) if rho<=A else F(0)
        assert base+shell-bulk==target
        identities.append({'n':n,'rho':str(rho),'A':str(A),'base':str(base),'selected_shell':str(shell),'bulk':str(bulk),'target':str(target)})
    # Factor Lambda^2*K*d*exp(d)/epsilon omitted on both sides.
    young=(F(32,3)**2/F(3))*F(2,4)
    assert young==F(512,27)
    assert -1+F(256,9)*F(13,12)==F(805,27)
    return {'complete':True,'C_n':cn,'hard_unique_face_selector_identities':identities,'young_factor':str(young),'analytic_Fisher_constant_arithmetic':'805/27','scope':'252 exact hard single-face selector and coefficient checks; no general soft selector, source geometry, or root budget certification.'}
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();a.output.write_text(json.dumps(run(),indent=2)+'\n')
