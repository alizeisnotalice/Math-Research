#!/usr/bin/env python3
"""Frozen-package verification and relocated full numerical replay; no PDF."""
import argparse,hashlib,json,os,shutil,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
DEFAULT_VENDOR=Path('/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def verify():
    hashes=json.loads((ROOT/'manifest.json').read_text())
    for name,h in hashes.items():assert digest(ROOT/name)==h,name
    return len(hashes)
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--verify-only',action='store_true');ap.add_argument('--output-dir',type=Path);ap.add_argument('--mpmath-path',type=Path);args=ap.parse_args();count=verify()
    if args.verify_only:print('verified',count,'manifest hashes');return
    if args.output_dir is None:ap.error('--output-dir required')
    out=args.output_dir.resolve()
    if out==ROOT or ROOT in out.parents:ap.error('output must be outside package')
    env=os.environ.copy();vendor=args.mpmath_path or (DEFAULT_VENDOR if DEFAULT_VENDOR.is_dir() else None)
    if vendor:env['PYTHONPATH']=str(vendor)+(os.pathsep+env['PYTHONPATH'] if env.get('PYTHONPATH') else '')
    subprocess.run([sys.executable,'-c','import mpmath; assert mpmath.__version__ == "1.3.0"'],env=env,check=True)
    out.mkdir(parents=True,exist_ok=False);runs=[]
    for stem in ('numeric_probe','exact_checks'):
        shutil.copyfile(ROOT/(stem+'.py'),out/(stem+'.py'))
        start=time.monotonic();subprocess.run([sys.executable,str(out/(stem+'.py')),'--output',str(out/(stem+'.json'))],env=env,check=True)
        assert (out/(stem+'.json')).read_bytes()==(ROOT/(stem+'.json')).read_bytes(),stem+' entire JSON differs'
        runs.append({'driver':stem+'.py','entire_json_byte_identical':True,'json_sha256':digest(out/(stem+'.json')),'elapsed_seconds':time.monotonic()-start})
    assert verify()==count
    receipt={'complete_replay':True,'manifest_hashes_before_and_after':count,'runs':runs,'python':sys.executable,'mpmath_path':str(vendor) if vendor else None,'scope':'Floating quadrature and finite seeded simulation replay; no interval certificate or general adaptive-column payment.'}
    (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
if __name__=='__main__':main()
