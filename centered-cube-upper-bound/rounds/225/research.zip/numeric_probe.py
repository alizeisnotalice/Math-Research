#!/usr/bin/env python3
"""R225 real phi scale-score quadrature and bounded seeded simulation; no order claim."""
import argparse,hashlib,json,math,random
from pathlib import Path
import mpmath as mp
HERE=Path(__file__).resolve().parent
CONTRACT_SHA256='ff01f629fd9a557abb4f1ebd5fb4e08776915267821e72f8df4baf5b2c9fe1ee'
def phi_derivative(x):
    x=abs(mp.mpf(x));h=mp.mpf('.5')
    def E23(t):
      if t==0:return mp.mpf(1),mp.mpf('.5')
      e=mp.exp(-t);e1=mp.e1(t);return e-t*e1,((1-t)*e+t*t*e1)/2
    if x<=h:
      el2,el3=E23(h-x);er2,er3=E23(h+x);return 1-el3-er3,er2-el2
    el2,el3=E23(x-h);er2,er3=E23(x+h);return el3-er3,er2-el2

def score(x):
    x=abs(mp.mpf(x));f,df=phi_derivative(x);return -1-x*df/f

def quadrature(window,dps,degree):
  with mp.workdps(dps):
    Z=mp.mpf(window);nodes,weights=mp.gauss_quadrature(degree,'legendre');cuts=[mp.mpf(0),mp.mpf('.5'),Z]+[mp.mpf(k) for k in (1,2,4,8,16,32,64) if k<window]
    edge_k=(2,4,8) if degree>=96 else ()
    if degree>=192:edge_k=(2,4,8,12,16,20)
    cuts=sorted(set(cuts+[mp.mpf('.5')+sg*mp.mpf(2)**(-k) for k in edge_k for sg in (-1,1)]));sums=[mp.mpf(0)]*3
    for lo,hi in zip(cuts,cuts[1:]):
      mid=(lo+hi)/2;half=(hi-lo)/2
      for q,w in zip(nodes,weights):
        x=mid+half*q;f,df=phi_derivative(x);z=-1-x*df/f;wt=2*half*w
        for j,v in enumerate((f,f*z,f*z*z)):sums[j]+=wt*v
    mass_tail=2*(mp.expint(4,Z-mp.mpf('.5'))-mp.expint(4,Z+mp.mpf('.5')));fZ,_=phi_derivative(Z);mean_tail=2*Z*fZ;c=mp.mpf(3)/16*(1-mp.exp(-1));a=mp.mpf(2)/3
    second_tail=4*mp.exp(mp.mpf('.5')-Z)+4/c*mp.exp(mp.mpf(1)/3-a*Z)*(Z*Z/a+2*Z/(a*a)+2/(a*a*a))
    vals={'mass_finite':sums[0],'mass_tail_exact_formula':mass_tail,'mass_plus_tail':sums[0]+mass_tail,'mass_normalization_abs_residual':abs(sums[0]+mass_tail-1),'mean_Z_finite':sums[1],'first_score_tail_exact_formula':mean_tail,'mean_Z_plus_tail':sums[1]+mean_tail,'I_second_moment_finite':sums[2],'I_analytic_omitted_tail_upper':second_tail,'I_finite_plus_analytic_tail_upper_ordinary_eval':sums[2]+second_tail,'tail_lower_phi_constant_c':c}
    return {'window':window,'dps':dps,'degree':degree,'nonnegative_halfline_cuts':[mp.nstr(x,dps) for x in cuts],'values':{k:mp.nstr(v,dps) for k,v in vals.items()},'tail_status':'Analytic formulas/bounds evaluated in ordinary mp arithmetic; quadrature is not interval-enclosed.'}

def simulate(paths,seed=2252026):
    ns=(1,2,4,8,16,32,64,128);means={n:0.0 for n in ns};M2={n:0.0 for n in ns};rng=random.Random(seed)
    with mp.workdps(20):
      for path in range(1,paths+1):
        total=0.0
        for i in range(1,129):
          r=math.sqrt(rng.random());magnitude=-r*math.log(1-rng.random());sign=-1 if rng.random()<.5 else 1;x=rng.random()-.5+sign*magnitude
          total+=float(score(x))
          if i in means:
            v=abs(total);delta=v-means[i];means[i]+=delta/path;M2[i]+=delta*(v-means[i])
    rows=[{'n':n,'sample_E_abs_sum_Z':means[n],'sample_standard_deviation_abs_sum':math.sqrt(M2[n]/(paths-1)),'Monte_Carlo_standard_error':math.sqrt(M2[n]/(paths-1)/paths)} for n in ns]
    return {'paths':paths,'max_dimension':128,'seed':seed,'coordinate_score_dps':20,'score_evaluation':'Direct mp E1/E2/E3 evaluation for every sampled coordinate; no lookup/interpolation','phi_sampling':'X=Uniform[-.5,.5]+sign*R*(-log U), R=sqrt(U0), independent sign; R density 2r gives w','floating_point_generator':'Python random.Random(seed), math.sqrt/log and finite floating-point accumulation','prefix_dependence':'For a path, all dimensions share their initial n coordinates; paths are independent PRNG draws.','results':rows,'scope':'Finite Monte Carlo evidence with sampling standard errors; no fitted order or certified probabilistic bound.'}

def main(output):
    stages=[]
    for name,window,dps,degree,paths in [('basic',24,25,48,512),('edge_tail_pressure',48,35,96,1024),('expanded_refined',96,50,192,4096)]:
      q=quadrature(window,dps,degree);sim=simulate(paths);stages.append({'stage':name,'quadrature':q,'simulation':sim});print(name,'paths',paths,'I',q['values']['I_second_moment_finite'],flush=True)
    with mp.workdps(60):
      comparisons=[{'stage':st['stage'],'mass_abs_difference_from_final':mp.nstr(abs(mp.mpf(st['quadrature']['values']['mass_finite'])-mp.mpf(stages[-1]['quadrature']['values']['mass_finite'])),50),'I_abs_difference_from_final':mp.nstr(abs(mp.mpf(st['quadrature']['values']['I_second_moment_finite'])-mp.mpf(stages[-1]['quadrature']['values']['I_second_moment_finite'])),50)} for st in stages[:-1]]
      xs=[mp.mpf('.5')]+[mp.mpf('.5')+sg*mp.mpf(10)**(-k) for k in (2,4,8) for sg in (-1,1)]+[mp.mpf(k) for k in (0,1,2,4,8,16,32,64,96)];edges=[]
      for x in sorted(set(xs)):
        f,df=phi_derivative(x);edges.append({'abs_x':mp.nstr(x,50),'phi':mp.nstr(f,50),'phi_derivative_on_positive_halfline':mp.nstr(df,50),'Z':mp.nstr(-1-x*df/f,50)})
      hard=[{'n':n,'exact_formula':'1+n*log(2)','ordinary_mp_value':mp.nstr(1+n*mp.log(2),50)} for n in (1,2,4,8,16,32,64,128)]
    result={'schema':'R225_real_phi_scale_score_probe_v1','complete':True,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'contract_sha256':CONTRACT_SHA256,'mpmath_version':mp.__version__,'score_definition':'Z=-1-x*phi_prime/phi','analytic_background':['phi=h*w, w=int_0^1 exp(-abs(x)/r) dr, integral phi=1','Integration by parts gives E_phi Z=0 when the stated exponential tails are retained','For x>=1, phi>=c exp(-4(x-.5)/3), abs(phi_prime)<=exp(-(x-.5)), c=3(1-exp(-1))/16','Thus phi*Z^2<=2exp(-(x-.5))+2x^2/c*exp(-2(x-.5)/3), giving the displayed finite second-moment tail bound','Hard-limit scale column has exact expression 1+n log2'],'stages':stages,'quadrature_refinement_comparisons':comparisons,'edge_and_tail_values':edges,'hard_limit_columns':hard,'scope':['Actual local phi and score evaluated by local Python/mpmath; no new dependencies.','Ordinary quadrature with analytic omitted-tail formulas/bounds, not directed interval certificates.','Seeded simulations are finite evidence; no dimension-order fit, global asymptotic claim or adaptive-column payment.','Original moving-leg source/receiver/clock qualifications and selector costs are not certified by this one-coordinate probe.','No original FULL closure or general theorem inferred from Monte Carlo.']}
    output.write_text(json.dumps(result,indent=2)+'\n')
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=HERE/'numeric_probe.json');args=ap.parse_args();main(args.output)
