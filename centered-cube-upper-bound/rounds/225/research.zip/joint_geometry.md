# R225：移动目标腿的共同来源占用与尚未闭合的尺度面预算

**状态：本稿没有得到新的根阶付款。** 给出一条保留实际共同来源权的整体 Cauchy 估计、准确候选以及可验证的有价回退。候选所需的几何预算未证；不将下列占用量改名后视作已经控制。R224 全尺度 QG 与已经支付的终端带 J 分量保持原账。

只读本轮合同及 R224 冻结的 `threshold_gap.md`、`traffic_reentry.md`。所有符号、正门和共同 q 沿 TR1–TR6；特别两目标腿是实际 `K1=P_s,L`、`K2=P_s,min(b,γL)`，没有换成独立固定列。

## 1. 首先筛选的准确命题

固定 n≥2、d=(log n)/2，并保原终端带

\[
T_d(x)=\{g(x)e^{-d/n}\le t\le g(x)\}\cap J_{far}(x,y).
\]

在积分书写中用与 y 无关的闭带承载时钟，把原 `J_far`、有效 heavy、high、唯一 j、终端 good/bad、capture/history、当前浮动补域及其他正门保在实际 η 或有效域内。无效行均置零，不在原过程外定义新后验。写

\[
F_{a,d}=\mathbb E\sum_{V,j}\int_{E_{\omega,V}}\!dx\int\beta_V(dy)
 \int_{T_d(x)}\iint
 \eta\delta_t\sqrt{\frac{p_y(x)K_{a,x}(v)}{w_t(y,v)}}
 d\Pi_t(v)d\Pi_t(u)\frac{dt}{t},\quad a=1,2.
\tag{JG1}
\]

仍显式保 `j=j(x)`。定义同一个真实占用权

\[
\Omega_d(x,v)=\int_{T_d(x)}\int
 \frac{1_{\rm high,valid}\,1_{Z_t}(v)}{e_t(y)}\beta_V(dy)
 \int\eta(x,y,v,u,t)\delta_t(v,u)d\Pi_t(u)\frac{dt}{t},
\tag{JG2}
\]

以及

\[
B_d=\mathbb E\sum_V\int_{E_{\omega,V}}\int
 [K_{1,x}(v)+K_{2,x}(v)]\Omega_d(x,v)\nu_V(dv)dx.
\tag{JG3}
\]

这里 `V,j` 在 Ω 中始终是 x 的实际标签；η 对实际完整行取值，不在新核参数上重算。

**待证几何命题。** 存在绝对 C 和固定 B<∞，对每个原合法输入及有限正交通截断，一致有

\[
\boxed{B_d\le\frac{C d}{K}\log^B(n+2)W_\nu.}
\tag{JG4，未证}
\]

它只要求当前完整终端带中的两条移动腿，不要求额外窄软度、窄物理尺度或预选接收 patch；包括 R=b。Ω 不是可任意选择的有界函数，其与同一实际 p、β、Π、score 和 η 的关系是命题核心。下文证明 JG4 足以带来真正的新增原正子交通付款，但本稿没有证明 JG4。

## 2. 已证：一次整体 Cauchy 保住实际来源占用

在有限非负截断上展开一份原 Π_t(v)。JG1 的密度为

\[
\eta\delta_t1_{Z_t}(v)\,
\frac{\sqrt{p_y(x)w_t(y,v)K_{a,x}(v)}}{e_t(y)}.
\]

把它分成

\[
\sqrt{\eta\delta_t1_{Z_t}(v)\,p_yw_t/e_t}
\;\sqrt{\eta\delta_t1_{Z_t}(v)\,K_{a,x}(v)/e_t}.
\]

对包括真实 x、种子、原 β⊗ν、另一份 Π_t(u) 和时钟的**同一底测度**作 Cauchy。没有独立化两个后验。第一平方因子为

\[
A_d=\mathbb E\sum_{V,j}\int_{E_{\omega,V}}dx\int p_y\beta_V(dy)
 \int_{T_d(x)}\iint\eta\delta_t\,d\Pi_t(v)d\Pi_t(u)\frac{dt}{t}.
\]

只在这里用 η≤1、δ≤n、时钟长度≤d/n、两份有效 Π 的概率归一及同一 x 的 FIRST，得到

\[
A_d\le d q\,\mathbb E\sum_V|E_{\omega,V}|\le dX.
\tag{JG5}
\]

第二平方因子恰为 JG3 的第 a 腿，记 B_(a,d)。两腿共用 A_d、Ω_d；故

\[
F_{1,d}+F_{2,d}
\le\sqrt{A_d}\left(\sqrt{B_{1,d}}+\sqrt{B_{2,d}}\right)
\le\boxed{\sqrt{2dX B_d}}.
\tag{JG6}
\]

无限正量由非负截断极限处理。唯一叶保证接收体积仅计一次；唯一 j 保留至实际时钟估计结束。没有使用 ν≤β、源独立或固定移动列。

## 3. Ω 中保留的 FIRST 共同来源权

原 high 给 `p_y e_g≥2Kq`，且有效 t≤g 时 e_t≥e_g。在合法 high 行设

\[
h_t(x,y)=\frac{2Kq}{p_y(x)e_t(y)}\in[0,1],
\]

其余行置零。p=0 不会成为非零 high 行。JG2 可以准确写成

\[
\boxed{
\Omega_d(x,v)=\frac1{2K}\int_{T_d(x)}\int
 \frac{p_y(x)\beta_V(dy)}q\,h_t(x,y)1_{Z_t}(v)
 \int\eta\delta_t\,d\Pi_t(u)\frac{dt}{t}.}
\tag{JG7}
\]

因此软来源不是一个独立可重选的“概率赢家”：`p_yβ/q` 是同一实际接收点、同一实际 L(x),s(x) 下的次概率来源分布。h_t、η、score 和另一个后验仍在其内部。JG7 是可以放入实际尺度面比较的真实权，而不是额外来源假设。

粗略删除这些关系，仅用 TR2，就有

\[
0\le\Omega_d(x,v)\le\frac d{2K}.
\tag{JG8}
\]

但 JG8 本身不推出 JG4。它允许把移动列的全部物理尺度面质量分别取最坏值，正是下一节的维数损失来源。

## 4. 成功时的原付款及当前可证回退价格

R224 TR4 给带内 `w_t/w_g≤e^d`。因此原两腿上界满足

\[
U_1(T_d)+U_2(T_d)
\le C_0e^{d/2}(F_{1,d}+F_{2,d}),\qquad
C_0=\frac{32\Lambda}{3}\sqrt{K/3}.
\tag{JG9}
\]

若 JG4 成立，JG6–9 就给

\[
U_1(T_d)+U_2(T_d)
\le\frac{32\Lambda}{3}\sqrt{2C/3}\,
 d e^{d/2}\log^{B/2}(n+2)\sqrt{XW_\nu}.
\]

Young 后，来源价为

\[
\varepsilon X+
\frac{512C\Lambda^2}{27\varepsilon}
 d^2e^d\log^B(n+2)W_\nu
=\varepsilon X+O_\varepsilon(\sqrt n\log^{B+2}(n+2))W_\nu.
\tag{JG10，条件结论}
\]

借原 TR1a 可测分配，这会支付终端带中两条移动腿对应的真实原正子交通，与 R224 已付的 J 分量互补；不会给三腿复制负信用。更早时钟仍另列。当前 JG4 未证，所以 JG10 不登记为已付款。

为量化本次直接放松究竟损失多少，以下给无条件的有价回退。令

\[
C_n=\sum_{k=0}^n\binom nk(k/n)^k(1-k/n)^{n-k},
\quad D_n=C_n[1+n\log(b/a)]\le C_n(1+n\log2),
\tag{JG11}
\]

端点按 0^0=1。全软度、全物理尺度的目标核有

\[
\int_{\mathbb R^n}\sup_{s\in[0,1],\,L\in[a,b]}P_{s,L}(x-v)dx\le D_n.
\tag{JG12}
\]

证明只需两个可直接核验的步骤。第一，把 n 个一维 `(1−s)h+sφ` 展开，按软坐标数 k 分组。每组的空间积分为 binom(n,k)，对应系数 `s^k(1−s)^(n-k)` 的最大值在 s=k/n。这一步完整保留所有中间软度，不仅是两个 soft 端点。

第二，对每一组非负核 Q，沿同一径向缩放有 `Q(x/L)` 随 L 不减。令 F_L=L^−n Q(x/L)，则其分布导数为

\[
dF_L=-nF_L\,d\log L+L^{-n}d[Q(x/L)].
\]

后一项非负；对真实 x 积分，其总质量恰为 `n||Q||_1 dlogL`，因为每个 F_L 的总质量不随 L 变。保初始项并只取该正项给 `∫sup_L F_L≤[1+nlog(b/a)]||Q||_1`。这包含 hard 跳面，未假设 L→P 光滑。对所有 k 求和即 JG12。

可用粗统一界 `C_n≤2+π√n`。一个自足核验方法：内项是 Bin(n,p) 在 k=np 的点概率；傅里叶反演、`sin(|t|/2)≥|t|/π` 和高斯积分给它≤`1/√(np(1-p))=√n/√(k(n-k))`。函数 `1/√(x(n-x))` 凸，中点积分比较给内部整数和≤其在(0,n)的积分π。两个端点各为1。于是 D_n=O(n^(3/2))，这里不是免费菜单常数。

将 JG8、JG12 用于两条实际移动腿，只能得到

\[
B_d\le\frac{dD_n}{K}W_\nu,
\qquad
U_1(T_d)+U_2(T_d)
\le\frac{64\Lambda}{3\sqrt6}\,
 d e^{d/2}\sqrt{D_nXW_\nu}.
\tag{JG13}
\]

其 Young 来源价为

\[
\varepsilon X+\frac{512\Lambda^2}{27\varepsilon}d^2e^dD_nW_\nu.
\tag{JG14}
\]

取 d=(log n)/2 后为 O_ε(n²log²n)W_ν，远未达到目标。这是失败标尺，不是新增有用付款，也不意味着 JG4 必假。

## 5. 最早尚缺的共同几何步骤

JG7指出需要保留的来源权。应用实际尺度的分布导数时，不能先把它换成上界 d/(2K)，然后分别付“软度菜单 × n 个尺度面”；这样正好得到 JG13。需要让同一个 `p_yβ/q`、阈值 score、history/捕获资格作用于被实际 L(x) 选中的边界与负 bulk，控制其净来源质量。

父级与同轮辅助稿正在使用完整 soft 家族的分解：`∂log L P=P(T−H)dx+B`，其中 H 是 posterior hard responsibility，T 是中心化 soft score，B 是真实 hard 面。该分解可在每个 x 冻结实际 s(x) 后沿辅助物理尺度积分，但对 x 自适应的 s 或 JG7 来源权，不能直接沿用无权核下的中心化。特别是本稿 JG7 的 p_y 仍为当前实际 L(x),s(x)；若用候选中间尺度 ℓ 的 p_y 取代它，就更换了来源分布，必须另付 Radon–Nikodym 或变化费用。

因此精确的未证桥是：对 JG3 中由真实 Ω_d 加权、由实际 L(x) 或 min(b,γL(x)) 选中的 hard 面减 bulk，保留 JG7 的共同来源关系后证明 JG4 的全局质量预算。现有 FIRST 次概率帽与 QG 固定参数积分没有授予这个比较。

QG可在原带 h_R 的共同核上使用，但不能回贴到本稿已经消去 h_R 的 JG1–3 而再领取一次硬来源帽；它也不是选中面上的逐点界。共同中心 k=0 的直觉只解释某些高包络不产生交通，未控制稀疏分离时许多未计数坐标的尺度面。因此本稿没有假定一个任意 pairwise selector 包络，也没有用特殊 hard 家族替代全部 soft 原量。

## 6. 实际本机核验与交付范围

实际运行本机 Python fractions.Fraction，精确计算 JG11 的 C_n，n=1,2,4,8,16,32,64；得到约 2、2.5、3.21875、4.24501800537、5.70425824707、7.77404547667、10.7057812508。另用64个有理等距尺度 L_j=1+j/64，精确计算 hard 核菜单列 `1+Σ_j[1−(L_(j−1)/L_j)^n]`，与解析 `1+nlog2` 比较均通过。前一计算是精确有理数，所列小数仅展示；涉及 log 的检查为浮点一致性测试。一般 JG12 的证明是上述分布导数与核质量论证，不依赖这些有限数值。

最终交付是 JG6–8 的真实共同来源接口、明确未证的 JG4、以及 JG13–14 的完整有价回退。本轮不将接口或回退价格登记为新增 root 付款；原一般目标仍未闭合。
