# R225 独立审查

## 作者稿前独立筛查

已读本轮 task_contract.md 与 R224 冻结 traffic_reentry.md 全文；不重审R224定理，不先读本轮作者稿。当前一般 n^(1/2+o(1)) 一致弱型仍未闭合。以下是新移动目标列/尺度score付款必须满足的条件，不预认新估计成立。

### 1. 正确目标和同点Cauchy后真正缺少的列

实际目标为 K1,x(v)=P_s(x),L(x)(x−v)、K2,x(v)=P_s(x),min(b,γL(x))(x−v)，物理参数依真实receiver x；目标列不依辅助 y，而 p_y、Π_y,t、e_t、high 均依同一y。允许沿R224 TR3在固定同一x,t展开一份Π并Cauchy，得到

    ∫high β(dy)∫Π_y,t(dv) √[p_y K_a,x(v)/w_t(y,v)]
      ≤√[q M_aν(x)/(2K)],
    M_aν(x)=∫K_a,x(v)ν(dv)。

此步保原 et 与 Z_t、无效过程置零；u的另一份完整Π只可在非负上放后归一。它不需要移动参数关于x归一，却也没有替最后的真实列 ∫_E M_aν(x)dx 付款。每个固定(L,s)的∫P_s,L dx=1不能代替实际选择列。ν≤β、把βΠ²拆成独立后验、把全来源缩成Z_g都不可用。

一个充分而非必要的候选接口是：对原不交实际 E_{ω,Vj} 和原自适应选择证明

    EΣV,j ∫E_{ω,Vj} M_aνV(x)dx ≤ A_n Wν。

也可证明保η、δ、两Π的更强联合界以绕过独立最坏列；但须给实际完整回代，而非只给某个新identity。对每个v控制合法共同包络的∫dx≤A_n再Tonelli可提供上述列；只给行界、固定θ列或以其它e(y)dy替代真实dx都不够。唯一V、唯一j须保到右端独立该标签才求和，原接收域E不能在删η/aω后扩成新hardgood点。

### 2. 费用如何回到原正量

若上面移动列接口确已证明，R224同一终端带 T_d={g e^(−d/n)≤t≤g}∩原clock 上可直接沿同点Cauchy、δ≤n及带宽d/n，得到每条原good三腿分配的条件费用

    P[λ_a 1_Td] ≤ C_J d e^(d/2)√(A_n X Wν),
    C_J=32Λ/(3√6),
    ≤ εX+[128Λ²/(27ε)] A_n d²e^d Wν。

λ_a=√Ka/(√K1+√K2+√J)是原正量上的可测分配；新付款应明确原branch及其精确补权。R224已付 λJ1_Td 不重领，R218旧浮动带不重领。若改用当前严格浮动补域的两腿化 good系数√(K/2)，则相对上式前因子乘√(3/2)，Young来源价乘3/2，即64Λ²/(9ε)·A_n d²e^d；两种路不可对同一份原正量重复收费/抵扣。

特别，给列价A_n后若仍取d=(log n)/2，来源价是 A_n√n log²n，不是√A_n√n log²n。若某个方法先给核包络倍数B_n、随后再对半密度Cauchy，须追踪它进入的是列价A_n还是最终√(XW)前因子；后者会被Young平方。若只覆盖更窄新带，必须保原余带未付，不能借窄带价声称整个clock。多个支/两腿分别用ε时，总εX也要相加或预分配。

已实际用本机Python Fraction核60组A、ε、X、W的平方形式Young及两腿化系数3/2关系，均通过。此计算只验证代数费用，不认证移动列接口或原输入实例。

### 3. coarea/尺度变差真正需要证明的内容

原L(x)、s(x)是合法可测选择，当前合同未授空间BV/Lipschitz正则性。因此沿选中轨迹微分，或以coarea把dx改成dL/level-surface measure，必须另证正则性、相应Jacobian/多重性和真实测度控制；不能将自由选择器当单调路径。另一合法方式是在固定receiver变量和source上构造参数方向共同包络，积分所有尺度变差后支配任意选择，但该参数变差必须实际可积且费用完整保留。

f_s有(1−s)h的hard跳跃。关于几何尺度的分布导数含体积归一bulk和移动hard面通量；只写光滑区域score漏掉面项。密度导数signed总积分为零，不等于正变差或sup包络零价。对半密度，soft端点与hard边界还须用BV/单侧极限或明确外包处理，不能将形式∂log f在零区作普通可积函数。实际strict-soft下界接近log2/n，并非s接近1；不能由其名称假设1−s≤O(1/n)而消除hard面。

若要用Fisher/score或coarea得到根阶，应分别给bulk绝对积分、所有面通量和soft选择费用，再给其与真实δ/wg/η的联合控制。固定soft/scale的signed抵消或固定score均值零不会自动保留到原positive δ及capture/history筛选后。共同soft有限菜单若有O(√n logn)费用，不能忽略或先乘后仍宣称同阶；反过来，直接联合估计可以避免独立最坏费用，但必须明确证明。

### 4. 保原clock/source的回代资格

QG是固定物理状态、保h_R的真实dx核积分；不能在R222/TR1已经领一次16/3并消硬核的余式上再套QG或再取hard帽。若新的联合几何路线回到消帽前原母式，应写清它替代原哪一次上放及其全部外常数，不能把两路线有利部分无价叠加。硬z始终全ν来源，不是终端good来源。

若参数方向变差同时改L、R、cj/g带或s，原w_g、K2/J、η中的原history/capture/high/clock资格不能在新节点重算。可保实际原权不动，或给逐项有价支配；把门当新节点依然成立需要独立证明。移动L还会改变g和T_d端点，不能在积分x后恢复免费的同窗；可以保原x依窗再逐点估计其宽度。

原两Π依同y，合法过程上归一，process/support与原Jfar外置零。对clock积分的Fubini须保每个实际状态的参数冻结条件；先取得固定θ的QG积分，再对真实x依θ(x)的整个源clock求和，需要共同包络或实际联合定理。固定θ的Oκ(logn)时钟引理本身不是该桥。原negative credits不参与本次positive enlargement，不能拿不同gate或已消费负项抵新变差费用。

## 初检结论

可用的真实结构是same-x FIRST/high Cauchy、原不交V/j、正量可测分配和保原窗宽；精确瓶颈是自适应移动列/其联合尺度score与实际dx回代。coarea或尺度变差只有在hard面、soft费用、选择器测度和Young平方后的原预算全部闭合时，才构成新增原付款。当前尚未审核或预认本轮作者新结论；初检完成，等待准确候选。

## 尺度导数候选：作者稿前独立核验

在读scale_variation作者稿前，已独立恢复一维bulk：−f_s−u sφ′=−s(φ+uφ′)−(1−s)h。因此 T_i=−s(φ+uφ′)/f_s、H_i=(1−s)h/f_s，乘积尺度分布导数为 P(T−H)dx 加正hard面。每面系数(1−s)/2乘其余n−1个归一密度；总面质量n(1−s)。固定核下E T_i=0且E T_i²≤sIφ，乘积给ET²≤nsIφ；不赋予原来源坐标独立。

Iφ有限及≤805/27也独立确认。一个仅用于交叉核验的更粗逻辑是：核心φ≥φ(1/2)≥(1−e^−1)/2≥5/16、|φ′|≤1；尾部log斜率是Laplace混合1/r的tilted均值，随u=x−1/2递减，最大≤16/5。结合EφX²=13/12及IBP的Iφ=∫x²φ′²/φ−1，得到757/75<805/27。已用本机Fraction实际核这两有理常数及二阶矩。本轮主稿沿作者805/27，不依赖更尖常数。

## numeric_probe源码、采样与尾方向：通过

已完整静审numeric_probe.py及numeric_notes.md，并解析全部原JSON。φ与正半线解析导数用正确E2/E3递推，score=−1−xφ′/φ为偶函数；不作数值差分。R=sqrt(U)密度2r，给Laplace(R)与均匀h独立卷积恰是φ；不同n共用路径前缀，各阶段同seed且样本数嵌套，notes准确披露相关性。Welford对abs(sum score)的样本均值、样本标准差及MC标准误实现正确，有限PRNG证据未被称概率认证。

质量遗漏尾2[E4(Z−1/2)−E4(Z+1/2)]、一阶score遗漏尾+2Zφ(Z)均准确，均值补尾方向为正。对x≥1、u=x−1/2，限制r∈[3/4,1]给φ≥c e^(−4u/3)、c=3(1−e^−1)/16；|φ′|≤e^−u和φ≤e^−u，故φZ²≤2e^−u+2x²e^(−2u/3)/c。代码二阶双尾积分的4倍、指数1/3−2Z/3及多项式系数均正确。该解析上界普通mp求值与非区间GL误差区分清楚；不把有限窗I加尾上界冒称严格数值区间。

已核三阶段24/48/96窗、25/35/50dps、GL48/96/192及512/1024/4096路径菜单、16边界/尾点、2组精度对照与原JSON/notes全部一致。源码/合同指纹匹配。实际另用本机70dps重算全部16个φ/φ′/score边尾值及三个质量/一阶/二阶尾表达，均一致；尾表达按原dps减4位相对精度核验。一次更紧的dps减3位检查在最终一阶尾的1.0267e−47相对差处超阈约2.7%，这是普通50dps闭式相减的末位差，放宽一个十进位后通过，不是积分尾方向或数学错误。没有重跑蒙特卡洛；最终完整迁移复跑由父代理实际执行并外置回执，本审核不预称该执行已完成。

## scale_variation.md完整作者稿审核：通过（已核终修）

SV1–7的责任、latent方差和distribution导数正确。SV3的805/27证明自足：核心下界3/16，尾Chebyshev给log斜率≤4，全线16/3，二阶矩13/12后IBP常数正确。SV8原显示链已按审查改为正continuous质量≤min{D_n(s),√(nsIφ)/2}，两个独立界不再混为Dn本身的链式结论；有理化上界资格s<1清楚。

SV9–12的shell系数准确：δ(u_i∓ell/2)变换Jacobian2配(1−s)/2及dell/ell，恰得(1−s)ri^−n。下端a严格、上端A闭合与原closed hard约定一致；A(x)=ri可在正测receiver域发生，终端跳已纳入，不能把该上端等号丢掉。不同ri相等的例外对每个v为dx零集，Fubini对任意有限ν仍零；所取满测集与s/A无关，故任意可测selector无需导数也可逐点冻结终端s后套FTC。负hardbulk是核自身补偿，不是旧负交通信用。

SV13–14的全族正包络费用完整。R220菜单可将每个affine因子复制为两个半次幂，m≤2n合法；所有核系数对s非负affine，连同责任乘积的绝对bulk及shell也可菜单支配，所以signed身份并非未定义∞−∞。Csm和实际χ加权shell均显式保留，其最坏费用不达root，作者未夸大。

SV15–18的加权同x Cauchy保r_t=∫Πuηδ/n，第一因子≤q，第二含真实χ_t/(2K)。终修明确共同I_d(x)只依x、全部y依Jfar/process在r_t/χ_t置零；barχ=(n/d)∫I_dχ_t∈[0,1]合法。真实allocated单腿价与Young系数128Λ²/(27ε)一致，hardcap一次，未重付J/旧浮动带。SV18是实际weighted shell的明确回代而非新root预算。

## joint_geometry.md完整作者稿审核：通过

JG1–9展开一份Π、保另一份和同一β⊗ν/真实dx底测度。两移动腿共享第一平方因子A_d≤dX，第二分别是实际Ω列，故F1+F2≤√(2dXB_d)。JG7的FIRST次概率 pβ/q、h_t=2Kq/(pe_t)≤1、1Z及ηδ全部保同y；Ω≤d/(2K)只是粗上放，不足以证明JG4。当前Jfar依y的书写已由正文共同承载带/有效域解释，主proof另明确共同窗。

JG10的条件Young来源常数512CΛ²/(27ε)、JG13/14无条件回退512Λ²/(27ε)正确。JG11–12将完整软度展开，内项系数最大在s=k/n；每个h/φ产品径向放大单调，归一导数为−n bulk加正测度，总正质量n||Q||dlogL，包含hard跳，给D_n=C_n[1+nlog(b/a)]。Fourier点概率界的常数有余量；[x(n−x)]^−1/2凸，中点单元比较给内部和≤π，故C_n≤2+π√n。最终d=.5logn的全族回退价O(n²log²n)明确是不成功放松，不是新root付款，也非原合资格命题反例。

JG4联合占用Cd polylog(n)Wν/K仍标未证；需要原Ω下选中shell与负bulk联合geometry，不能重选中间scale上的FIRST来源。原深clock补集仍未付。这个状态与合同一致。

## exact_checks轻执行：通过

已完整静审exact_checks.py：7个n的Cn由Fraction精确求和，252个hard唯一面selector恒等式覆盖下端/上端等号、已进入/未进入区间，Young512/27与Fisher805/27纯有理算术正确。它只检查hard单面代数，没有声称一般soft/source实例。

实际独立运行 `python3 exact_checks.py --output /tmp/r225_audit_exact_checks.json` exit0，全部41807字节与原JSON完全一致，SHA256 `8fcb0e74dc340c2d03f9f80b6d434c08d6778e9d639607a41b3f5943dd030d0f`。无活动session；不重复完整MC。

## 主proof与driver整合审核（报告待交）

已完整通读主proof.tex.txt的(225.1)–(225.11)及新增完整fallback段。精确selected shell的ties、upper endpoint与任意可测selector量词正确；Ω整体Cauchy及Young512Λ²K/(27ε)正确。共同终端窗明确，所有y依validclock保原high/validη内；不对移动核授固定列。新增fallback与已审JG11–14一致，原深clock和open联合预算均未冒称付款。主稿未使用更尖I常数，数值范围没有把普通求积/有限MC提升为证明。

reproduce.py已完整静审：manifest前后核验，两自足脚本迁移到包外新目录，显式mpmath1.3.0，两份完整JSON字节比较；回执含runtime字段、受比较原JSON无runtime/输出路径。实际整包迁移由父级冻结后运行，审核只认证逻辑和已实际轻执行，不预认未来回执。

## 最终报告与冻结结论

report.md 已全文静审，数学结论、参数范围、未证联合预算、深clock余量及O(n²log²n)回退失败价与主proof/作者稿一致。新增scale-variation估计没有被误称新增原根阶付款。普通GL和有限嵌套seed模拟的误差/相关性边界准确；252有限hard实例、7个Cn与纯算术也没有提升为原FULL证据。建议材料阅读、skill使用及最终迁移执行属于父代理记录，本审核不声称亲自重读其附件或执行尚未运行的最终driver。

最终受审文件SHA256如下，不绑定audit自身：

|文件|SHA256|
|---|---|
|task_contract.md|ff01f629fd9a557abb4f1ebd5fb4e08776915267821e72f8df4baf5b2c9fe1ee|
|scale_variation.md|3cb13e838485415f2b6977f3061c1f60903e2369ec404c7e0c96b6ec7838a09c|
|joint_geometry.md|6008dec25b1bc9f25bfdead69a3ca0fc4e49e656ee6b3694d4bc084bc8d84a38|
|proof.tex.txt|50382d8fc2b250badddfff39667c7b4339a0a7d618e98cbc5e180ab56d284647|
|numeric_probe.py|7d3183037ab8911058a4bbc7e70c252d20a6a9ec04f0ca03a7e4bd2dbbf5105f|
|numeric_probe.json|1452dc116f1a7a2f9f37719a511d1a72cb551c427e3491acc36837d7f1a2de8d|
|numeric_notes.md|bce50ae1ba5b2687cb05248493a1c0d58e73915f802b9b69f2bb21417a01871a|
|exact_checks.py|243661db8b51c59ba00f58d5534b308af0050292110650d80cce0f5d166332a7|
|exact_checks.json|8fcb0e74dc340c2d03f9f80b6d434c08d6778e9d639607a41b3f5943dd030d0f|
|reproduce.py|2abb7b3286f07d48fad8762f2f7158add118f19cf721725bae7abdee4420f235|
|report.md|6c77fb4791b580d5f8d764ef81a525a310fcbf3c6c2a92829a23c269a63bb149|

**最终结论：上述已证核族估计、selected shell身份、保实际Ω的共同来源Cauchy/Young接口及明确有价回退审核通过；(225.11)/JG4根阶联合占用仍未证，本轮无新增根阶原交通付款。** 主proof240行及LaTeX环境静检通过，不编译PDF。轻量exact独立运行整份JSON字节一致，边尾值/解析尾表达已实际本机高精复核；未重复Monte Carlo。父级冻结manifest后执行两脚本完整外移复现，实际回执外置于轮次README/归档，不需修改本audit。

本audit至此冻结，停止写入；无活动运行session。
