# R615 原始文献：同步张量 D_m 的端点付款尚未找到

检索日期：2026-10-25。使用 academic-literature-search 技能；只将两篇直接相关原始研究列为核查结果。**没有找到能推出 `D_m≤√2 O_m+A√m` 的已证定理。** 一个原始停止定理需要非中心的 differentiation basis；另一个抽象乘积定理保留 LlogL 源费。均不能支付当前任意 2m 维 L¹ 来源的同尺度 D_m。

## 1. de Guzmán：变化纤维的真实停止，但非中心基且保留熵

Miguel de Guzmán, *An inequality for the Hardy-Littlewood maximal operator with respect to a product of differentiation bases*, **Studia Mathematica 49 (1974), 185–194**, DOI [10.4064/sm-49-2-185-194](https://doi.org/10.4064/sm-49-2-185-194)。[出版社记录](https://www.impan.pl/en/publishing-house/journals-and-series/studia-mathematica/all/49/2/100306)，[原始扫描 PDF](https://www.impan.pl/shop/en/publication/transaction/download/product/100306)。题录 verified；必要正文实际读取 pp185–189，特别 **§2 Theorem p186、停止步骤 p187**。

假设为两个 differentiation bases 的 maximal 满足 `|{M_i h>λ}|≤∫φ_i(|h|/λ)`，φ_i 连续严格递增、φ_i(0)=0。其 product basis 允许两块独立选择集合。定理用 φ₁、φ₂ 的 Stieltjes 卷积给乘积上界。特化 `φ_i(u)=A_i u`，并将空/负上限段删去，得到可安全使用的较弱明确后果

\[
|\{Mf>\lambda\}|\le\frac{A_1A_2}{\lambda}
\int |f|\,[2+4\log^+(4|f|/\lambda)].
\tag{1}
\]

停止的具体结构是：先取第一块 fiber maximal T₁f；以 `A={T₁f>λ/2}` 截断，第二块再平均 `1_A T₁f`。原 product 接收 `Mf>λ` 包含于该截断第二块 maximal 的 `>λ/2` 集。

**不能直接把 A_i 换成当前 centered O_m。** 原定义及 p187 证明使用所有含点的 J：若 J 内某 u′ 满足 `T₁f(u′,y″)≤λ/2`，则 J 的 fiber 均值也≤λ/2。这依赖 J 同时是 u′ 的允许集合。中心方体在 J 内其他点不是同一个中心；低标签核也不是该原基。因此此停止既未直接适用于 D_m，也未去掉 (1) 的熵费。同尺度在转向 product basis/迭代 maximal 时已经放宽。

临时独审原页：[/tmp/ccu_r615_deguzman_p186_187.png](/tmp/ccu_r615_deguzman_p186_187.png)，PDF [/tmp/ccu_r615_deguzman.pdf](/tmp/ccu_r615_deguzman.pdf)。仅供同页核验；最终归档无需复制整篇论文。

## 2. Fava：中心 fiber 算子也可用的抽象乘积定理，仍非纯 L¹

Norberto Angel Fava, *Weak type inequalities for product operators*, **Studia Mathematica 42 (1972), 271–288**, DOI [10.4064/sm-42-3-271-288](https://doi.org/10.4064/sm-42-3-271-288)。[出版社记录](https://www.impan.pl/en/publishing-house/journals-and-series/studia-mathematica/all/42/3/98356)，[原始扫描 PDF](https://www.impan.pl/shop/en/publication/transaction/download/product/98356)。题录 verified；实际读 **I.§1 pp274–275、I.§2 Theorem 1 pp276–278**，并核 p279 的结果重述。

“maximal operator”须 positive、sublinear、order-preserving、L∞ contraction 且 weak-(1,1)，底空间 σ-finite。Theorem 1 对 k 个这种算子的复合给

\[
\mu\{M_k\cdots M_1f>4t\}
\le C\int_{\{f>t\}}\frac f t
\left(\log\frac f t\right)^{k-1}d\mu,
\tag{2}
\]

f 属相应 R_(k−1) 尾积分类；C 不是本任务所需的维数无关 √2 系数。k=2 仍为一阶对数源费。中心 cube fiber maximal 满足这些抽象假设，故无需 de Guzmán 的非中心基条件；但必须先将同步输入上界为两个独立 fiber maximal 的复合。它没有处理当前 `g_(x′,t)(y″)` 随第二块 receiver selector t 改变时的同步改进。对一般 L¹ 不在 R₁ 的 f，(2) 的右端可无穷；截断极限仍不产生纯 W 付款。

## 对数源费不能被 dimension-only·W 代替

固定任意 m，λ=1，令 `f_M=M 1_[0,M^(−1/(2m))]^(2m)`，M≥1，则 W=1，而 (1) 的源费恰为 `2+4log(4M)`，随 M 无界。因此不能从 (1)/(2) 的源费推出 `polylog(m)W`。这只是该文献费用的适用性限制，**不是 D_m 的反例**：当前每个 D_m 核密度≤1，故这个 W=1 输入反而满足 `S_m f_M≤1`，严格 `>1` 接收集为空。

本机数学 venv 的 SymPy 实际核了该盒质量为 1 和上述对数费用；没有新输入搜索或数值优化。

## 实际查询及阅读日志

渠道：web 搜索、出版社/原 arXiv；出版社扫描 PDF 的 web 抓取为403，随后本机 urllib 成功读取，pypdf 判定无文本层，必要页用 pdftoppm+tesseract OCR；de Guzmán p186–187 另作原图视觉核验。OCR 不是定理证明，关键 centered caveat 直接对照原定义与停止步骤。

实际查询（按次序；未执行的计划查询不计）：

```text
"maximal" "tensor product" "weak (1, 1)" diagonal
"Stein" "Strömberg" "product" maximal weak dimension
"maximal" "changing" "fiber" "weak" tensor
"tensor products" "maximal operators" weak type
"diagonal" "maximal operators" "weak" tensor product
"maximal" "products of balls" "weak" dimension
"Stein Strömberg" 1983 pdf maximal
"Sommer" "products" "maximal functions" balls
"Fava" "product operators" weak type
"Fava" "Strong differentiability" product measures pdf
"Stein" "Strömberg" "259" "pdf" 1983
Fava "Weak type inequalities for product operators" pdf Studia 42 271 288
"An inequality for the Hardy-Littlewood maximal operator" "185" pdf
site.impan.pl "An inequality for the Hardy" "product"
"Weak type inequalities for product operators" "pdf" "Fava" 1972
"Weak type inequalities for product operators" "bibliotekanauki"
"de Guzmán" "product of differentiation bases" pdf theorem
"Fava" "product operators" "Theorem" "1972"
"Fava" "sm42" "pdf"
"Guzmán" "sm49" "pdf"
"Weak type inequalities" "271" "matwbn"
site.eudml.org/doc "Weak type inequalities for product operators"
```

限定排除：Sommer [arXiv:1703.07728v2](https://arxiv.org/pdf/1703.07728) 的必要 pp1–4/Theorem 1 已读，其共同尺度 products-of-balls 结论明确为 1<p≤∞，没有 weak-(1,1)，故不列入主结果或 BibTeX。没有继续扩展此 p>1 文献。另对第64轮作了有界历史检索；这不是64项数学工具技能库的核验。实际范围是 rounds/064/research.zip!proof.md 的定向关键词核查；命中的是有限 source-pairing/能量松弛记录，未发现可支付当前同步 D_m 的定理。此为必要范围核查，不是对全项目或文献的不存在性断言。

未重读 R081/R289 localization、R293 混合工具、R610 邻接差或球形 root 结果。结论是这两篇具体原始定理不闭合 D_m，而非宣称所有潜在文献均不存在。到此停止。

## 已核 BibTeX

```bibtex
@article{deGuzman1974ProductBases,
  author  = {Miguel de Guzm{\'a}n},
  title   = {An inequality for the {Hardy--Littlewood} maximal operator with respect to a product of differentiation bases},
  journal = {Studia Mathematica},
  volume  = {49},
  number  = {2},
  pages   = {185--194},
  year    = {1974},
  doi     = {10.4064/sm-49-2-185-194},
  url     = {https://www.impan.pl/shop/en/publication/transaction/download/product/100306}
}
@article{Fava1972ProductOperators,
  author  = {Norberto Angel Fava},
  title   = {Weak type inequalities for product operators},
  journal = {Studia Mathematica},
  volume  = {42},
  number  = {3},
  pages   = {271--288},
  year    = {1972},
  doi     = {10.4064/sm-42-3-271-288},
  url     = {https://www.impan.pl/shop/en/publication/transaction/download/product/98356}
}
```
