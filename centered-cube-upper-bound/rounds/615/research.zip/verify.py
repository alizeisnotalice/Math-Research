"""R615 independent beta integral and positive volume expansion checks."""
from pathlib import Path
from fractions import Fraction as F
from math import comb
import json,sys
j=json.loads(Path(sys.argv[1] if len(sys.argv)>1 else Path(__file__).with_name('RESULTS.json')).read_text())
for row in j['rows']:
 m=row['m'];q=m//2
 strong=F(m,4)*sum((F(comb(m,k))*sum((F((-1)**i*comb(m-k-1,i),2**(k+i+1)*(k+i+1)) for i in range(m-k)),F(0)) for k in range(q+1)),F(0))
 volume=F(m,2)*sum((F(comb(m,k))*sum((F(comb(m-1,i),k+i+1) for i in range(m)),F(0)) for k in range(q+1)),F(0))
 assert strong==F(row['strong_integral_exact']['rational_part']) and F(row['strong_integral_exact']['log2_coefficient'])==0
 assert volume==F(row['cumulative_volume_at_2_exact'])
 weak=volume/F(2**(2*m+1))
 assert weak==F(row['weak_quasinorm_lower_at_R2_exact'])<F(1,8)
print(json.dumps({'independent_beta_rows':len(j['rows']),'positive_volume_expansion_rows':len(j['rows']),'exact_R2_weak_lower_rows':len(j['rows']),'scope':'canonical profile only, not sum or convolution weak bound'}))
