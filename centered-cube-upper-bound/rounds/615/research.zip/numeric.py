"""R615 canonical boundary profile: exact strong integral and one weak-level lower bound."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
from fractions import Fraction as Q
from math import comb
import json,time,sys,platform,resource,hashlib
import sympy as sp
import flint
from flint import arb,ctx
START=time.perf_counter();ctx.prec=256
r,u,R=sp.symbols('r u R',positive=True)

def A(q):
 q=Q(q);return arb(q.numerator)/q.denominator
def iv(q):return {'lo_exact':str(q.lower().fmpq()),'hi_exact':str(q.upper().fmpq()),'display':q.str(32)}
rows=[]
for m in [2,4,8,16,32,64]:
 h=m//2
 first=sp.Poly(sp.expand(sum((sp.binomial(m,k)*(r-1)**k for k in range(h+1)),sp.Integer(0))),r)
 # Second-block radial derivative: all positive-maximal faces, each dr/2 and area r^(m-1).
 second=sp.Rational(m,2)*r**(m-1)
 radial=sp.Poly(sp.expand(second*first.as_expr()),r)
 ell=sp.Poly(sp.expand(sum((sp.binomial(m,k)*(1-u)**k*u**(m-k) for k in range(h+1)),sp.Integer(0))),u)
 assert sp.expand(first.as_expr()-r**m*ell.as_expr().subs(u,1/r))==0
 assert sp.expand(radial.as_expr()-sp.Rational(m,2)*r**(2*m-1)*ell.as_expr().subs(u,1/r))==0
 # Strong path1: multiply radial derivative by (1/2)r^(-2m).
 strong_rat=Q(0);strong_log=Q(0);volume2=Q(0)
 for (power,),coeff in radial.terms():
  volume2+=Q(coeff)*Q(Q(2)**(power+1)-1,power+1)
  exponent=power-2*m
  if exponent==-1:strong_log+=Q(coeff,2)
  else:strong_rat+=Q(coeff,2)*Q(Q(2)**(exponent+1)-1,exponent+1)
 # Independent strong path2: m/4 integral_(1/2)^1 ell(u)du/u.
 other_rat=Q(0);other_log=Q(0)
 for (power,),coeff in ell.terms():
  if power==0:other_log+=Q(m,4)*Q(coeff)
  else:other_rat+=Q(m,4)*Q(coeff)*Q(1-Q(1,2)**power,power)
 assert (strong_rat,strong_log)==(other_rat,other_log) and strong_log==0
 # ell at p=1/2; monotone coupling gives its minimum on p in[0,1/2].
 ell_half=sum((Q(comb(m,k),2**m) for k in range(h+1)),Q(0))
 assert ell_half>=Q(1,2)
 strong=A(strong_rat)+A(strong_log)*arb(2).log();lower=A(Q(m,8))*arb(2).log()
 assert strong>lower
 weak_at_two=Q(1,2)*Q(1,2)**(2*m)*volume2
 weak_upper_at_two=Q(1,8)*(1-Q(1,2)**(2*m))
 assert 0<weak_at_two<weak_upper_at_two<Q(1,8)
 # Independent cumulative volume primitive constructed termwise in SymPy.
 primitive=sp.integrate(radial.as_expr(),r)
 assert Q(primitive.subs(r,2)-primitive.subs(r,1))==volume2
 rows.append({'m':m,'ambient_dimension':2*m,'first_block_max_outer_coordinates':h,
  'geometry_factor':'second positive-max faces derivative(m/2)r^(m-1); first low-shell volume r^m ell(r)',
  'radial_identity_polynomial_residual':'0','ell_minimum_at_p_half_exact':str(ell_half),
  'strong_integral_exact':{'rational_part':str(strong_rat),'log2_coefficient':str(strong_log)},'strong_integral':iv(strong),'strong_over_m':iv(strong/m),'strong_lower_m_log2_over_8':iv(lower),'strong_minus_lower':iv(strong-lower),
  'independent_strong_integral_coefficient_residual':['0','0'],'cumulative_volume_at_2_exact':str(volume2),'independent_cumulative_primitive_residual':'0',
  'weak_level_lambda_at_R2_exact':str(Q(1,2)*Q(1,2)**(2*m)),'weak_quasinorm_lower_at_R2_exact':str(weak_at_two),'weak_lower_at_R2':iv(A(weak_at_two)),'weak_upper_all_levels_exact':'1/8','weak_cumulative_upper_at_R2_exact':str(weak_upper_at_two),'strict_weak_lower_below_upper':True})
out={'status':'PASS_6_EXACT_STRONG_AND_WEAK_PROFILE_ROWS','definition':'On 1<=r=2||z_second||infinity<=2 with unique positive maximizing second coordinate, and first block in cube side r with <=floor(m/2) coordinates outside unit cube, G_m(z)=(1/2)r^(-2m); zero elsewhere. Unique-max ties are null sets.',
 'geometry':'For a chosen positive maximizing second coordinate, dr/2 times r^(m-1) other-coordinate volume; sum over m disjoint-a.e. faces gives(m/2)r^(m-1)dr. The first-block low-shell volume is sum_(k<=h)binom(m,k)(r-1)^k=r^m ell_m(r). Therefore radial volume derivative a_m(r)=(m/2)r^(2m-1)ell_m(r).',
 'strong_formula':'integral G=(m/4)integral_1^2 ell_m(r)dr/r >=m ln2/8, since ell_m(r)=P[Bin(m,1-1/r)<=floor(m/2)]>=1/2. Probability decreases with p<=1/2; symmetric binomial at p1/2 gives the endpoint bound.',
 'weak_formula':'V(R)=integral_1^R a_m(r)dr <=(R^(2m)-1)/4. At lambda=(1/2)R^(-2m), strict superlevel is r<R a.e., so lambda*volume <=(1/8)(1-R^(-2m))<1/8. Levels below the minimum amplitude use V(2) and only decrease lambda*volume; levels above1/2 give empty sets. Thus weak L1 quasinorm<=1/8.',
 'rows':rows,'decision':'The canonical profile has rigorously linear strong mass in m and a uniformly bounded weak L1 quasinorm. A strong linear price alone therefore does not discard the boundary mechanism at weak type.',
 'scope':'Only the prescribed limiting boundary profile; no finite L1 bad input, no convolution weak-type bound, no actual shared-selector operator estimate, no general weak-type conclusion.',
 'error_policy':'SymPy integer polynomial identities and Fraction integrals exact; two independent strong paths and an independent cumulative primitive agree. In fact strong integrals for these m are rational (log coefficient0). Arb256 encloses log2 lower bounds, rational displays and differences. No sampling, optimization, quadrature or parameter scan.',
 'versions':{'python':platform.python_version(),'sympy':sp.__version__,'python_flint':flint.__version__},'interpreter':sys.executable,'command':[sys.executable,*sys.argv],'arb_bits':ctx.prec,'processes':1,'runtime_seconds':time.perf_counter()-START,'peak_rss_bytes_macos':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
output=Path(sys.argv[1]) if len(sys.argv)>1 else Path('/tmp/ccu_r615_profile.json');output.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'status':out['status'],'rows':[{'m':z['m'],'strong':z['strong_integral']['display'],'strong_over_m':z['strong_over_m']['display'],'weak_lower_R2':z['weak_lower_at_R2']['display']} for z in rows],'seconds':out['runtime_seconds'],'script_sha256':out['script_sha256']},indent=2))
