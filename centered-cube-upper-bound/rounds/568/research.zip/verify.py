"""Exact R568 coefficient/old-margin checks; finite diagnostics, not global proof."""
from pathlib import Path
from fractions import Fraction as F
import argparse,json,platform,hashlib
import sympy as s

def run(path):
    data=json.loads(path.read_text());rows=[]
    for r in data['records']:
        M=F(r['M']);c0=1+F(r['input']['gamma'])
        for cs,out in r['caps'].items():
            c=F(cs)
            if c<=c0:continue
            w=sum((F(t['probability'])*F(t['external_mass'])/F(t['mass']) for t in r['auxiliary_cells'] if t['same_pair'] and F(t['mass'])>c*M),F(0))
            ov=F(out['p_overload']);assert (1-c0/c)*ov<=w<=ov
            rows.append({'case':r['input']['name'],'c':cs,'overload':str(ov),'Wout':str(w),'lower_slack':str(w-(1-c0/c)*ov),'upper_slack':str(ov-w)})
    aw,Lw,c0,Lcl,A0=s.symbols('aw Lw c0 Lcl A0',positive=True)
    eps=s.Rational(1,4);c=2*c0;delta=1-c0/c
    residuals=[s.cancel(aw/((1-eps)*delta)-s.Rational(8,3)*aw),s.cancel((c*Lcl+Lw/delta)/(1-eps)-s.Rational(8,3)*(c0*Lcl+Lw)),s.cancel((1-eps)*delta/(8*A0**2)-3/(64*A0**2)),s.cancel((1-eps)*delta/(4*A0**2)-3/(32*A0**2))]
    assert all(x==0 for x in residuals)
    P=list(map(F,['1/2','1/3','1/6']));Li=list(map(F,['1/10','2','7']));gp=list(map(F,['1/4','1/2','1/6']));gb=list(map(F,['1/2','1/6','1/3']));h=list(map(F,['1/2','1/4','2/5']))
    delta=[max(a-b,0) for a,b in zip(gp,h)];advance=[max(b-a,0) for a,b in zip(gp,h)]
    assert all(0<=hh<=a+b for hh,a,b in zip(h,gp,gb))
    lhs=[a+b-hh for a,b,hh in zip(gp,gb,h)];rhs=[b+d-aa for b,d,aa in zip(gb,delta,advance)]
    assert lhs==rhs
    weight=lambda vv:sum((p*v/l for p,v,l in zip(P,vv,Li)),F(0))
    slack=weight(gp)-weight(delta);assert slack==F(653,504)
    # Wide-grid escape is an algebraic sufficient-condition diagnostic only.
    wide=[]
    for n in [1,2,8,64,256]:
        ep=F(1,4);ratio=(F(n)/ep)**n;assert ratio>1
        pair=(1-ep/n)**n;assert pair>=1-ep
        wide.append({'n':n,'epsilon':str(ep),'pair_probability':str(pair),'vprime_over_G_lower_bound':str(ratio)})
    return {'scope':'Finite exact tests and symbolic coefficient identities; global weighted bound UNPROVED','python':platform.python_version(),'sympy':s.__version__,'code_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'whole_cell_checks':len(rows),'whole_cell_results':rows,'symbolic_residuals':list(map(str,residuals)),'weighted_terminal_residual':str(weight(lhs)-weight(rhs)),'weighted_underfill_slack':str(slack),'wide_grid_diagnostics':wide,'all_checks_pass':True,'rounding_error':'zero (rational/symbolic)'}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--numeric',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();r=run(a.numeric);a.output.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:r[k] for k in ['whole_cell_checks','symbolic_residuals','weighted_terminal_residual','all_checks_pass']}))
