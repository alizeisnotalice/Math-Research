# 第568轮复现

解压到任意新的空目录，不改研究仓库。需要Python 3.12与SymPy；Fraction、json等为标准库。已实际运行的解释器如下，包的其他成员均用相对路径。

```sh
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python numeric.py --output numeric.json
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python certificate.py --numeric numeric.json --output certificate.json
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python verify.py --numeric numeric.json --output verify.json
```

三条依次运行，后两条依赖第一条。numeric.json含可重建的全部逐格数据；为控制文件体积，归档numerics_summary.json删除了auxiliary_cells，但其余输入和数学字段保留。对照时忽略cost元数据；certificate结果的source_json_sha256随耗时字段改变，比较results及90项通过标志。verify结果应该逐项相同（版本/路径无数学作用）。

成功判据：12个作者实例全部assert通过；独立证书selected_case_count=3、scalar_or_vector_author_comparisons=90、all_checks_pass=true；verify的24个whole_h检查、4个符号残差和终端零残差通过。所有结论仅限报告所列范围。

REPORT.tex是详细论证源，不要求编译，未生成PDF。AUDIT.md保存先验与定点后审，包括被修正的终端范围错误。SOURCES.md记录已核原文的定理条件，引用不等于可直接用于原连续全问题。

本轮所有作者中间文件保留在仓库外，归档不逐份收录16份草稿。manifest.json给必要成员SHA-256和字节数；归档CRC另由主代理检查。
