# R568：共同分区 / actual-mass padding 的原文条件核验

**结论：本次限域核验未定位到可直接支付完整 bad 账的 source-mass padding 定理。** 两项最相关原文都提供全点共用的随机分区，但 padding 是距离球包含事件；实际簇质量仍需另控。不能把它们写成任意相关有限测度的 mass-qualified pair-cover，也不能用有限支持点数替代原全 \(L^1\) 范围。

只读 R568 合同、相关本地索引与 K03 技能，并沿用 academic-literature-search 的原文核验流程。K03 需要先给共同半度量及增量尾条件，不提供 actual-mass partition 接口。下列两篇均已查看原定理位置和必要证明；未下载论文、运行实验、编译 PDF 或改动其他文件。原文中的有限点数记作 \(N\)，与本题维数 \(n\) 分开。

## 1. 真正允许任意有限正权的候选

Krauthgamer–Lee–Mendel–Naor, *Measured descent: A new embedding method for finite metrics*：**Lemma 1.7 / 式(2)，作者稿 p.5；Definition 1.1–1.2 在 p.3；§2 证明 p.6–7**。[作者原文](https://web.math.princeton.edu/~naor/homepage%20files/descent-journal-final.pdf#page=5)

输入为有限 metric \((X,d)\) 与每点严格正的测度 \(\mu\)。对 \(\Delta=2^u\)，存在一份对全部 \(x\in X\) 共用的分区律，所有簇直径 \(\le\Delta\)，且
\[
 \Pr\!\left[B_d\!\left(x,\frac{\Delta}{16+16\log\frac{\mu B_d(x,\Delta)}{\mu B_d(x,\Delta/8)}}\right)
 \subseteq\mathcal P_u(x)\right]\ge\tfrac12.
\tag{MD}
\]
这里球为开球。作者证明先用有理权逼近及重复点归约到计数测度，再用共同随机半径及随机排列切球；没有来源坐标独立假设。单尺度常数没有显式 \(N\)、几何 aspect ratio 或 doubling 假设，**但依赖实际局部质量比**。用最坏 \(\mu(X)/\min_x\mu(x)\) 控比会引入测度 aspect ratio，离散化细化时无统一控制。

**对合同的准确接口（本段为迁移分析）。** 取 \(d=\|\cdot\|_\infty\)、\(r=\|z-y\|_\infty\)。要把 (MD) 的成功事件送入 R564 payer，至少需同时满足
\[
 \mu_i\overline B_\infty(y,\Delta)\le cM,
 \qquad
 r<\frac{\Delta}{16+16\log[\mu_iB_\infty(y,\Delta)/\mu_iB_\infty(y,\Delta/8)]}.
\tag{eligible-padding}
\]
因为 \(y\in H=\mathcal P_u(y)\)、\(\operatorname{diam}_\infty H\le\Delta\) 才给 \(H\subseteq\overline B_\infty(y,\Delta)\)。在有限输入上，若对应完整 marked measure 已给定，这个**条件分支**可用共同分区的 \(1/2\) 成功率和 R564 得 \(V(E_\Delta)\le2cL_{\rm cl}W\)。这是已知 payer 的条件应用，非原文的 weighted theorem。

当前 far 只知 \(\mu_i\overline B_\infty(y,r)>\eta_{\rm near}\alpha_CM\)，是下界；不推出 eligible-padding 的外球质量上界或其局部质量比。每元组单选一个 \(\Delta(y,z,M)\) 也不是一份共同分区律；需用全局尺度混合并记覆盖损失，或给共同价格预算。原文只覆盖有限 \(X\)；将其扩至本题连续 \(\mu=f\,dx\) 的分区律、可测性及原 \(L_i\)/窗的极限，尚未在此核验。无此接口，不能直接引用上面的条件分支作为原全输入已付结果。

## 2. 更强概率式，但原文是计数测度

Mendel–Naor, *Ramsey partitions and proximity data structures*, JEMS 9 (2007), 253–275：**Lemma 3.1 / 式(1)，p.257；证明及条件式(3)，pp.258–259**。[期刊原文](https://ems.press/content/serial-article-files/31592#page=5)

有限 metric \(X\)、任意 \(\Delta>0\)，有一份共同 \(\Delta\)-bounded 分区律，对全部 \(x\) 和 \(0<t\le\Delta/8\)：
\[
 \Pr[B_d(x,t)\subseteq\mathcal P(x)]
 \ge\left(\frac{|B_d(x,\Delta/8)|}{|B_d(x,\Delta)|}\right)^{16t/\Delta}.
\tag{MN}
\]
证明的半径条件概率下界为 \(|B(x,R-t)|/|B(x,R+t)|\)，使用同一随机排列；这是保留三点/多点距离位置的入口。**原 Lemma 3.1 不是实际来源权 \(\mu_i\) 的陈述**。不能把两个基数直接改为来源质量并称为已核定理，也不能用 \(N\) 与本题 \(n\) 混同。

其 Theorem 3.2（p.260）给全尺度共同树，但逐点全尺度 padding 概率仅保证 \(N^{-16/\alpha}\)，随支持规模衰减；不是无代价全尺度收据。单尺度 (MN) 无显式 metric aspect ratio；有限树实现的层数另依赖距离 aspect ratio（p.263）。即使补出加权版，仍未给 \(\mu_i\mathcal P(y)\le cM\)，也未控制本题 inverse-\(L_i\) 的失败分布。

## 对完整 bad 账的决定性边界

距离 padding 可在保簇直径的同时保证近点同簇；masscap 要求的是该簇中**实际来源质量**相对元组自己的 \(M\)。两者在任意相关、无密度上界、无质量 doubling 的 \(\mu_i\) 上并不等价。为原 \(\mu_i\) 另找一个 doubling 参考测度，会丢实际 \(h_H=\mu_iH\)；即使 \(\ell_\infty^n\) 的几何 doubling 可控，也不使任意 \(f\,dx\) 成为质量 doubling。

这两项均未把外部三点见证转成可用原父、未保其旧 \(L_i(z,\sigma)\) 信用，也未给失败账的可吸收 \(aQ_g\)。当前完整未付量仍是
\[
 \int(1-p^{\rm mass})\,dV
 \quad\text{或真实 Hall flow 的原加权 terminal；}
\]
小的未加权分离概率、局部球比公式或另一次 \(\int p^{\rm mass}dV\) 付款均不支付它。本轮没有新的 \(aQ_g+LW\) 估计；可改变机制决策的新增假设，正是可共同计价的 eligible-padding 分支覆盖，以及其余分支在原 \(dV\) 下的预算。到此停止，不把上述必要条件再包装成目标本身的 Carleson/coverage 假设。
