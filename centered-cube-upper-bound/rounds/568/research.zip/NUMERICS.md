# 第568轮实际数值检验笔记

一般上界 UNPROVED。计算决策：实际质量资格是否确实扩展整格包含；第三来源分母是否必须逐格真实归一；粗阈值付款是否可能严重过量。计算不认证全部 Lebesgue 父、旧窗口、历史及 inverse-Li 费用。

## 输入和三阶段

所有输入为有理坐标/质量字符串，来源允许相关；n=1,2,3，gamma=2，c=3,4,8，最多5个原子。M=mu(D)逐例重算，保y∈A∩D、z∈A（可z不在D）、mu(A)<gamma M。此为局部有限几何模型，未声称它已实现完整原历史或给出连续L1逼近证书。

1. 初步探路：集中来源下比较实际格质量与整格包含，两种事件确实不同。
2. 压力检验：近端重来源、远端大质量、h=cM等号、完全分离原对、旧来源不在D、双盒并集跨越。
3. 扩大复核：二维/三维相关来源，逐格外部质量变化；另一个实现独立复核3个固定例的90项标量或向量。扩大范围仍是有限测试，不能外推阶数。

## 精确结果摘要

q为原两点同格概率；pU为整格包含双盒并集概率；pMass3为c=3实际质量资格概率；over4为c=4同格过载概率。

| case | n | q | pU | pMass3 | over4 |
|---|---:|---:|---:|---:|---:|
| concentrated_n1_wholecell_zero | 1 | 7/8 | 0 | 7/8 | 0 |
| concentrated_n2_wholecell_zero | 2 | 9/16 | 0 | 9/16 | 0 |
| concentrated_n3_wholecell_zero | 3 | 27/64 | 0 | 27/64 | 0 |
| near_heavy_external_n1 | 1 | 5/6 | 0 | 1/3 | 1/2 |
| far_huge_external_n1 | 1 | 5/6 | 0 | 5/6 | 0 |
| mass_equality_c3 | 1 | 5/6 | 0 | 5/6 | 0 |
| mass_equality_c4 | 1 | 5/6 | 0 | 1/3 | 0 |
| two_coordinate_external_joint | 2 | 25/36 | 0 | 4/9 | 1/4 |
| three_coordinate_variable_external | 3 | 125/216 | 0 | 11/54 | 1/8 |
| pair_separated_complement | 2 | 0 | 0 | 0 | 0 |
| old_z_outside_receiver_D | 2 | 3/5 | 0 | 3/5 | 0 |
| union_crossing_and_external | 2 | 5/6 | 5/18 | 25/36 | 5/36 |

集中例的pU=0而pMass3>0，支持保留真实质量资格；这是探路结果，不是原全积分收益。
三维变外质量例c=3的过载格外部质量为3或9/2，条件均值7/2。拿均值代替逐格分母产生最大归一误差2/7，即使某总和偶然相同也不保持条件需求。
双盒跨越例c=4的原过载为5/36，粗阈值外质量账10/9，是其8倍。只记录粗上账与真概率的区别，不称为一般转移反例。
质量等号属于合格分支：mass_equality_c4例c=4等号事件概率1/2，过载为0。网格面自身在辅助平移测度下为零，与这个正概率的质量等号不同。

## 独立性与后验核验

numeric.py从所有原子坐标、平移端点与双盒边界拆分辅助平移区域，用Fraction精确求和，并与两点/三点全坐标乘积核及并集公式对照。
certificate.py另行实现成员区间拆分；不导入作者概率函数，独核mass_equality_c4、three_coordinate_variable_external、union_crossing_and_external三例，3×(6+3×8)=90项全部一致。它不重新认证pU字段。
verify.py在作者完整逐格数据上另核24个c>3整格归一不等式 `(1-c0/c)over <= Wout <= over`，这是补充核验，不谎称第二份独立空间划分。另有4个SymPy系数零残差、1个有理旧边际恒等式及5组宽格诊断（n=1,2,8,64,256，epsilon=1/4）。这些不新增一般预算证明。

所有几何积分为有限有理和，算术舍入误差为零；SymPy仅检查所列代数。未运行浮点优化、Arb、MATLAB或重新扫描旧LP/Gram：这些计算没有相应需求。本轮不声称通用区间API通过新检验。

## 主代理清洁目录实际复现

解释器：`/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python`；Python 3.12.14；SymPy 1.14.0。单进程，避免重复昂贵实验。

- numeric.py: 退出码 0，墙钟 0.067734 秒。
- certificate.py: 退出码 0，墙钟 0.048183 秒。
- verify.py: 退出码 0，墙钟 0.500059 秒。

全部12例数学字段与作者冻结输出完全一致；独立3例和90项结果一致。耗时和JSON来源哈希等运行元数据按实际运行记录，不要求不同机器/进程逐字节相同。
原始作者完整逐格结果可由numeric.py重建，仓库仅保必要摘要；精确独立证书包含输入。完整命令、代码哈希和运行记录见REPRODUCE.md、verification.json、manifest.json。
