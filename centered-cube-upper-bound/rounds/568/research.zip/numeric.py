"""R568 finite atomic diagnostics for actual grid mass and external witnesses."""
import os
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import argparse,json,hashlib,time,resource,platform

def prod(v):
 out=F(1)
 for t in v:out*=t
 return out

def inside(p,box):return all(a<=v<=b for v,(a,b) in zip(p,box))
def overlap_volume(*boxes):return prod([max(F(0),min(b[j][1] for b in boxes)-max(b[j][0] for b in boxes)) for j in range(len(boxes[0]))])
def union_contains(cell,A,D):return overlap_volume(cell,A)+overlap_volume(cell,D)-overlap_volume(cell,A,D)==overlap_volume(cell)
def kernel(points,l):return prod([max(F(0),1-(max(p[j] for p in points)-min(p[j] for p in points))/l) for j in range(len(points[0]))])
def union_probability(A,D,y,z,l):
 aa=[];dd=[];bb=[];ee=[]
 for (al,ah),(dl,dh),yy,zz in zip(A,D,y,z):
  Y=(max(yy,zz)-l,min(yy,zz))
  def leng(a,b):return max(F(0),min(Y[1],b)-max(Y[0],a))/l
  a=leng(al,ah-l);d=leng(dl,dh-l);b=leng(max(al,dl),min(ah,dh)-l);u=leng(min(al,dl),max(ah,dh)-l);aa.append(a);dd.append(d);bb.append(b);ee.append(u-a-d+b)
 return prod(aa)+prod(dd)-prod(bb)+sum((e*prod(bb[:j]+bb[j+1:]) for j,e in enumerate(ee)),F(0))
def pack(v):
 if isinstance(v,F):return str(v)
 if isinstance(v,dict):return {k:pack(t) for k,t in v.items()}
 if isinstance(v,(list,tuple)):return [pack(t) for t in v]
 return v

def frozen_cases():
 cases=[]
 def add(name,n,side,l,y,z,extra=(),A=None,D=None,baseweights=(F(1,2),F(1,2))):
  A=A or [(-side/2,side/2)]*n;D=D or A;atoms={}
  for p,w in [(y,baseweights[0]),(z,baseweights[1])]+list(extra):atoms[tuple(p)]=atoms.get(tuple(p),F(0))+w
  cases.append(dict(name=name,A=A,D=D,y=y,z=z,ell=l,gamma=F(2),caps=[F(3),F(4),F(8)],atoms=[dict(point=p,weight=w) for p,w in atoms.items()]))
 z1=[F(1,4)];y1=[F(0)]
 add('concentrated_n1_wholecell_zero',1,F(1),F(2),y1,z1)
 add('concentrated_n2_wholecell_zero',2,F(1),F(1),[F(0)]*2,[F(1,4)]*2)
 add('concentrated_n3_wholecell_zero',3,F(1),F(1),[F(0)]*3,[F(1,4)]*3)
 add('near_heavy_external_n1',1,F(1),F(3,2),y1,z1,[([F(3,4)],F(8))])
 add('far_huge_external_n1',1,F(1),F(3,2),y1,z1,[([F(4)],F(100))])
 add('mass_equality_c3',1,F(1),F(3,2),y1,z1,[([F(3,4)],F(2))])
 add('mass_equality_c4',1,F(1),F(3,2),y1,z1,[([F(3,4)],F(3))])
 add('two_coordinate_external_joint',2,F(1),F(3,2),[F(0)]*2,[F(1,4)]*2,[([F(3,4),F(0)],F(2)),([F(0),F(3,4)],F(2))])
 add('three_coordinate_variable_external',3,F(1),F(3,2),[F(0)]*3,[F(1,4)]*3,[([F(3,4) if j==k else F(0) for j in range(3)],F(3,2)) for k in range(3)])
 add('pair_separated_complement',2,F(2),F(1,2),[F(0)]*2,[F(3,4)]*2,[([F(3,2),F(3,2)],F(8))])
 add('old_z_outside_receiver_D',2,F(2),F(5,2),[F(1,2),F(0)],[-F(1,2),F(0)],[([F(3,2),F(0)],F(1,2))],A=[(-F(1),F(1))]*2,D=[(F(0),F(2)),(-F(1),F(1))],baseweights=(F(1),F(1,2)))
 add('union_crossing_and_external',2,F(2),F(3,2),[F(1,2),F(0)],[F(1,4),F(0)],[([F(1,2),F(5,4)],F(8))],A=[(-F(1),F(1))]*2,D=[(F(0),F(2)),(-F(1),F(1))])
 return cases

def analyze(case):
 A,D,y,z,l=case['A'],case['D'],case['y'],case['z'],case['ell'];atoms=case['atoms'];n=len(y);M=sum((a['weight'] for a in atoms if inside(a['point'],D)),F(0));N=sum((a['weight'] for a in atoms if inside(a['point'],A)),F(0));U=sum((a['weight'] for a in atoms if inside(a['point'],A) or inside(a['point'],D)),F(0));c0=1+case['gamma'];assert M>0 and N<case['gamma']*M and inside(y,A) and inside(y,D) and inside(z,A)
 exterior=[not (inside(a['point'],A) or inside(a['point'],D)) for a in atoms];breaks=[]
 for j,yy in enumerate(y):
  vals={yy-l,yy}
  for a in atoms:
   for t in [a['point'][j],a['point'][j]-l]:
    if yy-l<t<yy:vals.add(t)
  for box in [A,D]:
   for endpoint in box[j]:
    for t in [endpoint,endpoint-l]:
     if yy-l<t<yy:vals.add(t)
  breaks.append(sorted(vals))
 q=pU=fullmoment=externalmoment=F(0);dist={};cells=[]
 for intervals in product(*[list(zip(v[:-1],v[1:])) for v in breaks]):
  left=[(a+b)/2 for a,b in intervals];cell=[(v,v+l) for v in left];prob=prod([b-a for a,b in intervals])/l**n;ids=[i for i,a in enumerate(atoms) if all(v<=w<v+l for v,w in zip(left,a['point']))];same=all(v<=w<v+l for p in [y,z] for v,w in zip(left,p));h=sum((atoms[i]['weight'] for i in ids),F(0));he=sum((atoms[i]['weight'] for i in ids if exterior[i]),F(0));contained=union_contains(cell,A,D)
  cells.append(dict(left_endpoint_intervals=intervals,probability=prob,atom_indices=ids,same_pair=same,union_contained=contained,mass=h,external_mass=he))
  if same:
   q+=prob;pU+=prob*contained;fullmoment+=prob*h;externalmoment+=prob*he;key=(h,he);dist[key]=dist.get(key,F(0))+prob
 assert sum((a['probability'] for a in cells),F(0))==1
 triple=sum((a['weight']*kernel([y,z,a['point']],l) for a in atoms),F(0));exttriple=sum((a['weight']*kernel([y,z,a['point']],l) for i,a in enumerate(atoms) if exterior[i]),F(0));assert fullmoment==triple and externalmoment==exttriple and q==kernel([y,z],l) and pU==union_probability(A,D,y,z,l)
 results={}
 for c in case['caps']:
  good=over=eq=F(0);witness=[F(0)]*len(atoms);outside_bad_moment=F(0);overcells=[]
  for cell in cells:
   if not cell['same_pair']:continue
   p,h,he=cell['probability'],cell['mass'],cell['external_mass']
   if h<=c*M:good+=p
   else:
    over+=p;assert he>0;assert he>c*M-U
    if c>c0:assert he>(c-c0)*M
    weights=[atoms[i]['weight']/he if i in cell['atom_indices'] and exterior[i] else F(0) for i in range(len(atoms))];assert sum(weights,F(0))==1
    for i,w in enumerate(weights):witness[i]+=p*w
    outside_bad_moment+=p*he;overcells.append((p,he))
   if h==c*M:eq+=p
  assert 1-q+good+over==1 and good+over==q and pU<=good and sum(witness,F(0))==over
  extactualthreshold=c*M-U;wrong=F(0)
  if over:
   mean=outside_bad_moment/over;wrong=max(abs(he/mean-1) for p,he in overcells)
  results[str(c)]=dict(p_mass=good,p_overload=over,p_separated=1-q,p_equality_mass_cap=eq,probability_conservation=1-q+good+over,total_triple_Markov_price=triple/(c*M),total_Markov_clipped_upper=min(q,triple/(c*M)),external_true_union_threshold=extactualthreshold,external_true_union_Markov_price=exttriple/extactualthreshold,external_c0_Markov_price=exttriple/((c-c0)*M) if c>c0 else None,external_unconditioned_witness_atom_probabilities=witness,external_conditional_witness_atom_probabilities=[w/over for w in witness] if over else [F(0)]*len(witness),outside_mass_moment_on_overload=outside_bad_moment,maximum_wrong_mean_denominator_cell_normalization_error=wrong)
  assert over<=triple/(c*M) and over<=exttriple/extactualthreshold
  if c>c0:assert over<=exttriple/((c-c0)*M)
 return dict(input=case,M=M,N=N,union_mass=U,total_source_mass=sum((a['weight'] for a in atoms),F(0)),q=q,p_union=pU,full_mass_moment_same_pair=fullmoment,external_mass_moment_same_pair=externalmoment,triple_range_kernel_mass=triple,external_triple_range_kernel_mass=exttriple,same_pair_mass_distribution=[dict(mass=h,external_mass=he,probability=p) for (h,he),p in sorted(dist.items())],caps=results,auxiliary_cells=cells)

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',default=str(Path(__file__).with_suffix('.json')));args=ap.parse_args();st=time.perf_counter();records=[analyze(c) for c in frozen_cases()];payload=pack(dict(schema='R568.numeric.1',scope='Finite rational atomic structural diagnostic; genuine shifted-grid cell, not original weighted dV/history or general L1 proof',grid='uniform global shift represented by the left endpoint of the cell containing y; half-open cells, auxiliary boundary shifts null',gamma=F(2),c0=F(3),records=records,checks=dict(all_probability_partitions_exact=True,all_triple_kernel_identities_exact=True,all_union_probabilities_full_coordinate_exact=True,all_external_witnesses_cellwise_normalized=True,all_original_M_computed_from_mu_D=True),cost=dict(seconds=time.perf_counter()-st,maxrss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,processes=1,LP_calls=0,Gram_calls=0),python=platform.python_version(),code_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()));Path(args.output).write_text(json.dumps(payload,indent=2));print(json.dumps(dict(cost=payload['cost'],summary=[dict(name=r['input']['name'],M=r['M'],q=r['q'],p_union=r['p_union'],mass_c3=r['caps']['3']['p_mass'],over_c4=r['caps']['4']['p_overload'],wrong_denominator_c3=r['caps']['3']['maximum_wrong_mean_denominator_cell_normalization_error']) for r in payload['records']]),indent=2))
if __name__=='__main__':main()
