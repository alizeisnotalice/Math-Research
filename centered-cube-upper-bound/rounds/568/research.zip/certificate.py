#!/usr/bin/env python3
"""Independent rational cell integration; no author probability imports."""
from fractions import Fraction as F
from itertools import product
from pathlib import Path
from hashlib import sha256
import argparse, json, platform


def rational(x):
    if isinstance(x,float): raise TypeError('Exact input must not contain float coordinates or weights')
    return F(x)


def encode(x):
    if isinstance(x,F): return str(x.numerator)+'/'+str(x.denominator)
    if isinstance(x,dict): return {str(k):encode(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)): return [encode(v) for v in x]
    return x


def prod(xs):
    v=F(1)
    for x in xs:v*=x
    return v


def box_contains(point,box):
    return all(lo<=v<=hi for v,(lo,hi) in zip(point,box))


def certify(case):
    A=[[rational(v) for v in ab] for ab in case['A']]
    D=[[rational(v) for v in ab] for ab in case['D']]
    y=list(map(rational,case['y']));z=list(map(rational,case['z']))
    ell=rational(case['ell']);gamma=rational(case['gamma'])
    atoms=[(list(map(rational,a['point'])),rational(a['weight'])) for a in case['atoms']]
    assert ell>0 and gamma>0 and len(y)==len(z)==len(A)==len(D)
    assert all(w>0 and len(v)==len(y) for v,w in atoms)
    assert box_contains(y,A) and box_contains(y,D) and box_contains(z,A)
    assert len({hi-lo for lo,hi in A})==len({hi-lo for lo,hi in D})==1
    M=sum((w for v,w in atoms if box_contains(v,D)),F(0))
    massA=sum((w for v,w in atoms if box_contains(v,A)),F(0))
    assert M>0 and massA<gamma*M
    inside=[box_contains(v,A) or box_contains(v,D) for v,w in atoms]
    union_mass=sum((w for (_,w),yes in zip(atoms,inside) if yes),F(0))
    assert union_mass<=(1+gamma)*M
    parts=[]
    for j,yy in enumerate(y):
        lo,hi=yy-ell,yy
        # On open subintervals, membership of every source and z is constant.
        faces=[z[j],z[j]-ell]
        for v,w in atoms:faces.extend([v[j],v[j]-ell])
        cuts=sorted({lo,hi,*[v for v in faces if lo<v<hi]})
        parts.append(list(zip(cuts,cuts[1:])))
    cells=[];total=F(0);q=F(0);massmoment=F(0)
    for rect in product(*parts):
        left=[(a+b)/2 for a,b in rect]
        prob=prod([(b-a)/ell for a,b in rect]);total+=prob
        pair=all(a<=v<a+ell for a,v in zip(left,z))
        if not pair:continue
        members=[all(a<=v<a+ell for a,v in zip(left,point)) for point,w in atoms]
        h=sum((w for (_,w),yes in zip(atoms,members) if yes),F(0))
        e=sum((w for (_,w),yes,ins in zip(atoms,members,inside) if yes and not ins),F(0))
        q+=prob;massmoment+=prob*h
        cells.append((prob,h,e,members))
    assert total==1
    q_formula=prod([max(F(0),1-abs(yy-zz)/ell) for yy,zz in zip(y,z)])
    triple=sum((w*prod([max(F(0),1-(max(yy,zz,ww)-min(yy,zz,ww))/ell) for yy,zz,ww in zip(y,z,point)]) for point,w in atoms),F(0))
    assert q==q_formula and massmoment==triple
    thresholds=[]
    for cc in case['c']:
        c=rational(cc);assert c>=1+gamma
        pm=po=eq=externalmoment=F(0);witness=[F(0) for a in atoms];min_surplus=None
        thresholdinvoice=F(0);external_values=[]
        for prob,h,e,members in cells:
            if h<=c*M:
                pm+=prob
                if h==c*M:eq+=prob
            else:
                po+=prob;assert e>0
                surplus=e-(c-1-gamma)*M
                assert surplus>0
                min_surplus=surplus if min_surplus is None else min(min_surplus,surplus)
                norm=sum((w/e for (_,w),yes,ins in zip(atoms,members,inside) if yes and not ins),F(0))
                assert norm==1
                for k,((_,w),yes,ins) in enumerate(zip(atoms,members,inside)):
                    if yes and not ins:witness[k]+=prob*w/e
                externalmoment+=prob*e;external_values.append(e)
                if c>1+gamma:thresholdinvoice+=prob*e/((c-1-gamma)*M)
        assert pm+po==q and pm+po+(1-q)==1 and sum(witness,F(0))==po
        assert po<=triple/(c*M)
        if c>1+gamma:assert thresholdinvoice>=po
        mean_external=externalmoment/po if po else None
        wrong_mean_error=max([abs(e/mean_external-1) for e in external_values],default=F(0))
        thresholds.append(dict(wrong_mean_denominator_max_normalization_error=wrong_mean_error,c=c,p_mass=pm,p_over=po,p_separated=1-q,mass_equal_threshold=eq,witness_by_atom=witness,witness_total=sum(witness,F(0)),external_mass_invoice=externalmoment,min_external_surplus=min_surplus,threshold_normalized_invoice=None if c==1+gamma else thresholdinvoice,markov_bound=triple/(c*M)))
    return dict(id=case['id'],dimension=len(y),M=M,mass_A=massA,union_mass=union_mass,q=q,cell_mass_moment=massmoment,triple_kernel=triple,thresholds=thresholds,input=case)


def run(path):
    data=json.loads(path.read_text())
    selected=['mass_equality_c4','three_coordinate_variable_external','union_crossing_and_external']
    records={r['input']['name']:r for r in data['records']}
    results=[];comparisons=0
    for name in selected:
        author=records[name]
        case=dict(author['input']);case['id']=case.pop('name');case['c']=case.pop('caps')
        result=certify(case)
        for own,key in [('M','M'),('mass_A','N'),('union_mass','union_mass'),('q','q'),('cell_mass_moment','full_mass_moment_same_pair'),('triple_kernel','triple_range_kernel_mass')]:
            assert result[own]==rational(author[key]);comparisons+=1
        for entry in result['thresholds']:
            other=author['caps'][str(entry['c'])]
            for own,key in [('p_mass','p_mass'),('p_over','p_overload'),('p_separated','p_separated'),('mass_equal_threshold','p_equality_mass_cap'),('external_mass_invoice','outside_mass_moment_on_overload'),('markov_bound','total_triple_Markov_price'),('wrong_mean_denominator_max_normalization_error','maximum_wrong_mean_denominator_cell_normalization_error')]:
                assert entry[own]==rational(other[key]);comparisons+=1
            assert entry['witness_by_atom']==list(map(rational,other['external_unconditioned_witness_atom_probabilities']));comparisons+=1
        results.append(result)
    return encode(dict(scope='Three fixed finite rational atomic cases; exact mass partition and normalized actual external witness only; not original weighted dV or L1 estimate',python=platform.python_version(),arithmetic='fractions.Fraction, zero rounding error',independent_implementation=True,author_probability_imports=False,source_json_sha256=sha256(path.read_bytes()).hexdigest(),code_sha256=sha256(Path(__file__).resolve().read_bytes()).hexdigest(),selected_case_count=len(results),scalar_or_vector_author_comparisons=comparisons,all_checks_pass=True,results=results))


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--numeric',type=Path,default=Path(__file__).resolve().parent/'numeric.json')
    parser.add_argument('--output',type=Path)
    args=parser.parse_args()
    text=json.dumps(run(args.numeric),ensure_ascii=False,indent=2)+'\n'
    if args.output:args.output.write_text(text)
    print(text,end='')
