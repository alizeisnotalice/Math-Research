"""R554: finite all-subset 2D union directional probes; binary64 geometry."""
from pathlib import Path
import itertools,json,sys,time,hashlib
import numpy as np
import scipy
START=time.monotonic()
B=(1+np.sqrt(.5))/2
INPUTS=[
 dict(name='two_equal_axial_contact',stage='calibration',m=[.5,.5],x=[[0,0],[-B,0]],contact=True),
 dict(name='two_generic',stage='calibration',m=[.35,.65],x=[[0,0],[-.6,-.2]]),
 dict(name='three_mixed',stage='mixed_sign_pressure',m=[.3,.4,.3],x=[[0,0],[-.8,.25],[.2,-.7]]),
 dict(name='four_mixed',stage='mixed_sign_pressure',m=[.2,.3,.25,.25],x=[[0,0],[-.8,.25],[.2,-.7],[-.35,-.65]]),
 dict(name='five_mixed',stage='mixed_sign_pressure',m=[.2,.2,.2,.2,.2],x=[[0,0],[-.8,.25],[.2,-.7],[-.35,-.65],[-1.1,.4]]),
 dict(name='three_mass_ratio',stage='mass_ratio_expansion',m=[.04,.81,.15],x=[[0,0],[-.8,.25],[.2,-.7]]),
 dict(name='four_mixed_off_contact',stage='single_off_contact_check',m=[.2,.3,.25,.25],x=[[0,0],[-.77,.23],[.18,-.68],[-.36,-.61]]),
 dict(name='five_mass_ratio',stage='mass_ratio_expansion',m=[.025,.55,.1,.3,.025],x=[[0,0],[-.8,.25],[.2,-.7],[-.35,-.65],[-1.1,.4]])]
STEPS=[1e-3,1e-4,1e-5,1e-6,1e-7]

def union_area(boxes):
 if not boxes:return 0.
 xs=sorted(set(q for a,b,c,d in boxes for q in [a,b]));area=0.
 for lo,hi in zip(xs[:-1],xs[1:]):
  mid=(lo+hi)/2;ys=sorted((c,d) for a,b,c,d in boxes if a<mid<b)
  length=0.;right=None
  for c,d in ys:
   if right is None or c>right:length+=d-c;right=d
   elif d>right:length+=d-right;right=d
  area+=(hi-lo)*length
 return area

def geometry(m,x,i):
 inc=[];exc=[];valid=[];slacks=[]
 for mask in range(1,1<<len(m)):
  ids=[j for j in range(len(m)) if mask>>j&1];side=np.sqrt(m[ids].sum())
  low=x[ids].max(0)-side/2;high=x[ids].min(0)+side/2
  slacks.extend((high-low).tolist())
  if np.all(high>low):
   box=(float(low[0]),float(high[0]),float(low[1]),float(high[1]));valid.append(mask)
   (inc if mask>>i&1 else exc).append(box)
 a=union_area(inc);b=union_area(exc);u=union_area(inc+exc)
 return dict(U=u,contains_i_union=a,excludes_i_union=b,overlap=a+b-u,excludes_i_exposed=u-a),dict(positive_masks=valid,min_abs_box_width=float(np.min(np.abs(slacks))),zero_box_width_count=int(np.sum(np.array(slacks)==0)))

def path(m,x,i,t,mode):
 mt=m.copy();xt=x.copy()
 if mode in ['mass','joint']:mt[i]+=t
 if mode in ['position','joint']:
  nonzero=x!=0
  # Exact coordinate ODE x(t)=sgn(x)*sqrt(x^2+t), zeros remain fixed.
  xt[nonzero]=np.sign(x[nonzero])*np.sqrt(x[nonzero]**2+t)
 return geometry(mt,xt,i)[0]

def probe(config):
 m=np.array(config['m'],float);x=np.array(config['x'],float);i=int(np.argmax(x.sum(1)));shift=x[i].copy();x-=shift
 assert np.all(x.sum(1)<=1e-15)
 base,audit=geometry(m,x,i);result=dict(input=config,anchor_index=i,translation=shift.tolist(),anchored_positions=x.tolist(),velocity=np.divide(1.,2*x,out=np.zeros_like(x),where=x!=0).tolist(),base=base,base_geometry_audit=audit,directions={})
 for mode in ['mass','position','joint']:
  rows=[]
  for h in STEPS:
   plus=path(m,x,i,h,mode);minus=path(m,x,i,-h,mode)
   rows.append(dict(step=h,forward={k:(plus[k]-base[k])/h for k in base},backward={k:(base[k]-minus[k])/h for k in base},central={k:(plus[k]-minus[k])/(2*h) for k in base}))
  last,previous=rows[-1],rows[-2]
  gap=max(abs(last['forward'][k]-last['backward'][k]) for k in base)
  drift=max(abs(last['central'][k]-previous['central'][k]) for k in base)
  scale=max(1.,max(abs(v) for v in last['central'].values()))
  stable=gap<2e-5*scale and drift<2e-5*scale
  result['directions'][mode]=dict(differences=rows,max_last_one_sided_gap=gap,max_last_central_drift=drift,status='smooth_direction_numerically_consistent' if stable else 'one_sided_or_unstable_do_not_treat_central_as_derivative')
 result['base_degeneracy_note']='near-zero subset width: mathematical contact pressure; roundoff may create tiny boxes' if audit['min_abs_box_width']<1e-12 else ('known union-boundary contact calibration' if config.get('contact') else 'no near-zero subset width; derivative status remains numerical')
 result['joint_minus_mass_plus_position_last']={k:result['directions']['joint']['differences'][-1]['central'][k]-result['directions']['mass']['differences'][-1]['central'][k]-result['directions']['position']['differences'][-1]['central'][k] for k in base}
 return result

def main():
 result=dict(evaluation_count=len(INPUTS)*(1+3*2*len(STEPS)),calibration_exact_area='3/2-sqrt(2)/4',model=dict(n=2,lambda_=1,normalization='base mass1; dm_i/dt=1 changes total mass to1+t, no renormalization',boxes='all nonempty subsets: lower=max x-sqrt(mS)/2; upper=min x+sqrt(mS)/2',root_arithmetic='binary64 sqrt; full rectangle union by scanline, not sum of boxes',path='mass_i(t)=mass_i+t when enabled; x_kj(t)=sgn(x_kj)*sqrt(x_kj^2+t) for nonzero anchored coordinates, zero coordinates fixed',steps=STEPS,selection='fixed explicit inputs, no random search',sample_seed=None),records=[probe(c) for c in INPUTS],versions=dict(python=sys.version,numpy=np.__version__,scipy=scipy.__version__),command=f'{sys.executable} {Path(__file__)}',script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),elapsed_seconds=time.monotonic()-START,scope='Floating all-subset full union, local finite directional probes only; stability diagnostic is not differentiability proof or extremal certification.')
 Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2))
 for r in result['records']:
  print(r['input']['name'],r['base']['U'])
  for mode,d in r['directions'].items():print(mode,d['status'],d['differences'][-1]['forward'],d['differences'][-1]['backward'])
if __name__=='__main__':main()
