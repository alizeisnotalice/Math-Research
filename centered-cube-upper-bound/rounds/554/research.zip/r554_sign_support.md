# R554辅助：支持源符号随机化的量词与预算门

结论：量词合法，但目前只得到同一列值c的确定混合；没有sqrt(n)增益。整体径向流在逐坐标反射下协变，拉回原配置后，随机符号除“选择哪个来源”外全部消失。因此不能直接对它套固定系数Khintchine。没有找到新的根适配关联不等式，不建议仅以该随机化继续扩局部工具。

## 1. 同一全局选择的准确公式

固定R540同一组theta_a及完整带标签面测度nu。所有正质量列c_i=c=U/M。先固定一个与面无关的并列规则，对每个epsilon∈{−1,+1}^n取

    I(epsilon)∈argmax_i epsilon·x_i,
    p_i=Pr{I(epsilon)=i},  p(S)=Σ_(i∈S)p_i。

p_i是整个来源配置的正交锥选择概率，不假设均匀，不假设与S、面、归属来源或尺度独立。由同一个nu，准确地

    c=E_epsilon c_(I(epsilon))
     =(1/(2n))∫ p(S) r^(1−n) dnu。                 (1)

这是完整被收费列i∈S的混合，不是面归属i的混合。逐epsilon平移及反射时，应将原theta及分支标签一一运输；不能重新挑一组有利theta，也不能逐面重新挑I。

支持条件是：对固定epsilon，所有来源满足epsilon·(x_k−x_I)<=0。但I与epsilon相关；它不是一个对每个面独立抽取的支持源。

## 2. 对当前完整径向流，符号平均精确退成一个确定混合流

用tau表示面的外法向坐标符号，以免与随机epsilon混淆。对每个i预先固定0<delta_i<m_i^(1/n)/2，令

    w_i(y)=w_(delta_i)(y−x_i),
    R_i(F)=alpha_i(S)+tau[w_i(x_k)_j−w_i(y)_j],
    alpha_i(S)=1_(i∈S)/(2nr^(n−1)),

其中F=(a,S,j,tau,k,y,r)是同一个完整带标签面，k是端点归属来源。给定联合流合同为

    c_i=1+∫ R_i(F)dnu(F),
    R_i(F)=0 当k=i。

w_delta满足逐坐标反射协变。把每个epsilon反射后的式子拉回原坐标，外法向及向量分量的epsilon_j因子相消；没有留下可独立平均的Rademacher线性系数。

令确定的混合向量场

    W(y)=Σ_i p_i w_i(y),  u_k=W(x_k)。

则

    c=1+∫[p(S)/(2nr^(n−1))
           +tau(u_(k,j)−W_j(y))]dnu
     =1+∫Σ_i p_i 1_(k≠i) R_i(F)dnu。              (2)

W是有限个Lipschitz场的混合，各核心均在自己的单源接收盒内；故∫_E div W=Σp_i=1。同一theta的位置平衡准确给∫tau u_(k,j)dnu=0。因此(2)没有误用独立性，却仍只是(1)和原流公式的线性组合，没有新的容量或收费上界。

尤其不能将k=I时的逐面取消推广为所有i∈S的取消；混合后仍保留k≠i且i∉S的流项，这些项并无固定符号。

## 3. 为什么一般Khintchine不能付款

固定系数a时，E|Σ epsilon_j a_j|<=||a||_2。这里系数可随支持源选择I(epsilon)改变，此前提不成立。

一个纯有限代数守卫：来源位置包含全部cube顶点x_s=s∈{−1,+1}^n，取最大对角源I(epsilon)=epsilon。则

    epsilon·x_(I(epsilon))=n  对每个epsilon，
    ||x_(I(epsilon))||_2=sqrt(n)。

所以不能把选择后的内积当成固定系数和而得到sqrt(n)。这不是R540联合极值的反例；它只排除仅凭“来源是对角极大点”及Rademacher代数就产生该节省。位置平衡也不自动修复：它已经逐来源令每个确定速度场的共同力积分为0，不能再从这个零等式取得未付正项的上界。

指定本机Python/Fraction实际有限核验：n=4时固定全1向量的E|Σepsilon_j|=3/2，而选择顶点内积恒为4；n=8时分别为35/16和8。没有进行参数扫描，也没有将这两个配置当作联合极值证据。

## 4. 真正需要的几何关联与继续标准

若希望得到符号抵消，必须额外控制**翻转一个符号时，所选支持源改变所造成的完整带标签根响应**。该响应必须沿同一个全局来源选择、同一theta、全部charged/owner项和全部尺度计算。支持半空间本身没有给这个变化量上界。

例如对任何试图写成Σ_j epsilon_j Z_j(epsilon)的响应，准确的有限立方体分部积分是

    E[epsilon_j Z_j(epsilon)]
      =(1/2)E[epsilon_j (Z_j(epsilon)−Z_j(epsilon^(j)))]，

其中epsilon^(j)只翻转第j个符号。因此用Cauchy取得sqrt(n)因子后，仍须支付所有符号翻转响应的平方和；选择顶点的例子中每个方向的响应都同步改变，平方和本身有n级，节省消失。

值得继续的额外输入应当是一条可独立核验的根临界几何条件，控制这些**切换支持源的响应费用**，且统一于来源数、质量和可达分支，并明确利用全尺度根帽与支持半空间的联合关系。它不是“再假设平均余项有根阶界”；它要求对相邻符号选择之间的具体响应建立结构控制。当前没有该条件或证明，不能把需要它的有限代数式视为新全局估计。

本次判断：将支持源随机化本身作为当前径向流的新付款路线不值得继续；它严格折叠为确定混合W。若后续发现上述支持源切换的实际几何约束，再重新开题。现在停止，不扩展局部工具。

实际工具命令：

```sh
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python - <<'PY'
from fractions import Fraction
from math import comb
for n in (4,8):
    fixed=Fraction(sum(comb(n,k)*abs(n-2*k) for k in range(n+1)),2**n)
    adaptive=Fraction(n)
    print(n,'E fixed |sign sum| =',fixed,
          'E selected sign dot vertex =',adaptive)
PY
```
