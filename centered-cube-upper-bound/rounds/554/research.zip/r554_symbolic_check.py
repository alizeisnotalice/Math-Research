"""R554 symbolic identities only; no dimensional estimate."""
import sympy as S,sys,json
n=S.symbols('n',integer=True,positive=True)
s,beta,a=S.symbols('s beta a',positive=True)
alpha=S.symbols('alpha',real=True)
# Freeze r=2 by homogeneity, t=s, source norm=beta.
actual=1/(n*2**n)+(s*alpha-1)/(n*2**n*beta**n)-alpha*s/(n*2**n*s**n)
target=(1-(1-s*alpha)/beta**n-alpha*s**(1-n))/(n*2**n)
assert S.simplify(actual-target)==0
inside=S.simplify((1-(1-s*alpha)/beta**n-alpha*s**(1-n)).subs(alpha,-a)-a*s**(1-n))
assert S.simplify(inside-(beta**n-1-s*a)/beta**n)==0
rows=[]
for d in (2,3,4,8):
 y=S.symbols('y0:'+str(d),real=True)
 w=[v/(d*2**d*y[0]**d) for v in y]
 div=S.simplify(sum(S.diff(w[j],y[j]) for j in range(d)))
 delta=S.symbols('delta',positive=True)
 total=S.simplify((2*delta)**d/(2**d*delta**d))
 face=S.simplify(delta*(2*delta)**(d-1)/(d*2**d*delta**d))
 assert div==0 and total==1 and face==S.Rational(1,2*d)
 rows.append(dict(n=d,div=str(div),core=str(total),face=str(face)))
print(json.dumps(dict(python=sys.version,sympy=S.__version__,scalar_identity='0',inward_remainder=str(inside),radial_checks=rows),indent=2))

from fractions import Fraction
from math import comb
for d in (4,8):
    fixed=Fraction(sum(comb(d,k)*abs(d-2*k) for k in range(d+1)),2**d)
    print('sign guard',d,'fixed',fixed,'selected',d)
