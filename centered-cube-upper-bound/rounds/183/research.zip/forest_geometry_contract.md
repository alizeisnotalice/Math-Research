# R183 forest translation and overlap contract

Scope: exact source definitions and elementary consequences only. This is an evidence index, not a proof that a proposed weighted separation estimate pays the original companion.

## Random translation, cell sizes, and what is independent

R107 `rounds/107/research.zip::proof.md`, N8–N10 (lines 546–578), is the clearest randomized-forest statement. It adds an independent shift `ξ` on `T_near`, takes finest forest-cell sidelength `s_*=cna`, chooses `D=min{d≥0:2^d s_*≥(L−3)a}`, `S=2^D s_*`, and samples `ξ∼Unif([0,S)^n)` (N8, lines 548–555). All levels share that shift and are nested by repeated bisection; `ξ` is independent of the original input, original forest, all original history, and the whole pre-shift `T_near` (line 557). In the actual application `c=256`, so `s_*=256na` (R107 R9/R12, lines 973–1003). The original birth-grid cells are a different scale: R107 D1 (lines 36–40) defines half-open translated cells of side `d=a/n`.

For fixed pre-shift `x,y,ω`, R107 N9 (lines 559–572) states that each coordinate phase modulo `s_*` is independent uniform, so an interval of length `ℓ_i` crosses a cell boundary with probability `min(1,ℓ_i/s_*)`; endpoints have probability zero. It uses this for `Q(x,R(x))∪{y}` and gets `Pξ(Good_2^c)≤(nR+||x−y||_1)/s_*≤18/c` on the near support (not a two-source-pair bound). By the same phase law, for two fixed points `y,u` chosen before `ξ`, the probability they lie in different finest cells is exactly

`1 − ∏_{i=1}^n (1 − min(1, |y_i−u_i|/s_*))`.

This is a direct consequence of N8–N9's uniform independent phases, not a separately stated theorem. In R107 R12, `V` denotes a remaining finest-cell terminal leaf; earlier stopped nodes are distinct objects. Thus distinct finest cells imply distinct remaining finest-cell leaves, but this formula does not describe the split law of earlier stopped nodes. Conditioning on a shift-dependent stopping/acceptance event can bias the phase law; the documented independence applies to pre-shift source/traffic, not to a remnant already selected using `ξ`. R107 N9 line 986 explicitly says the independence is used once on original near traffic and is not reused after a later remnant depends on `ξ`.

At the top-grid scale `S` the same coordinate-phase argument gives, for two pre-`ξ` fixed points, top-cell separation probability `1−∏_i(1−min(1,|y_i−u_i|/S))`. This is only a top-cell statement; it does not give the split probability for a stopping node, whose boundary depends on the shifted cell masses.

## Original forest, top, and hard mass

R107 R9/R12 (lines 973–1005) describes a *new* forest formed from the shared shifted dyadic grid; at each seed its remaining terminal leaves `V` are finest half-open cells of side `256na`, with `|V|=(256na)^n`, and the relevant source/cube pair is assigned to a unique such leaf. R113 `rounds/113/research.zip::proof.md`, B8–B10 (lines 75–92), instead refers to the original FULL forest and defines its hard qualification

`h(A)=μ_hi(A∩B)`, `B={t_C≤b}`,

and `T_0(y)` as the top of that original forest containing `y`. At scale `t`, in each original finite-depth tree take the coarsest node with `h(A)≤H(t)` and fill uncovered parts with the original finest-grid cells; `A_t(y)` is the block containing `y`, and `Z_V(y,t)=D_V(y)∩(T_0(y)\A_t(y))`. These cited excerpts do not establish that R107's newly shifted forest is the same forest/grid as R113's original FULL forest. Accordingly the `256na` fixed-pair split formula above cannot be applied to the R113/R114 blocks `A_{j,t}` from these citations alone. R114 S3–S4 (lines 235–250) changes the threshold by ratio-band index to

`H_j(t)=q t^n max{1, √n c_(j+1)^n, √n(t/b)^n}`,

and takes `A_{j,t}(y)` as the coarsest original-tree node containing `y` with `h(A)≤H_j(t)`, using the original finest-grid fallback if no light node exists. The associated source set is `Z_{j,V}(y,t)=D_V(y)∩(T_0(y)\A_{j,t}(y))` (S4). The block is therefore determined by `(ω,V,j,t,y)` before the receiver variable is integrated. The actual selector `j=j(x), t=g(x)` still picks among this family as `x` varies.

The hard-tail/tree-node qualification is recorded in R117 `rounds/117/research.zip::proof.md`, JG14 (lines 155–162): `ν_V≤ν_h=1_{t_C≤b}μ_hi` and `ν_V(A)≤h(A)` for every original forest node `A`. This is a qualification for the original hard source `ν`; it does not transfer to `β` merely from a common parent. R117's JG-B proof, lines 183–200, distinguishes a genuine light block from the finest heavy fallback: if the heavy fallback remains unchanged there are no deletion jumps, and one cannot assign it a false `h(A)≤H_j(t)` estimate; only after expansion is the terminal counted block actually light and hence bounded by `h(A_*)≤H_j(T)`.

## Kernels and usable overlap facts

R116 `rounds/116/research.zip::proof.md`, F1–F2 (lines 21–34), gives the one-dimensional definitions

`h=1_[−1/2,1/2]`, `w(v)=∫_0^1 exp(−|v|/t)dt`, `φ=h*w`, `F=max(h,φ)`, `C(d)=∫_[−1/2,1/2] F(v−d)dv`.

It states `0<C(d)≤1` and `C(d)≥(1−|d|)_+`; the dependence on `|d|` makes the overlap symmetric in the two source points. R114 S5 (lines 254–259) and R117 JG1 (lines 31–40) use products of `min(1,C(|y_i−u_i|/b)/ξ_t)` (with the corresponding `b/(c_jt)` normalization), so the raw weight is symmetric under swapping the two fixed points when the same `j,t` is held fixed. Useful consequences available directly are: for `|y_i−u_i|≤b`, `C(|y_i−u_i|/b)≥1−|y_i−u_i|/b`; each factor is in `(0,1]`; and the product weight is symmetric. No stronger all-coordinate lower bound follows from these facts alone without a bound on the coordinate distances.

## Conditioning caveat for a source-dependent split

The exact separation formula applies after fixing `y,u` from the original source/traffic, independently of the new shift. If `β,ν` or a source pair is selected by a later maximum-flow, stopping, or acceptance rule that depends on `ξ`, then the pair under consideration is no longer a fixed pre-shift pair under the unconditional phase law. To retain the source dependence jointly, one needs either to condition only on pre-`ξ` data (where the stated independence holds) or to pay/derive a bound for the `ξ`-dependent selection. The cited sources provide the unweighted fixed-pair split identity and the original source/tree qualifications separately; they do not themselves give a weighted `E_ξ` estimate that simultaneously retains arbitrary `β,ν` dependence and all later masks.
