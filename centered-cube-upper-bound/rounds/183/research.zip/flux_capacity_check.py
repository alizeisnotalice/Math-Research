#!/usr/bin/env python3
"""Bounded exact finite capacity and nested-clock checks; standard library only."""
from fractions import Fraction as F
from pathlib import Path
import hashlib,json,argparse
HERE=Path(__file__).resolve().parent
Z=F(0)
def sm(xs): return sum(xs,Z)
def fs(xs): return [F(x) for x in xs]
def enc(x):
 if isinstance(x,F): return str(x)
 if isinstance(x,dict): return {k:enc(v) for k,v in x.items()}
 if isinstance(x,(list,tuple)): return [enc(v) for v in x]
 return x

def capacity(name,stage,A,L,B):
 A,L=fs(A),fs(L); B=F(B)
 assert len(A)==len(L) and all(0<=a<=1 for a in A) and all(l>=0 for l in L) and B>=0
 thresholds=sorted(set([Z]+A)); dual=[(t,t*B+sm(max(a-t,0)*l for a,l in zip(A,L))) for t in thresholds]
 value=min(v for _,v in dual); tau=min(t for t,v in dual if v==value)
 left=B; alloc=[Z]*len(A)
 for i in sorted(range(len(A)),key=lambda i:(-A[i],i)):
  alloc[i]=min(left,L[i]); left-=alloc[i]
 primal=sm(a*x for a,x in zip(A,alloc)); layer=Z; layers=[]
 for low,high in zip(thresholds,thresholds[1:]):
  tail=sm(l for a,l in zip(A,L) if a>low); part=(high-low)*min(B,tail);layer+=part;layers.append(dict(low=low,high=high,tail_L=tail,contribution=part))
 crude_total=B*max(A,default=Z);crude_dom=sm(a*l for a,l in zip(A,L));crude=min(crude_total,crude_dom)
 checks=dict(dual_primal_layercake=value==primal==layer,allocation_feasible=sm(alloc)<=B and all(0<=x<=l for x,l in zip(alloc,L)),crude_comparison=value<=crude,complementary_slackness=all((a<=tau or x==l) and (a>=tau or x==0) for a,l,x in zip(A,L,alloc)))
 assert all(checks.values()),(name,checks)
 return dict(name=name,stage=stage,A=A,L=L,B=B,dual_candidates=dual,optimal_tau=tau,greedy_allocation=alloc,primal=primal,layercake=layer,layers=layers,capacity=value,crude_B_maxA=crude_total,crude_sum_AL=crude_dom,crude_min=crude,strict_improvement=value<crude,checks=checks,scope='Abstract finite capacity; greedy allocation not asserted realizable by a physical clock')

def clock(name,stage,nu,R,w,times,scores,deletes):
 nu,w,times=fs(nu),fs(w),fs(times);R=list(R);n=len(nu);initial=w[:];alive=[True]*n;stop=[None]*n;lam=[Z]*n;loss=[Z]*n;plus=minus=Z;jumps=[];trace=[]
 assert len(scores)==len(deletes)==len(times)-1 and all(x>=0 for x in nu) and all(0<x<=1 for x in w) and all(r in (0,1) for r in R)
 assert all(a<b for a,b in zip(times,times[1:])) and all(int(k)==k and k>=0 for pair in scores for k in pair)
 def state(ww):
  mass=[v*x*int(z) for v,x,z in zip(nu,ww,alive)]; e=sm(mass);assert e>0;return e,sm(m*r for m,r in zip(mass,R))/e,[m/e for m in mass]
 e0,bi,_=state(w);rinitial=sm(v*x*r for v,x,r in zip(nu,w,R))
 for t0,t1,ks,batch in zip(times,times[1:],scores,deletes):
  start=w[:];before_alive=alive[:];es,bs,pis=state(start);end=[x*(t0/t1)**ks[0 if r else 1] for x,r in zip(start,R)];ee,be,_=state(end);dp=max(be-bs,0);dm=max(bs-be,0);plus+=dp;minus+=dm
  nonR=sm(nu[i]*start[i] for i in range(n) if alive[i] and not R[i]);seg=[dp*nu[i]*start[i]/nonR if alive[i] and not R[i] and nonR else Z for i in range(n)]
  assert sm(seg)==dp
  for i in range(n):
   lam[i]+=seg[i]
   if alive[i]:loss[i]+=nu[i]*(start[i]-end[i])
  probes=[]
  for t in (t0,(t0+t1)/2,t1):
   ww=[x*(t0/t)**ks[0 if r else 1] for x,r in zip(start,R)];e,b,pi=state(ww);kv=[ks[0 if r else 1] for r in R];rates=[pi[v]*sm(R[u]*max(kv[v]-kv[u],0)*pi[u] for u in range(n)) for v in range(n)];total=max(ks[1]-ks[0],0)*b*(1-b)
   assert sm(rates)==total
   for i in range(n):
    share=nu[i]*start[i]/nonR if alive[i] and not R[i] and nonR else Z
    assert rates[i]==share*total
   probes.append(dict(t=t,rate_by_v=rates,total_rate=total))
  w=end;assert len(set(batch))==len(batch) and all(alive[i] for i in batch)
  deleted=sm(nu[i]*w[i] for i in batch);deletedR=sm(nu[i]*w[i]*R[i] for i in batch)
  for i in batch: alive[i]=False;stop[i]=w[i]
  ep,bp,_=state(w);jump=bp-be;assert jump==(be*deleted-deletedR)/(ee-deleted)
  jumps.append(jump);trace.append(dict(t0=t0,t1=t1,scores=ks,alive_start=before_alive,b_start=bs,b_end_before_delete=be,continuous_plus=dp,continuous_minus=dm,lambda_increment=seg,deleted=batch,signed_jump=jump,rate_probes=probes))
 eg,bg,_=state(w)
 for i in range(n):
  if alive[i]:stop[i]=w[i]
 assert loss==[nu[i]*(initial[i]-stop[i]) for i in range(n)]
 L=[x/eg for x in loss];B=rinitial/eg-bi
 # A is fixed over the whole clock and supported on actual terminal survivors.
 A=[F(i+1,n)*int(alive[i]) for i in range(n)]
 cap=capacity(name+'_capacity',stage,A,L,B);weighted=sm(a*x for a,x in zip(A,lam));DA=sm(a*x for a,x in zip(A,loss));mR=sm(v*r for v,r in zip(nu,R));saturation=lambda da: mR/eg*da/(eg+da) if da else Z; sat=saturation(DA)
 checks=dict(flux_identity=plus==bg-bi+minus-sm(jumps),source_stop_ledger=all(loss[i]+nu[i]*stop[i]==nu[i]*initial[i] for i in range(n)),per_source_domination=all(0<=x<=l for x,l in zip(lam,L)),total_RF=sm(lam)==plus<=B,capacity_payment=weighted<=cap['capacity'],survivor_A=all(not a or alive[i] for i,a in enumerate(A)),nonlinear_saturation=weighted<=sat,zero_D_branch=(DA!=0 or weighted==sat==0) and saturation(Z)==0)
 assert all(checks.values()),(name,checks)
 return dict(name=name,stage=stage,nu=nu,R_fixed=R,w_initial=initial,times=times,scores_R_nonR=scores,delete_after=deletes,trace=trace,e_initial=e0,e_g=eg,b_R_initial=bi,b_R_terminal=bg,Pplus=plus,Pminus=minus,signed_jumps=jumps,terminal_alive=alive,w_stop=stop,w_virtual_terminal=w,source_continuous_loss=loss,L=L,B=B,lambda_by_v=lam,A_fixed=A,weighted_actual_flux=weighted,capacity_certificate=cap,D_A=DA,nu_R=mR,nonlinear_saturation_bound=sat,checks=checks,scope='Exact abstract nested clock, two homogeneous score classes each segment; no physical kernel/FIRST/history qualification')

def run():
 arrays=[('single','initial',[F(2,3)],[3],1),('ties','initial',[F(1,2)]*3,[1,2,3],2),('zero_B','initial',[0,1],[1,3],0),('B_above_L','initial',[F(1,4),1],[1,2],8),('strict_improvement','initial',[1,F(1,10)],[F(1,2),2],1),('fractional_greedy','initial',[F(3,4),F(1,4),0],[1,3,5],2),('zero_L','stress',[1,0],[0,0],3),('zero_A','stress',[0,0],[2,3],1),('zero_everything','stress',[],[],0),('dynamic_range','stress',[1,F(1,2**40),0],[F(1,2**30),2**30,1],1),('small_A','expanded',[F(1,2**60),F(1,2**61)],[2**40,2**41],2**40),('many_ties','expanded',[F(i%4,3) for i in range(12)],[F(2**i,3) for i in range(12)],F(100,3))]
 caps=[capacity(*x) for x in arrays]
 clocks=[clock('continuous_R_low','initial',[1,1],[1,0],[1,1],[1,2],[(0,1)],[[]]),clock('continuous_R_high','initial',[1,1],[1,0],[1,1],[1,2],[(1,0)],[[]]),clock('mixed_batch_terminal','stress',[1]*4,[1,1,0,0],[1,F(1,2),1,F(1,4)],[1,F(3,2),2],[(0,1),(1,2)],[[0,3],[2]]),clock('near_empty_R_extinct','stress',[1,1,F(1,2**30)],[1,0,0],[1,1,1],[1,F(3,2),2],[(0,1),(1,2)],[[0,1],[]]),clock('alternating_flow','expanded',[1,2,3,5],[1,0,1,0],[F(1,2),F(1,3),F(1,4),F(1,5)],[1,F(5,4),F(3,2),F(7,4),2],[(0,1),(2,1),(2,3),(4,3)],[[1],[],[2],[3]]),clock('large_mass_ratio','expanded',[1,2**20,F(1,2**20),3],[1,0,1,0],[1,F(1,2),F(1,4),F(1,8)],[1,F(4,3),F(5,3),2],[(0,1),(1,1),(1,2)],[[1],[0],[3]])]
 clocks.extend([
  clock('partial_R_delete_target_retained','stress',[1,1,1],[1,1,0],[1,F(1,2),1],[1,F(3,2),2],[(0,1),(0,1)],[[0],[]]),
  clock('partial_nonR_delete_target_retained','stress',[1,1,2],[1,0,0],[1,F(1,2),1],[1,F(3,2),2],[(0,1),(1,2)],[[1],[]]),
  clock('concurrent_partial_delete_target_retained','expanded',[1,2,3,4],[1,1,0,0],[1,F(1,2),F(3,4),1],[1,F(3,2),2],[(0,1),(1,2)],[[0,2],[]])])
 assert all(x['weighted_actual_flux']>0 for x in clocks[-3:])
 assert caps[4]['strict_improvement'] and caps[4]['capacity']==F(11,20)
 return dict(schema='r183_flux_capacity_v1',arithmetic='fractions.Fraction; no float or quadrature',inputs={'task_contract.md':hashlib.sha256((HERE/'task_contract.md').read_bytes()).hexdigest()},capacity_cases=caps,clock_cases=clocks,summary=dict(capacity_cases=len(caps),exact_clock_cases=len(clocks),stages=['initial','stress','expanded'],all_checks_pass=True,unexpected_failures=[]),limitations=['Finite algebra only, not physical FIRST/history or general dimension bound','Abstract greedy sharpness is not dynamic realizability','A is fixed and terminal-survivor supported only for the nonlinear dynamic bound','Deleted source weights stop at deletion for L; virtual terminal values do not enter e_g'])
if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=HERE/'flux_capacity_check.json');args=parser.parse_args();result=run();args.output.write_text(json.dumps(enc(result),indent=2,sort_keys=True)+'\n');print(json.dumps(result['summary'],sort_keys=True))
