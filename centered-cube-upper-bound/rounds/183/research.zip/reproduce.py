#!/usr/bin/env python3
"""Verify compact archive, then replay exact finite checks in a fresh directory."""
import argparse, hashlib, json, pathlib, shutil, subprocess, sys
base=pathlib.Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--verify-only',action='store_true');p.add_argument('--output-dir',type=pathlib.Path);args=p.parse_args()
inv=json.loads((base/'inventory.json').read_text())
for name,sha in inv['sha256'].items():
 assert hashlib.sha256((base/name).read_bytes()).hexdigest()==sha,name
print('inventory verified',len(inv['sha256']))
if args.verify_only:sys.exit(0)
if args.output_dir is None:p.error('--output-dir is required unless --verify-only')
out=args.output_dir.resolve();out.mkdir(parents=True,exist_ok=False)
shutil.copy2(base/'task_contract.md',out/'task_contract.md')
for stem in ('flux_capacity_check','reserve_pressure_check'):
 shutil.copy2(base/(stem+'.py'),out/(stem+'.py'))
 subprocess.run([sys.executable,str(out/(stem+'.py'))],check=True)
 assert json.loads((out/(stem+'.json')).read_text())==json.loads((base/(stem+'.json')).read_text()),stem
 print(stem,'complete JSON identical')
print('Only finite algebraic evidence is verified; no general upper-bound claim.')
