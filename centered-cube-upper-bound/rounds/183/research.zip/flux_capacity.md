# R183: positive-flux capacity and an exact receiving/source tradeoff

Parent proof. Independent screening precedes author-file audit. This controls actual positive traffic and spends no signed suffix credit. It does not prove the general root budget.

## FC1 Objects and measure

Fix an original row (x,y,omega,V,j,terminal parameters). Write auxiliary time r=log t on a finite complete interval [ell,g]. The original finite source nu, nested right-continuous Z_t, and weights 0<w_t<=1 satisfy -d w_t/d log t=k_t w_t, k_t>=0 a.e., with finitely many source deletion times. e_t=int_{Z_t}w_t dnu decreases, e_g>0, and Pi_t=1_Zt w_t nu/e_t. Threshold crossings of k cause no jumps of w. Endpoint deletions are assigned once to the original one-sided interval. Let R subset Z_ell be fixed in this time, allowed to lose sources. For each v let s_v be its deletion time or g if it survives; weights at deletion use the live left value. Define w_stop(v)=w_{s_v}(v).

The true positive-flux target measure on Z_ell is

Lambda(dv)=nu(dv) int_ell^g [1_Zt(v)w_t(v)/e_t] int_R (k_t(v)-k_t(u))_+ Pi_t(du) dt/t.

All integrands are nonnegative; Tonelli applies. No assumption of independence of sources or coordinates is used. Define

L(dv)=1_{Z_ell}(v)(w_ell(v)-w_stop(v))nu(dv)/e_g,
B=N_R(ell)/e_g-N_R(ell)/e_ell,
N_R(ell)=int_R w_ell dnu.

L is finite. B>=0. R182 RF1 gives Lambda(Z_ell)<=B, including all deletion jumps. Independently,

(dLambda/dnu)(v) <= int_ell^{s_v} k_t(v)w_t(v)dt/t /e_g
                 =(w_ell(v)-w_stop(v))/e_g,

since Pi_t(R)<=1 and e_t>=e_g. Thus 0<=Lambda<=L and ||Lambda||<=B simultaneously. If e_ell=e_g then B=0, and the actual flux vanishes. This is not an assertion that every measure satisfying these two constraints is dynamically realizable.

## FC2 Exact static capacity envelope

For any fixed measurable 0<=A<=1, define

C_B(A;L)=inf_{tau>=0} [tau B+int (A-tau)_+ dL].

Then

int A dLambda <= C_B(A;L)
 = int_0^1 min(B,L{A>s}) ds
 = sup{int A dlambda:0<=lambda<=L, ||lambda||<=B}.        (FC2)

Proof: the upper dual inequality follows by A<=tau+(A-tau)_+. Layer cake gives the same upper bound because lambda{A>s}<=min(B,L{A>s}). To attain the relaxed supremum, if B>=L{A>0} choose lambda=L on {A>0}. Otherwise choose a quantile tau in [0,1] with L{A>tau}<=B<=L{A>=tau}, take all L above tau and an appropriate constant fraction of L restricted to {A=tau}. Arbitrary mass at A=0 does not change the value. The cases B=0 and L=0 are immediate. This also proves the equality of the infimum and layer-cake formula, including atoms and ties. Fractional allocation is legitimate in the relaxed measure problem; it is not a new choice of original sources.

In particular C_B<=min(B||A||infty,int A dL). It can be strictly smaller. For example A=(1,1/10), L=(1/10,10), B=1 gives C_B=19/100 whereas the crude minimum is 1. The improvement arises from enforcing both sourcewise and total budgets on the SAME flux measure, not from replacing the original traffic by an independent coupling.

The integral over s is an exact layer allocation, so there is no number-of-layers charge. However L, B, and A are actual row-dependent quantities, not already globally paid capacities.

## FC3 Actual good weight and a payable receiving part

In the original application, A_y(v)=1_good(v)rho_y(v)J_v/(3Q_v) is fixed with the original terminal data throughout t. Its support lies in Z_g. Time-dependent history, far, and score gates stay outside A; dropping them only increases positive flux. On supp A, w_stop=w_g and original good gives p_y w_g(v)<=K Q_v. Therefore

p_y A_y(v) w_g(v)<=K rho_y(v)J_v/3.

Write Gamma_y(v)=log(w_ell(v)/w_g(v))>=0 on supp A. For any tau in [0,1], with factors at A=0 set to zero,

p_y int A dLambda
 <= tau p_y B +(K/(3e_g)) int_good rho_y(v)J_v
       (1-tau/A_y(v))_+ (exp(Gamma_y(v))-1) dnu(v).     (FC3)

This uses the pointwise identity (A-tau)_+=A(1-tau/A)_+ BEFORE good comparison. It does not upper-bound Gamma, assume rho independent of y, or replace bad-edge overlap by good-edge overlap.

For reciprocal R with original K=1 (retain K for constants), R182 RF2 gives
B<=nu(R)/e_g<=1/(2K kappa_n), kappa_n=K(1+(1+1/n)^(-n))/3.
The original raw outer coefficient after the hard cap is 32Lambda0/3 (Lambda0 denotes the original scalar, not the flux measure). Thus the tau term costs at most

(16Lambda0 tau/(3K kappa_n)) E int_Erec q dx.           (FC4)

The unique original j(x) is retained until applying this row-uniform bound, so there is no j-count. Source, seed, leaf and window accounts are the original ones. For any requested receiving coefficient epsilon>0, take

tau=min(1,3K kappa_n epsilon/(16Lambda0)).

If tau=1 then (A-tau)_+=0. Otherwise FC4 is exactly at most epsilon times the receiving integral. This is a genuine paid low-A contribution for arbitrary inputs, not a claim that the rest is negligible. Each allocation epsilon is counted only once against the available receiving absorption budget.

The remainder is the explicit source-weighted integral

(32Lambda0 K/9) E int_Erec dx sum_V int_high beta(dy)/e_g(y)
 int_good rho_y(v)J_v (1-tau/A_y(v))_+
        (exp(Gamma_y(v))-1) nu_V(dv).                  (FC5)

All original gates may be retained in a sharper version; FC5 is their positive upper relaxation. Actual beta, nu, original terminal choices and Lebesgue dx are unchanged. It is NOT a proved root source price. In particular the high-column bound int_high beta/e_g<=1/(2K) cannot be applied after simply removing y-dependent Gamma and rho. A pointwise or source-integrated joint geometric bound on that actual integrand is still needed.

## FC4 Exact localization of the remaining high-share geometry

If A_y(v)>tau>0, then chi_v=J_v/(3Q_v)>tau and rho_y(v)>tau/chi_v. Since 3Q_v=p_v+pplus_v+J_v,

p_v+pplus_v < (1/tau-1)J_v.

On capture, a_y(v)=T Delta_y(v), k_v=D K0_v and the same alpha satisfy rho=(1-(k_v+alpha_y J_v)/a_y(v))_+. Hence on this support

a_y(v) > (k_v+alpha_y J_v)/(1-tau/chi_v).

This accurately couples a large good share to soft-dominated receiver response AND capture excess. The denominator is positive because chi_v>tau. Reciprocal u still satisfies the DIFFERENT-edge geometry sum_i log_+(xi_g/C_i(y-u))<log(1/kappa_n). Combining these three simultaneous constraints with the original different-forest-block condition is the remaining geometric task. None of the constraints grants independence, a cap on arbitrary shell mass, or an upper bound on Gamma(y,v).

## FC5 Verification scope

The proof is measure-theoretic and uses the already audited RF1. Finite rational tests independently compute quantile allocation, all threshold dual values and layer cake; test actual finite score clocks where flux has an exact FTC integral; retain deletion-stop weights and whole posterior normalization. Finite tests do not certify original physical kernel realization, FIRST/history, or dimension asymptotics. The claimed new content is the simultaneous capacity envelope and its fully priced epsilon-receiving decomposition, not a completed general upper bound.
