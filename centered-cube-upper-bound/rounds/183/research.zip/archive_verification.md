# R183 archive verification

Final independent audit frozen at SHA256 777af0fb599282aff4be89b446a98c5047d5f3a218759d5b6243bfb104053ed6. Author files are frozen. The final inventory hashes every archive member except inventory.json itself. The packaging script copies all final files to an external checkpoint, compares every byte, creates ZIP only from that checkpoint, checks its CRC and every extracted member against the checkpoint, and then runs reproduce.py --verify-only against the checkpoint. The short round README records the resulting ZIP size and SHA256.

External checkpoint: /Users/zhengzhihao/Desktop/T/output/centered_cube_round183_20261016_final_checkpoint.
Independent numeric replay and reproduction-driver runs are recorded in parent_verification.md. No PDF was produced. Only the short round README, research.zip and project latest pointer are included in this research commit; no old-round files or other projects are changed. The redundant own untracked work directory is removed only after all backup and ZIP checks succeed.
