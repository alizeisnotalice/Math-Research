# R183：同一 RC 储备与 current 容量的联合加权几何预算

本文给出原互反 bad 正交通的一项无条件**加权** companion 预算，因而支付一个由物理核显式定义的正子支。它利用同一个实际 alpha 与同一来源的两种容量；不假定 beta≥nu，不优化或更换 alpha，不要求 Jnu≤q。实际未加权互反交通仍有明确补集，严格覆盖扩大及一般根阶结论均未证明。

## JG1. 原对象、来源与范围

固定一个原 (omega,V,a,b,q) 窗口及其真正唯一尺度标签 j(x)，a≤L,R≤b≤2a，s 为原 FIRST 选择。记

    p_z=P_(s,L)(x−z),  J_z=P_(1,b)(x−z),
    Lplus=min(b,(1+1/n)L),
    Q_z=(p_z+P_(s,Lplus)(x−z)+J_z)/3,
    QJ=∫J_z nu(dz).

nu=nu_V、beta=beta_V 是原有限正来源，分别受共同父来源 A_V 支配；没有 nu≤beta 的前提。对原实际接收 x，FIRST 给 P_(s,L)*f(x)=q>0，并对下述合法 K0 给 K0*f(x)≤q。因 nu≤f，beta≤f，

    ∫p_z nu(dz)≤q,       ∫p_y beta(dy)≤q.                 (JG1)

准确窄定位：R107 research.zip 内 proof.md 的 R1（905–913）给共同 q、Pcurrent f=q、sigma≤mu_hi≤f；nu≤sigma 由 R112 J1–J3 及 R181 CP 的来源链继承。R113 B2 与 R181 common_parent_budget 的 CP 给 beta,nu≤A 及全局 Wnu≤WA≤||f||1。每个固定窗口的 Wnu=E_omega Σ_V||nu_V||。不同时独立重跑的窗口没有免费共同质量账。本文不由 Q 的平均定义推导 Jnu≤q；即使只知 Qnu≤q，也只能由平均推出 Jnu≤3q，而非≤q。

物理核 h=1_[−1/2,1/2]、phi=h*w，P_(s,H) 为缩放后的 n 维混合乘积。实际严格软范围内 p,J,K0,Q 在有限位置均正。所有 dx 始终是原接收域上的 Lebesgue 测度，直至 JG9 明确使用固定 J 的正核积分。

## JG2. 真正 capture、bad 与尺度系数

沿用 R128 RT4–RT6 和 R182 JK 的原系数。gamma=1+1/n，c_j=gamma^(−j)，g=√(LR)，ell=1+log n，

    T=c_j^(n/2)/(g^n√ell),
    H0=g c_j^(−1/2)(1−s+s phi(1/2)) ell^(1/(2n)),
    Hhat=max(a,min(b,H0)),        K0_z=P_(s,Hhat)(x−z),
    k_z=D K0_z,                  D≥1.

D 是原 epsilon_RC 继承的常数，不是本稿新选参数。写 tau=a/c_j，hstop 为原 far 终点（原式 g exp(−u/n)，其中原 u 在选来源前已固定），

    Delta_y(v)=w_tau(y,v)−w_hstop(y,v),
    a_v=T Delta_y(v),           0≤a_v≤T.

hstop≤tau 时没有非零 far 贡献；非空 far 中保留原两个端点及所有支持。E_y 是原 capture 集（terminal 来源、基本 good 及原 Delta>0 等资格）；B_y 是原实际 bad 集，两者不交。原 RC 系数和残余为

    U_y(v)=1_Ey(v) min(a_v,k_v),
    alpha_y QJ=Dq−∫U_y(v)nu(dv),
    rho_y(v)=[1−(k_v+alpha_y J_v)/a_v]_+  on E_y,
    rho=0 elsewhere, including a_v=0.                       (JG2)

K0 是相同 s、合法 Hhat∈[a,b] 的 FIRST 测试，故 k nu≤Dq，alpha≥0。因为 B∩E=∅，保持同一个实际 alpha 得

    ∫_B k_u nu(du)≤alpha QJ.                                (JG3)

实际上 alpha QJ=(Dq−k nu)+∫_E(k−min(a,k))nu+∫_(E^c)k nu。不能把 bad 换成全部 u。rho>0 的 target 保留原 good、capture 与所有历史门。原良槽关系为

    p_y w_g(y,v)≤K Q_v,       A_y(v)=1_good rho_y(v)J_v/(3Q_v).

实际 K=1；写 K>0 只为追踪已经存在的常数，不授权改变 K。

## JG3. 联合消去 alpha，但不遗失来源正常化

R182 的确切联合核是（QJ>0、alpha>0 时）

    S_y(v)=1_E alpha J_v rho_y(v)^2,
    mu_y(du)=k_u1_B nu(du)/(alpha QJ),
    S_y(v)nu(dv) mu_y(du)
      =(J_v/QJ)1_E rho_y(v)^2 nu(dv) k_u1_B nu(du).          (JG4)

alpha=0 时 JG3 使 bad 的 k nu 质量为零，整个联合核定义为零。本稿对该联合核回代实际 posterior；不是先分别估计 S 与 mu 后引入 1/alpha。尤其在只使用 current 容量的扩展代数合同中，QJ/q 没有所得的统一上界，下面显式保留并抵消该压力。R128 RT5 原文另列 Jnu≤q；本文不使用该项，并不证明实际完整物理合同中 QJ/q 可以任意大。

## JG4. 互反 bad、high 与唯一 current 容量

设 xi_t=c_jt/b，

    w_t(y,z)=∏_i min(1,C(|y_i−z_i|/b)/xi_t),
    Pi_y,t(dz)=1_Zy,t(z)w_t(y,z)nu(dz)/e_y,t.

原 eligible t≤g，e_t≥e_g，w_g≤w_t≤1，high 是 p_y e_g≥2Kq。原基本 bad 为 b_x(y,u)=1{p_y w_g(y,u)>K Q_u}；本文再限制互反 R(y,u)=b_x(y,u)b_x(u,y)。其余原 bad/terminal/history 条件保留，不要求转置后具有原资格。

径向单调及 Lplus≤gamma L 给 Q_z≥d_n p_z，其中 d_n=(1+gamma^(−n))/3。置 kappa=K d_n。kappa≥1 时互反集为空；以下假设 kappa<1（原 K=1 满足）。两条严格 bad 给

    w_g(y,u)>kappa,
    kappa/w_g(y,u)<p_y/p_u<w_g(y,u)/kappa.

因此在原 high 互反行上

    1/(e_t p_u)≤p_y/(2Kq p_u)
                 ≤w_g(y,u)/(2K kappa q).                 (JG5)

这一步没有把 good target v 的重叠换成 bad source u 的重叠。

## JG5. 联合 source 行不等式

固定 target v、实际 x,y,t 及所有共同数据，先固定 r∈(0,1]；r 不得依正在积分的 u。利用 JG5、w_t w_g≤1，同一 nu 上的 Holder 不等式给

    ∫_(B∩R) (k_u/p_u)^r Pi_y,t(du)
      ≤(2K kappa q)^−1 ∫_(B∩R) k_u^r p_u^(1−r) w_t w_g nu(du)
      ≤(2K kappa q)^−1 (∫_B k_u nu)^r(∫p_u nu)^(1−r)
      ≤(2K kappa)^−1 (alpha QJ/q)^r.                      (JG6)

r=1 为线性积分；0<r<1 用 Holder 指数 1/r 与 1/(1−r)，无需来源独立。原 Z、额外 pair 门或分数门仅正向扩大，不重新定义 Pi 或 alpha。r=0 时同一计算直接给 Pi(B∩R)≤1/(2K kappa)，不需定义 0^0；这也等于只用 current 容量的端点。

写 d_v=[1−k_v/a_v]_+。在 active target 上 rho=(d_v−alpha J_v/a_v)_+。令

    c_r=4r^r/(r+2)^(r+2) (0<r≤1),       c_0=1.

对实际 alpha≥0，

    alpha^r rho^2≤c_r(a_v/J_v)^r d_v^(r+2).               (JG7)

证明：d_v>0 时令 z=alpha J_v/(a_v d_v)，则只需最大化 z^r(1−z)^2，0≤z≤1。导数为 z^(r−1)(1−z)[r−(r+2)z]，最大值在 z=r/(r+2)，即 c_r；d_v=0 时两边零。r=0 只用 rho²≤d_v²。此标量极值是对同一实际 alpha 的上界，不允许在来源间重新选 alpha。JG6 与 JG7 合为

    rho_v²∫_(B∩R)(k_u/p_u)^r Pi(du)
      ≤c_r/(2K kappa) (QJ/q)^r(a_v/J_v)^r d_v^(r+2).    (JG8)

这就是实际 reserve 与 current 源容量的联合机制；直接丢弃 (QJ/q)^r 一般错误。

## JG6. 可真正支付的物理加权 companion

在 active target 槽定义无量纲物理比

    Rbase(v,u)=(k_u/p_u)(J_v/a_v)(q/QJ),
    G_r(v,u)=w_g(y,v)^2 Rbase(v,u)^r,
    F_r(v,u)=G_r(v,u)/c_r.                                (JG9)

r=0 时定义 F_0=w_g(y,v)^2，即使某个抽象扩展的 Rbase=0 也不改此定义。实际 strictsoft 正源上比值均正常。非capture、a_v=0 或 rho=0 槽的**加权被积式**直接定义为零，先处理零槽再相乘，绝不构造 0×∞。QJ=0 的实际正 J 来源行有 nu=0，无交通；alpha=0 的 bad 槽由 JG3 为零。q>0、p_u>0 是原有效行资格，本稿不推广到任意带零 p 的抽象数据。

用 H∈[0,1] 记录全部原 receiver、high、good、capture、bad、reciprocal、score、terminal、history、unique-j、时间与剩余子支门。加权实际 companion 定义为

    C_rec[F_r]=E Σ_(V,j) ∫1_{j(x)=j} dx ∫beta(dy)∫_far dt/t
       ∬ H [p_y²rho_v² J_v/(9Q_v²)] F_r(v,u) Pi(dv)Pi(du).

不将 H 的 u 依赖提出积分。对每个 target，在给正上界时丢掉 H 的部分额外门；应用 JG8 后，JG9 的 (J_v/a_v)^r(q/QJ)^r 与压力精确抵消，得到

    rho_v²∫_(B∩R)F_r(v,u)Pi(du)
       ≤w_g(y,v)^2 d_v^(r+2)/(2K kappa).

再用原 good 而非 bad 关系 p_y w_g(y,v)≤KQ_v，得到实际行上界

    ∫ H [p_y²rho_v² J_v/(9Q_v²)]F_r(v,u)Pi(du)
       ≤ K J_v/(18 kappa).                               (JG10)

所有 a,J,p,k 都来自同一个原 x 和同一组 y,v,u；没有独立好槽替换。D 与 T 的量纲都保留在 Rbase 中，没有用 inverse K0、inverse alpha 或来源无权质量的上确界。

## JG7. r 可随 target 选择的准确范围

JG6–JG10 对每个 v 在 u 积分前固定 r 成立。因此可用任意可测 r=r(x,y,t,v;共同原数据)∈[0,1]，它不依当前 u，且逐 target 使用相应 c_r。无需有限 r 菜单费；JG10 的上界已独立 r，后续空间/时间积分不对 r 求导。固定的概率混合也可用 Tonelli 同价支付。

这**不**支付逐 pair 的 sup_r F_r(v,u)，不允许让 r 根据当前 u 优化后再套 Holder。r 的 t 依赖只用于正 companion，不可移用于要求 terminal A 时间固定的原 FTC。下文记 F 为任一上述合法 F_r；固定 r=1 已给一个完全显式分支。

## JG8. 原 high 列与全局来源账

在固定 x,V,j,t，先保持原 high；利用 e_t≥e_g、w_t≤1 后，

    ∫_high beta(dy) ∫J_v Pi_y,t(dv)
       ≤(J*nu)(x) ∫_high beta(dy)/e_g(y)
       ≤(J*nu)(x)/(2Kq) ∫p_y beta(dy)
       ≤(J*nu)(x)/(2K).                                 (JG11)

这里的 (J*nu)(x) 指 ∫P_(1,b)(x−v)nu(dv)，不是把 Q 或 a 当归一核。共同父来源足够支持 beta 的 high 列和 nu 的固定核列；无需 nu≤beta、signed 差为正或每叶 lambda b^n 帽。

## JG9. 实际时钟、j 与 Lebesgue 接收积分

把每个原 far 域写为其实际 xi=c_jt/b 子域，dt/t=d xi/xi，保留原 1_{j(x)=j}。由合法物理窗口，eligible xi∈[1/2,1]；JG10–11 后的正上界已不依 t,j。因此**此时**才扩到共同 [1/2,1]，长度 log2，再使用 Σ_j1_{j(x)=j}≤1。不能先放大不同 j 的原核再声称 j 消失。

b 为该原窗口的共同固定尺度；于是将正固定 J 列的 dx 扩到全空间，Tonelli 与 ∫P_(1,b)=1 给 ∫dx(J*nu)(x)=||nu||。结论是

    C_rec[F] ≤ log2/(36 kappa) Wnu ≤ log2/(36 kappa) WA.   (JG12)

这已经支付共同自适应 s(x),L(x) 对**此加权原 companion**的选择费用，因为它们在正扩大前通过实际 high/good/current/reciprocal 关系被消去了；不是逐固定 s,L 卷积界后免费取 sup。没有 Jnu/q 上界、额外 future 菜单或来源层数费。独立窗口若复用同一来源，JG12 要按窗口真实求和，不能再次宣称 Wnu≤||f||1 只收一次。

固定 r 不归一的旧记号满足

    C_rec[G_r]≤c_r log2/(36 kappa)Wnu;
    c_1=4/27,     C_rec[G_1]≤log2/(243 kappa)Wnu.         (JG13)

## JG10. 原正 raw 的一个实际根阶子支

预先固定 theta>0，在此前尚未支付的原互反正交通上取物理门 F≥theta。原非负 companion 满足 C_branch≤C_rec[F]/theta。R173 单向实际能量经 R181 共同父修复为

    E_J=EΣ_(V,j)∫1_j dx∫high beta(dy)∫actual dt/t
          ∬ H J_v(k_t(y,v)−k_t(y,u))_+² Pi(dv)Pi(du)
       ≤n Wnu/(2K).

只用单向能量，没有将 J_v 搬到 u 或支付完整双向 score 能量。该式保留实际 dx/high，依据 k²≤nk、∫k²w_t dt/t≤n、fixed J 列及唯一 j；原 hard 帽已经只移除一次。Cauchy 两边共享同一个正切片（分数门各取平方根），恢复 hard16/3 与外 2Lambda 各一次，得到

    Raw_rec^+[F≥theta]
       ≤(32Lambda/3)√[n log2/(72K kappa theta)] Wnu
       ≤(32Lambda/3)√[n log2/(72K kappa theta)] WA.         (JG14)

对未归一 G_r≥theta0，theta=theta0/c_r；对应 RHS 根号内乘 c_r。r=1 即

    Raw_rec^+[G_1≥theta0]
       ≤(32Lambda/3)√[n log2/(486K kappa theta0)] WA.       (JG15)

这是一条原模型中不附未知 posterior 假设的可支付几何子支。若 theta 固定，其价格为根阶；theta 随维数变小则须支付 theta^(−1/2)。不存在免费证明 F 普遍有下界的步骤。原 NB 冻结若需回代，必须在同门下保留已审的两槽 Radon–Nikodym 乘积价格至多 exp(4epsilon0)（companion），以及原 receiver 误差；不能把该价格当作额外免费吸收信用。

## JG11. 与 R175 原 K0/w_t cut 的准确比较

R175 reserve cut 使用原 bad 源 K0_u/w_t(y,u)≥M(v,t)，通过 bad k nu≤alpha QJ 与同 alpha 标量包络支付。其 cubic exact 阈值为

    M_cap^exact(v,t)=4p_y² a_v d_v³ QJ/
                       (243D Lcap² Q_v² e_t J_v).

这一保留 QJ/e_t 的式子可直接从同 reserve 推得；把它换成只含 p_y 的粗阈值，需要旧稿另用的 Jnu≤q 资格。本文的新主结论完全不需要该容量；不以 Q 的平均免费补出它。sharp 版本也可保留精确 h=d_v a_v QJ/(D e_t M J_v)，再用其已审分段包络，而不先丢正常化。

在互反 active pair 上设

    L_v=(27/4)w_g(y,v)^2 D J_v q/(QJ a_v p_y).

则新 r=1 归一权重精确为

    F_1=L_v (K0_u/w_t(y,u)) [p_y w_t(y,u)/p_u].

JG5 的双侧原互反关系与 w_g≤w_t≤1 给

    kappa≤p_y w_t(y,u)/p_u≤1/kappa,
    kappa L_v(K0_u/w_t)≤F_1≤L_v(K0_u/w_t)/kappa.         (JG16)

因此 K0_u/w_t≥theta/(kappa L_v) 足以触发新门；新门则必要 K0_u/w_t≥kappa theta/L_v。它在互反区域确实可译成由原同三点核给定的两侧阈值比较，但 L_v 不是旧 M_cap 或 M_sharp。没有证明二者存在普遍包含关系，更没有证明新门严格覆盖旧低捕获补集的一块原可实现交通。新步骤是互反 current 容量与 reserve 的 Holder 联合，并以原 good 权重和显式 q/QJ 配平；不是重新报告原 cubic，亦不是取代旧 cut 的一般更强定理。

若旧分支已领价格，应只对其补集再取新门，写成互不相交的正分割。对于任一旧已付集合 O，

    Raw_rec^+=Raw_rec^+[O]+Raw_rec^+[O^c∩{F≥theta}]
                          +Raw_rec^+[O^c∩{F<theta}].

JG14 只收第二项的新增来源价；第三项原位保留。没有再次领取已消费 suffix、反向信用或其他 signed 负项。

## JG12. 有限精确核验接口与尚未付款的量

r=1 的标量 equality 在 alpha J_v/a_v=d_v/3：alpha rho²=(4/27)(a_v/J_v)d_v³。对共同 reserve 数据统一缩放 J→tJ，QJ→tQJ，alpha→alpha/t，则 alpha QJ、alpha J_v、rho、S、mu 及 qJ_v/(QJ a_v) 都不变。故 JG8 中 QJ/q 与 JG9 中 q/QJ 精确抵消；删掉压力的错误 RHS 不具这个不变性。这给小型 Fraction 检查一个可复现接口。它只是同 reserve 代数的齐次检验，统一缩放后的 J 不是另一个已归一物理核，因此不能据此声称全物理 FIRST/reciprocal/history 例已经构造。数值所有零分母须先分支，不以浮点微正数替代。

保留下来的实质缺口为：原未加权 good-v/bad-u 三点交通在 F<theta 的部分；非互反 bad；原其他 mother shares；独立窗口重复来源费；NB 原 receiving 误差与未付核乘子。新 target-adaptive r 也不能免费取 u-dependent 最优包络或证明这些补集小。既没有一般 receiver epsilon 吸收，也没有证明全原 companion 为 polylog 来源价，故一般 FULL/L1 根阶目标仍未完成。
