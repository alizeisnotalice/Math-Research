# R183 exact finite flux capacity checks

All 21 cases pass: 12 abstract capacity arrays and 9 exact nested-deletion clocks, in initial/stress/expanded stages. Arithmetic is exclusively `fractions.Fraction`; there is no quadrature, floating-point tolerance, or fitted asymptotic claim. These are finite algebra certificates, not physical kernel/FIRST/history examples or a general centered-cube bound.

For finite nonnegative L,B and fixed 0≤A≤1, the checker independently computes:

- dual: minimum of τB+Σ(A−τ)+L over τ∈{0,A_i};
- primal: descending-A greedy allocation 0≤λ_i≤L_i, Σλ_i≤B;
- layercake: exact interval sum of min(B,Σ_{A_i>s}L_i).

All three agree exactly and the greedy allocation satisfies complementary slackness. Zero B, zero L, zero A, empty arrays, B exceeding total L, ties, small A, and weights spanning powers 2^-30 through 2^41 are included. For A=(1,1/10), L=(1/2,2), B=1, the sharp capacity is 11/20, strictly below min(B max A,ΣAL)=7/10. Its greedy allocation is an abstract sharp witness; it is not asserted realizable by an original physical clock.

## Exact clock integration and retained costs

The first six clocks reuse the explicit rational parameter lists of R182's deletion checker, copied into this self-contained file; three further clocks retain positive-weight terminal targets after partial R, partial non-R, or concurrent mixed deletion. No old JSON or code is a runtime dependency. R is a fixed source label including later-deleted sources. On each interval each class R/non-R has one nonnegative integer score, and w_i(t)=w_i(t0)(t0/t)^k. All receiver normalizers use the full actual surviving set. Concurrent deletions are applied once, including terminal deletions.

Within an interval the non-R source share ν_vw_v/Σ_nonRνw is constant. The positive rate at v is this share times (k_nonR−k_R)+ b_R(1−b_R), while every R target has zero positive rate. The exact derivative db_R/dlogt=(k_nonR−k_R)b_R(1−b_R) therefore gives the per-v integral as its share times max(b_R(end−)−b_R(start+),0). This is a rational FTC calculation; start/middle/end rate identities separately check the full double sum against the class formula. It would be invalid for heterogeneous scores within a class.

Every clock checks the signed deletion identity P+=b_g−b_initial+P−−ΣΔb, per-source stopping ledger, Λ_v≤ν_v(w_initial−w_stop)/e_g, and ΣΛ≤B=initial_R_weight/e_g−b_initial. Deleted sources' virtual terminal weights are recorded but do not enter e_g or the loss payment. The capacity uses all L slots; fixed A_i=(i+1)/N on actual terminal survivors and zero otherwise, so deleted slots contribute no weighted traffic.

The additional denominator-preserving bound uses D_A=Σ Aν(w_initial−w_g), m_R=Σ_Rν and checks

`Σ AΛ ≤ (m_R/e_g) D_A/(e_g+D_A)`.

The zero-D branch returns zero before division by D_A. This dynamic estimate is checked only on actual clocks with fixed survivor-supported A, never on arbitrary greedy λ. Both this estimate and capacity are retained separately; no numerical ordering between them is presumed.

| Clock | Actual weighted flux | Capacity | Saturation bound |
|---|---:|---:|---:|
| continuous R low | 1/6 | 1/6 | 1/6 |
| continuous R high | 0 | 1/12 | 2/21 |
| mixed batch and terminal deletion | 0 | 1/6 | 16/21 |
| near-empty, R later extinct | 536870912/5764607527866073089 | 5/3 | 5368709120/3 |
| alternating four segments | 0 | 2871/4900 | 94076928/9519475 |
| large mass ratio | 0 | 3/8 | 18874386/11 |
| partial R deletion, target retained | 149/910 | 1/2 | 2/3 |
| partial non-R deletion, target retained | 1/7 | 8/21 | 16/51 |
| concurrent mixed partial deletion, target retained | 46/407 | 64/99 | 28/39 |

The first clock attains both bounds exactly. The last three deletion clocks all have strictly positive weighted flux, certified by explicit assertions, and recompute each non-R target share on every interval after the alive set changes. Their score pairs are respectively (0,1)/(0,1), (0,1)/(1,2), and (0,1)/(1,2); the deleted non-R targets receive fixed A=0 because they are absent from the terminal support. The near-empty case preserves a positive weighted flux despite R becoming extinct, and also shows that both budgets can be very loose when e_g is tiny. The zero weighted values in the deletion stresses arise from the actual terminal support restriction; they are not evidence for a physical traffic estimate. No source envelope, receiver measure, dimension price, or physical qualification is discharged by these finite checks.

## Reproduction

Run with Python 3 (standard library only):

```sh
python3 flux_capacity_check.py
```

The script writes adjacent `flux_capacity_check.json`; `--output /tmp/result.json` redirects only the output. Adjacent `task_contract.md` is the sole runtime input and its SHA256 is embedded under a portable filename key. Assertion failure exits nonzero. Isolated replay copies only the script and contract outside the repository and compares the complete JSON, with no ignored mathematical fields.
