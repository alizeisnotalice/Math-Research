# R183 独立预检与后审

本文件仅审本轮明确命题；不改作者文件，不运行数值，不Git/spawn/PDF。先独立推导，再读作者证明。当前第一阶段未读取本轮作者稿；只读父级准确候选消息、后落盘的task_contract.md，及原R128 RT2/RT4–6定义。R182结论使用已冻结版本，不重证已付RF。

## 1. 原固定A的量词与边界

固定完整实际行（x,y,omega,V,j及原硬来源/历史参数），再积分辅助t。原RT6的Delta=w_tau−w_h、T、K0、J、Q、capture E及同alpha=(Dq−∫Emin(TDelta,DK0)ν)/Jν均由该行端点确定，不随辅助t重选。原RT2目标v在S_g中，故有效A(v)=1_good rho(v)J(v)/(3Q(v))满足0≤A≤1、supp A⊂Z_g，且在本条clock内固定。此A可依receiver、源y、terminalg和同alpha；并不因此独立x或可移出接收积分。

原FA、Psi、其他history及时间资格一般仍依t/v/u。它们不属于上述固定A；若作正上界可丢[0,1]门，不能把它们无说明并入A再求导。若改变y、冻结中心或人为沿t重算alpha，须另记A交换，不能继承下面的固定A身份。eg=0行原high为空；所有除eg限eg>0。

## 2. 作者前自证：带权通量及真实source损失

写dσ=dlog t，k_t≥0、∂σwt=−ktwt，Zt嵌套，et=∫Ztwtν≥eg>0。R⊂Z_ell时间固定、允许后来删除。定义

    Λ(dv)=∫_ell^g Πt(dv) ∫R (kt(v)−kt(u))_+ Πt(du)dσ.

对任意固定非负A≤1，用(kt(v)−kt(u))_+≤kt(v)、Πt(R)≤1和et≥eg，有测度支配

    Λ(dv)≤L(dv):=eg^−1 1_Zell(v)
                    [well(v)−w_stop(v)]ν(dv).                 (I1)

stop是v的原删除时刻截到g，wt自身连续；逐source积分只到stop。对原有限跳删除可直接Fubini；更一般嵌套可测支持只要其存活时刻区间/stop可测，该正上界仍由Tonelli成立，不需要把连续杀死误写成删除和。L有限，因为wt≤1、ν有限。由已证RF1另有

    Λ(total)≤B:=N_R(ell)/eg−b_R(ell)
                =N_R(ell)(1/eg−1/eell)≥0.                   (I2)

(I2)在本轮实际原有限树版本使用RF1完整删除；不借原signed负信用。于是先已得安全的min{||A||∞B,∫A dL}，无n/clock长，但两个真实势的source/receiver费用仍在。

特别原A支持Zg，target v全程存活；故

    ∫A dΛ≤[C_A(ell)−C_A(g)]/eg,
    C_A(t)=∫A(v)wt(v)ν(dv).                                (I3)

这里没有target删除费用；R仍可删。对一般固定A，不能把w_stop免费换wg，或把已删source的虚拟wg算幸存质量。若改用A_t，积分∫A_t ktwt另出现∫alive wt dA_t，跳同刻需约定先后，不能删除其正变差。

还有准确连续signed身份。F_A=Πt A、b_R=Πt1R，则

    Φ_A,R+−Φ_A,R−=F_A b_R'−b_R F_A'.                         (I4)

这是由F_A'=mF_A−Πt(Ak)、b_R'=mb_R−Πt(1Rk)直接消去m所得；并非完整删除后的无跳望远镜。一次删除总质量d、R质量r、A质量d_A，删除前总质量e时

    Δb_R=(b_R d−r)/(e−d),
    ΔF_A=(F_A d−d_A)/(e−d).

原terminal A有d_A=0，但ΔF_A可正，仍不能漏该归一跳。若A_t变动，I4右侧另加b_R Πt(dot A_t)。

## 3. 父精确capacity候选的独立筛查（先于父稿）

(I1),(I2)的准确静态交集给

    ∫A dΛ ≤ inf_(τ≥0){τB+∫(A−τ)_+dL}
            =∫_0^||A||∞ min{B,L(A>s)}ds.                   (I5)

自证上界：0≤λ≤L、λ(total)≤B时，∫Aλ≤τB+∫(A−τ)+L。若B≥L(A>0)，取λ=L在A>0上即达值，τ=0。若B=0，取λ=0。其余取分位τ满足L(A>τ)≤B≤L(A≥τ)，在A>τ上取全部L、A=τ层取足够分数、其余0；恰达质量B和该对偶值。层积分在s<τ为B、s>τ为L(A>s)，给右端。A=0或上端本质上确界未取到不造成问题；阈值层允许分数密度，不要求原子可分割为集合。此证明只说所有支配测度λ的精确sup，不说原物理Λ能实现最优λ。

(I5)保留A分布、无layer计数费，可强于§2粗min；其依据是RF1与source-loss的联合约束，不是R170 signed边界已经支付原正交通的新证明。真实A/Γ/source成本仍待后审，不登记general根价。

设Γ(v)=log(well(v)/wg(v))。原good p_y wg(v)≤KQ(v)给，对每τ≥0，

    p_y∫(A−τ)+dL
      ≤K/(3eg)∫good rho(v)J(v)(expΓ(v)−1)
                         (1−τ/A(v))_+ ν(dv),              (I6)

A0处因子0。此处eg不可漏；Γ和A tail皆依原receiver/terminal，不能将其换成fixed-J全局常数。上式可正上放为1{A>τ}，但失去的信息是明确正放松，不是已付列界。

对互反R，已证B≤1/(2Kκ_n)。固定τ截断min(A,τ)部分的原正raw可付

    (16Λ/(3Kκ_n)) τ E∫_Erec q dx.                          (I7)

其余(A−τ)+仍乘全部原门，以I6为候选接口。τ可依原行选择但固定于该行clock，若用统一τ≤3Kκ_n ε/(16Λ)，I7≤ε E∫q；不能把选择τ本身或余项记作全局闭合。此处q始终原共同固定阈值，R107 R1的current完整输入身份和同窗口Σβ≤f支撑原FIRST容量。

## 4. Astra分母补偿候选的独立筛查（先于作者稿）

固定0≤A≤1且suppA⊂Zg，写G(t)=C_A(t)、D_A=G(ell)−G(g)≥0。e_t−G(t)=∫Zt(1−A)wtν非增，所以

    et≥eg+G(t)−G(g).

令r=N_R(ell)（安全可上放νR），用N_R(t)≤r、δ+≤kv得

    ∫A dΛ≤r∫_ell^g[−G'(t)]/[eg+G(t)−G(g)]² dlogt
            =(r/eg) D_A/(eg+D_A).                         (I8)

G无target删除，AC换元充分；分母正，D_A=0直接为0。R所有删除只使N_R下降，已在r上界内，不另收一次RF删除费。还由D_A≤eell−eg，I8≤r(1/eg−1/eell)=B，故该更精确初始加权r版改善RF1而不矛盾；作者νR版则较松。它与I5互为可用上界，未证明谁一般支配谁，不将两种同正项预算相加为双重付款。

若A不支持Zg，G会有删除损失、e−G虽仍非增却不能把全部G损失当score连续量的等式；用此换元须加/处理删A的具体项。若A_t或同alpha沿clock改动，更不能使用本固定A推导。原实际A满足资格，但D_A/eg要通过真实三点RC几何/接收积分支付；仅小于1的饱和因子不自动给任意ε或根阶来源价。

## 5. 本阶段状态

task_contract.md落盘后已实读，与以上固定对象和费用限制一致。作者证明尚未读取；此为作者前独立检查点。允许后续准确稿一次后审其证明、原alpha与支持、dx/j/窗口及有限数值标签。当前不认证整体middle或一般弱型上界，交付检查点后等待明确稿，不自行扩展。


## 6. Sol weighted reciprocal Hölder候选：作者前独筛

收到准确公式后、未读作者稿，独立核如下链。原reciprocal Rbad固定，p_u>κ_n p_y，et≥eg、high p_yeg≥2Kq，故

    1/(et p_u)≤1/(2Kκ_n q).

用k=DK0、∫Rbad kν≤alpha QJ、原current∫p_uν≤q，对固定r∈(0,1]的同ν Hölder得

    ∫Rbad k^r p_u^(1−r)ν≤(alpha QJ)^r q^(1−r),
    ∫Rbad (k_u/p_u)^r Πt(du)
       ≤alpha^r (QJ/q)^r/(2Kκ_n).

这里wt≤1正上放一次；原H若依u，先保留后正上放，不把它错误提出u积分。同alpha的标量极值为

    alpha^r rho_v²≤c_r(a_v/J_v)^r d_v^(r+2),
    c_r=4r^r/(r+2)^(r+2), d_v=(1−k_v/a_v)_+.

因此对明确物理权重

    G*_r=wg(y,v)²[(k_u/p_u)(J_v/a_v)(q/QJ)]^r

乘原companion，QJ/q准确相消；good p_y wg_v≤KQ_v给行价K c_r/(18κ_n)∫J_vΠt(dv)，丢d_v≤1。原high列∫β 1_high Πt(dv)≤ν(dv)/(2K)，因为Π密度≤p_y/(2Kq)、Σ∫p_yβ≤q。用共同ξ=c_jt/b∈[1/2,1]换元保留原1{j(x)=j}，逐ξ求和后再用fixedJ的真实dx归一，得到

    C_(rec,G*)≤c_r log2/(36κ_n) Wν.                         (I9)

若先扩每个j不同的t窗再直接删Σj，则该无层费不成立；作者须显写共同ξ。QJ>0、a_v>0、p_u>0只在非零原reciprocal/capture槽上用除法；alpha0由bad kν0使G* joint贡献0。a0 target余权0，QJ0是原零来源行。q/QJ是G*不可省的显式权重，不是已被删除的倒数费用；本候选不需要额外假Jν≤q。

对子支G*_r≥θ>0，正CS的companion≤I9/θ，原fixedJ平方能量≤nWν/(2K)给

    Raw_sub≤(32Λ/3)sqrt[n c_r log2/(72Kκ_n θ)] Wν
           ≤同系数 W_A.                                  (I10)

这里只支付一个固定r、θ的准确正子支；G*<θ及非reciprocal补集保持，原负项未消费，多个r菜单和其他窗口不能免费叠加。I9–10须作者全文落实原同alpha、support及time/j后方可登记最终付款。与旧R175物理cut是否严格扩大覆盖尚未证明；目前仅认证上述准确新weighted-companion接口，不因此认一般覆盖。

## 7. Astra完整缺额与near-saturation候选：作者前独筛

继续固定§4的terminal A、N(t)=∫R∩Zt wtν、z=G−Gg，定义连续phi(t)=eg^−1−(eg+z)^−1≥0、phi(g)=0。准确分解为

    I=Nell phi(ell)−L_R−M−L_den,
    L_R=∫_(ell,g]phi(t)(−dN(t)),
    M=∫dlogt∫A(v)1R(u)min(kv,ku)Πt(dv)Πt(du),
    L_den=∫N(t)(−dG(t))[(eg+z)^−2−et^−2].                 (I11)

证明先用δ+=kv−min得I+M=∫N(−dG)/et²，加L_den后为∫N(−dphi)。phi连续，BV分部无jump乘积遗漏，终端phi0，得Nell phiell−∫phi(−dN)。全部扣项非负，R连续衰减及并发/末端删除均在dN内，末端删除因phig0不重复收费。M为本identity的min-score overlap，不是原负交通信用；原H或paircut补集只能先正上放至完整I后使用本上界，不能越支扣掉M等项。

U=Nell phiell>0且I≥(1−ε)U时，各L_R/M/L_den≤εU。θ∈(0,1)给

    ∫_{z≥θD_A}(−dN)
      ≤ε Nell(eg+θD_A)/[θ(eg+D_A)].                        (I12)

令dH=N(−dG)/(eg+z)²、s=(et−eg−z)/(eg+z)≥0，则

    H{s≥h}≤εU/[1−(1+h)^−2], h>0.                          (I13)

分别来自phi(z)单调和L_den=∫[1−(1+s)^−2]dH，均为必要条件而非充分/免费小门。U0/D_A0直接零支，不用相对除法。加权真实原外pβdx可以逐行合并，须先保证总U有限或用原有限截断；reciprocal high下U≤RF B≤1/(2Kκ_n)可提供原有限接收域可积。若保留原mask，另加I−I_original≥0作为第四项，不能把它当已付的历史费用。当前以上仍是作者消息先筛，未读作者完整证明。


## 8. 父稿全文后审阶段

在§§1–7独立筛查完成后，首次完整实读flux_capacity.md FC1–5。精确static容量证明、分位层原子分数、FC3的eg与good rho因子、τ=min(1,3Kκε/(16Λ))、FC5的32ΛK/9真实余项及large-share的两个物理不等式均通过。已要求L显写1_Zell以与Λ同域；父级已落实。current容量来自R107 R1共同固定q，不从平均Q容量反推，不重定义q(x)来改变Z。

随后完整实读proof.tex.txt当前整合稿。主要FC/RCG恒等式、fixed-r的same-reserve物理G*子支付款、共同ξclock、Wν而非假Wβ能量预算及W_A上放一致。主稿仅使用current p容量，无免费future Jν≤q继承；声明未付补集、不声称一般root，与作者前筛查相符。详细author稿尚未齐时不因此认证所有扩展。

## 9. Astra全文后审阶段

已首次完整实读reciprocal_capture_geometry.md RCG1–17，随后核其唯一RCG17零alpha修订。原terminalA固定且支持Zg，G无删除；N含完整连续/BV删除，RCG6三个缺口、Stieltjes端点和非线性U≤B准确。RCG11/12必要结构与真实外pβdx第四maskloss成立，近极值条件不被偷作覆盖；固定q/FIRST、uniquej先统一行价后求和、RCG15固定接收费与RCG16旧n^(3/2)来源价均正确。M是新min-score identity项，不是原signed负信用。

RCG17最终将alphaJ/a放回被积函数，alpha0点态为0；active集的k/a、alphaJ/a≤1、h≤1给各项有限，避免形式0×∞。无其余实质修项。终端支持原定位的补充不改变推导；新随机ξ森林不能未证等同A_jt的原禁块森林，该索引争议未进入本稿主定理或付款依赖。

## 10. 数值静态审核阶段（未运行）

已全文静态读flux_capacity_check.py及md。12容量数组的dual阈值/greedy/tie/layercake与LP定义一致；greedy补齐A0无影响，也不被说成物理Λ。9个clock每段两类各同score，Λ_v按alive nonR固定份额乘正b_R端点增量，删后重算份额；完整双槽rate probes仅辅助恒等式，连续积分依据是该同类FTC。target A固定于最终幸存者，deleted源stop损失和虚拟terminal权/真实eg分开，D_A、RF、capacity、mR版saturation及zeroD均准确。三个新增partial deletion正weighted例提升有限压力范围，不扩一般实现性。共21例是12+9，不含重复内部capacity调用为新物理输入。

另全文静态读reserve_pressure_check.py及JSON摘要。9例仅6个r1 scalar reserve边界和3个QJ/q压力齐次式；同alpha容量、a0/alpha0、独立z(1−z)^2多项式因式及4/27取等正确。三压力行按J→tJ、QJ→tQJ、alpha→alpha/t保持原reservoir，明确保留原row RHS的QJ/q与G*的qJ/(QJa)抵消。没有构造p/et/high/reciprocal的joint LHS，也未测所有r，标签如此声明，不能替代完整新定理证明。本审未执行producer/replay，不重复数值。

## 11. target-dependent r扩展的作者前补筛

收到Sol准确扩展消息后、其全文尚未落盘前，独立核任意measurable r=r(x,y,t,v)∈[0,1]、独立当前u的版本。逐target先固定r再做同ν Hölder/alpha标量极值，令c0=1、base^0=1含base0，F=wg_v² base^r/c_r，base=(k_u/p_u)(J_v/a_v)(q/QJ)。r0用Πt(R)≤νR/et≤1/(2Kκ)、rho²≤d²单列。c_r逐target准确消去，故同一C_F≤log2 Wν/(36κ)且无r菜单费；t依赖只用于companion权重，不对它求导，不能移用于固定A通量identity。

此强化禁止r(x,y,t,v,u)逐pair选择或把u独立参数界当pointwise sup；固定概率mixture可用Tonelli同价，但不等于sup。主体主稿保守只采用fixed-r G*准确子支付款，详细扩展待Sol作者全文核量词后绑定。没有通过数值或未知source矩来扩大原coverage。


## 12. Sol完整稿后审与窄修终结

首次完整实读joint_geometric_budget.md JG1–12后通过。JG2物理T/H0/Hhat/τ/hstop已直接对照R128 RT6及原far定义一致，限实际非空far行；核心付款只需合法K0容量，未凭公式另造新选择器。JG3同储备bad容量、JG5原high/reciprocal方向、JG6同ν Hölder、JG7标量极值、JG9–12 normalized F真实列价以及target-adaptive r范围均与§6/11自证吻合。alpha0在原strictsoft K0>0下bad质量零；a0/rho0先零被积式、QJ0为原零ν行，无0×∞；r0单独用current容量而不误用alpha^0除法。

正文每个target的r先固定于u积分，common ξ∈[1/2,1]后才合uniquej，fixed b下J真实dx归一，故C_rec[F]≤log2 Wν/(36κ)及JG14根价常数准确。旧能量仅单向J_v与同切片，未换到J_u。Wν由共同父支配上放W_A，绝不靠ν≤β或β硬尾资格；多窗口仍真实收费。主TeX保留fixed-r G*版，详细稿target-r扩展也通过。

JG11 exact旧阈值独立复算：原companion≤4p_y² a_v d_v³QJ/(243D Q_v²et M)，要≤Lcap²J_v即得文中M_cap^exact。F1=L_v(K0u/wtu)(p_y wtu/p_u)及κ≤中因子≤1/κ准确；只给两侧target阈值夹逼，不证明与旧具体cut普遍包含或严格扩大物理覆盖。旧支先不交化、所有未付补集和原负信用保留。

作者已落实两处最终窄修并已读取：R107 R1直接是sigma≤muhi≤f，nu≤sigma另由R112/CP继承；‘QJ/q无上界’仅限只用current的扩展代数合同，不声称实际完整原合同中可任意大，因R128 RT5另列Jν≤q。主定理显式q/QJ取消，使它不依赖这个future资格；压力数值仍只是非物理缩放的代数检验。

## 13. 最终整合、证据与剩余缺口

最后完整实读report.md、parent_verification.md、reproduce.py，以及缩窄后的forest_geometry_contract.md。报告准确登记target-adaptive但禁止u适应，区分固定r主稿与详细稿扩展；21+9=30有限例、仅r1数值、未跑三缺口积分、未证物理历史及一般n阶均准确。父级记录两脚本隔离退出0、完整JSON相等和最终driver实际执行；本审只静态核流程/标签与JSON摘要，没有执行或重复实验。driver在新目录只复制合同与两checker，验证完整JSON，最后inventory/包装由父级另验，不循环绑定本审哈希。

forest索引修订明确新独立ξ森林与原FULL A_jt森林尚未识别，256na fixed-pair公式不能据此付原禁块；原选择后的源依赖也不享免费平移独立性。本轮主定理不依赖该未核联系。source_provenance仅归档字节与窄定位，不作为未通读证明的认证。原固定q/current容量、真实dx、source、同alpha及全部窗口费用在整合稿一致。

最终结论：带权通量的联合capacity、完整删除三缺口/必要极值结构、预先分配的epsilon接收贡献、normalized same-reserve物理F子支的根阶来源付款通过。未付的是低F且高good-share互反补集、非互反带权列、其他mother份额和原总账所列窗口/NB费用。不存在一般闭合认证；不把抽象LP极值、有限钟或压力缩放当物理实现。全部作者后审已完成，无待修实质问题，以下实际计算最终哈希并冻结停止，不再写责任外文件或扩展研究。

## 14. 最终SHA256绑定

| 文件 | SHA256 |
|---|---|
| task_contract.md | `120513ecb14d646a405b7f420457f2ec84e344d16a0c3344461ea1655f3aa125` |
| flux_capacity.md | `1c9b74f0bca969b5637497a701cf4a025e79b650aad08fbb49d15320dea03716` |
| reciprocal_capture_geometry.md | `b7f5bd209ea3d09db501fb081ff55ad99b15a0681e3e4b74b63d7661d9d2bb9f` |
| joint_geometric_budget.md | `9eae3deb842fbf0186c6ca26b4e1e7cbdee5df44c206c045ec01deedc2b810a5` |
| forest_geometry_contract.md | `91c5be8787b903fbebbb4400d7200a830d854acfb8a90c9fe47bb0740cecb683` |
| proof.tex.txt | `1023aa8b1137d4987ad25cffe3899cdec6c93a7e7864c9717a836645fbf109a5` |
| report.md | `038cc9ff42fa2ec8f9d14460a138ffb0750b19c2ad52c8f99c144d75709a0e65` |
| parent_verification.md | `cf428289815db85939fe3f5760eaf58c077c9b20bbf1d92e18ba1eca415bfa7e` |
| source_provenance.json | `1052257661d51422ada9eb483afb55e3efbeb021f71581f55dfabf5c57387a0e` |
| reproduce.py | `ad3c435b7268dc23eee73b9c36b2c08aa26292034ee1dc159a495c958a6e3f35` |
| flux_capacity_check.py | `8e7ff98c6fe61229063b951c1950161d384ad34c2e40c21929cd76d953ecad7a` |
| flux_capacity_check.json | `a0bfe4aff0c745ef85778b58d4947305ec795bd1d9083ebae90aedc8995e63d9` |
| flux_capacity_check.md | `625e5340945bd7e99859dcd8e0793a61d2a7092f7f6a6bfefd775a27191b15f6` |
| reserve_pressure_check.py | `a9f0ade00530a6304f5f314d789605336628bad6e1dc2299fa3980929a14e0d4` |
| reserve_pressure_check.json | `1e3fad79b75ae68d845349d8a041d14ec7b1e7af134e868ff6f2f1eb8ca1dc24` |
