#!/usr/bin/env python3
"""Exact reserve optimization and pressure homogeneity, not a whole-joint test."""
from fractions import Fraction as F
from pathlib import Path
import argparse,hashlib,json
HERE=Path(__file__).resolve().parent
C1=F(4,27)
def sm(xs):return sum(xs,F(0))
def enc(x):
 if isinstance(x,F):return str(x)
 if isinstance(x,dict):return {k:enc(v) for k,v in x.items()}
 if isinstance(x,(list,tuple)):return [enc(v) for v in x]
 return x

def check(name,stage,nu,J,k,a,E,B,q,target,pressure=False):
 nu,J,k,a=map(lambda x:list(map(F,x)),(nu,J,k,a));q=F(q);Q=sm(x*y for x,y in zip(J,nu));c=q
 assert Q>0 and q>0 and all(x>=0 for x in nu+k+a) and all(x>0 for x in J) and all(e in (0,1) and b in (0,1) and not e*b for e,b in zip(E,B))
 U=sm(e*min(x,z)*m for e,x,z,m in zip(E,a,k,nu));alpha=(c-U)/Q;bad=sm(b*z*m for b,z,m in zip(B,k,nu))
 assert c>=sm(z*m for z,m in zip(k,nu)) and alpha>=0 and bad<=alpha*Q
 av,jv,kv=a[target],J[target],k[target]
 if av==0:rho=d=F(0);scalar_rhs=F(0);normalized=None
 else:
  rho=max(1-(kv+alpha*jv)/av,0);d=max(1-kv/av,0);scalar_rhs=C1*(av/jv)*d**3;normalized=alpha*rho**2/((av/jv)*d**3) if d else None
 lhs=alpha*rho**2
 assert lhs<=scalar_rhs
 # Independent substitution z=alpha*J/(a-k). z(1-z)_+^2<=4/27.
 z=alpha*jv/(av-kv) if av>kv else None
 polynomial=z*max(1-z,0)**2 if z is not None else F(0)
 assert polynomial<=C1 and (normalized is None or normalized==polynomial)
 # Exact factorization on active z in [0,1]: 4/27-z(1-z)^2=(z-1/3)^2(4/3-z).
 factor=None
 if z is not None and z<=1:
  factor=(z-F(1,3))**2*(F(4,3)-z);assert C1-polynomial==factor
 out=dict(name=name,stage=stage,nu=nu,J=J,k=k,a=a,E=E,B=B,q=q,c=c,QJ=Q,alpha=alpha,reserve_capture_U=U,bad_k_mass=bad,target=target,rho=rho,d=d,scalar_lhs=lhs,scalar_rhs=scalar_rhs,normalized_reserve=normalized,z=z,polynomial=polynomial,factorization_gap=factor,scalar_equality=lhs==scalar_rhs,checks=dict(capacity=True,reserve_identity=alpha*Q==c-U,zero_a_branch=av!=0 or rho==d==lhs==scalar_rhs==0,scalar_bound=lhs<=scalar_rhs,independent_polynomial=polynomial<=C1))
 if pressure:
  # This is the RHS and G* normalization arithmetic, NOT a sampled joint LHS.
  K=F(1);kappa=F(1,2);h=Q/q
  rhs=C1/(2*K*kappa)*h*(av/jv)*d**3
  norm=(jv/av)*(q/Q)
  final=rhs*norm
  missing=C1/(2*K*kappa)*(av/jv)*d**3
  assert final==C1/(2*K*kappa)*d**3
  out['pressure']=dict(K=K,kappa=kappa,QJ_over_q=h,unnormalized_joint_RHS=rhs,Gstar_pressure_multiplier=norm,normalized_RHS=final,normalized_formula=C1/(2*K*kappa)*d**3,incorrect_without_pressure_RHS=missing,ratio_full_to_missing=rhs/missing,pressure_cancellation_exact=True)
 return out

def run():
 rows=[check('optimal_scalar','initial',[1],[1],[0],[3],[1],[0],1,0),check('alpha_zero_capture','initial',[1],[1],[1],[3],[1],[0],1,0),check('at_rho_threshold','initial',[1],[1],[0],[1],[1],[0],1,0),check('a_zero','stress',[1],[1],[0],[0],[1],[0],1,0),check('k_above_a','stress',[1],[1],[2],[1],[1],[0],3,0),check('tiny_a_optimum','stress',[1],[1],[0],[F(1,2**40)],[1],[0],F(1,3*2**40),0)]
 eps=F(1,4);nu=[1,1,1];k=[1,eps,1];Jbase=[eps,1,eps];q=2+eps;Qbase=sm(Jbase);alpha0=(1+eps)/Qbase;aa=[1-eps,eps+3*alpha0,0];baseline=None
 for h in (F(1,2**20),F(1),F(2**20)):
  t=h*q/Qbase;J=[t*j for j in Jbase];row=check('pressure_'+str(h),'expanded',nu,J,k,aa,[1,1,0],[0,0,1],q,1,True)
  assert row['QJ']/q==h and row['alpha']==alpha0/t and row['scalar_equality'] and row['normalized_reserve']==C1
  invariants=(row['rho'],row['alpha']*J[1],row['alpha']*J[1]*row['rho']**2,row['pressure']['Gstar_pressure_multiplier'],row['pressure']['normalized_RHS'],row['pressure']['unnormalized_joint_RHS'])
  if baseline is None:baseline=invariants
  assert invariants==baseline
  rows.append(row)
 assert rows[0]['normalized_reserve']==C1 and rows[5]['normalized_reserve']==C1
 return dict(schema='r183_reserve_pressure_v1',arithmetic='Fraction exact',inputs={'task_contract.md':hashlib.sha256((HERE/'task_contract.md').read_bytes()).hexdigest()},constant=C1,cases=rows,summary=dict(cases=len(rows),stages=['initial','stress','expanded'],all_checks_pass=True,unexpected_failures=[]),notes=['All nine arrays satisfy c=q>=sum k nu, E disjoint B, same alpha Q=c-U; this is finite reserve algebra, not physical FIRST/history','The cubic zero branch is evaluated before a/J normalization; alpha=0 is retained without division by alpha','z(1-z)_+^2 has exact optimum 4/27 at z=1/3, with independent nonnegative factorization on [0,1] and zero for z>=1','The three pressure rows use J->tJ, Q->tQ, alpha->alpha/t with q,k,a,nu,E,B fixed; alpha J, rho, S, and Gstar pressure multiplier stay invariant','Pressure RHS is (2/(27 K kappa)) (QJ/q) (a/J) d^3; multiplying qJ/(QJ a) cancels both ratios exactly','Dropping QJ/q changes the alleged unnormalized RHS by the displayed factor; it is not a uniform harmless constant','No p, p_y, e_t or reciprocal whole-joint conditions are constructed, and no actual joint LHS or integration is claimed tested','No numerical conclusion about dimensions or the general weak bound follows'])
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=HERE/'reserve_pressure_check.json');args=p.parse_args();r=run();args.output.write_text(json.dumps(enc(r),indent=2,sort_keys=True)+'\n');print(json.dumps(r['summary'],sort_keys=True))
