# R579 独立审查归档

四份独审按原文合并；临时路径及其SHA标注当时被审核的草稿版本，最终正文另由FINAL_AUDIT.md锁定。一般上界没有闭合。

---

来源审查 ccu_r579_cap_audit.md，SHA256 52171243421fc1847fcf35b94d7232b7543d68cb4a6caeb807731788dda4015d

# R579 截断共同曝光与时间覆盖独审

**判定：截断、精确共同来源分解、真实标签选取及时间覆盖常数全部通过，无必须修复的数学错误。** 尚未证明质量加权整体曝光的根阶上界；时间覆盖只返回未知接收体积的常数倍，不能作为吸收或一般弱型证明。

先按父代理给出的定义独立推导，再读 `/tmp/ccu_r579_astra.md`，SHA-256 为 `1c5f00f009676efce6df298a4c082a77e7d2672673bb38e8e9235573b933c75e`。保留原输入全部真实标签、固定原全尺度 H2、完整R及全部实际见证质量。本文只写本文件，未改他人/仓库，未运行几何扫描、优化、git、PDF或代理。

## 1. 截断不损失原信用：通过

沿既定边长 `r(t)^n=Le^t/λ`，令 Bt=min(At,λ)、Kcap=BT+∫0T Bt。x∈R 的全部不同见证质量对数为 s1<…<sk。在 t≥sj 时
\[
A_t(x)\ge\lambda e^{s_j-t},\qquad
0<\lambda e^{s_j-t}\le\lambda,
\]
所以同一下界也适用于Bt。对互不交的见证间隔积分，再把最后一段与端点BT合并，仍得
\[
K_{\rm cap}(x)\ge\lambda[1+V(x)].
\]
并非把每段下界在t<sj处外推；[0,s1]仍只丢掉非负贡献。开CS保证尺度相等时所有见证标签也严格位于Q内，不遗漏端点质量。

因此准确有
\[
\lambda|R|\le Q_{\rm cap}:=\int_R\frac{K_{\rm cap}}{1+V}
\le\int_R\frac{K}{1+V}\le(1+T)W.
\]
T=0时，所有带内见证质量都是L=U，在R上A0≥λ、B0=λ、V=0，故Qcap=λ|R|，另由∫B0≤W得到基础预算。R为空时所有式子均为0。截断准确消除了高度overshoot，但不自动消除长时间subcritical曝光。

## 2. 零分母与同一来源分解：通过

设Nt(x)=ν(Q(x,r(t)))。Nt>0时θt=min{1,Le^t/Nt}；Nt=0时定义θt=0。由 `Le^t/r(t)^n=λ`，
\[
B_t(x)=r(t)^{-n}N_t(x)\theta_t(x)
=\sum_i m_i r(t)^{-n}1_{Q(z_i,r(t))}(x)\theta_t(x).
\]
Nt=0时整个和为0，未进行0除法；Nt=Le^t时θ=1，两个分支相接。开立方体的对称性给相同的source-centered indicator。

θ由整个原输入、t及x共同确定，先于被收费标签i；同一receiver处所有来源使用同一个θ。故非负Tonelli准确给作者式(4)，端点项和连续项都保留 `θt/(1+V)`。来源质量不被虚拟拆分，允许weighted/co-located labels。

在固定ν后此分解合法，但θ、V、R、H2随整个ν变化；不能因此把该量说成跨输入线性的来源算子，或删改来源后沿用旧列。目标只需
`∫ν(dy) wcap(y)≤C(1+bT)W` 的整体预算，不要求每一来源列单独满足同一上界。作者没有作该未经证明的强化。

## 3. 原 H2 给真实小原子上界：通过

每个实际标签i属于原贪心块P(i)，原H2含以zi为中心、边长 `(2MP(i)/λ)^(1/n)` 的cube。若x∉H2且i∈Q(x,r_m)，却有2MP(i)≥m，则由cube对称及嵌套，x也在该源中心cube⊂H2内，矛盾。因此严格
\[
2M_{P(i)}<m,\qquad m_i\le M_{P(i)}<m/2.
\]
这是真实捕获标签的上界，不是从receiver薄层推出源质量小，也不要求mI≤U或单原子位置一般。

若同时Nt≥m，按任一固定次序加入该开cube中的完整真实标签，第一次累计达到m时，之前总质量<m，最后原子质量<m/2，所以所得实际子集质量s满足
\[
m\le s<3m/2.
\]
若m≤2U/3，则L≤m≤s<3m/2≤U。所有选中标签已严格在原cube内，且rs≥rm，故包括s=m时仍有x∈CS。没有用任意分数截原子，也没有把恰等于λ的捕获误当严格极大值；严格接收盒来自位置仍有余量。

## 4. Gx 时间覆盖及常数：通过

令c=log(3/2)>0，Gx={t∈[0,T]:At≥λ}。若t≤T−c，由上一节得到某实际见证对数sj∈[t,t+c)，因此t∈[sj−c,sj]。剩余末段在[0,T]中的长度至多c。

全部sj间隔给
\[
\left|\bigcup_j[s_j-c,s_j]\right|
\le c+\sum_{j<k}\min\{c,s_{j+1}-s_j\}.
\]
限制回[0,T]只减小长度，端点的测度为0，不损失“≥λ”边界。对d≥0，
\[
\min\{c,d\}\le3c(1-e^{-d}).
\]
当d≤c，d/(1−e^−d)递增；当d≥c，c/(1−e^−d)递减；公共最大值为c/(1−e^−c)=3c。d=0时两边同为0。合并末段得到准确
\[
\boxed{|G_x|\le2c+3cV(x).}
\]
T<c时直接|Gx|≤T<c即可；T=0时|Gx|=0。这里使用完整实际见证质量表，非按receiver私选来源partition。

指定本机Python/SymPy实际核了导数表达式：将双曲函数改写为指数后，`d/dd[d/(1−e^−d)]−(e^d−1−d)/(4sinh²(d/2))` 残差0；c/(1−e^−c)−3c残差0。单纯第一次通用simplify未约掉双曲形式，不作为零残差证据；随后指数形式准确约零。显示读数3c约1.2163953243，仅作读数，单调性和常数由上述解析论证支持。

## 5. 为何不能吸收，以及真正保留的未证目标

在Gx上Bt=λ，因此其时间部分除以1+V后只有
\[
\lambda\int_R\frac{|G_x|}{1+V(x)}dx
\le3c\lambda|R|.
\]
3c>1严格成立：`log(3/2)> (1/2)/(3/2)=1/3`。故该常数没有可供统一吸收的<1因子。端点另有费用，且Gx外的Bt=At<λ的连续曝光完全没有由该时间覆盖式控制。不能因为2c<1就忽略V系数、端点及subcritical部分来移项。

截断及式(4)因此是一个合法的新checkpoint；尚未得到的几何桥仍是两receiver因子θt与1/(1+V)、原H2及完整cube产品结构如何共同控制来源整体曝光。需要实际证明该整体预算或其他全部误差已付的机制。作者明确未作此证明，没有一般根阶、cut新引理或弱型上界的过度主张。

作者式(8)写 `C[1+b log(2U/L)]W`，任务的简写是 `C(1+bT)W`；二者不是逐字相同，但b≤1时互相比较至多差绝对因子1+log2。C为未指定统一常数时不构成数学错误；若后续给具体C，应统一记号或显式保留该因子。不能据此隐藏任何n依赖损失。

## 最终结论

截断下界、零分母、共同来源账、开盒/时间端点、first-cross真实标签选取及2c+3cV常数均通过。无必须修复项；目标记法可按上段统一。剩余整体曝光预算和一般目标仍未证明。本次仅有小符号检查，无新增数值探路，审核完成，停止。

## 6. 第二次授权续审：light core 几何与整带分量付款

**本节判定：通过，无新增必须修复项；没有累计 light 预算。** 上面原审的 Astra 版本 SHA `1c5f00f009676efce6df298a4c082a77e7d2672673bb38e8e9235573b933c75e` 保留，不能据该旧审自动认证新文字。本次先按父代理准确命题独立核验，再实际读了以下新版本：

| 文件 | 本节已审 SHA-256 |
|---|---|
| `/tmp/ccu_r579_astra.md`（现含第4节续稿） | `387d902fdacb62e06ff3f2c3e6f251642f0fec3ccb6f2521f6c01547c1240bc1` |
| `/tmp/ccu_r579_complement.md` | `bcf24ee6fadd5959a886ec90f49995802b5c4c699ee16a9255207325898c1940` |

### 6.1 Light 标签大 core 必低 β：通过严格阈值

固定m>0、0<δ≤1/2，Ilight为全部原贪心块MP≤δm的标签并。若实际K⊂Ilight、k=mK>δm且βK≥b，那么处理高族K时，它被选中或被此前某质量≥k的所选块P拦截。两种情形都使K的一个真实标签最终属于质量≥k>δm的原块，矛盾于Ilight定义。因此严格βK<b。

此证明不要求K位于同一块，不要求K是带内见证，也不以receiver另选greedy；保留原所有质量尺度。k=δm的等号不能套该低β结论（某个原高块本身就可在等号上），稿中使用的严格k>δm正确。

### 6.2 Joint receiving box 的产品折扣：含截断守卫通过

再设k≤m，令rm=(m/λ)^(1/n)、rk=(k/λ)^(1/n)、c=rk/rm∈(0,1]、uj=(1−dj(K)/rk)+∈[0,1]。真实Bm(K)=∩i∈KQ(zi,rm)的宽度因子为 `(1−dj/rm)+`。

当dj≤rk时，该因子正好等于(1−c)+cuj；当dj>rk时uj=0，而真实因子≤1−c。因此无论 core 原尺度上是否已经空盒，都有
\[
\lambda|B_m(K)|/m\le\prod_j[(1-c)+cu_j].
\]
两因子的右减左差为 `c(1−c)(1−u)(1−v)≥0`，归并可证任意n；等价地，∏[1−c(1−uj)]对c在[0,1]凸，低于两端弦。故
\[
\lambda|B_m(K)|\le m(1-c+c\beta_K)
\le m[b+1-c]
\le m\left[b+\frac{\log(m/k)}n\right]
\le m\left[b+\frac{\log(1/\delta)}n\right].
\]
最后用1−e^−z≤z；k=m、βK=0、n=1及dj≥rm都没有被遗漏。δ=b/2时系数为 `b+log(2√n)/n`。这是逐个实际core的几何界，非多个core接收并的界。

新 Astra 的prefix补充也正确：固定scale下若q_light(x,t)>δm，逐个加入捕获的真实light标签直到首次严格超过δm，因每个mi≤δm，可得δm<k≤2δm≤m，并有x∈Bm(K)。因此这些core盒确覆盖该完整superlevel，但没有限制盒数、source重复总质量或跨scale选择；稿中明确没有据此结算Jlight。

### 6.3 同一 cap 对象的 endpoint 与 heavy 分量：整带通过

Complement 先用完整分母 `max(q_t,m(t))` 精确分解Qcap=Qend+QH(δ)+QL(δ)。qH/qL的标签划分只依原块和共同t，MP>δm为heavy、MP≤δm为light，边界没有漏源。m(t)>0使max分母永不为0；q=0时分子全0。

Qend≤∫AT=W单独付一次。对某原P的heavy来源要能在R捕获，必须同时满足
\[
2M_P<m(t)<M_P/\delta.
\]
严格端点只影响dt零测集。保留原H2源中心洞，并仅为这个付费分量丢掉V及cap分母，得到
\[
Q_H(\delta)\le\sum_PM_P\int_{2M_P}^{M_P/\delta}
(1-2M_P/m)\,dm/m
=[\log(1/(2\delta))-1+2\delta]W.
\]
与[L,U]相交只会减费；没有要求MP≤U，也没有复制每窗W。取δ=b/2后准确是
\[
\boxed{Q_{\rm end}+Q_H(b/2)\le[\tfrac12\log n+b]W.}
\]
δ=1/2时heavy窗口为空、积分恰0；n=1时只余W；T=0时两个参数积分都0且端点仍只付W。系数0.5log n+n^−1/2在n≥1不少于1，与这些端点相容。

本次实际SymPy核积分差、δ=1/2值、代入δ=b/2后的完整系数差均为0。新 Astra 第4节开头引用的是较松的heavy `log(1/(2δ))W` 加endpointW，它也成立；这里更准确的显示系数来自已审Complement，二者不应在具体常数表中混写。

### 6.4 Light 饱和时间式及剩余费用：通过但未付

设Eδ(x)={t:qL,t(x)≥m(t)}、h=log(1+δ)>0。t≤T−h时，捕获light标签每个mi≤δm，first-cross m给实际质量 `m≤s≤(1+δ)m≤U`。开cube在s=m时仍合法；t≤log(s/L)≤t+h使Eδ落在全部真实见证区间[sj−h,sj]及最后长度≤h的窗。

同一union-length论证给
\[
|E_\delta(x)|\le2h+\frac{h}{1-e^{-h}}V(x)
=2h+\frac{(1+\delta)h}{\delta}V(x)
\le2\delta+(1+\delta)V(x).
\]
T<h、T=0、δ=1/2、闭的qL≥m及质量相同见证去重均已处理；light标签随t变化不妨碍每个t构造一个原全族中已有的见证。SymPy实核该h系数恒等式差0。

精确light分母仍为**总**q_t。饱和时light integrand≤λ/(1+V)，所以
\[
Q_{L,\rm sat}\le(1+\delta)\lambda|R|,
\quad
Q_{L,\rm sat}\le\lambda\int_R\frac{V}{1+V}+2\delta\lambda|R|.
\]
这两式均是receiver self-cost，不是已从W支付的来源预算；δ=b/2时只把最后项变成bλ|R|，仍不能免费丢掉V权重项或吸收全部R。qL<m的subthreshold积分保留总q和1+V，尚无邻近实际见证保证，也未由逐core小体积控制其累计并集。

**本节最终范围：** endpoint+heavy整带分量已付；light饱和时间约束与逐core产品折扣合法，但完整Jlight、根阶Qcap预算及一般弱型目标仍未证明。新版本的已审范围止于上述明确SHA；后续追加不自动通过。仅有小符号运算，无bulk试验，第二次审核完成，停止。

---

来源审查 ccu_r579_vertex_audit.md，SHA256 42392da6063ef9ac7a4e114ab91f2d1617ea0e31731c5f8c406153685c7fa165

# R579 顶点族逐尺度强估计：独立解析审核

**结论：通过。** 所给完整 band 残余体积公式及其解析下界正确，能够排除每个尺度统一的 `light receiver volume≤b·polylog(n)·W` 强估计。它不反证完整Jlight、Qcap目标或一般弱型目标：本例T=0，已允许且已付的W端点足够。

本审先按父代理消息中的定义独立推导，没有读取新作者证明、没有重跑正在完成的7个数值例。只用本机指定Python/SymPy核关键导数、指数恒等式和连续k上界；另用Fraction核符号常数的有理包围。没有来源子集/几何枚举、bulk计算、git、PDF或代理，只写本文件。

## 1. 全原高族与原 H2：通过

输入为 `{0,1}^n` 全部顶点、每点质量1、W=2^n、λ=1。非单标签S的基数s满足2≤s≤2^n；若变动坐标数为d，则s≤2^d、d≥log2 s，且
\[
\beta_S=(1-s^{-1/n})^d.
\]
单标签另行处理，β=1，不把s=1代入含log的推导。

令t=log(s)/n∈[log2/n,log2]，f(t)=t log(1−e^−t)。因底数在(0,1)，
\[
\log\beta_S\le\frac{n}{\log2}f(t).
\]
写x=e^−t∈[1/2,1)，则
\[
(1-x)f'(t)=g(x)=(1-x)\log(1-x)-x\log x,
\quad g''(x)=\frac{2x-1}{x(1-x)}\ge0.
\]
g连续延拓到x=1，g(1/2)=g(1)=0，故g≤0，f递减。因此
\[
\beta_S\le1-2^{-1/n}
<\frac{\log2}{n}<n^{-1/2}=b.
\]
最后对n≥1成立；本例随后只用n≥16。原全部质量尺度的高β族所以恰为单标签，质量ties无影响，原greedy实际选择所有2^n个单标签。

置ρ=2^(1/n)。每个原H2盒边长ρ，ρ≥1使每坐标的0/1两区间相接或重叠；全顶点Cartesian积因此给**准确**
\[
H_2=[-\rho/2,1+\rho/2]^n.
\]
这不是以凸包替代真实原好区。

## 2. 参数与所有原块均 light：通过端点

取整数n≥16，k=ceil(log2(2√n))、m=2^k、r=2^(k/n)、δ=b/2。因为m≥2√n，所有原块MP=1≤δm；light的闭阈值包括等号，不会误判边界输入。

设B(n)=2+(log2 n)/2。ceil给k≤B(n)，并且
\[
\frac{d}{dn}\frac{B(n)^2}{n}
=\frac{B(n)}{n^2}\left(\frac1{\log2}-B(n)\right)<0
\quad(n\ge16).
\]
边界B(16)²/16=1，所以k²/n≤1。进而k≤√n≤n/2；k≥3，当然满足所需k≥2。由此m≤W、ρ<r≤√2<2，全部实际band子集、正宽度及后面的外区参数均合法。未用不存在的k>n层。

## 3. 完整 band 接收并与扣除 H2 的精确公式

考虑完整band[m,m]，所有实际见证恰为m个顶点的子集，不能只挑k维面。按接收坐标分类（有限个边界超平面不影响体积）：

- central区间 `(1−r/2,r/2)` 长r−1，同时捕获0和1；
- 左、右outer区间各长1，分别只捕获0或1；
- 超过总包络则不捕获该坐标任何顶点。

若恰有j个central坐标，名义边长r的开cube捕获2^j个真实单位源。故存在m=2^k个实际标签的CS见证，**当且仅当j≥k**。这处理了完整全族，包括j>k时的许多不同m标签见证。

固定r时捕获m个源虽只保证平均值≥λ，但这些源全在开cube内；选定有限m标签后有严格位置余量，可略缩边长仍捕获它们，平均值遂严格>λ。因此这里不是把弱等号水平误当严格极大水平。

central区间在[0,1]内，完全处于H2。每个outer区间与H2的交长度为
\[
q=1-(r-\rho)/2=(\rho+2-r)/2\in(0,1).
\]
恰j个central坐标的pattern总体积是 `C(n,j)(r−1)^j 2^(n−j)`，其H2内部分再乘q^(n−j)。因此完整残余G准确满足
\[
\boxed{\frac{|G|}{W}=
\sum_{j=k}^n\binom nj\left(\frac{r-1}{2}\right)^j
\left[1-\left(\frac{\rho+2-r}{2}\right)^{n-j}\right].}
\]
j=n时括号为0，正确表示全central区域被H2覆盖；其他项非负。开/闭边界仅差零测集，不影响此体积恒等式。

## 4. j=k 项下界与所有常数：通过

由n≥2k和log(1−u)≥−2u（0≤u≤1/2），
\[
\binom nk=\frac{n^k}{k!}\prod_{i=0}^{k-1}(1-i/n)
\ge\frac{n^k}{k!}\exp(-k^2/n).
\]
单调log的积分上界给
\[
\log k!\le\int_1^k\log x\,dx+\log k
=k\log k-k+1+\log k,
\quad k!\le e k(k/e)^k.
\]
同时r−1≥k log2/n，r−ρ≥(k−1)log2/n。以q=1−(r−ρ)/2，
\[
q^{n-k}\le\exp[-(n-k)(r-\rho)/2]
\le2^{-(k-1)/4}\le2^{-1/4}.
\]
此处q∈(0,1)、n−k≥n/2、k≥2均已在上节获得，不存在符号反转或负宽度问题。

令a=e log2/2，则只取j=k项得到
\[
\frac{|G|}{W}\ge
(1-2^{-1/4})e^{-1-k^2/n}\frac{a^k}{k}
\ge(1-2^{-1/4})e^{-2}\frac{a^k}{k}.
\]
两个e^−1分别来自factorial和k²/n≤1，没有多扣或少扣常数。

a∈(1/2,1)可完全初等认证：e>2、log2>1/2给下界；e<11/4与分两段梯形积分上界log2<17/24给 `e log2<187/96<2`。故a<1，使用k的**上界**时a^k方向正确：
\[
\frac{a^k}{k}\ge
\frac{a^2 n^{\log a/(2\log2)}}{2+\tfrac12\log_2n}.
\]
令
\[
c_0=(1-2^{-1/4})e^{-2}a^2>0,
\quad\gamma=\tfrac12+\frac{\log a}{2\log2}
=\frac{\log(e\log2)}{2\log2}>0,
\]
则准确有
\[
\boxed{\frac{|G|}{bW}\ge
\frac{c_0 n^\gamma}{2+\tfrac12\log_2n}.}
\]
γ<1/2也由a<1可见。正幂除一个log仍超过任意固定多对数，故解析结论不依赖7例数值。

## 5. 范围与实际工具证据

原全部来源在该尺度均light；G也是完整实际band接收并在原H2外的部分。因而任何声称“每个尺度的完整light接收测度≤C b polylog(n)W”的统一强估计都被此族否定，包括仅声称饱和light receiver superlevel的小体积版本。不能用逐core的小交盒折扣直接推出这个完整并界。

这不是完整Jlight的反例。这里T=0，参数积分为0、V=0，端点B0在G上恰为λ，Qcap=λ|G|，而固定尺度Markov已给λ|G|≤W。原目标允许W基础费，未要求T=0也额外获得b。若扩大band、计入两receiver分母和所有时间，其累计表现需要另证，本审未外推。

本机Python/SymPy实际核验：g二阶导差0；f导数与g代换关系差0；B(n)²/n导数差0及其n=16连续边界值1；γ的两种写法差0。Fraction核 `11/4·17/24=187/96<2`。没有运行7个有限顶点体积或任何来源枚举；小符号检查不替代以上一般证明。

**无必须修复项。** 建议后续保持“逐尺度强估计失败”的准确标题与T=0范围，不称Jlight、Qcap或一般弱型目标失败。本次审核完成，停止。

---

来源审查 ccu_r579_selection_audit.md，SHA256 6039a28fb56147ea6580c174e141a8d555e0a447ce84cf5b67b3791e8aa60a3f

# R579 last-witness selection 独立审核

结论：**通过，未发现必须修复的数学错误。** 通过对象是一次付费的 top 部分、余部最大真实见证选择、真实分母填满、foreign 排除及其共同来源行恒等式；没有通过任何尚未证明的累计列容量、根阶预算或一般弱型改善。第 5 节正确地停在直接 packing 尝试不足以付款的位置，并未把它写成不可能性定理。

被审稿：`/tmp/ccu_r579_selection.md`，SHA256
`ec4daec4bf6483cd5c11c92447e24714b1cff7e7a84939aee71a51896fe610ef`。
先按任务给出的定义独立推导，再全文对照该稿。约定有限正质量原子、原标签及原全尺度 H2 不变，`0<L<=U<infinity`、`lambda>0`，`n>=1`；Q 的参数为**边长**且 Q 开，C_S 使用相应严格捕获条件。原贪心块 P 覆盖全部标签，且 H2 包含每个 i 属于 P 的来源中心立方体，边长为 `(2 M_P/lambda)^(1/n)`。本审使用这一已证工具，没有重审其构造。

## 1. Top 及最大见证：量词和严格边界通过

若 x 有带内见证质量至少 `2U/3`，固定边长 `r_U` 的立方体捕获至少该质量。对全原输入的这一固定尺度平均作 Tonelli，其全空间积分为 W，故 `lambda |R_top| <= 3W/2`。这是完整 top 的一次付款。`L>=2U/3`（含等号）、`L=U` 及 `W<L` 均已正确处理。

对余部，有限全部子集族保证最大实际质量 m 存在，且 `L<=m<2U/3`。任意被 Q(x,r_m) 捕获的标签 i 若满足 `2M_P>=m`，则 x 已进入该来源的 H2 立方体，矛盾。因此 `m_i<=M_P<m/2`。若一个捕获标签不属于 S，则真实子集 `S union {i}` 质量严格小于 `3m/2<U`、严格大于 m，且其较大实际立方体仍严格捕获全部标签，违反最大性。故捕获集恰为 S、真实分母恰为 m。

两最大质量见证具有同一边长，均须等于该边长下的完整捕获标签集，故唯一；这同时处理相同子集质量及来源位置重合。重合标签不能只取其中一部分而仍保持填满。有限子集的开集 C_S、固定 H2 及有限并差给出可测选区 D_S；选区互不交并覆盖 R_lo。这里不需要可测选择定理或另行选择 tie。

## 2. Foreign 排除及连续 q 后缀：通过

对非空真实 foreign 标签集 J，若 `0<m_J<=U-m` 且全部来源严格落在边长 `r_(m+m_J)` 的立方体中，S 的原捕获立方体嵌在其中，故 `S union J` 构成质量更大的合法带内真实见证，矛盾。单标签情形就是式 (4)，开立方体的补条件给出 `>=`，不应改成 `>`。允许新质量恰为 U。式 (5) 只是 D_S 的外包，稿中没有误写成等号。

对每个**实数** `m<q<=2U/3`，假设边长 r_q 捕获质量至少 q。每个捕获标签仍有 `m_i<q/2`。按任意标签顺序取首次累计达到 q 的前缀，所得真实质量 s 满足

`q<=s<3q/2<=U`。

严格小于 `3q/2` 来自前缀跨越前的总质量严格小于 q 及最后标签严格小于 q/2，故在 `q=2U/3` 端点仍有 `s<U`。这些来源严格在 q 立方体内，因而也在其实际 s 立方体内，且 `s>m`，矛盾。因此式 (6) 的严格 `<q` 成立，包括假设捕获质量恰等于 q 的情形。这不是仅对实际子集质量的断言，也未被无依据延伸至 q 大于 `2U/3`。

## 3. 同一真实来源行动及尚未付款部分：通过

在每个 receiver 使用同一 Q(x,r_S)，来源权重为 `lambda/m_S`。有限标签正 Tonelli 给出

`sum_i m_i integral_Rlo lambda 1_{i in S(x)}/m_S(x) dx = integral_Rlo lambda dx = sum_S lambda |D_S|`。

标签指标对重合位置仍有原本含义。这里 m_S 为已证的真实总分母，没有把选定子集质量替代可能更大的分母，也没有让各来源使用不同立方体。式 (7) 是行质量恒等式；若要付款仍需控制每个来源的累计曝光或其真实整体积分，本文没有假定该控制。

第 5 节式 (8) 由 foreign 标签 j 的 x 端排除、z 端严格捕获及三角不等式推出，正部和全部质量条件正确。对于集合版应理解为 `J subset T\S`；选一个违反 x 端共同捕获的标签即可得到相应差值。若 `m_T>=m_S+m_J`，该差值下界消失。小质量增量满足

`(1+v/m)^(1/n)-1 <= v/(n m)`，`v>=0,n>=1`，

由凹性成立，n=1 取等号。因此这一个 separation 不能直接提供与 r_S 可比的统一间隔；稿中只据此指出当前证明的缺口，没有据此排除所有其他联合 packing 或容量方法。

## 4. 实际计算与未审范围

实际执行本机 Python 3.12 环境 `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python`，SymPy 1.14.0：对 `f(v)=(1+v/m)^(1/n)-1`，得到 `f'(0)-1/(nm)=0`，且

`f''(v)=-(1+v/m)^(1/n)(n-1)/(n^2(m+v)^2)`。

这辅助核对增量公式；一般选择、阈值端点、foreign 排除及收费恒等式的结论来自上面的书面推导。没有运行几何枚举、数值扫描、累计容量计算或 PDF 编译；没有核验作者另一次计算的执行记录。没有重审历史 H2 基础、其他 cap 分解或一般 L1 回代。当前可保留的是完整选择归约及 top `3W/2` 付款，全部余部的根阶来源预算仍未证明。

---

来源审查 ccu_r579_uncross_audit.md，SHA256 76ba359af964a85bb0b09c5b8ffb1d6a9fdfaf4f817f09371970b7e852fa3d65

# R579 独审：共同归一化位移、filled cells 与 antichain 付款

**判定：三个数学断言通过。** 精确换元、共同被收费标签所迫出的原来源集合嵌套，以及实际来源 antichain 的 W 预算均成立。**措辞须限定：这一步不是 cube 特有的 uncrossing。** 它依靠同锚同参数下的凸性嵌套；在相应 filled-cell 假设下，同样适用于一般凸体。当前没有链预算，本审不研究或断言链预算。

本审先独立推导以下三项，然后才读 `/tmp/ccu_r579_last_cells.md`。没有先依作者的新证明起步。只写本文件，不改作者稿、仓库或其他文件。

## 1. 真正使用的假设

沿原实际正标签输入 nu=sum_i m_i delta_zi，m_i>0，令 r_S^n=m_S/lambda。已经证明的末见证 cells D_S 是可测有限族，彼此不交并分尽 R_lo，且每个 x in D_S 的开立方体 Q(x,r_S) 捕获的实际标签**恰为 S**。

这意味着对每个 i in S，D_S subset Q(z_i,r_S)。它也意味着捕获质量的真实分母等于 m_S。H2、完整 witness union 和末见证选择是建立这些假设的原始依据；下面换元不重新选 good region、子来源或 radii。

置 Q0=(-1/2,1/2)^n，对所有原来源和所有 cells 使用同一个 u in Q0，定义

\[
 A_S(u)=\{i\in S:z_i+r_Su\in D_S\},\qquad
 a_S(u)=\sum_{i\in A_S(u)}m_i.
\]

A_S(u) 是原全标签的实际子集；仍用原 m_S 算 r_S，不以 a_S(u) 替换节点质量。

## 2. 精确换元与真实分母：通过

对每个 i in S，由 D_S subset Q(z_i,r_S)，

\[
 \int_{Q_0}\mathbf1_{D_S}(z_i+r_Su)\,du
 =r_S^{-n}|D_S|.
\]

乘真实 m_i 并求和，有

\[
 \int_{Q_0}a_S(u)\,du
 =\frac{m_S}{r_S^n}|D_S|
 =\lambda|D_S|.
\]

因此

\[
 \boxed{\lambda|R_{\rm lo}|=
        \int_{Q_0}\sum_Sa_S(u)\,du.}                     \tag{1}
\]

等价地，原来源账中的 coefficient lambda*m_i/m_S 与 dx=r_S^n du 相消为 m_i。分母 m_S 由 filled property 等于真实 nu(Q(x,r_S))，不是删去其他来源后的替代量。每个 receiver 的原选定动作没有改变；换元只是逐来源项表示同一动作。

Q0 的体积为1，未漏归一化因子。所有 r_S>0；空 cell 或空 A_S 的贡献为0，不产生零除法。输入和 cell 族有限，换求和与积分没有额外可积性要求。任意正权重、重合位置均合法；同位置标签仍分别携带实际 m_i。

原 cells 为有限盒布尔组合，因而 Borel。换元直接适用于这些集合，不需先删边界。Q0 边界本身为零测集，开/闭参数选择不改变 (1)；精确原 cells 的 filled property 给内部 u 上逐点的后续嵌套断言。没有通过浮点容差忽略来源或边界质量。

## 3. 共同收费来源迫使原集合嵌套：通过

若 i in A_S(u) intersection A_T(u)，且 m_S<=m_T，则 r_S<=r_T，并且

\[
 x_S=z_i+r_Su\in D_S,\qquad x_T=z_i+r_Tu\in D_T.
\]

对每坐标 u_j in (-1/2,1/2)，在 0<r<=R 下，

\[
 r(u_j-1/2)-R(u_j-1/2)=(R-r)(1/2-u_j)\ge0,
\]
\[
 R(u_j+1/2)-r(u_j+1/2)=(R-r)(1/2+u_j)\ge0.
\]

故同锚捕获立方体准确嵌套：

\[
 Q(z_i+ru,r)\subseteq Q(z_i+Ru,R).
\]

两者捕获的原标签分别恰为 S,T，所以

\[
 \boxed{A_S(u)\cap A_T(u)\ne\varnothing, m_S\le m_T
        \ \Longrightarrow\ S\subseteq T.}               \tag{2}
\]

若质量相等，捕获侧长和中心也相等，因此 S=T。也可由正权重排除 proper inclusion 的等质量情况。所有标签的合法性同时来自一个共同 u，未对每个被收费来源私选不同 u。

应注意，(2) 不是断言 A_S(u) 本身形成 laminar 家族，也不自动给 A_S subset A_T。正确结论是：**对固定 i,u，向该 i 收费的原集合 S 两两嵌套。**

## 4. 实际原来源 antichain 的费用：通过

设 F 是原 cell 标签集在包含关系下的任一 antichain。若 S,T in F 不同，则由 (2)，A_S(u) 与 A_T(u) 不交。因此对每个 u in Q0，

\[
 \boxed{\sum_{S\in F}a_S(u)\le\sum_i m_i=W.}            \tag{3}
\]

积分并用 (1) 的逐 cell 等式，有

\[
 \lambda\sum_{S\in F}|D_S|\le W.
\]

这是真实接收 cells 的一份 antichain 付款，不是把每个 S 的全质量 m_S 重新加总。对于同一个 u，原 source i 至多被 antichain 中一个 cell 收费。若按 u 选取不同 antichain，只要选择可测，逐点 (3) 仍成立；不能借此同时把多个 antichain 各自 W 当作整个 family 的一份 W。

整个 family 中同一来源可沿嵌套链重复出现，(3) 没有限制该重复。不给这种链自动套原不复制森林 theorem，也不将原 S 的 radius 改成 A_S(u) 的质量 radius。

## 5. 必须限定的适用范围：不是 cube 专属

作者用坐标端点证明立方体包含关系是正确的，但相同包含关系有更一般的凸性证明。

例如取任意体积1的凸体 K（先用开内部，不影响体积），以 x+rK 为捕获体。对参数 u in -K，0 belongs u+K。因 u+K 凸且包含0，0<r<=R 给

\[
 r(u+K)\subseteq R(u+K).
\]

因此，对同锚中心 z_i+r u、z_i+R u 的捕获体也有

\[
 z_i+r(u+K)\subseteq z_i+R(u+K).
\]

若对应 cells 具有同样的真实 filled property，换元参数取 -K，且 |K|=1，以上精确账和 antichain 付款原样成立。对原点对称凸体，-K=K，连参数记法也相同。标量 convex-combination 形式为

`tau(u+v)=u+[tau*v+(1-tau)*(-u)]`,  0<=tau<=1,

其中 v,-u in K。

因此该步仅用了**凸体的同锚凸性嵌套及真实填满**，没有使用 cube 的完整坐标乘积宽度折扣。不能将其称为 cube 特有几何估计，或据此宣称一般凸体已拥有原 cube 的 H2 construction/费用或末见证全局预算；这里只说明这一换元与 uncrossing 步的适用范围。

建议作者将“uses the cube's coordinate intervals”限定为“for cubes this follows coordinatewise; the uncrossing itself extends to convex capture bodies under the same filled-cell hypothesis”。此为范围修正，无需改动 (1)--(3) 数式。

## 工具与停止边界

本机指定 Python/SymPy 实际核了两端点差、上述 convex-combination 恒等式（残差0），以及三维 scalar-dilation Jacobian r^3。一般 n 的 Jacobian r^n 和几何包含由正文直接证明；符号检查不替代论证。没有数值扫描。

**最终结论：恒等式、真实分母、嵌套及 antichain W 付款通过；需避免 cube 专属性措辞。** 完整 family 的链累计尚无预算，本审不延伸该问题。完成停止。
