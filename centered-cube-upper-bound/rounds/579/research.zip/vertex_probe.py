"""Frozen vertex-cube saturated fixed-scale receiver finite sums, no source enumeration."""
from fractions import Fraction as Q
from math import comb,isqrt
from pathlib import Path
import argparse,json,sys,platform,time,resource,shlex
import flint
import sympy as S
from flint import arb,ctx
ctx.prec=512
parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=Path(__file__).resolve().parent/'vertex_probe.json');args=parser.parse_args();START=time.perf_counter()
def aq(q):q=Q(q);return arb(q.numerator)/q.denominator
def ds(x):return x.str(60)
LN2=arb(2).log()
AC=arb(1).exp()*LN2/2
GAMMA=aq(Q(1,2))+AC.log()/(2*LN2)
C0=(1-(-LN2/4).exp())*(-arb(2)).exp()*AC**2
assert 0<AC<1 and GAMMA>0 and C0>0
x,ks=S.symbols('x k',positive=True)
g=(1-x)*S.log(1-x)-x*S.log(x)
g_second_residual=S.simplify(S.diff(g,x,2)-(2*x-1)/(x*(1-x)))
log_integral=S.integrate(S.log(x),(x,1,ks))
log_integral_residual=S.simplify(log_integral-(ks*S.log(ks)-ks+1))
logfactorial_envelope_residual=S.simplify(log_integral+S.log(ks)-((ks+1)*S.log(ks)-ks+1))
assert g_second_residual==0 and log_integral_residual==0 and logfactorial_envelope_residual==0
SCALAR_CERT={'a_e_log2_over2_Arb':ds(AC),'gamma_Arb':ds(GAMMA),'c0_Arb':ds(C0),'zero_lt_a_lt_one':True,'gamma_positive':True,'c0_positive':True,'analytic_ratio_lower_formula':'c0*n^gamma/(2+log(n)/(2log(2))) for n>=16; general derivation supplied by root and subject to separate audit, not proved by this scalar computation','finite_consistency_only':'Only five prescribed baseline k cases are compared. Neither k-neighbor control is used to test this analytic lower bound; no finite table proves it for all n.'}
SYMBOLIC_CERT={'g':'(1-x)*log(1-x)-x*log(x)','g_second_derivative':'(2*x-1)/(x*(1-x))','g_second_derivative_residual':str(g_second_residual),'log_integral':str(log_integral),'log_integral_residual':str(log_integral_residual),'logfactorial_integral_upper_envelope':'log(k! ) <= integral_1^k log(x) dx + log(k) = (k+1)*log(k)-k+1, integer k>=1; inequality uses monotonicity of log','envelope_expression_residual':str(logfactorial_envelope_residual),'scope':'Symbolic equalities only; log(k!) is not asserted equal to its integral envelope.'}
base=[]
for n in [16,64,256,1024,4096]:
 k=0
 while 2**(2*k)<4*n:k+=1
 assert 2**(2*k)>=4*n and (k==0 or 2**(2*(k-1))<4*n)
 base.append((n,k,'minimal_all_blocks_light_k'))
cases=base+[(256,base[2][1]-1,'k_minus_one_nonlight_control'),(256,base[2][1]+1,'k_plus_one_light_pressure')]
guards={}
for n in [16,64,256,1024,4096]:
 b=1/arb(n).sqrt();upper=-(-LN2/n).expm1()
 assert upper>0 and upper<b
 max_other=arb(0);max_d=None
 for d in range(2,n+1):
  # Actual subset with d varying coordinates has cardinality<=2^d.
  # Beta<=f_d=(1-2^(-d/n))^d; all possible d checked, no atoms enumerated.
  fd=(-(-d*LN2/n).expm1())**d
  assert fd<upper
  if fd>max_other:max_other=fd;max_d=d
  elif max_other>fd:pass
  else:raise AssertionError('Unresolved finite scalar maximum')
 guards[n]={'possible_varying_coordinate_counts_checked':n,'f1_beta_upper_Arb':ds(upper),'b_Arb':ds(b),'b_minus_f1_Arb':ds(b-upper),'max_f_d_d_ge2_Arb':ds(max_other),'max_f_d_d_ge2_at_d':max_d,'all_non_singleton_beta_below_b_certified':True,'logic':'For real subset S, k=|S|<=2^d and r=k^(1/n)<=2^(d/n), so beta<=[1-2^(-d/n)]^d<=f1<b. Fixed n finite d certificate, not source enumeration.'}
rows=[]
for n,k,role in cases:
 ts=time.perf_counter();assert 2<=k<n
 rho=(LN2/n).exp();r=(k*LN2/n).exp()
 # Normalized formula: binom(n,j) A^j [1-(1-B)^(n-j)].
 A=(k*LN2/n).expm1()/2
 B=rho*((k-1)*LN2/n).expm1()/2
 assert r>=rho and r<=2 and A>0 and 0<B<1
 loginside=(-B).log1p()
 weight=arb(comb(n,k))*A**k
 normalized=arb(0);term_count=0;positive_terms=0
 for j in range(k,n+1):
  bracket=arb(0) if j==n else -((n-j)*loginside).expm1()
  term=weight*bracket
  if j<n:assert term>0;positive_terms+=1
  else:assert term.contains(0)
  normalized+=term;term_count+=1
  if j<n:weight*=aq(Q(n-j,j+1))*A
 assert term_count==n-k+1 and normalized>0
 ratio=normalized*arb(n).sqrt()
 scalar_lower=C0*(GAMMA*arb(n).log()).exp()/(2+arb(n).log()/(2*LN2)) if role=='minimal_all_blocks_light_k' else None
 if scalar_lower is not None:assert scalar_lower<ratio
 root=isqrt(n);assert root*root==n
 light_ratio=Q(2**k,2*root);light=light_ratio>=1
 assert light==(2**(2*k)>=4*n)
 rows.append({'n':n,'k':k,'role':role,'m_exact':str(2**k),'actual_complete_mass_band':[str(2**k),str(2**k)],'k_range_legal':True,'all_selected_singleton_blocks_light':light,'m_over_2sqrt_n_exact':str(light_ratio),'light_threshold_equality':light_ratio==1,'rho_Arb':ds(rho),'r_Arb':ds(r),'A_r_minus_one_over_two_Arb':ds(A),'B_r_minus_rho_over_two_Arb':ds(B),'full_sum_term_count_including_zero_jn':term_count,'strictly_positive_term_count':positive_terms,'G_volume_over_W_Arb':ds(normalized),'G_volume_over_bW_Arb':ds(ratio),'ratio_gt_one_certified':bool(ratio>1),'analytic_scalar_lower_Arb':ds(scalar_lower) if scalar_lower is not None else None,'actual_ratio_minus_scalar_lower_Arb':ds(ratio-scalar_lower) if scalar_lower is not None else None,'scalar_bound_below_actual_ratio_certified':True if scalar_lower is not None else None,'scalar_consistency_scope':'finite consistency at the prescribed baseline k only' if scalar_lower is not None else 'k-neighbor control excluded from analytic lower-bound comparison','runtime_seconds':time.perf_counter()-ts})
result={'status':'PASS_FROZEN_VERTEX_MODEL_HIGH_BETA_GUARDS_AND_SEVEN_COMPLETE_SUMS','n_values':[16,64,256,1024,4096],'rows':rows,'independent_scalar_certificate':SCALAR_CERT,'symbolic_certificate':SYMBOLIC_CERT,'high_beta_guard_certificates':{str(n):g for n,g in guards.items()},'model':{'nu':'all 2^n vertices of {0,1}^n, mass1 each','lambda':1,'W':'2^n','original_H2':'[-rho/2,1+rho/2]^n, rho=2^(1/n), since only singleton beta>=1/sqrt(n)','G':'{x:nu(Q(x,r))>=m} minus ORIGINAL H2, m=2^k, r=m^(1/n)'},'volume_formula':'|G|/W=2^-n sum_(j=k)^n binom(n,j)(r-1)^j[2^(n-j)-(rho+2-r)^(n-j)]','formula_derivation':'Each coordinate both vertices length r-1; exactly one vertex total length2, of which rho+2-r lies in H2. All both-coordinate intervals lie in H2. j both coordinates give mass2^j. Product receiver lengths and subtraction give complete finite sum.','stable_sum':'A=(r-1)/2 via expm1; B=(r-rho)/2=rho*expm1((k-1)ln2/n)/2. Sum all binom(n,j) A^j[-expm1((n-j)log1p(-B))], recurrence for weights. No term cutoff, final j=n term exact zero.','precision_bits':512,'numerical_certificate':'Arb512 outward balls throughout all logs/exponentials/powers/sums; integer binomial initial value and rational recurrence factors exact; no floating decision or source enumeration.','actual_band_equivalence':'Modulo the finite collection of coordinate capture faces, q>=2^k at side r=2^(k/n) iff x lies in some actual C_S with |S|=2^k. All selected vertices lie strictly inside that cube, so slight side shrink gives maximal average>1. Thus G is the complete actual fixed-mass band residual, contained in the strict maximal level.','scope':'The fixed-r average need not be strictly>1 on q=m, but the complete actual band receiver is inside strict maximal level via side shrink. Only finite frozen n/k, not full Qlight/global weak bound/asymptotic proof. T0 endpoint W payer not removed. n256 k-1 is retained as nonlight control and cannot refute an all-blocks-light claim.','interpreter':sys.executable,'python_version':platform.python_version(),'python_flint_version':flint.__version__,'sympy_version':S.__version__,'command':'OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 '+shlex.join([sys.executable]+sys.argv),'runtime_seconds':time.perf_counter()-START,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'processes':1}
args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps([{k:r[k] for k in ['n','k','role','all_selected_singleton_blocks_light','m_over_2sqrt_n_exact','G_volume_over_W_Arb','G_volume_over_bW_Arb']} for r in rows],indent=2))
print(json.dumps({k:result[k] for k in ['status','runtime_seconds','peak_rss_bytes','precision_bits']},indent=2))
