"""True central mu captured by repeated pairs at the same original middle history."""
import argparse
from collections import defaultdict
from fractions import Fraction as F
import json
from pathlib import Path
import zipfile


def source_cells(main_box, candidates, density, lib):
    n = len(candidates)
    intersections = []
    for mask in range(1 << n):
        boxes = [main_box] + [box for i,box in enumerate(candidates) if mask & (1 << i)]
        intersections.append(lib["comb_mass"](lib["intersection"](*boxes),density))
    cells = intersections.copy()
    for i in range(n):
        for mask in range(1 << n):
            if not mask & (1 << i):
                cells[mask] -= cells[mask | (1 << i)]
    assert sum(cells) == intersections[0] and all(m >= 0 for m in cells)
    for mask in range(1 << n):
        assert intersections[mask] == sum(m for bits,m in enumerate(cells) if mask & bits == mask)
    return cells


def run(label, stage, lib):
    groups = defaultdict(lambda: defaultdict(F))
    parents = {p["id"]:p for p in stage["parents"]}
    mass = {c["mask"]:F(c["mass"]) for c in stage["cells"]}
    count = 0
    for row in stage["roots_cross"]:
        t, u, g = [row[x] for x in ("t","u","g")]
        term = sum(F(row["coefficient"])*mass[z]*mass[q]
                   for z in row["z_masks"] for q in row["q_masks"])
        assert term == F(row["root_mass"])
        groups[t][u,g] += term
        count += len(row["z_masks"])*len(row["q_masks"])
    total = sum(sum(row.values()) for row in groups.values())
    assert count == 230 and total == F(stage["benchmarks"]["cross"]["mother"])
    owners = sorted(p["id"] for p in stage["parents"] if p["role"] == "old")
    index = {p:i for i,p in enumerate(owners)}
    print("\nCOVER fixture",label,"rows",count,"old parents",len(owners))
    for radius in ("old","central","nine_eighths"):
        overall = defaultdict(F)
        for t, pairs in groups.items():
            share = sum(pairs.values())
            law = {(u,g):w/share for (u,g),w in pairs.items()}
            T = parents[t]
            boxes = []
            for i in owners:
                old = parents[i]
                r = F(old["radius"]) if radius=="old" else F(T["radius"])*(F(9,8) if radius=="nine_eighths" else 1)
                boxes.append(tuple((F(x)-r,F(x)+r) for x in old["center"]))
            cells = source_cells(lib["box"](T,"box"),boxes,stage["density"],lib)
            assert sum(cells) == F(T["m"])
            for bits,w in enumerate(cells):
                if not w:
                    continue
                hits = {p for p,j in index.items() if bits & (1 << j)}
                left = sum(v for (u,g),v in law.items() if u in hits)
                right = sum(v for (u,g),v in law.items() if g in hits)
                both = sum(v for (u,g),v in law.items() if u in hits or g in hits)
                product = 1-(1-left)*(1-right)
                for k in (1,2,4,8,32):
                    for mode,eligible in (("right",right),("true_pair",both),("product",product)):
                        assert 0 <= eligible <= 1
                        overall[mode,k] += share/total*w/F(T["m"])*(1-(1-eligible)**k)
        for k in (1,2,4,8,32):
            right,actual,product = (overall[m,k] for m in ("right","true_pair","product"))
            assert right <= actual
            print("union",label,radius,k,"right,original-pair,product",float(right),float(actual),float(product))
            print("exact",right,actual,product)


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--archive",type=Path,required=True)
args = parser.parse_args()
with zipfile.ZipFile(args.archive) as z:
    comb, lib = {"__name__":"archived_comb811"},{"__name__":"archived_trade813"}
    exec(compile(z.read("comb811.py"),"comb811.py","exec"),comb)
    exec(compile(z.read("trade813.py"),"trade813.py","exec"),lib)
    name, dim, h, middle, old = comb["FIXTURES"][-1]
    original = comb["fixture"](name,dim,h,middle,old)
    rebuilt = json.loads(z.read("comb814-rebuilt.json"))["stages"][0]
    for name, data in (("original",original),("rebuilt",rebuilt)):
        run(name,data,lib)
print("All calibrated stock and receiver-union fractions verified exactly.")
