"""Reproduce all R824 computations from the two pinned research bundles."""
import argparse
from fractions import Fraction
import hashlib
from importlib.metadata import version
from pathlib import Path
import platform
import subprocess
import sys
from tempfile import TemporaryDirectory
from zipfile import ZipFile

import flint
from flint import arb, ctx

ROOT = Path(__file__).resolve().parent
R814 = "891d8cbcbd35537e6abc18c938e53b1b4f300327357c24c8d14a51a46ad5e190"
R823 = "49fb22a6274856e4c8d39af4cfb80b10265467bebac89c3ef30a305131a71ebd"


def pinned(path, expected):
    path = path.resolve()
    if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
        raise ValueError(f"Input bundle mismatch: expected {expected}")
    return path


def price_replay(older, previous):
    with TemporaryDirectory(prefix="old-price-replay-", dir=ROOT) as temp, ZipFile(previous) as archive:
        module = Path(temp) / "replay823.py"
        code = archive.read(module.name)
        ns = {"__name__": "archived_price_check", "__file__": str(module)}
        exec(compile(code, module.name, "exec"), ns)
        ns["prices"](older)


def strengthened_costs():
    for prec in (256, 384):
        ctx.prec = prec
        for power in (64, 96, 160):
            n = arb(10**power)
            ell = (n + 2).log()
            jump = n.sqrt() * ell**8
            upper = jump / (1024 * (1 + (n / jump).log()))
            lower = upper - 1
            assert lower > 0 and jump >= upper
            # Ratios in units b. The additive term dominates any displayed n^10 pre-factor.
            tests = (
                ("tree low", -Fraction(5, 2048)),
                ("tree inventory", -Fraction(243, 2048)),
                ("tree re-entry with price", -Fraction(235, 2048)),
                ("public trimming", -Fraction(3, 32)),
                ("reverse real stock", -Fraction(1, 64)),
            )
            for name, exponent in tests:
                interval = arb(exponent.numerator)/exponent.denominator + 10*ell/lower
                assert interval < 0
                print("PARAMS", prec, "n=10^"+str(power), name, "log/b <=", interval.str(12))
            assert 16*(-lower/32).exp() < 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--r814", type=Path, required=True)
    parser.add_argument("--r823", type=Path, required=True)
    args = parser.parse_args()
    if not __debug__:
        raise RuntimeError("Run with assertions enabled.")
    older, previous = pinned(args.r814, R814), pinned(args.r823, R823)
    print("Python", platform.python_version(), "python-flint", flint.__version__,
          "FLINT", flint.__FLINT_VERSION__, "NumPy", version("numpy"), "SciPy", version("scipy"), flush=True)
    print("R814", R814, "R823", R823, flush=True)
    price_replay(older, previous)
    for name in ("chain824.py", "cover824.py", "quota824.py", "code824.py"):
        print("\nRUN", name, flush=True)
        args = [] if name == "code824.py" else ["--archive", str(older)]
        subprocess.run([sys.executable, "-E", "-B", str(ROOT / name), *args], cwd=ROOT, check=True)
    strengthened_costs()
    print("PASS complete round 824 exact replay")


if __name__ == "__main__":
    main()
