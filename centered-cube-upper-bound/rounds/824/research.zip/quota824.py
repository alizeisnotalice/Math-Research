"""Exact finite R814 top-D, low-density, and vertex-peeling diagnostics.

For each real z/q membership cell, actual parent identities and recorded
coefficient are retained. Source mu is constant only *relative to itself*
within a membership cell. Receiver-owner conditioning follows the explicit
R814 product model; price-merged mode is only an off-hypothesis comparison.
"""

from collections import defaultdict
from fractions import Fraction as F
from itertools import product
import argparse, json, zipfile

DELTAS = (F(1, 8), F(1, 4), F(1, 2), F(3, 4), F(64, 81), F(15, 16), F(1))
EPSILONS = (F(1, 8), F(1, 2))


def build(stage, merged):
    parents = {p["id"]: p for p in stage["parents"]}
    cells = {c["mask"]: F(c["mass"]) for c in stage["cells"]}
    raw = []
    for root in stage["roots_cross"]:
        t, u, g = (root[k] for k in ("t", "u", "g"))
        D = F(64) if merged else F(parents[t]["volume_bin"])
        for z, q in product(root["z_masks"], root["q_masks"]):
            w = F(root["coefficient"]) * cells[z] * cells[q]
            assert w > 0
            raw.append({"t": t, "D": D, "L": (u, z, D), "R": (g, q, D), "w": w})
    assert len(raw) == 230
    total = sum((e["w"] for e in raw), F(0))
    assert total == F(stage["benchmarks"]["cross"]["mother"])
    return parents, cells, raw, total


def prepare(parents, cells, edges):
    gamma = {side: defaultdict(F) for side in ("L", "R")}
    t_weight = {side: defaultdict(lambda: defaultdict(F)) for side in ("L", "R")}
    for e in edges:
        for side in gamma:
            B = e[side]
            gamma[side][B] += e["w"]
            t_weight[side][B][e["t"]] += e["w"]
    density = {}
    top = {}
    for side in ("L", "R"):
        for B, g in gamma[side].items():
            D = B[2]
            terms = t_weight[side][B]
            values = {
                mask: sum(
                    (
                        w / g / F(parents[t]["m"])
                        for t, w in terms.items()
                        if mask & parents[t]["bit"]
                    ),
                    F(0),
                )
                for mask in cells
            }
            assert sum((values[mask] * mass for mask, mass in cells.items()), F(0)) == 1
            left = D
            integral = F(0)
            for mask in sorted(cells, key=lambda x: values[x], reverse=True):
                amount = min(left, cells[mask])
                integral += amount * values[mask]
                left -= amount
                if not left:
                    break
            assert left == 0 and 0 <= integral <= 1
            density[side, B] = values
            top[side, B] = integral
    return gamma, density, top


def evaluate(
    parents, cells, edges, total, gamma, density, top, delta, epsilon, seed=None
):
    liveB = {
        side: {B for B in gamma[side] if top[side, B] <= delta} for side in ("L", "R")
    }
    H = {}
    surviving = []
    for i, e in enumerate(edges):
        if seed is not None and i not in seed:
            continue
        if e["L"] not in liveB["L"] or e["R"] not in liveB["R"]:
            continue
        bit = parents[e["t"]]["bit"]
        mt = F(parents[e["t"]]["m"])
        D = e["D"]
        left, right = density["L", e["L"]], density["R", e["R"]]
        highL = (
            sum(
                (
                    mass
                    for mask, mass in cells.items()
                    if mask & bit and left[mask] > delta / D
                ),
                F(0),
            )
            / mt
        )
        highR = (
            sum(
                (
                    mass
                    for mask, mass in cells.items()
                    if mask & bit and right[mask] > delta / D
                ),
                F(0),
            )
            / mt
        )
        if highL > epsilon or highR > epsilon:
            continue
        valid = tuple(
            mask
            for mask in cells
            if mask & bit and left[mask] <= delta / D and right[mask] <= delta / D
        )
        h = sum((cells[m] for m in valid), F(0))
        if not h:
            continue
        H[i] = (valid, h)
        surviving.append(i)
    pre = sum((edges[i]["w"] for i in surviving), F(0))
    rounds = 0
    removed = 0
    while True:
        curr = {side: defaultdict(F) for side in ("L", "R")}
        for i in surviving:
            e = edges[i]
            for side in curr:
                curr[side][e[side]] += e["w"]
        bad = {
            side: {B for B in gamma[side] if curr[side][B] < gamma[side][B] / 4}
            for side in ("L", "R")
        }
        keep = [
            i
            for i in surviving
            if edges[i]["L"] not in bad["L"] and edges[i]["R"] not in bad["R"]
        ]
        if len(keep) == len(surviving):
            break
        removed += len(surviving) - len(keep)
        surviving = keep
        rounds += 1
    final = sum((edges[i]["w"] for i in surviving), F(0))
    peaks = {}
    probability_peaks = {}
    for side in ("L", "R"):
        curr = defaultdict(F)
        occ = defaultdict(lambda: defaultdict(F))
        probability_occ = defaultdict(lambda: defaultdict(F))
        for i in surviving:
            e = edges[i]
            B = e[side]
            curr[B] += e["w"]
            masks, h = H[i]
            for mask in masks:
                occ[B][mask] += e["w"] / h
                probability_occ[B][mask] += e["w"]
        worst = F(0)
        worst_probability = F(0)
        for B, g in curr.items():
            assert g >= gamma[side][B] / 4
            for mask, weight in occ[B].items():
                worst = max(worst, B[2] * weight / g)
            for mask, weight in probability_occ[B].items():
                worst_probability = max(worst_probability, weight / g)
        peaks[side] = worst
        probability_peaks[side] = worst_probability
        assert worst_probability <= min(F(1), 8 * delta)
    return {
        "pre": pre,
        "final": final,
        "rounds": rounds,
        "removed": removed,
        "edges": len(surviving),
        "peaks": peaks,
        "probability_peaks": probability_peaks,
        "boundL": peaks["L"] <= 8 * delta,
        "boundR": peaks["R"] <= 8 * delta,
        "surviving": surviving,
        "H": H,
    }


def union_check(cells, edges, result):
    """Exact iid draws given one right vertex, grouped by identical H."""
    surviving = result["surviving"]
    if not surviving:
        return
    groups = defaultdict(F)
    for i in surviving:
        groups[edges[i]["R"]] += edges[i]["w"]
    B = max(groups, key=groups.get)
    gamma = groups[B]
    laws = defaultdict(F)
    for i in surviving:
        if edges[i]["R"] == B:
            masks, _ = result["H"][i]
            laws[tuple(sorted(masks))] += edges[i]["w"] / gamma
    assert sum(laws.values(), F(0)) == 1
    entries = [(set(masks), p) for masks, p in laws.items()]
    assert len(entries) <= 12  # bounded finite enumeration for this fixture
    for k in (2, 4):
        formula_union = formula_private = F(0)
        for mask, mass in cells.items():
            p = sum((prob for H, prob in entries if mask in H), F(0))
            formula_union += mass * (1 - (1 - p) ** k)
            formula_private += mass * k * p * (1 - p) ** (k - 1)
        enum_union = enum_private = F(0)
        for chosen in product(entries, repeat=k):
            Hs = [x[0] for x in chosen]
            probability = F(1)
            for _, p in chosen:
                probability *= p
            un = set().union(*Hs)
            enum_union += probability * sum((cells[m] for m in un), F(0))
            for j in range(k):
                others = set().union(*(Hs[:j] + Hs[j + 1 :]))
                enum_private += probability * sum(
                    (cells[m] for m in Hs[j] - others), F(0)
                )
        assert formula_union == enum_union
        assert formula_private == enum_private
        print(
            " UNION_CHECK right_vertex=",
            B,
            "k=",
            k,
            "H_types=",
            len(entries),
            "union~",
            float(formula_union),
            "slot_private~",
            float(formula_private),
            "expected_union_exact=",
            formula_union,
            "slot_private_exact=",
            formula_private,
        )


def q_only_check(cells, edges, result):
    """Draw iid retained records after conditioning only on exact q-cell."""
    by_q = defaultdict(list)
    for i in result["surviving"]:
        by_q[edges[i]["R"][1]].append(i)
    if not by_q:
        return
    q = max(
        by_q,
        key=lambda q: (
            len({edges[i]["t"] for i in by_q[q]}),
            sum((edges[i]["w"] for i in by_q[q]), F(0)),
        ),
    )
    ids = by_q[q]
    parents = sorted({edges[i]["t"] for i in ids})
    gamma = sum((edges[i]["w"] for i in ids), F(0))
    laws = defaultdict(F)
    for i in ids:
        masks, _ = result["H"][i]
        laws[tuple(sorted(masks))] += edges[i]["w"] / gamma
    assert sum(laws.values(), F(0)) == 1
    entries = [(set(masks), p) for masks, p in laws.items()]
    assert len(entries) <= 12
    for k in (2, 4):
        inventory = k * sum(
            (p * sum((cells[x] for x in H), F(0)) for H, p in entries), F(0)
        )
        union = private = F(0)
        for mask, mass in cells.items():
            p = sum((prob for H, prob in entries if mask in H), F(0))
            union += mass * (1 - (1 - p) ** k)
            private += mass * k * p * (1 - p) ** (k - 1)
        enum_union = enum_private = F(0)
        for chosen in product(entries, repeat=k):
            Hs = [x[0] for x in chosen]
            probability = F(1)
            for _, p in chosen:
                probability *= p
            enum_union += probability * sum((cells[m] for m in set().union(*Hs)), F(0))
            for i in range(k):
                others = set().union(*(Hs[:i] + Hs[i + 1 :]))
                enum_private += probability * sum(
                    (cells[m] for m in Hs[i] - others), F(0)
                )
        assert enum_union == union and enum_private == private
        print(
            " Q_ONLY q=",
            q,
            "parents=",
            parents,
            "records=",
            len(ids),
            "H_types=",
            len(entries),
            "k=",
            k,
            "inventory~",
            float(inventory),
            "union~",
            float(union),
            "private~",
            float(private),
            "exact inventory,union,private=",
            inventory,
            union,
            private,
        )


def run(name, stage, merged):
    parents, cells, edges, total = build(stage, merged)
    gamma, density, top = prepare(parents, cells, edges)
    print(
        "\nFIXTURE",
        name,
        "price_mode=",
        ("merged_D64_offhypothesis" if merged else "separate_D"),
        "records=",
        len(edges),
        "total=",
        total,
        "vertices L/R=",
        len(gamma["L"]),
        len(gamma["R"]),
    )
    for side in ("L", "R"):
        values = sorted(top[side, B] for B in gamma[side])
        print(
            " TOP_D",
            side,
            "min/median/max~=",
            float(values[0]),
            float(values[len(values) // 2]),
            float(values[-1]),
            "exact range=",
            values[0],
            values[-1],
        )
    for delta in DELTAS:
        for epsilon in EPSILONS:
            result = evaluate(
                parents, cells, edges, total, gamma, density, top, delta, epsilon
            )
            print(
                " GATE delta=",
                delta,
                "eps=",
                epsilon,
                "pre/total=",
                float(result["pre"] / total),
                "final/total=",
                float(result["final"] / total),
                "edges=",
                result["edges"],
                "peel_rounds=",
                result["rounds"],
                "pmax L/R=",
                float(result["probability_peaks"]["L"]),
                float(result["probability_peaks"]["R"]),
                "p<=min(1,8delta)=",
                "verified" if result["edges"] else "vacuous_no_surviving_vertices",
                "peaks D*g=",
                float(result["peaks"]["L"]),
                float(result["peaks"]["R"]),
                "<=8delta=",
                result["boundL"],
                result["boundR"],
            )
            if epsilon == F(1, 8) and delta in (F(64, 81), F(15, 16)):
                union_check(cells, edges, result)
            if not merged and epsilon == F(1, 8) and delta == F(15, 16):
                q_only_check(cells, edges, result)
    if not merged:
        # Deliberately erase every edge incident to one vertex except a small
        # positive edge. This is a peeling stress mask, not a geometric root.
        found = None
        for side in ("L", "R"):
            for B, g in gamma[side].items():
                incident = [i for i, e in enumerate(edges) if e[side] == B]
                for i in incident:
                    if edges[i]["w"] < g / 4:
                        found = side, B, i, incident
                        break
                if found:
                    break
            if found:
                break
        assert found
        side, B, chosen, incident = found
        seed = (set(range(len(edges))) - set(incident)) | {chosen}
        result = evaluate(
            parents, cells, edges, total, gamma, density, top, F(1), F(1, 8), seed
        )
        assert result["rounds"] > 0 and result["removed"] > 0
        print(
            " ARTIFICIAL_MASK victim=",
            side,
            B,
            "kept_victim_fraction=",
            edges[chosen]["w"] / gamma[side][B],
            "initial_removed=",
            len(edges) - len(seed),
            "post_mask_pre=",
            float(result["pre"] / total),
            "post_peel=",
            float(result["final"] / total),
            "peeled_edges=",
            result["removed"],
            "peel_rounds=",
            result["rounds"],
            "not_a_root_filter=true",
        )


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--archive", required=True)
args = parser.parse_args()
with zipfile.ZipFile(args.archive) as z:
    rebuilt = json.loads(z.read("comb814-rebuilt.json"))["stages"][0]
    ns = {"__name__": "archived_comb811"}
    exec(compile(z.read("comb811.py"), "comb811.py", "exec"), ns)
    name, n, h, middle, old = ns["FIXTURES"][-1]
    original = ns["fixture"](name, n, h, middle, old)
    for label, stage in [("original", original), ("rebuilt", rebuilt)]:
        run(label, stage, False)
        run(label, stage, True)
print(
    "\nPASS exact Fraction cell densities and finite peeling; n=4 high-dimensional long-jump gate is empty"
)
