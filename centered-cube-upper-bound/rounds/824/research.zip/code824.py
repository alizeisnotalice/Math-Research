#!/usr/bin/env python3
"""Exact small boxes and certified scalar asymptotic gates for the R824 geometry.

All dilations are about each box's own center.  The underlying measure is
Lebesgue measure restricted to the union of the *undilated* physical boxes.
The script never enumerates source-grid cells or high-dimensional codewords.
"""
from fractions import Fraction
from itertools import combinations, product
from math import prod

from flint import arb, ctx


F = Fraction
ZERO = F(0)
ALPHAS = (F(1), F(17, 16))
BIG_DIMENSIONS = (10**64, 10**96, 10**160)
DIAGNOSTIC_DIMENSIONS = (96, 160)


def centered_box(center, radius):
    return tuple((point - radius, point + radius) for point in center)


def intersection(first, second):
    clipped = tuple((max(a, c), min(b, d)) for (a, b), (c, d) in zip(first, second))
    if any(a >= b for a, b in clipped):
        return None
    return clipped


def volume(box):
    return ZERO if box is None else prod((hi - lo for lo, hi in box), start=F(1))


def union_volume(boxes):
    """Maintain signed inclusion-exclusion for rectangles, merging repeats."""
    signed = {}
    for box in boxes:
        if box is None:
            continue
        updated = dict(signed)
        updated[box] = updated.get(box, 0) + 1
        for old, coefficient in signed.items():
            overlap = intersection(old, box)
            if overlap is not None:
                updated[overlap] = updated.get(overlap, 0) - coefficient
        signed = {box: coefficient for box, coefficient in updated.items() if coefficient}
    return sum((coefficient * volume(box) for box, coefficient in signed.items()), start=ZERO)


def mass(box, support):
    if box is None:
        return ZERO
    return union_volume(intersection(box, physical) for physical in support)


def hamming(first, second):
    return sum(a != b for a, b in zip(first, second))


def small_code(m, maximum=5):
    required = (m + 3) // 4
    selected = []
    for word in product((-1, 1), repeat=m):
        if all(hamming(word, old) >= required for old in selected):
            selected.append(word)
        if len(selected) == maximum:
            break
    return selected


def balanced(word):
    return tuple(coordinate for sign in word for coordinate in (sign, -sign))


def check_finite(m):
    n = 2 * m
    words = [balanced(word) for word in small_code(m)]
    k = len(words)
    assert all(sum(word) == 0 for word in words)
    assert all(hamming(a, b) >= F(n, 4) for a, b in combinations(words, 2))

    central_centers = [tuple(F(3, 4) * sign for sign in word) for word in words]
    left_centers = [tuple(3 * sign for sign in word) for word in words]
    right_center = (F(1),) * n
    central = [centered_box(center, F(3, 2)) for center in central_centers]
    left = [centered_box(center, F(1)) for center in left_centers]
    right = centered_box(right_center, F(1))
    support = central + left + [right]
    shared_q_box = ((F(0), F(1, 4)),) * n
    central_mass, small_mass, private_corner = 3**n, 2**n, F(1, 4)**n

    assert mass(shared_q_box, support) == private_corner
    assert all(intersection(box, shared_q_box) == shared_q_box for box in central + [right])
    assert all(mass(box, support) == central_mass for box in central)
    assert all(mass(box, support) == small_mass for box in left + [right])
    assert all(intersection(a, b) is None for a, b in combinations(left + [right], 2))

    private_corners = []
    for i in range(k):
        corner = intersection(central[i], left[i])
        assert volume(corner) == private_corner == mass(corner, support)
        private_corners.append(corner)
        for j in range(k):
            if i != j:
                assert intersection(left[i], central[j]) is None
    assert union_volume(private_corners) == k * private_corner
    for left_box, corner in zip(left, private_corners):
        gaps = [max(F(0), a - d, c - b)
                for (a, b), (c, d) in zip(left_box, right)]
        assert gaps.count(F(2)) == m and gaps.count(F(0)) == m
        source_gap = sum(max(F(0), a - d, c - b)
                         for (a, b), (c, d) in zip(corner, shared_q_box))
        assert source_gap == F(15 * n, 8)
    support_mass = union_volume(support)
    assert support_mass == (
        union_volume(central)
        + k * (small_mass - private_corner)
        + small_mass - union_volume(intersection(right, box) for box in central)
    )

    owners = [
        centered_box(center, F(3, 64 * n)) for center in central_centers
    ] + [
        centered_box(center, F(1, 32 * n)) for center in left_centers + [right_center]
    ]
    assert all(intersection(a, b) is None for a, b in combinations(owners, 2))

    print(f"EXACT n={n} k={k} S={support_mass} corner_total={k * private_corner} q_mass={private_corner}")
    for alpha in ALPHAS:
        big_central = [centered_box(center, F(3, 2) * alpha) for center in central_centers]
        big_left = [centered_box(center, alpha) for center in left_centers]
        big_right = centered_box(right_center, alpha)
        true_expanded_ratios = []
        private_central_total = ZERO
        fully_private_central_total = ZERO
        private_left_total = ZERO
        alpha_right_cut = (2 * alpha * (alpha - F(1, 4)))**m
        alpha_central_right = (2 * (F(3, 2) * alpha - F(3, 4)))**m
        alpha_left_cut = (alpha - F(3, 4))**n
        alpha_central_left = (F(3, 2) * alpha - F(5, 4))**n

        for i in range(k):
            assert mass(intersection(central[i], big_right), support) == alpha_right_cut
            assert mass(intersection(right, big_central[i]), support) == alpha_central_right
            assert mass(intersection(central[i], big_left[i]), support) == alpha_left_cut
            assert mass(intersection(left[i], big_central[i]), support) == alpha_central_left

            both_right = intersection(big_central[i], big_right)
            assert volume(both_right) == (2 * alpha * (F(5, 2) * alpha - F(7, 4)))**m
            assert mass(both_right, support) <= volume(both_right)
            both_left = intersection(big_central[i], big_left[i])
            assert volume(both_left) == (F(5, 2) * alpha - F(9, 4))**n
            assert mass(both_left, support) <= volume(both_left)
            assert intersection(big_left[i], big_right) is None

            central_cuts = []
            for j in range(k):
                if i == j:
                    continue
                distance = hamming(words[i], words[j])
                overlap = intersection(central[i], big_central[j])
                assert mass(overlap, support) == central_mass * (alpha / 2)**distance
                central_cuts.append(overlap)

                assert intersection(big_left[i], big_central[j]) is None
                assert intersection(big_left[i], big_left[j]) is None
                if j > i:
                    enlarged_overlap = intersection(big_central[i], big_central[j])
                    geometric = central_mass * alpha**(n - distance) * (alpha - F(1, 2))**distance
                    assert volume(enlarged_overlap) == geometric
                    actual = mass(enlarged_overlap, support)
                    assert 0 < actual <= geometric
                    if alpha == 1:
                        assert actual == geometric == central_mass * F(1, 2)**distance
                    true_expanded_ratios.append(actual / central_mass)

            central_private = central_mass - union_volume(central_cuts)
            other_indices = [j for j in range(k) if i != j]
            differences = {
                j: {axis for axis in range(n) if words[i][axis] != words[j][axis]}
                for j in other_indices
            }
            exact_private_formula = sum(
                (
                    (-1)**count * central_mass * (alpha / 2)**len(
                        set().union(*(differences[j] for j in peers))
                    )
                    for count in range(len(other_indices) + 1)
                    for peers in combinations(other_indices, count)
                ),
                start=ZERO,
            )
            assert central_private == exact_private_formula
            private_central_total += central_private
            full_cuts = central_cuts + [intersection(central[i], big_left[i]),
                                        intersection(central[i], big_right)]
            fully_private_central_total += central_mass - union_volume(full_cuts)
            private_left_total += small_mass - alpha_central_left

        pair_sum = sum(
            (central_mass * (alpha / 2)**hamming(a, b)
             for i, a in enumerate(words) for j, b in enumerate(words) if i != j),
            start=ZERO,
        )
        assert private_central_total >= k * central_mass - pair_sum
        assert fully_private_central_total >= k * central_mass - pair_sum - k * (alpha_right_cut + alpha_left_cut)
        private_right = small_mass - union_volume(intersection(right, box) for box in big_central)
        assert private_right >= small_mass - k * alpha_central_right

        print(
            f"  alpha={alpha} central_private={private_central_total} "
            f"central_private_all={fully_private_central_total} "
            f"left_private={private_left_total} right_private={private_right} "
            f"max_two_expanded_true_ratio={max(true_expanded_ratios, default=ZERO)}"
        )
        check_same_scale_privacy(alpha, central, left_centers, right_center, big_central, support)
    print(f"  base_right_thin={F(3, 8)**m} base_left_thin={F(1, 8)**n}")


def check_same_scale_privacy(alpha, central, left_centers, right_center, expanded_central, support):
    n = len(central[0])
    m = n // 2
    beta = F(3, 2) * alpha
    assert beta < F(8, 5)
    expanded_left = [centered_box(center, beta) for center in left_centers]
    expanded_right = centered_box(right_center, beta)
    right_cut = ((beta + F(5, 4)) * (beta - F(1, 4)))**m
    own_left_cut = (beta - F(3, 4))**n
    total = ZERO
    for i, middle in enumerate(central):
        assert mass(intersection(middle, expanded_right), support) == right_cut
        assert mass(intersection(middle, expanded_left[i]), support) == own_left_cut
        assert all(
            intersection(expanded_left[i], peer) is None
            for j, peer in enumerate(expanded_central) if i != j
        )
        hub_gaps = [
            max(ZERO, a - d, c - b)
            for (a, b), (c, d) in zip(expanded_left[i], expanded_right)
        ]
        assert hub_gaps.count(4 - 2 * beta) == m
        assert hub_gaps.count(ZERO) == m
        assert intersection(expanded_left[i], expanded_right) is None
        assert volume(intersection(expanded_central[i], expanded_right)) == (
            (2 * beta - F(1, 4)) * (2 * beta - F(7, 4))
        )**m
        assert volume(intersection(expanded_central[i], expanded_left[i])) == (
            2 * beta - F(9, 4)
        )**n
        peers = [intersection(middle, peer)
                 for j, peer in enumerate(expanded_central) if i != j]
        cuts = peers + [
            intersection(middle, expanded_left[i]),
            intersection(middle, expanded_right),
        ]
        private = volume(middle) - union_volume(cuts)
        assert private >= 0
        assert private >= volume(middle) - sum(map(volume, peers)) - own_left_cut - right_cut
        total += private
    denominator = len(central) * volume(central[0])
    print(f"    same_scale_private={total} same_scale_private_fraction={total / denominator} "
          f"hub_gap_in_minus_axes={4 - 2 * beta}")


def arb_fraction(value):
    return arb(value.numerator) / value.denominator


def check_scalar(n, bits, expected_jump):
    """Certify log comparisons.  Do not materialize k or very large boxes."""
    ctx.prec = bits
    nn = arb(n)
    alpha = arb_fraction(ALPHAS[-1])
    log_two = arb(2).log()
    ell = arb(n + 2).log()
    jump = nn.sqrt() * ell**8
    log_jump = nn * (arb(3) / 2).log()
    if expected_jump:
        assert log_jump > jump
    else:
        assert log_jump < jump

    # Greedy capacity >= (3^(3/4)/2)^(n/2); also use a simpler rational certificate.
    greedy_lo = nn * (arb(9) / 8).log() / 2
    greedy_true = nn * (3 * arb(3).log() / 8 - log_two / 2)
    assert greedy_true > greedy_lo > nn / 64
    assert nn / 64 > log_two  # log floor(e^(n/64)) >= n/64 - log 2.

    pair_plain = -nn * log_two / 4
    pair_one = nn * (alpha / 2).log() / 4
    pair_both = nn * (3 * alpha.log() + (alpha - arb(1) / 2).log()) / 4
    assert pair_plain < pair_one < pair_both < 0

    one_left = nn * ((3 * alpha / 2 - arb(5) / 4) / 2).log()
    one_right = nn * (3 * alpha / 4 - arb(3) / 8).log() / 2
    both_left = nn * ((5 * alpha / 2 - arb(9) / 4) / 2).log()
    both_right = nn * (alpha * (5 * alpha / 2 - arb(7) / 4) / 2).log() / 2
    # r_0 = ceil(sqrt(n) ell^2) <= sqrt(n) ell^2 + 1.
    r0_up = nn.sqrt() * ell**2 + 1
    log_thin_gate_lower = -r0_up / 256
    assert one_left < log_thin_gate_lower and one_right < log_thin_gate_lower
    assert both_left < log_thin_gate_lower and both_right < log_thin_gate_lower
    # R818 b_0 = floor(r_0/(65536 ell))/16; R=1.
    assert 15 * nn / 8 > r0_up / (1048576 * ell)

    # Relative central source loss to all other alpha parents (own left + common right).
    central_from_peers = nn / 64 + pair_one
    central_from_right = nn * (2 * alpha * (alpha - arb(1) / 4) / 9).log() / 2
    central_from_own_left = nn * ((alpha - arb(3) / 4) / 3).log()
    for term in (central_from_peers, central_from_right, central_from_own_left):
        assert term + arb(3).log() < -nn / 16

    def short(value):
        return value.str(12)

    name = f"10^{len(str(n)) - 1}" if n in BIG_DIMENSIONS else str(n)
    print(
        f"ARB bits={bits} n={name} J_pass={expected_jump} "
        f"J/n={short(jump / nn)} log_jump/n={short(log_jump / nn)} "
        f"log_code_capacity_lower/n={short(greedy_lo / nn)} "
        f"log_pair_plain/n={short(pair_plain / nn)} "
        f"log_pair_one/n={short(pair_one / nn)} log_pair_both/n={short(pair_both / nn)} "
        f"log_both_left/n={short(both_left / nn)} log_both_right/n={short(both_right / nn)} "
        f"log_thin_gate_lower/n={short(log_thin_gate_lower / nn)} "
        "central_private_loss<exp(-n/16)"
    )


def check_added_scalar_budgets(n, bits):
    ctx.prec = bits
    nn = arb(n)
    ell = arb(n + 2).log()
    jump = nn.sqrt() * ell**8
    alpha = arb_fraction(F(17, 16))
    beta = 3 * alpha / 2
    assert beta < arb(8) / 5 and 4 - 2 * beta > 0 and arb(15) / 4 - 2 * beta > 0

    # Total loss over all k original central boxes, in units of one m_t=3^n.
    peers_squared = nn / 32 + nn * (alpha / 2).log() / 4
    hub_cut = nn / 64 + nn * (
        (beta + arb(5) / 4) * (beta - arb(1) / 4) / 9
    ).log() / 2
    own_left_cut = nn / 64 + nn * ((beta - arb(3) / 4) / 3).log()
    for term in (peers_squared, hub_cut, own_left_cut):
        assert term + arb(3).log() < -nn / 16
    two_enlarged_squared = nn / 32 + nn * (
         3 * alpha.log() + (alpha - arb(1) / 2).log()
    ) / 4
    assert two_enlarged_squared < -nn / 32

    # The floor may exceed the absolute resolution of a 256-bit ball.
    # Enclosing it by x-1 <= floor(x) <= x preserves all strict comparisons.
    log_size_ratio = 1 + (nn / jump).log()
    b_upper = jump / (1024 * log_size_ratio)
    b_lower = b_upper - 1
    assert b_lower > 0
    assert b_upper * (1 + (1024 * nn / b_upper).log()) < jump / 512

    # k <= exp(b/1024), lambda^n=exp(b/512), theta=exp(-b/512),
    # tau=tau'=exp(-b/256), E0 <= n^10 exp(-b/8).
    estimates = (
        ("k^2 lambda^n E0/theta", 10, F(-61, 512)),
        ("k^2 lambda^n E0/tau", 10, F(-15, 128)),
        ("kN tau", 1, F(-3, 1024)),
    )
    print(f"ADDED bits={bits} n=10^{len(str(n)) - 1} "
          f"b/J<={(b_upper / jump).str(12)} "
          f"log_two_enlarged_k_squared/n={(two_enlarged_squared / nn).str(12)} "
          "total_middle_loss<3^n exp(-n/16)")
    for label, log_power, coefficient in estimates:
        plain = arb_fraction(coefficient) + log_power * ell / b_lower
        scaled = plain + arb(1) / 2048
        assert plain < 0 and scaled < 0
        print(f"  {label}: log/b<={plain.str(12)}; "
              f"after dividing exp(-b/2048), log/b<={scaled.str(12)}")


def main():
    assert F(27, 16) > F(9, 8)**4
    for m in (1, 2, 4, 6, 8):
        check_finite(m)
    for bits in (256, 384):
        for n in BIG_DIMENSIONS:
            check_scalar(n, bits, expected_jump=True)
            check_added_scalar_budgets(n, bits)
        for n in DIAGNOSTIC_DIMENSIONS:
            check_scalar(n, bits, expected_jump=False)
    print("PASS: exact Fraction geometry and Arb scalar gate assertions.")
    print("Scope: geometric positive-L1 witness only; no original d_v, stopping history, or tree posterior.")


if __name__ == "__main__":
    main()
