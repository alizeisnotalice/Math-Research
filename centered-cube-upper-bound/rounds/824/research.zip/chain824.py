"""R814 exact parent-chain, slot-private, and nonneighbor-q diagnostics.

A=iid records; B=one shared physical q then conditional iid records;
C=stationary t -> (q,g) -> t bridge; Cq redraws q alone at each step.
On the R814 model, membership mask is sufficient for q and its donor mark;
W is independently uniform on E_g, so it supplies no further t information.
Finite n=4 is diagnostic only: the original high-dimensional gate is empty.
"""

import argparse, json, zipfile
from collections import defaultdict
from fractions import Fraction as F
from itertools import product


def make_law(weights, names):
    M = sum(weights.values(), F(0))
    assert M > 0
    pt = defaultdict(F)
    pq = defaultdict(F)
    pr = defaultdict(F)
    tq = defaultdict(F)
    tr = defaultdict(F)
    for (t, q, g), w in weights.items():
        v = w / M
        pt[t] += v
        pq[q] += v
        pr[q, g] += v
        tq[t, q] += v
        tr[t, (q, g)] += v
    assert (
        sum(pt.values(), F(0)) == sum(pq.values(), F(0)) == sum(pr.values(), F(0)) == 1
    )
    A = {(t, s): pt[t] * pt[s] for t in names for s in names}
    B = {
        (t, s): sum((tq[t, q] * tq[s, q] / pq[q] for q in pq), F(0))
        for t in names
        for s in names
    }
    C = {
        (t, s): sum((tr[t, r] * tr[s, r] / pr[r] for r in pr), F(0))
        for t in names
        for s in names
    }
    for pair in (A, B, C):
        assert all(sum((pair[t, s] for s in names), F(0)) == pt[t] for t in names)
    return M, pt, pq, pr, tq, tr, A, B, C


def neighbor(label, weights, names, parents, reference):
    M, pt, pq, pr, tq, tr, A, B, C = make_law(weights, names)
    # edge[a,b,q] is the unconditional stationary weight of the bridge a->b
    # with the physically sampled q in this membership cell.
    edge = defaultdict(F)
    for (q, g), rweight in pr.items():
        for a, b in product(names, repeat=2):
            edge[a, b, q] += tr[a, (q, g)] * tr[b, (q, g)] / rweight
    assert all(
        sum((edge[a, b, q] for q in pq), F(0)) == C[a, b]
        for a, b in product(names, repeat=2)
    )
    off = sum((C[a, b] for a, b in product(names, repeat=2) if a != b), F(0))
    results = {}
    for branch in ("adjacent_distinct", "all_three_distinct"):
        tot = forward = reverse = both = F(0)
        for a, b, c in product(names, repeat=3):
            if a == b or b == c:
                continue
            if branch == "all_three_distinct" and a == c:
                continue
            weight = C[a, b] * C[b, c] / pt[b]
            first_q_hits = sum(
                (edge[a, b, q] for q in pq if q & parents[c]["bit"]), F(0)
            )
            second_q_hits = sum(
                (edge[b, c, q] for q in pq if q & parents[a]["bit"]), F(0)
            )
            tot += weight
            forward += C[a, b] * second_q_hits / pt[b]
            reverse += first_q_hits * C[b, c] / pt[b]
            both += first_q_hits * second_q_hits / pt[b]
        if tot:
            assert 0 <= both <= min(forward, reverse) <= tot
            results[branch] = (tot, forward / tot, reverse / tot, both / tot)
    print(
        "BRIDGE",
        label,
        "parents=",
        names,
        "raw_original_mass_fraction_approx=",
        float(M / reference),
        "one_step_offdiag_approx=",
        float(off),
        "exact=",
        M / reference,
        off,
    )
    for branch, (path, fwd, rev, both) in results.items():
        print(
            "  NONNEIGHBOR",
            branch,
            "path_probability=",
            float(path),
            "forward=",
            float(fwd),
            "reverse=",
            float(rev),
            "both=",
            float(both),
            "bridge_path_over_full_original_mass=",
            float(M * path / reference),
            "bridge_forward_over_full_original_mass=",
            float(M * path * fwd / reference),
            "exact=",
            path,
            fwd,
            rev,
            both,
        )
    if not results:
        print("  NONNEIGHBOR no positive nonself paths")
    return (M, pt, pq, pr, tq, tr, A, B, C)


def evaluate(label, stage):
    parents = {p["id"]: p for p in stage["parents"]}
    cells = {c["mask"]: F(c["mass"]) for c in stage["cells"]}
    names = sorted(p["id"] for p in stage["parents"] if p["role"] == "middle")
    assert len(names) == 3
    weights = defaultdict(F)
    records = 0
    for root in stage["roots_cross"]:
        for z, q in product(root["z_masks"], root["q_masks"]):
            weights[root["t"], q, root["g"]] += (
                F(root["coefficient"]) * cells[z] * cells[q]
            )
            records += 1
    M, pt, pq, pr, tq, tr, A, B, C = make_law(weights, names)
    assert records == 230 and M == F(stage["benchmarks"]["cross"]["mother"])
    parent_mass = {t: F(parents[t]["m"]) for t in names}
    assert all(
        parent_mass[t]
        == sum((v for mask, v in cells.items() if mask & parents[t]["bit"]), F(0))
        for t in names
    )

    def bits(counts):
        return sum(parents[t]["bit"] for t, c in zip(names, counts) if c)

    def union(counts):
        mask = bits(counts)
        return sum((v for q, v in cells.items() if q & mask), F(0))

    def inter(counts):
        mask = bits(counts)
        return sum((v for q, v in cells.items() if q & mask == mask), F(0))

    def private(t, counts):
        other = sum(parents[s]["bit"] for s, c in zip(names, counts) if c and s != t)
        bit = parents[t]["bit"]
        return sum((v for q, v in cells.items() if q & bit and not q & other), F(0))

    print(
        "\nFIXTURE",
        label,
        "raw_original_mass=",
        M,
        "records=",
        records,
        "parent bins=",
        {t: parents[t]["volume_bin"] for t in names},
    )
    for i, t in enumerate(names):
        for j in range(i, 3):
            s = names[j]
            count = tuple(int(k in (i, j)) for k in range(3))
            both = inter(count)
            print(
                "PAIR",
                t,
                s,
                "inter/max=",
                float(both / max(parent_mass[t], parent_mass[s])),
                "private_t=",
                private(t, count),
                "private_s=",
                private(s, count),
                "small_saturated=",
                both == min(parent_mass[t], parent_mass[s]),
            )
    for mode in ("independent", "fixed_q", "right_qg", "redrawn_q"):

        def init(t):
            return tuple(int(x == t) for x in names)

        if mode == "fixed_q":
            states = {(q, t, init(t)): tq[t, q] for q in pq for t in names if tq[t, q]}
        else:
            states = {(None, t, init(t)): pt[t] for t in names}
        for k in range(1, 9):
            if k in (2, 3, 5, 8):
                assert sum(states.values(), F(0)) == 1
                inventory = expected_union = expected_common = slot_private = (
                    expected_path_ratio
                ) = F(0)
                repeat_parent = F(0)
                for (latent, last, counts), v in states.items():
                    inv = sum((c * parent_mass[t] for t, c in zip(names, counts)), F(0))
                    un = union(counts)
                    unique = sum(
                        (private(t, counts) for t, c in zip(names, counts) if c == 1),
                        F(0),
                    )
                    # Repeated physical parent means its every copy has no slot-private part.
                    if sum(c > 0 for c in counts) == 1 and k >= 2:
                        assert unique == 0
                    assert 0 <= unique <= un <= inv
                    inventory += v * inv
                    expected_union += v * un
                    expected_common += v * inter(counts)
                    slot_private += v * unique
                    expected_path_ratio += v * (inv - un) / inv
                    if any(c >= 2 for c in counts):
                        repeat_parent += v
                repeated = inventory - expected_union
                assert inventory == k * sum(
                    (pt[t] * parent_mass[t] for t in names), F(0)
                )
                print(
                    "SLOTS",
                    mode,
                    k,
                    "union/inventory=",
                    float(expected_union / inventory),
                    "repeat_ratio_of_expectations=",
                    float(repeated / inventory),
                    "expected_path_repeat_ratio=",
                    float(expected_path_ratio),
                    "slot_private/inventory=",
                    float(slot_private / inventory),
                    "slot_private/union=",
                    float(slot_private / expected_union),
                    "repeated_parent_probability=",
                    float(repeat_parent),
                )
                print(
                    "SLOTS_EXACT",
                    mode,
                    k,
                    "inventory=",
                    inventory,
                    "union=",
                    expected_union,
                    "slot_private=",
                    slot_private,
                    "ratio_of_expected_repeat=",
                    repeated / inventory,
                    "expected_path_repeat_ratio=",
                    expected_path_ratio,
                )
            if k == 8:
                break
            new = defaultdict(F)
            for (latent, t, counts), v in states.items():
                for i, s in enumerate(names):
                    if mode == "fixed_q":
                        transition = tq[s, latent] / pq[latent]
                    elif mode == "independent":
                        transition = pt[s]
                    elif mode == "right_qg":
                        transition = C[t, s] / pt[t]
                    else:
                        transition = B[t, s] / pt[t]
                    if transition:
                        cc = list(counts)
                        cc[i] += 1
                        new[latent, s, tuple(cc)] += v * transition
            states = new
    neighbor("all 3 parents", weights, names, parents, M)
    for D in (F(64), F(128)):
        selected = [t for t in names if F(parents[t]["volume_bin"]) == D]
        subset = {k: v for k, v in weights.items() if k[0] in selected}
        if subset:
            neighbor("same central bin " + str(D), subset, selected, parents, M)
    print(
        "scope: actual source-mu cells and full mother weights; right donor mark and W use only R814 conditional model; n=4 original high-dimensional J gate has no positive records"
    )


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--archive", required=True)
args = parser.parse_args()
with zipfile.ZipFile(args.archive) as z:
    rebuilt = json.loads(z.read("comb814-rebuilt.json"))["stages"][0]
    ns = {"__name__": "archived_comb811"}
    exec(compile(z.read("comb811.py"), "comb811.py", "exec"), ns)
    name, n, h, middle, old = ns["FIXTURES"][-1]
    original = ns["fixture"](name, n, h, middle, old)
    evaluate("original", original)
    evaluate("rebuilt", rebuilt)
print("\nPASS exact path counts, slot-private and bridge events")
