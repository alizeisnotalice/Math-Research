# R444 independent final audit

FINAL PASS（限定于真实距离带权全远域估计、两项KL的精确容量耦合身份及所列条件充分检验；不认证未加权U或完整R433预算）。2026-10-21。独立PRE先于新作者证明，现完成13件冻结输入后审与三脚本隔离复现。范围内无剩余实质阻断。原母账及完整目标未改变，没有新增原总账付款。

## 1. 实际双终端的距离权

raw Q_A严格保完整f匹配的I_Aw I_Av/(m_A²m_wm_v)、真实中心及两masscut<m_A/K²。事件Δ≤α等于两个互中心包含事件的union。逐向先以I_Aw≤m_w消分母，再积真实w中心体积≤α^nR_v^n、R_v^n/m_v≤1/q；真实masscut给∫I_Av dv≤m_A²/(K²q)。因此CDF≤2α^n/(K²q²)，该2是同一union上界，不是双收费。任意α>0、严格mass门和边长原子均无遗漏，空cutoff另按零。

独立native来源占用给总raw≤A_n²/q²。α0^n=K²及非负layercake共同给

 ∫ψ dQ_A≤q^−2∫_0^1min(A_n²,2/t)dt=q^−2Φ(A_n²)，
 Φ(v)=v（v≤2），2[1+log(v/2)]（v≥2）。

该饱和公式使用同一个critical权，未偷换成更快衰减权或丢total-cap。sourcewise原stage一次、初始own-high及两个whole-terminal帽给实际P上的

 ∫ψ dP≤S ε0² Φ(A_n²)X/s²。

上放时先保起始record，再删除未来正权；原未过滤路径可用product，受限law不被重新独立化。clip/stage积分及两方向已经在S内，未再乘2、stage数或额外λ/q。

这个结果只付带权正traffic。小的负指数矩不能上界−logψ；对固定pair的cell常数测试会被partition抵消。该固定pair代数不意味着原单v-fiber Fit可无代价升级为已条件于旧终端w的同价量。原Δ>α0及尺度可比保留，根稿Δ与旧Fhat参数δ没有混淆。

## 2. 实际二次捕获与两个KL差额

c_C是同原θ的AC累计，不要求θ单调；c≤X,Y。对u_C>0，λ_C=c′dt/u_C为概率，k_C=(c/X)(Y/Y∞)>0在λ_C几乎处处，r_C=∫c′k_C>0；tildeλ_C=(u_Ck_C/r_C)λ_C亦为概率。零格无费用，正u_C保证p_C>0。于是精确

 ∫c′log(1/k_C)dt=u_C log(u_C/r_C)+u_CD(λ_C||tildeλ_C)。

与实际cell Fit合并、令α_C=u_C/u、β_C=√(p_Cr_C)/√Q，给

 Fit+Eparent+Eterminal
 =u log(u/Q)+2uD(α||β)+Σ_Cu_CD(λ_C||tildeλ_C)，
 Q=(Σ_C√(p_Cr_C))²，0<Q≤Σr_C≤u（u>0）。

系数2、level归一及所有符号正确；没有把子概率或筛后source重新归一，辅助tilt不赋原history。p_Cr_C=m_v^−1∫c′cY/X是实际二次捕获，不是边界体积。R443的有限ν与各非负缺陷可积保证左右各项可积；以零端连续性/正截断及相对熵处理，不作∞−∞。u=0整纤维定义0。

因此U≤∫u[1+log(m_AQ/u²)]dν；保两个KL时是精确表示。这里bulk已按R443从同流精确取消，不重加SX，不重复使用旧平方信用。

## 3. 正量充分条件及未付几何

M=∫_{u>0}m_AQ/u dν是真实当前权正量。有限field有Q/u≤1、统一上质量与有限ν，所以M有限；R>0时M>0。按uν/R的Jensen给U≤R[1+log(M/R)]，由上述可积性合法。

根稿条件C≥1、b≥0、0<ε≤1均已列明。若尚未证明的M≤C(n+2)^b(X+nW)成立，则R>εX给更尖

 U≤R[1+log(C(n+2)^b/ε)]+εnW。

mainproof(12)的较松S版本亦成立：其X系数非负方可用R≤SX，W项可保SnW；该case下S>ε（X>0），零流/空case单列。实际常数、S及原低维/全账吸收条件未自动省略。

M的该预算未证。把Q/u放成1留下的是receiver support总量，不是固定来源occupancy；lowcommon仍带缺失的c_v(y)，不可免费添加。两个KL虽非负，还未证明它们消去M的大值。距离权的补偿与二次捕获间也未获得全流比较。本PASS不把工具或条件充分式记成完整来源价格。

## 4. 实际隔离复现和范围

使用指定 `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python`，在独立目录 `/var/folders/lq/2c4qbz2n0354_tnttkv_qsz00000gn/T/r444_audit_isolated_iq5rd88_` 实际运行geometry、mainproof、numeric三脚本，均exit0。三stdout与冻结输入逐字一致，再生numeric_certificate.json亦逐字一致。Python3.12.14、SymPy1.14.0、flint0.9.0/Arb256bit一致；未运行MATLAB/solver或新扫描。

geometry只核2个一般符号式及3饱和分支，native容量依解析证明。mainproof三profile的精确符号身份为0，retained9/2、7/10、125/36；70位非区间值只作符号诊断。同比接受1/3给r、Q乘1/9及比值不变，pair常数抵消为精确代数。它们不认证原质量门、真实中心选择器或完整history。

numeric为3个有限CDF有理例及7个规定维数的Arb解析常数，保原critical权和总帽强化、空分离支、K/q消元及更快权仅作比较。打印4附近没有被当等号，证书保严格正gap。有限CDF不宣称native sharpness，更不为U赋权。资源/共享索引只记录实际运行；隔离复跑及PRE辅助算术不增加覆盖。

最终：核准本轮两项限定工具和完整回代；未加权原U、完整R433、所有ε总吸收及全尺度结算仍未证明。母账保持原式。交付后停止扩展。

## 冻结字节 SHA-256（13输入）

- `r444_main.md`: `42bd0a90594c04f56956eaedf2dfb91b3f056ab144dc57417511777f8ebf8c66`
- `r444_geometry.md`: `fc0434439f796e1e151536ef6bf6ca3629636d00dc255185f6364251e1cc2fbd`
- `r444_geometry_check.py`: `cc3456fcc8cc74ba0db5418924db3d1532bf82e36d9271ef51afebef13d773c7`
- `r444_geometry.result.txt`: `0e438ae70cc2e0cc49a4b7b3ed9550e78850f6b2dec8a68892b48db4c04d016f`
- `r444_mainproof.md`: `ee8e749d83dfd57031fafe787ea7a43ed57c4ed287b7c85756275967b0d00d4c`
- `r444_mainproof_check.py`: `2ff5f94303effff8181a8d4d813fbcc0555d12d363101411bd45ab498673020f`
- `r444_mainproof.result.txt`: `873e238613533f81603148cb8cd54657965f863e92cb59888bf9360afff4ec0d`
- `r444_numeric.md`: `c8f8b1f890dc59f6035d5ffdac3612c7b1849370469558c2a51a9f40cabe7a43`
- `r444_numeric.py`: `c2c10a3763b586ae5b51c6d410693ce77663abc5562a3980c8be32551d4e7c4f`
- `r444_numeric_certificate.json`: `f9699eddf818e8d39518a2fffeac42e3df11c4a7dbe6ff03222725f81c0c2fc9`
- `r444_numeric_run.txt`: `8c5bc57d85e338a0fbe596f36ea0f3ed6852ae14121dc5357346cc2e6c7679ea`
- `r444_numeric_resources.txt`: `182830be1f77bfde2ed7b90abb499cd182602a406c2b16c6546c755a36cda27b`
- `r444_compute_index.md`: `36388116ce06ee78fd7b16ca15bcd3dac1d409b2208162be8ddd7db05af7e77c`
