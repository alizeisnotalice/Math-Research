# R444 — a saturated distance-weighted matching estimate on the actual terminal pair

**Result and scope.** The native matching argument extends from a near event to a single weight on the entire separated-terminal region. With all original marks retained, the resulting positive traffic has price
\[
 \boxed{\int_{\{\delta>\alpha_0\}}
       \left(\frac{\alpha_0}{\delta}\right)^n d\mathcal P
 \le \frac{S\varepsilon_0^2}{s^2}\,
          \Phi(A_n^2)X_q,}
 \qquad
 \Phi(v)=\begin{cases}v,&0\le v\le2,\\
            2[1+\log(v/2)],&v\ge2.
          \end{cases}
 \tag{1}
\]
Here \(\delta=2\|w-v\|_\infty/\max(R_w,R_v)\), \(\alpha_0=K^{2/n}=e^{2/\sqrt n}\), \(s=1+\sqrt n\), and \(A_n=1+n\log(b/a)\). The repeated use of v as a scalar argument of Phi in (1) is unrelated to the terminal receiver v. For fixed original parameters, the coefficient is \(O(S\varepsilon_0^2\log(n+2)/n)\).

This controls actual distance-weighted traffic, **not** the whole unweighted signed target U. In particular no unproved distance weight is inserted into U, no old fee is refunded, and no complete root-dimensional budget is claimed.

## 1. The native parent-row measure

Fix an actual parent A and put \(M=m_A/K^2\). Write \(I_{Au}=f(Q_A\cap Q_u)\). Define the positive raw terminal-pair measure
\[
 d\mathcal Q_A(w,v)=
 1_{\{m_w<M,m_v<M\}}
 \frac{I_{Aw}I_{Av}}{m_A^2m_wm_v}\,dw\,dv.
 \tag{2}
\]
It is exactly the integral of the two source capture measures against the actual full posterior product:
\[
 \mathcal Q_A(dw,dv)
 =\int\pi_A(dy)\pi_A(dz)
 1_{\{m_w<M,m_v<M\}}\rho_y(dw)\rho_z(dv).
\]
Every center in these formulas belongs to the actual E. No translated or enlarged cube is declared an actual receiver. All masses are the original full-source masses \(m_u=f(Q_u)=q_uR_u^n\), with \(q_u\ge q\). If \(M\le qa^n\), this row is empty because the mass cut is strict.

The audited original whole-terminal and stage contract gives, for any nonnegative terminal-pair function B,
\[
 \int B(A,w,v)\,d\mathcal P
 \le\frac S{h^2}\int\sigma(dA)\int B(A,w,v)\,d\mathcal Q_A(w,v).
 \tag{3}
\]
Here P remains the actual same flow with its current acceptance, early, history, old/new sources and both paths. To obtain (3), condition on the original starting record, delete future positive restrictions only for an upper bound, and apply the two whole-terminal hats. The unfiltered generated paths are conditionally independent; the filtered paths are not asserted to be independent. The original sourcewise endpoint bounds and the one-use stage increments give S once. Integrating the common clipping lift returns those same increments. Thus (3) applies to a function B of the actual terminal pair, without assigning history to either terminal or creating a stage count. It does not by itself dominate a signed U integrand by an unweighted traffic integral.

## 2. Near-center capacity from two matched masses

For every \(\alpha>0\), the event \(\delta\le\alpha\) is the union
\[
 \{w\in\alpha Q_v\}\ \cup\ \{v\in\alpha Q_w\},
 \tag{4}
\]
where dilation is about the cube's center and R is its side length. Hence
\[
 \mathcal Q_A\{\delta\le\alpha\}
 \le\frac{2\alpha^n}{K^2q^2}. \tag{5}
\]
For the first event, use the true matching inequality \(I_{Aw}\le m_w\). At fixed actual v the w centers satisfying \(w\in\alpha Q_v\) have volume at most \(\alpha^nR_v^n\). Consequently
\[
 \begin{aligned}
 \mathcal Q_A\{w\in\alpha Q_v\}
 &\le\frac{\alpha^n}{m_A^2}
    \int_{m_v<M} I_{Av}\frac{R_v^n}{m_v}\,dv\\
 &\le\frac{\alpha^n}{q m_A^2}
    \int_{m_v<M}I_{Av}\,dv.
 \end{aligned}
\]
For fixed z captured by such a v, \(R_v<(M/q)^{1/n}\), so the actual v centers lie in the cube centered at z of side \((M/q)^{1/n}\). Tonelli and full matching therefore give
\[
 \int_{m_v<M}I_{Av}\,dv
 =\int_{Q_A}f(z)\int_{m_v<M}c_v(z)\,dv\,dz
 \le m_A M/q.
\]
This proves the first half of (5); exchange w and v for the other half. The union bound is an upper bound on one event, not two charges to the original flow. Neither argument bounds f on a thin set.

Independently, the native actual-selector occupancy bound gives
\[
 \mathcal Q_A(1)
 =\left[\int\pi_A(dz)\int_{m_v<M}\rho_z(dv)\right]^2
 \le (A_n/q)^2.
 \tag{6}
\]
The square here is a positive raw product measure, not reused negative BH credit.

As a geometric check, whenever both parent overlaps are positive,
\[
 \delta\le 2R_A/\max(R_w,R_v)+1+\min(R_w,R_v)/\max(R_w,R_v)
 \le2b/a+2\le6.
\]
The final bound below does not need this diameter estimate.

## 3. Saturation removes the n-sized distance integral

Let \(\psi=(\alpha_0/\delta)^n\) on the original separated region \(\delta>\alpha_0\), and set it to zero elsewhere for the present integral. For \(0<t<1\),
\[
 \{\psi>t\}\subseteq\{\delta\le\alpha_0t^{-1/n}\}.
\]
Since \(\alpha_0^n=K^2\), (5) and (6) imply
\[
 \mathcal Q_A\{\psi>t\}
 \le\frac1{q^2}\min\{A_n^2,2/t\}.
\]
Layer cake, valid also for atoms in the actual selected-radius distribution, now yields
\[
 \int\psi\,d\mathcal Q_A
 \le\frac1{q^2}\int_0^1\min\{A_n^2,2/t\}\,dt
 =\frac{\Phi(A_n^2)}{q^2}. \tag{7}
\]
If \(A_n^2\le2\), the total-capacity term controls the whole integral. Otherwise the split is exactly at \(t=2/A_n^2\); its two contributions are 2 and \(2\log(A_n^2/2)\). No distributional regularity or independent integration of selected radii is assumed. Strict versus closed near boundaries can only enlarge the upper bound; endpoint values of the layer variable do not affect the integral.

Apply (3) to psi, use \(\int\sigma=X_q\), and \(h=s/(\varepsilon_0q)\). This proves (1). This is a uniform estimate on all separated terminal distances and all actual parents, rather than a count of newly selected near boxes. It uses both real matched captures in (2).

## 4. The remaining connection to the signed target

The original remaining flow already has \(\delta>\alpha_0\). Equation (1) bounds its psi-weighted positive part with every original gate still present. It supplies no upper bound on the complementary unweighted traffic or on the positive distance cost
\[
 -\log\psi=n\log(\delta/\alpha_0).
 \tag{8}
\]
An entropy-dual substitution of this distance weight into U must retain the exact compensating (8) on the same actual measure, unless the original fit/current defects prove a cancellation or an upper bound for it. The current calculation proves no such comparison. In particular, a small exponential moment of minus (8) is not an upper bound on its mean: Jensen supplies the opposite direction.

Thus (1) is the concrete native geometric budget available to the joint signed argument. The single still missing step is to control the compensation for this actual distance weight by the retained original signed defects, with no extra parent/source multiplicity. No assumption of that step is made here. Sol is checking that separate signed comparison; this attachment does not repeat a formal dual identity or claim its conclusion.

## 5. Executed local verification

The specified local math Python ran `/tmp/r444_geometry_check.py`; stdout is `/tmp/r444_geometry.result.txt`. SymPy checked two general symbolic layer-cake identities and three fixed saturation regimes (below, at and above the cutoff). These are arithmetic checks of (7); the native capacity proof is the analytic argument in Section 2. They are not an original-history geometric fixture. Independent numerical certificates, if included by the parent, have their own scope and are not counted here.

This bounded delivery stops with (1), its actual-flow scope, and the unresolved signed compensation (8). No repository or other agent's file was edited.
