import sympy as s
C,T,t=s.symbols('C T t',positive=True)
saturated=s.integrate(T,(t,0,C/T))+s.integrate(C/t,(t,C/T,1))
assert s.simplify(saturated-C*(1+s.log(T/C)))==0
n,alpha,K,q=s.symbols('n alpha K q',positive=True)
# Critical geometric weight cancels the dimension-dependent power exactly.
near=s.Rational(2)*K**2/t/(K**2*q**2)
assert s.simplify(near-2/(q**2*t))==0
for v in (s.Rational(1),s.Rational(2),s.Rational(8)):
    if v<=2:
        exact=s.integrate(v,(t,0,1)); target=v
    else:
        exact=s.integrate(v,(t,0,2/v))+s.integrate(2/t,(t,2/v,1))
        target=2*(1+s.log(v/2))
    assert s.simplify(exact-target)==0
print('PASS: two general symbolic identities and three fixed saturation regimes.')
print('Scope: layer-cake arithmetic only; native center bounds are proved analytically; no original-history numeric fixture.')
