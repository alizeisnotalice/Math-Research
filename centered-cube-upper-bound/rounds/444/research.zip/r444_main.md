# 第444轮：双终端距离加权匹配与实际二次捕获对偶

2026-10-21。本轮证明一项覆盖完整远终端区域的真实距离加权估计，并构造保原接受权的二次捕获对偶。前者尚未转成未加权原余项预算，后者的几何求和仍未证明。一般 n^(1/2+o(1)) 一致弱型上界未闭合，原母账不增加付款。

## 1. 冻结目标与原总账

沿用R443完整原流P、R=R433及任意非负L1来源f。W=||f||1，σ=q_A dA，X=σ(E)，a≤R_A≤b≤2a，q≤q_A≤λ，r=λ/q，A_n=1+nlog(b/a)，s=1+√n，h=s/(ε0q)，K=e^{√n}。保全部current、early、history、首次删除、双来源与路径资格。实际终端w固定捕获旧来源y，v固定捕获新来源z；不能刷新来源。

当前唯一完整目标为
\[
U=\int\log\frac{m_AB_{vC}(t)}{m_vB_{AC}(t)}dP,
\quad 2(\sqrt n-\log_+M_*)R\le U+4rC_dA_nW,
\]
M*=SA_n/(λh)。bulk已精确取消，不重加SX。

原入口仍为
\[
\Lambda\{8\lambda HW+2d_{eff}A_{entrance,n}W_\nu/H+64\widehat F R433
 +(2E387+64\widehat F C433)X+(2S390+16s+64\widehat F V433)W\},
\]
Λ=128/119，Fhat=(1−32δ−16η)^−1。本轮不假定初始、删除跳跃、尺度补集、终端或最终ε吸收已完成。

## 2. 全远域的实际几何带权估计

令Δ=2||w−v||∞/max(R_w,R_v)，α0=e^{2/√n}。原剩余流满足Δ>α0、m_w,m_v<m_A/K²。取ψ=(α0/Δ)^n。对每个实际父A，将两来源按原π_A积掉，得到真实接收中心测度
\[
dQ_A(w,v)=1_{m_w,m_v<m_A/K^2}\frac{I_{Aw}I_{Av}}{m_A^2m_wm_v}dw\,dv,
\quad I_{Au}=f(Q_A\cap Q_u).
\]
完整匹配I_Aw≤m_w消去一质量分母，给Q_A{Δ≤α}≤2α^n/(K²q²)；原来源占用同时给Q_A(1)≤A_n²/q²。没有用小体积推断小来源质量，没有引入虚拟接收cube。

将两界共同用于层积分，而不单用接收域直径，得
\[
\int\psi\,dQ_A\le q^{-2}\Phi(A_n^2),\qquad
\Phi(v)=\begin{cases}v,&v\le2,\\2[1+\log(v/2)],&v\ge2.\end{cases}
\]
再用原完整终端帽及一次阶段系数S，得到
\[
\boxed{\int\psi\,dP\le\frac{S\epsilon_0^2}{s^2}\Phi(A_n^2)X.}
\]
费用为O(Sε0²log(n+2)/n)X，所有原门仍在左端。这是带权全远域估计，不是完整R的付款，也不把它再拆成多项局部分支。

去掉ψ需要处理同原流的正代价−logψ=nlog(Δ/α0)。小的负指数矩不提供这个正代价的上界。对于固定终端对，ψ在cell上是常数，直接加入cell Gibbs对偶会精确抵消，不能凭此声称补偿已获得。

## 3. 保原接受权的实际二次捕获

沿R443用实际RN密度θ∈[0,1]定义累计c_C(t)，u_C=c_C(∞)，u=Σu_C；原外权ν保σ、旧来源π_A a0、dv/m_v及1/(hm_A)，R=∫u dν。写X_C=B_AC(t)，Y_C=B_vC(t)，p_C=Y_C(∞)/m_v。

构造真实level量
\[
r_C=\int c'_C(t)\frac{c_C(t)}{X_C(t)}\frac{Y_C(t)}{Y_C(\infty)}dt,
\quad Q=\left(\sum_C\sqrt{p_Cr_C}\right)^2.
\]
这里p_Cr_C=m_v^{-1}∫c'_C c_CY_C/X_C dt，保实际接受权的二次出现和真实来源质量，非边界体积。零质量格不作除法。

拟合与两项缺陷的联合对偶给精确身份
\[
\mathrm{Fit}+E_{parent}+E_{terminal}
=u\log(u/Q)+2uD(\alpha\Vert\beta)
 +\sum_Cu_CD(\lambda_C\Vert\widetilde\lambda_C)
\]
（逐纤维，定义及可积性见mainproof），从而
\[
U\le\int u[1+\log(m_AQ/u^2)]d\nu.
\]
这是可计算的共同对偶，不是新的来源W付款。它给出一个明确的正量充分检验
\[
\mathfrak M=\int_{u>0}\frac{m_AQ}{u}d\nu,
\qquad U\le R[1+\log(\mathfrak M/R)].
\]
若将来能证M≤C(n+2)^b(X+nW)，则对0<ε≤1、C≥1、b≥0、R>εX，可推
\[
U\le R[1+\log(C(n+2)^b/\epsilon)]+\epsilon nW.
\]
这有明确回代意义，但M的原几何预算尚未证明；不能把Q/u≤1后出现的接收域体积当作固定来源占用。亦不能给lowcommon补入缺失的c_v(y)。两个KL差额可能有用，目前没有证明它们支付M的大值。

## 4. 本轮决策与验证

两条结果还没有建立足够强的连接：距离加权几何预算已证；其去权代价与上述实际二次捕获之间的控制未证。下一步应研究依赖真实来源cell的几何测试，或保两个KL剩余的同流比较，不再调只依赖终端对的常数权。

实际启用1 Astra high、2 Sol high、1 Sol medium，其他配额保持空闲。使用64项D02技能的有限域Gibbs条件，本文对偶由同一有限cell与实际level概率直接展开；不把邻近文献或一般强对偶当证明。

指定独立Python实际运行SymPy、Fraction及Arb：geometry核饱和分段，numeric核有限CDF及明确参数费用，mainproof核实际clipping/current的联合差额与常数权抵消。有限CDF不认证原cube历史；高精度浮点只作诊断，不替代区间证书。具体范围与命令见计算索引。三脚本最终隔离复跑不增加覆盖数。模型扣额数据不可得。不编译PDF，精简归档详细LaTeX与必要证据。
