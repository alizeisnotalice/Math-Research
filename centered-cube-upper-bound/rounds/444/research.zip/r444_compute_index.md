# R444 bounded layercake计算索引

责任：numeric，仅本前缀；无agent/repo/他人修改。Astra负责nearCDF原生几何证明，Sol负责U与distance/logweight比较，本任务不重复dual或source模型。

输入：`r444_contract.md`、root/Astra冻结nearCDF 2α^n/(K²q²)，α0=exp(2/√n)，归一d=2dist/maxR，support≤6；root指定critical权(α0/d)^n。

主计算：原critical权ψ的nearCDF+总容量饱和Φ(A_n²)，Fraction五knots CDF三例核B<2、=2、>2（不称native）。另SymPy critical/general-power boundary、导数、γ→n极限；Arb256bit在7个规定维数核价格、empty branch、K/q消元及独立S/h²形式乘积。γ2n只作更小权的可求和对照，不当U majorant。fixed-side n2另核support empty。无new center sample/LP/随机scan。

命令：`/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/r444_numeric.py`
环境Python3.12.14，SymPy1.14.0，flint0.9.0；具体耗时/RSS见resources。

输出归档：`r444_numeric.py`、`r444_numeric_certificate.json`、`r444_numeric_run.txt`、`r444_numeric_resources.txt`、`r444_numeric.md`、本索引。脚本输出自身目录，无作者脚本依赖。

状态：实际运行通过；仅原生CDF条件下的layercake积分证书，不认证U比较、原history或整体闭合。停止。

冻结：主证书已按root/Astra确认总容量An²/q²强化；同一原ψ无修改。七维数与三CDF branch全部实际运行通过，最终.24秒/RSS约74.2MB；无进一步扫参。

作者分工：geometry_check.py实际SymPy核两一般式及三饱和分支；mainproof_check.py实际核三阶段clipping接受表（u=9/2,7/10,125/36）、联合KL身份及θ同比缩放。70位浮点仅作诊断。最终归档隔离复跑三脚本不增加模型覆盖数；解释器均为指定独立Python。
