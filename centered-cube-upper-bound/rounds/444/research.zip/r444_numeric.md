# R444 terminal中心distance权的layercake核验

已与Astra核对R427接口。固定真实父A，raw pair capacity按π_A(dy)π_A(dz)ρ_y(dw)ρ_z(dv)，两个terminal各捕获对应父来源且m_w,m_v<m_A/K²。归一距离

`d=2||w−v||∞/max(Rw,Rv)`。

近事件union恰为d≤α；已证capacity CDF记M(α)，输入为

`M(α)≤2α^n/(K²q²)`。

α0=exp(2/√n)，所以α0^n=K²。两真terminal各交父cube，故

`d≤2RA/maxR+(Rw+Rv)/maxR≤2b/a+2=:Dmax≤6`。

原分离门只保留d>α0。这里不新增几何样本、不构造terminal关联矩阵，数值任务只核已证CDF的积分常数。

## 主证书：原critical权的总容量饱和强化

Astra/root确认同时保raw product总容量`M(∞)≤A_n²/q²`。这是未过滤sourcewise占用的乘积上界；原future正过滤不会把它增大，不宣称过滤后独立。令B=A_n²、t=nlog(d/α0)，原CDF可用

`q² M_t(t)≤min(B,2e^t)`。

**仍使用原critical权**ψ=e^−t，而不是改成更小权。layercake给

`q²∫ψ dM≤Φ(B)`，

`Φ(B)=B (0≤B≤2);  Φ(B)=2+2log(B/2) (B>2)`。

推导是精确积分`∫_0^∞e^−t min(B,2e^t)dt`，在t=log(B/2)分段；B≤2不应插入负对数。Φ在2处连续且两边导数均1，SymPy核通过。若另用有限Dmax，T=nlog(Dmax/α0)>0，则可更紧取`Φ(min(B,2e^T))`。

三个**仅CDF代数**的Fraction小例覆盖B=1、2、8，原ψ直接积分分别10/11、20/11、121/30，精确离散Stieltjes公式一致，且分别≤Φ(B)=1、2、2+2log4。CDF取r=(d/α0)^n的五个有理knots，非真实center实例，未用于断言native sharpness。

在b/a=2、S=3、eps0=1/4、q=2明示输入下，饱和价格如下；q²倍价格为不含q的profile：

|n|Φ(A_n²)|再保Dmax=6的q²价格|若另有S/h² prefactor，其形式系数|
|--|--|--|--|
|1|原分离support空|0|0|
|2|4.09267|3.51018|.112922|
|4|5.92475|5.92475|.123432|
|16|10.5833|10.5833|.0793750|
|64|15.8724|15.8724|.0367416|
|256|21.3508|21.3508|.0138522|
|1024|26.8792|26.8792|.00462796|

形式系数是`S eps0² Φ(min(A_n²,2e^T))/s²`；本任务没有把该prefactor或原ψ强行赋予U。主强化来自**同一ψ的总容量饱和**，不需要改变原weight。

## 1. root指定critical权的准确价格

令ψ(d)=(α0/d)^n，在(α0,Dmax]使用。Stieltjes分部积分为

`∫_(α0,D] ψ dM = ψ(D)M(D)−M(α0)+nα0^n∫_α0^D M(α)α^(−n−1)dα`。

保留−M(α0)只会更紧；丢去后由near CDF得

`∫ψ dM ≤ 2α0^n/(K²q²)[1+nlog(D/α0)]`
`       =2/q²[1+nlogD−2√n]`，条件α0<D。

α0≥D时严格分离support为空，费用0，不能套负括号。SymPy核boundary、导数及general-power极限均精确一致；Arb另核未化简式与K消元后的式一致。

## 2. dimension-free profile与可求和criterion

写t=nlog(d/α0)，0<t≤T=nlog(D/α0)。原生CDF给无量纲profile

`M_t(t)≤2e^t/q²`。

任意非负下降φ(t)，相应权ψ=φ(t)满足

`∫φ dM≤(2/q²)[e^Tφ(T)+∫_0^T e^t(−dφ(t))]`。

因此随T一致可求和的准确充分criterion是endpoint及上述加权variation一致有界。critical φ=e^−t恰给2(1+T)/q²，保留T≈n的费用；不能从α0^n=K²就称此权dimension-free。

更快下降φ=e^−(1+η)t，η>0，给

`charge≤(2/q²)[(1+η)/η−e^(−ηT)/η]≤2(1+η)/(ηq²)`。

对应距离powerγ=(1+η)n。这是**更小的另一权**，其常数较小不能免费替代root原critical权。一般γ≠n的准确有限价格为

`(2/q²)[γ/(γ−n)−n/(γ−n)(α0/D)^(γ−n)]`。

这些公式只提供几何权的可检验预算条件。尚未证明原U的实际signed integrand由critical ψ或任何更快权majorize；actual fit/deletion项怎样提供该distance衰减由主证明另核。

## 3. 有界实际常数

指定newenv实际运行`r444_numeric.py`，SymPy+Arb256bit。只取n=1,2,4,16,64,256,1024，Dmax=6，S=3、eps0=1/4、q=2显式作为输入。所有近CDF价格均由Arb包围，严格符号由区间判定。

|n|q²·critical charge|q²·γ=2n charge|若另有S/h² prefactor，其形式系数|
|--|--|--|--|
|1|0（空support）|0|0|
|2|3.51018|3.06007|.112922|
|4|8.33408|3.91574|.173627|
|16|43.3363|3.999999998|.325022|
|64|199.345|<4|.461447|
|256|855.381|<4|.554962|
|1024|3543.523|<4|.610111|

最后一列只计算独立形式乘积`(S/h²)·charge=2S eps0²[1+nlogD−2√n]/s²`，q精确消去；本任务没有将S/h²或该权强加到原U。尺度比可直接替Dmax=2b/a+2；例如fixed-side Dmax=4,n2也为空support，脚本实际核该小维边界。

γ=2n在大n显示为4附近时，直接相减会丢严格gap；证书另保存正量`2exp(−T)/q²`，严格证明小于4/q²，没有把打印舍入当等号。

## 范围、复现与停止

脚本`r444_numeric.py`、`r444_numeric_certificate.json`、`r444_numeric_run.txt`、`r444_numeric_resources.txt`及计算索引`r444_compute_index.md`均在同目录，未改他人／repo。精确解析公式与有限误差证书不依赖新center实例。主可用信息是同一critical距离weight的Φ(A_n²)总容量饱和价格；仅nearCDF的有限D价格与更快weight criterion作为核验基线。U与chosenweight仍明确分开；不声称付款原U或全R433。交付停止。
