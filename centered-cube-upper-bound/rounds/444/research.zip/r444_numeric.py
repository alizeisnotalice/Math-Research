"""Exact layercake constants for the R427 near-center CDF interface.
No U majorization, new center samples, duals or original-history certification.
"""
from pathlib import Path
from fractions import Fraction as F
import json,sys,platform
import sympy as sp
from flint import arb,ctx
import flint
ROOT=Path(__file__).resolve().parent;ctx.prec=256

def A(x):
 x=F(x);return arb(str(x.numerator))/arb(str(x.denominator))
# CDF bound F(alpha)<=C alpha^n, support<=D; integrate only alpha>a.
n,a,D,C,g,z=sp.symbols('n a D C gamma z',positive=True)
critical=C*a**n*(1+n*sp.log(D/a))
critical_derivative=sp.simplify(sp.diff(critical,D)-C*n*a**n/D)
assert critical_derivative==0
# Algebraic boundary+layercake integral, not a missing endpoint convention.
critical_ibp=C*a**n+sp.integrate(C*n*a**n/z,(z,a,D))
assert sp.simplify(critical-critical_ibp)==0
general=C*a**n*(g/(g-n)-n/(g-n)*(a/D)**(g-n))
assert sp.simplify(sp.diff(general,D)-C*n*a**g*D**(n-g-1))==0
assert sp.simplify(general.subs(D,a)-C*a**n)==0
assert sp.simplify(sp.limit(general,g,n)-critical)==0
# alpha0^n/K^2=1: use positive n, exp rules before numerical evaluation.
nn=sp.symbols('N',positive=True)
normalization=sp.simplify(sp.exp(2*sp.sqrt(nn))/sp.exp(2*sp.sqrt(nn)))
assert normalization==1

# Saturated critical profile: total normalized pair capacity <= B=An^2.
def Phi(bb):
 if bb<=2:return bb
 assert bb>2
 return 2+2*(bb/2).log()
zz=sp.symbols('Bcap',positive=True)
assert sp.simplify((2+2*sp.log(zz/2)).subs(zz,2)-2)==0
assert sp.simplify(sp.diff(2+2*sp.log(zz/2),zz).subs(zz,2)-1)==0

rows=[];S=F(3);eps0=F(1,4);q=F(2);ratio=F(2)
for dim in [1,2,4,16,64,256,1024]:
 sn=A(dim).sqrt();K=sn.exp();alpha0=(2/sn).exp();Dmax=2*A(ratio)+2
 T=A(dim)*Dmax.log()-2*sn
 if T<0:
  rows.append({'n':dim,'scale_ratio':str(ratio),'alpha0_Arb':str(alpha0),
    'Dmax_Arb':str(Dmax),'far_support_empty':True,'critical_charge':'0',
    'reason':'alpha0>Dmax: cannot satisfy both terminal-center separation conditions.'})
  print('n',dim,'empty separated support; alpha0=',alpha0,'Dmax=',Dmax);continue
 assert T>0
 charge=2/A(q*q)*(1+T)
 # Direct unsimplified expression verifies K/alpha0 units as well.
 direct=2*alpha0**dim/(K*K*A(q*q))*(1+A(dim)*(Dmax/alpha0).log())
 assert (direct-charge).contains(0)
 # A faster-decaying smaller weight: gamma=2n.
 strong=2/A(q*q)*(2-(-T).exp())
 strong_gap=2/A(q*q)*(-T).exp()
 assert strong>0 and strong_gap>0 and charge-strong>0
 # Formal prefactor if a separate reference projection supplies S/h^2.
 # This is NOT supplied or used here as a bound for U.
 s=1+sn;h=s/(A(eps0)*A(q))
 formal=A(S)*charge/(h*h)
 An=1+A(dim)*A(ratio).log()
 Bcap=An*An
 saturated=Phi(Bcap)
 finite_Bcap=Bcap if Bcap<2*T.exp() else 2*T.exp()
 saturated_finite=Phi(finite_Bcap)
 assert saturated_finite>0
 assert charge*A(q*q)-saturated_finite>=0 or (charge*A(q*q)-saturated_finite).contains(0)
 rows.append({'n':dim,'S_input':str(S),'eps0_input':str(eps0),'q_input':str(q),
  'scale_ratio_input':str(ratio),'alpha0_Arb':str(alpha0),'K_Arb':str(K),
  'Dmax_Arb':str(Dmax),'T_nlog_D_over_alpha0_Arb':str(T),
  'critical_distance_power':'n','critical_charge_Arb':str(charge),
  'critical_charge_times_q_squared_Arb':str(charge*A(q*q)),
  'stronger_decay_distance_power':'2n','stronger_decay_charge_Arb':str(strong),
  'stronger_decay_infinite_support_bound':'4/q^2',
  'stronger_decay_gap_to_infinite_bound_Arb':str(strong_gap),
  'critical_charge_q_squared_over_An_Arb':str(charge*A(q*q)/An),
  'normalized_total_pair_cap_An_squared_Arb':str(Bcap),
  'saturated_Phi_An_squared_Arb':str(saturated),
  'saturated_finite_Dmax_Phi_min_Arb':str(saturated_finite),
  'saturated_formal_S_over_h_squared_coefficient_Arb':str(A(S)*A(eps0*eps0)*saturated_finite/(s*s)),
  'formal_S_over_h_squared_times_charge_Arb':str(formal),
  'formal_prefactor_not_U_bound':True,'far_support_empty':False})
 print('n',dim,'q^2 criticalcharge=',charge*A(q*q),
       'q^2 strongcharge=',strong*A(q*q),'formal S/h² charge=',formal)
# One lower-scale sanity check: D=4 for fixed side and n=2 => alpha0>4.
assert (2/A(2).sqrt()).exp()>4
# Three finite rational CDFs test the <2, =2, >2 total-cap branches.
# r=(d/alpha0)^n; these are abstract CDFs, never native center examples.
cdf=[]
knots=[F(11,10),F(3,2),F(2),F(4),F(8)]
for B0 in [F(1),F(2),F(8)]:
 Fvals=[min(B0,2*z) for z in knots]
 masses=[Fvals[0]]+[Fvals[j]-Fvals[j-1] for j in range(1,len(knots))]
 assert all(mm>=0 for mm in masses) and sum(masses,F(0))==B0
 exact=sum((mm/rr for mm,rr in zip(masses,knots)),F(0))
 ibp=Fvals[-1]/knots[-1]+sum((Fvals[j]*(1/knots[j]-1/knots[j+1]) for j in range(len(knots)-1)),F(0))
 assert exact==ibp
 phi=Phi(A(B0));assert phi-A(exact)>0
 cdf.append({'normalized_total_cap':str(B0),'branch':'below2' if B0<2 else 'equal2' if B0==2 else 'above2',
  'r_knots':list(map(str,knots)),'point_masses':list(map(str,masses)),
  'exact_weighted_integral':str(exact),'exact_discrete_IBP':str(ibp),
  'Phi_Arb':str(phi),'strict_gap_Arb':str(phi-A(exact)),
  'scope':'Only a finite CDF algebra check; not actual center geometry.'})
 print('saturated CDF B=',B0,'exact weighted=',exact,'Phi=',phi)
report={'environment':{'executable':sys.executable,'python':platform.python_version(),
 'sympy':sp.__version__,'flint':flint.__version__,'Arb_bits':ctx.prec},
 'distance':'d=2||w-v||inf/max(Rw,Rv)',
 'near_CDF_input':'F(alpha)<=2 alpha^n/(K^2 q^2)',
 'alpha0':'exp(2/sqrt(n)); alpha0^n=K^2',
 'critical_weight':'psi(d)=(alpha0/d)^n on alpha0<d<=Dmax',
 'critical_charge_formula':'2 alpha0^n/(K^2 q^2) [1+n log(Dmax/alpha0)]',
 'critical_symbolic_derivative_residual':str(critical_derivative),
 'general_power_charge':'C a^n [gamma/(gamma-n)-n/(gamma-n)(a/D)^(gamma-n)]',
 'general_power_at_gamma_n':'C a^n[1+nlog(D/a)]',
 'dimension_free_normalized_profile':'t=nlog(alpha/alpha0), F<=2 exp(t)/q^2',
 'summable_weight_criterion':'For nonnegative decreasing phi(t), finite endpoint plus integral exp(t)(-dphi(t)) uniformly bounded; phi=exp(-(1+eta)t) has infinite-support charge <=2(1+eta)/(eta q^2).',
 'cases':rows,'saturated_profile_Phi':'B if B<=2; 2+2log(B/2) if B>2','saturated_CDF_checks':cdf,
 'scope':'Certified layercake arithmetic conditional on the proved native CDF. Chosen weight not shown to majorize U; no new original geometry/history or global budget.'}
(ROOT/'r444_numeric_certificate.json').write_text(json.dumps(report,indent=2)+'\n')
print('PASS: saturated Phi three branches, critical/general-power constants, 7 bounded dimensions; no U comparison asserted.')
