"""Bounded exact clipping algebra plus high-precision diagnostics.
No native receiver-selector or original-history realization is claimed.
"""
import sympy as s

Q = s.Rational
t = s.Symbol("t", positive=True)


def log_integral(expr, lo, hi):
    expr = s.expand(expr)
    slope, intercept = s.diff(expr, t), expr.subs(t, 0)
    if slope == 0:
        assert intercept > 0
        return (hi-lo)*s.log(intercept)
    def primitive(x):
        y = s.simplify(expr.subs(t, x))
        return Q(0) if y == 0 else (y*s.log(y)-y)/slope
    return s.expand(primitive(hi)-primitive(lo))


def profile(atoms, breaks, pattern):
    count = len(pattern[0])
    M = sum(vol*f for vol, f, a, v, c in atoms if a)
    mv = sum(vol*f for vol, f, a, v, c in atoms if v)
    Yfinal = [sum(vol*f for vol, f, a, v, c in atoms if v and c == C)
              for C in range(count)]
    p = [y/mv for y in Yfinal]
    mass = [Q(0)]*count
    r = [Q(0)]*count
    defect = [Q(0)]*count
    for j, (lo, hi) in enumerate(zip(breaks, breaks[1:])):
        for C in range(count):
            rate = sum(vol*pattern[j][C] for vol, f, a, v, c in atoms
                       if a and v and c == C and f > lo)
            if not rate:
                continue
            X = s.expand(sum(vol*(f if f <= lo else t)
                             for vol, f, a, v, c in atoms if a and c == C))
            Y = s.expand(sum(vol*(f if f <= lo else t)
                             for vol, f, a, v, c in atoms if v and c == C))
            retained = mass[C]+rate*(t-lo)
            integrand = s.cancel(rate*retained*Y/(X*Yfinal[C]))
            r[C] += s.integrate(integrand, (t, lo, hi))
            defect[C] += rate*(log_integral(X, lo, hi)
                               -log_integral(retained, lo, hi)
                               +(hi-lo)*s.log(Yfinal[C])
                               -log_integral(Y, lo, hi))
            mass[C] += rate*(hi-lo)
    r = [s.simplify(x) for x in r]
    u = sum(mass)
    root = sum(s.sqrt(p[C]*r[C]) for C in range(count))
    cap = root**2
    fit = sum(x*s.log(x/(u*p[C])) for C, x in enumerate(mass) if x)
    cell = 2*sum(x*s.log(x*root/(u*s.sqrt(p[C]*r[C])))
                 for C, x in enumerate(mass) if x)
    level = sum(defect[C]-x*s.log(x/r[C])
                for C, x in enumerate(mass) if x)
    leading = u*s.log(u/cap)
    lhs = fit+sum(defect)
    rhs = leading+cell+level
    exact = s.simplify(s.expand_log(s.expand(lhs-rhs), force=True))
    assert exact == 0, exact
    numbers = [s.N(x, 70) for x in [u-cap, leading, cell, level]]
    assert all(x >= 0 for x in numbers)
    for x, rc in zip(mass, r):
        assert s.N(rc, 70) >= 0
        assert s.N(x-rc, 70) >= 0
    return M, mass, r, cap, numbers


base = [(Q(1), Q(2), 1, 1, 0),
        (Q(1,2), Q(5), 1, 1, 1),
        (Q(1,3), Q(1), 1, 0, 0),
        (Q(2,3), Q(3), 0, 1, 1)]
breaks = [Q(0), Q(1), Q(2), Q(3), Q(5)]
full = [[Q(1), Q(1)]]*4
zero = [[Q(0), Q(1,4)], [Q(0), Q(0)],
        [Q(0), Q(3,4)], [Q(0), Q(1,5)]]
expanded = base + [(Q(1,4), Q(4), 1, 1, 2),
                   (Q(1,5), Q(2), 0, 1, 2),
                   (Q(1,6), Q(3), 1, 1, 3),
                   (Q(1,7), Q(1), 1, 0, 3)]
expanded_breaks = [Q(0), Q(1), Q(2), Q(3), Q(4), Q(5)]
expanded_pattern = [[1, Q(1,2), 1, Q(1,3)],
                    [Q(1,2), 0, Q(2,3), 1],
                    [0, 1, Q(1,3), Q(1,2)],
                    [0, Q(1,3), Q(1,2), 0],
                    [0, Q(1,4), 0, 0]]

outputs = []
for label, atoms, levels, pat in [
    ("initial two-cell full", base, breaks, full),
    ("zero-pressure two-cell", base, breaks, zero),
    ("expanded four-cell", expanded, expanded_breaks, expanded_pattern),
]:
    result = profile(atoms, levels, pat)
    outputs.append(result)
    print("PASS", label, "u =", sum(result[1]))
    print(" exact two-KL identity; [u-Q, leading, cell-KL, level-KL] =",
          [str(v) for v in result[4]])

scaled = profile(base, breaks, [[Q(1,3)*x for x in row] for row in full])
original = outputs[0]
assert all(s.simplify(r1-r0/9) == 0 for r0, r1 in zip(original[2], scaled[2]))
assert s.simplify(s.expand(scaled[3]-original[3]/9)) == 0
assert sum(scaled[1]) == sum(original[1])/3
print("PASS uniform retention 1/3: r and Q scale by 1/9; mA Q/u^2 unchanged")

psi, a, b, z = s.symbols("psi a b z", positive=True)
constant_difference = z*s.log(psi*a)+(1-z)*s.log(psi*b)-s.log(psi*(a+b))
constant_difference -= z*s.log(a)+(1-z)*s.log(b)-s.log(a+b)
assert s.simplify(s.expand_log(constant_difference, force=True)) == 0
print("PASS pair-constant Gibbs test cancellation (symbolic)")
print("Scope: three finite clipping profiles plus one scalar-retention comparison;")
print("symbolic identities and 70-digit noninterval sign diagnostics, not native history.")
