# R444：实际拟合与两项捕获缺陷的共同对偶测试

**结论范围。** 本稿冻结一个由原实际接受权和两个真实立方体的 clipping 交叠确定的对偶测试。它把 `fit + Eparent + Eterminal` 合并成一个非负的、可计算的二次捕获量，并给出完整差额；尚未证明该量的全中心预算。因此没有新的原母账付款，也没有把人为距离权当作未加权原流。

## 1. 固定同一原流

全部符号沿用 `/tmp/r443_mainproof.md` §§1–3。特别
\[
 d\nu=\sum_e\frac{\sigma(dA)\pi_A(dy)a_0^e(A,y)G(A,v)}
                         {h\,m_A}\frac{dv}{m_v}
\]
只是已证终端正支配的基测度；实际 RN 密度 \(\vartheta\in[0,1]\) 保留当前阶段、原旧来源、low-common、early、路径与 future 的全部实际影响。它没有被置为 1，也未假定随 clipping level 单调。

固定 \((e,A,y,v)\)，保原有限格 \(C\)，写
\[
 c_C(t)=\int_0^t\int_{C\cap Q_A\cap Q_v}
 1_{\{f(z)>r\}}w(y,z)\vartheta(z,r)\,dz\,dr,\qquad
 u_C=c_C(\infty),\quad u=\sum_Cu_C,
\]
\[
 X_C(t)=B_{AC}(t),\quad Y_C(t)=B_{vC}(t),\quad
 p_C=Y_C(\infty)/m_v.
\]
所有来源质量由同一完整 \(f\) 决定；\(c_C\le X_C,Y_C\)、\(\sum_Cp_C=1\)。
R443 的精确同流量为
\[
 U=\int g_{m_A}(u)\,d\nu-\mathrm{Fit}-E_{\rm parent}-E_{\rm terminal},
 \quad R=\int u\,d\nu,\quad g_M(u)=u[1+\log(M/u)].
\tag{1}
\]
原母比较是
\[
 2(\sqrt n-\log_+M_*)R\le U+4rC_dA_nW.
\tag{2}
\]
这里已保 bulk 的精确抵消，不再添 \(SX\)，也不重复使用旧捕获平方信用。

## 2. 冻结具体测试：真实 level 捕获倾斜

当 \(u_C>0\)，定义 level 概率
\[
 d\lambda_C(t)=c_C'(t)dt/u_C,\qquad
 k_C(t)=\frac{c_C(t)}{X_C(t)}
         \frac{Y_C(t)}{Y_C(\infty)}\in(0,1]
 \quad(\lambda_C\text{-a.e.}),
\]
\[
 r_C=\int c_C'(t)k_C(t)dt,\qquad
 d\widetilde\lambda_C=\frac{u_C k_C}{r_C}\,d\lambda_C.
\tag{3}
\]
若 \(u_C=0\)，该格全部项置零。正质量格有 \(p_C,r_C>0\)；零点不作除法。
这些都是原 \(c_C,X_C,Y_C\) 的显式可测函数，不选新来源，不重新运行任何路径。
关键的实际交叠表达是
\[
 \boxed{p_Cr_C=\frac1{m_v}
      \int c_C'(t)c_C(t)\frac{Y_C(t)}{X_C(t)}dt.}
\tag{4}
\]
它保留原接受权两次出现所形成的二次捕获，而非立方体边界体积。

置
\[
 Q=\left(\sum_C\sqrt{p_Cr_C}\right)^2,\qquad
 \alpha_C=u_C/u,\qquad
 \beta_C=\frac{\sqrt{p_Cr_C}}{\sqrt Q}.
\tag{5}
\]
\(u=0\) 时整纤维贡献零；\(u>0\) 时 \(Q>0\)。
这等价于冻结 cell 对偶测试
\(\log\sqrt{r_C/p_C}\) 在正格上，其零格按支持限制处理。
由 Cauchy，
\[
 0<Q\le\sum_Cr_C\le u.
\tag{6}
\]

## 3. 完整弱对偶与所有差额

对每个正格，直接计算两个 level law 的 KL：
\[
 \int c_C'\log(1/k_C)\,dt
 =u_C\log(u_C/r_C)
   +u_CD(\lambda_C\Vert\widetilde\lambda_C).
\tag{7}
\]
把 (7) 与 cell fit
\(uD(\alpha\Vert p)\) 相加，并仅整理对数，得到
\[
 \boxed{
 \mathrm{Fit}_{\rm fibre}+E_{{\rm parent},{\rm fibre}}
                 +E_{{\rm terminal},{\rm fibre}}
 =u\log(u/Q)+2uD(\alpha\Vert\beta)
       +\sum_Cu_CD(\lambda_C\Vert\widetilde\lambda_C).}
\tag{8}
\]
这是显式可行测试的弱对偶证书；不调用无限维强对偶。每个右侧项非负，特别
\[
 U\le\int u\left[1+\log\frac{m_AQ}{u^2}\right]d\nu.
\tag{9}
\]
若不丢右侧两个 KL，(9) 相应为精确恒等式。可积性沿用 R443：有限接收场上 (1) 的三个非负减项有限；(8) 因而不作无穷减无穷。连续 level 可先截断，随后用相对熵的非负性和已证有限值取极限。

这比把两个缺陷分别扔掉更准确；但它本身不是对 (2) 的来源付款。为避免只是把 logarithmic 目标换名，明确给出由此产生的一个**正的、非对数充分检验**：
\[
 \mathfrak M=
 \int_{\{u>0\}}\frac{m_AQ}{u}\,d\nu
 =\frac1h\sum_e\int\sigma(dA)\pi_A(dy)a_0^e(A,y)
       \int G(A,v)\frac{Q}{u}\frac{dv}{m_v}.
\tag{10}
\]
对 \(R>0\)，按实际保留质量 \(u\,d\nu/R\) 的 Jensen，
\[
 U\le R\,[1+\log(\mathfrak M/R)].
\tag{11}
\]
零原流单独取零，不计算 \(\log0\)。\(\mathfrak M\) 是有真实当前权的二次捕获积分，(4) 给出其原生定义；不是无标记 \(P_2\)，也不能用 \(\sum_Cr_C\le u\) 就宣布它已付。

例如若实际能证固定常数 \(C\ge1,b\ge0\) 的
\(\mathfrak M\le C(n+2)^b(X+nW)\)，则在 \(R>\epsilon X\)、\(R\le SX\) 时，
\[
 U\le S[1+\log(C(n+2)^b/\epsilon)]X+SnW.
\tag{12}
\]
这里取 \(0<\epsilon\le1\)，保证所用 \(X\) 系数非负。大维可再核吸收；小维与全部旧母账仍须保留。**(12) 的前提未证明，本稿不据此记任何费用。**

## 4. 距离权为何不能免费补偿，以及缺的具体几何约束

R444 另一方向的权
\(\psi(A,w,v)=(\alpha_0/\delta(w,v))^n\)
对固定 receiver-pair 纤维的 cell 是常数。任意 cell Gibbs 测试 \(a_C>0\) 中，
\[
 \sum_C\alpha_C\log(\psi a_C)
       -\log\sum_Cp_C\psi a_C
 =\sum_C\alpha_C\log a_C-\log\sum_Cp_Ca_C.
\tag{13}
\]
因此，仅插入这个 pair 常数不能从 cell fit 获得
\(-\log\psi=n\log(\delta/\alpha_0)\) 的补偿。已知 \(\int\psi\,d\mathcal P\) 小只价格一个加权原流；不能反向给该正 log 的上界。

(3)–(4) 的测试确实依赖真实 cell 和 level，避开了 (13) 的空抵消。不过当前能证的几何/代数界只有 (6)。把 \(Q/u\) 放成 1 后，(10) 出现实际 receiver support 的总 \(\int dv/m_v\)，不是固定来源的 occupancy，不能用 \(A_n/q\) 代替。不同 \(v\) 的交叠可以由不同来源供给。

缺的具体比较是：利用完整匹配、当前权及 old-source low-common，把 **(4) 的真实二次交叠在 (10) 的同一原父/旧来源积分下** 求和，而不是逐 pair 后删掉来源关联。low-common 带 \(c_v(y)\)，(4) 未必带它；不可无代价补入。另一个可能是保 (8) 的两个非负 KL 抵消 (10) 的大值，但也未建立这种比较。

诊断性结论是：这一个显式共同测试没有完成母预算；冻结它作为精确可计算的检验，不继续调人为距离常数，不新增局部分支，不修改原 \(R433\)。

## 5. 计算证据范围

同前缀脚本对三组有限 clipping/current profiles 计算 (3)–(8)，含零接受段和非单调接受段。实际父/终端来源质量由模型来源胞积分，未把 \(f\) 当均匀体积。符号检查用于积分恒等式；高精度数值只诊断根号与 KL 的大小。另检查 pair-constant 对偶抵消，以及全局等比例接受时 \(Q\) 二次缩放、\(m_AQ/u^2\) 不变。它们不是原真实中心、严格质量门或完整 history 的实现。

实际运行 `/tmp/r444_mainproof_check.py`：初步两格全接受、两格零接受压力、扩大四格三种 profile 的 retained mass 分别为 \(9/2,7/10,125/36\)。三种 (8) 差精确符号化简为 0，70 位非区间诊断中 \(u-Q\) 及三个右侧项均非负。接受率整体乘 \(1/3\) 的比较精确验证 \(r_C,Q\) 乘 \(1/9\)，以及 pair-constant 测试的符号抵消。标准输出 `/tmp/r444_mainproof.result.txt`；复用前轮来源胞只是接口复核，不算新增原生覆盖。
