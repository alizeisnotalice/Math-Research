# R512：连续半径的真实极值与同步几何亏损

本定理覆盖固定任意非负L1来源及整个连续半径窗；不是有限候选的经验外推。它构建可用于后续几何付款的全局极值对象和同步替换不等式，尚不提供根阶预算。闭质量层标签是明确的外放松，不能宣称与原半开层最优值相等。

## 1. 原域、闭层域与正支配

固定n≥1、μ=f dx≥0、0<W=μ(R^n)<∞、0<a≤b≤2a、q>0、λ=rq、S>0、γ>1。E为Borel中心集，a.e. B∈E至少存在R∈[a,b]满足q≤μQ(B,R)/R^n≤λ；任意Lebesgue可测E取mod零Borel版本。先删去无合法动作的Borel中心零集，下文E每点纤维非空，不改变任何积分。原历史、gate保持标签，本定理只支配raw平方，不重评原历史。

记m(B,R)=μQ(B,R)，m_j=qa^nγ^j，j=0,…,J，其中J=floor(log_γ(λb^n/(qa^n)))。动作空间Y=[a,b]×{0,…,J}紧。闭可行动作集
\[
\mathcal A_B=\{(R,j):qR^n\le m(B,R)\le\lambda R^n,\quad m_j\le m(B,R)\le\gamma m_j\}.
\]
边界质量允许相邻两标签；每中心仍只能选择一个标签和一个半径。原半开质量层选择均可行。将原t(B)≤S提升为S，仅对原非负raw列逐点增大，故平方也增大；不声称原接受流随此变化。

令\(\mathcal H=\bigoplus_{j=0}^J L^2(\mu)\)，核
\[
k(B,R,j)(y)=S R^{-n}1_{Q(B,R)}(y)e_j.
\]
用σ_E=dB|_E为固定第一边缘，考虑有限正测度Γ在R^n×Y上，第一边缘σ_E，且支撑在全空间闭集G={(B,R,j):(R,j)∈A_B}。定义
\[
\ell^\Gamma=\int k\,d\Gamma\in\mathcal H,
\qquad \mathcal Q(\Gamma)=\|\ell^\Gamma\|_{\mathcal H}^2.
\]
确定性共同选择对应Γ=dB|_E δ_(R(B),j(B))；每B只有一个选择，来源对从不参与选择。

固定层半径比至多(γr)^(1/n)。R511的原中心包络积分给
\[
0\le\ell_j^\Gamma\le C=S[1+\log(\gamma r)],\quad
\sum_j\ell_j^\Gamma\le SA_n,\quad A_n=1+n\log(b/a).
\]
说明混合情形：每中心各标签/半径所分配的总概率为1，故包络不乘候选数或双标签数。可等价用固定边缘的测度积分支配，无需把任意pair单独取sup。

取任一可测合法动作并令辅助t=1，由Tonelli和同一包络q|E|≤A_nW，所以E有限测度。可测选择的存在在第3节说明。亦可直接用已有原选择证明此有限性。于是Q≤CSA_nW；该线性于n的粗界只保证极值问题有限，不冒称目标阶。

## 2. 极值存在：保来源的强场紧性

绝对连续性保证任何立方体边界μ测度零。若(B_l,R_l)→(B,R)，R≥a>0，则指标函数μ-a.e.收敛；支配收敛给m(B_l,R_l)→m(B,R)及k(B_l,R_l,j)→k(B,R,j)于H。标签离散，所以k在整个R^n×Y连续，且||k||≤M=S a^-n√W。

G因此闭。Γ族第一边缘固定、Y紧：对任意ε，取紧中心集K使σ_E(K^c)<ε，则所有Γ在K×Y外质量<ε。归一化|E|后由Prokhorov紧性定理，任意Γ序列有弱收敛子列。极限仍有固定边缘且由闭集Portmanteau仍集中在G；E本身不必闭，其支持由固定边缘保证，不能把G∩(E×Y)误作闭集。

关键是H值积分强收敛，而非只得弱收敛：给定ε，在紧K×Y上，k像紧，选有限ε网并令P为其张成空间的正交投影，则||(I−P)k||≤ε于K×Y，全空间≤M。故每个Γ的尾范数≤ε|E|+Mσ_E(K^c)。有限维Pk各坐标为全空间有界连续函数，弱收敛使其积分收敛。先固定K/P再取极限，最后令ε及尾趋0，得到||ell^Γ_l−ell^Γ||→0。

因此Q在此弱紧可行族连续并达最大值Q*。这只对固定n、a、μ、E给存在；M和紧集的依赖不用于宣称维数一致的数值逼近率。零E、W或S可直接给零场。

## 3. 不借无限维purification的确定性极值

闭G和紧Y保证B↦A_B弱可测：Y每个开集是可数个紧集的并，G在这些紧动作集上的投影闭，故相交非空的中心集Borel。限制到E即有非空紧值。对固定最优ell*，score
\[
\psi(B,R,j)=\langle k(B,R,j),\ell^*\rangle
=S R^{-n}\int_{Q(B,R)}\ell_j^*(y)d\mu(y)
\]
连续且有界。可测最大值定理给可测argmax动作c*(B)。记其确定性场ell_d。由于Γ*第一边缘固定，
\[
\langle\ell^*,\ell_d-\ell^*\rangle
=\int_E\max_{c\in A_B}\psi(B,c)dB-\int\psi\,d\Gamma^*\ge0.
\]
平方展开与Q*最大性给
\[
0\ge Q(\Gamma_d)-Q^*=2\langle\ell^*,\ell_d-\ell^*\rangle+\|\ell_d-\ell^*\|^2\ge0.
\]
两项必为零。因此存在真正确定性共同半径/标签的最大选择器，且其字段等于ell*。这不是调用一般无限维纯化定理：只利用当前平方目标的正二次余项和可测线性argmax。它不意味着所有最大选择器相同。

对原输入t≤S的半开层raw平方，有Q_original≤Q*；原质量和密度band不改变，闭标签可优化。若将来证明Q*≤B(n)W，便支配原平方；含δX*时须保X*≤rX_original。没有证明Q*的独立多对数来源预算。

## 4. 同步四盒交集由score亏损控制

固定一个上述最大确定性c*(B)。对任意可测合法替代c(B)和任意可测U⊂E，定义
\[
h_U=\int_U[k(B,c(B))-k(B,c^*(B))]dB,
\quad D_U=\int_U[\psi(B,c^*(B))-\psi(B,c(B))]dB\ge0.
\]
在U上替换的动作仍合法，且只改共享中心选择。全局最大性精确给
\[
\boxed{\ \|h_U\|_{\mathcal H}^2\le2D_U.\ }\tag{EX}
\]
这强于R511近最佳响应的单个一阶条件：它同时适用于任意中心包和任意合法连续半径替代。必须保替代的真实q带，不准搬来另一中心的半径便默认可行。

左端是实来源几何：写d_B=k(B,c)-k(B,c*)，则
\[
\|h_U\|^2=\int_{U\times U}\langle d_B,d_C\rangle\,dB\,dC.
\]
其中每项\(\langle k(B,R,j),k(C,T,l)\rangle\)准确等于
\[
1_{j=l}\frac{S^2\mu(Q(B,R)\cap Q(C,T))}{R^nT^n}.
\]
故EX保留四项有符号的真实盒交集，未将边界体积乘未经证明的来源帽。对互斥中心包U_1,…,U_m，还可将它展开为各包平方加全部交叉项，不再逐包独立收W。

若D_U=0，对U的每个子集也有零亏损，EX使所有子集上的∫d_B=0；利用H可分及标量化，可得d_B=0 a.e.于U。这只说明一个指定合法替代在零score亏损区域不能改变真实来源核，不宣称有统一正margin或所有维度的稳定常数。

## 5. 明确尚缺的几何付款

EX的右边仍是极值场的score差。若只丢掉替代score，得到∫ψchosen=Q*，仍循环。本轮没有证明存在足够丰富、保持q带的替代使D_U可由一次W或小吸收量控制；也未从EX得到R511的终端K预算。它提供保所有连续半径的一般极值对象及可用的有符号几何约束，不能充当根阶完成。

原历史同流、旧入口倍数及全部时钟/跳跃/尺度费用仍沿主稿保留；改变选择器只作raw平方外支配。

## 6. 外部定理与核验范围

实际阅读的紧性定理：Evan Sorensen，SLMath 2024 tightness session，Theorem 1.1，紧概率族有弱收敛子列。本应用在Polish空间R^n×Y、固定有限非零总质量归一后；另验证闭约束及强H场连续，未从一般弱收敛直接推平方连续。
[原讲义](https://www.mit.edu/~skycao/SLMath/Session_1_notes_(tightness).pdf)。

可测最大值定理采用Weigand–Roith–Burger《Adversarial flows》Appendix F，Theorem F.3所陈述版本（其证明引Aliprantis–Border Theorem18.19）：可分度量动作域、弱可测非空紧值、Carathéodory目标，给可测最大selector。以上逐项核条件，不引用该文的对抗流应用定理。
[论文与定理](https://doi.org/10.1017/S0956792525100120)。

M01/M03技能仅用于核对紧性/极值/稳定性边界。未使用它们尚未认证的一般KM或通用稳定定理；本节正是另给所需论证。

## 7. 本机精确几何核验（不替代一般证明）

以下采用真实一维μ=1_[−3,3]dy、真实中心区间及常半径1或2，q=r=S=1。每个中心包整体选一个动作，故是有限包域而非第2节整个连续选择域。闭层γ=2给R=2的两个合法标签，显式检验端点。三阶段分别为1、2、3个中心包（3、9、27种选择），对每组有限最大配置穷尽全部替代及所有中心包子集，用Fraction准确积分piecewise线性原来源列的乘积；验证EX、亏损非负及平方增量身份。最大值只对这个有限包域认证，绝不据n=1推一般阶数。

```python
from fractions import Fraction as F
from itertools import product
mu_interval=(F(-3),F(3))
blocks=[(F(-1),F(-1,2)),(F(-1,2),F(0)),(F(0),F(1,2))]
actions=[(F(1),0),(F(2),0),(F(2),1)]
count=0
for nb in (1,2,3):
 I=blocks[:nb]
 knots={mu_interval[0],mu_interval[1]}
 for l,h in I:
  for R,j in actions:
   knots.update([l-R/2,l+R/2,h-R/2,h+R/2])
 xs=sorted(x for x in knots if mu_interval[0]<=x<=mu_interval[1])
 def field(choice):
  return [[sum(max(F(0),min(h,y+actions[c][0]/2)-max(l,y-actions[c][0]/2))/actions[c][0]
               for (l,h),c in zip(I,choice) if actions[c][1]==j) for y in xs] for j in range(2)]
 def inner(a,b):
  return sum((xs[t+1]-xs[t])*(2*a[j][t]*b[j][t]+a[j][t]*b[j][t+1]+a[j][t+1]*b[j][t]+2*a[j][t+1]*b[j][t+1])/6
             for j in range(2) for t in range(len(xs)-1))
 choices=list(product(range(3),repeat=nb)); fields={c:field(c) for c in choices}
 best=max(choices,key=lambda c:inner(fields[c],fields[c]));L=fields[best];Q=inner(L,L)
 for c in choices:
  for bits in product((0,1),repeat=nb):
   new=tuple(c[i] if bits[i] else best[i] for i in range(nb));V=fields[new]
   h=[[V[j][t]-L[j][t] for t in range(len(xs))] for j in range(2)]
   D=-inner(L,h);norm=inner(h,h);gain=inner(V,V)-Q
   assert D>=0;assert norm<=2*D;assert gain==-2*D+norm;count+=3
 print('blocks',nb,'choices',len(choices),'best',best,'exact Q',Q)
print('PASS',count,'exact real-center interval exchange and closed-label checks')
```
