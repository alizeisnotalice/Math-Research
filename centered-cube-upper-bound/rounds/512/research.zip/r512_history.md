# R512 来源、决策与复现索引

起始专用clone /Users/zhengzhihao/Math-Research-centered-cube-work，origin git@github.com:alizeisnotalice/Math-Research.git，main起点52b70feae7f64a26f155c7a78c538632a6c9a869，工作区干净。上一轮真实独审/推送形成进展，本轮沿其终端继续。只主代理写项目归档，各子代理各自/tmp责任文件，不共享暂存区。

读取R511归档说明，复用既有三个Agent。Astra限定于Hardy终端几何与真正合法的score替代；Sol high先独立核极值量词，再读作者；Sol medium计算跨层拥挤与严格DP证书。没有多个高成本Agent重复同一整题，没有填满槽位。

主代理读M01/M03技能及其来源状态；仅采用检查闭性、紧性、亏损方向、极值与稳定性区别的原则，未借技能名使用未经核验的KM或通用近极值稳定定理。实际外部阅读为SLMath 2024 Evan Sorensen Theorem1.1和Weigand/Roith/Burger论文正式Cambridge PDF Appendix F.3，URL及具体适用条件在proof。搜索的其他结果不作证据，未将相关题名当定理。本轮不下载或提交新PDF，不编译PDF。

proof是固定任意L1来源的连续动作外放松域一般证明，包含闭质量端点处理、强H场紧性、确定性最大场和所有合法同步替换EX。不是n=1数值证明；独立作者与审查都保持原半开域仅被支配，原history并未单调。来源不允许有原子是核连续性的明确输入，与原f dx范围一致。固定a>0及有限比例窗仅为当前原入口合同，不能据此宣布全尺度定理完成。

numeric真实模型沿原格点小源但保所有合法k，首次严格超过总列1。浮点探索main screen可用--rescreen固定seed重跑；六个不可随脚本复现的非必要子集历史观察已从最终py/json/md删除，未进入正式证据。严格证书使用Arb256球及真实删除条带/有限L1边界，DP避免K!。默认复制py与JSON一并运行，只重跑严格部分，不机械再跑昂贵探索；JSON中统计置信区间仍是探索数据，不等于严格证书。

重放按replay.json执行指定Python-I，geometry/proof python围栏提取为脚本；numeric.py与冻结JSON一并复制后运行，stdout逐字比对，JSON规范化仅按replay明列规则处理。PRE独立检查或独审重复运行不叠加为新的研究证据数量。MATLAB未调用，不列证据。

关键未付：EX右边真实score亏损的独立来源预算、保持真实q带的小亏损替代、R511近层终端；原入口旧费用全部保留。已知Hardy尾可付并不授权忽略k=0。固定模型c_j容量分散不推广为所有来源的容量分散。
