#!/usr/bin/env python3
from pathlib import Path
import numpy as np
import scipy
from scipy.stats import binomtest
import json,sys,time,platform
ROOT=Path(__file__).resolve().parent

def screen():
 rng=np.random.default_rng(5122026);N=40000;results=[]
 for n in [16,64,256,1024]:
  counts={q:0 for q in [1.25,1.5,2.,3.,4.,8.,16.]}
  for offset in range(0,N,1000):
   U=np.sort(rng.random((min(1000,N-offset),n)),axis=1)
   for q in counts:
    ks=np.arange(n+1);R=(2.**(ks/n))/(q**(1/n));valid=(R>1)&(R<2);ks=ks[valid];t=R[valid]-1
    below=np.where(ks[None,:]>0,U[:,np.maximum(ks-1,0)],0)
    above=np.where(ks[None,:]<n,U[:,np.minimum(ks,n-1)],1)
    hit=((below<=t)&(above>=t)).any(axis=1)
    counts[q]+=int(hit.sum())
  for q,c in counts.items():
   p=c/N;lo,hi=binomtest(c,N).proportion_ci(confidence_level=.999)
   z={'n':n,'q':q,'samples':N,'hits':c,'qP_estimate':q*p,'qP_binomial_999_interval':[q*lo,q*hi],'purpose':'floating Monte Carlo exploration only; no theorem or strict certificate'};results.append(z)
  print('SCREEN',n,[(q,round(q*c/N,6)) for q,c in counts.items()],flush=True)
 return {'environment':{'executable':sys.executable,'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__},'screen':results}

# Strict finite-model certificate. Default execution below loads the already recorded
# reproducible screen; pass --rescreen to repeat Monte Carlo exploration.
from fractions import Fraction as Q
from math import comb
from functools import reduce
import flint
from flint import arb,ctx
ctx.prec=256
checks=0

def ck(x):
 global checks
 assert bool(x)
 checks+=1

def aa(x):
 x=Q(x);return arb(x.numerator)/x.denominator

def firsthit(n,probs,targets):
 remaining=sum(probs,arb(0));dp=[arb(0)]*(n+1);dp[0]=arb(1);P=[];transitions=0
 for p,target in zip(probs[:-1],targets):
  t=p/remaining;ck(t>0 and t<1);nextdp=[arb(0)]*(n+1);hit=arb(0)
  for r,mass in enumerate(dp):
   if mass==0:continue
   m=n-r;w=(1-t)**m
   for l in range(m+1):
    transitions+=1;z=mass*w;new=r+l
    if new==target:hit+=z
    else:nextdp[new]+=z
    if l<m:w=w*(m-l)/(l+1)*t/(1-t)
  P.append(hit);dp=nextdp;remaining-=p
 S=sum(probs,arb(0))**n
 out=[S*p for p in P];no=S*sum(dp,arb(0))
 ck((sum(out,arb(0))+no-S).contains(0))
 return out,no,transitions

def certified(n,qpower):
 q=2**qpower;ks=list(range(qpower+1,n+1));K=len(ks);delta=Q(1,10000*n*K)
 base=arb(2).root(n);Rs=[base**(k-qpower) for k in ks]
 ck(all(R>1+2*aa(delta) and R<2-2*aa(delta) for R in Rs))
 A=[R-1-2*aa(delta) for R in Rs];B=[R-1+2*aa(delta) for R in Rs]
 probs=[A[0]]+[A[j]-B[j-1] for j in range(1,K)]+[1-B[-1]]
 ck(all(p>0 for p in probs))
 asc,no,ta=firsthit(n,probs,ks)
 desc_rev,no2,td=firsthit(n,list(reversed(probs)),[n-k for k in reversed(ks)])
 desc=list(reversed(desc_rev));ck((no-no2).contains(0));ck((sum(asc,arb(0))-sum(desc,arb(0))).contains(0))
 selected=sum(asc,arb(0));total=q*selected;ck(total>1)
 L=1000*n;factor=Q(L-2,L)**n;ck(aa(factor)*total>1)
 def st(x):return x.str(35,radius=True)
 rules=[]
 for name,P in [('ascending_k',asc),('descending_k',desc)]:
  ell=[q*p for p in P];objective=sum((x*x for x in ell),arb(0));ck(objective>0)
  rules.append({'shared_rule':name,'P_j_arb':[st(p) for p in P],'ell_j_arb':[st(p) for p in ell],'Q_over_W_periodic_arb':st(objective),'Q_over_W_finite_lower_arb':st(aa(factor)*objective),'max_individual_ell_arb':st(reduce(lambda a,b:a.max(b),ell)),'total_ell_arb':st(sum(ell,arb(0)))})
 S=sum(probs,arb(0));left=arb(0);caps=[]
 for j,k in enumerate(ks):
  left+=probs[j];caps.append(q*comb(n,k)*left**k*(S-left)**(n-k))
 maxcap=reduce(lambda a,b:a.max(b),caps);all_rule_bound=maxcap*total
 ck(all_rule_bound<1)
 survive=(1-4*K*delta)**n
 ck((sum(probs,arb(0))-aa(1-4*K*delta)).contains(0))
 result={'n':n,'q0':q,'parent_density_band_r':1,'candidate_k':ks,'K':K,'delta':str(delta),'R_min_arb':st(Rs[0]),'R_max_arb':st(Rs[-1]),'exact_survival_probability':str(survive),'survival_probability_arb':st(aa(survive)),'discard_stripe_upper_bound_exact':str(4*n*K*delta),'selected_probability_arb':st(selected),'surviving_no_eligible_probability_arb':st(no),'total_raw_column_arb':st(total),'finite_total_raw_column_lower_arb':st(aa(factor)*total),'rules':rules,'all_shared_rule_Q_over_W_upper_arb':st(all_rule_bound),'eligible_raw_column_caps_arb':[st(c) for c in caps],'max_eligible_column_cap_arb':st(maxcap),'sum_eligible_caps_squared_arb':st(sum((c*c for c in caps),arb(0))),'dp_transitions_ascending':ta,'dp_transitions_descending':td,'finite_L':L,'finite_W':str(L**n),'finite_lower_factor_exact':str(factor),'scope':'two demonstrated shared selectors; no optimality claim'}
 print('CERT',n,q,'K',K,'total',st(total),'square_asc',rules[0]['Q_over_W_periodic_arb'],'square_desc',rules[1]['Q_over_W_periodic_arb'],'all_rule_upper',st(all_rule_bound),flush=True)
 return result

def strictmain():
 path=ROOT/'r512_numeric.json'
 old=json.loads(path.read_text()) if path.exists() and '--rescreen' not in sys.argv else screen()
 old['certified_models']=[certified(16,1),certified(64,2),certified(64,4)]
 old['strict_environment']={'executable':sys.executable,'python':platform.python_version(),'python_flint':flint.__version__,'arb_precision_bits':ctx.prec}
 old['strict_checks']=checks
 path.write_text(json.dumps(old,indent=2)+'\n')
 print('PASS strict finite-model certificates; all three total columns exceed 1; demonstrated rules only',flush=True)

if __name__=='__main__':strictmain()
