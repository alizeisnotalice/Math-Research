from __future__ import annotations

import argparse
import hashlib
import json
import platform
import sys
from dataclasses import dataclass
from fractions import Fraction as F
from itertools import combinations, product
from math import prod
from pathlib import Path

import flint
from flint import arb, ctx, fmpq


PRECISION = 256
K_VALUES = (1, 2, 4, 16)


def point(*coordinates):
    return tuple(F(x) for x in coordinates)


def ball(value):
    value = F(value)
    return arb(fmpq(value.numerator, value.denominator))


def interval(value):
    return value.str(24)


def exact_sum(values):
    return sum(values, F(0))


@dataclass(frozen=True)
class Box:
    bounds: tuple

    @property
    def volume(self):
        return prod(hi - lo for lo, hi in self.bounds)

    def contains(self, point):
        return all(lo < x < hi for (lo, hi), x in zip(self.bounds, point))


@dataclass(frozen=True)
class Cube:
    center: tuple
    radius: F

    def scale(self, factor=F(1)):
        return Box(tuple((x - factor*self.radius, x + factor*self.radius) for x in self.center))


def cells(boxes):
    axes = []
    for axis in zip(*(box.bounds for box in boxes)):
        cuts = sorted(set(end for pair in axis for end in pair))
        axes.append(zip(cuts, cuts[1:]))
    for parts in product(*axes):
        sample = tuple((lo + hi) / 2 for lo, hi in parts)
        yield sample, prod(hi - lo for lo, hi in parts)


def overlap(*boxes):
    return prod(
        max(F(0), min(hi for _, hi in axis) - max(lo for lo, _ in axis))
        for axis in zip(*(box.bounds for box in boxes))
    )


def owners(shrinks, priority):
    v = [F(0)] * len(shrinks)
    count = 0
    for x, size in cells(shrinks):
        owner = next((i for i in priority if shrinks[i].contains(x)), None)
        if owner is not None:
            v[owner] += size
            count += 1
    for k, i in enumerate(priority):
        independent = shrinks[i].volume
        for order in range(1, k+1):
            independent += (-1)**order * sum(
                overlap(shrinks[i], *(shrinks[j] for j in subset))
                for subset in combinations(priority[:k], order)
            )
        assert independent == v[i]
    return v, count


def cap_one_primal(subset, sizes, v, G):
    cap = [v[i] / (G * sizes[i]) if i in subset else F(0) for i in range(len(v))]
    gamma = [F(0)] * len(v)
    left = F(1)
    price = F(0)
    for i in sorted(subset, key=lambda j: sizes[j], reverse=True):
        gamma[i] = min(cap[i], left)
        left -= gamma[i]
        if not left:
            price = sizes[i]
            break
    total = sum(g * size for g, size in zip(gamma, sizes))
    dual_caps = [max(F(0), size - price) for size in sizes]
    assert sum(gamma) <= 1 and all(0 <= g <= c for g, c in zip(gamma, cap))
    assert price + sum(u * c for u, c in zip(dual_caps, cap)) == total
    return gamma, total, price


def transfer_geometry(name, cubes, priority, prices, direction, thresholds):
    n = len(cubes[0].center)
    labels = tuple(range(len(cubes)))
    a = 32*n
    parent = [cube.scale() for cube in cubes]
    shrunk = [cube.scale(F(1, a)) for cube in cubes]
    sizes = [box.volume for box in parent]
    v, own_cells = owners(shrunk, priority)
    V = sum(v)
    all_cells = []
    for x, volume in cells(parent + [box for box, _ in prices]):
        active = tuple(i for i, box in enumerate(parent) if box.contains(x))
        if active:
            density = exact_sum(weight for box, weight in prices if box.contains(x))
            all_cells.append((active, volume, density))
    assert all(density >= 1 for _, _, density in all_cells)
    # A common open arrangement cell proves that full and subfamily LPs are simplices.
    assert any(active == labels for active, _, _ in all_cells)
    root = max(labels, key=lambda i: sizes[i])
    assert sum(size == sizes[root] for size in sizes) == 1
    lam = [F(i == root) for i in labels]
    assert all(sum(lam[i] for i in active) <= 1 for active, _, _ in all_cells)
    G0 = max(
        exact_sum(v[i] for i in subset) / max(sizes[i] for i in subset)
        for k in range(1, len(cubes) + 1) for subset in combinations(labels, k)
    )
    assert G0 > 0
    if name == "isolated_ratio_one_eighth_nonconstant_density":
        assert cubes[1].radius / cubes[0].radius == F(1, 8)
    mass = [exact_sum(weight * overlap(box, region) for region, weight in prices) for box in parent]
    lebesgue = [[overlap(A, B) for B in parent] for A in parent]
    intersections = [
        [exact_sum(weight * overlap(A, B, region) for region, weight in prices) for B in parent]
        for A in parent
    ]
    for i, j in product(labels, repeat=2):
        assert lebesgue[i][j] == exact_sum(
            volume for active, volume, _ in all_cells if i in active and j in active
        )
        assert intersections[i][j] == exact_sum(
            volume * density for active, volume, density in all_cells if i in active and j in active
        )
    assert all(mass[j] == intersections[j][j] >= sizes[j] for j in labels)
    kernel = [[F(direction(cubes[j].radius, cubes[i].radius)) for i in labels] for j in labels]
    assert any(kernel[j][i] != kernel[i][j] for j, i in product(labels, repeat=2))

    def forward(weights):
        return [
            exact_sum(weights[i] * intersections[j][i] * kernel[j][i] for i in labels) / mass[j]
            for j in labels
        ]

    def transpose(weights):
        return [
            exact_sum(weights[j] * intersections[i][j] * kernel[j][i] for j in labels) / mass[i]
            for i in labels
        ]

    q = forward(lam)
    assert all(0 <= value <= 1 for value in q)
    assert q != transpose(lam)
    physical_cross_average = exact_sum(
        volume
        * exact_sum(v[j] / sizes[j] for j in active)
        * exact_sum(lam[i] for i in active)
        for active, volume, _ in all_cells
    )
    overlap_weighted_pair = exact_sum(
        v[j] / sizes[j] * lam[i] * lebesgue[i][j] for i, j in product(labels, repeat=2)
    )
    assert physical_cross_average == overlap_weighted_pair <= V

    threshold_tests = []
    for u in thresholds:
        J = tuple(j for j in labels if q[j] > u)
        gamma, capped_value, capped_dual_price = cap_one_primal(J, sizes, v, G0)
        G0_original_clip = exact_sum(
            min(sizes[j] * lam[j], v[j] / G0) for j in J
        )
        assert G0_original_clip <= capped_value
        value_on_J = exact_sum(v[j] for j in J)
        direct_transfer = exact_sum(gamma[j] * mass[j] * q[j] for j in labels)
        from_transpose = exact_sum(lam[i] * mass[i] * t for i, t in enumerate(transpose(gamma)))
        cell_transfer = exact_sum(
            volume * density * exact_sum(
                lam[i] * gamma[j] * kernel[j][i] for i in active for j in active
            )
            for active, volume, density in all_cells
        )
        assert direct_transfer == from_transpose == cell_transfer
        same_direction_wrong = exact_sum(
            lam[i] * mass[i] * t for i, t in enumerate(forward(gamma))
        )
        if J:
            assert G0_original_clip == 0 < capped_value and same_direction_wrong != direct_transfer
            assert ball(capped_value) > c0() * ball(value_on_J / G0)
            assert direct_transfer > u * capped_value
            assert ball(G0 * direct_transfer / value_on_J) > c0() * ball(u)
            high_ratio = str(G0 * direct_transfer / value_on_J)
        else:
            assert not (value_on_J or capped_value or direct_transfer)
            high_ratio = None
        reverse_charge = exact_sum(v[j] * q[j] for j in labels)
        assert reverse_charge <= u*V + value_on_J
        theoretical = ball(u*V) + ball(G0 * direct_transfer / u) / c0()
        if J:
            assert ball(reverse_charge) < theoretical
        threshold_tests.append({
            "u": str(u),
            "high_rows": list(J),
            "exact_threshold_rows_excluded": [j for j in labels if q[j] == u],
            "true_high_owner_volume": str(value_on_J),
            "reoptimized_gamma": list(map(str, gamma)),
            "cap_one_value": str(capped_value),
            "cap_one_simplex_dual_price": str(capped_dual_price),
            "old_packing_restricted_and_clipped": str(G0_original_clip),
            "bilinear_original_transpose_and_cell_value": str(direct_transfer),
            "same_direction_wrong_value": str(same_direction_wrong),
            "G0_bilinear_divided_by_high_volume": high_ratio,
            "actual_reverse_charge": str(reverse_charge),
        })

    return {
        "name": name,
        "dimension": n,
        "cubes": [{"center": list(map(str, c.center)), "radius": str(c.radius)} for c in cubes],
        "price_rectangles": [
            {"bounds": [list(map(str, pair)) for pair in box.bounds], "density": str(weight)}
            for box, weight in prices
        ],
        "positive_volume_parent_price_cells": len(all_cells),
        "positive_volume_shrink_owner_cells": own_cells,
        "owner_priority": list(priority),
        "owners": list(map(str, v)),
        "d": list(map(str, sizes)),
        "m": list(map(str, mass)),
        "ambient_measure_is_absolutely_continuous": True,
        "P0": str(sizes[root]),
        "G0_original_owner_subsets": str(G0),
        "original_lambda": list(map(str, lam)),
        "k": [list(map(str, row)) for row in kernel],
        "q_forward": list(map(str, q)),
        "weighted_transpose_applied_to_original_lambda": list(map(str, transpose(lam))),
        "weighted_overlap_integral_WF": str(physical_cross_average),
        "weighted_overlap_integral_WF_divided_by_V": str(physical_cross_average / V),
        "threshold_tests": threshold_tests,
    }


def c0():
    return 1 - (-arb(1)).exp()


def geometry_fixtures():
    simple = (
        Cube(point(0, 0), F(2)),
        Cube(point("1/2", 0), F(3, 2)),
        Cube(point("7/4", "1/8"), F(1, 2)),
        Cube(point("9/4", "-1/8"), F(1, 2)),
        Cube(point("31/16", "1/16"), F(1, 8)),
        Cube(point("7/4", "1/8"), F(1, 4)),
    )
    uniform = transfer_geometry(
        "six_squares_uniform_price_nonsymmetric_scale",
        simple, (5, 0, 1, 2, 3, 4),
        ((Cube(point(0, 0), F(4)).scale(), F(1)),),
        lambda row, col: row < col,
        (F(1, 2), F(3, 4)),
    )
    thin = (Cube(point(0), F(1)), Cube(point("31/32"), F(1, 8)))
    nonuniform = transfer_geometry(
        "isolated_ratio_one_eighth_nonconstant_density",
        thin, (0, 1),
        (
            (Cube(point(0), F(2)).scale(), F(1)),
            (Box(((F(31, 32), F(33, 32)),)), F(1)),
        ),
        lambda row, col: row <= col / 8,
        (F(1, 2), F(3, 5)),
    )
    assert uniform["m"] == uniform["d"] and nonuniform["m"] != nonuniform["d"]
    return [uniform, nonuniform]


def as_intervals(rows):
    return tuple((F(lo), F(hi), F(value)) for lo, hi, value in rows)


def sliding_integral(f, lo, hi, absolute=True):
    return exact_sum(
        (abs(value) if absolute else value) * max(F(0), min(hi, r) - max(lo, l))
        for l, r, value in f
    )


def at(f, x):
    return exact_sum(abs(value) for l, r, value in f if l < x < r)


def hard(f, s, x, absolute=True):
    return sliding_integral(f, x-s, x+s, absolute) / (2*s)


def hard_breaks(f, s):
    return sorted({edge + offset for l, r, _ in f for edge in (l, r) for offset in (-s, s)})


def direct_sup(f, s, R, x):
    candidates = sorted({x-R, x+R, *(v for v in hard_breaks(f, s) if x-R <= v <= x+R)})
    heights = [hard(f, s, v) for v in candidates]
    value = max(heights)
    return value, [v-x for v, height in zip(candidates, heights) if height == value]


def slope_sup(f, s, R, x):
    knots = sorted({x-R, x+R, *(v for v in hard_breaks(f, s) if x-R < v < x+R)})
    current = hard(f, s, knots[0])
    value = current
    for l, r in zip(knots, knots[1:]):
        m = (l+r)/2
        slope = (at(f, m+s) - at(f, m-s)) / (2*s)
        current += slope*(r-l)
        value = max(value, current)
    assert current == hard(f, s, x+R)
    return value


def affine_at(f, s, left, right, displacement):
    first = hard(f, s, left+displacement)
    last = hard(f, s, right+displacement)
    slope = (last-first)/(right-left)
    return slope, first-slope*left


def envelope(f, s, R):
    hard_knots = hard_breaks(f, s)
    cuts = sorted({z+shift for z in hard_knots for shift in (-R, R)})
    pieces = []
    for l, r in zip(cuts, cuts[1:]):
        mid = (l+r)/2
        lines = [affine_at(f, s, l, r, shift) for shift in (-R, R)]
        lines.extend((F(0), hard(f, s, z)) for z in hard_knots if mid-R <= z <= mid+R)
        local_knots = {l, r}
        for (a, b), (c, d) in combinations(lines, 2):
            if a != c:
                crossover = (d-b)/(a-c)
                if l < crossover < r:
                    local_knots.add(crossover)
        local_knots = sorted(local_knots)
        for left, right in zip(local_knots, local_knots[1:]):
            middle = (left+right)/2
            m, b = max(lines, key=lambda line: line[0]*middle+line[1])
            low, high = m*left+b, m*right+b
            assert all(v >= 0 for v in (low, high))
            for x, represented in ((left, low), (middle, m*middle+b), (right, high)):
                assert represented == slope_sup(f, s, R, x) == direct_sup(f, s, R, x)[0]
            pieces.append((right-left, low, high))
    return pieces


def p_power(pieces):
    value = arb(0)
    for width, l, r in pieces:
        if l == r:
            value += ball(width * l) * ball(l).sqrt()
        else:
            start = ball(l)
            end = ball(r)
            value += ball(2*width/(5*(r-l))) * (end**2*end.sqrt()-start**2*start.sqrt())
    return value


def p_two(pieces):
    return exact_sum(width*(l*l+l*r+r*r)/3 for width, l, r in pieces)


def window_case(name, values, s, R, probes):
    f = as_intervals(values)
    assert all(l < r for l, r, _ in f) and all(r <= lo for (_, r, _), (lo, _, _) in zip(f, f[1:]))
    fixed = envelope(f, s, F(0))
    moved = envelope(f, s, R)
    p_input = sum(ball((r-l)*abs(v))*ball(abs(v)).sqrt() for l, r, v in f)
    fixed_p, moved_p = p_power(fixed), p_power(moved)
    powered_bound = (ball(1+256*(R/s)**2).log()*ball(F(3, 4))).exp()
    assert fixed_p < p_input
    if R:
        assert p_two(moved) > p_two(fixed)
        assert fixed_p < moved_p < powered_bound*p_input
    else:
        assert p_two(moved) == p_two(fixed) and moved_p.overlaps(fixed_p)
    samples = []
    for x in probes:
        optimum, displacements = direct_sup(f, s, R, x)
        assert optimum == slope_sup(f, s, R, x)
        endpoints_only = max(hard(f, s, x-R), hard(f, s, x+R))
        assert optimum >= max(hard(f, s, x), endpoints_only)
        samples.append({
            "x": str(x),
            "fixed_signed_mean": str(hard(f, s, x, absolute=False)),
            "fixed_absolute_mean": str(hard(f, s, x)),
            "max_two_window_ends": str(endpoints_only),
            "full_window": str(optimum),
            "some_maximizing_displacements": list(map(str, displacements)),
        })
    return {
        "name": name,
        "f_steps": [list(map(str, item)) for item in f],
        "s": str(s),
        "R": str(R),
        "pointwise": samples,
        "entire_envelope_affine_pieces_checked": len(moved),
        "fixed_p2_integral_exact": str(p_two(fixed)),
        "moving_p2_integral_exact": str(p_two(moved)),
        "input_p3_over_2_integral": interval(p_input),
        "fixed_p3_over_2_integral": interval(fixed_p),
        "moving_p3_over_2_integral": interval(moved_p),
        "R709_p_power_bound": interval(powered_bound),
        "moving_p3_over_2_integral_divided_by_input": interval(moved_p / p_input),
    }


def windows():
    pulse = ((0, 1, 1),)
    results = [
        window_case("small_shift_of_one_rectangular_pulse", pulse, F(1, 2), F(1, 128),
                    (F(-1, 4), F(129, 256), F(1, 2))),
        window_case("signed_steps_and_absolute_integrand",
                    ((-2, -1, -2), (-1, "-1/2", "1/3"), ("1/4", 1, "3/2"), ("5/4", "7/4", -1)),
                    F(3, 4), F(1, 5), (F(-3, 2), F(0), F(1, 3), F(8, 5))),
        window_case("two_separated_equal_peaks", ((-2, -1, 2), (1, 2, 2)),
                    F(1, 2), F(2), (F(0), F(1, 2), F(3))),
        window_case("zero_movement", pulse, F(1, 2), F(0), (F(1, 2),)),
    ]
    assert any(
        F(sample["full_window"]) > F(sample["max_two_window_ends"])
        for result in results for sample in result["pointwise"]
    )
    return results


def certified_ceil(value):
    ans = value.ceil().unique_fmpz()
    assert ans is not None
    k = int(ans)
    assert arb(k-1) < value < arb(k)
    return k


def dimension_scalars(n):
    dimension = arb(n)
    h = 1 + ball(F(1, 32*n))
    ln = dimension.log()
    delta = (ln / dimension).sqrt() / 64
    base_power = (1+256*delta**2).log()
    tensor = (ball(F(3*n, 4))*base_power).exp()
    dominating = (ball(F(3, 64))*ln).exp()
    assert 1 < tensor < dominating
    cube_ratio = 2*h*dimension/ln
    short_ratio = cube_ratio*delta
    log2 = arb(2).log()
    full = 3 + certified_ceil(dimension * cube_ratio.log() / log2)
    short = 2 + certified_ceil(dimension * short_ratio.log() / log2) if short_ratio > 1 else None
    if short is not None:
        assert 0 < short <= full
    root_n = dimension.sqrt()
    scope = []
    for mode, count in (("uniform", full), ("restricted", short)):
        if count is None:
            continue
        base = arb(count).sqrt()*dominating
        use_K = []
        for k in K_VALUES:
            ratio = (base*(arb(k)/root_n).sqrt())/root_n
            simplified = arb(k).sqrt()*(arb(count)/dimension).sqrt()*(-ball(F(13, 64))*ln).exp()
            assert ratio.overlaps(simplified)
            use_K.append({"K": k, "capped_tensor_price_divided_by_sqrt_n": interval(ratio)})
        powered = (ball(F(2, 3))*base.log()).exp()
        reduction = (arb(count).log()/3+ball(F(1, 32))*ln).exp()
        assert powered.overlaps(reduction)
        normalized = reduction/root_n
        rate = ((arb(count)/dimension).log()/3-ball(F(13, 96))*ln).exp()
        assert normalized.overlaps(rate)
        scope.append({
            "window": mode,
            "J": count,
            "at_G_equal_to_sqrt_n": use_K,
            "zero_absorption_scalar_divided_by_sqrt_n": interval(normalized),
        })
    return {
        "n": n,
        "delta": interval(delta),
        "tensor_p_power": interval(tensor),
        "n_power_3_over_64": interval(dominating),
        "two_h_to_the_n_separate": interval(2*h**n),
        "upper_radius_ratio_times_delta": interval(short_ratio),
        "window_results": scope,
    }


def absorption():
    reports = []
    for eps, k in product((F(1, 8), F(1, 32)), K_VALUES):
        u = eps/2
        eta_over_c0 = eps**2/(4*k)
        exact_receiver = u + k*eta_over_c0/u
        assert exact_receiver == eps
        eta = c0()*ball(eta_over_c0)
        source = ball(k/u)/c0()
        assert (ball(u)+source*eta).contains(ball(eps))
        reports.append({
            "K": k,
            "epsilon": str(eps),
            "u": str(u),
            "eta_over_c0": str(eta_over_c0),
            "eta": interval(eta),
            "exact_absorption": str(exact_receiver),
            "source_multiplier_before_B_eta": interval(source),
        })
    return reports


def report():
    ctx.prec = PRECISION
    script = Path(__file__)
    return {
        "schema": "r749-directional-transfer-verification-v1",
        "runtime": {
            "python": platform.python_version(),
            "python_executable": sys.executable,
            "python_flint": flint.__version__,
            "arb_precision_bits": PRECISION,
            "script_sha256": hashlib.sha256(script.read_bytes()).hexdigest(),
            "working_directory_for_commands": "directory containing verify.py and verify.json",
            "write_command": [sys.executable, "-B", script.name, "--out", "verify.json"],
            "rerun_command": [sys.executable, "-B", script.name, "--check", "verify.json"],
        },
        "genuine_cube_transpose_real_owner_checks": geometry_fixtures(),
        "finite_rational_moving_window_checks": windows(),
        "arb_dimension_scalars_only": [dimension_scalars(n) for n in (16, 64, 256, 1024, 2**20, 2**40, 2**60)],
        "arb_absorption_coefficients": absorption(),
        "scope": [
            "Finite cube families use absolutely continuous pricing and exact original owner volumes.",
            "The first kernel is strictly scale directional. The comparison kernel on two cubes uses the illustrative ratio threshold 1/8.",
            "G0 for finite fixtures is the worst original owner subset ratio; dimension scalars instead use G >= sqrt(n).",
            "The directional test verifies identities and charge conversion for the chosen packings, not a universal reverse bound.",
            "Moving-window envelopes are exact piecewise affine functions for the listed finite step data.",
            "High-dimensional Arb checks concern scalar estimates only.",
        ],
    }


def main():
    parser = argparse.ArgumentParser()
    target = parser.add_mutually_exclusive_group(required=True)
    target.add_argument("--out", type=Path)
    target.add_argument("--check", type=Path)
    args = parser.parse_args()
    raw = json.dumps(report(), ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    if args.out:
        args.out.write_text(raw, encoding="utf-8")
        print(f"wrote {args.out} ({len(raw)} bytes)")
    else:
        if args.check.read_text(encoding="utf-8") != raw:
            raise SystemExit("rerun differs from saved results")
        print(f"identical rerun of {args.check} ({len(raw)} bytes)")


if __name__ == "__main__":
    main()
