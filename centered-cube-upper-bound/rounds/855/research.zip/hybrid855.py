"""Exact axis-refresh capacity and a separate whole-bin occupation check."""
from collections import defaultdict
from fractions import Fraction as F
from itertools import product
import sys

U = F(2)
LAMBDA = F(1)
Y_PERP = F(1, 8)
TRANS = F(1, 64)


def span(i):
    return i[1] - i[0]


def hit(i, j):
    return max(F(0), min(i[1], j[1]) - max(i[0], j[0]))


def move(i, x):
    return i[0] + x, i[1] + x


def integrated_length(q, offset, target):
    if offset[1] <= offset[0]:
        return F(0)
    knots = sorted({*q} | {z - g for z, g in product(target, offset) if q[0] < z - g < q[1]})
    heights = [hit(move(offset, k), target) for k in knots]
    trapezoids = sum((y - x) * (a + b) / 2
                     for x, y, a, b in zip(knots, knots[1:], heights, heights[1:]))
    a, b = target
    l, r = offset

    def primitive(x):
        return (max(F(0), x + r - a) ** 2 - max(F(0), x + l - a) ** 2
                - max(F(0), x + r - b) ** 2 + max(F(0), x + l - b) ** 2) / 2

    assert trapezoids == primitive(q[1]) - primitive(q[0])
    return trapezoids


def centered_interval(q0, width):
    return q0 - width / 2, q0 + width / 2


def menus(n, density, receivers, packages):
    repeated = [F(0)] * 4
    transverse_volume = TRANS ** (n - 1)
    for center, q_width, offset, b_width in packages:
        q = centered_interval(center, q_width)
        preset = centered_interval(offset, b_width)
        actual = comparison = weighted = F(0)
        for e, side in receivers:
            true_offset = (max(preset[0], -side / 2), min(preset[1], side / 2))
            cap_offset = (max(preset[0], -1), min(preset[1], 1))
            t = integrated_length(q, true_offset, e) / q_width
            c = integrated_length(q, cap_offset, e) / q_width
            assert 0 <= t <= c <= b_width
            actual += t
            comparison += c
            weighted += t * density / (LAMBDA * side ** n)
        assert actual <= comparison <= b_width
        q_mass = density * q_width * transverse_volume
        local = q_mass * actual
        repeated[0] += local
        repeated[1] += q_mass * actual / b_width
        repeated[2] += q_mass * comparison
        repeated[3] += q_mass * weighted
        print("  q center, fixed menu width, actual y length, enlarged-box y length, separately normalized:",
              center, b_width, actual, comparison, actual / b_width,
              "; mean actual kappa(dy_d):", weighted)
    print("  sum over true q masses: axis dy, separately normalized, enlarged-box dy, actual kappa:",
          *repeated)
    print("  full positive-width receiver volume factor:", transverse_volume,
          "; actual q × full-y Lebesgue and kappa charges:",
          repeated[0] * transverse_volume, repeated[3] * transverse_volume)
    return repeated


def stage(label, n, density, specs, packages):
    assert 1 < density <= 2
    receivers = [(tuple(map(F, ends)), F(side)) for ends, side in specs]
    assert all(e2[0] > e1[1] for (e1, _), (e2, _) in zip(receivers, receivers[1:]))
    actual_e = sum(span(e) * TRANS ** (n - 1) for e, _ in receivers)
    for (a, b), side in receivers:
        assert F(2) ** (n - 1) < side ** n <= U ** n
        assert -side / 2 < a < b < side / 2
        assert Y_PERP + TRANS / 2 < side / 2
        assert max(abs(a), abs(b), Y_PERP + TRANS / 2) + 1 < 4
    assert Y_PERP == U * F(1, 16)  # true common theta off the chosen axis
    lo, hi = receivers[0][0][0], receivers[-1][0][1]
    left, right = move((-1, 1), lo), move((-1, 1), hi)
    axis_union = hi - lo + 2
    assert hit(left, right) > 0 and axis_union == 2 * U - hit(left, right)
    compared_mass = density * axis_union * U ** (n - 1)
    D = U ** n
    assert compared_mass == 2 * density * D - density * hit(left, right) * U ** (n - 1)
    assert compared_mass <= 2 * density * D <= 4 * LAMBDA * D
    for center, qw, _, _ in packages:
        q = centered_interval(center, qw)
        assert lo - 1 < q[0] < q[1] < hi + 1
        assert TRANS < min(side for _, side in receivers) / 2
    print(f"{label}: n={n}, lambda=1, true M={density}, true common bin {n}, E volume={actual_e}")
    print("  every theta_off = 1/16 gives the displayed central axis fibre; extremes", lo, hi,
          "; comparison union eta/(lambda*D) =", compared_mass / (LAMBDA * D))
    return menus(n, density, receivers, packages)


def toy_rank():
    # Pure finite rank model. No transverse displacement is asserted.
    widths = [F(1 + (j % 3 == 1)) for j in range(48)]
    intervals = []
    at = F(0)
    for width in widths:
        intervals.append((at, at + width))
        at += width
    H, d = F(7), F(5)
    p = []
    for i, (a, b) in enumerate(intervals):
        p.append({j: widths[j] / d for j, (c, e) in enumerate(intervals)
                  if j < i and a >= 2 * H and H <= a - e and b - c <= H + d})
    transpose = [defaultdict(F) for _ in widths]
    for i, row in enumerate(p):
        assert sum(row.values()) <= 1
        for j, prob in row.items():
            transpose[j][i] = widths[i] * prob / widths[j]
    assert all(sum(row.values()) <= 1 for row in transpose)
    delta = {i: w * (1 - sum(row.values())) for i, (w, row) in enumerate(zip(widths, p))}
    flow = {i: v for i, v in delta.items() if v}
    occupied = defaultdict(F)
    depths = []
    while flow:
        depths.append(sum(flow.values()))
        nxt = defaultdict(F)
        for i, val in flow.items():
            occupied[i] += val
            for j, coeff in transpose[i].items():
                nxt[j] += val * coeff
        flow = nxt
    assert list(occupied[i] for i in range(len(widths))) == widths
    print("FINITE RANK ONLY: 48 bins with integer t=1,2; H=7,d=5; terminal by depth:",
          " ".join(map(str, depths)), "; exact full occupation", sum(widths))


if __name__ == "__main__":
    print("Python", sys.version.split()[0], "Fraction exact; no external libraries.")
    print("Fixed s=0, U=2; true A_y gate retained in dy; B(q) preset from q-axis only.")
    print("Off-axis source and receiver boxes have positive width. Comparison B_y has common side 2.")
    first = stage("INITIAL", 2, F(3, 2),
                  ((("-7/8", "-5/8"), "2"), (("-1/8", "1/8"), "2"), (("5/8", "7/8"), "2")),
                  ((F(-5, 4), F(1, 32), F(1, 2), F(1, 32)),
                   (F(5, 4), F(1, 32), -F(1, 2), F(1, 8))))
    pressure = stage("TRUE-VOLUME PRESSURE", 2, F(3, 2),
                     ((("-47/64", "-1/2"), "3/2"), (("-1/8", "1/8"), "2"), (("1/2", "3/4"), "2")),
                     ((F(-5, 4), F(1, 32), F(3, 4), F(1, 8)),
                      (F(5, 4), F(1, 32), -F(3, 4), F(1, 32))))
    assert 0 < pressure[0] < pressure[2]
    stage("EXPANDED", 3, F(31, 16),
          ((("-31/32", "-7/8"), "2"), (("-1/16", "1/16"), "7/4"), (("7/8", "31/32"), "2")),
          ((F(-7, 4), F(1, 128), F(53, 64), F(1, 256)),
           (F(7, 4), F(1, 128), -F(53, 64), F(1, 32))))
    toy_rank()
