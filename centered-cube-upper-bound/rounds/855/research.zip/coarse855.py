"""Exact positive-width three-scale affine pushforwards; no complete ray law."""
from fractions import Fraction as F
from itertools import product
from math import prod
import sys

SIGMA = F(3, 2)
EPS = F(1, 4096)


def interval(c, width):
    return c - width / 2, c + width / 2


def box(n, c, first, transverse=None):
    width = first if transverse is None else transverse
    return (interval(c, first),) + (interval(F(0), width),) * (n - 1)


def length(i):
    return i[1] - i[0]


def volume(b):
    return prod(length(i) for i in b)


def moved(i, s, c=F(0)):
    x, y = (c + s * z for z in i)
    return min(x, y), max(x, y)


def clip(i, j):
    return max(i[0], j[0]), min(i[1], j[1])


def overlap(i, j):
    return max(F(0), length(clip(i, j)))


def smaller(b, slack):
    out = tuple((x + slack, z - slack) for x, z in b)
    assert all(length(i) > 0 for i in out)
    return out


def peaks(i, j):
    return tuple(a + b for a, b in product(i, j))


def density(i, j, x):
    return overlap(i, moved(j, -1, x)) / (length(i) * length(j))


def cdf(i, j, z):
    a, b = i
    c, d = j
    return (max(0, z - a - c) ** 2 - max(0, z - b - c) ** 2
            - max(0, z - a - d) ** 2 + max(0, z - b - d) ** 2) / (2 * length(i) * length(j))


def target_mass(i, j, target):
    result = cdf(i, j, target[1]) - cdf(i, j, target[0])
    # Independent direct integration of conditional-v lengths over the u interval.
    knots = sorted({*i} | {z - w for z, w in product(target, j) if i[0] < z - w < i[1]})
    widths = [overlap(j, moved(target, 1, -x)) for x in knots]
    direct = sum((b - a) * (u + v) / 2
                 for a, b, u, v in zip(knots, knots[1:], widths, widths[1:]))
    assert result == direct / (length(i) * length(j))
    assert 0 <= result <= 1
    return result


def coefficients(side):
    ui, uj, uk = side
    step1, step2 = uj / ui, uk / uj
    A, B = uk * (1 / ui - 1 / uj), uk / uj - 1
    assert A == step2 * (step1 - 1) and B == step2 - 1
    return step1, step2, A, B


def fibers(uboxes, vbox, mid, side, y):
    step1, step2, A, B = coefficients(side)
    v = tuple(moved(i, -B) for i in vbox)
    utot = sum(volume(b) for b in uboxes)
    data = []
    for u in uboxes:
        retained = tuple(clip(i, moved(z, -1 / (step1 - 1), step1 * a / (step1 - 1)))
                         for i, z, a in zip(u, mid, y))
        if any(length(i) <= 0 for i in retained):
            continue
        a = tuple(moved(i, -A, step1 * step2 * t) for i, t in zip(retained, y))
        data.append((volume(retained) / utot, a))
    return data, v


def mass(data, v, target):
    return sum((weight * prod(target_mass(i, j, cell) for i, j, cell in zip(a, v, target))
                for weight, a in data), F(0))


def peak(data, v):
    assert data
    # Clusters can differ in x1. Transverse intervals coincide, so the
    # univariate first-coordinate mixture maximum gives the exact joint maximum.
    a0 = data[0][1]
    assert all(a[1:] == a0[1:] for _, a in data)
    knots = {x for _, a in data for x in peaks(a[0], v[0])}
    first = max(sum(w * density(a[0], v[0], x) for w, a in data) for x in knots)
    others = prod(1 / max(length(a), length(b)) for a, b in zip(a0[1:], v[1:]))
    return first * others


def setup(case):
    n = (2, 2, 4)[case]
    side = (F(1), F(4, 3) if case < 2 else F(8, 5), F(2))
    si, _, a, b = coefficients(side)
    u0, v0 = F(3, 8), F(1, 4)
    z0, x0 = -(si - 1) * u0, -a * u0 - b * v0
    v = box(n, v0, F(1, 64) if case < 2 else F(1, 16))
    if case == 1:
        u = [box(n, u0 + shift, F(1, 16), F(1, 8)) for shift in (-F(15, 256), F(15, 256))]
        fixed = u0 - F(15, 256)
    else:
        u = [box(n, u0, F(1, 8))]
        fixed = u0 if case == 0 else u0 - F(1, 128)
    if case < 2:
        mid = box(n, z0, F(1, 16))
    else:
        mid = ((z0, z0 + (si - 1) / 64),) + box(n, F(0), F(1, 8))[1:]
        x0 += a / 128
    targets = [("central", box(n, x0, F(1, 64) if case < 2 else F(1, 256)))]
    if case == 1:
        targets.append(("shifted", box(n, x0 + F(15, 512), F(1, 64))))
    return n, side, u, v, mid, targets, (fixed,) + (F(0),) * (n - 1)


def check_geometry(n, side, u, v, mid, targets):
    step1, step2, a, b = coefficients(side)
    root = box(n, F(0), 2 * EPS)
    used = [root, mid, *(q for _, q in targets)]
    assert all(not overlap(l[0], r[0]) for i, l in enumerate(used) for r in used[i + 1:])
    source = [*u, v]
    assert all(not overlap(l[0], r[0]) for i, l in enumerate(source) for r in source[i + 1:])
    assert all(max(abs(z) for z in axis) + 1 < 4 for rec in used for axis in rec)
    for patch in u:
        for axis, vv in zip(patch, v):
            assert max(abs(x - t) for x, t in product(axis, (-EPS, EPS))) < side[0] / 2
            for y, u0, v0 in product((-EPS, EPS), axis, vv):
                z = step1 * y - (step1 - 1) * u0
                assert abs(v0 - z) < side[1] / 2
                assert step2 * z - (step2 - 1) * v0 == step1 * step2 * y - a * u0 - b * v0
    true_bins = [next(j for j in range(n + 1) if s ** n <= 2 ** j) for s in side]
    assert true_bins[0] < true_bins[1] < true_bins[2]
    return true_bins


def run(case):
    n, side, u, v, mid, targets, fixed = setup(case)
    true_bins = check_geometry(n, side, u, v, mid, targets)
    step1, step2, a, b = coefficients(side)
    y = (F(0),) * n
    data, scaled_v = fibers(u, v, mid, side, y)
    assert any(all(i[0] <= t <= i[1] for i, t in zip(ubox, fixed)) for ubox in u)
    assert all(i[0] < -(step1 - 1) * t < i[1] for i, t in zip(mid, fixed))
    kept = sum(w for w, _ in data)
    assert kept == (F(1, 8) if case == 2 else 1)
    point_peak = 1 / prod(length(i) for i in scaled_v)
    raw_peak = peak(data, scaled_v)
    if case == 1:
        _, _, first_u, first_v, first_mid, first_targets, _ = setup(0)
        assert sum(map(volume, u)) == sum(map(volume, first_u))
        assert v == first_v and mid == first_mid and targets[0] == first_targets[0]
    if case < 2:
        assert point_peak == 16384 and raw_peak == 256
    print(f"case {case + 1}: n={n}, U={side}, true bins={true_bins}, A={a}, B={b}, y=0")
    print("  true source masses for U,V:", SIGMA * sum(volume(bx) for bx in u), SIGMA * volume(v),
          "; intermediate acceptance on original U:", kept)
    print("  fixed-u density peak, integrated raw peak, conditioned-on-mid peak:",
          point_peak, raw_peak, raw_peak / kept)
    inner, _ = fibers(u, v, smaller(mid, step1 * EPS), side, y)
    for name, target in targets:
        raw = mass(data, scaled_v, target)
        uniform_lower = mass(inner, scaled_v, smaller(target, step1 * step2 * EPS))
        fixedmass = prod(overlap(i, moved(j, 1, -a * t)) / length(j)
                         for i, j, t in zip(target, scaled_v, fixed))
        assert raw >= uniform_lower
        if case == 1 and name == "central":
            # Elementary exact zero, even allowing every y in the root.
            enlarged = tuple((x - step1 * step2 * EPS, z + step1 * step2 * EPS) for x, z in target)
            assert raw == 0 and mass(data, scaled_v, enlarged) == 0 and kept == 1
        else:
            assert uniform_lower > 0
            if case < 2:
                assert raw == F(1, 16)
        print("  actual target", name,
              "fixed-u / original two-step / conditional-on-mid / uniform-in-y lower:",
              fixedmass, raw, raw / kept, uniform_lower)


if __name__ == "__main__":
    print("Python", sys.version.split()[0], "Fraction exact; no stochastic sampling.")
    print("True positive-width sources (constant-density sigma cuts) and disjoint receiver cores.")
    print("Original probability divides by the full two source masses, including lost mid mass.")
    print("Geometry and affine pushforward certificate only; no full P_ray or history gates.")
    for i in range(3):
        run(i)
