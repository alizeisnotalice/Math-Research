"""R855: certified separated-shell gain and marked affine posterior on true rows."""

from fractions import Fraction as F
from math import isqrt
import sys

from flint import arb, ctx, __version__ as flint_version


def aq(x):
    x=F(x)
    return arb(x.numerator)/x.denominator


def gain(n,g,prec):
    ctx.prec=prec
    t=arb(2).log()*g/n
    r=t.exp()
    direct=n*(2*t-(2*r-1).log())
    positive_form=n*(1+(r-1)**2/(2*r-1)).log()
    assert direct.overlaps(positive_form)
    # ln(1+x)>=x/(1+x) for x>=0, so log gain/n >= (1-1/r)^2.
    # Concavity gives 1-exp(-t)>= t/(2 ln2) for 0<=t<=ln2.
    assert direct>arb(g*g)/(4*n)
    return direct


def gains():
    max_n=16384
    print("Natural-log gain L=(r^2/(2r-1))^n, r=2^(g/n); interval bounds at 384 bits.")
    print("All feasible cells independently verified at 192 and 384 bits; g^2/(4n) is a strict lower bound.")
    tested=0
    n=64
    while n<=max_n:
        b=isqrt(n-1)+1
        trials=(b,2*b,b*(n.bit_length()-1))
        row=[]
        for g in trials:
            # Two steps of this size are required to fit in one [1,2] window.
            if 2*g>n:
                row.append("outside window")
                continue
            low=gain(n,g,192)
            high=gain(n,g,384)
            assert low.overlaps(high)
            row.append(high.str(11))
            tested+=1
        print(" ", n, "g=(b,2b,b log2 n)",trials,":",*row)
        n*=2
    assert tested==25


def root_two_bounds(n):
    denominator=2**24
    lower,upper=denominator,2*denominator
    target=2*denominator**n
    while upper-lower>1:
        middle=(lower+upper)//2
        if middle**n<=target:
            lower=middle
        else:
            upper=middle
    lo,hi=F(lower,denominator),F(upper,denominator)
    assert lo**n<2<hi**n
    return lo,hi


def physical(n):
    # Genuine receiving cores with rational centres and fixed rational
    # actual sides. The reverse comparison scales are U_0=1,U_1=r,U_2=r^2.
    # Terminal y varies over a positive cube; all images remain inside
    # the displayed actual cores for every true pair of source points.
    ey,h = F(1,2048),F(1,1024)
    hv=h/n
    u0,v0=F(3,8),F(1,4)
    lo,hi=root_two_bounds(n)
    assert 2*h < u0-v0-hv
    zrange=(-(hi-1)*u0,-(lo-1)*u0)
    xrange=(-(hi-1)*(hi*u0+v0),-(lo-1)*(lo*u0+v0))
    zcenter=sum(zrange)/2
    xcenter=sum(xrange)/2
    midhalf=F(1,128)
    assert (zrange[1]-zrange[0])/2+hi*ey+(hi-1)*h<midhalf
    assert (xrange[1]-xrange[0])/2+hi**2*ey+hi*(hi-1)*h+(hi-1)*hv<midhalf
    assert xcenter+2*midhalf<zcenter and zcenter+midhalf<-ey
    sides=(F(1),F(4,3) if n==2 else F(5,4),F(3,2))
    D=(1,2,4)
    vs=tuple(l**n for l in sides)
    for v,d in zip(vs,D):
        assert F(d,2)<v<=d
    for center,half,l in zip((F(0),zcenter,xcenter),(ey,midhalf,midhalf),sides):
        assert l<=2 and abs(center)+half+1<4
        assert abs(center-u0)+half+h<l/2 and abs(center-v0)+half+hv<l/2
    # sigma = 3/2 on [-4,4]^n, eta is the cut to the pair of actual
    # uniform source packets. All real window maxima on these cores are 3/2.
    mu=F(3,2)*(2*h)**n
    mv=F(3,2)*(2*hv)**n
    row=F(D[1]*D[2])*mu*mv/(vs[1]*vs[2])**2
    assert row>0 and mu==mv*n**n

    # Write x=r^2*y-r(r-1)*u-(r-1)*v. Measured from the upper
    # receiving face and divided by the u-width, its coordinates have
    # the exact law Xi+tau*Yi, Xi,Yi independent Unif[0,1].
    # Marks low/low and high/high each carry 4^(-n) of the same original
    # row. For the projection cell [0,tau/2]^n only low/low can enter.
    r=arb(2)**(arb(1)/n)
    assert aq(lo)<r<aq(hi)
    tau=1/(n*r)
    actual=(tau/8)**n
    uniform=(tau/(2*(1+tau)))**n
    low_cond=(tau/2)**n
    both_marks=F(1,4)**n
    assert 0<tau<1 and 0<actual<uniform<1
    assert (actual/aq(both_marks)).overlaps(low_cond)
    # r^n=2 gives these projection powers as exact rationals.
    frac=F(1,2*(8*n)**n)
    assert actual.overlaps(aq(frac)) and low_cond.overlaps(aq(F(1,2*(2*n)**n)))
    print("True box dimension",n,"bins (0,1,2), rational witness sides",sides,
          "; two directed original row factors D_i/v_i^2.")
    print("  Raw marked-eligible row before half-packet flags",aq(row).str(10),
          "; equal low/low and high/high masses",aq(row*both_marks).str(10))
    print("  Small receiving cell: exact actual raw projection fraction",frac,
          "; Lebesgue-uniform receiving-hull fraction",uniform.str(10))
    print("  Same raw cell under low/low mark", (aq(row)*actual).str(10),
          "; high/high mark 0; conditional low/low",low_cond.str(10))


def posterior_moments():
    ctx.prec=192
    print("Posterior Xi+tau*Yi: plateau density 1 plus two linear ramps of width tau.")
    print("Integral p^(1-a): 1-tau+2*tau/(2-a) with a<2; product uses independent coordinates.")
    for n in (1,2,3,20,64,256,16384):
        tau=F(1,n)
        moments=[]
        for a in (F(1,2),F(1),F(3,2)):
            single=1-tau+2*tau/(2-a)
            exact=1+tau*a/(2-a)
            assert single==exact and 1<exact<=4
            value=aq(exact)**n
            assert 1<value<aq(a/(2-a)).exp()
            moments.append(value.str(10))
        print(" ",n,"tau=1/n; moments at a=1/2,1,3/2:",*moments)


if __name__=="__main__":
    print("Python",sys.version.split()[0],"python-flint",flint_version,"| Fraction plus Arb")
    gains()
    for dim in (2,3):
        physical(dim)
    posterior_moments()
    print("All assertions passed. True boxes give local marked projections; the high-n gain is geometric.")
