"""Exact affine coordinates and reciprocal whole-row overlap on true boxes."""
from fractions import Fraction as F
from math import isqrt
from sys import version

import sympy

LAMBDA = F(1)
SIGMA = F(3, 2)
E = F(1, 4096)
U0, V0, THETA0 = F(-1, 8), F(1, 8), F(1, 8)


def dyadic_root(n, j, digits=18):
    scale = 2 ** digits
    target = 2 ** (j + n * digits)
    a, b = scale, 2 * scale + 1
    while b > a + 1:
        mid = (a + b) // 2
        if mid ** n <= target:
            a = mid
        else:
            b = mid
    assert a ** n <= target < b ** n
    return F(a, scale), F(b, scale)


def symbolic():
    ui, uj, uk = sympy.symbols("U_i U_j U_k", positive=True)
    y, u, v = sympy.symbols("y u v")
    z = (uj / ui) * y - (uj / ui - 1) * u
    x = (uk / uj) * z - (uk / uj - 1) * v
    a = uk * (1 / ui - 1 / uj)
    b = uk / uj - 1
    assert sympy.simplify(x - ((uk / ui) * y - a * u - b * v)) == 0
    assert sympy.simplify((z - v) / uj - (x - v) / uk) == 0
    print("SymPy", sympy.__version__, "exact two-hop identity and fixed-v invariant theta.")


def ranks(n, j, k, uj, uk):
    boxes = ((1 / (4 * uj[1]), 1 / (4 * uj[0])),
             tuple(V0 + a * THETA0 for a in uj),
             tuple(V0 + a * THETA0 for a in uk))
    # Nominal centers are bracket midpoints. Actual rays for all
    # u,v and theta in their E-halfwidth boxes are uniformly inside.
    origins = [(a + b) / 2 for a, b in boxes]
    assert all(4 * E + (b - a) / 2 < 8 * E for a, b in boxes)
    assert all(a + 16 * E < b for a, b in zip(origins, origins[1:]))
    real_side = (F(1), uj[0], dyadic_root(n, k - 1)[1])
    for q, side, center in zip((0, j, k), real_side, origins):
        assert F(2) ** (q - 1) < side ** n <= 2 ** q
        assert max(abs(center - u) for u in (U0, V0)) + 9 * E < side / 2
        assert abs(center) + 8 * E + 1 < 4
    # dx=U^n dtheta in each of the two actual section boxes.
    theta_mass = (2 * E) ** n
    assert all(2 ** q * theta_mass < (16 * E) ** n for q in (0, j, k))
    return real_side, theta_mass


def outward(lo, hi=None, digits=8):
    hi = lo if hi is None else hi
    scale = 10 ** digits
    lq, uq = lo * scale, hi * scale
    a = lq.numerator // lq.denominator
    b = -(-uq.numerator // uq.denominator)
    return f"[{a//scale}.{a%scale:0{digits}d},{b//scale}.{b%scale:0{digits}d}]"


def check(n, j, k):
    d = k - j
    b = 1 + isqrt(n - 1)
    assert j >= b + 1 and d >= b + 1
    uj, uk = dyadic_root(n, j), dyadic_root(n, k)
    ell, theta_mass = ranks(n, j, k, uj, uk)
    # Actual partner mass from one disjoint sigma-cut and the true row g.
    # It is constant over v and over all receiver cells in the section.
    packet = SIGMA * (2 * E) ** n
    mz, mx = F(3, 4) * packet, F(1, 2) * packet
    Dz, Dx = 2 ** j, 2 ** k
    vz, vx = ell[1] ** n, ell[2] ** n
    T0 = packet / LAMBDA
    Tj = Dz * mz / (LAMBDA * vz ** 2)
    Tk = Dx * mx / (LAMBDA * vx ** 2)
    assert 0 < Tk < Tj
    Ij, Ik = (T0, T0 + Tj), (T0 + Tj, T0 + Tj + Tk)
    H = Tk / 2
    L = min(Ij[1] + H, Ik[1]) - max(Ij[0] + H, Ik[0])
    assert L == Tk / 2 > 0
    p_plus, p_minus = L / Tj, L / Tk
    assert 0 < p_plus < p_minus == F(1, 2)
    # Both use the true same-v and theta sections, and the same rank overlap.
    assert (p_plus * Tj * theta_mass * packet
            == p_minus * Tk * theta_mass * packet == L * theta_mass * packet)
    actual = (p_plus / mx) / (p_minus / mz)
    assert actual == F(Dx, Dz) * (vz / vx) ** 2 <= 4 * F(Dz, Dx)
    # Exact endpoints for A and h/A, using monotonicity on r>=1.
    a0 = uk[0] * (1 - 1 / uj[0])
    a1 = uk[1] * (1 - 1 / uj[1])
    h = F(1, 8 * n)
    lo, hi = h / a1, h / a0
    assert 0 < lo <= hi <= F(b, 2 * n)
    # Separate general Bernoulli/log slope check: log2>=1/2 gives
    # A >= 2^((b+1)/n)-1 >= (b+1)/(2n).
    assert F(1, 4 * (b + 1)) <= F(b, 2 * n)
    print(f"n={n}, bins=0,{j},{k}, b={b}, gap={d}; actual z,x side {ell[1]},{ell[2]}")
    print("  m_z/packet,m_x/packet: 3/4,1/2; L/T_k=1/2; (L/T_j)*2^gap:", outward(p_plus * 2 ** d))
    print("  reciprocal ratio * 2^gap:", outward(actual * 2 ** d),
          "; (4p-/m_z)/(p+/m_x) divided by 2^gap:", outward(4 / (actual * 2 ** d)))
    print("  common theta pushforward masses agree; h/A in", outward(lo, hi), "≤", F(b, 2 * n))


if __name__ == "__main__":
    print("Python", version.split()[0], "Fraction exact; decimal intervals outward.")
    print("True positive-width sigma cuts, sigma=3/2 on [-4,4]^n and lambda=1.")
    print("Finite local-rank overlap H=T_k/2. This verifies the local section, not a complete R854 history.")
    symbolic()
    for args in ((16, 6, 12), (64, 18, 63), (256, 72, 230)):
        check(*args)
