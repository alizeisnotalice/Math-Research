"""R855: face/depth signatures and three moving-cube gates on true sources."""

from argparse import ArgumentParser
from fractions import Fraction as F
from hashlib import sha256
from itertools import product
from pathlib import Path
from zipfile import ZipFile
import sys

from flint import arb, ctx, __version__ as flint_version


PIN = "c6ff24f72b21a798e295b3bb365b9401c4aa1caf71f9a2ae9ef0683d42aae2ca"


def archived_model(path):
    assert sha256(path.read_bytes()).hexdigest()==PIN
    with ZipFile(path) as archive:
        script=archive.read("rays854.py")
    env={"__name__":"rays854_face_reference","__file__":"rays854.py"}
    exec(compile(script,"rays854.py","exec"),env)
    return env


def qarb(x):
    x=F(x)
    return arb(x.numerator)/x.denominator


def sig(x):
    face=int(x>F(1,2))
    d=min(x,1-x)
    if d==0:
        return face,0
    k=1
    while d<=F(1,2)**(k+1):
        k+=1
    return face,k


def accepts(s,z,c):
    return (1-c)*s <= z <= (1-c)*s+c


def clipped_area(constraints):
    polygon=[(F(0),F(0)),(F(1),F(0)),(F(1),F(1)),(F(0),F(1))]
    for a,b,c in constraints:
        next_poly=[]
        for p,q in zip(polygon,polygon[1:]+polygon[:1]):
            fp=a*p[0]+b*p[1]+c
            fq=a*q[0]+b*q[1]+c
            if fp>=0:
                next_poly.append(p)
            if (fp>=0)!=(fq>=0):
                t=fp/(fp-fq)
                next_poly.append(tuple(x+t*(y-x) for x,y in zip(p,q)))
        polygon=next_poly
    return abs(sum(p[0]*q[1]-p[1]*q[0]
                   for p,q in zip(polygon,polygon[1:]+polygon[:1])))/2


def one_axis_checks():
    # Mutual inclusion equivalently requires min >= (1-c)*max for
    # each of the two distances to a face. A matching dyadic bucket
    # gives this at the nearer face, and the farther depth is >=1/2.
    points=tuple(F(j,64) for j in range(65))
    count=0
    for c in (F(1,2),F(2,3),F(3,4),F(9,10)):
        t=1-c
        one=((-t,F(1),F(0)),(t,F(-1),c))
        both=one+((F(1),-t,F(0)),(F(-1),t,c))
        assert clipped_area(one)==c
        assert clipped_area(both)==c/(2-c)
        for s,z in product(points,repeat=2):
            if sig(s)==sig(z):
                assert accepts(s,z,c) and accepts(z,s,c)
                count+=1
    # With two independent uniform depths per coordinate, the sum of
    # squares of lengths of the dyadic intervals at both faces is 1/6.
    assert 2*F(1,16)/(1-F(1,4))==F(1,6)
    print("1D exact polygon ratios confirmed at four c; finite signature hits checked:",count)
    print("  Uniform independent points: fixed-anchor c, mutual c/(2-c), identical sign+bucket 1/6 per axis.")


def whole_packet_hits(U,c,theta,eps,h,s,z):
    # Actual source centres lie at (0,s,0,..) and (0,z,0,..);
    # the receiver centre lies within U*eps of U*theta*e_1.
    e=qarb(h)+(1-c)*qarb(h)+c*U*qarb(eps)
    radius=c*U/2
    corners=(c*U*qarb(theta),abs(qarb(z)-(1-c)*qarb(s)),arb(0))
    if all(d+e<radius for d in corners):
        return True
    assert any(d-e>radius for d in corners)
    return False


def archive_replay(n,env):
    env["certify_geometry"](n,"common")
    eps,h=env["EPS"],env["SOURCE_HALF"]
    A,B,P=env["A_MASS"],env["B_MASSES"],env["PARTNER"]
    theta=env["LAYOUTS"]["common"][1]
    assert theta==F(1,4) and env["LAYOUTS"]["common"][2]==theta
    assert h==eps/2
    g=n//2
    c_gap=1/arb(2).sqrt()
    D=(2**g,2**n)
    U=(arb(2).sqrt(),arb(2))
    c_min=tuple(1/u for u in U)
    assert c_min[0].overlaps(c_gap) and c_min[1]==qarb(F(1,2))
    before=minimum=dynamic=mutual=F(0)
    sig_mass=arb(0)
    edge_profiles=[]
    for slot,u,d,c0 in zip((1,2),U,D,c_min):
        d_variation=qarb(eps)+qarb(h)/u
        # Coordinate 1 crosses just the depth boundary 1/4; other
        # non-2 coordinates cross just the sign at the receiver.
        assert qarb(theta)-d_variation>qarb(F(1,8))
        assert qarb(theta)+d_variation<qarb(F(1,2))
        assert d_variation<qarb(F(1,4))
        keep=[]
        for j in range(slot+1):
            z=P[j]
            f0=whole_packet_hits(u,c0,theta,eps,h,F(0),z)
            r0=whole_packet_hits(u,c0,theta,eps,h,z,F(0))
            f1=whole_packet_hits(u,c_gap,theta,eps,h,F(0),z)
            r1=whole_packet_hits(u,c_gap,theta,eps,h,z,F(0))
            assert (f0,r0,f1,r1)==(j==0,True,j==0 or (slot==2 and j==1),True)
            keep.append((f0,r0,f1,r1))
            w=B[j]/d
            before+=w
            minimum+=w*F(f0+r0,2)
            dynamic+=w*F(f1+r1,2)
            mutual+=w*int(f1 and r1)

            # Axis 2: B0 has positive-face sign and depth (1/4,1/2];
            # it agrees with A's sign with probability 1/2. Other B
            # packets use a depth below 1/4, so agreement is impossible.
            depth=qarb(F(1,2))-qarb(z)/u
            assert depth-d_variation>0
            if j==0:
                assert depth-d_variation>qarb(F(1,4))
                assert depth+d_variation<qarb(F(1,2))
                # In the first axis and every axis except the second,
                # signs or buckets disagree only when the receiver
                # coordinate lies between sources. Given receiver y
                # in the source's coordinate interval, its mean is 1/3.
                # That interval has receiver probability h/(u*eps).
                sig_mass += qarb(w/2)*(1-1/(6*u))**(n-1)
            else:
                assert depth+d_variation<qarb(F(1,4))
        edge_profiles.append(tuple(keep))

    assert 0<mutual<minimum<dynamic<before
    assert (dynamic-minimum)/before==F(1,3*2**g+7)
    assert 0<sig_mass<qarb(mutual)
    raw=A*(2*eps)**n*before
    print("n",n,"true R854-config bins",(g,n),"; gap",g,
          "; marked raw",qarb(raw).str(10))
    print("  Fractions of the SAME true raw mass:",
          *(qarb(v/before).str(10) for v in (minimum,dynamic,mutual)),
          "; extra simultaneous sign+depth:",(sig_mass/qarb(before)).str(10))
    print("  Actual paid masses / three levels:",
          *(qarb(raw*v/before).str(10) for v in (minimum,dynamic,mutual)),
          "; signature", (qarb(raw/before)*sig_mass).str(10))
    print("  Per-original-mass gain dynamic over minimum:",F(1,3*2**g+7))
    if n==16:
        print("  Ordered partner profiles by bin (min fwd/rev, gap fwd/rev):",edge_profiles)


def stress(n):
    # In this separate true uniform input take eta=sigma=3/2 on a
    # large box, B=A_y of side 2. Conditioned on any y in the small
    # receiving core, both original source coordinates are independent
    # uniform in B; the three gates are product measures here.
    c=1/arb(2).sqrt()
    ratio=c/(2-c)
    signed=1/arb(6)
    assert signed<ratio<c
    log2=arb(2).log()
    vals=(c,ratio,signed,signed/ratio)
    print("n",n,"uniform tensor log2(one-way,mutual,same signature,signature/mutual):",
          *( (n*v.log()/log2).str(10) for v in vals))

    # Actual separate packets with uniform density 3/2. Cubical parent
    # side 2, centre in a real core of halfside e_y. Normalized source
    # positions for all axes lie close to these fixed values.
    e_y,e_s=F(1,2048),F(1,512)
    spread=(e_y+e_s)/2
    opposite=(F(1,4),F(3,4))
    depth_mismatch=(F(7,32),F(9,32))
    for s,z in (opposite,depth_mismatch):
        assert 0<s-spread<z+spread<1 and z-s>2*spread
    s,z=opposite
    assert s+spread<F(1,2)<z-spread
    # At gap c=1/sqrt2 both near-side ratios hold; at c=1/2
    # the left inequality already fails uniformly. Reflected right
    # failure gives zero even one-way in either orientation at c=1/2.
    assert c>qarb(F(7,10))
    assert s-spread>F(3,10)*(z+spread)
    assert 1-z-spread>F(3,10)*(1-s+spread)
    assert z-spread>F(1,2)*(s+spread)+F(1,2)
    assert s+spread<F(1,2)*(z-spread)
    s,z=depth_mismatch
    assert s+spread<F(1,4)<z-spread<z+spread<F(1,2)
    assert s-spread>F(1,2)*(z+spread)
    assert 1-z-spread>F(1,2)*(1-s+spread)
    # For both pairs, the physical raw marked mass has the same
    # constant density and volume on the actual independent packets.
    raw=F(9,4)*((2*e_y)*(2*e_s)**2/4)**n
    assert raw==F(9,4)*F(1,2)**(28*n)
    print("  True opposite-face packets: minimal c=1/2 gives 0; gap/mutual give 1; signature 0.")
    print("  True same-face different-depth packets: even mutual at c=1/2 gives 1; signature 0.")
    print("  Original true ordered marked mass of each separate example: (9/4)*2^(-"+str(28*n)+").")


if __name__=="__main__":
    p=ArgumentParser()
    p.add_argument("--handoff",type=Path,required=True)
    args=p.parse_args()
    ctx.prec=192
    print("Python",sys.version.split()[0],"python-flint",flint_version,"| exact Fraction and 192-bit Arb")
    print("Pinned R854 ZIP",PIN)
    one_axis_checks()
    data=archived_model(args.handoff)
    print("Comparable raw order: fixed minimum physical side 1 (fair actual anchor role),")
    print("gap shrink with the same fair role, then mutual on that same gap shrink.")
    for n in (16,20,64,128,256):
        archive_replay(n,data)
    for n in (20,64,128,256):
        stress(n)
    print("All passed. Original marked rows and independent tensor comparison reported separately.")
