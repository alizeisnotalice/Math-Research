"""R855: two-end Whitney cells, true receiver menus, and original-mass budgets."""

from decimal import Decimal, localcontext
from fractions import Fraction as F
from itertools import product
import sys


DEPTH = (F(3,16),F(27,128))
LABEL_MID = F(1,2)-sum(DEPTH)/2
THETA_POS = (F(1,2)-DEPTH[1],F(1,2)-DEPTH[0])
THETA_NEG = (-THETA_POS[1],-THETA_POS[0])
ROOT_HALF = F(1,256)
SOURCE_HALF = F(1,8192)
CHILD_HALF = F(1,16384)
CHILD_STEP = F(1,512)


def normalized_round(value):
    with localcontext() as ctx:
        ctx.prec=10
        return str(Decimal(value.numerator)/Decimal(value.denominator))


def check_whitney():
    ratio=DEPTH[1]/DEPTH[0]
    assert ratio==F(9,8)
    # Both distances to faces have ratios <=9/8. The nearer distance
    # is in DEPTH, while the farther absolute change is the same and
    # the farther minimum is >=1/2. Testing the affine endpoint
    # inequalities in theta_p,theta_c,r certifies the whole product.
    for C in (THETA_POS,THETA_NEG):
        for p,c,r in product(C,C,(F(0),1/ratio)):
            assert abs(p-r*c)<=(1-r)/2
    assert THETA_POS[0]<LABEL_MID<THETA_POS[1]
    sharp=1/ratio
    assert THETA_POS[1]-sharp*THETA_POS[0]==(1-sharp)/2
    larger=F(9,10)
    assert THETA_POS[1]-larger*THETA_POS[0]>(1-larger)/2
    print("True Whitney sign cells, near depths [3/16,27/128], ratio 9/8.")
    print("All affine endpoint inequalities tested through r=8/9; n-dimensional boxes are products.")


def lower_bin_side(n):
    d=2**24
    target=F(33,64)*d**n
    lo,hi=d//2,d
    while hi-lo>1:
        m=(hi+lo)//2
        if m**n<target:
            lo=m
        else:
            hi=m
    c=F(hi,d)
    assert F(1,2)<c**n<F(17,32)
    return 2*c


def geometry(n):
    U=F(2)
    root_sources=(-U*LABEL_MID,U*LABEL_MID)
    private_sources=(F(-1,4),F(1,4))
    u=lower_bin_side(n)
    assert 2**(n-1)<u**n<2**n
    near=tuple(sorted(root_sources+private_sources))
    assert all(b-a>2*SOURCE_HALF for a,b in zip(near,near[1:]))
    assert max(map(abs,near))+ROOT_HALF+SOURCE_HALF<u/2
    assert ROOT_HALF+1<4
    labels=(THETA_POS,THETA_NEG)
    all_child=[]
    branch_probs=[]
    for side,(s,p,C,t) in enumerate(zip(root_sources,private_sources,labels,(LABEL_MID,-LABEL_MID))):
        old_other=root_sources[1-side]
        assert C[0]<(-ROOT_HALF-s-SOURCE_HALF)/U
        assert (ROOT_HALF-s+SOURCE_HALF)/U<C[1]
        c_mid=s+t
        widths=((3 if side==0 else 2)*CHILD_HALF,CHILD_HALF)
        volume=[]
        for j,(shift,h) in enumerate(zip((-CHILD_STEP,CHILD_STEP),widths)):
            extent=abs(shift)+max(h,CHILD_HALF)
            center=c_mid+shift
            assert t-extent-SOURCE_HALF>C[0]
            assert t+extent+SOURCE_HALF<C[1]
            assert max(abs(c_mid-s),abs(c_mid-p))+extent+SOURCE_HALF<F(1,2)
            assert abs(c_mid-old_other)-extent-SOURCE_HALF>F(1,2)
            assert max(abs(c_mid),abs(center))+h+1<4
            all_child.append((center-h,center+h))
            volume.append(2*h*(2*CHILD_HALF)**(n-1))
        branch_probs.append(tuple(v/sum(volume) for v in volume))
    intervals=sorted(all_child+[(-ROOT_HALF,ROOT_HALF)])
    assert all(a[1]<b[0] for a,b in zip(intervals,intervals[1:]))
    assert branch_probs==[(F(3,4),F(1,4)),(F(2,3),F(1,3))]
    # Original sigma=3/2 on [-4,4]^n; eta is its cut to the four
    # displayed packets, each of mass m. Every real core has window
    # maximal height 3/2. Child-side l=1 witnesses use their preserved
    # and private endpoints; root-side witnesses use the real s,q pair.
    m=F(3,2)*(2*SOURCE_HALF)**n
    raw_unit=(2*ROOT_HALF)**n*m*m/F(2)**(2*n)
    correction=(U/u)**(2*n)
    assert 1<correction<4
    return raw_unit,correction,branch_probs


def menu_distribution(branch):
    # Each turn uses fresh independent child outcomes in their actual
    # raw conditional receiving laws. Labels can be read by either test.
    p=tuple((a,b,branch[0][a]*branch[1][b]) for a,b in product(range(2),repeat=2))
    out=[]
    for turn in range(3):
        if turn==0:
            choices=(int(a!=b) for a,b,_ in p)
        elif turn==1:
            choices=(int(a==b) for a,b,_ in p)
        else:
            choices=(int(a!=0 or b!=0) for a,b,_ in p)
        mass=[F(0),F(0)]
        for tile,(_,_,w) in zip(choices,p):
            mass[tile]+=w
        assert sum(mass)==1
        out.append(tuple(mass))
    assert tuple(v[0] for v in out)==(F(7,12),F(5,12),F(1,2))
    return tuple(out)


def replay(n,alpha):
    raw,correction,branch=geometry(n)
    assert 0<alpha<F(1,2)
    # Split true E_n (a single physical cube) on axis 1 into two
    # adjacent labelled tiles, each alpha of the volume, and the
    # complementary slab. Only tile 0 uses the smaller actual witness.
    # G=1 there and alpha^2 on the others, with fixed original pair s,q.
    areas=(alpha,alpha,1-2*alpha)
    assert sum(areas)==1
    I=1-alpha+alpha*correction
    G=(F(1),alpha**2,alpha**2)
    root=tuple(a*v*g for a,v,g in zip(areas,(correction,F(1),F(1)),G))
    R=sum(root)
    assert all(x>0 for x in root)
    assert I>=1 and R<=I
    # The four actual outcome probabilities factor for each physical
    # root tile. Every combined label leaves the same conditional
    # root distribution, including the G concentration.
    for tile,weight in enumerate(root):
        for a,b in product(range(2),repeat=2):
            lab=branch[0][a]*branch[1][b]
            assert weight*lab/(R*lab)==root[tile]/R

    menus=menu_distribution(branch)
    mixing=(F(1,2),F(1,3),F(1,6))
    mixed=tuple(sum(m[p]*w for m,w in zip(menus,mixing)) for p in range(2))
    assert mixed==(F(37,72),F(35,72))
    for tile in (0,1):
        assert root[tile]<=4*alpha*I
    one=sum(p*w for p,w in zip(menus[0],root))
    mix=sum(p*w for p,w in zip(mixed,root))
    assert 0<one<=4*alpha*I and 0<mix<=4*alpha*I and mix/R>F(1,2)

    # Enumerate the actual joint menu choices from three turns.
    # Every realization counts each distinct physical receiving tile once.
    union=F(0)
    expected_area=F(0)
    naive=F(0)
    for indices in product(range(2),repeat=3):
        prob=menus[0][indices[0]]*menus[1][indices[1]]*menus[2][indices[2]]
        selected=set(indices)
        gate=sum(root[t] for t in selected)
        area=alpha*len(selected)
        assert gate<=4*area*I
        union+=prob*gate
        expected_area+=prob*area
        naive+=prob*sum(root[t] for t in indices)
    assert expected_area==F(253,144)*alpha<3*alpha
    assert union==F(253,288)*(root[0]+root[1])
    assert one<union<naive and union<=4*expected_area*I
    # Repeating any already determined menu tile has exactly the same
    # geometric union as selecting it once.
    assert sum(root[t] for t in {0,0,0})==root[0]

    print("n",n,"real parent bin",n,"and child bin 0; alpha",alpha,
          "; small-tile D^2/v^2",normalized_round(correction))
    print("  All true parent/child cores fit same two fixed sign-depth cells, with child exclusion of other root end.")
    print("  One turn and mixed-turn probabilities under G row:",
          normalized_round(one/R),normalized_round(mix/R),
          "; original mix/I",normalized_round(mix/I),
          "; same original threshold 4alpha",normalized_round(4*alpha))
    print("  Three-turn union/I and duplicate-counted/I:",
          normalized_round(union/I),normalized_round(naive/I),
          "; true expected union area/area(Y)",expected_area)
    print("  Actual original gated mixed mass",normalized_round(raw*mix),
          "; actual anchored original I",normalized_round(raw*I))


if __name__=="__main__":
    print("Python",sys.version.split()[0],"| exact Fraction, physical box geometry and original weights.")
    check_whitney()
    print("Both arm labels are true disjoint child receiving cores with probabilities (3/4,1/4),(2/3,1/3).")
    print("Conditionally on fixed s,q the geometric label test depends on both labels and relative cell, uniformly in root y.")
    print("Scope: local independent sampling of true child rows, with geometry certified for each root tile.")
    for n,exponent in ((4,4),(16,8),(64,32),(256,64)):
        replay(n,F(1,2**exponent))
    print("All rational assertions passed.")
