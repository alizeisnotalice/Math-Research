from fractions import Fraction as F
from itertools import product

def interval(c,r): return (c-r/2,c+r/2)
def length_inter(*xs): return max(F(0),min(x[1] for x in xs)-max(x[0] for x in xs))
def far_area(x,z,d):
    def above(x,z):
        a,b=x;c,e=z;p=lambda t:max(F(0),t)**2
        return (p(e-a-d)-p(e-b-d)-p(c-a-d)+p(c-b-d))/2
    return above(x,z)+above(z,x)
counts={'matched_mass_identity':0,'gated_swap':0,'signed_credit':0}
for ac,wc,tc in product((F(-1,4),F(0),F(1,4)),(F(-1),F(-1,2),F(0),F(1,2),F(1)),(F(-1),F(-1,2),F(0),F(1,2),F(1))):
    A=interval(ac,F(2)); w=interval(wc,F(1));t=interval(tc,F(1))
    iw=length_inter(A,w);it=length_inter(A,t);c=length_inter(A,w,t)
    x=iw-c;y=it-c;j=length_inter(w,t)
    assert x*y==iw*it-c*(iw+it)+c*c
    assert 0<=x<=1-j and 0<=y<=1-j
    assert x+y+c<=2
    counts['matched_mass_identity']+=1
for ac,weights,d in product((F(-1,4),F(0),F(1,4)),((F(1,4),F(1,3),F(1,5)),(F(1,7),F(1,2),F(1,6)),(F(1,10),F(1,10),F(1,10))),(F(0),F(1,8),F(1,2),F(1))):
    A=interval(ac,F(2)); ws=[interval(c,F(1)) for c in (F(-1,2),F(0),F(1,2))]
    edges=sorted(set([A[0],A[1]]+[p for w in ws for p in w if A[0]<p<A[1]]))
    cells=list(zip(edges,edges[1:])); masks=[]
    for x in cells:
        mid=sum(x)/2;masks.append(tuple(int(w[0]<=mid<=w[1]) for w in ws))
    prodmoment=exclusive=credit=common=F(0)
    zmax=max(sum(a*b for a,b in zip(weights,mask)) for mask in masks)
    for i,x in enumerate(cells):
      for j,z in enumerate(cells):
        area=far_area(x,z,d)/4
        zy=sum(a*b for a,b in zip(weights,masks[i]));zz=sum(a*b for a,b in zip(weights,masks[j]))
        c=sum(weights[k]*masks[i][k]*masks[j][k] for k in range(3))
        prodmoment+=area*zy*zz;exclusive+=area*(zy-c)*(zz-c)
        credit+=area*c*(zy+zz-c);common+=area*c
    swapped=F(0)
    for w,t in product(range(3),repeat=2):
        mass=sum(far_area(x,z,d) for i,x in enumerate(cells) for j,z in enumerate(cells) if masks[i][w] and not masks[i][t] and masks[j][t] and not masks[j][w])
        swapped+=weights[w]*weights[t]*mass/4
    assert swapped==exclusive
    counts['gated_swap']+=1
    assert prodmoment-exclusive==credit and 0<=credit<=2*zmax*common
    counts['signed_credit']+=1
print('PASS',counts,'total',sum(counts.values()))
