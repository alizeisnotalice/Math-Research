# R405 independent audit — FINAL PASS (bounded scope; no new payment)

FINAL PASS for the stated identities, exact comparisons, bounded failed-candidate analysis, numerical scopes, and unchanged R404 ledger. No general far-source budget or root-order closure is certified. Only this file was edited. The independent prefilter below was completed before reading the R405 author arguments; the later full post-review and final byte bindings complete this audit.

## Entering contract

Freeze the complete R404 mother-field ledger. R404 is the original two-end R400 soft remainder restricted to the source event

    F(y,z)={||y-z||infinity>a(exp(1/sqrt(n))-1)/2,
            ||y-z||1>a/8}.

There are NO inherited near-only shared/disjoint failure, inner/collar or count restrictions on this far measure. Full f, actual du, m_A=f(Q_A)=q_A R_A^n, q-band, K=exp(sqrt(n)), h, all original clock/high-rank/current-source marks, nested stages and the external old-y-conditioned E_uv/Z_u remain frozen. An exclusive witness is not an original history-qualified receiver transition.

Write E_A(y,z)=Z_A(y)-C_A(y,z). The actual two-sided soft argument and original old-source capacities give the sufficient majorant

    R404 <=(B_L/h^2) J_far,
    B_L=beta/(2L)+C_col/[(2-epsilon0)(L-epsilon0)],
    J_far=integral sigma(dA) pi_A(dy)pi_A(dz)
                          1_F(y,z) E_A(y,z)E_A(z,y).

This is a positive domination after dropping stated original marks, NOT an identity replacing the actual cost by an arbitrary unweighted moment. A bound J_far<=C n Xq/q_-^2 would suffice to pay a small Xq coefficient with its full L and epsilon0 dependencies. It is not known necessary and is not established by restating the desired budget. A direct marked source-price proof could be weaker and still useful.

## Exact order swap and what it retains

Positive Tonelli gives

    J_far=integral mu(dw)mu(dt) integral f(y)f(z)
          c_w(y)(1-c_t(y))c_t(z)(1-c_w(z))1_F(y,z)
          T_(K max(m_w,m_t))(y,z) dy dz,

where the ACTUAL parent kernel is

    T_M(y,z)=integral_{m_A>M}q_A c_A(y)c_A(z)dA/m_A^2.

Its masses and selectors still come from the same full f. Equivalently child matching cancels exactly to

    integral dw dt pi_w(dy)pi_t(dz)
       (1-c_t(y))(1-c_w(z))1_F(y,z)
       T_(K max(m_w,m_t))(y,z).

The receiver reference measure here is plain dw dt, not q_w dw q_t dt. No q ratio or receiver mass may be silently changed. The child posteriors are exact complete-f normalizations, not free probability laws. Parent common capture, its matched mass threshold and F remain jointly coupled.

Before the parent integration, let

    x_Awt=f(Q_A intersect Q_w outside Q_t),
    z_Awt=f(Q_A intersect Q_t outside Q_w).

The source integral with F is at most x_Awt z_Awt, and equals that product only if F is removed. The far indicator couples the two sources and cannot be factorized into independent marginal restrictions. The exact triple-intersection identities without F, by themselves, do not evaluate the far integral.

The proved R401 pair tail may upper-bound T_M by its coordinate-sensitive envelope and necessary ||y-z||infinity<=b cutoff. This is valid, but it replaces the actual parent's full-f mass by a much coarser geometric upper bound. The R404 advance depended precisely on cancelling a child denominator against its OWN matching mass before estimating actual center volume. That source-parent link should not be discarded without a replacement joint budget. Neither the coordinate envelope nor the two far norm thresholds alone supply a growing multicoordinate spread factor for arbitrary concentrated f.

## Useful exact matching facts, without claiming a charge

On each actual parent/children triple in this integral,

    x_Awt<=m_w<m_A/K, z_Awt<=m_t<m_A/K,
    pi_A(Q_w)<=m_w/m_A<1/K,
    pi_A(Q_t)<=m_t/m_A<1/K.

Moreover the parent background is a genuine full-f mass:

    f(Q_A outside(Q_w union Q_t))
       =m_A-f(Q_A intersect Q_w)-f(Q_A intersect Q_t)
                                      +f(Q_A intersect Q_w intersect Q_t)
       >=m_A-m_w-m_t>(1-2/K)m_A.

Here K>2 in the original contract. It is legitimate to expose a further conditional source from that background if all original labels are retained and the normalization is explicitly paid. It is NOT legitimate to charge the same background mass independently for every parent/child pair or stage and call it one W budget. A true joint non-repeating source allocation or occupation bound is still needed. The large outside mass is not automatically a fresh source, a disjoint support, an old qualified trajectory or a new receiver-column capacity.

The selected radius relationship is also real: strict far mass and q-band imply the parent radius is larger than each child by the corresponding factor (K q_-/lambda)^(1/n), wherever that factor exceeds one. This contact with actual cube geometry may be retained, but gives no joint estimate merely by naming it. Near-only single-face capacities cannot be reused on this entire far region without a separate geometric argument.

## Standards for a forthcoming claimed far estimate

A useful sufficient result must either bound the displayed matched parent/child source integral (or an honestly weaker original marked quantity) at the claimed scale, or give an actual source allocation whose TOTAL multiplicity is controlled at that scale. It must preserve full matching, actual center measures, parent common capture, both anti-captures, original F and genuine source weights. Individual private source neighborhoods or clusters cannot each charge the full W. R404's compact-neighborhood theorem may be used only with a proved footprint-volume budget; arbitrary child-dependent unions do not inherit its single fixed-D fee for free.

High exclusive ranks provide positive normalizations and the existing B_L/h^2 interface; they are lower occupancies rather than an upper packing budget. Existing outgoing/incoming capacities apply at the original old source and endpoints, not automatically to the new w,t or a resampled background source. No negative square or prior positive receipt can be deducted again. At the original entrance a new R404 receipt is multiplied by 64Lambda, with all old fees and available absorption constraints still retained.

No theorem of impossibility or counterexample family is asserted here, and no prospective author result is prejudged. The next step is to screen an exact new candidate against these requirements.

## Actual bounded local arithmetic

Reviewer ran 1131 Fraction full-source set checks with strict far-mass pairs: exact triple-intersection source products, a retained coupled two-source mask, and the background lower bound above. Some child source mass was allowed outside the parent, so the background inequality did not assume nesting. These are finite matching/algebra checks only, not native spatial/history certification or evidence for an unknown global bound. No separate reviewer script was saved; the count is not pooled with future author/parent experiments.

The independent prefilter was completed at this point. General far payment was not proved; the final author review below preserves that conclusion.

Inherited byte bindings:
- `/tmp/r404_main.md`: `d4914c5995deaa1b692ebb3c09928771e36cee8ca6a4b5c2604c85daad440b77`
- `/tmp/r404_geometry.md`: `40c6e289b5975657334317f985a9fa4f084a8cf2d45ce935975ac0f99316d1bf`
- `/tmp/r401_geometry.md`: `ea28d2fa8acb65c03f7d9cc38748724c6e054d1ceb2de2a09074e0dd03d471b0`


## Later independently screened global moment simplification

Let N be the fixed R404 source union and F its complement. For the SAME actual parent field put

    P_A=integral pi_A(dy)Z_A(y)
       =(1/m_A)integral_{m_w<m_A/K}f(Q_A intersect Q_w)dw/m_w,
    P2=integral sigma(dA)P_A^2.

This mean occupation preserves the actual parent-mass matching and is a nonnegative observable, not a reset source law or original flow row. The exact decomposition is

    P2=J_ex,F+J_prod,N+T_F,
    J_prod,N=integral sigma pi_A^2 1_N Z_A(y)Z_A(z),
    T_F=integral sigma pi_A^2 1_F C_A(y,z)
                                      [Z_A(y)+Z_A(z)-C_A(y,z)].

It follows by splitting the product ZyZz across N/F and expanding (Zy-C)(Zz-C) on F. There is no negative-sign or singular subtraction issue: C<=min(Zy,Zz), all three terms are positive and finite under the actual center envelope and finite Xq.

The inherited R404 union average at theta=1 gives J_prod,N<=2A_n Xq/q_-^2. The R399 common moment and Z<=A_n/q_- give

    0<=T_F<=2(A_n/q_-)integral sigma pi_A^2 C_A
           <=4lambda A_n Xq/(q_-^3 K).

Hence

    0<=P2-J_ex,F<=2A_nXq/q_-^2
                          +4lambda A_nXq/(q_-^3 K).

For fixed q-band ratio and A_n=O(n), a dimension-uniform n-order bound for P2 is equivalent up to these EXPLICIT controlled moment errors to that for J_ex,F. This is a legitimate simplification of a stronger unmarked geometric sufficient condition. It is not a necessary condition for an estimate of the smaller actual fully marked R404 cost.

The controlled moment terms must not be called identical to already paid original-flow pieces or deducted from an old ledger a second time. In particular multiplying T_F by B_L/h^2 yields its own explicit coefficient; it is not automatically the previously recorded common-past chi_n coefficient. Used only as a positive identity and order-equivalence, this creates no new receipt or fee and changes no original total budget.

Reviewer ran 18 additional Fraction finite full-source incidence checks of this decomposition and T_F<=2Jmax*commonmoment. The diagnostic source partition N was an arbitrary coupled source mask, which suffices for the identity; it did not certify the R404 geometric union theorem or a native n-order estimate. These cases are separate from the earlier 1131 prefilter algebra checks and future author/parent experiments.

The independent simplification screen passed in this exact limited scope. No far-source payment is certified; the final author and report review is recorded below.


## Frozen author post-review and actual executions

Read both complete frozen author notes and both delivered Python scripts. Independently reran both scripts locally: geometry 673 Fraction checks (625 same-full-source third-background cases and 48 polynomial tails), aux 147 Fraction checks (75 mass identities, 36 source-gated swaps, 36 correction identities), all PASS. These are 820 delivered-script checks, not pooled with the 1131 and 18 unsaved reviewer arithmetic cases above. The finite receiver quadrature is not native full-history realization.

Geometry PASS in its stated bounded scope: strict far matching gives background/m_A in (1-2/K,1]; the conditional third-source normalization is essential. Its unnormalized third-source moment is only constant-comparable to J_far. The exact positive 1/m_A^3 layer cake, matched V_f(r), and triple-center envelope coefficient 3lambda/(2q_-M^2) are correct. The attenuation examples do not provide the missing source average, and the note does not claim otherwise.

Aux PASS in its stated bounded scope: the retained F belongs inside Pi_F, exact two-witness difference products factor only after dropping F, and all actual parent and child matching measures are consistent. The common-moment cancellation and native squared-mass tail yield the stated O(A_n/K)X correction. P2 comparison has the correct direction and explicitly does not turn a bound on negative credit into payment of a positive remainder. Both notes leave the R404 ledger unchanged.

The geometry note's T_F denotes the third-background moment comparable to J_far; the aux note's T_F denotes the small common-overlap correction. These are DIFFERENT quantities. Any integrated report must distinguish them explicitly; this audit uses J_bg and T_common respectively.

Reviewed the corrected MATLAB source and recorded output without rerunning MATLAB. The initial independent source-grid scheme is explicitly rejected as integral evidence: mean-capture relative mismatches were approximately 0.721 and 1.059. The corrected scheme partitions the whole parent source cube at every receiver capture boundary; source-cell masses and capture masks are then consistent with the same full-f child masses. Its row-mean guard equals the receiver-grid volume divided by m_A analytically; the reported ordinary-double capture balance gap is 8.8817841970012523e-16. The 12 corrected cases have maximum reported split residual 3.1918911957973251e-14. This tests the finite-grid algebra and matching consistency; it does not certify receiver integration or the far gate, which remains a cell-midpoint approximation. No convergence or dimension exponent is inferred.

The fixed parent is [0,2]^n with f=1 there and no parent-center integration. The displayed P_squared is the fixed-parent row mean squared, NOT the global sigma-weighted P2 integral. The qmin=.75 branch lies in the original 4/3 q-band; qmin=.1 is explicitly separate broad-band stress. Neither branch realizes synchronized high-rank/history core gates. These ordinary MATLAB diagnostics are separate from the 820 Fraction Python checks.


## Final report and ledger verification

Read the complete final r405_main.md and r405_readme.md. PASS: the report separates J_bg (the author's third-source T_F, comparable to J_ex,F) from T_common,F (the aux small common correction). Its finite-measure justification q_- a^n |E| <= integral_E f(Q_A)dA <= b^n W is correct by actual-center containment and Tonelli; all moment differences are thus finite. No infinity subtraction is used.

The main report's P2 identity and explicit errors agree with the author proof and the independent screen. Its general n-order comparison is limited to the two full-source moment relaxations, not stated as necessary for paying the smaller actual marked remainder. The common-error coefficient is explicitly not old chi_n and is not deducted or charged a second time. The triple-background layer-cake remains a precise unproved-geometric-average interface, rather than a cost reduction.

The three inherited R404 ledger lines agree with the entering contract: R404 multipliers 16,32,64; unchanged chi_n, Delta404, P_L, E387 and S390; untouched low-dimensional alternative and A_entrance,n. No new source W fee, no new X absorption, no altered L, no reset f/clock/history and no additional near payment are introduced. The general target remains unproved.

Final numerical presentation PASS: 673+147=820 delivered Fraction checks are separate from the reviewer's unsaved 1131+18 arithmetic checks and from the 12 ordinary MATLAB corrected diagnostics. The initial alias is explicitly a rejected integral estimate, not a successful experiment. A small discrete split residual does not certify a continuous far integral. The corrected source capture-cell matching check is valid for the receiver grid; no receiver/far quadrature error, high-rank history, global parent integral or dimension-order inference is certified. MATLAB recorded output was reviewed, not independently rerun by this reviewer. Python delivered scripts were actually rerun by this reviewer and passed.

FINAL PASS is restricted to these proven identities, comparisons, honest failed route, actual evidence ranges, and unchanged total budget. It is not certification of a new geometric n-order estimate, root-order source payment, near extremizer, or general cube maximal bound. No author or repository file was edited. Audit is frozen after the bindings below.

## Final SHA-256 bindings
- `/tmp/r405_main.md`: `3f3d978f284fc9573157da5ae452d23c45d94abfb1ebeec349a961fa1b26f75f`
- `/tmp/r405_readme.md`: `0ef7a776f58ec56c8203e845064e7ecacd13004f563e70bd4237fa943de78187`
- `/tmp/r405_geometry.md`: `9692cbbabd1f3bb30dcd3a70965f7efbece6f47503b3dbc2848a15961b49d537`
- `/tmp/r405_aux.md`: `9c091ecce1c33e980f601ff70a8e67550375d5c5630e3c37bcd96ff75e4a9220`
- `/tmp/r405_geometry_check.py`: `d255c92882262bb0ecfd249aa2661089d5ee23665cb8c684c97e987494a3fb95`
- `/tmp/r405_aux_check.py`: `afa8680e49de4af87af864408d1bbbece3df13511b7c0447f2e338dd2d3f2d65`
- `/tmp/r405_geometry.result.txt`: `7c0d4b5b9237eb338af81df771b0577dcdaee2b1d1569789e5aa3e2cd02f7ec3`
- `/tmp/r405_aux.result.txt`: `714274b5ca6ee754413b138614d368d0eae241c23b7a734553bbb5ea376d10d4`
- `/tmp/r405_posterior_check.m`: `0ccd7fd7c68fe6089d7a6f17e4b5149546ae56878897e55f0450fdf9bef80e68`
- `/tmp/r405_posterior.result.txt`: `3d45fd837701fc1e0234c9b12216b291721f54b57e80e785265feab20c7c17cb`
- `/tmp/r404_main.md`: `d4914c5995deaa1b692ebb3c09928771e36cee8ca6a4b5c2604c85daad440b77`
