from fractions import Fraction as F
from itertools import product
from math import comb
counts={'full_matching_third_source':0,'triple_tail_polynomial':0}
# Exact cell masses of f=1 on [-2,2]^2. Atomic receiver quadrature only.
src=list(product([F(2*j+1,4) for j in range(-4,4)],repeat=2))
cell=F(1,4)
def capture(c,R,x): return all(abs(a-b)<=R/2 for a,b in zip(c,x))
A=frozenset(i for i,x in enumerate(src) if capture((F(0),F(0)),F(2),x))
mA=len(A)*cell
assert mA==4
ws=[]
for c in product([F(j,2) for j in range(-2,3)],repeat=2):
    Q=frozenset(i for i,x in enumerate(src) if capture(c,F(1),x))
    assert len(Q)*cell==1
    ws.append(Q)
K=F(3)
for w,t in product(ws,repeat=2):
    mw=len(w)*cell; mt=len(t)*cell
    assert mw<mA/K and mt<mA/K
    outside=len(A-(w|t))*cell
    assert outside>=mA-mw-mt>(1-2/K)*mA
    # Full old-source/new-source exclusive mass, retaining a distance mask.
    pair=sum(cell*cell for i in A&w-t for j in A&t-w
             if max(abs(src[i][k]-src[j][k]) for k in range(2))>F(1,4))
    two=pair/(mA*mA)
    triple=pair*outside/(mA**3)
    assert two==triple*mA/outside
    assert two<=triple/(1-2/K)
    counts['full_matching_third_source']+=1
def atten(a):
    n=len(a); coeff=[F(1)]
    for d in a:
        nxt=[F(0)]*(len(coeff)+1)
        for k,c in enumerate(coeff): nxt[k]+=c; nxt[k+1]-=d*c
        coeff=nxt
    U=min(F(1),F(1,max(a))) if max(a) else F(1)
    return 2*n*sum(c*U**(2*n+k)/F(2*n+k) for k,c in enumerate(coeff))
for n in range(1,13):
    for a in ([F(0)]*n,[F(1)]*n,[F(2)]*n,[F(1,2)]*n):
        value=atten(a)
        assert 0<=value<=1
        if a[0]==0: assert value==1
        if a[0]>=1: assert value==1/(F(a[0])**(2*n)*comb(3*n,n))
        counts['triple_tail_polynomial']+=1
print('PASS',counts,'total',sum(counts.values()))
