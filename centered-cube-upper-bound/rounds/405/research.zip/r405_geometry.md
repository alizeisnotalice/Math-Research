# R405 — Bounded screening of a global third-source matching certificate

**Outcome: no new payment proved.** The R404 remainder and ledger are unchanged. This note records one global candidate, the exact completed calculation, and the specific matching-dependent center estimate still missing. It does not add another near-region shape, failure tag, density threshold, or conditional payment theorem.

## 1. Candidate and the actual original quantity

Retain the FINAL R404 contract, including full f, actual Lebesgue centers, matched m_A=f(Q_A)=q_A R_A^n, q_-≤q_A≤λ, a≤R_A≤b≤2a, K=exp(√n), and the original stages, clocks and old-source β,C_col bounds. In the applicable high-dimensional branch K>2. Let F denote the fixed R404 far source event

 ||y−z||∞>a(e^(1/√n)−1)/2 and ||y−z||1>a/8.

No near-only collar, count or failure-coordinate constraint is imposed on F. As in R404, the positive parent moment

 J_F=∫σ(dA)∫π_A(dy)π_A(dz)1_F
             [Z_A(y)−C_A(y,z)][Z_A(z)−C_A(y,z)]          (1)

would suffice for a new budget: R404≤B_L J_F/h², using the original two rank gates, the pointwise old-source β,C_col bounds and the same-z stage sum. The target J_F≤C nX_q/q_-² is a SUFFICIENT stronger statement, not a theorem being invoked or a necessary condition for paying the original marked remainder.

The single candidate tested here was to use simultaneous full matching of both small witnesses and the parent. For witnesses w,t with m_w,m_t<m_A/K, most parent source mass lies OUTSIDE their union. Adding that third source could potentially restrict all parent centers at once. The issue is whether its center restriction gives a gain after the full source average, rather than merely introducing an additional formal denominator.

## 2. What the full matching actually proves

For fixed actual A,w,t define

 U_Awt=f(Q_A\(Q_w∪Q_t)),  M=K max(m_w,m_t).

On m_A>M,

 (1−2/K)m_A<U_Awt≤m_A,                                 (2)

because f(Q_A∩(Q_w∪Q_t))≤m_w+m_t<2m_A/K. This uses all of f and never assigns original history to w,t or the new source.

Expand (1) in its two actual exclusive witnesses. In every resulting term the sources satisfy y∈Q_w\Q_t and z∈Q_t\Q_w, while the parent captures y,z and m_A>M. Insert the exact conditional third-source law

 1_{x∈Q_A\(Q_w∪Q_t)}f(x)dx/U_Awt.

This preserves the original integrand. It is not legitimate to omit U_Awt. If instead one uses the convenient factor 1/m_A, the resulting total is

 T_F=∫μ(dw)μ(dt)∫f(y)f(z)f(x)
       1_F 1_{y∈Q_w\Q_t}1_{z∈Q_t\Q_w}1_{x∉Q_w∪Q_t}
       [∫_E q_A c_A(y)c_A(z)c_A(x)1_{m_A>M}dA/m_A³]
       dx dy dz.                                       (3)

Every integral is nonnegative. By (2), with the exact same original fields,

 (1−2/K)J_F≤T_F≤J_F,
 J_F≤T_F/(1−2/K).                                      (4)

Thus adding a third source by itself is only a constant-factor equivalent version of the moment. The extra inverse parent mass does NOT provide a free K gain: integrating the third source contributes U_Awt comparable to m_A. This is why (3) is not reported as a new cost reduction.

## 3. The actual geometric step left unresolved

A concrete geometric form is obtained without erasing parent matching. For fixed x,y,z,w,t set

 V_f(r)=∫_E q_A c_A(x)c_A(y)c_A(z)
                  1_{M<m_A≤r}dA.

The original selector and its full mass m_A=f(Q_A) remain inside this definition. Positive layer cake gives the exact identity

 ∫_E q_A c_A(x)c_A(y)c_A(z)1_{m_A>M}dA/m_A³
                 =3∫_M^∞ V_f(r)dr/r⁴.                 (5)

This includes mass atoms and the strict lower cutoff correctly. Let d_j be the span of x_j,y_j,z_j, R0=(M/q_-)^(1/n). Merely using m_A≤r⇒R_A≤(r/q_-)^(1/n) gives

 V_f(r)≤λ∏_j((r/q_-)^(1/n)−d_j)_+,
 (5)≤[3λ/(2q_-M²)] F_(n,2)(d/R0),
 F_(n,2)(a)=2n∫_0^1 x^(2n−1)∏_j(1−a_j x)_+dx.         (6)

This is a valid triple-center envelope, not an equality for the actual selector or a claimed sharp bound under matching. It retains all coordinate spans. For example F_(n,2)(0)=1 and F_(n,2)(1,...,1)=1/binom(3n,n). These attenuation facts do not supply a source-weighted estimate by themselves.

The unresolved step in THIS attempted proof is to estimate the actual-center expression (5), averaged against the three full source factors and the two exclusive witness measures in (3), at order nX_q/q_-². In particular the dependence of the matched sublevel {f(Q_A)≤r} on all other source mass must be used jointly across w,t. Replacing V_f by only the span volume in (6) loses precisely that restriction. Bounding the remaining x integral by W, or by an unpriced local f-box mass, does not settle it: that introduces another uncontrolled source mass divided by M. Neither thin boundary volume nor independent source coordinates is available.

This identifies a specific possible geometric estimate involving the same three captured sources and the parent matching sublevel; it is not asserted to be necessary for the original goal. No n-order estimate for it has been proved here. Equation (4) also prevents treating an abstract estimate of T_F with the same unknown size as an improvement.

All R404 constants and costs therefore remain untouched. The argument neither pays F nor modifies its support. The R404 exact near payment remains valid independently of this unsuccessful global candidate. No further candidate is pursued in this bounded task.

## 4. Actual local checks and their limits

Executed locally with Python standard-library Fraction:

    python3 /tmp/r405_geometry_check.py
    PASS {'full_matching_third_source': 625,
          'triple_tail_polynomial': 48} total 673

The first group uses exact cell masses of the SAME full source f=1 on a bounded two-dimensional box, parent side 2, small cube side 1, and rational K=3. All selected cell-aligned cube masses are computed exactly; it checks (2), the exact conditional third-source identity and the two-sided comparison (4), including a retained source-distance mask. Receiver integration in that diagnostic is finite quadrature, not a native Lebesgue-center estimate; the rational K checks the local algebra for K>2 rather than claiming all original high-dimensional history gates.

The second group evaluates the polynomial integral in (6) by exact rational expansion, including zero spans and all-equal spans 1 and 2 through n=12. For equal a≥1 it verifies a^(−2n)/binom(3n,n). These checks certify the displayed algebra on their stated cases, not the unproved average bound.

**Final status:** screened one joint matching candidate; proved its identities and the precise constant-factor limitation, but obtained no new general X_q or W payment. The unique remaining task is a genuinely source-averaged use of the actual parent matching sublevel in the far geometry, or a different proof of the original marked cost. This note is not a completed research-budget improvement.
