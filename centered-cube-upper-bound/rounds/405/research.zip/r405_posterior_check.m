% Fixed-parent diagnostics, not the global sigma(parent) P2 integral.
% Full f=1_[0,2]^n; A=[0,2]^n; R_w=1; m_w=exact intersection volume.
% First expose independent-grid alias, then use exact source capture cells.
fprintf('Initial independent source-grid alias check (NOT accepted integral evidence):\n');
for n=[2,3]
 Ns=8;Nr=12;axisW=-0.5+((1:Nr)-0.5)*3/Nr;
 ww=cartgrid(axisW,n);yy=cartgrid(((1:Ns)-0.5)*2/Ns,n);
 m=prod(max(0,min(2,ww+0.5)-max(0,ww-0.5)),2);
 use=m>=0.1 & m<2^n/exp(sqrt(n));m=m(use);ww=ww(use,:);
 cap=capture(yy,ww,n);Z=cap*((3/Nr)^n./m);
 nominal=mean(Z);balance=sum(use)*(3/Nr)^n/2^n;
 fprintf('n=%d source_mean=%.12g exact_capture_balance=%.12g relative_mismatch=%.9g\n',n,nominal,balance,abs(nominal-balance)/max(balance,realmin));
end
fprintf('Corrected capture-cell scheme; far gate still midpoint, no error certificate:\n');
fprintf('n Nr qmin source_cells P_squared far_exclusive near_product overlap_far far_fraction capture_gap\n');
maxSplit=0;maxBalance=0;count=0;
for n=[2,3]
 if n==2, widths=[12,18,24];else,widths=[6,9,12];end
 for Nr=widths
  axisW=-0.5+((1:Nr)-0.5)*3/Nr;
  wwFull=cartgrid(axisW,n);
  mFull=prod(max(0,min(2,wwFull+0.5)-max(0,wwFull-0.5)),2);
  cut=sort(unique([0,2,axisW-0.5,axisW+0.5]));cut=cut(cut>=0 & cut<=2);
  % Numerically duplicate cuts at roundoff distance produce zero-size cells.
  cut=cut([true,diff(cut)>1e-12]);
  centers=(cut(1:end-1)+cut(2:end))/2;cellWidths=diff(cut);
  yy=cartgrid(centers,n);pp=prod(cartgrid(cellWidths,n),2)/2^n;
  dinf=zeros(size(yy,1));done=zeros(size(yy,1));
  for jj=1:n
   temp=abs(yy(:,jj)-yy(:,jj)');dinf=max(dinf,temp);done=done+temp;
  end
  near=(dinf<=expm1(1/sqrt(n))/2 | done<=1/8);far=~near;
  pairWeights=pp*pp';
  for qmin=[0.1,0.75]
   use=mFull>=qmin & mFull<2^n/exp(sqrt(n));ww=wwFull(use,:);m=mFull(use);
   cap=capture(yy,ww,n);mu=(3/Nr)^n./m;Z=cap*mu;C=(cap.*mu')*cap';
   meanZ=pp'*Z;balance=sum(use)*(3/Nr)^n/2^n;
   balanceGap=abs(meanZ-balance);assert(balanceGap<1e-10);
   zp=Z*Z';P2=meanZ^2;ex=(Z-C).*(Z'-C);
   jf=sum(ex.*far.*pairWeights,'all');jn=sum(zp.*near.*pairWeights,'all');
   tf=sum(C.*(Z+Z'-C).*far.*pairWeights,'all');
   gap=abs(P2-jf-jn-tf);assert(gap<1e-10 && min(ex,[],'all')>-1e-10);
   maxSplit=max(maxSplit,gap);maxBalance=max(maxBalance,balanceGap);count=count+1;
   fprintf('%d %d %.2f %d %.12g %.12g %.12g %.12g %.9g %.3g\n',n,Nr,qmin,size(yy,1),P2,jf,jn,tf,jf/max(P2,realmin),balanceGap);
  end
 end
end
fprintf('PASS %d corrected diagnostics; max algebraic split residual %.17g; max capture balance error %.17g\n',count,maxSplit,maxBalance);
fprintf('qmin=.75 has ratio 4/3; .1 is wide-band stress. Fixed parent only, no high-rank-history claim.\n');
fprintf('Receiver quadrature and far-cell midpoint error are uncertified; no dimension exponent inferred.\n');
function grid=cartgrid(axis,n)
 boxes=cell(1,n);[boxes{:}]=ndgrid(axis);grid=zeros(numel(boxes{1}),n);
 for j=1:n,grid(:,j)=boxes{j}(:);end
end
function cap=capture(y,w,n)
 cap=true(size(y,1),size(w,1));
 for j=1:n,cap=cap & (abs(y(:,j)-w(:,j)')<=0.5);end
 cap=double(cap);
end
