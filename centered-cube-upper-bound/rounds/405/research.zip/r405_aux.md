# R405 — two actual witnesses, exact difference masses, and the size of overlap credit

**Outcome.** Swapping both exclusive witnesses gives the exact actual-receiver formula below. With the original far source gate, the two difference masses must remain coupled by that gate. The intersection subtraction has an exponentially small global upper bound, obtained from full matching and the native parent-center squared-mass tail. This does not pay the remaining far product moment; no new root receipt or ledger change is asserted.

## 1. Frozen far event and the complete swap

Use the full R404 field: f≥0 in L1, actual receiver measures du, m_u=f(Q_u)=q_uR_u^n, q_-≤q_u≤λ, a≤R_u≤b≤2a, μ(du)=du/m_u, σ(du)=q_u du, π_A=f1_{Q_A}/m_A. Put K=e^sqrt(n), A_n=1+n log(b/a). All original source, stage, clock and history quantities remain frozen. Define the current far source gate

F(y,z)=1_{||y−z||∞>a(e^{1/√n}−1)/2}
        ·1_{||y−z||_1>a/8}.

For an actual parent endpoint A let Z_A,C_A,E_A be exactly the R404 quantities with strict witness mass m_w<m_A/K. Consider the full-source moment relevant to this remaining gate,

J_ex,F=∫σ(dA)π_A(dy)π_A(dz) F(y,z)
                           E_A(y,z)E_A(z,y).             (1)

This is a positive relaxation used in the original double-rank estimate, not itself an assertion that every source pair satisfies the original marked high-rank conditions.

For fixed A,w,t write

B_Awt=Q_A∩(Q_w\Q_t),  D_Awt=Q_A∩(Q_t\Q_w),
Π_F(B,D)=∫_B∫_D f(y)f(z)F(y,z)dy dz.

Positive Tonelli gives the exact formula

J_ex,F=∫μ(dw)μ(dt)∫_{m_A>K max(m_w,m_t)}
                       σ(dA) Π_F(B_Awt,D_Awt)/m_A².       (2)

Every receiver in (2) is actual, and the SAME parent A must capture both source points. The two strict small-mass gates are retained as their exact combined gate. No two parent selectors or fake intersection receivers are introduced.

When F≡1, and only then, Π_F(B,D)=f(B)f(D). Put

I_w=f(Q_A∩Q_w), I_t=f(Q_A∩Q_t), I=f(Q_A∩Q_w∩Q_t).

Then the task's ungated difference-mass formula is

f(B)f(D)=(I_w−I)(I_t−I)
        =I_w I_t−I(I_w+I_t)+I².                           (3)

For the actual far gate, replacing Π_F by f(B)f(D) is a positive relaxation, not an equality. In particular the far gate cannot be recovered just from the three scalar masses I_w,I_t,I.

## 2. What the parent and child mass constraints provide

With J_wt=f(Q_w∩Q_t), complete matching implies

0≤I_w−I≤m_w−J_wt,
0≤I_t−I≤m_t−J_wt,
(I_w−I)+(I_t−I)+I=f(Q_A∩(Q_w∪Q_t))≤m_A.                 (4)

The first two inequalities follow from actual set containment, not from a volume bound on f. However, when K≥2, the original strict gate already gives

f(Q_w∪Q_t)≤m_w+m_t≤2 max(m_w,m_t)<m_A.                   (5)

Thus the SCALAR parent mass constraint in (4) supplies no further restriction beyond full child masses on this far-mass domain. This observation does not discard the actual parent geometry in (2); it identifies why merely substituting union/intersection masses does not settle the parent-center integral. A joint geometric constraint on the same A across both source locations would still be needed.

## 3. Exact far overlap correction and its global size

Keep the far source gate and define

J_prod,F=∫σ(dA)π_A(dy)π_A(dz) F(y,z) Z_A(y)Z_A(z).

Pointwise, with C=C_A(y,z),

Z_A(y)Z_A(z)−(Z_A(y)−C)(Z_A(z)−C)
                    =C[Z_A(y)+Z_A(z)−C]≥0.              (6)

Therefore

J_prod,F−J_ex,F
 =∫σπ_Aπ_A F C_A[Z_A(y)+Z_A(z)−C_A].                    (7)

This is the exact common-overlap correction under the far gate, not a newly borrowed negative square from BH. The actual-center envelope gives 0≤Z_A≤A_n/q_-. Hence

0≤J_prod,F−J_ex,F≤(2A_n/q_-) J_common,
J_common=∫σ(dA)π_A(dy)π_A(dz) C_A(y,z).                 (8)

For completeness the matching-based global bound on J_common is

J_common≤2λ|E|/(q_-K)≤2λX_q/(q_-²K).                    (9)

Indeed swapping the single common witness gives

J_common=∫μ(dw)∫_{m_A>K m_w}q_A I_Aw² dA/m_A²,
I_Aw=f(Q_A∩Q_w).

Use I_Aw²≤m_w I_Aw. For each fixed source z the genuine real parent-center tail satisfies

∫q_A c_A(z)1_{m_A>M}dA/m_A²
 ≤λ∫_0^∞dt/max(M,q_-t)²=2λ/(q_-M),                      (10)

where t=(2||A−z||∞)^n is the true cube-volume radial variable. With M=K m_w, Tonelli and f(Q_w)=m_w cancel the actual witness denominator and prove (9). No source-density bound, independent-radius integration or copy of the parent field appears here. This is the already established R399 common-moment estimate, used explicitly rather than claimed as a new inequality.

Combining (8),(9) yields the quantitative comparison

J_prod,F−[4λA_n/(q_-³K)]X_q≤J_ex,F≤J_prod,F.              (11)

All integrals are finite by Z_A≤A_n/q_- and X_q<∞. The far gate remains in the equality (7); only the proved upper bound drops it. Formula (11) does not say the original far traffic is large. It says that for this particular full-source moment relaxation, the intersection subtraction can alter the far product moment by at most the displayed amount.

## 4. Original-cost interface and the remaining gap

The original frozen double-rank inequality and actual old-source row/column bounds give

R404≤(B_L/h²)J_ex,F,
B_L=β/(2L)+C_col/[(2−ε_0)(L−ε_0)],
h=(1+√n)/(ε_0q_-).                                      (12)

All stage b_i are summed at the same source before Σb_i≤1 is used, as in R404. This is a positive upper relaxation; equality with the original marked residual is not claimed.

Replacing J_ex,F by J_prod,F in the right side of (12) increases that particular upper bound by at most

[4(λ/q_-)ε_0² B_L A_n/(K(1+√n)²)]X_q
                         ≤[4(λ/q_-)ε_0²B_L/K]X_q.        (13)

This comparison has the direction stated: an upper bound on a negative correction cannot by itself give an upper bound on the remaining large term. It is not a newly paid positive branch of R404, and no extra fee is inserted into the ledger merely to record (13).

The unestimated term is the complete parent-posterior product Z_A(y)Z_A(z) on the original TWO-norm far domain, with parent matching and the same actual selector. The R404 neighborhood theorem pays its corresponding near restriction, but does not control this far part. The present two-witness union/intersection manipulation produces neither a source W estimate for that product nor a usable lower bound for a larger cancellation. To improve the budget one must retain more of the actual high-rank/stage correlations than this full-source relaxation, or prove a new source-integrated parent geometry bound; simply cancelling both child masses and summing their parent footprints has not provided one.

No lower bound here excludes the desired theorem for the original marked residual. It only bounds what the specific intersection credit (7) can accomplish. The R404 residual and all original entrance/source fees remain unchanged. This bounded route ends with its exact unresolved cost, not a renamed claim of root payment.

## 5. A single matched posterior row-mean moment

Define, without rebuilding the original field,

P_A=π_A Z_A
   =m_A^{-1}∫_{m_w<m_A/K} f(Q_A∩Q_w)dw/m_w,
P2=∫σ(dA)P_A².

This is an explicitly defined scalar full-source moment of the SAME matched parent/witness kernel. It is finite because Z_A≤A_n/q_-. Let N be the R404 union of the root-scale l∞ displacement cube and the l1 ball of radius a/8, including its boundary; the far gate F is exactly its complement. Write J_prod,N for the product moment with 1_N in place of F, and T_F=J_prod,F−J_ex,F from (7). Positive Tonelli gives the exact identity

P2=J_prod,F+J_prod,N=J_ex,F+J_prod,N+T_F.                 (14)

The R404 matching theorem bounds the Z-product itself, not only the exclusive product. For each original (A,y), it gives

∫π_A(dz)1_N(y,z) Z_A(z)≤2/q_-.

Multiplying by Z_A(y)≤A_n/q_-, then integrating σ(dA)π_A(dy), proves

0≤J_prod,N≤2A_n X_q/q_-².                               (15)

Equations (11),(14),(15) therefore yield the complete comparison

0≤P2−J_ex,F
 ≤[2A_n/q_-²+4λA_n/(q_-³K)]X_q.                         (16)

Thus, on one frozen field, the far exclusive full-source moment and P2 differ only by an explicitly bounded near product and the intersection correction. This is a useful reduction of the remaining GEOMETRIC estimate to a single matched posterior row mean. Neither (14) nor (16) proves a bound for P2.

In the actual double-rank units of (12), the difference is at most

{2ε_0² B_L A_n/(1+√n)²
 +4(λ/q_-)ε_0² B_L A_n/[K(1+√n)²]}X_q.                 (17)

The first coefficient is exactly the R404 θ=1 near price; the second is (13). They are not new source W fees. This comparison explains the already controlled terms, and does not license charging the near piece twice in the inherited ledger. If parameters such as L are changed to allocate smaller absorption, the original mother split and its P_L must change as already specified in R404.

An appropriate bound for P2 is therefore sufficient to control the far moment up to these explicit costs; conversely a bound for that far moment transfers to P2 with precisely (16). This equivalence concerns the two full-source MOMENT relaxations, with their stated X_q allowances. It is not a necessary condition for a bound on the original marked flow R404, which can be strictly smaller than the relaxation (12). The next unproved task is a geometric bound for this matched posterior row-mean moment, not an assertion that P2 has already been paid.

## 6. Executed local checks

Ran `python3 /tmp/r405_aux_check.py` using Python Fraction:

`PASS {'matched_mass_identity': 75, 'gated_swap': 36, 'signed_credit': 36} total 147`

The source is the genuine full L1 density f=1 on [-4,4]. Parent intervals have side 2 and child intervals side 1, so all displayed masses and q=1 matching are exact. The first group checks (3),(4) at 75 actual interval configurations. The next groups integrate the continuous two-source far event |y−z|>d exactly over interval cells, using a positive-part quadratic formula; they compare both orders of the swap and the signed correction identity at 36 choices of parent location, rational witness weights and source-distance threshold.

The witness integration in the latter groups is finite quadrature, not native continuous receiver dw. The strict diagnostic mass gap can be K=3/2; these 1D checks do not realize the original K=e^sqrt(n), high-rank or full-history core. They check exact source gating and algebra only. The general actual-du comparison (9)–(11) follows analytically from the native center tail (10), not the finite models. No counterexample search or additional special-family route was undertaken.
