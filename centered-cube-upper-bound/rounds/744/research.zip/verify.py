"""R744. Finite exact checks for the projected owner volume and the true R743 history."""
from fractions import Fraction as Q
from itertools import combinations, product
from math import factorial
import json
import platform
import sys

import flint
from flint import arb, ctx

ctx.prec = 256


def discrete_union(n, m, levels, cutoff):
    # Integer digits encode (j+1/2)/levels, the gaps of equally weighted grid cells.
    points = levels**n
    union = fixed = 0
    for digits in product(range(levels), repeat=n):
        union += 2*sum(sorted(digits)[:m]) + m <= 2*levels*cutoff
        fixed += 2*sum(digits[:m]) + m <= 2*levels*cutoff
    # Independent union count using multisets and their multinomial multiplicities.
    from itertools import combinations_with_replacement
    from collections import Counter
    check = 0
    for digits in combinations_with_replacement(range(levels),n):
        if 2*sum(digits[:m])+m <= 2*levels*cutoff:
            multiplicity = factorial(n)
            for count in Counter(digits).values():
                multiplicity //= factorial(count)
            check += multiplicity
    directions = len(list(combinations(range(n),m)))
    assert union == check <= min(points, directions*fixed)
    enlarged = cutoff + Q(m, 2*levels)
    assert Q(fixed,points) <= enlarged**m/factorial(m)
    return dict(n=n,m=m,levels=levels,cutoff=str(cutoff),points=points,
                union=union,one_projection=fixed,coordinate_sets=directions,
                fixed_volume_enclosure=str(enlarged**m / factorial(m)))


def exact_ceil(acc):
    rounded = acc.ceil().unique_fmpz()
    if rounded is None:
        raise ArithmeticError("The interval does not fix an integer ceiling")
    return int(rounded)


def large_dimension(n,p=1):
    # No factorial or array of length n is allocated for these interval tests.
    N = arb(n)
    h = 1 + 1/(32*N)
    kappa = h**n
    c = arb(4096)
    t = c*N.sqrt()
    delta = 1/N**p
    height_cost = (kappa / (delta*t)).log()
    assert height_cost > 0 or height_cost < 0
    radius = (N+1).log()+ (height_cost if height_cost>0 else 0)
    lower_radius_factor = (arb(2).log()/N).exp()
    b = lower_radius_factor*128*h*(N/N.log()).sqrt()*radius
    m = min(n, max(64, exact_ceil(8*(N*b).sqrt())))
    tau = arb(m)/(256*N)
    qbin = 1/N+2*(1+1/N)/(32*N)+(1+1/N)*tau
    e = arb(1).exp()
    base = e**2 * N * (b + m*qbin) / m**2
    bins = 1+exact_ceil((lower_radius_factor*64*(N/N.log()).sqrt()).log()
                         / (1+1/N).log())
    prefactor = arb(bins)/t*(h*(1+1/N))**n
    log_owner_bound = prefactor.log()+m*base.log()
    if m<n:
        assert base < arb(1)/2
        assert log_owner_bound < -arb(m)/2
    return dict(n=str(n),p=p,c=4096,m=str(m),bins=str(bins),tau=str(tau),
                simplex_base_upper_interval=str(base),
                log_unclipped_endpoint_bound=str(log_owner_bound),
                nontrivial=bool(log_owner_bound<0))


def true_history():
    n,a = 64,2048
    v=Q(3,16)**4*Q(21,8)**60
    d0=2**64
    theta = 1-Q(1,a**256)
    lower_m = theta*(v-6*d0)-v/32
    alpha = 64*Q(7,16)**8
    old = (1-alpha)**2*(lower_m-v/8)
    assert old>8*d0
    residual = (old-8*d0)**2/old
    assert residual/v>Q(68280,100000) and v<118*8*theta*d0
    m=64
    tau=Q(m,256*n)
    coordinate=1-tau/2
    assert 1-tau < coordinate < 1 and theta>Q(1,n)
    for r in (Q(1,2),Q(3,4)):
        s_pivot = Q(1)
        s_secondary = Q(1)
        assert s_secondary > s_pivot/2  # excludes the secondary from both R743 tests
        radius_squared = (64*r/s_secondary)**2 * n
        assert arb(radius_squared.numerator)/radius_squared.denominator > arb(n).log()
    b_min=128*(arb(n)/arb(n).log()).sqrt()*arb(n+1).log()
    assert 8*(n*b_min).sqrt() > n
    upper_D=theta*d0+v/a**192
    assert (lower_m-v/4)/(8*upper_D)>Q(8384246,100000)
    assert (theta*v-v/4)/(8*theta*d0)<Q(8827041,100000)
    return dict(n=n,c="2048^(-64)/(2048 log(2048))",
                V_T="(3/16)^4(21/8)^60",R_high="theta V_T",
                D=["theta*2^64","theta*2^64+V_T/2048^192"],
                M=["theta*(V_T-6*2^64)-V_T/32","theta*V_T"],
                normalized_M_excess_interval=["83.84246","88.27041"],
                R741_B="1/2",R742_B="1/2",
                R743_sites="all half-sized inscribed cells and all vertices",
                R743_over_V_lower_at_1e8=(10**8*residual/v).__floor__(),
                m=m,tau=str(tau),test_site_abs_coordinate=str(coordinate),
                R744=0,finite_bill_upper_over_sqrtnD=118)


def top(values, cap):
    amount = Q(0)
    for value in sorted(values, reverse=True):
        take = min(Q(1), cap)
        amount += value * take
        cap -= take
        if cap == 0:
            break
    return amount


def capacity_certificates():
    # Three coarse groups in one bin, with distinct fine cells. The incidence graph is A-B-C.
    # Scale scores by 2*zeta. Each incident column has unit density in these normalized units.
    # Both independently available budgets serve the exact same three demands.
    weights = (Q(2), Q(3), Q(2))
    incidence = ((1,1,0),(0,1,1))
    u = (Q(1),Q(2,3),Q(1))
    coarse = ((Q(1),Q(0),Q(0)), (Q(0),Q(0),Q(1)))
    fine = ((Q(0),Q(1,4),Q(0)),(Q(0),Q(1,4),Q(0)))
    caps = (Q(1),Q(1,4))
    covered = [sum(incidence[k][j]*(coarse[k][j]+fine[k][j]) for k in range(2)) for j in range(3)]
    for k in range(2):
        assert sum(coarse[k]) <= caps[0] and sum(fine[k]) <= caps[1]
    primal = sum(mass*max(Q(0),1-b) for mass,b in zip(weights,covered))
    dual = sum(mass*price for mass,price in zip(weights,u))
    for neighbors in incidence:
        demand = [mass*price for mass,price,ok in zip(weights,u,neighbors) if ok]
        dual -= sum(top(demand,cap) for cap in caps)
    # For optimality, the expensive middle row must be saturated. Use the permitted coarse split.
    coarse2 = ((Q(3,4),Q(1,4),Q(0)),(Q(0),Q(1,4),Q(3,4)))
    assert all(sum(row)==caps[0] for row in coarse2)
    covered2 = [sum(incidence[k][j]*(coarse2[k][j]+fine[k][j]) for k in range(2)) for j in range(3)]
    optimum = sum(weight*max(Q(0),1-b) for weight,b in zip(weights,covered2))
    assert optimum == dual == 1 and primal == Q(3,2)
    scattered = []
    for P in (1,5,17):
        count = 32*P
        h0 = Q(1,128)
        zeta = h0/16
        # Two equally sized budgets, one distinct coarse and fine cell per real-valued test demand.
        # Uniform primal and constant dual certify the optimum. This is only an allocation model.
        cap = Q(P)
        value = count * (1 - h0*(2*cap/count)/(2*zeta))
        lower = count - 2*top([h0]*count,cap)/(2*zeta)
        spill = 1-2*cap/count
        assert value == lower == count/2 and spill > Q(7,8)
        scattered.append(dict(each_budget=P,groups=count,deficit=str(value),tail_fraction=str(spill)))
    return dict(weighted_chain_optimum=str(optimum),chain_cut=[str(x) for x in u],
                chain_suboptimal_primal=str(primal),dispersed=scattered)


if __name__=="__main__":
    print(json.dumps(dict(python=sys.executable,python_version=platform.python_version(),
                     python_flint=flint.__version__,arb_bits=ctx.prec,
                     command="python -B verify.py",
                     exact_small=[discrete_union(*args) for args in
                                  ((3,1,5,Q(1,4)),(4,2,5,Q(2,5)),(6,3,4,Q(5,8)),
                                   (7,5,4,Q(11,8)),(8,8,4,Q(7,2)))],
                     true_two_scale=true_history(), allocation=capacity_certificates(),
                     analytic_bound_checks=[large_dimension(2**e,p) for e in
                                            (10,18,25,32,44,60) for p in (1,3)]),
                     indent=2))
