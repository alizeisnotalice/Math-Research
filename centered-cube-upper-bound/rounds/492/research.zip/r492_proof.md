# R492：同一成功族的显式来源分配与实际输出列账

结论：Gram 行和条件确实给每个子父同时保有至少 \(2/3\) 完整质量的显式 fractional 来源收据，最大父也不例外。最大父的一次新源输出保列帽一（归一化时为 \(3/2\)）；全族输出的直接 Campbell 列仍含上方来源秩。尚未得到 R491 累计 \(p\) 次停止账的根阶来源付款。

## 1. 同时分配，不用质量比放松

固定一条实际成功记录，其有限非空保留族为 \(\mathcal F_0\)，包括实际 raw 最大父 \(B_*\)。保持完整 \(\mu=f\,dx\)、\(m_C=\mu(Q_C)>0\)，并假设原已证条件
\[
 \sum_{D\in\mathcal F_0,D\ne C}\gamma_{CD}\le\tfrac12,
 \qquad \gamma_{CD}=\frac{\mu(Q_C\cap Q_D)}{\sqrt{m_Cm_D}}. \tag{1}
\]
所有成员保原记录中排斥旧 \(y,z\) 的资格；分配不改变这些盒子。定义
\[
 D_{\mathcal F_0}(u)=\sum_{D\in\mathcal F_0}\frac{c_D(u)}{\sqrt{m_D}},
 \quad r_C(u)=\frac{c_C(u)/\sqrt{m_C}}{D_{\mathcal F_0}(u)},
 \quad b_C=\int r_Cd\mu. \tag{2}
\]
分母零时全部取零。于是 \(0\le r_C\le c_C\)，\(\sum_Cr_C=1_{\cup_CQ_C}\)。在 \(Q_C\) 上分母严格正，积分 Cauchy 给
\[
 b_C=\frac1{\sqrt{m_C}}\int_{Q_C}\frac{d\mu}{D_{\mathcal F_0}}
 \ge\frac{m_C^2}{\sqrt{m_C}\int_{Q_C}D_{\mathcal F_0}d\mu}
 =\frac{m_C}{1+\sum_{D\ne C}\gamma_{CD}}
 \ge\frac23m_C. \tag{3}
\]
没有 \(m_D/m_C\) 损失。故任意子族 \(\mathcal I\subset\mathcal F_0\) 同时满足必要 Hall 条件
\[
 \mu\Big(\bigcup_{C\in\mathcal I}Q_C\Big)
 \ge\sum_{C\in\mathcal I}b_C\ge\tfrac23\sum_{C\in\mathcal I}m_C. \tag{4}
\]
这里直接构造已证明可行性，不需无限维匹配定理。原有限 PPP 点可按增广质量/mark 可测编号，原删除规则可测，故(2)及 \(b_C\) 对完整记录联合可测；同质量点不被合并。归一新来源律为
\[
 \omega_C(du)=r_C(u)\mu(du)/b_C\le\tfrac32\pi_C(du). \tag{5}
\]
这只是该实际记录后的辅助采样，绝不赋予新来源旧时钟、旧 pair 或后续成功资格。

## 2. 最大父：一次真实列帽和归一费用

令 \(\mathcal G\) 为 R486 同一自然输入 \(\mathsf M\) 附当前父原记录后，取实际成功事件的完整记录测度；成功后仍保旧父、旧来源、全部 raw 配置、保留族与 mark。其最大父投影由 R479 §2/R486 geometry §2 支配：
\[
 (B_*)_\#\mathcal G\le\nu(dB),\qquad \nu=t\sigma,\quad 0\le t\le S. \tag{6}
\]
对任何冻结可测输入权 \(0\le a\le1\)，包括 \(a=q_j^p\)，定义正次概率扩充
\[
 d\mathcal G^{\rm alloc}=a(\xi)\mathcal G(d\mathrm{record})
       \frac{r_{B_*}(u)}{m_{B_*}}\mu(du). \tag{7}
\]
每成功记录保留比例 \(b_{B_*}/m_{B_*}\in[2/3,1]\)。由 \(r_B\le c_B\) 和(6)，
\[
 \frac23\int a\,d\mathcal G\le|\mathcal G^{\rm alloc}|
 \le\int a\,d\mathcal G,\qquad
 (B_*,u)_\#\mathcal G^{\rm alloc}\le\nu(dB)\pi_B(du). \tag{8}
\]
若必须保持全部成功质量，可改用(5)，则输出列帽是 \(3/2\)，不是一。全部旧标签可仍附在扩充测度中，但其条件律一般与新 \(u\) 相关。

源投影的可证价为
\[
 \mathcal G^{\rm alloc}_u(du)\le D_t(u)\mu(du),
 \quad D_t(u)=\int t(B)c_B(u)\frac{dB}{R_B^n}
 \le S A_n,\quad A_n=1+n\log(b/a). \tag{9}
\]
从而总量至多 \(SA_nW\)，仍是线性维数价。新源加上旧配置不服从 R486 自然 \(\pi_B\otimes\mathrm{PPP}_{B,u}\)：旧配置保留时有些成员不捕获新 \(u\)。因此不能免费把(7)接回原 \(JH\)，也不能把(8)的父—来源列帽宣称为整个配置列帽。

## 3. 全族：保 PPP 输入的实际上秩费用

仍在原质量带并保增广 mark。令
\[
 \rho_x(d\widehat A)=c_A(x)\nu(dA)ds_A/m_A,
 \quad U_b(x)=|\rho_{x,b}|,
 \quad w_x(\widehat C)=\rho_{x,b}\{\widehat A\prec\widehat C\}.
\]
将每个成员都送出 \(r_C(u)\mu(du)/m_C\)，得到全族计数扩充 \(\mathcal G^{\rm all}\)。每记录质量在 \([2|\mathcal F_0|/3,|\mathcal F_0|]\)，不是次概率核。删实际成功门、删 \(a\le1\)、用 \(r_C\le c_C\)，再对原 PPP 作一次 Campbell 换序，得到
\[
 \mathcal G^{\rm all}(d\widehat C,du)
 \le\nu(dC)ds_C\pi_C(du)\,L_b(\widehat C),
\quad
 L_b(\widehat C)=\frac1T\int\pi_C(dx)
       [U_b(x)-w_x(\widehat C)]. \tag{10}
\]
证明：固定 \(x\) 的输入父秩为 \(v\)，指定候选 \(C\) 的强度是 \(\rho_x(d\widehat C)/T\)，须 \(v>w\)。对所有输入父积分恰给 \((U_b-w)/T\)，然后才积分 \(x\sim\pi_C\)。增广原子边界为秩 Lebesgue 零测；无未声明质量无原子假设。这里不能保最大点 void，因指定的 \(C\) 不一定是最大点。

有 \(L_b\le SA_n/T\)，所以这条直接全族列账至多给 \(S^2A_n^2W/T\)。分配的 \(\sum_Cr_C\le1\) 仅在**同一记录**成立，不能在不同输入父/配置的 Campbell 积分中先相加后抹掉上秩。

也可以作合法全族次概率核
\[
 \sum_{C\in\mathcal F_0}\frac{r_C(u)}{M_{\mathcal F_0}}\mu(du),
 \qquad M_{\mathcal F_0}=\sum_Cm_C.
\]
其总质量在 \([2/3,1]\)，最大父保留份额至少 \(2m_{B_*}/(3M_{\mathcal F_0})\)，并非统一常数。由于 \(m_C/M_{\mathcal F_0}\le1\)，(10)仍是合法上界；尚无从真实成功门推出的统一列帽一。不能同时声称全族每个成员有常数概率、又保持核的总质量一。

## 4. 与 R491 的实际 p-stop 精确连接

不能只把无权成功 occupation 当停止账；但可保下一步停止权作精确连接。令原成功记录的核为 \(J^{\rm rec}(\xi,d\zeta,d\beta)\)，\(\beta\) 是原最大父输出的自然状态，\(\zeta\) 保留原记录、raw 族和 \(\mathcal F_0\)。定义
\[
 d\Gamma_j=q_j(\xi)\mathsf M(d\xi)
 J^{\rm rec}(\xi,d\zeta,d\beta)H(\beta,d\xi')
 q_{j+1}(\xi')^{p-1}e(\xi'). \tag{11}
\]
零密度处取 \(0^{p-1}=0\)。这是原 \(\mathcal P=JH\) 的正加权一步，不改变刷新或历史。因到达 \(\xi'\) 的密度恰为 \(q_{j+1}\)，
\[
 |\Gamma_j|=\int q_{j+1}^pe\,d\mathsf M,
 \qquad A_p=\mathsf M(e)+\sum_{j\ge0}|\Gamma_j|. \tag{12}
\]
这个接口由 Astra 同轮提出；此处直接按原到达密度核验。当前成功族仍为原 \(\mathcal F_0(\zeta)\)，不是刷新后重新筛出的族。

对(11)附全族次概率分配
\[
 d\widetilde\Gamma_j=d\Gamma_j\,
 \sum_{C\in\mathcal F_0}
 \frac{r_C(u)}{M_{\mathcal F_0}}\mu(du).
\]
令
\[
 \mathcal C_p(u)=\sum_{j\ge0}\int
 \frac{1_{\cup_{C\in\mathcal F_0}Q_C}(u)}{M_{\mathcal F_0}}
 \,d\Gamma_j.
\]
Tonelli 与(3)给准确、保原停止权的夹逼
\[
 \boxed{\frac23[A_p-\mathsf M(e)]
 \le\int\mathcal C_p\,d\mu
 \le A_p-\mathsf M(e).} \tag{13}
\]
因此若能证明 \(\int\mathcal C_p d\mu\le\eta X+B_pW\)，则
\(A_p\le\mathsf M(e)+\tfrac32\eta X+\tfrac32B_pW\)，再由 R491 恢复原 \(R\)。初始一次 \(\mathsf M(e)\) 仅按原已证一次失败价计一次。

对每代，(11)中额外权 \(q_j,q_{j+1}^{p-1},e\le1\)，所以§2–3的列上界有效。还有更好的、由 Astra 提供并在此核验的最大父 Palm 顺序：先用真实输出列支配 \(\mathsf MJ\le\mathsf M\)，再丢成功族选择。写 \(u_0(z)=D_t(z)\)、\(b_0=2rS/T\)。由于 \(\mathcal F_0\subset\{B\}\cup F_{<B}\)、\(M_{\mathcal F_0}\ge m_B\)，
\[
 \frac{1_{\cup_{C\in\mathcal F_0}Q_C}(z)}{M_{\mathcal F_0}}
 \le\frac{c_B(z)+\sum_{C\in F_{<B}}c_C(z)}{m_B}.
\]
对自然参考的条件 PPP 作 Campbell，第一项积分为 \(u_0(z)\)，第二项为
\[
 \frac1T\int\frac{c_C(z)\nu(dC)}{m_C}
 \int_{m_B\ge m_C}\frac{I_{BC}}{m_B^2}\nu(dB)
 \le b_0u_0(z). \tag{14}
\]
这里闭尾中心 CDF 给内积分 \(\le2rS\)：先积 \(x\in Q_C\)，用
\(\int_{m_B\ge m_C}c_B(x)\nu(dB)/m_B^2\le2rS/m_C\)。同带/mark 的删除只作正上放，原子仍包含在闭尾中。

R491 有 \(q_j\le a_j:=\min(1,e^Lb_0^j)\)，于是第 \(j\) 代的分配源列至多 \(a_j(1+b_0)u_0(z)\)，累计
\[
 \mathcal C_p(z)\le(1+b_0)\Big(\sum_{j\ge0}a_j\Big)D_t(z). \tag{15}
\]
这避免直接全族 Campbell 的上方秩损失，但仍未给根阶来源价：\(D_t\le SA_n\)，且 \(\sum a_j\) 有停止深度因子。未把实际成功配置的条件律称为 PPP；PPP 只在正上放到自然参考后使用。

真正待付的 \(\mathcal C_p\) 含下一状态停止权及原成功记录；(15)把这些权放成一后不够。本稿尚未以 R491 的 \(p\)-Jensen 缺陷支付该累计列，(13)–(15)不单独算完整付款，也没有生成另一条可继承旧历史的链。

## 5. 精确有限核验（证据范围）

下列脚本将三个真实一维区间的五个源区域精确积分，来源密度非均匀，质量为 \(1,4,9\)，使平方根有理。检查显式分配、每父收据及全部子族 Hall 条件；另核等质量极端行和 \(1/2\)。它是完整来源质量的有限盒族检查，不是连续接收中心选择器、统一 qband 或原 PPP/history 的实现；一般证明是(2)–(3)。

```python
from fractions import Fraction as F
from itertools import combinations
checks = 0
def ck(x):
    global checks
    assert x
    checks += 1
# Q0=[0,1], Q1=[4/5,9/5], Q2=[8/5,13/5].
# Rows give source mass on private/overlap intervals; full f is constant on each.
models = [
    ([F(1),F(2),F(3)],
     [(F(4,5),(0,)),(F(1,5),(0,1)),(F(18,5),(1,)),
      (F(1,5),(1,2)),(F(44,5),(2,))]),
    ([F(1),F(1)],[(F(1,2),(0,)),(F(1,2),(0,1)),(F(1,2),(1,))])
]
for roots,cells in models:
    n=len(roots); m=[s*s for s in roots]
    b=[F(0)]*n; overlaps=[[F(0)]*n for _ in range(n)]
    for mass,ids in cells:
        den=sum(1/roots[i] for i in ids)
        weights={i:(1/roots[i])/den for i in ids}
        ck(sum(weights.values())==1)
        for i in ids:
            b[i]+=mass*weights[i]
            for j in ids: overlaps[i][j]+=mass
    for i in range(n):
        ck(overlaps[i][i]==m[i])
        row=sum(overlaps[i][j]/(roots[i]*roots[j]) for j in range(n) if j!=i)
        ck(row<=F(1,2))
        ck(b[i]>=m[i]/(1+row))
        ck(F(2,3)*m[i]<=b[i]<=m[i])
    for k in range(1,n+1):
        for ids in combinations(range(n),k):
            union=sum(mass for mass,sig in cells if set(ids)&set(sig))
            ck(union>=sum(b[i] for i in ids)>=F(2,3)*sum(m[i] for i in ids))
print(f'{checks} exact Fraction assertions PASS; finite full-source interval families only.')
```

实际运行：从本文唯一 Python fence 提取到新临时目录，用指定本机 Python `-I` 隔离执行，stdout 为 `38 exact Fraction assertions PASS; finite full-source interval families only.`。
