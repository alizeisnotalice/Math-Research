# R492 独立终审

FINAL PASS（限定范围）。认证同时分配／子族容量、最大父新源列及其归一费用、同链 p-stop 的真实前一跳恢复，以及先最大点列支配再自然 PPP Campbell 的单代列上界。不认证累计来源根价、A_p 付款或一般完整上界闭合。

独立 PRE 在作者稿阅读前形成并保留。局部 Cauchy 使用完整 m_C 与 γ_CD，给每父 M_C≥m_C/(1+rowγ)≥2m_C/3；联合可测分配及全部子族 Hall 下界成立。最大父未归一来源核行在[2/3,1]且列≤νπ_B；保全质量归一时列升至至多3/2，不能同时宣称帽一。合计全族子核恰为 union/G，局部分配本身未降低跨配置总列，新来源不继承原共同源／自然配置／history。

Γ_j 保原 J 记录、随后同一 H 和下一状态权 q_(j+1)^(p−1)e，质量准确为∫q_(j+1)^p e。初始 M(e) 单列，仅付一次；族收据恢复剩余 p-stop 的至少2/3，而非将成功 occupation 当作停止。

更好的单代列推导顺序合法：先把 union/G 正放成最大父与全部 lower 点的输出可测函数，再删≤1的停止权和原标签，使用完整自然状态 MJ≤M；没有在实际成功后假设配置仍为 PPP。自然 π_B 与额外1/m_B恰给内积分 I_BC/m_B²；真实中心 CDF 的闭尾含下端质量原子，给该内积分≤2rS。于是单代≤a_j(1+b0)u，累计仍保Σa_j与u，不能由此换成 rootW。直接全部 raw 候选的上方秩因素与此合法先 max 正放没有混用。

独立隔离重放 geometry 17、proof 38、numeric 222 项，共277项精确断言通过；stdout 与 replay 一致。numeric JSON 仅删除 compute_index.seconds 后全字段一致，canonical SHA256 为 `c3c171203578c8bd5bc2a59acd2e5f7cc59279d7e4183499ca9faa6ddf16a6b5`。四个过门几何族及一个明确未过门族是有限原子来源／有限实际区间方形接口，不认证连续接收场、qband 或原 p-stop/history 实现。history 文档仅为限定索引，不作本轮证明或全面历史新颖性依据。原初始、旧母账倍率及所有未付累计/尺度费用保留。

## 冻结输入 SHA256

- `r492_main.md`: `17e206bb931eff578a6bef614334d51acc9eb286f1394b27c22465f96e91570e`
- `r492_geometry.md`: `5d9fbf0c04ad7390e9ef285f30dd95a9b331bf0e8741fff8c662a8514a6307d3`
- `r492_proof.md`: `fb2dfe1724d80098a908694c99246b8e265ea7ada2cb532326a304dca7f3c881`
- `r492_numeric.md`: `1a536740acbcfece5050626b01cb77da00fd92d06494c9fedb6f966a0d7428d7`
- `r492_numeric.py`: `541817daf1bc43459c5bd87ed91a2c6bb9174d9637d63cfdd7aeb971af394d51`
- `r492_numeric.json`: `62510f530961a08dcb35d2912feebcad19986d3f82669ebe7ec5760a226fd576`
- `r492_replay.json`: `5fdbfa06d68fd36bbcf3905f518b0868b8b47dac1167aff601e88002acf5378f`
- `r492_history.md`: `cd894bf13bf257d8799f2202666bd743660e83dfbb6f388dc93dc6940e4d4960`
