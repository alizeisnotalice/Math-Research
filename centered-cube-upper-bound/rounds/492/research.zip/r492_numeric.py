from pathlib import Path
from fractions import Fraction as F
from itertools import combinations
import json,sys,platform,time,math
import sympy as sp
ROOT=Path(__file__).resolve().parent;start=time.perf_counter();checks=0

def ck(v):
 global checks
 assert v
 checks+=1

def st(v):return str(v)
def points(n):return [tuple(F(x) for x in p) for p in n]
def subsets(n):
 for k in range(1,n+1):yield from combinations(range(n),k)

def fixture(name,phase,dim,centers,atoms,weights):
 return dict(name=name,phase=phase,dimension=dim,centers=points(centers),sides=[F(1)]*len(centers),atoms=points(atoms),weights=list(map(F,weights)))
commoncenters=[(0,),(F(3,4),)];commonatoms=[(0,),(F(2,5),),(1,),(3,)]
fixtures=[fixture('initial_equal_mild','initial',1,commoncenters,commonatoms,[3,1,3,1]),fixture('pressure_row_boundary','pressure',1,commoncenters,commonatoms,[2,2,2,1]),fixture('pressure_mass_ratio25','pressure',1,commoncenters,commonatoms,[3,1,99,1]),fixture('expanded_two_dimensional','expanded',2,[(0,0),(F(3,4),0),(0,F(3,4))],[(0,0),(1,0),(0,1),(F(2,5),0),(0,F(2,5)),(F(2,5),F(2,5)),(3,3)],[13,14,14,1,1,1,1]),fixture('discard_overlap_too_large','discard',1,commoncenters,commonatoms,[1,3,1,1])]
records=[]
for f in fixtures:
 dim=f['dimension'];centers=f['centers'];atoms=f['atoms'];mu=f['weights'];m=len(centers);na=len(atoms)
 B=[];margins=[]
 for c,R in zip(centers,f['sides']):
  row=[]
  for x in atoms:
   ds=[abs(x[k]-c[k])-R/2 for k in range(dim)]
   ck(all(z!=0 for z in ds))
   row.append(int(all(z<0 for z in ds)));margins.append(min(abs(z) for z in ds))
  B.append(row)
 mass=[sum(mu[i]*B[j][i] for i in range(na)) for j in range(m)]
 roots=[]
 for v in mass:
  a=math.isqrt(v.numerator);b=math.isqrt(v.denominator);ck(a*a==v.numerator and b*b==v.denominator);roots.append(F(a,b))
 overlap=[[sum(mu[i]*B[j][i]*B[k][i] for i in range(na)) for k in range(m)] for j in range(m)]
 gamma=[[overlap[j][k]/(roots[j]*roots[k]) for k in range(m)] for j in range(m)]
 rowgamma=[sum(gamma[j][k] for k in range(m) if k!=j) for j in range(m)]
 common_atoms=[i for i in range(na) if all(B[j][i] for j in range(m))]
 ck(len(common_atoms)>0)
 gate=all(z<=F(1,2) for z in rowgamma)
 base=dict(name=f['name'],phase=f['phase'],dimension=dim,centers=[[st(x) for x in c] for c in centers],sides=list(map(st,f['sides'])),atoms=[[st(x) for x in x] for x in atoms],source_weights=list(map(st,mu)),capture=B,mass=list(map(st,mass)),sqrt_mass=list(map(st,roots)),overlap=[[st(x) for x in row] for row in overlap],offdiagonal_row_gamma=list(map(st,rowgamma)),minimum_strict_coordinate_margin=st(min(margins)),row_gate=gate,source_total_W=st(sum(mu)),common_captured_source_indices=common_atoms,common_x_gate=True,cloud_scope='All parents share the listed actual source atom(s); this alone does not certify original successful cloud/history.')
 if not gate:
  ck(f['phase']=='discard');base['discard_reason']='off-diagonal Gram row exceeds 1/2; no full-family allocation theorem certification';records.append(base);continue
 a=[[F(0)]*na for _ in range(m)]
 for i in range(na):
  denom=sum(F(B[j][i],1)/roots[j] for j in range(m))
  for j in range(m):a[j][i]=(F(B[j][i],1)/roots[j]/denom) if denom else F(0)
  ck(sum(a[j][i] for j in range(m))==int(denom>0))
  ck(all(a[j][i]>=0 and a[j][i]<=1 for j in range(m)))
 M=[sum(a[j][i]*mu[i] for i in range(na)) for j in range(m)]
 lower=[mass[j]/(1+rowgamma[j]) for j in range(m)]
 for j in range(m):ck(M[j]>=lower[j]);ck(lower[j]>=F(2,3)*mass[j])
 G=sum(mass);union=sum(mu[i] for i in range(na) if any(B[j][i] for j in range(m)))
 ck(sum(M)==union);ck(F(2,3)<=union/G<=1)
 halls=[]
 for sub in subsets(m):
  union_sub=sum(mu[i] for i in range(na) if any(B[j][i] for j in sub))
  target=sum(lower[j] for j in sub);ck(target<=union_sub)
  halls.append(dict(parents=list(sub),demand=st(target),union_mass=st(union_sub),slack=st(union_sub-target)))
 # Explicit flow realizes stronger per-parent demands lower_j and all source capacities.
 flow=[[a[j][i]*mu[i]*lower[j]/M[j] for i in range(na)] for j in range(m)]
 for j in range(m):ck(sum(flow[j])==lower[j]);ck(all(flow[j][i]==0 for i in range(na) if not B[j][i]))
 for i in range(na):ck(sum(flow[j][i] for j in range(m))<=mu[i])
 # Family input mass G: the subkernel has output exactly mu restricted to union.
 unnormalized_column=[sum(a[j][i] for j in range(m)) for i in range(na)]
 normalized_column=[v*G/union for v in unnormalized_column]
 for i in range(na):
  ck(unnormalized_column[i]==int(any(B[j][i] for j in range(m))))
  if unnormalized_column[i]:ck(normalized_column[i]>1)
 base.update(allocation_r=[[st(x) for x in row] for row in a],allocated_M=list(map(st,M)),strong_lower=list(map(st,lower)),family_G=st(G),union_mass=st(union),subkernel_row_mass=st(union/G),p_stop_fraction_if_input_is_p_stop=st(union/G),all_parent_subset_Hall=halls,strong_demand_flow=[[st(x) for x in row] for row in flow],demonstration_family_input_mass=st(G),input_measure_scope='G is a deliberately chosen demonstration weight, not the original stopping-flow measure.',source_column_RN_unnormalized=list(map(st,unnormalized_column)),source_column_RN_after_row_normalization=list(map(st,normalized_column)),normalization_scope='Columns compared for the same family input mass G. Subkernel row<=1 alone is not a column theorem; here exact conservation proves RN=1_union. Row-normalizing changes it to G/union>1 on union.')
 records.append(base)
# Algebra used by Jensen: sum_D I_CD/sqrt(mC*mD)=1+offdiagrow, including D=C.
z,rr=sp.symbols('z rr',positive=True)
ck(sp.simplify(1/(1+rr)-sp.Rational(2,3)) .subs(rr,sp.Rational(1,2))==0)
result=dict(scope='Finite atomic source and finite actual interval/square parents. No Lebesgue receiver, L1-source, original history, or global column-bound claim.',compute_index=dict(executable=sys.executable,python=platform.python_version(),sympy=sp.__version__,command='"'+sys.executable+'" r492_numeric.py',seconds=time.perf_counter()-start),checks=checks,retained_families=4,discarded_families=1,formula=dict(row_gate='sum_D!=C I_CD/sqrt(mC*mD)<=1/2; diagonal excluded',allocation='rC(z)=(1_QC/sqrt(mC))/sumD(1_QD/sqrt(mD))',lower='M_C>=mC/(1+rowgamma_C)>=2mC/3',subkernel='sumC rC mu/G_F=1_union mu/G_F; row=mu(union)/G_F in[2/3,1]',column='For family input mass G_F output=mu|union; row-normalizing multiplies columns by G_F/mu(union) and generally destroys this exact column conservation.'),records=records,decision='The allocation retains at least2/3 of the true p-stop row, not all successful occupation. All parent-subset Hall conditions hold for stronger lower demands and have explicit feasible flows. Row and source-column controls must be distinguished.',errors='All numbers and checks exact Fraction/SymPy. Perfect-square captured masses, hence no irrational/Arb approximation needed. Capture has strict rational margins; no grids or Monte Carlo.')
(ROOT/'r492_numeric.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS',checks,'exact assertions;4 gated geometric families,1 explicit discard;all parent-subset Hall and source columns')
