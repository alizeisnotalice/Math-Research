# R492：整族来源分配接入同一链的真实 p 次停止

沿 R491 的自然参考 \(\mathsf M\)、原实际 \(P=JH\)，保全部成功门与原记录。目标仍为 \(A_{p,N}=\sum_{j<N}\langle q_j^p,e\rangle\) 的根阶来源价。本稿检验一个机制：对**停止前一跳的实际成功族**作同时来源分配。它确实恢复固定比例的该停止质量，但所得跨代来源列尚未有根价；不将局部并集容量算成全局付款。

## 1. 同时来源分配及真实恢复量

每个实际成功记录保其筛后族 \(F_0\)，最大质量父 \(B\in F_0\)，并满足
\[
\sum_{D\in F_0\setminus\{C\}}
\gamma_{CD}\le\tfrac12,\qquad
\gamma_{CD}=\frac{\mu(Q_C\cap Q_D)}{\sqrt{m_Cm_D}}.
\]
全部父都捕获原人工来源、排斥旧来源对；该记录的历史不改变。设
\[
D_F(z)=\sum_{C\in F_0}\frac{c_C(z)}{\sqrt{m_C}},\quad
r_C^F(z)=\frac{c_C(z)/\sqrt{m_C}}{D_F(z)},\quad
G_F=\sum_{C\in F_0}m_C.
\tag{1}
\]
分母零时定义为零。对每个 \(C\)，Cauchy 给
\[
\int r_C^F\,d\mu
=\frac1{\sqrt{m_C}}\int_{Q_C}\frac{d\mu}{D_F}
\ge\frac{m_C}{1+\sum_{D\ne C}\gamma_{CD}}
\ge\frac23m_C.
\tag{2}
\]
因此联合子核
\[
\mathcal A_F(C,dz)=\frac{r_C^F(z)}{G_F}\mu(dz)
\]
的总行质量为
\[
\frac{\mu(\bigcup_{C\in F_0}Q_C)}{G_F}\in[2/3,1].
\tag{3}
\]
这是同时分配：每个来源点的列和恰为 \(1_{\cup F_0}/G_F\)，没有按父分别复制来源质量。它是附加分析子核；新 \(z\) 没有任何原历史资格。

关键是选择正确的输入流。展开实际 \(J\) 并保留原记录与 \(F_0\) 标签，随后仍按同一 \(H\) 输出状态 \(s'\)。对 \(j\ge0\) 定义正测度
\[
d\Gamma_j=q_j(s)\mathsf M(ds)\,
J(s,d\omega)H(\omega,ds')\,
q_{j+1}(s')^{p-1}e(s').
\tag{4}
\]
\(\omega\) 含最大父、lower raw 配置及成功族标签。因为 \(q_{j+1}=P^*q_j\)，
\[
|\Gamma_j|=\langle q_{j+1}^p,e\rangle.
\tag{5}
\]
这不是全部成功占用量，也没有把成功质量当成停止质量。有限 \(N\) 下令 \(\Gamma_{<N}=\sum_{j=0}^{N-2}\Gamma_j\)，并定义实际来源列
\[
\mathcal B_N(z)=\int
 \frac{1_{\cup F_0}(z)}{G_F}\,d\Gamma_{<N}.
\]
由 (3)–(5)，
\[
\boxed{A_{p,N}\le\langle1,e\rangle+
\frac32\int\mathcal B_N(z)\,d\mu(z).}
\tag{6}
\]
同时 \(\int\mathcal B_Nd\mu\le A_{p,N}-\langle1,e\rangle\)。故恢复是完整正分数而非趋零权；但仅写 (6) 不构成费用改进。

## 2. 先用真实最大父列，再估整族列

记
\[
u(z)=\int\frac{c_B(z)}{m_B}\,\nu(dB),\qquad
b_0=\frac{2rS}{T},\qquad
 a_j=\min\{1,e^{\sqrt n}b_0^j\}.
\]
此处 \(u\) 为函数；\(\nu=t\sigma\) 为原父测度。沿已证带内界 \(q_j\le a_j\)，实际最大父输出的自然参考满足 \(\mathsf M J\le\mathsf M\)，从而投影后的密度 \(h_j\le a_j\)。这只是测度支配，不声称成功后 raw 配置条件独立。

实际 \(F_0\subset\{B\}\cup F_{\rm lower}\)、\(G_F\ge m_B\)，故逐记录
\[
\frac{1_{\cup F_0}(z)}{G_F}
\le\frac{c_B(z)+\sum_{C\in F_{\rm lower}}c_C(z)}{m_B}.
\tag{7}
\]
式 (4) 的最后权不超过1；在这里才正删除停止权及其他标签。自然参考下第一项的来源列恰为 \(u(z)\)。lower 项的 Poisson 一阶矩为
\[
\frac1T\int\frac{c_C(z)}{m_C}\nu(dC)
 \int_{m_B\ge m_C}\frac{I_{BC}}{m_B^2}\nu(dB),
\qquad I_{BC}=\mu(Q_B\cap Q_C).
\tag{8}
\]
原次序与同带限制只在上界中删除。真实中心子水平容量给
\(G_x(t)=\int c_B(x)1_{m_B\le t}\nu(dB)\le rSt\)。非负层饼，包括下端原子，给
\[
\int_{m_B\ge a}\frac{c_B(x)}{m_B^2}\nu(dB)
\le\int_a^\infty\frac{2G_x(t)}{t^3}\,dt
\le\frac{2rS}{a}.
\]
再对 \(x\in Q_C\) 积分，式 (8) 的内积分至多 \(2rS\)。因此得到实际一代及累计列界
\[
\boxed{\mathcal B_N(z)\le
 (1+b_0)\left(\sum_{j=0}^{N-2}a_j\right)u(z).}
\tag{9}
\]
这保留原来源质量匹配和 Lebesgue 中心；没有密度帽。证明只用自然参考的 raw 一阶矩，上界前的 \(\Gamma_j\) 始终是原链真实测度。

## 3. 唯一尚缺的结算

令 \(\beta=\log(1/b_0)\)，则
\[
\sum_{j\ge0}a_j\le
\left\lceil\frac{\sqrt n}{\beta}\right\rceil+
\frac1{1-b_0},\qquad \int u\,d\mu=R.
\]
所以 (9) 仍仅给 \(O(\sqrt n)R\)，不是 \(O(\sqrt n)W\)。即使一代式中的 lower 项只占 \(b_0u\)，最大父项仍为 \(u\)。低 Gram 的父数量不能替代 \(G_F/m_B\) 的增长；后者没有被假定大。

当前精确缺桥是：**在 (4) 的同一实际停止权下**，证明 (7) 放松损失和跨代列重复可以共同结算，使
\[
\int\mathcal B_N\,d\mu
\le c\,A_{p,N}+\varepsilon X+C_\varepsilon\sqrt n\log^A(n+2)W,
\qquad c<2/3,
\tag{10}
\]
一致于 \(N\)，或给等效的有价比较。这里只标明充分吸收阈值，不假定 (10)。不能通过先把停止权删掉，再逐代使用 (9)，获得它。初始 \(\langle1,e\rangle\) 仍按原一次账保留。没有新增一般付款，也没有更换链后迁移旧费用。

## 4. 实际小型核验

指定本机 Python 实际运行以下代码，输出 `PASS 17 exact allocation and predecessor-stop assertions; no native-history certification`。前12项为有限来源集合的分配接口，后5项为同链停止前一跳恒等式；均不声称真实高维成功历史实例。

```python
from fractions import Fraction as F
checks=0
for k in (2,3,4):
    c=F(1,4*k)
    private=1-c
    row=(k-1)*c
    alloc=private+c/F(k)
    union=c+k*private
    G=F(k)
    assert row<=F(1,2)
    assert alloc>=1/(1+row)
    assert union/G>=F(2,3)
    assert k*alloc==union
    checks+=4
P=[[F(1,4),F(1,8),0],[0,F(1,3),F(1,6)],[0,0,F(1,5)]]
e=[1-sum(row) for row in P]
q=[F(1)]*3
for j in range(5):
    nxt=[sum(q[a]*P[a][b] for a in range(3)) for b in range(3)]
    pred=sum(q[a]*P[a][b]*nxt[b]*e[b]
             for a in range(3) for b in range(3))
    target=sum(nxt[b]**2*e[b] for b in range(3))
    assert pred==target
    q=nxt;checks+=1
print(f'PASS {checks} exact allocation and predecessor-stop assertions; '
      'no native-history certification')
```
