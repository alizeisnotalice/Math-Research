# 独立复现

先解压本包到独立目录。保持basename，使用用户指定Python环境；需要SymPy1.14.0和python-flint0.9.0，MATLAB复现另需已安装MATLAB。源代码不读取外部/tmp草稿，冻结输入均在程序内或相邻JSON中。

先核文件与记录：

```sh
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python verify.py
```

再运行独立回放（它创建临时目录、验证脚本SHA、按依赖仅运行一次四份Python，并比较数学字段；不会覆盖归档参考JSON）：

```sh
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python ccu_r569_prefix_repro.py --directory . --run --output /tmp/r569-replay.json
```

单独执行的准确命令如下。为保护参考数据，请先把脚本复制到另一个目录，再执行；certificate读取新numeric JSON。

```sh
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python ccu_r569_prefix_numeric.py --output ccu_r569_prefix_numeric.json
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python ccu_r569_prefix_certificate.py --numeric ccu_r569_prefix_numeric.json --output ccu_r569_prefix_certificate.json
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python ccu_r569_prefix_actions.py --output-prefix ccu_r569_prefix_actions
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python ccu_r569_prefix_ledger.py --output ccu_r569_prefix_ledger.json
```

MATLAB脚本通过自身位置找相邻numeric脚本及JSON。将两者与`.m`放在同一独立目录，在MATLAB执行`run('/绝对路径/ccu_r569_prefix_matlab.m')`即可；输出写相邻JSON。本轮实际使用连接工具run_matlab_file，原真实工具版本和命令在MATLAB JSON保留。不同平台计时/hash路径可变；严格证书判号与数学字段须一致。

所有显示小数均须按NUMERICS中的证据类型解释。verify.py核算现有证书的有理端点、范围和哈希，并不以有限文件检查证明一般上界。LaTeX仅作结构检查，不编译PDF。
