"""R569-B independent input audit and sequential isolated lightweight replays.

No solver or experiment design. Frozen jobs use archive-relative basenames.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import shutil
import subprocess
import sys
import tempfile
import time
from fractions import Fraction as F

import sympy as sp

# Archive basenames only. No source directory or /tmp draft is a dependency.
JOBS = [
    dict(name='numeric',script='ccu_r569_prefix_numeric.py',reference='ccu_r569_prefix_numeric.json',
         output='ccu_r569_prefix_numeric.json',arguments=['--output','{work}/ccu_r569_prefix_numeric.json'],
         script_sha256='d6942e7d88173cc5eee1b82142ef1824287b660142bbca85109b358b0df9090f',
         scope='Finite exact factored order formula / 80-digit displays; not interval or original-history certificate'),
    dict(name='certificate',script='ccu_r569_prefix_certificate.py',reference='ccu_r569_prefix_certificate.json',
         output='ccu_r569_prefix_certificate.json',
         arguments=['--numeric','{work}/ccu_r569_prefix_numeric.json','--output','{work}/ccu_r569_prefix_certificate.json'],
         script_sha256='a9b1df904695dcc71c1f5e058b91de444398ad73e1e50304ec0b04bf22be14b0',
         scope='Independent closed record/collision and Arb finite-model certificate'),
    dict(name='actions',script='ccu_r569_prefix_actions.py',reference='ccu_r569_prefix_actions.json',
         output='ccu_r569_prefix_actions.json',arguments=['--output-prefix','{work}/ccu_r569_prefix_actions'],
         script_sha256='c068e066506fe25bc19a2ce5479f287118ea453b23ba72a74f02607de7cf1e09',
         scope='Independent finite continuous-action collapse and strict-threshold certificate'),
    dict(name='ledger',script='ccu_r569_prefix_ledger.py',reference='ccu_r569_prefix_ledger.json',
         output='ccu_r569_prefix_ledger.json',arguments=['--output','{work}/ccu_r569_prefix_ledger.json'],
         script_sha256='b2b763b69b29bbb28890b390f5671f41690558fc3a3707a4a177dcfdc8eba0b2',
         scope='Exact symbolic conditional ledger and rational fixture; not finite geometry'),
]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def input_audit():
    L2, L3 = sp.symbols('L2 L3', real=True)
    positions = [F(0), F(3, 4), F(3, 2)]
    centers = [F(0), F(3, 4)]
    rows = []
    model_inputs=[(n,w) for n in (2,3) for w in ([1,1,1],[1,2,1])]
    # Sole extra pressure input authorized by root; no further search.
    model_inputs.append((2,[1,1,0]))
    for n,weights in model_inputs:
            masks = []
            boundaries = []
            for center in centers:
                # All source and parent coordinates have the same listed value.
                distances = [2 * abs(x-center) for x in positions]
                boundaries.append(sorted({str(d**n) for d in distances if F(1) <= d <= F(2)}))
                masks.append({str(side): [j for j,d in enumerate(distances) if d <= side]
                              for side in (F(1),F(5,4),F(3,2),F(7,4),F(2))})
            assert masks[0]['1'] == masks[0]['5/4'] == [0]
            assert masks[0]['3/2'] == masks[0]['7/4'] == masks[0]['2'] == [0,1]
            assert masks[1]['1'] == masks[1]['5/4'] == [1]
            assert masks[1]['3/2'] == masks[1]['7/4'] == masks[1]['2'] == [0,1,2]
            early = 1+n*(L3-L2)       # g=1 atom + integral_1^entry dg/g
            late = 1+n*(2*L2-L3)      # integral_entry^G dg/g + g=G atom
            lam = 2+n*L2
            assert sp.expand(early+late-lam) == 0
            states=[]
            parent_formulae=[]
            for b,(old,new,mask0,mask1) in enumerate([
                (weights[0],weights[0]+weights[1],[0],[0,1]),
                (weights[1],sum(weights),[1],[0,1,2])]):
                kap=sp.Rational(new,old)
                I=early+late/kap
                rho0=early/I;rho1=late/(kap*I)
                a=sp.Rational(1,4)*(1 if b==0 else sp.Rational(1,2))
                assert sp.cancel(rho0+rho1-1)==0
                assert sp.cancel(a*(old*rho0+new*rho1)-lam*a*old/I)==0
                parent_formulae.append(dict(parent=b,old_mass=old,late_mass=new,
                    kappa_late=str(kap),I=str(I),rho_early=str(rho0),rho_late=str(rho1),
                    finite_parent_measure_weight='1/4',t='1' if b==0 else '1/2',a=str(a)))
                states.extend([dict(parent=b,mass=old,mask=mask0),dict(parent=b,mass=new,mask=mask1)])
            batches=[]
            for mass in sorted({v['mass'] for v in states}):
                ids=[i for i,v in enumerate(states) if v['mass']==mass]
                overlap=[(i,j) for ii,i in enumerate(ids) for j in ids[ii+1:]
                         if any(weights[x]>0 for x in set(states[i]['mask']) & set(states[j]['mask']))]
                batches.append(dict(mass=mass,states=ids,overlapping_support_pairs=overlap))
            rows.append(dict(n=n,weights=weights,G=str(2**n),entry=str(F(3,2)**n),
                inclusion_masks_by_side=masks,action_breakpoints=boundaries,
                parents=parent_formulae,mass_batches=batches,
                zero_weight_locations=[i for i,w in enumerate(weights) if w==0],
                overlapping_same_mass_batch_pressure_activated=any(
                    x['overlapping_support_pairs'] for x in batches)))
    return dict(status='PASS_input_conditions_with_explicit_scope_limits',models=rows,
        exact_checks=dict(cube_inclusions=True,actual_source_masses_and_kappa=True,
            both_action_endpoint_atoms_included=True,continuous_action_mass_normalizes=True,
            source_hazard_identity=True,entry_point_has_no_continuous_action_atom=True),
        startup_rule='A_u(x)>s starts; equality A_u(x)=s stays low; zero s permits only positive hazard',
        limitations=[
            'Atomic sources, not a positive Lebesgue L1 source.',
            'Two weighted parent atoms are quadrature, not original parent Lebesgue integration.',
            'Action collapse preserves finite source masks, masses and rate law only; actual geometric cubes differ inside each interval.',
            'No physical old Li/sigma/history/head/stop/core/full-restoration/mother certificate follows.',
            'Common race labels are an analysis dictionary, never replacements for physical B or C.',
            'The original four positive-weight models do not activate overlapping same-mass pressure; the authorized fifth 110 model does.',
            'The fifth model third location has zero mass; its unweighted pair checks are algebra only, not positive source demands.'
        ])


def semantic(value):
    """Only declared volatile metadata is removed; mathematical fields retained."""
    if isinstance(value,dict):
        out={}
        for k,v in value.items():
            low=k.lower()
            if ('sha256' in low or low.endswith('_path') or low.endswith('_directory')
                    or low in {'seconds','elapsed_seconds','runtime_seconds',
                    'wall_time_seconds','maxrss_bytes','peak_rss_bytes','command','python_executable'}):
                continue
            out[k]=semantic(v)
        return out
    if isinstance(value,list): return [semantic(v) for v in value]
    return value


def differences(a,b,path=''):
    if type(a) is not type(b): return [path+':type']
    if isinstance(a,dict):
        ans=[]
        for k in sorted(set(a)|set(b)):
            if k not in a or k not in b: ans.append(path+'/'+k+':missing')
            else: ans.extend(differences(a[k],b[k],path+'/'+k))
        return ans
    if isinstance(a,list):
        if len(a)!=len(b): return [path+':length']
        return [d for i,(x,y) in enumerate(zip(a,b)) for d in differences(x,y,path+f'/{i}')]
    return [] if a==b else [path]


def replay(job,directory,work):
    source=directory/job['script'];reference=directory/job['reference']
    actualsha=sha(source)
    if job['script_sha256'] is None:
        raise RuntimeError('Owner has not frozen script hash: '+job['name'])
    if actualsha!=job['script_sha256']:
        raise RuntimeError('Frozen script hash changed: '+str(source))
    copied=work/source.name
    shutil.copy2(source,copied)
    for item in job.get('inputs',[]):
        original=directory/item['source']
        if sha(original)!=item['sha256']:
            raise RuntimeError('Frozen input hash changed: '+str(original))
        shutil.copy2(original,work/item['target'])
    args=[str(x).replace('{work}',str(work)) for x in job.get('arguments',[])]
    command=[sys.executable,str(copied),*args]
    env=os.environ.copy()
    for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):env[k]='1'
    start=time.perf_counter()
    proc=subprocess.run(command,cwd=work,env=env,text=True,capture_output=True,
                        timeout=job.get('timeout_seconds',300))
    (work/(job['name']+'_stdout.txt')).write_text(proc.stdout)
    (work/(job['name']+'_stderr.txt')).write_text(proc.stderr)
    out=work/job['output']
    result=dict(name=job['name'],workdir=str(work),command=command,
        script_sha256=actualsha,reference_sha256=sha(reference),exit_code=proc.returncode,
        elapsed_seconds=time.perf_counter()-start,stderr=proc.stderr,
        scope=job['scope'])
    if proc.returncode!=0: raise RuntimeError(json.dumps(result,ensure_ascii=False))
    observed=json.loads(out.read_text());expected=json.loads(reference.read_text())
    diff=differences(semantic(observed),semantic(expected))
    result.update(output_sha256=sha(out),semantic_match=not diff,
                  difference_paths=diff[:100],output=str(out),
                  reported_versions=observed.get('versions',{}))
    return result


def external_outputs(directory):
    result={}
    for name in ('numeric','certificate','actions','ledger','matlab'):
        path=directory/f'ccu_r569_prefix_{name}.json'
        if not path.exists(): continue
        data=json.loads(path.read_text())
        record=dict(reference_json=path.name,reference_sha256=sha(path),scope=data.get('scope'))
        record['versions']=data.get('versions',{k:data[k] for k in
            ('python','sympy','flint','arb_precision_bits','matlab_version','matlab_release') if k in data})
        record['checks']=data.get('checks',data.get('symbolic_checks',{}))
        if name=='numeric':
            record['evidence_label']='Exact factored order/rate expressions; 80-digit comparisons are not interval enclosures'
            record['pressure_serial_extra']=[dict(s=x['s'],display=x['serial_extra_price_display'])
                for x in data['models'][-1]['thresholds']]
        elif name=='certificate':
            record.update(evidence_label='192-bit Arb outward bounds plus exact symbolic batch formula; no order enumeration',
                model_count=data['model_count'],pair_checks=data['ordered_prefix_pair_checks'],
                exact_equality_low_cases=data['nonempty_exact_startup_equalities'],
                diagnostic_tolerance=data['author_display_tolerance'])
        elif name=='actions':
            record['evidence_label']='256-bit Arb rate/gap endpoints and exact equality-first decisions'
        elif name=='ledger':
            record['evidence_label']='Exact symbolic algebra; decimal fixture display is not an interval or geometric certificate'
        else:
            record.update(evidence_label='Actual MATLAB tool output checked only; double precision, not a rigorous certificate',
                actual_tool_command=data['command'],not_rerun_by_reviewer=True,
                actual_tool_numeric_sha256=data['python_json_sha256'],
                same_frozen_numeric_input=(data['python_json_sha256']==sha(directory/'ccu_r569_prefix_numeric.json')),
                script_sha256=data['script_sha256'])
            for suffix in ('.m','.md'):
                companion=directory/('ccu_r569_prefix_matlab'+suffix)
                if companion.exists():record['companion'+suffix+'_sha256']=sha(companion)
            note=directory/'ccu_r569_prefix_matlab.md'
            if note.exists():
                found=re.search(r'```text\n(MATLAB_VERSION=.*?)\n```',note.read_text(),re.S)
                if found:
                    tooltext=found.group(1)+'\n'
                    record['verified_tool_output_text_sha256']=hashlib.sha256(tooltext.encode()).hexdigest()
                    record['actual_tool_text_matches_recorded_script_hash']=(
                        'SCRIPT_SHA256='+data['script_sha256']) in tooltext
                    record['actual_tool_text_matches_numeric_input_hash']=(
                        'PYTHON_JSON_SHA256='+data['python_json_sha256']) in tooltext
        result[name]=record
    return result


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--run',action='store_true')
    parser.add_argument('--directory',type=Path,default=Path(__file__).resolve().parent,
                        help='Frozen sibling scripts/JSON/index directory')
    parser.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'))
    args=parser.parse_args()
    directory=args.directory.resolve();output=args.output
    index=directory/'ccu_r569_prefix_compute_index.json'
    prior=json.loads(output.read_text()) if output.exists() else {}
    payload=dict(schema='R569.prefix.independent_repro.1',input_audit=input_audit(),
        versions=dict(python=platform.python_version(),sympy=sp.__version__,executable=sys.executable),
        code_sha256=sha(__file__),compute_index_sha256=sha(index) if index.exists() else None,
        replays=prior.get('replays',[]),external_outputs=external_outputs(directory),
        comparison_policy='Remove SHA metadata, paths/commands, elapsed time and peak RSS only; retain mathematical data and precision labels',
        status=prior.get('status','input_audit_complete_waiting_frozen_owner_outputs'))
    if 'independent_directory' in prior:payload['independent_directory']=prior['independent_directory']
    if args.run:
        if any(job['script_sha256'] is None for job in JOBS):
            raise RuntimeError('Not all required owner scripts have frozen hashes')
        work=Path(tempfile.mkdtemp(prefix='ccu_r569_prefix_repro_'))
        payload['independent_directory']=str(work)
        payload['replays']=[replay(job,directory,work) for job in JOBS]
        payload['status']='PASS_replays' if all(x['semantic_match'] for x in payload['replays']) else 'MISMATCH_replays'
    output.write_text(json.dumps(payload,indent=2,ensure_ascii=False))
    print(json.dumps(dict(status=payload['status'],models=len(payload['input_audit']['models']),
                         replays=len(payload['replays'])),ensure_ascii=False))


if __name__=='__main__':main()
