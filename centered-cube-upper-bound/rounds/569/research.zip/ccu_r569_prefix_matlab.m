% R569-B independent finite Exp-order floating cross-check, no simulation.
% All geometry and rates below are reconstructed from the frozen input.
clear;
tStart = tic;
artifactDirectory = fileparts(mfilename('fullpath'));
pythonPath = fullfile(artifactDirectory,'ccu_r569_prefix_numeric.json');
assert(isfile(pythonPath), 'Await the frozen Python output; do not rerun it.');
py = jsondecode(fileread(pythonPath));
sources = [0, 3/4, 3/2];
centers = [0, 3/4];
parentRate = [1/4, 1/8]; % quadrature weight times t / R^n
thresholds = [0, 1/32, 1/8, 1/4];
weightsList = [1,1,1; 1,2,1; 1,1,0];
modelCases = [2,1;2,2;3,1;3,2;2,3]; % four primary cases plus authorized tie test
orders = sortrows(perms(1:4));
maxError = 0;
maxProbabilityResidual = 0;
maxCollisionResidual = 0;
priceMismatch = 0;
clusterMismatch = 0;
boundaryCount = 0;
models = struct([]);
modelIndex = 0;
for caseIndex = 1:size(modelCases,1)
        n = modelCases(caseIndex,1);
        wIndex = modelCases(caseIndex,2);
        modelIndex = modelIndex + 1;
        weights = weightsList(wIndex,:);
        entry = (3/2)^n;
        G = 2^n;
        masks = false(4,3);
        rates = zeros(1,4);
        masses = zeros(1,4);
        rho = zeros(1,4);
        for b = 1:2
            % Radius is g^(1/n)/2. Distances are identical in every coordinate.
            oldMask = abs(sources-centers(b)) <= 1/2;
            newMask = abs(sources-centers(b)) <= 3/4;
            oldMass = sum(weights(oldMask));
            newMass = sum(weights(newMask));
            kappa = newMass/oldMass;
            earlyIntegral = 1 + log(entry); % includes the atom at g=1
            lateIntegral = (1 + log(G/entry))/kappa; % atom at g=G
            I = earlyIntegral + lateIntegral;
            ids = 2*b-1:2*b;
            rho(ids) = [earlyIntegral,lateIntegral]/I;
            rates(ids) = parentRate(b)*rho(ids);
            masks(ids,:) = [oldMask;newMask];
            masses(ids) = [oldMass,newMass];
        end
        levels = unique(masses);
        probability = zeros(24,1);
        for k = 1:24
            o = orders(k,:);
            factors = zeros(1,4);
            for j = 1:4
                factors(j) = rates(o(j))/sum(rates(o(j:4)));
            end
            probability(k) = prod(factors);
        end
        maxProbabilityResidual = max(maxProbabilityResidual,abs(sum(probability)-1));
        pm = py.models(modelIndex);
        assert(pm.n == n && isequal(cellfun(@str2double,pm.weights(:))',weights));
        referenceRates = arrayfun(@(i) str2double(pm.rate_displays{i}),1:4);
        maxError = max(maxError,max(abs(rates-referenceRates)));
        resultThresholds = struct([]);
        for si = 1:4
            s = thresholds(si);
            perOrder = struct([]);
            prices = zeros(24,1);
            serialPrices = zeros(24,1);
            for k = 1:24
                o = orders(k,:);
                ever = false(4,3);
                previous = zeros(1,3);
                opened = false(1,4);
                winners = zeros(numel(levels),3);
                for li = 1:numel(levels)
                    opened = opened | masses == levels(li); % one whole batch
                    for x = 1:3
                        active = opened & masks(:,x)';
                        A = sourceHazard(active,rates,parentRate);
                        if A == s
                            boundaryCount = boundaryCount + 1;
                        end
                        if A > s
                            winner = o(find(active(o),1));
                            winners(li,x) = winner;
                            if previous(x) ~= winner
                                ever(winner,x) = true;
                            end
                            previous(x) = winner;
                        end
                    end
                end
                prices(k) = sum(ever*weights');
                serialPrices(k) = serialPrice(o,masks,rates,parentRate,masses,weights,s);
                perOrder(k).order = o-1;
                perOrder(k).probability = probability(k);
                perOrder(k).price = prices(k);
                perOrder(k).serial_batch_price = serialPrices(k);
                perOrder(k).clusters = arrayfun(@(j) find(ever(j,:))-1,1:4,'UniformOutput',false);
                perOrder(k).prefix_winners_matlab_labels = winners;
                pr = pm.thresholds(si).orders(k);
                assert(isequal(pr.order(:)',o-1));
                maxError = max(maxError,abs(probability(k)-str2double(pr.probability_display)));
                priceMismatch = priceMismatch + (prices(k) ~= str2double(pr.price));
                priceMismatch = priceMismatch + (serialPrices(k) ~= str2double(pr.serial_batch_price));
                for j = 1:4
                    referenceCluster = jsonCluster(pr.clusters,j);
                    clusterMismatch = clusterMismatch + ~isequal(perOrder(k).clusters{j}(:),referenceCluster(:));
                end
            end
            expectedPrice = probability'*prices;
            serialExtra = probability'*(serialPrices-prices);
            maxError = max(maxError,abs(expectedPrice-str2double(pm.thresholds(si).expected_price_display)));
            maxError = max(maxError,abs(serialExtra-str2double(pm.thresholds(si).serial_extra_price_display)));
            prefixResult = struct([]);
            allLevels = [0,levels];
            for li = 1:numel(allLevels)
                opened = masses <= allLevels(li);
                active = masks & opened';
                A = arrayfun(@(x) sourceHazard(active(:,x)',rates,parentRate),1:3);
                started = A > s;
                hit = zeros(3,3);
                closed = zeros(3,3);
                different = zeros(3,3);
                low = ones(3,3);
                for y = 1:3
                    for z = 1:3
                        if started(y) && started(z)
                            low(y,z) = 0;
                            for k = 1:24
                                o = orders(k,:);
                                wy = o(find(active(o,y),1));
                                wz = o(find(active(o,z),1));
                                hit(y,z) = hit(y,z) + probability(k)*(wy == wz);
                            end
                            unionMask = active(:,y) | active(:,z);
                            intersectionMask = active(:,y) & active(:,z);
                            closed(y,z) = sum(rates(intersectionMask))/sum(rates(unionMask));
                            different(y,z) = 1-hit(y,z);
                        end
                        ppair = pm.thresholds(si).prefixes(li).pairs((y-1)*3+z);
                        maxError = max(maxError,abs(hit(y,z)-str2double(ppair.hit_display)));
                        maxError = max(maxError,abs(different(y,z)-str2double(ppair.exclusive_display)));
                        maxError = max(maxError,abs(low(y,z)-str2double(ppair.startup_failure)));
                    end
                end
                maxProbabilityResidual = max(maxProbabilityResidual,max(abs(hit+different+low-1),[],'all'));
                maxCollisionResidual = max(maxCollisionResidual,max(abs(hit-closed),[],'all'));
                assert(isequal(started(:),pm.thresholds(si).prefixes(li).startup_success(:)));
                refA = cellfun(@str2double,pm.thresholds(si).prefixes(li).A_display(:))';
                maxError = max(maxError,max(abs(A-refA)));
                prefixResult(li).mass = allLevels(li);
                prefixResult(li).hazards = A;
                prefixResult(li).startup_success = started;
                prefixResult(li).same_winner_enumeration = hit;
                prefixResult(li).same_winner_closed_formula = closed;
                prefixResult(li).different_winner = different;
                prefixResult(li).startup_failure = low;
            end
            resultThresholds(si).s = s;
            resultThresholds(si).expected_price = expectedPrice;
            resultThresholds(si).serial_extra_price = serialExtra;
            resultThresholds(si).orders = perOrder;
            resultThresholds(si).prefixes = prefixResult;
        end
        models(modelIndex).n = n;
        models(modelIndex).weights = weights;
        models(modelIndex).rates = rates;
        models(modelIndex).rho = rho;
        models(modelIndex).masks = masks;
        models(modelIndex).masses = masses;
        models(modelIndex).mass_levels = levels;
        models(modelIndex).thresholds = resultThresholds;
end
assert(priceMismatch == 0 && clusterMismatch == 0);
assert(maxError < 1e-12 && maxProbabilityResidual < 1e-12 && maxCollisionResidual < 1e-12);
out.schema = 'R569.prefix.MATLAB.float.1';
out.scope = 'Independent finite floating enumeration only; no continuous-parent, history, or original theorem certificate';
out.matlab_version = version;
out.matlab_release = version('-release');
out.execution_directory = artifactDirectory;
out.command = sprintf('mcp__matlab__run_matlab_file({script_path:%s})',fullfile(artifactDirectory,'ccu_r569_prefix_matlab.m'));
out.script_sha256 = fileHash(fullfile(artifactDirectory,'ccu_r569_prefix_matlab.m'));
out.python_json_sha256 = fileHash(pythonPath);
out.python_script_sha256 = fileHash(fullfile(artifactDirectory,'ccu_r569_prefix_numeric.py'));
out.models = models;
out.checks.max_absolute_python_error = maxError;
out.checks.max_probability_conservation_residual = maxProbabilityResidual;
out.checks.max_collision_formula_residual = maxCollisionResidual;
out.checks.per_order_price_mismatches = priceMismatch;
out.checks.per_order_cluster_mismatches = clusterMismatch;
out.checks.exact_double_boundary_visits = boundaryCount;
out.seconds = toc(tStart);
fid = fopen(fullfile(artifactDirectory,'ccu_r569_prefix_matlab.json'),'w');
assert(fid >= 0);
fprintf(fid,'%s\n',jsonencode(out,PrettyPrint=true));
fclose(fid);
fprintf('MATLAB_VERSION=%s\n',out.matlab_version);
fprintf('MODELS=%d ORDERS_PER_MODEL=24 THRESHOLDS=4\n',numel(models));
fprintf('MAX_ABSOLUTE_PYTHON_ERROR=%.17g\n',maxError);
fprintf('MAX_PROBABILITY_RESIDUAL=%.17g\n',maxProbabilityResidual);
fprintf('MAX_COLLISION_RESIDUAL=%.17g\n',maxCollisionResidual);
fprintf('PRICE_MISMATCHES=%d CLUSTER_MISMATCHES=%d BOUNDARY_VISITS=%d\n',priceMismatch,clusterMismatch,boundaryCount);
fprintf('SCRIPT_SHA256=%s\nPYTHON_JSON_SHA256=%s\n',out.script_sha256,out.python_json_sha256);
fprintf('SECONDS=%.6f\n',out.seconds);

function A = sourceHazard(active,rates,parentRate)
% Full-parent rates are exact dyadic constants. This preserves A=s ties.
A = 0;
for b = 1:2
    ids = 2*b-1:2*b;
    if all(active(ids))
        A = A + parentRate(b);
    else
        A = A + sum(rates(ids(active(ids))));
    end
end
end

function price = serialPrice(order,masks,rates,parentRate,masses,weights,s)
% Deliberately wrong serial reveal, kept only as the batch-pressure diagnostic.
[~,sequence] = sortrows([masses(:),(1:4)']);
opened = false(1,4);
previous = zeros(1,3);
ever = false(4,3);
for j = sequence'
    opened(j) = true;
    for x = 1:3
        active = opened & masks(:,x)';
        if sourceHazard(active,rates,parentRate) > s
            winner = order(find(active(order),1));
            if previous(x) ~= winner
                ever(winner,x) = true;
            end
            previous(x) = winner;
        end
    end
end
price = sum(ever*weights');
end

function h = fileHash(path)
fid = fopen(path,'rb');
assert(fid >= 0);
bytes = fread(fid,Inf,'*uint8');
fclose(fid);
md = java.security.MessageDigest.getInstance('SHA-256');
md.update(bytes);
h = lower(reshape(dec2hex(typecast(md.digest(),'uint8'),2)',1,[]));
end

function c = jsonCluster(clusters,j)
% JSON regular nested arrays decode as numeric matrices, ragged arrays as cells.
if iscell(clusters)
    c = double(clusters{j});
else
    c = double(clusters(j,:));
end
end
