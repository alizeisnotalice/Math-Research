#!/usr/bin/env python3
"""R569-B exact mass-batch after-hazard certificate; no order enumeration."""
from pathlib import Path
from fractions import Fraction as F
from functools import lru_cache
from hashlib import sha256
import argparse,json,platform
import sympy as sp
import flint
from flint import arb,ctx
ctx.prec=192
X=sp.Symbol('x',positive=True);L2,L3=sp.symbols('L2 L3',real=True)
RR=sp.symbols('r0:4',positive=True)

def sf(v):return sp.Rational(str(v))
def af(v):
    v=sp.Rational(v)
    return arb(int(v.p))/int(v.q)
def cancel(v):return sp.cancel(v)
def bounds(v):return F(str(v.lower().fmpq())),F(str(v.upper().fmpq()))
def pack(v):
    if isinstance(v,(sp.Basic,F)):return str(v)
    if isinstance(v,dict):return {str(k):pack(x) for k,x in v.items()}
    if isinstance(v,(tuple,list)):return [pack(x) for x in v]
    return v

def interval(v):
    lo,hi=bounds(v)
    return dict(lower_exact=str(lo),upper_exact=str(hi),approximate_display=float(v.mid()))

@lru_cache(None)
def parse_author(text,n):
    expr=sp.sympify(text,locals={'L2':L2,'L3':L3,**{str(r):r for r in RR}})
    # Solve x=(1+n(L3-L2))/(1+n(2L2-L3)); all race quantities
    # depend only on x, so the remaining L2 cancels identically.
    return cancel(expr.subs(L3,L2+(X*(1+n*L2)-1)/(n*(X+1))))

def polynomial_value(p,x):
    out=arb(0)
    for coeff in sp.Poly(p,X).all_coeffs():out=out*x+af(coeff)
    return out

class Model:
    def __init__(self,n,weights):
        self.n=n;self.w=list(map(sf,weights));self.G=sp.Integer(2)**n;self.entry=sp.Rational(3,2)**n
        self.E=1+af(self.entry).log();self.T=1+af(self.G/self.entry).log();self.x=self.E/self.T
        assert self.E>0 and self.T>0
        self.mass=[];self.masks=[];self.rates=[];self.parent=[];self.geometry=[]
        positions=[sp.Rational(0),sp.Rational(3,4),sp.Rational(3,2)]
        for b in range(2):
            center=sp.Rational(3,4)*b;a=sp.Rational(1,4)/(2**b)
            early=[i for i,v in enumerate(positions) if abs(v-center)<=sp.Rational(1,2)]
            late=[i for i,v in enumerate(positions) if abs(v-center)<=1]
            entries=[(2*abs(v-center))**n for v in positions]
            assert all(v in [0,self.entry] or v>self.G for v in entries)
            m0=sum(self.w[i] for i in early);m1=sum(self.w[i] for i in late);k=m1/m0
            self.geometry.append(dict(parent=b,center_diagonal=center,source_entry_h=entries,early_mask=early,late_mask=late,old_mass=m0,late_mass=m1,kappa=k,base_rate=a))
            for kind,mask,m,r in [('early',early,m0,a*k*X/(k*X+1)),('late',late,m1,a/(k*X+1))]:
                self.parent.append(b);self.mass.append(m);self.masks.append(set(mask));self.rates.append(cancel(r))
        self.levels=sorted(set(self.mass));self.cache={}
    def value(self,expr):
        expr=cancel(expr)
        if expr not in self.cache:
            if expr.is_Rational:self.cache[expr]=af(expr)
            else:
                num,den=sp.fraction(expr)
                nv=polynomial_value(num,self.x);dv=polynomial_value(den,self.x)
                assert not dv.contains(0)
                self.cache[expr]=nv/dv
        return self.cache[expr]
    def strict_start(self,A,s):
        delta=cancel(A-s)
        if delta==0:return False,'exact equality: low'
        v=self.value(delta)
        if v>0:return True,'strict positive Arb separation'
        if v<0:return False,'strict negative Arb separation'
        raise ArithmeticError('Startup comparison not certified: '+str(delta))
    def active(self,u,z):return {i for i,m in enumerate(self.mass) if m<=u and z in self.masks[i]}
    def hazard(self,S):return cancel(sum((self.rates[i] for i in S),sp.Integer(0)))
    def run(self,s):
        counts=[];label_probs=[];start_rows=[]
        for z in range(3):
            started=False;startmass=None;row=[];probs=[sp.Integer(0)]*4;extra=sp.Integer(0)
            for u in self.levels:
                S=self.active(u,z);A=self.hazard(S);yes,why=self.strict_start(A,s)
                row.append(dict(mass=u,A=A,A_interval=interval(self.value(A)),success=yes,decision=why))
                if yes and not started:
                    started=True;startmass=u
                    for i in S:probs[i]=cancel(self.rates[i]/A)
                elif yes:
                    new={i for i in S if self.mass[i]==u}
                    extra+=sum((self.rates[i] for i in new),sp.Integer(0))/A
                    for i in new:probs[i]=cancel(self.rates[i]/A)
            count=cancel(sum(probs,sp.Integer(0)))
            assert cancel(count-(1+extra if started else 0))==0
            counts.append(count);label_probs.append(probs);start_rows.append(dict(source=z,start_mass=startmass,batches=row))
        price=cancel(sum((w*c for w,c in zip(self.w,counts)),sp.Integer(0)))
        prefixes=[]
        for u in [sp.Integer(0)]+self.levels:
            sets=[self.active(u,z) for z in range(3)];A=[self.hazard(S) for S in sets]
            started=[self.strict_start(a,s)[0] for a in A];pairs=[]
            for y in range(3):
                for z in range(3):
                    J=self.hazard(sets[y]&sets[z]);both=started[y] and started[z]
                    hit=cancel(J/(A[y]+A[z]-J)) if both else sp.Integer(0)
                    exclusive=cancel(1-hit) if both else sp.Integer(0);startup=0 if both else 1
                    assert cancel(hit+exclusive+startup-1)==0
                    pairs.append(dict(y=y,z=z,J=J,hit=hit,exclusive=exclusive,startup_failure=startup,hit_interval=interval(self.value(hit))))
            prefixes.append(dict(mass=u,active=[sorted(S) for S in sets],A=A,startup_success=started,pairs=pairs))
        finalA=[self.hazard(self.active(self.levels[-1],z)) for z in range(3)]
        H=cancel(sum((w*a for w,a in zip(self.w,finalA)),sp.Integer(0)))
        W=sum(self.w)
        bound=None
        if s>0:
            bound=af(W)*(1+(1+self.value(H)/af(s*W)).log())
            assert self.value(price).upper()<bound.lower()
        return dict(s=s,record_count_by_source=counts,record_label_probabilities=label_probs,expected_price=price,expected_price_interval=interval(self.value(price)),source_start_batches=start_rows,prefixes=prefixes,Jensen_bound_interval=None if bound is None else interval(bound)),H


def serial_counterfactual(model,s):
    """Wrong sequential opening, evaluated only to quantify its pressure error."""
    counts=[]
    for z in range(3):
        S=set();begun=False;count=sp.Integer(0)
        for i in sorted(range(4),key=lambda i:(model.mass[i],i)):
            if z not in model.masks[i]:continue
            S.add(i);A=model.hazard(S);yes,_=model.strict_start(A,s)
            if yes and not begun:count=sp.Integer(1);begun=True
            elif yes:count+=model.rates[i]/A
        counts.append(cancel(count))
    return cancel(sum((w*c for w,c in zip(model.w,counts)),sp.Integer(0)))


def display_difference(expr,display,model):
    # The author's display is a decimal value, not an outward interval.
    # Report an explicit comparison tolerance, without certifying that display.
    shown=sf(display);delta=model.value(expr)-af(shown);lo,hi=bounds(delta)
    error=max(abs(lo),abs(hi));assert error<F(1,10**45)
    return str(error)


def main(numeric_path):
    author=json.loads(numeric_path.read_text());raw=author['input']
    assert list(map(sf,raw['source_positions_diagonal']))==[0,sp.Rational(3,4),sp.Rational(3,2)]
    thresholds=list(map(sf,raw['thresholds']));assert thresholds==[0,sp.Rational(1,32),sp.Rational(1,8),sp.Rational(1,4)]
    allowed=[(2,(1,1,1)),(2,(1,2,1)),(3,(1,1,1)),(3,(1,2,1)),(2,(1,1,0))]
    actual=[(int(v['n']),tuple(int(sf(w)) for w in v['weights'])) for v in author['models']]
    assert actual==allowed
    results=[];pair_count=0;nonempty_equalities=[]
    for given in author['models']:
        n=int(given['n']);weights=list(map(sf,given['weights']));m=Model(n,weights)
        assert m.G==sf(given['G']) and m.entry==sf(given['entry_threshold'])
        assert [dict(mass=u,states=[i for i,v in enumerate(m.mass) if v==u]) for u in m.levels]==[dict(mass=sf(b['mass']),states=b['states']) for b in given['mass_batches']]
        for i,g in enumerate(given['states']):
            assert m.mass[i]==sf(g['mass']) and sorted(m.masks[i])==g['mask']
            assert cancel(m.rates[i]-parse_author(g['rate'],n))==0
            assert m.value(m.rates[i])>0
        runs=[]
        for s,g in zip(thresholds,given['thresholds']):
            assert s==sf(g['s']);out,H=m.run(s)
            # Independent hazard identity in x. E+T=Lambda, and I=E+T/k.
            rhs=cancel(sum((v['base_rate']*v['old_mass']*(X+1)/(X+1/v['kappa']) for v in m.geometry),sp.Integer(0)))
            assert cancel(H-rhs)==0 and cancel(H-parse_author(given['source_hazard_integral'],n))==0
            out['author_price_display_difference_upper']=display_difference(out['expected_price'],g['expected_price_display'],m)
            for p,q in zip(out['prefixes'],g['prefixes']):
                assert p['mass']==sf(q['mass']) and p['active']==q['active'] and p['startup_success']==q['startup_success']
                for z,(A,authorA) in enumerate(zip(p['A'],q['A'])):
                    assert cancel(A-parse_author(authorA,n))==0
                    if A!=0 and cancel(A-s)==0:nonempty_equalities.append(dict(n=n,weights=weights,s=s,mass=p['mass'],source=z,decision='low'))
                for a,b in zip(p['pairs'],q['pairs']):
                    assert (a['y'],a['z'])==(b['y'],b['z'])
                    for key in ['J','hit','exclusive','startup_failure']:
                        assert cancel(a[key]-parse_author(str(b[key]),n))==0
                    pair_count+=1
            if weights==[1,1,0]:
                serial=serial_counterfactual(m,s);extra=cancel(serial-out['expected_price'])
                value=m.value(extra)
                assert extra==0 or value>0
                out['wrong_serial_pressure']=dict(expected_price=serial,extra_price=extra,extra_interval=interval(value),author_extra_display_difference_upper=display_difference(extra,g['serial_extra_price_display'],m),is_correct_model=False)
            runs.append(out)
        results.append(dict(n=n,weights=weights,G=m.G,entry=m.entry,geometry=m.geometry,positive_ratio_x_interval=interval(m.x),rate_expressions=m.rates,rate_intervals=[interval(m.value(r)) for r in m.rates],thresholds=runs))
    return pack(dict(schema='R569.prefix.certificate.1',scope='Five frozen atomic-source / finite-parent-quadrature proposal models only; record prices and prefix hit/startup, not original continuous parent/history/Li or global weighted invoice',method='after-hazard mass-batch formula and exact rational functions of x; no clock-order enumeration or author-function imports',python=platform.python_version(),sympy=sp.__version__,flint=flint.__version__,arb_precision_bits=ctx.prec,numeric_json_sha256=sha256(numeric_path.read_bytes()).hexdigest(),code_sha256=sha256(Path(__file__).resolve().read_bytes()).hexdigest(),author_display_tolerance='1e-45 (comparison only; not an interval claim for author decimals)',all_checks_pass=True,model_count=len(results),ordered_prefix_pair_checks=pair_count,nonempty_exact_startup_equalities=nonempty_equalities,results=results))


if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--numeric',type=Path,default=Path(__file__).resolve().parent/'numeric.json');ap.add_argument('--output',type=Path)
    args=ap.parse_args();text=json.dumps(main(args.numeric),indent=2)+'\n'
    if args.output:args.output.write_text(text)
    print(text,end='')
