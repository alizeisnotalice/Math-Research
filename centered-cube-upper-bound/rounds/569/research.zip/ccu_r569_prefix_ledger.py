#!/usr/bin/env python3
"""R569-B bounded symbolic ledger; no scan, sampling, solver, or source model."""
from pathlib import Path
import argparse, hashlib, json, platform
import sympy as sp

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--output', type=Path, default=Path(__file__).with_suffix('.json'), help='JSON output path (default: script sibling .json)')
args=parser.parse_args()
A,C,L,a,K,D,Lam,H=sp.symbols('A C L a K D Lam H', positive=True)
s=1/(Lam*(K**2*D**2+K*H*D))
z=sp.factor(K**2*Lam*s*D**2)
y=sp.factor(K*Lam*s*H*D)
assert sp.simplify(z+y-1)==0
assert sp.simplify(z-K*D/(K*D+H))==0
assert sp.simplify(y-H/(K*D+H))==0
q=sp.symbols('q', real=True)
poly=(1-4*A**2*a)*q**2-(2*C+4*A**2*L)*q+C**2
rad=a*C**2+C*L+A**2*L**2
full=(C+2*A**2*L+2*A*sp.sqrt(rad))/(1-4*A**2*a)
assert sp.simplify(poly.subs(q,full))==0
assert sp.simplify(sp.discriminant(poly,q)-16*A**2*rad)==0
# Young choice zeta=1/(2A) is valid exactly below the full threshold.
zeta=1/(2*A)
assert sp.simplify((C+A*L/zeta)/(1-A*(zeta+a/zeta))-(2*C+4*A**2*L)/(1-4*A**2*a))==0
# Full scalar inequality is q <= C+2A sqrt(a q^2+Lq).
# Far uses the independently inherited already-paid-near invoice.
far=(4*C+8*A**2*L)/(1-8*A**2*a)
full0=sp.simplify(full.subs(a,0))
assert sp.simplify(full0-(C+2*A**2*L+2*A*sp.sqrt(C*L+A**2*L**2)))==0
# A single rational algebra fixture; NOT asserted to be a realizable cube input.
fixture={A:sp.Rational(2),C:sp.Rational(3),K:sp.Rational(3),D:sp.Rational(2),Lam:sp.Rational(5,2),H:sp.Rational(7,3)}
sv=sp.factor(s.subs(fixture)); zv=sp.factor(z.subs(fixture)); yv=sp.factor(y.subs(fixture))
Brec=1+sp.log(1+Lam*H/s)
gamma=sp.Rational(3,2); Lcl=sp.Rational(7,5); b0=sp.Rational(4,5)
Brec_v=sp.simplify(Brec.subs(fixture))
Ltot=1+gamma**2*Lcl*Brec_v+sp.Rational(5,7)
rows=[]
for route,denomfactor,expr in [('full',4,full),('far_after_near',8,far)]:
    threshold=sp.Rational(1,denomfactor*4)
    for label,av in [('zero',sp.Rational(0)),('below',threshold-sp.Rational(1,1024)),('boundary',threshold),('above',threshold+sp.Rational(1,1024))]:
        den=sp.factor(1-denomfactor*sp.Rational(4)*av)
        legal=bool(den>0)
        item={'route':route,'case':label,'a':str(av),'threshold':str(threshold),'denominator':str(den),'strict_absorption':legal}
        if legal:
            exact=expr.subs({A:sp.Rational(2),C:sp.Rational(3),L:Ltot,a:av}, simultaneous=True)
            qbound=exact/b0**2
            rbound=2*sp.sqrt(2*qbound)
            item.update({'Q_over_W_exact':str(qbound),'Q_over_W_decimal_display':str(sp.N(qbound,20)), 'Rstar_over_W_exact':str(rbound),'Rstar_over_W_decimal_display':str(sp.N(rbound,20))})
            assert qbound.is_positive is not False
        else:
            item['decision']='No uniform finite bound follows from this scalar absorption inequality.'
        rows.append(item)
source=Path(__file__).read_bytes()
result={'formulae':{'s':str(s),'startup_z':str(z),'startup_y':str(y),'full_scalar_root':str(full),'far_scalar_invoice':str(far),'full_a_zero':str(full0)},'scope':'Symbolic conditional ledger and one rational algebra fixture only; not a cube instance or a geometry proof.', 'python':platform.python_version(),'sympy':sp.__version__,'script_sha256':hashlib.sha256(source).hexdigest(),'symbolic_checks':{'startup_upper_bound_coefficients_sum_to_one':True,'full_upper_root_solves_squared_invoice':True,'full_discriminant':True,'Young_sufficient_invoice':True,'a_zero_retains_all_L':True},'fixture':{'A0':'2','Cmother':'3','K':'3','Dclk':'2','Lambda':'5/2','SAn':'7/3','gamma':'3/2','Lcl':'7/5','b0':'4/5','Ldiff':'5/7','s':str(sv),'startup_z_coefficient':str(zv),'startup_y_coefficient':str(yv),'Brec_exact':str(Brec_v),'Ltotal_exact':str(Ltot)},'boundary_checks':rows}
args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'python':result['python'],'sympy':result['sympy'],'script_sha256':result['script_sha256'],'symbolic_checks':'PASS','startup_fixture':{'s':str(sv),'z':str(zv),'y':str(yv),'sum':str(zv+yv)},'boundary_checks':[{k:r[k] for k in ('route','case','a','denominator','strict_absorption')} for r in rows]},ensure_ascii=False,indent=2))
