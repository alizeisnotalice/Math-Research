# 来源、技能与定理适用范围

- 研究基线：R568提交6da1cd4aabeccd79668ae30b64a6de99345be9f5，原合同F1–F6及母账；R561真实双边tent/同phase、R564质量合格共同簇、R566共享价格与原near付款沿用。REPORT明确完整原Li、旧σ、真实来源和恢复分母。R562旧后验恒等式不重复计成果。
- 用户采用的R565补充文件SHA256：48d68f094e08b042cb8a0a1001889b0ab8cbb0ac8f849224a03324b879f2c67b。本轮未以简化计算为由删掉坐标或参数。
- 本轮记录定理在REPORT中自含推导：确定强度PPP的非负Campbell–Mecke/void公式、整批after-hazard、Stieltjes对数界、Tonelli/Jensen。它不是对未来winner擅用可预测补偿。有限强度公式可由Poisson点数条件化后对被计点求和，再单调极限得到。未调用未核验的端点或高维文献定理。
- 使用64项数学工具中的I02（滤过/投影/补偿条件）和L03（有理/区间证书规范），读取其SKILL.md及L03来源说明。技能安装包的旧通用区间API状态不作为本轮Arb证明；实际运行证书保留精确向外端点。G03私有捕获树接口定义不足，未把名称当可用定理。
- 规范文件本机位置：/Users/zhengzhihao/.codex/skills/math-i02-filtration-projections-compensators/SKILL.md；/Users/zhengzhihao/.codex/skills/math-l03-rational-and-interval-certificates/SKILL.md。这里只用实际适用项，未声称逐个运行所有64项。
- 本机数学环境README/verification.json仅确认环境功能。研究命题证据来自本轮实际运行及独审，不来自安装检查。
- GitHub规模规则2026-10-23重新读取[官方repository limits](https://docs.github.com/en/repositories/creating-and-managing-repositories/repository-limits)：单对象强制100MB、单推送2GB；目录宽度建议3000。diff显示300文件不等于仓库总文件上限。本轮仅新增两项归档文件并更新项目总览，不改历史或其他项目。
