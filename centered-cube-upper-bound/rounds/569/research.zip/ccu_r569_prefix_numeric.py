"""R569-B one bounded exact-form expanded-proposal mass-prefix race experiment."""
import os
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
from pathlib import Path
from itertools import permutations
import argparse,json,hashlib,time,resource,platform
import sympy as sp

L2,L3=sp.symbols('L2 L3',real=True);rr=sp.symbols('r0:4',positive=True);sublogs={L2:sp.log(2),L3:sp.log(3)}
def clean(x):return sp.cancel(x)
def display(x):return str(sp.N(x.subs(sublogs),50))
def rational(x):return sp.Rational(x)
def sign(x):
 x=clean(x)
 if x==0:return 0
 val=sp.N(x.subs(sublogs),80)
 return 1 if val>0 else -1

def permutation_probability(order):
 left=sum(rr);p=sp.Integer(1)
 for b in order:p*=rr[b]/left;left-=rr[b]
 return p
ORDERS=list(permutations(range(4)));PP=[permutation_probability(o) for o in ORDERS]

def records(order,weights,states,levels,startup,s,serial=False):
 sets=[set() for _ in states];last=[None]*3;begun=[False]*3
 batches=[[i for i,v in enumerate(states) if v['mass']==m] for m in levels]
 if serial:batches=[[i] for batch in batches for i in batch]
 opened=set()
 prepared=startup
 if prepared is None:
  prepared=[]
  for batch in batches:
   opened.update(batch);acts=[];success=[]
   for x in range(3):
    active=opened&{i for i,v in enumerate(states) if x in v['mask']};A=clean(sum((v['rate'] for i,v in enumerate(states) if i in active),sp.Integer(0)));acts.append(active);success.append(sign(A-s)>0)
   prepared.append((acts,success))
 if order is None:return prepared
 for acts,success in prepared:
  for x in range(3):
   active=acts[x]
   if not success[x]:continue
   winner=next(i for i in order if i in active)
   if not begun[x] or winner!=last[x]:sets[winner].add(x)
   begun[x]=True;last[x]=winner
 return sum((sum(weights[x] for x in ss) for ss in sets),sp.Integer(0)),[sorted(ss) for ss in sets]

def model(n,weights):
 st=time.perf_counter();print('MODELSTART',n,weights,flush=True);G=sp.Integer(2)**n;entry=sp.Rational(3,2)**n;E=1+n*(L3-L2);T=1+n*(2*L2-L3);Lam=2+n*L2;parents=[];states=[]
 oldm=[weights[0],weights[1]];highm=[weights[0]+weights[1],sum(weights)];masks=[[[0],[0,1]],[[1],[0,1,2]]]
 for b in range(2):
  a=sp.Rational(1,4)*(1 if b==0 else sp.Rational(1,2));kap=highm[b]/oldm[b];I=E+T/kap;rho0=clean(E/I);rho1=clean((T/kap)/I);assert clean(rho0+rho1-1)==0
  parents.append(dict(id=b,center_diagonal=sp.Rational(3,4)*b,R=sp.Integer(1),t=1 if b==0 else sp.Rational(1,2),finite_parent_measure_weight=sp.Rational(1,4),a=a,old_mass=oldm[b],expanded_mass=highm[b],kappa_high=kap,I=I,rho_early=rho0,rho_late=rho1))
  for k,rho in enumerate([rho0,rho1]):states.append(dict(id=len(states),parent=b,kind='early' if k==0 else 'late',g_lower=sp.Integer(1) if k==0 else entry,g_upper=entry if k==0 else G,contains_g1_atom=k==0,contains_gG_atom=k==1,continuous_density='dg/(I*kappa*g)',mask=masks[b][k],mass=oldm[b] if k==0 else highm[b],rho=rho,rate=clean(a*rho)))
 rates=[v['rate'] for v in states];rate_sub=dict(zip(rr,rates));numeric_rates=[sp.N(v.subs(sublogs),80) for v in rates];numeric_PP=[]
 for order in ORDERS:
  left=sum(numeric_rates);p=sp.Float(1,80)
  for i in order:p*=numeric_rates[i]/left;left-=numeric_rates[i]
  numeric_PP.append(p)
 assert abs(sum(numeric_PP)-1)<sp.Float('1e-70')
 levels=sorted({v['mass'] for v in states});Afinal=[clean(sum((v['rate'] for v in states if x in v['mask']),sp.Integer(0))) for x in range(3)];hazard=clean(sum(weights[x]*Afinal[x] for x in range(3)));identity=clean(Lam*sum(p['a']*p['old_mass']/p['I'] for p in parents));assert clean(hazard-identity)==0
 thresholdresults=[]
 for s in map(sp.Rational,[0,sp.Rational(1,32),sp.Rational(1,8),sp.Rational(1,4)]):
  counts=[];serialcounts=[];orderrows=[];prepared=records(None,weights,states,levels,None,s);serialprepared=records(None,weights,states,levels,None,s,True)
  for o in ORDERS:
   cost,clusters=records(o,weights,states,levels,prepared,s);serial,_=records(o,weights,states,levels,serialprepared,s,True);counts.append(cost);serialcounts.append(serial);orderrows.append(dict(order=list(o),probability_rate_expression=PP[len(orderrows)],probability_display=str(sp.N(numeric_PP[len(orderrows)],50)),clusters=clusters,price=cost,serial_batch_price=serial))
  # Compact exact rational-in-rates expectation. This is not an interval certificate.
  exact=sp.Add(*[p*c for p,c in zip(PP,counts)],evaluate=False);exactserial=sp.Add(*[p*c for p,c in zip(PP,serialcounts)],evaluate=False);actual=exact.xreplace(rate_sub);val=sum(p*c for p,c in zip(numeric_PP,counts));assert abs(sp.N(actual.subs(sublogs),60)-val)<sp.Float('1e-50')
  prefixes=[]
  for mass in [sp.Integer(0)]+levels:
   active=[{i for i,v in enumerate(states) if v['mass']<=mass and x in v['mask']} for x in range(3)];A=[clean(sum((rates[i] for i in aset),sp.Integer(0))) for aset in active];started=[sign(a-s)>0 for a in A];pairs=[]
   for y in range(3):
    for z in range(3):
     inter=active[y]&active[z];J=clean(sum((rates[i] for i in inter),sp.Integer(0)));den=clean(A[y]+A[z]-J);both=started[y] and started[z];hit=clean(J/den) if both else sp.Integer(0);exclusive=clean(1-hit) if both else sp.Integer(0);startupfail=sp.Integer(0 if both else 1);assert clean(hit+exclusive+startupfail-1)==0
     # Enumerate same-prefix winner under the same 24 order probabilities.
     prob=sp.Integer(0)
     if both:
      for order,p in zip(ORDERS,PP):
       wy=next(i for i in order if i in active[y]);wz=next(i for i in order if i in active[z]);prob+=p*int(wy==wz)
      orderhit=sum((p*int(next(i for i in o if i in active[y])==next(i for i in o if i in active[z])) for o,p in zip(ORDERS,numeric_PP)),sp.Float(0,80));assert abs(orderhit-sp.N(hit.subs(sublogs),80))<sp.Float('1e-60')
     pairs.append(dict(y=y,z=z,J=J,hit=hit,exclusive=exclusive,startup_failure=startupfail,hit_display=display(hit),exclusive_display=display(exclusive)))
   prefixes.append(dict(mass=mass,active=[sorted(x) for x in active],A=A,A_display=[display(a) for a in A],startup_success=started,startup_margins=[clean(a-s) for a in A],pairs=pairs))
  W=sum(weights);bound=None if s==0 else W*(1+sp.log(1+hazard/(s*W)));sourcebound=None if s==0 else sum(weights[x]*(1+sp.log(1+Afinal[x]/s)) for x in range(3))
  thresholdresults.append(dict(s=s,expected_price_rate_expression=exact,rate_symbol_order=[str(v) for v in rr],expected_price=actual,expected_price_display=str(sp.N(val,50)),serial_batch_expected_price_rate_expression=exactserial,serial_extra_price_display=str(sp.N(sum((p*(a-b) for p,a,b in zip(numeric_PP,serialcounts,counts)),sp.Float(0,80)),50)),orders=orderrows,prefixes=prefixes,Jensen_hazard_bound=bound,Jensen_hazard_bound_display=display(bound) if bound is not None else None,sourcewise_record_bound_display=display(sourcebound) if sourcebound is not None else None))
 print('MODELDONE',n,weights,'seconds',time.perf_counter()-st,flush=True)
 return dict(n=n,weights=weights,G=G,entry_threshold=entry,log_symbols={'L2':'ln2','L3':'ln3'},Lambda=Lam,parents=parents,states=states,rate_displays=[display(r) for r in rates],mass_batches=[dict(mass=m,states=[i for i,v in enumerate(states) if v['mass']==m]) for m in levels],source_total_mass=sum(weights),final_source_hazards=Afinal,source_hazard_integral=hazard,source_hazard_integral_display=display(hazard),hazard_identity_rhs=identity,hazard_identity_exact_residual=sp.Integer(0),thresholds=thresholdresults,seconds=time.perf_counter()-st)

def pack(v):
 if isinstance(v,sp.Basic):return str(v)
 if isinstance(v,dict):return {str(k):pack(x) for k,x in v.items()}
 if isinstance(v,(list,tuple)):return [pack(x) for x in v]
 return v

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',default=str(Path(__file__).with_suffix('.json')));args=ap.parse_args();st=time.perf_counter();models=[model(n,list(map(sp.Integer,w))) for n,w in [(2,(1,1,1)),(2,(1,2,1)),(3,(1,1,1)),(3,(1,2,1)),(2,(1,1,0))]];payload=pack(dict(schema='R569.prefix.1',scope='Finite atomic source / two cube-parent quadrature model; full continuous action mass retained in source-equivalent collapsed states, not continuous-parent/history/root-order certificate',input=dict(dimensions=[2,3],source_positions_diagonal=[sp.Integer(0),sp.Rational(3,4),sp.Rational(3,2)],source_weights=[[1,1,1],[1,2,1]],extra_pressure_model=dict(n=2,weights=[1,1,0]),thresholds=[0,sp.Rational(1,32),sp.Rational(1,8),sp.Rational(1,4)],same_mass_batch='simultaneous reveal, initial winner once hazard strictly>s; no serial record within one mass batch',endpoint_rule='g1 atom included early; gG atom included late; threshold entry g0 belongs late capture but has zero continuous rho point mass'),models=models,checks=dict(all_continuous_action_mass_collapsed_exactly=True,source_hazard_identity_exact=True,all_pair_partition_exact=True,all_pair_collision_closed_formula_matches_orders_at_80_digits=True,pair_order_comparison_tolerance='1e-60',all_startup_equalities_go_low=True),cost=dict(seconds=time.perf_counter()-st,maxrss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,orders_per_model=24,models=5,thresholds_per_model=4,MC_samples=0,LP_calls=0),versions=dict(python=platform.python_version(),sympy=sp.__version__),code_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()));Path(args.output).write_text(json.dumps(payload,indent=2));print(json.dumps(dict(cost=payload['cost'],summary=[dict(n=m['n'],weights=m['weights'],hazard=m['source_hazard_integral_display'],prices=[dict(s=r['s'],expected=r['expected_price_display'],serialextra=r['serial_extra_price_display']) for r in m['thresholds']]) for m in payload['models']]),indent=2))
if __name__=='__main__':main()
