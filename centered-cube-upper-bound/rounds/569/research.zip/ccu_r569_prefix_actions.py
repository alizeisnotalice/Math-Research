"""R569-B independent continuous-action collapse and Arb threshold certificate.
No record-order enumeration, price computation, or continuous-parent claim.
"""
from pathlib import Path
from fractions import Fraction
import argparse
import hashlib
import json
import platform
import sys
import sympy as sp
from flint import arb, ctx
import flint

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--output-prefix', type=Path, default=Path(__file__).with_suffix(''),
                    help='Output prefix for .json/.md; default: beside this script.')
args = parser.parse_args()
BASE = args.output_prefix
BASE.parent.mkdir(parents=True, exist_ok=True)
ctx.prec = 256
ctx.threads = 1
L2, L3 = sp.symbols('L2 L3', real=True)
g = sp.symbols('g', positive=True)
LOGS = {sp.log(2): L2, sp.log(3): L3}
ARB_LOGS = {L2: arb(2).log(), L3: arb(3).log()}
THRESHOLDS = [sp.Rational(1, 32), sp.Rational(1, 8), sp.Rational(1, 4)]

def canonical(x):
    return sp.cancel(sp.expand_log(sp.expand(x), force=True).subs(LOGS))

def ae(x):
    x = sp.sympify(x)
    if x in ARB_LOGS:
        return ARB_LOGS[x]
    if x.is_Rational:
        return arb(int(x.p)) / arb(int(x.q))
    if x.is_Add:
        ans = arb(0)
        for t in x.args:
            ans += ae(t)
        return ans
    if x.is_Mul:
        ans = arb(1)
        for t in x.args:
            ans *= ae(t)
        return ans
    if x.is_Pow and x.exp.is_Integer:
        return ae(x.base) ** int(x.exp)
    raise TypeError(f'Non-rational/logarithmic expression: {x}')

def endpoint(y):
    m, e = y.man_exp()
    return {'mantissa': str(m), 'binary_exponent': int(e)}

def ball(x):
    return {'arb_enclosure': x.str(65), 'lower_dyadic': endpoint(x.lower()),
            'upper_dyadic': endpoint(x.upper())}

def fraction_endpoint(y):
    m, e = y.man_exp()
    return Fraction(int(m)) * (Fraction(2) ** int(e))

def certified_sign(x):
    x = canonical(x)
    if x == 0:
        return 0, {'method': 'exact_symbolic_zero', 'expression': '0'}
    b = ae(x)
    if b.lower() > 0:
        sign = 1
    elif b.upper() < 0:
        sign = -1
    else:
        raise ArithmeticError(f'Unresolved sign at {ctx.prec} bits: {x}: {b}')
    return sign, {'method': 'Arb_strict_endpoint', 'expression': str(x), **ball(b)}

models = []
equality_rows = []
strict_gaps = []
rate_lowers = []
parent_count = rate_count = comparison_count = 0

for n in [2, 3]:
    G = sp.Integer(2) ** n
    entry = sp.Rational(3, 2) ** n
    # Geometry is checked from the actual diagonal source/center coordinates.
    positions = [sp.Integer(0), sp.Rational(3, 4), sp.Rational(3, 2)]
    centers = [sp.Integer(0), sp.Rational(3, 4)]
    radius_old = sp.Rational(1, 2)
    radius_high = sp.Integer(1)
    masks_old = [[i for i, p in enumerate(positions) if abs(p-c) <= radius_old]
                 for c in centers]
    masks_high = [[i for i, p in enumerate(positions) if abs(p-c) <= radius_high]
                  for c in centers]
    assert masks_old == [[0], [1]]
    assert masks_high == [[0, 1], [0, 1, 2]]
    assert (2 * sp.Rational(3, 4)) ** n == entry
    assert (2 * radius_high) ** n == G
    for weights_tuple in ([(1, 1, 1), (1, 2, 1), (1, 1, 0)] if n == 2 else [(1, 1, 1), (1, 2, 1)]):
        weights = list(map(sp.Integer, weights_tuple))
        name = f'n{n}_w{"".join(map(str, weights_tuple))}'
        parents = []
        states = []
        Lambda = canonical(2 + sp.log(G))
        for b in range(2):
            oldm = sum(weights[i] for i in masks_old[b])
            highm = sum(weights[i] for i in masks_high[b])
            kap = sp.Rational(highm, oldm)
            t = sp.Integer(1) if b == 0 else sp.Rational(1, 2)
            parent_weight = sp.Rational(1, 4)
            a = parent_weight * t  # R=1; finite parent quadrature weight explicit.
            J_early = canonical(sp.integrate(1/g, (g, 1, entry)))
            J_late = canonical(sp.integrate(1/g, (g, entry, G)))
            I = canonical(1 + J_early + (1 + J_late)/kap)
            # Keep both endpoint atoms separate before collapse.
            atom_1 = canonical(1/I)
            early_cont = canonical(J_early/I)
            late_cont = canonical(J_late/(I*kap))
            atom_G = canonical(1/(I*kap))
            rho_early = canonical(atom_1 + early_cont)
            rho_late = canonical(late_cont + atom_G)
            normalization = canonical(atom_1+early_cont+late_cont+atom_G-1)
            assert normalization == 0
            weighted_mass = canonical(a * (oldm*(atom_1+early_cont)
                                             +highm*(late_cont+atom_G)))
            identity_rhs = canonical(Lambda*a*oldm/I)
            assert canonical(weighted_mass-identity_rhs) == 0
            for component in [I, atom_1, early_cont, late_cont, atom_G,
                              rho_early, rho_late]:
                sg, _ = certified_sign(component)
                assert sg == 1
            parent_count += 1
            parents.append({'id': b, 'center_diagonal': str(centers[b]),
                'R': '1', 't': str(t), 'finite_parent_weight': str(parent_weight),
                'a': str(a), 'old_mass': str(oldm), 'high_mass': str(highm),
                'kappa_high': str(kap), 'integral_early_dg_over_g': str(J_early),
                'integral_late_dg_over_g': str(J_late), 'I': str(I),
                'rho_components': {'g1_atom': str(atom_1),
                    'early_continuous': str(early_cont),
                    'late_continuous': str(late_cont), 'gG_atom': str(atom_G)},
                'rho_early': str(rho_early), 'rho_late': str(rho_late),
                'normalization_residual_exact': str(normalization),
                'a_rho_mass_integral': str(weighted_mass),
                'Lambda_tq_over_I_rhs': str(identity_rhs),
                'mass_identity_residual_exact': '0'})
            for kind, rho, mass, mask in [('early', rho_early, oldm, masks_old[b]),
                                          ('late', rho_late, highm, masks_high[b])]:
                rate = canonical(a*rho)
                sg, cert = certified_sign(rate)
                assert sg == 1
                rate_lowers.append(fraction_endpoint(ae(rate).lower()))
                rate_count += 1
                states.append({'id': len(states), 'parent': b, 'kind': kind,
                               'mask': mask, 'mass': str(mass),
                               'rho': str(rho), 'rate': str(rate),
                               'rate_positive_certificate': cert})
        levels = [sp.Integer(0)] + sorted({sp.Integer(st['mass']) for st in states})
        prefix_rows = []
        for mass in levels:
            active = [[st['id'] for st in states
                       if sp.Integer(st['mass']) <= mass and x in st['mask']]
                      for x in range(3)]
            hazards = [canonical(sum((sp.sympify(states[i]['rate'], locals={'L2':L2,'L3':L3})
                                        for i in indices), sp.Integer(0)))
                       for indices in active]
            comparisons = []
            for x, A in enumerate(hazards):
                row = {'source': x, 'A_exact': str(A), 'A_enclosure': ball(ae(A)),
                       'thresholds': []}
                for s in THRESHOLDS:
                    sg, cert = certified_sign(A-s)
                    comparison_count += 1
                    result = {'s': str(s), 'A_minus_s': str(canonical(A-s)),
                              'sign': sg, 'startup_A_strictly_greater_s': sg > 0,
                              'certificate': cert}
                    row['thresholds'].append(result)
                    if sg == 0:
                        eq = {'model': name, 'prefix_mass': str(mass), 'source': x,
                              'A': str(A), 's': str(s), 'startup': False}
                        equality_rows.append(eq)
                    else:
                        diff_ball = ae(canonical(A-s))
                        lower_abs = (fraction_endpoint(diff_ball.lower()) if sg > 0
                                     else -fraction_endpoint(diff_ball.upper()))
                        assert lower_abs > 0
                        strict_gaps.append((lower_abs, name, str(mass), x, str(s), sg))
                comparisons.append(row)
            prefix_rows.append({'mass': str(mass), 'active_state_indices': active,
                                'comparisons': comparisons})
        assert canonical(sum(sp.sympify(st['rate'], locals={'L2':L2,'L3':L3})
                             for st in states if st['parent']==0)-sp.Rational(1,4)) == 0
        assert canonical(sum(sp.sympify(st['rate'], locals={'L2':L2,'L3':L3})
                             for st in states if st['parent']==1)-sp.Rational(1,8)) == 0
        if weights_tuple == (1, 1, 0):
            assert n == 2 and levels == [0, 1, 2]
            assert [st['id'] for st in states if st['mass'] == '2'] == [1, 3]
            afinal0 = canonical(sum((sp.sympify(st['rate'], locals={'L2':L2,'L3':L3}) for st in states if 0 in st['mask']), sp.Integer(0)))
            assert canonical(afinal0-sp.Rational(1,4)-sp.sympify(states[3]['rate'],locals={'L2':L2,'L3':L3})) == 0
            assert certified_sign(afinal0-sp.Rational(1,4))[0] == 1
        models.append({'id':name,'n':n,'weights':list(weights_tuple),'G':str(G),
                       'entry':str(entry),'Lambda':str(Lambda),'parents':parents,
                       'states':states,'mass_batches':[{'mass':str(m), 'states':[st['id'] for st in states if sp.Integer(st['mass'])==m]} for m in levels if m != 0],'prefixes':prefix_rows})

assert parent_count == 10 and rate_count == 20 and comparison_count == 189
assert len(equality_rows) == 4
assert all(e['source']==0 and e['A']=='1/4' and e['s']=='1/4'
           for e in equality_rows)
min_gap = min(strict_gaps)
min_rate = min(rate_lowers)
assert min_rate > Fraction(27358, 1000000)
assert min_gap[0] > Fraction(3151, 1000000)

def sha(path):
    p = Path(path)
    return hashlib.sha256(p.read_bytes()).hexdigest()

payload = {'schema':'R569-B.actions-thresholds.1',
    'scope':'Independent continuous-action collapse and finite-model strict threshold certificate only; no record enumeration or Pi_rec computation.',
    'versions':{'python_full':sys.version,'python_executable':sys.executable,
                'sympy':sp.__version__,'python_flint':flint.__version__,
                'arb_precision_bits':ctx.prec,'flint_threads':ctx.threads},
    'input_provenance':{'label':'R569-B two-parent, three-source atomic cube model',
        'parameters':'All model parameters, exact integrations, masks, and thresholds are embedded in this script.',
        'external_draft_files_required':False},
    'code_sha256':sha(__file__),
    'endpoint_convention':'g=1 atom early; g=G atom late; entry is late as an actual closed-cube incidence but omega has no atom at entry. All equal mass states are one simultaneous prefix.',
    'checks':{'models':len(models),'parents':parent_count,'positive_rates':rate_count,
              'threshold_comparisons':comparison_count,
              'strict_Arb_comparisons':len(strict_gaps),
              'exact_equalities':len(equality_rows),
              'rho_normalization_exact':True,'restored_mass_identity_exact':True,
              'all_startup_equalities_go_low':True,
              'no_record_orders_enumerated':True,'no_record_price_computed':True},
    'safe_strict_rate_lower_rational':'27358/1000000',
    'safe_strict_threshold_gap_lower_rational':'3151/1000000',
    'smallest_positive_rate_lower_exact':str(min_rate),
    'minimum_strict_threshold_gap_lower_exact':str(min_gap[0]),
    'minimum_strict_threshold_gap_location':{'model':min_gap[1],
        'prefix_mass':min_gap[2],'source':min_gap[3],'s':min_gap[4],'sign':min_gap[5]},
    'equalities':equality_rows,'models':models}
json_path=BASE.with_suffix('.json')
json_path.write_text(json.dumps(payload,indent=2)+'\n')

lines=['# R569-B independent action-collapse and threshold certificate','',
'PASS for the assigned finite model only. No record enumeration or record-price calculation was performed.','',
'For each parent, with entry $e=(3/2)^n$, $G=2^n$, and high/old mass ratio $k$, set',
'$$E=1+\\log e,\\quad F=1+\\log(G/e),\\quad I=E+F/k.$$','',
'The restored early and late probabilities are exactly $E/I$ and $F/(kI)$. The early part includes the $g=1$ atom; the late part includes the $g=G$ atom. The continuous density is $dg/(I\\kappa(g)g)$. At entry the source mass jumps, but $\\omega$ has no entry atom.','',
'Independent SymPy integration, with both endpoint atoms separately retained, verified for all ten parents:',
'$$\\int\\rho=1,\\qquad a\\int M(g)\\rho(dg)=\\Lambda a m/I.$$','',
'Here $a$ already includes the finite parent quadrature weight $1/4$: the two parent rates are $1/4$ and $1/8$. Thus the displayed identity is the finite quadrature form of $\\Lambda t q/I$; the parent weight is not omitted.','',
'At 256-bit Arb precision, all 20 collapsed rates have strictly positive lower bounds. All 189 prefix/source/threshold comparisons were resolved: 185 by strict Arb endpoint signs and four by exact symbolic equality. No approximate sign test was used.','',
'The sole added stress model is n=2, weights (1,1,0). Its two late proposals both have mass 2 and must be revealed as one batch. At that actual prefix source 0 has A=1/4+r_late,parent1>1/4; there is no intermediate A=1/4 prefix. The third listed position has zero source mass and is retained only as a geometric threshold probe.','',
'## Exact equalities','',
'In each of the four original positive-weight models, source 0 at the parent-0 high-mass prefix has $A=r_0+r_1=1/4$ exactly. Therefore startup $A>s$ is **false** at $s=1/4$. The equality branch is decided before interval evaluation.','',
'| Model | Prefix mass | Source | A | Startup at s=1/4 |','|---|---:|---:|---:|---|']
for e in equality_rows:
    lines.append(f"| {e['model']} | {e['prefix_mass']} | {e['source']} | {e['A']} | low |")
lines += ['', '## Rate enclosures', '', '| Model | State | Rate enclosure (Arb) |', '|---|---|---|']
for model in models:
    for st in model['states']:
        lines.append(f"| {model['id']} | {st['parent']} {st['kind']} | `{ae(sp.sympify(st['rate'],locals={'L2':L2,'L3':L3})).str(22)}` |")
lines += ['', '## Threshold startup pattern', '',
'Each triplet gives startup for sources (0,1,2), using strict $A>s$. Equal-mass proposals are opened simultaneously.','',
'| Model | Prefix mass | s=1/32 | s=1/8 | s=1/4 |','|---|---:|---|---|---|']
for model in models:
    for prefix in model['prefixes']:
        vals=[]
        for j in range(3):
            vals.append(''.join('1' if c['thresholds'][j]['startup_A_strictly_greater_s'] else '0'
                                for c in prefix['comparisons']))
        lines.append(f"| {model['id']} | {prefix['mass']} | {' | '.join(vals)} |")
lines += ['', '## Bounds and provenance', '',
    '- Every rate is strictly greater than `0.027358` (an exact rational conservative bound; the JSON also retains the sharper certified dyadic endpoint).',
    f'- Every nonzero threshold gap has absolute value strictly greater than `0.003151` (exact rational bound); the closest certified case is `{min_gap[1]}`, mass `{min_gap[2]}`, source `{min_gap[3]}`, s=`{min_gap[4]}`.',
    f'- Interpreter: `{sys.executable}`, Python `{platform.python_version()}`; SymPy `{sp.__version__}`; python-flint `{flint.__version__}`; Arb precision `{ctx.prec}` bits, one thread.',
    f'- Code SHA256: `{payload["code_sha256"]}`.',
    f'- JSON SHA256: `{sha(json_path)}`.',
    '- Standalone reproduction: all model parameters are embedded in the script; no external target/numeric drafts are read.',
    '- Run `python ccu_r569_prefix_actions.py` to write beside the script, or pass `--output-prefix PATH` for a chosen prefix.',
    '', 'The JSON stores exact rational/logarithmic expressions and certified dyadic lower/upper endpoints, not only displayed decimals. These checks certify the actual atomic-source/two-parent action collapse and threshold stability. They do not certify continuous-parent geometry, original history, the record budget, or the global weak-type target.']
BASE.with_suffix('.md').write_text('\n'.join(lines)+'\n')
print(json.dumps({'checks':payload['checks'],'minimum_strict_gap_lower':float(min_gap[0]),
                  'minimum_rate_lower':float(min_rate),'code_sha256':payload['code_sha256'],
                  'json_sha256':sha(json_path),'md_sha256':sha(BASE.with_suffix('.md'))},indent=2))
