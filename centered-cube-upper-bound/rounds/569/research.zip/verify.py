"""R569 archive structural/provenance and rational-bound checks; not a global proof."""
from pathlib import Path
from fractions import Fraction as F
import argparse,ast,hashlib,json,re,sys
P=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def read(role):return json.loads((P/f'ccu_r569_prefix_{role}.json').read_text())
def interval(x):
 lo,hi=F(x['lower_exact']),F(x['upper_exact']);assert lo<=hi;return lo,hi

def main():
 n,c,a,l,m,r=map(read,['numeric','certificate','actions','ledger','matlab','repro'])
 scripts=['numeric','certificate','actions','ledger','repro']
 for role in scripts:ast.parse((P/f'ccu_r569_prefix_{role}.py').read_text())
 assert n['cost']['models']==5 and n['cost']['orders_per_model']==24
 assert n['cost']['MC_samples']==n['cost']['LP_calls']==0
 assert c['all_checks_pass'] and c['model_count']==5 and c['ordered_prefix_pair_checks']==756
 assert c['numeric_json_sha256']==sha(P/'ccu_r569_prefix_numeric.json')
 for role,key in [('numeric','code_sha256'),('certificate','code_sha256'),('actions','code_sha256'),('ledger','script_sha256'),('repro','code_sha256')]:assert read(role)[key]==sha(P/f'ccu_r569_prefix_{role}.py')
 width=F(0);rates=prices=serial=0
 for model in c['results']:
  for v in model['rate_intervals']:
   lo,hi=interval(v);assert lo>0;rates+=1
  for v in model['thresholds']:
   lo,hi=interval(v['expected_price_interval']);assert lo>=0;prices+=1;width=max(width,hi-lo)
   if 'wrong_serial_pressure' in v:
    slo,shi=interval(v['wrong_serial_pressure']['extra_interval'])
    if v['s'] in ['0','1/32','1/8']:assert slo>0;serial+=1
    else:assert slo==shi==0
 assert rates==prices==20 and serial==3
 assert width==F(37,392318858461667547739736838950479151006397215279002157056)
 assert len(c['nonempty_exact_startup_equalities'])==4
 assert all(x['decision']=='low' for x in c['nonempty_exact_startup_equalities'])
 assert a['checks']['parents']==10 and a['checks']['threshold_comparisons']==189
 assert a['checks']['positive_rates']==20 and a['checks']['exact_equalities']==4
 assert a['checks']['rho_normalization_exact'] and a['checks']['restored_mass_identity_exact']
 assert all(l['symbolic_checks'].values()) and F(l['fixture']['startup_z_coefficient'])+F(l['fixture']['startup_y_coefficient'])==1
 assert len(l['boundary_checks'])==8
 for x in l['boundary_checks']:assert x['strict_absorption']==(F(x['denominator'])>0)
 assert m['script_sha256']==sha(P/'ccu_r569_prefix_matlab.m')
 assert m['python_json_sha256']==sha(P/'ccu_r569_prefix_numeric.json')
 assert m['checks']['per_order_price_mismatches']==m['checks']['per_order_cluster_mismatches']==0
 assert m['checks']['max_absolute_python_error']<2e-15
 assert r['status']=='PASS_replays' and len(r['replays'])==4
 assert all(x['exit_code']==0 and x['semantic_match'] for x in r['replays'])
 tex=(P/'REPORT.tex').read_text();assert sha(P/'REPORT.tex')=='7b894e3dadc61eb790cd6b06088ce62c7448f419dc731a97dc2e2ed076cd8f4e'
 tex=re.sub(r'(?<!\\)%[^\n]*','',tex)
 stack=[]
 for kind,env in re.findall(r'\\(begin|end)\{([^}]+)\}',tex):
  if kind=='begin':stack.append(env)
  else:assert stack and stack.pop()==env
 assert not stack
 assert len(re.findall(r'(?<!\\)\\\[',tex))==len(re.findall(r'(?<!\\)\\\]',tex))
 tags=re.findall(r'\\tag\{([^}]+)\}',tex);assert len(tags)==len(set(tags))
 labels=re.findall(r'\\label\{([^}]+)\}',tex);assert len(labels)==len(set(labels))
 assert set(re.findall(r'\\(?:eqref|ref)\{([^}]+)\}',tex))<=set(labels)
 for p in P.iterdir():assert p.suffix.lower() not in ['.pdf','.pyc','.aux','.log']
 manifest=P/'MANIFEST.json'
 if manifest.exists():
  for name,h in json.loads(manifest.read_text())['sha256'].items():assert sha(P/name)==h,name
 return dict(status='PASS',scope='Archive, rational endpoints, provenance and TeX structure only; no PDF compilation, no general-bound certificate',python=sys.version.split()[0],finite_models=5,rate_intervals=rates,record_price_intervals=prices,record_max_interval_width=str(width),ordered_prefix_pairs=756,positive_serial_pressure_cases=serial,action_threshold_checks=189,exact_nonempty_equality_cases=4,scalar_boundary_cases=8,independent_python_replays=4,matlab_max_absolute_error=m['checks']['max_absolute_python_error'],report_sha256=sha(P/'REPORT.tex'))
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path);ar=ap.parse_args();v=json.dumps(main(),ensure_ascii=False,indent=2)+'\n'
 if ar.output:ar.output.write_text(v)
 print(v,end='')
