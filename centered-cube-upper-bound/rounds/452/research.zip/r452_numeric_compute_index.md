# R452 计算索引

- 责任：Sol medium，仅 `/tmp/r452_numeric*`。无repo/他人修改、git或agent。
- 先只读：r451_mainproof_check.py、r451_geometry_check.py；未执行别人脚本或覆盖其输出。
- 真连续输入：f=1[-4,4]+1[-1/8,1/8]，W33/4；receiver区间[-1/4,1/4] R1、[1,5/4] R3/2；qband[1,5/4]非qexact。
- 三层：(δ,η)=(1/16,1/8),(1/32,1/16),(1/64,1/32)。packet半宽ηδ/4，receiverblock半宽(1/2−η)δ。实际Lebesgue measure全部记录。
- 验证：67844 Fraction checks；全block捕获严格边距、单mass、全ordered pair交集mass保留、packetwise/pairwiseI2相等、firstmoment匹配、与原解析分段积分比较。
- 原解析：I2=2507/10800，q²I2/W=2507/89100。三层fill-corrected误差67/172800、67/691200、67/2764800。
- 工具：指定数学Python3.12.14，Fraction；实际.28s、RSS23,363,584bytes。
- 范围：一个L1连续receiver场的三层实施证据；不声称f压缩L1收敛或generalproof、originalhistory。
- 输出：r452_numeric.py、r452_numeric_certificate.json、r452_numeric_run.txt、r452_numeric_resources.txt、r452_numeric.md、此索引；同目录自含复现。
- 状态：冻结停止。
