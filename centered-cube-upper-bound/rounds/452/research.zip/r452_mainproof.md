# R452 — screening a zero-cost incidence potential with the original acceptance retained

**Result:** no new payment of the complete original remainder. The candidate below uses actual matched cubes and gives a genuine zero matching-cost potential. Its necessary nonnegative compensation, however, returns only the already available bound `I_Aw≤m_w`. Keeping the original source-dependent acceptance destroys zero cost and produces the explicit term (6). This identifies the failed step without passing to the stronger unmarked `∫fJ²` problem.

## 1. Same original flow, not a reconstructed source law

Use R435 contract: full f, actual centers, `m_A=f(Q_A)=q_A R_A^n`, `σ=q_A dA`, `π_A=f c_A/m_A`, and strict `m_w<m_A/K`. Let L(A,y,z)∈[0,1] be the RN density of the **original** static pushforward divided by `S σπ_A²`. It retains all old/new source, stage, current, clock, early, path and future restrictions. In particular its support has

    Z_A(y)>(4−ε0)h,    C_A(y,z)<h.

Put `c*=1−1/(4−ε0)`. The allowed normalized exclusive integral is

    E_L=∫σπ_A(dy)π_A(dz) L(A,y,z)(1−C_A(y,z)/Z_A(y)),
    R≤S E_L/c*.                                                   (1)

No gate is factored out. With zero-rank values set to zero, define

    r_Aw(y)=Z_A(y)^−1 ∫π_A(dz)L(A,y,z)(1−c_w(z)).

Then Tonelli gives exactly

    E_L=∫σ(dA)∫_{m_w<m_A/K}dw
             ∫f(y)c_A(y)c_w(y)r_Aw(y)dy/(m_A m_w).                (2)

This is the starting point, not a new unmarked estimate. The function r_Aw generally depends on the old source y, including through the actual accepted history.

## 2. The proposed signed geometric test and its complete price

For each actual pair use the normalized incidence potential

    d_Aw(x)=c_w(x)/m_w−c_A(x)/m_A.

It has exactly zero full-source cost, `∫f d_Aw=0`. Write `I=I_Aw`. On common capture it is positive. Its positive and negative full-source masses are both

    ∫f(d_Aw)_+=∫f(d_Aw)_−=1−I/m_A≥1−1/K.                        (3)

The negative part lies on `Q_A\Q_w`, precisely the exclusive new-source region in (2), not on a negligible geometric boundary. This uses source matching, not a volume-to-mass substitution.

The minimal direct nonnegative repair of this test yields the pointwise inequality

    c_A c_w/m_w
      ≤ [d_Aw+c_A(1−c_w)/m_A]/(1−m_w/m_A).                       (4)

It is equality on Q_A; outside Q_A its right side is nonnegative. Integrating against f gives

    I/m_w≤(1−I/m_A)/(1−m_w/m_A),                                (5)

which is exactly equivalent to `I≤m_w`. Thus a source-independent positive coefficient multiplying (4) provides no improved strict-far receipt. The far ratio does not suppress the repair: (3) makes its source mass close to one.

## 3. Why the original L cannot be inserted for free

The obvious attempt is to multiply the potential by `c_A r_Aw`. Its actual matching price is

    C_Aw=∫f c_A r_Aw d_Aw
         =∫π_w c_A r_Aw−∫π_A r_Aw.                            (6)

It is not zero. In fact the exact accepted edge cost in (2) is

    ∫f c_A c_w r_Aw/(m_A m_w)
        =[C_Aw+∫π_A r_Aw]/m_A.                                (7)

Hence neither dropping C_Aw nor calling it a free signed dual is legal. The genuine missing comparison for this candidate is an aggregate estimate of (6), **jointly with the positive companion in (7)**, using the original old/new source weights and deletion law. The known `a_i↓`, `Σb_i≤1`, and static sourcewise domination do not give equality of the two posterior averages in (6). High-rank/low-common qualifies the original pair; it does not balance these new one-source marginals or qualify w as an original father.

Replacing r_Aw by a source-independent supremum restores zero matching price but loses exactly the original L correlation and returns (5). Taking a conditional mean on the common-capture region reproduces the original accepted traffic in the coefficient rather than bounding it. Neither operation is a new estimate.

The separate soft-factor covariance correction was also screened. Its small-error bound is of the previously available R416 type; it does not control (6) with the remaining current/history gates. It is not archived here as a new receipt.

This closes only the normalized-incidence test considered here. It is not a claim that every signed-center dual fails. The full original R and all mother-ledger coefficients remain unchanged; no square, cross, clock, or previous positive receipt is deducted again.

## 4. Actual computation and limits

The designated local math Python ran `/tmp/r452_mainproof_check.py`, with output `/tmp/r452_mainproof.result.txt`: **20 exact Fraction assertions**, four local incidence calculations. They verify zero matching cost, equality of the two variations (3), the pointwise repair (4), its integrated price, and the source-weighted identity (7). The weighted price has positive, zero and negative examples, so its sign was not silently chosen.

These scalar checks are algebra verification, not native continuous-center models or original history realizations. The identities and inequalities for actual cubes are proved above without relying on those finite examples. No broad counterexample search, new density cutoff, or new unproved second-moment assumption was introduced.
