# R452 — screening one explicit zero-cost center potential

**Outcome.** No new bound for \(q^2\int fJ^2\), and no new charge in the original ledger, is obtained. This attachment constructs one concrete geometric signed price with exactly zero matching cost and tests its required pointwise inequality. That inequality fails for this price on a fully matched continuous-center cube field. The calculation isolates the limitation of the proposed price; it does not refute the integrated target or the existence of a different signed certificate. Only this one candidate was pursued.

## 1. The candidate and its complete dual budget

Keep the actual Lebesgue centers \(A\in E\), selected side lengths \(a\le R_A\le b\le2a\), and full matching
\[
m_A=f(Q_A)=q_AR_A^n,\qquad q\le q_A\le\lambda.
\]
Write
\[
D(y)=\int_E\frac{c_A(y)}{R_A^n}\,dA,
\quad X_q=\int_Eq_A\,dA,
\quad A_n=1+n\log(b/a),\quad r=\lambda/q.
\]
The certified native envelope is \(D\le A_n\), and \(qJ\le D\). The zero-receiver case is trivial; assume \(X_q>0\). Define the explicit center average and price
\[
\overline D_\sigma=\frac1{X_q}\int_Eq_AD(A)\,dA,
\qquad
\tau_A=\frac{2[D(A)-\overline D_\sigma]}{R_A^n}.
\tag{1}
\]
This price uses the actual selected cubes, their actual centers, and their known matching masses. It does not introduce a virtual receiver or independently select a radius for each source.

Positive Tonelli gives the useful geometric cost calculation
\[
\int_ED(A)\,dA
=\int_E\frac{|E\cap Q_B|}{R_B^n}\,dB\le |E|.
\tag{2}
\]
Therefore \(0\le\overline D_\sigma\le r\). More importantly, full matching gives
\[
\int_E\tau_Am_A\,dA
=2\int_Eq_A[D(A)-\overline D_\sigma]dA=0,
\tag{3}
\]
with absolute cost bounded by
\[
\int_E|\tau_A|m_A\,dA
\le4\int_Eq_AD(A)dA\le4rX_q\le4rA_nW.
\tag{4}
\]
Thus signed integration in (3) is legitimate. Without centering, the corresponding positive price has cost at most \(2rA_nW\).

The precise proposed sourcewise comparison was
\[
D(y)^2\le B_n+\int_E\tau_Ac_A(y)\,dA
\quad\text{for }f\text{-a.e. }y,
\qquad B_n\le Cn\operatorname{polylog}(n+2).
\tag{5}
\]
If true, it would immediately give \(q^2\int fJ^2\le B_nW\) using (3), with no unpriced dual term. This is an explicit certificate candidate, not an assertion of dual existence. The following calculation shows that (5) is too strong for this particular price.

## 2. One fully matched native field tests the pointwise comparison

Use, in each dimension, the single field
\[
f=1_{[-2,2]^n},\qquad E=[-1,1]^n,
\qquad R_A=\max\{1,2\|A\|_\infty\}.
\tag{6}
\]
All selected cubes lie in the full support of \(f\). Consequently \(m_A=R_A^n\), \(q_A=q=\lambda=1\), \(1\le R_A\le2\), \(X_q=2^n\), and \(W=4^n\). The centers have their true Lebesgue measure. No atomic source or arbitrary incidence matrix is used.

For a source \(x\in[-1,1]^n\) with all coordinates nonzero, exact radial-face integration of the center field gives
\[
D(x)=\prod_{j=1}^n(1-|x_j|)
+\int_{1/2}^1\frac1{2s}
 \sum_{i=1}^n\prod_{j\ne i}
  \left(1-\frac{|x_j|}{2s}\right)ds.
\tag{7}
\]
The first term is the overlap with the center cube \([-1/2,1/2]^n\), on which \(R_A=1\). For an outer center face \(A_i=\pm s\), only the sign matching \(x_i\) can capture \(x\); the other center-coordinate lengths are \(2s-|x_j|\). Division by \((2s)^n\) proves the second term. Coordinate-zero exceptional sets are Lebesgue-null; no assertion about these sets is needed.

In particular, inside any fixed open orthant,
\[
D(x)\longrightarrow G_n:=1+\frac n2\log2
\quad\text{as }x\longrightarrow0.
\tag{8}
\]
Now put
\[
L_n=\int_E\frac{D(A)}{R_A^n}\,dA.
\]
For \(0<t\le1\), integration of (7) over \([-t,t]^n\) yields
\[
\int_{[-t,t]^n}D(A)dA=(2t)^n F_n(t),
\]
\[
F_n(t)=\left(1-\frac t2\right)^n
+\int_{1/2}^1\frac n{2s}
       \left(1-\frac{t}{4s}\right)^{n-1}ds.
\tag{9}
\]
The exact layer cake for the actual selected radius is
\[
R_A^{-n}=2^{-n}
+\int_{1/2}^1\frac{n}{2^nt^{n+1}}
          1_{\{\|A\|_\infty\le t\}}dt
\quad(A\in E).
\]
It includes the inner constant-radius region. Hence
\[
L_n=F_n(1)+n\int_{1/2}^1F_n(t)\frac{dt}{t}
\le (1+n\log2)
 \left[\left(\frac34\right)^n
 +\frac{n\log2}{2}\left(\frac78\right)^{n-1}\right].
\tag{10}
\]
Only \(t\ge1/2\), \(s\le1\), and nonnegative integrands are used for the inequality. In particular \(L_n\to0\).

For every source, positivity gives
\[
\int_E\frac{c_A(y)D(A)}{R_A^n}\,dA\le L_n.
\]
The residual of the signed price (1) is thus bounded below by
\[
D(y)^2-\int_E\tau_Ac_A(y)dA
=D(y)^2-2\int_E\frac{c_A(y)D(A)}{R_A^n}dA
 +2\overline D_\sigma D(y)
\ge D(y)^2-2L_n.
\tag{11}
\]
Using the positive-volume source neighborhoods in (8), its essential supremum is at least \(G_n^2-2L_n\). Therefore
\[
\liminf_{n\to\infty}\frac1{n^2}
 \operatorname*{ess\,sup}_{y:f(y)>0}
 \left[D(y)^2-\int_E\tau_Ac_A(y)dA\right]
\ge\frac{(\log2)^2}{4}>0.
\tag{12}
\]
No dimension-uniform choice \(B_n=Cn\log^a(n+2)\), for fixed finite \(a\), can certify (5) with this price. Centering the positive price cannot repair the problem: the added term in (11) is nonnegative.

This is not an integrated lower bound of the forbidden size: the full source mass in (6) is \(4^n\), and no claim that the integrated second-moment target fails is made. It also does not exclude signed prices with a different spatial dependence or with additional matching information.

## 3. What remains unproved, and the proof decision

The constructive part of this attempt is the explicit zero-cost price and its absolute matching budget (1)–(4). Its required source inequality, not its matching cost or admissibility, is the failed step. Average capture at actual center locations can be very small while capture at a common source location is large. Matching the means does not provide the signed spatial correction needed to majorize those source peaks.

A useful continuation would need a price which uses the shared full-cube constraints to cover these source peaks while paying its positive and negative center parts jointly. Replacing the residual in (11) by its unknown source integral would simply return to the original target. This attachment therefore does not propose that replacement, assert a missing dual exists, or count a conditional bound as a payment. No further candidate or counterexample search was undertaken.

## 4. Actual computation and evidence type

The designated local Python executed `/tmp/r452_geometry_check.py`; saved stdout is `/tmp/r452_geometry.result.txt`. The script expands (9) and integrates it exactly into rational coefficients of \(1,\log2,(\log2)^2\); it evaluates these expressions with 1024-bit Arb intervals. It uses three bounded stages, \(n=1,16,64\), all for the same native family (6), with no sampling or optimization.

- \(n=1\): the direct coefficient identity gives \(L_1=1/4+(3/2)\log2+(1/2)(\log2)^2\).
- \(n=16\): \(L_n\approx1.4461250\), and \(G_n^2-2L_n\approx39.9470978\).
- \(n=64\): \(L_n\approx0.00410544\), and \(G_n^2-2L_n\approx537.3370949\).

Arb verifies positivity and the analytic bound (10) at these parameters. The all-dimension conclusion (12) follows from (8)–(10), not numerical extrapolation. The model has genuine source and receiver volume, exact matching, and octave side lengths, but it is not claimed to realize the original marked history. No new \(W\) charge or absorbable \(X_q\) error is added. The bounded attempt stops here.
