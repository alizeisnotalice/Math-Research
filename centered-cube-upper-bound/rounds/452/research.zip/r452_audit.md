# R452 independent audit — FINAL PASS（限定范围）

FINAL PASS：认证固定维数、显式密度带放宽下的真实L¹场→有限全捕获盒模型的M2逼近桥，及本轮两项signed候选的准确代数/适用范围。**统一有限几何预算B(n,r)尚未证明；没有一般M2界、原R433付款或全尺度根阶闭合。** 原母账保持不变。下方保留先于作者新稿完成的PRE。

## 1. 新逼近桥的独立后审

读取最终 `r452_approximation.md` 与根稿，确认如下步骤均合法：

- 固定n,N，截断g保E_N的全部立方体与pair交集质量。有限支撑来源格胞压到正体积小盒时保持每胞质量及总W_N≤W；并不需要、也没有声称压缩密度在L¹收敛。
- δ=a/(2L)、中心半格平移与R_j∈2δZ，使Q(c_j,R_j)的面落在来源胞边界，故恰为来源胞的并。a=2δL保向下量化仍≥a，≤b；a=b亦完全有效。中心位移≤(1/2−η)δ，来源盒半宽ηδ/4，最近捕获边界仍有3ηδ/4间距。因此整个接收盒上每个来源盒全入或全出；实际m_j和I_jl精确保留g的中心cube及pair交集质量。无独立radius外放松或点中心代整盒。
- 对任意可测R，格平均是R1_E与1_E的微分商。在E的a.e密度点，其均值、中心与量化R均趋原值。L¹来源对cube及cube-pair质量的连续性由端点收敛、源面零测及g支配收敛成立；固定ε>0因此足以使原边界q/λ点最终通过放宽门。E外a.e多数门最终失败。网格不必嵌套，包含点的轴平行cube直径趋零足以适用微分定理。
- 保留格并集F_L在同一有界区，1_F_L→1_E a.e。其pair核由W_N/[(1−ε)qa^n]²统一支配，故DCT给目标收敛。接收胞等比例收缩的measure及M2因子分别是(1−2η)^n和(1−2η)^(2n)，均趋1。零质量来源胞略去，零测接收截断给零结论，不需对零分母取商。
- 由统一有限模型B(n,r')传递，准确损失为(1−ε)^−2且r'=(1+ε)r/(1−ε)。N→∞用原非负pair核MCT。ε可固定；若欲ε↓0必须另控B右邻域，不能假设连续，不能只用r'=1有限结果。固定维数细化并无n极限交换。只恢复无标记M2，不恢复原stage/history或全尺度入口。

所以这是一般可证的逼近桥，意义强于单个数值模型；但缺少其要接的统一B，不是来源预算付款。根稿对“单band/octave到所有尺度另须结算”的限制正确。首段半径术语已修为边长，最终字节如下。

## 2. 其他附件的范围与符号核验

`mainproof` 的原静态L是同一原P的RN投影，不给辅助w原历史。归一incidence势∫f(c_w/m_w−c_A/m_A)=0，正负variation均1−I/m_A；非负修复只等价于I≤m_w。原source-dependent r_Aw乘入后，(6)(7)必须保两个posterior均值差，零价不再成立。式(1)(2)的Z、m_A、m_w归一化与高rank系数正确；没有把此差当新receipt。

`geometry` 的τ_A=2(D(A)−Dbarσ)/R_A^n匹配价零、绝对成本≤4rA_nW均可积。实际native selector族的radial-face式(7)、box平均(9)及含inner base的层积分(10)系数正确；非零坐标开正交象限趋0给正体积source邻域，故pointwise残差的esssup下界真实。其Θ(n²)失败只针对此价格的sourcewise majorization，不是source-integrated目标反例。n=1/16/64的1024-bit Arb是解析表达式的区间核验；全维结论另由指数上界证明，不凭三点拟合。

PRE中的signed权可积性、general-band正负损失与较弱原门接口保留有效；本轮逼近桥不自动给signed无限证书的权紧性，而是允许一个对所有有限全捕获几何成立的统一目标上界直接经M2收敛传递。没有将dual存在本身当证明。

## 3. 实际隔离复现与证据边界

使用指定数学Python `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python`，在新目录
`/var/folders/lq/2c4qbz2n0354_tnttkv_qsz00000gn/T/r452_audit_isolated_06o42ykc`
实际运行三个脚本。三份stdout及numeric生成certificate JSON与冻结版本逐字节一致。只运行有限白名单脚本，没有重跑历史或扩展搜索。

正式证据分别为：mainproof 20 Fraction局部代数断言；geometry一个native族n=1/16/64的精确系数与Arb区间检查；numeric一个非均匀真实L¹/连续receiver场的三层实施、67844 Fraction检查。numeric单质量/全部pair质量保留，packetwise与pairwiseM2相等；三个η是该实施序列，不假称与一般证明的η(L)逐项同值，均满足严格间距并趋0。原解析I2=2507/10800，三层实际receiver gaps及fill-corrected误差都保留。有限三层仅证该实施，不作一般逼近定理的数值替代，也不认证原history。资源文件保留作者原实际运行记录，不推算扣额或将本审复跑相加为新覆盖。PRE临时小表只作审查辅助，不归档新增证据。

无未修数学阻断项。一般统一B、完整来源相关性预算和原全R根价仍未付；没有新增母账槽或吸收系数。

## 4. 最终字节绑定（14输入）

- `r452_main.md`: `8ae5ab10bceb0af5903fc9756d04f306e223449d8d631cd0dbf8c4753e7682ce`
- `r452_approximation.md`: `3528d357735eb0f05b4d390bf5efc5ac3d2e960e96e8f1b860571524c761224f`
- `r452_geometry.md`: `c47c321d39f51bde28bf96806e43d04ce38a1eb62fc71b9e1a8b6607cf929582`
- `r452_geometry_check.py`: `48fc460e65a118f267789e7afba8a7ec9cbf62c4e7d7d0c17245cebe6fab781f`
- `r452_geometry.result.txt`: `e69ee43be67dca773e86396c63b1909da3cf0f028c9c9efb41e14582cd61b9a6`
- `r452_mainproof.md`: `c3017afe78df0914c5964631704a0ec2b7d4f7a51f5cf7c26662c13c995728c1`
- `r452_mainproof_check.py`: `894dcbf49b5901750320efbfda4982c156d1e2a7a1b26b013b85b960e62e2a77`
- `r452_mainproof.result.txt`: `b6c9389675bb5e482a86dd23202cce5d52dde633a956c07a854ce27c31e5b5e3`
- `r452_numeric.md`: `d3144e20303a225050bf293bea49d2bd93b4496f1ee33db4283379df6f96d373`
- `r452_numeric.py`: `262d9145cd126b2082c81f2d681b9adb267fb290e1a581f5af60b3ca622f0596`
- `r452_numeric_certificate.json`: `756da70c153b3f9debbc9fdb9529794cd988c5ed74e2d407fb1dc48f386c739f`
- `r452_numeric_run.txt`: `c70162ffa6d0650e9ee278ae5f1cb89cc31fd8e2a77eca4c30731325da154dac`
- `r452_numeric_resources.txt`: `3aa0181a2b5124fd0dfbb91543a153d7959b85fc8c2a27f38154633a42420a97`
- `r452_numeric_compute_index.md`: `fad35aa1e1c42258990c4c6b72cf087707de3527f1d591ffc47032dab5f503fe`

---

# R452 independent audit — PRE

PRE ONLY。先独立核候选，未读本轮作者新稿；这里只给可审核的充分条件与原门接口，未构造一般维数证书，未认证原R433预算或新付款。后续作者稿另行审查。只修改本文件。

## 1. 同一完整场与最小抵消条件

固定任意完整非负f∈L¹，实际Lebesgue中心E和单值可测side a≤R_A≤b≤2a，m_A=f(Q_A)=q_A R_A^n，0<q≤q_A≤λ，r=λ/q。记V_A=R_A^n、D(y)=∫_E c_A(y)dA/V_A、J(y)=∫_E c_A(y)dA/m_A、W=∫f、X=∫_E q_A dA。保完整来源权f(y)dy，不能换成未加权dy或f²。

令β是有限常数，α:E→R为可测signed中心权。以下是一个直接充分证书：

    D(y)² ≤ β + ∫_E α(A)c_A(y)dA       对fdy-a.e y，
    ∫_E |α(A)|m_A dA < ∞，
    ∫_E α(A)m_A dA ≤ 0。

则Fubini合法，得到∫fD²≤βW。α不要求非负；恰是负中心权允许共同matching抵消。若想证明固定几何族中所有可行来源f的统一结论，点态式必须覆盖每个允许来源支持，而不是只覆盖一份有限最优解的正质量cell。对每个实际场分别构造α亦可，但β必须有声明的统一n、qband、octave依赖；依f选择的证书不能隐藏目标量于β或不可积负权中。

r=1时m_A=qV_A，几何条件∫αV_A≤0确实足够。一般band的准确稳健充分条件是

    Pα=∫α_+ V_A dA， Nα=∫α_- V_A dA，
    r Pα ≤ Nα < ∞。

因为∫αm_A≤λPα−qNα=q(rPα−Nα)。仅有Pα≤Nα并不保消去；若Pα=Nα，只能上放出q(r−1)Pα的额外非负费用。不能因α有负部就对整个signed积分统一乘r。若可直接证明actual ∫αm_A≤0，则不必支付上述最坏band损失；它利用了实际q_A与α的关联，须另有真实证明。

∫|α|V_A<∞是易核的充分可积条件，因为m_A≤λV_A。可用更弱的实际∫|α|m_A<∞；后者由Tonelli也保证点态绝对积分对fdy-a.e有限。没有此类控制，不能从两个无限正负中心费用作∞−∞抵消。有限E与a>0虽保证D≤A_n及原M2有限，但不自动控制任意α。W=0时合法场无正mass接收，结论平凡；W>0且抵消有效的非空证书自然要求β≥0。

## 2. 强目标和母账作用

逐点qJ≤D≤λJ；所以β=O(n polylog(n+2))的上述证书确实给q²∫fJ²≤βW。在q-exact场D=qJ精确；一般band以M2反推D²时才可能付r²。另有准确matching式

    X=∫fD ≤ √(W∫fD²) ≤ √β W，

这里X不是q|E|，也不需要凭空加r。相反，∫D²dy、仅中心均值或仅有限来源质量上的最优值都不能取代∫fD²。D≤A_n只给β=A_n²，仍是旧二次维数上界。

因此这是一条充分的强几何路线，并非一般weak根界的必要条件；即使取得某octave/qband场的统一证书，原入口跨层、初始/删除及总ε手续仍须完整处理。若直接给原R≤εX+QεW，只替换母账64Λ₀Fhat R槽；不得同时叠加R447/R449等对同一whole-R的替代结算。

## 3. 保原source-pair门的较弱证书

也可保原共同父与完整双来源门。取可测0≤L(A,y,z)≤1，必须独立知道原P的source投影≤S L σ(dA)π_A(dy)π_A(dz)，σ=q_A dA、π_A=f c_A/m_A；若L为indicator，原支持且原静态包络足够。一般正L只有support>0不足以给这个密度帽。

保原Z_A(y)>(4−ε₀)h、C_A(y,z)<h与strict-mass K定义。令

    F_L(y)=∫_E [c_A(y)/V_A]dA
                ∫π_A(dz)L(A,y,z)[Z_A(y)−C_A(y,z)]，
    E_L=∫f(y)F_L(y)dy。

这是原E_{K,L}的准确换序，非负，保old/new标签；F_L一般依完整f、实际m与L，不是纯几何D²。原R≤S E_L/[(3−ε₀)h]。不能把其receiver展开中的L与未捕获新source条件因子化，亦不能给新增receiver旧路径history。

一个可审的较弱中心对偶是

    q F_L(y) ≤ β + γD(y) + ∫α(A)c_A(y)dA， γ≥0，

连同第1节实际signed抵消与可积性。于是

    R ≤ [S ε₀/((3−ε₀)s)] (βW+γX)，
    h=s/(ε₀q)。

β=O(n polylog)给根阶来源价；γ=(3−ε₀)s ε/(Sε₀)给所需εX系数。这里只核充分接口，尚未构造它。若S=0则原流零，不需除S。L若取原真实history投影的RN平均，仍是同一测度的准确表示，不是刷新历史，但预算的难点不能被这种重命名消去。

## 4. 无限selector与有限LP之间必须另证的桥

有限source/receiver全捕获模型提供可直接验的弱对偶，但不存在“有限模型有dual，因此所有实际selector有同价dual”的推论。若走离散极限，至少需：覆盖任意完整f及单值actual R_A；捕获边界误差对同一f和中心测度可控；β统一；signed中心权有足够绝对可积或一致可积控制；极限继续满足source点态majorization及matching balance。允许正误差时应明确其积分预算，不能把负权逃逸或临界边界的损失免费丢掉。此处无需假定/调用无限维强对偶、最优attainment或可测极小者存在。

中心权α(A)与来源测试同一capture c_A的Fubini是抵消核心。若换成α(A,y)或source-conditioned重配后的权，∫f(y)c_A(y)α(A,y)dy不再等于α(A)m_A，须另证其实际预算。保历史的较弱矩亦不能从signed可逆/对称流自动获得单向正费用抵消。

## 5. 实际本机算术与PRE状态

指定math-research-tools Python实际运行Fraction及SymPy：在R451的一维固定真实packet/center几何中，v=12/25，D_i=v(1,2,2,1)，β=72/125，三行capture为(1100),(0110),(0011)。取积分中心权γ=(v²−β,3v²,v²−β)，逐一核四个来源cell身份D_i²=β+Σγ_jB_ji、Σγ_j=0与均匀来源积分=β；这只覆盖该有限允许来源支持。另核两个general-band的正负权符号式。未构造一般场证书、未新增扫描；临时审查算术不另记为native历史覆盖。

PRE结论：候选在q-exact条件与上述可积性下正确；一般qband要保rPα−Nα或实际mass加权balance的真实费用。原门较弱对偶接口准确但仍未证。等待作者具体证书或新比较，不提前认证一般目标。
