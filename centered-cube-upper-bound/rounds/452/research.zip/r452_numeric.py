#!/usr/bin/env python3
"""Three common-grid refinements of one genuine nonuniform L1 receiver field."""
from fractions import Fraction as Q
from pathlib import Path
import json,sys,platform
ROOT=Path(__file__).resolve().parent
checks=0
def ck(x):
 global checks
 assert x
 checks+=1
D=Q(1,8)
GROUPS=[(Q(-1,4),Q(1,4),Q(1)),(Q(1),Q(5,4),Q(3,2))]
W=Q(33,4); q=Q(1)
def ov(l,r,a,b):return max(Q(0),min(r,b)-max(l,a))
def mass(l,r):return ov(l,r,Q(-4),Q(4))+ov(l,r,-D,D)
def cube_mass(c,R):return mass(c-R/2,c+R/2)
# Original analytic integral: J is affine between this exact breakpoint list.
pts=sorted(set([Q(-4),Q(4),-D,D]+[v for l,r,R in GROUPS for v in (l-R/2,l+R/2,r-R/2,r+R/2)]))
pieces=[];I2=Q(0);I1=Q(0)
for z0,z1 in zip(pts,pts[1:]):
 mid=(z0+z1)/2;a=Q(0);b=Q(0)
 for l,r,R in GROUPS:
  m=cube_mass((l+r)/2,R)
  ck(cube_mass(l,R)==m and cube_mass(r,R)==m)
  if max(l,mid-R/2)<min(r,mid+R/2):
   # max/min branch fixed throughout this breakpoint interval.
   lo=(l,Q(0)) if l>=mid-R/2 else (-R/2,Q(1))
   hi=(r,Q(0)) if r<=mid+R/2 else (R/2,Q(1))
   a+=(hi[0]-lo[0])/m;b+=(hi[1]-lo[1])/m
 density=Q(int(-4<mid<4)+int(-D<mid<D))
 val=density*(a*a*(z1-z0)+a*b*(z1*z1-z0*z0)+b*b*(z1**3-z0**3)/3)
 first=density*(a*(z1-z0)+b*(z1*z1-z0*z0)/2)
 I2+=val;I1+=first
 pieces.append(dict(left=z0,right=z1,J_constant=a,J_linear=b,density=density,I2=val))
original_E=sum((r-l for l,r,R in GROUPS),Q(0))
ck(I1==original_E and mass(-4,4)==W)

def refine(delta,eta):
 source=[]
 k0=int(Q(-4)/delta)-1;k1=int(Q(4)/delta)+1
 for k in range(k0,k1+1):
  x=k*delta;a=mass(x-delta/2,x+delta/2)
  if a:source.append(dict(k=k,center=x,mass=a,packet_halfwidth=eta*delta/4))
 ck(sum((s['mass'] for s in source),Q(0))==W)
 receiver=[];qvalues=[];minimum_margin=Q(10)
 half=(Q(1,2)-eta)*delta
 for l,r,R in GROUPS:
  ck((l/delta).denominator==1 and (r/delta).denominator==1)
  ck((R/(2*delta)).denominator==1)
  for j in range(int(l/delta),int(r/delta)):
   c=delta*(j+Q(1,2));capt=[]
   for i,s in enumerate(source):
    distance=abs(s['center']-c)
    hit=distance+half+s['packet_halfwidth']<R/2
    miss=distance-half-s['packet_halfwidth']>R/2
    ck(hit or miss)
    # Center cube is exactly a union of whole source Voronoi cells.
    voronoi_hit=(c-R/2<=s['center']-delta/2 and s['center']+delta/2<=c+R/2)
    ck(hit==voronoi_hit)
    if hit:capt.append(i)
    margin=R/2-distance-half-s['packet_halfwidth'] if hit else distance-half-s['packet_halfwidth']-R/2
    minimum_margin=min(minimum_margin,margin)
   m=sum((source[i]['mass'] for i in capt),Q(0))
   ck(m==cube_mass(c,R))
   qvalues.append(m/R)
   receiver.append(dict(j=j,center=c,R=R,volume=2*half,mass=m,capture_indices=capt))
 ck(all(abs(a['center']-b['center'])>2*half for i,a in enumerate(receiver) for b in receiver[i+1:]))
 ck(set(qvalues)=={Q(1),Q(5,4)})
 ck(max(r['R'] for r in receiver)/min(r['R'] for r in receiver)<=2)
 J=[]
 for i,s in enumerate(source):
  J.append(sum((r['volume']/r['mass'] for r in receiver if i in r['capture_indices']),Q(0)))
 packet_I2=sum((s['mass']*j*j for s,j in zip(source,J)),Q(0))
 first=sum((s['mass']*j for s,j in zip(source,J)),Q(0))
 Emeasure=sum((r['volume'] for r in receiver),Q(0))
 ck(first==Emeasure)
 pair_I2=Q(0);pairs=[]
 for ia,a in enumerate(receiver):
  for ib,b in enumerate(receiver):
   common=set(a['capture_indices']).intersection(b['capture_indices'])
   compressed=sum((source[i]['mass'] for i in common),Q(0))
   left=max(a['center']-a['R']/2,b['center']-b['R']/2)
   right=min(a['center']+a['R']/2,b['center']+b['R']/2)
   original=mass(left,right) if left<right else Q(0)
   ck(compressed==original)
   pair_I2+=a['volume']*b['volume']*compressed/(a['mass']*b['mass'])
   if ia<=ib:pairs.append(dict(i=ia,j=ib,intersection_mass=original))
 ck(packet_I2==pair_I2)
 fill=1-2*eta
 ck(Emeasure==fill*original_E)
 corrected=packet_I2/fill**2
 return dict(delta=delta,eta=eta,source_cells=len(source),receiver_cells=len(receiver),
 source=source,receiver=receiver,source_J=J,pair_intersections=pairs,q_min=min(qvalues),q_max=max(qvalues),
 minimum_fullcapture_margin=minimum_margin,receiver_measure=Emeasure,receiver_fill_fraction=fill,
 I2=packet_I2,normalized_M2=q*q*packet_I2/W,analytic_error=packet_I2-I2,
 fill_corrected_I2=corrected,fill_corrected_error=corrected-I2)
results=[refine(Q(1,16),Q(1,8)),refine(Q(1,32),Q(1,16)),refine(Q(1,64),Q(1,32))]
ck(all(abs(results[i+1]['analytic_error'])<abs(results[i]['analytic_error']) for i in range(2)))
ck(all(abs(results[i+1]['fill_corrected_error'])<abs(results[i]['fill_corrected_error']) for i in range(2)))
out=dict(scope='one genuine nonuniform L1 field; three finite refinement checks, not a general approximation proof/history',
 executable=sys.executable,python=platform.python_version(),checks=checks,
 original=dict(f='1[-4,4]+1[-1/8,1/8]',W=W,groups=GROUPS,q_min=Q(1),q_max=Q(5,4),
 receiver_measure=original_E,I2=I2,normalized_M2=I2/W,first_moment=I1,analytic_pieces=pieces),cases=results)
def encode(x):
 if isinstance(x,Q):return str(x)
 raise TypeError(type(x).__name__)
(ROOT/'r452_numeric_certificate.json').write_text(json.dumps(out,default=encode,indent=2)+'\n')
print('executable:',sys.executable,'Python:',platform.python_version())
print('original I2=',I2,'M2=',I2/W,'receiver measure=',original_E,'q-band=[1,5/4]')
for a in results:
 print('delta=',a['delta'],'eta=',a['eta'],'sources=',a['source_cells'],'receivers=',a['receiver_cells'],'measure=',a['receiver_measure'],'margin=',a['minimum_fullcapture_margin'])
 print(' I2=',a['I2'],float(a['I2']),'M2=',a['normalized_M2'],float(a['normalized_M2']))
 print(' error=',a['analytic_error'],'fill_corrected_error=',a['fill_corrected_error'])
print('PASS',checks,'exact checks; 3 refinements, one field, no general theorem certification')
