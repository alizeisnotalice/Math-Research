"""Bounded R452 check: one explicit native selector, not a target counterexample."""
from fractions import Fraction as F
from math import comb
from flint import arb, ctx
ctx.prec = 1024

def ball(q):
    q=F(q)
    return arb(q.numerator)/q.denominator

def exact_poly_integral(n):
    # L_n = constant + (3n/2) log2 + (n^2/2) log2^2.
    # Polynomial coefficients arise from the exact angular box integral.
    constant=F(1)
    for k in range(1,n+1):
        ck=F(comb(n,k)*(-1)**k,2**k)
        if k<n:
            ck += F(n*comb(n-1,k)*(-1)**k*(2**k-1),2*4**k*k)
        constant += ck*(1+F(n,k)*(1-F(1,2**k)))
    log2=arb(2).log()
    L=ball(constant)+ball(F(3*n,2))*log2+ball(F(n*n,2))*log2**2
    bound=(1+n*log2)*(ball(F(3,4))**n+n*log2/2*ball(F(7,8))**(n-1))
    assert L>0
    assert bound-L>0
    peak=1+n*log2/2
    residual_lower=peak**2-2*L
    print(f'n={n}: L_n={L.str(18)}')
    print(f'n={n}: analytic upper={bound.str(18)}; source residual lower={residual_lower.str(18)}')
    return constant

# Direct n=1 evaluation is an independent exact coefficient check.
assert exact_poly_integral(1)==F(1,4)
print('stage 1: direct n=1 coefficient identity PASS')
for stage,n in [('stage 2',16),('stage 3',64)]:
    exact_poly_integral(n)
    print(stage+': 1024-bit Arb containment/positive integral checks PASS')
print('Model: full f=1 on [-2,2]^n, E=[-1,1]^n, R(A)=max(1,2||A||inf), exact q_A=1.')
print('All integrals are analytic Lebesgue integrals of this one selector family; no sampling or LP.')
print('The asymptotic failure of this candidate pointwise dual follows from the displayed analytic exponential bound.')
print('The calculation does not disprove the source-integrated root target; W=4^n.')
