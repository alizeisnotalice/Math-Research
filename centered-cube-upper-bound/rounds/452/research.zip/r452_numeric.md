# R452 共同网格逼近的三层实施核验（冻结）

一条真正非均匀 L¹ 来源、连续 Lebesgue receiver 场的三层共同网格检查全部通过。每层单 cube 质量、所有成对交集质量与原 f 的对应中心 cubes **完全相等**；实际压缩场的 packetwise 与 pairwise 二阶矩也精确相等。67844项 Fraction 检查，未作其他扫描。这是数值实施证据，不是一般逼近定理、原 history 或维数界证明。

## 1. 原连续场及解析基准

先只读 `/tmp/r451_mainproof_check.py` 与 `/tmp/r451_geometry_check.py`，未运行或修改它们。选取前者允许精确解析的 L¹ 场：

`f(x)=1_[−4,4](x)+1_[−1/8,1/8](x)`，总质量 `W=33/4`。

连续 receiver 集合及单值 selector 为：`A∈[−1/4,1/4]` 时 R(A)=1；`A∈[1,5/4]` 时 R(A)=3/2。E 的 Lebesgue 长度3/4，octave比3/2。中央 cubes 完整捕获 bump、remote cubes 完整不捕获，所以完整质量分别为5/4、3/2，真实 q-field 为5/4、1。它是 q-band `[1,5/4]`，**不是 q-exact**。

定义 `J(z)=∫_E 1_{z∈Q_A}/m_A dA`。脚本由 receiver 区间交长直接生成分段 affine J，在 f 的每个常密度段上解析积分二次多项式，得到

`∫fJ=3/4`，`I₂=∫fJ²=2507/10800`，

`M₂=q_min² I₂/W=2507/89100`，其中 q_min=1。

JSON保存每个解析分段的端点、J常数/线性系数、f密度及该段I₂，全部有理数，没有数值 quadrature。原 receiver 是整段 Lebesgue 场，并非只对离散代表点求目标。

## 2. 共同网格的实际实现

只用三层 `(δ,η)=(1/16,1/8),(1/32,1/16),(1/64,1/32)`。source Voronoi cells 是 `δk+[−δ/2,δ/2]`。逐 cell 精确计算原 f 质量，并压到中心δk、半宽ηδ/4的正体积 packet；压缩后 f_δ 是非负 L¹ 函数，保持总质量33/4。

receiver 中心为 `c_j=δ(j+1/2)`，只取原两个 receiver 区间内的格 cell。每个 block 半宽 `(1/2−η)δ`，取其原区间对应的 R。两 side 在所有层均为2δ的整数倍，因此每个中心 cube 的边界均为 source Voronoi cell 边界，是这些 cells 的精确并。

脚本对每个 packet×receiver block 验证：在整个 block 上，实际 cube 对整个 packet 严格全捕获或严格全不捕获；没有中心点替代整个 block。完整质量等于原 f 中心 cube 的质量。对每对中心 cubes，packet捕获集合交的总质量严格等于原 f 的真实 cube intersection 质量。

block之间严格不交；真实 receiver measure 为 `(1−2η)|E|`，没有将丢失 gaps 当作已填体积。本例 side无需round，bump又始终全捕获或全不捕获，所以压缩场 q-band 原样 `[1,5/4]`，无需放宽。这里不把这点推广为一般网格化不需 q-band 放宽。

压缩源不声称 L¹趋近原 f。实际上 packet支撑体积随η缩小，不能用 L¹收敛解释本实验；使用的是总质量、cube及cube-pair质量的精确保留和 receiver 积分逼近。

## 3. 三阶段实际结果

| 阶段 | δ；η | 正质量source cells / receiver blocks | 实际receiver measure | 严格capture margin | I₂近似 | M₂近似 |
|---|---|---|---|---|---:|---:|
| 初步 | 1/16；1/8 | 129 / 12 | 9/16 | 3/512 | .130791015625 | .01585345643939 |
| 压力 | 1/32；1/16 | 257 / 24 | 21/32 | 3/2048 | .1777984619140625 | .02155132871686 |
| 有限精细化 | 1/64；1/32 | 513 / 48 | 45/64 | 3/8192 | .2040414810180664 | .02473230072946 |

表中小数只作显示，JSON保存实际 Fraction。三层 I₂精确为 `13393/102400`、`58261/327680`、`213953/1048576`；M₂精确为 `13393/844800`、`58261/2703360`、`213953/8650752`。它们与原解析基准的绝对误差逐层严格下降。

实际未填 receiver 体积是主误差来源。将 I₂近似除以实际填充率平方 `(1−2η)²` 后，与原 I₂的差精确为

`67/172800`、`67/691200`、`67/2764800`。

三层均等于 `(67/675)δ²`，每次缩小为四分之一；这是本例三项实际数据的精确关系，不将有限关系冒称一般误差阶定理。

同时逐层核 `∑packet mass·Jδ = |Eδ|`。计算 `∑packet mass·Jδ²` 与 `∑receiver-pairs volume_i volume_j·原intersectionmass/(m_i m_j)` 精确一致。此处 pair质量精确保留是关键，未用“压缩f在L¹逼近”作理由。

## 4. 复现与范围

命令：

```sh
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/r452_numeric.py
```

实际解释器为上述路径，Python3.12.14；全部数学运算为标准库 Fraction，无舍入误差。实际运行 .28秒，最大RSS23,363,584 bytes。脚本只写自身目录 JSON，完整输入内置；读取别人脚本仅用于选择已有场，不构成运行依赖。未git/spawn、未改repo或他人文件。

冻结白名单：`r452_numeric.py`、`r452_numeric_certificate.json`、`r452_numeric_run.txt`、`r452_numeric_resources.txt`、`r452_numeric.md`、`r452_numeric_compute_index.md`。三层执行完成，停止；不从此例认证一般 q-band/octave 任意场的逼近定理。
