from fractions import Fraction as F

# Exact three-source-region test of the proposed incidence dual.
# Regions are intersection, parent-only, witness-only.  This checks the
# algebra, not a native selector or any original high-rank/history gate.
count=0
for M,m,I in [(F(8),F(1),F(1)),(F(8),F(1),F(1,2)),(F(9),F(1),F(0)),(F(10),F(3,2),F(2,3))]:
    mass=[I,M-I,m-I]
    ca=[F(1),F(1),F(0)]; cw=[F(1),F(0),F(1)]
    d=[cw[j]/m-ca[j]/M for j in range(3)]
    assert sum(mass[j]*d[j] for j in range(3))==0; count+=1
    neg=sum(mass[j]*max(-d[j],0) for j in range(3))
    pos=sum(mass[j]*max(d[j],0) for j in range(3))
    assert pos==neg==1-I/M; count+=1
    lhs=[ca[j]*cw[j]/m for j in range(3)]
    rhs=[(d[j]+ca[j]*(1-cw[j])/M)/(1-m/M) for j in range(3)]
    assert all(lhs[j]<=rhs[j] for j in range(3)); count+=1
    assert sum(mass[j]*rhs[j] for j in range(3))==(1-I/M)/(1-m/M); count+=1
    # Actual source-dependent coefficient: off-parent extension is zero.
    r=[F(3,7),F(1,5),F(0)]
    dualcost=sum(mass[j]*ca[j]*r[j]*d[j] for j in range(3))
    old=sum(mass[j]*ca[j]*cw[j]*r[j]/(M*m) for j in range(3))
    parent=sum(mass[j]*ca[j]*r[j]/M for j in range(3))
    assert old==(dualcost+parent)/M; count+=1
    print('M,m,I=',M,m,I,'negative dual mass=',neg,'weighted cost=',dualcost)
print('PASS',count,'Fraction assertions; four local incidence calculations.')
print('No native geometry, original stage gates, or global budget is certified by these scalar checks.')
