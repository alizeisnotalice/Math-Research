from fractions import Fraction as F
from flint import arb, ctx
ctx.prec=256
assert arb(2)<arb(1).exp()<arb(3)

# Native 1D receiver blocks, full source packets, side lengths 1 and 2.
# This is a kernel/interface test, NOT a Pi433-history instance.
packets=[(F(-251,1000),F(-249,1000)),(F(749,1000),F(751,1000))]
source_mass=[F(1),F(3)]
centers=[(F(-3,10),F(-1,5)),(F(0),F(1,10))]
side=[F(1),F(2)]
B=[[1,0],[1,1]]
vol=[r-l for l,r in centers]
for j,(l,r) in enumerate(centers):
    for i,(p,q) in enumerate(packets):
        if B[j][i]:
            assert p>=r-side[j]/2 and q<=l+side[j]/2
        else:
            assert q<l-side[j]/2 or p>r+side[j]/2
mass=[sum(source_mass[i]*B[j][i] for i in range(2)) for j in range(2)]
density=[mass[j]/side[j] for j in range(2)]
assert mass==[1,4] and density==[1,2]
# The mass prefixes below are identical for every K in [2,3], hence for e.
K=F(3); theta=F(1,2)
rho=[vol[j]/mass[j] for j in range(2)]
J=sum(rho)
Z=sum(rho[j] for j in range(2) if mass[j]<mass[1]/K)
assert J==F(1,8) and Z==F(1,10) and Z>theta*J
parent_sigma=density[1]*vol[1]
pi_old=F(1,4); pi_new=F(3,4)
R=parent_sigma*pi_old*pi_new
exclusive_accept=F(1)
outmass=R*exclusive_accept
outdensity=outmass/(density[0]*vol[0])
formula=vol[1]/side[1]*pi_new/Z/density[0]
assert R==F(3,80) and outdensity==F(3,8) and formula==outdensity
assert outdensity<=F(2)/theta
assert sum(rho[j] for j in range(2) if mass[j]<mass[0]/K)==0
assert outmass==R
print('PASS native: complete capture/matching, strict K descent, relative input, exact output column')
print('J=',J,'Z_parent=',Z,'input/output mass=',R,'output density=',outdensity)

# Inclusive CDF and strict-past endpoint checks, including tied mass atoms.
cases=[([1,3,9],[F(1,5),F(3,10),F(1,2)]),
       ([1,1,3],[F(1,4),F(1,3),F(5,12)]),
       ([1,2,2,8],[F(1,10),F(1,5),F(3,10),F(2,5)])]
count=0
for masses,weights in cases:
    total=sum(weights)
    for k in (F(2),F(3)):
        for eta in (F(1,5),F(1,2),F(4,5)):
            low=[]; windowmax=F(0)
            for m in masses:
                past=sum(w for m2,w in zip(masses,weights) if m2<m/k)
                closed=sum(w for m2,w in zip(masses,weights) if m2<=m)
                window=sum(w for m2,w in zip(masses,weights) if m/k<=m2<=m)
                assert closed==past+window
                windowmax=max(windowmax,window)
                low.append(past<=eta*total)
                if low[-1]: assert closed<=eta*total+window
            lowmass=sum(w for w,flag in zip(weights,low) if flag)
            assert lowmass<=eta*total+windowmax
            count+=1
print('PASS CDF:',count,'finite rank configurations (not native-center tests)')

def log_lower(r):
    assert r>=1
    z=(r-1)/(r+1)
    return 2*sum((z**(2*j+1)/F(2*j+1) for j in range(120)),F(0))

rankcount=0
for masses,weights in cases:
    total=sum(weights)
    for k in (F(2),F(3)):
        data=[]
        for m,w in zip(masses,weights):
            past=sum(w2 for m2,w2 in zip(masses,weights) if m2<m/k)
            left=sum(w2 for m2,w2 in zip(masses,weights) if m2<m)
            right=sum(w2 for m2,w2 in zip(masses,weights) if m2<=m)
            data.append((w,past,left,right))
        model_window=max(right-past for _,past,_,right in data)
        for H0 in (F(1,20),F(1,5),F(2,5)):
            for theta2 in (F(1,5),F(1,2),F(4,5)):
                cut=max(H0,theta2*total)
                eligible=[row for row in data if row[1]>cut]
                assert all(left>cut for _,_,left,_ in eligible)
                rankint=sum((w/right for w,_,_,right in eligible),F(0))
                rawint=sum((w/past for w,past,_,_ in eligible),F(0))
                lower=log_lower(total/cut)
                assert rankint<=lower
                assert rawint<=(1+model_window/H0)*rankint
                assert rawint<=(1+model_window/H0)*lower
                rankcount+=1
print('PASS strict-left log:',rankcount,'exact rational checks; native window not imposed on atoms')
print('Scope: no certification of original high-h, current, paths, or full Pi433 history.')
