# R456 计算索引

- 责任：Sol medium，仅/tmp/r456_numeric*；无repo/他人修改、git或spawn。
- 阅读：r455_numeric.py、r455_direct_budget.md；与r321同步具体模型，未重复其独立fixture/general证明。
- 一个真实L1 fullcapture基型：两source packets、三个真实receiver区间。三case：等权side1 τ1/4、同场空高门τ1/2、不等质量centralR2 τ1/4；无扫描。
- 核：joint参考σπ²；固定pair父G、source刷新S各自可逆幂等；fullSG仅不变非可逆；parent DA投影真可逆。精确p门切分、真实center体积、完整mass/qband均保留。
- 费用：原base低集density1的累计boundary RN max、尾、期望停时；每N1,2,4,8 exact Green/质量恒等；有理inverse；fiber(d,c)、M1及fresh最终帽下必丢量。
- 核心结果：eq frozen cap3/2残留1/6，fresh cap2残留0、mean7/2；uneq frozen cap4/3残留4/45，fresh cap19/12残留0、mean25/9。高集为空时保持全尾，不虚报覆盖。
- 实跑：指定数学Python3.12.14，Fraction；224checks PASS，.02s、RSS21,643,264bytes。
- 输出：r456_numeric.py、r456_numeric_certificate.json、r456_numeric_run.txt、r456_numeric_resources.txt、r456_numeric.md、此index。同目录自含复现。
- 范围：有限核/费用证据，无原strict-K/history、一般混合率或统一boundary帽认证。
- 状态：冻结停止。
