from fractions import Fraction as F
from itertools import product
checks=0
sigma=[F(3,10),F(9,25)]
pi=[[F(1,3),F(2,3),F(0)],[F(0),F(1,2),F(1,2)]]
pairs=list(product(range(3),repeat=2))
joint=[[sigma[a]*pi[a][y]*pi[a][z] for y,z in pairs] for a in range(2)]
nu=[sum(joint[a][x] for a in range(2)) for x in range(9)]
post=[[joint[a][x]/nu[x] if nu[x] else F(0) for a in range(2)] for x in range(9)]
T=[[sum(pi[a][y]*pi[a][z]*post[x][b] for x,(y,z) in enumerate(pairs)) for b in range(2)] for a in range(2)]
print('Stage 1: actual positive center blocks, side 1; source packet masses 1,2,2.')
for a in range(2):
 assert sum(T[a])==1;checks+=1
 for b in range(2):
  assert sigma[a]*T[a][b]==sigma[b]*T[b][a];checks+=1
assert T[1][0]==F(10,67);checks+=1
print('sigma=',sigma,'T=',T)
print('Stage 2: killed flow; high-p event is first center block, tau=19/200.')
g=[F(0),F(1)]
v=[F(0),F(0)]
total_hit=F(0)
for N in range(1,33):
 v=[v[a]+g[a] for a in range(2)]
 qg=[sum(post[x][a]*g[a] for a in range(2)) for x in range(9)]
 hit=sum(joint[0][x]*qg[x] for x in range(9))
 total_hit+=hit
 g=[F(0),sum(pi[1][y]*pi[1][z]*qg[x] for x,(y,z) in enumerate(pairs))]
 qv=[sum(post[x][a]*v[a] for a in range(2)) for x in range(9)]
 hit_from_green=sum(joint[0][x]*qv[x] for x in range(9))
 assert total_hit==hit_from_green;checks+=1
 assert total_hit+sum(sigma[a]*g[a] for a in range(2))==sigma[1];checks+=1
 assert max(qv[x] for x in range(9) if joint[0][x])==F(27,10)*(1-F(57,67)**N);checks+=1
 if N in (1,4,32):
  print('N=',N,'hit=',float(total_hit),'boundary density cap=',float(max(qv[x] for x in range(9) if joint[0][x])))
assert F(27,10)*(1-F(57,67)**4)>1;checks+=1
print('Exact infinite boundary cap=27/10; this exceeds the single-step cap 1.')
print('Stage 3: zero and disconnected incidence endpoints.')
for weight in (F(0),F(1,7),F(1)):
 # Disjoint source packets make the collapsed kernel the identity.
 Td=[[F(1),F(0)],[F(0),F(1)]]
 state=[F(0),weight]
 for N in (1,3,20):
  after=[state[0]*Td[0][a]+state[1]*Td[1][a] for a in range(2)]
  assert after==state;checks+=1
  assert after[0]==0;checks+=1
print('PASS',checks,'Fraction assertions.')
print('The first two stages are exact continuous-center/source-packet reductions; all centers have q=3 or 4.')
print('They do not satisfy original strict-far/history gates. Stage 3 is a separate finite incidence endpoint check.')
