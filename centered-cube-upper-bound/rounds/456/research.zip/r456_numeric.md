# R456 冻结来源对与刷新来源的首达费用（冻结）

一个真实一维fullcapture基型、三个有目的case的精确结果：刷新source可清除冻结mixed-source fiber的不灭残留，但累计首次命中高p集的密度帽会放大，不能由stationarity或reversibility免费付成1。等权场的最终帽为2，N=4已为37/25；不等质量两尺度场最终为19/12。224项Fraction检查通过，未做scan或一般混合率推断。

## 1. 真实场、门与参考测度

复用R455内置基型，未改别人文件。source为以±1/4为中心、半宽1/1000的两个正体积packet；其常密度质量记a_0,a_1。receiver区间 L=[−3/5,−2/5]、O=[−1/20,1/20]、R=[2/5,3/5]，真实长度(1/5,1/10,1/5)。脚本验证整个packet×receiver区间capture为(1,0),(1,1),(0,1)。

- 初探：a=(1/2,1/2)，side=(1,1,1)，完整mass=(1/2,1,1/2)，qband[1/2,1]，X=3/10，τ1/4。
- 幂等/零命中压力：同场仅τ改1/2，高集真实为空。
- 有限扩大：a=(1/3,2/3)，side=(1,2,1)，完整mass=(1/3,1,2/3)，qband[1/3,2/3]，X=1/4，τ1/4。

W均1、octave≤2，但没有原strict-K质量差、stage/history或winner资格。参考是完整原静态双来源measure

`M(dA,i,j)=σ(dA)π_A(i)π_A(j)=a_i a_j B_Ai B_Aj dA/(R_A m_A)`。

其总量X=∫σ。文中数值Markov参考μ=M/X，父边缘μ_A=σ/X；将质量乘X即回原base，**密度帽不变**。p仍为实际 `p_i(A)=|E_i∩Q_A|/R_A`。用R455的affine切分法精确求交点，不用center点代门。

τ1/4时高集恰为L中[−1/2,−2/5]、R中[2/5,1/2]，中央O全low；两个outer各占一半。此模型高/低状态对同一parent的所有合法source pairs一致（中央端点零测除外）。因此parent+high/low旗标确实是连续核的精确有限lumping，不是离散几何近似。只在本模型第一来源高门与两来源并集门几乎处处相同，不能推广为一般免因子2。

## 2. 两种Bayes核及可逆性

记区间长度v_B。固定ordered source pair x=(i,j)的父后验是

`q_x(B) ∝ v_B B_Bi B_Bj/(R_B m_B)`。

它在每个真实receiver区间内均匀；高/低子区间按精确长度切分。冻结pair核G始终保x，故G²=G。source刷新核S在保持当前真实parent点时按π_A⊗π_A重抽pair，亦S²=S。两者都对完整joint μ逐项详细平衡，均核验不变测度。

source后父的两块更新在完整joint上是SG，保μ但一般**不详细平衡**；初探和两尺度场的最大详细平衡残差分别为1/40和4/189。不能把两块Gibbs乘积本身称作可逆。

其parent投影是确实可逆的DA核

`P_AB=Σ_x π_A⊗π_A(x) q_x(B)`。

脚本核P与精确parent+flag核对σ/X详细平衡。初探P为

`[[4/5,1/5,0],[1/5,3/5,1/5],[0,1/5,4/5]]`，σ/X=(1/3,1/3,1/3)。

这项区分保留在证书中，没有因投影可逆而宣称带全部原history的刷新核合法。

## 3. endpoint命中不等于累计ever-hit

冻结x后，单次父高门概率为h_x。G幂等只说明一步后的endpoint分布不再变化，**并不说明重复抽父没有累计命中收益**：每轮独立重抽同一条件父时，N轮ever-hit是 `1−(1−h_x)^N`，期望抽父数1/h_x；h_x=0则永不命中、期望∞。

初探h_(00)=h_(11)=2/5，mixed-pair h=0。若先在中央O抽一次pair并永久冻结，则endpoint命中始终1/5，ever-hit极限只有1/2。fresh源后父从同一中央出发：

| N | frozen endpoint | frozen ever-hit | fresh endpoint | fresh ever-hit |
|---:|---:|---:|---:|---:|
| 1 | 1/5 | 1/5 | 1/5 | 1/5 |
| 2 | 1/5 | 8/25 | 7/25 | 2/5 |
| 4 | 1/5 | 272/625 | 203/625 | 17/25 |
| 8 | 1/5 | 192032/390625 | 130123/390625 | 114/125 |

两尺度场冻结central首次pair的ever-hit极限5/9，fresh最终可全命中。空高集压力例两核始终不命中，stationarity不凭空产生高集。

## 4. 主费用：原base低集到boundary的累计RN帽

初始g₀取原base在low的限制，密度为1，而非随意归一到一个点。令K是被high杀死的low核、R是low→high边界核；从初始low mass迭代，精确累加 `v_N=Σ_(t=0..N−1)g₀K^t` 与 `hit_N=v_NR`，保留尾g_N。逐N=1,2,4,8核

`v_N−v_NK=g₀−g_N`，`|g_N|+|hit_N|=|g₀|`。

并利用killed核详细平衡核相同density形式。最终transient部分用有理Gauss–Jordan求(I−K)^−1；closed fibers的非零尾单列，未伪造inverse或强行置零。

下表质量均除原X，边界密度相对同一base_H=μ|high：

| case | 初始low | base_H质量 | frozen最终帽；残留 | fresh最终帽；残留 | fresh条件期望步数 |
|---|---:|---:|---|---|---:|
| 初探τ1/4 | 2/3 | 1/3 | 3/2；1/6 | 2；0 | 7/2 |
| 空高集τ1/2 | 1 | 0 | 0；1 | 0；1 | ∞ |
| 两尺度τ1/4 | 3/5 | 2/5 | 4/3；4/45 | 19/12；0 | 25/9 |

空高集的“帽0”只表示边界measure为0，绝不表示覆盖成功。两个非空例frozen从全low出发期望∞，因mixed fiber有正残留；若只条件于最终可命中的起始部分，平均步数分别5/2、105/46，不能拿这些较小数替全low成本。

初探fresh在N=1,2,4,8的boundary RN帽依次为 `3/5,1,37/25,1161/625`，残留为 `7/15,1/3,13/75,89/1875`。两尺度N4帽为6854838/5274997>1。首达时间有限仍不能推出boundary帽≤1。

初探最终fresh boundary两块质量=(1/3,1/3)，base_H=(1/6,1/6)，故帽2。两尺度最终boundary=(8/45,19/45)，base_H=(2/15,4/15)，两密度=(4/3,19/12)。回原base后，初探fresh首达总质量1/5、high参考1/10；两尺度分别3/20、1/10。未采用随机数proposal运行次数代替这项测度费用。

## 5. 保pair时的fiber容量与必丢量

每个pair的原low量d_x、高参考量c_x如下（表除X，实际原量乘本case X）：

| pair | 初探(d_x,c_x)/X | 两尺度(d_x,c_x)/X |
|---|---|---|
| 00 | (1/4,1/6) | (7/45,2/15) |
| 01 | (1/12,0) | (2/45,0) |
| 10 | (1/12,0) | (2/45,0) |
| 11 | (1/4,1/6) | (16/45,4/15) |

在保pair的静态容量模型中，boundary帽M最多接收Mc_x，故最小丢弃量精确是 `Σ_x(d_x−Mc_x)+`。c_x=0必须丢掉全部d_x；可取每fiber保留min(d_x,Mc_x)构造静态充分性，但不附赠原history上的合法算法或Green费用。

- 初探：M1最小丢弃1/3（原量1/10）；取fresh最终帽M2仍须丢弃1/6（原量1/20）。
- 两尺度：M1最小丢弃1/5（原量1/20）；M19/12仍须丢弃4/45（原量1/45）。
- 空高集：M1或M0均须丢弃全部原量X=3/10。

取fresh最终帽时，两非空例的保pair必丢量恰等于frozen不灭残留，脚本逐fiber核验。这不约束释放pair标签的fresh链；它说明清除该残留与保留原source fibers不是同一机制。

## 6. 复现及范围

```sh
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/r456_numeric.py
```

指定解释器实际Python3.12.14；所有几何、门、核、inverse、Green flux和fiber量均Fraction精确运算。最后冻结运行.02秒、最大RSS21,643,264bytes；224检查PASS。一个基型、一个空门压力、一个质量/side变参；无额外scan、无agent、git、repo或他人修改。与作者另有fixture分开计数，不重复其general证明。

冻结白名单：`r456_numeric.py`、`r456_numeric_certificate.json`、`r456_numeric_run.txt`、`r456_numeric_resources.txt`、`r456_numeric.md`、`r456_numeric_compute_index.md`。脚本自含、同目录输出；完成停止，不声称原strict-K/history资格或一般混合/边界帽。
