# R456 — one strict-mass source refresh and a priced low-relative landing

**Result and limit.** The construction is one actual exclusive jump,
retaining the old source and refreshing only the second source. Its
column and low-relative landing prices follow from the already proved
R411/R413 rank tools; they are not new geometric theorems. The refreshed
conditional source law and its fresh-common estimate are checked
explicitly. This does not close the remaining traffic or give an
iteratable constant column bound.

## 1. The original input and the new auxiliary probability

Write \(\Gamma_0=\sigma(dA)\pi_A(dy)\pi_A(dz)\), with all definitions
as in the R435 contract. Let the static projection of the original
two-end low-p submeasure be
\[
d\rho=S L(A,y,z)\,d\Gamma_0,\qquad 0\le L\le1,\qquad R=\rho(\mathrm{all}).
\]
All original stage, current, early, path, and other restrictions are in
this RN density. On its positive support,
\[
Z_A(y)>\theta J(y),\quad Z_A(y)>(4-\varepsilon_0)h,
\quad C_A(y,z)<h,
\qquad \theta=\theta_y>0.
\]
Put \(c_*=(3-\varepsilon_0)/(4-\varepsilon_0)>0\). The actual
subprobability kernel
\[
Q_{A,y,z}(du)=
\frac{1_{\{m_u<m_A/K\}}(1-c_u(z))}{Z_A(y)}\,\rho_y(du)
\tag{1}
\]
has total mass \(b_A(y,z)=1-C_A(y,z)/Z_A(y)\ge c_*\). Thus
\(\widehat Q=Q/b_A\) is a probability kernel on the original positive
support. First draw \(u\) from this kernel; then draw \(z'\) from the
full actual \(\pi_u\). Keep \(y\) unchanged and keep the original
record as a label. In particular \(m_u<m_A/K\), and \(u\) is an actual
Lebesgue receiver. No old history is assigned to the auxiliary \(u,z'\).

## 2. Exact output density and the relative-rank improvement

For the unconditioned kernel (1), let
\[
B_{Au}(y)=\int\pi_A(dz)L(A,y,z)(1-c_u(z)).
\]
The output at \((u,y,z')\), relative to
\(\sigma(du)\pi_u(dy)\pi_u(dz')\), has density
\[
d_0(u,y)=\frac{S}{q_u}
\int_{\{m_A>K m_u\}}
 \frac{c_A(y)}{R_A^n}\frac{B_{Au}(y)}{Z_A(y)}\,dA.
\tag{2}
\]
This follows by writing every factor in (1) and using the two factors
\(m_u^{-1}\) in \(\pi_u(dy)\pi_u(dz')\); no receiver measure is
replaced. Terms with zero incoming weight are zero. When \(B_{Au}>0\),
the original relative gate gives \(Z_A(y)>\theta J(y)\). Since
\(B_{Au}\le1\) and
\(\int c_A(y)R_A^{-n}dA\le\lambda J(y)\),
\[
0\le d_0(u,y)\le C_0:=\frac{Sr}{\theta},\qquad r=\lambda/q.
\tag{3}
\]
For \(\widehat Q\), the exact formula has
\(L/b_A(y,z)\) inside the \(z\)-integral; it cannot be factored out as
a function of \((A,y)\). It gives
\[
0\le d_*(u,y)\le C_*:=\frac{Sr}{c_*\theta}.
\tag{4}
\]
The conditioned output \(\widehat\rho\) has mass exactly \(R\). Its
density is independent of \(z'\), because that source was actually
drawn from \(\pi_u\). The constants in (3)--(4) retain their full
\(S,r,\theta,\varepsilon_0\) dependence. The inverse-\(\theta\) bounds
are only convenient coarse bounds, not improvements on the old
logarithmic relative-rank bounds.

**Inherited high-rank-window improvement.** The strict-left mass-quantile
argument in R411 geometry (3), (10)--(11) improves these constants; it is
an existing tool, not a second new geometric result. Put
\[
H_0=(4-\varepsilon_0)h,\qquad B_K=s/q,\qquad
J_{\max}=A_n/q,\qquad A_n=1+n\log(b/a).
\]
The inclusive rank \(T_y(m)=\rho_y\{u:m_u\le m\}\) satisfies
\(T_y(m_A)\le Z_A(y)+B_K\). On the
original support \(Z_A(y)>H_0\),
\[
\frac1{Z_A(y)}\le
\left(1+\frac{B_K}{H_0}\right)\frac1{T_y(m_A)}.
\]
Moreover the left rank \(F_y(m_A)=\rho_y\{u:m_u<m_A\}\) is strictly
larger than \(d_y=\max\{H_0,\theta J(y)\}\) on the original support.
Expanding each mass atom into its rank interval,
\(\mathrm{atom}/T_{\rm right}\le\int_{F}^{T_{\rm right}}dt/t\);
the whole eligible interval lies above \(d_y\). The continuous part
uses the same CDF change of variables. Thus
\[
\int_{Z_A(y)>d_y}\frac{\rho_y(dA)}{T_y(m_A)}
\le\log_+\frac{J(y)}{d_y}.
\tag{4a}
\]
There is no first-crossing-atom correction. If \(J(y)\le H_0\), the
eligible set is empty. Since \(h=s/(\varepsilon_0q)\), a valid uniform
replacement for (3)--(4) is
\[
\widetilde C_0=\frac{4Sr}{4-\varepsilon_0}\,
 \log_+\min\left\{\frac{J_{\max}}{H_0},\frac1\theta\right\},
\qquad \widetilde C_*=\frac{4Sr}{3-\varepsilon_0}\,
 \log_+\min\left\{\frac{J_{\max}}{H_0},\frac1\theta\right\}.
\tag{4b}
\]
All subsequent occurrences of \(C_*\) may use \(\widetilde C_*\).
For \(\theta\ge1\) the original input is empty. If the constant in
(4b) is zero, the input is also empty; no division to
choose a threshold is needed. The original formulas remain valid as
looser alternatives, and are not separate fees.

The exclusion factor has not been silently discarded from the exact
formula. If \(\ell_A(y)=\int L\,d\pi_A\), full matching gives
\[
0\le\ell_A(y)-B_{Au}(y)
\le\pi_A(Q_u)\le m_u/m_A<1/K.
\tag{5}
\]
Consequently the **unconditioned** output without exclusion differs
from (2) by a nonnegative density at most \(C_0/K\). This absolute
comparison supplies no fixed relative reduction of the retained column;
it is not used as a negative credit.

## 3. A genuine low-relative landing price, including atoms

For \(0<\eta<1\), define
\(I_\eta(y)=\{u:Z_u(y)\le\eta J(y)\}\). A native mass-window bound is
\[
\rho_y\{M/K\le m_u\le M\}\le B_K:=\frac{1+\log K}{q}.
\tag{6}
\]
Indeed \(m_u\ge qR_u^n\) and capture of \(y\) force the center
distance bound; integrate the envelope
\(1/\max(M/K,q(2\|u-y\|_\infty)^n)\) inside
\(q(2\|u-y\|_\infty)^n\le M\). Its inner volume contributes \(1/q\)
and its shell contributes \((\log K)/q\). Both mass endpoints are
included.

Let \(T_y(m)=\rho_y\{w:m_w\le m\}\). Strict past and inclusive rank
satisfy \(T_y(m_u)-Z_u(y)\le B_K\). Thus
\(I_\eta(y)\subset\{u:T_y(m_u)\le\eta J(y)+B_K\}\). The mass of a
sublevel of the inclusive CDF is at most its level, including tied
atoms. Hence
\[
\rho_y(I_\eta(y))\le\eta J(y)+B_K.
\]
Using full matching and \(\int fJ=|E|\le X/q\),
\[
\int\sigma(du)\pi_u(dy)1_{I_\eta(y)}
\le r\eta X+r(1+\log K)W.
\tag{7}
\]
Combining (4) and (7) yields the actual landing price
\[
\boxed{\quad
\widehat\rho\{u\in I_\eta(y)\}
\le C_*r\eta X+C_*r(1+\log K)W.
\quad}
\tag{8}
\]
Since \(K=e^{\sqrt n}\), \(1+\log K=s\). Taking
\(\eta=\min\{1/2,\varepsilon/(C_*r)\}\) makes (8) at most
\(\varepsilon X+C_*rsW\). The \(\varepsilon X\) charge needs its
actual place in the mother budget; it is not free.

For clarity, the original positive fraction being paid is exactly
\[
\omega(A,y,z)=\widehat Q_{A,y,z}(I_\eta(y)),\qquad
\rho=\omega\rho+(1-\omega)\rho.
\tag{9}
\]
Pull (9) back to full original records. Its paid mass equals the left
side of (8); history is retained on both original fractions. The raw
subprobability version instead has output mass at least \(c_*R\) and
price \(C_0\) in (8). These are alternative bookkeeping choices, not
two charges to add.

## 4. The exact surviving issue; a fresh common-capture bound

The unpaid lifted measure has \(Z_u(y)>\eta J(y)\), strict mass
descent, and the same original labels. It is not asserted to satisfy
the original current-stage, second-source rank, or path gates at the
new parent. Reapplying (3) with the new relative parameter would in
general multiply column constants; finite descending depth does not
turn this into a summable source price. The unresolved step is a
uniform or summably drifting **actual receiving-column bound for the
continued flow**, together with the cumulative landing cost. Formula
(8) proves only one landing price, not that a fixed fraction lands.

Fresh common capture does admit a precise estimate and should not be
listed as wholly uncontrolled. At fixed \((u,y)\), full matching gives
\[
\int\pi_u(dz')C_u(y,z')
=\int_{m_v<m_u/K}\rho_y(dv)\pi_u(Q_v)
\le Z_u(y)/K.
\]
With \(J\le A_n/q\), where \(A_n=1+n\log(b/a)\), the output (4)
therefore satisfies
\[
\widehat\rho\{C_u(y,z')\ge h\}
\le\min\{1,A_n/(qKh)\}\,R.
\tag{10}
\]
This uses its actual conditional \(\pi_u\) law, so no extra column
factor is needed for this single relative-to-\(R\) bound. It also holds
after restrictions depending only on \((u,y)\). It does not justify
repeated column bounds or assign any missing history; no repeated fee
or absorption is claimed here.

## 5. Bounded local evidence

`/tmp/r456_geometry_check.py` was actually run with the designated math
Python; stdout is `/tmp/r456_geometry.result.txt`. It verifies a native
one-dimensional field with disjoint positive-volume center intervals,
full source packets, selected sides 1 and 2, and matched band \([1,2]\).
The strict-prefix kernel is identical for \(2\le K\le3\), including
\(K=e\), certified by Arb. Exact Fraction arithmetic gives
\(J=1/8\), \(Z_A=1/10\), original and refreshed mass \(3/80\), and
output density \(3/8\); the landing has zero own past. Eighteen further
finite CDF configurations check strict/inclusive endpoints and tied
atoms. Fifty-four additional checks verify the strict-left logarithmic
integral, using an exact rational lower bound on the logarithm from the
positive atanh series; a discrete model's own window width is used,
not an assumed native bound. They are rank-algebra checks, not
native-center fields.

The native example does **not** satisfy the original high-h/current/
history contract, and is not claimed as an instance of the complete
original paid fraction. It verifies the geometric kernel and matching
calculations only. The general statements (2)--(10) are proved above.
