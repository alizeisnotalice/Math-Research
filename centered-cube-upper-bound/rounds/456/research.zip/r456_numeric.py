#!/usr/bin/env python3
"""One genuine 1D fullcapture family: frozen-pair and refreshed-pair Bayes kernels."""
from fractions import Fraction as Q
from pathlib import Path
from itertools import product
import json,sys,platform
ROOT=Path(__file__).resolve().parent
checks=0
def ck(x):
 global checks
 assert x
 checks+=1
def zeros(n,m):return [[Q(0) for j in range(m)] for i in range(n)]
def eye(n):return [[Q(int(i==j)) for j in range(n)] for i in range(n)]
def mm(A,B):return [[sum((x*y for x,y in zip(row,col)),Q(0)) for col in zip(*B)] for row in A]
def rm(v,A):return [sum((v[i]*A[i][j] for i in range(len(v))),Q(0)) for j in range(len(A[0]))]
def mv(A,v):return [sum((x*y for x,y in zip(row,v)),Q(0)) for row in A]
def inverse(A):
 n=len(A);aug=[row[:]+ident for row,ident in zip(A,eye(n))]
 for i in range(n):
  pivot=next(k for k in range(i,n) if aug[k][i])
  aug[i],aug[pivot]=aug[pivot],aug[i];z=aug[i][i];aug[i]=[x/z for x in aug[i]]
  for k in range(n):
   if k!=i:
    z=aug[k][i];aug[k]=[x-z*y for x,y in zip(aug[k],aug[i])]
 return [r[n:] for r in aug]
def stochastic(P,mu):
 ck(all(sum(row)==1 and all(x>=0 for x in row) for row in P))
 ck(rm(mu,P)==mu)
def db(P,mu):ck(all(mu[i]*P[i][j]==mu[j]*P[j][i] for i in range(len(mu)) for j in range(len(mu))))
P_SOURCE=[(Q(-251,1000),Q(-249,1000)),(Q(249,1000),Q(251,1000))]
BASE=[(Q(-3,5),Q(-2,5)),(Q(-1,20),Q(1,20)),(Q(2,5),Q(3,5))]
PAIRS=list(product(range(2),repeat=2));TIMES=(1,2,4,8)
def high_length(Ey,index,tau):
 al,ar,R=Ey[index];cuts=sorted(set([al,ar]+[p+sgn*R/2 for l,r,_ in Ey for p in (l,r) for sgn in (-1,1) if al<p+sgn*R/2<ar]))
 high=Q(0);details=[]
 for l,r in zip(cuts,cuts[1:]):
  mid=(l+r)/2;u=Q(0);v=Q(0)
  for el,er,_ in Ey:
   if max(el,mid-R/2)>=min(er,mid+R/2):continue
   lo=(el,Q(0)) if el>=mid-R/2 else (-R/2,Q(1));hi=(er,Q(0)) if er<=mid+R/2 else (R/2,Q(1))
   u+=(hi[0]-lo[0])/R;v+=(hi[1]-lo[1])/R
  pl,pr=u+v*l,u+v*r;cross=None
  if min(pl,pr)>=tau:amount=r-l
  elif max(pl,pr)<=tau:amount=Q(0)
  else:
   cross=(tau-u)/v;ck(l<cross<r and u+v*cross==tau)
   amount=r-cross if v>0 else cross-l
  ck(0<=amount<=r-l)
  high+=amount;details.append(dict(left=l,right=r,p_intercept=u,p_slope=v,crossing=cross,high_length=amount))
 return high,details

def killed(P,mu,high_flags,closed_low=None):
 low=[i for i,h in enumerate(high_flags) if not h];hi=[i for i,h in enumerate(high_flags) if h]
 K=[[P[i][j] for j in low] for i in low];R=[[P[i][j] for j in hi] for i in low]
 base_low=[mu[i] for i in low];base_hi=[mu[i] for i in hi]
 g=base_low[:];occ=[Q(0)]*len(low);boundary=[Q(0)]*len(hi);finite=[]
 for t in range(1,max(TIMES)+1):
  occ=[x+y for x,y in zip(occ,g)]
  if hi:boundary=[x+y for x,y in zip(boundary,rm(g,R))]
  g=rm(g,K)
  if t in TIMES:
   ock=rm(occ,K)
   ck([x-y for x,y in zip(occ,ock)]==[x-y for x,y in zip(base_low,g)])
   # Density version uses reversibility on the killed low set.
   density=[x/y for x,y in zip(occ,base_low)];Kd=mv(K,density)
   ck([x-y for x,y in zip(density,Kd)]==[1-x/y for x,y in zip(g,base_low)])
   ck(sum(g)+sum(boundary)==sum(base_low))
   cap=max((x/y for x,y in zip(boundary,base_hi)),default=Q(0))
   finite.append(dict(N=t,tail_mass=sum(g),boundary_mass=sum(boundary),boundary_measure=boundary[:],boundary_density_max=cap))
 closed=set(closed_low or [])
 trans=[k for k,i in enumerate(low) if i not in closed]
 closed_mass=sum((mu[i] for i in closed),Q(0))
 if trans:
  Kt=[[K[i][j] for j in trans] for i in trans]
  fundamental=inverse([[Q(int(i==j))-Kt[i][j] for j in range(len(trans))] for i in range(len(trans))])
  occupation=rm([base_low[i] for i in trans],fundamental)
  Rt=[[R[i][j] for j in range(len(hi))] for i in trans]
  hit=rm(occupation,Rt) if hi else []
  ck(sum(hit)+closed_mass==sum(base_low))
  mean_conditional_capturable=sum(occupation)/sum(base_low[i] for i in trans)
 else:
  hit=[Q(0)]*len(hi);occupation=[];mean_conditional_capturable=None
 cap=max((x/y for x,y in zip(hit,base_hi)),default=Q(0))
 return dict(low_indices=low,high_indices=hi,base_low_mass=sum(base_low),base_high_mass=sum(base_hi),
 base_high_measure=base_hi,finite=finite,final_boundary_measure=hit,final_boundary_mass=sum(hit),final_density_max=cap,
 residual_mass=closed_mass,mean_steps_from_base_low='infinity' if closed_mass else mean_conditional_capturable,
 mean_steps_conditional_capturable=mean_conditional_capturable,killed_matrix=K,boundary_matrix=R)

def run(name,weights,sides,tau):
 E=[(l,r,R) for (l,r),R in zip(BASE,sides)];vol=[r-l for l,r in BASE]
 B=[]
 for l,r,R in E:
  row=[]
  for pl,pr in P_SOURCE:
   hit=pl>r-R/2 and pr<l+R/2;miss=pr<l-R/2 or pl>r+R/2
   ck(hit!=miss);row.append(int(hit))
  B.append(row)
 ck(B==[[1,0],[1,1],[0,1]])
 m=[sum((w*b for w,b in zip(weights,row)),Q(0)) for row in B]
 sigma=[v*mass/R for v,mass,R in zip(vol,m,sides)];X=sum(sigma);parent_mu=[x/X for x in sigma]
 pi=[[w*b/mass for w,b in zip(weights,row)] for row,mass in zip(B,m)]
 pair_prob=[[p[i]*p[j] for i,j in PAIRS] for p in pi]
 post=[];nu=[]
 for pair,(i,j) in enumerate(PAIRS):
  raw=[v*row[i]*row[j]/(R*mass) for v,row,R,mass in zip(vol,B,sides,m)];z=sum(raw)
  ck(z>0);post.append([x/z for x in raw]);nu.append(weights[i]*weights[j]*z/X)
 ck(sum(nu)==1)
 h=[[Q(0)]*4 for _ in range(3)];gates=[]
 for ia,((l,r,R),row) in enumerate(zip(E,B)):
  for ip,(i,j) in enumerate(PAIRS):
   if row[i]*row[j]:
    Ey=[e for e,rr in zip(E,B) if rr[i]];idx=Ey.index(E[ia]);length,detail=high_length(Ey,idx,tau)
    h[ia][ip]=length/vol[ia];gates.append(dict(parent=ia,pair=[i,j],high_fraction=h[ia][ip],pieces=detail))
 common_h=[]
 for a in range(3):
  values={h[a][p] for p in range(4) if pair_prob[a][p]>0};ck(len(values)==1);common_h.append(next(iter(values)))
 # Exact frozen-pair joint state including genuine high/low center subintervals.
 states=[];joint_mu=[]
 for a in range(3):
  for p in range(4):
   if not pair_prob[a][p]:continue
   for flag in (False,True):
    fraction=h[a][p] if flag else 1-h[a][p]
    if fraction:
     states.append((a,p,flag));joint_mu.append(parent_mu[a]*pair_prob[a][p]*fraction)
 G=zeros(len(states),len(states));S=zeros(len(states),len(states))
 for u,(a,p,flag) in enumerate(states):
  for v,(b,t,newflag) in enumerate(states):
   fraction=h[b][t] if newflag else 1-h[b][t]
   if p==t:G[u][v]=post[p][b]*fraction
   if a==b and flag==newflag:S[u][v]=pair_prob[a][t]
 stochastic(G,joint_mu);db(G,joint_mu);stochastic(S,joint_mu);db(S,joint_mu)
 ck(mm(G,G)==G and mm(S,S)==S)
 SG=mm(S,G);stochastic(SG,joint_mu)
 sg_db_error=max(abs(joint_mu[i]*SG[i][j]-joint_mu[j]*SG[j][i]) for i in range(len(states)) for j in range(len(states)))
 frozen_h=[sum((post[p][a]*h[a][p] for a in range(3)),Q(0)) for p in range(4)]
 closed=[u for u,(a,p,flag) in enumerate(states) if not flag and frozen_h[p]==0]
 frozen=killed(G,joint_mu,[flag for a,p,flag in states],closed)
 # Refresh both sources, then Bayes-parent DA chain on actual parent centers.
 P=[[sum((pair_prob[a][p]*post[p][b] for p in range(4)),Q(0)) for b in range(3)] for a in range(3)]
 stochastic(P,parent_mu);db(P,parent_mu)
 parent_states=[];flag_mu=[]
 for a in range(3):
  for flag in (False,True):
   fraction=common_h[a] if flag else 1-common_h[a]
   if fraction:parent_states.append((a,flag));flag_mu.append(parent_mu[a]*fraction)
 PF=zeros(len(parent_states),len(parent_states))
 for i,(a,flag) in enumerate(parent_states):
  for j,(b,newflag) in enumerate(parent_states):PF[i][j]=P[a][b]*(common_h[b] if newflag else 1-common_h[b])
 stochastic(PF,flag_mu);db(PF,flag_mu)
 closed_fresh=[i for i,(a,flag) in enumerate(parent_states) if not flag] if not any(common_h) else []
 refreshed=killed(PF,flag_mu,[flag for a,flag in parent_states],closed_fresh)
 # Compare endpoint vs ever-hit for the natural central-parent starting law.
 initial_pair=pair_prob[1];fixed_times=[]
 r=[sum((P[a][b]*common_h[b] for b in range(3)),Q(0)) for a in range(3)]
 Qparent=[[P[a][b]*(1-common_h[b]) for b in range(3)] for a in range(3)]
 frozen_limit=sum((w for w,hp in zip(initial_pair,frozen_h) if hp>0),Q(0))
 endpoint=r[:];survival=[Q(0),Q(1),Q(0)]
 for t in range(1,max(TIMES)+1):
  survival=rm(survival,Qparent)
  if t in TIMES:
   fixed_times.append(dict(N=t,frozen_endpoint=sum((w*hp for w,hp in zip(initial_pair,frozen_h)),Q(0)),
    frozen_ever_hit=sum((w*(1-(1-hp)**t) for w,hp in zip(initial_pair,frozen_h)),Q(0)),
    refreshed_endpoint=endpoint[1],refreshed_ever_hit=1-sum(survival)))
  endpoint=mv(P,endpoint)
 pair_fibers=[]
 for p,pair in enumerate(PAIRS):
  c=nu[p]*frozen_h[p];d=nu[p]-c
  pair_fibers.append(dict(pair=pair,base_pair_mass=nu[p],high_reference_c=c,original_low_d=d,
   frozen_one_draw_high=frozen_h[p],frozen_parent_draws_to_hit=(1/frozen_h[p]) if frozen_h[p] else 'infinity',
   final_boundary_density=(d/c) if c else None))
 discards=[]
 for cap in (Q(1),refreshed['final_density_max']):
  terms=[max(Q(0),f['original_low_d']-cap*f['high_reference_c']) for f in pair_fibers]
  discards.append(dict(M=cap,per_pair_discard=terms,minimum_discard_normalized=sum(terms),minimum_discard_absolute=X*sum(terms)))
 for p,f in enumerate(pair_fibers):
  got=sum((mass for idx,mass in zip(frozen['high_indices'],frozen['final_boundary_measure']) if states[idx][1]==p),Q(0))
  ck(got==(f['original_low_d'] if f['high_reference_c'] else Q(0)))
 ck(sum((f['original_low_d'] for f in pair_fibers if not f['high_reference_c']),Q(0))==frozen['residual_mass'])
 ck(discards[-1]['minimum_discard_normalized']==frozen['residual_mass'])
 ck(sum(f['original_low_d'] for f in pair_fibers)==frozen['base_low_mass'])
 ck(sum(f['high_reference_c'] for f in pair_fibers)==frozen['base_high_mass'])
 return dict(name=name,n=1,tau=tau,source_packets=P_SOURCE,source_mass=weights,receivers=E,receiver_volume=vol,
 full_receiver_mass=m,q_min=min(mass/R for mass,R in zip(m,sides)),q_max=max(mass/R for mass,R in zip(m,sides)),W=sum(weights),X=X,
 parent_reference_sigma=sigma,parent_stationary=parent_mu,pair_source_prob=pair_prob,parent_given_pair=post,pair_stationary=nu,
 gates=gates,joint_states=states,joint_stationary=joint_mu,frozen_G=G,source_S=S,full_SG_detailed_balance_error=sg_db_error,
 refreshed_parent_P=P,refreshed_parent_flag_states=parent_states,refreshed_parent_flag_P=PF,
 frozen=frozen,refreshed=refreshed,central_start_times=fixed_times,frozen_central_start_hit_limit=frozen_limit,
 pair_fibers=pair_fibers,retained_pair_boundary_cap_discards=discards)
results=[run('initial_equal_side',[Q(1,2),Q(1,2)],[Q(1)]*3,Q(1,4)),
 run('empty_high_pressure',[Q(1,2),Q(1,2)],[Q(1)]*3,Q(1,2)),
 run('unequal_mass_two_side',[Q(1,3),Q(2,3)],[Q(1),Q(2),Q(1)],Q(1,4))]
out=dict(scope='one genuine fullcapture 1D family; finite reversible kernels/Green/boundary prices, no strict-K/history or general mixing claim',
 executable=sys.executable,python=platform.python_version(),checks=checks,cases=results)
def enc(x):
 if isinstance(x,Q):return str(x)
 raise TypeError(type(x).__name__)
(ROOT/'r456_numeric_certificate.json').write_text(json.dumps(out,default=enc,indent=2)+'\n')
print('executable:',sys.executable,'Python:',platform.python_version())
for a in results:
 print(a['name'],'tau=',a['tau'],'X=',a['X'],'qband=',a['q_min'],a['q_max'])
 print(' fixed-pair: cap=',a['frozen']['final_density_max'],'residual=',a['frozen']['residual_mass'],'mean=',a['frozen']['mean_steps_from_base_low'])
 print(' refreshed: cap=',a['refreshed']['final_density_max'],'residual=',a['refreshed']['residual_mass'],'mean=',a['refreshed']['mean_steps_from_base_low'])
 print(' fibers:',[(z['pair'],z['original_low_d'],z['high_reference_c']) for z in a['pair_fibers']])
 print(' discards:',[(z['M'],z['minimum_discard_normalized']) for z in a['retained_pair_boundary_cap_discards']])
 print(' finite refreshed:',[(z['N'],z['tail_mass'],z['boundary_density_max']) for z in a['refreshed']['finite']])
print('PASS',checks,'Fraction checks; three purposeful cases, no scan')
