# R456 independent audit — FINAL PASS（限定刷新接口与旧工具应用）

FINAL PASS：认证本轮保原记录的一步strict-K刷新列公式/落点分数价格、保pair精确容量式，以及Gibbs first-hit/Green/terminal身份和完整充分证书。**一步列帽和rank窗是R411/R413旧工具的复核应用，不计新一般引理；未取得原双低交集、跨代列容量或一般根阶总预算。** 无固定覆盖比例、免费迭代或历史转授。保留原初查于后；不将其当最终完整证明。

## 1. 实际strict-K刷新

精确输出式(2)的q_u、m_A/m_u及V_A权正确。Raw Q为subprob、行量b=1−C/Z≥c*；逐原记录概率化Q/b后保持全部质量，L/b必须留在旧z积分内。新z'真实独立抽自π_u，所以静态输出密度不依z'；原history只在第一原记录和其实际RN中保留。

原relative门给Sr/θ及Sr/(c*θ)粗帽。最终加强也正确：strict Z>max(H0,θJ)使parent质量原子的左秩大于该阈值；T_inc−Z≤s/q。每个原子w/T_right≤∫left^right dt/t，无首跨原子+1。因此normalized帽可取

    Cbar=4Sr/(3−eps0) ·log_+min{Jmax/H0,1/θ}。

这与已读R411(7)–(11)及R413的旧列论证相同，Qhat正是原exclusive概率核，附π_u为保列扩张。稿件已准确归属，不以重证旧界算新进展。θ≥1、Cbar0或原输入为空的零流先处理，不作阈值除零。

单侧closed质量窗[M/K,M]保两端原子，native径向base+shell为(1+logK)/q；inclusive CDF sublevel给基底价rηX+r(1+logK)W，实际输出需乘**整份**C*或Cbar。选新rank阈值η使X费≤εX后，原正分数由Qhat(Iη)拉回完整原Π，补集精确保留。该新η是分析阈值，不改原Fhat中既有的clipping参数。Raw/normalized及粗/强帽是替代计法，不能加总。

式(5)排除修正只对unconditioned输出：ℓ−B≤I_Au/m_A<1/K给非负绝对density差≤C0/K，不是负信用或固定相对减量。Fresh-common式(10)依赖实际z'|u,y=π_u，平均C_u≤Z_u/K，故坏共同捕获质量≤min(1,A_n/(qKh))R，无额外列帽；保u,y条件仍可用。它未赋新父current/relative/history，也未授权过滤z'后免费重复该条件law。

## 2. 保pair容量与累计刷新

Transport的源pair边缘ν、条件父law R_x和barL0归一正确；不变pair类、边界帽SM的最小未运质量确为S∫(barL0−Mh)+dν。逐fiber保min(barL0,Mh)再抽R_x|H/h构造可测充分计划，零fiber/零h不取商。只是该限定类的准确覆盖条件，缺额尚无root源价。

Mainproof的collapsed father T=Q*Q对σ可逆且PSD；完整systematic两块更新只保证基底不变，不能称可逆。Killed density K*、v_N−K*v_N=g0−gN、joint边界1_H Qv_N和原入流=首次命中+terminal均正确。C_N是完整(B,y,z)边界的RN最大帽，不是parent边缘平均，自动仅≤N。Supersolution g0+K*V≤V、QV|H≤CS并加V∈L¹(σ)时，Na_N≤∫V使terminal→0，构成完整**充分**证书；该证书未由原几何构造，也不是宣称一般预算必要条件。非L¹时不能漏terminal。

Sol例的完整边界极限27/10、shared-pair base2/15和parent边缘6/5区分正确。母入口仍乘64Λ₀Fhat，Green源费为512Λ₀Fhat S C_Nτ^−α√(n/α)W且保同乘子的terminal；不能只报一次高门费、叠加不同层G0/BH/入口费用或退款旧R455。

指定整对刷新后，后续marginal密度仅依原father g0，故相同g0有相同first-hit/terminal。这不抹除field本身的来源几何，也不是其他保联合标签核的不可能性；原pair信息只能通过g0的定量约束或新的合法列核使用。root限定正确。

## 3. 数值、历史与实际复现

Numeric的parent+flag是这些场的精确continuous lumping：central所有合法pairs同为low，outer各仅捕获一packet；不只是各pair的high比例巧合相等。High边界只有pure pairs，所以这几个例中parent+flag帽恰等full joint帽；一般不能推广，尤其不能与Sol的27/10及6/5混用。Frozen闭fiber与fresh transient分类无漏transient→closed出口；有理inverse仅用于可达transient，空high保全尾。规范化μ=base/X不改变RN帽，表中frozen/fresh终帽、残留和停时归一一致。有限匹配场未过原strict-K/highh/history，不能成为原预算反例或一般mixing证书。

隔离目录为 `/var/folders/lq/2c4qbz2n0354_tnttkv_qsz00000gn/T/r456_audit_isolated_8zssa1kf`，指定math-research-tools Python实际运行三脚本。mainproof先前122项只跑一次；最终核其script未变。Numeric stdout/JSON及最终geometry stdout均逐字节匹配冻结文件。

分类范围：mainproof 122 Fraction接口/守恒断言；numeric三purposeful cases的224项有理检查；geometry一个真实strict-K/fullmatching场（未满足原highh/history）、18有限原子CDF配置及54 strict-left有理log检查。后两组不强加native窗常数到任意原子表。一般公式由解析证明，不从检查数推出。历史索引只作有界定位，不保证全文穷尽；已有列价与终端低rank工具明确旧归属。资源是实跑记录，不估扣额；PRE临时符号检查不新增归档样本。

无未修数学阻断项。完整母账及所有原初始/删除/尺度/吸收手续继续保留；本轮没有一般原R闭合。

## 4. 最终字节绑定（15输入）

- `r456_main.md`: `50e62b15b3c1e6669c191562dfca9635f34c83c627cdd9e4b2d2f860d89e3ae6`
- `r456_transport.md`: `b7a1eaaeebcea4aefff34521f114957ca6dc4bf8558b13683d422760862d203b`
- `r456_geometry.md`: `1f0305be12a0cda93e37058dd3fa57c516295ac0ab0d95fc57d000ffdbf6c0b1`
- `r456_geometry_check.py`: `35db36e5afa08bcffd5ab0d35861a36da68383112d6a946e7daed4b1ad5cbeac`
- `r456_geometry.result.txt`: `4a3aeead33dcf09a99dd74b1f8ec50dd00fb46d4f984712f49c242b171911c5e`
- `r456_mainproof.md`: `57cd5588589144548f42cf6d107f46dc98bd9c326b49c19058c42139db6ab5fe`
- `r456_mainproof_check.py`: `3cbc1c0b1d91519fcb51b0ed78aded4f28c35e82470756919d385c88a0a5446e`
- `r456_mainproof.result.txt`: `c2e17c936623814b5557d13defbb553da62124cffcf0400739e6b487bede6105`
- `r456_numeric.md`: `cad35357404e22dde7904cfb6ca600d08ac45f09976d0e2b1daa071e47654f09`
- `r456_numeric.py`: `2059dfe52a5bbdde711d21bb84d5e59ae1dd546b76b6f3d357362f6881eff681`
- `r456_numeric_certificate.json`: `443ec0971ecffeead560693216862c49caf49c1db3eab09b546e8f11cd6cb970`
- `r456_numeric_run.txt`: `c985b9a5a498ca3262e5fbce666819f6c6d7a8eb8ade80266a1d4ed3bc2c09f0`
- `r456_numeric_resources.txt`: `a7cd3974d37391c3040911fbad837dc0d3f17007d2ca32b1619d4b9f26188d0a`
- `r456_numeric_compute_index.md`: `d9970326b8a4c80a238de058920c3b079a092168e2e60cad2e3b1121b6711334`
- `r456_history_index.md`: `652049855f18077c500d46912234f582a5e07c6bacb7d66d212973787f442808`

---

# R456 independent audit — PRECHECK（非最终PASS）

只核足够的定量覆盖条件、原测度耦合及费用。已读R455 direct-budget和R435 frozen contract；未读R456新作者证明，不默认低p估计。目标仍是同一原双低p交集R_low≤εX+Cε√n polylog(n+2)W，而非另一个无标记余项。仅修改本文件。

## 1. 原正测度与可用高门价格

记M(dA,dy,dz)=σ(dA)π_A(dy)π_A(dz)，M(all)=X。Π是已付R455高门后的完整原正限制，投影ρ≤S M，支持p_y(A)<τ、p_z(A)<τ；原stage/clock/early/路径/未来等标签仍在Π。原投影帽由a_i^e≤B_e、Σb_i≤1、θ_i≤1和ΣB_e=S取得，不是把原flow任意重建成M。

在同一场的任意aux状态(B,y',z')上，H={p_{y'}(B)≥τ or p_{z'}(B)≥τ}。R455给

    S M(H)≤B_H W， B_H=8S τ^−α√(n/α)。

τ=(n+2)^−c、c≥1、α=1/[2c log(n+2)]时B_H=8S√[2ec nlog(n+2)]。此价格保S；不能将高门图像先称为原history合格票据。旧原parent高p票据已经付款；从其双low补集产生的aux命中是**另一批原low票据的正分数**，使用相同几何定理仍需新增相应来源费用，不能免费复用旧付款额度。

## 2. 保原来源对的正确Bayes父核

完整来源dy权不可省略。写

    C2(y,z)=∫_E q_B c_B(y)c_B(z)/m_B² dB，
    M_yz(dy,dz)=f(y)f(z)C2(y,z)dy dz，
    R_yz(dB)=q_B c_B(y)c_B(z)dB/[m_B² C2(y,z)]。

在C2>0上这是概率核；C2=0的来源对无M或ρ质量，可墓地。原qband、a>0和|E|<∞保证C2有限；所有参数积分及归一化可测。不能用无q_B的共同捕获law假称σπ²可逆，或以|E_y∩E_z|作错误归一化。

保持原y,z，给原记录ω独立附B~R_yz，不改变原A及任何原标签。若ρ=S L M，则其aux图像为

    ρT(dB,dy,dz)=S barL(y,z) M(dB,dy,dz)，
    barL(y,z)=∫R_yz(dA)L(A,y,z)∈[0,1]。

因此pair-source边缘精确保留，且列≤S M。barL通常不是L(B,y,z)：新父没有旧父的history/current/首次删除资格。accepted parent边缘也通常不等于原ρ_A；只有未过滤基底M本身的parent边缘σ由此核不变。

令q_H(ω)=R_yz(H)，原可付正分数为q_HΠ（等价在Π×R上取aux high事件）。它的原记录和来源都未刷新，mass等于aux high图像mass，故

    ∫q_H dΠ≤S M(H)≤B_H W。

这个**上界**合法，不需要给B继承history；但它尚未给Π总量。

## 3. 足够且可审核的最弱正覆盖接口

一般地可允许Π上行子概率核K(ω,dξ)，只要直接证明实际aux列ν=∫Π(dω)K(ω,dξ)≤C_T S M(dξ)。行亏损/墓地质量必须保留为未覆盖，不可丢。定义q_H(ω)=K(ω,H)≤1，则∫q_HΠ≤C_T B_H W。

对任意固定覆盖参数0<κ≤1，有精确的正上界

    R_low≤κ^−1∫q_H dΠ + Dκ，
    Dκ=∫(1−q_H/κ)_+dΠ。

所以一个真正足够的新增定量条件是

    Dκ≤εX+Qε√n log^A(n+2)W。

连同上述列价，得到R_low≤εX+[C_T B_H/κ+Qε√n log^A]W。要保root polylog量级，C_T/κ至多允许声明的参数/ε常数和polylog增长；不能隐藏1/κ≈√n、指数n或stage数。更强且易检查的形式是在坏记录价格≤εX+rootW之后，逐原good记录有q_H≥κ。也可给直接的平均覆盖下界，但ε项除κ后的系数须正确调整。

此条件只是准确审查门槛，并未被证明。若q_H很小，Dκ几乎就是原low质量，不能把定义Dκ当新解决。若作者用coupling流，须有第一边缘≤原Π、第二边缘≤C_T S M|H，未覆盖第一边缘满足上述价格；仅存在一个廉价aux方案、或只有总capacity上界，都不提供需求覆盖下界。

将此原R_low估计代入母账时只对原R槽新增64Λ₀Fhat εX及对应来源价；已有R455高票据价与旧C/V、初始/删除/尺度项保持。若这是后续迭代，则每次新覆盖是同一剩余测度的正分数，必须按原records联合/顺序一次拉回，不能逐轮重新用旧完整Π宣称多次收缩。

## 4. Stationarity/idempotence究竟提供什么

正确的pair-Bayes核对M stationary，且T²=T；它把父条件分布投影到R_yz。于是q_H只依y,z，第二次最终状态分布没有改善。stationarity证明的是列**上界**及高命中正分数的价格，不给q_H在实际barL来源对上的下界。原L可能与小q_H相关，不能把∫ρ q_H换成(ρ(all)/X)M(H)或未过滤平均。

“至少一次命中”N次抽样的概率是1−(1−q_H)^N，确可增大，但≤Nq_H；现有上界价格相应至多N B_H W，不是免费放大。一直抽到命中需要控制q_H=0部分及1/q_H/occupation的额外费用，stationarity和投影幂等都不给这个控制。

若有一个保base列的有限步链，并**另证**N步未命中质量≤aR_low+εX+QW、a<1，则首次命中可按N次列上界付≤N C_T B_H W，解出时全部右端除1−a。此为合法路线，但N/(1−a)的增长和terminal/墓地必须显式。reversibility本身也不能取消单向正命中成本。

## 5. 刷新source/father的合法限度

可在固定原记录外附一个共同Markov kernel到(B,y',z')。如果它只通过原static状态作用，并确有M K=M（例如正确基底条件的Gibbs步骤），则ρ≤S M给ρK≤S M；high正分数仍能拉回原Π计价。但旧source、b_i、首次死亡、当前占用与路径历史仍属于原记录，不属于新y'/z'/B。此操作只给分析辅助标签，不重新生成原flow。

若kernel另依保留历史、原L或源选择偏差，则“每一个固定kernel stationary”不足以推出按记录选核后的实际列价；须证明共同K的stationarity，或直接证明∫ΠK≤C_T S M。fresh f/W后只接受捕获会产生行亏损，必须算作未覆盖；不能将条件接受后归一化的概率免费当原行概率。

即便是完全独立从M/X刷新，high概率也只是M(H)/X：当X未知时无法假设它有正统一下界。此示例只说明何处出现待证定量条件，不否定实际几何可能给的额外约束。

本任务目标是原正质量R，所以保第一原记录并给high图像支配足够计价；若后续改为signed U或原cost比较，另需原cost和auxcost的关系/有价transfer defect，不能把廉价新状态成本上放为原实际成本。

## 6. 实际本机辅助与PRE状态

指定数学Python/SymPy核一个符号条件重采样矩阵K=[[1−u,u],[1−u,u]]：K²=K、(1−u,u)K=(1−u,u)，但原low限制(1−u,0)的一步high质量恰u(1−u)。这是单个Markov接口代数检查，不是native原场或原history反例，不做参数/几何扫描。它只帮助区分stationary列预算与实际接受权覆盖下界。

PRE结论：正确Bayes/刷新核能够合法定价原low记录中的aux high命中正分数；从该分数到完整low预算仍需第3节真实覆盖/有价缺额条件。stationarity/idempotence不自动给出它。等待作者证明，不标最终PASS。


## 7. 后续strict-K刷新候选的独立推导（先于作者该候选证明）

原Π支持Z_A(y)≥θ_yJ(y)>0、Z_A(y)>(4−ε₀)h、C_A(y,z)<h。附加子概率核

    K(ω,du,dz')=1_{m_u<m_A/K} c_u(y)(1−c_u(z))
                    du/[m_u Z_A(y)] ·π_u(dz')。

原记录ω仍完整保留。每行总质量=(Z_A(y)−C_A(y,z))/Z_A(y)≥c*=1−1/(4−ε₀)，所以输出Ξ(all)≥c*Π(all)。未归一化接受行；被拒绝质量显式，不给u/z'原history。

利用Π投影≤Sσπ_A²并保原relative gate到分母处理，输出满足

    Ξ(du,dy,dz')≤(Sr/θ_y)σ(du)π_u(dy)π_u(dz')。

准确换序中需要的父积分为

    ∫_{m_A>K m_u} q_A c_A(y)dA/[m_A Z_A(y)]
       ·1_{Z_A(y)≥θ_yJ(y)}
    ≤[λ/(θ_yJ(y))]∫c_A(y)dA/m_A≤λ/θ_y。

这说明输出帽Sr/θ_y正确，无额外stage数或2；没有把输出误称为原Π。J0来源无输入，所有积分为非负Tonelli。

对新父u的原场closed rankT_u与strict pastZ_u，真实质量窗[mu/K,mu]的ρ_y容量≤B_K=(1+logK)/q：用体积变量v=(2dist∞)^n的majorant∫_0^(mu/q)dv/max(mu/K,qv)。因此Z_u(y)≤θ'J(y)蕴含T_u(y)≤θ'J(y)+B_K。inclusive闭CDF子水平包含完整质量原子且容量≤该阈值，给基底价格

    ∫σ(du)π_u(dy)1_{Z_u(y)≤θ'J(y)}
      ≤rθ'X+r(1+logK)W。

题提1+2logK是更松有效常数。若用于输出Ξ，**整式再乘Sr/θ_y**，即价Sr²θ'X/θ_y+Sr²(1+logK)W/θ_y；不能漏输出帽。另一个新source z'的同类事件可由base对称性定价，OR另有2，不能混入当前单端公式。

该刷新保原y、另抽z'；u/z'无原high-common、current、early等资格。新relative gate若保留，只是分析上的新可测条件，不自动恢复全部原门。输出列帽、拒绝质量、后续筛选对fresh law的影响与累积帽须逐步控制；以上不是免费可迭代收缩，也没有为完整Π给source预算。

已在独立PRE后读r456_transport和冻结mainproof：保pair容量式S∫(r−Mh)+确为该限定类必要充分，显式t=min(r,Mh)的保留/条件high核无可测或零分母缺口；Gibbs正文的T=Q*Q、killed adjoint及Green/terminal显示初核方向正确，最终结论仍需待全部冻结材料后独审。
