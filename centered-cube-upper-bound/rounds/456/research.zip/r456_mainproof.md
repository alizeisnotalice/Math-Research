# R456 — exact Gibbs transport and the cumulative high-p boundary price

**Outcome.** The two-step Gibbs construction preserves the actual static base and the original accepted mass. Its cumulative first-hit price is an explicit Green boundary density, not the single-step constant \(S\). No bound on that density, or on its surviving terminal mass, follows here from the original high-rank/low-common gates. Thus there is no new complete remainder payment.

## 1. The actual reversible kernel and the original input

Use the unchanged R435 field. Set \(x=(y,z)\) and
\[
 d\mathcal B(A,x)=\sigma(dA)\pi_A(dy)\pi_A(dz),\qquad
 \nu(dx)=\int\mathcal B(dA,dx),\qquad \mathcal B(1)=X.
\]
Its conditional father law is
\[
 R_x(dB)=\frac{q_Bc_B(y)c_B(z)}{m_B^2 C_2(y,z)}\,dB,\quad
 C_2(y,z)=\int_E\frac{q_Bc_B(y)c_B(z)}{m_B^2}\,dB.                 \tag{1}
\]
Zero \(C_2\) fibers have zero \(\nu\)-mass. All spaces are standard Borel, and these explicit measurable densities define the kernels up to irrelevant null fibers.

Refreshing \(x\sim\pi_A^2\), then \(B\sim R_x\), gives the father kernel
\[
 T(A,dB)=\int\pi_A^2(dx)R_x(dB).                                \tag{2}
\]
It is \(\sigma\)-reversible: its conductance is
\(\int\nu(dx)R_x(dA)R_x(dB)\). It is positive semidefinite as well: if
\(Qg(x)=\int R_x(dA)g(A)\), then \(T=Q^*Q\) on \(L^2(\sigma)\).
The complete systematic two-block update is invariant for \(\mathcal B\), but need not itself be reversible; (2) is the reversible collapsed kernel.

Let \(P_0\) be the original double-low-p restriction, with every old history retained, and static density \(S L_0\) against \(\mathcal B\). Its father density is exactly
\[
 g_0(A)=S\int\pi_A^2(dx)L_0(A,x),\qquad0\le g_0\le S.             \tag{3}
\]
Attaching auxiliary draws to each original record preserves its entire weight. The original record remains a label; no new source or father acquires its old gates. Replacing \(L_0\) by the indicator of gates at the refreshed state would be a different, unjustified procedure.

## 2. Exact first-hit flow, including the terminal

Fix \(0<\tau<1\), and let
\[
 H=\{(B,y,z):p_y(B)\ge\tau\ \text{or}\ p_z(B)\ge\tau\}.
\]
For a father input density \(g\), the refreshed pair/father law has density \(Qg(x)\) against \(\mathcal B(B,x)\). Killing at \(H\) therefore gives
\[
 (K^*g)(B)=\int\pi_B^2(dx)\,1_{H^c}(B,x)Qg(x).                  \tag{4}
\]
Here \(K^*\) denotes the density adjoint of the substochastic forward kernel. It is positive and \(K^*1\le1\), but it is not asserted symmetric.

Define \(g_j=(K^*)^jg_0\), \(v_N=\sum_{j=0}^{N-1}g_j\). Then
\[
 v_N-K^*v_N=g_0-g_N,\qquad
 d\mathcal H_N=1_H(B,x)Qv_N(x)\,d\mathcal B(B,x),                \tag{5}
\]
\[
 P_0(1)=\mathcal H_N(1)+\int g_N\,d\sigma.                      \tag{6}
\]
\(\mathcal H_N\) is the cumulative **first**-hit law. Disjoint first-hit events on the augmented original record space prove (6); their probabilities may equivalently be pulled back as fractional positive restrictions of the original records. No conditional restart or normalization is used. The remaining term includes every nonhit history, including invariant classes that never reach \(H\).

The smallest uniform boundary capacity constant is exactly
\[
 C_N=\frac1S\operatorname*{ess\,sup}_{\mathcal B|H}Qv_N
 \quad(S>0),                                                  \tag{7}
\]
with \(C_N=0\) if the boundary base is null. Since each \(g_j\le S\), only \(C_N\le N\) is automatic. R455 now gives the valid finite bound
\[
 P_0(1)\le
 8S C_N\tau^{-\alpha}\sqrt{n/\alpha}\,W+\int g_N\,d\sigma,
 \qquad 0<\alpha\le1.                                         \tag{8}
\]
All original entrance multipliers remain: multiplying this slot by
\(64\Lambda_0\widehat F\) gives source fee
\(512\Lambda_0\widehat F S C_N\tau^{-\alpha}\sqrt{n/\alpha}W\)
and the full surviving term with the same multiplier. Fees from earlier receipts are not refunded. If \(S=0\) or \(X=0\), the input is zero and no normalized quantity is needed.

## 3. The specific unproved geometric step

A constructive sufficient certificate would be a nonnegative father function \(V\) with
\[
 g_0+K^*V\le V,\qquad QV|_H\le C S,                            \tag{9}
\]
Positive iteration makes (9) dominate every \(v_N\). If in addition \(V\in L^1(\sigma)\), this is a complete sufficient certificate: writing \(a_j=\int g_j\,d\sigma\), substochasticity makes \(a_j\) nonincreasing, and
\[
 N a_N\le\sum_{j=0}^{N-1}a_j=\int v_N\,d\sigma\le\int V\,d\sigma.
\]
Hence the terminal in (8) is at most \(\int V\,d\sigma/N\) and tends to zero. Monotone convergence for the first-hit law then gives the source fee in (8) with \(C_N\) replaced by \(C\). Without the \(L^1\) condition, the terminal must still be retained or bounded separately. A polylogarithmic \(C\) would give a summable boundary fee, but such a certificate has not been constructed from the original gates.

Even the simple constant test \(V=CS\) requires the precise inequality
\[
 \int\pi_A^2L_0\le C\,a_H(A),\qquad
 a_H(A)=\int\pi_A^2(dx)1_H(A,x),                               \tag{10}
\]
because \(K^*1=1-a_H\). Original acceptance on double-low-p supplies no such parentwise comparison. A nonconstant test would have to transfer accepted load through the **actual** common-parent posterior \(R_x\), with an explicit boundary price. The original \(Z_A,C_A\) gates qualify the initial source pair, not independently refreshed pairs; they have not supplied this comparison or a survival rate.

This is the remaining gap for this mechanism. Stationarity proves neither a time-free \(S\) boundary cap nor contraction of the original low-p input. The earlier static Bayes receipt in R434 and the fixed-source path prices indexed in r456_history_index.md do not provide (9). Fixed-pair resampling being idempotent also does not mean its repeated ever-hit probability is constant.

## 4. Actual finite verification and its limits

The local math Python actually ran r456_mainproof_check.py; r456_mainproof.result.txt records **122 Fraction assertions** in three stages.

The principal fixture is genuinely continuous: side length 1; center intervals
\([-7/20,-1/4]\) and \([1/4,17/50]\); source packets
\([-7/10,-3/5]\), \([-1/20,1/20]\), \([3/5,7/10]\)
have respective full masses \(1,2,2\), constant on each packet. Every center in the first block captures exactly the first two packets; every center in the second captures exactly the last two. Thus \(q_A=3\) or \(4\), and
\[
 \sigma=(3/10,9/25),\qquad
 T=\begin{pmatrix}55/67&12/67\\10/67&57/67\end{pmatrix}.
\]
All cross-block centers lie outside the other block's selected cube, up to a null boundary. Hence \(p_y(A)\) equals its own center-block length, \(1/10\) or \(9/100\), on every captured source. At \(\tau=19/200\), \(H\) is exactly the first block. Starting with density 1 on the second block, (5)–(6) give boundary density
\[
 C_N=\frac{27}{10}\left[1-(57/67)^N\right].
\]
This is the RN maximum on the complete \((B,y,z)\) boundary, not a constant density on the entire first father block. Every hit has both sources in the shared packet; the base mass of that boundary portion is \((3/10)(2/3)^2=2/15\). Its limiting hit mass is \(9/25\), so the full-record density is \((9/25)/(2/15)=27/10\). After projecting away the two source coordinates, the first-block father marginal instead has limiting density \((9/25)/(3/10)=6/5\). The displayed \(C_N\) exceeds 1 at \(N=4\) and tends to \(27/10\). This is an exact continuous-field check that successive first hits can accumulate beyond the single-step cap. The third stage separately checks zero and disconnected finite-incidence endpoints.

These fixtures do not possess the original strict-far/path/history gates and do not disprove a stronger estimate using them. They only rule out deriving the required cumulative cap from invariance, \(g_0\le S\), and matching alone by reusing the one-step \(S\) bound. No new full-flow payment is claimed.
