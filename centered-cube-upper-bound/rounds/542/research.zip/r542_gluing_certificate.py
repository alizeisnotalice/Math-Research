import sys,platform,time,json,functools
from pathlib import Path
import numpy as np,sympy as sp,flint
from flint import arb,ctx
ctx.prec=256;START=time.monotonic();COUNTS={'algebraic_comparisons':0,'full_2d_union_evaluations':0}

def ev(e):
 e=sp.sympify(e)
 if e.is_Rational:return arb(int(e.p))/int(e.q)
 if e.is_Add:return sum((ev(t) for t in e.args),arb(0))
 if e.is_Mul:
  ans=arb(1)
  for t in e.args:ans*=ev(t)
  return ans
 if e.is_Pow:
  a,b=e.args
  if b.is_Integer:return ev(a)**int(b)
  if b.is_Rational:return ev(a).root(int(b.q))**int(b.p)
 raise ValueError(str(e))
def sign(e):
 COUNTS['algebraic_comparisons']+=1;a=ev(e)
 if a>0:return 1
 if a<0:return -1
 if sp.simplify(e)==0:return 0
 raise ArithmeticError('unresolved '+str(e))
def less(a,b):return sign(a-b)
def maximum(v):return max(v,key=functools.cmp_to_key(less))
def minimum(v):return min(v,key=functools.cmp_to_key(less))
def boxes(x,w,n):
 ans=[];excluded=[]
 for mask in range(1,1<<len(w)):
  ids=[i for i in range(len(w)) if mask>>i&1];r=sum(w[i] for i in ids)**sp.Rational(1,n);mins=[minimum([x[i][j] for i in ids]) for j in range(n)];maxs=[maximum([x[i][j] for i in ids]) for j in range(n)];widths=[r+mins[j]-maxs[j] for j in range(n)];sg=[sign(v) for v in widths]
  b=dict(mask=mask,r=r,mins=mins,maxs=maxs,lo=[t-r/2 for t in maxs],hi=[t+r/2 for t in mins],widths=widths)
  if min(sg)>0:ans.append(b)
  else:excluded.append(dict(mask=mask,width_signs=sg,reason='zero-volume or empty',widths=[str(v) for v in widths]))
 return ans,excluded

def union2d(bs):
 COUNTS['full_2d_union_evaluations']+=1
 rect=[(np.array([float(v) for v in b['lo']]),np.array([float(v) for v in b['hi']])) for b in bs];ed=np.unique([v[k][0] for v in rect for k in (0,1)]);U=0.
 for a,b in zip(ed[:-1],ed[1:]):
  mid=(a+b)/2;ys=sorted((lo[1],hi[1]) for lo,hi in rect if lo[0]<mid<hi[0])
  if not ys:continue
  lo,hi=ys[0];length=0.
  for c,d in ys[1:]:
   if c>hi:length+=hi-lo;lo,hi=c,d
   else:hi=max(hi,d)
  U+=(b-a)*(length+hi-lo)
 return float(U)
def record_expr(e):return dict(exact=str(e),arb256=str(ev(e)),sign=sign(e))
def solve(name,n,xa,wa,xb,wb,stage):
 xa=[[sp.sympify(t) for t in p] for p in xa];xb=[[sp.sympify(t) for t in p] for p in xb];wa=list(map(sp.Rational,wa));wb=list(map(sp.Rational,wb));A,exA=boxes(xa,wa,n);B,exB=boxes(xb,wb,n)
 S=max(A,key=functools.cmp_to_key(lambda a,b:less(a['hi'][0],b['hi'][0])));T=min(B,key=functools.cmp_to_key(lambda a,b:less(a['lo'][0],b['lo'][0])));a=S['hi'][0];bb=T['lo'][0];r=S['r'];s=T['r'];R=(r**n+s**n)**sp.Rational(1,n);d=maximum([r,s]);g=(R-d)/2
 shift=[a+g-bb]+[(S['mins'][j]+S['maxs'][j]-T['mins'][j]-T['maxs'][j])/2 for j in range(1,n)];yb=[[p[j]+shift[j] for j in range(n)] for p in xb]
 # Cross union set S+T is a legitimate source subset in the combined package.
 indsA=[i for i in range(len(wa)) if S['mask']>>i&1];indsB=[i for i in range(len(wb)) if T['mask']>>i&1];selected=[xa[i] for i in indsA]+[yb[i] for i in indsB]
 crosslo=[maximum([p[j] for p in selected])-R/2 for j in range(n)];crosshi=[minimum([p[j] for p in selected])+R/2 for j in range(n)];spans=[maximum([S['maxs'][j]-S['mins'][j],T['maxs'][j]-T['mins'][j]]) for j in range(1,n)];widths=[R-z for z in spans];K=g*sp.prod(widths);lower=(R-d)**n/2
 supportA=[dict(mask=b['mask'],slack=record_expr(a-b['hi'][0])) for b in A];supportB=[dict(mask=b['mask'],slack=record_expr(b['lo'][0]-bb)) for b in B]
 assert all(v['slack']['sign']>=0 for v in supportA+supportB)
 left=record_expr(a-crosslo[0]);right=record_expr(crosshi[0]-a-g);assert left['sign']>=0 and right['sign']>=0
 transverse=[]
 for j in range(1,n):
  center=(S['mins'][j]+S['maxs'][j])/2;centerB=(T['mins'][j]+T['maxs'][j])/2+shift[j]
  assert sign(center-centerB)==0
  cl=center-widths[j-1]/2;ch=center+widths[j-1]/2
  margins=[record_expr(cl-crosslo[j]),record_expr(crosshi[j]-ch)];assert all(v['sign']>=0 for v in margins)
  spanbound=record_expr(d-spans[j-1]);assert spanbound['sign']>0
  transverse.append(dict(axis=j,span_max=str(spans[j-1]),width=record_expr(widths[j-1]),span_below_d=spanbound,inclusion_margins=margins))
 assert sign(g)>0 and sign(K)>0 and sign(K-lower)>=0
 out=dict(name=name,n=n,stage=stage,alpha=dict(positions=[[str(t) for t in p] for p in xa],masses=[str(v) for v in wa],support_mask=S['mask'],positive_boxes=len(A),excluded_boxes=exA,support_order_certificate=supportA),beta=dict(positions=[[str(t) for t in p] for p in xb],masses=[str(v) for v in wb],support_mask=T['mask'],positive_boxes=len(B),excluded_boxes=exB,support_order_certificate=supportB),translation=[str(v) for v in shift],r=str(r),s=str(s),R=str(R),d=str(d),gap=record_expr(g),cross_axis_gap_containment_margins=[left,right],transverse_certificate=transverse,K=record_expr(K),universal_lower_bound=record_expr(lower),K_minus_lower=record_expr(K-lower),scope='Finite exact algebraic support and prism containment certificate; analytical construction, not a grid LP, supplies continuous geometric inequality.')
 if n==2:
  C,exc=boxes(xa+yb,wa+wb,n);ua=union2d(A);ub=union2d(B);uc=union2d(C);gain=uc-ua-ub;k=float(K);out['complete_2d_union_check']=dict(U_alpha=ua,U_beta=ub,U_new=uc,gain=gain,K=k,gain_minus_K=gain-k,positive_combined_boxes=len(C),scope='Floating full-union cross-check only; continuous lower bound follows independently from certified support separation and cross-box prism containment.')
 return out

def package(n,side=1,scale=1):
 # Three source package: supports can involve multiple labels. Rational nonzero transverse spans.
 x=[]
 for i,q in enumerate([0,sp.Rational(2,5),sp.Rational(21,50) if n>=8 else sp.Rational(9,20)]):
  p=[side*q]+[sp.Rational(((i+1)*(j+2))%7-3,100) for j in range(1,n)];x.append([t*scale for t in p])
 return x
cases=[]
for name,n,ascl,bscl,am,bm,stage in [('n1_multisource',1,1,1,1,1,'initial'),('n2_multisource',2,1,1,1,1,'initial'),('n2_massratio_100',2,1,sp.Rational(1,10),1,sp.Rational(1,100),'pressure'),('n3_massratio_1000',3,1,sp.Rational(1,10),1,sp.Rational(1,1000),'pressure'),('n3_asymmetric_large_alpha',3,3,1,27,1,'expanded'),('n8_multisource_ratio256',8,1,sp.Rational(1,2),1,sp.Rational(1,256),'expanded')]:
 wa=[sp.Rational(2,5)*am,sp.Rational(3,10)*am,sp.Rational(3,10)*am];wb=[sp.Rational(1,4)*bm,sp.Rational(1,4)*bm,sp.Rational(1,2)*bm];cases.append((name,n,package(n,1,ascl),wa,package(n,-1,bscl),wb,stage))
cases.insert(3,('n2_zero_width_old_box',2,[[0,0],[sp.Rational(1,2),0],[1,0]],[sp.Rational(1,4),sp.Rational(1,4),sp.Rational(1,2)],package(2,-1),[sp.Rational(1,4),sp.Rational(1,4),sp.Rational(1,2)],'pressure'))
results=[]
for args in cases:
 q=solve(*args);results.append(q);print(q['name'],'S/T',q['alpha']['support_mask'],q['beta']['support_mask'],'g',float(sp.sympify(q['gap']['exact'])),'K',float(sp.sympify(q['K']['exact'])),flush=True)
out=dict(command=sys.executable+' '+str(Path(__file__).resolve()),versions=dict(python=platform.python_version(),numpy=np.__version__,sympy=sp.__version__,python_flint=flint.__version__),precision_bits=256,seed=None,config_count=len(results),counts=COUNTS,elapsed_seconds=time.monotonic()-START,scope='Seven deterministic finite multi-source pairs, dimensions 1,2,3,8. All positive-volume within-package receiving subsets enumerated, excluded degeneracies retained. Arb exact-expression checks certify support ordering and continuous cross-box containment; full two-dimensional union numerical check is separate. No model-constant optimization or general upper bound claimed.',results=results)
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2))
