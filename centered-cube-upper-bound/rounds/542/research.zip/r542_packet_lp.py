import sys,time,platform,json,functools
from fractions import Fraction as F
from pathlib import Path
import numpy as np,scipy,sympy as sp,flint
from scipy.optimize import linprog
from flint import arb,ctx
ctx.prec=192;START=time.monotonic()
def ae(e):
 e=sp.sympify(e)
 if e.is_Rational:return arb(int(e.p))/int(e.q)
 if e.is_Add:return sum((ae(v) for v in e.args),arb(0))
 if e.is_Mul:
  z=arb(1)
  for v in e.args:z*=ae(v)
  return z
 if e.is_Pow:
  base,p=e.args
  if p==sp.Rational(1,2):return ae(base).sqrt()
  if p==sp.Rational(-1,2):return 1/ae(base).sqrt()
  if p.is_Integer:return ae(base)**int(p)
 raise ValueError(str(e))
def compare(a,b):
 d=ae(a)-ae(b)
 if d>0:return 1
 if d<0:return -1
 if sp.simplify(a-b)==0:return 0
 raise ArithmeticError('Arb cannot separate '+str(a-b))
def sorted_unique(vs):
 vv=sorted(vs,key=functools.cmp_to_key(compare));out=[]
 for v in vv:
  if not out or compare(v,out[-1])!=0:out.append(v)
 return out

def getrect(x,w):
 N=len(w);out=[]
 for mask in range(1,1<<N):
  ids=[i for i in range(N) if mask>>i&1];r=sp.sqrt(sum(w[i] for i in ids))/2
  lo=[max((x[i][j] for i in ids),key=functools.cmp_to_key(compare))-r for j in range(2)];hi=[min((x[i][j] for i in ids),key=functools.cmp_to_key(compare))+r for j in range(2)]
  if all(compare(hi[j],lo[j])>0 for j in range(2)):out.append((mask,lo,hi))
 return out

def solve(name,stage,x,w):
 x=[[sp.sympify(v) for v in p] for p in x];w=list(map(sp.Rational,w));N=len(w);full=(1<<N)-1;rect=getrect(x,w)
 edges=[sorted_unique([p[k][j] for p in rect for k in (1,2)]) for j in range(2)]
 def rank(v,axis):
  return next(i for i,e in enumerate(edges[axis]) if compare(v,e)==0)
 grid=np.zeros((len(edges[0])-1,len(edges[1])-1),dtype=np.uint64)
 for mask,lo,hi in rect:
  lx,hx=rank(lo[0],0),rank(hi[0],0);ly,hy=rank(lo[1],1),rank(hi[1],1);grid[lx:hx,ly:hy]|=np.uint64(1)<<np.uint64(mask-1)
 signatures=sorted(set(int(v) for v in grid.ravel())-{0});packets=list(range(1,full));A=[];representatives=[]
 for sig in signatures:
  witnesses=[s for s in range(1,full+1) if sig>>(s-1)&1]
  A.append([int(all(s&I for s in witnesses)) for I in packets]);ix,iy=np.argwhere(grid==sig)[0]
  representatives.append(dict(witnesses=witnesses,cell=[[str(edges[0][ix]),str(edges[0][ix+1])],[str(edges[1][iy]),str(edges[1][iy+1])]]))
 A=np.array(A,dtype=int);c=[sum(w[i] for i in range(N) if I>>i&1)/sum(w) for I in packets]
 res=linprog(-np.array(c,dtype=float),A_ub=A,b_ub=np.ones(len(A)),bounds=(0,None),method='highs')
 if not res.success:raise RuntimeError(res.message)
 # Rational reconstruction is accepted only after exact Fraction checks.
 primal=[F(float(v)).limit_denominator(10**6) for v in res.x];dual=[F(float(-v)).limit_denominator(10**6) for v in res.ineqlin.marginals];cf=[F(int(v.p),int(v.q)) for v in c]
 pfeas=all(v>=0 for v in primal) and all(sum(int(a)*v for a,v in zip(row,primal))<=1 for row in A)
 dfeas=all(v>=0 for v in dual) and all(sum(int(A[j,k])*dual[j] for j in range(len(A)))>=cf[k] for k in range(len(packets)))
 pv=sum(v*q for v,q in zip(primal,cf));dv=sum(dual);exact=pfeas and dfeas and pv==dv
 if not exact:raise ArithmeticError('Rational primal/dual not certified')
 halfids=[k for k,v in enumerate(cf) if v<=F(1,2)];Ah=A[:,halfids];ch=[cf[k] for k in halfids]
 hr=linprog(-np.array(ch,float),A_ub=Ah,b_ub=np.ones(len(A)),bounds=(0,None),method='highs')
 hp=[F(float(v)).limit_denominator(10**6) for v in hr.x];hd=[F(float(-v)).limit_denominator(10**6) for v in hr.ineqlin.marginals]
 hpf=all(v>=0 for v in hp) and all(sum(int(a)*v for a,v in zip(row,hp))<=1 for row in Ah)
 hdf=all(v>=0 for v in hd) and all(sum(int(Ah[j,k])*hd[j] for j in range(len(A)))>=ch[k] for k in range(len(halfids)))
 hpv=sum(v*q for v,q in zip(hp,ch));hdv=sum(hd)
 assert hr.success and hpf and hdf and hpv==hdv
 halfout=dict(candidate_count=len(halfids),exact_value=str(hpv),float_value=float(-hr.fun),max_individual_allowed_mass=str(max(ch)),rational_certificate=dict(primal_feasible=hpf,dual_feasible=hdf,exact_objective_equality=hpv==hdv,primal_weights=[dict(packet=packets[halfids[k]],weight=str(v)) for k,v in enumerate(hp) if v],dual_rows=[dict(row=j,weight=str(v),**representatives[j]) for j,v in enumerate(hd) if v]))
 fullsig=1<<(full-1);has_full=fullsig in signatures;fullcell=None
 if has_full:fullcell=representatives[signatures.index(fullsig)]
 # D_full equals U, hence including the full packet gives value at least 1.
 allA=np.c_[A,np.ones(len(A),int)];allc=np.r_[np.array(c,float),1.];allres=linprog(-allc,A_ub=allA,b_ub=np.ones(len(A)),bounds=(0,None),method='highs')
 ad=[F(float(-v)).limit_denominator(10**6) for v in allres.ineqlin.marginals];ap=[F(float(v)).limit_denominator(10**6) for v in allres.x];acf=cf+[F(1)]
 assert allres.success and all(v>=0 for v in ad) and all(v>=0 for v in ap)
 assert all(sum(int(a)*v for a,v in zip(row,ap))<=1 for row in allA)
 assert all(sum(int(allA[j,k])*ad[j] for j in range(len(A)))>=acf[k] for k in range(len(acf)))
 apv=sum(v*q for v,q in zip(ap,acf));assert apv==sum(ad)
 exx=[[float(e) for e in edge] for edge in edges];cellareas=np.diff(exx[0])[:,None]*np.diff(exx[1])[None,:]
 out=dict(name=name,stage=stage,N=N,positions=[[str(v) for v in p] for p in x],masses=[str(v) for v in w],positive_rectangle_count=len(rect),grid_shape=list(grid.shape),occupied_grid_cells=int(np.sum(grid!=0)),distinct_witness_families=len(signatures),U_float=float(np.sum(cellareas*(grid!=0))),has_positive_full_label_only_cell=has_full,full_label_only_cell_certificate=fullcell,full_label_only_area_float=float(np.sum(cellareas*(grid==fullsig))),half_mass_packet_lp=halfout,proper_packet_lp_float=float(-res.fun),proper_packet_exact_value=str(pv),rational_certificate=dict(primal_feasible=pfeas,dual_feasible=dfeas,exact_objective_equality=exact,primal_weights=[dict(packet=packets[k],weight=str(v)) for k,v in enumerate(primal) if v],dual_rows=[dict(row=j,weight=str(v),**representatives[j]) for j,v in enumerate(dual) if v]),including_full_packet_exact_value=str(apv),including_full_packet_rational_certificate=dict(exact_checks_pass=True,primal_weights=[dict(packet=packets[k] if k<len(packets) else full,weight=str(v)) for k,v in enumerate(ap) if v],dual_rows=[dict(weight=str(v),**representatives[j]) for j,v in enumerate(ad) if v]),including_full_packet_lp_float=float(-allres.fun),including_full_packet_note='Full packet alone gives 1 as a trivial baseline; the exact rational primal-dual certificate verifies the reported optimum only for this listed configuration.',full_only_simple_bound=str(1-min(w)/sum(w)) if has_full else None,half_packet_full_only_simple_bound=str(max(ch)) if has_full else None,scope='Exact algebraic grid ordering via Arb192 with symbolic equality; rational LP proof applies only to listed finite configuration and proper-packet family.')
 return out
r=sp.sqrt(sp.Rational(1,2));b=(1+r)/2
cases=[('two_source_contact','initial',[(0,0),(b,0)],['1/2','1/2']),('three_separated','initial',[(0,0),(2,0),(0,2)],['1/2','1/3','1/6']),('three_generic','initial',[(0,0),('3/5','1/10'),('1/10','3/5')],['1/3']*3),('four_generic','expanded',[(0,0),('3/5','1/10'),('1/10','3/5'),('-1/2','-1/5')],['1/4']*4),('four_cluster','pressure',[(0,0),('1/100','1/100'),('-1/100','1/100'),('1/100','-1/100')],['1/4']*4),('three_coincident','pressure',[(0,0)]*3,['1/2','1/3','1/6']),('six_cluster','expanded',[(0,0),('1/100','0'),('0','1/100'),('-1/100','0'),('0','-1/100'),('1/100','1/100')],['1/6']*6)]
cases.sort(key=lambda c:{'initial':0,'pressure':1,'expanded':2}[c[1]])
results=[]
for name,stage,x,w in cases:
 start=time.monotonic();q=solve(name,stage,x,w);q['elapsed_seconds']=time.monotonic()-start;results.append(q);print(name,q['proper_packet_exact_value'],q['has_positive_full_label_only_cell'],flush=True)
out=dict(command=sys.executable+' '+str(Path(__file__).resolve()),versions=dict(python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__,sympy=sp.__version__,python_flint=flint.__version__),arb_precision_bits=192,seed=None,scope='Seven deterministic finite configurations, N<=6. No model-constant scan, global-extremizer claim, all-N inequality, or inference from floating optimal status. D_I is the old deletion region: every covering witness meets I. Boundary grid lines have zero area; all positive grid cells retained.',definition='max sum_I w_I mu(I)/M, all nonempty proper I, w>=0, sum_I w_I 1_DI<=1 on every occupied exact receiving grid cell.',packet_mask_convention='bit i denotes source i, i starts at zero',elapsed_seconds=time.monotonic()-START,results=results)
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2))
