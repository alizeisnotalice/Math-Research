from fractions import Fraction as F
from pathlib import Path
import sys,platform,json,time
import sympy as sp
from flint import arb,ctx
ROOT=Path(__file__).resolve().parent;ctx.prec=256
start=time.perf_counter();checks=0

def ck(v):
 global checks
 assert v
 checks+=1

def ar(v):
 v=F(v);return arb(v.numerator)/v.denominator
# General coefficient identities, with positive t before cancellation.
r,S,t,tau,delta,T,X,R=sp.symbols('r S t tau delta T X R',positive=True)
Tp=1024*r*S**2/(tau*delta)
ck(sp.cancel((2*r*S*(S/tau)/T).subs(T,Tp)-delta/512)==0)
ck(sp.cancel(t*(2*r*S*(S/t)/T)-2*r*S**2/T)==0)
ck(sp.cancel((2*r*S**2/T).subs(T,Tp)-tau*delta/512)==0)
C=F(257)
ck(C/(512*8*C*4)==F(1,16384))
ck(F(3,8)+F(1,16384)==F(6145,16384))
ck(F(6145,16384)<F(1,2))
scalars=[]
for eps in (F(1,1000),F(1),F(1000)):
 for ss in (F(1,1000),F(1),F(1000)):
  for rr in (F(1),F(2),F(1000)):
   ttau=min(ss,eps/(8*C));dd=min(F(1,4),eps/(8*C*ss));threshold=1024*rr*ss**2/(ttau*dd);HH=ss/ttau
   ck(rr>=1);ck(0<ttau<=ss);ck(0<dd<=F(1,4));ck(threshold>0)
   massbudget=rr*ss/threshold
   weak_per_R=2*HH*massbudget;strong_per_X=2*rr*ss**2/threshold
   ck(weak_per_R==dd/512);ck(strong_per_X==ttau*dd/512)
   for actual_t in (ttau,ss):ck(actual_t*2*rr*ss*(ss/actual_t)/threshold==strong_per_X)
   fee=C*strong_per_X;baseline=F(3,8)*eps;total=baseline+fee
   ck(fee<=eps/16384);ck(total<=eps/2)
   scalars.append(dict(epsilon=str(eps),S=str(ss),r=str(rr),tau=str(ttau),delta=str(dd),T=str(threshold),H=str(HH),raw_mass_budget_rS_over_T=str(massbudget),oldhit_bound_coefficient_per_R=str(weak_per_R),t_cancelled_oldhit_bound_per_X=str(strong_per_X),recovered_fee_257_per_X=str(fee),old_baseline_absorption_per_X=str(baseline),combined_absorption_over_epsilon=str(total/eps),all_exact=True))
# True 1D fullcapture static field for the Janossy factor, not arbitrary v.
# f=1[-2,2], fixed side1, E=[-1/5,4/5], A=0 and original tie mark1/2.
Elo,Ehi=F(-1,5),F(4,5);AA=F(0);BB=F(4,5);side=F(1);sA=F(1,2);sB=F(1,4)
corelo=max(AA-side/2,BB-side/2);corehi=min(AA+side/2,BB+side/2)
ck((corelo,corehi)==(F(3,10),F(1,2)));ck(sB<sA)
ck(Elo-side/2>=-2);ck(Ehi+side/2<=2)
# On the whole core, center capture intersection is [x-.5,.8].
for xx in (corelo,corehi):
 left=max(Elo,xx-side/2);right=min(Ehi,xx+side/2)
 ck(left==xx-side/2);ck(right==Ehi)
 ck(sA*(right-left)==F(13,20)-xx/2)
x,Ts=sp.symbols('x Ts',positive=True);vexpr=sp.Rational(13,20)-x/2
primitive=2*Ts*sp.exp(-vexpr/Ts)
ck(sp.simplify(sp.diff(primitive,x)-sp.exp(-vexpr/Ts))==0)
windows=[]
for threshold,ks in [(F(1,20),(8,9)),(F(1,10),(4,)),(F(1,5),(2,))]:
 for kk in ks:
  # k<=v/T<k+1, reversed because v decreases with x.
  lo=max(corelo,F(13,10)-2*threshold*(kk+1));hi=min(corehi,F(13,10)-2*threshold*kk)
  ck(lo<hi)
  vlo=F(13,20)-hi/2;vhi=F(13,20)-lo/2
  ck(kk*threshold<=vlo<vhi<=(kk+1)*threshold)
  ck(vhi-vlo<=threshold)
  Z=ar(2*threshold)*((-ar(vlo/threshold)).exp()-(-ar(vhi/threshold)).exp())
  ck(Z>0)
  rnmin=ar(hi-lo)*(-ar(vhi/threshold)).exp()/Z
  rnmax=ar(hi-lo)*(-ar(vlo/threshold)).exp()/Z
  ck(rnmin>arb(-1).exp());ck(rnmax<arb(1).exp());ck(rnmin<1);ck(rnmax>1)
  ck((rnmax/rnmin-(ar((vhi-vlo)/threshold)).exp()).contains(0))
  windows.append(dict(T=str(threshold),slab_k=kk,C_intersect_slab=[str(lo),str(hi)],length=str(hi-lo),v_range=[str(vlo),str(vhi)],v_over_T_range=[str(vlo/threshold),str(vhi/threshold)],exact_Z_expression='2*T*(exp(-v_min/T)-exp(-v_max/T))',Z=str(Z),density_RN_relative_uniform_min=str(rnmin),density_RN_relative_uniform_max=str(rnmax),e_inverse=str(arb(-1).exp()),e=str(arb(1).exp()),scope='Actual continuous cube/center Janossy-factor interface; T not claimed to satisfy original successful high-gate parameters'))
ck(len(windows)==4);ck(len(scalars)==27)
result=dict(scope='PPP whole-family old-hit coefficient arithmetic and actual static cube Janossy slab factor only. No original successful high-gate/history certification.',compute_index=dict(executable=sys.executable,python=platform.python_version(),sympy=sp.__version__,arb_precision_bits=ctx.prec,command='"'+sys.executable+'" r482_numeric.py',seconds=time.perf_counter()-start),checks=checks,formula=dict(input_mass_budget='E[p]<=rS/T (main geometric proof input)',oldhit_with_conditional_cap='loss<=(2rSH/T)*R',t_cancellation='integral t(A)*2rS*(S/t(A))/T d_sigma <=2rS^2*X/T',T='1024rS^2/(tau*delta)',new_loss='tau*delta*X/512',recovery='257',old_baseline='3epsilon*X/8',combined_bound='(6145/16384)*epsilon*X<epsilon*X/2'),parameter_cases=scalars,Janossy_model=dict(source_density='1_[-2,2]',W='4',parent_center_domain=['-1/5','4/5'],selected_R='1',full_mass='1',q='1',r='1',t='1 STATIC',original_A='0',raw_B='4/5 (frozen endpoint parameter / Janossy density trace)',sA='1/2',sB='1/4',core=['3/10','1/2'],v='(13/10-x)/2',conditional_density='exp(-v(x)/T)*1_core(x)/Z',windows=windows),exactness='All parameter and geometry arithmetic Fraction, symbolic cancellation and exponential primitive exact; 256-bit Arb conditional normalizers and RN endpoint balls. No Monte Carlo or grid approximation.')
(ROOT/'r482_numeric.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS',checks,'checks;27 exact scalar cases and4 actual static Janossy slab windows; no full success/history claim')
