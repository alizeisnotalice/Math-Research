# R482：同一 Poisson 族的质量预算与共同核心恢复成本

目标仍是 R481 同一 \(\Omega_{\ell}\) 上的实际 \(w_{\ell}\)。本稿只检验一条候选：用保留族的真实来源并集承接原附源 \(x\)，同时利用总质量收缩及低 Gram 重叠。得到可付的质量加权界与明确的恢复系数，但没有得到 \(w_{\ell}\) 的新无权预算。

## 1. 保原父分母的整族质量收缩

沿 R479—481 的原场和 Poisson 扩展，固定完整旧记录及 \((A,x,j,s)\)。原附源 \(x\) 不刷新，旧 \(y,z\) 和历史不移给辅助父。对 raw Poisson 点集 \(\mathcal P\)，Campbell 的有限级数公式及完整匹配给
\[
\mathbb E\left[\sum_{B\in\mathcal P}\frac{m_B}{m_A}\mid A,x,j,s\right]
=\frac1{Tm_A}\int_{(m_B,s_B)<(m_A,s)}
 t(B)c_B(x)\sigma(dB)ds_B
\le\frac{rS}{T}=:c.
\tag{1}
\]
最后一步是实际中心容量：\(m_B\le m_A\)、\(c_B(x)=1\) 时，\(B\) 位于以 \(x\) 为中心、边长 \((m_A/q)^{1/n}\) 的盒中；\(t(B)q_B\le S\lambda\)。没有使用来源密度帽或把来源边界质量换成体积。

在成功长边流 \(\Omega_{\ell}\) 中，保留族 \(\mathcal F\subset\mathcal P\) 包含最大父，记
\[
l=|\mathcal F|,\quad M_{\mathcal F}=\sum_{B\in\mathcal F}m_B,
\quad U_{\mathcal F}=\mu\!\left(\bigcup_{B\in\mathcal F}Q_B\right).
\]
所有筛选只是原扩展的正限制，所以
\[
\boxed{\int_{\Omega_{\ell}}\frac{M_{\mathcal F}}{m_A}
\le cR,\qquad
\int_{\Omega_{\ell}}\frac{U_{\mathcal F}}{m_A}\le cR\le cSX.}
\tag{2}
\]
这保留原 \(m_A\) 分母，且只有一次原流价格。它控制的是族质量权，不是 \(|\Omega_{\ell}|\) 或有符号 \(w_{\ell}\)。

## 2. 同一族低 Gram 的真实两面作用

原成功族满足 \(\gamma_{BC}=\mu(Q_B\cap Q_C)/\sqrt{m_Bm_C}\) 的每行非对角和至多 \(1/2\)。设 \(N_{\mathcal F}(x')=\sum_{B\in\mathcal F}c_B(x')\)，对系数 \(\sqrt{m_B}\) 使用 Gram 谱上界得
\[
\int N_{\mathcal F}^2d\mu\le\tfrac32M_{\mathcal F}.
\]
Cauchy 给已证并集下界 \(U_{\mathcal F}\ge2M_{\mathcal F}/3\)。另一方面，原附源所在共同核心
\[
C_{\mathcal F}=Q_A\cap\bigcap_{B\in\mathcal F}Q_B
\]
上 \(N_{\mathcal F}=l\)，故
\[
\mu(C_{\mathcal F})\le\frac{3M_{\mathcal F}}{2l^2},\qquad
\boxed{\frac{\mu(C_{\mathcal F})}{U_{\mathcal F}}\le\frac9{4l^2}.}
\tag{3}
\]
这是完整真实 \(f\) 的来源质量估计，和(2)作用于同一 \(\mathcal F\)，不另取独立父族或另一来源分布。

## 3. 为什么不能用并集后验免费恢复原附源

这里仅作比较，不实际刷新 \(x\)。给定不记录 \(x\) 数值的以下粗记录 \(\zeta\)：原完整记录、原独立标记、raw 点集的实际中心及标记、删后索引。它不记录由 \(x\) 算出的连续秩值。相对于原记录、中心标记乘积测度和 \(\mu(dx)\)，有限 Poisson 的 Janossy 密度含
\[
\frac{c_A(x)}{m_A}
 e^{-v_x(A,s)/T}
\prod_{B\in\mathcal P}\frac{t(B)c_B(x)}{Tm_B},
\tag{4}
\]
以及下序门和原成功正权。因此在正质量 \(\zeta\) 上，原实际条件来源律 \(\eta_{\zeta}\) 对 \(\mu\) 绝对连续，且 \(\eta_{\zeta}(C_{\mathcal F})=1\)。这一步只对明确粗化的记录成立；没有声称任意记录确定的连续函数加入后仍具有产品绝对连续性。

若希望用真实并集后验
\[
\upsilon_{\mathcal F}(dx')=
\frac{1_{\cup_BQ_B}(x')}{U_{\mathcal F}}\mu(dx')
\]
作为同一来源的容量参考，则(3)强制
\[
\eta_{\zeta}\le C_0\upsilon_{\mathcal F}
\quad\Longrightarrow\quad
C_0\ge\frac{U_{\mathcal F}}{\mu(C_{\mathcal F})}
\ge\frac{4l^2}{9}.
\tag{5}
\]
同样，以 \(\mathrm{TV}=\sup_E|\eta(E)-\upsilon(E)|\) 定义，有
\[
\mathrm{TV}(\eta_{\zeta},\upsilon_{\mathcal F})
\ge\left(1-\frac9{4l^2}\right)_+.
\tag{6}
\]
所以静态核心容量小，不能同时被用作原 \(x\) 概率小；实际来源恰被选择在核心内。式(5)说明这一特定共同来源支配至少需要族大小平方的系数。它不是一般不可能性结论；(6)也不证明本题特定线性位移被积函数的误差必大，只禁止从全测度接近或常数列帽自动推出该误差小。

## 4. 对实际长边目标的准确缺口

(2)已把整族 \(M_{\mathcal F}/m_A\) 加权流控制到 \((rS^2/T)X\)。但原
\[
w_{\ell}=\frac1n\int_{\Omega_{\ell}}
\frac{x-A}{R_A}\cdot\frac{B_*-A}{R_A}
\]
没有这个质量权。该点积的符号和大小仍依实际核心内的 \(x\) 及原接受权；低 Gram 并集下界没有将它乘上 \(M_{\mathcal F}/m_A\)。

因此唯一尚缺的比较是：在保持同一实际来源和所有标签时，将上述有向点积与(2)的质量权及已付来源误差联系起来。直接改接并集后验会遇到(5)；直接去掉质量权则需要控制 \(m_A/M_{\mathcal F}\)，现有质量下降与最大父对数账只给 R481 的一般线性维数价格。不能把任一逆矩假定有限且有根阶上界。

本稿不新增软支、不重新扣旧负信用，不把(2)称为整个 \(w_{\ell}\) 的付款。它把“整族 union 共用一次 W”这一候选的实际加权收益和恢复障碍同时固定下来；完整根阶比较仍未证明，停止该候选。

## 5. 实际有限核验

指定本机Python实际执行下列脚本：

```text
PASS 49 exact Fraction assertions; 8 finite Gram models and 3 native interval-overlap cases, no original history.
```

前8个配置是共同来源胞加不交来源瓣的有限Gram模型，不声称是实际立方体族。后3个配置为 \(f=1_{[-3,3]}\)、两条边长1的真实区间、中心 \(\pm(1-c)/2\)、父中心0边长2；完整质量与交并来源质量均实际计算，但不具备原 double-center-external 或全部history门。这里只核(3)—(6)的代数与真实来源交集含义。

```python
from fractions import Fraction as F
checks=0
for l in range(2,10):
    c=F(1,2*(l-1)); M=F(l); U=c+l*(1-c)
    quadratic=c*l*l+l*(1-c)
    assert (l-1)*c==F(1,2)
    checks+=1
    assert quadratic==F(3,2)*M
    checks+=1
    assert c<=F(3,2)*M/(l*l)
    checks+=1
    assert U>=F(2,3)*M
    checks+=1
    assert c/U<=F(9,4*l*l)
    checks+=1
for c in [F(1,10),F(1,4),F(1,2)]:
    left=-(1-c)/2; right=(1-c)/2
    I=max(F(0),min(left+F(1,2),right+F(1,2))
          -max(left-F(1,2),right-F(1,2)))
    U=2-I
    assert I==c
    checks+=1
    assert I<=F(1,2)
    checks+=1
    assert I/U<=F(9,16)
    checks+=1
print(f'PASS {checks} exact Fraction assertions; 8 finite Gram models and 3 native interval-overlap cases, no original history.')
```
