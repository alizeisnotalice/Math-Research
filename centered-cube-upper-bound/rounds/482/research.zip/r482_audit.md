# R482 FINAL PASS（仅限加强合同与精确条件核）

独立预审先于作者稿，终审核对全部七项冻结输入。PASS 认证原长边流的全 raw 族 no-oldhit 正限制、其新增费用、同秩层 Janossy 条件来源核及附件已列明比较；不认证实际 work 或一般根阶预算。

真实中心容量给 E[M_raw/m_A]≤rS/T。原 t(A)>0 行的旧双源密度为 ℓ/t；积分原父 tσ 后准确抵消，损失≤2rS²X/T=τδX/512，零 t 行无原流质量。geometry 的较松 δSX/512 是同事件的替代上界，不叠扣。新增恢复费≤εX/16384；主稿在新 Ω₀ 上重推有符号 w₀，未将正限制误作 signed 积分单调性。原母账与未付项保留。

无命中后仅按 raw row 筛出的预族不依旧双源，但旧接受权不可刷新。Janossy 的 b_A(U_raw)、原父分母、实际前缀、指数与 G 均保留；单位 slab 的 e 比较只在同一正质量 D 上成立。geometry(8) 是合法来源柱式，l=0 域已置零，尚无跨配置列价。核心/并集支配所需系数及 TV 下界不被误作特定 work 误差下界；更换积分来源不能免费继承原 slab 或 history。完整目标未闭合。

实际独立复现：指定 Python、新临时目录，运行 geometry/complement 内嵌代码及 numeric.py，27、49、325 项均通过，三段 stdout 与 replay 逐字一致。numeric JSON 仅剔除 compute_index.seconds 后全字段相同，canonical SHA256：f7b9f9cffecbbf2c2244d714e8b0fd7e63b97de0340ee92359265d94e7116476。有限证据仅覆盖所述 Gram/交集代数、真实静态 Janossy 接口与参数算术；未认证完整原高门/history，未编译 PDF。

冻结输入 SHA256：

- `r482_main.md`: `3186b15e5ca52cedcc442b7ce04e7c09cd47468a6fa6f230eb75b03fd97294dc`
- `r482_geometry.md`: `7d33f0369deaa8f667562cf0adad78321cd977b4458d7218fa049638aa34a20b`
- `r482_complement.md`: `dd778ddad3873a0608f95a0a29e6ed7b4ac4667276c125b837473afddbda6886`
- `r482_numeric.md`: `8f374be6bcde6c50c2af31e95901bd0fd4b7371e5b8ca5901872a1157a8bce44`
- `r482_numeric.py`: `d3ded1691e03340f755451225c5cd7cd6d59e60de7e2136a9ba1524f85a9a3ba`
- `r482_numeric.json`: `746d181b06fdeab03e548b9f404400f60647caf44299204e2c2b365607e1109b`
- `r482_replay.json`: `026d7e7847823a8b63c7e30eaa0529b4621b822aa899a07fd4a0971ea5258470`
