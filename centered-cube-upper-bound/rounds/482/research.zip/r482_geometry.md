# R482：整族 no-hit、真实并集质量与单位秩层 Janossy 结算

## 1. 唯一机制及冻结输入

本稿只研究 R481 的同一长边流 \(\Omega_\ell\)：原 \(\Pi\)、父 \(A\)、人工来源 \(x\)、旧 \(y,z\)、实际 raw Poisson 族、最大父以及所有原历史不变。目标仍是支付其质量或原归一化 work，而不是另建无标记问题。沿用 \(m_A=q_AR_A^n\)、\(\sigma=q_A dA\)、\(\pi_A=c_A\mu/m_A\)、\(q\le q_A\le\lambda\)、\(r=\lambda/q\)、\(0\le t(A)\le S\)、\(R=\int t\,d\sigma\)，以及 \(t(A)\ge\tau\)、\(H=S/\tau\)、\(T=1024rSH/\delta\)。

尝试的联合机制是：低 Gram 族有真实并集质量收益；原旧双来源又被整族排斥。若这两项能在同一实际配置下结算，可望支付父费用。下面先去掉 old-hit 自适应删父，再精确核查共同核心到并集的来源转移。最后仍缺跨配置来源列预算；没有声称完整目标已闭合。

## 2. 全 raw 族 no-hit 可支付，且有更紧的匹配常数

固定原 \((A,x,s_A)\)，增广质量次序记 \(B\prec A\)。该次序只由质量和 tie mark 决定；截断父均满足 \(m_B\le m_A\)。raw Poisson 强度为
\[
 \frac1T1_{B\prec A}t(B)c_B(x)\frac{\sigma(dB)ds_B}{m_B}.
\]
令 \(M_{\rm raw}=\sum_Bm_B\)、\(U_{\rm raw}=\bigcup_BQ_B\)，以及
\(p_{\rm raw}=\mu(Q_A\cap U_{\rm raw})/m_A\)。真实匹配给
\[
 \{B:c_B(x)=1,m_B\le m_A\}
 \subset Q_{(m_A/q)^{1/n}}(x),
\]
其中右侧是中心域、体积 \(m_A/q\)。故一次 Campbell 公式直接给
\[
 \boxed{\mathbb E\frac{M_{\rm raw}}{m_A}
 =\frac1{Tm_A}\int_{B\prec A}t(B)c_B(x)\,d\sigma(B)ds_B
 \le\frac{rS}{T}.}\tag{1}
\]
这包含质量原子，且没有将来源质量换成中心体积：中心体积用于 \(dB\)，\(\sigma\le\lambda dB\)。由并集次可加性，\(p_{\rm raw}\le M_{\rm raw}/m_A\)。在实际旧pair条件密度 \((\ell/t)\pi_A^2\le H\pi_A^2\) 下，
\[
 \Pr\{\text{任一 raw 父捕获旧 }y\text{ 或 }z\}
 \le2H\mathbb E p_{\rm raw}\le\frac{2rSH}{T}.\tag{2}
\]
因此从 \(\Omega_\ell\) 删除整条发生 raw old-hit 的配置，得 \(\Omega_0\)，新增费用至多
\[
 |\Omega_\ell|-|\Omega_0|
 \le\frac{2rSH}{T}R\le\frac{2rS^2H}{T}X
 =\frac{\delta S}{512}X.\tag{3}
\]
这是同一次实际 positive restriction；可以使用较松的旧 Schur 常数，但不能再收两次。以下 no-hit 族未被赋予原历史。

在 \(\Omega_0\) 上，族 \(F_0\) 可只按 raw 亲和行和删除，不再按旧pair删父。给定 \((A,x,\text{raw族})\)，其定义与旧pair独立，最大父保留，\(l=|F_0|\ge v/(4T)\)。令
\[
 M_0=\sum_{B\in F_0}m_B,\quad U_0=\bigcup_{B\in F_0}Q_B,
 \quad p_0=\mu(Q_A\cap U_0)/m_A.
\]
完整低 Gram 结论给
\[
 \mu(U_0\setminus Q_A)\ge\frac23M_0-p_0m_A.\tag{4}
\]
而对任何固定 raw 配置 \(F\)，真实旧pair权为
\[
 b_A(U_F):=\int_{(Q_A\setminus U_F)^2}\ell(A,y,z)\,d\pi_A(y)d\pi_A(z)
 \le\min\{t(A),S(1-p_F)^2\}.
\tag{5}
\]
所有原历史仍包含在 \(\ell\) 内。这里必须先作 (3) 的整配置删除；不能对原先依赖旧pair删出的族直接宣称 (5)。

式 (1) 同时揭示本候选的费用问题：\(M_0/m_A\)、\(p_0\) 和 \(\mu(U_0\setminus Q_A)/m_A\) 的实际未筛期望均至多 \(rS/T\)。全流相应积分至多 \((rS/T)R\)。特别地，提供固定比例父质量的 \(M_0\ge c m_A\) 分支本身至多 \(rSR/(cT)\)。大基数并不自动意味着相对 \(m_A\) 的大并集；这不是一般目标的反例，而是该实际抽样的定量结算事实。

## 3. 单位秩层确实去掉高次归一分母，但尚未去掉来源列重复

在同一质量带内，定义与来源无关的增广父基准
\[
 d\kappa_0(B,s_B)=\frac{t(B)}{Tm_B}\sigma(dB)ds_B.
\]
固定 \((A,s_A)\) 后，捕获 \(x\) 的 prefix 强度总量是 \(v_A(x)/T\)。对 raw 点数 \(j\ge1\)、配置 \(F=(B_1,\ldots,B_j)\)，令
\[
 C_{A,F}=Q_A\cap\bigcap_{i=1}^jQ_{B_i},\qquad
 d\Lambda_j=\frac{\sigma(dA)ds_A}{m_Aj!}
 \prod_{i=1}^j1_{B_i\prec A}\,d\kappa_0(B_i,s_i).
\]
同带限制隐含于每个乘积。令 \(G(A,F,v)\) 表示所有仅涉及原父、抽样、秩及几何的成功门，包括长边和双中心外置。原 old-hit 门已由 (5) 精确处理。单位秩层 \(k\le v_A(x)/T<k+1\)（此处整数 \(k\ge1\)）上的实际 no-hit 质量精确为
\[
 Q_k=\sum_{j\ge1}\int b_A(U_F)\,d\Lambda_j
 \int_{C_{A,F}}e^{-v_A(x)/T}
 1_{\{k\le v_A(x)/T<k+1\}}G(A,F,v_A(x))\,d\mu(x).
\tag{6}
\]
这是原来源换序，不是将条件 \(x\) 改成均匀来源。每个原标签在原记录内保留；这里只投影计算总质量。该式保留了真实 prefix、slab 和 void 权，且无 \(v^{-j}\) 型分母。层内 void 权比值至多 \(e\)。

对符合成功门的配置，\(C_{A,F}\) 包含于所有 \(F_0\) 成员，故
\[
 \mu(C_{A,F})\le\frac{3M_0}{2l^2}
 \le\frac{3m_A}{2l},\qquad l\ge k/4.\tag{7}
\]
第一式由 \(l^2\mu(C_{A,F})\le\int(\sum_{F_0}c_B)^2d\mu\le3M_0/2\) 得到。于是去掉核心内的 slab/成功限制后，可以用 \(e^{-k}3M_0/(2l^2)\) 上界 (6) 的内积分。为避免任何可测存在选择，外层只保一个确定的配置门 \(G_k^0\)：它保所有与 \(x\) 无关的必要成功条件及 \(l\ge k/4\)，不要求“存在某个合适来源”。

把 \(M_0=\int\sum_{B\in F_0}c_B(z)\,d\mu(z)\) 展开，得到合法的柱式
\[
 Q_k\le\int\mathcal C_k(z)\,d\mu(z),\qquad
 \mathcal C_k(z)=\frac32e^{-k}\sum_{j\ge1}\int
 G_k^0\,b_A(U_F)\frac{\sum_{B\in F_0}c_B(z)}{l^2}\,d\Lambda_j.
\tag{8}
\]
式 (8) 在 \(G_k^0=0\) 处定义被积函数为0；在其支持上 \(l\ge k/4>0\)，没有零分母。其用途是精确定位尚缺的共同来源容量，**不是已付费用**。新积分来源 \(z\) 只需属于一个成员；它未必属于原共同核心，甚至未必仍在相同的秩层。因此不能把 \(e^{-k}\) 改成 \(e^{-v_A(z)/T}\)，也不能按 \(z\) 的 Poisson 概率把剩余配置积分归一为1。层内 void 比值至多 \(e\) 只适用于仍留在该层的来源，不适用于这次 core-to-union 转移。

唯一未证步骤是对 (8) 保留必要原门的跨配置来源列作可求和估计，或给一个不丢原 slab 的替代分配。低 Gram 已经正确支付 \(l^{-2}\)；尚未支付的是同一新来源可以接收多少不同核心配置，以及变更来源后丢失的 void 归一。不能将 (8) 的定义当作新的根阶结论。除 (3) 的真实新增小 \(X\) 分支外，本稿没有获得 \(Q\) 或实际 work 的根阶总价。

## 4. 小型实际计算及其范围

以下三个明确的二维立方体族使用完整来源 \(f=1_{[-2,2]^2}\)，各 cube 的质量和交叠均由真实积分计算。它们仅核低 Gram 的共同核心/并集不等式以及转移后 capture signature 可以变化；没有构造 Lebesgue 接收场或原高秩历史，不是主目标的反例。

```python
from fractions import Fraction as F
from itertools import product,combinations
checks=0
for eps in (F(1,20),F(1,30),F(1,40)):
 boxes=[tuple(((-eps,F(1)) if s>0 else (-F(1),eps))
              for s in signs) for signs in product((-1,1),repeat=2)]
 def inter(indices):
  ans=F(1)
  for d in range(2):
   ans*=max(F(0),min(boxes[i][d][1] for i in indices)
                    -max(boxes[i][d][0] for i in indices))
  return ans
 masses=[inter([i]) for i in range(4)]
 for i in range(4):
  assert sum(inter([i,j])/masses[i] for j in range(4) if j!=i)<F(1,2);checks+=1
 core=inter(range(4));M=sum(masses)
 union=sum((-1)**(len(J)+1)*inter(J) for k in range(1,5)
           for J in combinations(range(4),k))
 assert core<=F(3,2)*M/16;checks+=1
 assert union>=F(2,3)*M;checks+=1
 assert union==4;checks+=1
 def count(x):return sum(all(lo<=a<=hi for a,(lo,hi) in zip(x,Q)) for Q in boxes)
 assert count((F(0),F(0)))==4;checks+=1
 assert count((F(1,2),F(1,2)))==1;checks+=1
print('PASS 3 explicit full-source cube families; 27 Fraction assertions. No receiver-Lebesgue or original-history certificate.')
```

指定 Python `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python` 已实际运行，stdout 与上述 print 相同。一般结论由 (1)–(8) 的解析证明给出，不以有限检查代替全来源费用。
