"""R772 rational peak fibres, true marked price paths and entropy gates."""

import argparse
from fractions import Fraction as Q
from hashlib import sha256
from itertools import combinations, product
import json
from math import comb, prod
from pathlib import Path
from platform import python_version

from flint import arb, ctx, fmpq, __version__ as flint_version


ctx.prec = 256


def ball(x):
    q = Q(x)
    return arb(fmpq(q.numerator,q.denominator))


def interval(x,r):
    return x-r,x+r


def meet(*intervals):
    return max(a for a,b in intervals),min(b for a,b in intervals)


def length(I):
    return max(Q(0),I[1]-I[0])


def included(A,I):
    return A[0]<=I[0]<=I[1]<=A[1]


def clip(poly,axis,threshold):
    # Retain sign*coordinate <= threshold, and compute crossing points exactly.
    out = []
    for x,y in zip(poly[-1:]+poly[:-1],poly):
        fx,fy = axis(x)-threshold,axis(y)-threshold
        if (fx<=0)!=(fy<=0):
            t = fx/(fx-fy)
            out.append(tuple(s+t*(u-s) for s,u in zip(x,y)))
        if fy<=0:
            out.append(y)
    return out


def polygon_area(poly):
    return abs(sum(x*v-y*u for (x,y),(u,v) in zip(poly,poly[1:]+poly[:1])))/2


def affine_box(R,p,q,x=Q(0)):
    return [(x+u,x+u+w) for u,w in ((-R-p,-R-q),(R+p,-R-q),(R+p,R+q),(-R-p,R+q))]


def areas():
    checks = []
    for R,p,q,x in ((Q(1),Q(1,3),Q(1,2),Q(0)),(Q(3,4),Q(1,8),Q(3,5),Q(11,7)),
                    (Q(1),Q(1,2),Q(0),Q(-1,3)),(Q(2),Q(0),Q(0),Q(0)),
                    (Q(3,2),Q(2,3),Q(3,2),Q(0))):
        polygon = affine_box(R,Q(0),q,x)
        inner = polygon_area(clip(clip(polygon,lambda v:v[1],x+q),lambda v:-v[1],q-x))
        outer = polygon_area(clip(polygon,lambda v:-v[1],-x-q))+polygon_area(
            clip(polygon,lambda v:v[1],x-q))
        assert inner==4*R*q and outer==4*R*R
        assert inner+outer==polygon_area(polygon)==4*R*(R+q)

        all_shapes = affine_box(R,p,q)
        plus = polygon_area(clip(all_shapes,lambda v:-v[1],-p-q))
        minus = polygon_area(clip(all_shapes,lambda v:v[1],-p-q))
        assert plus==minus==(2*R)**2/2 and plus+minus==4*R*R
        checks.append({"R_p_q_x":list(map(str,(R,p,q,x))),"price_anchor_inner_outer":list(map(str,(inner,outer))),
                       "center_anchor_two_outer_triangles":list(map(str,(plus,minus)))})
    # Every axis endpoint of the ball about x belongs to the parent-centred upper hull.
    s,q = Q(7,4),Q(5,6)
    y = (Q(1,3),Q(-4,7))
    x = (y[0]+s,y[1]-s/3)
    widths = []
    for xk,yk in zip(x,y):
        upper = interval(yk,s+q)
        inside = length(meet(upper,interval(xk,q)))
        outside = length(upper)-inside
        assert inside==2*q and outside==2*s
        widths.append((outside,inside))
    fibre = []
    for bits in product((0,1),repeat=2):
        volume = prod(widths[l][b] for l,b in enumerate(bits))
        assert volume==(2*s)**2*(q/s)**sum(bits)
        fibre.append([bits,str(volume)])
    return {"polygon_checks":checks,"actual_exact_inside_axis_fibres":fibre}


def peak_geometry():
    A = [(Q(-5),Q(-1)),(Q(1),Q(6)),(Q(-3,2),Q(9,2)),(Q(-7,2),Q(7,2))]
    s = [length(I)/2 for I in A]
    assert s==[Q(2),Q(5,2),Q(3),Q(7,2)]
    y = [(a+b)/2 for a,b in A]
    E = [interval(x,r/32) for x,r in zip(y,s)]
    v = list(map(length,E))
    assert all(length(meet(X,Y))==0 for X,Y in combinations(E,2))
    price = []
    for j in range(-8,8):
        price.extend([((Q(j),Q(j)+Q(1,2)),Q(1,2)),((Q(j)+Q(1,2),Q(j+1)),Q(3,2))])

    def mu(I):
        return sum(density*length(meet(I,P)) for P,density in price)

    m = list(map(mu,A))
    assert m==list(map(length,A))
    # The largest parent has two histories with different genuine shared-price supports.
    history = [(0,v[0],(Q(-9,2),Q(-1))),(1,v[1],(Q(1),Q(11,2))),
               (2,v[2],(Q(-3,2),Q(4))),(3,Q(3,4)*v[3],A[3]),
               (3,Q(1,4)*v[3],(Q(-3),Q(3)))]
    label = [j for j,w,C in history]
    I = [w for j,w,C in history]
    C = [R for j,w,R in history]
    states = range(len(history))
    assert all(included(A[j],R) and w>0 for j,w,R in history)
    assert all(sum(w for a,w,C0 in history if a==j)==v[j] for j in range(len(s)))
    marked = {(a,b):mu(meet(C[a],C[b])) if label[a]!=label[b] else Q(0)
              for a,b in product(states,repeat=2)}
    K = {(a,b):w/(m[label[a]]*m[label[b]]) for (a,b),w in marked.items()}
    d = [sum(K[a,b]*I[b] for b in states) for a in states]
    assert all(w>0 for w in d)
    P = {(a,b):K[a,b]*I[b]/d[a] for a,b in K}
    B = sum(x*g for x,g in zip(I,d))
    assert all(sum(P[a,b] for b in states)==1 for a in states)
    assert all(I[a]*d[a]*P[a,b]==I[a]*I[b]*K[a,b]==I[b]*d[b]*P[b,a]
               for a,b in K)
    h = Q(33,32)

    def edge_len(x,j,q):
        return length(meet(E[j],interval(x,q)))

    def price_integrals(box,cuts):
        a,b = box
        return sorted({a,b}|{x for x in cuts if a<x<b}
                      |{x for price_cell,w in price for x in price_cell if a<x<b})

    def price_hit(known,j,q):
        ends = price_integrals(known,[x+sgn*q for x in E[j] for sgn in (-1,1)])
        total = Q(0)
        for a,b in zip(ends,ends[1:]):
            l,r = edge_len(a,j,q),edge_len(b,j,q)
            assert edge_len((a+b)/2,j,q)==(l+r)/2
            total += mu((a,b))*(l+r)/(2*v[j])
        return total/mu(known)

    partitions = [[Q(0),Q(0)],[Q(0),Q(0)]]
    raw,paths = Q(0),0
    collision_direct = Q(0)
    for a,b,c in product(states,repeat=3):
        i,j,k = label[a],label[b],label[c]
        energy = I[a]*I[b]*K[a,b]*P[b,c]
        if not energy or not(s[j]>s[i] and s[j]>s[k]):
            continue
        raw += energy
        paths += 1
        # A_i intersection A_k is contained in X=union A.
        collision_direct += energy*m[j]*mu(meet(A[i],A[k]))/(m[i]*m[k])
        X,Z = meet(C[a],C[b]),meet(C[b],C[c])
        assert marked[a,b]==mu(X)>0 and marked[b,c]==mu(Z)>0
        assert energy==I[a]*d[a]*P[a,b]*P[b,c]
        R,p,q = h*s[j],h*s[i],h*s[k]
        for x,u,v0 in product(X,E[j],E[k]):
            assert abs(u-x)<=R and abs(v0-u)<=R+q
        for z,u,v0 in product(Z,E[j],E[i]):
            assert abs(u-z)<=R and abs(v0-u)<=R+p
        assert included(interval(y[j],s[j]+q),E[k])
        assert all(included(interval(y[j],s[j]+q),interval(x,q)) for x in X)
        assert included(interval(y[j],s[j]+p),E[i])
        assert all(included(interval(y[j],s[j]+p),interval(z,p)) for z in Z)
        right = price_hit(X,k,q)
        left = price_hit(Z,i,p)
        for l,r in product((0,1),repeat=2):
            partitions[l][r]+=energy*(left if l else 1-left)*(right if r else 1-right)
    assert 0<raw<=B and sum(map(sum,partitions))==raw
    assert all(x>0 for row in partitions for x in row)
    assert partitions[0][1]==partitions[1][0]
    h_cells = sorted({x for U in A for x in U}|{x for P0,w in price for x in P0})
    row_squared = []
    for e in states:
        j = label[e]
        lower = [f for f in states if K[e,f] and s[label[f]]<s[j]]
        H2 = Q(0)
        for lo,hi in zip(h_cells,h_cells[1:]):
            mid = (lo+hi)/2
            if not any(L0<=mid<=R0 for L0,R0 in A):
                continue  # X is the union of all the actual parents.
            Hx = sum(I[f]*K[e,f]/m[label[f]] for f in lower if A[label[f]][0]<=mid<=A[label[f]][1])
            H2 += mu((lo,hi))*Hx**2
        if H2:
            row_squared.append((e,H2,I[e]*m[j]*H2/d[e]))
    collision_recomputed = sum(w for e,H2,w in row_squared)
    assert collision_recomputed==collision_direct>0
    # Adaptive diagnostic: conditioned on an actual peak continuation,
    # sample lower labels from the original row and use the known preceding x only.
    cutoff = Q(2,5)
    paid= unpaid = again = Q(0)
    changed_roots = 0
    signatures_total = 0
    largest_actual_capacity_ratio = Q(0)
    for a,b in product(states,repeat=2):
        i,j = label[a],label[b]
        if not K[a,b] or s[i]>=s[j]:
            continue
        eligible = [c for c in states if s[label[c]]<s[j] and P[b,c]]
        bmass = sum(P[b,c] for c in eligible)
        if not bmass:
            continue
        by_label = {k:sum(P[b,c] for c in eligible if label[c]==k)/bmass
                    for k in sorted({label[c] for c in eligible})}
        assert sum(by_label.values())==1
        known = meet(C[a],C[b])
        assert mu(known)==marked[a,b]
        factor = I[a]*I[b]*K[a,b]*bmass/mu(known)
        features = list(product(by_label,range(2)))

        def probability(feature,x):
            k,bit = feature
            g = edge_len(x,k,h*s[k])/v[k]
            return by_label[k]*(g if bit else 1-g)

        def volume_factor(feature):
            k,bit = feature
            return (h*s[k]/s[j])**bit

        base = price_integrals(known,[x+sign*h*s[k] for k in by_label for x in E[k] for sign in (-1,1)])
        cuts = set(base)
        for a0,b0 in zip(base,base[1:]):
            for feature in features:
                z0,z1 = probability(feature,a0),probability(feature,b0)
                split = cutoff*volume_factor(feature)
                assert probability(feature,(a0+b0)/2)==(z0+z1)/2
                if min(z0,z1)<split<max(z0,z1):
                    crossing = a0+(b0-a0)*(split-z0)/(z1-z0)
                    assert probability(feature,crossing)==split
                    cuts.add(crossing)
        points = sorted(cuts)
        signatures = set()
        test_x = points+[(p0,p1) for p0,p1 in zip(points,points[1:])]
        for cell in test_x:
            is_interval = isinstance(cell,tuple)
            x = sum(cell)/2 if is_interval else cell
            chosen = tuple(f for f in features if probability(f,x)>=cutoff*volume_factor(f))
            vf = sum(volume_factor(f) for f in chosen)
            largest_actual_capacity_ratio = max(largest_actual_capacity_ratio,vf)
            present = sum(probability(f,x) for f in chosen)
            assert cutoff*vf<=present<=1
            assert sum(probability(f,x) for f in features)==1
            for k,bit in chosen:
                observation = interval(x,h*s[k])
                envelope = interval(y[j],s[j]+h*s[k])
                assert included(envelope,observation)
                size = length(observation) if bit else length(envelope)-length(observation)
                assert size==m[j]*volume_factor((k,bit))
            if is_interval:
                signatures.add(chosen)
                a0,b0 = cell
                paid_piece = sum((probability(f,a0)+probability(f,b0))/2 for f in chosen)
                cell_mass = mu(cell)*factor
                paid += cell_mass*paid_piece
                unpaid += cell_mass*(1-paid_piece)
                again += cell_mass
        changed_roots+=len(signatures)>1
        signatures_total+=len(signatures)
    assert paid+unpaid==again==raw and 0<paid<raw and 0<unpaid and changed_roots
    C_star = max(sum(w for k,w,C0 in history if k==j)/v[j] for j in range(len(s)))
    eta_test = max(marked[e,f]/min(m[label[e]],m[label[f]])
                   for e,f in K if K[e,f] and s[label[f]]<s[label[e]])
    cap = C_star*eta_test
    assert C_star==1 and eta_test==Q(5,6)
    row_bucket_records = []
    entropy_contexts = 0
    mixed_breakpoint_checks = 0
    mixed_witness = None
    for e in states:
        i = label[e]
        lower = [f for f in states if K[e,f] and s[label[f]]<s[i]]
        for bucket in sorted({s[label[f]] for f in lower}):
            next_states = [f for f in lower if s[label[f]]==bucket]
            state_weights = {f:K[e,f]*I[f] for f in next_states}
            d_b = sum(state_weights.values())
            assert d_b==d[e]*sum(P[e,f] for f in next_states)>0
            owner_labels = {label[f] for f in next_states}
            owner_density_peak = max(sum(w/v[k] for f,w in state_weights.items() if label[f]==k)
                                     for k in owner_labels)
            assert owner_density_peak<=cap/m[i]
            radius = h*bucket
            q_ratio = radius/s[i]
            ref = interval(y[i],s[i]+radius)
            assert all(included(ref,E[k]) for k in owner_labels)
            breakpoints = 0
            for a in lower:
                X = meet(C[a],C[e])
                assert mu(X)==marked[a,e]>0
                cuts = price_integrals(X,[z+sign*radius for k in owner_labels for z in E[k] for sign in (-1,1)])
                entropy_contexts += 1
                for x in cuts+[(x+y)/2 for x,y in zip(cuts,cuts[1:])]:
                    p = sum(w*edge_len(x,label[f],radius)/v[label[f]] for f,w in state_weights.items())/d_b
                    assert 0<=p<=1
                    inner = length(meet(ref,interval(x,radius)))
                    outer = length(ref)-inner
                    assert inner==m[i]*q_ratio and outer==m[i]
                    assert d_b*p<=inner*owner_density_peak<=cap*q_ratio
                    assert d_b*(1-p)<=outer*owner_density_peak<=cap
                    entropy = -sum(ball(t)*ball(t).log() for t in (p,1-p) if t)
                    upper = ball(cap)*(entropy+ball(p)*ball(q_ratio).log()).exp()
                    assert ball(d_b)<upper
                    breakpoints += 1
                    mixed_breakpoint_checks += 0<p<1
                    if e==3 and bucket==3 and p==Q(1,2):
                        mixed_witness = {
                            "e":e,"first_history":a,"x":str(x),"m_i":str(m[i]),
                            "q_ratio":str(q_ratio),"d_b":str(d_b),"p":str(p),
                            "entropy_bound_interval":upper.str(20),
                        }
            row_bucket_records.append([e,str(bucket),str(d_b),str(owner_density_peak),breakpoints])
    assert len(row_bucket_records)==8 and entropy_contexts==22
    assert mixed_breakpoint_checks>0 and mixed_witness is not None
    entire_rows = {
        "C_star_from_history_load":str(C_star),"eta_test_true_overlap_ratio":str(eta_test),
        "nonzero_row_bucket_pairs":len(row_bucket_records),"positive_old_price_contexts":entropy_contexts,
        "rows_e_upper_radius_d_b_peak_density_and_price_checks":row_bucket_records,
        "nontrivial_inner_probabilities":mixed_breakpoint_checks,"mixed_rational_witness":mixed_witness,
        "scope":"Exact capacity at all breakpoints; mode masses are affine between them and the entropy expression is concave.",
    }
    return {
        "parents": [list(map(str,R)) for R in A],"owners": [list(map(str,R)) for R in E],
        "m_equals_d":list(map(str,m)),"history_i_I_C":[[i,str(w),list(map(str,R))] for i,w,R in history],
        "row_d":list(map(str,d)),"source_edge_mass_B":str(B),"genuine_peak_mass":str(raw),
        "positive_peak_paths":paths,
        "entire_row_entropy":entire_rows,
        "original_source_collision_X_parent_union": {
            "true_peak_sum":str(collision_direct),"H_e_squared_recomputed":str(collision_recomputed),
            "nonzero_rows_e_H_squared_and_weighted_contribution":[[e,str(u),str(w)] for e,u,w in row_squared],
        },
        "left_right_inner_axis_counts_actual_mass":[[str(w) for w in row] for row in partitions],
        "adaptive_modes": {
            "fixture_bands_use_exact_actual_radius_as_upper":True,
            "finite_multiplier_on_q_pow_t":str(cutoff),"raw_peak":str(again),"paid":str(paid),
            "unpaid":str(unpaid),"price_contexts_with_changed_choices":changed_roots,
            "mode_sets_over_contexts":signatures_total,
            "capacity_multiplier_relative_to_current_m":str(1/cutoff),
            "largest_actual_selected_capacity_over_current_m":str(largest_actual_capacity_ratio),
        },
    }


def entropy_experiment():
    summaries = []
    for n in (8,32,128,512):
        nn = arb(n)
        ell = arb(n+2).log()
        rc = (nn.sqrt()*ell**2).ceil().unique_fmpz()
        assert rc is not None
        r = int(rc)
        threshold = ball(Q(r,1024))
        L_over_n = ell**3/nn.sqrt()
        for ratio in (Q(1,2),Q(3,4),Q(63,64),None):
            logq = -L_over_n if ratio is None else ball(ratio).log()
            eligible,by_entropy = [],[]
            terms = []
            for t in range(n+1):
                log_c = arb(comb(n,t)).log()
                cost = log_c+t*logq
                assert cost<=threshold or cost>threshold
                if cost<=threshold:
                    eligible.append(t)
                if t in (0,n):
                    entropy = arb(0)
                else:
                    u = ball(Q(t,n))
                    entropy = -nn*(u*u.log()+(1-u)*(1-u).log())
                    assert log_c<entropy
                if entropy+t*logq<=threshold:
                    by_entropy.append(t)
                terms.append(cost.exp())
            assert set(by_entropy)<=set(eligible) and 0 in eligible and n in eligible
            actual = sum(terms[t] for t in eligible)
            normalize = (1+logq.exp())**n
            assert sum(terms).overlaps(normalize)
            assert actual<(n+1)*threshold.exp()
            if len(eligible)==n+1:
                assert actual.overlaps(normalize)
                coverage_probability=arb(1)
            else:
                omitted = sum(value for t,value in enumerate(terms) if t not in eligible)
                assert omitted>0 and (actual+omitted).overlaps(normalize)
                coverage_probability=actual/normalize
            if ratio is not None:
                exact = sum(comb(n,t)*ratio**t for t in eligible)
                assert ball(exact).overlaps(actual)
                assert ball(exact/(1+ratio)**n).overlaps(actual/normalize)
            summaries.append({
                "n":n,"r":r,"q_ratio":str(ratio) if ratio is not None else "exp(-L/n)",
                "legal_exact_t":len(eligible),"legal_by_entropy_upper":len(by_entropy),
                "first_positive_legal_t":eligible[1],"legal_relative_volume":actual.str(14),
                "legal_probability_when_normalized_by_full_hull":coverage_probability.str(14),
            })
    return summaries


def report():
    return {
        "scope":(
            "True 1D AC priced and closed parent geometry, disjoint full owners, and explicit finite history gates. "
            "Adaptive probes condition on a genuine peak continuation. The many-axis scans concern ideal Lebesgue volumes."
        ),
        "python":python_version(),"python_flint":flint_version,"arb_bits":ctx.prec,
        "source_sha256":sha256(Path(__file__).read_bytes()).hexdigest(),
        "commands":["python -B verify.py --out verify.json","python -B verify.py --check verify.json"],
        "one_axis_geometry":areas(),"actual_peak":peak_geometry(),"entropy_gates":entropy_experiment(),
    }


def main():
    parser = argparse.ArgumentParser()
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--out",type=Path)
    group.add_argument("--check",type=Path)
    args = parser.parse_args()
    result = report()
    data = (json.dumps(result,indent=2,sort_keys=True)+"\n").encode()
    if args.out:
        args.out.write_bytes(data)
        print(f"wrote {args.out} ({len(data)} bytes)")
    else:
        assert args.check.read_bytes()==data, "certificate differs"
        print(f"identical rerun of {args.check} ({len(data)} bytes)")
    print(f"Five polygon cases, {result['actual_peak']['positive_peak_paths']} actual peaks, "
          f"{len(result['entropy_gates'])} entropy gate tests.")


if __name__=="__main__":
    main()

