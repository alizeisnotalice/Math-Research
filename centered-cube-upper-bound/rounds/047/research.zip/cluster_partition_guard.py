#!/usr/bin/env python3
"""Round 47: exact threshold source partitions and bridge pressure guards.
Standard library only. Tree partition identities cover all thresholds analytically;
volume certificates here cover only the tested thresholds. All checks use Fraction.
"""
from fractions import Fraction as F
from functools import lru_cache
from itertools import combinations, product
import json
import time
from pathlib import Path


def fs(q):
    return str(q)


def merge(points, weights):
    d = {}
    for p, w in zip(points, weights):
        p = tuple(map(F, p)); w = F(w)
        assert w > 0
        d[p] = d.get(p, F(0)) + w
    mass = sum(d.values(), F(0))
    return tuple(sorted(d)), tuple(d[p] / mass for p in sorted(d)), mass


def families(points, weights):
    n = len(points[0]); N = len(points); ans = []
    for mask in range(1, 1 << N):
        ids = [j for j in range(N) if mask >> j & 1]
        lo = tuple(min(points[j][i] for j in ids) for i in range(n))
        hi = tuple(max(points[j][i] for j in ids) for i in range(n))
        mass = sum((weights[j] for j in ids), F(0))
        close = sum(1 << j for j, p in enumerate(points)
                    if all(lo[i] <= p[i] <= hi[i] for i in range(n)))
        ans.append((mask, mass, lo, hi, close))
    return tuple(ans), tuple(a for a in ans if a[0] == a[4])


@lru_cache(None)
def root_interval(q, n, bits):
    """Monotone dyadic brackets: roots <=1 use [0,1]; larger roots use
    [2^k,2^(k+1)]. Within a bin the fixed-bit dyadic grid is shared;
    adjacent bins share an endpoint. Thus both enclosure endpoints are
    nondecreasing in q. Exact roots at dyadic grid points are collapsed.
    """
    assert q > 0
    if n == 1:
        return q, q
    hi = F(1)
    while hi ** n < q:
        hi *= 2
    if hi ** n == q:
        return hi, hi
    lo = F(0) if hi == 1 else hi / 2
    for _ in range(bits):
        mid = (lo + hi) / 2
        v = mid ** n
        if v == q:
            return mid, mid
        if v < q:
            lo = mid
        else:
            hi = mid
    assert lo ** n <= q <= hi ** n
    return lo, hi


def prune(boxes):
    boxes = sorted(set(b for b in boxes if all(l < h for l, h in b)))
    return tuple(b for k, b in enumerate(boxes)
                 if not any(k != j and all(c[i][0] <= b[i][0] and b[i][1] <= c[i][1]
                                            for i in range(len(b)))
                            for j, c in enumerate(boxes)))


@lru_cache(maxsize=100000)
def union_volume(boxes):
    boxes = prune(boxes)
    if not boxes:
        return F(0)
    cuts = sorted(set(z for b in boxes for z in b[0]))
    total = F(0)
    for l, h in zip(cuts, cuts[1:]):
        mid = (l + h) / 2
        active = tuple(b for b in boxes if b[0][0] < mid < b[0][1])
        if active:
            section = F(1) if len(boxes[0]) == 1 else union_volume(tuple(b[1:] for b in active))
            total += (h - l) * section
    return total


def inclusion_exclusion(boxes):
    boxes = prune(boxes); total = F(0)
    for k in range(1, len(boxes) + 1):
        for group in combinations(boxes, k):
            v = F(1)
            for i in range(len(boxes[0])):
                width = min(b[i][1] for b in group) - max(b[i][0] for b in group)
                v *= max(F(0), width)
            total += v if k % 2 else -v
    return total


def envelope(fam, lam, n, bits):
    inner = []; outer = []
    for _, mass, lo, hi, _ in fam:
        rl, ru = root_interval(mass / lam, n, bits)
        inner.append(tuple((hi[i] - rl / 2, lo[i] + rl / 2) for i in range(n)))
        outer.append(tuple((hi[i] - ru / 2, lo[i] + ru / 2) for i in range(n)))
    inner = prune(inner); outer = prune(outer)
    vl, vu = union_volume(inner), union_volume(outer)
    assert vl <= vu
    return vl, vu, inner, outer


def exact_max(points, weights, x):
    n = len(x); events = {}
    for p, w in zip(points, weights):
        r = max(abs(x[i] - p[i]) for i in range(n))
        if r == 0:
            return None  # infinity at an atom
        events[r] = events.get(r, F(0)) + w
    mass = F(0); best = F(0)
    for r in sorted(events):
        mass += events[r]  # all ties enter together
        best = max(best, mass / (2 * r) ** n)
    return best


def subset_hit(fam, points, x, lam):
    n = len(x)
    return any(lam * (2 * max(max(abs(x[i] - points[j][i]) for i in range(n))
                                   for j in range(len(points)) if mask >> j & 1)) ** n < mass
               for mask, mass, _, _, _ in fam)



def components(N, edges):
    parent = list(range(N))
    def find(j):
        while parent[j] != j:
            parent[j] = parent[parent[j]]; j = parent[j]
        return j
    for ids in edges:
        for j in ids[1:]: parent[find(j)] = find(ids[0])
    groups = {}
    for j in range(N): groups.setdefault(find(j), []).append(j)
    return tuple(sorted(tuple(v) for v in groups.values()))


def indices(mask, N):
    return [j for j in range(N) if mask >> j & 1]


def admissible(fam, lam, n):
    return tuple(a for a in fam if a[1] > lam * max(h-l for l,h in zip(a[2],a[3]))**n)


def coarse(points, weights, lam, ids=None):
    if ids is None: ids = tuple(range(len(points)))
    mass = sum(weights[j] for j in ids); n = len(points[0])
    edges = [[i,j] for i in range(len(ids)) for j in range(i+1,len(ids))
             if lam * max(abs(points[ids[i]][a]-points[ids[j]][a]) for a in range(n))**n < mass]
    cs = components(len(ids),edges)
    if len(cs)==1: return (tuple(ids),)
    return tuple(sorted(c for g in cs for c in coarse(points,weights,lam,tuple(ids[j] for j in g))))


def hit(points, weights, x, lam):
    v = exact_max(points,weights,x)
    return v is None or v > lam


def spanning_tree(N, fam, n):
    strengths={}
    for mask,m,lo,hi,_ in fam:
        ids=indices(mask,N)
        if len(ids)<2: continue
        d=max(h-l for l,h in zip(lo,hi)); score=m/d**n
        for i,j in combinations(ids,2): strengths[i,j]=max(strengths.get((i,j),F(0)),score)
    edges=sorted(((w,i,j) for (i,j),w in strengths.items()),reverse=True)
    chosen=[]
    for w,i,j in edges:
        cs=components(N,[[a,b] for _,a,b in chosen])
        if not any(i in c and j in c for c in cs): chosen.append((w,i,j))
    assert len(chosen)==max(0,N-1)
    return strengths,chosen


def proper_projection_guards(records):
    for n in (2,3,4,6,8):
        vertices=list(product((0,1),repeat=n)); even=[v for v in vertices if sum(v)%2==0]
        for mask in range(1,(1<<n)-1):
            ids=indices(mask,n); a={}; b={}
            for v in vertices:
                key=tuple(v[i] for i in ids); a[key]=a.get(key,F(0))+F(1,2**n)
            for v in even:
                key=tuple(v[i] for i in ids); b[key]=b.get(key,F(0))+F(1,2**(n-1))
            assert a==b
        records.append(dict(stage='proper_projections',n=n,product_N=len(vertices),parity_N=len(even),
                            projections_checked=(1<<n)-2))
    # Certified log(2) interval from the positive atanh(1/3) series.
    H=24; low=2*sum((F(1,3)**(2*j+1)/F(2*j+1) for j in range(H)),F(0))
    high=low+2*F(1,3)**(2*H+1)/(F(2*H+1)*(1-F(1,9)))
    assert 2*low>1
    for n in (2,3,4,8,16,64,256):
        tl=n*low; tu=n*high; m=1
        while m*m<tu: m+=1
        assert (m-1)**2<tl and tu<=m*m
        assert 2*tl/m>1
        a=F(1,4); lam=F(3,2)*F(1,2**n)*a**(-n)
        assert F(1,2**n)/(lam*a**n)==F(2,3)<F(3,4)
        assert F(1,2**(n-1))/(lam*a**n)==F(4,3)>F(3,4)
        assert lam*2**(n-1)*a**n==F(3,4)
        delta=a/F(4*n)
        assert lam*2**(n-1)*(a-delta)**n>=F(9,16)
        # log(32/15)<1 since 32/15<1+1+1/2<e.
        assert F(32,15)<F(5,2)
        records.append(dict(stage='parity_short_peak',n=n,m=m,log2_lower=str(low),log2_upper=str(high),
             lam=str(lam),initial_captured_volume=str(2**(n-1)*a**n),cost_lower='3/4',
             note='symbolic all-n formulas checked, no enumeration or spatial integration at n>=16'))
    # Exact circulation: integrate piecewise-affine velocity on four oriented edges.
    for eps in (F(1,32),F(1,16),F(1,8)):
        y0=F(1,4); y1=F(3,4)
        bottom=F(0)-F(1,4)*eps
        right=(y1*y1-y0*y0)/4-F(1,4)*(y1-y0)
        top=F(1,4)*eps
        left=-(y1*y1-y0*y0)/4
        assert bottom+right+top+left==F(-1,8)
        records.append(dict(stage='posterior_circulation',eps=str(eps),oriented_integrals=list(map(str,(bottom,right,top,left))),circulation='-1/8'))


def test_source(name, points, weights, records):
    points,weights,_ = merge(points,weights)
    N=len(points); n=len(points[0]); fam,closed = families(points,weights)
    critical=sorted(set(m/max(h-l for l,h in zip(lo,hi))**n for _,m,lo,hi,_ in fam if lo!=hi))
    selected=sorted(set(critical[:2]+critical[-2:]+critical[len(critical)//2:len(critical)//2+1]))
    levels=sorted(set([F(1,64),F(1,4),F(1),F(4)]+[c*f for c in selected for f in (F(31,32),F(1),F(33,32))]))
    # Modest deterministic receiver lattice plus actual positions and pair midpoints.
    axes=[]
    for a in range(n):
        low=min(p[a] for p in points); high=max(p[a] for p in points)
        axes.append([low-F(1,3),(low+high)/2,high+F(1,3)])
    xs=set(product(*axes)); xs.update(points)
    xs.update(tuple((p[a]+q[a])/2 for a in range(n)) for p,q in combinations(points,2))
    for lam in levels:
        af=admissible(fam,lam,n); cf=admissible(closed,lam,n)
        cs=components(N,[indices(a[0],N) for a in af])
        assert cs==components(N,[indices(a[0],N) for a in cf])
        coarse_cs=coarse(points,weights,lam)
        assert all(any(set(c)<=set(d) for d in coarse_cs) for c in cs)
        for x in xs:
            flags=[hit(tuple(points[j] for j in c),tuple(weights[j] for j in c),x,lam) for c in cs]
            assert sum(flags)<=1
            assert hit(points,weights,x,lam)==any(flags)==subset_hit(fam,points,x,lam)
        records.append(dict(stage='exact_partition',name=name,n=n,N=N,lam=str(lam),
             components=[list(c) for c in cs],coarse_components=[list(c) for c in coarse_cs],
             admissible_count=len(af),closed_count=len(cf),receiver_tests=len(xs)))
    cone_tests=0
    shifts=set(tuple(F(sign,4) if i==axis else F(0) for i in range(n)) for axis in range(n) for sign in (-1,1))
    shifts.update(product((F(-1,4),F(1,4)),repeat=n))
    for x in xs:
        a=sum((w for p,w in zip(points,weights) if max(abs(x[i]-p[i]) for i in range(n))<=F(1,2)),F(0))
        for z in shifts:
            b=sum((w for p,w in zip(points,weights) if max(abs(x[i]+z[i]-p[i]) for i in range(n))<=F(3,4)),F(0))
            assert b>=a
            cone_tests+=1
    records.append(dict(stage='cone_inclusion',name=name,n=n,N=N,comparisons=cone_tests,
                        initial_side='1',later_side='3/2',shift_radius='1/4'))
    strengths,tree=spanning_tree(N,fam,n)
    tree_levels=sorted(set(critical+[F(1,2)*critical[0],2*critical[-1]])) if critical else [F(1)]
    tree_levels+= [(x+y)/2 for x,y in zip(tree_levels,tree_levels[1:])]
    for lam in tree_levels:
        expected=components(N,[indices(a[0],N) for a in admissible(fam,lam,n)])
        assert expected==components(N,[[i,j] for w,i,j in tree if w>lam])
        assert expected==components(N,[[i,j] for (i,j),w in strengths.items() if w>lam])
    records.append(dict(stage='all_threshold_tree',name=name,n=n,N=N,threshold_tests=len(tree_levels),
                         edges=[dict(i=i,j=j,strength=str(w)) for w,i,j in tree]))
    # Root-interval volume guards, separately recomputing each component family.
    for lam in (F(1,4),F(1),F(4)):
        af=admissible(fam,lam,n); cs=components(N,[indices(a[0],N) for a in af])
        previous=None
        for bits in (12,20):
            vl,vu,inner,outer=envelope(af,lam,n,bits)
            sl=F(0); su=F(0)
            for c in cs:
                cp=tuple(points[j] for j in c); cw=tuple(weights[j] for j in c)
                ff,_=families(cp,cw); ff=admissible(ff,lam,n)
                l,u,_,_=envelope(ff,lam,n,bits); sl+=l; su+=u
            assert vl==sl  # inner boxes from different exact components are disjoint
            assert vl<=vu<=su and sl<=vu
            if previous: assert previous[0]<=vl<=vu<=previous[1]
            previous=(vl,vu)
            if len(prune(inner))<=9: assert inclusion_exclusion(inner)==vl
            records.append(dict(stage='interval_volume',name=name,n=n,N=N,lam=str(lam),bits=bits,
                total_lower=str(vl),total_upper=str(vu),component_lower_sum=str(sl),component_upper_sum=str(su)))


def bridge(points, weights, lam, eps):
    # Input weights need not sum to one; comparison is raw until normalization.
    N=len(points); n=len(points[0]); assert n>=2 and N>=2
    assert len(set(points))==N, "merge repeated original positions before bridge()"
    assert all(w>0 for w in weights) and eps>0 and lam>0
    D=max(max(p[i] for p in points)-min(p[i] for p in points) for i in range(n))
    K=1
    while F(K**(n-1))<=lam*D**n*(N-1)/eps: K+=1
    b=eps/F((N-1)*(K+1)); d={p:w for p,w in zip(points,weights)}; chains=[]
    for p,q in zip(points,points[1:]):
        chain=[]
        for h in range(K+1):
            z=tuple(p[i]+F(h,K)*(q[i]-p[i]) for i in range(n))
            d[z]=d.get(z,F(0))+b; chain.append(z)
        chains.append(chain)
    for chain in chains:
        for p,q in zip(chain,chain[1:]):
            if p!=q: assert d[p]+d[q]>lam*max(abs(p[i]-q[i]) for i in range(n))**n
    assert sum(d.values())==sum(weights)+eps
    pts=tuple(sorted(d)); ws=tuple(d[p] for p in pts); index={p:j for j,p in enumerate(pts)}
    edges=[[index[p],index[q]] for chain in chains for p,q in zip(chain,chain[1:])]
    assert len(components(len(pts),edges))==1
    return pts,ws,K


def main():
    records=[]
    for n in (1,2,3,4):
        templates=[('unequal_correlated',[(F(0),)*n,tuple(F(i+1,3) for i in range(n)),tuple(F(2*(i+1),3) for i in range(n))],[1,7,2]),
          ('nested_weights',[tuple(F(j*(-1)**i,4) for i in range(n)) for j in (-3,-1,0,1,4)],[1,2,11,3,1]),
          ('separated_pairs',[tuple(F(j if i==0 else j%2,2) for i in range(n)) for j in (0,1,12,13)],[1,3,2,5]),
          ('duplicate_ties',[(F(0),)*n,(F(0),)*n,(F(1),)*n],[1,2,1])]
        for name,pts,ws in templates: test_source(name,pts,ws,records)
    # Stage 2: proper multiway witnesses cannot be replaced by pair edges.
    for n in (2,3,4):
        N=2**n; lam=F(2*N-1,2*N)
        assert F(N-1,N)<lam<F(1)
        assert F(2,N)<lam
        # Every nonsingleton vertex subset has diameter one.
        for k in range(2,N): assert F(k,N)<=lam
        records.append(dict(stage='multiway_only',n=n,N=N,lam=str(lam),
             proof_guard='all proper nonsingleton subsets empty; full cube vertices admissible'))
    for n in (1,2,4,8):
        for N in (4,8,16,64):
            lam=F(3,N)
            assert lam<1
            for k in range(2,N+1): assert F(k,N)<=lam*(k-1)**n
            records.append(dict(stage='coarse_chain_failure',n=n,N=N,lam=str(lam),
                 coarse_components=1,hyper_components=N,weak_ratio='1'))
    # Stage 3: actual small-mass bridges, strict pair inequalities, all-scale receiver computation.
    for n in (2,3,4,8):
        pts=((F(0),)*n,(F(1),)*n,tuple(F(2) if i==0 else F(0) for i in range(n)))
        ws=(F(1,4),F(1,2),F(1,4)); lam=F(1,2)
        for eps in (F(1,4),F(1,16),F(1,64)):
            bp,bw,K=bridge(pts,ws,lam,eps)
            xs=list(pts)+[tuple(F(j,4) for _ in range(n)) for j in range(-1,10)]
            for x in xs:
                old=exact_max(pts,ws,x); new=exact_max(bp,bw,x)
                assert new is None or (old is not None and new>=old)
                normalized=exact_max(bp,tuple(w/(1+eps) for w in bw),x)
                if new is None: assert normalized is None
                else: assert normalized==new/(1+eps)
            records.append(dict(stage='bridge_realization',n=n,original_N=3,eps=str(eps),lam=str(lam),
                normalized_lam=str(lam/(1+eps)),K=K,new_N=len(bp),raw_mass=str(sum(bw)),
                receiver_tests=len(xs),note='pair chain certified exactly; no high-dimensional volume integration'))
    # One dimensional mass obstruction: equal chain approaches sharp factor 2.
    for N in (2,4,16,64):
        lam=F(1); a=F(1,N); gap=2*a*F(99,100); D=(N-1)*gap
        assert 2*a>lam*gap and F(1)>lam*D/2
        records.append(dict(stage='one_dimensional_boundary',n=1,N=N,mass='1',diameter=str(D),ratio=str(lam*D)))
    proper_projection_guards(records)
    counts={}
    for r in records: counts[r['stage']]=counts.get(r['stage'],0)+1
    result=dict(round=47,status='PASS',proof_status='exact decomposition and bridge obstruction; general square-root upper bound unproved',
        arithmetic='fractions.Fraction; no randomized sampling or exponent fitting',counts=counts,cases=len(records),
        scope='Finite receiver checks and interval-volume guards verify only listed samples. General statements have separate proofs.',records=records)
    Path(__file__).with_name('results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,sort_keys=True)+'\n')
    print(json.dumps(dict(status='PASS',cases=len(records),counts=counts),sort_keys=True))

if __name__=='__main__': main()
