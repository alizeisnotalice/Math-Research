#!/usr/bin/env python3
"""Exact actual-cube source resampling; finite diagnostic continuation, not native rank kernel."""
from fractions import Fraction as F
from pathlib import Path
from collections import Counter
import json, hashlib
BASE=Path(__file__).resolve().parent
C=Counter()
def ck(k,v):
 C[k]+=1
 assert v,k
def vol(c,n):return c[0]**n
def intersection(a,b,n):
 ra,xa=a;rb,xb=b
 length=max(F(0),min(xa+ra/2,xb+rb/2)-max(xa-ra/2,xb-rb/2))
 return length*min(ra,rb)**(n-1)
def half(c,n,positive):
 r,x=c;lo=x-r/2;hi=x+r/2
 length=max(F(0),hi-max(lo,F(0))) if positive else max(F(0),min(hi,F(0))-lo)
 return length*r**(n-1)
def contains(a,b):return abs(a[1]-b[1])+b[0]/2<=a[0]/2 and b[0]<=a[0]
def run(stage,n,radii,K):
 before=sum(C.values());eps=F(1,1000)
 # Uniform compact full source f=1_Q4. Each actual cube lies inside Q4.
 cubes={(j,sgn):(r,sgn*eps if j>=3 else F(0)) for j,r in enumerate(radii) for sgn in [-1,1]}
 for (j,sgn),cube in cubes.items():
  ck('actual_cube_inside_compact_full_source',cube[0]/2+abs(cube[1])<2)
  ck('actual_q_and_same_source_cap',vol(cube,n)/cube[0]**n==1)
  for k in range(j):
   for oldsgn in [-1,1]:ck('actual_ancestor_cube_containment',contains(cube,cubes[k,oldsgn]))
 for j in range(len(radii)-1):ck('strict_mass_growth_all_edges',radii[j+1]**n>K*radii[j]**n)
 initial=(2,1);v=(0,1);u=(1,1);M0=F(1);stepsmax=len(radii)-2
 totals=Counter();bydepth={};leaves=[];maxconditional=F(0);gap_dependence=False
 def walk(current,history,path,weight):
  nonlocal maxconditional,gap_dependence
  j,sgn=current;cube=cubes[current];m=vol(cube,n);ancestor=cubes[history[-1]];depth=len(path)
  # The actual union equals its largest nested cube: proved geometrically above.
  unionmass=vol(ancestor,n);hitmass=intersection(cube,ancestor,n);p=hitmass/m
  sumold=sum(vol(cubes[h],n) for h in history)
  ck('actual_union_inside_current_and_exact_mass',hitmass==unionmass and all(contains(ancestor,cubes[h]) for h in history))
  ck('conditional_recapture_actual_union_bound',p<=sumold/m)
  ck('conditional_geometric_history_bound',sumold/m<1/(K-1))
  maxconditional=max(maxconditional,p)
  record=bydepth.setdefault(depth,dict(incoming=F(0),recapture=F(0),normal_terminal=F(0)))
  record['incoming']+=weight;record['recapture']+=weight*p;totals['recapture']+=weight*p
  leaves.append(dict(kind='first_recapture',depth=depth,path=path,current=list(current),mass=str(weight*p)))
  local=p
  for positive in [False,True]:
   mass=half(cube,n,positive)-half(ancestor,n,positive);prob=mass/m
   ck('actual_source_half_union_complement_nonnegative',mass>=0)
   # Continuation depends on the sampled source sign; the probabilities are not independent.
   normal=F(1,4) if positive else F(1,3)
   if j+1>=len(radii):normal=F(1)
   terminal=weight*prob*normal;totals['normal_terminal']+=terminal;record['normal_terminal']+=terminal
   leaves.append(dict(kind='normal_terminal',depth=depth,path=path,current=list(current),source_sign=int(positive),mass=str(terminal)))
   continuation=weight*prob*(1-normal);local+=prob
   if continuation:
    nxtj=min(j+(2 if positive else 1),len(radii)-1);nxt=(nxtj,1 if positive else -1)
    ck('continuation_strict_mass_growth',vol(cubes[nxt],n)>K*m)
    ck('new_sample_is_captured_by_selected_next_cube',contains(cubes[nxt],cube))
    gap_dependence=True
    walk(nxt,history+[current],path+[[j,sgn,int(positive)]],continuation)
  ck('joint_local_source_distribution_conserves',local==1)
 walk(initial,[v,u],[],M0)
 rec=totals['recapture'];terminal=totals['normal_terminal'];ck('joint_all_first_hit_and_terminal_mass',rec+terminal==M0)
 ck('finite_any_recapture_union_bound',rec<=F(stepsmax,K-1)*M0)
 ck('source_receiver_choices_are_dependent_fixture',gap_dependence)
 for d,z in bydepth.items():ck('generation_conditional_bound_without_survival_condition',z['recapture']<=z['incoming']/(K-1))
 # Independent recursive scalar recurrence on states (j, previous j), with full sign weights.
 def oracle(cur,old):
  j,sgn=cur;cc=cubes[cur];aa=cubes[old];m=vol(cc,n);hit=intersection(cc,aa,n)/m;ans=hit
  for pos in [False,True]:
   p=(half(cc,n,pos)-half(aa,n,pos))/m;term=F(1,4) if pos else F(1,3)
   if j+1>=len(radii):term=1
   if term<1:
    nxt=(min(j+(2 if pos else 1),len(radii)-1),1 if pos else -1);ans+=p*(1-term)*oracle(nxt,cur)
  return ans
 ck('independent_first_hit_recurrence_equals_joint_enumeration',oracle(initial,u)==rec)
 return dict(stage=stage,n=n,K=str(K),radii=list(map(str,radii)),q='1',source='uniform density 1 on Q4; total W=4^n',W=str(4**n),initial_marks={'v':[0,1],'u':[1,1],'w0':[2,1]},initial_mass='1',maximum_source_draws=stepsmax,exact_recapture=str(rec),recapture_display=float(rec),normal_terminal=str(terminal),bound_N_over_Kminus1=str(F(stepsmax,K-1)),maximum_conditional_actual_union_probability=str(maxconditional),joint_terminal_branches=len(leaves),joint_distribution_sha256=hashlib.sha256(json.dumps(leaves,sort_keys=True).encode()).hexdigest(),generation=[dict(depth=d,**{k:str(v) for k,v in z.items()}) for d,z in sorted(bydepth.items())],exact_checks=sum(C.values())-before,scope='Actual compact positive-L1 source and actual cube geometry; receiver states are finite quadrature labels, not positive receiver dx. The source-sign-dependent strict-growth/terminal kernel is a diagnostic subkernel, NOT the original R350 rank kernel. No original highpast/native input realization claimed.')
def main():
 models=[run('initial',4,[F(1),F(6,5),F(3,2),F(2)],F(3,2)),run('boundary_stress',16,[F(8+j,8) for j in range(9)],F(5,2)),run('expanded',64,[F(16+j,16) for j in range(17)],F(4)),run('expanded',64,[F(5+j,5) for j in range(6)],F(64))]
 out=dict(status='PASS',total_exact_checks=sum(C.values()),check_counts=dict(C),models=models,conditional_scope='Every source draw is conditioned on the full pre-draw path/current cube. No conditioning on subsequent survival and no independence of source and receiver choices is used. First recapture absorbs; old v,u and every earlier w remain in the union. Finite diagnostic continuation is not the native rank subkernel or a full original marked input.')
 (BASE/'r352_numeric_result.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(status='PASS',total_exact_checks=sum(C.values()),models=[{k:m[k] for k in ['stage','n','exact_checks','joint_terminal_branches','recapture_display']} for m in models]),sort_keys=True))
if __name__=='__main__':main()
