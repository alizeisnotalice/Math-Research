# R352 final independent audit — PASS for the first-recapture branch

Scope: the frozen main, ledger, README, core proof and its standalone code, numeric code/result/notes, and the necessary inherited R350/R351 interfaces. Only owned audit files were changed. No Git changes or author edits were made. This is not a re-audit of the entire historical reduction, and does not certify general weak-type closure.

## 1. Independent proposition screen and proof review

The ancestor union is exactly old v, old u, and w_0,...,w_{j-1}; it excludes current w_j. The old marks have actual strict masses m_{w0}>K m_u>K^2 m_v. Every surviving new rank edge has m_next>K m_current. The source is drawn from the true full-f posterior pi_current BEFORE testing recapture and before conditioning on rank survival. If it hits any ancestor cube, the path stops for its first hit. Otherwise the original full rank subkernel is applied without renormalizing the fresh-source restriction. This ordering is correctly specified in the frozen core.

Conditional on the complete pre-draw history, union mass is at most the sum of actual ancestor full-f masses. Therefore its posterior probability is strictly below sum_{l>=1}K^{-l}=1/(K-1). No source density cap, boundary-volume argument, or independence of successive sources is used. The old v and u are not omitted. All old source/clock/J/eta-Omega/high-past/outside/late qualifications remain ancestral labels, not newly granted qualifications at a resampled receiver.

The history-dependent fresh transition is a positive contraction of the previously proved posterior/rank transition P. From its true q du subinvariance, each live receiver marginal remains at most q. Each individual step has exact conservation M_j=B_j+T_j+M_{j+1}. First-hit branches are disjoint, so summing their masses does not repeatedly charge a path or ancestor.

With N=max(1,ceil(log(m1/m0)/log K)), strict growth forbids a surviving N-jump path, including equality when m1/m0 is a power of K. Consequently there are at most N source draws, not N+1. Thus B_rec<=N G_core/(K-1)<=N X_q/(K-1), and the complete marked terminal decomposition G_core=B_rec+F_fresh is exact.

## 2. Original high-past guard and actual new absorption

On nonzero original traffic, the old physical terminal envelope and high-past threshold imply 1+n log2>(1+sqrt(n))/epsilon. For x=sqrt(n), this forces x>1/epsilon. The elementary bounds log2<7/10 and log(4/3)<3/10 give N<=x in this nonempty regime. The positive exponential series yields N/(e^x-1)<=24/x^3<24 epsilon^3<epsilon/16 for epsilon=119/3072. Empty original high-past gives zero input and zero new charge. No new input is constructed to evade this guard.

This is a genuine small-X payment for a positive first-recapture subbranch, not a bound on the entire fresh complement. The optional arbitrary-delta/source-fee alternative in core is an alternative upper bound for that same branch and is not added to the adopted ledger.

## 3. Fresh complement and exact missing cost

The fresh source regions Q_current minus all earlier cubes are pairwise disjoint along each individual path. They are not disjoint between different paths. The frozen core correctly retains the full conditional history weighting in H(z,u) of the terminal source bill int f int xi b H. Each generation contributes at most one, hence H<=N; no bound by one or a polylogarithm is proved. The general N Delta W bound is only linear scale. Neither source resets nor rank termination replace original chronological initial/deletion/future-deleted-source atoms.

This new residual is the terminal measure of the actual killed marked process, with all original labels and new sampled path labels. It is not a restarted original G, and it need not have its current endpoint in the original R351 receiver core. The initial core restriction remains on the original witness. No free transfer of an original clock/gate to later receivers is used.

## 4. Final main/ledger/README: PASS

The B_H coefficient is [(13/3)epsilon+gamma_eff+beta+alpha_rec]X_q, beta=epsilon/16 inherited from R350/351, alpha_rec=N/(K-1)<epsilon/16 the one new payment. The source prices [C_epsilon,n+4(1+sqrt(n))]W+(D_top+C_hit)W_ex are retained unchanged. The R351 cascade fee is not billed a second time, and no optional occupation/thinning fee is inserted.

Entrance factor 2 and external Lambda=128/119 are kept. The new external charge is at most 2Lambda epsilon/16=1/192. Under the stated condition that the historical CZ 1/256 is in the same certified X ledger, the accumulated coefficient is 853/2304+2Lambda(gamma_eff+alpha_rec)<877/2304. The unallocated fraction exceeds 1427/2304; this is headroom, not a payment for the remaining integrals.

The ledger explicitly preserves fresh cross-path occupation, general soft/crossing terms, hard-contract-exterior coupled terms, distance/low-pe/extreme-scale/threshold complements, all three historical time-atom classes, H/layer/source/physical-scale/outer-integration/truncation-limit fees, and original exterior multipliers. It does not assert that a single frozen-field bound proves the arbitrary-L1 global theorem. Main and README correctly state the goal is still open and do not claim only constants or logs remain.

## 5. Numerical evidence and code scope: PASS

Read the full numeric script, result and notes. The source f=1_{Q4} is genuinely compact L1. Each receiver label is an actual cube with checked full-source mass R^n and q=1. However receivers are finite quadrature labels, not positive receiver Lebesgue sets. The source-sign-dependent continuation is explicitly a diagnostic subkernel, not the native R350 rank kernel or an original high-past/core input.

The exact joint enumeration samples source first, integrates its actual union intersection and sign-complement volumes, and only then applies source-dependent continuation/termination. Both initial v,u and all prior witnesses are in the ancestor union. Nested cube containment makes its union integral exact. Every next cube captures the newly sampled source and has a checked strict mass gap. The separate first-hit recurrence agrees with the whole joint enumeration; recapture and ordinary terminals sum to mass one. The notes correctly flag zero-mass leaves and the coarse bounds greater than one in three configurations.

The frozen result is 17,192 Fraction checks: 71 initial, 525 boundary/dependent, and 16,429+167 expanded. Decimal probability displays are merely summaries of exact rational values. They do not certify a continuous receiver realization, the original root K, or the untouched occupation remainder.

The parent reports a fresh full numeric run PASS 17,192, and the core standalone script PASS 96 strict-chain cases plus its explicit rational epsilon/polynomial certificates. I checked the core standalone script is byte-identical to the unique embedded Python block. I did not repeat the full parent pipelines. Separately, I executed six exact Fraction epsilon/exterior-ledger identities and the 335 preliminary thinning/weak-dual algebra assertions; these auditor checks are not added to parent totals.

## 6. Unadopted thinning/occupation proposals

The earlier preliminary audit distinguishes actual common receiver weights from independently source-selected weights and records the correct weak-dual direction: an upper bound on retainable mass gives a LOWER bound on the least discarded mass, not a payment upper bound. The additional continuous-capacity geometry note was read: its compact weak-star box/finite-constraint separation argument is compatible with the stated finite-band operator bounds and S>0, but it supplies no required root retention estimate. That note is not adopted in the final main ledger or archived as a new paid tool. Likewise qP<=q and input<=q alone do not bound cumulative occupation by one.

## 7. Conclusion

PASS for the actual first-ancestral-recapture payment, its event order and finite horizon, final absorption/source bookkeeping, numeric scope, and explicit unresolved fresh occupation. The general arbitrary-input root-order theorem and all historical/global unpaid slots remain open. Audit work stops at these frozen files.

## Frozen SHA256 bindings

Current-round files and necessary inherited interfaces reviewed; inherited binding is not a new exhaustive historical audit.

```
0a63cfab28a814597c5727880748e1ebbaec5c0616cb21a0ad07298278248b74  /tmp/r352_main.md
dab3b0867d53feb46ee2c4a465f267e6a778059674ba302f3155338c44bc0228  /tmp/r352_ledger.md
4613d3ebdf8973aa9c4c3cd2a0bc32b59f60135fd863e0d20623fe7923f4d79e  /tmp/r352_readme.md
3ffe96d2acab960535e236abf7fcf2a0ee0d351d7755d49501a3175dd69cfdcc  /tmp/r352_core.md
badf688d99f3d6ba9f1e0629410febc72f068f6f5b3e95b06a3c409b64126668  /tmp/r352_core_checks.py
3466865362cebbbb184ef9236d1096744e8c393084fae6e79aff644f0a657c47  /tmp/r352_numeric.py
cfe08e78db466c10231231363b7a246cdba9399ab5aa64aa900b8f0e43528b85  /tmp/r352_numeric_result.json
3d2d005ca1115af7f7636fc01ddf0559faa685b29171ebad307eb014857f9978  /tmp/r352_numeric.md
d8d4b8d08544623d265871efe41254ce660d1ddc3cefdc25f2a868127b932a5e  /tmp/r352_audit_pre.md
c8d688467593892e84608eb40774d62d61112284b40c18c261dee54f8effe4a3  /tmp/r351_geometry.md
27421b0a4fcacfbd10f89f0707be35514f3c349af8097c77753a98b0d6d6c48b  /tmp/r351_core.md
0253a14b9104f1b469d0e1d721fcb6ea6ea6256a8f8f43efabe278564619790e  /tmp/r351_main.md
b07aa6f09f20a06d09fb2dfc79459dc6e6f74aedd6f3e882e4876c615b16f253  /tmp/r351_ledger.md
77b0073f2f7559efce33c3c0f646249861953e336c2465ba7820fae2856de27f  /tmp/r351_audit.md
eef2a5ba2e20828387aab0ac8a8d3b58a55196229a44ae63f8870804b5b74b20  /tmp/r350_geometry.md
```
