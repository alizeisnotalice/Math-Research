# R352 independent preliminary audit

Only the parent's propositions and the already frozen R351/R350 contract were used. No R352 author proof has been read. Scope is the original marked G_core receiver marginal kappa(u)du on C=E_infty, with 0<=kappa<=q, common full f, m_u=int f c_u=q_u R_u^n, actual receiver Lebesgue measure, and all original ancestor/clock marks fixed. The present screen does not establish a new general root payment.

## 1. Common receiver thinning: exact sufficient certificate

A thinning must be one jointly measurable function a:C->[0,1], common to every source and original label. Set
 D_a(z)=int_C a(u)c_u(z)/R_u^n du.
The relevant cap D_a<=s is required for f(z)dz-almost every source; a stronger Lebesgue-a.e. cap is also sufficient. A separate favorable a_z for each source is not a receiver thinning. An expectation over a common randomized a is legitimate only with the corresponding expected occupancy bound and actual expected discarded marked traffic.

Tonelli and the actual shared q identity give
 int_C a kappa <= int_C a q =int f D_a<=sW.
For the original incoming marked law, restricting its same receiver label with probability a is an exact decomposition. Consequently
 G_core <=sW + Loss(a),  Loss(a)=int_C (1-a)kappa.
Thus s=O(sqrt(n) polylog(n)) and a proved Loss(a)<=delta X_q+C_delta sqrt(n)polylog(n)W would give the desired payment. Occupancy feasibility alone does not prove that most original kappa is retained. Neither a finite optimum nor stability of a finite optimizer establishes continuous-source feasibility or this missing loss bound.

## 2. Weak dual and its direction

Let psi>=0 be measurable with int f psi finite, and put b_psi(u)=int f(z)psi(z)c_u(z)/R_u^n dz. Since D_C<=A_n, b_psi is integrable on C. Every feasible a obeys
 int a kappa <=s int f psi +int_C(kappa-b_psi)_+du.
This follows by writing kappa a=b_psi a+(kappa-b_psi)a. It is a weak upper bound on the maximal retained mass, and therefore a LOWER bound on the minimal discarded mass:
 inf_a Loss(a) >=int_C min(kappa,b_psi)du-s int f psi.
In particular, the dual cannot be read backwards as an upper bound on loss or a general root payment. A good candidate a gives a valid upper bound on loss by its actual integral; a good dual can certify that loss cannot be smaller. Any claimed finite primal/dual optimum must retain this sign distinction. No strong duality or infinite-dimensional optimizer realization is used here.

For a finite certified discretization, all source constraints must cover the complete f-source support (or have an explicit residual source budget). Point probes do not certify the continuum cap. A potential or receiver weight reconstructed from numeric data is a certificate only after verifying all required source inequalities and its exact retained/discarded original mass.

## 3. Explicit feasible thinning, with its actual missing quantity

There is a constructive feasible receiver weight, requiring no optimizer. Define
 M(u)=esssup_{z in Q_u, with respect to f(z)dz} D_C(z),
 a_s(u)=min(1,s/M(u)), with a_s=1 when M=0.
Measurability follows from {M>t}={int_{Q_u} f(z)1_{D_C(z)>t}dz>0}. By Fubini, for f-a.e. z and a.e. capturing u, M(u)>=D_C(z). Hence if D_C(z)>s, a_s(u)<=s/D_C(z) on all such u, and if D_C(z)<=s simply D_a<=D_C. Thus D_{a_s}<=s, and
 G_core <=sW+int_C kappa(u)(1-s/M(u))_+du.
The remaining loss has the exact layer cake
 int_C kappa(1-s/M)_+ =int_s^{A_n} (s/t^2) int_{M>t}kappa(u)du dt
when s<A_n (zero otherwise). This is a valid actual-source interface, not a proof that the tail is small. Uniform scaling a=min(1,s/A_n) is also feasible but returns only the old linear-scale baseline. No favorable concentration of the kappa-weighted M-tail follows from thinning feasibility or from the R351 closed core guard alone.

## 4. Occupation route: exact joint condition still needed

For a fixed source-resampling/rank sub-Markov kernel P with sigma=q du subinvariant, original input I<=sigma implies each I P^j<=sigma, not their sum. Strict mass growth gives a finite horizon N. The actual occupation O=sum_{j<N}I P^j satisfies O=I+OP, and original terminal mass equals I(C), with its full path labels retained. At source y its cumulative terminal occupation is
 int xi_y(du)b_y(u) sum_{j<N}kappa_j(u)/q_u,
where b_y is the fractional lost-rank probability. A bound on this actual source quantity, integrated against f, is needed. It cannot be inferred from separate per-generation column bounds.

For example O<=L sigma implies total terminal payment <=L Delta W. Obtaining L=polylog(n) for the actual I would be useful; only L<=N follows presently. The sufficient slack condition I<=sigma-sigma P telescopes to O<=sigma, but it pays only a restricted input whose total slack mass is already a one-step terminal source fee; it is not a proof for the original full I. The auxiliary route must not alter the R351 core input or silently inherit earlier qualification after source resets.

## 5. Executed bounded algebra check

A fresh local Python Fraction process ran 335 exact assertions on finite source/receiver incidence data: explicit M-based feasible thinning, source-cap/payment identities, and both weak-dual inequalities for five caps and multiple source prices. This verifies the algebra and bound directions only, not a continuous cube realization or any original history qualification. It is auditor evidence, separate from parent/author totals.

Status: the stated thinning and occupation interfaces are valid. The quantitative discarded-flow or cumulative occupation estimate required for a general root budget remains unproved. Await author candidates before any final file-level review.
