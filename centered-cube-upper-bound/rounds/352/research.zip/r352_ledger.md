# 第352轮完整总账：只支付首次祖先回捕，不宣称全局闭合

沿用351的全部冻结定义、原始标记及历史归约。令 \(W=\int f\)，\(X_q=\int_E q\le X=\lambda|E|\)，\(W_{ex}=\int(f-T_{clip})_+\)，\(\varepsilon=119/3072\)，\(\Lambda=128/119\)。本轮不重新认证全部历史入口。

原始入口保持
\[
T_{entrance}\le8\lambda HW+2d_{eff}A_nW_\nu/H+2B_H.
\]
351核心被准确分解为首次祖先回捕和未回捕终端：
\[
G_{core}=\mathcal B_{rec}+\mathcal F_{fresh},\qquad
\mathcal B_{rec}\le\alpha_{rec}X_q.
\]
原highpast为空时两项均零且取alpha_rec=0；否则取
\[
\alpha_{rec}=N/(e^{\sqrt n}-1)<\varepsilon/16.
\]
这里 \(N=\max\{1,\lceil\log[(\lambda/q_-)(b/a)^n]/\sqrt n\rceil\}\)。这是首次回捕一次付款，不逐祖先重复付款。未回捕终端仍未得到根阶控制。

完整的当前硬层账为
\[
B_H\le\mathcal F_{fresh}
+[(13/3)\varepsilon+\gamma_{eff}+\beta+\alpha_{rec}]X_q
+[C_{\varepsilon,n}+4(1+\sqrt n)]W
+(D_{top,n}+C_{hit,n})W_{ex}.
\]
\(\beta=\varepsilon/16\) 是350已付、351沿用的级联费用，不再新增。
\(\gamma_{eff}=0\) 若旧highpast强制为空，否则 \((8/3)e^{-\sqrt n}<\varepsilon/16\)。
\[
C_{\varepsilon,n}=\frac\lambda{q_-}\left[\frac{2+3\sqrt n+2e^{-\sqrt n}}\varepsilon+1+\sqrt n\right],\quad
D_{top,n}=1+\sqrt n+\log(4/3),
\]
\[
C_{hit,n}=2(\lambda/q_-)(1+\sqrt n)(1+\log(1/\varepsilon)).
\]
以上完整保留原来源费。本轮采用alpha_rec吸收，没有增加来源费；core附件的任意delta替代界不与本账叠加。

入口乘2、历史外乘Lambda后接收系数为
\[
13/36+2\Lambda(\gamma_{eff}+\beta+\alpha_{rec}).
\]
只有在历史CZ的1/256确属同一认证X外账时，才可合计为
\[
853/2304+2\Lambda(\gamma_{eff}+\alpha_{rec})<877/2304.
\]
未分配吸收余额大于1427/2304；它不是任何尚未估计积分的付款证据。全部来源费与未付积分仍承受原外乘因子。正负信用不重复使用。

必须分别保留：

1. \(\mathcal F_{fresh}=\int f(z)\int\xi_z(du)b_z(u)\mathscr H(z,u)\,dz\)。真实历史加权占用 \(\mathscr H\) 仅知不超过N，端部容量每代不超过Delta，机械总界仍N Delta W即线性阶。沿路径区域不交不能推出跨路径不重计。这是当前B_H主攻点。
2. 一般软层 \(C_H-S_H\)、越阈 \(I_H\)、hard合同外的质量可比重尾联合交通以及尚未嵌入hard的项。
3. 宽距离、低pe、极端尺度比与全部阈值补集；高度折扣和逆尺度费用不得单独丢弃。
4. 原历史初始 \(I_{time}\)、删除跳跃 \(J_{time}\)、未来被删来源 \(D_{time}\)，独立预算未完成。辅助秩核终止和原ell的b原子均不能代替这些历史时间原子。
5. H选择、全部分层、来源、物理尺度、外积分及截断极限费用。当前单个冻结场的预算不能不经求和直接充当任意正L1输入的完整上界。

结论：本轮有一个实际回捕分支的小吸收付款；一般一致弱型上界仍未闭合，不能称仅剩常数或对数优化。
