R352 finite joint-path recapture diagnostic

Fresh local standard-library Python runs returned PASS 17,192 exact Fraction assertions: initial n=4, 71; boundary/dependent-branch n=16, 525; expanded n=64, 16,596 across two configurations. The displayed probabilities below are decimal summaries of exact rational outputs, not interval certificates. No general core lemma is numerically certified.

Reproduce:

```
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 r352_numeric.py
```

The script is self-contained, writes r352_numeric_result.json beside itself, and uses no prior temporary-file input. Only these two files and this note are deliverables.

The source is genuinely compact positive-L1 f=1 on Q4, with W=4^n. Receiver states are actual cubes of rational sides R in [1,2], centered at zero for the old v/u/w0 labels and at +/-1/1000 along the first axis thereafter. Their actual full-source masses are R^n and q=1. Every ancestor/current containment and source-support containment is checked exactly. Receiver states are finite quadrature labels, not positive receiver Lebesgue cells; therefore this is not a simulation of the actual continuous receiver field.

The initial marks are v at radius index 0, u at index 1, and w0 at index 2. At each step, history includes BOTH v,u and every earlier w. First draw a new source from the prescribed full-source posterior pi_current=f 1_Qcurrent/m_current. If it lies in the union of ancestor cubes, absorb as first recapture. Otherwise its first-coordinate sign determines the next receiver index (one or two levels upward), its next center, and its normal-terminal probability (1/3 or 1/4). At the final level normal termination is certain. Thus source and receiver choices are dependent. This diagnostic continuation is a strict-mass-growth subkernel, NOT the original R350 rank subkernel; original y/r, highpast/core qualifications and the entire native marked input are not realized here.

For each full pre-draw path, exact geometric containment makes the actual ancestor union its largest member. Its intersection with the current cube and its positive/negative halfspace complements are integrated using rational interval lengths and tensor volumes. The program checks

  Pr(recapture | full pre-draw history,current) = f(Qcurrent intersect history-union)/m_current
  <= sum_history m_i/m_current < 1/(K-1).

No conditioning on this draw's subsequent survival is made. After each source-sign branch, the dependent receiver choice is checked to capture the sampled source and to satisfy m_next>K m_current. The complete local distribution sums to one. Joint first-hit and normal-terminal branches sum to the original mass 1. A separate first-hit recurrence agrees exactly with full path enumeration. Generation recapture is bounded using the actual incoming probability, and total recapture is bounded by N/(K-1), where N is the maximum number of source draws.

| Stage | n | K | Maximum draws N | Enumerated terminal branches | Exact-probability display | N/(K-1) |
|---|---:|---:|---:|---:|---:|---:|
| Initial | 4 | 3/2 | 2 | 9 | 0.54192109375 | 4 |
| Dependent branching | 16 | 5/2 | 7 | 123 | 0.3942242665641645 | 14/3 |
| Expanded depth | 64 | 4 | 15 | 5919 | 0.0833364086156872 | 5 |
| Expanded mass separation | 64 | 64 | 4 | 27 | 0.0005820419444433267 | 4/63 |

Some enumerated leaves may have zero mass; branch counts are not counts of positive-probability histories. The first three coarse total bounds exceed 1 and are reported honestly. The last configuration gives a nontrivial total bound, while the actual probability is much smaller. All K are finite diagnostic choices, not the original root K=exp(sqrt(n)). No dimension-order inference is made.

The output preserves stage/radius/mark data, generation incoming and absorbed masses, exact total rational probabilities, and deterministic hashes of the full joint leaf distributions without storing large path tables. The decision-relevant conclusion is that the conditional recapture estimate survives explicit source-dependent receiver choices when the draw order and full ancestor union are retained. It supplies no estimate for the remaining non-recapturing occupation, no replacement for the native rank kernel, and no general root payment.
