from fractions import Fraction as F
from itertools import product
count=0
for K,length,seed in product((F(3,2),F(2),F(3),F(5)),range(1,9),range(3)):
 masses=[F(1)]
 for j in range(length):
  masses.append(masses[-1]*(K+F(seed+1,10)))
 current=masses[-1]
 old=sum(masses[:-1])
 assert old/current < 1/(K-1)
 weights=[F(1,3),F(1,2),F(1,6)]
 conditional=[min(F(1),old/current)*w for w in weights]
 assert sum(conditional)<=1/(K-1)
 count+=1
eps=F(119,3072)
assert eps<F(1,20)
assert 24*eps**3<eps/16
def exp_partial(x,n):
 term=F(1);total=term
 for j in range(1,n+1):
  term*=x/j;total+=term
 return total
assert exp_partial(F(7,10),4)>2
assert exp_partial(F(3,10),3)>F(4,3)
assert F(7,10)*20+1+F(3,10)/20<=20
for x in range(1,101):
 assert F(x+2)*2*(1+x)<=12*x*x
 assert x+2<=3*x
print("PASS",count,"strict-chain source-mass checks; exact epsilon and polynomial certificates")
