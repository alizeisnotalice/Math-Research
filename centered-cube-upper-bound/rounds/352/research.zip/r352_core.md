# R352 — Pay first ancestral source recapture in the actual occupation flow

**Proved branch payment.** Start from the fixed original R351 core entrance
\(I=\kappa(w)1_{E_\infty}(w)dw\), retaining all its old marks. During the
legal R351 source-resampling/rank iteration, stop a path at its first
resampled source lying in any earlier receiver cube. The total mass
\(\mathcal B_{\rm rec}\) of these first-recapture paths satisfies
\[
 \mathcal B_{\rm rec}\le
       \frac{N}{K-1}G_{\rm core}\le\frac{N}{K-1}X_q.        \tag{1}
\]
For the fixed original high-past entrance and
\(\varepsilon=119/3072\), this costs less than
\(\varepsilon X_q/16\). The exact remaining paths have new resampled
sources outside every ancestral receiver cube. Their cumulative
cross-path terminal source bill remains unproved.

## 1. Original labels and the order of the construction

Freeze the original full-f hard field:
\[
 m_u=\int f1_{Q_u}=q_uR_u^n,\quad
 q_-=3\lambda/4\le q_u\le\lambda,\quad
 a\le R_u\le b\le2a,\quad
 K=e^{\sqrt n},\quad \sigma(du)=q_u\,du.
\]
Use the same full-f posteriors and capture measures
\[
 \pi_u(dz)=f(z)1_{Q_u}(z)dz/m_u,\qquad
 \xi_z(du)=q_u1_{Q_u}(z)du/m_u.
\]
The R350 incoming late density satisfies \(\kappa\le q\). Restrict it
only by the R351 receiver core gate \(w\in E_\infty\). This leaves
\(I\le\sigma\) and mass \(G_{\rm core}\).

Restore the old small-receiver mark if it was integrated into \(\Omega\).
Every initial path has marks
\[
 (y_{\rm old},v_{\rm old},u_{\rm old},r_{\rm old},w_0),
 \qquad m_{w_0}>Km_{u_{\rm old}}>K^2m_{v_{\rm old}}.       \tag{2}
\]
The original source, old clock including its terminal atom, original
full \(J\), \(\eta\Omega\), high-past, outside and late masks remain fixed
on that path. They are not reevaluated at a later receiver.

Use the complete R350 noncyclic rank subkernel \(Q_z(u,dw)\), as justified
in R351: it has row mass at most one, all surviving edges have
\(m_w>Km_u\), and
\[
 \int \xi_z(du)Q_z(u,dw)\le\xi_z(dw).
\]
Its missing row mass is \(b_z(u)=1-Q_z(u,E)\). With
\(\Delta=2(1+\sqrt n)\),
\[
 \int\xi_z(du)b_z(u)=\min\{\Delta,D(z)\},\qquad D(z)=\xi_z(E). \tag{3}
\]
No old soft qualification is needed for the subkernel statement.

At current receiver \(w_j\), define its complete past union
\[
 \mathcal H_j=
 Q_{v_{\rm old}}\cup Q_{u_{\rm old}}
                 \cup\bigcup_{0\le i<j}Q_{w_i}.           \tag{4}
\]
The step order is essential:

1. Conditional on all past marks and the current \(w_j\), sample
   \(z_j\) from the original probability \(\pi_{w_j}\).
2. If \(z_j\in\mathcal H_j\), stop and charge this path to its first
   source recapture.
3. Otherwise use \(Q_{z_j}(w_j,dw_{j+1})\). Its missing probability
   gives an ordinary terminal path; its surviving part continues,
   carrying every previous mark and the new \(z_j\).

In step 1 the conditioning is **before** testing rank survival at that
step. The law is exactly \(\pi_{w_j}\); it has not been conditioned on
future success or on a new concentration gate. No independence between
successive sources is asserted. Source selection on the fresh region is
not renormalized; its lost probability is explicitly the recapture
payment.

## 2. Actual shared-source bound for the whole ancestral union

Along every surviving history the masses in (2), followed by
\(m_{w_1},\ldots,m_{w_j}\), increase by strict factors \(K\). Consequently
\[
 \begin{split}
 \pi_{w_j}(\mathcal H_j)
 &=\frac{\int f(z)1_{Q_{w_j}}(z)1_{\mathcal H_j}(z)dz}{m_{w_j}}\\
 &\le
 \frac{m_{v_{\rm old}}+m_{u_{\rm old}}+
                         \sum_{i<j}m_{w_i}}{m_{w_j}}
 <\sum_{\ell=1}^\infty K^{-\ell}
 =\frac1{K-1}.                                          \tag{5}
 \end{split}
\]
Overlapping ancestor cubes only decrease the numerator. This estimate
uses their actual full-f masses, not their volumes. It includes both
old receivers, even though they precede the new iterated flow.

Let \(M_j\) denote the mass alive before the source draw at step \(j\),
\(B_j\) the mass stopped for its first recapture there, and \(T_j\) the
fresh-source mass stopped by the rank kernel there. Conditional
integration of (5) and probability conservation give
\[
 B_j\le M_j/(K-1),\qquad
 M_j=B_j+T_j+M_{j+1}.                                    \tag{6}
\]
In particular \(M_j\le M_0=G_{\rm core}\). This is a first-recapture
decomposition; a bad path is not charged repeatedly.

The history-dependent fresh-source deletion is a positive contraction
of the legal R351 transition \(P(u,dw)=\int\pi_u(dz)Q_z(u,dw)\).
Thus its actual receiver marginals still satisfy
\(\kappa_j\le q\), because \(\sigma P\le\sigma\).
This does not identify the history-dependent process with a newly
qualified original \(G\).

Put
\[
 m_0=q_-a^n,\quad m_1=\lambda b^n,\quad
 N=\max\left\{1,\left\lceil
        \frac{\log(m_1/m_0)}{\log K}\right\rceil\right\}.
\]
No path can survive \(N\) rank jumps: it would have mass
\(>K^Nm_0\ge m_1\). Hence it undergoes at most \(N\) source draws,
including the draw at which it terminates. The initial extra mass gap
in (2) could shorten this count; it is not needed in this upper bound.
Summing (6) proves (1), and gives the exact terminal identity
\[
 G_{\rm core}=\mathcal B_{\rm rec}
                         +\sum_{j=0}^{N-1}T_j.           \tag{7}
\]

## 3. Original-entrance guard and its actual fee

This dimension guard refers to the **fixed old traffic**, not to a new
row after iteration. If that traffic is nonzero, its old high-past gate
and the real terminal capture envelope imply, with \(x=\sqrt n\),
\[
 1+x^2\log2>\frac{1+x}{\varepsilon}.
\]
If \(x\le1/\varepsilon\), then
\(1+x^2\log2<1+x^2\le(1+x)/\varepsilon\), a contradiction.
Therefore \(x>1/\varepsilon\).

For the original octave,
\[
 N\le1+x\log2+\log(4/3)/x.
\]
The elementary bounds \(\log2<7/10\), \(\log(4/3)<3/10\) imply \(N\le x\)
for \(x\ge20\). Since the actual \(\varepsilon=119/3072<1/20\), this
applies to every nonzero original entrance. The positive exponential
series gives \(e^x-1\ge x^4/24\). Hence
\[
 \frac{N}{K-1}\le\frac{x}{e^x-1}
 \le\frac{24}{x^3}<24\varepsilon^3<\varepsilon/16.          \tag{8}
\]
The last strict inequality follows already from
\(\varepsilon<1/20\), since \(24/400<1/16\).
If the old high-past gate is empty, \(G_{\rm core}=0\), and this branch
costs zero. Combining (1),(8) gives the asserted genuine
\(\varepsilon X_q/16\) receiver payment.

There is also a uniform statement for arbitrary \(0<\delta\le1\),
without using the old high-past dimension guard:
\[
 \mathcal B_{\rm rec}
 \le \delta X_q+12\sqrt{18/\delta}\,\sqrt n\,W.             \tag{9}
\]
Indeed \(N\le x+2\le3x\), and \(e^x-1\ge x^3/6\), so (1) gives
\(\mathcal B_{\rm rec}\le18X_q/x^2\).
If \(x\ge\sqrt{18/\delta}\), this is at most \(\delta X_q\).
Otherwise the already proved **unmodified** R351 finite iteration
bounds the entire entrance by
\(G_{\rm core}\le N\Delta W\le12x^2W
 \le12\sqrt{18/\delta}\,xW\).
This alternative proof is only an upper bound for the same recapture
portion; it does not charge a second copy of the entrance.

In the current ledger it suffices to use (8). Its fee, and every source
fee in (9) if that alternative is used, must receive the original
exterior multiplier. It does not replace any earlier paid receipt.

## 4. Genuine fresh-source structure and the exact unpaid occupation

On a path without recapture, define
\[
 A_j=Q_{w_j}\setminus\mathcal H_j.
\]
Then \(z_j\in A_j\), the \(A_j\) are pairwise disjoint **along that path**,
and
\[
 \int_{A_j}f
 \ge m_{w_j}-\int_{\mathcal H_j}f
 >\left(1-\frac1{K-1}\right)m_{w_j}.                      \tag{10}
\]
In particular all earlier receiver cubes miss the newly sampled
source \(z_j\). This is an actual triangular source-capture relation
in a nonnested family of cubes, not a volume estimate.
It gives no disjointness between regions from different paths.

For precision, the fresh terminal bill in (7) can be written
\[
 \sum_jT_j=\int f(z)\int\xi_z(du)b_z(u)
                                  \mathscr H(z,u)\,dz,    \tag{11}
\]
where \(\mathscr H\) is the sum of the surviving occupation densities
\(\kappa_j(u)/q_u\), each further weighted by the conditional probability,
given that current receiver and its surviving past, that
\(z\notin\mathcal H_j\).
This conditional probability is formed from the retained history;
it is not a newly chosen favorable source distribution. Standard
disintegration on the finite marked path spaces supplies a measurable
version. Each generation contributes a number in \([0,1]\), so
\(0\le\mathscr H\le N\), but no dimension-free or logarithmic bound for
its integral against the lost-rank source capacity is proved.

Equation (10) does not permit replacing \(\mathscr H\) by one in (11).
Distinct paths can charge the same source region. The current proof
still only gives \(\sum T_j\le N\Delta W\).
The new progress is the rigorously paid recapture portion and the
stronger exact structure of its complement; the desired general
cumulative occupation supersolution remains missing.

No occupation LP duality or extra negative-square credit is used.
The live fresh flow is not reset to an original \(G\), and no source
density cap or unproved cross-path Carleson condition is introduced.

## 5. Executed local checks and coordinated path test

The following embedded code was actually executed: 96 exact strict-chain
source-mass comparisons, plus exact rational certificates for the
epsilon fee and the elementary polynomial bounds. These are finite
algebra checks; equations (5)–(11) are the proof.

A separate numeric agent received the full event order, both initial
\(v,u\) marks, the subkernel terminal rule, and the requirement to test
the source event before conditioning on rank success. Its path-model
results are recorded separately and are not claimed here before delivery.

~~~python
from fractions import Fraction as F
from itertools import product
count=0
for K,length,seed in product((F(3,2),F(2),F(3),F(5)),range(1,9),range(3)):
 masses=[F(1)]
 for j in range(length):
  masses.append(masses[-1]*(K+F(seed+1,10)))
 current=masses[-1]
 old=sum(masses[:-1])
 assert old/current < 1/(K-1)
 weights=[F(1,3),F(1,2),F(1,6)]
 conditional=[min(F(1),old/current)*w for w in weights]
 assert sum(conditional)<=1/(K-1)
 count+=1
eps=F(119,3072)
assert eps<F(1,20)
assert 24*eps**3<eps/16
def exp_partial(x,n):
 term=F(1);total=term
 for j in range(1,n+1):
  term*=x/j;total+=term
 return total
assert exp_partial(F(7,10),4)>2
assert exp_partial(F(3,10),3)>F(4,3)
assert F(7,10)*20+1+F(3,10)/20<=20
for x in range(1,101):
 assert F(x+2)*2*(1+x)<=12*x*x
 assert x+2<=3*x
print("PASS",count,"strict-chain source-mass checks; exact epsilon and polynomial certificates")
~~~

Only this bounded note was authored. The general occupation/root goal
remains open after the first-recapture branch is paid.
