"""Exact ordered-block and fixed-terminal charges in a finite rank/measure model."""
from collections import defaultdict
from fractions import Fraction as F
from math import factorial, prod
import sys

N = 12
BINS = 12
SEED = 0


def sides():
    unit = 2 ** 14
    sides = []
    for j in range(BINS):
        lo, hi = unit, 2 * unit + 1
        limit = 2 ** (j + 14 * N)
        while hi - lo > 1:
            mid = (lo + hi) // 2
            if mid ** N <= limit:
                lo = mid
            else:
                hi = mid
        side = F(lo, unit)
        assert F(2) ** (j - 1) < side ** N <= 2 ** j
        sides.append(side)
    return sides


def reference():
    volumes = []
    last = None
    lengths = sides()
    for j in range(BINS):
        for label in (0, 1):
            weight = j + 2 if label == 0 else 2 * j + 3
            width = F(weight, 4096)
            center = F(2 * (2 * j + label) - (2 * BINS - 1), 64)
            if last is not None:
                assert last < center - width / 2
            last = center + width / 2
            assert abs(center) + width / 2 + lengths[j] / 2 < 4
            volumes.append(width * F(1, 64) ** (N - 1))
    h = [v / sum(volumes) for v in volumes]
    assert all(x > 0 for x in h) and sum(h) == 1
    assert all(h[2 * j] != h[2 * j + 1] for j in range(BINS))
    return h


def transitions(scale):
    p, marks = [], []
    for s in range(2 * BINS):
        k, label = divmod(s, 2)
        options = [2 * j + r for j in (k + 1, k + 3) if j < BINS for r in (0, 1)]
        weights = {cell: 1 + (2 * k + label + 3 * (cell // 2) + cell % 2) % 5
                   for cell in options}
        maximum = scale * F(5 + (k + 2 * label) % 4, 8)
        row = {x: maximum * w / sum(weights.values()) for x, w in weights.items()}
        split = {}
        for x, d in row.items():
            private_fraction = F(1 + (k + x) % 3, 4)
            split[x] = (d * private_fraction, d * (1 - private_fraction))
            assert min(split[x]) > 0 and sum(split[x]) == d
        assert sum(row.values()) <= 1
        assert all(x // 2 > k for x in row)
        p.append(row)
        marks.append(split)
    assert p[0][2] != p[1][2]
    return p, marks


def advance(vector, kernel):
    result = defaultdict(F)
    for source, a in vector.items():
        for cell, p in kernel[source].items():
            result[cell] += a * p
    return dict(result)


def powers(p):
    out = [{SEED: F(1)}]
    while nxt := advance(out[-1], p):
        out.append(nxt)
    depths = [r for r, row in enumerate(out) if any(j // 2 == 4 for j in row)]
    assert depths == [2, 4]
    return out


def elementary(weights):
    e = [F(1)] + [F(0)] * len(weights)
    for x in weights:
        for i in range(len(weights), 0, -1):
            e[i] += x * e[i - 1]
    return e


def order_test(p, marks, h, deepest):
    paid, wrong = [], []
    for s, row in enumerate(marks):
        charged = {}
        repeated = {}
        for x, alternatives in row.items():
            d = sum(alternatives)
            assert d == p[s][x] > 0
            charged[x] = sum(prob * h[x] / d for prob in alternatives)
            repeated[x] = sum(prob * h[x] / prob for prob in alternatives)
            assert charged[x] == h[x] and repeated[x] == 2 * h[x]
        paid.append(charged)
        wrong.append(repeated)
    total_h = [h[2 * j] + h[2 * j + 1] for j in range(BINS)]
    e_all = elementary(total_h)
    e_reachable = elementary(total_h[2::2])
    maxima = [F(0)] * (deepest // 2 + 1)
    number = 0
    for q in range(1, deepest // 2 + 1):
        for mask in range(2 ** q):
            m = mask.bit_count()
            z = {SEED: F(1)}
            for i in range(q):
                z = advance(advance(z, p), paid if (mask >> i) & 1 else p)
            actual = sum(z.values(), F(0))
            assert 0 <= actual <= e_reachable[m] <= e_all[m] <= F(1, factorial(m))
            maxima[m] = max(maxima[m], actual)
            number += 1
    z = {SEED: F(1)}
    w = z.copy()
    for _ in range(3):
        z = advance(advance(z, p), paid)
        w = advance(advance(w, p), wrong)
    assert 0 < sum(z.values()) and sum(w.values()) == 8 * sum(z.values())
    return number, maxima, e_reachable, e_all, sum(z.values()), sum(w.values())


def first_at_bin(p, target):
    true = defaultdict(F, {SEED: F(1)})
    for i in range(2 * target):
        for x, prob in p[i].items():
            if x // 2 <= target:
                true[x] += true[i] * prob
    return true[2 * target] + true[2 * target + 1]


def caps(h):
    weights = []
    for x in range(len(h)):
        j, label = divmod(x, 2)
        raw = ([F(k + 1) for k in range(j)] if label == 0
               else [F(1, j - k) for k in range(j)])
        w = [a / sum(raw) for a in raw]
        assert sum(w) <= 1 and (j == 0 or sum(w) == 1)
        weights.append(w)
    return weights


def terminal_charge(p, prefix, h):
    w = caps(h)
    by_k = [F(0)] * BINS
    by_x = [F(0)] * len(h)
    v = [F(0)] * BINS
    for row in prefix[1:]:
        for s, pathweight in row.items():
            k = s // 2
            v[k] += pathweight
            for x, d in p[s].items():
                assert k < x // 2
                mass = pathweight * min(d, w[x][k] * h[x])
                by_k[k] += mass
                by_x[x] += mass
    assert v[0] == 0
    assert all(v[k] == first_at_bin(p, k) <= 1 for k in range(1, BINS))
    for k in range(BINS):
        assert by_k[k] <= v[k] * sum(h[x] * w[x][k] for x in range(len(h)) if k < x // 2)
    assert all(actual <= h[x] * sum(w[x]) for x, actual in enumerate(by_x))
    total = sum(by_x)
    assert total == sum(by_k) <= sum(h) == 1
    return total, max(v), max(a / b for a, b in zip(by_x, h))


def show(q):
    if q.denominator.bit_length() <= 34:
        return str(q)
    scale = 10 ** 9
    z = q.numerator * scale // q.denominator
    a, b = divmod(z, scale)
    return f"{a}.{b:09d}↓"


def affine():
    n, a, y, length = 3, F(3, 2), F(1, 3), F(1, 4)
    lo, hi = (1 + a) * y - a * length, (1 + a) * y
    density = 1 / a ** n
    assert density * (hi - lo) ** n == length ** n
    print("Fixed-y 3D affine check: a=3/2, true image side", hi - lo,
          "and Lebesgue density factor", density)


if __name__ == "__main__":
    print("Python", sys.version.split()[0], "Fraction exact; ↓ rounded down within 10^-9.")
    print("Finite rank/measure model: true disjoint non-equal positive receiver boxes; synthetic rational rows.")
    h = reference()
    for strength in (F(1, 3), F(2, 3), F(1)):
        p, marks = transitions(strength)
        visits = powers(p)
        count, maxima, reach, upper, split_once, split_wrong = order_test(p, marks, h, len(visits) - 1)
        charge, max_visits, ratio = terminal_charge(p, visits, h)
        print("strength", strength, "max real depth", len(visits) - 1,
              "bin 4 via depths 2 and 4; subset tests", count)
        print("  maxima by |S|=1..5:", " ".join(map(show, maxima[1:])))
        print("  e_j reachable and full:", " ".join(map(show, reach[1:6])),
              "|", " ".join(map(show, upper[1:6])))
        print("  three marked blocks aggregate d / separate private d:",
              show(split_once), show(split_wrong))
        print("  all-depth final-block cost (L=1), max ever-visit of one middle bin, max cost/h(cell):",
              show(charge), show(max_visits), show(ratio))
    affine()
