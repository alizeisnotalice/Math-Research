"""Exact cube-overlap moments and rigorous gamma-mixture tail checks."""
from fractions import Fraction as F
from itertools import product
from math import comb, prod
import sys

import flint
from flint import arb, ctx, fmpq

PS = (3, 7, 16)
RATIOS = (F(1, 2), F(3, 4), F(1))
DIMS = (4, 16, 32, 64, 256, 1024)


def ball(q):
    return arb(fmpq(q.numerator, q.denominator))


def overlap(t, c, a, b):
    return max(F(0), min(t + a / 2, c + b / 2) - max(t - a / 2, c - b / 2)) / a


def slabs(r, c, p):
    a, b = 3 * r / 2, F(3, 2)
    ends = sorted({c + d for gap in ((b - a) / 2, (b + a) / 2) for d in (-gap, gap)})
    pieces = []
    for x, y in zip(ends, ends[1:]):
        alpha, beta = overlap(x, c, a, b), overlap(y, c, a, b)
        exact = sum(alpha ** (p - k) * beta ** k for k in range(p + 1)) / (p + 1)
        pieces.append((y - x) * exact / b)
    assert sum(pieces) == 1 - r + 2 * r / (p + 1)
    return pieces


def exact_power():
    centers = (F(0), F(17, 11), F(-101, 13))
    checks = 0
    for r, c, p in product(RATIOS, centers, PS):
        pieces = slabs(r, c, p)
        expected = 1 - r + 2 * r / (p + 1)
        assert sum(prod(box) for box in product(pieces, repeat=4)) == expected ** 4
        checks += 1
    print("Fraction:", checks, "physical 1D breakpoint integrations and independent 4D slab sums.")
    print("  Arbitrary fixed centers checked at 0,17/11,-101/13; exact translation removes c.")
    for r in RATIOS:
        bases = [1 - r + 2 * r / (p + 1) for p in PS]
        print("  r", r, "moment bases for p=3,7,16:", " ".join(map(str, bases)),
              "; raise each to n exactly.")


def gamma_terms(n, R):
    # Independent regularized Gamma and positive Poisson-tail enclosures.
    incomplete = [arb(1)] + [R.gamma_lower(m, 1) for m in range(1, n + 1)]
    cutoff = n + 96
    terms = [arb(1)]
    for k in range(1, cutoff + 2):
        terms.append(terms[-1] * R / k)
    exp = (-R).exp()
    assert R < cutoff + 2
    rem = exp * terms[-1] / (1 - R / (cutoff + 2))
    err = arb(0, rem.upper())
    down = arb(0)
    independent = [arb(1)] + [arb(0)] * n
    for m in range(cutoff, 0, -1):
        down += terms[m]
        if m <= n:
            independent[m] = exp * down + err
    assert all(x.overlaps(y) for x, y in zip(incomplete, independent))
    return incomplete, independent


def table(precision):
    ctx.prec = precision
    log2 = arb(2).log()
    found = {}
    for n in DIMS:
        R = log2 * n / 16
        gamma, poisson = gamma_terms(n, R)
        for r in RATIOS:
            weights = [comb(n, m) * (1 - r) ** (n - m) * (2 * r) ** m for m in range(n + 1)]
            assert sum(weights) == (1 + r) ** n
            tail = sum(ball(w) * g for w, g in zip(weights, gamma))
            second = sum(ball(w) * g for w, g in zip(weights, poisson))
            assert tail.overlaps(second) and tail > 0 and tail < ball((1 + r) ** n)
            if r == 1:
                assert tail == ball(F(2) ** n) * gamma[n] or tail.overlaps(ball(F(2) ** n) * gamma[n])
            if r < 1:
                assert tail > ball((1 - r) ** n)
            bounds = []
            for p in PS:
                exact_moment = (1 - r + 2 * r / (p + 1)) ** n
                upper = (p * R).exp() * ball(exact_moment)
                assert tail < upper and second < upper
                bounds.append(upper)
            found[n, r] = (tail, *bounds)
    return found


def log10_bracket(value):
    scaled = value.log() / arb(10).log() * 1000
    low = int(scaled.lower().floor().unique_fmpz())
    high = int(scaled.upper().ceil().unique_fmpz())

    def pretty(k):
        sign = "-" if k < 0 else ""
        a, b = divmod(abs(k), 1000)
        return f"{sign}{a}.{b:03d}"

    return f"[{pretty(low)},{pretty(high)}]"


if __name__ == "__main__":
    print("Python", sys.version.split()[0], "python-flint", flint.__version__)
    print("Q=[-1/2,1/2]^n, r=U_i/U_j; measure dt/D_j on all of R^n, fixed c.")
    print("Exact q overlaps factor by coordinates; 1-r plateau and 2r linear shoulders.")
    print("Threshold q0=2^(-n/16), R=-log(q0). Shape-zero Gamma term is 1.")
    exact_power()
    # The p=7 base is affine decreasing in r, so the endpoint comparison
    # implies the uniform tail bound at all dimensions, ratios and fixed c.
    assert 2 ** 7 * F(5, 8) ** 16 < F(17, 20) ** 16
    print("Uniform p=7 tail bound (17/20)^n: 2^7*(5/8)^16 < (17/20)^16 exactly.")
    low = table(192)
    high = table(384)
    assert all(a.overlaps(b) for key in low for a, b in zip(low[key], high[key]))
    print("Arb 192 and 384 bits; independent positive Poisson-tail enclosure at both precisions.")
    print("Every Chernoff bound and exact tail verified. Below are outward log10 brackets.")
    print(" n r | tail | e^(3R)M3 | e^(7R)M7 | e^(16R)M16")
    for (n, r), values in high.items():
        print(n, r, " | ".join(map(log10_bracket, values)))
