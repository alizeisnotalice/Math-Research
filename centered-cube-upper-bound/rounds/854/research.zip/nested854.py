"""R854: nested outer cubes under two actual source switches, and finite ranks."""

from decimal import Decimal, localcontext
from fractions import Fraction as F
import sys


R_LO = F(7071,10000)
R_HI = F(7072,10000)
Q = F(1,2)


def show(value):
    with localcontext() as ctx:
        ctx.prec=9
        return str(Decimal(value.numerator)/Decimal(value.denominator))


def positive_geometry(n):
    # Comparison sides U=(2,sqrt(2),1). Both ratios r=1/sqrt(2)
    # lie in the strict rational interval below.
    assert R_LO**2 < Q < R_HI**2 and R_LO>F(7,10)
    inset=F(1,4*n)
    rho=inset/64
    z1=1-F(9,8)*inset
    z2=F(-3,8)
    A=F(-1,4)
    private=F(1,8)
    sliver=1-F(3,4)*inset
    packets=(A,z1,z2,private,sliver)
    assert all(y-x>2*rho for x,y in zip(sorted(packets),sorted(packets)[1:]))

    # y1=(1-r)*z1+r*y0; y2=(1-r)*z2+r*y1, centred at y0=0.
    # The same rho is the halfside of every source and receiver
    # box, so repeated convex combinations preserve this perturbation bound.
    y1=((1-R_HI)*z1,(1-R_LO)*z1)
    y2=((1-R_LO)*z2+R_LO*y1[0],(1-R_HI)*z2+R_HI*y1[1])
    centers=((F(0),F(0)),y1,y2)
    assert 2*rho<y2[0] and y2[1]+2*rho<y1[0]
    assert all(max(abs(a),abs(b))+rho+1<4 for a,b in centers)

    # Top actual side l0=2(1-inset) has real bin n, by Bernoulli.
    # Middle actual side sqrt(2) has bin n/2; low side 1, bin 0.
    assert 1-n*inset==F(3,4)>Q
    l0=2*(1-inset)
    radii=((1-inset,1-inset),(R_LO,R_HI),(Q,Q))
    actual_members=[]
    for (low,high),(rlo,rhi) in zip(centers,radii):
        assert 2*rho<rlo
        arrived=[]
        for j,s in enumerate(packets):
            distance_max=max(abs(s-low),abs(s-high))
            distance_min=max(F(0),low-s,s-high)
            inside=distance_max+2*rho<rlo
            if not inside:
                assert distance_min-2*rho>rhi
            if inside:
                arrived.append(j)
        actual_members.append(tuple(arrived))
    assert actual_members==[(0,1,2,3),(0,1,2,3,4),(0,2,3)]

    # Top outer B0 uses radius 1 and contains all packets. B1=A1
    # and B2=A2. Along either switch z is in the true parent A
    # and therefore B; B_child=z+r*(B_parent-z) is nested.
    assert all(abs(s)+2*rho<1 for s in packets)
    for slot,pair in enumerate(((0,1),(1,2),(2,3))):
        assert all(p in actual_members[slot] for p in pair)

    # Actual A1 can extend outside A0. The upper outer face drops by
    # (1-r)(y0+1-z1), uniformly for all positive boxes.
    overhang=inset-F(3,10)*(1-z1+2*rho)
    assert overhang==F(209,320)*inset
    assert 0<sliver-(1-inset)-2*rho and sliver-(1-inset)+2*rho<overhang

    # The underlying sigma is exactly 3/2 on [-4,4]^n and eta is its
    # restriction to these five true packets. The actual [1,2]
    # maximal height equals 3/2 on the shown receiving cores (lambda=1).
    core=(2*rho)**n
    m=F(3,2)*core
    volumes=(l0**n,F(2)**(n//2),F(1))
    assert F(2)**(n-1)<volumes[0]<=F(2)**n
    raw=tuple(core*m*m/v**2 for v in volumes)
    assert 0<raw[0]<raw[1]<raw[2]
    print("n",n,"real bins",(n,n//2,0),"; two different positive-width pivot boxes.")
    print("  Uniform right-face overhang A1 outside A0 >=",overhang,
          "; entire positive sliver packet in A1 minus A0.")
    print("  True cut masses in units m: A0,A1,A2=(4,5,3), B0,B1,B2=(5,5,3).")
    print("  Original marked ordered raw masses on the three actual cores:",*(show(r) for r in raw))


def overlap(a,b):
    return max(F(0),min(a[1],b[1])-max(a[0],b[0]))


def rank_matrix(t,H):
    intervals=[]
    position=F(0)
    for v in t:
        assert 0<v<=4 and v<=H
        intervals.append((position,position+v))
        position+=v
    P=tuple(tuple(overlap((a-H,b-H),target)/(b-a) for target in intervals)
            for a,b in intervals)
    assert all(0<=sum(row)<=1 for row in P)
    assert all(all(P[i][j]==0 for j in range(i,len(t))) for i in range(len(t)))
    return P


def advance(weights,P):
    return tuple(sum(m*P[i][j] for i,m in enumerate(weights)) for j in range(len(weights)))


def finite_ranks():
    # Four source-direction channels; per-source angular probabilities
    # sum to one. Arithmetic t_i are toy actual rank lengths, not
    # the masses of the physical packet experiment above.
    H=F(1)
    channels=((F(2),F(1,2),(F(3,4),F(1),F(1,2),F(1),F(3,4))),
              (F(2),F(1,2),(F(1,3),F(1,2),F(2,3),F(1,4))),
              (F(3),F(2,3),(F(1),F(3,4),F(1),F(1,2),F(1),F(1,4))),
              (F(3),F(1,3),(F(1,4),F(1,3))))
    S=F(5)
    assert sum(w*p for w,p,_ in channels)==S
    data=[]
    delta=F(0)
    sum_mu=F(0)
    for mass,phase,t in channels:
        w=mass*phase
        P=rank_matrix(t,H)
        mu=tuple(w*v for v in t)
        pushed=advance(mu,P)
        assert all(a<=b for a,b in zip(pushed,mu))
        assert sum(mu)-sum(pushed)==w*min(H,sum(t))
        delta+=sum(mu)-sum(pushed)
        sum_mu+=sum(mu)
        data.append((w,t,P,mu))
    assert delta==F(55,12)<H*S
    print("Finite rank slices only: H=1, S=5, total raw",sum_mu,
          "; one-step death Delta",delta,"; componentwise mu P <= mu.")
    for q in range(1,5):
        killed=F(0)
        carried=F(0)
        for w,t,P,mu in data:
            current=mu
            for _ in range(q):
                nxt=advance(current,P)
                assert all(a<=b for a,b in zip(nxt,current))
                assert sum(current)-sum(nxt)<=w*min(H,sum(t))
                current=nxt
            killed+=sum(mu)-sum(current)
            carried+=w*min(q*H,sum(t))
        assert killed<=q*delta<=q*H*S and carried<=q*H*S
        print("  q",q,"dead with uniform rank reattachment",killed,
              "; with exact rank carried",carried,"; qHS",q*H*S)


if __name__=="__main__":
    print("Python",sys.version.split()[0],"| exact Fraction, strict rational sqrt(2) bounds")
    print("Each source switch sends B to z+(U_child/U_parent)*(B-z); two nested outer reductions.")
    for n in (4,8,16):
        positive_geometry(n)
    finite_ranks()
    print("All assertions passed. The geometric and finite-rank tests use separate models.")
