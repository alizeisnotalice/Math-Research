"""Exact early-clock and terminal-menu audits."""
from argparse import ArgumentParser
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
from zipfile import ZipFile
import sys

PIN = "d7e0cc5e31eb94cd6bb536dca40af122bc4793adfdf0dfb43e0e2b94be01c674"


def fixture(path):
    assert sha256(path.read_bytes()).hexdigest() == PIN
    with ZipFile(path) as archive:
        key = "handoff850.py"
        env = {"__file__": key, "__name__": "pinned_real_rows"}
        exec(compile(archive.read(key), key, "exec"), env)
    return env


def advance(vector, p):
    out = defaultdict(F)
    for e, amount in vector.items():
        for f, prob in p[e].items():
            out[f] += amount * prob
    return dict(out)


def uniform_rank():
    count, h, d = 39, F(4), F(3)
    rev = []
    # Rank in [i,i+1) to the whole of [j,j+1) with increment in [H,H+d],
    # for every point of the current interval. Every rank-bin mass R_s is 1.
    for i in range(count):
        rev.append({j: 1 / d for j in range(i + 1, count)
                    if h <= j - i - 1 and j - i + 1 <= h + d})
    assert h > d and max(map(len, rev)) == 2
    lmax = 0
    max_bound_ratio = F(0)
    paths_30 = []
    for i in range(count):
        trace = {i: F(1)}
        total = defaultdict(F)
        steps = 0
        while trace:
            trace = advance(trace, rev)
            if not trace:
                break
            steps += 1
            for j, weight in trace.items():
                total[j] += weight
            if i == 0 and trace.get(30, 0):
                paths_30.append((steps, trace[30]))
        assert all(value <= 1 / d for value in total.values())
        if total:
            max_bound_ratio = max(max_bound_ratio, d * max(total.values()))
        lmax = max(steps, lmax)
    assert paths_30 == [(5, F(1, 243)), (6, F(1, 729))]
    print("UNIFORM-RANK MECHANISM ONLY: t=1,H=4,d=3; reverse edges advance 5 or 6.")
    print("  max depth", lmax, "max sum_r(K*)^r/(R_s/d)", max_bound_ratio,
          "; from 0 to 30 by depth", [(r, str(x)) for r, x in paths_30])


def geom():
    print("EXACT GEOMETRIC GAP SUM (alpha,beta,g0,sum,2alpha/beta):")
    for alpha, beta in ((F(0), F(3, 4)), (F(1, 3), F(4, 3)),
                        (F(2, 7), F(5)), (F(3, 4), F(1))):
        if not alpha:
            print(" ", alpha, beta, "-", 0, 0)
            continue
        g = 1
        while 2 ** g * alpha < beta:
            g += 1
        value = F(2) ** (1 - g)
        assert value <= 2 * alpha / beta
        assert 2 ** g * alpha >= beta and (g == 1 or 2 ** (g - 1) * alpha < beta)
        print(" ", alpha, beta, g, value, 2 * alpha / beta)


def outward(lo, hi):
    scale = 10 ** 8
    lq, hq = lo * scale, hi * scale
    l = lq.numerator // lq.denominator
    u = -(-hq.numerator // hq.denominator)
    return f"[{l//scale}.{l%scale:08d},{u//scale}.{u%scale:08d}]"


def gamma_tail():
    unit = 64  # lambda=1,b=8,a0=3

    def A(q):
        return F(2 ** q, (q + 1) ** 2)

    def gamma(q):
        return unit * (1 + A(q))

    start = 10
    ratio_of_A = 2 * F(start + 1, start + 2) ** 2
    # Both A and the increasing ratio-of-A are bounded below by their
    # q=10 values; this proves the growth bound on all q>=10.
    assert ratio_of_A > F(3, 2)
    assert A(start) * (ratio_of_A - F(3, 2)) >= F(1, 2)
    print("Gamma tail: q<10 finite; q>=10 successive ratios >=3/2, certificate t*tail<=13.")
    for t in (F(96), F(128), gamma(18), F(4, 3) * gamma(32)):
        finite_end = 43
        partial = sum(1 / gamma(q) for q in range(finite_end + 1) if gamma(q) >= t)
        start_tail = finite_end + 1
        while gamma(start_tail) < t:
            start_tail += 1
        cap = 3 / gamma(start_tail)
        assert t * (partial + cap) <= 13
        print("  t=", t, "; t*sum_{Gamma>=t} Gamma^-1 in", outward(t * partial, t * (partial + cap)))


def histories(k, start):
    # Actual folded path; its conditional active point is preserved by every K.
    stack = [((start,), F(1))]
    complete = []
    while stack:
        path, prob = stack.pop()
        row = k[path[-1]]
        halt = 1 - sum(row.values())
        if halt:
            complete.append((path, prob * halt))
        for f, value in row.items():
            assert f % 2 == start % 2
            stack.append((path + (f,), prob * value))
    assert sum(value for _, value in complete) == 1
    return complete


def true_events(model, n, h, depth, theta):
    rows, _, packet = model["real_fixture"](n)
    p, bare, _, _ = model["kernels"](rows, n, h)
    k = [{f ^ 1: value for f, value in row.items()} for row in p]
    paths = []
    for y in range(len(k)):
        hs = [(seq, coeff) for seq, coeff in histories(k, y) if len(seq) >= depth]
        paths.append(hs)
    tail = [sum(value for _, value in hs) for hs in paths]
    powers = model["powers"](k)
    assert tail == [sum(row.values()) for row in powers[depth - 1]]
    initial = {}
    frozen = [defaultdict(F), defaultdict(F)]
    for i, root in enumerate(rows):
        for tag in (0, 1):
            for old, prob in bare[2 * i + tag].items():
                frozen[tag][old // 2] += root.fraction * prob
        for left, a in p[2 * i].items():
            for right, b in p[2 * i + 1].items():
                value = root.fraction * a * b * tail[left] * tail[right]
                if value:
                    initial[i, left // 2, right // 2] = value
    assert all(u <= rows[y].fraction for side in frozen for y, u in side.items())
    live = initial.copy()
    while live:
        step = False
        for i in (0, 1):
            mass = defaultdict(F)
            for key, value in live.items():
                mass[key[i + 1]] += value
            remove = {y for y, value in mass.items() if value < theta[i] * frozen[i][y]}
            if remove:
                step = True
                live = {key: value for key, value in live.items() if key[i + 1] not in remove}
        if not step:
            break
    return rows, packet, paths, tail, live


def physical_menu(packet, threshold, real_model):
    center = F(-1, 16)
    half = real_model["PACKET"]
    quarter = [center - half + i * half / 2 for i in range(5)]
    assert quarter[-1] == center + half
    assert all((b - a) / (2 * half) * packet == packet / 4
               for a, b in zip(quarter, quarter[1:]))
    amount = F(2) ** (-threshold)
    assert packet * amount / 4 <= 1  # C0*lambda*2^k for C0=lambda=1 and every k>=0
    return quarter, amount


def clocks(model, n, h, depth, theta, gap, expected):
    rows, packet, paths, tail, live = true_events(model, n, h, depth, theta)
    quarter, amount = physical_menu(packet, gap, model)
    live_total = sum(live.values(), F(0))
    paid = [F(0), F(0), F(0)]
    used = set()
    example = None
    for (_, left, _), root_weight in live.items():
        middle = 2 * left + 1
        assert tail[middle] > 0
        clock = [F(0), F(0), F(0)]
        for path, coeff in paths[middle]:
            assert path[0] == middle and all(e % 2 == middle % 2 for e in path)
            early = [rows[f // 2] for f in path[1:]
                     if rows[middle // 2].bin - rows[f // 2].bin >= gap]
            late = rows[path[-1] // 2]
            assert bool(early) == (rows[middle // 2].bin - late.bin >= gap)
            # Real private w is fixed in one of its four physical equal-mass
            # quarters. Continue to retain the same actual active point u.
            flags = [[(v.slot % 4 == c and
                       F(2) ** (rows[middle // 2].bin - v.bin) * amount >= 1)
                      for v in early] for c in range(4)]
            union = F(sum(any(hits) for hits in flags), 4)
            terminal = F(sum(hits[-1] for hits in flags), 4) if early else F(0)
            repeat = F(sum(sum(hits) for hits in flags), 4)
            assert union == F(len({v.slot % 4 for v in early}), 4)
            assert terminal == F(bool(early), 4) and repeat == F(len(early), 4)
            assert 0 <= terminal <= union <= 1 and union <= repeat
            for i, weight in enumerate((union, terminal, repeat)):
                clock[i] += coeff * weight
            used.update(rows[middle // 2].bin - v.bin for v in early)
            if early and (example is None or len(early) > len(example[1])):
                example = (rows[middle // 2].bin, [(v.bin, v.slot % 4) for v in early])
        for i in range(3):
            paid[i] += root_weight * clock[i] / tail[middle]
    total = sum(row.fraction for row in rows)
    assert total == 59
    actual = (live_total / total, *(x / total for x in paid))
    assert actual == expected
    print(f"TRUE n={n}, H/t={h}, minimum total depth={depth}, theta={theta}, true-bin g0={gap}:")
    print("  B_infty/F, all clocks/F, terminal father/F, repeated clocks/F:", *actual)
    print("  overcount from repeated clocks/F:", (paid[2] - paid[0]) / total)
    if live:
        print("  held u in B (actual possible first coordinate 1/16); same private w in A quarters",
              " ".join(map(str, quarter)))
        print("  menu probability is 2^(-g0) on quarter v.slot%4, beta=1;",
              "eligible geometric bin gaps:", sorted(used))
        print("  one actual qualifying path clock list (start bin; early bin and quarter):", example)


if __name__ == "__main__":
    parser = ArgumentParser()
    parser.add_argument("--handoff", required=True, type=Path, help="pinned rounds/850/research.zip")
    mod = fixture(parser.parse_args().handoff)
    print("Python", sys.version.split()[0], "Fraction exact; pinned R850 archive", PIN)
    print("Actual reduced-H P/K gates and R852 pruning thresholds; general thick history is untested.")
    print("Identical earlier true y menus evaluated on the same retained-source path and same private w.")
    clocks(mod, 64, 7, 2, (F(1, 49), F(1, 49)), 18,
           (F(512, 141659), F(11456, 48589037), F(192, 991613), F(11456, 48589037)))
    clocks(mod, 64, 8, 2, (F(5, 16), F(5, 16)), 18, (F(0), F(0), F(0), F(0)))
    clocks(mod, 256, 8, 3, (F(1, 8), F(9, 64)), 72,
           (F(341747, 5799936), F(4073923, 185597952), F(341747, 23199744), F(4142611, 185597952)))
    uniform_rank()
    geom()
    gamma_tail()
