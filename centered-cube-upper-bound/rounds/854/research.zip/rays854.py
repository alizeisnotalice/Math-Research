"""R854: true multi-bin angular overlaps and original marked row charges."""

from fractions import Fraction as F
from math import comb, factorial, prod
import sys

from flint import arb, ctx, __version__ as flint_version


EPS = F(1,128)
SOURCE_HALF = EPS/2
A_MASS = F(1,16)
B_MASSES = (F(1,32),F(1,16),F(1,8))
PARTNER = (F(1,4),F(5,8),F(7,8))
SQRT2_LO = F(1414,1000)
SQRT2_HI = F(1415,1000)
SCALE_BOUNDS = ((F(1),F(1)),(SQRT2_LO,SQRT2_HI),(F(2),F(2)))
LAYOUTS = {
    "common": (F(1,4),)*3,
    "disjoint": (F(1,8),F(1,4),F(3,8)),
}


def as_arb(x):
    return arb(x.numerator)/x.denominator


def certify_geometry(n,layout):
    centers = LAYOUTS[layout]
    assert SQRT2_LO**2 < 2 < SQRT2_HI**2
    # E_j has center U_j * theta_j e1 with all halfsides U_j*EPS.
    # Source anchor and the three partner packets have halfside SOURCE_HALF.
    # All source packets are centered on the second axis.
    assert n>=2 and n%2==0
    assert all(v-u>2*SOURCE_HALF for u,v in zip((F(0),)+PARTNER,PARTNER))
    first_axis_envelopes = []
    for slot,((lo,hi),center) in enumerate(zip(SCALE_BOUNDS,centers)):
        assert center-EPS>SOURCE_HALF
        assert center+EPS+SOURCE_HALF < F(1,2)
        assert lo*(F(1,2)-center-EPS) > SOURCE_HALF
        first_axis_envelopes.append((lo*(center-EPS),hi*(center+EPS)))
        assert hi*(center+EPS)+1 < 4
        for p,u in enumerate(PARTNER):
            if p<=slot:
                assert u+SOURCE_HALF < lo*(F(1,2)-EPS)
            else:
                assert u-SOURCE_HALF > hi*(F(1,2)+EPS)
    assert all(end<start for (_,end),(start,_) in zip(first_axis_envelopes,first_axis_envelopes[1:]))
    if layout=="disjoint":
        assert all(b-a>2*(EPS+SOURCE_HALF) for a,b in zip(centers,centers[1:]))
    # sigma=5/4 on [-4,4]^n outside the four packets, and inside them
    # constant densities realizing the masses. Eta is the cut to these
    # same four packets, in BOTH layouts.
    total = A_MASS+sum(B_MASSES)
    assert all(m>F(5,4)*(2*SOURCE_HALF)**n for m in (A_MASS,)+B_MASSES)
    assert 1 < F(5,4) < F(5,4)+total==F(49,32)<2
    if layout=="common":
        # At theta_*=1/4 e1, every actual anchor s hits all three true
        # E_j, since s/U_j is at most SOURCE_HALF in all coordinates.
        assert all(SOURCE_HALF<lo*EPS for lo,_ in SCALE_BOUNDS)
        fixed_mass=tuple(A_MASS+sum(B_MASSES[:j+1]) for j in range(3))
        assert fixed_mass==(F(3,32),F(5,32),F(9,32))


def overlap_averages(n):
    # Exact proof for every s in the whole positive-width source box.
    # Normalized angular supports have centers theta0 - s/U_j.
    # For axes i, pair intersection length = 2EPS - |s_i|*gap,
    # with gap=|1/U_j-1/U_k|. Uniform source coordinates are independent
    # and E|s_i|=SOURCE_HALF/2. With three ordered inverse scales,
    # the intersection of the two extremes is already in the middle.
    root_two=arb(2).sqrt()
    mid=1/root_two
    ratio=as_arb(SOURCE_HALF/(4*EPS))
    i01=(1-ratio*(1-mid))**n
    i12=(1-ratio*(mid-arb(1)/2))**n
    i02_exact=F(15,16)**n
    i02=as_arb(i02_exact)
    assert i02.overlaps((1-ratio/2)**n)
    assert 0<i02<i01<1 and i02<i12<1
    if n>=4:
        assert as_arb(F(7,8)**n) < i02
    return i01,i12,i02,i02_exact


def replay(n):
    for layout in LAYOUTS:
        certify_geometry(n,layout)
    bins=(0,n//2,n)
    D=tuple(2**j for j in bins)
    C=(2*EPS)**n
    q=tuple(sum(B_MASSES[:j+1]) for j in range(3))
    V=tuple(C*d for d in D)
    assert sum(v/d for v,d in zip(V,D))==3*C
    row_weights=tuple(m/d for m,d in zip(q,D))
    row_total=C*sum(row_weights)
    raw_marked=A_MASS*row_total
    raw_all=C*sum((A_MASS+m)**2/d for m,d in zip(q,D))
    assert 0<raw_marked < raw_all

    i01,i12,i02,i02_exact=overlap_averages(n)
    thresh2=i01+i12-i02
    thresh3=i02
    union=3-i01-i12
    assert (union+thresh2+thresh3).overlaps(arb(3))
    assert 0<thresh3<thresh2<union
    weighted2=(as_arb(row_weights[0])*i01 + as_arb(row_weights[1])*thresh2
               +as_arb(row_weights[2])*i12)/as_arb(sum(row_weights))
    weighted3=i02
    assert 0<weighted3<weighted2<1

    # Same actual partner, not just the existence of a different
    # admissible partner at each hit centre. B0 sees all three ranks,
    # B1 sees ranks 1 and 2, and B2 sees only rank 2.
    geometry_by_slot=(i01,thresh2,i12)
    common_partner2=(as_arb(B_MASSES[0])*sum(m/d for m,d in zip(geometry_by_slot,D))
                     + as_arb(B_MASSES[1]*(F(1,D[1])+F(1,D[2])))*i12)/as_arb(sum(row_weights))
    common_partner3=i02*as_arb(B_MASSES[0]*sum(F(1,d) for d in D)/sum(row_weights))
    assert 0<common_partner3<common_partner2<weighted2 and common_partner3<weighted3
    assert all(0<d for d in D)

    print("n",n,"true bins",bins,"D",D,"; each angular size C",C)
    print("  Identical per-scale receiving volumes in both layouts. Exact integral M_s=3C for EVERY s.")
    print("  Shared common angle mean volume/C: M>=1,2,3:",
          *(v.str(10) for v in (union,thresh2,thresh3)))
    print("  Disjoint angular layout: 3,0,0 exactly; physical centres are distinct in either layout.")
    print("  Three independent Q-angles have all-hit probability C^3 in both layouts.")
    print("  A single shared Q-angle has all-hit probability C*(15/16)^n or 0.")
    print("  Common layout: every s has M>=3 volume/C >=",F(7,8)**n,
          "; source-integrated exactly",i02_exact)
    print("  Original marked mass",as_arb(raw_marked).str(10),
          "; unmarked full ordered tau on same cores",as_arb(raw_all).str(10))
    print("  Share of original marked mass M>=2,3:",
          weighted2.str(10),weighted3.str(10),"; disjoint 0,0.")
    print("  Share retaining same actual partner at >=2,3 reached bins:",
          common_partner2.str(10),common_partner3.str(10),"; disjoint 0,0.")
    arr=tuple(as_arb(raw_marked)*v for v in (weighted2,weighted3,common_partner2,common_partner3))
    print("  Actual four gated marked masses:",
          *(v.str(10) for v in arr))
    print("  Fixed common theta=1/4 e1: actual nested box masses 3/32,5/32,9/32 for every s.")


def product_gate_poly(n,m):
    # On the partial-radius test the coordinate factors of b_rho/mass
    # are independent V_i uniform on [1/2,1]. The change t=-log(V)
    # gives density 2*exp(-t) on [0,log(2)]. Inclusion-exclusion up to
    # m shifted upper faces and the gamma integral yield the exact
    # coefficients of P(product V_i >= 2^(-m)) as a polynomial in ln 2.
    if m<=0:
        return (F(0),)
    if m>=n:
        return (F(1),)
    coeff=[F(0)]*n
    for r in range(m):
        w=F(2**(n-r)*(-1)**r*comb(n,r))
        coeff[0]+=w
        for j in range(n):
            coeff[j]-=w*F((m-r)**j,2**(m-r)*factorial(j))
    return tuple(coeff)


def product_gate(n,m):
    log_two=arb(2).log()
    value=arb(0)
    for c in reversed(product_gate_poly(n,m)):
        value=value*log_two+as_arb(c)
    if 0<m<n:
        assert 0<value<1
    return value


def local_source_tests(n):
    D=(1,2**(n//2),2**n)
    bins=(0,n//2,n)
    angular=(2*EPS)**n
    partners=tuple(sum(B_MASSES[:i+1]) for i in range(3))
    raw=angular*A_MASS*sum(m/d for m,d in zip(partners,D))
    # Every tested source neighbourhood stays in the same isolated
    # packet; rho is the full side length in s+rho*Q.
    packet_centers=(F(0),)+PARTNER
    assert min(b-a for a,b in zip(packet_centers,packet_centers[1:]))>4*SOURCE_HALF
    inputs=(("empty gate",SOURCE_HALF,4),
            ("partial",2*SOURCE_HALF,n+3),
            ("full",4*SOURCE_HALF,n+5))
    print("  Local source-mass gates on the same true anchors and partner packets:")
    for name,rho,Nexp in inputs:
        N0=2**Nexp
        pA=[]
        pB=[]
        for j,d in zip(bins,D):
            if name=="empty gate":
                assert N0*max((A_MASS,)+B_MASSES)*F(1,2)**n<d
                pA.append(arb(0))
                pB.append((arb(0),)*3)
            elif name=="full":
                assert N0*min((A_MASS,)+B_MASSES)>=d
                pA.append(arb(1))
                pB.append((arb(1),)*3)
            else:
                threshold=Nexp-4-j
                pA.append(product_gate(n,threshold))
                pB.append(tuple(product_gate(n,threshold+shift) for shift in (-1,0,1)))

        # True raw row on E_i: C*eta(A)*m_{B_p}/D_i.
        # Independence here is the raw fixed-witness restriction to
        # two uniform source packets inside every tested true centre.
        per_bin=tuple(as_arb(angular*A_MASS*partners[i]/d)*pA[i] for i,d in enumerate(D))
        gate_a=sum(per_bin)
        gate_b=sum(as_arb(angular*A_MASS/d)*sum(as_arb(B_MASSES[p])*pB[i][p]
                   for p in range(i+1)) for i,d in enumerate(D))
        both=sum(as_arb(angular*A_MASS/d)*pA[i]*sum(as_arb(B_MASSES[p])*pB[i][p]
                 for p in range(i+1)) for i,d in enumerate(D))
        assert (both.overlaps(gate_a) and gate_a.overlaps(gate_b)) if name!="partial" else (
            0<both<gate_a<as_arb(raw) and both<gate_b<as_arb(raw))
        if name=="full":
            assert both.overlaps(as_arb(raw))

        # Geometric counting bound, valid for every s. If ell_y+rho<=2,
        # the enlarged true cube covers s+rho Q. Hence marked j satisfy
        # log2(b/lambda)-1-n*log2(1+rho) <= j <= log2(N0*b/lambda).
        # The remaining indices have U_j+rho>2. Since rho<=1,
        # log2(1+rho) and log2(2/(2-rho)) are both <= 2*rho.
        top=sum(F(2)**j>(2-rho)**n for j in range(n+1))
        assert top<=1+2*n*rho
        count_cap=3+Nexp+4*n*rho
        max_b=A_MASS*(F(1,2)**n if name=="empty gate" else 1)
        pointwise_max=sum(d<=N0*max_b for d in D)
        assert pointwise_max<=count_cap

        print("   ",name,"rho",rho,"N0=2^"+str(Nexp),
              "; anchor pass fractions per bin:",*(p.str(9) for p in pA),
              "; pointwise max count",pointwise_max,"; top exception",top)
        print("      raw ratios anchor/partner/both:",
              *((r/as_arb(raw)).str(10) for r in (gate_a,gate_b,both)),
              "; actual both-gate mass",both.str(10))
        if n==4 and name=="partial":
            print("      exact anchor probability polynomials in ln(2), low to high degree:",
                  *(tuple(map(str,product_gate_poly(n,Nexp-4-j))) for j in bins))
    print("    Every source has marked-bin count <= 3+log2(N0)+4*n*rho by enlargement and the top exception.")


if __name__=="__main__":
    ctx.prec=192
    print("Python",sys.version.split()[0],"python-flint",flint_version,"| Fraction and 192-bit Arb")
    print("Same actual source cut, positive-width centres, lambda=1; all true window heights in [5/4,49/32].")
    print("Marked raw flow: anchor A and every actual B partner, with denominator lambda*D_j^2.")
    for dimension in (4,8,16):
        replay(dimension)
        local_source_tests(dimension)
    print("All assertions passed. Source integrals follow from exact box formulas.")
