# R179 独立中段容量审计

先行检查点：已读本轮task_contract.md，未读本轮作者证明。仅本责任文件；不数值、Git/spawn/PDF或修改他人。一般上界未闭合，等待精确候选一次后审。

## 1. 实际共同输入与source顺序

固定原omega,V,j,y,t时，nu/Zt/wt/et/Pit独立receiver x。真实的固定时间joint source measure是

    beta(dy) [1_Zt(v)wt(y,v)/et(y)]nu(dv)
             [1_Zt(u)wt(y,u)/et(y)]nu(du).

它在每个y下是两份原条件概率，外质量为beta；不是y,v,u三个独立概率来源。只有完成对依x的terminal/good/high/rho/history门的合法正支配后，才能把该固定测度移到dx外。Pig、g、wg、alpha与actual s/L/R不能随之冻结。

原m_L由x−y定义，原k_t由y−v及Ci/ξt定义。中段m0<m_L<k_delta不提供一个免费的小k_t、有限active坐标集合或source独立性。

## 2. 同alpha容量的准确归一与质量齐次性

沿原U≤DK0且bad上U=0，QJ=Jnu，

    alpha_y QJ=Dq−U_y nu,
    gamma_y=alpha_y QJ/D
       =G0+integral(K0−U_y/D)nu≥G0+B_y,
    G0=q−K0nu≥K0(beta−nu), B_y=K0(1_bad_y nu).

K0必须在该固定x,j的整个y积分中共同，且q测试同一f。gamma不是任意可分配的来源预算。full-initial bad、later deletion、samealpha反应及nu外槽不可因概率记号消失。逐j的tau=K0y(beta−nu)/gamma、mu_y=K0u nu_bad/gamma仍有真实密度；其联合质量≤1/4并不控制带原反核的receiver列积分。

共同把f,beta,nu乘c>0时，q、et/eg、gamma/G0/B_y均乘c，原alpha/rho/Pi不变；原raw及W_beta乘c。因此任何新规范化/优化结论应保持这个一次齐次性。把beta、nu各自概率化后重选alpha或q，已经换了原输入，不能作为本轮原交通证明。

## 3. EJ接口与不能遗失的分母

已付平方能量是原v好槽的J_v(delta+)²Pi²，价格nW_beta/(2K)。Cauchy的另一因子准确为

    (p_y² A_v²/J_v)Pi_t(dv)Pi_t(du),
    p_y²A_v²/J_v=1_good p_y²rho_v²J_v/(9Q_v²).

保留strict lower-score/bad质量可减小第二因子；把它改成1也只能给上界。不能交换为J_vk_u²、把一份wg^(−1) overlap冒作wg^(−2) companion，或因rho≤1而忽略samealpha在新的容量优化中的约束。

high资格中1/et≤1/eg≤p_y/(2Kq)，但只在actual high/eligible域原样成立。若使用这个不等式后正去high门，必须保留新引入的p_y、q^(−1)（平方分母相应平方），不能在门外仍以原eg作无条件归一。若全程只用x-independent Pi的概率质量，可以在原可定义域外/et0取零subprobability，并把actual time正扩到固定j的ξ∈[1/2,1]；不能把这两种不同扩张依据混用。

fixed-J能量和R17835都要求同次receiver积分固定b。若新命题改用b(x)，不仅overlap，原EJ的J空间结算也须重新付价；不能只说有一个自适应半径工具就继承固定J energy。额外窗口/j菜单、原history/source聚合均须显示。

## 4. mixed-overlap的可用精确形式

固定s,L,b，lambda=L/b，W_(s,L)=(1−s)delta0+s w_L dz。逐坐标有

    b_(s,L)=h_L*W_(s,L),
    h_lambda*phi≤r(lambda)C,
    phi_lambda*phi≤r(lambda)(w_lambda*C).

因此mixed current与J的overlap保留soft位移卷积；W是概率并不意味着w_lambda*C≤C。多维只在固定源中心、固定参数下张量化。若用shift后的中心y+z，原Ci(y,v)、wt、bad、samealpha和history仍在原y，不能用Ci(y+z,v)直接替换。

receiver s(x),L(x)使W也依x，不能先把它当作固定来源measure移到dx外。R178共同半径35已付的是hardreceiver与J/C的共同空间衰减，及m=0上一份阈值分母；SO18/CJ的额外p、Q、et²、rho和第二来源乘子仍须保留。新mixed工具必须准确声明它支付的是这些乘子中的哪一部分，以及其真实source/receiver价格。

通用good插值可作为核比较起点：对任意固定theta∈[0,1]，

    pA≤(K/3)^theta p^(1−theta)(J/wg)^theta.

但theta改变的是实际分母次数/核指数；不能用某一指数的overlap结论替另一个指数的实际积分。beta总来源非乘积，也没有可免费独立化的两赢家。

## 5. 本次后审的最小义务

等待Astra/Sol/父级准确候选，再核：同一原nu与alpha；真实et及原source qualification；fixed或variable b的全部代价；是否真的控制平方companion/原raw而不是其单分母替身；mixed adaptive积分是否保留soft位移与actualdx；中段覆盖及所有原source/scale/time/j/history费用。

不预判一个统一强lemma，也不认证有限numerics。当前只有以上精确接口/必要义务，没有新原raw付款。先行检查点交付后停止等待。


## 6. 新fullmixed adaptive候选：作者前独筛

固定b、source中心y,v，允许任意measurable L(x)∈[b/2,b]及0≤s(x)≤sbar≤1。因w偶递减，w_L≤2w_b，故

    W_(s,L)≤Theta_b:=delta0+2sbar w_b dz,
    P_(s,L)(x−y)≤integral h_L^(tensor n)(x−y−z)Theta_b^(tensor n)(dz).

Theta不依x；不是把原source shift后重选权重。正Tonelli后对每个位移z以center y+z套R178真实adaptive common-L35，得到

    integral P_(s(x),L(x))(x−y)J_b(x−v)dx
      ≤35b^(−n) product_i[C(D_i)+2sbar(w*C)(D_i)],
    D_i=(y_i−v_i)/b.                                  (B1)

单份原wt/wg≤1/productCi仍在原y/v计算，所以加权上界为

    35b^(−n) product_i[1+2sbar R_1(D_i)],
    R_lambda(D)=(w_lambda*C)(D)/C(D).                  (B2)

原Pi、alpha、Ci均未随位移重选。Theta总质量(1+2sbar)^n确实存在；nsbar≤c仅使此总质量≤e^(2c)。由于C≤1，无分母overlap也有这个粗质量界，但B2的source ratio乘积不由nsbar≤c单独控制；它可能随n或source位移很大。平方分母/CJ source价仍未由B1/B2支付。

## 7. source ratio解析界：作者前独筛

设psi(D)=exp(−|D|)/(1+|D|)。直接a分部与a=(1+u)^(−1)代换给

    psi/2≤w≤psi.

C≥w/2：|D|≤1/2时hardtent≥1/2且w≤1；外部用F≥w、C=h*F≥phi及正半轴凸平均phi≥w。故C≥psi/4。另一方面

    psi(r−t)≤(1+|t|)e^|t| psi(r), |t|≤1/2,

先得phi≤(3/2)e^(1/2)psi；hard h也满足同样界，故F≤该常数psi，再与h平均得

    psi/4≤C≤(9e/4)psi.                               (B3)

对0<lambda≤1，epsilon_scale=1/lambda−1≥0，D≥0，w_lambda(r)≤lambda^(−1)e^(−|r|/lambda)/(1+|r|)。B3给

    R_lambda(D)≤(9e/lambda)[1+2A(D,epsilon_scale)],
    A(D,epsilon)=integral_0^D e^(−epsilon r)/(1+r)dr.   (B4)

独立核算：三段r<0、0≤r≤D、r>D；两外段除以psi(D)后总和≤[1+e^(−epsilon D)]/(2+epsilon)≤1。中段用

    1/[(1+r)(1+D−r)]
      =[1/(1+r)+1/(1+D−r)]/(D+2),

乘(1+D)/(D+2)≤1，第二项在r与D−r配对后≤第一项，因此≤2A。边界D0中段为空；负D由偶性。

A≤log(1+D)；epsilon>0时在1/epsilon处分开，尾≤integral_1^infinity e^(−u)/u du≤e^(−1)，故

    A≤min{log(1+D),log(1+1/epsilon)+e^(−1)}.

lambda1必须用A(D,0)=log(1+D)，不能代入1/0。B1的共同支配位移是w_b，所以其source ratio是R_1；不能因每个actual L(x)<b就免费把B4的lambda<1 cutoff套入B2，除非另证uniform scalegap的共同位移支配。

这些是明确sourcecost的核界，不是原raw或middle band全预算。候选已作者前筛查通过，等待成稿与父级capacity准确命题再审；不数值、不扩展反例。


## 8. source ratio远场：作者前筛查

由endpoint Laplace代换可直接算w(D)~e^(−D)/D，C(D)~A e^(−D)/D，A=[2sinh(1/2)]²。固定0<lambda<1时，w_lambda的e^r矩有限，故正确远场候选为

    R_lambda(D)→integral e^r w_lambda(r)dr
                =integral_0^1 2a/(1−lambda²a²)da
                =−log(1−lambda²)/lambda².

证明须用指数尾截断/可积支配，不可只写形式极限。lambda1时中段tilted卷积约A/[r(D−r)]，积分贡献2logD；固定端段与两个外段只有O(1)的ratio。因此R_1(D)/(2logD)→1。此渐近只说明sourcecost不能无条件删去，不是fixedlambda的uniform upper bound，更不能交换D→infinity与lambda→1。

## 9. 父级Jeffreys混合与连续尺度包络：作者前筛查

令dmu(s)=ds/[pi sqrt(s(1−s))]。对任何非负a_i,b_i，候选

    sup_(s∈[0,1]) product_i[(1−s)a_i+s b_i]
       ≤C0 sqrt(n) integral product_i[(1−s)a_i+s b_i]dmu(s),
    C0=2pi e                                                   (C1)

独立核算成立。展开非负Bernoulli likelihood后，只须核s^k(1−s)^(n−k)。写s=sin²theta，theta*=asin sqrt(k/n)，朝pi/4方向取h=1/(4sqrt n)的区间；可略过pi/4但不越[0,pi/2]。一路sin/cos之一不减，另一个≥原值/2，故loglik''≥−10n，theta*一阶导为0，端点k0/n按零幂延拓导数也为0。损失≤5/16<1，区间mu质量1/(2pi sqrt n)，从而C1。全和的sup≤各项sup之和，保留全部非负展开系数；无source独立假设。

固定s下lambda^n P_(s,lambda)(z)随lambda非减，hard跳向正。因此准确点态正包络为

    sup_(lambda∈[1/2,1])P_(s,lambda)(z)
       ≤P_(s,1)(z)+n integral_(1/2)^1P_(s,lambda)(z)dλ/λ.    (C2)

先对C1混合，再对混合后的径向核用C2，可避免sup与积分的错误交换。fixedlambda currentmixed/J overlap≤product_i r(lambda)Ci[1−s+sR_lambda(D_i)]。故任意adaptive s/L、fixedb/y/v的物理overlap上界为

    C0 sqrt(n)b^(−n)Cprod
      [integral G_1(s)dmu
        +n integral_(1/2)^1r(lambda)^n integral G_lambda(s)dmu dλ/λ],
    G_lambda(s)=product_i[1−s+sR_lambda(D_i)].                (C3)

这保留全sourcecost，R178 n∫r^n/λ≤34仍准确适用。

若所有lambda∈[1/2,1]均有average_i R_lambda(D_i)≤1−delta，0<delta≤1，AMGM给G≤(1−delta s)^n≤exp(−n delta s)。以s=sin²theta及sin theta≥2theta/pi可直接界Jeffreys积分≤min{1,2/sqrt(n delta)}。因此C3的无Cprod系数≤35C0 sqrt(n)min{1,2/sqrt(n delta)}，严格deficit得到dimensionfree70C0/sqrt(delta)，critical average≤1得到35C0sqrt(n)。

条件须对全部lambda包括1成立，不可只在actual一个lambda或有限菜单认证后外推。C3是核几何，不是中段CJ/raw付款；variableb、source归一/alpha及squaredenominator义务不因Jeffreys混合消失。候选已先独筛，等待精确稿后审。


## 10. 两篇几何成稿完整后审

已实读 mixed_scale_geometry.md MG1–18（并包括末节全部接口限制）与 extremal_soft_geometry.md ES1–8。与上述作者前独推逐式对照：本次两稿在各自明示范围通过，无待修数学项。

MG6–7 的固定Theta支配、真实adaptive common-L35、单份wt/wg取消及b^(−n)正确；MG13外段/中段方向、lambda1端点、MG17固定lambda<1的DCT和MG18先固定A后D趋无穷的双截断均充分。其质量界未被冒充sourceproduct界，未把lambda<1截断插入共同wb包络。

ES1统一常数2pi e及k0/n延拓正确；ES2径向正测度方向/闭硬面向右版本正确。ES4先用软度概率积分、再用sup_lambda integral≤integral sup_lambda及共同径向包络，因而没有非法交换上确界与积分。ES3卷积先作hard/phi收缩，再与正w_lambda卷积，准确保留r_lambda。ES6系数等于Beta积分，虽有2^n形式展开而未把每项再收费。ES7假设确实覆盖全部lambda（包含1）；ES8的35、2/sqrt(n delta)、70C0/sqrt(delta)与delta0解释均正确。严格亏损消除软度选择sqrt(n)费用，只是明示来源对充分条件下的核结论；没有推出实际中间段全满足该条件。

两篇均仅fixedb物理receiver/source核几何。单份C补偿可由wt/wg≤1/Cprod使用；原CJ平方分母、第二来源、samealpha、et资格、列source积分、窗口与j费用完整保留。没有由本次稿件新增原raw全付款认证。有限数值由另组负责，本审不运行或引用其通过作为一般证明。

当前实算绑定如下（audit自身仍待实际capacity成稿后最终冻结）：

| 文件 | SHA256 |
| --- | --- |
| mixed_scale_geometry.md | 733f23075eedb5cc352de8cd529aa91b6194797c96e0d657926031d52838c387 |
| extremal_soft_geometry.md | e4317e5050c59c0d766a216959ea52529ff648b3ca6cc52f1722626c2c4e99d1 |


## 11. 主LaTeX整合稿核对

已实读当前proof.tex.txt。整合稿忠实保留ES/MG的全部关键范围：C0=2pi e；共同径向正包络；r_lambda收缩和35；准确Beta系数；ES7对全部lambda含1的条件；delta0临界与delta>0的70C0/sqrt(delta)；fixedb、b^(−n)与单份wt/wg补偿。Theta总质量与sourceproduct分开，lambda<1固定远场极限未冒充uniform upper，lambda1的2logD共振未隐藏。最终段明确原中间段按beta/nu/Pit、samealpha和归一分母的积分仍未付，未登记新的raw根阶付款。

数值段将两级求积差明确称非严格误差指标，有限Bernoulli证书不证明实际来源的全lambda条件；这与本独审接受的数学范围一致。脚本迁移结果由父级/数值审计负责，本审未重复运行。

当前proof.tex.txt SHA256：`141b275394028b0830ed9d197a05c347fcae6134b61fd7b48bb27e8292aa1eaa`。等待Astra实际来源容量检查点后统一冻结；不扩展理论。


## 12. 实际共同来源自能量：作者前独立筛查

固定b>0及R^n上的偶概率位移测度W（不要求product），令Hb=h_b^tensor n、Jb=phi_b^tensor n、Kb=Hb*Jb=b^(−n)(h*phi)^tensor n(·/b)。对有限正来源β=ν+ζ，定义EW(σ,τ)=integral(Kb*W)(y−v)σ(dy)τ(dv)，D=E0−EW。候选恒等式独立筛查通过，范围为无权双来源积分。

取l_a(r)=a^(−1)e^(−r/a)1_(r≥0)。有l_a*tilde l_a=e^(−|r|/a)/(2a)，故w=integral_0^1 2a(l_a*tilde l_a)da。tensor时用概率混合pi(da)=product_i2a_i da_i以及g_(a,b)=product_i(h_b*l_(a_i b))。于是Kb=integral g*tildeg dpi。g属于L²；对任意有限质量σ，g*σ亦L²，故所有二次式有限且Tonelli/双线性合法。对正σ，

    D(σ,σ)=1/2 integral W(dz) integral pi(da)
              ||(g*σ)(·+z)−g*σ||²_2 ≥0.

W偶使D的双线性型对称，展开β=ν+ζ即得

    EW(β,ν)−E0(β,ν)
      =D(ζ,ζ)/4−D(ν+ζ/2,ν+ζ/2).

这不是把cross亏损单独称非负：它保留外源ζ自能量的正项。真实物理receiver identity EW(β,ν)=integral(Hb*W*β)(x)(Jb*ν)(x)dx也准确。W可取delta0；此时D0，边界无除法。a0为混合零测度端点，不定义l0且不影响积分。

没有额外把来源概率化；但原fulladaptiveW(x)、wt/wg、rho/alpha、et、原Π不能随之分离。基核是B=h*phi而非C=h*F；C−B的正差额需保留。此无权实际来源恒等式不新增raw付款，不免去fixedb/window/j义务。等待作者正文后审。


## 13. MC全文后审、整合及最终冻结

已完成middle_joint_capacity.md MC1–12及全篇范围后审。MC1–8对全部有限符号测度的正定自相关表示、平移L²差、精确1/4配方和真实dx identity通过；L²界≤b^(−n)使原子/符号输入均合法。MC7平方质量费用不能变成W_beta。MC9–10的C=C_base+正差与所有tensor交叉项保留正确；正差不推出其平移差有符号。

本审捕获并核验两项已落实的原槽身份修订：(i) MC12先保留b_H=∫H1_bad1_(ku<kv)Πdu，普通bad低score后验仅作正上界；(ii) 对全ν定义κ=Juν/QJ时，换密度等式保留1_Zt。κ仅用于实际et>0的行；此时ν非零、J严格正，QJ>0，无除零。两处修订均实读当前正文确认，没有改变原来源或删除历史。bad对倒Ju密度仅给下界方向，未被误用为上界。

已实读主proof.tex.txt新增MC整合节及report对应结论。主tex已用C_base避免与ES常数C0冲突，补齐h_b/H_b/pi定义；b_H、固定偶W、二次来源费用、实际C差和adaptive权重断点均忠实保留。数值追加段只称既有近似核系数上的有限有理代数检查，不认证物理积分或一般原条件。本审未运行数值、Git或编译PDF，未修改任何作者文件。

最终结论：ES、MG及MC在各自明示fixedb核/无权来源范围通过；没有待修项。新全软度共同尺度几何与真实共同来源1/4补偿机制成立，但一般middle原raw/CJ付款仍未闭合。本轮不把这些结构结论登记为新的raw全付款，不把alllambda来源亏损当作已由一般输入保证。所有actualalpha、原Π、平方分母/et资格、variableb和j/window/history费用保留。审计完成后停止，不扩研究。

最终实算SHA256绑定（取代前述中间hash；不包含本文件自指hash）：

| 文件 | SHA256 |
| --- | --- |
| task_contract.md | 20b2a47899ea2619f5cefb566e760b1e9c5e7f6165e4b12ad08217dfc918f814 |
| mixed_scale_geometry.md | 733f23075eedb5cc352de8cd529aa91b6194797c96e0d657926031d52838c387 |
| extremal_soft_geometry.md | e4317e5050c59c0d766a216959ea52529ff648b3ca6cc52f1722626c2c4e99d1 |
| middle_joint_capacity.md | 9d5ffdf82f02e12ff05b4f0f1890c9a157f237f2f40bee31a61997492efffc99 |
| proof.tex.txt | 541837fe4171df582e503c73d5c76ac8d852c7c81c0c4f0ae5e69f0b1edf8464 |
| report.md | d4ba06faa36e5df9645c77d119927a36f1e05e09539b99a1dba1684dad3fbfde |
