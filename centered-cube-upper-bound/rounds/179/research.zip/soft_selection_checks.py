"""Exact finite certificates for ES1/ES6/ES8; no inference to original raw."""
from fractions import Fraction as F
from math import comb
from pathlib import Path
import json
from decimal import Decimal,localcontext
def display(x):
 with localcontext() as c:
  c.prec=18
  return str(Decimal(x.numerator)/Decimal(x.denominator))

def beta(n,k):return F(comb(2*k,k)*comb(2*(n-k),n-k),4**n*comb(n,k))
stages=[]
for ns in ([1,2,4,8],[16,32,64],[128,256,1024]):
 rows=[]
 for n in ns:
  ks=range(n+1) if n<=64 else sorted({0,1,2,n//8,n//4,n//2,3*n//4,7*n//8,n-2,n-1,n})
  cert=[]
  for k in ks:
   peak=F(k,n)**k*F(n-k,n)**(n-k)
   ratio=peak/beta(n,k)
   assert ratio*ratio<=16*n
   cert.append(dict(k=k,ratio_over_sqrt_n_squared=float(ratio*ratio/n),exact_squared_bound_16n=True))
  assert sum(F(comb(n,k))*beta(n,k) for k in range(n+1))==1
  rows.append(dict(n=n,cases=cert,exact_prior_normalization=True))
 stages.append(rows)
vectors=[]
for n in (4,16,64):
 R=[F(3,2)]*(n//2)+[F(1,4)]*(n//2)
 delta=1-sum(R)/n
 es=[F(1)]
 for r in R:
  es.append(F(0))
  for k in range(len(es)-1,0,-1):es[k]+=r*es[k-1]
 integral=sum(es[k]*beta(n,k) for k in range(n+1))
 assert integral<=1 and integral*integral*n*delta<=4
 for j in range(9):
  s=F(j,8);g=F(1)
  for r in R:g*=1-s+s*r
  assert g<=(1-delta*s)**n
 vectors.append(dict(n=n,delta=str(delta),R_description='half 3/2, half 1/4',prior_integral=str(integral),integral_float=float(integral),exact_deficit_squared_bound=True,amgm_rational_points=9))
# Reuse existing physical scalar quadrature only; no new spatial samples.
source_rows=[]
raw=json.loads(Path(__file__).with_name('mixed_kernel_probe.json').read_text())
base={r['D']:r for r in raw['rows'] if r['lambda_value']=='1'}
for n in (1,4,16):
 d0=F(base['0']['hard_overlap'])**n-F(base['0']['soft_overlap'])**n
 for distance in ('1','4','16','64'):
  cross=F(base[distance]['hard_overlap'])**n-F(base[distance]['soft_overlap'])**n
  assert d0>0 and cross<0 and abs(cross)<=d0
  mass=-2*d0/cross
  increment=-d0-mass*cross
  remainder=d0+mass*cross+mass*mass*d0/4
  cap=mass*mass*d0/4
  assert increment==cap-remainder and remainder>=0
  source_rows.append(dict(n=n,D=distance,outer_mass_display=display(mass),increment_display=display(increment),capacity_display=display(cap),identity_exact_for_decimal_coefficients=True,scope='Fixed W=w tensor power; nu=delta0,zeta=mass delta_(D,...,D); coefficients are prior numerical quadrature, not physical interval certificate.'))
out=dict(scope='Exact finite rational checks, not proof that original source pairs satisfy the all-scale deficit condition.',stages=stages,mixed_vectors=vectors,common_source_energy=source_rows)
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(dict(likelihood_checks=sum(len(row['cases']) for stage in stages for row in stage),vector_checks=len(vectors),passed=True)))
