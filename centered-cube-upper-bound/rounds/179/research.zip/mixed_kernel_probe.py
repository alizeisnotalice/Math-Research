#!/usr/bin/env python3
"""R179 fixed 30-point mixed overlap study; empirical quadrature, analytic tails."""
from pathlib import Path
from fractions import Fraction as F
from functools import lru_cache
import json,sys,time,math,hashlib
HERE=Path(__file__).resolve().parent
VENDOR=Path('/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor');sys.path.insert(0,str(VENDOR));import mpmath as mp
LAM=(F(1,2),F(3,4),F(9,10),F(99,100),F(1));DIST=(F(0),F(1,2),F(1),F(4),F(16),F(64));THRESH=mp.mpf('0.000002')
class Budget(Exception):pass
def M(q):q=F(q);return mp.mpf(q.numerator)/q.denominator
def txt(x):return mp.nstr(x,mp.mp.dps)
def e4(x):return mp.mpf(1)/3 if x==0 else mp.expint(4,x)
def C(x):
 d=abs(x)
 if d==0:return mp.mpf(1)
 if d<=1:return 1-d+mp.mpf(1)/3-e4(1)-e4(d)+e4(d+1)
 return e4(d-1)-2*e4(d)+e4(d+1)
def primitive_phi(x):
 if x<0:return -primitive_phi(-x)
 return x-e4(mp.mpf('.5')-x)+e4(mp.mpf('.5')+x) if x<=mp.mpf('.5') else mp.mpf('.5')-e4(x-mp.mpf('.5'))+e4(x+mp.mpf('.5'))
def hard_overlap(lam,x):
 d=abs(x)
 if d>=(1+lam)/2:
  return (e4(d-(1+lam)/2)-e4(d+(lam-1)/2)-e4(d+(1-lam)/2)+e4(d+(1+lam)/2))/lam
 return (primitive_phi(d+lam/2)-primitive_phi(d-lam/2))/lam
@lru_cache(None)
def gauss(N,dps):
 with mp.workdps(dps):
  x,w=mp.gauss_quadrature(N,'legendre');return tuple((mp.sin(mp.pi*x[i]/2),w[i]*mp.pi/2*mp.cos(mp.pi*x[i]/2)) for i in range(N))
def splitpoints(lam,D,B):
 pts={-B,B,mp.mpf(0),D}
 for z in (mp.mpf(1),mp.mpf(4),mp.mpf(16)):
  pts.update([-z,z,D-z,D+z])
 for z in ((1+lam)/2,(1-lam)/2,mp.mpf(1)):
  pts.update([D-z,D+z])
 return sorted(p for p in pts if -B<=p<=B)
def integrate(lam,D,N,dps,deadline):
 with mp.workdps(dps):
  lam=M(lam);D=M(D);cut=D+40;pts=splitpoints(lam,D,cut);nodes=gauss(N,dps);soft=mp.mpf(0);displaced=mp.mpf(0)
  for a,b in zip(pts,pts[1:]):
   if deadline and time.monotonic()>deadline:raise Budget()
   mid=(a+b)/2;half=(b-a)/2
   va=[];vc=[]
   for z,weight in nodes:
    t=mid+half*z;wl=mp.expint(2,abs(t)/lam)/lam;ww=half*weight*wl
    va.append(ww*hard_overlap(lam,D-t));vc.append(ww*C(D-t))
   soft+=mp.fsum(va);displaced+=mp.fsum(vc)
  tail=2*mp.exp(1+D-(1+1/lam)*cut)/(1+lam)
  return dict(soft=+soft,displaced=+displaced,tail=+tail,cut=+cut,segments=len(pts)-1)
def study(lam,D,dps,N0,N1,deadline):
 with mp.workdps(dps):
  low=integrate(lam,D,N0,dps,deadline);high=integrate(lam,D,N1,dps,deadline);ll=M(lam);dd=M(D);cc=C(dd);aa=hard_overlap(ll,dd);bb=high['soft'];ww=high['displaced'];errB=abs(bb-low['soft']);errW=abs(ww-low['displaced']);relative=max(errB/abs(bb),errW/abs(ww));rr=mp.sinh(ll/2)/(ll*mp.sinh(mp.mpf('.5')));eps=1/ll-1
  resonance=mp.log(1+dd) if eps==0 else mp.exp(eps)*(mp.expint(1,eps)-mp.expint(1,eps*(1+dd))) if dd else mp.mpf(0)
  logbound=(9*mp.e/ll)*(1+2*resonance);cutoff=mp.log(1+1/eps)+mp.exp(-1) if eps>0 else None
  ss=[]
  for label,s in [('n4_s0',1-mp.exp(-mp.mpf(1)/4)),('n16_s0',1-mp.exp(-mp.mpf(1)/16)),('upper1',mp.mpf(1))]:
   q=(1-s)*aa+s*bb;den=(1-s)*cc+s*ww
   ss.append(dict(softness_label=label,s=txt(s),q=txt(q),q_over_C=txt(q/cc),compensated_ratio=txt(q/den),r_lambda_minus_ratio=txt(rr-q/den)))
  return dict(lambda_value=str(lam),D=str(D),dps=dps,N=[N0,N1],status='refinement_indicator_met' if relative<=M(F(1,500000)) else 'quadrature_unresolved',C=txt(cc),hard_overlap=txt(aa),hard_over_C=txt(aa/cc),soft_overlap=txt(bb),soft_over_displacement=txt(bb/ww),displacement=txt(ww),R_lambda=txt(ww/cc),r_lambda=txt(rr),hard_compensation_gap=txt(rr-aa/cc),soft_compensation_gap=txt(rr-bb/ww),softness=ss,
   quadrature=dict(low_soft=txt(low['soft']),low_displacement=txt(low['displaced']),high_soft=txt(bb),high_displacement=txt(ww),absolute_refinement_difference_soft=txt(errB),absolute_refinement_difference_displacement=txt(errW),relative_refinement_indicator=txt(relative),relative_target='2e-6',rigorous_error_bound=False,endpoint_transform='t=mid+half*sin(pi*z/2) on each split interval',segments=high['segments']),
   tail=dict(cutoff=txt(high['cut']),absolute_bound_each_integral=txt(high['tail']),relative_to_C_bound=txt(high['tail']/cc),analytic_formula='2 exp(1+D-(1+1/lambda)*B)/(1+lambda), B=D+40',scope='rigorous analytic truncation inequality in exact arithmetic; decimal display is high precision, not directed interval enclosure'),
   log_resonance=dict(epsilon_scale=txt(eps),A=txt(resonance),R_upper=txt(logbound),R_over_upper=txt((ww/cc)/logbound),A_log_distance_upper=txt(mp.log(1+dd)),A_scale_cutoff_upper=txt(cutoff) if cutoff is not None else None,fixed_lambda_far_limit=txt(-mp.log(1-ll*ll)/(ll*ll)) if ll<1 else None,lambda1_R_over_2logD=txt(ww/cc/(2*mp.log(dd))) if ll==1 and dd>1 else None,scope='finite checks of separately proved analytic log upper bound and limits; no fit'))
def main():
 start=time.monotonic();deadline=start+120;mp.mp.dps=30;stages=[]
 stage1=[(l,d) for l in (F(1,2),F(3,4),F(1)) for d in DIST[:3]]
 stage2=[(l,d) for l in (F(1,2),F(3,4),F(1)) for d in DIST[3:5]]+[(l,d) for l in (F(9,10),F(99,100)) for d in DIST[:5]]
 stage3=[(l,F(64)) for l in LAM];rows=[];exhausted=False
 for label,points in [('initial',stage1),('pressure',stage2),('far_resonance',stage3)]:
  for lam,D in points:
   if exhausted:rows.append(dict(stage=label,lambda_value=str(lam),D=str(D),status='not_evaluated_budget'));continue
   try:r=study(lam,D,30,32,64,deadline);r['stage']=label;rows.append(r)
   except Budget:rows.append(dict(stage=label,lambda_value=str(lam),D=str(D),status='not_evaluated_budget'));exhausted=True
 screen=time.monotonic()-start;refinements=[]
 for lam,D in [(F(1),F(64)),(F(99,100),F(64)),(F(1),F(0))]:
  if any(r['lambda_value']==str(lam) and r['D']==str(D) and 'R_lambda'in r for r in rows):
   refinements.append(study(lam,D,50,64,128,None))
 doc=HERE/'task_contract.md';data=dict(scope='Thirty actual one-dimensional mixed overlap points, fixed lambda/D and soft endpoint diagnostics; no source/history/receiver scan, no global-bound certificate.',definitions=dict(q='(1-s)*(h_lambda*phi)(D)+s*(phi_lambda*phi)(D)',soft_identity='phi_lambda*phi=w_lambda*(h_lambda*phi)',C='h*max(h,phi), not a probability kernel',displacement='(w_lambda*C)(D), retained without substitution by C',compensation='q <= r_lambda*((1-s)*C+s*(w_lambda*C))',r_lambda='sinh(lambda/2)/(lambda*sinh(1/2))'),budget=dict(points=30,prescreen_seconds_cap=120,main_N=[32,64],main_dps=30,selected_original_points=3,refinement_N=[64,128],refinement_dps=50),rows=rows,refinements=refinements,
  analytic_tail_derivation='For |t|>B>D+1, w_lambda(t)<=lambda^-1 exp(-|t|/lambda), and both C(D-t), (h_lambda*phi)(D-t)<=exp(1+D-|t|). Integrating both tails gives the stated bound.',
  far_distance=dict(lambda_less_than_1='R_lambda(D) -> -log(1-lambda^2)/lambda^2 for each fixed lambda<1; not uniform near1',lambda_equals_1='R_1(D)/(2log D) ->1',source='separate analytic argument by geometry author, not inferred by fitting these samples',tails='D exp(D) w(D)->1; D exp(D) C(D)->(2sinh(1/2))^2'),
  local_inputs={doc.name:hashlib.sha256(doc.read_bytes()).hexdigest()},dependencies=dict(mpmath_vendor=str(VENDOR),mpmath_version=mp.__version__,mpmath_entry_file=mp.__file__,mpmath_entry_sha256=hashlib.sha256(Path(mp.__file__).read_bytes()).hexdigest(),runtime='analytic E2/E4 kernels, no scipy or new software'),limitations=['Composite Gauss differences are empirical resolution indicators, not rigorous quadrature error bounds.','The analytic tail inequality is rigorous but no directed arithmetic certificate for its printed decimals is claimed.','Unresolved or budget-limited points remain explicit; no adaptive parameter expansion.','Uniform compensation/log theorems are authored and audited analytically, not certified by this finite sample.','Soft displacement and its scale resonance remain in all denominators.'],runtime=dict(prescreen_seconds=round(screen,3),total_seconds=round(time.monotonic()-start,3),python=sys.version))
 (HERE/'mixed_kernel_probe.json').write_text(json.dumps(data,indent=2)+'\n');print(json.dumps(dict(statuses={s:sum(r['status']==s for r in rows) for s in set(r['status'] for r in rows)},R=[dict(lambda_value=r['lambda_value'],D=r['D'],R=r.get('R_lambda'),indicator=r.get('quadrature',{}).get('relative_refinement_indicator')) for r in rows],refinements=[dict(lambda_value=r['lambda_value'],D=r['D'],R=r['R_lambda'],status=r['status'],indicator=r['quadrature']['relative_refinement_indicator']) for r in refinements],runtime=data['runtime']),indent=2))
if __name__=='__main__':main()
