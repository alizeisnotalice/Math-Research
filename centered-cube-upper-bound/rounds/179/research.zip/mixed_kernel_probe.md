# R179 mixed physical overlap and scale resonance

The finite study supports retaining the actual soft displacement w_lambda*C. It does not support replacing the mixed overlap by an absolute multiple of C uniformly in distance. The compensated inequality survives every sampled point, while the unshifted ratio grows with the equal-scale resonance. These numerical observations do not certify the analytic uniform bound.

Run `python3 mixed_kernel_probe.py` from any directory. It writes `mixed_kernel_probe.json` beside the script. The only numerical library is the existing vendor mpmath1.3.0, whose path/version/entry hash are recorded. All kernels use analytic exponential-integral formulas; no new software or source/history search is used. The local contract hash is retained.

## Actual kernels and three fixed stages

With h_lambda normalized to integral1, w_lambda(x)=lambda^-1 w(x/lambda), and phi_lambda=h_lambda*w_lambda, compute

`A_lambda=h_lambda*phi`,
`B_lambda=phi_lambda*phi=w_lambda*A_lambda`,
`W_lambda=w_lambda*C`,
`q_lambda,s=(1-s)A_lambda+s B_lambda`.

Here C=h*max(h,phi), not a probability kernel. The exact soft displacement W_lambda is never dropped. The candidate comparison is

`q_lambda,s <= r_lambda*((1-s)C+s W_lambda)`,
`r_lambda=sinh(lambda/2)/(lambda*sinh(1/2)) <=1`.

The geometry author supplied this precise strategy before execution. The30 parameter pairs are lambda in{.5,.75,.9,.99,1} and D in{0,.5,1,4,16,64}:

1. Nine initial points use lambda=.5,.75,1 and D=0,.5,1.
2. Sixteen pressure points fill D=4,16 for these three scales, and D<=16 for lambda=.9,.99.
3. Five far-distance points use D=64 for all five scales. Only the original points(1,64),(.99,64),(1,0) receive higher precision/resolution checks.

At each point, evaluate s=1-exp(-1/4), 1-exp(-1/16), and1. Since the numerator and compensated denominator are affine in s, their ratio is fractional linear; its extrema on any legal soft interval occur at its endpoints. These few soft values diagnose the intended n4/n16 lower endpoints without a softness scan. A/C and B/W separately retain the stronger hard/soft compensation comparison.

## Computation and error scope

A_lambda is a compact average of phi evaluated analytically with E4. For large distance, the implementation subtracts E4 values directly instead of subtracting two primitives close to1/2. This prevents loss from the constant primitive term. C uses its existing analytic E4 formula, with C(0)=1.

B_lambda and W_lambda share one-dimensional displacement quadrature. Split at t=0, physical kernel faces near D, and fixed tail landmarks. On each segment, composite Gauss-Legendre nodes use t=mid+half*sin(pi*z/2), flattening both endpoints. Main calculations use32/64 nodes per segment at30 decimal digits; three selected checks use64/128 at50 digits. No adaptive parameter or source search occurs.

For Bcut=D+40, both omitted tails have the analytic absolute bound

`2 exp(1+D-(1+1/lambda)*Bcut)/(1+lambda)`.

Indeed w_lambda(t)<=lambda^-1 exp(-|t|/lambda), and for |t|>Bcut both C(D-t) and A_lambda(D-t) are at most exp(1+D-|t|). This truncation inequality is rigorous in exact arithmetic. Its printed decimal evaluation is high precision, not a directed interval certificate. All tail/C evaluations are below2.98e-33.

The32/64 relative differences are at most1.216e-10, below the predefined2e-6 indicator target. The three64/128 checks have relative differences at most2.45e-13. These differences are empirical resolution indicators, not rigorous quadrature error bounds. Every point is labeled accordingly in JSON; none is called an interval certificate. Runtime of the first production run was11.885s main screening and16.505s overall, within the120s screen cap.

## Observations and analytic limits

The observed displacement ratios R_lambda=W_lambda/C are:

|lambda|D0|D.5|D1|D4|D16|D64|
|---|---:|---:|---:|---:|---:|---:|
|.5|.765109|.919378|1.507202|1.271637|1.173994|1.156444|
|.75|.669376|.845786|1.596873|1.945026|1.604366|1.496237|
|.9|.622001|.803310|1.610893|2.624351|2.759906|2.174713|
|.99|.596615|.779097|1.610088|3.115196|5.162025|6.204618|
|1|.593922|.776471|1.609662|3.172929|5.607687|8.443204|

All sampled A/C and B/W are at most the candidate r_lambda to the reported resolution. In particular at lambda1,D64, B/C≈7.9468633 while B/W≈.9412142. Retaining W gives compensation; suppressing the displacement would conceal a substantial coordinate cost.

Separately from the numerics, the geometry author derives, for epsilon_scale=1/lambda-1,

`R_lambda(D) <= (9e/lambda)*(1+2 A(D,epsilon_scale))`,
`A(D,epsilon_scale)=integral_0^D exp(-epsilon_scale*r)/(1+r) dr`,

with A<=log(1+D), and for lambda<1 also A<=log(1+1/epsilon_scale)+exp(-1). The script evaluates this actual integral via E1, and retains both distance and scale-cutoff bounds. The largest observed R/upper is approximately.036917, so the proposed constant is deliberately conservative; this experiment does not optimize it.

The far-distance assertions are analytic inputs, not fitted to the table:

- For each fixed lambda<1, R_lambda tends to -log(1-lambda^2)/lambda^2.
- For lambda1, R_1(D)/(2log D) tends to1.

The selected50-digit D64 ratio for lambda1 is1.01508071169. The fixed-lambda limit is not a global maximum: lambda.99 gives R(64)≈6.204618, above its eventual limit3.996567; lambda.9 gives R(16)≈2.759906, above its limit2.050285. The finite peak/resonance and nonuniform lambda->1 transition must remain in any budget. No global supremum or asymptotic exponent is inferred from D64.

The usable mechanism is the compensated, displaced kernel with a retained logarithmic distance/scale cost. The full adaptive tensor estimate still carries its per-coordinate source factors and total mixture mass. This scalar study neither pays those products nor integrates the original denominator, alpha, Pi, source/history or receiver masks.

## Reproduction review

Copied the final script and unchanged task contract to `/tmp/r179_mixed_review/` and ran independently. Every JSON field except runtime matches exactly, including all30 points, three high-precision refinements, analytic tail displays and dependency/contract hashes. Also checked the structural A_1=C identity at every sampled D>=1, and nonnegative hard/soft compensation gaps. These checks add no points and do not convert empirical quadrature differences into certified error bounds. Final production runtime: 12.436s main, 17.282s overall.
