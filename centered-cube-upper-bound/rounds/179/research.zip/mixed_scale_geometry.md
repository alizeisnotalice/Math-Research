# R179：mixed 自适应尺度的正位移包络及真实来源补偿

本稿只研究原 mixed receiver/J 的几何，不重复 shared-alpha 来源容量主线。已读 R179 合同、冻结 R178 source_overlap_identity SO2–8/SO18；准确命题先发父级与独审。这里得到新的全 mixed、共同自适应 s,L 的 source-weighted 列积分；明确列出位移总质量和逐坐标补偿，不称其已支付原 fractional raw。只写本文件，不 Git/spawn/PDF。

## MG1. 范围与唯一借用的 hard 工具

h=1[-1/2,1/2]，w(r)=∫₀¹exp(−|r|/a)da，φ=h*w，F=max(h,φ)，C=h*F。积分 a 为 dummy。h,w,φ 质量1；F,C 不归一，∫C>1。记 h_L,w_L,φ_L 为对应概率密度的物理 dilation，b_{s,L}=(1−s)h_L+sφ_L，P_{s,L}=∏b_{s,L}，J_b(z)=b^(−n)∏φ(zᵢ/b)。

固定 b>0 和真实来源中心 y,v。在整次 dx 积分中允许任意共同 measurable L(x)∈[b/2,b]、s(x)∈[0,sbar]，其中 sbar∈[0,1] 是预定上界。原 sources 无概率化、无坐标独立假设。原 b 若随 x 变化须另付费用，本稿不免费冻结它。

借用已证 R178 hard 工具：对任意中心 z,v 及任意 measurable L(x)∈[b/2,b]，

\[
\int h_{L(x)}^{\otimes n}(x-z)J_b(x-v)dx
\le35b^{-n}\prod_i C((z_i-v_i)/b).
\tag{MG1}
\]

它已经通过真实 common-radius layer-cake 支付尺度选择，而非 sup∫ 换 ∫sup。其一维根源为 h_λ*φ≤r(λ)C，r(λ)=sinh(λ/2)/(λsinh(1/2))≤exp[−(1−λ)/17]，λ∈[1/2,1]。本稿不在 soft 情形直接宣称同一 C 上界。

## MG2. 对所有自适应参数共同的正位移测度

准确卷积为

\[
b_{s,L}=h_L*W_{s,L},\qquad
W_{s,L}=(1-s)\delta_0+s w_L(z)dz.
\tag{MG2}
\]

因 w 偶递减、L=λb 且 λ≥1/2，有 w_L(z)=λ^(−1)b^(−1)w(z/(λb))≤2w_b(z)。因此对全部 x，

\[
W_{s(x),L(x)}\le\Theta_b:=\delta_0+2\bar s\,w_b(z)dz.
\tag{MG3}
\]

Theta 是固定于 x 的正测度，质量1+2sbar，不能免费叫作概率。逐 x 的 n 维乘积支配可由准确正 telescope 给出：

\[
\Theta_b^{\otimes n}-W^{\otimes n}
=\sum_{i=1}^n W^{\otimes(i-1)}\otimes(\Theta_b-W)
\otimes\Theta_b^{\otimes(n-i)}\ge0.
\tag{MG4}
\]

故 h_{L(x)}^⊗n*Theta_b^⊗n=P_{s(x),L(x)} 加上明确的非负余测度卷积。这里没有把 x-dependent W 误移出 dx：移出的是更大的、实际已计质量的固定 Theta。

## MG3. full mixed adaptive overlap 的新来源加权定理

令 D_i=(y_i−v_i)/b，定义完全由原物理核给出的来源因子

\[
R(D):={(w*C)(D)\over C(D)}>0,\qquad
\mathfrak D_{\bar s}(D_1,\ldots,D_n)
=\prod_i[1+2\bar s R(D_i)].
\tag{MG5}
\]

C 严格正，故无零分母。这不是待假设的 posterior moment 或来源概率参数；每个 D 的函数由一维核准确积分给定。

**定理。** 对 MG1 的所有共同自适应 s(x),L(x)，

\[
\boxed{\int P_{s(x),L(x)}(x-y)J_b(x-v)dx
\le35b^{-n}\prod_i[C(D_i)+2\bar s(w*C)(D_i)].}
\tag{MG6}
\]

证明：MG3–4 点态给 p_y≤∫Theta_b^⊗n(dz)h_{L(x)}^⊗n(x−y−z)。Tonelli 后对每个固定 z 以中心 y+z 使用 MG1。即使 L 原本依赖 y 或其他来源，本次固定这些参数后，x↦L(x) 仍是 MG1 允许的任意 selector，毋须重选 L。再对 z 的固定产品正测度作积分，准确给每坐标 C+2sbar(w*C)。b^(−n) 来自 J/receiver overlap；没有漏一个 b，也没有 binomial 菜单或 soft 网格。

原阈值 wt=∏min(1,C_i/ξ_t)，wg=∏min(1,C_i/ξ_g)，0<ξ_t,ξ_g≤1；允许 ξ_g 依 x。固定 b,y,v 时 C_i=C(D_i) 独立 x，逐坐标 C_i wt_i/wg_i≤max(C_i,ξ_g)≤1。因此同一个真实 fullmixed 列积分还给

\[
\boxed{\int p_yJ_b(x-v){w_t(y,v)\over w_g(y,v)}dx
\le35b^{-n}\mathfrak D_{\bar s}(D).}
\tag{MG7}
\]

等价地，将左端除以固定于 x 的实际来源补偿 mathfrak D 后，列积分≤35b^(−n)。所有额外 [0,1] 原门只减小左端；没有将这些门所含的非线性密度一起删除。它准确付一份 w_g 分母，不付 w_g² 或 Q_v 分母。MG6–7 是一般物理来源中心的全 mixed 定理，不要求特殊输入、原子或乘积来源。

## MG4. 所有位移与 source-product 费用

辅助位移测度质量为

\[
\|\Theta_b^{\otimes n}\|=(1+2\bar s)^n\le e^{2n\bar s}.
\tag{MG8}
\]

因 C≤1 且 w 是质量1的概率密度，w*C≤1，MG6 另给实际不带阈值分母的 fullmixed overlap≤35b^(−n)(1+2sbar)^n；若 n sbar≤c，则此真实列积分≤35e^(2c)b^(−n)。这是一个已付的小总软度子范围。与此同时，位移质量≤e^(2c)并不推出带一份 w_g 分母时的 mathfrak D 一致有界；远来源的 R(D_i) 仍可增长。对于一般 sbar=1，(1+2sbar)^n=3^n；不能将这项和 MG5 的逐坐标 product 成本称为根阶或 polylog。C 本身未归一，故位移质量有界也不自动给原 source/receiver 总预算。

若确知整个 receiver 子集的 s(x)∈[sunder,sbar]，可用更锐固定测度 (1−sunder)δ₀+2sbar w_b dz，MG6 的每坐标因子改为 (1−sunder)C+2sbar(w*C)，质量改为 (1−sunder+2sbar)^n；证明完全相同。sunder=sbar=0 时准确退化为原 hard35。这里如按多个 s 区间分别应用，必须保留真实区间数及来源分割费，不能逐区间同收一次35后忘记求和。

## MG5. w、C 的完全初等尾比较

以下给 MG5 sourcecost 的明确距离几何，而非只留下一个形式卷积。置 ψ(D)=e^(−|D|)/(1+|D|)。对 D≥0 作 a=1/(1+t) 变换：

\[
w(D)=e^{-D}\int_0^\infty{e^{-Dt}\over(1+t)^2}dt.
\tag{MG9}
\]

下界用 (1+t)^(−2)≥e^(−2t)，给 w≥e^(−D)/(D+2)≥ψ/2。上界分部得 I(D)=1−D∫₀∞e^(−Dt)/(1+t)dt；因 (1+t)^(−1)≥e^(−t)，得 I≤1/(1+D)。D=0 直接成立。所以

\[
\tfrac12\psi\le w\le\psi.
\tag{MG10}
\]

对 |z|≤1/2，ψ(D−z)≤(1+|z|)e^|z|ψ(D)≤αψ(D)，α=(3/2)e^(1/2)。故 φ=h*w≤αψ。在 |D|≤1/2，F=1≤αψ；在外 F=φ≤αψ。因此 C=h*F≤α²ψ=(9e/4)ψ。

下界：F≥w，因为 inside 1≥w，而 outside |D|≥1/2 时 w 在平均区间的正半轴凸，φ=h*w≥w。故 C≥φ；在 |D|≥1/2 时 C≥φ≥w。在 |D|≤1/2，C≥h*h=1−|D|≥1/2≥w/2。结合 MG10，得到

\[
\boxed{\tfrac14\psi(D)\le C(D)\le\tfrac{9e}{4}\psi(D).}
\tag{MG11}
\]

所有常数仅作保守解析界；并不将每坐标 9e 或其乘积隐藏在 O(1)。

## MG6. 有限距离、近等尺度的共振界

对 fixed λ∈[1/2,1]，记

\[
R_\lambda(D)={(w_\lambda*C)(D)\over C(D)},\quad
\epsilon_\lambda=\lambda^{-1}-1,\quad
A(D,\epsilon)=\int_0^{|D|}{e^{-\epsilon r}\over1+r}dr.
\tag{MG12}
\]

自证的全域有限界是

\[
\boxed{R_\lambda(D)\le{9e\over\lambda}
[1+2A(D,\epsilon_\lambda)].}
\tag{MG13}
\]

证明可用偶性取 D≥0。MG10 给 w_λ(r)≤λ^(−1)e^(−|r|/λ)/(1+|r|)，MG11 给 C(D−r)≤(9e/4)e^(−|D−r|)/(1+|D−r|)。所需积分在 r<0 和 r>D 两段总计≤ψ(D)，因为每段积分≤ψ(D)/(1+λ^(−1))≤ψ(D)/2。

在 0≤r≤D，用准确分式

1/[(1+r)(1+D−r)]=[1/(1+r)+1/(1+D−r)]/(D+2)。

乘 e^(−epsilon r) 后，第二项积分≤第一项 A(D,epsilon)：在 [0,D/2] 将 r 与 D−r 配对，差为两个同号非负因子的乘积。故中段≤2ψ(D)A。除以 C(D)≥ψ(D)/4，即得 MG13。

另外 A≤log(1+|D|)。当 epsilon>0 时，若 |D|≥1/epsilon，将积分在 1/epsilon 分开；后段以分母≥r 估计，给≤∫₁∞e^(−u)/u du≤e^(−1)。若 |D| 较小只需第一段。因此

\[
A(D,\epsilon)\le\min\{\log(1+|D|),\,
\log(1+1/\epsilon)+e^{-1}\}\quad(\epsilon>0).
\tag{MG14}
\]

λ=1 时 epsilon=0，A=log(1+|D|)。所以 MG5 中真实 R=R₁满足 R(D)≤9e[1+2log(1+|D|)]；这只是显式 sourceproduct 上界，不能把 n 个 logarithm 乘积当作 polylog(n)。

R178 的精确 fixedscale 比较则保留更锐的费用：

\[
{(b_{s,\lambda}*\phi)(D)\over C(D)}
\le r(\lambda)[(1-s)+sR_\lambda(D)].
\tag{MG15}
\]

MG13–15 同时保留 r(λ) 的收缩、distance logarithm 和 λ接近1的截断；它不是证明自适应时可以把 w_{λ(x)} 移出 dx。自适应定理的合法性仍由 MG3 的固定正位移包络支付；该固定包络使用 w_b，所以主定理的 sourcecost 是 R₁，不能免费用实际 lambda(x)<1 的 R_lambda 截断替代它。

## MG7. 共振确实存在：两个准确远场极限

这些极限说明显式 sourcecost 不能一般删去。由 MG9 作 u=Dt 并以 e^(−u)支配，

D e^D w(D)→1。

再对两个紧区间卷积作支配收敛，D e^D φ(D)→2sinh(1/2)，而 D>1 时 C(D)=h*φ(D)，所以

\[
D e^D C(D)\longrightarrow\kappa:=[2\sinh(1/2)]^2.
\tag{MG16}
\]

固定 λ<1 时，C(D−r)/C(D)→e^r。MG11 给其≤9e e^|r|(1+|r|)，这与 w_λ(r) 的乘积可积（严格指数余量 λ^(−1)−1>0），故支配收敛及非负 Tonelli 给

\[
\boxed{\lim_{|D|\to\infty}R_\lambda(D)
=\int e^r w_\lambda(r)dr
=\int_0^1{2a\over1-a^2\lambda^2}da
={-\log(1-\lambda^2)\over\lambda^2}.}
\tag{MG17}
\]

λ=1 的极限不同：

\[
\boxed{R_1(D)/(2\log|D|)\longrightarrow1.}
\tag{MG18}
\]

自证方法如下。给定小 ε>0，取足够大 A，使 r≥A 时 w(r)/(e^(−r)/r)及 C(r)/(κe^(−r)/r)均在1±ε内。对 D>2A，中段 [A,D−A] 的卷积夹在 κ(1±ε)²e^(−D)∫_A^{D−A}dr/[r(D−r)]，该准确积分为 (2/D)log((D−A)/A)。两端 [0,A]、[D−A,D] 除以 C(D) 的贡献对固定 A 有界，由 MG10–11 直接支配；外段 r<0、r>D 除以 C(D) 亦有统一有限界（指数 e^(−|r|) 或 e^(−(r−D)) 足够）。故除以2log D，先 D→∞再 ε→0即得。没有用拟合指数；λ1 的距离共振与 λ<1 的尺度共振均是实际物理核性质。

## MG8. 与原 score/lowoverflow、source 容量的准确接口

MG6–7 可保留任何原 [0,1] lowoverflow、score、good、history、唯一 j 门作正上界；但若这些门本身带 signed 或 unbounded 密度，不可一起删除。R177 的 latent soft 标签仍可在原 current-f 联合测度中整体 Tonelli，不需枚举 exceptional 坐标领取 binomial 菜单。物理 m<k 不推出 latent软标签数<k，故本稿没有靠这一错误反向蕴含限制 mixed 部分。

MG7 保留了真实 C_i 和原 wt/wg 的一份价格，可与原 score/time 机制继续结合，而不是先将 k_v或时间替成 n、log2。fixed (omega,V,j,y,t) 的 nu、Z_t、wt、et、Pi_t 独立 x，在正支配 receiver 门之后可以移外；Pi_g、wg、s,L、A、alpha及 receiver gates仍依x。原 EF10 精确回代后仍有 ρ²wg·wt(y,u)/(9Q_v²et²)，以及 baseline/growth 密度或第二份 p_y；MG7 没有支付它们。实际 bad来源及 same-alpha储备不能另选，原 beta/nu密度也不能各改成质量1。

若将 MG6 与真实固定正来源测度 Tonelli，必须保留右端 mathfrak D 的来源积分和 b^(−n)。若 b=b(x)、window/history随列变化，须另给共同 envelope或真实菜单费；不能仅由逐fixedb界取消 unique-j的不同归一列价。这里没有替这些费用领 W_beta预算，也没有将 C/F或其补偿因子概率化。

本轮新结果是对所有共同adaptive s,L的 MG6–7，构造是固定正位移包络+已付hard35，sourcecost由 MG5/MG8和 MG13–18完全显示。一般剩余 middle、原fractionalraw和 sharedalpha联合容量未闭合；sourceproduct成本不能被声明为无害。完成本有限几何命题后停止并交独审，不另作反例搜索或整套全局覆盖。
