# R179：共同来源能量与原中间带的容量接缝

状态：原 middle band 的一般付款仍未完成。本稿证明一个含实际接收积分、对全部有限正来源成立的混合能量比较；它把外来源 β 与内来源 ν 不同造成的能量增长，精确限制为实际剩余来源 ζ=β−ν 的四分之一 Dirichlet 能量。它没有把原三点 traffic 换成该无权能量，也没有新增已付 raw 分支。下面给出两者之间首次不能合法跨过的步骤及其明确费用。

## 1. 固定参数的准确命题

固定维数 n≥1、一个原窗口尺度 b>0。记一维 h=1_{[-1/2,1/2]}、w(r)=∫₀¹exp(−|r|/a)da、φ=h*w，并令

\[
C_0=h*\varphi=h*h*w,\qquad
H_b(x)=b^{-n}\prod_i h(x_i/b),\qquad
J_b(x)=b^{-n}\prod_i\varphi(x_i/b),
\]
\[
K_b=H_b*J_b=b^{-n}\prod_i C_0(x_i/b).
\tag{MC1}
\]

这里 C₀ 与原阈值 C=h*max(h,φ) 不同。H_b、J_b、K_b 都是概率核。令 W 为 Rⁿ 上任意**固定偶概率测度**，不要求坐标独立。允许实际物理软位移 W=⊗ᵢ[(1−s)δ₀+s w_{λb}(r_i)dr_i]，其中 s∈[0,1]、λ>0 固定；也允许这些 W 的固定正概率混合。

取同一原 V 上的有限正测度 ν≤β，ζ=β−ν。对有限实符号测度 σ、τ 定义

\[
E_W(\sigma,\tau)=\iint(K_b*W)(y-v)\,\sigma(dy)\tau(dv),
\quad E_0=E_{\delta_0},\quad D_W=E_0-E_W.
\tag{MC2}
\]

则 D_W 为对称半正定双线性型，且

\[
\boxed{
E_W(\beta,\nu)-E_0(\beta,\nu)
=\tfrac14D_W(\zeta,\zeta)
-D_W(\nu+\zeta/2,\nu+\zeta/2)
\le\tfrac14D_W(\zeta,\zeta).}
\tag{MC3}
\]

这不是独立选择两个来源的概率模型。β、ν、ζ 均为原实际来源，质量不归一化；ν 外槽已经包含在左边。当 β=ν 时右侧非正，得到完整同来源的能量收缩。

## 2. 初等自相关证明与全部常数

对 a∈(0,1]，令 ℓ_a(r)=a⁻¹exp(−r/a)1_{r≥0}。直接积分得

\[
(\ell_a*\widetilde\ell_a)(r)=(2a)^{-1}e^{-|r|/a},
\quad
w=\int_0^1 2a(\ell_a*\widetilde\ell_a)\,da.
\tag{MC4}
\]

令 π(da)=∏ᵢ2aᵢdaᵢ，为 (0,1]ⁿ 上概率测度，并令

\[
g_{a,b}(x)=\prod_i(h_b*\ell_{a_i b})(x_i),
\qquad h_b(r)=b^{-1}h(r/b).
\]

由卷积和 Tonelli，

\[
K_b=\int g_{a,b}*\widetilde g_{a,b}\,\pi(da),
\qquad \|g_{a,b}\|_2^2\le b^{-n}.
\tag{MC5}
\]

最后一个界只用 ℓ_{aᵢb} 为概率密度和一维 Jensen。因此有限符号来源满足
\(\|g_{a,b}*\sigma\|_2\le b^{-n/2}\|\sigma\|_{TV}\)，以下积分均有限，允许原子来源而无需正则化。记 f_{a,σ}=g_{a,b}*σ，则

\[
E_0(\sigma,\tau)=\int\langle f_{a,\sigma},f_{a,\tau}\rangle\,\pi(da),
\quad
E_W(\sigma,\tau)=\int\langle f_{a,\sigma},W*f_{a,\tau}\rangle\,\pi(da).
\]

W 偶使该双线性型对称。平移保持 L² 范数，故

\[
D_W(\sigma,\sigma)
=\frac12\int\pi(da)\int W(dz)
\|f_{a,\sigma}(\cdot+z)-f_{a,\sigma}\|_2^2\ge0.
\tag{MC6}
\]

此式没有维度常数，也没有使用 Fourier 外部定理。将 β=ν+ζ 代入，
\(-D_W(β,ν)=-D_W(ν,ν)-D_W(ζ,ν)\)；完成平方即 MC3。证明结束。

对实际正 ζ，还可量化

\[
0\le D_W(\zeta,\zeta)\le E_0(\zeta,\zeta)
\le b^{-n}\|\zeta\|^2.
\tag{MC7}
\]

中间一步使用 K_b*W≥0，最后一步使用 MC5。这仍是平方质量费用；没有证据将它换成 W_β，或把每个 V 的该费用归入一个可相加的 q 储备。

## 3. 真实 dx 意义与原 C 的准确差额

MC3 的左边确实含整个接收空间积分，而非先对来源取上确界。准确地，

\[
E_W(\beta,\nu)
=\int_{\mathbb R^n}(H_b*W*\beta)(x)(J_b*\nu)(x)\,dx.
\tag{MC8}
\]

该式来自固定核的 Tonelli 和偶性。因此 MC3 控制固定 hard 通道加入真实软位移后，与同一来源 J 通道的平均重叠增长。远位移处逐点比值大于一，并不妨碍这个共同来源比较；补偿来自 MC6 的同一来源平移差。

原阈值却是 C=h*max(h,φ)。因为 0≤φ≤1，令

\[
B=h(1-\varphi),\qquad R=h*B,\qquad C=C_0+R,
\quad R\ge0,\quad\operatorname{supp}R\subset[-1,1].
\tag{MC9}
\]

令 \(\widehat K_b=b^{-n}\prod_i C(x_i/b)\)，\(\mathcal R_b=\widehat K_b-K_b\ge0\)。它保留所有坐标交叉项，不逐坐标取最坏值。若以 E^R_W 表示将 MC2 的 K_b 换成 \(\mathcal R_b\)，则准确有

\[
E^{\widehat K}_W(\beta,\nu)-E^{\widehat K}_0(\beta,\nu)
\le \tfrac14D_W(\zeta,\zeta)
+E^R_W(\beta,\nu)-E^R_0(\beta,\nu).
\tag{MC10}
\]

最后的差不能因 R≥0 而宣布非正。未证明 R 或 \(\mathcal R_b\) 对任意 W 有 MC6 型收缩。其总质量准确为 (1+∫B)ⁿ−1，但本稿不按该质量粗放费用，也不将它称为一般问题的下界。MC10 保留的是明确物理正核差，尚无来源线性付款。

## 4. 原 middle traffic 到该能量的首次断点

沿用 R175 CJ1 的门 H∈[0,1]，并进一步限制
\(m_0<m_L(x,y)<k_\delta(n,s)\)。H 保留原 high、唯一 j、history、R_η、两槽原支持和低 score 指示。原 bad 集单列为 \(\mathsf B_y\)。固定 t 的 Π 不依 x；但 Π_g、s,L、ρ、Q、α 和终端门仍依 x。实际 companion 的原测度密度是

\[
\mathcal M(x,y,v,u,t)
=H\,1_{\mathsf B_y}(u)
\frac{p_y^2\rho_v^2J_v}{9Q_v^2}
\frac{w_t(y,v)w_t(y,u)}{e_t(y)^2},
\tag{MC11}
\]

对原 \(\mathbb E\sum_{V,j}dx\,β(dy)ν(dv)ν(du)dt/t\) 积分。这里没有省去 α；ρ 正是原同 α 的残余函数。

若首先对 u 的真实 bad 槽积分，必须保留其全部门。准确定义
\(b_H(x,y,v,t)=\int H(x,y,v,u,t)1_{\mathsf B_y}(u)1_{k_t(u)<k_t(v)}\,\Pi_{y,t}(du)\)。H 已含低 score 门时额外指示不改变该量。第二来源槽的精确系数成为

\[
\frac{p_y^2\rho_y(v)^2J_v}{9Q_v^2}
\frac{w_t(y,v)}{e_t(y)}
b_H(x,y,v,t),
\tag{MC12}
\]

其中 \(0\le b_H\le\Pi_{y,t}\{u\in\mathsf B_y:k_t(u)<k_t(v)\}\) 只是正上界，不能当作等式删除 u 相关 history。此系数依赖 y、v 的联合位置和同一原 α_y。即使固定 t 的 Π 可与 dx 换序，它也不是 MC8 中一个与 v 无关的外来源乘子。把它并入“新的 β”会得到依赖 v、x、t 的测度；对这样的对象，MC6 的同一 f_{a,σ} 平移平方恒等式已不能应用。这是本次尝试最早未获证明的步骤，而非已经获得的加权收缩。

此外，若 W 改为随接收点 x 选择的 W_x，MC8 的核不再是一个固定偶卷积算子，MC6 同样不能直接应用。父稿的正参数包络可另付其明确选择费用；本稿没有借 MC3 抹去这些费用。原 p 的 hard 基准尺度为 L，MC8 的基准为 b，本稿也未免费完成这种不同尺度转换。

第二个 bad 来源不能凭其 bad 标签改成另一个 J 权重。精确换密度 \(κ_x(du)=J_uν(du)/Q_J\) 后，有
\(Π_t(du)=(Q_J/e_t)1_{Z_t}(u)(w_t(y,u)/J_u)κ_x(du)\)。bad 关系给 \(J_u\le3p_yw_g(y,u)/K\)，这是 w_t/J_u 的下界方向，不能提供所需上界。因此对向来源的三核重叠，即便具有两个 C 因子，也不能自动替代 MC11；仍须支付这个实际倒 J_u 密度。原 same-α 捕获的是 K0_u，并非 J_u。

## 5. 本轮费用与下一步的准确位置

MC3 适用于任意固定 V、固定 b 和固定 W，及其固定正概率混合，无 n、时间或 j 因子。它同时包含 ν 外槽和 ζ 外槽。逐 V 或逐 j 相加只是把左右两边全部相加，不使平方来源费用变为 W_β；原 j 指示或 history 不能借此删除。原 α、e_t、τ、μ 没有被更换或分别取上确界，本稿没有使用其 subprobability 质量冒充列界。

真正值得保留的下一步机制是 MC6 的平移差补偿：若能从同一原 ρ/α、high/FIRST 和 bad 槽，构造一个保留 MC11 的共同来源双线性分解，则可尝试用该差补偿远来源的重叠增长。所需构造必须同时控制 (i) MC12 的 y–v 联合权重造成的交换差，(ii) MC10 的实际 C−C₀ 差额，(iii) 自适应参数选择费；当前三项均未被原储备恒等式支付。仅假设其中某个矩很小不构成新结论。

若最终证明原 middle companion ≤B_n W_β，原已付 EJ 才给
\((32Λ/3)\sqrt{nB_n/(2K)}W_β\)。本稿没有证明这个前提，也没有获得可额外领取的 ε∫q 接收价。R178 sparse、R177 overflow tail 和其他既付分支不变，middle 一般预算保持未付。本轮在此有界检查点停止，不扩展反例搜索。
