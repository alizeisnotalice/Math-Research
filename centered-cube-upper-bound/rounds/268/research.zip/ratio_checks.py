#!/usr/bin/env python3
"""R268 finite ratio price sums; ordinary mp, small exact geometry checks."""
import argparse,hashlib,json
from pathlib import Path
from fractions import Fraction as F
import mpmath as mp

def enc(x):return mp.nstr(x,100)
def mm(f):
 f=F(f);return mp.mpf(f.numerator)/f.denominator

def run(dps):
 with mp.workdps(dps):
  rows=[];directchecks=0
  for n in [1,2,8,16,64,256,512,1024,4096,10**6,10**9,10**12]:
   lg=mp.log1p(mp.mpf(1)/n);h=n*lg;logfactor=n*mp.log1p(1/(8*mp.sqrt(n)));turn=logfactor/(2*h);sat=min(n+2,int(mp.floor(turn))+1);remaining=n+2-sat
   for pp in ['2','3/2']:
    p=mm(pp);qlog=-2*h*p
    tail=mp.exp(p*(logfactor-2*h*sat))*(-mp.expm1(qlog*remaining))/(-mp.expm1(qlog)) if remaining else mp.mpf(0)
    S=sat+tail;B=1+turn+1/(-mp.expm1(qlog));assert S<=B
    direct=None;res=None
    if n<=512:
     direct=sum(mp.exp(p*min(mp.mpf(0),logfactor-2*h*j)) for j in range(n+2));res=abs(S-direct)/max(1,abs(S));assert res<mp.mpf('1e-45');directchecks+=1
    rows.append({'stage':'initial' if n<=16 else 'stress' if n<=1024 else 'expanded','n':n,'p':pp,'log_factor':enc(logfactor),'log_gamma':enc(lg),'h':enc(h),'cutoff_real':enc(turn),'saturated_terms':sat,'geometric_tail_terms':remaining,'S_p':enc(S),'B_p':enc(B),'bound_minus_S':enc(B-S),'S_over_sqrt_n':enc(S/mp.sqrt(n)),'B_over_sqrt_n':enc(B/mp.sqrt(n)),'normalized_gap':enc((B-S)/mp.sqrt(n)),'independent_direct_sum':enc(direct) if direct is not None else None,'direct_relative_residual':enc(res) if res is not None else None})
  geometry=[]
  # Perfect squares make d=1/(8sqrt n) rational; no sqrt used in certificates.
  for n,root in [(1,1),(4,2),(16,4),(64,8),(256,16)]:
   gamma=F(n+1,n);d=F(1,8*root)
   for b in [F(1),F(3,2),F(2)]:
    legal=[];j=0
    while gamma**(2*j)<=b:
     legal.append(j);j+=1
    for j in sorted(set([0,min(1,legal[-1])])):
     ratio=gamma**(2*j);L=F(1);R=ratio
     assert F(1)<=L<=R<=b and R/L>=ratio
     lhs=min(F(1),((L+d)/R)**n);rhs=min(F(1),(1+d)**n*gamma**(-2*n*j));assert lhs<=rhs
     # A second placement uses the remaining octave room, preserving same ratio.
     L2=b/ratio;R2=b;lhs2=min(F(1),((L2+d)/R2)**n);assert lhs2<=rhs
     geometry.append({'n':n,'b':str(b),'j':j,'gamma_exact':str(gamma),'d_exact':str(d),'L_exact':str(L),'R_exact':str(R),'ratio_lower_exact':str(ratio),'cell_fee_exact':str(lhs),'d_j_exact':str(rhs),'second_L_exact':str(L2),'second_R_exact':str(R2),'second_cell_fee_exact':str(lhs2),'exact_margins':[str(rhs-lhs),str(rhs-lhs2)]})
  return {'sums':rows,'direct_sum_checks':directchecks,'exact_ratio_geometry':geometry}

def fields(obj,path=''):
 out={}
 if isinstance(obj,dict):
  for k,v in obj.items():
   if isinstance(v,str) and k not in ['stage','p'] and not k.endswith('_exact'):
    try:
     z=mp.mpf(v)
     if mp.isfinite(z):out[path+k]=z
    except ValueError:pass
   elif isinstance(v,(dict,list)):out.update(fields(v,path+k+'/'))
 elif isinstance(obj,list):
  for i,v in enumerate(obj):out.update(fields(v,path+str(i)+'/'))
 return out

def main():
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));a=p.parse_args();low=run(50);high=run(90)
 with mp.workdps(120):
  x=fields(low);y=fields(high);assert x.keys()==y.keys();diff={k:abs(x[k]-y[k])/max(1,abs(y[k])) for k in x};worst=max(diff,key=diff.get);md=enc(diff[worst]);assert diff[worst]<mp.mpf('1e-42')
 out={'schema':'R268-ratio-geometric-price-v1','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'counts':{'price_cases_per_precision':24,'price_stage_cases':{'initial':8,'stress':8,'expanded':8},'independent_direct_sum_checks_per_precision':high['direct_sum_checks'],'exact_ratio_geometry_cases':len(high['exact_ratio_geometry']),'exact_geometry_placements':2*len(high['exact_ratio_geometry']),'precision_fields_compared':len(diff)},'mp50':low,'mp90':high,'precision_max_relative_difference':md,'precision_worst_field':worst,'scope':['d_j=min(1,(1+1/(8sqrt n))^n gamma^(-2nj)),j0..n+1. Saturated terms counted exactly using highprecision floor of explicit real threshold; remaining finite geometric sum evaluated with expm1.','n<=512 independently enumerates every term; larger dimensions are scalar finite price formulas only, not physical source/receiver models. No asymptotic law inferred from ratios.','Ratio geometry placements use perfect-square n so sqrt n,d,gamma,L,R and both fee inequalities are exact Fractions; all a1,b1/1.5/2 and R>=L constraints checked. These finite samples do not prove the universal ratio lemma.','50/90 mpmath arithmetic is ordinary, not outward interval certification. Source-saturation files from R268 remain unchanged. No FULL/history/root conclusion or dense-complement payment.']}
 a.output.write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps({'counts':out['counts'],'maxdiff':md,'worst':worst}))
if __name__=='__main__':main()
