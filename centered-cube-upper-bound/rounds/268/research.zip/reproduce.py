#!/usr/bin/env python3
"""R268 byte reproduction and independently checked exact rate bounds."""
from pathlib import Path
from fractions import Fraction as F
import argparse,json,hashlib,subprocess,sys,tempfile
ROOT=Path(__file__).resolve().parent

def rates():
    data=json.loads((ROOT/'source_checks.json').read_text());point=moment=0
    for case in data['cases']:
        beta=list(map(F,case['beta_masses']));Adj=case['source_adjacency_Q2w'];tau=F(case['tau'])
        s0=list(map(F,case['records'][0]['selected']))
        rho0=[b-s for b,s in zip(beta,s0)]
        m=[sum(b*k for b,k in zip(beta,row)) for row in Adj]
        for record in case['records'][1:]:
            k=record['iteration'];sigma=list(map(F,record['selected']))
            rho=[b-s for b,s in zip(beta,sigma)]
            slack=[max(F(0),tau-sum(s*z for s,z in zip(sigma,row))) for row in Adj]
            for i in range(len(beta)):
                if not m[i]:assert rho[i]==0
                else:assert rho[i]<=rho0[i]*(1-min(F(1),slack[i]/m[i]))**k
                point+=1
            ck=F(k**k,(k+1)**(k+1))
            assert sum(a*r for a,r in zip(slack,rho))<=ck*sum(b*r for b,r in zip(m,rho0))
            moment+=1
    return {'pointwise_rate_checks':point,'slack_moment_checks':moment}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--check-only',action='store_true');args=ap.parse_args()
    manifest=json.loads((ROOT/'manifest.json').read_text())
    for name,digest in manifest['sha256'].items():assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,name
    counts=rates();assert counts==manifest['extra_exact_counts'];print('Exact rate checks PASS',counts)
    if not args.check_only:
        with tempfile.TemporaryDirectory(prefix='r268-replay-') as d:
            for stem in ('source_checks','ratio_checks'):
                output=Path(d)/(stem+'.json')
                subprocess.run([sys.executable,str(ROOT/(stem+'.py')),'--output',str(output)],check=True)
                assert output.read_bytes()==(ROOT/(stem+'.json')).read_bytes(),stem
                print(stem,'byte-identical PASS')
    else:print('Hashes/rates only; full numerical replay not run.')
if __name__=='__main__':main()
