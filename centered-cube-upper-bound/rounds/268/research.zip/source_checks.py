#!/usr/bin/env python3
"""R268 exact finite source saturation and genuine uniform-interval examples."""
import argparse,hashlib,json
from pathlib import Path
from fractions import Fraction as F

def st(x):return str(F(x))
def atom_receivers(centers,w):
 events=sorted({c-w/2 for c in centers}|{c+w/2 for c in centers});return sorted(set(events+[(a+b)/2 for a,b in zip(events,events[1:])]+[events[0]-w,events[-1]+w]))
def overlap(a,b,c,d):return max(F(0),min(b,d)-max(a,c))
def L1_receivers(centers,w,width):
 edges=[c+sign*width/2 for c in centers for sign in [-1,1]];events=sorted({e+sign*w/2 for e in edges for sign in [-1,1]});return sorted(set(events+[(a+b)/2 for a,b in zip(events,events[1:])]+[events[0]-w,events[-1]+w]))
def models():
 q=lambda xs:list(map(F,xs))
 return [('initial','three_equal',q(['-3/4','0','3/4']),q(['1','1','1']),F(1),F(1),8,None),('stress','unequal',q(['-3/4','0','3/4']),q(['1/4','2','3/2']),F(1),F(1),4,None),('stress','closed_distance_boundary',q(['-1','0','1']),q(['1','2','1']),F(1),F(1),4,None),('stress','zero_and_isolated',q(['-2','0','2']),q(['1/2','0','3']),F(1),F(1),4,None),('stress','coincident_sources',q(['0','0','3/4']),q(['1/3','2/3','2']),F(1),F(1),4,None),('expanded','six_grid',[F(3*i,4) for i in range(6)],[F(1)]*6,F(1),F(1),3,None),('expanded','nine_two_clusters',[F(3*i,4) for i in range(5)]+[F(8)+F(3*i,4) for i in range(4)],[F((i%3)+1,2) for i in range(9)],F(1),F(1),3,None),('expanded','twelve_grid',[F(3*i,4) for i in range(12)],[F((i%4)+1,3) for i in range(12)],F(1),F(1),3,None),('initial','L1_three_equal',q(['-3/4','0','3/4']),q(['1','1','1']),F(1),F(1),5,F(1,10)),('stress','L1_unequal',q(['-3/4','0','3/4']),q(['1/4','2','3/2']),F(1),F(1),4,F(1,10)),('expanded','L1_six_grid',[F(3*i,4) for i in range(6)],[F((i%3)+1,2) for i in range(6)],F(1),F(1),3,F(1,10))]

def check(model):
 stage,name,c,beta,w,tau,steps,width=model;N=len(c);Adj=[[int(abs(x-y)<=w) for y in c] for x in c]
 margin=None
 if width:
  gaps=[]
  for i in range(N):
   for j in range(N):
    distance=abs(c[i]-c[j]);maximum=distance+width;minimum=max(F(0),distance-width)
    if Adj[i][j]:assert maximum<=w;gaps.append(w-maximum)
    else:assert minimum>=w;gaps.append(minimum-w)
  margin=min(gaps)
 receivers=L1_receivers(c,w,width) if width else atom_receivers(c,w)
 def receive(s,x):
  if width:return sum(si/width*overlap(ci-width/2,ci+width/2,x-w/2,x+w/2) for ci,si in zip(c,s))
  return sum(si for ci,si in zip(c,s) if abs(ci-x)<=w/2)
 def cap(s):
  values=[receive(s,x) for x in receivers];assert max(values)<=tau;return max(values)
 original_neighborhood=[sum(beta[j]*Adj[i][j] for j in range(N)) for i in range(N)]
 sigma=[beta[i]*min(F(1),tau/original_neighborhood[i]) if original_neighborhood[i] else beta[i] for i in range(N)]
 capchecks=0;records=[]
 for iteration in range(steps+1):
  maxcap=cap(sigma);capchecks+=len(receivers);rho=[b-s for b,s in zip(beta,sigma)];current=[sum(sigma[j]*Adj[i][j] for j in range(N)) for i in range(N)];slack=[max(F(0),tau-x) for x in current];resneigh=[sum(rho[j]*Adj[i][j] for j in range(N)) for i in range(N)]
  remaining_slacks=[slack[i] for i in range(N) if rho[i]>0]
  record={'iteration':iteration,'selected_mass':st(sum(sigma)),'residual_mass':st(sum(rho)),'receiver_max_exact':st(maxcap),'receiver_cap_margin_exact':st(tau-maxcap),'max_residual_source_slack':st(max(remaining_slacks,default=F(0))),'all_residual_source_neighborhoods_saturated':all(x==0 for x in remaining_slacks),'selected':list(map(st,sigma)),'source_neighborhood_selected':list(map(st,current)),'max_fraction_bit_length':max(max(x.numerator.bit_length(),x.denominator.bit_length()) for x in sigma)}
  records.append(record)
  if iteration==steps:break
  eta=[min(F(1),slack[i]/resneigh[i]) if resneigh[i] else F(1) for i in range(N)];nextsigma=[sigma[i]+eta[i]*rho[i] for i in range(N)]
  assert all(sigma[i]<=nextsigma[i]<=beta[i] for i in range(N));record['gain_to_next']=st(sum(nextsigma)-sum(sigma));record['eta']=list(map(st,eta));sigma=nextsigma
 if name in ['three_equal','L1_three_equal']:
  assert F(records[0]['selected_mass'])==F(4,3);assert F(records[1]['selected_mass'])==F(31,21)
 return {'stage':stage,'name':name,'source_type':'positive_L1_uniform_intervals' if width else 'finite_atomic_algebra','centers':list(map(st,c)),'beta_masses':list(map(st,beta)),'w':st(w),'tau':st(tau),'source_interval_width':st(width) if width else None,'source_adjacency_Q2w':Adj,'source_adjacency_uniform_margin':st(margin) if margin is not None else None,'receiver_test_centers':list(map(st,receivers)),'receiver_exact_checks':capchecks,'receiver_completeness':'L1 mass is continuous piecewise affine in receiver center with all breakpoints tested; atom indicators are constant between events and closed endpoints tested separately.','steps':steps,'records':records,'total_gain':st(F(records[-1]['selected_mass'])-F(records[0]['selected_mass']))}

def main():
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));a=p.parse_args();rows=[check(x) for x in models()]
 out={'schema':'R268-exact-source-saturation-v1','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'counts':{'models':len(rows),'atomic_models':sum(r['source_type']=='finite_atomic_algebra' for r in rows),'positive_L1_models':sum(r['source_type']=='positive_L1_uniform_intervals' for r in rows),'stage_models':{s:sum(r['stage']==s for r in rows) for s in ['initial','stress','expanded']},'iteration_states':sum(len(r['records']) for r in rows),'receiver_window_exact_checks':sum(r['receiver_exact_checks'] for r in rows),'updates':sum(r['steps'] for r in rows),'specified_4_over3_to_31_over21_checks':2},'cases':rows,'scope':['All calculations are exact Fraction arithmetic. Atomic models are only finite algebra diagnostics, including zero-mass and coincident-slot pressures.','Three genuine L1 examples have uniform density on positive-width intervals, width1/10. Source Q2w adjacency is proved constant over every pair of source blocks by exact endpoint distances, so the density fraction recursion is exactly represented by block masses.','True Qw receiver mass for L1 examples uses exact intersection lengths at every piecewise-affine breakpoint plus midpoints. Thus the reported cap checks apply to all real receiver centers, not just sampled points.','Residual saturation is reported at the finite stopping step, not claimed complete or converged. Finite models and monotonic gains do not prove a general iteration/convergence theorem, pay a dense complement, or qualify FULL/history/root.']}
 a.output.write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps({'counts':out['counts'],'maximum_fraction_bits':max(z['max_fraction_bit_length'] for r in rows for z in r['records'])}))
if __name__=='__main__':main()
