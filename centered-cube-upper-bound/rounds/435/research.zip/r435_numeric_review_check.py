"""Portable stdlib checks of the four rejected claims; no model repair/search.
Run: python3 r435_numeric_review_check.py
"""
from fractions import Fraction as F

d = F(1, 100)
t = F(65, 100)
c = F(7, 10)
u = c + d + t
y = c - d / 2
assert u - y > t + d
print('coverage witness u=', u, 'interior y=', y, 'distance=', u-y,
      'R/2=', t+d, 'failure=', u-y > t+d)
assert 2 + 2*d == F(101, 50)
print('D side=', 2+2*d, 'relative side versus 2=', (2+2*d)/2)
x = (d + F(65, 100)) / (d + F(49, 100))
assert x == F(33, 25) and x != F(22, 17)
print('shell ratio=', x, 'claimed=', F(22, 17), 'equal=', x == F(22, 17))
# log(x)=2 atanh(z), positive partial sum and rigorous geometric tail.
z = (x-1)/(x+1)
N = 40
lo = sum((2*z**(2*k+1)/F(2*k+1) for k in range(N)), F(0))
hi = lo + 2*z**(2*N+1)/(F(2*N+1)*(1-z*z))
assert F(2776317365982794, 10**16) < lo < hi < F(2776317365982796, 10**16)
print('log correct ratio numerical enclosure=', float(lo), float(hi))
print('log interval certified inside (0.2776317365982794, 0.2776317365982796)')
assert F(2)/(2*(d+t)) == F(50, 33)
print('mass eligibility ratio=', F(2)/(2*(d+t)))
for n in [1, 2, 3]:
    distance = F(14, 10) + 2*d*n
    assert distance == F(142, 100) + 2*d*(n-1)
    assert (distance == F(142, 100)) == (n == 1)
    print('n=', n, 'L1 supremum=', distance, 'claimed=', F(142, 100))
print('PASS: four rejection checks; no original-flow or repaired-model claim.')
