from fractions import Fraction as F
from decimal import Decimal as D, localcontext

# Three native positive-center-block parent families, same complete field as
# r435_complement_check.py. Static L below is diagnostic, not original history.
n=16
eta=F(1,1000); vol=eta**n
sides=[F(1),F(3,2),F(2)]
m=[x**n for x in sides]
weights=[m[0],m[1]-m[0],m[2]-m[1]]
positions=[F(0),F(5,8),F(7,8)]
assertions=0
for a,R in enumerate(sides):
    for y,x in enumerate(positions):
        inside=abs(x)+eta<R/2 and F(a+1,100)+eta<R/2
        outside=abs(x)-eta>R/2
        assert inside if y<=a else outside; assertions+=1
    for u in range(a):
        assert m[a]/m[u]>64; assertions+=1
with localcontext() as ctx:
    ctx.prec=70
    def dec(x): return D(x.numerator)/D(x.denominator)
    def mi(prior,channel):
        marg=[sum((prior[y]*channel[y][u] for y in range(len(prior))),F(0)) for u in range(len(channel[0]))]
        ans=D(0)
        for y,p in enumerate(prior):
            for u,k in enumerate(channel[y]):
                if p and k:
                    ans+=dec(p*k)*dec(k/marg[u]).ln()
        return ans
    for mode in range(3):
        results=[]
        for a in range(3):
            pi=[weights[y]/m[a] for y in range(a+1)]
            gate=lambda y,z: F(1) if mode==0 else (F((y+2*z+1)%4,3) if mode==1 else F(1,17) if y==z else F(0))
            L=[sum((pi[z]*gate(y,z) for z in range(a+1)),F(0)) for y in range(a+1)]
            base=[]; accepted=[]; refined=[]
            for y in range(a+1):
                Z=sum((vol/m[u] for u in range(a) if y<=u),F(0))
                qrow=[vol/m[u]/Z if Z and y<=u else F(0) for u in range(a)]
                ell=L[y] if Z else F(0)
                B=[sum((pi[z]*gate(y,z) for z in range(a+1) if z>u),F(0)) for u in range(a)]
                brow=[ell*qrow[u] for u in range(a)]
                arow=[qrow[u]*B[u] for u in range(a)]
                brow.append(1-sum(brow)); arow.append(1-sum(arow))
                rrow=[]
                for u in range(a):
                    rrow.extend([arow[u],brow[u]-arow[u]])
                rrow.extend([F(0),brow[-1]])
                for row in (brow,arow,rrow):
                    assert min(row)>=0 and sum(row)==1; assertions+=1
                base.append(brow); accepted.append(arow); refined.append(rrow)
            ib=mi(pi,base); ia=mi(pi,accepted); ir=mi(pi,refined)
            tol=D('1e-60')
            assert ia<=ir+tol; assertions+=1
            assert ib<=ir+tol; assertions+=1
            assert ir<=ib+D(2).ln()+tol; assertions+=1
            results.append((a,str(ia),str(ib),str(ir)))
        print('stage',mode+1,'(parent, I_accept, I_gated_prefix, I_refined):',results)
print('PASS',assertions,'assertions; 9 channel models, exact Fraction rows and native capture margins; 70-digit Decimal information diagnostics, not interval proof')
print('No original high-rank/low-common/clock/path certification; no test of a global information budget.')
