# R435：真实接受通道的一位信息比较；平均几何预算未闭合

## 准确候选与量词

固定 R435 合同的完整匹配场及同一静态门 \(0\le L(A,y,z)\le1\)，不改变原余流。记 \(\mu=f dx\)、\(c_*=1-1/(4-\varepsilon_0)\)、\(K=e^{\sqrt n}\)。令
\[
\ell_A(y)=\int\pi_A(dz)L(A,y,z),\quad
B_{Au}(y)=\int\pi_A(dz)L(A,y,z)(1-c_u(z)),
\]
故 \(0\le B_{Au}\le\ell_A\le1\)。原高秩门保证 \(Z_A(y)=0\) 时 \(\ell_A(y)=0\)。真实接受通道为
\[
k_A(y,du)=\frac{1_{m_u<m_A/K}c_u(y)}{m_uZ_A(y)}B_{Au}(y)du,
\quad k_A(y,\partial)=1-k_A(y,E).
\tag{1}
\]
零分母处真实输出取零。所有质量和 \(Z_A\) 都来自完整 \(f\) 与真实中心，未刷新来源。

独立核对信息下界成立：真实输出 \(u\) 的来源后验 \(\nu_{Au}\) 支持 \(Q_A\cap Q_u\)，于是
\[
D(\nu_{Au}\Vert\pi_A)
=\log\frac{m_A}{I_{Au}}
 +D(\nu_{Au}\Vert\pi_A(\cdot\mid Q_u))
\ge\log\frac{m_A}{m_u}>\sqrt n,
\quad I_{Au}=\mu(Q_A\cap Q_u).
\tag{2}
\]
输出零质量的项忽略；墓地 KL 非负。全部均为非负扩展实数量，未作无穷相减。因此
\[
R_{433}\le\frac{S}{c_*\sqrt n}\int\sigma(dA)I_A^{\rm acc}.
\tag{3}
\]
本轮只检验一条深入机制：先保留原来源门的边缘 \(\ell_A\)，再分离 exclusive 接受造成的信息，判断能否给平均信息以 \(n\operatorname{polylog}n\,W\) 价格。

## 已证的一位比较

定义保门 prefix 通道
\[
Q_A^L(y,du)=\ell_A(y)
 \frac{1_{m_u<m_A/K}c_u(y)}{m_u Z_A(y)}du,
\quad Q_A^L(y,\partial)=1-\ell_A(y).
\tag{4}
\]
它对每行归一；保留真实 \(Z_A\) 和原门边缘，不是假设均匀子父。先从 (4) 得 \(V\)，对真实输出 \(u\) 抽一个接受位 \(C\)，成功率为 \(B_{Au}(y)/\ell_A(y)\)；墓地行取 \(C=0\)。最终将拒绝输出合并到墓地，恰得 (1)。链式法则和数据处理给
\[
\boxed{I_A^{\rm acc}\le I(Y;V,C)
 =I_A^{L\text{-pre}}+I(Y;C\mid V)
 \le I_A^{L\text{-pre}}+\log2.}
\tag{5}
\]
可用有限可测分割再取上确界理解无穷情形；各条件信息非负，不需要相减两个无穷。没有将 \(B/Z\) 的后验浓缩误判为信息上界 \(\log(m_A/m_u)\)。

因此接受位附加项在 (3) 中至多
\[
\frac{S\log2}{c_*\sqrt n}X_q.
\tag{6}
\]
给定 \(\epsilon>0\)，若 \(n\ge N_\epsilon=
\lceil(2S\log2/(c_*\epsilon))^2\rceil\)，(6) 至多 \(\epsilon X_q/2\)。有限低维可用原生 \(X_q\le A_nW\)、\(A_n=1+n\log(b/a)\)，故 \(R_{433}\le S(1+N_\epsilon\log2)W\)。这是条件性整体论证的量词，不是当前新增付款。

## 唯一未消项及实际失败位置

(5) 没有支付 \(\int\sigma I_A^{L\text{-pre}}\)。删去 \(u,z\) 的联合接受依赖可能过度上放，因此不将该 prefix 的强预算当作下一步必要目标。

保持原接受通道时，(2) 给出精确非负分解
\[
I_A^{\rm acc}=\int_E\bar k_A(du)
 \left[\log\frac{m_A}{I_{Au}}
 +D(\nu_{Au}\Vert\pi_A(\cdot\mid Q_u))\right]
 +\bar k_A(\partial)D(\nu_{A\partial}\Vert\pi_A).
\tag{7}
\]
这里 \(\bar k_A=\pi_A k_A\)，接受后验在捕获集内由真实 \(B_{Au}(y)/Z_A(y)\) 倾斜。完整质量匹配只给 \(I_{Au}\le m_u\)，是 (2) 所需的**下界方向**；即使 \(m_A/m_u\) 有 octave 上限，也不能将 \(\log(m_A/I_{Au})\) 或倾斜 KL 上放成该上限。另一方面，来源积分中的小交叠输出权可能补偿这个对数，不能据此断言预算为假。

本次未能将 (7) 的完整父积分，利用实际中心几何及原门，控制为
\[
\frac{c_*\epsilon\sqrt n}{S}X_q
 +C_\epsilon n\log^A(n+2)W.
\]
具体缺的是小交叠输出权与接受后验倾斜的**联合跨父信息结算**，不是墓地遗漏或接受位的无限信息。这决定了本候选尚无完整根阶费用、无新母账系数，不能拿网格熵耗散直接替代 (7)。

## 本机检查范围

实际执行 `/tmp/r435_geometry_check.py`，输出保存 `/tmp/r435_geometry.result.txt`：三阶段、9 个通道模型、93 项断言通过。使用已核的 \(n=16\) 正 Lebesgue 中心块与完整来源包，边长 \(1,3/2,2\)，完整匹配 \(q_A=1\)，保真实严格质量门及 \(Z_A\)。三阶段分别取常数、非对称、稀疏来源门。Fraction 精确检查捕获、行概率与墓地；70 位 Decimal 检查 (5)（非区间证明）。没有原高秩、低共同捕获、时钟或完整路径认证，也没有测试上述平均预算。

结论：信息下界和一位比较已证明；原 R433 整体预算仍未解决。原账不变，本次有界尝试停止。
