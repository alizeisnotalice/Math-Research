from fractions import Fraction as F

# Finite original-label algebra only: no claim of a qualified geometric cascade.
cases=[
 ([4,4,1,0],[F(1,4),F(1,4),F(1,2)],F(1)),
 ([5,3,2,0],[F(1,3),F(1,3),F(1,3)],F(1)),
 ([3,3,3,2],[F(1,4),F(1,2),F(1,4)],F(1)),
 ([2,1,0,0],[F(1,2),F(1,2),F(0)],F(1)),
 ([8,7,2,1,0],[F(1,8),F(3,8),F(1,4),F(1,4)],F(2)),
 ([0,0,0],[F(1,2),F(1,2)],F(1))]
for k,(roots,deltas,s) in enumerate(cases):
    D=[F(x*x) for x in roots]
    r=[max(F(0),1-s/d) if d else F(0) for d in D[:-1]]
    # A frozen positive history restriction, allowed to depend on stage.
    r=[v*F((i%3)+1,3) for i,v in enumerate(r)]
    acc=F(0);cost=F(0);delete=F(0);sqdelete=F(0);om=F(0)
    for i,delta in enumerate(deltas):
        cost+=delta*r[i]*D[i];acc+=delta*r[i]
        delete+=acc*(D[i]-D[i+1])
        omega=F(roots[i]-roots[i+1]);om+=omega
        sqdelete+=acc*(roots[i]+roots[i+1])*omega
    terminal=acc*D[-1]
    assert cost==terminal+delete==terminal+sqdelete
    assert om==roots[0]-roots[-1]
    assert 0<=acc<=sum(deltas)<=1
    assert delete<=2*roots[0]*om
    print(f'case {k+1}: R={cost}, terminal={terminal}, deletion={delete}, sqrt_budget={om}')
print('PASS 6 finite cases: plateaus, whole jumps, nonzero terminal, zero rows; exact Fraction.')
print('No native centers or original survival/history realization asserted; only the displayed identities are tested.')
