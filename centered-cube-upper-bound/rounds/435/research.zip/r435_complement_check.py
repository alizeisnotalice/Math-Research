from fractions import Fraction as F
from decimal import Decimal as D, localcontext
import json
n=16
eta=F(1,1000)
v=eta**n
sides=[F(1),F(3,2),F(2)]
m=[R**n for R in sides]
w=[m[0],m[1]-m[0],m[2]-m[1]]
x1=[F(0),F(5,8),F(7,8)]
# E_i are disjoint eta-cubes centered at ((0),(i+1)/100,0,...).
# Sources are eta-cubes centered at (x1[k],0,...).
for i,R in enumerate(sides):
 for k,x in enumerate(x1):
  inside=(abs(x)+eta<R/2 and F(i+1,100)+eta<R/2)
  outside=(abs(x)-eta>R/2)
  assert inside if k<=i else outside
for i in range(3):
 for j in range(i):
  assert m[i]/m[j]>64  # e^4 <64, so these are actual strict-K edges.
rows=[]
with localcontext() as ctx:
 ctx.prec=70
 def dec(x):return D(x.numerator)/D(x.denominator)
 for i in range(3):
  pi=[wk/m[i] for wk in w[:i+1]]
  channels=[]
  for k in range(i+1):
   Z=sum((v/m[j] for j in range(i) if k<=j),F(0))
   row=[F(0)]*i
   if Z:
    for j in range(i):
     if k<=j:
      B=1-m[j]/m[i]
      row[j]=(v/m[j])/Z*B
   row.append(1-sum(row))
   assert all(x>=0 for x in row) and sum(row)==1
   channels.append(row)
  marg=[sum((pi[k]*channels[k][j] for k in range(i+1)),F(0)) for j in range(i+1)]
  assert sum(marg)==1
  I=D(0); H=D(0); real=sum(marg[:i],F(0)); support_lower=D(0)
  for j,t in enumerate(marg):
   if not t: continue
   KL=D(0)
   for k in range(i+1):
    post=pi[k]*channels[k][j]/t
    if post:
     KL+=dec(post)*(dec(post/pi[k])).ln()
     if j<i:assert k<=j
   assert KL>=-D('1e-60')
   I+=dec(t)*KL
   if j<i:
    l=dec(m[i]/m[j]).ln()
    assert KL+D('1e-60')>=l
    H+=dec(t)*l
  assert I+D('1e-60')>=H
  assert H+D('1e-60')>=D(4)*dec(real)
  rows.append({'parent':i,'Eex_A':str(dec(real)),'log_energy_A':str(H),'mutual_information_A':str(I),
      'all_rows_exact_subprobabilities':True,'actual_continuous_cube_matching':True})
print(json.dumps({'n':n,'center_block_volume':str(v),'W':str(m[-1]),'rows':rows,
 'scope':'Exact Fraction channel rows and geometric containments; 70-digit Decimal KL evaluation. No original high-rank, soft, stage, or full-path certification; no test of the proposed global information bound.'},indent=2))
