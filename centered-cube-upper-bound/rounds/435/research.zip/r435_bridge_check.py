from fractions import Fraction as F

def mm(a,b):
 return [[sum((a[i][k]*b[k][j] for k in range(len(b))),F(0)) for j in range(len(b[0]))] for i in range(len(a))]
# Two fixed pair fibres, each with two possible fathers. Bayes redraw preserves the pair.
checks=0
for p in [F(0),F(1,1000),F(1,4),F(1,2)]:
 K=[[1-p,p,0,0],[1-p,p,0,0],[0,0,F(1,3),F(2,3)],[0,0,F(1,3),F(2,3)]]
 assert mm(K,K)==K
 # A change in pair marginal is invariant; no strict contraction on whole state space.
 v=[[1-p,p,0,0]]
 assert mm(v,K)==v
 # Repeated killing on H has exact geometric total; no uniform hitting lower bound as p->0.
 alive=F(1); paid=F(0)
 for _ in range(10):
  paid+=alive*p;alive*=1-p
 assert paid+alive==1
 checks+=1
# Whole comparison: if defect+error <= alpha S X +(C/s)H+CsW, n/s<=s.
for n in [1,4,9,16,64,256]:
 import math
 s=1+math.sqrt(n)
 assert n/s<=s
print(f'PASS: {checks} exact conditional-resampling projection/killing models')
print('PASS: 6 numeric n/s<=s parameter checks; general inequality is algebraic')
print('Scope: finite algebra and conditional-kernel obstruction only, not a continuous-cube/history counterexample or proof of R433 bound.')
