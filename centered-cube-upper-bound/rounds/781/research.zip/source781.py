#!/usr/bin/env python3
"""R781 exact one-source budget over absolute size buckets and price-aware greedy checks."""

from collections import defaultdict
from fractions import Fraction as F
from itertools import product
import json
import sys


SUPPORT=(F(-16),F(16))
PERIOD=F(1,8)


def ss(items):
    return sum(items,F(0))


def meet(*intervals):
    return max(i[0] for i in intervals),min(i[1] for i in intervals)


def length(i):
    return max(F(0),i[1]-i[0])


def contains(i,j):
    return i[0]<=j[0]<=j[1]<=i[1]


def mu(i):
    a,b=meet(i,SUPPORT)
    if a>=b:
        return F(0)

    def primitive(x):
        k=x//PERIOD
        rem=x-k*PERIOD
        return k*PERIOD+rem/2+max(F(0),rem-PERIOD/2)

    return primitive(b)-primitive(a)


def union_mass(intervals):
    blocks=[]
    for a,b in sorted(intervals):
        if blocks and a<=blocks[-1][1]:
            blocks[-1]=(blocks[-1][0],max(b,blocks[-1][1]))
        else:
            blocks.append((a,b))
    return ss(map(mu,blocks))


def model(count):
    R_values=(1,2,4)[:count]
    mid_positions=(F(1,8),F(-1,16),F(5,16))
    H_data=[]
    for R,c in zip(R_values,mid_positions):
        ctr=(F(-3*R,8),c,F(R,2))
        radius=tuple(F(j*R,8) for j in (5,7,6))
        for j,(x,s) in enumerate(zip(ctr,radius)):
            parent=x-s,x+s
            C=parent if j!=1 else (x-s,x+s-F(R,16))
            E=x-s/32,x+s/32
            H_data.append((R,parent,C,E,x,s))
    O,A,C,E,centers,radii=map(tuple,zip(*H_data))
    m=tuple(map(mu,A))
    I=tuple(map(length,E))
    assert m==tuple(map(length,A)) and all(F(O[i],2)<=s<O[i] for i,s in enumerate(radii))
    assert all(contains(a,e) for a,e in zip(A,E))
    assert all(not length(meet(e,f)) for i,e in enumerate(E) for f in E[:i])
    keys=range(len(A))
    centers_used=tuple(range(1,len(A),3))
    assert all(O[v]<=m[v]<2*O[v] for v in centers_used)  # D=R in dimension 1.
    s={(i,j):mu(meet(C[i],C[j])) for i,j in product(keys,repeat=2)}
    K={(i,j):p/(m[i]*m[j]) if i!=j else F(0) for (i,j),p in s.items()}
    d={v:ss(I[i]*K[v,i] for i in keys) for v in centers_used}
    arm={v:tuple(i for i in keys if O[i]==O[v] and m[i]<m[v] and K[v,i]>0) for v in centers_used}
    assert all(len(h)==2 for h in arm.values()) and all(d.values())
    # Local equality at the selected parent is verified. Periodicity also gives
    # earlier equalities, so these sizes are not asserted to be first crossings.
    assert all(mu((x-PERIOD/2,x+PERIOD/2))==PERIOD and PERIOD/2<r for x,r in zip(centers,radii))
    return R_values,O,A,C,E,m,I,s,K,d,arm,keys,centers_used


def anchor_eta():
    R,O,A,C,E,m,I,s,K,d,arm,keys,centers=model(3)
    H=ss(I[i]/m[i] for i in keys if O[i]==2 and C[i][0]<=0<=C[i][1])
    v=centers[1]
    assert A[v][0]<=0<=A[v][1]
    return H**2*I[v]/(4*d[v])


def test(count,eta):
    R,O,A,C,E,m,I,s,K,d,arm,keys,centers=model(count)
    ends=sorted({*SUPPORT,*(p for i in (*A,*C) for p in i)})
    cells=list(zip(ends,ends[1:]))
    cell_weights=list(map(mu,cells))
    assert all(cell_weights)

    # First calculation keeps both true endpoints and their actual marked prices.
    path={}
    for v in centers:
        for u,g in product(arm[v],repeat=2):
            raw=I[u]*I[v]*K[u,v]*I[g]*K[v,g]/d[v]
            for i,Y in enumerate(cells):
                left=mu(meet(Y,C[u],C[v]))/s[u,v]
                if not left:
                    continue
                for j,Z in enumerate(cells):
                    right=mu(meet(Z,C[g],C[v]))/s[v,g]
                    if right:
                        path[u,v,g,i,j]=raw*left*right
    assert path
    assert all(path[u,v,g,i,j]==path[g,v,u,j,i] for u,v,g,i,j in path)

    true_by_bucket=defaultdict(F)
    for (u,v,g,i,j),w in path.items():
        true_by_bucket[O[v],i,j]+=w/(cell_weights[i]*cell_weights[j])
    H={(r,i):ss(I[g]/m[g] for g in keys if O[g]==r and contains(C[g],Y))
       for r in R for i,Y in enumerate(cells)}

    eta_integral=eta*ss(cell_weights)
    assert 0<eta_integral<=1
    totals=defaultdict(F)
    counters=defaultdict(int)
    witness=None
    for (i,Y),(j,Z) in product(enumerate(cells),repeat=2):
        q0={}
        A_bound={}
        factor=cell_weights[i]*cell_weights[j]
        for v in centers:
            r=O[v]
            left=ss(I[u]/m[u] for u in arm[v] if contains(C[u],Y))
            right=ss(I[g]/m[g] for g in arm[v] if contains(C[g],Z))
            a0=I[v]*left*right/(m[v]**2*d[v]) if contains(C[v],Y) and contains(C[v],Z) else F(0)
            assert a0==true_by_bucket[r,i,j]
            abar=H[r,i]*H[r,j]*I[v]/(r**2*d[v])
            with_parent=abar if contains(A[v],Y) and contains(A[v],Z) else F(0)
            assert 0<=a0<=with_parent<=abar
            totals["unlocalized_outer_bound_minus_true_parent_bound"]+=factor*(abar-with_parent)
            q0[r]=a0
            A_bound[r]=with_parent
        if not any(A_bound.values()):
            continue
        counters["positive_bound_price_pairs"]+=1
        if sum(x>0 for x in A_bound.values())>1:
            counters["multiple_positive_bucket_prices"]+=1
        tail=F(0)
        joint=local=marked_joint=marked_local=F(0)
        for r in reversed(R):
            a0=A_bound[r]
            if not a0:
                continue
            tail+=a0
            joint_w=min(F(1),(eta/tail)**2)
            local_w=min(F(1),(eta/a0)**2)
            counters["unsaturated_cumulative_entries"]+=joint_w<1
            counters["saturated_cumulative_entries"]+=joint_w==1
            joint+=a0*joint_w
            local+=a0*local_w
            marked_joint+=q0[r]*joint_w
            marked_local+=q0[r]*local_w
        integral=tail if tail<=eta else 2*eta-eta**2/tail
        assert 0<=marked_joint<=joint<=integral<=2*eta
        assert marked_joint<=marked_local<=local and joint<=local
        counters["local_reused_price_pairs_over_shared_2eta"]+=local>2*eta
        totals["mixed_cumulative_outer_payment"]+=factor*joint
        totals["independent_local_outer_payment"]+=factor*local
        totals["actual_marked_cumulative_payment"]+=factor*marked_joint
        totals["actual_marked_local_reuse_payment"]+=factor*marked_local
        totals["actual_marked_unpaid_after_cumulative"]+=factor*(ss(q0.values())-marked_joint)
        if witness is None and local>2*eta and marked_joint>0:
            witness={"left_actual_cell":Y,"right_actual_cell":Z,"mu_cells":[cell_weights[i],cell_weights[j]],
                     "a_by_r":A_bound,"actual_marked_density_by_r":q0,
                     "cumulative_to_eta":joint/eta,"local_reused_to_eta":local/eta}
    assert totals["unlocalized_outer_bound_minus_true_parent_bound"]>0
    assert 0<totals["actual_marked_cumulative_payment"]<=totals["actual_marked_local_reuse_payment"]
    if count==3:
        assert witness and totals["actual_marked_cumulative_payment"]<totals["actual_marked_local_reuse_payment"]
    if count==1:
        assert totals["actual_marked_cumulative_payment"]==totals["actual_marked_local_reuse_payment"]

    # A fixed known price cell, then one chooses real covering parents based on the row.
    by_left=defaultdict(dict)
    for w,mass in path.items():
        by_left[w[3]][w]=mass
    greedy_report={}
    cover_witness=None
    union_witness=None
    for kappa in (F(1),F(3,4)):
        greedies={"N1":defaultdict(F),"N2":defaultdict(F)}
        for i,edges in by_left.items():
            initial=ss(edges.values())
            eligibility={g:{e for e in edges if m[g]<=kappa*m[e[1]] and contains(A[g],cells[e[4]])}
                         for g in keys}
            chosen=[]
            live=set(edges)
            for N in (1,2):
                choice=max(keys,key=lambda g:(ss(edges[e] for e in live&eligibility[g]),-g))
                added=live&eligibility[choice]
                if added:
                    chosen.append(choice)
                    live-=added
                worst=max(ss(edges[e] for e in live&eligibility[g]) for g in keys)
                assert worst<=initial/(N+1)
                covered=set(edges)-live
                copied_right_labels={e for e in edges if e[2] in chosen and e in eligibility[e[2]]}
                assert copied_right_labels<=covered
                special=covered-copied_right_labels
                row=greedies["N"+str(N)]
                row["worst_residual_fraction_max"] = max(row["worst_residual_fraction_max"],worst/initial)
                row["removed_by_geometric_greedy"] += ss(edges[p] for p in covered)
                row["missed_by_only_right_label"] += ss(edges[p] for p in special)
                row["rows_checked"] += 1
                if special and cover_witness is None and kappa==F(3,4) and N==2:
                    p=max(sorted(special),key=edges.get)
                    i_star=next(g for g in chosen if p in eligibility[g])
                    assert i_star!=p[2]
                    cover_witness={"y":cells[i],"z":cells[p[4]],"old_u_v_g":p[:3],
                                   "chosen_winner_prefix":chosen[:],"actual_covering_parent":i_star,
                                   "real_size_test":[m[i_star], kappa*m[p[1]]],
                                   "positive_marked_edge_mass":edges[p]}
                if len(chosen)==2 and union_witness is None:
                    physical=[A[g] for g in chosen]
                    combined=union_mass(physical)
                    price_sum=ss(cell_weights[j] for j,Q in enumerate(cells)
                                 if any(contains(A[g],Q) for g in chosen))
                    sum_m=ss(m[g] for g in chosen)
                    assert combined==price_sum>0
                    if combined<sum_m:
                        assert price_sum/combined==1
                        union_witness={"known_y":cells[i],"kappa":kappa,"chosen_prefix":chosen[:],
                                       "true_mu_union":combined,"sum_of_parent_mu":sum_m,
                                       "normalized_union_prior_mass":price_sum/combined}
        greedy_report[str(kappa)]=greedies
    assert cover_witness
    if count>1:
        assert union_witness
    return {"absolute_R_upper_ends":R,"real_parents":A,"real_mark_intervals":C,"disjoint_real_owners":E,
            "radius_octaves":"each absolute R uses [R/2,R), with upper endpoint excluded",
            "absolute_D_left_volume_end_in_n1_equal_R":R,"true_d_of_middle":d,
            "peak_Q0_before_gates":ss(path.values()),"pointwise_density_upper_support":"both actual y,z must lie in A_v",
            "all_parent_masses_equal_lengths":True,"first_crossing_scope":"earlier periodic equalities exist; this tests only the local contract",
            "uniform_frozen_eta_density":eta,"shared_row_integral":eta_integral,
            "tail_payment_totals":totals,"tail_payment_counts":counters,"nonresetting_budget_witness":witness,
            "price_aware_greedy":greedy_report,"geometric_coverage_lost_by_only_matching_g":cover_witness,
            "true_overlap_and_union_price_prior":union_witness,
            "one_band_union_scope":"when count is one, no row requires a second positive-cost greedy pick"}


if __name__=="__main__":
    eta=anchor_eta()
    print(json.dumps({"python":sys.version.split()[0],"arithmetic":"Fraction","command":"python -B source781.py",
                      "scope":"finite actual periodic 1D local contracts; frozen eta from the R=2 outer term at zero price in the full model",
                      "models":[test(n,eta) for n in (1,2,3)]},sort_keys=True,indent=2,default=str))
