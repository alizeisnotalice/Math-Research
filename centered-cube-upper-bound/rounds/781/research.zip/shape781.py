#!/usr/bin/env python3
"""R781 balanced-grid shape and certified dyadic series, with one unrestricted stress case."""

from collections import Counter
from fractions import Fraction as F
import json
import sys

from flint import __version__ as flint_version, arb, ctx


ctx.prec=256
THETA=F(1,48)


def ball(q):
    q=F(q)
    return arb(q.numerator)/q.denominator


LN2=arb(2).log()
C_G=1/(1-(-LN2/24).exp())
C_THETA=1/(1-(-LN2*ball(THETA)).exp())


def value(x):
    return x.str(22)


def enclosure(lo,hi):
    return [value(lo),value(hi)]


def moments(a):
    return tuple(sum(v**k for v in a) for k in (1,2,3))


def series(groups,n):
    total=arb(0)
    power=arb(1)
    w=arb(1)
    ratio=(-LN2/n).exp()
    depth=2*n+64
    for l in range(depth):
        term=w
        for v,multiplicity in groups.items():
            if v:
                term*=(1-power*ball(v))**multiplicity
        total+=term
        power*=ratio
        w/=2
    tail=ball(F(1,2**(depth-1)))
    assert total>ball(F(1,2**(2*n)))
    return total,total+tail,depth,tail


def optimum(groups,n):
    intercept=(1-THETA)*n

    def exact_slope(q):
        return sum(m*(q*v)/(1-q*v) for v,m in groups.items())-intercept

    def signs(q):
        b=ball(q)
        tot=-ball(intercept)
        for v,m in groups.items():
            if v:
                w=b*ball(v)
                tot+=m*w/(1-w)
        if tot>0:
            return 1
        if tot<0:
            return -1
        exact=exact_slope(q)
        return int(exact>0)-int(exact<0)

    if 1 not in groups and exact_slope(F(1))<=0:
        left=right=F(1)
    else:
        left,right=F(1,4),F(1)
        assert exact_slope(left)<0
        for _ in range(104):
            pivot=(left+right)/2
            flag=signs(pivot)
            if flag<0:
                left=pivot
            elif flag>0:
                right=pivot
            else:
                left=right=pivot
                break
        assert signs(left)<=0 and signs(right)>=0

    def second(q):
        u=ball(q)
        return -sum((m*(1-ball(v)*u).log() for v,m in groups.items() if v),arb(0))

    # The first summand decreases in q, and the rest increases.
    lo=-ball(intercept)*ball(right).log()+second(left)
    hi=-ball(intercept)*ball(left).log()+second(right)
    return lo,hi,left,right


def profile(a,label,balanced):
    n=len(a)
    groups=Counter(a)
    assert all(0<=x<=1 for x in groups)
    p1,p2,p3=moments(a)
    derivative=p1+p2+p3/2
    gsum=p1+p2/2+p3/6
    old=ball(p1/2)
    slo,shi,L,tail=series(groups,n)
    elo,ehi,qlo,qhi=optimum(groups,n)
    poly=C_G*(-ball(gsum)).exp()
    theta_weak=C_THETA*(-ehi).exp()
    theta_strong=C_THETA*(-elo).exp()
    assert shi<theta_weak
    if balanced:
        assert derivative<=F(23,24)*n
        assert shi<poly
        if gsum:
            assert elo>ball(gsum)
        else:
            assert elo==ehi==0
    else:
        assert derivative>n and slo>poly
        assert qlo<=F(47,95)<=qhi
    return {"profile":label,"n":n,"balanced_equal_rank_exposure":balanced,
            "moments_p1_p2_p3":[p1,p2,p3],"sum_a_g_prime_over_n":derivative/n,
            "sum_g_over_n":gsum/n,"old_p1_over_2n":p1/(2*n),
            "lattice_series":{"explicit_term_count":L,"upper_tail":value(tail),
                               "S":enclosure(slo,shi),"minus_log_S_over_n":enclosure(-shi.log()/n,-slo.log()/n)},
            "optimal_q_bracket":[qlo,qhi],"E_theta_over_n":enclosure(elo/n,ehi/n),
            "bare_exp_minus_sum_g":value((-ball(gsum)).exp()),
            "with_factor_C_g_times_exp_minus_sum_g":value(poly),
            "C_theta_exp_minus_E_theta":enclosure(theta_weak,theta_strong),
            "actual_S_over_old_exp_minus_p1_over_2":enclosure(slo*old.exp(),shi*old.exp()),
            "actual_S_over_bare_exp_minus_sum_g":enclosure(slo*ball(gsum).exp(),shi*ball(gsum).exp()),
            "actual_S_over_polynomial_prefactored_bound":enclosure(slo/poly,shi/poly),
            "series_under_polynomial_exponent_with_prefactor":shi<poly}


def all_cases():
    rows=[]
    for n in (8,16,64,256):
        q=tuple(-1+F(2*j+1,n) for j in range(n))
        choices={"equal":q,"reversed":q[::-1],"swap_halves":q[n//2:]+q[:n//2],
                 "cyclic_one_step":q[1:]+q[:1]}
        assert choices["reversed"]==tuple(-t for t in q)
        for name,qprime in choices.items():
            assert sorted(qprime)==list(q)
            a=tuple(abs(x-y)/2 for x,y in zip(q,qprime))
            p1,p2,p3=moments(a)
            if name=="reversed":
                assert p1==F(n,2)
                assert (p1+p2+p3/2)/n==F(23,24)-F(7,12*n*n)
                assert (p1+p2/2+p3/6)/n==F(17,24)-F(1,4*n*n)
            if name=="swap_halves":
                assert p1==F(n,2) and len(set(a))==1 and a[0]==F(1,2)
                assert (p1+p2/2+p3/6)/n==F(31,48)
            rows.append(profile(a,name,True))
    stress=profile((F(1),)*64,"all_one_displacements_no_shared_rank_law",False)
    return {"grid":"q_j=-1+(2j+1)/n; both arrays are permutations of the same midpoints",
            "theta":THETA,"Cb_1_over_1_minus_2_to_minus_1_over_24":value(C_G),
            "C_theta":value(C_THETA),"results":rows,"independent_stress":stress,
            "tail_math":"truncate at L terms; the remaining geometric bound is 2^(1-L), since every product factor is at most one",
            "scope":"S is a geometric across-bin series. All bisection and tail bounds are deterministic enclosures, and the model evaluates no original peak mass."}


if __name__=="__main__":
    print(json.dumps({"python":sys.version.split()[0],"python_flint":flint_version,
                      "arb_precision_bits":ctx.prec,"command":"python -B shape781.py",
                      "certificate":all_cases()},indent=2,sort_keys=True,default=str))
