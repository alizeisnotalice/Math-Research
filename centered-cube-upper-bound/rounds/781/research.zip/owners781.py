#!/usr/bin/env python3
"""R781 true shared central owner, independent-probe mismatch and true peak factors."""

from collections import defaultdict
from fractions import Fraction as F
from itertools import product
import json
import sys


def ss(items):
    return sum(items,F(0))


def prod(items):
    out=F(1)
    for value in items:
        out*=value
    return out


def length(i):
    return max(F(0),i[1]-i[0])


def section(*intervals):
    return max(i[0] for i in intervals),min(i[1] for i in intervals)


def intersect(*boxes):
    return tuple(section(*axis) for axis in zip(*boxes))


def contains(outer,inner):
    return all(a<=c<=d<=b for (a,b),(c,d) in zip(outer,inner))


def box(center,r):
    return tuple((a-r,a+r) for a in center)


def volume(box):
    return prod(map(length,box))


def center(box):
    return tuple((a+b)/2 for a,b in box)


def count_gate(axis_tables,needed):
    state={(0,0):F(1)}
    for table in axis_tables:
        nxt=defaultdict(F)
        for (r,s),old in state.items():
            for (i,j),chance in table.items():
                nxt[min(needed[0],r+i),min(needed[1],s+j)]+=old*chance
        state=nxt
    assert ss(state.values())==1
    return state[needed]


def weights(l,r,both):
    table={(1,1):both,(1,0):l-both,(0,1):r-both,(0,0):1-l-r+both}
    assert min(table.values())>=0 and ss(table.values())==1
    return table


def certify(n):
    a=32*n
    h=1+F(1,a)
    lower_radius=F(1)
    R_b=F(2)
    D=(2*R_b)**n/2
    T=h*R_b
    test_radius=F(3,2)*lower_radius
    small=F(5,4)
    v_radius=2-F(1,4*n)
    r_own=v_radius/a
    tau=r_own/4
    eps=r_own/64
    v_center=tuple((F(0),)*(n-1)+(t,) for t in (-F(1,8*n),F(1,8*n)))
    shifts=[(F(-5,2),)*n,*v_center,(F(5,2),)*n]
    radii=(small,v_radius,v_radius,small)
    A=[box(c,r) for c,r in zip(shifts,radii)]
    E=[box(c,r/a) for c,r in zip(shifts,radii)]
    C=list(A)
    C[2]=tuple((lo,hi-F(1,16*n)) for lo,hi in A[2])
    assert all(lower_radius<=r<2*lower_radius for r in radii)
    assert all(contains(A[i],E[i]) for i in range(4))
    assert all(not volume(intersect(v,w)) for i,v in enumerate(E) for w in E[:i])
    period=F(1,4*n)
    step=period/2

    def mu_axis(i):
        lo,hi=section(i,(F(-8),F(8)))
        if lo>=hi:
            return F(0)

        def primitive(x):
            k=x//period
            z=x-k*period
            return k*period+z/2+max(F(0),z-period/2)

        return primitive(hi)-primitive(lo)

    def parts(i):
        lo,hi=section(i,(F(-8),F(8)))
        for k in range(lo//step,hi//step+1):
            part=section((lo,hi),(k*step,(k+1)*step))
            if length(part):
                yield part,F(1 if k%2==0 else 3,2)

    def mean(i):
        return ss((b-a)*(a+b)*w/2 for (a,b),w in parts(i))/mu_axis(i)

    def deviation_mean(i,center0):
        integral=F(0)
        for (lo,hi),density in parts(i):
            cuts=sorted({lo,hi,max(lo,min(hi,center0))})
            integral+=ss((b-a)*(abs(a-center0)+abs(b-center0))*density/2
                         for a,b in zip(cuts,cuts[1:]))
        return integral/mu_axis(i)

    def mu(b):
        return prod(map(mu_axis,b))

    m=list(map(mu,A))
    I=list(map(volume,E))
    assert m==list(map(volume,A)) and D<=m[1]==m[2]<2*D
    marks={(e,g):mu(intersect(C[e],C[g])) for e,g in product(range(4),repeat=2)}
    K={(e,g):v/(m[e]*m[g]) if e!=g else F(0) for (e,g),v in marks.items()}
    degree={v:ss(K[v,g]*I[g] for g in range(4)) for v in (1,2)}
    assert K[1,2]>0
    active=min(n-1,3)

    def owner_from_prices(Y,Z,W):
        lo,hi=W
        a0,a1=Y[0]+test_radius,Y[1]+test_radius
        b0,b1=Z[0]-test_radius,Z[1]-test_radius
        assert lo<a0<=a1<hi and lo<b0<=b1<hi
        l=(hi-mean(Y)-test_radius)/length(W)
        r=(mean(Z)-test_radius-lo)/length(W)
        if a0>b1:
            both=F(0)
        else:
            assert a1<b0
            both=(mean(Z)-mean(Y)-2*test_radius)/length(W)
        return weights(l,r,both),(l,r)

    def owner_first(Y,Z,W):
        cuts=set(W)
        cuts.update(x+test_radius for i,_ in parts(Y) for x in i if W[0]<x+test_radius<W[1])
        cuts.update(x-test_radius for i,_ in parts(Z) for x in i if W[0]<x-test_radius<W[1])
        cuts=sorted(cuts)

        def values(x):
            l=mu_axis(section(Y,(Y[0],x-test_radius)))/mu_axis(Y)
            r=mu_axis(section(Z,(x+test_radius,Z[1])))/mu_axis(Z)
            return l,r,l*r

        integral=[F(0)]*3
        for a0,b0 in zip(cuts,cuts[1:]):
            ga,gm,gb=map(values,(a0,(a0+b0)/2,b0))
            for k in range(3):
                integral[k]+=(b0-a0)*(ga[k]+4*gm[k]+gb[k])/(6*length(W))
        l,r,both=integral
        return weights(l,r,both),(l,r)

    def lens_measure(y,z,needed):
        d=tuple(v-u for u,v in zip(y,z))
        lens=intersect(box((F(0),)*n,T),box(d,T))
        lens_volume=volume(lens)
        assert lens_volume==prod(max(F(0),2*T-abs(c)) for c in d)>0
        tables=[]
        choices=[]
        for k in range(active):
            I0=lens[k]
            cuts=sorted({*I0,*(q for q in (test_radius,d[k]-test_radius) if I0[0]<q<I0[1])})
            hist=defaultdict(F)
            atoms=[]
            for a0,b0 in zip(cuts,cuts[1:]):
                x=(a0+b0)/2
                label=(int(x>=test_radius),int(x<=d[k]-test_radius))
                hist[label]+=(b0-a0)/length(I0)
                atoms.append((label,b0-a0))
            l=length(section(I0,(test_radius,I0[1])))/length(I0)
            r=length(section(I0,(I0[0],d[k]-test_radius)))/length(I0)
            both=length(section(I0,(test_radius,d[k]-test_radius)))/length(I0)
            assert all(hist[key]==w for key,w in weights(l,r,both).items())
            tables.append(hist)
            choices.append(atoms)
        fraction=count_gate(tables,needed)
        via_cuts=ss(prod(row[1] for row in word) for word in product(*choices)
                    if all(sum(row[0][j] for row in word)>=needed[j] for j in (0,1)))
        via_cuts*=prod(length(i) for i in lens[active:])
        assert via_cuts==fraction*lens_volume
        independent=count_gate([
            weights(ss(v for (i,j),v in t.items() if i),ss(v for (i,j),v in t.items() if j),
                    ss(v for (i,j),v in t.items() if i)*ss(v for (i,j),v in t.items() if j))
            for t in tables],needed)
        return {"positive_lens_volume":lens_volume,"actual_common_pass_volume":via_cuts,
                "shared_fraction_within_lens":fraction,"independent_draws_probability_in_two_copies_of_lens":independent,
                "normalized_common_volume_against_full_cube":via_cuts/(2*T)**n,
                "one_axis_relative_W_support_over_T":[x/T for x in lens[0]],
                "same_axis_other_offset_support_over_T":[(x-d[0])/T for x in lens[0]]}

    configs=[("close_both_impossible",(1,)*active,(active,active)),
             ("open_both_possible",(-1,)*active,(active,active))]
    if active>1:
        configs.append(("mixed_count_gate",(1,)+(-1,)*(active-1),(2,2)))
    cases=[]
    seen=[]
    for name,signs,needed in configs:
        y=tuple(-test_radius+sgn*tau for sgn in signs)+(-test_radius,)*(n-active)
        z=tuple(test_radius-sgn*tau for sgn in signs)+(test_radius,)*(n-active)
        Y,Z=box(y,eps),box(z,eps)
        assert all(not volume(intersect(Y,a0))*volume(intersect(Z,b0)) for a0,b0 in seen)
        seen.append((Y,Z))
        assert contains(C[0],Y) and contains(C[3],Z)
        assert all(contains(C[e],Y) and contains(C[e],Z) for e in (1,2))
        by_peak=F(0)
        by_peak_independent=F(0)
        with_d=F(0)
        with_d_independent=F(0)
        via_pooled=F(0)
        via_pooled_d=F(0)
        via_pooled_independent=F(0)
        via_pooled_independent_d=F(0)
        raw=F(0)
        per_middle={}
        for v in (1,2):
            assert all(contains(tuple((hi-T,lo+T) for lo,hi in P),E[v]) for P in (Y,Z))
            first_price=mu(intersect(Y,C[0],C[v]))/marks[0,v]
            second_price=mu(intersect(Z,C[v],C[3]))/marks[v,3]
            old_path=I[0]*I[v]*K[0,v]*(I[3]*K[v,3]/degree[v])*first_price*second_price
            raw+=old_path
            assert old_path>0

            price_tables=[]
            separate=[]
            W_tables=[]
            W_separate=[]
            for j in range(active):
                table,(l,r)=owner_from_prices(Y[j],Z[j],E[v][j])
                second,(L,R)=owner_first(Y[j],Z[j],E[v][j])
                assert table==second and (l,r)==(L,R)
                price_tables.append(table)
                separate.append(weights(l,r,l*r))
                W_tables.append(second)
                W_separate.append(weights(L,R,L*R))
            k=count_gate(price_tables,needed)
            k_independent=count_gate(separate,needed)
            by_peak+=old_path*k
            by_peak_independent+=old_path*k_independent
            with_d+=old_path*k*degree[v]
            with_d_independent+=old_path*k_independent*degree[v]

            # After combining the two price marks at W first, no artificial price/owner
            # weight is inserted. Multiplying the absolute indicator by d cancels d once.
            same_after_switch=count_gate(W_tables,needed)
            independent_after_switch=count_gate(W_separate,needed)
            coefficient=I[0]*I[v]*I[3]*mu(Y)*mu(Z)/(m[0]*m[3]*m[v]**2)
            assert old_path==coefficient/degree[v]
            via_pooled+=coefficient*same_after_switch/degree[v]
            via_pooled_independent+=coefficient*independent_after_switch/degree[v]
            via_pooled_d+=coefficient*same_after_switch
            via_pooled_independent_d+=coefficient*independent_after_switch
            sample=E[v][0]
            tv_y=deviation_mean(Y[0],y[0])/length(sample)
            tv_z=deviation_mean(Z[0],z[0])/length(sample)
            assert max(tv_y,tv_z)<=F(1,128)
            per_middle[v]={"k_shared_owner":k,"k_two_independent_owners":k_independent,
                           "genuine_two_mark_peak_mass":old_path,
                           "price_mixed_axis_TV_bound_to_centered_uniform":[tv_y,tv_z],
                           "true_shared_axis_table":{str(key):w for key,w in price_tables[0].items()},
                           "owner_axis_offset_range_y_at_mark_center":[(x-y[0])/T for x in sample],
                           "owner_axis_offset_range_z_at_mark_center":[(x-z[0])/T for x in sample]}
        assert (by_peak,by_peak_independent,with_d,with_d_independent)==(
            via_pooled,via_pooled_independent,via_pooled_d,via_pooled_independent_d)
        assert 0<=by_peak<by_peak_independent<raw
        exact_lens=lens_measure(y,z,needed)
        if name.startswith("close"):
            assert by_peak==with_d==exact_lens["actual_common_pass_volume"]==0
        else:
            assert by_peak>0 and exact_lens["actual_common_pass_volume"]>0
        cases.append({"price_pattern":name,"y_true_center":y,"z_true_center":z,"truth_price_box_half_side":eps,
                      "number_of_required_hits_by_side":needed,"tested_coordinate_count":active,
                      "true_old_two_price_peak_mass":raw,"shared_owner_accepted_peak_mass":by_peak,
                      "separately_drawn_owner_accepted_peak_mass":by_peak_independent,
                      "shared_owner_weighted_by_original_degree":with_d,
                      "separately_drawn_owner_weighted_by_original_degree":with_d_independent,
                      "positive_central_paths":per_middle,"reference_box_not_true_owner":exact_lens})
    return {"n":n,"a":a,"h":h,"physical_radius_octave":"[1,2), lower end s=1",
            "D_for_central_volume_bucket":D,"R_at_volume_upper_end":R_b,"T=hR":T,
            "true_parent_radii":radii,"true_parent_centers":shifts,
            "actual_nonuniform_product_mu":"period 1/(4n), density 1/2 then 3/2 in each coordinate on [-8,8]",
            "all_true_parent_mass_equals_Lebesgue_volume":True,"true_owners_disjoint":True,
            "old_full_degree_by_central_history":degree,
            "diagnostic_gate":"left offset >= (3/2)s/T, right offset <= -(3/2)s/T, each on its prescribed number of active axes; both offsets affine maps of the same W",
            "conditional_offset_law":"both coordinate marginals at fixed y,z are genuine scaled uniforms; their difference is (z-y)/T. After averaging the true prices, the marginal TV bounds average the exact TV of two translates of a uniform interval.",
            "cases":cases,"scope":"actual finite product peak and diagnostic coordinate gates; lens clip at price centers has its own Lebesgue normalization"}


if __name__=="__main__":
    print(json.dumps({"python":sys.version.split()[0],"arithmetic":"Fraction",
                      "command":"python -B owners781.py","dimensions":[certify(n) for n in (2,4,8)]},
                     sort_keys=True,indent=2,default=str))
