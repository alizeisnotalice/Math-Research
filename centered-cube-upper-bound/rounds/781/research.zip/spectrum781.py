"""Finite checks for the common-receiver and source-rank arguments in round 781."""
from fractions import Fraction as F
import json
from math import factorial
import sys

import flint
from flint import arb, ctx
import sympy as sp

ctx.prec = 256


def integer_enclosure(x):
    value = x.unique_fmpz()
    assert value is not None, x
    return int(value)


def coordinates_and_lower_model(n):
    ell = arb(n + 2).log()
    theta = arb(n) / ell
    z = 2 + (theta - 1) * (arb(4) / n + arb(4) / n**2)
    old = integer_enclosure(((n * z.log() + 4 * ell) / theta.log()).ceil())
    m = 3
    while F((n + 1)**2 * 3**m, factorial(m)) > 1:
        m += 1
    m_root = 3
    while ((n + 1) * 3**m_root)**2 > n * factorial(m_root)**2:
        m_root += 1
    m_polylog = 3
    while True:
        value = (arb(n + 1) * 3**m_polylog / factorial(m_polylog)) * ell**2
        if value < 1:
            break
        assert value > 1
        m_polylog += 1
    k = max(48, integer_enclosure(((arb(3) * n / (74 * arb(n).log())).sqrt() + arb(1) / 2).floor()) - 20)
    # A whole atom stratum on each side is counted with its true atomic mass.
    p = F(2 * (k // 2)**2, (k + 20)**2)
    assert p > F(1, 16)
    exponent = -2 * n * (p - F(1, 16))**2
    return {"n":n, "R779_opposite_face_count":old,
            "first_m_for_bound_1_over_n_plus_1":m,
            "first_m_for_sqrt_n_budget":m_root,
            "first_m_for_bound_1_over_log_squared":m_polylog,
            "original_wide_window_K":k, "atom_same_half_lower":str(p),
            "log_probability_lower_tail_upper":str(exponent)}


def maximum_matching(graph):
    n = len(graph)
    partner_right = [-1] * n

    def augment(left, seen):
        for right in graph[left]:
            if right in seen:
                continue
            seen.add(right)
            old = partner_right[right]
            if old == -1 or augment(old, seen):
                partner_right[right] = left
                return True
        return False

    for left in range(n):
        augment(left, set())
    partner_left = [-1] * n
    for right, left in enumerate(partner_right):
        if left != -1:
            partner_left[left] = right
    if -1 not in partner_left:
        assert sorted(partner_left) == list(range(n))
        return partner_left, None
    # Alternating reachability gives a Hall obstruction, independently verified below.
    lefts = {i for i, right in enumerate(partner_left) if right == -1}
    todo = list(lefts)
    rights = set()
    while todo:
        left = todo.pop()
        for right in graph[left]:
            if right in rights:
                continue
            rights.add(right)
            old = partner_right[right]
            assert old != -1
            if old not in lefts:
                lefts.add(old)
                todo.append(old)
    assert set().union(*(set(graph[i]) for i in lefts)) == rights
    assert len(rights) < len(lefts)
    return None, (sorted(lefts), sorted(rights))


def exact_rank_matching(n, ratio):
    errors = [abs(F(2 * j, n) - ratio) for j in range(n)]
    levels = sorted(set(errors))

    def graph(epsilon):
        return [[j for j in range(n) if errors[abs(i - j)] <= epsilon] for i in range(n)]

    lo, hi = -1, len(levels) - 1
    while hi - lo > 1:
        mid = (lo + hi) // 2
        if maximum_matching(graph(levels[mid]))[0] is not None:
            hi = mid
        else:
            lo = mid
    perm, _ = maximum_matching(graph(levels[hi]))
    assert max(errors[abs(i - j)] for i, j in enumerate(perm)) == levels[hi]
    # Check the strict lower graph, including when hi is the first listed level.
    lower = [[j for j in range(n) if errors[abs(i - j)] < levels[hi]] for i in range(n)]
    _, cert = maximum_matching(lower)
    assert cert is not None
    return {"n":n, "a_over_T":str(ratio), "min_band_halfwidth":str(levels[hi]),
            "permutation":perm, "lower_Hall_left":cert[0], "lower_Hall_neighbors":cert[1]}


def scale_counts(n):
    h = 1 + arb(1) / (32 * n)
    eps = (arb(n + 2).log() / n).sqrt()
    log2 = arb(2).log()
    radii = [h * ((j + 1) * log2 / n).exp() for j in range(n)]
    out = []
    for wave in (F(1), F(2, 3), F(1, 2), F(5, 11)):
        count = dist_count = 0
        for t in radii:
            x = t * wave.denominator / wave.numerator
            phase = arb.pi() * x
            sinc = abs(phase.sin() / phase)
            accepted = sinc < 2 * eps
            assert accepted or sinc > 2 * eps
            assert 0 < x and x < 6
            radius = arb.pi() * eps * x
            distances = [abs(x - j) for j in range(8)]
            possible = any(d < radius for d in distances)
            assert possible or all(d > radius for d in distances)
            assert not accepted or possible
            count += int(accepted)
            dist_count += int(possible)
        out.append({"n":n,"a_over_R":str(wave),"sinc_pass_bins":count,
                    "necessary_distance_pass_bins":dist_count,"all_bins":n})
    return out


def rank_cost():
    x = sp.symbols("x", positive=True)
    t, mass = sp.symbols("t mass", positive=True)
    denom = t * (2 + sp.log(mass / t))**2
    assert sp.simplify(sp.diff(denom, t) - (2 + sp.log(mass / t)) * sp.log(mass / t)) == 0
    assert sp.integrate(2 / (2 + x)**2, (x, 0, sp.oo)) == 1
    # Overlapping physical source intervals, Lebesgue measure.
    families = [[(0, 8), (5, 12), (4, 10), (10, 16), (1, 16)],
                [(0, 2), (1, 6), (3, 4), (4, 13), (0, 12), (5, 15), (0, 16)]]
    results = []
    for intervals in families:
        covered = set()
        counts = []
        for a, b in intervals:
            old = len(covered)
            covered.update(range(a, b))
            counts.append((len(covered) - old, len(covered)))
        total = len(covered)
        integral = sum(2 * arb(new) / (size * (2 + (arb(total) / size).log())**2)
                       for new, size in counts)
        assert integral > 0 and integral < 1
        results.append({"intervals":intervals,"prefix_added_and_size":counts,
                        "source_integral":str(integral),"sum_separate":sum(b-a for a,b in intervals)})
    return results


def main():
    ns = (64, 256, 1024, 4096, 2**16, 2**24, 2**40, 2**80)
    out = {"python":sys.version.split()[0], "python_flint":flint.__version__,
           "sympy":sp.__version__, "arb_precision_bits":ctx.prec,
           "lower_input_sha256":"1edcae8168482f25991581deceb58dcdf59a807be84bc3464cce75f9530b8243",
           "face_and_lower_model":[coordinates_and_lower_model(n) for n in ns],
           "rank_matching":[exact_rank_matching(n, a) for n in (12,24,48,96)
                            for a in (F(1),F(1,2),F(2,3),F(3,4),F(4,5))],
           "scale_counts":[row for n in (256,1024,4096,16384) for row in scale_counts(n)],
           "source_rank":rank_cost(),
           "scope":"Scale counts use the diagnostic threshold eps=sqrt(log(n+2)/n). Rank certificates refer only to the indicated finite grid, and the two independent lower-model prices are reference prices."}
    print(json.dumps(out,sort_keys=True,indent=2))


if __name__ == "__main__":
    main()
