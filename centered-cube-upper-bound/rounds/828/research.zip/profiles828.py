"""Compute true anchored-tail and receiver tail probabilities; record the flat-volume exponents."""
import argparse
from concurrent.futures import ProcessPoolExecutor
from fractions import Fraction as F
from hashlib import sha256
from math import comb
from pathlib import Path
from flint import arb, ctx
import stratified828 as source

DIGITS = 10**12
RUN_DIMS = (32, 128, 512, 1024, 8192, 2**19, 2**30)


def ar(value):
    value = F(value)
    return arb(value.numerator) / value.denominator


def ceiling(value):
    return -((-value.numerator) // value.denominator)


def enclosing(value):
    if value.lower() > 1 or value.upper() < 0:
        raise ArithmeticError("Probability interval missing [0,1]")
    low = max(0, int((value * DIGITS).lower().floor().unique_fmpz()))
    high = min(DIGITS, int((value * DIGITS).upper().ceil().unique_fmpz()))
    return low, high


def exact_lower_tail(probs, repeat, threshold):
    # Exact coefficients below threshold.  P=0 or 1 is handled without division.
    data = [F(1)] + [F(0)]*(threshold-1)
    for p in probs:
        coefs = [comb(repeat, j)*p**j*(1-p)**(repeat-j)
                 for j in range(min(repeat,threshold-1)+1)]
        nxt = [F(0)]*threshold
        for i, vi in enumerate(data):
            if vi:
                for j, vj in enumerate(coefs[:threshold-i]):
                    nxt[i+j] += vi*vj
        data = nxt
    return sum(data)


def single(job):
    model, label, probs = job
    assert len(probs)==4 and sum(probs)/4 >= F(111,1000)
    out = []
    for n in RUN_DIMS:
        threshold = (n+13)//14
        copies = n//4
        exact = exact_lower_tail(probs,copies,threshold) if n <= 128 else None
        boxes = []
        for bits in (192,320):
            ctx.prec = bits
            error = ar(F(3,2))**(threshold-1)
            for p in probs:
                error *= ar(1-p/3)**copies
            h = 1+ar(F(1,32*n))
            alpha = 1-(2*ar(F(63,64))/h-1)*(-arb(2).log()/n).exp()
            geom = (1+alpha)**n/arb(2)**threshold
            if n >= 512:
                assert error < (-arb(n)/125).exp()
                assert geom < (-arb(n)/64).exp()
            bound = [max(0,int((error*DIGITS).upper().ceil().unique_fmpz())) if error.upper()<1 else DIGITS,
                     max(0,int((geom*DIGITS).upper().ceil().unique_fmpz())) if geom.upper()<1 else DIGITS]
            if exact is not None:
                lo, hi = enclosing(ar(exact))
                assert lo <= min(hi,bound[0])
                bound.extend([lo,hi])
            boxes.append(bound)
        out.append((n, *[min(boxes[0][j],boxes[1][j]) if j!=2 else max(boxes[0][j],boxes[1][j])
                          for j in range(len(boxes[0]))]))
    return model, label, out


def dimension_price(n):
    ctx.prec = 384
    v = arb(n)
    ell = arb(n+2).log()
    jump = v.sqrt()*ell**8
    sigma = (-jump/v).exp()
    b = (1+1/(32*v))*sigma+(1-sigma)/4
    # A conservative explicit rank meeting r log(8en/r) <= J/12.
    rank = int((jump/(48*(8*arb(1).exp()*v/jump).log())).lower().floor().unique_fmpz())
    if rank < 1 or jump/v >= ar(F(1,10)):
        return "outside-asymptotic-parameter-range"
    entropy = arb(rank)*(8*arb(1).exp()*v/arb(rank)).log()
    assert entropy <= jump/12
    log_budget = v*b.log()+entropy + jump/12
    assert log_budget <= -jump/2
    return f"rank={rank} log-volume/J={str(log_budget/jump)}"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--r814", required=True, type=Path)
    parser.add_argument("--r827", required=True, type=Path)
    parser.add_argument("--jobs", type=int, default=6)
    args = parser.parse_args()
    assert 1 <= args.jobs <= 12
    source.init_worker(args.r827)
    stages = [(name,source.RANGE.prepare(stage)) for name,stage in source.RANGE.read_stages(args.r814)]
    work = []
    for name, model in stages:
        _, _, _, rows = source.extreme_case((name,model,9,F(63,64)))
        for i, row in enumerate(rows):
            work.append((name,i,row[1]))
    digest = sha256()
    worst = {}
    with ProcessPoolExecutor(max_workers=args.jobs) as pool:
        for name, index, results in pool.map(single,work):
            for record in results:
                n, miss, geom, *exact = record
                scores = worst.setdefault((name,n),[0,0,0])
                scores[0] = max(miss,scores[0])
                scores[1] = max(geom,scores[1])
                if exact:
                    scores[2] = max(exact[1], scores[2])
                digest.update((repr((name,index,*record))+"\n").encode())
    for (name,n),(miss,geom,exact) in sorted(worst.items()):
        print(name,n,"max actual miss upper /1e12",miss,"central volume tail upper /1e12",geom,
              "exact-miss upper /1e12",exact if n<=128 else "not enumerated")
    print("68 rows, 7 dimensions, actual anchored counts and independent receive bounds:",
          digest.hexdigest())
    for n in (2**19,10**30,10**40,10**64,10**96,10**128):
        print("Steiner",n,dimension_price(n))
    print("PASS R828 receiver profiles and affine projection budgets")


if __name__ == "__main__":
    main()
