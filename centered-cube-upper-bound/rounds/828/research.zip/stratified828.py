"""Exact axis subsampling on the pinned R814 source laws used by R827."""

import argparse
from concurrent.futures import ProcessPoolExecutor
from fractions import Fraction as F
from functools import lru_cache
from hashlib import sha256
from itertools import combinations, product
from math import comb, exp, lcm, log
from pathlib import Path
import sys
from types import ModuleType
from zipfile import ZipFile

PIN827 = "e17868416d79203cec8b3d8dd32609505c55b4ecc5da6610c5f7f4f568d48996"
COUNTS = (2, 3, 5, 9)
CUTS = tuple(map(F, ("1/4", "1/2", "3/4", "7/8", "15/16", "63/64")))
DIMS = (32, 512, 8192, 2**19)
SAMPLES = (1, 4, 8, 16, 32, 64)
GRID = 1 << 4096


def load827(archive_path):
    assert sha256(archive_path.read_bytes()).hexdigest() == PIN827
    with ZipFile(archive_path) as archive:
        for name in ("comb827", "ranges827"):
            module = ModuleType(name)
            module.__file__ = str(archive_path / (name + ".py"))
            sys.modules[name] = module
            source = archive.read(name + ".py")
            exec(compile(source, module.__file__, "exec"), module.__dict__)
    return sys.modules["ranges827"]


def init_worker(archive_path):
    global RANGE
    RANGE = load827(archive_path)


def pair_tail(left, right, threshold):
    """Integrate two rectangles directly with the triangular ramp antiderivative."""
    def one_sign(first, second):
        area = F(0)
        for (a, b, fa), (c, d, fb) in product(first, second):
            def ramp(x):
                return max(F(0), x - threshold)**2
            area += fa*fb*(ramp(d-a) - ramp(d-b) - ramp(c-a) + ramp(c-b))/2
        return area
    return one_sign(left, right) + one_sign(right, left)


@lru_cache(maxsize=16)
def choose_table(n, d):
    return tuple(comb(n, j) for j in range(d + 1))


def grouped_elementary(prob_numerators, copies, limit):
    coefficients = [1]
    for numerator in prob_numerators:
        if not numerator:
            continue
        step = min(copies, limit)
        group = [choose*numerator**j for j, choose in enumerate(choose_table(copies, step))]
        result = [0] * (min(limit, len(coefficients) + step - 1) + 1)
        for i, old in enumerate(coefficients):
            for j, value in enumerate(group[:limit-i+1]):
                result[i+j] += old*value
        coefficients = result
    return coefficients + [0] * (limit + 1 - len(coefficients))


@lru_cache(maxsize=64)
def mixed_choices(n, d, h):
    return tuple((-1)**(j-h)*comb(j-1, h-1)*comb(n-j, d-j) for j in range(h, d+1))


def hit_tail(coefficients, powers, population, draws, hits):
    numerator = sum(mixed_choices(population, draws, hits)[j-hits] *
                    coefficients[j]*powers[draws-j] for j in range(hits, draws+1))
    denominator = comb(population, draws) * powers[draws]
    assert 0 <= numerator <= denominator
    return numerator, denominator


def exact_sanity():
    """Exhaust all axis samples and all hit outcomes on eight axes."""
    demos = ((0, 1, 3, 5), (2, 2, 2, 2))
    for numerators in demos:
        denominator = 5
        copies = 2
        population = 8
        axis = numerators * copies
        coefs = grouped_elementary(numerators, copies, population)
        powers = [denominator**d for d in range(population+1)]
        for d in range(1, population+1):
            counts = [0] * (d+1)
            for sample in combinations(axis, d):
                for outcome in product((0, 1), repeat=d):
                    weight = 1
                    for p, indicator in zip(sample, outcome):
                        weight *= p if indicator else denominator-p
                    counts[sum(outcome)] += weight
            assert sum(counts) == powers[d]*comb(population, d)
            for h in range(1, d+1):
                assert hit_tail(coefs, powers, population, d, h)[0] == sum(counts[h:])


def digest_ints(digest, values):
    for value in values:
        value = value.to_bytes(max(1, (value.bit_length()+7)//8), "big")
        digest.update(len(value).to_bytes(8, "big"))
        digest.update(value)


def add_weight(sums, value, weight):
    numerator, denominator = value
    floor, remainder = divmod(GRID*numerator*weight.numerator, denominator*weight.denominator)
    sums[0] += floor
    sums[1] += floor + bool(remainder)


def display(interval, root=1):
    """Display only. Comparisons and certified transcript are integer-only."""
    lower, upper = interval
    if upper == 0:
        return "0"
    marks = []
    for v in (lower, upper):
        marks.append(0.0 if v == 0 else exp((log(v)-log(GRID))/root))
    if format(marks[0], ".7g") == format(marks[1], ".7g"):
        return format(marks[0], ".7g")
    return "[" + ",".join(format(x, ".7g") for x in marks) + "]"


def beats(value, fee):
    pm, pd = value
    return pm*fee.denominator > pd*fee.numerator


def run_case(task):
    model_name, (total, rows), count, cut = task
    rng = RANGE.range_probability
    log_hash = sha256()
    results = {}
    probabilities = []
    weights = []
    for side, mass, axes in rows:
        threshold = cut*side
        p = tuple(rng(l, r, m, threshold, count) for l, r, m in axes)
        if count == 2:
            assert p == tuple(pair_tail(l, r, threshold) for l, r, _ in axes)
        assert len(p) == 4
        probabilities.append(p)
        weights.append(mass/total)
        digest_ints(log_hash, (side.numerator, side.denominator, mass.numerator, mass.denominator))
        for v in p:
            digest_ints(log_hash, (v.numerator, v.denominator))

    for dimension in DIMS:
        copies = dimension//4
        sizes = [d for d in SAMPLES if d <= dimension]
        results_for_n = {d: {} for d in sizes}
        for d, cell in results_for_n.items():
            cell["random"] = [0, 0]
            cell["half"] = [0, 0]
            cell["classes"] = [[0, 0] for _ in range(4)] if d <= copies else []
            cell["oracle"] = [0, 0] if d <= copies else []
            cell["positive"] = F(0)
            cell["passes"] = [F(0)] * 5
            cell["anchor_passes"] = [F(0)] * 5
        for p, weight in zip(probabilities, weights):
            denominator = lcm(*(prob.denominator for prob in p))
            a = tuple(prob.numerator*(denominator//prob.denominator) for prob in p)
            powers = tuple(denominator**j for j in range(max(sizes)+1))
            e = grouped_elementary(a, copies, max(sizes))
            for d, cell in results_for_n.items():
                # Compare exact owner-corrected relative remaining width.
                relative_gap = 1-cut/(1+F(1, 32*dimension))
                first_moment_fee = (3**(count-1)*relative_gap)**d
                # At a true receiving center, direct anchoring in a dyadic volume
                # bin of side ratio 2^(1/n) costs at most the following rational base.
                anchor_fee = (2*(1-cut) + (2*cut-1)/dimension)**d if count == 2 and cut > F(1,2) else None
                all_hit = hit_tail(e, powers, dimension, d, d)
                half_hit = hit_tail(e, powers, dimension, d, (d+1)//2)
                assert all_hit[0] <= half_hit[0]
                # Maclaurin, equality at d=1, and all-hit lower bound from
                # the smallest probability are independent consistency checks.
                lo, hi = F(min(a), denominator)**d, F(sum(a), 4*denominator)**d
                assert lo.numerator*all_hit[1] <= all_hit[0]*lo.denominator
                assert all_hit[0]*hi.denominator <= hi.numerator*all_hit[1]
                if d == 1:
                    assert all_hit[0]*hi.denominator == hi.numerator*all_hit[1]
                for key, value in (("random", all_hit), ("half", half_hit)):
                    add_weight(cell[key], value, weight)
                if all_hit[0]:
                    cell["positive"] += weight
                if beats(all_hit, first_moment_fee):
                    cell["passes"][0] += weight
                if anchor_fee is not None and beats(all_hit, anchor_fee):
                    cell["anchor_passes"][0] += weight
                digest_ints(log_hash, (*all_hit, half_hit[0]))
                if d <= copies:
                    for axis, value in enumerate(a):
                        fixed = value**d, powers[d]
                        add_weight(cell["classes"][axis], fixed, weight)
                        if beats(fixed, first_moment_fee):
                            cell["passes"][axis+1] += weight
                        if anchor_fee is not None and beats(fixed, anchor_fee):
                            cell["anchor_passes"][axis+1] += weight
                    add_weight(cell["oracle"], (max(a)**d, powers[d]), weight)
        for d, cell in results_for_n.items():
            assert all(0 <= lo <= hi <= GRID for lo, hi in
                       [cell["random"], cell["half"], *cell["classes"]])
            assert cell["random"][1] <= cell["half"][1]+len(rows)
            if cell["classes"]:
                assert cell["random"][1] <= cell["oracle"][1]+len(rows)
                for interval in cell["classes"]:
                    assert interval[1] <= cell["oracle"][1]+len(rows)
            for value in (*cell["passes"], *cell["anchor_passes"]):
                digest_ints(log_hash, (value.numerator, value.denominator))
            results[dimension, d] = cell
    return model_name, count, cut, log_hash.hexdigest(), probabilities, results


@lru_cache(maxsize=32768)
def extremal_minimum(left, right, middle, threshold, count):
    """Probability each designated observation is minimum and the span passes."""
    counts = {}
    for law, multiplicity in ((left, 1), (right, 1), (middle, count-2)):
        if multiplicity:
            counts[law] = counts.get(law, 0) + multiplicity
    laws = tuple(counts)
    maximum = max(b for law in laws for a, b, w in law)
    breaks = sorted({endpoint-offset for law in laws for a, b, w in law
                     for endpoint in (a,b) for offset in (0,threshold)})
    probabilities = [F(0)] * len(laws)
    for a, b in zip(breaks, breaks[1:]):
        densities = [RANGE.density_at(law, (a+b)/2) for law in laws]
        if not any(densities):
            continue
        survival = [(RANGE.interval_share(law, a, maximum),
                     RANGE.interval_share(law, b, maximum)) for law in laws]
        short_span = [(RANGE.interval_share(law, a, a+threshold),
                       RANGE.interval_share(law, b, b+threshold)) for law in laws]
        for i, density in enumerate(densities):
            if density:
                exponents = tuple(counts[law] - (i == j) for j, law in enumerate(laws))
                estimates = [RANGE.average_linears(tuple((lo, hi, e)
                             for (lo, hi), e in zip(intervals, exponents)))
                             for intervals in (survival, short_span)]
                assert estimates[0] >= estimates[1]
                probabilities[i] += (b-a)*density*(estimates[0]-estimates[1])
    return tuple(probabilities[laws.index(law)] for law in
                 ((left,right) if count == 2 else (left,right,middle)))


def reflect(law):
    return tuple((-b,-a,w) for a,b,w in reversed(law))


def extreme_case(task):
    name, (_, rows), count, cut = task
    out = []
    for side, _, axes in rows:
        size = side*cut
        per_axis = []
        for left, right, middle in axes:
            direct = extremal_minimum(left, right, middle, size, count)
            reverse = extremal_minimum(reflect(left), reflect(right), reflect(middle), size, count)
            coeff = (1,1) if count == 2 else (1,1,count-2)
            proof = RANGE.range_probability(left, right, middle, size, count)
            assert sum(p*m for p,m in zip(direct,coeff)) == proof
            assert sum(p*m for p,m in zip(reverse,coeff)) == proof
            per_axis.append(tuple(a+b for a,b in zip(direct,reverse)))
        out.append(tuple(zip(*per_axis)))
    return name, count, cut, out


def check_extreme_classes(models, pool):
    tests = [(name, model, count, cut)
             for (name, model), count, cut in product(models, COUNTS, CUTS) if cut > F(1,2)]
    by_gate = {(name, count, cut): rows
               for name, count, cut, rows in pool.map(extreme_case, tests)}
    print("Shared designated extreme anchors, including all extra-probe choices")
    digest = sha256()
    for name, (total, rows) in models:
        for dimension in (32, 2**19):
            h0 = 1+F(1,32*dimension)
            fees = {cut: 2*(1-cut/h0)+(2*cut/h0-1)/dimension for cut in CUTS if cut > F(1,2)}
            right_gates = {}
            for model, _, k, c in tests:
                if model == name:
                    p_rows = [(sum(r[1])/4, r[1]) for r in by_gate[name,k,c]]
                    right_gates[k,c] = p_rows
            gate = max(right_gates,
                       key=lambda g: min(p for p, _ in right_gates[g])/fees[g[1]])
            min_p = min(p for p, _ in right_gates[gate])
            min_gain = min_p/fees[gate[1]]
            assert gate == (9, F(63,64)) and min_p >= F(111,1000)
            if dimension >= 512:
                assert F(101,1000) > 3*fees[gate[1]]
            digest_ints(digest, (gate[0], gate[1].numerator, gate[1].denominator,
                                 min_gain.numerator, min_gain.denominator))
            print("RIGHT-GATE", name, dimension, "k", gate[0], "c", gate[1],
                  "min-mean", format(float(min_p), ".9g"),
                  "fee", format(float(fees[gate[1]]), ".9g"),
                  "min-ratio", format(float(min_gain), ".9g"), flush=True)
            passed = [F(0)] * 9
            counts = [0] * 9
            for r, (_, mass, _) in enumerate(rows):
                gains = [F(0)] * 9
                for _, _, k, c in (test for test in tests if test[0] == name):
                    axis_laws = by_gate[name,k,c][r]
                    for anchor, prob in enumerate(axis_laws):
                        axis_mean = sum(prob)/4
                        gains[anchor] = max(gains[anchor], axis_mean/fees[c])
                        for axis, value in enumerate(prob):
                            gains[axis+3] = max(gains[axis+3], value/fees[c])
                gains[7] = max(gains[3:7])
                gains[8] = max(gains[:3])
                digest_ints(digest, (dimension, r))
                for j, gain in enumerate(gains):
                    digest_ints(digest, (gain.numerator, gain.denominator))
                    if gain > 1:
                        passed[j] += mass/total
                        counts[j] += 1
            print("EXTREME", name, dimension, "random-anchors(left,right,central)+four-fixed+fixed-oracle+random-oracle",
                  ",".join(format(float(x), ".9g") for x in passed), "counts", counts, flush=True)
    print("EXTREME exact-transcript SHA-256", digest.hexdigest(), flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--r814", required=True, type=Path)
    parser.add_argument("--r827", required=True, type=Path)
    parser.add_argument("--jobs", default=4, type=int, choices=range(1, 7))
    parser.add_argument("--full", action="store_true")
    parser.add_argument("--extremes", action="store_true", help="only run designated-extreme anchor comparison")
    options = parser.parse_args()
    assert __debug__, "Run with assertions enabled"
    ranges = load827(options.r827)
    exact_sanity()
    ranges.uniform_check()
    models = [(name, ranges.prepare(stage)) for name, stage in ranges.read_stages(options.r814)]
    if options.extremes:
        with ProcessPoolExecutor(max_workers=options.jobs, initializer=init_worker,
                                 initargs=(options.r827,)) as pool:
            check_extreme_classes(models, pool)
        return
    tasks = [(name, model, count, cut) for (name, model), count, cut in product(models, COUNTS, CUTS)]
    transcripts = sha256()
    ptable = {}
    print("Pinned archives", ranges.PIN, PIN827, flush=True)
    print("Columns n k c d random-root half-root class-roots oracle-root positive-mass "
          "mass-beating-fee(random,classes) fee-root log-fee-root anchor-mass(random,classes)", flush=True)
    with ProcessPoolExecutor(max_workers=options.jobs, initializer=init_worker,
                             initargs=(options.r827,)) as pool:
        for name, count, cut, digest, probabilities, results in pool.map(run_case, tasks):
            transcripts.update(f"{name} {count} {cut} {digest}\n".encode("ascii"))
            ptable[name, count, cut] = probabilities
            ncases = len(results)
            maxp = max(max(p) for p in probabilities)
            maxavg = max(sum(p)/4 for p in probabilities)
            print("CASE", name, count, cut, digest, "maxp", format(float(maxp), ".9g"),
                  "maxavg", format(float(maxavg), ".9g"), "grid-cells", ncases, flush=True)
            for (dimension, d), cell in results.items():
                if not options.full and (dimension, d) != (DIMS[-1], SAMPLES[-1]):
                    continue
                fee = 3**(count-1)*(1-cut/(1+F(1, 32*dimension)))
                print("CELL", name, dimension, count, cut, d,
                      display(cell["random"], d), display(cell["half"], d),
                      ",".join(display(item, d) for item in cell["classes"]) or "-",
                      display(cell["oracle"], d) if cell["oracle"] else "-",
                      format(float(cell["positive"]), ".7g"),
                      ",".join(format(float(value), ".7g") for value in
                               cell["passes"][:5 if cell["classes"] else 1]),
                      format(float(fee), ".8g"), format(log(float(fee)), ".8g"),
                      ",".join(format(float(value), ".7g") for value in
                               cell["anchor_passes"][:5 if cell["classes"] else 1])
                      if count == 2 and cut > F(1, 2) else "-", flush=True)
    for name, (total, rows) in models:
        selections = [(count, cut) for count, cut in product(COUNTS, CUTS)]
        for fee_name, fees in (
            ("stretch", {(k,c): 3**(k-1)*(1-c) for k,c in selections}),
            ("anchor-limit", {(k,c): 2*(1-c) for k,c in selections if k == 2 and c > F(1,2)}),
            ("anchor-dyadic-32", {(k,c): 2*(1-c)+(2*c-1)/32 for k,c in selections
                                  if k == 2 and c > F(1,2)}),
        ):
            paid = [F(0)] * 6
            paid_counts = [0] * 6
            row_cert = sha256()
            for i, (_, mass, _) in enumerate(rows):
                p_by_gate = {gate: ptable[(name, *gate)][i] for gate in fees}
                mean_gain = max(sum(p)/4/fees[g] for g, p in p_by_gate.items())
                class_gains = [max(p[j]/fees[g] for g, p in p_by_gate.items()) for j in range(4)]
                gains = [mean_gain, *class_gains, max(class_gains)]
                for j, gain in enumerate(gains):
                    if gain > 1:
                        paid[j] += mass/total
                        paid_counts[j] += 1
                    digest_ints(row_cert, (gain.numerator, gain.denominator))
            print("UNION", name, fee_name, "random+four-fixed+oracle",
                  ",".join(format(float(v), ".9g") for v in paid), "counts", paid_counts,
                  "exact-ratio-sha256", row_cert.hexdigest())
            transcripts.update(row_cert.digest())
        for count, cut in selections:
            for earlier, later, increasing in (
                ((name, COUNTS[COUNTS.index(count)-1], cut), (name, count, cut), count != COUNTS[0]),
                ((name, count, cut), (name, count, CUTS[CUTS.index(cut)-1]), cut != CUTS[0]),
            ):
                if increasing:
                    assert all(a <= b for x, y in zip(ptable[earlier], ptable[later])
                               for a, b in zip(x, y))
    print("PASS", len(tasks)*34*4, "rational single-axis integrals;",
          sum(d<=n for n,d in product(DIMS,SAMPLES))*len(tasks)*34,
          "rational without-replacement row cells; weighted masses use 2^-4096 intervals.")
    print("Transcript SHA-256", transcripts.hexdigest())


if __name__ == "__main__":
    main()
