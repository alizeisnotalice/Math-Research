"""Exact per-coordinate exchange probabilities on R814 continuous sources.

Given one actual root (t,u,g), z,q are independently drawn from the *true*
truncated product-comb mu on A_t∩A_u and A_t∩A_g. The 16 virtual exchanges
are tested against physical parents; virtual points are not declared actual
records. Label exchange is one global u<->g swap per exchanged pair.
"""

import argparse, json, zipfile
from fractions import Fraction as F
from itertools import product, combinations
from math import prod, comb


def run(name, stage, ns):
    assert stage["dimension"] == 4
    parents = {p["id"]: p for p in stage["parents"]}
    wide = F(stage["density"]["bump_half_width"])
    total = F(stage["benchmarks"]["cross"]["mother"])
    roots = stage["roots_cross"]
    assert (
        len(roots) == 34
        and sum(len(r["z_masks"]) * len(r["q_masks"]) for r in roots) == 230
    )
    sums = {k: {"plain": F(0), "either": F(0)} for k in range(5)}
    full_plain = full_either = F(0)
    for root in roots:
        t, u, g = (parents[root[k]] for k in ("t", "u", "g"))
        probabilities = []
        lm = rm = F(1)
        for j in range(4):
            T = tuple(map(F, t["box"][j]))
            U = tuple(map(F, u["box"][j]))
            G = tuple(map(F, g["box"][j]))
            left = (max(T[0], U[0]), min(T[1], U[1]))
            right = (max(T[0], G[0]), min(T[1], G[1]))
            both = (max(T[0], U[0], G[0]), min(T[1], U[1], G[1]))
            zl = ns["interval_mass"](*left, wide)
            qr = ns["interval_mass"](*right, wide)
            cross = ns["interval_mass"](*both, wide)
            assert zl > 0 and qr > 0 and 0 <= cross <= min(zl, qr)
            lm *= zl
            rm *= qr
            probabilities.append(cross * cross / (zl * qr))
        weight = F(root["root_mass"]) / total
        assert F(root["coefficient"]) * lm * rm == F(root["root_mass"])
        allgood = prod(probabilities)
        # All 16 masks can be reassigned with the original labels iff all
        # four axes are good. If each exchanged pair may use ONE global label
        # reversal, all masks are feasible iff <=1 axis is bad.
        cluster_all = allgood + sum(
            (
                (1 - probabilities[i])
                * prod(probabilities[j] for j in range(4) if j != i)
                for i in range(4)
            ),
            F(0),
        )
        assert allgood <= cluster_all <= 1
        full_plain += weight * allgood
        full_either += weight * cluster_all
        row = []
        for k in range(5):
            one = two = F(0)
            for subset in combinations(range(4), k):
                S = set(subset)
                plain = prod(probabilities[j] for j in S)
                reverse = prod(probabilities[j] for j in range(4) if j not in S)
                either = plain + reverse - allgood
                assert 0 <= plain <= either <= 1
                one += plain / comb(4, k)
                two += either / comb(4, k)
            sums[k]["plain"] += weight * one
            sums[k]["either"] += weight * two
            row.append((one, two))
        print(
            "ROW",
            name,
            (root["t"], root["u"], root["g"]),
            "root_weight=",
            root["root_mass"],
            "axis_good=",
            list(map(str, probabilities)),
            "plain_by_k=",
            [str(x[0]) for x in row],
            "either_by_k=",
            [str(x[1]) for x in row],
            "all16_plain=",
            allgood,
            "all16_either=",
            cluster_all,
        )
    assert sum((F(r["root_mass"]) for r in roots), F(0)) == total
    print(
        "\nSUMMARY",
        name,
        "total=",
        total,
        "34 true root rows, 230 positive source-cell pairs",
    )
    for k in range(5):
        x, y = sums[k]["plain"], sums[k]["either"]
        print(
            "COUNT",
            k,
            "original_label=",
            float(x),
            "global_swap_allowed=",
            float(y),
            "exact=",
            x,
            y,
        )
    print(
        "ALL16 simultaneous original_label=",
        float(full_plain),
        "one_global_label_choice_for_whole_cluster=",
        float(full_plain),
        "global_swap_per_pair=",
        float(full_either),
        "exact=",
        full_plain,
        full_either,
    )
    print(
        "Actual record weights are used; the 16 exchanged pairs are virtual and do not become real history records. Four-dimensional high-J gate is empty."
    )


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--archive", required=True)
args = parser.parse_args()
with zipfile.ZipFile(args.archive) as z:
    rebuilt = json.loads(z.read("comb814-rebuilt.json"))["stages"][0]
    ns = {"__name__": "archived_comb811"}
    exec(compile(z.read("comb811.py"), "comb811.py", "exec"), ns)
    name, n, h, middle, old = ns["FIXTURES"][-1]
    original = ns["fixture"](name, n, h, middle, old)
    run("original", original, ns)
    run("rebuilt", rebuilt, ns)
print("\nPASS exact rational real-parent exchange and virtual-cluster feasibility")
