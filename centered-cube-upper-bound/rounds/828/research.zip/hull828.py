"""Exact finite hitting sets for R814 4D physical parent boxes.

Optimizations condition on (t,g), so they are geometric diagnostics, not a
claim that an admissible protocol may read hidden t. Source-cluster fractions
are integrated under the actual truncated product-comb source law. Closed-box
hits and strict-interior hits are separately identified.
"""

import argparse, json, zipfile
from collections import defaultdict
from fractions import Fraction as F
from itertools import combinations, product
from math import prod


def box(parent):
    return tuple(tuple(map(F, a)) for a in parent["box"])


def intersect(*boxes):
    return tuple(
        (max(b[j][0] for b in boxes), min(b[j][1] for b in boxes)) for j in range(4)
    )


def nonempty(B):
    return all(a <= b for a, b in B)


def full(B):
    return all(a < b for a, b in B)


def contains(B, p, strict=False):
    return all(a < x < b if strict else a <= x <= b for (a, b), x in zip(B, p))


def volume(B):
    return prod(max(F(0), b - a) for a, b in B)


def candidates(owners, domain):
    # Every maximal hit pattern has a witness at the midpoint of an
    # intersection of some subset of physical closed boxes and domain.
    ids = sorted(owners)
    out = {}
    for n in range(1, len(ids) + 1):
        for subset in combinations(ids, n):
            parts = [owners[x] for x in subset] + ([] if domain is None else [domain])
            B = intersect(*parts)
            if not nonempty(B):
                continue
            point = tuple((a + b) / 2 for a, b in B)
            cover = frozenset(x for x in ids if contains(owners[x], point))
            strict = frozenset(x for x in ids if contains(owners[x], point, True))
            assert cover
            # Equal coverage: prefer an all-interior witness when available.
            quality = (
                len(strict),
                int(domain is None or contains(domain, point, True)),
            )
            if cover not in out or quality > out[cover][1]:
                out[cover] = (point, quality)
    return [(key, value[0]) for key, value in out.items()]


def opt(weights, owners, domain, k):
    cs = candidates(owners, domain)
    if not cs:
        return F(0), (), set()
    best = None
    for count in range(1, k + 1):
        for selection in combinations(cs, count):
            covered = set().union(*(x[0] for x in selection))
            w = sum((weights[u] for u in covered), F(0))
            if best is None or w > best[0]:
                best = (w, tuple(x[1] for x in selection), covered)
    return best


def source_mass(boxes, wide, ns):
    if not full(boxes):
        return F(0)
    return ns["mass"](boxes, wide)


def cluster_probability(Z, points, radius, wide, ns):
    clusters = [tuple((v - radius, v + radius) for v in p) for p in points]
    denom = source_mass(Z, wide, ns)
    assert denom > 0
    hit = sum((source_mass(intersect(Z, C), wide, ns) for C in clusters), F(0))
    if len(clusters) == 2:
        hit -= source_mass(intersect(Z, clusters[0], clusters[1]), wide, ns)
    assert 0 <= hit <= denom
    return hit / denom


def polygon_area(points):
    pts = sorted(set(points))

    def cross(a, b, c):
        return (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])

    lower = []
    for p in pts:
        while len(lower) >= 2 and cross(lower[-2], lower[-1], p) <= 0:
            lower.pop()
        lower.append(p)
    upper = []
    for p in reversed(pts):
        while len(upper) >= 2 and cross(upper[-2], upper[-1], p) <= 0:
            upper.pop()
        upper.append(p)
    hull = lower[:-1] + upper[:-1]
    return (
        abs(
            sum(
                (
                    hull[i][0] * hull[(i + 1) % len(hull)][1]
                    - hull[(i + 1) % len(hull)][0] * hull[i][1]
                    for i in range(len(hull))
                ),
                F(0),
            )
        )
        / 2
    )


def projection_checks():
    # Axis-parallel 4D boxes: independently expand the product and compare
    # to the full sum of coordinate projection volumes.
    for lengths, r in [
        ((F(1), F(2), F(3), F(4)), F(1, 3)),
        ((F(1, 2), F(3, 2), F(2), F(5, 2)), F(1, 5)),
    ]:
        direct = prod(x + 2 * r for x in lengths)
        projection = sum(
            (2 * r) ** (4 - len(S)) * prod(lengths[i] for i in S)
            for k in range(5)
            for S in combinations(range(4), k)
        )
        assert direct == projection
    # 2D non-axis segment plus square, independently compute convex hull and
    # shoelace area from all endpoint+corner sums.
    for v, r in [((F(2), F(1)), F(1, 3)), ((F(-3, 2), F(5, 4)), F(2, 5))]:
        points = [
            (x + c[0], y + c[1])
            for x, y in ((F(0), F(0)), v)
            for c in product((-r, r), repeat=2)
        ]
        actual = polygon_area(points)
        formula = (2 * r) ** 2 + 2 * r * (abs(v[0]) + abs(v[1]))
        assert actual == formula
    print(
        "PROJECTIONS exact: 2 four-dimensional axis boxes; 2 planar non-axis segments via independent convex-hull shoelace"
    )


def run(label, stage, ns):
    parents = {p["id"]: p for p in stage["parents"]}
    wide = F(stage["density"]["bump_half_width"])
    cells = {c["mask"]: F(c["mass"]) for c in stage["cells"]}
    roots = stage["roots_cross"]
    assert (
        len(roots) == 34
        and sum(len(r["z_masks"]) * len(r["q_masks"]) for r in roots) == 230
    )
    M = sum((F(r["root_mass"]) for r in roots), F(0))
    assert M == F(stage["benchmarks"]["cross"]["mother"])
    groups = defaultdict(dict)
    for r in roots:
        assert r["u"] not in groups[r["t"], r["g"]]
        groups[r["t"], r["g"]][r["u"]] = r
    totals = {
        key: F(0)
        for key in (
            "free1",
            "free2",
            "central1",
            "central2",
            "right1",
            "right2",
            "source1",
            "source2",
        )
    }
    print(
        "\nFIXTURE",
        label,
        "root rows=",
        len(roots),
        "source-cell records=230",
        "(t,g) groups=",
        len(groups),
        "raw total=",
        M,
    )
    for (t, g), rows in sorted(groups.items()):
        T = box(parents[t])
        G = box(parents[g])
        domain = intersect(T, G)
        weights = {u: F(r["root_mass"]) for u, r in rows.items()}
        owners = {u: box(parents[u]) for u in rows}
        # For fixed (t,g), the true q-law is mu restricted to T∩G:
        # the u-dependent factors multiply this same unnormalized measure.
        qmass = source_mass(domain, wide, ns)
        assert qmass == sum(
            (cells[q] for q in next(iter(rows.values()))["q_masks"]), F(0)
        )
        q_masks = next(iter(rows.values()))["q_masks"]
        assert all(r["q_masks"] == q_masks for r in rows.values())
        assert all(
            qmass == sum((cells[q] for q in r["q_masks"]), F(0)) for r in rows.values()
        )
        result = {}
        for tag, D in [("free", None), ("central", T), ("right", domain)]:
            for k in (1, 2):
                w, points, covered = opt(weights, owners, D, k)
                result[tag, k] = (w, points, covered)
                totals[tag + str(k)] += w
        # The central-constrained point achieves the same optimum here but
        # avoids a vacuous outside-A_t witness for source-cluster comparison.
        # r=s_t/128; no optimization over all source clusters is claimed.
        radius = F(parents[t]["radius"]) / 128
        for k in (1, 2):
            w, points, covered = result["central", k]
            hit = F(0)
            for u, r in rows.items():
                Z = intersect(T, owners[u])
                p = cluster_probability(Z, points, radius, wide, ns)
                hit += F(r["root_mass"]) * p
            totals["source" + str(k)] += hit
        for k in (1, 2):
            w, points, covered = result["free", k]
            flags = [
                {
                    "p": p,
                    "inside_t": contains(T, p, True),
                    "in_t_closed": contains(T, p),
                    "inside_g": contains(G, p, True),
                    "in_g_closed": contains(G, p),
                    "interior_left": [
                        u for u in sorted(covered) if contains(owners[u], p, True)
                    ],
                    "boundary_left": [
                        u
                        for u in sorted(covered)
                        if contains(owners[u], p) and not contains(owners[u], p, True)
                    ],
                }
                for p in points
            ]
            print(
                "CONSTRAINED",
                label,
                (t, g),
                "k=",
                k,
                "central_points=",
                result["central", k][1],
                "right_points=",
                result["right", k][1],
                "membership_I_interior_B_boundary_O_outside=",
                {
                    tag: [
                        {
                            "point": p,
                            "t": (
                                "I"
                                if contains(T, p, True)
                                else "B" if contains(T, p) else "O"
                            ),
                            "g": (
                                "I"
                                if contains(G, p, True)
                                else "B" if contains(G, p) else "O"
                            ),
                            "left": {
                                u: (
                                    "I"
                                    if contains(owners[u], p, True)
                                    else "B" if contains(owners[u], p) else "O"
                                )
                                for u in owners
                            },
                        }
                        for p in result[tag, k][1]
                    ]
                    for tag in ("central", "right")
                },
            )
            print(
                "GROUP",
                label,
                (t, g),
                "k=",
                k,
                "row_count=",
                len(rows),
                "condition_weight=",
                sum(weights.values(), F(0)),
                "q_contact_mass=",
                qmass,
                "max_weight=",
                w,
                "covered=",
                sorted(covered),
                "witness=",
                flags,
                "source_cluster_radius=",
                radius,
            )
    print(
        "TOTAL",
        label,
        "fractions=",
        {k: float(v / M) for k, v in totals.items()},
        "exact=",
        {k: str(v / M) for k, v in totals.items()},
    )
    print(
        "scope: t,g are frozen physical labels for this finite benchmark; direct-source cluster uses the SAME central-constrained optimal points; lower bounds are exact for that choice, not an optimized cluster upper bound."
    )


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--archive", required=True)
args = parser.parse_args()
projection_checks()
with zipfile.ZipFile(args.archive) as z:
    rebuilt = json.loads(z.read("comb814-rebuilt.json"))["stages"][0]
    ns = {"__name__": "archived_comb811"}
    exec(compile(z.read("comb811.py"), "comb811.py", "exec"), ns)
    name, n, h, middle, old = ns["FIXTURES"][-1]
    original = ns["fixture"](name, n, h, middle, old)
    run("original", original, ns)
    run("rebuilt", rebuilt, ns)
print(
    "\nPASS exact physical parent hitting and source-mass integrals; n=4 high-J gate empty"
)
