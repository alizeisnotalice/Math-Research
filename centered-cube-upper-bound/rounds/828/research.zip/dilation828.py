"""Replay the affine-dilation branch with exact gates and Arb fee intervals."""

from fractions import Fraction as F
from hashlib import sha256
from itertools import combinations
from math import comb, isqrt
import platform

from flint import arb, ctx
import flint


DIMS = (32, 512, 8192, 2**19, 2**22)
DELTA = F(1, 16)
DECIMAL_GRID = 10**9


def probability(n, survivors, draws):
    """Probability that a uniform draw of distinct axes avoids all missing axes."""
    assert 0 <= survivors <= n and 0 <= draws <= n
    if survivors < draws:
        return F(0)
    missing = n - survivors
    if missing <= draws:
        return F(comb(n-draws, missing), comb(n, missing))
    return F(comb(survivors, draws), comb(n, draws))


def minimal_gate(n, k, threshold):
    """Minimal N with exact P(all k from N) strictly above the threshold."""
    assert 1 <= k <= n and 0 < threshold < 1
    low, high = 0, 1
    while probability(n, n-high, k) > threshold:
        low, high = high, min(2*high, n-k+1)
    while high-low > 1:
        middle = (low+high)//2
        if probability(n, n-middle, k) > threshold:
            low = middle
        else:
            high = middle
    r = n-low
    assert probability(n, r-1, k) <= threshold < probability(n, r, k)
    return r


def check_axis_enumeration():
    cases = 0
    for n in range(1, 10):
        for k in range(1, n+1):
            subsets = [set(sample) for sample in combinations(range(n), k)]
            for survivors in range(n+1):
                good = set(range(survivors))
                observed = F(sum(sample <= good for sample in subsets), len(subsets))
                assert probability(n, survivors, k) == observed
                cases += 1
            for threshold in (F(1,4), F(1,2), F(5,8), F(3,4)):
                naive = next(r for r in range(n+1)
                             if F(sum(sample <= set(range(r)) for sample in subsets),
                                  len(subsets)) > threshold)
                assert minimal_gate(n, k, threshold) == naive
    return cases


def box_overlap_share(source, widths, center):
    ratio = F(1)
    for (left, right), width, point in zip(source, widths, center):
        overlap = max(F(0), min(right, point+width/2)-max(left, point-width/2))
        ratio *= overlap/(right-left)
    return ratio


def check_positive_blocks():
    """All scales s >= 1 satisfy the outer cap for a positive center box."""
    n, k, A, u, gamma = 5, 2, F(4), F(1,2), F(3,2)
    small = (F(-1,16), F(1,16))
    side = (F(3,8), F(7,16))
    sources = ((F(3,4), (small,)*n), (F(1,4), (side,)*2+(small,)*(n-2)))
    centers = ((F(0),)*n, (F(1,32),)*n, (F(-1,32),)*n)

    def averaged(d, center):
        volumes, values = [], []
        for axes in combinations(range(n), d):
            widths = tuple(u if j in axes else F(1) for j in range(n))
            mass = sum(w*box_overlap_share(rect, widths, center) for w, rect in sources)
            volumes.append(u**d)
            values.append(mass/volumes[-1])
        return sum(values)/len(values), max(values)

    r = minimal_gate(n, k, (1+gamma/2)/A)
    assert r == 4
    # All the interval inclusion/exclusion margins hold everywhere on
    # [-1/32,1/32]^5. Total positive mass is one, so larger cubes have average <=1.
    assert sum(weight for weight, _ in sources) == 1
    for mass, rect in sources:
        assert mass > 0 and all(-F(1,2)+F(1,32) <= a < b <= F(1,2)-F(1,32)
                                for a,b in rect)
        assert all((a,b) == small or a-F(1,32) > u/2 for a,b in rect)
        assert all((a,b) == side or max(abs(a), abs(b))+F(1,32) < u/2 for a,b in rect)
    assert A*u**k == 1
    for center in centers:
        confirmed, _ = averaged(k, center)
        assert confirmed == F(33,10) > 1+gamma
        for m in range(1, n+1):
            K = probability(n, r, m)
            T = gamma/(2*A)*K/(u**m)
            U = 1/(u**m)
            average, maximum = averaged(m, center)
            assert 0 <= T < average <= maximum <= U
    print("POSITIVE-BLOCKS n=5 k=2 A=4 u=1/2 r=4",
          "mean_k 33/10, scale volumes exact, future cap 1 on all sides >=1;",
          "m=1..5 and three centers, inequalities uniform on [-1/32,1/32]^5")


def ar(value):
    return arb(value.numerator)/value.denominator


def log_comb_ratio(n, r, m):
    assert 0 <= m <= r <= n
    # K=1 at r=n (also avoids the canceling lgamma expressions).
    if r == n or m == 0:
        return arb(0)
    return (arb(r+1).lgamma() + arb(n-m+1).lgamma()
            - arb(n+1).lgamma() - arb(r-m+1).lgamma())


def fee_logs(n, k, r, m, A, gamma, bits):
    ctx.prec = bits
    lu = (arb(m)/k)*ar(A).log()
    logK = log_comb_ratio(n, r, m)
    logT = ar(gamma/(2*A)).log()+logK+lu
    log2 = arb(2).log()
    logW = log2 + (log2+lu-logT).log() - logT
    if n <= 512:
        assert logK.overlaps(ar(probability(n, r, m)).log())
    return lu, logK, logT, logW


def grid_interval(x):
    scaled = x*DECIMAL_GRID
    low = int(scaled.lower().floor().unique_fmpz())
    high = int(scaled.upper().ceil().unique_fmpz())
    assert 0 <= high-low <= 2
    return low, high


def verified_logs(n, k, r, m, A, gamma):
    if r < m:
        return None
    first = fee_logs(n, k, r, m, A, gamma, 192)
    second = fee_logs(n, k, r, m, A, gamma, 320)
    assert all(a.overlaps(b) for a,b in zip(first, second))
    sides = []
    for a,b in zip(first, second):
        lo1, hi1 = grid_interval(a)
        lo2, hi2 = grid_interval(b)
        sides.extend((max(lo1,lo2), min(hi1,hi2)))
    assert all(lo <= hi for lo,hi in zip(sides[::2], sides[1::2]))
    return tuple(sides)


def run_rational(digest):
    count = 0
    for u in (F(1,2), F(3,4)):
        for n in (8, 32, 128):
            for k in (1, 2, 4):
                A = u**(-k)
                gamma = (A-1)/2
                r = minimal_gate(n, k, (1+gamma/2)/A)
                for delta in (F(1,8), F(1,4), F(3,4)):
                    m = int(n*delta)
                    K = probability(n, r, m)
                    T = gamma/(2*A)*K/(u**m)
                    U = 1/(u**m)
                    assert 0 <= T <= gamma/(2*A)*U < U
                    ledgers = verified_logs(n, k, r, m, A, gamma)
                    assert (ledgers is None) == (K == 0)
                    if K:
                        assert grid_interval(ar(T).log())[0] <= ledgers[5]
                        assert grid_interval(ar(T).log())[1] >= ledgers[4]
                        assert grid_interval(ar(U).log())[0] <= ledgers[1]
                        assert grid_interval(ar(U).log())[1] >= ledgers[0]
                        true_log_fee = (2*(2*ar(U)/ar(T)).log()/ar(T)).log()
                        lo, hi = grid_interval(true_log_fee)
                        assert lo <= ledgers[-1] and hi >= ledgers[-2]
                    digest.update(f"{u} {n} {k} {m} {r} {K} {T} {U} {ledgers}\n".encode())
                    count += 1
    print("EXACT-RATIONAL u=1/2,3/4 and A=u^-k", count, "certified cases",
          "includes zero-threshold branches when m>r")


def fixed_scales(digest):
    cells = 0
    for A in (F(2), F(4)):
        gamma = (A-1)/2
        L = 1+gamma/2
        for n in DIMS:
            m = int(n*DELTA)
            for k in sorted({1, 3, 16, isqrt(n), n//16, n//2, n}):
                alpha = L/A
                r = minimal_gate(n, k, alpha)
                interval = verified_logs(n, k, r, m, A, gamma)
                assert interval is not None
                ctx.prec = 320
                lu, logK, _, logW = fee_logs(n, k, r, m, A, gamma, 320)
                # Convexity A^(1/k)-1 <= (A-1)/k, and r/n >= (L/A)^(1/k).
                # Under the fixed delta choice the per-step ratio exceeds 1+ln(L)/(2k).
                ell = ar(L).log()
                assert ar(DELTA) < ell/(2*ar(A-1))
                assert logK+lu > m*(1+ell/(2*k)).log()
                if k >= n//2:
                    lower = (ar(4*A/gamma).log().log()+ar(4*A/gamma).log()
                             - (arb(m)/k)*ar(A).log())
                    assert logW.overlaps(lower) or logW > lower
                digest.update(f"{A} {n} {k} {m} {r} {interval}\n".encode())
                print("DILATION", A, n, k, m, r,
                      *interval[2:], flush=True)
                cells += 1
    print("ARB-CELLS", cells,
          "192/320 bits; output is numerator over 10^9, intervals ln(K), ln(T), ln(fee)")


def main():
    assert __debug__, "Run with assertions enabled"
    print("Python", platform.python_version(), "python-flint", flint.__version__,
          "FLINT", flint.__FLINT_VERSION__)
    print("INDEPENDENT exhaustive subset probabilities", check_axis_enumeration())
    check_positive_blocks()
    digest = sha256()
    run_rational(digest)
    print("GRID columns A n k m r lnK_low lnK_high lnT_low lnT_high lnFee_low lnFee_high",
          flush=True)
    fixed_scales(digest)
    print("PASS dilation branch exact replay SHA-256", digest.hexdigest())


if __name__ == "__main__":
    main()
