"""Replay this round only, with pinned positive-source inputs and deterministic output."""
import argparse
from concurrent.futures import ThreadPoolExecutor
from hashlib import sha256
from pathlib import Path
import platform
import subprocess
import sys
import flint

HERE = Path(__file__).resolve().parent
PINS = {
    "r814": "891d8cbcbd35537e6abc18c938e53b1b4f300327357c24c8d14a51a46ad5e190",
    "r827": "e17868416d79203cec8b3d8dd32609505c55b4ecc5da6610c5f7f4f568d48996",
}

def run(job):
    filename, args = job
    completed = subprocess.run(
        [sys.executable, "-E", "-B", str(HERE / filename), *args],
        cwd=HERE, text=True, stdout=subprocess.PIPE, check=True,
    )
    return filename, completed.stdout.rstrip()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--r814", type=Path, required=True)
    parser.add_argument("--r827", type=Path, required=True)
    parser.add_argument("--jobs", type=int, default=12, choices=range(1, 13))
    args = parser.parse_args()
    archives = {key: getattr(args, key).resolve() for key in PINS}
    for key, archive in archives.items():
        digest = sha256(archive.read_bytes()).hexdigest()
        if digest != PINS[key]:
            raise ValueError(f"{key} archive SHA-256 mismatch")
    both = ["--r814", str(archives["r814"]), "--r827", str(archives["r827"])]
    small = max(1, min(4, (args.jobs - 3) // 2))
    common = [*both, "--jobs", str(small)]
    archives_only = ["--archive", str(archives["r814"])]
    first = [
        ("stratified828.py", common),
        ("stratified828.py", [*common, "--extremes"]),
        ("hull828.py", archives_only),
        ("swaps828.py", archives_only),
        ("dilation828.py", []),
    ]
    threads = 5 if args.jobs >= 5 else 1
    print(f"Python {platform.python_version()}; python-flint {flint.__version__}; FLINT {flint.__FLINT_VERSION__}")
    for key, digest in PINS.items():
        print(key, digest)
    with ThreadPoolExecutor(max_workers=threads) as pool:
        for name, stdout in pool.map(run, first):
            print(name, stdout, sep="\n")
    name, stdout = run(("profiles828.py", [*both, "--jobs", str(args.jobs)]))
    print(name, stdout, sep="\n")
    print("PASS R828 full replay")

if __name__ == "__main__":
    main()
