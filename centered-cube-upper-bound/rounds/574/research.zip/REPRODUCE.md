# R574 复现与证据范围

本包的主证明在 REPORT.tex，数值附录在 NUMERICS.tex；不编译PDF。BAND_BRIDGE.md 保留恢复步骤与条件范围，AUDIT.md 是本轮最终独立审核。numeric.json 保存完整有限来源子集、实际接收盒、残余cell及根式证书。它不证明一般残余预算。

运行用户独立环境：

    OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 /Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python numeric.py --output replay.json

解释器 Python 3.12.14，SymPy 1.14.0；核心几何使用标准库 Fraction、isqrt 的精确运算。SymPy只用于根式展示。未调用 MATLAB、Arb 或优化器。脚本每例设120秒上限，使用单进程。实际最终归档路径重放总耗时约0.126秒、峰值72.4MB。运行时/内存不是固定预期值。

10例参数完全冻结于代码：n1三原子；n2四角±5/8与±3/4；六源3×2网格；八源四角近点对；每种A=1、2。全部源质量1、λ=1、b=1/√n。多原子选中block由最后模型实测。扩大参数范围只用于这些指定机制检查，不做维数阶拟合。

全部根式体积以有理系数保存，误差0。192-bit有理平方根包围认证每个非零符号；若包围跨零会报错，不作猜测。JSON中的display仅为阅读小数，不参与判定。比较结果时递归忽略 command、runtime_seconds、peak_rss_bytes 三项，其余字段应完全相同。REPLAY.json记录本次已实际运行的路径重放及代码哈希；不是凭脚本存在声称运行。

完整源代码含全部断言：高簇greedy及拒绝见证、源partition、完整C/H端点分区、全部大core包含、每个残余witness的所有大core和incident blocks、H独立容斥以及A1/A2的E一致。有限测试不能认证一般n或任意L1；解析定理的范围和未付项见正文。

MANIFEST.json给出除其自身外每个归档成员的字节数与SHA-256；不包含运行后可重建的replay.json、缓存、阶段草稿或旧轮次副本。

## 独立审核脚本

    /Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python ccu_r574_audit_check.py --input numeric.json --source numeric.py --output audit_check.replay.json

AUDIT.md及audit_check.json记录审查者当时实际inline运行的数学检查；保存CLI时审查者仅核了--help。随后主代理在本包路径实际运行了上述可携带CLI，返回PASS，11个根基、916个区间对象、121个根式基乘法、355个独立子集重建、1458项残余见证条件及10行公式检查的计数全部相同。此后运行不改变原审核者的工作范围，也没有再次计算完整arrangement。
