"""Targeted R574 archive audit; no full arrangement replay or new model.

The mathematical body was executed successfully inline. This portable CLI
wrapper was saved afterward without repeating those mathematical checks.
"""
import argparse
import ast
from fractions import Fraction as F
import json
import math
from pathlib import Path
import sys

import sympy as S

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--input', type=Path, default=Path(__file__).resolve().parent / 'numeric.json')
parser.add_argument('--source', type=Path, default=Path(__file__).resolve().parent / 'numeric.py')
parser.add_argument('--output', type=Path, help='Write a new result file; otherwise print JSON.')
args = parser.parse_args()
data = json.loads(args.input.read_text())
src = args.source.read_text()
objects = []
rad = set()


def walk(v):
    if isinstance(v, dict):
        if 'radical_coefficients' in v:
            objects.append(v)
            rad.update(map(int, v['radical_coefficients']))
        if 'volume_coefficients' in v:
            rad.update(map(int, v['volume_coefficients']))
        for x in v.values():
            walk(x)
    elif isinstance(v, list):
        for x in v:
            walk(x)


walk(data)
D = 2**192
rb = {}
for d in rad:
    assert d > 0 and all(e == 1 for e in S.factorint(d).values())
    v = math.isqrt(d * D * D)
    lo = F(v, D)
    hi = lo if v * v == d * D * D else F(v + 1, D)
    assert lo * lo <= d <= hi * hi and hi - lo <= F(1, D)
    rb[d] = (lo, hi)
for q in objects:
    lo = F(0)
    hi = F(0)
    for ds, cs in q['radical_coefficients'].items():
        c = F(cs)
        a, b = rb[int(ds)]
        lo += c * (a if c >= 0 else b)
        hi += c * (b if c >= 0 else a)
    assert [lo, hi] == list(map(F, q['isolating_interval']))

# Load only arithmetic definitions, never source model enumeration or writes.
ns = {'F': F, 'gcd': math.gcd}
wanted = {'clean', 'add', 'neg', 'sub', 'mul', 'rat', 'sqrtr'}
mod = ast.parse(src)
exec(compile(ast.Module(body=[x for x in mod.body if isinstance(x, ast.FunctionDef) and x.name in wanted], type_ignores=[]), '<arithmetic-only>', 'exec'), ns)
for d in rad:
    for e in rad:
        v = ns['mul']({d: F(1)}, {e: F(1)})
        assert S.simplify(sum(S.Rational(c.numerator, c.denominator) * S.sqrt(k) for k, c in v.items()) - S.sqrt(d) * S.sqrt(e)) == 0
for d in rad:
    assert ns['add']({d: F(2, 3)}, {d: F(-2, 3)}) == {}

expected = {
    'n1_three': (S.Integer(3), 0, 0),
    'n2_four_5_8': (S.Rational(113, 16) - 3 * S.sqrt(2) / 2, S.Rational(49, 16) - 3 * S.sqrt(2) / 2, 0),
    'n2_four_3_4': (S.Rational(17, 4), S.Rational(1, 4), 2 * S.sqrt(2) - S.Rational(11, 4)),
    'n2_six_grid': (S.Rational(13, 2), S.Rational(1, 2), 4 * S.sqrt(2) - S.Rational(11, 2)),
    'n2_eight_corner_pairs': (16 * S.sqrt(2) - S.Rational(115, 8), (127 * S.sqrt(2) - 175) / 8, 0),
}
checked_models = set()
beta_count = 0
witness_count = 0
for row in data['rows']:
    ev, r1, r2 = expected[row['model']]
    assert S.simplify(S.sympify(row['exact_volume_E']['expression']) - ev) == 0
    assert S.simplify(S.sympify(row['exact_volume_E_minus_H_A']['expression']) - (r1 if row['A'] == 1 else r2)) == 0
    masks = row['selected_partition_masks']
    used = 0
    for m in masks:
        assert not used & m
        used |= m
    assert used == (1 << row['N']) - 1
    tab = {q['mask']: q for q in row['all_subset_certificate']}
    assert set(tab) == set(range(1, 1 << row['N']))
    if row['model'] not in checked_models:
        z = [[F(t) for t in p] for p in row['unit_source_positions']]
        n = row['n']
        for mask, q in tab.items():
            ids = [i for i in range(row['N']) if mask >> i & 1]
            m = len(ids)
            assert m == q['mass']
            spans = [max(z[i][j] for i in ids) - min(z[i][j] for i in ids) for j in range(n)]
            positive = all(m > x if n == 1 else m > x * x for x in spans)
            assert positive == q['positive_C']
            beta = S.prod(1 - S.Rational(x.numerator, x.denominator) / (m if n == 1 else S.sqrt(m)) for x in spans) if positive else S.Integer(0)
            assert S.simplify(beta - S.sympify(q['beta']['expression'])) == 0
            flag = S.simplify(n * beta * beta - 1).is_nonnegative
            assert flag is not None and bool(flag) == q['high']
            beta_count += 1
        checked_models.add(row['model'])
    for cell in row['residual_cells']:
        for mask in cell['witness_masks']:
            q = tab[mask]
            good = any(k['high'] and k['mask'] & mask == k['mask'] and row['A'] * k['mass'] >= q['mass'] for k in tab.values())
            assert not good
            incident = [u for u in masks if u & mask]
            assert all(row['A'] * tab[u]['mass'] < q['mass'] for u in incident)
            assert len(incident) >= row['A'] + 1
            witness_count += 1

result = {
    'exact_root_basis': sorted(rad),
    'root_interval_objects': len(objects),
    'basis_product_pairs': len(rad)**2,
    'independent_subset_beta_checks': beta_count,
    'residual_cell_witness_checks': witness_count,
    'table_rows': len(data['rows']),
    'result': 'PASS',
    'scope': 'targeted archive semantics/arithmetic only; no full arrangement replay or new geometry',
    'interpreter': sys.executable,
    'sympy_version': S.__version__,
}
encoded = json.dumps(result, ensure_ascii=False, indent=2) + '\n'
if args.output:
    if args.output.resolve() in {args.input.resolve(), args.source.resolve()}:
        raise ValueError('Audit output must not overwrite an input.')
    args.output.write_text(encoded)
print(encoded, end='')
