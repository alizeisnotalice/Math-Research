# R574 主证明定点独审

**最终指定范围通过，无阻断修复项。** 新全尺度高core覆盖、残余必要条件、合法增量及两条条件恢复总账均成立。此前附件“等价地”措辞已改为“充分实现方式”，主稿也已明确增量针对C_S\H₂非空的S。现已核NUMERICS、代码、数据及重放记录；10例不构成一般残余预算证明。

所审最终主REPORT SHA256：`fcf7d61670409596fb6b5a63f460232ee4daecb1d547b5ea33eb3dc205a9b4b3`。

所审定版文件SHA256：

- `astra_bridge.md`：`cf2d4507d8605aa39f6ef7e9999bf48072fecc205aeafe0cb2126f95d900a837`。
- release `BAND_BRIDGE.md`：`f6038ad1030623f0fdbab8ba1043ed0aaaa1e385be9ca65b973977d5539535d7`。
- `NUMERICS.tex`：`7235ed5ba983c98c2386765762354063f26db5ebf8d06eedca63efdaac624a04`。
- `numeric.py`：`41df3397cefec8b64bdf3969bcc3c3fd9fb2a869b1ac1d1e5208afbbab192bde`。
- `numeric.json`：`abaa98d2b4eaa3efef251d75b0df97af8ae08129c106b193dee95f54e0b59f20`。
- `REPLAY.json`：`d38870fb84132356b85f98d51c94192a36c879d3ec13566309c38cf4bbdcebd9`。

此前先独立核过命题，本次逐式对照作者文本与附录。R571来源局部化按本任务作为已证工具使用，不重审其全历史；仅对固定存档作下述针对性核验，没有新模型/维数扫描或全arrangement重跑，未改正文或他人文件/repo，未spawn、未编译PDF。

## 1. 全尺度高core覆盖

全部非空原label子集有限，按质量降序且固定处理ties的greedy明确存在。选中源集互不交。因每个singleton β=1≥b，每个原标签最终被恰好一个选中U包含，故Σm_U=W；重复位置的不同标签不破坏此源不交结论。

选中β_U≥b>0使每个q_j=d_j(U)/r_U<1。逐坐标 `(1−q_j)(1+q_j)≤1` 及 `q_j+A^(1/n)≤A^(1/n)(1+q_j)` 得

`λ|D_U^(A)|≤A m_U/β_U`，`λ|H_A|≤A W/b`。

此处先对完整D的坐标体积计算再作receiver并集上界，没有用薄层体积推断任意source mass。

若K⊂S、β_K≥b且m_K≥m_S/A，K被选或被先选U拦截，两种情况均有m_U≥m_K和真实共同标签i∈U∩K⊂S。于是r_S≤A^(1/n)r_U，整个C_S位于D_U^(A)。相同质量时非严格质量比较已足够；C_S开放、D闭合使边界包含无缺口。这个论证不要求S⊂U，也没有把receiver carrier重标成一个原见证簇。

A=1的全部高β付款W/b与A=2、b=n^-1/2的好区付款2√nW均跨所有质量带一次有效，n=1和所有允许ties亦包含。作者没有把好区付款说成完整E_λ付款。

## 2. 残余必要条件

x∈C_S\H_A时，若任何质量≥m_S/A的K⊂S仍β_K≥b，则上节整盒包含矛盾，所以所有这些K的β均严格<b。

若选中U与S相交而m_U≥m_S/A，同一共同标签直接给C_S⊂D_U^(A)，也矛盾。因此所有incident U质量严格小于m_S/A。由所选U partition labels，m_S≤Σincident m_U，推出incident数量严格大于A，即至少floor(A)+1。A=2时至少三个。

这些是一向的必要残余约束，作者明确未把它们当作充分刻画。H₂之外的receiver项仍有全部crossing source、质量和尺度，式residual没有漏项。

## 3. old cover减去C_K

以A=2的残余S为对象，取真实K⊂S、m_K≥m_S/2。R573 carrier B包含C_S与C_K，且

`λ|B|≤β_Km_K+(β_K+2/n)(m_S−m_K)`。

若实际旧receiver集合V包含C_K，则C_S\V⊂B\C_K。因此可以减去真实体积λ|C_K|=β_Km_K，得到作者增量式。β_K=0或C_K空时仍合法，没有除以β。

对C_S\H₂非空的S，上一节给β_K<b，故系数可换成b+2/n。这里A必须取2（或另行保证K属于hereditary量词范围）；主稿上下文已固定H₂，Astra§5也明确A=2。若最终编辑消去此上下文，应将“residual S”写成“C_S\H₂非空的S”。

按全子集质量递增处理时，proper K因正质量有m_K<m_S，故其完整C_K确已处理（含先被H₂覆盖者）。残余S不能是singleton；删除其一个最小质量原子可得proper半质量core。这样有限递推没有覆盖遗漏。

但“core的原子以前出现过”不等于“core的整盒receiver已覆盖”。作者正确要求后者，也没有把全子集累计的Δ费用误说成≤W或R573非复制forest light-edge账。尚未支付的正是跨标签重复/重组总量。

## 4. 全尺度条件恢复：常数2√n+D_n

若对所有有限原子ν及阈值统一有 `λ|E_λ\H₂|≤D_nW`，与好区合并得到完整原子weak常数2√n+D_n。网格量化紧支撑f后，每个固定cube质量误差由缩小边界管的f质量控制；边界Lebesgue零测，故每个严格见证最终仍过阈。Fatou保留完整weak常数，再用min(f,j)1[-j,j]^n单调恢复一般f。

这个路线不经过R571局部化，因而没有16e、N_n、4/3或源格1/(1−η)；也不要求H₂近似集收敛。作者明确没有仅凭部分atomic好区就宣布完整L¹估计。

## 5. 单mass-band条件恢复：常数16e+(4/3)N_nB_n

充分几何输入是全部真实atomic band clusters的union（或后文实际出现的closed-cluster子族）付款，常数B_n独立于原子数、阈值、带及输入。它不是given-forest定理本身。

R571实际共同f_k来源、ΣW_k≤N_nW、R∈[a,2a]及q_k∈[3λ/4,λ]均按已证工具使用。固定α<3/4，选ε>0使α<3/4−ε、ε<1/6，取τ=αλ及

`L=(3/4−ε)λa^n`，`U=(1+ε)λ(2a)^n`。

比值为 `2^n(1+ε)/(3/4−ε)<2^(n+1)`。对同一完整f_k作共同网格原子化，固定x、原见证R的捕获质量收敛，最终在[L,U]中且q_{k,j}>τ。实际捕获的全部atoms组成S，其r_S(τ)>R，因而即使原见证边界有量化atom，也严格落入开放C_S(τ)。不存在将q≤λ的见证错误地直接塞入C_S(λ)的步骤。

Fatou给τ|E_k|≤B_nW_k。由于每个α<3/4都成立，取α↑3/4得到4B_nW_k/3，再按一次ΣW_k和异常集费用，恰得

`λ|{Mf>λ}|≤[16e+(4/3)N_nB_n]W`。

这里不使用后续冻结场/grid动作，因此没有D、C0、J或1/(1−η)费用可添减；作者该范围正确。

捕获全部atoms的S确实source-box-closed：其bbox在真实见证cube内，故closure不会再加未捕获atom。这允许band假设仅付实际closed S，而不是把任意非closed S做closure后强称质量仍在同一带。重atom>U不属于该band的任何S，但其全水平集贡献不能据此免费删去；附件已正确区分。网格j与截断j仅是极限，不累加source费用。

若完整band残余另有D_n^band，则B_n=2√n+D_n^band，最终费用为

`16e+(8/3)N_n√n+(4/3)N_nD_n^band`。

不同k的实际来源不同，故不能无证去掉好区项的N_n或4/3。对同一个ν的全带好区一次付费也不使逐band残余自动可求和。这两种恢复总账在主稿和附录中保持分离。

## 6. scope修复已核

初读临时稿的band bridge曾称(B)与受控forest构造“等价”。当前定版第5节已改为“一种充分实现方式”，正确区分了forest构造⇒(B)与未证明的反向。主REPORT的增量段现在明确写C_S\H₂非空，A=2的hereditary条件不会与一般A混用。上述修复已核，均不再是待修项。

## 7. 数值代码：精确运算与全receiver对象

代码只测试固定n=1、2、unit masses、λ=1、A=1或2。n=1边长m，n=2边长√m；五个规定输入枚举全部2^N−1个非空标签子集。因此每例的E确实对应完整scale supremum，而不是scale grid。正C判据使用每个真实width>0；任一width≤0时β=0，不把两个负width的乘积当作正体积。

根式以有理系数的squarefree根组合保存。加法逐基合并，乘法对squarefree d,e使用g=gcd(d,e)、q=de/g²及√d√e=g√q，正确保持精确值。平方因子剥除的sqrtr输入都是本固定列表的正整数；没有浮点质量进入半径。display中的SymPy小数不参与任何几何决定。

rootbounds用v=isqrt(d·2^384)，给v/2^192与(v+1)/2^192；平方恰相等时上下界相等。整数定义保证向外，负系数在bounds中交换上下端点。sign只接受整个有理区间严格正/负，或空系数字典的精确零；区间跨0则立即报错，不把窄区间当零。故3392条被接受的nonzero decisions具有有效的rational enclosure证据；该3392计数来自实际保存/重放记录，本次未重新产生完整比较计数。

坐标集合含所有正C盒和H盒的全部端点，精确排序/去重后取所有相邻开区间的笛卡尔积。每个盒的membership在这种cell上恒定；区间总外侧没有任何盒，有限边界faces为零测。因此计算覆盖完整E、H及E\H的Lebesgue体积，无未付空间尾。残余cell没有只选一个winner：程序对该cell的全部witness masks逐一核查所有大型high子core及所有incident selected blocks。

qualified C整盒包含也由此得到：若open C\closed H非空，它是非空开集，必含一个非端点cell中的正体积部分，会被程序的residual witness检查发现。故这里不仅是a.e.数值采样包含。独立H inclusion–exclusion逐个取交盒的真实端点，并以canonical radical coefficients与arrangement体积完全相等作比较，不靠小数容差。

## 8. 本次实际针对性运行及报告数值

实际使用指定本机Python/SymPy执行一次仅针对固定archive的独立检查，未执行numeric.py的模型枚举主体、未覆盖原JSON、未重跑全arrangement：

- 对出现的11个根基，以独立整数平方比较核192bit上下界，并逐项复核916个保存根式的有理interval字段。
- 仅从AST载入加/减/乘/根式规范化函数，对11²=121个basis乘积与SymPy精确根式比较，全部相等；同基有理加法消去亦精确。
- 从五个实际source位置、mask和unit masses独立重建全部355个子集的非空C、β及high判据，与存档逐项相同；不是只信保存的high布尔值。
- 对10行存档共1458个residual-cell×witness组合，重新逐个遍历全部子core和incident blocks，所有hereditary/严格质量/块数断言成立。
- 对报告10行E与E\H_A公式作SymPy精确差检查，全部为0；所选mask不交并覆盖全标签，完整mask集合1,…,2^N−1亦逐例核对。

输出为PASS；出现根基为1,2,3,5,6,7,10,14,30,35,42。以上是实际运行范围，不冒称重新计算所有transient sign decisions、全部cell积分或原完整replay。

实际inline核验的数学代码及结果现已保存为自有复现材料：

- `/tmp/ccu_r574_audit_check.py`，SHA256 `f026f5d468b089e8af92e165f1744dc3be9ad65fc8a7fd51ecea94db22459971`。
- `/tmp/ccu_r574_audit_check.json`，SHA256 `2f45c95b11a01c21553cd01f5ae16bb98699aec0b7043bfd6d3023fc124b5f08`。

数学主体实际执行形式是指定解释器的inline Python；保存时只加了可携带的argparse输入/输出包装，未再次执行这些已通过的数学检查。保存后实际运行`--help`确认CLI解析/语法可用。默认输入取脚本同目录的numeric.json/numeric.py，也可显式指定；不会写原数据。解包后的复现命令为：

`python ccu_r574_audit_check.py --input numeric.json --source numeric.py --output audit_check.replay.json`

应使用有SymPy的已安装解释器。本地原执行解释器为`/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python`。结果JSON明确标记inline执行与事后CLI包装的区别；该针对性核验不重算arrangement或创造新模型。

NUMERICS的子集数7、15、15、63、255及正C数6、15、9、16、105，与独立重建和JSON相同。八源paired模型确有12个high sets（8 singleton、4 pair），greedy选4个mass-two pairs，β=1−√2/32；因此有非singleton拦截测试。四角3/4例的独立解析控制E=17/4、H₂=8、残余2√2−11/4>0正确；它验证残余真实存在，不反驳覆盖定理或给出一般预算下界。

REPLAY.json记录release位置实际重放、全部数学字段相同、10例、3392 nonzero decisions、0.126秒左右和约72.4MB峰值RSS；记录的code SHA与当前numeric.py一致。原numeric.json允许command/runtime等元数据与release replay不同，未借此改变几何。本文读核该重放记录，但没有把root的完整replay称作自己的重跑。

没有新维数、额外模型、solver、Arb、MATLAB或PDF工作。所述精确误差是fixed radical arithmetic误差0与向外比较；它不是一般连续source/所有维数的误差认证。

## 最终判定与剩余

当前定版REPORT、附录和数值在上述限定范围通过；无待修复项。新增已付全尺度内容是H₂好区；完整hereditary低β crossing残余、重复source增量总账、完整band payer/forest覆盖仍未证明。两条恢复都是正确条件推理，10例有限证据不构成残余已经付款。一般weak目标及维数指数无改善。未核仓库提交、最终archive/manifest或PDF排版；这些不在本任务范围。按任务范围结束待命。
