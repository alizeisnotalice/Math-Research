"""Ten frozen complete-subset greedy/A-inflation exact geometry experiments."""
from fractions import Fraction as F
from math import isqrt,gcd
from functools import cmp_to_key
from pathlib import Path
import json,sys,platform,time,resource,signal,argparse,shlex
import sympy as S
parser=argparse.ArgumentParser()
parser.add_argument('--output',type=Path,default=Path(__file__).resolve().parent/'numeric.json')
args=parser.parse_args()
START=time.perf_counter();PREC=192;DEN=2**PREC
ROOT={};DECISIONS=0

def rootbounds(d):
    if d not in ROOT:
        v=isqrt(d*DEN*DEN)
        ROOT[d]=(F(v,DEN),F(v,DEN) if v*v==d*DEN*DEN else F(v+1,DEN))
    return ROOT[d]
def clean(v):return {d:c for d,c in v.items() if c}
def add(a,b):
    z=a.copy()
    for d,c in b.items():z[d]=z.get(d,F(0))+c
    return clean(z)
def neg(a):return {d:-c for d,c in a.items()}
def sub(a,b):return add(a,neg(b))
def mul(a,b):
    z={}
    for d,c in a.items():
        for e,f in b.items():
            g=gcd(d,e);q=d*e//(g*g);z[q]=z.get(q,F(0))+c*f*g
    return clean(z)
def rat(x):return clean({1:F(x)})
def sqrtr(k,c=F(1)):
    q=1;d=k;p=2
    while p*p<=d:
        while d%(p*p)==0:q*=p;d//=p*p
        p+=1
    return rat(c*q) if d==1 else clean({d:c*q})
def bounds(v):
    lo=F(0);hi=F(0)
    for d,c in v.items():
        a,b=rootbounds(d)
        lo+=c*(a if c>=0 else b);hi+=c*(b if c>=0 else a)
    return lo,hi
def sign(v):
    global DECISIONS
    if not v:return 0
    lo,hi=bounds(v);DECISIONS+=1
    if lo>0:return 1
    if hi<0:return -1
    raise AssertionError('Unresolved exact algebraic sign: '+str(v))
def key(v):return tuple(sorted(v.items()))
def unkey(v):return dict(v)
def expr(v):return str(sum(S.Rational(c.numerator,c.denominator)*S.sqrt(d) for d,c in sorted(v.items())))
def exactout(v):
    lo,hi=bounds(v)
    return {'radical_coefficients':{str(d):str(c) for d,c in sorted(v.items())},'expression':expr(v),'isolating_interval':[str(lo),str(hi)],'display':str(S.N(sum(S.Rational(c.numerator,c.denominator)*S.sqrt(d) for d,c in v.items()),20))}
def alarm(sig,frame):raise TimeoutError('120 second case cap')
signal.signal(signal.SIGALRM,alarm)
models=[('n1_three',[(F(-1),),(F(0),),(F(1),)]),('n2_four_5_8',[(x,y) for x in [F(-5,8),F(5,8)] for y in [F(-5,8),F(5,8)]]),('n2_four_3_4',[(x,y) for x in [F(-3,4),F(3,4)] for y in [F(-3,4),F(3,4)]]),('n2_six_grid',[(x,y) for x in [F(-3,2),F(0),F(3,2)] for y in [F(-3,4),F(3,4)]])]
models.append(('n2_eight_corner_pairs',[(cx+delta,cy) for cx in [F(-1),F(1)] for cy in [F(-1),F(1)] for delta in [F(-1,32),F(1,32)]]))
rows=[]
for name,z in models:
    n=len(z[0]);N=len(z);subs=[]
    for mask in range(1,1<<N):
        ids=[i for i in range(N) if mask>>i&1];m=len(ids)
        mins=[min(z[i][j] for i in ids) for j in range(n)];maxs=[max(z[i][j] for i in ids) for j in range(n)]
        r=rat(m) if n==1 else sqrtr(m)
        widths=[sub(r,rat(maxs[j]-mins[j])) for j in range(n)]
        positive=all(sign(w)>0 for w in widths)
        if positive:
            numerator=rat(1)
            for w in widths:numerator=mul(numerator,w)
            beta={d:c/m for d,c in numerator.items()}
            # beta>=1/sqrt(n) iff n beta^2>=1 (beta>0)
            high=sign(sub({d:n*c for d,c in mul(beta,beta).items()},rat(1)))>=0
            half={d:c/2 for d,c in r.items()}
            box=[(sub(rat(maxs[j]),half),add(rat(mins[j]),half)) for j in range(n)]
        else:beta={};high=False;box=None
        subs.append({'mask':mask,'mass':m,'mins':mins,'maxs':maxs,'beta':beta,'high':high,'box':box})
    selected=[];used=0;blocking=[]
    for q in sorted(subs,key=lambda v:(-v['mass'],v['mask'])):
        if q['high'] and not used&q['mask']:
            selected.append(q);assert not used&q['mask'];used|=q['mask']
        elif q['high']:
            blocker=next(u for u in selected if u['mask']&q['mask'])
            assert blocker['mass']>=q['mass']
            blocking.append({'rejected_high_mask':q['mask'],'mass':q['mass'],'earlier_selected_blocker':blocker['mask'],'blocker_mass':blocker['mass'],'shared_mask':blocker['mask']&q['mask']})
    assert used==(1<<N)-1 and sum(q['mass'] for q in selected)==N
    for A in [1,2]:
        signal.alarm(120);start=time.perf_counter()
        hboxes=[]
        for q in selected:
            side=rat(A*q['mass']) if n==1 else sqrtr(A*q['mass'])
            half={d:c/2 for d,c in side.items()}
            hboxes.append([(sub(rat(q['mins'][j]),half),add(rat(q['maxs'][j]),half)) for j in range(n)])
        good={q['mask']:any(k['high'] and (k['mask']&q['mask'])==k['mask'] and A*k['mass']>=q['mass'] for k in subs) for q in subs}
        coords=[]
        for j in range(n):
            vals={key(e) for q in subs if q['box'] for e in q['box'][j]}
            vals.update(key(e) for box in hboxes for e in box[j])
            coords.append(sorted(vals,key=cmp_to_key(lambda a,b:sign(sub(unkey(a),unkey(b))))))
        index=[{v:i for i,v in enumerate(cs)} for cs in coords]
        cb=[]
        for q in subs:
            if q['box']:cb.append((q,[tuple(index[j][key(e)] for e in q['box'][j]) for j in range(n)]))
        hb=[[tuple(index[j][key(e)] for e in box[j]) for j in range(n)] for box in hboxes]
        E={};H={};R={};resw=set();rescells=[];positive_cells=0
        dims=[len(c)-1 for c in coords]
        for ix in range(dims[0]):
            dx=sub(unkey(coords[0][ix+1]),unkey(coords[0][ix]))
            for iy in range(dims[1] if n==2 else 1):
                js=[ix,iy] if n==2 else [ix]
                witness=[q['mask'] for q,box in cb if all(lo<=jj<hi for jj,(lo,hi) in zip(js,box))]
                insideH=any(all(lo<=jj<hi for jj,(lo,hi) in zip(js,box)) for box in hb)
                if not witness and not insideH:continue
                area=dx if n==1 else mul(dx,sub(unkey(coords[1][iy+1]),unkey(coords[1][iy])))
                assert sign(area)>0;positive_cells+=1
                if witness:E=add(E,area)
                if insideH:H=add(H,area)
                if witness and not insideH:
                    R=add(R,area);resw.update(witness)
                    for mask in witness:
                        q=subs[mask-1]
                        assert not good[mask]
                        incident=[u for u in selected if u['mask']&mask]
                        assert all(A*u['mass']<q['mass'] for u in incident)
                        assert len(incident)>=A+1
                    rescells.append({'cell_indices':js,'witness_masks':witness,'volume_coefficients':{str(d):str(c) for d,c in area.items()}})
        # Inclusion of every qualified C_S is checked against all residual cells.
        assert all(not good[mask] for mask in resw)
        assert sign(sub(rat(A*N) if n==1 else sqrtr(2,A*N),H))>=0
        # Independent inclusion-exclusion for H, at most six selected boxes.
        H_ie={}
        for mask in range(1,1<<len(hboxes)):
            chosen=[hboxes[i] for i in range(len(hboxes)) if mask>>i&1]
            vol=rat(1)
            for j in range(n):
                lo=chosen[0][j][0];hi=chosen[0][j][1]
                for box in chosen[1:]:
                    if sign(sub(box[j][0],lo))>0:lo=box[j][0]
                    if sign(sub(box[j][1],hi))<0:hi=box[j][1]
                width=sub(hi,lo)
                if sign(width)<=0:vol={};break
                vol=mul(vol,width)
            H_ie=add(H_ie,vol if mask.bit_count()%2 else neg(vol))
        assert H_ie==H
        row={'H_independent_inclusion_exclusion_error':'0','model':name,'n':n,'N':N,'lambda':1,'unit_source_positions':[[str(x) for x in p] for p in z],'A':A,'b':'1' if n==1 else '1/sqrt(2)','all_subset_count':len(subs),'positive_C_count':len(cb),'high_subset_count':sum(q['high'] for q in subs),'selected_partition_masks':[q['mask'] for q in selected],'greedy_rejected_high_blocking_certificate':blocking,'selected_partition_masses':[q['mass'] for q in selected],'selected_beta':[exactout(q['beta']) for q in selected],'qualified_large_high_core_subset_count':sum(good.values()),'all_subset_certificate':[{'mask':q['mask'],'mass':q['mass'],'beta':exactout(q['beta']),'high':q['high'],'positive_C':q['box'] is not None,'C_endpoints':[[expr(e) for e in pair] for pair in q['box']] if q['box'] else None,'has_large_high_core':good[q['mask']]} for q in subs],'exact_volume_E':exactout(E),'exact_volume_H_A':exactout(H),'exact_volume_E_minus_H_A':exactout(R),'arrangement_axis_intervals':dims,'positive_union_cells':positive_cells,'residual_cell_count':len(rescells),'residual_witness_masks':sorted(resw),'residual_cells':rescells,'residual_witness_checks':[{'mask':mask,'mass':subs[mask-1]['mass'],'beta':exactout(subs[mask-1]['beta']),'incident_blocks':[u['mask'] for u in selected if u['mask']&mask],'incident_masses':[u['mass'] for u in selected if u['mask']&mask],'all_large_cores_low_beta':not good[mask]} for mask in sorted(resw)],'all_inclusion_and_hereditary_incidence_checks':True,'runtime_seconds':time.perf_counter()-start}
        rows.append(row);signal.alarm(0)
for model in models:
    pair=[r for r in rows if r['model']==model[0]]
    assert pair[0]['exact_volume_E']['radical_coefficients']==pair[1]['exact_volume_E']['radical_coefficients']
result={'status':'PASS_10_COMPLETE_SUBSET_GREEDY_INFLATION_CASES','rows':rows,'algebra':'exact squarefree-radical coefficient arithmetic for box volumes; rational 192-bit root isolators for every nonzero sign/order decision; canonical zero/equality exact','root_isolation_bits':PREC,'certified_nonzero_sign_decisions':DECISIONS,'volume_arithmetic_error':'0','comparison_unresolved_count':0,'interpreter':sys.executable,'python_version':platform.python_version(),'sympy_version':S.__version__,'command':'OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 '+shlex.join([sys.executable]+sys.argv),'runtime_seconds':time.perf_counter()-START,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'processes':1,'scope':'Finite complete all-subset receiver geometry only. Positive residual is unpaid; no general residual budget, forest theorem or dimension extrapolation.'}
args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='rows'},ensure_ascii=False,indent=2))
print(json.dumps([{'model':v['model'],'A':v['A'],'selected':v['selected_partition_masks'],'E':v['exact_volume_E']['expression'],'H':v['exact_volume_H_A']['expression'],'residual':v['exact_volume_E_minus_H_A']['expression'],'residual_display':v['exact_volume_E_minus_H_A']['display'],'residual_cells':v['residual_cell_count'],'witnesses':v['residual_witness_masks']} for v in rows],ensure_ascii=False,indent=2))
