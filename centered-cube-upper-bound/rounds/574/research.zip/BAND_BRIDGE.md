# R574：质量带 receiver 付款到一般 L1 的准确桥

**结论。** R571 已证的共同来源局部化足以把一个真正完整的 atomic mass-band receiver 预算接到一般 L1，准确总账为
\[
\boxed{\lambda|\{M_\square f>\lambda\}|
\le\left[16e+\frac43N_n B_n\right]\|f\|_1,
\quad N_n=2+\lceil\log_2(32n^2)\rceil.}\tag{A}
\]
这里 B_n 必须支付完整的实际质量带 cluster 族，而非一个先给定的森林。下文以整个 band union 作清晰的充分输入；可削弱为该带内全部 source-box-closed clusters，见第4节。R573 的 given-forest 定理目前不能直接充任它；缺口在 crossing-source 几何，不在剩余密度/尺度恢复。此稿证明 (A) 的实际恢复步骤，不将其当作新增几何付款。

已读冻结 R574 contract，只查看 R571 REPORT §2、R572 REPORT 冻结入口及 R573 forest 定理的相关条款。只写本文件，不动 repo/他人文件，不 spawn；不重复 Astra 的跨来源几何。指定本机 Python/SymPy 实跑核查了质量比余量、ε=1/8 时的 9/5、及 \((4/3)14=56/3\)，无数值实验。

## 1. 这里真正需要的 atomic band 命题

对任意 finite positive atomic \(\nu=\sum_i m_i\delta_{z_i}\)，W=Σm_i，任意阈值 τ>0 及 0<L≤U，定义
\[
\mathcal C_{\tau;L,U}(\nu)
=\bigcup_{\substack{\varnothing\ne S\subset\{1,\dots,N\}\\L\le m_S\le U}}
C_S(\tau),\quad
C_S(\tau)=\bigcap_{i\in S}\left\{x:\|x-z_i\|_\infty<\frac12(m_S/\tau)^{1/n}\right\}.
\]
一个明确的充分输入是统一估计
\[
\tau|\mathcal C_{\tau;L,U}(\nu)|\le B_nW
\quad\text{当 }U/L\le2^{n+1}.
\tag{B}
\]
它含该 ν 的全部 band clusters、真实 Lebesgue receivers、全部来源重叠；B_n 与 atoms 数量、位置、质量、τ、L、U 无关。

R573 已付的是：若原 cluster labels **已经**进入不复制的 source forest，则该森林 retained nodes 的 union 可取 \(14\sqrt nW\)。若未来能以共同选择的森林覆盖 (B) 的完整 union，并且所有森林 root mass 总和≤P_nW，那么可合法取
\[
B_n=14P_n\sqrt n.
\tag{C}
\]
当前没有这样的覆盖与总 root-mass 证明。不是每个 cluster 分配一棵树后都可领取 W；也不是某一树的 root mass≤W 就说明整族 root mass≤W。

## 2. R571 来源局部化的全部实际输入

固定原阈值 λ>0、\(\mu=f dx\)、W=∥f∥1。先取有界紧支撑 f≥0；一般输入最后恢复。R571 对有限弱测试集 E 选真实末次见证边长 R(x)，使
\[
\mu Q(x,R(x))=\lambda R(x)^n.
\]
只在此实际绝对连续输入上使用其连续性与可测性。R571 的循环单坐标二分矩形过滤，取原输入平均>λ/16 的极大矩形 H，满足
\[
\frac\lambda{16}|H|<\mu H\le\frac\lambda8|H|,\quad
\sum_H\mu H\le W.
\]
其已付中心异常集 \(\mathcal B\) 满足 \(\lambda|\mathcal B|\le16eW\)。令
\[
E_k=\{x\in E\setminus\mathcal B:2^k\le R(x)<2^{k+1}\},\quad a=2^k,
\]
\[
f_k=f1_{\cup\{H:2^k/(8n)<L_H<2^{k+2}n\}},\quad W_k=\|f_k\|_1.
\]
它给同一实际来源 f_k，并对全部 x∈E_k 保留
\[
q_k(x):=R(x)^{-n}\int_{Q(x,R(x))}f_k
\in[3\lambda/4,\lambda].
\tag{1}
\]
这是来源选择的几何结论，不是对任意集中源加一个密度帽。每个原 H 只进入至多 N_n 个这样的长度窗口，因此
\[
\sum_kW_k=\sum_H\mu H\#\{k:H\text{ enters }f_k\}\le N_nW.
\tag{2}
\]
不能将 (2) 借给任意按质量分层的来源，也不能在各 k 重新做彼此无关的完整 source decomposition 后仍保留同一 N_n。

## 3. 用真实质量带、严格阈值把每个 E_k 放进 (B)

固定 \(0<\alpha<3/4\)，取 ε>0 足够小，使
\[
\alpha<3/4-\varepsilon,\quad\varepsilon<1/6.
\]
令 \(\tau=\alpha\lambda\)，并对这个 k 固定
\[
L=(3/4-\varepsilon)\lambda a^n,\qquad
U=(1+\varepsilon)\lambda(2a)^n.
\tag{3}
\]
则
\[
U/L=2^n\frac{1+\varepsilon}{3/4-\varepsilon}<2^{n+1}.
\tag{4}
\]
例如 ε=1/8 给质量比 \((9/5)2^n\)，此时可取 α=1/2；尖锐总账则令 α↑3/4，同时缩小 ε。

将 **整个同一 f_k 来源** 按网格原子化：每格的真实质量放到格内一点，网格尺寸→0，得到有限 ν_{k,j}，总质量始终恰为 W_k。对每个固定 x∈E_k，R(x)>0 是同一个真实见证边长；cube 边界 Lebesgue 零测给
\[
q_{k,j}(x):=R(x)^{-n}\nu_{k,j}(Q(x,R(x)))\longrightarrow q_k(x).
\tag{5}
\]
故对每个这样的 x，充分大 j 时
\[
(3/4-\varepsilon)\lambda\le q_{k,j}(x)\le(1+\varepsilon)\lambda,
\quad q_{k,j}(x)>\tau.
\tag{6}
\]
令 S_{k,j}(x) 为 ν_{k,j} 中被 Q(x,R(x)) 实际捕获的 **全部** atom labels。由 (3)、R∈[a,2a] 与 (6)，其实际总质量在 [L,U]；其 threshold side length 为
\[
r_{S_{k,j}}(\tau)
=(m_{S_{k,j}}/\tau)^{1/n}
=R(x)(q_{k,j}(x)/\tau)^{1/n}>R(x).
\tag{7}
\]
所以即使某个 atom 在原见证 cube 的边界上，中心仍严格落在开放的 \(C_{S_{k,j}}(\tau)\) 内。没有用非严格质量等式替代本题严格超水平条件。

因此
\[
1_{E_k}\le\liminf_j1_{\mathcal C_{\tau;L,U}(\nu_{k,j})}.
\]
Fatou 与 (B) 给 \(\tau|E_k|\le B_nW_k\)，于是对每个 α<3/4 都有 \(\lambda|E_k|\le(B_n/\alpha)W_k\)。令 α↑3/4，得到
\[
\boxed{\lambda|E_k|\le\tfrac43B_nW_k.}\tag{8}
\]
这不需要 approximate forests、receivers 或异常集合收敛；只使用整个真实 band union 的统一估计。

## 4. 边长、closure、重 atom 与质量分割的准确边界

* **质量不是边长。** 一般任意来源的 R∈[a,2a] 不保证捕获质量在有限比质量带；这里是 (1) 的双侧平均帽才给 \(m=qR^n\) 的 \((4/3)2^n\) 比，近似后用 (4) 留余量。r_S(τ) 是由 cluster 总质量定义的阈值边长，通常不等于 R；forest 定理只需 mass band，因此 (7) 的轻微 side enlargement 不产生另一个体积费。
* **初始 clusters 已 closed。** S_{k,j}(x) 取 Q 中全部 atoms，其 coordinate bounding box 包含于 Q；因此其 source-hull closure 不会再加新原子。故 (B) 也可仅要求支付该 mass band 内全部 source-box-closed S 的 union；(5)–(8) 原证明不变。这里不需要将非closed S closure 后仍强称其质量留在 band。未来 uncrossing 若改用不同 cluster T，可能 m_T>U；这不能静默继续使用同一个 band 定理。若原 S labels 本身保留为 forest nodes，质量>U 的 ancestors 可以由定理的 upper truncation 处理；若只剩超出 band 的新盒覆盖原 receiver，则还欠该新盒的真实费用。
* **单个重 atom。** 在 (B) 内，m_i>U 的 atom 不可能属于任何 admitted S，删除它不改变该 band union。质量在 [L,U] 的 atom 可以合法成为 retained base，β=1；R573 高-β pruning/base 总账已经允许它，不能另假设所有 atom leaves 都低 β。原 atomic 全水平集若由 m_i>U 的 atom 贡献，这个 band 并不覆盖它；不得按 R 的小边长强行给它指定小质量。
* **这里不必任意拆 atom 修带。** 实际 L1 网格原子化与 (5) 已足够。有限 atom 若人为拆成同位置的真质量 pieces，只有当各 piece 总质量仍为原 m_i、所有 cluster 使用同一公共 refinement 时才不复制 source。不同 receiver 私自拆标签后各领原质量是非法的。cube 实际捕获同位置的全部 pieces；选择其中一部分是新 subsource cluster，必须重新验证严格阈值，且没有解决 crossing/forest 选择。
* **nonatomic 分割是来源的共同操作。** 网格分割对全部中心同时固定，来源总质量 W_k 不变。不同 j 是证明极限，并不累加来源费用。有限几何整理中若要选用部分 L1 mass，也必须保留真实共同可测子源；R571 并未授权按 receiver 免费复制它。

## 5. 总账、恢复与没有自动获得的费用

先对有限个 k 求和，再令 octave 集增至全部整数，由 (2)、(8) 与异常集费用得到 (A)。随后取 \(f_j=\min(f,j)1_{[-j,j]^n}\uparrow f\)，非负单调收敛与 sup 交换给 \(M f_j\uparrow M f\)，严格超水平集单调极限保留同一常数；不对截断 j 累加 W。有限弱测试集可逐步增大，得到整个水平集。

若真的有 (C)，则此路线的准确最终费用是
\[
\lambda|\{Mf>\lambda\}|\le
\left[16e+\frac{56}{3}N_nP_n\sqrt n\right]W.
\tag{9}
\]
P_n 若为 polylog，便达到所需根阶乘固定对数幂。P_n 当前未付。

本桥使用 R571 第一段、源格保留前的共同 f_k 入口。它不使用冻结 Q0/Φ、bulk 删除、γ/G 动作或平移源格，所以不引入其 D、C0、J 或 \((1-\eta)^{-1}\) 因子，也不能从该路线虚领/抵扣那些分支费用。若未来几何构造额外依赖固定源格或 source-cell qualification，须重新检查并支付它的保留量，不能只借这里有利的常数。

**准确停止点：** 现有森林单带定理与一般 L1 之间的质量比、严格阈值、原子化和来源累计可以按以上证明闭合；尚未闭合的是 (B) 的完整 crossing cluster union；一种充分实现方式是给出真正覆盖它且总 root source mass 受控的森林/联合接收构造。没有把这个假设性几何输入称作已证新进展。交付后停止，待审。

## 附录：已核 H2 好区与完整残余预算的精确接账

仅使用独审 `/tmp/ccu_r574_statement_audit.md` §§4–5 已核结论，不重做几何。对固定整个 finite atomic ν、固定阈值 τ，按其**全部**高 β 子集构造同一个 greedy 族，取 \(b=n^{-1/2}\)、A=2，得到 \(H_2(\nu,\tau)\)，满足
\[
\tau|H_2(\nu,\tau)|\le2\sqrt nW.
\tag{10}
\]
它依赖整个 ν 与 τ；不是只由质量带 [L,U] 决定，也不是可在不同来源间不经证明共用的固定集合。

**单质量带残余。** 若另外真正证明、对全部 allowed ν、τ、[L,U] 一致有
\[
\tau|\mathcal C_{\tau;L,U}(\nu)\setminus H_2(\nu,\tau)|\le D_nW,
\qquad U/L\le2^{n+1},
\tag{11}
\]
则分解 receiver 集合并用 (10) 即得到 (B)，准确可取
\[
\boxed{B_n=2\sqrt n+D_n.}\tag{12}
\]
若几何仅覆盖本桥实际用到的 closed-cluster band family，(11) 可作同样限制，恢复证明不变。D_n 必须对整个残余 union 付费，不能是逐见证、逐节点或逐来源的未合并估计。

将 (12) 代入已经证明的桥，得到
\[
\boxed{\lambda|\{Mf>\lambda\}|
\le\left[16e+\frac83N_n\sqrt n+\frac43N_nD_n\right]W.}\tag{13}
\]
在该实际恢复中，原子输入分别是 \(\nu_{k,j}\approx f_kdx\)，所以好区分别为 \(H_2(\nu_{k,j},\alpha\lambda)\)。每个 j 不是一笔新费用，但不同 k 的来源确实不同；现有合法总账是 \(\sum_k2\sqrt nW_k\le2\sqrt nN_nW\)。没有证明这些好区由原输入的一份 H2 覆盖，也没有证明它们的 receiver union 仅费 \(2\sqrt nW\)，故不能从 (13) 移除好区项的 N_n 或密度因子 4/3。

对于**同一个** ν、τ，(10) 确实跨其全部质量带一次有效。然而若 (11) 仅逐带成立，残余部分仍可能重复领取 W；固定 ν 的好区一次付款不使逐带残余自动可求和。要获得全尺度常数必须另付完整残余，或给实际可求和的来源/receiver 总账。

**完整全尺度残余。** 若真正证明更强的一致命题
\[
\tau|\{M_\square\nu>\tau\}\setminus H_2(\nu,\tau)|\le D_nW
\quad\text{对所有 finite atomic ν 与所有 τ>0},
\tag{14}
\]
则 (10) 直接给原子弱型常数 \(K_n=2\sqrt n+D_n\)。此时无需 R571 来源局部化，任意 L1 保持**同一** K_n，没有 16e、N_n 或 4/3：

1. 对紧支撑 f≥0，把每个缩小网格格子的真实 f 质量移至格内一点，得到有限 ν_j，总质量恒等于 ∥f∥1。
2. 对任意固定真实 cube Q(x,t)，membership 改变只来自边界的网格厚层，故
   \[
   |\nu_j(Q(x,t))-\int_{Q(x,t)}f|
   \le\int_{\operatorname{dist}_\infty(y,\partial Q(x,t))\le\delta_j}f(y)dy\to0.
   \]
   边界 Lebesgue 零测，因而每个严格见证 \(t^{-n}\int_Qf>\lambda\) 对充分大 j 仍是 \(M\nu_j>\lambda\) 的见证。
3. 所以 \(1_{\{Mf>\lambda\}}\le\liminf_j1_{\{M\nu_j>\lambda\}}\)。Fatou 与原子完整弱型给 \(\lambda|\{Mf>\lambda\}|\le K_n\|f\|_1\)。H2 对象已在原子完整总账中消去，不需任何 H2_j 的收敛。
4. 对一般非负 L1，取 \(\min(f,j)1_{[-j,j]^n}\uparrow f\)，严格超水平集单调极限即保留 K_n。对 |f| 同样成立。

因此 (14) 若付出，将直接给一般 L1 的 \(2\sqrt n+D_n\) 常数；当前只知好区 (10)，(11)/(14) 的完整残余预算仍未证明。此附录不把单独的 atomic H2 几何对象宣称为已对一般 L1 单独构造成功。附录完成，停止待审。
