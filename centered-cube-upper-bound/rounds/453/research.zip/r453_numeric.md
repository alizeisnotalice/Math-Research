# R453 固定坐标外中心费用的真几何有限检查（冻结）

六个 R451 真 q-exact/octave 场均完成整 receiver-box 距离门的 Fraction 积分，并在同一几何上独立最大化 T₁。六例都有相等的有理原解/对偶；R451已证的 M₂最优 source 在六例中也均达到 T₁最大值。未见本组 n≤3 的 T₁/W 明显随维数放大，但这不认证猜想中的任意几何统一单坐标界。

## 1. 输入及真几何资格

从 `r451_numeric_certificate.json` 只抽取必要 source/center坐标、packet/block半宽、R、q、已认证最优a和两个M₂基准，存入本轮 `r453_numeric_input.json`。该文件记录旧原文件SHA256和原case索引；重跑不需要R451文件。脚本重新核完整Cartesian坐标全集、唯一single-valued R、source/center不交、每个packet×整个receiverblock的严格全capture/miss、uniform与已证a的完整q匹配。

n=1,2,3，source packets位于 `{−3/4,−1/4,1/4,3/4}^n`，半宽1/1000；center blocks位于 `{−1/2,0,1/2}^n`，半宽h=6/25，单block体积v=(12/25)^n。单尺度全R1；两尺度仅全零center block取R2，其余R1。W1，q=2^-n，q-band比例r=1，octave≤2，完整源f是这些packet上的常密度函数。未加入任意incidence，未实现原history或winner最大化。

## 2. T₁定义与整区间门

本轮逐字计算

`T₁=∫f(y)∫_{R_B≤R_A, |A₁−B₁|>R_A/2} c_A(y)c_B(y)/(R_A^n R_B^n) dA dB dy`。

等side时A,B两个方向均保留，未擅自除2。门只涉及第一坐标，其余坐标整块积分贡献 `(2h)^{2(n−1)}`。对区间 `[l,u]×[p,q]`，

`area{A−B>t}=[(u−p−t)+²−(l−p−t)+²−(u−q−t)+²+(l−q−t)+²]/2`。

再加交换A,B后的项得绝对值门；边界线为零测集。两端R均1时，第一坐标center差0、1/2、1对应area为0、`(2h)²/2`、`(2h)²`。所有含R2的允许pair area均0：R2作A时阈值1，而最大第一坐标距离不超过 .5+.48=.98；R2作B而A侧R1时不满足side次序。脚本逐pair精确核这些area，绝未用中心点代替距离门。

每个 source i 的线性费用为真pair面积乘捕获与side分母之和。为LP缩放，除以v²。独立closed-form核：令 I₁=1_{第一source坐标inner}，k=其余inner坐标数，则单尺度费用是 `I₁4^k`；两尺度是 `I₁4^k−2^{n−1}1_{所有坐标inner}`。只有原中央R1块捕获所有inner source时才有删除项，不能对其他source也扣掉。

## 3. 三阶段结果及维数费用

为免单位混淆，记 `D₂=q²∫fJ²/W`（即R451目标）；原未归一二阶矩为 `M₂raw/W=D₂/q²`。下表所有量均按W=1归一：

| 阶段 | n；selector | uniform T₁ | 已证M₂最优a的T₁ = 独立maxT₁ | T₁/D₂（最优a） | n·maxT₁ |
|---|---|---:|---:|---:|---:|
| 初步 | 1；R1 | .1152 | .1152 | 1/5 | .1152 |
| 初步 | 1；中央R2 | 0 | 0 | 0 | 0 |
| 压力 | 2；R1 | .0663552 | .0663552 | 1/5 | .1327104 |
| 压力 | 2；中央R2 | .03981312 | .05308416 | 16/97 | .10616832 |
| 扩大 | 3；R1 | .0382205952 | .0382205952 | 1/5 | .1146617856 |
| 扩大 | 3；中央R2 | .032105299968 | .039749419008 | 208/1029 | .119248257024 |

所有小数均为精确有理数的终止表示。对应最优a的D₂依次是 .576、.5184、.331776、.32182272、.191102976、.196644962304；与R451基准逐项Fraction复核。若按未归一M₂raw比较，则上表T₁/D₂再乘q²=4^-n：单尺度为1/20、1/80、1/320；两尺度非零项为1/97、13/4116。JSON另存uniform与T₁-LP最优source的全部比值。

`n·maxT₁` 是固定几何中，对所有source质量的n个坐标分别取最大再作union上界的收费；它不是实际坐标事件并集的精确质量，也不能直接等同总D₂。几何坐标对称，所以每坐标最大值相同，但无需假定某个最优source自身对称。

### 结构性判断

单尺度T₁也是capture rowspace目标：取仅center第一坐标为0的行，系数 `3^(其余零坐标数)`。脚本对每source精确核该线性identity，得 `T₁=v² 5^{n−1}/2^n=D₂/5`。因此单尺度不存在通过集中source提高T₁的空间，不能把稀疏LP解说成搜索增益。

两尺度n2、n3保留R451的source关联效应。其T₁相对uniform分别提高4/3、13/10；M₂最优a亦达到T₁最优，但最优source不声明唯一。当前数值只支持“这个有限场的同一相关性可同时增大二阶矩及坐标费”，没有任何任意场或随n增长结论。

## 4. 独立T₁ LP证书

在固定真实capture B下，最大化缩放后的线性source费用c·a，约束 `Ba=qR^n`、Σa1、a≥0。dual采用自由λ、β：`β+Bᵀλ≥c`，upper=`β+λ·qR^n`。HiGHS只定位候选；Fraction恢复所有a、λ、β，逐列核slack≥0并核primal=dual。六例修复量0，缩放最大值为 `1/2,0,5/4,1,25/8,13/4`。全原解/对偶及pair-area矩阵均在certificate。

## 5. 实跑及冻结

```sh
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/r453_numeric.py
```

实际Python3.12.14、SciPy1.18.1。7318项精确检查PASS；最后冻结运行 .35秒，最大RSS74,579,968 bytes。六个小LP，最大64source变量，未扩大geometry或维数、未作扫描。仅改本轮numeric*；无git/spawn/repo/他人修改。

冻结白名单：`r453_numeric.py`、`r453_numeric_input.json`、`r453_numeric_certificate.json`、`r453_numeric_run.txt`、`r453_numeric_resources.txt`、`r453_numeric.md`、`r453_numeric_compute_index.md`。同目录自含复现，原R451文件只作提取来源无需随包。任务完成停止。
