#!/usr/bin/env python3
"""Exact whole-receiver-box fixed-coordinate outer-center gate, six native fields."""
from fractions import Fraction as Q
from pathlib import Path
import json,sys,platform,hashlib
from itertools import product
import numpy as np
import scipy
from scipy.optimize import linprog
ROOT=Path(__file__).resolve().parent
INPUT=ROOT/'r453_numeric_input.json'
DATA=json.loads(INPUT.read_text());checks=0
def ck(x):
 global checks
 assert x
 checks+=1
def pos(x):return max(Q(0),x)
def one_sided(l,u,p,q,t):
 return (pos(u-p-t)**2-pos(l-p-t)**2-pos(u-q-t)**2+pos(l-q-t)**2)/2
def far_area(a,b,half,threshold):
 l,u=a-half,a+half;p,q=b-half,b+half
 return one_sided(l,u,p,q,threshold)+one_sided(p,q,l,u,threshold)
def solve(spec):
 n=spec['n'];multi=spec['multiscale'];half=Q(spec['center_halfwidth']);ph=Q(spec['packet_halfwidth']);length=2*half;v=length**n
 source=[list(map(Q,p)) for p in spec['source_points']];centers=[list(map(Q,p)) for p in spec['center_points']]
 R=list(map(Q,spec['R']));q=Q(spec['q']);old_a=list(map(Q,spec['source_mass']));uniform=[Q(1,len(source))]*len(source)
 ck(source==[list(x) for x in product([Q(-3,4),Q(-1,4),Q(1,4),Q(3,4)],repeat=n)])
 ck(centers==[list(x) for x in product([Q(-1,2),Q(0),Q(1,2)],repeat=n)])
 ck(R==[Q(2) if multi and all(z==0 for z in c) else Q(1) for c in centers])
 ck(q==Q(1,2**n) and ph==Q(1,1000) and half==Q(6,25))
 ck(all(max(abs(x-y) for x,y in zip(a,b))>2*ph for i,a in enumerate(source) for b in source[i+1:]))
 ck(len(source)==4**n and len(centers)==3**n and max(R)/min(R)<=2)
 ck(all(max(abs(x-y) for x,y in zip(a,b))>2*half for i,a in enumerate(centers) for b in centers[i+1:]))
 capture=[]
 for a,r in zip(centers,R):
  row=[]
  for y in source:
   dist=max(abs(x-z) for x,z in zip(a,y))
   hit=dist+half+ph<r/2;miss=dist-half-ph>r/2
   ck(hit or miss);row.append(int(hit))
  capture.append(row)
 target=[q*r**n for r in R]
 for weights in (old_a,uniform):
  ck(sum(weights)==1 and all(w>=0 for w in weights))
  ck(all(sum((b*w for b,w in zip(row,weights)),Q(0))==t for row,t in zip(capture,target)))
 scaled_cost=[Q(0)]*len(source);gate=[]
 for ia,(a,ra) in enumerate(zip(centers,R)):
  row=[]
  for ib,(b,rb) in enumerate(zip(centers,R)):
   area=far_area(a[0],b[0],half,ra/2) if rb<=ra else Q(0)
   ck(0<=area<=length**2)
   expected=Q(0)
   if ra==rb==1:
    distance=abs(a[0]-b[0])
    expected=Q(0) if distance==0 else (length**2/2 if distance==Q(1,2) else length**2)
   ck(area==expected)
   row.append(area)
   coef=area/length**2/(ra**n*rb**n)
   for i in range(len(source)):
    scaled_cost[i]+=coef*capture[ia][i]*capture[ib][i]
  gate.append(row)
 # Independent exact closed-form audit of the box-pair gate on this family.
 for i,y in enumerate(source):
  first_inner=int(abs(y[0])==Q(1,4));other_inner=sum(abs(z)==Q(1,4) for z in y[1:])
  formula=Q(first_inner)*4**other_inner-(Q(2**(n-1)) if multi and first_inner and other_inner==n-1 else Q(0))
  ck(scaled_cost[i]==formula)
 rowspace=None
 if not multi:
  rowspace=[(Q(3)**sum(x==0 for x in c[1:])) if c[0]==0 else Q(0) for c in centers]
  ck(all(sum((lam*row[i] for lam,row in zip(rowspace,capture)),Q(0))==cost for i,cost in enumerate(scaled_cost)))
 d=[sum((Q(row[i])/r**n for row,r in zip(capture,R)),Q(0)) for i in range(len(source))]
 def M(weights):return v*v*sum((w*x*x for w,x in zip(weights,d)),Q(0))
 def T(weights):return v*v*sum((w*x for w,x in zip(weights,scaled_cost)),Q(0))
 ck(M(old_a)==Q(spec['optimal_target']) and M(uniform)==Q(spec['uniform_target']))
 A=np.array(capture+[[1]*len(source)],dtype=float);rhs=np.array([float(t) for t in target]+[1.])
 lp=linprog(-np.array([float(c) for c in scaled_cost]),A_eq=A,b_eq=rhs,bounds=(0,None),method='highs')
 ck(lp.success)
 opt=[Q(float(x)).limit_denominator(10**6) for x in lp.x]
 ck(sum(opt)==1 and all(x>=0 for x in opt))
 ck(all(sum((x*b for x,b in zip(opt,row)),Q(0))==t for row,t in zip(capture,target)))
 lam=[Q(float(-x)).limit_denominator(10**6) for x in lp.eqlin.marginals[:-1]]
 beta=Q(float(-lp.eqlin.marginals[-1])).limit_denominator(10**6)
 repair=max(Q(0),max(c-beta-sum((l*row[i] for l,row in zip(lam,capture)),Q(0)) for i,c in enumerate(scaled_cost)))
 beta+=repair
 slack=[beta+sum((l*row[i] for l,row in zip(lam,capture)),Q(0))-c for i,c in enumerate(scaled_cost)]
 ck(all(x>=0 for x in slack))
 dual=beta+sum((l*t for l,t in zip(lam,target)),Q(0));primal=sum((w*c for w,c in zip(opt,scaled_cost)),Q(0))
 ck(primal==dual)
 rows=[]
 for name,weights in [('uniform',uniform),('R451_M2_optimal',old_a),('T1_optimal',opt)]:
  t,m=T(weights),M(weights)
  rows.append(dict(name=name,T1_over_W=t,q2_M2_over_W=m,raw_M2_over_W=m/(q*q),T1_over_q2_M2=t/m,T1_over_raw_M2=t*q*q/m,
   dimension_union_price=n*t,dimension_union_over_q2_M2=n*t/m,source_mass=weights))
 return dict(n=n,multiscale=multi,coordinate=1,receiver_volume=v,gate_area_matrix=gate,
   T1_cost_over_volume_squared=scaled_cost,single_scale_rowspace_lambda=rowspace,rows=rows,T1_optimal_source=opt,
   scaled_primal=primal,scaled_dual=dual,dual_lambda=lam,dual_beta=beta,dual_slack=slack,dual_repair=repair)
results=[solve(s) for s in DATA['cases']]
ck(all(a['rows'][1]['T1_over_W']==a['rows'][2]['T1_over_W'] for a in results))
out=dict(scope='fixed-coordinate gate on six genuine q-exact octave fields only; no uniform coordinate theorem/history',
 executable=sys.executable,python=platform.python_version(),scipy=scipy.__version__,checks=checks,
 input_file=INPUT.name,input_sha256=hashlib.sha256(INPUT.read_bytes()).hexdigest(),results=results)
def enc(x):
 if isinstance(x,Q):return str(x)
 raise TypeError(type(x).__name__)
(ROOT/'r453_numeric_certificate.json').write_text(json.dumps(out,default=enc,indent=2)+'\n')
print('executable:',sys.executable,'Python:',platform.python_version(),'SciPy:',scipy.__version__)
for a in results:
 print('n=',a['n'],'multiscale=',a['multiscale'],'scaled_primal_dual=',a['scaled_primal'],a['scaled_dual'],'repair=',a['dual_repair'])
 for row in a['rows']:print(' ',row['name'],'T1=',row['T1_over_W'],float(row['T1_over_W']),'T1/q2M2=',row['T1_over_q2_M2'],'nT1=',row['dimension_union_price'])
print('PASS',checks,'exact checks; six tiny coordinate-cost LP certificates')
