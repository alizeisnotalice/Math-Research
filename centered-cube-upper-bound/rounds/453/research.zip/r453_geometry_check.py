"""R453: one native full-capture fixture and refinement bookkeeping, not a target bound."""
from fractions import Fraction as F
import sympy as s
from flint import arb, ctx
ctx.prec=256

# Full source packets centered at +/-1/4 with half-width 1/1000.
# Receiver cells L, O, R, all with selected cube side 1.
P=[(F(-251,1000),F(-249,1000)),(F(249,1000),F(251,1000))]
E=[(F(-3,5),F(-2,5)),(F(-1,20),F(1,20)),(F(2,5),F(3,5))]
B=[]
for lo,hi in E:
    row=[]
    for pl,ph in P:
        full=(pl>=hi-F(1,2) and ph<=lo+F(1,2))
        empty=(ph<lo-F(1,2) or pl>hi+F(1,2))
        assert full != empty
        row.append(int(full))
    B.append(row)
assert B==[[1,0],[1,1],[0,1]]
vol=[hi-lo for lo,hi in E]
mass=[sum(F(x,2) for x in row) for row in B]
assert mass==[F(1,2),F(1),F(1,2)]
X=sum(v*m for v,m in zip(vol,mass))
assert X==F(3,10)
print('stage 1: native full-capture/matching PASS; qband=[1/2,1], R=1, X=3/10')

x=s.symbols('x', real=True)
# Source-conditioned p_i(A); symmetry combines both source contributions.
outer=(s.Rational(1,20)*(1-s.log(s.Rational(1,5)))
       +s.integrate(1-s.log(x+s.Rational(3,4)),(x,-s.Rational(11,20),-s.Rational(9,20)))
       +s.Rational(1,20)*(1-s.log(s.Rational(3,10))))
central=s.integrate(1-s.log(s.Rational(1,5)-x),(x,-s.Rational(1,20),s.Rational(1,20)))
H=s.expand_log(s.simplify(outer+central),force=True)
base=sum(s.Rational(m.numerator,m.denominator)*s.Rational(v.numerator,v.denominator)
         *(1+s.log(2)+s.log(s.Rational(v.denominator,v.numerator)))
         for v,m in zip(vol,mass))
# Arb evaluation of the exact elementary log expressions.
def exact_arb(expr):
    if expr.is_Rational: return arb(int(expr.p))/int(expr.q)
    if expr.func==s.log: return exact_arb(expr.args[0]).log()
    if expr.func==s.Add: return sum((exact_arb(a) for a in expr.args),arb(0))
    if expr.func==s.Mul:
        out=arb(1)
        for a in expr.args: out*=exact_arb(a)
        return out
    if expr.func==s.Pow and expr.args[1].is_Integer: return exact_arb(expr.args[0])**int(expr.args[1])
    raise ValueError(expr)
Hb,baseb=exact_arb(H),exact_arb(base)
assert Hb>0 and baseb-Hb>0
print('stage 2: exact source-conditioned entropy =',H)
print('stage 2: 256-bit Arb entropy =',Hb.str(18),'cell upper =',baseb.str(18),'PASS')
for N in (2,16):
    refined=sum(s.Rational(m.numerator,m.denominator)*s.Rational(v.numerator,v.denominator)
                *(1+s.log(2)+s.log(s.Rational(N*v.denominator,v.numerator)))
                for v,m in zip(vol,mass))
    assert s.simplify(s.expand_log(refined-base,force=True)-s.Rational(3,10)*s.log(N))==0
    print(f'stage 3: subdivide every receiver cell into {N} equal cells: exact upper increase = (3/10)log({N}); actual E_i and entropy unchanged')
print('No optimizer, no source-density cap, no original-history claim, and no dimension-uniform second-moment certificate.')
