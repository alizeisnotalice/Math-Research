# R453：阈值半径外层选择器的既有记录定位

**定位结论。** 在本次限定关键词检索及抽取的项目文件中，没有找到已经按每个中心 (A) 定义

\[
R_A=\sup\{R:\mu(Q(A,R))/R^n>q\},\qquad
m_A=qR_A^n,\qquad \mu(Q(A,s))/s^n\le q\ (s>R_A)
\]

并为该选择器支付具体费用的既有证明。这里仅报告有限范围检索结论，不据此断言项目其他未检索文件不存在此对象。也没有认证上述半径对任意 (L^1) 全尺度输入可测、达到等号或满足所需弱型支付。

最接近的既有内容有三类，但都不是这个选择器：

1. [direct_capture_mass_band_square_20261007.md](/Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/direct_capture_mass_band_square_20261007.md:17) 对**已给定**的 receiver 集 (E) 和已给定的可测 (R(x))，只假设 (m(x)=\mu(Q_x)>\tau R(x)^n)；按完整捕获质量 (m(x)) 分 dyadic bands。其具体结论在 §3 (5)–(7)：每带 (T_k(y)\le2)，且 ∫Σ_k T_k^2dμ\le2I_1)。这是以仍未支付的 (I_1=\tau|E|) 为右端的来源平方预算，不是 (O(W)) 费用，也不要求 R 为赢家；文本没有选择阈值最后半径。
2. [gated_occupancy_bridge.md](/Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/gated_occupancy_bridge.md:13) 冻结实际 hard winner (R(x))、硬幅度带和 FIRST 等门；§3 起有 cone 径向恒等式，概述及后续段给既有全窗 (O(n)W) 粗费用及固定窄尺度子支。选择器是原 winner；没有由 (\sup\{R:\text{average}>q\}) 构造 (R_A)。[single_capture_source_rearrangement_20261007.md](/Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/single_capture_source_rearrangement_20261007.md:9) 也保留既有真实 finite winner / 已给合法 selector，证明的是背景加 spike 的 isolated profile 费（§2–3），非任意 (L^1) threshold-radius 费。
3. [adaptive_core_source_budget_20261007.md](/Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/adaptive_core_source_budget_20261007.md:52) §3 确有“每节点仅冻结一份最大半径证书”，从有限网格的可认证半径选最大 (r_P)，并以核心体积 (K_P+Qr_P) 只付一次。但 (r_P) 是来源核心覆盖证书半径，选择资格不是 cube average (>q)；它不定义 (m_A=q r_P^n) 或所有更大尺度平均 ≤q。§6 有固定并集/坏来源清算；§7 的几何组件局限于有限来源树，报告明确不是原 φ/FIRST/fullhistory。

另查 `/tmp/r410_geometry.md` §末端的 last-exit/半径 CDF 片段：这是把 (c_u(y)\mu(du)) 推到半径轴、按累计质量 (J_y(R_u)) 分位截断，费用来自精确 (R_u^{-n}) 尾；它不是对 receiver (A) 取平均越阈外层半径。rounds/028–029 的“最后退出”则是多标记路径死亡/终端分解，同样不是该阈值半径选择器。

**任意 (L^1) 全尺度覆盖：未找到/未证。** 本检索命中的费用分别是 (2I_1)、原资格下 (O(n)W) 或有限来源核心证书预算；均不能据此声称新 outermost selector 已有低阶费用或一般全尺度适用性。
