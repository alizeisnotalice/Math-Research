# R453 — ordered receiver pairs: the paid interior and the exact exterior obstacle

**Outcome:** no new payment of the complete target. This note screens one scale-ordered, coordinate-by-coordinate argument. The interior-center estimate is an application of the old center-volume mechanism, not a new root breakthrough. The exterior slice and outermost-selector steps below have not furnished the missing source budget.

## 1. Finite model and actual ordered pairs

Use R451 finite geometry and R452 approximation: full source mass W, genuine disjoint positive-volume source boxes and receiver-center boxes; each center box has one selected side in [a,b], b≤2a; complete capture/exclusion on each source box; m_A=f(Q_A)=q_A R_A^n with θ≤q_A≤rθ. No matrix not realized by these cubes is admitted.

Let

    D(y)=∫E c_A(y)dA/R_A^n,
    C=∫f D²=Σ_i a_i(Σ_j B_ji v_j/R_j^n)².

For W=1 this is the requested finite objective. Order actual pairs by side, breaking equal-side ties lexicographically in their centers. The diagonal has zero product Lebesgue measure, including within a receiver box. Thus C is twice the integral over ordered pairs (B,A), R_B≤R_A, with kernel

    I_AB/(R_A^n R_B^n),   I_AB=f(Q_A∩Q_B).                    (1)

The denominators are the actual selected sides. Matching, source correlations and actual center volumes remain present.

## 2. Interior-center pairs are absorbable

On ordered pairs with B∈Q_A, use I_AB≤m_B≤rθR_B^n and integrate the actual B centers, whose union inside Q_A has volume at most R_A^n. Consequently

    O_in≤rθ|E|≤r∫fD≤r sqrt(WC).                             (2)

Writing O_out for the other ordered pairs,

    C=2O_in+2O_out≤2r sqrt(WC)+2O_out,
    C≤4r²W+4O_out.                                         (3)

No number of scale bands is charged. The same proof allows arbitrary positive restrictions. It is the previously used center-inside-volume estimate applied to the stronger second-moment objective; it does not estimate O_out or refund any old receipt.

For exterior pairs assign the first coordinate k with |A_k−B_k|>R_A/2. Denote the resulting disjoint ordered sets by S_k. Then

    O_out=Σ_k O_k,
    O_k=∫_{S_k} I_AB dA dB/(R_A^n R_B^n).                  (4)

A bound O_k≤C(r)W for every k would suffice, but is not proved here.

## 3. Fubini preserves matching only before taking a slice

Write a source as (x,t), where t is coordinate k. Let H_A be the transverse cube, I_A the longitudinal interval, and

    m_A^k(x)=∫_{I_A}f(x,t)dt,
    I_AB^k(x)=∫_{I_A∩I_B}f(x,t)dt.

The exact version of (4) is

    O_k=∫dx∫_{S_k}1_{H_A∩H_B}(x) I_AB^k(x)
                          dA dB/(R_A^n R_B^n).            (5)

Full matching says ∫_{H_A}m_A^k(x)dx=m_A. It does not put the individual slice average m_A^k(x)/R_A in [θ,rθ]. In addition, projecting the actual centers at fixed x produces a measure on longitudinal center and side, with transverse weight 1_{H_A}(x)dA/R_A^(n−1). It is not a single one-dimensional Lebesgue selector. Both issues must be addressed before importing a one-dimensional matched estimate.

A positive Hölder repair does preserve the full masses, but has an additional coefficient. Put

    p_A^k(x)=1_{H_A}(x)m_A^k(x)/m_A,
    β_AB^k(x)=I_AB^k(x)/sqrt(m_A^k(x)m_B^k(x)),

with zero values for zero denominators. Then 0≤β≤1 and

    I_AB=sqrt(m_A m_B)∫sqrt(p_A^k p_B^k)β_AB^k dx,
    I_AB²≤m_A m_B |H_A∩H_B|∫p_A^k p_B^k(β_AB^k)²dx.        (6)

These are genuine full-mass identities/inequalities. However, the last density-product integral has no established source-integrable bound under the actual matching constraints. Merely replacing it by a uniform transverse density is invalid. Using only the probability/Hellinger bound instead returns I_AB≤sqrt(m_A m_B), weaker than the already available I_AB≤min(m_A,m_B). No additional abstract coefficient is proposed as a paid target; this repair has not established (4)'s required price.

## 4. Extra outermost-radius control: exact direction and inflation

The parent additionally asked to test a **new** selector satisfying m_A=qR_A^n and f(Q(A,s))≤qs^n for every s>R_A. Such a selector is an extra hypothesis, not a property of the arbitrary frozen finite field or its original histories.

Let d=||A−B||∞. For an exterior ordered pair with positive intersection volume, the smallest A-centered cube containing Q_A∪Q_B has side

    L_A=max(R_A,2d+R_B)=2d+R_B,
    1+R_B/R_A<L_A/R_A<1+2R_B/R_A.                         (7)

The upper inequality may safely be made non-strict when boundaries are included. In an octave the lower ratio exceeds 3/2 and the upper is at most 3. Thus direct isotropic inflation can have an exponential volume factor.

More decisively, the outermost condition gives

    f(Q(A,L_A)\Q_A)≤q(L_A^n−R_A^n),
    I_AB≥m_A+m_B−qL_A^n.                                  (8)

The first controls B\A from above; the second is a **lower** bound for the positive overlap appearing in (1). It is not the upper bound needed in (4). This does not rule out a more joint use of all outer-radius constraints. It rules out paying O_out merely by this enclosing-cube substitution. A containing box at a new center cannot be assigned an actual receiver's matching or outermost qualification for free.

## 5. Computation and stopping decision

The local designated math Python ran `r453_mainproof_check.py`; stdout is `r453_mainproof.result.txt`. **121 Fraction assertions** check nine positive-volume cube configurations (n=1,2,9; side ratios 1/2,3/4,1), the minimal containing side, the exterior/intersection conditions, and the direction in (8). Two scalar union-mass cases additionally check that direction. This is exact geometry/algebra, not an outermost full-f selector or an original-history certificate. No expanded Hölder counterexample search was run.

The result is the explicit interior absorption (3), the unchanged exterior integral (4) with its true slice weights, and a failed direct use of extra outermost control. No general nW estimate, new whole-flow receipt, or closure follows. The complete original remainder and mother ledger remain unchanged.
