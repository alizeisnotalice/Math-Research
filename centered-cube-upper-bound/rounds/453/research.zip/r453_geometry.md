# R453 — source-conditioned center entropy: exact finite cost, no uniform payment

**Outcome.** No new bound for \(\sum_i a_i d_i^2\) is proved. One possible spatial compensation was screened: centers which rarely capture other centers associated with the same source should carry an entropy price. Keeping the source condition is essential, but the only rigorous cost obtained here contains a partition entropy. It is not stable under refinement and cannot be fed into the R452 approximation theorem as a uniform estimate. This is a bounded scope attachment, not a new paid branch or a claim that the full target fails.

## 1. The actual finite geometry and the proposed source condition

Use exactly the R451 finite full-capture model. Source packets \(P_i\) are disjoint positive-volume boxes with masses \(a_i\), \(\sum_i a_i=1\). Receiver center boxes \(E_j\) are disjoint, have volumes \(v_j\), and have fixed selected cube side lengths \(R_j\). The whole packet \(P_i\) is either captured by every center of \(E_j\), or captured by none; its incidence is \(B_{ji}\). Full matching is
\[
m_j=\sum_i a_iB_{ji}=q_jR_j^n,
\qquad \theta\le q_j\le r\theta.
\]
No source independence is assumed. Zero-mass source packets may be omitted.

For each source packet define its actual center set
\[
E_i^{\rm src}=\bigcup_{j:B_{ji}=1}E_j.
\]
For \(A\in E_j\) with \(B_{ji}=1\), put
\[
p_i(A)=\frac{|E_i^{\rm src}\cap Q(A,R_j)|}{R_j^n},
\qquad \ell_i(A)=\log\frac{e}{p_i(A)}.
\tag{1}
\]
This is a Lebesgue-center quantity conditioned on the **same** captured source, not a source-mass estimate from volume. Replacing \(E_i^{\rm src}\) by the full receiver set would discard this condition: additional centers not capturing packet \(i\) could enlarge that replacement without changing \(d_i\).

The contemplated compensation cost is the concrete positive integral
\[
\mathcal H=\sum_j\frac1{R_j^n}
 \int_{E_j}\sum_i a_iB_{ji}\ell_i(A)\,dA.
\tag{2}
\]
It is not a free center price in the matching dual: its integrand depends on the source label \(i\). In particular one cannot replace \(\sum_i a_iB_{ji}\ell_i(A)\) by \(m_j\) times a source-independent quantity without proving a suitable bound. No pointwise majorization of \(d_i^2\) by these entropy terms is asserted here.

## 2. The proved native finite estimate

Every receiver row has positive mass. Choose a positive-mass packet captured by row \(j\). Full capture across all centers of \(E_j\) forces each coordinate side length of \(E_j\) to be at most \(R_j\): the allowed centers in that coordinate must all lie in the interval which captures the whole corresponding packet interval.

For every \(A\in E_j\), it follows coordinatewise that
\[
|E_j\cap Q(A,R_j)|\ge2^{-n}v_j.
\]
This includes centers on the boundary, or can be read almost everywhere without changing any integral. Since \(E_j\subset E_i^{\rm src}\) when \(B_{ji}=1\),
\[
p_i(A)\ge\frac{v_j}{2^nR_j^n},
\qquad
\ell_i(A)\le1+n\log2+\log\frac{R_j^n}{v_j}.
\tag{3}
\]
Using the complete matching sum, rather than a bound on individual source densities, proves
\[
\boxed{\quad
\mathcal H\le
\sum_j q_jv_j
 \left[1+n\log2+\log\frac{R_j^n}{v_j}\right].
\quad}
\tag{4}
\]
All center volumes and masses in (4) are actual. This is the rigorous estimate obtained in this attempt. It preserves arbitrary correlations among the source masses, but it is **not** the requested uniform source budget.

## 3. The refinement obstruction is a price defect, not a target counterexample

Split every \(E_j\) into \(N\) equal-volume axis-parallel boxes, keeping its selected side length, capture pattern and complete mass unchanged. This is the same receiver field. Each set \(E_i^{\rm src}\), the integral \(\mathcal H\), and every \(d_i\) are unchanged.

However, the right side of (4) increases by exactly
\[
\sum_jq_jv_j\log N=X_q\log N.
\tag{5}
\]
Thus the local-cell estimate cannot be made uniform by passing to finer full-capture boxes. In particular this price cannot be inserted into the R452 approximation argument and treated as a dimension-only constant.

The missing geometric operation for this attempted compensation is to aggregate the shared sets \(E_i^{\rm src}\) **before** charging entropy, while preserving their correlation with the full source weights \(a_i\). Bounding them separately by the current receiver cell produces (5); replacing them by the full receiver set loses the source condition. Neither operation supplies the missing uniform comparison. The attachment does not propose the existence of that comparison as a theorem or count (2) under a new name as a payment. No complete dual certificate for the original objective has been obtained.

## 4. Bounded native check

The designated local Python ran `/tmp/r453_geometry_check.py`; output is `/tmp/r453_geometry.result.txt`. It checks one actual finite full-capture geometry, not an arbitrary incidence table:

- Dimension one; two source packets centered at \(\pm1/4\), half-width \(1/1000\), each of mass \(1/2\).
- Receiver center intervals \([-3/5,-2/5]\), \([-1/20,1/20]\), and \([2/5,3/5]\), all with selected side length one. Their capture rows are \((1,0),(1,1),(0,1)\), verified with exact rational endpoint inequalities.
- The true masses are \(1/2,1,1/2\), so the band is \([1/2,1]\), and \(X_q=3/10\).

Exact symbolic integration of the source-conditioned overlaps gives
\[
\mathcal H=\frac12+\frac{\log10240}{20}-\frac{\log3}{5}
\approx0.7419803872.
\]
A 256-bit Arb evaluation verifies the cell upper bound \(\approx1.060090246\). The two refinement checks \(N=2,16\) verify the exact increase \((3/10)\log N\) in that upper bound while the real geometry and \(\mathcal H\) stay fixed. These are three bounded verification stages, with no optimization, parameter search, or original-history claim.

The check certifies the finite geometry and the refinement bookkeeping only. It does not establish a high-dimensional estimate, nor disprove the desired one. The original budget is unchanged, and the attempt stops here.
