from fractions import Fraction as F

checks=0
print('n, R_B/R_A, center_distance/R_A, L_A/R_A, dilation_volume')
for n in (1,2,9):
    for t in (F(1,2),F(3,4),F(1)):
        R=F(1); r=t; dist=F(1,2)+t/4
        ca=[F(0)]*n; cb=[dist]+[F(0)]*(n-1)
        L=max(R,2*dist+r)
        assert dist>R/2; checks+=1
        overlap=F(1)
        for j in range(n):
            lo=max(ca[j]-R/2,cb[j]-r/2)
            hi=min(ca[j]+R/2,cb[j]+r/2)
            overlap*=max(F(0),hi-lo)
            assert -L/2<=ca[j]-R/2<=ca[j]+R/2<=L/2; checks+=1
            assert -L/2<=cb[j]-r/2<=cb[j]+r/2<=L/2; checks+=1
        assert overlap>0; checks+=1
        assert 1+t<L<=1+2*t; checks+=1
        assert cb[0]+r/2==L/2; checks+=1
        # Shrinking the proposed enclosing side fails at B's outer face.
        assert cb[0]+r/2>(L-F(1,10000))/2; checks+=1
        print(n,t,dist,L,L**n,sep=', ')
# Exact normalized-incidence compensation is already checked in R452;
# here check only the direction of an outer union upper bound.
for mA,mB,I,cap in [(F(8),F(1),F(1,2),F(10)),(F(4),F(1),F(1),F(5))]:
    union=mA+mB-I
    assert union<=cap; checks+=1
    assert I>=mA+mB-cap; checks+=1
print('PASS',checks,'Fraction assertions.')
print('Scope: exact positive-volume cube geometry and union-mass inequality direction. No outermost full-f selector or original-history realization is claimed.')
