# R453 independent audit — FINAL PASS（限定范围）

FINAL PASS：认证本轮真实有序接收对的内部吸收、保完整质量的切片恒等式/方向核验、有限source-conditioned中心熵估计及六个固定真几何T₁最优证书。**未证明外部坐标联合预算、统一有限F界、一般M2或完整原R433根价；没有新增母账付款。** 先于新作者稿形成的独立PRE保留于后。

## 1. 主公式与两篇理论附件

对同一完整f、实际Lebesgue中心、真实单值side及matching，F=∫fD²和X=∫fD的量纲/权重正确。按side排序后I_AB≤m_B≤λV_B、B∈Q_A真实中心体积≤V_A，给内部≤λ|E|≤rX。X≤√(WF)和Young给F≤4r²W+4O_out。根稿用R_B≤R_A的全有序域与坐标并集T_k，等side双计和多坐标重叠只是正上放，故同样F≤4r²W+4ΣT_k。作者先lex打破等side并取首个外坐标的O_k为相应T_k子集；二者没有混同精确并集。固定A的cube边界对B的Lebesgue测度零，纵使R_A可测也不删除正mass原子。此内部机制沿用旧体积预算，不能单独控制外部source相关性。

`mainproof` 的横向Fubini、Hellinger式(6)及Cauchy方向正确，零slice分母取零；可能无有限界的密度乘积项没有被免费丢掉。切片平均不继承完整q-band，投影不是一维单值Lebesgue selector。额外outermost条件没有被赋给原接收场；正交叠且外部时最小A中心包含side为2dist∞+R_B，式(7)区间正确。利用新outermost假设只得到式(8)的overlap下界，不能付款所需正上界。121 Fraction断言只核几何/代数方向，不认证outermost full-f场或history。

`geometry` 保同来源i的E_i，未用全E替换。正mass捕获盒保证每个接收盒坐标宽≤R_j，故|E_j∩Q_A|≥v_j/2^n，原p_i与熵上界(3)(4)成立。该熵含真实source权；每接收盒分成N份使实际E_i、D及熵不变，而已证粗上界恰增XlogN。因此现有价不是R452所需的分割一致源预算，不能把它当新receipt。一个native一维场的source-conditioned overlap分段积分与精确log表达式正确，256-bit Arb仅核该表达式/上界；N2/16细分只核同场价格退化，未反驳目标。

`selector_index` 仅为有限关键词/文件定位，不作为outermost选择器不存在的定理，不认证其任意L¹全尺度可测性、达到等号或费用。其所列旧机制未被用作新的外部交叠界。最终主稿明确这些限制。

## 2. 真有限几何T₁证书

数值输入在本轮JSON自含，脚本重新检查完整Cartesian packet/center全集、单值side、互不交正体积块、全block capture/miss及uniform/旧最优权的q-exact matching。真实门|A₁−B₁|>R_A/2在中心盒乘积上用正部平方反导数精确积分；等side两方向都保留，未用代表中心或除2。R2相关允许pair面积为零，scaled source费用及独立closed-form核一致。

六个T₁优化使用相同完整q质量约束，但独立目标；HiGHS只找候选，Fraction逐行原可行、逐列dual slack、原对偶相等与零修复认证固定几何的全可行来源最大值。单尺度capture-rowspace身份使目标恒定；两尺度n2/n3相关性增益4/3、13/10正确。T₁、q²M2及raw M2的q²因子未混；n·maxT₁是分别取每坐标最大后的union价格，不是实际并集也不是总F。n≤3不能支持维数渐近或任意几何单坐标预算。

## 3. 实际隔离复现与保留范围

指定数学Python `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python` 在新目录
`/var/folders/lq/2c4qbz2n0354_tnttkv_qsz00000gn/T/r453_audit_isolated_226yxnyr`
实际运行三个脚本。三份stdout与冻结输出逐字节一致；numeric生成JSON亦逐字节一致。最终运行geometry时再次比较前两脚本及numeric输入未变，没有重复累计覆盖。

证据分开记录：numeric六个小LP/7318精确检查，mainproof 121 Fraction断言，geometry一个native一维场的符号/Arb计算及同场N2/16细分。前两者不认证新原history实例；geometry不提供高维预算。资源文本保留作者实跑记录，不外推扣额；PRE一个旧有限模型的临时算术仅辅助独立审查，不添加正式证据文件或样本。无未修实质阻断项。

所有已证内容与根稿“没有新完整余项付款”的结论一致。R452是强无标记目标逼近桥，不能替原history传递。外部ΣT_k、统一源相关预算及原入口/初始/删除/最终吸收仍需证明；旧母账不减记，替代容量结算不重复叠加。

## 4. 最终字节绑定（15输入）

- `r453_main.md`: `825ca3f461db0970be4a8508d07a0d2c4919fe6a7a4ba8ad3468975a1d2934b7`
- `r453_geometry.md`: `d3e8e90b53304f94a9f7114d1188eb7dc0fc01c078e799061efbbdf8207fb3fa`
- `r453_geometry_check.py`: `9800a8b87e29ceb7a5ec2123a91e841d97a7f89fde3bd7f104e4abee9c469914`
- `r453_geometry.result.txt`: `af0180233b3bf9d8324a23a5c6cf7da60b75e673d1b3e6686a8ab87258043b9e`
- `r453_mainproof.md`: `d25a1c165008005a985726d58f482f479d06831305d7eef1b3f368c4aaf8310d`
- `r453_mainproof_check.py`: `6e49188c4d19ee218e5c7f3c9747eb82059c1d48be16e55d26d8dd3cbfc8c332`
- `r453_mainproof.result.txt`: `a11a54b2fee53d3c4cc31155149faaa9245191bdd8390c667e68f43f72de6c22`
- `r453_numeric.md`: `6e411b8b33e0364f1aa025855175fae5b94559d442e019232063b3b817b29a5e`
- `r453_numeric.py`: `e13e82cb1a987e43bc277c208977ae66a0dd69a4f260614e17a389e618c3ce5b`
- `r453_numeric_input.json`: `1465b35edaff6367ae310a2a018c8aff689bb19920197b527ec3673f0d0a1b18`
- `r453_numeric_certificate.json`: `dd6cff07f49763b8ece5e47b8a145e8b6b620b56fef88a5fdaa57aac5d09011b`
- `r453_numeric_run.txt`: `170341d3e792201c1388cefe5523c7ae20ef5b0eed9e66196ef96489e1c1a94e`
- `r453_numeric_resources.txt`: `5b10b033d3a7c87cd2dad49dee35a49f011d4ca813a2f3849bf1243753def0e5`
- `r453_numeric_compute_index.md`: `d66469143d7ca91431f8d4f26afa7a2cc63560f1d5b2e555f8044ca68cdb9c63`
- `r453_selector_index.md`: `c6145a55b759137bcb424c5c9efc235383e702ee4796ee6f7297d9d565384bcd`

---

# R453 independent audit — PRE

PRE ONLY。先独立核目标与可用交叠接口；已读已证R451有限弱对偶及R452逼近桥，未读R453作者新证明。没有构造统一有限预算，不认证一般M2、完整原R433或新付款。只修改本文件，完成后等待具体稿件。

## 1. 有限目标的真实量词

固定n、0<a≤b≤2a、r≥1；来源盒P_i彼此不交且正体积，接收中心盒E_j彼此不交且正体积v_j，实际单值边长R_j∈[a,b]。每一对来源/接收盒对**所有**A∈E_j都全捕获或全不捕获，B_ji为该真实关系。来源权a_i≥0、Σa_i=1，f=Σa_i1_Pi/|P_i|，V_j=R_j^n，m_j=Σ_i B_ji a_i。

必须有同一个θ>0满足θV_j≤m_j≤rθV_j；不允许逐row另选θ，或任意矩阵冒充cube。允许a_i=0，不等于允许接收mass零。若将LP闭化到θ=0，则Ba=0，只产生目标0的退化情况，不提供正q真实场。来源支持未被任何接收捕获的cell也须保总质量1，其目标贡献自然零。

d_i=Σ_j B_ji v_j/V_j是实际D(y)=∫c_A(y)dA/R_A^n在整个P_i上的值。F:=Σa_i d_i²=∫fD²，X:=Σ_j(v_j/V_j)m_j=Σa_i d_i。欲证F≤C(r)n log^A(n+2)，C与A不得暗依赖盒数、体积比、最小a_i、θ、位置或selector复杂度。每一个固定n内取任意有限盒数；不能把盒数有限当统一常数。

θJ_i≤d_i≤rθJ_i，所以θ²M2≤F≤r²θ²M2。r=1时精确等价；固定r一般band也是同阶强目标，不能凭夹界称只需覆盖q-exact即可。R452需传递到r'=(1+ε)r/(1−ε)>r；要么在每个固定r'有统一常数，ε固定，要么另证r邻域稳定。单一r=1证书或若干LP最优值不满足这个量词。

## 2. 已有的一次预算与双接收交叠的精确对象

全capture+完整来源给

    I_jk=Σ_i a_i B_ji B_ki=f(Q_A∩Q_B)  (A∈E_j,B∈E_k)，
    F=Σ_j,k v_jv_k I_jk/(V_jV_k)，
    X=∫fD， X²≤F (W=1)。

I_jk在每个接收盒对上确实常值；这是source交叠质量，不是几何交叠体积。其合法原生信息包括0≤I_jk≤min(m_j,m_k)、矩阵(I_jk)为L²(f)的Gram矩阵、全部行使用同一个来源a及同一立方体几何。单独这些代数条件不证明n级预算，且不能丢掉几何而用于任意B。

已证native径向容量D≤A_n=1+nlog(b/a)，连同matching给X≤A_n、F≤A_n X≤A_n²。它是现有二次维数预算，不能再将X默认为常数或O(√n)。∫_E D(A)dA≤|E|控制的是**中心**Lebesgue平均；F需要source fdy，二者不是同一边缘。PSD/Cauchy允许取正上界，但不凭PSD产生来源重用节省。

纯几何pair体积满足

    ∫_E² |Q_A∩Q_B|/(V_AV_B)dA dB = ∫D(y)²dy，
    ∫_{Q_A}D(y)dy≤A_n V_A。

这些合法体积/中心预算不能直接替换I_jk。来源盒可承载很高的常密度，q-band只约束整个实际cube的平均，不约束其交集、union、边界薄层或单来源cell。用I≤densitycap·intersection-volume、用qbar在union上作原matching、或将捕获source条件换成中心均值，都需新增真实证明。

## 3. 一个准确但仍未证的双接收比较接口

保持实际连续接收盒（q_A=m_A/V_A在每盒常数）。定义

    U_D=∫_E q_A [V_A^−1∫_{Q_A}D(y)dy]dA，
    Δ_D=∫_E² [f(Q_A∩Q_B)−(q_A+q_B)|Q_A∩Q_B|/2]
                         dA dB/(V_AV_B)。

则F=U_D+Δ_D是精确恒等式。差额有符号，绝非已证非负删除信用；同一个f、实际交集和两个实际q必须保留。D≤A_n、有限中心测度及正下界V≥a^n保证两部分有限，不作∞−∞。它与R451的M2版本只差真实分母，不能遗漏q_Aq_B权后混用。

可用作建设性审查门槛：若**另证**Δ_D≤ηF+C(r)n log^A(n+2)W、η<1，并对实际线性平均T_Ru(A)=V_A^−1∫QA u有统一L²(dy)→L²(dA)范数N，则

    U_D≤λ||D||²_L²(dy)≤λN²|E|≤rN²X≤rN²√(WF)，
    F≤[r²N⁴/(1−η)²+2C(r)n log^A(n+2)/(1−η)]W。

这条条件回代的权重和Young常数正确；本PRE不调用任何未核定的维数一致算子定理，更没有证明Δ_D的吸收式。若作者用独立的pair packing/Schur预算代替上述Δ条件，也必须以同一完整来源权证明实际I_jk的加权和，不能用已知体积budget当作该结论。把Δ或一个未知row平均重新命名为“交叠预算”并非新证据。

## 4. 原完整账与较弱保门目标

统一F界经R452只恢复无标记强M2；由X=∫fD≤√(WF)可得选定band/octave场的根阶中心质量。它是一般weak目标的充分强路线，未证明为必要条件。全尺度入口、原初始/删除/时钟/未来限制及总ε仍须按原完整账处理，不能以单band结论宣称已闭合。

若改走较弱原门路线，可保可测L(A,y,z)且真实原source投影≤S L σπ_A²，原支持仍Z_A(y)>(4−ε₀)h、C_A(y,z)<h。准确非负矩为

    E_{K,L}=∫σπ_A(dy)π_A(dz)L(A,y,z)[Z_A(y)−C_A(y,z)]，
    R433≤S E_{K,L}/[(3−ε₀)h]。

其新receiver展开必须保B_L(A,y,w)=∫π_A(dz)L(A,y,z)(1−c_w(z))，不是p(1−p)乘独立平均门。R452全capture逼近没有承诺继承这些history/source-dependent标记，所以有限F证书可经无标记强界支配此矩；直接有限保门结论则需另外证明门及对应实际measure的传递，不能默认免费。

若最后只得到原R≤εX+QεW，母账只在64Λ₀Fhat R槽回代；C433/V433、初始/删除/尺度费用保持，最终ε吸收另核。对同一whole-R的R447/R449容量替代不重复叠加为新增付款。

## 5. 实际本机辅助与停止

指定本机数学Python/Fraction仅核R451已存在的一维真有限几何：三接收盒体积12/25、side1，四来源cell质量1/4。精确验证sourcewise二阶矩=真实pair质量展开=72/125、X=18/25、X²≤F≤A_nX且A_n=1。该小算术只核接口，既无新扫描也无高维/history覆盖，不当一般证书。

PRE结论：目标量词和同完整f的双接收Gram/交叠恒等式合法；已有基本容量仍只给A_n²。可审核的新实质应是实际source交叠的统一加权预算（或明确的Δ_D吸收），不是体积替代、dual存在、有限检查数或原门刷新。等待作者关键步骤。
