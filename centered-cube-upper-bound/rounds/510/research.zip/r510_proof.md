# R510 主代理：共同半径放松的完整来源费用及后续约束

本稿证明一种具体放松会在线性维数处丢失信息，从而决定下一步必须保留什么；它不否定原一般根阶目标，不给原余流新增付款。父密度带固定r=1仍不足以补救丢掉共同选择的损失。

## 1. 真实有限L1模型与完整W归一

取a=1,b=2，L=nb，E=Q(0,L)，f=1_{Q(0,L+b)}，W=(L+b)^n，t=1。对每个B∈E以及每个R∈[a,b]，Q(B,R)都包含在源支撑内，故m(B,R)=R^n，q(B,R)=1。原两来源均匀于同一个Q(B,R)，历史核可取平凡，gate=1。M≥1时共同盒密度恒1，D_*仅要求s=max(2||x−B||∞,2||z−B||∞)≥a。

一个真实中心只能选一个R_B；对所有来源对使用同一R_B归一。其原余流满足
\[
R_* =\int_E[1-(a/R_B)^{2n}]\,dB
\le |E|[1-(a/b)^{2n}]<|E|<W.
\tag{1}
\]
取R_B=b达到第一个上界。这个允许任意可测共同半径的结论来自均匀后验CDF，不是有限参数猜测。

若却把选择器放进每一对来源的积分内，对每个pair在s∈[a,b]上各选R=s，则对于每个固定B，源产品体积的径向CDF为s^{2n}。该放松准确给
\[
\widehat R_* =\int_E\int_a^b s^{-2n}\,d(s^{2n})\,dB
 =2n\log(b/a)|E|.
\tag{2}
\]
这里每次小盒仍满足q=1、D_*，但这些选择彼此不再是同一个R_B。故
\[
\widehat R_*/W=2n\log2\,(n/(n+1))^n
 \ge (2\log2/e)n,
\tag{3}
\]
其中n log(1+1/n)≤1。不仅是相对于一个微小接收域的放大，错误放松本身按完整W计费也已经线性。

(2)不是原流的反例，也不能用来证明原流至少线性；(1)已明确原流在该模型小于W。它定位“逐pair最大化共同半径”会把未付几何费用重新放大的机制。原中心半径可以依赖f与B，但不能依赖随后选择的各来源pair。

## 2. 可复现网格与一般误差界

将可选半径离散为R_j=2^{j/K}，j=0,...,K，逐pair松弛在第j壳取最小容纳半径R_j。归一后每中心的准确费用是
\[
E_{n,K}=\sum_{j=1}^K R_j^{-2n}(R_j^{2n}-R_{j-1}^{2n})
=K(1-e^{-2n\log2/K}).
\tag{4}
\]
它随K上升并趋于2n log2。令c=2n log2，利用x−x²/2<1−e^{-x}<x得到
\[
c-c^2/(2K)<E_{n,K}<c.
\tag{5}
\]
单调性由对实K求导，1−e^{-c/K}(1+c/K)>0给出。故有限网格也能严格显示损失；不需要以数值外推阶数。numeric实际核K=n,4n,16n的12个配置，证明型Arb球只负责有限不等式，(4)-(5)负责一般结论。

## 3. 下一步采用的共同选择合同

按原质量分层E_j，并将原半径、原m_B、全部gate/history作为同一个中心记录保留。geometry中的原内来源列F_j，满足R_*=∫ΣF_jdμ。待证的平方重叠量是
\[
\mathcal Q=\int\sum_jF_j^2\,d\mu.
\]
若N=O_r(n)且Q≤C_r S²log^A(n+2)W，Cauchy可给完整根阶。这是充分条件而非本轮已证估计。现有Q≤C_rS R_*代回仅线性，不接受为收缩。

本轮不把“每层半径范围窄”当作可随意扩大盒的理由。放大固定半径ρ_j至多有体积γr倍，但任意L1来源在新增薄层内可任意集中；原q_B上帽不能自动搬到A_{ρ_j}f。因而下一步必须直接估原F_j，或明确支付扩大盒所引入的实际来源质量。仅保相近体积不足。

这使用A04技能的共享变量与外放松范围原则；没有援引其外部MIP最小性定理、没有调用未核验OT强对偶，也没有把有限网格当连续原问题的精确离散化。后续有限模型应把同一B的所有pair共用R_B写成共享变量，而不能对每个pair设独立选择。

## 4. 本机符号辅助检查

以下20项只复核(2)、(4)的有限代数。一般证明已在上文给出；numeric另有146项检查，geometry另有27项精确Jacobian/导数检查与3个非严格浮点对照，浮点对照不计精确证书。

```python
import sympy as s
count=0
u=s.symbols('u',positive=True)
for n in range(1,9):
    v=s.integrate(s.diff(u**(2*n),u)/u**(2*n),(u,1,2))
    assert s.simplify(v-2*n*s.log(2))==0;count+=1
for n in (1,4,16,64):
    for K in (n,4*n,16*n):
        j=s.symbols('j',integer=True,positive=True)
        rj=2**(s.Rational(1,K)*j)
        prev=2**(s.Rational(1,K)*(j-1))
        shell=s.simplify((rj**(2*n)-prev**(2*n))/rj**(2*n))
        assert s.simplify(shell-(1-2**(-s.Rational(2*n,K))))==0;count+=1
print('PASS',count,'exact shared-radius envelope identities; not an upper-bound counterexample')
```

## 5. 主代理提出的分数重叠壳：已证行消减，未证来源列

这是对硬popular阈值的建设性替代，避免要求高维捕获概率在固定阈值上保留正比例质量。对任意可测0≤p_j(y,z)≤1定义
\[
q_j(y,z)=(p_j(y,z)-\sum_{i<j}p_i(y,z))_+.
\]
设M_j=max_{i≤j}p_i、M_{-1}=0，则逐点q_j≤M_j−M_{j-1}，故
\[
\sum_j q_j\le\sup_j p_j\le1.
\tag{6}
\]
有限和直接望远镜；无限情形用非负单调收敛。并且
\[
\int q_j(y,z)\,d\mu(z)\ge\int p_j(y,z)\,d\mu(z)
 -\sum_{i<j}\int p_i(y,z)\,d\mu(z).
\tag{7}
\]
若m_j按至少Λ>1增长、所有先前行≤γm_i，而当前行≥βm_j，则
\[
\int q_j(y,z)d\mu(z)\ge[\beta-\gamma/(\Lambda-1)]m_j.
\tag{8}
\]
取Λ−1≥2γ/β，保留至少βm_j/2。没有将p当作集合，也没有使用点态来源密度帽。

在本题可取真实对称共同捕获核
\[
A_j(y,z)=\int_{E_j}t(B)R_B^{-n}1_{Q_B}(y)1_{Q_B}(z)dB,
\quad \ell_j(y)=\int_{E_j}t(B)R_B^{-n}1_{Q_B}(y)dB.
\]
原质量层m_B∈[m_j,γm_j)给行质量
m_jℓ_j(y)≤∫A_j(y,z)dμ(z)≤γm_jℓ_j(y)。逐层selector包络给ℓ_j≤C:=S[1+log(γr)]。C=0单列零流；否则p_j=A_j/C是对称、可测且≤1的核。在H_j={ℓ_j≥u}，0<u≤C，可用β=u/C；取间隔h使Λ=γ^h≥1+2γC/u，在每一个模h子序列分别构造q_j，就有H_j上的正行保留与各子序列Σq_j≤1。合并子序列最多h，不能把该费用漏掉。低于阈值u的来源也未自动删除或付款。

A_j是原真实父盒的共同捕获核；它不是完整有序gate/history本身。它可以作为原F_j≤2ℓ_j的辅助平方预算来源，但若要由q_j重新生成原硬流必须另证有价拉回，不能声称历史已经相同。

归一行θ_j(y)=∫q_j(y,z)dμ(z)之后，把H_j上的ℓ_j(y)^2转移给z会产生真实列
\[
K(z)=\sum_j\int_{H_j}\ell_j(y)^2\frac{q_j(y,z)}{\theta_j(y)}d\mu(y).
\tag{9}
\]
θ_j在H_j严格正，行量精确保留。式(6)只控制未归一q_j的点态和，不控制带θ_j^{-1}及μ(dy)积分的(9)。本轮未证明K的多对数预算，亦未完成原F_j平方界。该正分配明确修复行保留步骤，来源列与原历史连接仍须完成，不将其包装为整体根阶付款。

下面8项有限精确检查包括5个分数序列和3个嵌套分块核。分块核仅验证(6)-(8)与保留实际归一列的要求，不是原立方体输入。其中按层质量m_j除后的列分别为1、3/4、3/4，合计5/2；若改为实际行质量θ_j归一，每层列均为1，合计3。这是有限分块核的具体值，不能以点态和1改写为归一列1。

```python
from fractions import Fraction as F
seqs=[[F(0)]*4,[F(1)]*4,[F(1,4),F(1,2),F(1),F(1)],
      [F(1),F(1,2),F(1,4),F(0)],[F(0),F(1,2),F(0),F(1)]]
count=0
for ps in seqs:
    total=F(0);qs=[]
    for p in ps:qs.append(max(F(0),p-total));total+=p
    assert sum(qs)<=max(ps);count+=1
N=16;previous=[[0]*N for _ in range(N)];used=[[0]*N for _ in range(N)]
for m in (1,4,16):
    p=[[int(y//m==z//m) for z in range(N)] for y in range(N)]
    q=[[max(0,p[y][z]-previous[y][z]) for z in range(N)] for y in range(N)]
    assert all(sum(q[y])>=F(m,2) for y in range(N))
    assert all(q[y][z]==q[z][y] for y in range(N) for z in range(N))
    for y in range(N):
        for z in range(N):previous[y][z]+=p[y][z];used[y][z]+=q[y][z]
    assert max(map(max,used))<=1;count+=1
    print('fractional block',m,'row',sum(q[0]),'column divided by mass',F(sum(q[0]),m))
print('PASS',count,'exact fractional-shell checks; normalized columns remain explicit')
```
