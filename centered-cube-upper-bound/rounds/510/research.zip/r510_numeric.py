#!/usr/bin/env python3
"""Finite R510 denominator/face-anchor and true density-band experiments."""
from pathlib import Path
import json,sys,time,platform
import sympy as sp
import flint
from flint import arb,ctx
ROOT=Path(__file__).resolve().parent
ctx.prec=256
checks=0
B,s,y=sp.symbols('B s y',real=True)

def ck(x):
 global checks
 assert bool(x)
 checks+=1

def integ(expr,var,lo,hi):return sp.simplify(sp.integrate(expr,(var,lo,hi)))
def qarb(x):
 x=sp.Rational(x);return arb(int(x.p))/int(x.q)
def exactball(x):
 if x.is_Rational:return qarb(x)
 if x.func==sp.Add:return sum((exactball(a) for a in x.args),arb(0))
 if x.func==sp.Mul:
  z=arb(1)
  for a in x.args:z*=exactball(a)
  return z
 if x.func==sp.log:return exactball(x.args[0]).log()
 if x.func==sp.Pow and x.args[1].is_Rational:
  b,p=x.args;return exactball(b).root(int(p.q))**int(p.p)
 raise ValueError(x)

def paircase(e,M):
 R=1-2*B;F=2*s+2*B-1;L=s/2-B-sp.Rational(1,4)
 ck(e<=sp.Rational(1,4));ck((R.subs(B,-e))<=2)
 ck(sp.simplify(F.subs(s,R)-R)==0)
 ck(sp.simplify(L.subs(s,R)-(sp.Rational(1,4)-2*B))==0)
 # q_s=2-R/s<=1<=M throughout 1<=s<=R; D* is precisely this radial annulus.
 ck(M>=1)
 origB=sp.factor((F.subs(s,R)*L.subs(s,R)-F.subs(s,1)*L.subs(s,1))/R**2)
 oxB=integ(F*sp.diff(L,s)/R**2,s,1,R)
 ozB=integ(L*sp.diff(F,s)/R**2,s,1,R)
 ck(sp.simplify(origB-oxB-ozB)==0)
 orig,ox,oz=[integ(z,B,-e,0) for z in [origB,oxB,ozB]]
 ck(sp.simplify(orig-ox-oz)==0)
 # True face anchors: outer coordinate y=B+sign*s/2; dB dy Jacobian=1.
 # Negative face f(y)=1, positive face f(y)=3. Physical radial face dx=ds/2.
 negB=y+s/2;posB=y-s/2
 oxneg=(F/R**2/2).subs(B,negB)
 ozneg=(L/R**2/2).subs(B,negB)
 ozpos=(3*L/R**2/2).subs(B,posB)
 def neg_anchor(expr):
  a=integ(integ(expr,s,-2*e-2*y,sp.Rational(1,2)-y),y,-sp.Rational(1,2)-2*e,-sp.Rational(1,2)-e)
  b=integ(integ(expr,s,1,sp.Rational(1,2)-y),y,-sp.Rational(1,2)-e,-sp.Rational(1,2))
  return sp.simplify(a+b)
 ax=neg_anchor(oxneg);azneg=neg_anchor(ozneg)
 azpos=integ(integ(ozpos,s,1,2*(y+e)),y,sp.Rational(1,2)-e,sp.Rational(1,2))
 az=sp.simplify(azneg+azpos)
 ck(sp.simplify(ax-ox)==0);ck(sp.simplify(az-oz)==0)
 # Illustrative bad substitution: replacing the original parent denominator R^2 by F_s^2.
 rxB=integ(sp.diff(L,s)/F,s,1,R)
 rzB=integ(L*sp.diff(F,s)/F**2,s,1,R)
 rx,rz=[integ(z,B,-e,0) for z in [rxB,rzB]]
 replaced=sp.simplify(rx+rz)
 og=integ(1-(F.subs(s,1)/R)**2,B,-e,0)
 rg=integ(2*sp.log(R/F.subs(s,1)),B,-e,0)
 ck(exactball(orig)>0);ck(exactball(oz-ox)>0);ck(exactball(replaced-orig)>0)
 ck(exactball(rg-og)>0)
 ck(sp.simplify(ox+oz-ax-az)==0)
 return {'e':e,'M':M,'parent_density_band_r':1,'actual_radius_range':[1,1+2*e],'q_B':1,'F_growth_ratio_max':(1+2*e)/(1-2*e),'original_gate_pair_Dstar':orig,'original_gate_outer_x':ox,'original_gate_outer_z':oz,'independent_face_anchor_x':ax,'independent_face_anchor_z':az,'face_anchor_z_negative':azneg,'face_anchor_z_positive':azpos,'replacement_gate_outer_x':rx,'replacement_gate_outer_z':rz,'replacement_gate_total':replaced,'original_ungated_Dstar':og,'replacement_ungated_total':rg,'original_gate_arb':exactball(orig).str(35,radius=True),'replacement_gate_arb':exactball(replaced).str(35,radius=True),'replacement_minus_original_arb':exactball(replaced-orig).str(35,radius=True)}

def cluster(n,h,wide):
 r=sp.Integer(2)**n if wide else sp.Integer(2)
 Rhi=sp.Integer(2) if wide else sp.Integer(2)**sp.Rational(1,n)
 # Exact antiderivative n[logR-sum((1-h/R)^k/k,k=1,...,n-1)].
 exact=n*(sp.log(Rhi)-sum(((1-h/Rhi)**k-(1-h)**k)/k for k in range(1,n)))
 ra=arb(2) if wide else arb(2).root(n);ha=qarb(h)
 result=n*(ra.log()-sum((((1-ha/ra)**k-(1-ha)**k)/k for k in range(1,n)),arb(0)))
 upper=arb(int(r)).log();lower=qarb((1-h)**(n-1))*upper
 ck(result>0);ck(result<upper);ck(result>lower)
 return {'n':n,'h':h,'density_band_r':r,'regime':'wide_r_outside_frozen_contract' if wide else 'fixed_r_2','R_interval':[1,Rhi],'exact_integral':sp.simplify(exact),'integral_arb':result.str(35,radius=True),'rigorous_lower_bound_exact':(1-h)**(n-1)*sp.log(r),'rigorous_upper_bound_exact':sp.log(r),'integral_over_log_r_arb':(result/upper).str(35,radius=True)}

def uniform_grids():
 rows=[]
 for n in [1,4,16,64]:
  common=1-sp.Rational(1,2)**(2*n)
  previous=None
  for mult in [1,4,16]:
   K=mult*n
   exact=K*(1-sp.Integer(2)**(-sp.Rational(2*n,K)))
   ball=K*(1-arb(2).root(K)**(-2*n))
   limit=2*n*arb(2).log()
   lo=limit-limit**2/(2*K)
   ck(ball>lo);ck(ball<limit);ck(common<1)
   if previous is not None:ck(ball>previous)
   previous=ball
   rows.append({'n':n,'K':K,'K_over_n':mult,'parent_density_band_r':1,'a':1,'b':2,'M':1,'common_choice_max_original_probability':common,'inner_pairwise_choice_discrete_envelope':exact,'discrete_envelope_arb':ball.str(35,radius=True),'continuous_envelope_exact':2*n*sp.log(2),'continuous_envelope_arb':limit.str(35,radius=True),'strict_lower_bound_exact':2*n*sp.log(2)-(2*n*sp.log(2))**2/(2*K),'strict_upper_bound_exact':2*n*sp.log(2)})
 return rows

def main():
 start=time.perf_counter();pairs=[];clusters=[]
 for e in [sp.Rational(1,16),sp.Rational(1,8),sp.Rational(1,4)]:
  for M in [sp.Integer(1),sp.Rational(3,2)]:
   z=paircase(e,M);pairs.append(z)
   print('PAIR',e,M,'orig',z['original_gate_arb'],'replace',z['replacement_gate_arb'],flush=True)
 for n,h in [(2,sp.Rational(1,16)),(4,sp.Rational(1,64)),(8,sp.Rational(1,256))]:
  for wide in [False,True]:
   z=cluster(n,h,wide);clusters.append(z)
   print('CLUSTER',n,h,'r',z['density_band_r'],z['integral_arb'],flush=True)
 def ser(x):
  if isinstance(x,sp.Basic):return str(x)
  raise TypeError(type(x))
 grids=uniform_grids()
 for z in grids:print('GRID',z['n'],z['K'],z['discrete_envelope_arb'],flush=True)
 out={'uniform_shared_radius_grids':grids,'scope':'finite R510 evidence; no general geometry/history/root certification','environment':{'executable':sys.executable,'python':platform.python_version(),'sympy':sp.__version__,'python_flint':flint.__version__,'arb_precision_bits':ctx.prec},'two_cluster_model':{'f':'1[-1,-1/4]+3*1[1/4,1]','W':3,'B':'[-e,0]','a':1,'R_B':'1-2B','m_B':'R_B','q_B':1,'t':1,'nu':'dB','gate':'original x<=0','Dstar':'s>=1 and F_B(s)/s<=M*q_B','F_B_s_on_Dstar':'2s+2B-1','L_B_s_on_Dstar':'s/2-B-1/4'},'pairs':pairs,'clusters':clusters,'checks':checks,'compute_seconds':time.perf_counter()-start}
 (ROOT/'r510_numeric.json').write_text(json.dumps(out,default=ser,indent=2)+'\n')
 print('PASS',checks,'exact/symbolic/Arb strict checks; 6 pair, 6 compact-cluster, 12 analytic grid configurations')
if __name__=='__main__':main()
