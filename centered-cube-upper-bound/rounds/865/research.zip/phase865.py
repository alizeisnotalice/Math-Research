"""Certified phase densities on genuine intersections of axis-parallel cubes."""

from fractions import Fraction as F
from math import ceil, prod
from sys import version

from flint import __version__ as flint_version
from flint import arb, ctx

ctx.prec = 320
PI = arb.pi()
LOG2 = arb(2).log()
R = F(1)


def ball(x):
    return arb(x.numerator)/x.denominator


def fmt(x):
    return x.str(9)


def sinc(z):
    return arb(1) if z.is_zero() else z.sin()/z


def rational_sinc(turns):
    if not turns:
        return arb(1)
    if turns.denominator == 1:
        return arb(0)
    return sinc(PI*ball(turns))


def cube_radius(index,p):
    return R*(1+F(index,2*p))


def true_intersection(lengths,center,p):
    """Each of the p distinct cubes supplies a necessary face."""
    assert len(lengths)==len(center)>=p-1
    cubes=[]
    for owner in range(p):
        radius=cube_radius(owner,p)
        coords=[]
        for j,(length,origin) in enumerate(zip(lengths,center)):
            assert 0<length<2*R
            shift=radius-length/2
            if owner==0:
                origin+=shift
            elif owner==1+j%(p-1):
                origin-=shift
            coords.append((origin-radius,origin+radius))
        cubes.append(coords)
    result=[]
    essential=set()
    for intervals in zip(*cubes):
        lo=max(x for x,_ in intervals)
        hi=min(y for _,y in intervals)
        lower=[i for i,(x,_) in enumerate(intervals) if x==lo]
        upper=[i for i,(_,y) in enumerate(intervals) if y==hi]
        assert len(lower)==len(upper)==1
        essential.update(lower+upper)
        result.append((lo,hi))
    assert essential==set(range(p))
    assert result==[(q-L/2,q+L/2) for q,L in zip(center,lengths)]
    return result


def fejer_average(rectangle,period,groups,signs,order):
    """True mean of Fejer_order(sum signs*theta) on this rectangle."""
    lengths=[q-p for p,q in rectangle]
    mids=[(q+p)/2 for p,q in rectangle]
    center=sum(sign*mids[j]/period for group,sign in zip(groups,signs) for j in group)
    output=arb(1)
    for k in range(1,order):
        coeff=prod(rational_sinc(k*lengths[j]/period) for group in groups for j in group)
        output+=2*ball(F(order-k,order))*coeff*(2*k*PI*ball(center)).cos()
    return output


def finite_cases():
    p=4
    c=F(1,128*p)
    period=F(1)
    groups=((0,1),(2,3))
    signs=(1,-1)
    lengths=(period/2,)*4
    rect=true_intersection(lengths,(F(0),)*4,p)
    other=true_intersection(lengths,(period/2,F(0),F(0),F(0)),p)
    y=fejer_average(rect,period,groups,signs,2)
    z=fejer_average(other,period,groups,signs,2)
    assert (y-(1+16/PI**4)).contains(0)
    assert (z-(1-16/PI**4)).contains(0)
    print(f"LOW FOURIER actual four-cube intersections, Fejer_2 of phase difference: centered {fmt(y)}, shifted {fmt(z)}.")
    print("  The two means are exactly 1+16/pi^4 and 1-16/pi^4.")

    nil=true_intersection((period,period/3,period,period/3),(F(0),)*4,p)
    assert fejer_average(nil,period,groups,signs,512)==1
    print("  One full-period axis in each group gives exact phase uniformity, even for order 512.")

    groups=(tuple(range(4)),tuple(range(4,8)))
    lengths=(c,c,c/32,c/32)*2
    rect=true_intersection(lengths,(F(0),)*8,p)
    assert sum(lengths[j]>=c*R for j in groups[0])==len(groups[0])//2
    biased=[]
    for order in (8,64,512):
        y=fejer_average(rect,period,groups,signs,order)
        assert 1<y<=order
        biased.append((order,fmt(y)))
    assert fejer_average(rect,period,groups,signs,64)>50
    print("  Narrow true boxes with exactly half the axes long can be genuinely nonuniform.")
    print("  Fejer order and true mean on that box",biased)
    print("  Fejer order N has Haar mean 1 and supremum N, and the phase-difference test is nonproduct.")


def sinc_envelope(c,H):
    x0=PI*ball(c/H)
    if c<=H:
        rho=sinc(x0).max(1/PI)
    else:
        rho=1/x0
    assert 0<rho<1
    return rho


def uniformity_log(groups,r,c,H):
    """Log of m times a rigorously uniform phase-density error bound."""
    assert r>=2
    rho=sinc_envelope(c,H)
    delta_log=2*ball(H/c).log()-arb(3).log()+(r-2)*rho.log()
    return arb(groups).log()+delta_log,rho


def high_exact_box(n,groups,d,p,c,h):
    r=d//2
    # Half-integer on every long axis, so the modeled box is not a trivial
    # full-period aligned box. Each short axis is only one-third of a period.
    long=h*(F(ceil(c*R/h-F(1,2)))+F(1,2))
    short=h/3
    assert 0<short<c*R<=long<c*R+h<2*R
    assert n>=p-1 and groups*d<=n
    # These representative coordinate classes prove the symbolic construction
    # for all n axes. The p actual cubes have one owner per upper face class.
    representatives=tuple((long,short,F(1,2))[j%3] for j in range(max(3,p-1)))
    true_intersection(representatives,(F(0),)*len(representatives),p)
    assert r%2==0
    first_harmonic_log=r*abs(rational_sinc(long/h)).log()+(d-r)*rational_sinc(short/h).log()
    total_log=arb(groups).log()+first_harmonic_log
    assert total_log < -LOG2
    # Under centered phase, (1+first/2)^groups differs from one by
    # between zero and groups*first. This is independent of the envelope.
    return total_log


def compare_transport(k,n,groups):
    # The elementary R864 calibration in the same units, one actual parent.
    a=arb(n+2).log()
    j0=groups//32
    assert 2*PI*2**(6*k)*a < arb(groups)/16
    rho=arb(2).exp()*n*a/j0**2
    assert rho<1
    shell_main=2*(arb(n)*a).sqrt()-arb(groups)/2048
    shell_tail=(j0+1)*rho.log()-(-rho).log1p()
    territory=shell_main.max(shell_tail)+LOG2
    payable=(-arb(groups)/128).max(territory+arb(n).log())+LOG2
    assert payable < -arb(groups)/4096
    return payable/groups


def scalable_case(k,p):
    n=2**(12*k)
    groups=2**(8*k)
    d=2**(3*k)
    h=F(1,2**(6*k))
    c=F(1,128*p)
    assert groups*d<=n
    assert h*h*n==R*R
    coarse,coarse_rho=uniformity_log(groups,d//2,c,F(1))
    tight,tight_rho=uniformity_log(groups,d//2,c,h/R)
    direct=high_exact_box(n,groups,d,p,c,h)
    coarse_pass=coarse<-2*LOG2
    assert tight<-2*LOG2
    assert tight_rho<1/PI
    print(f"SCALE n=2^{12*k}, m=2^{8*k}, d=2^{3*k}, p={p}, h/R=2^-{6*k}, essential cubes={p}.")
    print(f"  H=1 sinc envelope {fmt(coarse_rho)}, log2(total error bound) {fmt(coarse/LOG2)}.")
    print(f"  H=1 entire-box phase-density guarantee at S<=1/4: {'yes' if coarse_pass else 'bound inconclusive'}.")
    print(f"  Actual H=h/R: sinc envelope {fmt(tight_rho)}, log2(total error bound) {fmt(tight/LOG2)}. Entire-box guarantee yes.")
    print(f"  Centered nonaligned physical box: log2 bound for mean R864 density minus one {fmt(direct/LOG2)}.")
    if k>=10:
        rate=compare_transport(k,n,groups)
        print(f"  Same R864 parent trap: cap n and move log(n+2), log(payable fraction)/m <= {fmt(rate)}.")
    return coarse_pass


if __name__=="__main__":
    print(f"Python {version.split()[0]}, python-flint {flint_version}, 320-bit Arb plus exact rationals.")
    print("Each phase is the sum of the physical coordinates in a disjoint group divided by h, modulo one.")
    print("For x in [0,pi], sinc decreases, since the numerator of its derivative decreases from zero.")
    print("For x>=pi use abs(sinc x)<=1/x; use 1/pi for the coarse tail or 1/x0 when x0>=pi.")
    print("With r>=2 long axes, two Fourier factors sum against k^-2, giving delta=(H/c)^2*rho^(r-2)/3.")
    print("If S=sum delta<=1/4, the entire phase density is pointwise in [1-S,exp(S)] after choosing continuous representatives.")
    print("Consequently all nonnegative arbitrary mean-one F have that average bound, including every Fejer order.")
    print("The construction models true intersections and their own normalized Lebesgue measure, without the full R813 history.")
    finite_cases()
    passed={k:scalable_case(k,4) for k in (2,4,8,9,10,30)}
    assert not any(passed[k] for k in (2,4,8))
    assert all(passed[k] for k in (9,10,30))
    scalable_case(10,64)
