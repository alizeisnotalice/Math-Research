"""R865: physical inter-arm boxes and explicit periodic Fourier diagnostics."""
from argparse import ArgumentParser
from collections import defaultdict
from fractions import Fraction as F
from functools import lru_cache, reduce
from hashlib import sha256
from itertools import product
from math import prod
from pathlib import Path
from zipfile import ZipFile
import json
import sys

from flint import acb, arb, ctx, __version__ as FLINT

PIN863="88a1819012871f487f3a96c308cc7e6f4d3ef5e0aeaa9ac69a12eb15adbcbffc"
PIN_RECORDS864="c9671992d8a95e65b61cc58c385907541a1d5c99a7d2956766f3b3e1f4ddfe9d"
AMPL=F(9,10)
Q=tuple(F(x,16777216) for x in (-29358079,29358081,-29358079,-20971519))
QRAD=F(1,33554432)


def load(rounds):
    archive=rounds/"863"/"research.zip"
    assert sha256(archive.read_bytes()).hexdigest()==PIN863
    with ZipFile(archive) as z:
        name="actual863.py"
        code=z.read(name)
        manifest=json.loads(z.read("MANIFEST.json"))["sha256"]
    assert sha256(code).hexdigest()==manifest[name]
    helpers={"__name__":"boxes865_archive","__file__":name}
    exec(compile(code,name,"exec"),helpers)
    comb=helpers["archive_member"](rounds,814,"comb811.py")
    public=helpers["archive_member"](rounds,860,"public860.py")
    stage=comb["fixture"](*comb["FIXTURES"][-1])
    parents,src,raw,hard,fmt,pin,cut=public["load"](rounds)
    source=helpers["Source"](comb,stage)
    assert (len(raw),len(hard),len(parents))==(920,848,8)
    assert sum(hard.values())==cut[2]
    for (t,l,r),amount in raw.items():
        u,z,k=l
        g,q,h=r
        lt=parents[u]["j"]*src[z]/(2*parents[u]["m"])
        rt=parents[g]["j"]*src[q]/(2*parents[g]["m"])
        assert k in (0,1) and h in (0,1)
        assert amount==parents[t]["j"]*lt*rt/(parents[t]["m"]**2*parents[t]["full_d"])
        assert 0<parents[u]["j"]/2<=parents[u]["owner_volume"]/2
        assert 0<parents[g]["j"]/2<=parents[g]["owner_volume"]/2
    return parents,src,raw,hard,source,pin,cut


def A(x):
    return arb(x.numerator)/x.denominator


def show(x):
    return "0" if x==0 else (A(x) if isinstance(x,F) else x).str(10,radius=True)


def meet(*boxes):
    return tuple((max(a for a,b in z),min(b for a,b in z)) for z in zip(*boxes))


def volume(box):
    return prod(max(F(0),b-a) for a,b in box)


def real_mass(source,box):
    return prod(source.mass(a,b) for a,b in box)


class Fourier:
    def __init__(self,source):
        self.source=source
        self.bumps=tuple((source.phase+j*source.period-source.bump,
                          source.phase+j*source.period+source.bump)
                         for j in range(source.low//source.period,source.high//source.period))
        self.pi=arb.pi()

    @lru_cache(maxsize=None)
    def uniform(self,a,b,k):
        if a>=b:
            return acb(0)
        if k==0:
            return acb(A(b-a))
        h=F(k)*(b-a)/self.source.period
        if h.denominator==1:
            return acb(0)
        x=self.pi*A(h)
        angle=self.pi*A(F(k)*(a+b)/self.source.period)
        return acb(angle.cos(),angle.sin())*A(b-a)*x.sin()/x

    @lru_cache(maxsize=None)
    def true(self,a,b,k):
        if a>=b:
            return acb(0)
        if k==0:
            return acb(A(self.source.mass(a,b)))
        a,b=max(a,self.source.low),min(b,self.source.high)
        if a>=b:
            return acb(0)
        floor=self.uniform(a,b,k)*A(self.source.floor)
        high=sum((self.uniform(max(a,u),min(b,v),k) for u,v in self.bumps
                  if a<v and u<b),acb(0))
        return floor+A(self.source.peak-self.source.floor)*high

    def box(self,box,r,true_mu):
        f,mass=(self.true,lambda a,b:self.source.mass(a,b)) if true_mu else (self.uniform,lambda a,b:b-a)
        if volume(box)==0:
            return arb(0)
        a,b,c,d=box
        return (f(*a,r)*f(*b,r).conjugate()).real*A(mass(*c)*mass(*d))


@lru_cache(maxsize=None)
def laurent(power,sign):
    out={0:F(1)}
    weights={0:F(1),-1:sign*AMPL/2,1:sign*AMPL/2}
    for _ in range(power):
        nxt=defaultdict(F)
        for (a,p),(b,w) in product(out.items(),weights.items()):
            nxt[a+b]+=p*w
        out=nxt
    assert all(out[-k]==out[k] for k in out)
    return out


def phi_moments(orb,box,powers,true_mu):
    d={k:orb.box(box,k,true_mu) for k in range(max(powers)+1)}
    return {(power,s):A(laurent(power,s)[0])*d[0]
            +sum((2*A(laurent(power,s)[k])*d[k] for k in range(1,power+1)),arb(0))
            for power,s in product(powers,(-1,1))}


def per_price_first_mode(orb,parents,src):
    source=orb.source
    both=[{sum(p["bit"] for p in parents.values()):acb(1)},
          {sum(p["bit"] for p in parents.values()):F(1)}]
    for j in range(source.n):
        plane=sorted({source.low,source.high,*(v for p in parents.values() for v in p["box"][j])})
        row=[defaultdict(acb),defaultdict(F)]
        for a,b in zip(plane,plane[1:]):
            x=(a+b)/2
            c=sum(p["bit"] for p in parents.values() if p["box"][j][0]<x<p["box"][j][1])
            row[1][c]+=source.mass(a,b)
            f=orb.true(a,b,int(j<2))
            row[0][c]+=f.conjugate() if j==1 else f
        next_=[defaultdict(acb),defaultdict(F)]
        for z in (0,1):
            for (a,v),(b,w) in product(both[z].items(),row[z].items()):
                next_[z][a&b]+=v*w
        both=next_
    assert dict(both[1])==src
    return {y:x.real/A(src[y]) for y,x in both[0].items()}


def box_rows(parents,raw):
    arms={}
    roots={}
    for t,l,r in raw:
        u,g=l[0],r[0]
        for v in (u,g):
            arms[t,v]=meet(parents[t]["box"],parents[v]["box"])
        roots[t,u,g]=meet(parents[t]["box"],parents[u]["box"],parents[g]["box"])
        assert volume(arms[t,u])>0 and volume(arms[t,g])>0
    return dict(sorted(arms.items())),dict(sorted(roots.items()))


def geometric(roots,parents,source,raw):
    initial=[F(0)]*5
    sides=[defaultdict(F),defaultdict(F)]
    for (t,l,r),w in raw.items():
        u,z,k=l
        g,q,h=r
        J=roots[t,u,g]
        V=volume(J)
        mu=real_mass(source,J)
        assert (V>0)==(mu>0)
        d=parents[t]["bit"]|parents[u]["bit"]|parents[g]["bit"]
        L,R=(d&y==d for y in (z,q))
        assert not (L or R) or V>0
        initial[0]+=w*(V>0)
        initial[1]+=w*L
        initial[2]+=w*R
        initial[3]+=w*(L and R)
        initial[4]+=w*(L or R)
        if L and R:
            sides[0][u,k]+=w
            sides[1][g,h]+=w
    assert all(sum(d.values())==initial[3] for d in sides)
    assert all(x<=parents[i]["owner_volume"]/2 for d in sides for (i,k),x in d.items())
    peaks=tuple(max((2*x/parents[i]["owner_volume"] for (i,k),x in d.items()),default=F(0))
                for d in sides)
    return tuple(initial),peaks


def peak(its):
    return reduce(arb.max,tuple(its))


def range_arb(seq):
    seq=tuple(seq)
    return show(reduce(arb.min,seq)),show(peak(seq))


def phase_record_marks(curr,parents,mean,fixed_q,right_mean):
    total=[arb(0),arb(0),arb(0)]
    margins={s:[defaultdict(arb),defaultdict(arb)] for s in (-1,0,1)}
    base=[defaultdict(F),defaultdict(F)]
    for (t,l,r),x in curr.items():
        u,z,k=l
        g,q,h=r
        weights=[(1+s*A(AMPL)*mean[z])*(1+s*A(AMPL)*(right_mean if fixed_q else mean[q]))/
                 A((1+AMPL)**2) for s in (-1,0,1)]
        for index,s in enumerate((-1,0,1)):
            weighted=weights[index]*A(x)
            total[index]+=weighted
            margins[s][0][u,k]+=weighted
            margins[s][1][g,h]+=weighted
        base[0][u,k]+=x
        base[1][g,h]+=x
    mass=sum(curr.values())
    for index,s in enumerate((-1,0,1)):
        for j,v in enumerate(margins[s]):
            assert sum(v.values(),arb(0)).overlaps(total[index])
            assert all(q<=parents[i]["owner_volume"]/2 for (i,k),q in base[j].items())
            assert all(v[k]<A(w) or v[k].overlaps(A(w)) for k,w in base[j].items())
    assert total[1].overlaps(A(mass/(1+AMPL)**2))
    assert total[0]<total[1]<total[2]
    share=tuple(a/A(mass) for a in total)
    return share,tuple(tuple(peak(2*w/A(parents[i]["owner_volume"]) for (i,k),w in d.items())
                             for d in margins[s]) for s in (-1,0,1))


def measurements(source,parents,src,arms,roots,raw,hard,q95,qnear,qbox,bits):
    ctx.prec=bits
    f=Fourier(source)
    assert f.uniform(source.low,source.low+source.period,1)==0
    moments={}
    for name,data in (("central-small",arms),("inter-arm",roots)):
        pos={key:B for key,B in data.items() if volume(B)>0}
        assert pos and all(real_mass(source,B)>0 for B in pos.values())
        moments[name]={}
        for use_mu in (False,True):
            moments[name][use_mu]=defaultdict(list)
            for key,B in pos.items():
                m=real_mass(source,B) if use_mu else volume(B)
                x=phi_moments(f,B,(1,2,4),use_mu)
                assert (x[1,-1]+x[1,1]).overlaps(2*A(m))
                for k,v in x.items():
                    moments[name][use_mu][k].append(v/A(m))
            assert moments[name][use_mu]
    m=per_price_first_mode(f,parents,src)
    right=f.box(qbox,1,True)/A(real_mass(source,qbox))
    ans={k:phase_record_marks(d,parents,m,fixed,right) for k,d,fixed in (
        ("all",raw,False),("hard",hard,False),("q95 whole true cell",q95,False),
        ("same q95 positive neighborhood",qnear,True))}
    return moments,ans,right


def conditional_four_tables(parents,src,rows,receiver,source_cut):
    """Return exact conditional (auxiliary probability, D/|P|) at true endpoints."""
    labels=tuple(sorted(parents))
    rates={i:receiver[i]*parents[i]["j"]/parents[i]["m"] for i in labels}
    count=defaultdict(int)
    data={}
    @lru_cache(maxsize=None)
    def geometry(keys):
        bits=sum(parents[i]["bit"] for i in keys)
        mass=sum(src[y] for y in source_cut if y&bits==bits)
        physical=meet(*(parents[i]["box"] for i in keys))
        V=volume(physical)
        assert mass>0 and V>0
        return mass,V

    endpoints=sorted({(t,a[0],a[1]) for t,l,r in rows for a in (l,r)})
    for t,g,q in endpoints:
        assert q in source_cut and src[q]>0
        assert q&parents[t]["bit"] and q&parents[g]["bit"]
        avail=tuple(i for i in labels if q&parents[i]["bit"] and rates[i]>0)
        assert t in avail and g in avail
        total=sum(rates[i] for i in avail)
        probs={i:rates[i]/total for i in avail}
        law=defaultdict(F)
        for h,k in product(avail,repeat=2):
            key=tuple(sorted({t,g,h,k}))
            D,V=geometry(key)
            assert D>=src[q]
            law[D/V]+=probs[h]*probs[k]
            count["ordered"]+=1
            count[f"{len(key)} distinct"]+=1
        assert sum(law.values())==1
        data[t,g,q]=dict(law)
    return data,dict(count),geometry.cache_info().currsize


def four_marks(parent_law,rows,parents,Lambda,bits):
    ctx.prec=bits
    moment={}
    saturated={}
    for arm,d in parent_law.items():
        h=sum(p*min(F(1),Lambda/v) for v,p in d.items())
        pc=sum(p for v,p in d.items() if Lambda>=v)
        assert F(0)<=pc<=h<=1
        moment[arm]=h
        saturated[arm]=pc
    results=[arb(0),arb(0),arb(0)]
    same_window_saturation=[F(0)]*3
    margin=[defaultdict(arb),defaultdict(arb)]
    originals=[defaultdict(F),defaultdict(F)]
    @lru_cache(maxsize=None)
    def root(x):
        return A(x).sqrt()
    for (t,l,r),w in rows.items():
        lk,rk=(t,l[0],l[1]),(t,r[0],r[1])
        a,b=moment[lk],moment[rk]
        mark=root(max(a,b))
        for j,x in enumerate((root(a),root(b),mark)):
            results[j]+=A(w)*x
        for j,key in enumerate((lk,rk)):
            same_window_saturation[j]+=w*saturated[key]
        if max(a,b)==1:
            same_window_saturation[2]+=w
        for j,(i,y,h) in enumerate((l,r)):
            margin[j][i,h]+=A(w)*mark
            originals[j][i,h]+=w
    for j,table in enumerate(margin):
        assert sum(table.values(),arb(0)).overlaps(results[2])
        for (i,h),orig in originals[j].items():
            assert orig<=parents[i]["owner_volume"]/2
            assert table[i,h]<A(orig) or table[i,h].overlaps(A(orig))
    den=sum(rows.values())
    if same_window_saturation[2]==den:
        assert results[2].overlaps(A(den))
    else:
        assert results[2]<A(den)
    return (tuple(x/A(den) for x in results),tuple(x/den for x in same_window_saturation),
            tuple(peak(2*x/A(parents[i]["owner_volume"]) for (i,h),x in d.items()) for d in margin))


def exact_full_gate(law,rows):
    # Full capture by the arm max needs at least one completely saturated
    # arm on every original record; the endpoint gate is the largest D/V
    # of any positive-measure auxiliary draw for that actual endpoint.
    ep={arm:max(options) for arm,options in law.items()}
    whole=max(min(ep[t,l[0],l[1]],ep[t,r[0],r[1]]) for t,l,r in rows)
    return whole,max(ep.values())


def four_diagnostic(parents,src,raw,hard,q95,qnear,cut):
    print("True conditional four-parent test, r=4, p=2.")
    print("Available G_i are exactly the archived cube source supports A_i; no extra high-dimensional eligibility data is encoded.")
    print("Auxiliary h,k independent with replacement given each actual source y, using r_i j_i/m_i on labels containing y.")
    print("Exact sigma=min(1,Lambda |P|/mu_B(P)), Theta=(E sigma)^(1/2). Both original roles kept; max applies before integration.")
    _,_,_,_,Acut,B,inside=cut
    freeze={i:F(sum((i,h) in Acut for h in (0,1)),2) for i in parents}
    print("Actual hard r_i:",tuple(freeze.items()),"; true source cells in B:",len(B))
    assert all(t in inside for t,l,r in hard)
    hard_qnear={key:w*qnear[key]/q95[key] for key,w in hard.items() if key in qnear}
    for name,d,receivers,source_cut,groups in (
        ("full window",raw,dict.fromkeys(parents,F(1)),set(src),
           (("full original",raw),("hard cut with full auxiliary law",hard),("same fixed-q neighborhood",qnear))),
        ("hard half-core and true-source cut",hard,freeze,B,
           (("hard original",hard),("same fixed-q hard neighborhood",hard_qnear))),
    ):
        law,count,geoms=conditional_four_tables(parents,src,d,receivers,source_cut)
        critical,last=exact_full_gate(law,d)
        print(" ",name,"unique endpoints",len(law),"; ordered conditional draw counts",tuple(sorted(count.items())),
              "; distinct true parent-family intersections",geoms)
        print("   exact max-mark full threshold then every-endpoint threshold:",
              critical,last,"; interval forms",show(critical),show(last))
        for Lambda in dict.fromkeys((F(1),F(10**8),critical)):
            print("   Lambda =",Lambda)
            for label,rows in groups:
                low=four_marks(law,rows,parents,Lambda,192)
                hi=four_marks(law,rows,parents,Lambda,384)
                vals,sat,marg=hi
                assert all(x.overlaps(y) for x,y in zip(vals+marg,low[0]+low[2])) and sat==low[1]
                if Lambda==critical:
                    assert sat[2]==1
                print("    ",label,"original mass / full F",show(sum(rows.values())/sum(raw.values())),
                      "; original mark L/R/max",tuple(show(x) for x in vals))
                print("      auxiliary saturation L/R, fully marked record share:",
                      tuple(show(x) for x in sat),"; marked true U/W half densities",tuple(show(x) for x in marg))


def replay(rounds):
    parents,src,raw,hard,source,pin,cut=load(rounds)
    arms,roots=box_rows(parents,raw)
    q95={key:w for key,w in raw.items() if key[2][1]==95}
    Qbox=tuple((x-QRAD,x+QRAD) for x in Q)
    for p in parents.values():
        if p["bit"]&95:
            assert all(a<c<d<b for (a,b),(c,d) in zip(p["box"],Qbox))
        else:
            assert volume(meet(p["box"],Qbox))==0
    q_mass=real_mass(source,Qbox)
    assert 0<q_mass<=src[95] and q95
    qnear={key:w*q_mass/src[95] for key,w in q95.items()}
    C,D,mean=measurements(source,parents,src,arms,roots,raw,hard,q95,qnear,Qbox,192)
    moments,stats,cond=measurements(source,parents,src,arms,roots,raw,hard,q95,qnear,Qbox,384)
    assert mean.overlaps(cond)
    for name,data in moments.items():
        for law,v in data.items():
            for label,values in v.items():
                assert all(a.overlaps(b) for a,b in zip(values,C[name][law][label]))
    for name,(f,g) in stats.items():
        a,b=D[name]
        assert all(x.overlaps(y) for x,y in zip(f,a))
        assert all(x.overlaps(y) for u,v in zip(g,b) for x,y in zip(u,v))

    print("Python",sys.version.split()[0],"python-flint",FLINT,"; exact Fraction geometry and weights, Arb 192/384 Fourier.")
    print("Pinned R863",PIN863,"; R814",pin,"; fixed q coordinates independently reused from R864 records",PIN_RECORDS864)
    print("Physical R=1 from source archive; period P =",source.period,
          "; Phi_pm(y)=1 +/- (9/10) cos(2 pi (y1-y2)/P).")
    print("Fourier kernel: length*sinc(pi k length/P)*exp(pi i k (a+b)/P) coordinatewise; actual comb uses exact floor/peak intervals.")
    print("Uniform phase has mass |B| and each correlated profile has uniform one-coordinate marginals on a full torus.")
    print("For original-record marks both price profiles use the common pointwise envelope 19/10; units are [Phi_1 Phi_2/(19/10)^2].")
    print("Both real arm factors eta_l=j_u mu(cell_z)/(2m_u), eta_r=j_g mu(cell_q)/(2m_g) and j_t/(m_t^2 d_t) exactly reproduce every original weight.")
    print("H_ti=A_t intersect A_i; J_tug=A_t intersect A_u intersect A_g; original q source neighborhood true mass",q_mass)
    print("Absolute q-neighborhood weights equal the original q95 weights multiplied by mu(neighborhood)/mu(true cell 95).")
    print("Zero-volume boxes have zero true mass. Volume ratios are restricted to positive-volume boxes.")
    M=sum(raw.values())
    for name,boxes in (("central-small H",arms),("inter-arm ordered J",roots)):
        table={k:B for k,B in boxes.items() if volume(B)>0}
        zero=tuple(k for k in boxes if k not in table)
        assert all(real_mass(source,boxes[k])==0 for k in zero)
        print(" ",name,"positive/zero =",len(table),len(zero),"; distinct positive physical boxes",len(set(table.values())))
        source_mass=tuple(real_mass(source,B) for B in table.values())
        print("   Leb volume range:",min(map(volume,table.values())),max(map(volume,table.values())),
              "; exact comb source mass range:",show(min(source_mass)),show(max(source_mass)))
        print("   exact mu(B)/Leb diagnostic range:",
              show(min(real_mass(source,B)/volume(B) for B in table.values())),
              show(max(real_mass(source,B)/volume(B) for B in table.values())))
        print("   example positive physical box and exact Leb/true mass:",
              next(iter(table)),volume(next(iter(table.values()))),real_mass(source,next(iter(table.values()))),
              "; first zero example",zero[0] if zero else "none")
    positive_roots=[((t,u,g),B) for (t,u,g),B in roots.items() if volume(B)>0]
    assert all(source.mass(a,b)==(b-a)*source.peak for _,B in positive_roots for a,b in B[:2])
    print("On positive J the first two coordinates lie entirely in comb peaks; the normalized moments under Leb and true mu agree exactly.")
    for tag,metric in (("Leb",volume),("true comb mu",lambda B:real_mass(source,B))):
        values=[metric(B)/min(metric(arms[t,u]),metric(arms[t,g])) for (t,u,g),B in positive_roots]
        assert all(0<v<=1 for v in values)
        print(" Inter-arm/common fraction of smaller arm",tag,"positive roots range:",
              show(min(values)),show(max(values)))
    for name,data in moments.items():
        for is_true,vals in data.items():
            print(" ",name,"Fourier profile moment ratios","true mu" if is_true else "Leb",
                  "; signs ordered minus/plus:")
            for power in (1,2,4):
                print("  power",power,range_arb(vals[power,-1]),range_arb(vals[power,1]))
    for name,d in (("all",raw),("hard",hard),("q95",q95),("same q95 positive neighborhood",qnear)):
        F0=sum(d.values())
        scores,peaks=geometric(roots,parents,source,d)
        print(" ",name,"row count",len(d),"; actual original mass share/F",show(F0/M))
        print("   original score by J positive, price L in J, R in J, both, either / original group:",
              tuple(show(x/F0) for x in scores))
        print("   dual-true-price-in-J original max weights per U/W half Lebesgue:",
              tuple(show(x) for x in peaks))
    for name,(f,g) in stats.items():
        print(" ",name,"original two-price profile mark / group: minus, uniform, plus",tuple(show(x) for x in f))
        print("   max actual U/W half densities in each of the three marks:",
              tuple(tuple(show(x) for x in pair) for pair in g))
    four_diagnostic(parents,src,raw,hard,q95,qnear,cut)
    print("These are fixed physical-box and finite source-label integrals. No displacement, refitting of the original weight, or general p-moment conclusion.")


if __name__=="__main__":
    parser=ArgumentParser()
    parser.add_argument("--rounds",type=Path,required=True)
    replay(parser.parse_args().rounds)

