#!/usr/bin/env python3
"""R523 bounded five-time common mixture: IDEAL POINT-LATTICE LIMIT ONLY."""
from pathlib import Path
from fractions import Fraction as Q
import json,sys,platform,time,math,itertools
import numpy as np
import flint
from flint import arb,ctx
ctx.prec=256
ROOT=Path(__file__).resolve().parent
checks=0

def ck(x):
 global checks
 assert bool(x)
 checks+=1

def aa(x):
 x=Q(x);return arb(x.numerator)/x.denominator

def firsthit(n,p,targets):
 S=sum(p,arb(0));remaining=S;dp=[arb(0) for j in range(n+1)];dp[0]=arb(1);P=[]
 for prob,target in zip(p[:-1],targets):
  ratio=prob/remaining;ck(ratio>0 and ratio<1);nd=[arb(0) for j in range(n+1)];hit=arb(0)
  for r,mass in enumerate(dp):
   if mass==0:continue
   m=n-r;w=(1-ratio)**m
   for inc in range(m+1):
    z=mass*w;nr=r+inc
    if nr==target:hit+=z
    else:nd[nr]+=z
    if inc<m:w=w*(m-inc)/(inc+1)*ratio/(1-ratio)
  P.append(hit);dp=nd;remaining-=prob
 out=[x*S**n for x in P];none=sum(dp,arb(0))*S**n
 ck((sum(out,arb(0))+none-S**n).contains(0))
 return out,none

def model(n,qpower,stage):
 q=2**qpower;ks=list(range(qpower+1,n+1));K=len(ks);delta=Q(0);G=Q(4,3)
 base=arb(2).root(n);grow=aa(G).root(n);R=[base**(k-qpower) for k in ks];V=[grow*r for r in R]
 oldA=[r-1-2*aa(delta) for r in R];oldB=[r-1+2*aa(delta) for r in R]
 newA=[v-1-2*aa(delta) for v in V];newB=[v-1+2*aa(delta) for v in V]
 ck(all(1+2*aa(delta)<r<2-2*aa(delta) for r in R))
 ck(all(oldB[j]<newA[j] for j in range(K)));ck(all(newB[j]<oldA[j+1] for j in range(K-1)));ck(newB[-1]<1)
 Fold=[oldA[j]-8*j*aa(delta) for j in range(K)]
 Fnew=[newA[j]-(8*j+4)*aa(delta) for j in range(K)]
 S=1-8*K*aa(delta)
 bins=[Fold[0]]+[Fold[j]-Fold[j-1] for j in range(1,K)]+[S-Fold[-1]]
 ck(all(z>0 for z in bins));ck((sum(bins,arb(0))-S).contains(0))
 asc,none=firsthit(n,bins,ks)
 C=1+arb(4).log();An=1+n*arb(2).log();threshold=1/An;baseK=arb(2).root(4)
 L=1000*n;factor2=Q(L-2,L)**n;factor3=Q(L-3,L)**n;beta_cell=Q(2*n,L+3)
 ck(beta_cell<Q(1,500));ck(Q(2*n)/beta_cell==L+3)
 def st(x):return x.str(35,radius=True)
 results=[]
 for name,P in [('ascending_k',asc)]:
  ell=[q*p for p in P];beta_k=[ell[j]+(ell[j-1]/2 if j else 0)+(ell[j+1]/2 if j+1<K else 0) for j in range(K)];alpha=[b/C for b in beta_k]
  energy=sum((l*b for l,b in zip(ell,beta_k)),arb(0));discrete=sum((l*l for l in ell),arb(0))
  high=[];low=[];unclassified=[]
  for j,a in enumerate(alpha):
   if a>threshold:high.append(j)
   elif a<threshold:low.append(j)
   else:unclassified.append(j)
  ck(not unclassified)
  highP=sum((P[j] for j in high),arb(0));highScore=sum((ell[j]*beta_k[j] for j in high),arb(0))
  rows=[{'k':k,'P_arb':st(P[j]),'ell_arb':st(ell[j]),'alpha_arb':st(alpha[j]),'An_alpha_arb':st(An*alpha[j]),'class':'high' if j in high else 'low','K_target_arb':st(baseK.max(An*alpha[j]))} for j,k in enumerate(ks)]
  out={'shared_selector':name,'rows':rows,'real_window_Q_over_W_periodic_arb':st(energy),'discrete_label_sum_ell_squared_arb':st(discrete),'finite_Q_over_W_lower_arb':st(aa(factor2)*energy),'finite_Q_over_W_upper_arb':st(energy),'high_k':[ks[j] for j in high],'high_P_arb':st(highP),'high_receiver_nu_per_cell_arb':st(q*highP),'high_score_per_cell_arb':st(highScore),'high_score_fraction_periodic_arb':st(highScore/energy)}
  if name=='ascending_k':
   slowP=rapidP=unknownP=arb(0);slowScore=rapidScore=unknownScore=arb(0);details=[];joint=[]
   for j in high:
    k=ks[j];remaining=n-k;prob=(Fnew[j]-Fold[j])/(S-Fold[j]);ck(prob>0 and prob<1)
    w=(1-prob)**remaining;target=baseK.max(An*alpha[j]);sp=rp=up=arb(0)
    for inc in range(remaining+1):
     z=P[j]*w;ratio=arb(2)**inc
     if ratio<target:
      sp+=z;joint.append((k,inc,z))
     elif ratio>target:rp+=z
     else:up+=z
     if inc<remaining:w=w*(remaining-inc)/(inc+1)*prob/(1-prob)
    ck((sp+rp+up-P[j]).contains(0))
    slowP+=sp;rapidP+=rp;unknownP+=up;slowScore+=q*sp*beta_k[j];rapidScore+=q*rp*beta_k[j];unknownScore+=q*up*beta_k[j]
    details.append({'k':k,'additional_coordinate_probability_arb':st(prob),'slow_P_arb':st(sp),'rapid_P_arb':st(rp),'unresolved_P_arb':st(up)})
   out['full_high_classification']={'slow_P_arb':st(slowP),'rapid_P_arb':st(rapidP),'unresolved_P_arb':st(unknownP),'slow_receiver_nu_per_cell_arb':st(q*slowP),'slow_oldscore_per_cell_arb':st(slowScore),'slow_score_fraction_periodic_arb':st(slowScore/energy),'rapid_score_fraction_periodic_arb':st(rapidScore/energy),'finite_safe_slow_receiver_nu_over_W_lower_arb':st(aa(factor3)*q*slowP),'finite_safe_slow_score_over_W_lower_arb':st(aa(factor3)*slowScore),'details':details,'reason':'ascending first-hit filters only earlier coordinates; above current radius remaining coordinates retain categorical conditional law'}
  results.append(out)
 # IDEAL POINT LATTICE ONLY: intermediate count e|d is Bin(d,p_g).
 # This does not discard any parent from the ideal whole-highslow set.
 gs=[Q(1),Q(13,12),Q(7,6),Q(5,4),G]
 def inner(x,y):
  return sum((a*(y.get(k,arb(0))+(y.get(k-1,arb(0))+y.get(k+1,arb(0)))/2) for k,a in x.items()),arb(0))
 def finner(x,y):return sum((inner(cols,y.get(e,{})) for e,cols in x.items()),arb(0))
 def add(field,e,k,a):
  c=field.setdefault(e,{});c[k]=c.get(k,arb(0))+a
 fields=[];sourcechecks=[]
 for ig,g in enumerate(gs):
  field={};total=arb(0);rowcount=0
  for k,d,p in joint:
   r=base**(k-qpower);v=aa(G).root(n)*r;rg=aa(g).root(n)*r
   if ig==0:weights=[arb(1)]+[arb(0)]*d
   elif ig==len(gs)-1:weights=[arb(0)]*d+[arb(1)]
   else:
    frac=(rg-r)/(v-r);ck(frac>0 and frac<1)
    weights=[math.comb(d,e)*frac**e*(1-frac)**(d-e) for e in range(d+1)]
   ck((sum(weights,arb(0))-1).contains(0))
   for e,w in enumerate(weights):
    # Per-source column: period integral of number of captured lattice atoms
    # (2^(k+e)), divided by rg^n=g*2^k/q, gives q*2^e/g.
    coeff=aa(Q(q*2**e)/g)
    ck((coeff-aa(2**(k+e))/rg**n).contains(0))
    add(field,e,k+e,coeff*p*w);total+=p*w;rowcount+=1
  ck((total-slowP).contains(0));fields.append(field)
  sourcechecks.append({'g':str(g),'parent_measure_arb':st(total),'expanded_type_count':rowcount,'phase_j':sorted(4*e for e in field)})
 gram=[[finner(x,y) for y in fields] for x in fields]
 for i in range(5):
  for j in range(5):ck((gram[i][j]-gram[j][i]).contains(0))
 # Nonnegative field-square construction certifies PSD; active-set enumeration
 # only chooses a rational feasible candidate. Arb convex tangent bound certifies it.
 M=np.array([[float(x) for x in row] for row in gram]);candidates=[]
 for size in range(1,6):
  for support in itertools.combinations(range(5),size):
   H=M[np.ix_(support,support)]
   block=np.block([[H,-np.ones((size,1))],[np.ones((1,size)),np.zeros((1,1))]])
   try:sol=np.linalg.solve(block,np.r_[np.zeros(size),1.])[:-1]
   except np.linalg.LinAlgError:continue
   if np.min(sol)<-1e-12:continue
   x=np.zeros(5);x[list(support)]=np.maximum(sol,0);x/=sum(x)
   candidates.append((float(x@M@x),x))
 val,x=min(candidates,key=lambda pair:pair[0])
 support=[i for i,v in enumerate(x) if v>1e-12]
 den=2**44;weights=[Q(0)]*5
 for i in support[:-1]:weights[i]=Q(round(x[i]*den),den)
 weights[support[-1]]=1-sum(weights)
 ck(all(w>=0 for w in weights));ck(sum(weights)==1)
 grad=[sum((gram[i][j]*aa(weights[j]) for j in range(5)),arb(0)) for i in range(5)]
 objective=sum((aa(weights[i])*grad[i] for i in range(5)),arb(0))
 mingrad=grad[0]
 for z in grad[1:]:mingrad=mingrad.min(z)
 lower=2*mingrad-objective
 endpoint=gram[-1][-1];old=gram[0][0]
 endpoint_kkt=[gram[i][-1]-endpoint for i in range(4)]
 ck(all(z>0 for z in endpoint_kkt))
 ck(weights==[Q(0),Q(0),Q(0),Q(0),Q(1)])
 mixed={}
 for f,w in zip(fields,weights):
  for e,cols in f.items():
   for k,a in cols.items():add(mixed,e,k,a*aa(w))
 ck((finner(mixed,mixed)-objective).contains(0))
 gap=objective-lower;ck(gap.upper()<aa(Q(1,10**10))*endpoint)
 ck(objective<=endpoint or (objective-endpoint).contains(0))
 # Positive-coefficient sanity check only, not an explicit source-cell enumeration.
 # The source-column formula rests on integer-translation invariance and mass transport above.
 ck(all(aa(Q(q*2**e)/g)>0 for g in gs for k,d,p in joint for e in range(d+1)))
 row={'stage':stage,'n':n,'q':q,'scope':'IDEAL delta=0 point-lattice limit; not original positive-delta L1 or its finite-boundary field',
 'g_values':[str(g) for g in gs],'delta_exact':'0','high_k':[ks[j] for j in high],
 'whole_highslow_parent_measure_arb':st(slowP),'old_full_Q_arb':st(energy),'old_slow_full_cross_score_arb':st(slowScore),
 'joint_rows':[{'k':k,'d':d,'P_arb':st(p)} for k,d,p in joint],
 'source_column_checks':sourcechecks,'Gram_arb':[[st(z) for z in row] for row in gram],
 'Gram_float_for_readability':M.tolist(),'single_action_energy_arb':[st(gram[i][i]) for i in range(5)],
 'endpoint_energy_arb':st(endpoint),'old_energy_arb':st(old),
 'rational_common_probabilities':[str(w) for w in weights],
 'feasible_mixture_energy_arb':st(objective),'convex_tangent_global_lower_arb':st(lower),
 'optimality_gap_upper_arb':st(gap),'mixture_over_endpoint_arb':st(objective/endpoint),
 'global_min_over_endpoint_enclosure':{'lower_arb':st(lower/endpoint),'upper_arb':st(objective/endpoint)},
 'feasible_strict_improvement_over_endpoint':bool(objective<endpoint),
 'endpoint_KKT_reduced_cost_arb':[st(z) for z in endpoint_kkt],
 'endpoint_cross_over_endpoint_energy_arb':[st(gram[i][-1]/endpoint) for i in range(5)],
 'endpoint_unique_global_minimizer_certified':True,
 'decision_gap': 'Arb tangent bound: min_simplex f >= 2 min_i(M nu)_i - f(nu); rational nu feasible; Gram PSD by source-field construction',
 'original_positive_delta_high_k':{'probe':[2,3,4],'pressure':list(range(3,14))+list(range(56,65)),'expanded_density':list(range(6,24))+list(range(47,64))}[stage],
 'original_L1_bridge_missing':['positive-delta intermediate clipping produces noninteger mass and continuously varying actual phase/window','P_kd lacks parent-position and source-point correlations required by intermediate field Gram','need a uniform positive-delta field/Gram convergence bound, including phase-floor discontinuities, and finite-source-boundary control; no intermediate parent deletion permitted']}
 print('MODEL',stage,'nu',[str(w) for w in weights],'mix/endpoint',st(objective/endpoint),'gap/endpoint',st(gap/endpoint),flush=True)
 return row

def main():
 start=time.perf_counter();models=[model(16,1,'probe'),model(64,2,'pressure'),model(64,4,'expanded_density')]
 out={'scope':'Five actions, three fixed n/q values, IDEAL POINT-LATTICE delta=0 exploration only; original L1 exact intermediate Gram not recovered; no 64 updates or scan',
 'environment':{'executable':sys.executable,'python':platform.python_version(),'python_flint':flint.__version__,'numpy':np.__version__,'arb_precision_bits':ctx.prec},'models':models,'checks':checks,'seconds':time.perf_counter()-start}
 (ROOT/'r523_time_numeric.json').write_text(json.dumps(out,indent=2)+'\n')
 print('PASS ideal-lattice five-time common mixture, source columns and Arb global bounds')
if __name__=='__main__':main()
