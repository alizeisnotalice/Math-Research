#!/usr/bin/env python3
"""R523 fixed whole-highslow endpoint capture and original-J substitution decision."""
from pathlib import Path
from fractions import Fraction as Q
import json,sys,platform,time
import flint
from flint import arb,ctx
ctx.prec=256
ROOT=Path(__file__).resolve().parent
checks=0

def ck(x):
 global checks
 assert bool(x)
 checks+=1

def aa(x):
 x=Q(x);return arb(x.numerator)/x.denominator

def firsthit(n,p,targets):
 S=sum(p,arb(0));remaining=S;dp=[arb(0) for j in range(n+1)];dp[0]=arb(1);P=[]
 for prob,target in zip(p[:-1],targets):
  ratio=prob/remaining;ck(ratio>0 and ratio<1);nd=[arb(0) for j in range(n+1)];hit=arb(0)
  for r,mass in enumerate(dp):
   if mass==0:continue
   m=n-r;w=(1-ratio)**m
   for inc in range(m+1):
    z=mass*w;nr=r+inc
    if nr==target:hit+=z
    else:nd[nr]+=z
    if inc<m:w=w*(m-inc)/(inc+1)*ratio/(1-ratio)
  P.append(hit);dp=nd;remaining-=prob
 out=[x*S**n for x in P];none=sum(dp,arb(0))*S**n
 ck((sum(out,arb(0))+none-S**n).contains(0))
 return out,none

def model(n,qpower,stage):
 q=2**qpower;ks=list(range(qpower+1,n+1));K=len(ks);delta=Q(1,10000*n*K);G=Q(4,3)
 base=arb(2).root(n);grow=aa(G).root(n);R=[base**(k-qpower) for k in ks];V=[grow*r for r in R]
 oldA=[r-1-2*aa(delta) for r in R];oldB=[r-1+2*aa(delta) for r in R]
 newA=[v-1-2*aa(delta) for v in V];newB=[v-1+2*aa(delta) for v in V]
 ck(all(1+2*aa(delta)<r<2-2*aa(delta) for r in R))
 ck(all(oldB[j]<newA[j] for j in range(K)));ck(all(newB[j]<oldA[j+1] for j in range(K-1)));ck(newB[-1]<1)
 Fold=[oldA[j]-8*j*aa(delta) for j in range(K)]
 Fnew=[newA[j]-(8*j+4)*aa(delta) for j in range(K)]
 S=1-8*K*aa(delta)
 bins=[Fold[0]]+[Fold[j]-Fold[j-1] for j in range(1,K)]+[S-Fold[-1]]
 ck(all(z>0 for z in bins));ck((sum(bins,arb(0))-S).contains(0))
 asc,none=firsthit(n,bins,ks)
 C=1+arb(4).log();An=1+n*arb(2).log();threshold=1/An;baseK=arb(2).root(4)
 L=1000*n;factor2=Q(L-2,L)**n;factor3=Q(L-3,L)**n;beta_cell=Q(2*n,L+3)
 ck(beta_cell<Q(1,500));ck(Q(2*n)/beta_cell==L+3)
 def st(x):return x.str(35,radius=True)
 results=[]
 for name,P in [('ascending_k',asc)]:
  ell=[q*p for p in P];beta_k=[ell[j]+(ell[j-1]/2 if j else 0)+(ell[j+1]/2 if j+1<K else 0) for j in range(K)];alpha=[b/C for b in beta_k]
  energy=sum((l*b for l,b in zip(ell,beta_k)),arb(0));discrete=sum((l*l for l in ell),arb(0))
  high=[];low=[];unclassified=[]
  for j,a in enumerate(alpha):
   if a>threshold:high.append(j)
   elif a<threshold:low.append(j)
   else:unclassified.append(j)
  ck(not unclassified)
  highP=sum((P[j] for j in high),arb(0));highScore=sum((ell[j]*beta_k[j] for j in high),arb(0))
  rows=[{'k':k,'P_arb':st(P[j]),'ell_arb':st(ell[j]),'alpha_arb':st(alpha[j]),'An_alpha_arb':st(An*alpha[j]),'class':'high' if j in high else 'low','K_target_arb':st(baseK.max(An*alpha[j]))} for j,k in enumerate(ks)]
  out={'shared_selector':name,'rows':rows,'real_window_Q_over_W_periodic_arb':st(energy),'discrete_label_sum_ell_squared_arb':st(discrete),'finite_Q_over_W_lower_arb':st(aa(factor2)*energy),'finite_Q_over_W_upper_arb':st(energy),'high_k':[ks[j] for j in high],'high_P_arb':st(highP),'high_receiver_nu_per_cell_arb':st(q*highP),'high_score_per_cell_arb':st(highScore),'high_score_fraction_periodic_arb':st(highScore/energy)}
  if name=='ascending_k':
   slowP=rapidP=unknownP=arb(0);slowScore=rapidScore=unknownScore=arb(0);details=[];joint=[]
   for j in high:
    k=ks[j];remaining=n-k;prob=(Fnew[j]-Fold[j])/(S-Fold[j]);ck(prob>0 and prob<1)
    w=(1-prob)**remaining;target=baseK.max(An*alpha[j]);sp=rp=up=arb(0)
    for inc in range(remaining+1):
     z=P[j]*w;ratio=arb(2)**inc
     if ratio<target:
      sp+=z;joint.append((k,inc,z))
     elif ratio>target:rp+=z
     else:up+=z
     if inc<remaining:w=w*(remaining-inc)/(inc+1)*prob/(1-prob)
    ck((sp+rp+up-P[j]).contains(0))
    slowP+=sp;rapidP+=rp;unknownP+=up;slowScore+=q*sp*beta_k[j];rapidScore+=q*rp*beta_k[j];unknownScore+=q*up*beta_k[j]
    details.append({'k':k,'additional_coordinate_probability_arb':st(prob),'slow_P_arb':st(sp),'rapid_P_arb':st(rp),'unresolved_P_arb':st(up)})
   out['full_high_classification']={'slow_P_arb':st(slowP),'rapid_P_arb':st(rapidP),'unresolved_P_arb':st(unknownP),'slow_receiver_nu_per_cell_arb':st(q*slowP),'slow_oldscore_per_cell_arb':st(slowScore),'slow_score_fraction_periodic_arb':st(slowScore/energy),'rapid_score_fraction_periodic_arb':st(rapidScore/energy),'finite_safe_slow_receiver_nu_over_W_lower_arb':st(aa(factor3)*q*slowP),'finite_safe_slow_score_over_W_lower_arb':st(aa(factor3)*slowScore),'details':details,'reason':'ascending first-hit filters only earlier coordinates; above current radius remaining coordinates retain categorical conditional law'}
  results.append(out)
 # Endpoint probability is one on every actual finite highslow parent.
 phases={};aligned={};actual={};oldslow={};excess={}
 for k,d,p in joint:
  a=aa(Q(q,G))*2**d*p
  phases.setdefault(d,{})[k]=a
  aligned[k]=aligned.get(k,arb(0))+a
  actual[k+d]=actual.get(k+d,arb(0))+a
  oldslow[k]=oldslow.get(k,arb(0))+q*p
  excess[k]=excess.get(k,arb(0))+aa(Q(q,G))*(2**d-1)*p
 def norm(cols):
  return sum((a*a+a*cols.get(k+1,arb(0)) for k,a in cols.items()),arb(0))
 def inner(x,y):
  return sum((a*(y.get(k,arb(0))+(y.get(k-1,arb(0))+y.get(k+1,arb(0)))/2) for k,a in x.items()),arb(0))
 oldcols=dict(zip(ks,ell));phase_norms={d:norm(cols) for d,cols in phases.items()}
 B=sum(phase_norms.values(),arb(0));ZZ=norm(aligned);AA=norm(actual);LZ=inner(oldcols,aligned)
 oldcross=inner(oldcols,oldslow);gain=inner(oldcols,excess)
 ck((oldcross-slowScore).contains(0));ck((LZ-oldcross/aa(G)-gain).contains(0))
 ck(all((aligned[k]-oldslow[k]/aa(G)-excess[k]).contains(0) for k in aligned))
 ck((sum((p for k,d,p in joint),arb(0))-slowP).contains(0));ck(unknownP==0)
 active=len(phases)
 if active==1:ck((ZZ-B).contains(0))
 else:ck(ZZ<active*B)
 J=1
 while arb(4)**aa(Q(J,8))<An:J+=1
 ck(arb(4)**aa(Q(J-1,8))<An);ck(arb(4)**aa(Q(J,8))>An)
 ck(max(4*d for d in phases)<J)
 factor4=Q(L-4,L)**n
 lower=(slowScore-aa(Q(3,8))*energy)/aa(G)
 ck(LZ>lower)
 finite_cross_gap=aa(factor4)*LZ-(slowScore-aa(Q(3,8))*aa(factor2)*energy)/aa(G)
 ck(finite_cross_gap>0)
 def bracket(v):return {'lower_arb':st(aa(factor4)*v),'upper_arb':st(v)}
 endpoint={'scope':'all periodic highslow; endpoint on ALL actual finite highslow, sandwiched by positive fields; no miss','joint_rows':[{'k':k,'d':d,'phase_j':4*d,'old_window_start':str(Q(k,2)),'actual_window_start':str(Q(k+d,2)),'P_arb':st(p),'new_source_column_arb':st(aa(Q(q,G))*2**d*p)} for k,d,p in joint],
 'active_phase_j':[4*d for d in sorted(phases)],'active_phase_count':active,'theoretical_J':J,
 'phase_norms_per_W_arb':{str(4*d):st(v) for d,v in phase_norms.items()},
 'B_over_W_periodic_arb':st(B),'Z_norm_squared_over_W_periodic_arb':st(ZZ),'actual_A_norm_squared_over_W_periodic_arb':st(AA),
 'L_Z_over_W_periodic_arb':st(LZ),'old_slow_score_over_W_periodic_arb':st(slowScore),'shell_gain_in_L_Z_over_W_arb':st(gain),
 'R518_relaxed_cross_lower_over_W_arb':st(lower),'R518_relaxation_gap_over_W_arb':st(LZ-lower),
 'finite_R518_cross_gap_lower_over_W_arb':st(finite_cross_gap),'Z_squared_over_B_arb':st(ZZ/B),'B_over_old_Q_arb':st(B/energy),'L_Z_over_old_Q_arb':st(LZ/energy),
 'finite_core_factor_exact':str(factor4),'finite_B_over_W':bracket(B),'finite_Z_norm_squared_over_W':bracket(ZZ),'finite_L_Z_over_W':bracket(LZ),
 'finite_old_slow_score_over_W':bracket(slowScore),'finite_actual_A_norm_squared_over_W':bracket(AA),
 'normalizer_identity':'Z=D/G+positive endpoint shell field; residual window displacement exactly zero'}
 # Old slow bulk and endpoint-terminal-group energies. No winner updates.
 groupold={d:{k:q*p for k,dd,p in joint if dd==d} for d in phases}
 Qbulk=norm(oldslow);Qgroup=sum((norm(cols) for cols in groupold.values()),arb(0))
 Credit=sum((inner(x,y) for d,x in groupold.items() for e,y in groupold.items() if d!=e),arb(0))
 ck((Credit-(Qbulk-Qgroup)).contains(0))
 Cpair=sum((aa(Q(4**d-1)/G**2)*norm(cols) for d,cols in groupold.items()),arb(0))
 ck((Cpair-(B-Qgroup/aa(G)**2)).contains(0))
 ck(Qbulk>0);ck(Qgroup>0)
 if any(d>0 for d in phases):ck(Cpair>0)
 else:ck(Cpair==0)
 if active==1:ck(Credit.contains(0))
 else:ck(Credit>0)
 ck((aa(G)**2*B-Qbulk-(aa(G)**2*Cpair-Credit)).contains(0))
 ratio=aa(G)**2*B/Qbulk;jeff=ZZ/B
 alignedratio=aa(G)**2*ZZ/Qbulk
 if any(d>0 for d in phases):ck(alignedratio>1)
 else:ck((alignedratio-1).contains(0))
 h=Q(1,8);d0=1-3*h;kappa_h=4*h/(1-h)
 threshold0=aa((1-beta_cell)**2*d0**2)/J
 threshold_general=threshold0*aa(1-kappa_h)
 backcoef=ratio/threshold0
 # All finite ratios follow the existing positive-field f4 sandwich;
 # these are conservative independent bounds, not periodic values relabelled finite.
 f4=aa(factor4)
 def br(v):return {'lower_arb':st(f4*v),'upper_arb':st(v)}
 finite_ratio={'lower_arb':st(f4*ratio),'upper_arb':st(ratio/f4)}
 finite_credit={'lower_arb':st((f4*Qbulk-Qgroup).max(arb(0))),'upper_arb':st(Qbulk-f4*Qgroup)}
 finite_cap={'lower_arb':st((f4*B-Qgroup/aa(G)**2).max(arb(0))),'upper_arb':st(B-f4*Qgroup/aa(G)**2)}
 if active==1:finite_credit={'lower_arb':'0','upper_arb':'0'}
 if all(d==0 for d in phases):finite_cap={'lower_arb':'0','upper_arb':'0'}
 ck(f4*ratio>threshold0)
 row={'stage':stage,'n':n,'q':q,'G':str(G),'h':str(h),'beta_cell_exact':str(beta_cell),'theoretical_J':J,'active_phase_j':sorted(4*d for d in phases),'active_phase_count':active,
 'Q_bulk_over_W_periodic_arb':st(Qbulk),'Q_group_over_W_periodic_arb':st(Qgroup),'Credit_over_W_periodic_arb':st(Credit),'C_pair_over_W_periodic_arb':st(Cpair),'B_endpoint_over_W_periodic_arb':st(B),'Z_squared_over_W_periodic_arb':st(ZZ),
 'old_full_Q_over_W_periodic_arb':st(energy),'bulk_old_full_cross_score_over_W_periodic_arb':st(oldcross),'bulk_old_full_cross_score_fraction_arb':st(oldcross/energy),'G_squared_Z_squared_over_Q_bulk_arb':st(alignedratio),'G_squared_B_over_Q_bulk_arb':st(ratio),'J_eff_arb':st(jeff),'Credit_over_Q_bulk_arb':st(Credit/Qbulk),'G_squared_C_pair_over_Q_bulk_arb':st(aa(G)**2*Cpair/Qbulk),'Q_group_over_Q_bulk_arb':st(Qgroup/Qbulk),
 'original_J_threshold_T_zero_arb':st(threshold0),'R522_general_transport_threshold_arb':st(threshold_general),'original_J_back_substitution_coefficient_arb':st(backcoef),'replace_J_by_J_eff_diagnostic_coefficient_arb':st(ratio*jeff/aa((1-beta_cell)**2*d0**2)),
 'phase_group_old_norms_arb':{str(4*d):st(norm(cols)) for d,cols in groupold.items()},'phase_group_endpoint_norms_arb':{str(4*d):st(v) for d,v in phase_norms.items()},
 'finite_core_factor_exact':str(factor4),'finite_Q_bulk_over_W':br(Qbulk),'finite_Q_group_over_W':br(Qgroup),'finite_B_endpoint_over_W':br(B),'finite_Credit_over_W_conservative':finite_credit,'finite_C_pair_over_W_conservative':finite_cap,'finite_G_squared_B_over_Q_bulk':finite_ratio,
 'finite_original_J_back_substitution_coefficient':{'lower_arb':st(f4*backcoef),'upper_arb':st(backcoef/f4)},
 'T_self_exact':'0: all parents within endpoint phase d share U=d/2; window differences stay constant',
 'identity':'B=Q_group/G^2+C_pair; Credit=Q_bulk-Q_group; G^2 B/Q_bulk=1+(G^2 C_pair-Credit)/Q_bulk',
 'strict_checks':{'C_pair_nonnegative':bool(Cpair>=0),'finite_ratio_above_original_J_threshold':bool(f4*ratio>threshold0)}}
 print('MODEL',stage,'G2B/Qbulk',st(ratio),'J_eff',st(jeff),'J',J,'active',active,'threshold',st(threshold0),'coefficient',st(backcoef),flush=True)
 return row

def main():
 start=time.perf_counter()
 models=[model(16,1,'probe'),model(64,2,'pressure'),model(64,4,'expanded_density')]
 out={'scope':'Three frozen real R521 whole-highslow inputs; no 64-step iteration; periodic capture identity with finite conservative brackets, no asymptotic extrapolation','environment':{'executable':sys.executable,'python':platform.python_version(),'python_flint':flint.__version__,'arb_precision_bits':ctx.prec},'models':models,'checks':checks,'seconds':time.perf_counter()-start}
 (ROOT/'r523_numeric.json').write_text(json.dumps(out,indent=2)+'\n')
 print('PASS R523 fixed endpoint capture, credit and original-J substitution checks')
if __name__=='__main__':main()
