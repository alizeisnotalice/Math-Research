from fractions import Fraction as F
from itertools import product
import math
ct={'pair_scale':0,'removal_budget':0,'tail_choice':0}
for n in [1,2,8]:
 centers=[(F(0),)*n,(F(1,2),)*n,(F(2),)*n];rs=[F(1),F(3,2),F(2)]
 zs=centers+[(F(1),)*n];mass=[F(1,4)]*4
 cap=[[int(all(abs(z[k]-c[k])<=r/2 for k in range(n))) for z in zs] for c,r in zip(centers,rs)]
 for us in [[F(1,4),F(1,2),F(1,4)],[F(1),F(2),F(3)],[F(0),F(1),F(0)]]:
  I=sum(us)
  for gone in product([0,1],repeat=3):
   f=sum(u*g for u,g in zip(us,gone))
   for H in [F(1,10),F(1),F(3),F(7)]:
    B=F(0);harm=F(0);cum=F(0)
    for s in sorted(set(rs)):
     atom=sum(us[i] for i in range(3) if rs[i]==s);cum+=atom
     harm+=atom/max(H,cum)
    for k,r in enumerate(rs):
     weight=r**(-n)-(rs[k+1]**(-n) if k<2 else F(0))
     active=range(k+1);J=sum(us[i] for i in active)
     if J<H:continue
     V=sum(us[i]*rs[i]**n for i in active)
     fg=sum(us[i]*gone[i] for i in active)
     Vg=sum(us[i]*gone[i]*rs[i]**n for i in active)
     Q=sum((us[i]*us[j]*int(gone[i] or gone[j])*sum(m*abs(cap[i][z]-cap[j][z]) for z,m in enumerate(mass)) for i in active for j in active),F(0))/2
     assert Q/J<=4*(Vg+fg*V/J)
     B+=weight*Q/J;ct['pair_scale']+=1
    assert B<=4*f*(1+harm)
    assert float(harm)<=1+max(0,math.log(float(I/H)))+1e-13
    assert float(B)<=4*float(f)*(2+max(0,math.log(float(I/H))))+1e-13
    ct['removal_budget']+=1
for n,ratio,eps,hrel in product([1,2,64,10000],[1,2],[.01,1,100],[.01,1,100]):
 S=(1+n*math.log(ratio))*(1+math.pi*math.sqrt(n)/2)
 T=2+max(0,math.log(1/hrel));C=16*S*n*T/9
 D=.5+math.log1p(C/eps)
 cost=C*math.exp(.5-D)
 assert cost<=eps*(1+1e-12)
 ct['tail_choice']+=1
print('PASS',ct)
