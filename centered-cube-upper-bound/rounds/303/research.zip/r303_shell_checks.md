# R303 displaced-source shell diagnostics

Exact finite tensor intersection moments for genuine positive-volume L1 beta/nu cubes and concentric receiver shells. Actual s=0 kernels, FIRST<=1 and same-radius hardcaps<=4. No complete low-m/e_g/maxhardcap history, FULL certificate, or general dimension order is asserted.

delta=1/(100n), beta uniform cube centered0 side2delta mass1; nu uniform cube centered(t repeated k coordinates,0 remaining),side2delta,mass4. R_i=L_i=1+i/m; E0=Q_(R0-2delta);Ei=Q_(Ri-2delta) minus Q_(R_(i-1)-2delta). Cube parameters are side lengths.

For each shell i, f_i(z)=Ri^-n [product overlap(side_i,Ri,z_l)-product overlap(side_(i-1),Ri,z_l)]. M1=4 E(sum f_i), M2=4 E(sum f_i)^2. One-dimensional overlaps are affine between exact breakpoints; Simpson integrates their quadratic products exactly with Fraction. Tensor independence computes pair moments before cumulative summation.

|n|t|k|max J|linear traffic|BH at H≈sqrt n|BH/linear|
|---:|---:|---:|---:|---:|---:|---:|
|4|0|0|2.94146|5.57695|0|0|
|4|1/4|1|2.94146|4.20828|0.351764|0.0835885|
|4|1/2|1|2.94146|2.97695|0.472374|0.158677|
|4|1/4|4|2.94146|1.75929|0.419446|0.238418|
|4|1/2|4|2.94146|0.478927|0.199232|0.415998|
|8|0|0|4.89367|5.55124|0|0|
|8|1/8|1|4.89367|4.84393|0.0629339|0.0129923|
|8|1/4|1|4.89367|4.19756|0.0984179|0.0234465|
|8|1/8|8|4.89367|1.8048|0.121342|0.0672327|
|8|1/4|8|4.89367|0.581631|0.0633928|0.108991|
|16|0|0|8.799|5.46356|0|0|
|16|1/16|1|8.799|5.10734|0.00746174|0.00146098|
|16|1/8|1|8.799|4.77784|0.0124346|0.00260256|
|16|1/16|16|8.799|1.79865|0.0245055|0.0136244|
|16|1/8|16|8.799|0.619135|0.0125412|0.020256|

Centered source gives Qpair=0 exactly, despite the multiple receiver radii. Displacement makes Qpair positive in these tested models. Thus radial separation alone does not produce this gap in the centered complete-capture construction; these cases locate an additional boundary mechanism. This is a finite diagnostic, not a general dichotomy or asymptotic claim.

w_i=Ri^-n-R_(i+1)^-n; endpoint b^-n; BH=sum_(J_i>=H) w_i Q_i/J_i. H uses floor(1000sqrt n)/1000 and half/double this rational threshold.

All signs, moment comparisons and fee bounds use exact Fraction. JSON decimal displays are 60-digit conversions; exact BH fractions and hashes of full exact pair matrices / layer gaps support reproduction without storing the matrices.
