# R303: a single remaining local-heavy disagreement fee after paid complements

Fix the original low-pe,m>M, aspect v>=v0 target and all original outer fields. Every qualification, full e_g,m,q,soft selector and FIRST response remains computed from the ORIGINAL sources. All estimates below are inside that fixed outer instance; its original multiplier must still be applied.

Set A_n=1+n log(b/a), S=A_n Csoft_n, d=kappa0 psi_inf/(q_-v0), H=sqrt(d A_n/(4lambda)), and C_rho=1/(1-rho), where rho is the strict soft-coordinate constant from the main R303 note. Choose epsilon>0,L0>=0 and
 D0=1+log[1+(16 S n)/(9epsilon)],
 T_H=2+log_+(S/(q_-H)),
 D1=1/2+log[1+(16 S n T_H)/(9epsilon)].
Define the frozen original-source column partition
 Z_l={z:beta(Q_(2D0 b)(z))<=q_-a^n L0}, Z_h=R^n\Z_l,
 nu_l=1_(Z_l)nu, nu_h=1_(Z_h)nu.
The sets are measurable since the translated-cube source integral is measurable. There is no subsequent source renormalization.

Let B_H^near(D1;nu_h) mean the exact R302 fee formed with the SAME original U_y,J_y and the restricted source nu_h, keeping only double receiver pairs with BOTH |u-y|_infinity<=D1 b and |w-y|_infinity<=D1 b. Its denominator is the original J_y, not a near-only row mass. Then

 T_target <=2 C_rho L0 W_(nu_l)
       +4sqrt(lambda d A_n)(W_beta+W_(nu_h))
       +3epsilon W_beta+2 B_H^near(D1;nu_h).                 (1)

Proof. Split actual traffic by far source pairs |y-z|_infinity>D0 b, near light columns, and near heavy columns. The R296 actual positive far-traffic estimate pays the first part by epsilon W_beta. That estimate applies the actual hard cap before extending receiver space; it supplies no density cap at source centers. The strict soft-overlap R303 theorem pays near light columns by 2 C_rho L0 W_(nu_l).

For near heavy traffic, first retain the original target qualifications and then remove only the near pair restriction positively. This is bounded by all original target traffic integrated against nu_h. Its original FIRST condition is unchanged (beta,p,q are unchanged), and the hard cap for nu_h is inherited by monotonicity from nu. The original low/m height qualifications continue to be evaluated from the full original data; no m or e_g is recomputed after restricting nu. The R301 witness and R302 cumulative overlap estimates require those original heights and inherited hard caps, so they apply to this restricted positive source integral with the same d and U_y. They give
 T_(target;nu_h)<=4sqrt(lambda d A_n)(W_beta+W_(nu_h))+2B_H(nu_h).

The general receiver-removal R303 theorem applies to this same fee with G_y={|u-y|_infinity>D1 b} and inherited caps. It pays B_H^far(D1;nu_h)<=epsilon W_beta while preserving the original denominator. The exact pair partition B_H=B_H^near+B_H^far yields (1). No source budget is spent independently per geometric cell or scale, and no negative credit is reused.

For example L0=sqrt(A_n) makes the first two source terms root order in this window, with the exact constants C_rho and lambda d retained. The still-unpaid term is supported on heavy local columns and on pairs of receivers near their original soft source. This is a paid reduction of its domain, not a proof that its cost is small. In particular evenness or smoothness of the soft profile does not cap the source mass of an arbitrary hard-cube boundary layer.

The extreme-aspect complement v<v0 and all original outside terms remain unchanged. Formula (1) must be integrated only with the original allowed source bridges and outer clock multipliers. It is not a general endpoint theorem, and no matching receiver-term absorption is invented here.
