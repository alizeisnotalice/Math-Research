from pathlib import Path
import sys,json
try:import mpmath as m
except ImportError:
 sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor');import mpmath as m
records=[]
def phi(x):
 x=abs(x)
 if x<=m.mpf('.5'):return 1-m.expint(3,m.mpf('.5')-x)-m.expint(3,m.mpf('.5')+x)
 return m.expint(3,x-m.mpf('.5'))-m.expint(3,x+m.mpf('.5'))
for dp in [40,60]:
 m.mp.dps=dp
 rho=1-2*m.quad(lambda u:u*m.exp(-m.mpf('1.5')/u),[0,1])
 assert 0<rho<1
 for L,R in [('1','1'),('1','2'),('2','1'),('1.5','1'),('1','1.5'),('1.999','1.001')]:
  L,R=m.mpf(L),m.mpf(R)
  for d in [m.mpf(0),m.mpf('.5'),m.mpf('1.99'),m.mpf(4)]:
   lo,hi=d-R/2,d+R/2
   cuts=sorted(set([lo,hi]+[x for x in [-L/2,m.mpf(0),L/2] if lo<x<hi]))
   val=m.quad(lambda x:phi(x/L)/L,cuts)/R
   bound=rho/max(L,R)
   assert val<=bound+m.mpf('1e-32')
   records.append({'kind':'actual overlap','dp':dp,'L':str(L),'R':str(R),'shift':str(d),'value':str(val),'bound':str(bound)})
 for n in [1,2,4,16,64,256,1024]:
  C=m.mpf(1)
  for k in range(1,n+1):
   c=m.mpf(1) if k==n else m.exp(m.loggamma(n+1)-m.loggamma(k+1)-m.loggamma(n-k+1)+k*m.log(m.mpf(k)/n)+(n-k)*m.log(m.mpf(n-k)/n))
   assert c<=1+m.mpf('1e-30')
   C+=c*rho**k
  assert C<=1/(1-rho)
  records.append({'kind':'coefficient sum','dp':dp,'n':n,'value':str(C),'bound':str(1/(1-rho))})
result={'status':'PASS','checks':len(records),'rho':str(rho),'uniform_coefficient':str(1/(1-rho)),'scope':'finite high precision diagnostics, not interval certificates','records':records}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2))
print(json.dumps({k:v for k,v in result.items() if k!='records'}))
