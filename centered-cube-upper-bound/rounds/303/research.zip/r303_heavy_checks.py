from fractions import Fraction as F
import math
count=0
for n in (1,2,8,64,1024):
 for a in (F(1,2),F(1),F(3)):
  for m in (a,F(3,2)*a,2*a):
   for c in (F(1,4),F(3,4),F(1)):
    for h in (a/100,a/10):
     r=max(a,c*m)
     for eps in (F(1,100),F(1,10000)):
      R=m*(1+eps)
      u=R/2-h; z=-h
      assert abs(u-z)<=R/2
      assert (r<=m and r<=c*m) or r==a
      assert m/r<=1/c
      L=max(a,c*R)
      assert min(L,R)>=r
      count+=1
outer=0
for n in (1,2,8,64,1024):
 for a in (F(1,2),F(1),F(3)):
  for b in (a,F(3,2)*a,2*a):
   for h in (a/100,a/10):
    t=b-5*h
    if t>=a:
     assert 1+n*math.log(float(b/t))<=1+float(5*n*h/a)+1e-10
     m=t; R=m+h/2
     assert R+4*h<=b
     u=R/2+h; z=-h
     assert abs(u-z)<=(R+4*h)/2
    else:
     assert math.log(float(b/a))<=float(5*h/a)+1e-12
    outer+=1
print(count,outer)  # actual output: 540 90
