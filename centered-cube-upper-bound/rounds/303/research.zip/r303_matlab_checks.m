% R303: independent local MATLAB quadrature of the actual soft tail.
r303Ratios = [1,1.5,2];
r303Values = zeros(3,3);
for r303Index = 1:3
    r303Cutoff = (1+r303Ratios(r303Index))/2;
    r303Loose = 1-2*integral(@(u) u.*exp(-r303Cutoff./u),0,1, ...
        'AbsTol',1e-10,'RelTol',1e-10);
    r303Tight = 1-2*integral(@(u) u.*exp(-r303Cutoff./u),0,1, ...
        'AbsTol',1e-13,'RelTol',1e-12);
    assert(r303Tight>0 && r303Tight<1);
    assert(abs(r303Loose-r303Tight)<1e-10);
    r303Values(r303Index,:) = [r303Ratios(r303Index),r303Tight,1/(1-r303Tight)];
end
r303Result = struct('status','PASS','cases',3,'version',version, ...
    'columns',{{'scale_ratio','rho','uniform_point_coefficient'}}, ...
    'values',r303Values,'scope','Floating quadrature diagnostics, not interval certificates');
r303Path = fullfile(fileparts(mfilename('fullpath')),'r303_matlab_checks.json');
r303Fid = fopen(r303Path,'w');
assert(r303Fid>=0);
fwrite(r303Fid,jsonencode(r303Result),'char');
fclose(r303Fid);
disp(r303Result);
