# R303 independent preauthor screen

Own only /tmp/r303_audit.md. No R303 author proof read before saving this screen. Retain original U_y=alpha1_E p_y/q, original full e_g,m, low/high/history/source masks, actual receiver Lebesgue dx, original FIRST and same-accepted-receiver/same-selected-radius hardcaps. Sources are finite positive original L1 beta,nu, q_-=3lambda/4, a<=L,R<=b<=2a. This is a bounded screen for the R302 B_H boundary expense, not a global closure claim.

## 1. General receiver-deletion boundary quantity and exact factor

Fix a row y and any measurable receiver deletion set F_y, frozen independently of hard source z. Let f=integral_F U, I=integral U, and on a radius prefix define J=integral_{R<=r}U, j=integral_{F,R<=r}U, V=integral_{R<=r}R^nU, v=integral_{F,R<=r}R^nU. Let Q_far be the R302 half double receiver integral restricted to at least one endpoint in F. It is a positive part of the SAME original double integral, with the near-near complement exact.

Original same-radius hardcaps give nu(C_u symmetric_difference C_w)<=4lambda(R(u)^n+R(w)^n). Symmetry of the half double integral therefore yields the slightly sharper

    Q_far<=4lambda[J v+j V-j v]
            <=4lambda[J v+j V].

Thus Q_far/J<=4lambda[v+(j/J)V] on J>0. There is NO additional factor two. A zero prefix has zero Q and no division.

## 2. Integrate original radius layers, including atoms

Let mu be the pushforward of U dx by the actual R, J(s)=mu([a,s]) inclusive, ell=b^-n delta_b+n r^-n-1 dr. On J(r)>=H>0, integrate the preceding estimate. The first term is <=f by positive exchange and ell([s,b])=s^-n.

For the second term use j(r)<=f and J(r)>=max(H,J(s)) for r>=s on the high gate. Its upper bound is f integral mu(ds)/max(H,J(s)). Since the reciprocal is decreasing, an inclusive atom evaluates its whole mass at the upper CDF endpoint and is bounded by the corresponding quantile interval. Hence

    integral mu(ds)/max(H,J(s))
       <=integral_0^I du/max(H,u)
       <=1+log_+(I/H).

Consequently the row boundary fee satisfies

    B_far,y<=4lambda f[2+log_+(I/H)].

If I<H the high layer is empty and the actual fee is zero. Endpoint atoms at a,b, an atom crossing H, and J=H are all covered; the final ell atom must be retained.

There is also a threshold-free entropy version. Because j/J<=min(1,f/J), the same exchange bounds the second term by integral mu(ds)min(1,f/J(s))<=f[1+log(I/f)] when f>0. Therefore

    B_far,y<=4lambda f[2+log(I/f)].

The f=0 value is zero by direct definition. On I>=H the two bounds combine into 4lambda f[2+log(I/max(H,f))]. This is a quantified entropy/deletion budget, not a bound on source density. No common normalization by I is substituted into actual receiver integration.

## 3. Actual far-receiver tail and source-linear payment

For F_y={|u-y|_infinity>Db}, D>1/2, the actual full common-soft positive envelope gives

    I_y<=M=S/q_-, S=A_n Csoft_n,
    f_y<=M alpha_D,
    alpha_D=min(1,(n/3)exp(1/2-D)).

The constant is consistent with the true phi=h*w tail: for t>1/2 its two-sided tail is <=(2/3)exp(1/2-t). The common-soft coefficient identity sum_k k c_nk=(n/2)Csoft_n converts this to (n/3)Csoft_n. Applying the positive actual scale envelope (mass A_n), with L<=b, preserves this bound at the physical cutoff Db; multiplying by q_-^-1 and alpha<=1 gives the displayed f bound. No product of independently selected coordinate softnesses is used.

Integrating the deletion estimate over ORIGINAL beta, and only then replacing f,I by these uniform bounds, yields

    B_far<= (16/3)S alpha_D
                       [2+log_+(M/H)] W_beta.

The equivalent untruncated exponential coefficient is (16/9)S n exp(1/2-D)[2+log_+(M/H)]. There is no (b/a)^n factor and beta is charged once. If A=(16/9)S n[2+log_+(M/H)], choosing D=1/2+log(1+A/epsilon) makes the coefficient A exp(1/2-D)<epsilon for epsilon>0. All H, lambda, q_-, S and original outer-price dependences remain. The remaining near-near receiver disagreement is exact and not paid by this tail estimate; all original aspect/outer/history ledgers remain.

## 4. Actual bounded diagnostics and verdict

An actual local Python run checked 128 finite receiver-indicator/prefix configurations with exact Fraction source ledgers and 50-digit logarithms. It included two dimensions, two cumulative row masses, every deletion pattern on a three-receiver menu and thresholds below, at and above cumulative atoms. All far-prefix boundary budgets passed. These test the algebra and endpoint bookkeeping, not an original all-input source/history realization.

Independent-screen verdict: PASS for the general receiver-deletion stability estimate, its entropy variant and the actual far-receiver source payment, including factors and atoms. No claim that near disagreement or the original global problem has been paid. Await author files/heavy-column route for bounded audit; no other files or Git changed.

## 5. Independent soft-coordinate contraction screen

Before reading a new author proof, screened a stronger R302 pair-amplitude estimate on b/a<=2. For actual w, let rho=P(|W|<=3/2)=1-2 integral_0^1 u exp[-3/(2u)]du<1. Every soft-hard coordinate overlap s_(L,R)=phi_L*h_R satisfies the UNIFORM bound rho/max(L,R), at every separation.

If L>=R, its height is <=||phi_L||_infinity=P(|W|<=1/2)/L<=rho/L. If R>=L, write s(delta)=R^-1 P(Y_L+W_L in delta+[-R/2,R/2]), where Y_L is uniform on [-L/2,L/2]. This event forces W_L into delta+[-(R+L)/2,(R+L)/2]. The even-decreasing w density assigns no greater mass to such an interval than to the centered one. Since R/L<=2, that centered interval has normalized halfwidth <=3/2, yielding rho/R. Thus no favorable scale/convolution selector has been chosen per receiver; it is a pointwise bound for every fixed scale pair BEFORE integrating the two already paid positive selector measures.

A q_k tensor term has k soft coordinates, so its overlap is <=rho^k max(L,R)^-n. The actual common-soft positive coefficient sum therefore has

    C_n(rho)=sum_(k=0)^n c_(n,k)rho^k
                    <=sum_(k=0)^n rho^k<=1/(1-rho),

because each c_(n,k) is a binomial probability maximum and <=1. Combining with the exact R302 double-scale normalization gives

    ||P||_infinity<=(2a^-n-b^-n)/(1-rho).

Consequently the ACTUAL direct light-column branch with beta(Q_(2Db)(z))<=q_-a^n L0 costs at most [2/(1-rho)]L0 nu(Z_light). It can allow root-polylog L0 without a sqrt(n) amplitude loss. Neither this estimate nor the unchanged L1 mass A_n^2 Csoft supplies the unpaid heavy/far source integration or original outer ledger. The pointwise improvement is dimension-free, the claimed total general-source price is not.

Actual local mpmath quadrature at 60 digits gave rho=0.88652101965929144768734422058075555958219330086475 and 1/(1-rho)=8.8122046655478089926290753868250891545514293132159; phi's unit-scale height is 0.55679127144964308526140124767563846447232920967732<rho. These are ordinary high-precision diagnostics, not interval certificates. Independent statement verdict: PASS.

## 6. Author-file comparisons after independent screening — PASS

Read /tmp/r303_geometry.md after screening the receiver-removal theorem. Its factor, cumulative harmonic integral, inclusive atoms and entropy variation agree with the independent proof. The true full-soft tail retains the common coefficient sum and actual scale-envelope mass before restricting the far region. The exact near/far split keeps the ORIGINAL J in both denominators; it does not recompute a smaller near-only normalization. The original-traffic reentry has the correct factor two on B and epsilon. The stated near source/receiver support inclusions are valid geometric facts and are explicitly not small-source-mass estimates. All original aspect and outer fees remain. No correction is needed.

Read /tmp/r303_soft_gap.md after screening its strict contraction. Even-unimodality follows from positive centered-interval overlap layercake, so the R>=L center evaluation applies uniformly to every translation. Its R/L<=2 implication and L>=R density-height argument give the correct single-coordinate rho. The common-soft coefficient sum and exact two positive selector integrals are retained before the point estimate. Thus it legitimately improves the ACTUAL direct light-column payment without a Poisson factor two, while the full L1 envelope mass and heavy/far/source/outer fees remain. No new selector exchange, source density or independent-coordinate softness is introduced. No correction is needed.

Provisional proof bindings:
- /tmp/r303_geometry.md: d32113b1bf00e020774a2b8626164aeb2533ce2494d287088b087787b1d0473a
- /tmp/r303_soft_gap.md: a33eaf0e31204642204b4f507c1f089bac652e8b690a25da52d96dd0733c7dff

## 7. Independent positive-composition screen before final integration

The proposed combination is valid. Freeze D0>1 and source columns Z_l={beta(Q_(2D0b)(z))<=q_-a^n L0}, Z_h its complement, nu_l=1_Zl nu and nu_h=1_Zh nu. Split actual target traffic into pair-far, near-light and near-heavy. R296 pays pair-far by epsilon W_beta using D0=1+log(1+C0/epsilon), C0=(16/9)A_n n Csoft, while the dimension-free contraction pays near-light by 2C_rho L0 W_nu_l with C_rho=1/(1-rho).

Near-heavy is positively enlarged to the same original aspect-qualified target with hard source restricted to nu_h. This is legitimate only as a FROZEN positive source restriction: original full e_g,m,q,low/high masks, alpha and their point heights are unchanged, not recomputed for nu_h. Its hardcap is inherited by nu_h<=nu, while original beta FIRST is unchanged. Therefore the R302 proof still gives the universal-H source terms 4sqrt(lambda d A_n)(W_beta+W_nu_h)+2B_H(nu_h). R303 receiver removal applies to that same restricted hard-source fee, with original J_y unchanged; choose D1 by its explicit epsilon cutoff to pay B_far<=epsilon W_beta. Hence

    T_target <=2C_rho L0 W_nu_l
            +4sqrt(lambda d A_n)(W_beta+W_nu_h)
            +3epsilon W_beta+2B_H^near(D1;nu_h).

The coefficient 3epsilon is one actual-traffic far fee plus TWO times the auxiliary-boundary far fee. All source charges are displayed. Empty heavy columns may be omitted entirely, but the displayed nonnegative bound remains valid if left unoptimized. The outstanding boundary is supported on heavy source columns and two receivers near their soft source, with the ORIGINAL full-prefix J denominator. This is a positive upper-bound composition: B_H is an auxiliary geometric fee, not an exact original traffic residual allocation. The aspect complement and original outer ledger remain, and no cheap bound for the local-heavy fee is asserted. Verdict: PASS.

## 8. Combined-budget file comparison — PASS

Read /tmp/r303_combined_budget.md and its README candidate. Their formula agrees with the independent composition screen. D0 uses the original actual pair-far R296 estimate and pays epsilon W_beta; D1 pays the auxiliary B far part, whose reentry coefficient is two, so the final coefficient is exactly 3epsilon. The heavy-source positive restriction preserves original full e_g,m and point heights rather than redefining the qualification. The same beta FIRST, inherited nu_h caps, original U_y and J_y therefore justify the reused R301/R302/R303 proofs. The light fee has no additional Poisson factor. The remaining local-heavy B is correctly described as an auxiliary fee of a positive upper estimate, not an exact original traffic residual. No correction is required.

Provisional combined-budget SHA256: 78b9114fb55bc83ede67b6c3226ea1ad0620e208cfe162ce034dbd41a73adf5c

## 9. Independent interior ultra-near screen before reading its author file

A new SAME-selected-radius auxiliary branch is valid. For fixed y, let the original interior row intensity be supported where |x-y|_infinity<=R(x)/2-h. Every such actual hard cube contains the ENTIRE fixed source cube Q_(2h)(y). If that row measure is nonzero, let m_y be its essential infimum of R. Original actual caps therefore give nu(Q_(2h)(y))<=4lambda m_y^n by taking the infimum/limit of valid same-R bounds. An actual witness attaining m_y is not required; the fixed source mass is bounded along arbitrarily small positive-measure radius prefixes. Essential-infimum measurability follows from rational tests of the measurable row kernel. Zero rows have zero target density and are assigned any harmless legal radius.

On target traffic under this row measure, R>=m_y almost everywhere. The original aspect v>=v0 implies L>=v0^(2/n)R (also when L>=R). Thus r_y=max(a,v0^(2/n)m_y) lies in [a,b] and both actual scales are >=r_y. The original R297 own-scale theorem with frozen omega=1_Q_(2h)(y) gives normalized capacity at most (16/3)(m_y/r_y)^n<=(16/3)v0^-2 and actual branch price (16/3)kappa0 psi_inf v0^-2 W_beta. Original low/high/e/m qualifications remain unchanged; no inflated-radius cap was used.

This pays an original ultra-near INTERIOR traffic suballocation. It does not directly pay the auxiliary R302 B_H boundary fee, nor the noninterior collar or intermediate source annulus. An alternate whole-close branch using R+4h caps needs a separately proved ALL-radius original cap or an explicit extra hypothesis; a single selected-radius cap is insufficient. Its relationship to previous tiny-source-near payments must be stated without claiming a new general heavy-column closure. Independent statement verdict: PASS with these precise scopes.

## 10. Heavy-column auxiliary file comparison — PASS

Read /tmp/r303_heavy_columns.md after the independent interior screen. The actual U_int kernel, measurable essential minimum, positive-prefix witness proof and exception-set traffic estimate justify the SAME-selected-radius cap limit without a measurable point selection. Own-scale r_y is legal, its v0^-2 normalization is exact, and original FIRST costs W_nu only once. This is a genuine original interior-ultra-near suballocation; it is not a direct estimate of the auxiliary B_H fee. Collar, intermediate source annulus and aspect complements remain.

The optional whole-close Section 5 is explicitly conditional on ALL-radius caps at accepted receivers and expressly does not claim original provenance for that stronger premise. Its R+4h inflation, margin h, bottom m<=b-5h limit, top FIRST strip, narrow-window fallback and exponential factor e^(5eta) are correct. No selected-radius cap is silently inflated. Its possible overlap with earlier tiny-source-near payments must be treated as an auxiliary check rather than a new general heavy-column closure; the final editorial nonnovelty phrase requested by the parent will be bound without reauditing the mathematics.

## 11. Final integration/evidence receipt — PASS and frozen

Read the final README and the heavy-column scope clarification. The auxiliary interior capture is explicitly an automatic R297 application; independent novelty relative to earlier tiny-near work is not established or counted as a new general budget. Its whole-close extension remains conditional on separately verified all-radius caps and is not used in the combined theorem. The final README otherwise agrees with all four proofs: dimension-free soft-coordinate point contraction, actual light payment, original-normalization far-receiver deletion budget, positive heavy-source composition with coefficient 3epsilon, and the remaining local-heavy AUXILIARY fee. It explicitly preserves source bridges, extreme aspect and original outer/clock costs, and does not assert general closure. No final correction is required.

Inspected evidence artifacts: soft-gap JSON reports 62 PASS checks at the documented ordinary 40/60-digit precision and constants agree with the independently computed 60-digit values in Section 5. Shell JSON is PASS with no failures and sum 1621; its 15 true positive-volume source/shell cases, 1065 exact tensor second moments and 31 concentric zero-Q layers agree with README. The same-center versus displaced Q behavior is only a model diagnostic, not a universal overlap law. MATLAB JSON reports three PASS cases and local R2026a Update 4; wide/tight floating quadratures are explicitly not interval certificates. Parent reports actually rerunning all these and the extracted geometry 384/288/72 and auxiliary 540/90 scripts; the scripts and embedded result statements are bound below, without claiming separate nonexistent log artifacts or repeating full runs. The auditor independently ran the 128 finite deletion-prefix cases and 60-digit rho quadrature recorded above. Finite evidence does not supply original full low/m/e/history or all-radius maximal qualifications, and is not used to fit a general dimension exponent.

Final SHA256 bindings (superseding provisional hashes above):
- /tmp/r303_README.md: 298a4595ceacf63aed0fb5e46c9e466a97dabd98e4f1b452c3d6c7ab313f827a
- /tmp/r303_soft_gap.md: a33eaf0e31204642204b4f507c1f089bac652e8b690a25da52d96dd0733c7dff
- /tmp/r303_geometry.md: d32113b1bf00e020774a2b8626164aeb2533ce2494d287088b087787b1d0473a
- /tmp/r303_combined_budget.md: 78b9114fb55bc83ede67b6c3226ea1ad0620e208cfe162ce034dbd41a73adf5c
- /tmp/r303_heavy_columns.md: 48dc2ecf1798dc784571c96063e085e53d53e600d3cd54a3322e9cd2fb87ca16
- /tmp/r303_soft_gap_checks.py: 89473c6ff30e4a99000c7c954571618aac22201b142879917530c90656ade30b
- /tmp/r303_soft_gap_checks.json: 0c451031a1458acbc05760d9407b6c9bc3743e45f6a567518389f88564062280
- /tmp/r303_shell_checks.py: a91d1566ea54f943ffbea0055446672804be7865f8fa69a387be1859ddbb8148
- /tmp/r303_shell_checks.json: 1a1dcb34f70c04f276c621efda7d4cc00b8e835c8c68b6f9f176fdeaad6f5834
- /tmp/r303_shell_checks.md: f6fb5a092dea74e319378226241ed1138b38bc7bf3065c872c94ad6e5d1f8d8d
- /tmp/r303_geometry_checks.py: 37337217f0750346197afdfa3a4e29522873f46e4b6b0d241a147479d9ae6955
- /tmp/r303_heavy_checks.py: 3a0144a4c73c03d68ed0891f1f71c0272724e718edf407ed3a8ab10d7ca07753
- /tmp/r303_matlab_checks.m: 1ca7ccce4bb2a59f36b0db607a99eb4499c333caefd72727a0caa5970c84d3d4
- /tmp/r303_matlab_checks.json: 094deb58aa9846320702b8e1021ff662cf01c951dcf2d821af1599a92d7083c4

Final bounded verdict: PASS. What remains unproved is a general source-linear root budget or valid absorption for the original-normalization local near-receiver disagreement on frozen heavy source columns, plus the original extreme-aspect/source/outer/global ledgers. Receiver closeness does not imply small arbitrary-source boundary mass. The auxiliary interior proof does not erase that fee or supply an unverified inflated cap. Audit frozen; no repository/Git/PDF or other author file changed.
