# R303 — a source-conserving stability estimate for receiver-boundary disagreement

## 1. Exact original fee and the new paid branch

Keep the complete R302 original setting: arbitrary finite positive L1 beta,nu; actual full-soft p_y=P_(s(x),L(x))(x-y); a<=L,R<=b<=2a; q_-=3lambda/4<=q<=lambda; original accepted receivers E with FIRST and SAME-receiver/SAME-radius hard caps. Let alpha(x,y) be the original z-independent row gate dominating the target. Its original full e_g,m and all source/history qualifications are not recomputed. Put

    U_y(u)=alpha(u,y)1_E(u)p_y(u)/q(u),
    I_y=integral U_y du,
    J_y(r)=integral_{R(u)<=r}U_y(u)du,
    ell_n(dr)=b^(-n)delta_b(dr)+n r^(-n-1)1_(a,b)(r)dr.

For a fixed H>0 the actual outstanding geometric fee is

    B_H=integral beta(dy)ell_n(dr)1{J_y(r)>=H}Q_y(r)/J_y(r),
    Q_y(r)=(1/2)integral_{R(u),R(w)<=r}U_y(u)U_y(w)
                         nu(Q_(R(u))(u) Delta Q_(R(w))(w))du dw. (1)

Delta denotes symmetric difference, and Q_r has side r. Zero rows contribute zero.

Here is a general new receiver-removal stability theorem. Let G_y be ANY measurable set of actual receivers, fixed as a function of y and the original field, and set f_y=integral_(G_y)U_y du. Let B_H^G be the part of (1) whose receiver pair has at least one endpoint in G_y. Then

    B_H^G <=4lambda integral beta(dy) f_y
                              [2+log_+(I_y/H)].               (2)

There is also the H-independent refinement

    B_H^G <=4lambda integral beta(dy) f_y[2+log(I_y/f_y)],       (3)

with value zero at f_y=0. Both are valid on the SAME original fee; their pointwise minimum may be taken. If I_y<H then the entire original row of B_H is zero. No whole hard-source mass is replicated per scale in these estimates.

For the concrete spatial choice

    G_y(D)={u:|u-y|_infinity>Db}, D>1/2,
    S=A_n Csoft_n, A_n=1+n log(b/a),
    Csoft_n<=1+(pi/2)sqrt(n), M=S/q_-,
    T_H=2+log_+(M/H),

(2) and the TRUE common-soft tail give the explicit new source payment

    B_H^far(D) <=(16/9) S n T_H exp(1/2-D) W_beta.              (4)

There is no (b/a)^n factor. For every epsilon>0 the legal choice

    D_epsilon=1/2+log[1+(16 S n T_H)/(9epsilon)]>1/2           (5)

makes B_H^far(D_epsilon)<=epsilon W_beta. The remaining fee is exactly B_H^near(D_epsilon), in which BOTH receivers lie within infinity-distance D_epsilon b of their original soft source y. This is an unconditional payment of an actual positive portion of B_H, not a sufficient overlap hypothesis or a renamed clipped-capacity cost.

## 2. A prefix-preserving proof of the stability theorem

Fix a row y and suppress its subscript. Let mu be the pushforward of U_y(u)du under actual R(u). Define cumulative masses

    J(r)=mu([a,r]), V(r)=integral_[a,r]s^n mu(ds),
    J_G(r)=integral_{G_y,R(u)<=r}U_y(u)du,
    V_G(r)=integral_{G_y,R(u)<=r}U_y(u)R(u)^n du.

Then J_G<=min(f,J), and V_G is associated with the SAME original submeasure, not a source fitted after choosing a radius.

The far-pair indicator is at most 1_G(u)+1_G(w). By symmetry, the half in Q cancels this two-sided overcount. The original hard caps at u and w give

    nu(Q_(R(u))(u) Delta Q_(R(w))(w))
                  <=4lambda[R(u)^n+R(w)^n].

Consequently, on J(r)>0,

    Q^G(r)/J(r)
         <=4lambda[V_G(r)+(J_G(r)/J(r))V(r)].                  (6)

A source point appearing in both cubes is not assumed disjoint; the positive inequality explicitly pays its possible overcount. Crucially the two powers R(u)^n and R(w)^n are retained until their scale integration. Replacing them prematurely by b^n would introduce the unnecessary exponential factor which the following calculation avoids.

The identity ell_n([s,b])=s^(-n) and Tonelli yield

    integral ell_n(dr)1{J(r)>=H}V_G(r)<=f.                     (7)

For the second term, use J_G(r)<=f and J(r)>=max(H,J(s)) whenever r>=s and J(r)>=H. Then

    integral ell_n(dr)1{J(r)>=H}V(r)J_G(r)/J(r)
       <=f integral mu(ds)s^n integral_[s,b]
                                 ell_n(dr)/max(H,J(s))
       =f integral mu(ds)/max(H,J(s)).                        (8)

For any decreasing nonnegative g, its inclusive-CDF endpoint convention gives

    integral g(J(s))mu(ds)<=integral_0^I g(t)dt.               (9)

At a radius atom the left side uses the right endpoint of a jump interval, and hence is at most the integral of the decreasing function over that interval. The continuous part follows by quantiles; this also handles singular continuous measures. In particular, for g(t)=1/max(H,t),

    integral mu(ds)/max(H,J(s))
      <= I/H                       if I<=H;
      <= 1+log(I/H)                if I>=H.                   (10)

When I<H the original B_H row is empty. In all cases the last integral is at most 1+log_+(I/H). Combining (6)-(10) proves (2), including an atom that jumps over H and all endpoint cases. The atom at b in ell_n is essential in (7)-(8) and has not been dropped.

For (3), keep the additional bound J_G/J<=min(1,f/J) and omit the high-prefix restriction positively. In place of (8) obtain

    integral mu(ds)min(1,f/J(s))
       <=integral_0^I min(1,f/t)dt
       =f[1+log(I/f)]                 when 0<f<=I.            (11)

Together with (7), this proves (3). This alternate logarithm records the rarity of removed receivers, while (2) uses the actual cumulative-prefix threshold. Neither formula assumes a cap on nu density, nor a bound on I/f independent of the original input.

## 3. Actual common-soft tail, with all dimension and scale factors

The exact one-dimensional profiles are

    h=1_[-1/2,1/2], w(t)=integral_0^1 exp(-|t|/u)du,
    phi=h*w, f_s=(1-s)h+s phi,
    Hsoft(v)=sup_(0<=s<=1)product_i f_s(v_i).

The common-soft positive expansion is Hsoft<=sum_k a_(n,k)Q_k, where Q_k is the probability density averaged over the choices of k phi coordinates and n-k hard coordinates. The coefficients satisfy

    sum_k a_(n,k)=Csoft_n,
    sum_k k a_(n,k)=(n/2)Csoft_n.

Every Q_k and Hsoft are nonincreasing along rays from zero. The actual tail for D>1/2 obeys

    integral_(|v|_infinity>D)Hsoft(v)dv
          <=(n/3)Csoft_n exp(1/2-D).                          (12)

Indeed the one-dimensional phi tail is

    2 integral_0^1 u^2 exp(-(D-1/2)/u)(1-exp(-1/u))du
          <=(2/3)exp(1/2-D),

and the coefficient-weighted product union bound gives (12). This retains the ONE actual common softness, rather than multiplying independent coordinatewise maxima.

Apply the full-profile scale envelope

    sup_(a<=L<=b)L^(-n)Hsoft((u-y)/L)
       <=b^(-n)Hsoft((u-y)/b)
                       +n integral_a^b L^(-n)Hsoft((u-y)/L)dL/L.

Only afterwards restrict |u-y|_infinity>Db. Since L<=b, the normalized cutoff is at least D, so positive Tonelli and (12) yield

    f_y(D)<= (S/q_-)(n/3)exp(1/2-D), I_y<=M=S/q_-.             (13)

This is the same actual full-soft tail mechanism already established in R296, now used on receiver pairs inside B_H. The tail-restricted profile itself is not asserted ray-decreasing. The row gate alpha<=1 only decreases these integrals.

Substitute (13) and log_+(I_y/H)<=log_+(M/H) in (2), then use lambda/q_-=4/3. This gives exactly (4). Formula (5) makes its coefficient strictly less than epsilon. In particular no spatial covering argument grants a hard cap to a source-centered cube; every hard cap was applied to an original accepted witness before the full-soft tail envelope was used.

## 4. Exact local remainder and original integral reentry

Partition each receiver pair using

    1=1{u,w both outside G_y(D)}+1{u or w in G_y(D)}.

Thus B_H=B_H^near(D)+B_H^far(D) exactly, with the same original J_y(r) in BOTH denominators and the same prefix condition J_y(r)>=H. The near term is NOT recomputed using a smaller near-only normalization. Such recomputation would change the original fee and is not licensed by this proof.

The R302 original traffic bridge therefore gives, for every H>0 and D>1/2,

    T_target<=8lambda H W_beta+(2d/H)A_n W_nu
                   +2B_H^near(D)
                   +(32/9)S n T_H exp(1/2-D)W_beta.          (14)

Here d=kappa0 psi_inf/(q_-v0), with the original low/high and aspect constants, and all original masks and common selectors are exactly those entering R302. For H=sqrt(dA_n/(4lambda)) and D=D_epsilon,

    T_target<=4sqrt(lambda d A_n)(W_beta+W_nu)
                         +2epsilon W_beta+2B_H^near(D_epsilon). (15)

The source-mass-balanced H from R302 can equally be retained; D_epsilon then uses that actual H in T_H. Zero source masses give zero original traffic. The positive original outer price Lambda(xi) multiplies (14) or (15) inside the existing outer source/clock ledger. There is no newly free outer integration, no assumption that the aspect complement v<v0 is paid, and no invented absorption entry involving lambda|E|.

On the near term the two receiver centers obey |u-w|_infinity<=2Db. Moreover any hard source in their symmetric difference lies within (D+1/2)b of y. These are actual support facts, not a claim of small source mass. The remaining unproved geometric estimate is a useful source-linear or receiver-absorbable bound for this local, original-normalization double-receiver boundary integral. The coarse bound B_H^near<=A_nW_nu remains valid and is not root order by itself. No thin-boundary source-density estimate follows from the accepted receiver hard caps alone.

The completed gain is the general stability theorem (2)-(3), and its unconditional full-soft far-pair payment (4)-(5). It gives an actual source-conserving reduction of the outstanding fee, while explicitly preserving the local disagreement bottleneck.

## 5. Actual bounded numerical verification

An actual local Python run used exact Fractions for 384 pair/scale hard-cap comparisons and 288 receiver-removal source-budget comparisons, with three dimensions n=1,2,8, empty/all/partial removal masks, zero and positive row weights, threshold crossings and endpoints. The logarithmic majorant in those 288 cases was checked using Python math double precision with tolerance 1e-13. Separately 72 explicit full-soft tail cutoff choices were checked using Python math double precision through n=10000 with relative tolerance 1e-12. These are finite diagnostics, not a proof of the remaining local boundary estimate. Reproducible code follows and writes no files.

```python
from fractions import Fraction as F
from itertools import product
import math
ct={'pair_scale':0,'removal_budget':0,'tail_choice':0}
for n in [1,2,8]:
 centers=[(F(0),)*n,(F(1,2),)*n,(F(2),)*n];rs=[F(1),F(3,2),F(2)]
 zs=centers+[(F(1),)*n];mass=[F(1,4)]*4
 cap=[[int(all(abs(z[k]-c[k])<=r/2 for k in range(n))) for z in zs] for c,r in zip(centers,rs)]
 for us in [[F(1,4),F(1,2),F(1,4)],[F(1),F(2),F(3)],[F(0),F(1),F(0)]]:
  I=sum(us)
  for gone in product([0,1],repeat=3):
   f=sum(u*g for u,g in zip(us,gone))
   for H in [F(1,10),F(1),F(3),F(7)]:
    B=F(0);harm=F(0);cum=F(0)
    for s in sorted(set(rs)):
     atom=sum(us[i] for i in range(3) if rs[i]==s);cum+=atom
     harm+=atom/max(H,cum)
    for k,r in enumerate(rs):
     weight=r**(-n)-(rs[k+1]**(-n) if k<2 else F(0))
     active=range(k+1);J=sum(us[i] for i in active)
     if J<H:continue
     V=sum(us[i]*rs[i]**n for i in active)
     fg=sum(us[i]*gone[i] for i in active)
     Vg=sum(us[i]*gone[i]*rs[i]**n for i in active)
     Q=sum((us[i]*us[j]*int(gone[i] or gone[j])*sum(m*abs(cap[i][z]-cap[j][z]) for z,m in enumerate(mass)) for i in active for j in active),F(0))/2
     assert Q/J<=4*(Vg+fg*V/J)
     B+=weight*Q/J;ct['pair_scale']+=1
    assert B<=4*f*(1+harm)
    assert float(harm)<=1+max(0,math.log(float(I/H)))+1e-13
    assert float(B)<=4*float(f)*(2+max(0,math.log(float(I/H))))+1e-13
    ct['removal_budget']+=1
for n,ratio,eps,hrel in product([1,2,64,10000],[1,2],[.01,1,100],[.01,1,100]):
 S=(1+n*math.log(ratio))*(1+math.pi*math.sqrt(n)/2)
 T=2+max(0,math.log(1/hrel));C=16*S*n*T/9
 D=.5+math.log1p(C/eps)
 cost=C*math.exp(.5-D)
 assert cost<=eps*(1+1e-12)
 ct['tail_choice']+=1
print('PASS',ct)
```

Only /tmp/r303_geometry.md was written. No earlier proof, other author file or Git state was changed.
