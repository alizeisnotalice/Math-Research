# R303 — a true same-radius witness pays interior heavy columns

## 1. Exact original interface and the proved branch

Fix one original outer-data/clock instance, with finite positive L1 sources beta and nu, accepted receiver set E, and its actual measurable fields s,L,R,q. Assume

    a<=L(x),R(x)<=b<=2a,  q(x)>=q_-=3lambda/4>0.

Keep the full original low-pe, m>M, band, forbidden and history mask I0(x,y,z) in [0,1], and the actual soft point p_y(x). The original qualifications give the R297 actual point heights, with

    kappa0=2K/(ell M), gamma=1+1/n,
    psi_inf=3-2/(3gamma^n)<2.754748.

The ONLY hard cap required for the proved theorem below is the cap at the SAME selected radius at original receivers:

    nu(Q_(R(x))(x))<=4lambda R(x)^n, for a.e. x in E.  (1)

Q_t denotes a centered cube of side t. No cap at an enlarged or future radius is inferred from (1). Original FIRST means

    integral p_y(x) beta(dy)<=q(x), for a.e. x in E.    (2)

Choose any measurable original row mask alpha(x,y) in [0,1], independent of z, dominating I0. Taking alpha=1 is permitted. All quantities below are constructed from the same fixed original field; none of the source measures, e, m, s,L,R or q is recomputed.

Fix h>0 and 0<v0<=1. Define the ACTUAL interior near subtraffic by retaining the original mask and imposing

    |y-z|_infinity<=h,
    |x-y|_infinity<=R(x)/2-h,
    v(L,R)=min(1,(L/R)^(n/2))>=v0.                    (3)

Its raw receiver/source integral is

    T_int=integral I0 1_(3) p_y(x)h_(R(x))(x-z)/q(x)
                                dx beta(dy)nu(dz).

Then the following unconditional consequence of this stated original interface holds:

    T_int <=(16/3)kappa0 psi_inf v0^(-2) W_beta,
    T_int <=[1+n log(b/a)]W_nu.                        (4)

One may take the minimum. The first bound is independent of n except through kappa0, v0 and the bounded constant psi_inf. It applies at all original physical scales and all original common softnesses. It is a positive original traffic allocation, rather than a replacement fixed-scale convolution.

In particular, intersect (3) with ANY frozen hard-column set, including

    Z_heavy={z:b_D(z)>q_- a^n L0},
    b_D(z)=beta({y:|y-z|_infinity<=Db}).                (5)

The same first payment, with W_beta unchanged, pays that heavy-column interior allocation. No density or total-mass assumption is made. Large b_D is permitted. The theorem pays an actual geometric portion of those columns, not b_D itself.

## 2. Construct the witness from the actual row; no cover hypothesis

Put

    U_y^int(x)=1_E(x)alpha(x,y)p_y(x)/q(x)
                       1{|x-y|_infinity<=R(x)/2-h}.

On rows for which this positive measure is nonzero, let

    m_y=essinf_(U_y^int dx) R(x),
    c=v0^(2/n), r_y=max(a,c m_y).                      (6)

The nonzero-row set and m_y are measurable: for rational t, its sublevel sets are determined by the measurable integrals of U_y^int 1{R<t}. For a zero row choose any m_y in [a,b] and exclude that row from all following charges. Such a row has no traffic in (3). Indeed integrating the original hard source at each receiver bounds its target row measure by 4lambda U_y^int(x)dx, using (1).

For every nonzero row and every epsilon>0 there is positive U_y^int measure of original receivers u satisfying

    R(u)<m_y+epsilon,
    |u-y|_infinity<=R(u)/2-h,
    nu(Q_(R(u))(u))<=4lambda R(u)^n.                   (7)

The a.e. original cap can be imposed without losing this positive measure. For every such u, the triangle inequality gives the GENUINE cube inclusion

    Q_(2h)(y) subset Q_(R(u))(u).

Hence nu(Q_(2h)(y))<=4lambda(m_y+epsilon)^n. Taking epsilon down to zero proves the frozen source-row capacity

    nu(Q_(2h)(y))<=4lambda m_y^n.                     (8)

No measurable point selector u(y) is necessary. The bound follows from a positive set of witnesses, and (8) is independent of which one is chosen. This is the useful geometric step: a row with actual interior response automatically supplies a small-scale capturing witness for the whole frozen nearby source block.

On almost every target edge in (3), R(x)>=m_y. The exceptional receiver set has zero U_y^int measure, and (1) makes its integrated target traffic zero. The aspect condition implies L(x)>=cR(x). Thus

    min(L(x),R(x))>=r_y.

This own-scale gate is automatic on the paid original allocation, rather than an extra unproved covering premise. Also r_y<=m_y<=b, and

    nu(Q_(2h)(y))/(q_- r_y^n)
       <=(16/3)(m_y/r_y)^n
       <=(16/3)c^(-n)=(16/3)v0^(-2).                 (9)

The factor v0^(-2) is explicit. No conclusion for unrestricted tiny aspect is hidden in (4).

## 3. Actual receiver integration and FIRST

Apply the proved R297 own-row-scale theorem to the frozen r_y of (6), the frozen pair mask omega(y,z)=1{|y-z|_infinity<=h}, and the original beta restricted to nonzero rows. The actual interior and aspect masks may be retained on the left and dropped positively only after the actual point heights are used. That theorem gives

    T_int <= kappa0 integral beta(dy)
       [nu(Q_(2h)(y))/(q_- r_y^n)]
                         Psi_((1+1/n)^(n/2))((b/r_y)^n)
       <=kappa0 psi_inf integral beta(dy)
                               nu(Q_(2h)(y))/(q_-r_y^n).

Equation (9) proves the first bound in (4). In particular no replacement of r_y by a is made. Source conservation is explicit: each beta row is charged once, regardless of its own m_y; the same nu mass may occur at different beta rows, but its total normalized mass on EACH row is proved in (9) before summing. No W_nu is charged once per scale.

For the second bound, use original FIRST (2) at actual receivers before receiver extension. Drop all positive source/geometry masks and use the single hard-scale envelope on [a,b], whose Lebesgue integral is 1+n log(b/a). This costs W_nu once on the aggregate traffic. FIRST is not applied at an invented receiver, to a latent soft component, or to a nu/beta-swapped input.

All arguments use positive Tonelli; zero rows were excluded without dividing by their mass. Cube boundary conventions do not affect these L1-source integrals. Actual receiver-dependent scale selectors are retained until the applicable point-height inequality or FIRST is invoked. The original outer multiplier still multiplies these RAW receipts once.

## 4. Precise remaining geometry

Within the old near heavy-column branch, the theorem removes exactly the part satisfying (3). For the same aspect-qualified target the remaining part includes

    h<|y-z|_infinity<=Db,

and the true receiver boundary collar

    |y-z|_infinity<=h, |x-y|_infinity>R(x)/2-h.

It also leaves the original aspect complement v<v0. There is no assertion that heavy columns force interior traffic, nor that their boundary collar has small original p_y h_R/q traffic. The specific missing geometric premise for extending the same-radius proof is an affordable fixed-source capture of those collar edges at witness radii no larger than their actual min(L,R), or a separate original-FIRST payment of that collar. The present proof supplies such a witness automatically for the interior, but not for the collar. An arbitrarily large source mass outside the accepted witness cubes is not controlled by (1).

Thus (4) is a proved payment for the stated interior branch. It is an automatic application of R297; independent novelty versus the earlier R289 near-source work has not been established, and it is not counted as a new general root budget. It does not close the near-heavy mechanism for arbitrary inputs. The parent's dimension-free point coefficient from /tmp/r303_soft_gap.md separately improves the light-column receipt; that contraction is neither rederived nor assumed to resolve the collar here.

## 5. Conditional extension; enlarged caps are NOT part of (1)

For completeness the stronger very-close statement has a short, exact additional premise. Suppose separately that ORIGINAL accepted receivers carry

    nu(Q_t(x))<=4lambda t^n for EVERY t in [a,b].       (10)

This all-radius premise is stronger than the selected-radius interface (1). Prior notes name a maximal hard cap, but that name alone is not a verified locator in the original reduction; this note does NOT certify (10) for the current original input.

Under (10), all |y-z|_infinity<=h, v>=v0 traffic (without the interior condition) is paid as follows. Use the original z-independent row gate

    U_y^out=1_E alpha p_y/q
                     1{|x-y|_infinity<=R(x)/2+h}

and its essential minimum m_y of R. Every actual very-close hard-supported edge has this row gate automatically. If m_y<=b-5h, actual original witnesses with R<m_y+h satisfy

    Q_(2h)(y) subset Q_(R+4h)(x),
    a<=R+4h<b.

Premise (10), at that original x but at the NEW radius R+4h, gives nu(Q_(2h)(y))<=4lambda(m_y+5h)^n. The same r_y=max(a,c m_y) therefore gives the bottom-row receipt

    T_bottom <=(16/3)kappa0 psi_inf v0^(-2)
                                 (1+5h/a)^n W_beta.   (11)

The remaining nonzero rows have m_y>b-5h, hence all their actual target hard radii exceed B0=b-5h. When B0>=a, aggregate original FIRST followed by the SINGLE envelope [B0,b] gives

    T_top<=[1+n log(b/B0)]W_nu
          <=[1+5nh/a]W_nu.                            (12)

No per-row or per-window nu fee occurs. If B0<a, the entire original window instead has FIRST fee 1+n log(b/a)<=1+5nh/a, without needing (11). Consequently with h=eta a/n, the conditional whole-very-close receipt is at most

    (16/3)kappa0 psi_inf v0^(-2)e^(5eta) W_beta
                                      +(1+5eta)W_nu.  (13)

For the narrow-window fallback only the second term is needed. This extension accurately records its translation/inflation 4h, witness margin h, endpoint loss 5h and exponential volume loss. It cannot be advertised as an unconditional original payment until (10) has an exact original provenance. In contrast Sections 1–4 use only (1).

## 6. Actual bounded local verification; minimal reproduction

The following Python standard-library code was actually run. It passed 540 exact-Fraction interior/own-scale cases and 90 outer-boundary cases; only the logarithmic endpoint checks use floating point. These diagnostics check the geometric and normalization algebra, not every original selector or arbitrary-source theorem. The analytic proofs above give those quantifiers.

```python
from fractions import Fraction as F
import math
count=0
for n in (1,2,8,64,1024):
 for a in (F(1,2),F(1),F(3)):
  for m in (a,F(3,2)*a,2*a):
   for c in (F(1,4),F(3,4),F(1)):
    for h in (a/100,a/10):
     r=max(a,c*m)
     for eps in (F(1,100),F(1,10000)):
      R=m*(1+eps)
      u=R/2-h; z=-h
      assert abs(u-z)<=R/2
      assert (r<=m and r<=c*m) or r==a
      assert m/r<=1/c
      L=max(a,c*R)
      assert min(L,R)>=r
      count+=1
outer=0
for n in (1,2,8,64,1024):
 for a in (F(1,2),F(1),F(3)):
  for b in (a,F(3,2)*a,2*a):
   for h in (a/100,a/10):
    t=b-5*h
    if t>=a:
     assert 1+n*math.log(float(b/t))<=1+float(5*n*h/a)+1e-10
     m=t; R=m+h/2
     assert R+4*h<=b
     u=R/2+h; z=-h
     assert abs(u-z)<=(R+4*h)/2
    else:
     assert math.log(float(b/a))<=float(5*h/a)+1e-12
    outer+=1
print(count,outer)  # actual output: 540 90
```

Only this assigned file was created; no other author file or Git state was changed. The source-scale theorem is imported from /tmp/r297_scale_budget.md; no new scale-envelope theorem or universal root bound is claimed.
