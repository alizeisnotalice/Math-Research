# R303: strict soft-coordinate contraction removes the root point-amplitude cost

## Theorem and actual branch payment
Use the ACTUAL common-soft profiles h=1_[-1/2,1/2], w(x)=integral_0^1 exp(-|x|/u)du, phi=h*w, f_s=(1-s)h+s phi. Retain a<=L,R<=b<=2a, q>=q_-=3lambda/4, original arbitrary positive L1 sources beta,nu, actual receivers and all original target masks. Let mu=delta_b+n dL/L and let P=K*H be the positive two-selector envelope from R302. In particular the actual selected traffic satisfies
 T_omega<=q_-^(-1) integral omega(y,z)P(z-y)beta(dy)nu(dz)
for every frozen measurable source-pair gate 0<=omega<=1.

Define
 rho=1-2 integral_0^1 u exp(-3/(2u))du, 0<rho<1,
 C_n(rho)=sum_(k=0)^n c_(n,k)rho^k,
 c_(n,k)=max_(0<=s<=1) binom(n,k)s^k(1-s)^(n-k).
Then
 ||P||_infinity <=C_n(rho)(2a^(-n)-b^(-n))
                <=(2a^(-n)-b^(-n))/(1-rho).             (1)
The coefficient is independent of dimension. Unlike the previous root point bound, (1) keeps a strict loss for every genuinely soft coordinate before summing over the shared-soft expansion.

For D>0,L0>=0 define b_D(z)=beta(Q_(2Db)(z)),
 Z_light={z:b_D(z)<=q_-a^n L0},
 omega_light=1_{|y-z|_infinity<=Db}1_{Z_light}(z).
The actual direct branch payment becomes
 T_light<=[2-(a/b)^n] C_n(rho)L0 nu(Z_light)
         <=2L0 nu(Z_light)/(1-rho).                     (2)
This permits L0 as large as root-polylog dimension order for a root-polylog receipt, whereas the previous Csoft~sqrt(n) point estimate only permitted polylog L0. The source gates are defined using original beta and are not recomputed. The near heavy columns, far pairs and original outer ledger remain explicit. One cannot iterate partitions and spend the full nu mass each time without an additional price.

The integrable mass remains ||P||_1=A_n^2 Csoft_n. A dimension-free point amplitude is not a dimension-free L1 envelope or an all-input endpoint. The proof does not assert any source density or beta/nu order.

## Uniform strict contraction of an actual soft coordinate
Let W have density w, a normalized even decreasing density. Its exact two-sided tail is
 P(|W|>t)=2 integral_0^1 u exp(-t/u)du.
For fixed L,R, denote the hard overlap h_L*h_R and soft overlap phi_L*h_R. The former is at most 1/max(L,R).

If L>=R, convolution by the probability density h_R cannot increase the sup norm. Also phi is even and decreasing away from zero, and
 phi(0)=integral_(-1/2)^(1/2) w(x)dx=P(|W|<=1/2)<=rho.
Hence ||phi_L*h_R||_infinity<=rho/L.

If R>=L, the convolution phi_L*h_R is even and decreasing away from zero, so it is maximal at zero. To justify this without an external structural theorem, use positive layer cake: the superlevel sets of an even decreasing one-dimensional density are centered intervals, and the overlap length of two centered intervals after translation is maximal at zero and nonincreasing with the absolute translation. Integrating these overlap lengths proves the assertion for the convolution.

Let Y be uniform on [-1/2,1/2], independent of W. Then
 (phi_L*h_R)(0)=(1/R)P(|L(Y+W)|<=R/2).
The event implies |W|<=R/(2L)+1/2<=3/2 because R/L<=b/a<=2. Its probability is at most rho. Consequently in both orientations,
 (phi_L*h_R)(delta)<=rho/max(L,R) for every delta.      (3)
The inequality includes L=R, both scale endpoints, all translations and arbitrarily small but positive a. It uses the original full w, not a Gaussian or independent coordinate-softness replacement.

## Common softness and both selected scales
For a subset S of k coordinates, the fixed-scale tensor overlap therefore has point value at most rho^k max(L,R)^(-n). Averaging over S and retaining the exact common-s coefficients gives
 (Q_(n,L)*h_R)(delta)<=C_n(rho)max(L,R)^(-n).
Each c_(n,k) is a binomial probability at its maximum and is at most one, including k=0,n. Thus C_n(rho)<=sum_(k=0)^n rho^k<=1/(1-rho).

Now integrate BOTH positive scale measures mu. The R302 exact identity
 integral integral max(L,R)^(-n)mu(dL)mu(dR)=2a^(-n)-b^(-n)
proves (1). The actual receiver-dependent scale and softness selections were first dominated by K(x-y) and H(x-z); only afterwards was the actual receiver integral enlarged and evaluated as K*H. No receiver selector has been passed illegally through a convolution. Integrating (1) against the actual light gate proves (2) with no Poisson factor two.

## Remaining geometric task and diagnostics
The improvement in (2) enlarges the paid light-mass region but does not imply all actual columns are light. FIRST only holds at actual accepted receivers; it does not cap b_D(z) at source centers. The remaining heavy-column problem must use additional actual receiver geometry. The high-cumulative symmetric-difference budget B_H is separate and has no general root payment from this point bound alone.

Main actually evaluated rho using the connected local MATLAB integral routine: displayed rho approximately0.8865 and (1-rho)^(-1) approximately8.8122. High-precision, multi-stage true-profile checks and exact coefficient diagnostics are provided separately. These finite calculations support the implementation and constants, not the all-input theorem. All theorem steps above are analytic; no simulation determines an exponent.
