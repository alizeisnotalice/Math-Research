#!/usr/bin/env python3
"""Exact tensor intersection moments for displaced positive-volume shell diagnostics."""
import json,sys,hashlib
from pathlib import Path
from fractions import Fraction as F
from decimal import Decimal as D,localcontext
from math import isqrt
if hasattr(sys,'set_int_max_str_digits'):sys.set_int_max_str_digits(0)
COUNTS={};FAIL=[]
def ck(ok,label,data):
 COUNTS[label]=COUNTS.get(label,0)+1
 if not ok:FAIL.append({'test':label,'data':data})
def dec(q):
 with localcontext() as c:c.prec=60;return str(D(q.numerator)/D(q.denominator))
def digest(q):return hashlib.sha256(str(q).encode()).hexdigest()
def overlap(s,R,z):
 if not s:return F(0)
 return max(F(0),min(s/2,z+R/2)-max(-s/2,z-R/2))
def breaks(s,R,lo,hi):
 return [v for v in [-(s+R)/2,-abs(s-R)/2,abs(s-R)/2,(s+R)/2] if lo<v<hi]
def moment(s,R,t,delta,s2=None,R2=None):
 lo=t-delta;hi=t+delta;points=sorted(set([lo,hi]+breaks(s,R,lo,hi)+(breaks(s2,R2,lo,hi) if s2 is not None else [])))
 total=F(0)
 for a,b in zip(points,points[1:]):
  def value(z):return overlap(s,R,z)*(overlap(s2,R2,z) if s2 is not None else 1)
  # Simpson is exact for each quadratic product of affine overlap pieces.
  total+=(b-a)*(value(a)+4*value((a+b)/2)+value(b))/6
 return total/(2*delta)
def run(n,m,t,k):
 delta=F(1,100*n);rr=[1+F(i,m) for i in range(m+1)];sides=[r-2*delta for r in rr];vol=[s**n-(sides[i-1]**n if i else 0) for i,s in enumerate(sides)];u=[v/r**n for v,r in zip(vol,rr)]
 name=f'n{n}_m{m}_t{t}_k{k}'
 ck((2*delta)**n>0,'actual_positive_L1_source_cubes',{'case':name})
 for i,r in enumerate(rr):
  ck(sides[i]/2+delta==r/2 and r**(-n)<=1 and 4*r**(-n)<=4,'actual_soft_support_FIRST_sameR_caps',{'case':name,'shell':i})
 # Cache one-dimensional moments for zero and shifted coordinates.
 cache={}
 def one(a,ra,b=None,rb=None,center=F(0)):
  key=(a,ra,b,rb,center)
  if key not in cache:cache[key]=moment(a,ra,center,delta,b,rb)
  return cache[key]
 def tensor(a,ra,b=None,rb=None):return one(a,ra,b,rb,t)**k*one(a,ra,b,rb,F(0))**(n-k)
 mu=[]
 for i,r in enumerate(rr):
  outer=tensor(sides[i],r);inner=tensor(sides[i-1],r) if i else 0
  mu.append((outer-inner)/r**n)
 pair=[[F(0) for _ in rr] for _ in rr]
 for i,ri in enumerate(rr):
  for j in range(i+1):
   rj=rr[j];v=F(0)
   for si,signi in [(sides[i],1)]+([(sides[i-1],-1)] if i else []):
    for sj,signj in [(sides[j],1)]+([(sides[j-1],-1)] if j else []):v+=signi*signj*tensor(si,ri,sj,rj)
   pair[i][j]=pair[j][i]=v/(ri*rj)**n
   ck(0<=pair[i][j]<=u[i]*u[j],'exact_shell_pair_intersection_moment_range',{'case':name,'i':i,'j':j})
 J=M1=M2=F(0);layers=[]
 for i,r in enumerate(rr):
  J+=u[i];M1+=4*mu[i];M2+=4*(pair[i][i]+2*sum(pair[i][:i]));Q=J*M1-M2
  ck(0<=mu[i]<=u[i],'exact_first_shell_moment_range',{'case':name,'shell':i})
  ck(M1*M1<=4*M2 and 0<=M2<=J*M1,'exact_Jensen_and_Q_nonnegative',{'case':name,'r':str(r)})
  if not t:ck(M1==4*J and M2==4*J*J and Q==0,'concentric_exact_zero_Q',{'case':name,'r':str(r)})
  w=r**(-n)-(rr[i+1]**(-n) if i+1<len(rr) else 0)
  layers.append({'r':r,'w':w,'J':J,'M1':M1,'M2':M2,'Q':Q})
 total=sum(l['w']*l['M1'] for l in layers);Hroot=F(isqrt(n*1000000),1000);fees=[]
 for H in [Hroot/2,Hroot,2*Hroot]:
  BH=F(sum(l['w']*l['Q']/l['J'] for l in layers if l['J']>=H))
  paid=F(sum(l['w']*l['M1'] for l in layers if l['J']>=H))
  ck(0<=BH<=paid<=total,'exact_BH_range',{'case':name,'H':str(H)})
  fees.append({'H':str(H),'qualifying_layers':sum(l['J']>=H for l in layers),'BH':dec(BH),'BH_exact_fraction':str(BH),'BH_over_full_linear_traffic':dec(BH/total) if total else None,'BH_over_nu_mass':dec(BH/4),'large_J_linear_traffic':dec(paid)})
 return {'name':name,'dimension':n,'m':m,'shells':m+1,'shift_t':str(t),'shifted_coordinates':k,'delta':str(delta),'beta_mass':'1','nu_mass':'4','max_J':dec(J),'full_linear_traffic':dec(total),'positive_Q_layers':sum(l['Q']>0 for l in layers),'BH_thresholds':fees,'one_dimensional_cached_integrals':len(cache),'pair_moment_matrix_sha256':hashlib.sha256('|'.join(str(v) for row in pair for v in row).encode()).hexdigest(),'layers':[{'r':str(l['r']),'J':dec(l['J']),'M1':dec(l['M1']),'M2':dec(l['M2']),'Qpair':dec(l['Q']),'Q_over_JM1':dec(l['Q']/(l['J']*l['M1'])) if l['M1'] else None,'Q_exact_sha256':digest(l['Q'])} for l in layers]}
stages=[]
for name,n,m in [('initial',4,4),('boundary_displacement',8,8),('expanded',16,16)]:
 specs=[(F(0),0),(F(1,n),1),(F(2,n),1),(F(1,n),n),(F(2,n),n)]
 stages.append({'name':name,'cases':[run(n,m,t,k) for t,k in specs]})
out={'status':'PASS' if not FAIL else 'FAIL','scope':'Exact finite tensor intersection moments for genuine positive-volume L1 beta/nu cubes and concentric receiver shells. Actual s=0 kernels, FIRST<=1 and same-radius hardcaps<=4. No complete low-m/e_g/maxhardcap history, FULL certificate, or general dimension order is asserted.','construction':'delta=1/(100n), beta uniform cube centered0 side2delta mass1; nu uniform cube centered(t repeated k coordinates,0 remaining),side2delta,mass4. R_i=L_i=1+i/m; E0=Q_(R0-2delta);Ei=Q_(Ri-2delta) minus Q_(R_(i-1)-2delta). Cube parameters are side lengths.','moment_method':'For each shell i, f_i(z)=Ri^-n [product overlap(side_i,Ri,z_l)-product overlap(side_(i-1),Ri,z_l)]. M1=4 E(sum f_i), M2=4 E(sum f_i)^2. One-dimensional overlaps are affine between exact breakpoints; Simpson integrates their quadratic products exactly with Fraction. Tensor independence computes pair moments before cumulative summation.','global_layer_fee':'w_i=Ri^-n-R_(i+1)^-n; endpoint b^-n; BH=sum_(J_i>=H) w_i Q_i/J_i. H uses floor(1000sqrt n)/1000 and half/double this rational threshold.','check_counts':COUNTS,'failures':FAIL,'stages':stages}
base=Path(__file__);base.with_suffix('.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n')
lines=['# R303 displaced-source shell diagnostics','',out['scope'],'',out['construction'],'',out['moment_method'],'','|n|t|k|max J|linear traffic|BH at H≈sqrt n|BH/linear|','|---:|---:|---:|---:|---:|---:|---:|']
for stage in stages:
 for c in stage['cases']:
  fee=c['BH_thresholds'][1];lines.append(f"|{c['dimension']}|{c['shift_t']}|{c['shifted_coordinates']}|{float(c['max_J']):.6g}|{float(c['full_linear_traffic']):.6g}|{float(fee['BH']):.6g}|{float(fee['BH_over_full_linear_traffic']):.6g}|")
lines+=['','Centered source gives Qpair=0 exactly, despite the multiple receiver radii. Displacement makes Qpair positive in these tested models. Thus radial separation alone does not produce this gap in the centered complete-capture construction; these cases locate an additional boundary mechanism. This is a finite diagnostic, not a general dichotomy or asymptotic claim.','',out['global_layer_fee'],'','All signs, moment comparisons and fee bounds use exact Fraction. JSON decimal displays are 60-digit conversions; exact BH fractions and hashes of full exact pair matrices / layer gaps support reproduction without storing the matrices.']
base.with_suffix('.md').write_text('\n'.join(lines)+'\n');print(json.dumps({'status':out['status'],'checks':COUNTS,'failures':FAIL,'cases':[{'name':c['name'],'maxJ':c['max_J'],'BH_root':c['BH_thresholds'][1]['BH'],'BH_over_traffic':c['BH_thresholds'][1]['BH_over_full_linear_traffic']} for st in stages for c in st['cases']]},indent=2));assert not FAIL,FAIL
