# 第101轮：保留接收测度的占用优化、共同分配与有偿拼接

一般中心立方体极大算子在全部非负 L1 输入上的 sqrt(n)n^{o(1)} 一致弱型上界仍未证明。本轮不改变这一状态，也不把存在一个有限证书解释为维数一致的证书。第100轮已独立提交并推送；本轮另行归档。

本轮得到三个可供一般证明使用的工具：由真实未来尺度占用推导正超额平方能量上界；在实际接收测度下优化有偿删除的代理量；在同一真实捕获关系上构造保持行质量的来源重分配，并量化其能量下降和原后验分数的变化。分量证书的拼接则显式保留阈值份额、局部相互作用、远场和计数可加费用。这些一般工具尚未支付目标阶所需的联合预算。

所有来源、接收、阈值和尺度均在对应命题中固定。有限计算用于检验候选策略和反例边界，不拟合一般维数指数。新的公开守卫验证一个真实可数来源的全尺度证书；它只是拼接命题的检查。私人压力配方、程序及量化结果继续留在本地。详细 LaTeX 文本随归档提供，不编译 PDF。


## 统一主账与本轮缺口

记 W=∫f，A_L 为全边长 L 的中心立方体平均。能量阈值记 κ，原共同容量分支阈值记 λ，二者不混用。R100 实际障碍在高度 κ/2 上给 Ω、|Ω|≤2W/κ 及 f≤κ/2 于 Ω 的补集；势的存在性针对 L1∩L2，不能预先断言任意 L1 输入有有限势能。

实际正超额 D_L=(A_Lf−κ)_+，J=∫D_L dL/L，K=∫D_L² dL/L。令 G(t)=t−log(1+t)、ψ=G^{-1}、Φ(q)=∫_0^q ψ(v)dv。本轮证明 K≤κ²Φ(nJ/κ)/n。对任意有偿删除集合 D⊂Ω^c，此式在同一保留接收集合上积分。给定删除体积时，带正确平层处理的 J 尾部删除优化这个代理量；它不证明代理量与真实 K 的最优删除相同。

帽返回仍是 C_n≤4A+8√(nAB/log2)，其中 |U|≤AW/κ、∫_{U^c}K≤BκW 必须对每个正规输入及每个 κ 以维数唯一的 A、B 成立。存在单个输入的有限 A、B 不足够。若能统一支付 A=n^{o(1)}、B=n^{o(1)}，才得到目标。现有已付一般 O(n log n) 基准保留。

另一分支始终保留原同源、同 λ、最早尺度 L_*(x)、全部联合门和已付删除。完整原账为

λ|E_initial|≤[A_old+C_ext+√n+2⌈√n⌉]W+λ|F_2|。

A_old、C_ext、原强度分层和全尺度返回按 adaptive 模块原式逐项保留。共同分配迭代保持原边和行质量，有限次迭代可对同一选定集合的所有子割使用；其当前后验不自动继承原后验的数值门。下降量可和不等于来源列具有根阶上界，也不保证极限保留全部原边。

本轮最小未付部分是：真实 J 分布下的删除体积与保留代理能量的统一联合预算；或者原 F_2 捕获图上能支付全部来源列及余下接收需求的几何估计。代理量与 nJ²+(2√2/3)√(nκ)J^{3/2} 点态相差至多3倍，因而可用同一付费保留集合上的两个实际矩表达缺口，但不能把该等价改写成矩预算已付。局部拼接还必须支付阈值份额的倒数费用、真实相互作用和远场。来源树的每个子树条件、比较分配的能量与熵均是输入假设，不能由改写自动取得。

若未来在 L1∩L2 上取得与幅度无关的一致弱界，才对非负输入做单调截断并对原极大算子取极限，覆盖任意正 L1 输入。当前没有完成此回代所需的统一估计。


## 1. Fixed-certificate gluing

For \(f\ge0\) in \(L^1(\mathbb R^n)\), use the full-side cube average and energy
\[
 A_Lf(x)=L^{-n}\int_{x+[-L/2,L/2]^n}f(y)\,dy,\qquad
 \mathcal E_\kappa(f;U)=
 \int_{U^c}\int_0^\infty(A_Lf-\kappa)_+^2\,\frac{dL}{L}\,dx.
 \tag{G1}
\]
Caps are Lebesgue measurable and receiver/scale sets are measurable for \(dx\,dL/L\). No boundary regularity is assumed. Nonnegative sums and energies may be infinite, but a useful certificate has finite displayed bounds.

Let \(f_j\ge0\) be a finite or countable family in \(L^1\), with
\[
 f=\sum_j f_j,\quad W_j=\|f_j\|_1>0,\quad
 0<W=\sum_jW_j<\infty,\qquad p_j=W_j/W.
 \tag{G2}
\]
Zero-mass components are discarded. Fix \(\kappa>0\), \(0\le\eta<1\), and \(s=1-\eta\). For positive numbers \(\theta_j\), suppose actual component caps satisfy
\[
 |U_j|\le\frac{A_jW_j}{\kappa\theta_j},\qquad
 \mathcal E_{\kappa\theta_j}(f_j;U_j)
       \le B_j\kappa\theta_jW_j,\qquad A_j,B_j\ge0.
 \tag{G3}
\]
These are hypotheses at the chosen thresholds. A certificate at threshold \(\kappa\) cannot replace one at threshold \(\kappa\theta_j\).

Let \(V\) be a separately paid receiver set, \(\mathcal D\) a measurable active region, and \(D_j\) measurable masks. Require, almost everywhere on \((V^c\times(0,\infty))\cap\mathcal D\),
\[
 \sum_{j:(x,L)\in D_j}\theta_j\le s,\qquad
 F(x,L):=\sum_j{\bf1}_{D_j^c}(x,L)A_Lf_j(x)\le\eta\kappa.
 \tag{G4}
\]
The second condition is an actual bound on all inactive sources together. Put \(U=V\cup\bigcup_jU_j\), and suppose
\[
 \int_{U^c}\int_0^\infty{\bf1}_{\mathcal D^c}
             (A_Lf-\kappa)_+^2\,\frac{dL}{L}\,dx
 \le D_0\kappa W.
 \tag{G5}
\]
This is the actual complementary-region energy, not a consequence of the component estimates.

Then
\[
 |U|\le |V|+\frac1\kappa\sum_j\frac{A_jW_j}{\theta_j},
 \qquad
 \mathcal E_\kappa(f;U)
 \le s\kappa\sum_jB_jW_j+D_0\kappa W.
 \tag{G6}
\]
Thus the final certificate constants are
\[
 A=\frac{\kappa|V|}{W}+\sum_j\frac{A_jp_j}{\theta_j},
 \qquad B=s\sum_jB_jp_j+D_0.
 \tag{G7}
\]
All fees refer to the same source, final cap, threshold and receiver measure.

### Proof

The source series converges in \(L^1\) and almost everywhere. Tonelli gives \(A_Lf=\sum_jA_Lf_j\); these averages are finite since \(A_Lf\le W/L^n\). At an admissible row in \(\mathcal D\) with \(x\notin U\), set \(I=\{j:(x,L)\in D_j\}\) and \(r_j=(A_Lf_j-\kappa\theta_j)_+\). The inactive bound gives
\[
 (A_Lf-\kappa)_+
 \le\left(\sum_{j\in I}A_Lf_j-s\kappa\right)_+
 \le\sum_{j\in I}r_j.
\]
For infinite \(I\), the last inequality follows by summing \(A_Lf_j\le r_j+\kappa\theta_j\) and using \(\sum_{j\in I}\theta_j\le s\). Weighted Cauchy on finite subsets, then monotone convergence, yields
\[
 (A_Lf-\kappa)_+^2
 \le s\sum_j{\bf1}_{D_j}
       \frac{(A_Lf_j-\kappa\theta_j)_+^2}{\theta_j}.
 \tag{G8}
\]
Integrate over \(\mathcal D\) and \(x\notin U\). Because \(U^c\subset U_j^c\), each integral is at most its component energy after the remaining nonnegative restrictions are removed. Tonelli and (G3) cancel the \(\theta_j\) factors. Adding the disjoint complementary-region energy (G5) proves the energy bound. Countable subadditivity of measure proves the volume bound.

Caps may overlap. The volume estimate may overcount that overlap, but remains an honest upper bound. Energy is computed outside the actual final union, and the active threshold sum is paid at each receiver/scale row. No source-energy additivity without this condition has been used.

## 2. Soft far-field payment

Keep the packing part of (G4), and replace its hard bound on \(F\) by
\[
 \int_{U^c}\int_0^\infty{\bf1}_{\mathcal D}
           (F-\eta\kappa)_+^2\,\frac{dL}{L}\,dx
 \le D_1\kappa W.
 \tag{G9}
\]
Then the same volume estimate holds, while
\[
 \mathcal E_\kappa(f;U)
 \le\left[\left(\sqrt{s\sum_jB_jp_j}+\sqrt{D_1}\right)^2
                        +D_0\right]\kappa W.
 \tag{G10}
\]
Indeed, the pointwise bound on the active region becomes
\[
 (A_Lf-\kappa)_+\le
       \sum_{j\in I}(A_Lf_j-\kappa\theta_j)_+
             +(F-\eta\kappa)_+.
\]
The first summand has squared \(L^2(dx\,dL/L)\) norm at most \(s\kappa\sum_jB_jW_j\) on the retained active region, by the proof of (G8). The \(L^2\) triangle inequality and (G9) give (G10); the complementary region is then added separately. If its right side is finite, both summands genuinely belong to that \(L^2\) space. If it is infinite, the bound is interpreted in the extended sense.

Thus a far field can be paid by a pointwise threshold reserve or by the displayed retained-receiver energy. Small individual source masses do not establish either condition.

## 3. Global mass cutoff and spatial overlap

Set
\[
 R=(W/\kappa)^{1/n},\qquad
 \mathcal D=\{(x,L):0<L<R\}.
 \tag{G11}
\]
For \(L\ge R\), \(A_Lf\le W/L^n\le\kappa\). Hence (G5) holds with \(D_0=0\), independently of the cap. This uses full side \(L\), not half side.

Suppose \(f_j\) vanishes almost everywhere outside a closed set \(S_j\), and use
\[
 D_j=\{(x,L):0<L<R,\
               \operatorname{dist}_\infty(x,S_j)\le L/2\}.
 \tag{G12}
\]
The distance function is continuous, so these masks are measurable. If a mask is inactive with \(L<R\), the averaging cube is disjoint from the source support and \(A_Lf_j=0\). Thus the inactive contribution is zero. Closures may enlarge these masks; no overlap bound follows from their existence.

Assume, for a positive integer \(q\), that the actual support intersection count satisfies
\[
 \#\{j:\operatorname{dist}_\infty(x,S_j)\le L/2\}\le q
 \quad\text{for almost every }(x,L),\quad 0<L<R.
 \tag{G13}
\]
If every component has a certificate at threshold \(\kappa/q\) with common bounds \(A_0,B_0\), choose \(V=\varnothing\), \(\eta=0\), and \(\theta_j=1/q\). Formula (G6) gives
\[
 |U|\le qA_0W/\kappa,\qquad
 \mathcal E_\kappa(f;U)\le B_0\kappa W.
 \tag{G14}
\]
The reduced component threshold cancels the overlap factor in energy, but the cap fee \(q\) remains. More generally, one may choose fixed positive \(\theta_j\) whose sum on every intersecting family is at most one, retaining exactly (G7).

In particular, if
\[
 \operatorname{dist}_\infty(S_i,S_j)\ge R
                   \quad(i\ne j),
 \tag{G15}
\]
then no cube of full side \(L<R\) meets two supports: two points of such a cube have \(\ell^\infty\) distance at most \(L\), contradicting (G15). Thus \(q=1\), and certificates at threshold \(\kappa\) glue with their summed cap and energy bounds. This is a countable all-scale separation theorem. Small scales see at most one source, and total mass eliminates the remaining scales. Its separation radius depends on total mass, not just on one component.

One may remove a bad receiver set \(V\) before requiring (G13); its actual measure is then paid in (G7). Replacing the radius in (G11) by component-dependent radii would require an additional proof controlling their cross-component far field.

## 4. Global threshold allocation

Without spatial localization, activate all components at every row and require \(\sum_j\theta_j\le1\). The following sufficient formula keeps the full cost of the decomposition.

Suppose, for every threshold \(\sigma>0\), each component admits a certificate with the same constants \(A_j>0,B_j\):
\[
 |U_{j,\sigma}|\le A_jW_j/\sigma,\qquad
 \mathcal E_\sigma(f_j;U_{j,\sigma})\le B_j\sigma W_j.
 \tag{G16}
\]
The constants must be uniform in \(\sigma\) before the allocation is chosen. If
\[
 S=\sum_j\sqrt{A_jW_j}<\infty,\qquad
 \theta_j=\frac{\sqrt{A_jW_j}}{S},
 \tag{G17}
\]
then the union at thresholds \(\sigma_j=\kappa\theta_j\) satisfies
\[
 |U|\le S^2/\kappa,\qquad
 \mathcal E_\kappa(f;U)\le\kappa\sum_jB_jW_j.
 \tag{G18}
\]
Apply (G6) with \(\eta=0\), \(V=\varnothing\), the whole active region, and every mask active. For common constants \(A_0,B_0\), the certificate is
\[
 A=A_0\left(\sum_j\sqrt{p_j}\right)^2,\qquad B=B_0.
 \tag{G19}
\]
This need not be finite merely because total mass is finite.

## 5. Infinite limits and the endpoint interface

The proof works directly with countably many components. It does not restart a local theorem for each partial sum, change undeclared caps, or interchange a nonlinear solution operator with a source sum. All exceptional sets are for the same product measure \(dx\,dL/L\); a countable union remains null. The final cap is the single measurable union \(V\cup\bigcup_jU_j\).

If components or local certificates are constructed by approximation, one must still establish the stated hypotheses for the actual chosen thresholds. A fixed-time \(L^1\) bound for an approximate PDE does not replace (G3), (G5), or (G9). For a weak maximal conclusion on arbitrary \(L^1\) sources, a separately proved uniform estimate on bounded compactly supported truncations can instead pass to the original cube maximal operator by monotone convergence. This does not claim a finite-energy obstacle for every \(L^1\) source.

For use with a cap-to-maximal return of the form
\[
 C_n\le4A+8\sqrt{\frac{nAB}{\log2}},
 \tag{G20}
\]
the relevant inputs are the actual uniform constants in (G7) or (G10). For example (G14) gives the displayed return
\[
 C_n\le4qA_0+
               8\sqrt{\frac{nqA_0B_0}{\log2}},
 \tag{G21}
\]
provided the local certificates and overlap bound hold uniformly for every source and threshold in the proposed application. That premise is not proved here. With hard far-field reserve \(s=1-\eta\), common active count \(q\), and \(\theta_j=s/q\), the exact constants are
\[
 A=\frac{\kappa|V|}{W}+\frac{qA_0}{s},
 \qquad B=sB_0+D_0.
 \tag{G22}
\]
An apparently small energy fee cannot erase the inverse-threshold cap cost.

Only positivity of cube averaging, countable integration, and \(L^2\) inequalities enter these proofs. Local caps may arise from genuine nonlinear obstacle arguments, but no sum of obstacle solutions is identified with a solution for the summed source. The existence and mass bound of an actual obstacle do not themselves supply the component exterior-energy constants \(B_j\) in (G3). A generally affordable localization must still pay simultaneously for the local certificates, cap, threshold packing, and cross-component far field. That step remains open.

状态：一般中心立方体弱常数 sqrt(n)n^{o(1)} 仍 OPEN。本稿提供可合法使用的条件工具与来源范围；没有证明实际删帽占用的尾部费用、实际来源树的子幂 packing，或阈值拼接的免费端点预算。积分使用真实接收测度，删掉的接收集合始终保留在系数中。

## 1. 本轮工具选择及来源状态

G01 用于分辨全部子树 Carleson 条件与根预算；G02 用于保留删除函数的外分布；E03 用于来源树的确切归一化与局部注入；N04 用于无限拼接的误差账本。边界调和函数/UR/corkscrew/CDC 路由的假设与本题不同，故不将其作为本题占用的来源。N04 的相关下降预算是自包含代数命题，邻接的矩阵可和性和有理差分论文不作为其证明。

本次直接读取下列一手原稿或期刊文本的指定 PDF 页。只登记实际读到的页与命题；没有以技能索引、路径 hash 或搜索摘要代替定理阅读，没有声称截图视觉复核。

|一手来源|实际读取位置|准确范围|
|---|---|---|
|[Do–Thiele, Lp theory for outer measures and two themes of Lennart Carleson united, v3](https://arxiv.org/pdf/1309.0945v3)|PDF pp.13–14 Definitions 2.4–2.5、pp.20–22 Theorem 4.1 及其弱端点证明|外分布由删除后的 size 定义；Thm4.1 在一维底空间的 tents、指定 smooth compact kernel 下给 strong 1<p<=∞，square size 需均值零。弱端点删除证明调用已知一维 HL 最大定理，不提供本题高维新弱界。|
|[Arcozzi–Holmes–Mozolyako–Volberg, Bellman function sitting on a tree, v2](https://arxiv.org/pdf/1809.03397v2)|PDF pp.2–4 定义及 Theorem 1.3，pp.6–9 Lemma 1.5 与 proof-by-formula|二进来源树上的非负节点质量 lambda_I、全部后代和 Lambda(I)、每个节点的 Carleson 条件。源常数4，势 B=4(F−f²/(v+A))；域 f²<=Fv、0<=A<=v 且分母正。节点质量注入导致 a²,b²,ab,c 增量，不能仅以普通 martingale 守恒替代。|
|[Fraccaroli, Duality for outer L^{p,infinity} spaces, NYJM 32 (2026), 321–348](https://nyjm.albany.edu/j/2026/32-14v.pdf)|PDF pp.2–6、pp.9–10 的 setting/size、pp.15–17 major-subset proof|sigma-finite setting 且 mu-null=>omega-null。当前期刊版 Thm1.2 对 arbitrary size 的 p>a 分支要求 p<∞ 与分割常数K；Thm1.3 的 p<=a 分支要求 p≠∞ 和标准 ell^r size。major subset 要求 mu(A\B)<=mu(A)/2，不能仅保留 mu(B)>=mu(A)/2。常数依赖 a,p,q,r（arbitrary size 另含K）。|

版本区别须保留：安装技能 G02 引用 2023 v1；2026 期刊版将 arbitrary-size theorem 编号为1.2，并在 Thm1.3(ii) 明列 p≠∞。本轮按实际读到的期刊版调用，未把旧技能的简写扩大为端点定理。

## 2. 外分布为何不能丢接收指标

在外测度 mu、生成集合族及 size S 给定后，outer distribution 的确切定义是

d_S(F;t)=inf{mu(D): ||F 1_{X\D}||_{L∞_mu(S)}<=t}。

其中 ||F1_R||_{L∞_mu(S)}=sup_E S(F1_R)(E)。必须重新截断函数后计算 size；原始 S(F)(E) 的数表通常不能恢复删除后的 size。普通点态集合 {F>t} 也通常不是这个外分布。

实际接收占用 H,J0 在 X_rec=Ω^c 上用 dx 测量。P(T)=∫_{Ω^c,H<=T}J0 dx 是 ordinary retained integral，不能在未给出 size、外覆盖族、mu 与其桥梁之前，把它改称 outer norm。若另行将实际 receiver×scale 几何外测度化，需要证明：

1. 生成集费用确实控制 dx 接收删除量；
2. size 对真实截断函数满足单调/齐次/准次可加与有限性；
3. 输入及实际 J0 或 H 被所选嵌入控制，且维数、尺度、阈值与几何常数全部支付。

Do–Thiele Thm4.1 不能直接补第三项：其 kernel/一维帐篷不同，弱端点证明本身借已有最大定理。Fraccaroli 的 norm characterization 也不产生未支付的 H 或 HJ0 分布费用。

## 3. 普通弱 L1 的 major-subset 合同（自证）

令 h>=0 为任意 Lebesgue 可测接收函数。定义

K(h)=sup_{t>0}t |{h>t}|，
M(h)=sup_{0<|A|<∞} inf_{B⊂A, |A\B|<=|A|/2} ∫_B h。

扩展值意义下有 K(h)/2<=M(h)<=2K(h)。若 K 有限且正，对任意 A，删 D=A∩{h>2K/|A|}，其体积<=|A|/2；余下 B 上 h<=2K/|A|，故 ∫Bh<=2K。K=0 情形 h=0 a.e.。反向取 A={h>t} 当其体积有限，任意合法 B 满足 ∫Bh>=t|A|/2；若 A 无穷，可先取有限可测子集使其体积任意大，得到同一扩展值结论。对 t 求上确界即得下界。

这个自证命题只是弱尾的等价写法，不提供 K(H) 的估计。即使 K(H) 已有限，也不能自动控制截断的全接收积分 P(T)，因为 weak L1 不能给 strong L1。故该合同不能代替实际联合前沿的支付。

## 4. 保留接收指标的已付费单树嵌入（自证）

### 准确条件

给有限 source measure (Y,mu)，有限 rooted laminar tree {E_v}：后代集合包含于祖先，不可比节点的集合两两不交（均可按 mu 零集修改）。允许子集合不覆盖父集合；未覆盖余量仍计入 mu。若两个不同节点代表相同正测度集合，只允许其作为同一祖先链上的带标签节点，不将它们当不交兄弟。

给 q∈L2(mu) 和非负可测实际接收行 a_v(x)。对某个固定可测保留接收集合 R，定义

alpha_v(R)=∫_R a_v(x)dx。

假设实际每个子树均满足

Σ_{u descendant of v, inclusive} alpha_u(R)<=C mu(E_v)。 (S4.1)

zero-mass 节点及后代的 alpha 均由此为0，可省去0/0平均。则

Σ_v alpha_v(R) |mu(E_v)^(-1)∫_{E_v}q dmu|²<=4C∫|q|²dmu。 (S4.2)

这适用于同一个 R 上的系数；不能以未删 receiver 的全矩代入后，再在输出处补上删除指标。R 改变时需重新核验或由非负性合法继承其 packing。C 是已付费输入，L2源范数也是已付费输入。

### 自包含证明

用 abs(q) 的平均 m_v，并在全部根集合上定义 Mq(y)=max_{v:y∈E_v}m_v，根外取0。对任意 t>0，节点集 {m_v>t} 的最大祖先节点构成互不交集合，其并集恰是 {Mq>t}。由每个最大节点的平均，

t mu({Mq>t})<=∫_{Mq>t}|q|dmu。

层析与 Tonelli 给

∫(Mq)²dmu<=2∫|q| Mq dmu<=2||q||2||Mq||2，

因此 ||Mq||2<=2||q||2。有限树保证此处 Mq∈L2：每个正质量平均有限且只有有限个集合。

另一方面，全部 high-average 节点被其最大祖先子树覆盖，由 (S4.1)，

Σ_{v:m_v>t}alpha_v(R)<=C mu({Mq>t})。

再用层析：Σalpha_v m_v²<=C||Mq||2²<=4C||q||2²，且 |avg q|<=avg|q|，得到 (S4.2)。该证明没有使用目标立方体弱界。

对 countable laminar tree，若每个平均有定义、所有子树界以同一个 C 成立，任意递增有限节点截断仍满足对应 subtree inequality。应用有限结论并以 monotone convergence 取极限，得到同一估计；不需要把无穷终端项直接置零。

### 对实际占用的迁移条件

要把此工具用于 H、J0、精确正超额占用或 cap-energy，至少须另外构造实际 E_v、mu、q、a_v，使删帽后真实目标有

actual_target(R)<=Σ_v alpha_v(R)|avg_{E_v}q|² + paid_remainder。

然后证明全部子树的 C、支付源 L2 范数或另给质量归一化，并支付非树化的远场、重叠、尺度门与余量。中心不同的全部立方体不是已知 laminar tree；来源依赖分配的受约束列也不自动成为这个树。根预算不足以认证 (S4.1)。本稿没有提出 C 为子幂的猜想。

## 5. 来源停止树的误差与节点注入

E03 的来源树把节点原子质量 lambda_v 加到后代和，故一般不是仅有 m(child)=m(parent)p 的无注入树。若采用普通 mass-conserving 预算势，必须先定义其实际模型。

给有限概率树，m(child)=m(v)p(child|v)，孩子概率总和1（终止余量可作额外 leaf），并对内部节点给非负 cost c_v、potential Phi_v、误差 epsilon_v，使

Phi_v>=c_v+Σ_child p(child|v)Phi_child−epsilon_v。

乘 m(v) 后有限求和，得到准确恒等式方向

Σ_internal m(v)c_v <= m(root)Phi_root−Σ_leaves m(v)Phi_v+Σ_internal m(v)epsilon_v。

若 terminal Phi>=0，可丢终端的非正项。无限树或分层拼接要保留有限层恒等式，至少给误差加权部分和的统一上界，并控制终端势符号/极限。源注入、门重启与重叠不是误差“自动可和”；需写入真实 cost 或额外质量项。

N04 的序列版本：若 H_{k+1}<=H_k−d_k+epsilon_k，d_k>=0，H_k>=L，且 S=sup_m Σ_{k=0}^m epsilon_k<∞，则 Σd_k<=H0−L+S。证明只是有限望远镜后单调极限。有符号误差的统一上方部分和界足够；“逐步存在下降”或未支付误差并不够。没有指定实际势 H_k 及初始量的大小，不能从该代数结论获得子幂预算。

## 6. 真正局部能量的 cap-certificate 最大值拼接（自证）

准确工具：给 u_j>=0 属于 H1(R^n)，假设 Σ_j(||u_j||2²+E(u_j))<∞，其中 E(u)=1/2∫||∇u||1²。则 U=sup_j u_j∈H1 且

||U||2²<=Σ||u_j||2²， E(U)<=ΣE(u_j)， {U>0}=∪_j{u_j>0} a.e.。

若另有 Σ||u_j||1<∞，则 U∈L1。这个量词只拼接给定的实际 certificates，不声明 U 是和源对应的障碍 minimizer，也不分解其通量，不给现有 certificates 的能量免费估计。

证明：Sobolev max/min 梯度局部性给

E(u∨v)+E(u∧v)=E(u)+E(v)。

有限最大值 U_m=max_{j<=m}u_j 因此满足 E(U_m)<=Σ_{j<=m}E(u_j)，以及 U_m²<=Σ_j u_j²。U_m 单调趋于 U，后者的平方可积；dominated convergence 给强 L2 极限。梯度能量的一致界（F>=|p|2²/2）给弱 H1 子列，强 L2 识别其极限为 U。凸能量弱下半连续给 E(U)<=ΣE(u_j)。countable 支持等式在取所有代表的共同满测集后成立；L1 附加结论由 U<=Σu_j 和 Tonelli 给出。

还有不要求 Σ||u_j||2² 的 relative 版本：D 为有限体积 bounded open set，u_j∈H0^1(D)、0<=u_j<=1、ΣE(u_j)<∞。则 U∈H0^1(D)、0<=U<=1、E(U)<=ΣE(u_j)。有限最大值仍在 H0^1；其 L2 一致界来自 |D|，单调 dominated limit 与弱 H1 closedness 保留零边界条件。域无需光滑。

据此定义仅含 a.e. 集合约束的 relative variational certificate cost

cap_F^D(A)=inf{E(u): u∈H0^1(D), 0<=u<=1, u=1 a.e. 于 A}。

对 measurable A_j⊂D 有 cap_F^D(∪A_j)<=Σ cap_F^D(A_j)。若右侧有限，每个 j 取带 epsilon 2^-j 余量的竞争函数，应用 relative 最大值结论，最后 epsilon↓0；若右侧无穷则不产生有限证书。**不把此 a.e. 约束成本冒称已经建立的准连续/q.e. Sobolev capacity 理论。**

这一工具可以相加 paid certificate energies 和 union admissibility，但它与实际 cube-average 正超额 occupation、receiver/scale masks 之间的桥梁仍需另证。阈值 source gluing 属于 nonlinear 模块的不同工具；max potential 不推出其 interaction 变小。全空间若只有 ΣE(u_j)<∞ 而缺任何 L2 紧性合同，本稿不声称 U∈H1。

## 7. 对 R101 的可用结论与仍缺条件

已核来源允许保留 receiver deletion 来定义外分布，或在真正 laminar source tree、每个 subtree 已支付后使用4C嵌入；这两项都保留了实际截断。N04 允许在清楚的质量流和误差上界下传递有限预算。局部凸能量最大值可拼接给定 cap certificates 的付费能量与并集约束；不构造和源的障碍。

本轮未找到经原文核验的一般定理，可从实际晶体障碍的质量/有限帽体积直接推出精确超额占用尾部、联合 H,J0 前沿，或 locality gluing 的小 interaction 参数。阈值余量、行质量、共享来源列、远场和无限尺度都仍须由题内论证提供。一般目标 OPEN；这些工具不能作为免费 endpoint closure。

## 1. Actual input and retained receiver fields

The general centered-cube root-order target remains OPEN. Let n>=2, f>=0 belong to L1 intersect L2, W=integral f>0, and kappa>0. The actual R100 obstacle at height kappa/2 supplies a measurable cap Omega with |Omega|<=2W/kappa and f<=kappa/2 almost everywhere on its complement. All fields below use this SAME source and cap. The zero source is trivial. An arbitrary-L1 conclusion still requires a uniform regular-input estimate before monotone truncation of the original maximal operator.

Use the full-side cube average and actual exterior positive-excess energy

$$
A_Lf(x)=L^{-n}\int_{x+[-L/2,L/2]^n}f(y)\,dy,\qquad
E_\kappa(f;U)=\int_{U^c}\int_0^\infty(A_Lf(x)-\kappa)_+^2\,\frac{dL}{L}\,dx. \tag{1}
$$

Recall beta=1+1/(2n), c_beta=n/(1-beta^(-n)). With mu=f1_Omega the R100 fields are

$$
N_0=A_L\mu\,\mathbf1_{\{A_Lf>\kappa\}},\quad
N_1=A_L\mu\,\mathbf1_{\{A_Lf>\kappa\beta^{-n}\}},\quad
J_0(x)=\int_0^\infty N_0\,\frac{dL}{L},\quad
H(x)=\int_0^\infty N_1\,\frac{dL}{L}. \tag{2}
$$

They are measurable extended nonnegative fields. The present round retains the actual deletion indicator. It does not replace the retained moment by the previously unpaid whole moments. Outside Omega these fields are finite at almost every receiver: differentiation gives A_Lf(x)->f(x)<=kappa/2, below both strict thresholds, at small L; total mass kills both thresholds above a finite scale; the averages are bounded on the remaining compact scale interval. Their spatial integrals can nevertheless be infinite.

## 2. Exact single-height feasibility

Fix a>=0. For T>=0 define

$$
V_H(T)=|\Omega^c\cap\{H>T\}|,\qquad
P_H(T)=\int_{\Omega^c\cap\{H\le T\}}J_0(x)\,dx,\qquad
\tau_{H,a}=\inf\{T\ge0:V_H(T)\le aW/\kappa\}. \tag{3}
$$

The infimum of the empty set is infinity. A finite tau belongs to the admissible set. Indeed the set is upward closed; choose admissible T_j decreasing to tau. The sets {H>T_j} increase to {H>tau}, so continuity from below of measure preserves the budget. For positive T the product T P_H(T) is increasing, including extended infinite values. Therefore the smallest R100 certificate within this strict height-cap class occurs at its finite positive volume quantile:

$$
U_H=\Omega\cup\{x\in\Omega^c:H(x)>\tau_{H,a}\},\quad
|U_H|\le(2+a)W/\kappa,\quad
E_\kappa(f;U_H)\le c_\beta\tau_{H,a}P_H(\tau_{H,a}). \tag{4}
$$

If tau=0, do not multiply zero by infinity. Actual persistence N0<=c_beta H implies N0=0 for almost every scale on {H=0}; the retained positive excess is zero. If tau=infinity there is no admissible finite-height cap at this budget. This says nothing against other caps. Possible positive-measure level sets are retained entirely by the strict rule; allowing partial deletion of ties is a different admissible class and is not silently included.

## 3. Exact positive-excess occupation

Define actual receiver fields, without a relaxed threshold,

$$
D_L(x)=(A_Lf(x)-\kappa)_+,\quad
J(x)=\int_0^\infty D_L(x)\,\frac{dL}{L},\quad
J_{\ge L}(x)=\int_L^\infty D_s(x)\,\frac{ds}{s},\quad
K(x)=\int_0^\infty D_L(x)^2\,\frac{dL}{L}. \tag{5}
$$

On Omega complement the contact bound gives D_L<=N0, so J<=J0<=H. In particular J is finite almost everywhere there, while its full spatial integral need not be finite. The following scalar argument itself holds at any receiver for a nonnegative L1 input, regardless of the obstacle.

Put G(t)=t-log(1+t) for t>=0, and let psi be its increasing inverse from [0,infinity) onto [0,infinity). If A_Lf(x)=kappa(1+t), t>0, cube nesting yields A_sf(x)>=(L/s)^n A_Lf(x). Integrating this lower bound until s=L(1+t)^(1/n) gives the precise future occupation:

$$
J_{\ge L}(x)\ge\int_L^{L(1+t)^{1/n}}
\kappa\bigl((1+t)(L/s)^n-1\bigr)\,\frac{ds}{s}
=\frac{\kappa}{n}G(t). \tag{6}
$$

Consequently D_L(x)<=kappa psi(n J_{>=L}(x)/kappa). This future-tail bound is stronger than replacing the future tail by all of J at once. Define

$$
\Phi(q)=\int_0^q\psi(v)\,dv
=\frac{\psi(q)^2}{2}-\psi(q)+\log(1+\psi(q)),\qquad q\ge0. \tag{7}
$$

The equality follows by setting v=G(t), dv=t/(1+t)dt. If J(x)<infinity, put r=log L and F(r)=J_{>=exp(r)}(x). It is absolutely continuous on bounded intervals with F'=-D_exp(r) almost everywhere, and F(-infinity)=J, F(infinity)=0. On a finite r interval the chain rule gives the integral of psi(nF/kappa)(-F'); passing to the two endpoints by monotone convergence yields

$$
K(x)\le\int_{-\infty}^{\infty}\kappa\psi(nF(r)/\kappa)(-F'(r))\,dr
=\frac{\kappa^2}{n}\Phi\!\left(\frac{nJ(x)}{\kappa}\right). \tag{8}
$$

This argument uses actual scale averages, not an independent scale model. J=0 gives K=0 directly. If J=infinity, the bound is an extended infinite upper bound and pays nothing.

An explicit coefficient avoids numerical inversion. Since G'(t)=t/(1+t), integration or differentiation proves G(t)>=t^2/[2(1+t)]. Solving this quadratic inequality and using sqrt(q^2+2q)<=q+sqrt(2q) gives

$$
\psi(q)\le q+\sqrt{q^2+2q}\le2q+\sqrt{2q},\qquad
\frac{\Phi(q)}q\le q+\frac23\sqrt{2q}\quad(q>0). \tag{9}
$$

The ratio Phi(q)/q is increasing because psi is increasing. The coefficient tends to zero as q decreases to zero. This is a refinement of the scale certificate; no volume bound follows from (8) alone.

## 4. Paid cap and the actual missing joint budget

For T>0 set q=nT/kappa and define

$$
V_J(T)=|\Omega^c\cap\{J>T\}|,\quad
R_J(T)=\int_{\Omega^c\cap\{J\le T\}}J(x)\,dx,\quad
U_{J,T}=\Omega\cup\{x\in\Omega^c:J(x)>T\}. \tag{10}
$$

Integrating (8) on the SAME retained receiver set, then using monotonicity of Phi(q)/q, gives

$$
|U_{J,T}|\le2W/\kappa+V_J(T),\qquad
E_\kappa(f;U_{J,T})\le\frac{\kappa^2}{n}\int_{\Omega^c\cap\{J\le T\}}
\Phi(nJ/\kappa)\,dx
\le\kappa\frac{\Phi(q)}qR_J(T). \tag{11}
$$

All integrals keep their actual deletion indicator. At T=0 the retained energy is zero directly; at infinite retained integral the positive-T formula is only an infinite bound. At budget V_J<=aW/kappa, the finite volume quantile tau_J,a is feasible by exactly the measure argument of section 2. It minimizes not only the increasing bound [Phi(nT/kappa)/(nT/kappa)]R_J(T), but also the middle integral in (11) and the actual retained energy, within the strict J-height-cap class. This does not optimize over arbitrary shapes or partial ties.

A uniform weak bound requires uniform coefficients, not merely a finite certificate for one input. Suppose dimension-only finite constants a_n and B_n work for every regular nonnegative f and every kappa>0: for each such pair there is some T>0 with V_J(T)<=a_n W/kappa and the first inequality below. Only under this unproved uniform hypothesis does the existing all-scale return give

$$
\frac{\Phi(nT/\kappa)}{nT/\kappa}\frac{R_J(T)}W\le B_n,\qquad
C_n\le4(2+a_n)+8\sqrt{\frac{n(2+a_n)B_n}{\log2}}. \tag{12}
$$

The unproved task is to pay the actual volume and retained occupation jointly, or the sharper middle integral in (11), with subpower coefficients for every input. No uniform estimate for those quantities is asserted here.

There is a precise circularity check on an overly small threshold. Taking a scale witnessing a strict maximal superlevel in (6) proves

$$
\{x\in\Omega^c:Mf(x)>\kappa[1+\psi(nT/\kappa)]\}
\subseteq\{x\in\Omega^c:J(x)>T\}. \tag{13}
$$

Thus a uniform subpower volume budget at T comparable to kappa/n would already give a subpower weak maximal bound at a fixed threshold factor, after paying Omega. It is a deliberately strong finite diagnostic, not a free general lemma or a necessary target. Larger T paired with genuinely smaller retained occupation remains allowed. The source-and-scale geometry that could pay this tradeoff is still missing.

## 5. Optimizing the surrogate over all paid receiver sets

The strict-threshold restriction is unnecessary for the monotone surrogate if measurable ties are paid correctly. Put X=Omega complement, fix b=aW/kappa>0, and define

$$
S(x)=\frac{\kappa^2}{n}\Phi(nJ(x)/\kappa),\qquad
\mathcal B(b)=\inf_{D\subseteq X\text{ measurable},\ |D|\le b}\int_{X\setminus D}S(x)\,dx. \tag{14}
$$

Here J is finite almost everywhere on X by section 1. Assume first that some admissible D0 has finite retained surrogate C. For each t>0, S is at least s_t=(kappa^2/n)Phi(nt/kappa)>0 on {J>t}; consequently V_J(t)<=b+C/s_t<infinity. These finite tails decrease to zero as t increases to infinity because J is finite almost everywhere. Hence the positive-budget volume quantile tau is finite. If tau=0, deleting {J>0} costs at most b and leaves zero surrogate.

If tau>0, right continuity supplies |{J>tau}|<=b. For thresholds increasing to tau from below, the level sets decrease to {J>=tau}; their measure is finite from any positive threshold onwards. Since every threshold below tau is inadmissible, |{J>=tau}|>=b. Choose a measurable subset B_tau of {J=tau} of measure b-|{J>tau}|. Such a subset exists by nonatomicity of Lebesgue measure; the level set here has finite measure. Then

$$
D_* =\{x\in X:J(x)>\tau\}\cup B_\tau,\qquad
|D_*|=b,\qquad
\int_{X\setminus D_*}S=\mathcal B(b). \tag{15}
$$

To prove the last assertion without subtracting infinite totals, compare any competitor D with |D|<=b. On D\D_* the score is at most s_tau; on D_*\D it is at least s_tau. Both difference sets have finite measure and |D\D_*|<=|D_*\D|. Thus the first difference-set integral is no greater than the second. The common retained part is nonnegative and can be added to both sides in the extended sense. Taking D=D0 first also proves the retained integral for D_* is finite. Competitors with infinite retained cost are then harmless.

If every admissible deletion has infinite retained surrogate, (14) is infinity and there is no paid conclusion. If b=0, the empty deletion is the only choice up to null sets, independently of any infinite quantile. This theorem optimizes S, not the actual point energy K, and makes no claim that all actual-energy-optimal caps are height caps. It gives a precise remaining sufficient budget: show that this actual-source optimum is subpower times kappa W at a subpower volume fee.

For certified finite receiver partitions one can enclose the surrogate without computing the inverse function. The elementary inequalities G(t)<=t and G(t)<=t^2/2 imply psi(q)>=max(q,sqrt(2q)); integrating each bound gives

$$
\max\left\{\frac{q^2}{2},\frac{2\sqrt2}{3}q^{3/2}\right\}
\le\Phi(q)\le q^2+\frac{2\sqrt2}{3}q^{3/2}. \tag{16}
$$

The scalar relaxation has a uniform constant cost. Write L(q)=max(q^2/2,c q^(3/2)), U(q)=q^2+c q^(3/2), where c=2sqrt(2)/3. If a=q^2 and b=cq^(3/2), then a+b<=3max(a/2,b), so Phi<=U<=3Phi. Therefore the explicit physical surrogate

$$
S_{\rm pow}(x)=nJ(x)^2+\frac{2\sqrt2}{3}\sqrt{n\kappa}\,J(x)^{3/2}
\quad\text{satisfies}\quad S(x)\le S_{\rm pow}(x)\le3S(x). \tag{17}
$$

The same inequalities hold for the optimal retained integrals over any fixed cap-volume budget, including extended infinite values. Both scores increase strictly with J, so their quantile-and-tie ordering agrees. This identifies the remaining budget, up to a constant factor, as the actual retained mixed second and three-halves moments of J. It does not bound either moment, and does not remove uncertainty from finite receiver enclosures.

Cellwise lower scores produce a lower bound on (14) after optimizing deletion of exact cell volumes; cellwise upper scores produce a realized measurable cell-union and partial-cell cap with an upper bound. A partial cell is allowed only with its actual Lebesgue volume charged, never by discarding an uncertain cell for free. Such finite certificates do not establish a general dimension law. A numerical strict-height frontier remains distinct from the tie-optimized or arbitrary-cell frontier unless that additional optimization was actually performed.

## 6. Final review and evidence status

The original independent Astra and Sol reviews cover all equations (1)--(17), the complete proofs and stated limitations; final delta acknowledgements are separately recorded. The complete continuum numerical producer and isolated replays have finished. The recovered numerical report and final verification section state their actual scope and execution provenance. Finite certificates do not prove the general joint budget. This paragraph updates only the interrupted metadata checkpoint; no mathematical assertion above is changed.

## 1. Exact graph and current status

This round proves a source- and receiver-dependent balancing update on the actual original graph, with an exact finite energy budget and a finite-entropy comparator guarantee. It does not prove a root-capacity conclusion. The current input is the original nonnegative finite L1 source `mu=f dy`, threshold `lambda>0`, and an actual measurable receiver set `B` in the retained original F2 event. The original earliest cube `Q_x=Q(x,L_x)`, `1<=L_x<=2`, satisfies `mu(Q_x)=lambda L_x^n`. All original anchor, full P1 window, middle, selected-coarse, packet and physical gates remain, as do the paid unit and mesh deletions. No source restriction or gate restart is made here.

Write `H_n=1+n log 2`,
\[
 k_x(y)=L_x^{-n}1_{Q_x}(y),\quad
 b_B(y)=\int_B k_x(y)\,dx,\quad
 d\pi_x(y)=k_x(y)d\mu(y)/\lambda.
\]
The original radial hard envelope gives `0<=b_B<=H_n`. Every receiver has probability law `pi_x` on its actual capture. This is a joint law defined by the actual source and Lebesgue receiver measure; no product-posterior assumption is made.

## 2. A genuine source- and receiver-dependent allocation

For `s>0`, define
\[
 R_B(x)=\int b_B(y)d\pi_x(y),\quad
 Z_x=\int\frac{d\pi_x(y)}{b_B(y)+s},\qquad
 a_x(y)=\frac{k_x(y)}{(b_B(y)+s)Z_x}.
\]
Then `a_x` has row mass `lambda` against the SAME `mu`, with support in the original cube. On `E_C={x in B:R_B(x)<=C}`, Jensen gives `Z_x^{-1}<=R_B(x)+s<=C+s`, so
\[
 \int_{E_C}a_x(y)dx
 \le(C+s)\frac{b_B(y)}{b_B(y)+s}\le C+s.
\]
The same bound holds for every measurable receiver subcut. Thus this is a legal common physical allocation on `E_C`, with fee `(C+s)mu(N_A)` for each subcut `A`, where `N_A` is its essential original source neighborhood. The burden `b_B` is always computed on the same full `B`; it is not silently recomputed during this argument.

## 3. Exact unpaid quantity

Tonelli gives
\[
 \lambda\int_B R_B(x)dx=\int b_B(y)^2d\mu(y).
\]
For `C>0`, the trivial deletion estimate is
\[
 \lambda|B\setminus E_C|\le C^{-1}\int b_B^2d\mu
 \le(H_n/C)\lambda|B|.
\]
This does not pay the complement at root order. A new original-joint-gate estimate, a legal paid redistribution of the complement, or a precisely qualified failure is still required. Small `R_B` is a sufficient certificate for this particular allocation, not a necessary condition for optimal Hall capacity. The R100 annulus has actual `b_B<1` on its entire contact event and therefore cannot pressure the missing high-load regime.

## 4. Variance-controlled common-column balancing

The next lemma uses the original graph itself rather than a scale envelope. Zero source or zero receiver demand has no residual allocation to pay. Otherwise fix `0<D=lambda|B|<infinity`, `0<W=mu(R^n)<infinity`, and ANY measurable allocation `a_x(y)>=0` satisfying
\[
 \int a_x\,d\mu=\lambda\quad\hbox{for a.e. }x\in B,
 \qquad a_x(y)=0\text{ outside }Q_x,
 \qquad b(y)=\int_B a_x(y)dx\le H.                                \tag{1}
\]
The algebraic lemma uses only (1), so it is valid for any measurable capture graph with these properties; the application in this public route is the fixed original graph above. In particular the side range is used to obtain the initial canonical ceiling, not to justify the update. Here `H>0` is a proved common-column ceiling. The canonical original allocation supplies `H=H_n`. The same construction also works with a better certified ceiling; no pointwise bound on `a` is assumed. Define the ACTUAL joint measure `a_x(y)dx dmu(y)` of total mass `D` and its conditional source laws `pi_x=a_x mu/lambda`. Put
\[
 R(x)=\mathbb E_{\pi_x}b,\qquad
 V=\lambda\int_B\operatorname{Var}_{\pi_x}(b)dx,
 \qquad E=\int b^2d\mu.                                         \tag{2}
\]
All are finite because `b<=H`. For `0<eta<=1/H`, define
\[
 a_x^+(y)=a_x(y)[1+\eta(R(x)-b(y))].                              \tag{3}
\]
This is nonnegative, supported on the SAME original capture graph, and its row mass is exactly `lambda`. Indeed the bracket lies in `[1-eta H,1+eta H]`, and the row integral of its added part is zero. This is not an input restriction, a new selector or a probabilistic independence assertion.

Write
\[
 d(y)=\int_Ba_x(y)R(x)dx-b(y)^2,
 \qquad b^+=b+\eta d.                                           \tag{4}
\]
Since `0<=R<=H`,
\[
 0\le b^+\le b+\eta b(H-b)\le H.                               \tag{5}
\]
The last inequality follows from `H-[b+eta b(H-b)]=(H-b)(1-eta b)>=0`. Thus the same ceiling can be used at every iteration.

Tonelli and the row normalization give
\[
 \int b\,d\,d\mu
 =\lambda\int_B R^2dx-\int b^3d\mu=-V.                          \tag{6}
\]
For `b(y)>0`, columnwise Cauchy–Schwarz yields
\[
 d(y)^2
 \le b(y)\int_B a_x(y)[R(x)-b(y)]^2dx.
\]
At `b=0` both sides vanish. Integrating and using `b<=H` gives `int d^2 dmu<=H V`. Consequently
\[
 E^+\le E-\eta(2-\eta H)V.                                    \tag{7}
\]
This is an unconditional descent on the actual graph. It is strict whenever `V>0`, with no uncharged remainder.

Iterate (3) on the SAME `B,mu,lambda,Q_x`, using a fixed admissible `eta`. There is no repeated classification or threshold change. For every finite `m`,
\[
 \eta(2-\eta H)\sum_{j=0}^{m-1}V_j
 \le E_0-E_m,\qquad
 E_m\ge D^2/W.                                                 \tag{8}
\]
The lower terminal bound is Cauchy–Schwarz applied to `int b_m dmu=D`. In particular at `eta=1/H`,
\[
 \sum_{j=0}^{m-1}V_j\le H(E_0-E_m)
 \le H^2D-HD^2/W.                                              \tag{9}
\]
The infinite nonnegative sum is finite, so `V_j->0`; no compactness, limit-plan existence, or optimality is inferred. For the initial canonical graph, `D<=H_n W` and `E_0<=H_n D<=H_n^2 W`. Thus this is a finite source-priced potential, but its available dimension cost is still linear/quadratic, not the desired root fee. The nonzero lower terminal must not be discarded as if it vanished.

## 5. A finite comparator theorem, with its actual entropy price

A legal comparison allocation `a^*` has the same row mass and graph support. Assume its column `b^*` has finite energy `E^*=int(b^*)^2dmu`, and that
\[
 K_0=\int_B\int a_x^*(y)\log\frac{a_x^*(y)}{a_{0,x}(y)}
                         d\mu(y)dx<\infty.                     \tag{10}
\]
Use the usual zero-density convention. This is relative entropy of TWO actual positive joint measures with equal total mass `D`, so it is nonnegative. Finite `K_0` includes absolute continuity with respect to the initial plan. No comparison allocation or finite `K_0` is supplied by a gate or by an external duality theorem.

For `0<eta<=1/(2H)`, every finite iterate has
\[
 (1-\eta H)^j a_0\le a_j\le(1+\eta H)^j a_0.                    \tag{11}
\]
Hence `K_j=int a^* log(a^*/a_j)` is finite and nonnegative. The elementary bound `log(1+u)>=u-u^2` for `|u|<=1/2` gives
\[
 K_{j+1}-K_j
 \le-\eta\left(E_j-\int b_jb^*d\mu\right)
            +\eta^2H^2D.                                      \tag{12}
\]
To check the first term, integrate `R_j(x)` against the comparator row: it gives `lambda int R_j dx=E_j`; the other term is `int b_j b^*dmu`. The quadratic remainder uses only `|R_j-b_j|<=H` and the comparator's total mass `D`.

Since
\[
 E_j-\int b_jb^*d\mu
 =\tfrac12(E_j-E^*)+\tfrac12\int(b_j-b^*)^2d\mu,
\]
finite summation, `K_m>=0`, and monotonicity of `E_j` imply, for `m>=1`,
\[
 E_m\le E^*+\frac{2K_0}{\eta m}+2\eta H^2D.                     \tag{13}
\]
This supplies an explicit finite iteration guarantee relative to a GIVEN legal comparator. It does not assert attainment of an optimal allocation or an entropy bound for such an optimizer. Choosing smaller `eta` and more iterations requires exactly the displayed budget. It does not produce a root comparator from the original F2 gates.

## 6. What the joint gates do and do not control here

For the original-posterior comparisons in this section, initialize `a_{0,x}=k_x=L_x^-n 1_Qx`; the general update and comparator lemmas above allow other feasible initial plans. The original source and earliest graph remain fixed throughout. Therefore every geometric and original-input gate remains true as a statement about the original `f,lambda,L_x`. Their *posterior expressions*, however, refer to the original canonical `pi_{0,x}`, not automatically to the updated row laws. For any nonnegative score `F`, (11) supplies only
\[
 (1-\eta H)^j\mathbb E_{\pi_{0,x}}F
 \le\mathbb E_{\pi_{j,x}}F
 \le(1+\eta H)^j\mathbb E_{\pi_{0,x}}F.                          \tag{14}
\]
For bounded scores `F` (or scores with finite current expectation), there is also an exact one-step score identity:
\[
 \mathbb E_{\pi_{j+1,x}}F-\mathbb E_{\pi_{j,x}}F
 =-\eta\operatorname{Cov}_{\pi_{j,x}}(b_j,F).                    \tag{14a}
\]
This follows by inserting (3), using `R_j=E_pi b_j`. It applies to the original same-selector scores `Phi_1((x-y)/L_x)` and `Phi_theta((x-y)/L_x)` without any distributional assumption. Preserving a lower-middle score would be helped by nonpositive covariance, while preserving an upper-coarse score would be helped by nonnegative covariance. Neither sign is proved by the original gates.

To state an actual information budget, normalize the common joint measure by `D`: `dP_j=a_{j,x}(y)dx dmu(y)/D`. The same reference `dx dmu` is used at every stage. Then
\[
 \chi^2(P_{j+1}\Vert P_j)=\frac{\eta^2V_j}{D},\qquad
 \sum_{j<m}\chi^2(P_{j+1}\Vert P_j)
 \le\frac{\eta(E_0-E_m)}{D(2-\eta H)}.                           \tag{14b}
\]
The first formula is the integral of the squared multiplier minus one, with the usual zero-density convention; update (3) cannot create mass where the old plan is zero. Equation (8) proves the second. This summability is not an endpoint information bound. Defining total variation as half L1, its elementary finite-horizon consequence is only
\[
 \|P_m-P_0\|_{\rm TV}
 \le\frac12\sqrt{\frac{m\eta(E_0-E_m)}{D(2-\eta H)}}.             \tag{14c}
\]
Indeed each step has TV at most half its chi-square square root; use the triangle inequality and Cauchy–Schwarz over the `m` steps. The bound may exceed one and does not give uniform rowwise gate preservation. Finite increment energy must not be treated as a free posterior-transfer theorem.

The full step `eta=1/H` has no positive uniform lower factor. Thus original lower-middle and upper-coarse posterior moments cannot both be transported for free through a long optimization. No independence appears at any stage.

Small `V_j` means small within-row variance UNDER THE CURRENT row laws. It does not by itself bound the common level of `b_j`, establish a KKT condition on every original edge, or prove an optimal Hall bound. Even though damped finite steps preserve the original essential support, a limiting plan may lose edges. No limiting plan or originally qualified high-flat-load counterexample is asserted here.

For any chosen finite iteration, the reciprocal construction of §2 can be applied with its current `a_j,b_j,pi_j`. On `R_j<=C` it gives a single shared allocation of column at most `C+s`. The unpaid demand obeys only
\[
 \lambda|\{x\in B:R_j(x)>C\}|\le E_j/C.                         \tag{15}
\]
This exact remainder and (13) identify the missing geometric input. Substituting the general `E_j<=H_nD` yields the old demand-dependent cost, not a root source budget. A single fixed iteration can be used for the whole selected set and all its subcuts; using different iterations for different receiver pieces would require paying the sum of their columns, which is NOT free.

## 6A. A precise next geometric bottleneck, not an established hypothesis

One genuinely stronger-than-comparator input that would complete the all-cut estimate is the following **unproved sufficient dissipation hypothesis**. Fix a dimension-dependent target `0<C_n<H_n` of root order, uniformly over the original sources, thresholds and receiver cuts. For EACH finite actual original F2 cut `B`, initialize canonically and use `eta=1/(2H_n)`. Require a number `gamma=gamma(f,lambda,B)` with `0<gamma<=H_n`, independent of the iteration index, such that EVERY reachable iterate satisfies
\[
 V_j\ge\gamma(E_j-C_nD)_+.                                     \tag{15a}
\]
A uniform lower choice `gamma_n` depending only on dimension would additionally give a uniform iteration rate. It is stronger than required for the eventual all-cut implication; an input/cut-dependent positive `gamma` already suffices. Neither version is claimed necessary, nor is either proved by the original gates. The point is an actual dissipation statement about the reachable source allocation, rather than assuming a good optimizer exists.

To verify the exact conditional return, (7) at this step size gives
\[
 (E_m-C_nD)_+
 \le\left(1-\frac{3\gamma}{4H_n}\right)^m(E_0-C_nD)_+.            \tag{15b}
\]
If an energy is already below the target, monotonicity keeps it below; otherwise subtract (15a). Every finite column remains supported in the original essential neighborhood `N_B`. Thus, for `D>0`, its mass there is `D`, `mu(N_B)>0`, and `E_m>=D^2/mu(N_B)`. Taking the scalar bound (15b) to the limit gives
\[
 D\le C_n\mu(N_B).                                             \tag{15c}
\]
No limiting allocation, source restriction, new selector, gate restart, or entropy comparison is used in this implication. Finite cuts suffice, with increasing-cut limits if a larger receiver set is considered. All outer fees below remain.

There is presently no geometric proof of (15a): the original gates constrain the initial captured law, whereas later positive allocations can become arbitrarily small on original edges. Variance under such a law can miss alternative source directions. Summability (8), source preservation, or mere existence of a lower-energy comparison does not supply a positive dissipation constant. No adversarially qualified original-F2 example establishing or refuting this hypothesis is claimed. It is a precise next falsifiable input, not a claim of plausible closure and not another numerical menu this round.

## 7. Full original ledger, all cuts and terminal

For every measurable `A subset B`, the essential original neighborhood is
`N_A={y:int_A 1_Qx(y)dx>0}`. Every finite plan constructed above is supported there on that cut and has row mass `lambda`. A genuine common column ceiling `C_*` gives `lambda|A|<=C_*mu(N_A)` by Tonelli. A plan constructed for one fixed `B` works for all its subcuts; independently constructing different plans for different `B` is not the assertion of one global plan without a separate existence theorem.

Retain the frozen payments
\[
\begin{gathered}
 H_n=1+n\log2,\quad C_{\rm ext}=2H_n/\sqrt{n+2},\\
 B_{\rm base}=4+2(\log2)\sqrt{7n/3},\quad
 \theta=\log^{-2}(n+2),\quad\alpha=[10\log(n+2)]^{-1},\\
 T_{\rm soft}=1+(\log2)\min\{2n,\sqrt{n(\theta^{-1}+4\theta/3)}\},\\
 a_{\rm pkt}=n^{-p_0},\quad\rho_0=n^{-1/2},\quad
 P_{\rm dom}=(5+3\log(1/a_{\rm pkt}))/\rho_0,\\
 h_*=(16n^{3/2})^{-1},\quad E_*=e^{nh_*},\quad
 B_*=1+E_*[1+(2n^2+n)h_*],\\
 P_{\rm phys}=2[E_*+B_*+2(1+E_*)\sqrt n],\\
 A_{\rm old}=B_{\rm base}+C_{\rm ext}+T_{\rm soft}/\alpha
                         +P_{\rm dom}+P_{\rm phys}.
\end{gathered}
\]
Here `a_pkt=n^-p0` is the packet parameter, not the initial allocation `a_{0,x}` used above. The physical union is paid once. The additional captured-low deletion adds another `C_ext`, and the unit/mesh branches add `T+2N`, `T=sqrt n`, `N=ceil sqrt n`:
\[
 \lambda|E_{\rm initial}|
 \le(A_{\rm old}+C_{\rm ext}+T+2N)W+\lambda|F_2|.                 \tag{16}
\]
The present balancing algorithm changes NO input or threshold, and so incurs no repeated classification fee. It also supplies no replacement for the full remaining term: canonical `H_nW` and R99 outer `2n log2 W` remain valid fallbacks. If only a subset is allocated at root column, its complement remains explicitly payable by the old fallback or a new proof. The energy terminal (8) and comparator terminal in (12) are retained; they are different from the unresolved receiver demand.

Optional full-window coarse and near-anchor deletions, if invoked later, add `T_soft/alpha` and `1+n log(1+1/sqrt n)`; neither is added or used here. A future change to `mu_i,lambda_i` requires fresh original gates and the original-threshold weight `t_i=lambda_initial/lambda_i`. Repeated core fees remain `sum t_i(T_i+2N_i)W_i`, plus classification charges and unfinished terminal demand, bounded if necessary by `t_m H_n W_m`. Empty receiver demand is zero even if source remains. The original all-scale `O(log(n+2))` return and any separate strength-layer `J_n=O(log n)` with actual overlap remain.

D01/B01 are used only to keep the positive-plan model and feasible-certificate direction explicit; no continuum strong duality or optimal-plan existence is imported. N04 is used in its elementary finite telescoping scope: (7) has a proved finite lower terminal and zero error, while (12) has its displayed finite error sum. This gives a constructive actual-graph tool with explicit limits. General joint-gated root capacity remains OPEN.

本项对有限菜单中的三个实际非负 L1∩L2 来源取得完整连续接收域与尺度区间包围，最终保存四份精度记录。同源精度复算不增加来源数。符号与置换单元使用准确 Lebesgue 体积；共同来源标签、实际障碍帽与严格阈值保留。未决单元的全部体积与保留能量上界计入费用，空间和尺度尾部有全域为零的证明。有理与定向定点端点承担认证，浮点仅供展示。

有限记录支持所测试预算下的可实现删帽证书。严格高度帽、代理最优删除、同一构造帽的真实能量是不同对象；精度区间跨越预算时只报告未决。生产与复制重放的执行来源在本地分别登记，恢复角色没有执行生产程序。未推导一般维数律、原联合 F2 门结论或极大弱常数下界。任意非负 L1、真实 Lebesgue 接收、全部尺度的一致 n^(1/2+o(1)) 目标仍 OPEN。

具体来源配方、程序、定量前沿与方法压力属于 PRIVATE；本公开段不含它们。

Three exact stages on new continuous inputs show why individually valid local caps cannot be glued without threshold reserves and interaction accounting. The same inputs admit a paid aggregate-cap repair. Every receiver and source volume remains in the certificate.

A source-dependent allocation update was also checked on the same physical capture graphs. It preserves rows, edge support and the column ceiling while lowering the column potential of a deliberately imbalanced feasible allocation. The balanced control has zero gain. This is an implementation check of the general update lemma, not original F2 qualification, high-load evidence, or a termination bound.

The tests use rational geometry and directed scale integrals, with no grids or old-model replays. They neither contradict the correctly priced gluing lemma nor prove the general weak target, which remains OPEN.

## 审核恢复与最后装配

四个理论模块的候选筛查、完整 Markdown 与匹配 LaTeX 审查由原 Astra 和 Sol 审核者完成，实际范围逐次记入本地审核记录。覆盖模块第17式、共同分配第15a–c式及后验变化公式另有全文增量确认；来源模块的 TeX 符号已修正。私人障碍资格段的梯度符号修正另由本次恢复角色及独立审核者实际复读，不将原 Astra 未登记的私人附录阅读归入其范围。软远场变体的精确系数在全文阶段核验，未冒称提前筛查。

中断发生时，程序与结果已完成，但 numeric.md 和部分公开审计段仍停留在早期检查点。2026年10月13日恢复工作先核对原程序、数据和父代理隔离回执的全部散列；匹配后重建数值报告，不重复计算旧输入，也不把继承回执登记成恢复角色自行执行。旧审计文件保留本地原貌；本报告使用最后实际完成状态，而非早期公开摘要。

主代理负责最终装配和范围审查，恢复后的独立 Sol 审核者检查报告、数值记录、回执与归档。最终归档验收另行记录；各角色的实际读取、程序执行和继承证据分别说明。数学工具、数值程序和公开守卫的通过范围仅限明示命题及输入。一般根阶弱型上界仍 OPEN。


## 实际验证、复现范围与限制

四个理论模块分别提供完整 Markdown 和匹配 LaTeX。两名不同模型的审核者先检查主要候选的量词与反例风险，再阅读完整证明；软远场变体的精确系数是在全文审查时核验，不能把它写成已提前完成的精确命题筛查。主代理另行核对未来占用链式积分、有限体积删除的平层处理、共同列的下降和有限比较，以及阈值拼接的费用。理论 PASS 表示所述命题与条件通过审查，不表示未付的统一预算成立。

第一条私人计算对三个真实非负 L1∩L2 输入进行完整连续接收区间包围，共四份精度记录，含同一初探输入的两种尺度精度。最终记录含 22069 个不同来源接收单元、23191 次接收单元包围、1556032 个接收与尺度矩形、88 条高度前沿记录和12份可实现的代理量删帽证书。符号与置换单元使用准确 Lebesgue 体积；来源标签在各坐标共享。未决单元的全部体积和保留能量上界均收费；尺度及空间尾部有全域为零的证明。使用有理和定向定点计算，浮点仅展示。精度复算不是新增输入，也不是随机样本。

主代理将该程序复制到独立临时目录执行，耗时3.868815875秒，exit0、stderr为空；全部解析 JSON 字段与最终记录完全相等，没有排除任何字段。区间尚宽的结果保留为不确定；有限输入上的成功删除不能推出一般维数律。作者先执行两份初探精度记录，再由完整命令重算初探并完成压力和扩大，总计六次计算记录；最终保存四份，仍只有三个不同实际输入。12份预算证书中只有三个不同帽形状，部分单元删除分支实际执行零次；该分支的证明及代码检查不冒充运行覆盖。

第二条私人计算在一组新连续来源的三个阶段上，精确检查带真实体积的局部拼接、同源付费修复，以及实际捕获图上的一次共同分配更新和零增益对照。所有源积分、接收积分和尺度积分均保留；没有继承未检验的原 F2 门。主代理隔离复制执行耗时0.038763166秒，exit0、stderr为空。全部数学和描述字段一致，只排除实际存在的 runtime_seconds。两条私人计算不共享测试模型，不把同源的多个观察量计作多个新输入。

公开守卫为一个真实一维可数来源，直接验证无限几何级数、全部来源之间的分离、连续尺度的区间捕获公式和单一并帽外全尺度零正超额。它不以有限前缀或接收网格代替无穷来源。准确质量2、L2范数平方4、帽体积1、全边长质量截止2、来源距离下界7/2，因而实际帽费用1/2。主代理隔离执行耗时0.014028875秒，exit0、stderr为空，PASS。完整标准库 Python 程序内嵌于本报告末尾；提取该代码即可复现。该守卫验证拼接工具的适用性，不提供一般目标的独立证据。

三类隔离执行回执保留原程序散列和输出，复现没有改变作者记录。私人配方、程序和量化压力仅本地；公开归档只保留一般证明、中性验证范围、公开守卫及清单。更新后的64项技能按具体工具读取与适用条件使用，条目散列盘点不等于64项原文全部阅读或全部定理已核验。所用一手来源的实际阅读范围在 sources 模块分别登记。

本轮不运行 LaTeX 编译器、不生成 PDF。装配检查控制字符、环境配对、花括号、标签及引用、显示公式分隔，并校验归档内部散列；静态检查不声称编译成功。目标仍未证明，下一轮必须继续支付一般输入的保留占用矩或原捕获图共同来源容量。


## 独立公开审核程序

```python
"""Actual countable-source, all-scale separated-cap gluing certificate.

One source on R: f=2 sum_{j>=0}1_[4j-a_j,4j+a_j], a_j=2^(-j-2).
This verifies exact infinite-series and cleared-denominator certificates.
It does not replace the countable family by a finite prefix or sample receivers.
"""
from fractions import Fraction as Q
import json


def run():
    density, kappa = Q(2), Q(1)
    first_halfwidth, ratio, spacing = Q(1, 4), Q(1, 2), Q(4)
    # Exact series S=sum a_j is the unique solution S=a_0+ratio*S.
    # All terms are nonnegative and ratio<1; the geometric remainder tends0.
    assert 0 < ratio < 1
    width_sum = first_halfwidth/(1-ratio)
    assert width_sum == first_halfwidth + ratio*width_sum == Q(1, 2)
    source_volume = cap_volume = 2*width_sum
    mass = density*source_volume
    source_square_integral = density**2*source_volume
    fullside_cutoff = mass/kappa
    assert source_volume == cap_volume == 1
    assert mass == 2 and source_square_integral == 4
    assert fullside_cutoff == 2

    # For EVERY i<j, |c_j-c_i|>=spacing and a_i,a_j<=a_0.
    # Therefore their closed supports are separated by at least this margin.
    separation_lower = spacing-2*first_halfwidth
    assert separation_lower == Q(7, 2) > fullside_cutoff

    # Entire continuous one-source exterior calculation, not node evaluation:
    # t>=a. At halfside r<=t-a the average is0. On t-a<r<t+a,
    # average=density*(r-t+a)/(2r), whose r derivative is
    # density*(t-a)/(2r²)>=0. On r>=t+a the average=density*a/r,
    # with derivative -density*a/r²<0. Hence its exact maximum is
    # density*a/(t+a)<=density/2=kappa. Clearing its denominator,
    # kappa*(t+a)-density*a = kappa*(t-a)>=0 for our density.
    assert density == 2*kappa
    assert kappa+ kappa-density == 0  # coefficient of a in the last identity
    assert kappa > 0                 # coefficient of (t-a)
    local_cap_volume_over_mass = Q(1)/density
    assert local_cap_volume_over_mass == Q(1, 2)

    # Outside the SINGLE countable union of caps, every local average<=1.
    # A fullside L<cutoff cannot meet two supports, by the global separation.
    # At L>=cutoff, the WHOLE infinite source satisfies Af<=mass/L<=1.
    # Thus the actual positive excess is identically zero outside the union
    # for all centers/scales (source/cap boundary changes are null sets).
    allscale_exterior_energy = Q(0)
    cap_fee = kappa*cap_volume/mass
    assert cap_fee == Q(1, 2)

    return {
        'status': 'PASS',
        'actual_source_instances': 1,
        'component_count': 'countably infinite; no finite-prefix substitution',
        'dimension': 1,
        'source': 'density2 intervals centered4j, halfwidth2^(-j-2), j>=0',
        'receiver_measure': 'actual Lebesgue dx; all centers and all full-side scales',
        'source_mass_exact': str(mass),
        'source_L2_squared_exact': str(source_square_integral),
        'source_volume_exact': str(source_volume),
        'single_union_cap_volume_exact': str(cap_volume),
        'all_pair_support_separation_lower': str(separation_lower),
        'global_fullside_mass_cutoff': str(fullside_cutoff),
        'small_scale_source_interaction_bound': 1,
        'local_component_allscale_exterior_average_upper': str(kappa),
        'actual_allscale_union_exterior_energy_exact': str(allscale_exterior_energy),
        'paid_cap_coefficient_exact': str(cap_fee),
        'infinite_tail': 'exact convergent geometric-series identity',
        'original_F2_or_obstacle_claim': False,
        'general_centered_cube_weak_target': 'OPEN',
        'receiver_samples_or_PDE_solves': 0,
    }


if __name__ == '__main__':
    print(json.dumps(run(), sort_keys=True))
```
