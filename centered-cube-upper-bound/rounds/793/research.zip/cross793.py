"""R793: exact cross-middle Gram terms from the full observed and hidden arms."""

import argparse
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
from itertools import product
import json
from pathlib import Path
import platform
import sys

import flint
from flint import arb, fmpq, ctx


ctx.prec = 256
ETA = F(3,4)


def ar(x):
    a=F(x)
    return arb(fmpq(a.numerator,a.denominator))


def total(values):
    return sum(values,F(0))


def balltotal(values):
    return sum(values,arb(0))


def ar_archive(x, original):
    if isinstance(x,arb):
        return str(x)
    return original.encode_fraction(x)


def fixture(n,stage,scale,physical,geom,original):
    base=geom.instances(n,stage)
    cells,raw,_,_=original.build_original(n,base,physical,geom)
    J={ (i,j):physical.parent_overlap(n,p,q,original.AMP)
        for (i,p),(j,q) in product(enumerate(base),repeat=2)}
    K={(i,j):w/(base[i].m*base[j].m) for (i,j),w in J.items()
       if base[i].m!=base[j].m and 0<w<=ETA*min(base[i].m,base[j].m)}
    d={v:total(base[i].owner*k for (w,i),k in K.items() if v==w)
       for v in range(len(base))}
    size=scale**n
    parents=[geom.Parent(p.c*scale,p.s*scale,p.m*size,p.owner*size,p.keep) for p in base]
    if scale!=1:
        for (i,j),ww in J.items():
            p,q=parents[i],parents[j]
            lo=max(p.c-p.s,q.c-q.s)
            hi=min(p.c+p.s,q.c+q.s)
            new=scale*physical.mu1(lo/scale,hi/scale,original.AMP)*(2*min(p.s,q.s))**(n-1)
            assert new==ww*size
            if (i,j) in K:
                assert new*q.owner/(p.m*q.m)==K[i,j]*base[j].owner
    arms={}
    eligible={}
    B=defaultdict(set)
    for group,mu in sorted(cells.items()):
        for i in group:
            a=i,group
            arms[a]=parents[i].keep*parents[i].owner/(parents[i].m)*size*mu
            eligible[a]=tuple(v for v in group if (v,i) in K and parents[i].m<parents[v].m)
            for v in eligible[a]:
                B[v].add(a)
    R=defaultdict(lambda:defaultdict(F))
    for x,rows in raw.items():
        for (i,v,j,z),w in rows.items():
            a,b=(i,x),(j,z)
            assert a in B[v] and b in B[v]
            R[a][v,b]+=size*w
    return parents,d,dict(arms),eligible,B,R


def certify_conditional(parents,degree,lam,eligible,B,R):
    M={v:parents[v].m*degree[v] for v in B}
    P={a:total(rows.values()) for a,rows in R.items()}
    Pa_v=defaultdict(F)
    for a, rows in R.items():
        for (v,b),weight in rows.items():
            Pa_v[a,v]+=weight
    s_by_v={}
    s0={v:total(lam[b] for b in B[v])/mv for v,mv in M.items()}
    accepted=empty=identities=0
    min_relative_s=F(1)
    max_factor=F(0)
    witness=None
    for a, va in eligible.items():
        for v in va:
            Pav=Pa_v.get((a,v),F(0))
            s=Pav/(parents[v].owner/parents[v].m*lam[a])
            assert 0<=s<=s0[v]<=1
            if Pav:
                s_by_v[a,v]=s
                accepted+=1
                min_relative_s=min(min_relative_s,s/s0[v])
            else:
                empty+=1
            norm=F(0)
            cap_sum=F(0)
            for b in sorted(B[v]):
                xi=F((a[0]+b[0]+v+len(va)*len(eligible[b]))%5,4)
                val=R.get(a,{}).get((v,b),F(0))
                cond=val/(Pav*lam[b]) if Pav else F(0)
                assert s*M[v]*cond==xi
                assert val==parents[v].owner/(degree[v]*parents[v].m**2)*lam[a]*lam[b]*xi
                norm+=lam[b]*cond
                cap_sum+=lam[b]*xi
                identities+=1
                if cond:
                    amplification=M[v]*cond
                    if amplification>max_factor:
                        max_factor=amplification
                        witness=dict(observed_left_full_arm=a,actual_middle_v=v,hidden_full_arm=b,
                                     xi=xi,s=s,ungated_s0=s0[v],
                                     correct_conditional_density_g=cond,
                                     M_v_times_g_if_acceptance_is_omitted=amplification)
            assert s==cap_sum/M[v] and norm==int(bool(Pav))
    assert witness and max_factor>1 and min_relative_s<1
    return M,P,s_by_v,dict(
        accepted_observed_arm_middle_rows=accepted,zero_acceptance_rows_retained_in_diagnostic=empty,
        exact_hidden_arm_before_and_after_gate_identities=identities,
        smallest_actual_s_over_ungated_s0=min_relative_s,
        largest_M_v_g_on_a_true_hidden_record=max_factor,
        positive_witness_why_s_is_needed=witness)


def compare_square(parents,M,P,lam,R,s,bin_of):
    W=total(P.values())
    grouped=defaultdict(F)
    direct, direct_in_bin, direct_diagonal, missing_s = (arb(0) for _ in range(4))
    root={v:ar(x).sqrt() for v,x in M.items()}
    bins={v:bin_of(parents[v].m) for v in M}
    support_cross_ab=0
    for a,rows in sorted(R.items()):
        by_b=defaultdict(dict)
        for (v,b),w in rows.items():
            by_b[b][v]=w
        fullnorm=total(w/P[a] for w in rows.values())
        assert fullnorm==1
        for b,by_v in sorted(by_b.items()):
            denom=P[a]*lam[b]
            g={v:r/denom for v,r in by_v.items()}
            terms={v:root[v]*ar(x) for v,x in g.items()}
            tmp=defaultdict(lambda:arb(0))
            for v,x in terms.items():
                tmp[bins[v]]+=x
            if len(tmp)>1:
                support_cross_ab+=1
            direct+=ar(denom)*balltotal(terms.values())**2
            direct_in_bin+=ar(denom)*balltotal(x*x for x in tmp.values())
            direct_diagonal+=ar(denom)*balltotal(x*x for x in terms.values())
            missing_s+=ar(denom)*balltotal(x*ar(s[a,v]) for v,x in terms.items())**2
            for v,w in product(by_v,repeat=2):
                grouped[v,w]+=by_v[v]*by_v[w]/denom
    assert all(grouped[v,w]==grouped[w,v] for v,w in grouped)
    per_pair={pair:ar(value)*root[pair[0]]*root[pair[1]] for pair,value in grouped.items()}
    from_gram=balltotal(per_pair.values())
    diag=balltotal(w for (v,u),w in per_pair.items() if v==u)
    within=balltotal(w for (v,u),w in per_pair.items() if bins[v]==bins[u])
    cross=balltotal(w for (v,u),w in per_pair.items() if bins[v]!=bins[u])
    cross_same=balltotal(w for (v,u),w in per_pair.items() if bins[v]==bins[u] and v!=u)
    assert all(x.overlaps(y) for x,y in ((direct,from_gram),
               (direct_diagonal,diag),(direct_in_bin,within),(direct,within+cross)))
    # Diagonal is also rational before interval conversion.
    rational_diag=total(M[v]*value for (v,u),value in grouped.items() if v==u)
    assert diag.overlaps(ar(rational_diag))
    assert 0<missing_s<direct and 0<cross<direct and support_cross_ab>0
    off=max((pair for pair in grouped if bins[pair[0]]!=bins[pair[1]]),
            key=lambda pair:grouped[pair]**2*M[pair[0]]*M[pair[1]])
    # Ranking by the square avoids comparing intervals or truncating the roots.
    assert per_pair[off]>0
    return dict(
        true_P_marginal_mass=W,
        true_mids_with_volume_bins=[(v,parents[v].m,bins[v],M[v]) for v in sorted(M)],
        observed_rows_with_positive_P_a=len(P), coeligible_hidden_price_blocks_spanning_bins=support_cross_ab,
        relative_to_true_P={
            "all_square":direct/ar(W),
            "gram_square":from_gram/ar(W),
            "only_within_absolute_volume_bin":within/ar(W),
            "only_identical_middle_diagonal":rational_diag/W,
            "wrong_square_if_conditional_acceptance_s_is_omitted":missing_s/ar(W)},
        ratios_to_full_true_square={
            "within_true_bin":within/direct,"identical_parent":diag/direct,
            "distinct_parent_same_bin":cross_same/direct,"distinct_volume_bins":cross/direct,
            "drop_acceptance_s":missing_s/direct},
        rational_coefficients_before_square_roots=[
            (v,u,value) for (v,u),value in sorted(grouped.items())],
        certified_positive_cross_bin_pair=[off,per_pair[off]/direct])


def cert_case(n,stage,scale,physical,geom,original):
    parent,d,lam,eligible,B,R=fixture(n,stage,scale,physical,geom,original)
    M,P,s,accept=certify_conditional(parent,d,lam,eligible,B,R)
    square=compare_square(parent,M,P,lam,R,s,geom.floor_log2)
    return dict(n=n,actual_total_parents=len(parent),physical_dilation=scale,
                phase_period=scale/8,volume_multiplier=scale**n,
                true_full_peak_records=sum(map(len,R.values())),
                conditional_acceptance=accept,actual_cross_middle_square=square)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--price-dir",type=Path)
    p.add_argument("--phase-dir",type=Path)
    p.add_argument("--geometry-dir",type=Path)
    out=p.add_mutually_exclusive_group()
    out.add_argument("--output",type=Path)
    out.add_argument("--check",type=Path)
    args=p.parse_args()
    for path in (args.price_dir,args.phase_dir,args.geometry_dir):
        if path:
            sys.path.insert(0,str(path))
    import price792 as original
    import common791 as physical
    import merges789 as geom
    models=[cert_case(n,stage,F(1),physical,geom,original) for stage,n in enumerate((4,8,16),1)]
    shifted=cert_case(4,1,F(31,32),physical,geom,original)
    before=models[0]["actual_cross_middle_square"]
    after=shifted["actual_cross_middle_square"]
    assert before["relative_to_true_P"]["all_square"].overlaps(after["relative_to_true_P"]["all_square"])
    assert before["rational_coefficients_before_square_roots"]==after["rational_coefficients_before_square_roots"]
    assert before["relative_to_true_P"]["only_identical_middle_diagonal"]==(
        after["relative_to_true_P"]["only_identical_middle_diagonal"])
    assert before["ratios_to_full_true_square"]["distinct_volume_bins"] > (
        after["ratios_to_full_true_square"]["distinct_volume_bins"])
    data=dict(
        python={"executable":sys.executable,"version":platform.python_version(),
                "machine":platform.machine(),"python_flint":flint.__version__},
        arithmetic="Exact Fraction coefficients, 256-bit Arb square roots and directed interval comparisons",
        command="python -B cross793.py --check cross793.json",
        dependencies={name:sha256(Path(module.__file__).read_bytes()).hexdigest()
                      for name,module in (("price792.py",original),("common791.py",physical),("merges789.py",geom))},
        scope=("Complete a and b retain the physical original arm owner label and true price member type. "
               "True conditional densities are constant within these types; independent auxiliary owners "
               "within E_i integrate to one under the original price-dependent screen. "
               "No added cut is imposed on the given finite diagnostic R792 peak. "
               "The 31/32 variant scales all centers, radii, owner volume and source phase; "
               "the actual d_v is invariant. The outer left measure is the unnormalized actual P^a, "
               "while the measure on the hidden true arm is its original lambda prime."),
        physical_cases=models, physical_rescaled_n4=shifted)
    text=(json.dumps(data,sort_keys=True,indent=2,default=lambda x:ar_archive(x,original))+"\n").encode()
    if args.output:
        args.output.write_bytes(text)
    elif args.check:
        if args.check.read_bytes()!=text:
            raise SystemExit("certificate differs")
        print("cross793: exact acceptance and independent complete cross-middle squares agree")
    else:
        print(text.decode(),end="")


if __name__=="__main__":
    main()

