"""Round 793. Exact geometric points and interval checks of the inverse lens and scale profile."""
from argparse import ArgumentParser
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path
import platform
import sys

import flint
from flint import arb, ctx, fmpq
import common791 as physical
import cross793
import frames793
import merges789 as geom
import price792 as original

ctx.prec = 256
LOG2 = arb(2).log()


def ar(x):
    x = F(x)
    return arb(fmpq(x.numerator, x.denominator))


def encode(x):
    if isinstance(x, arb):
        return str(x)
    if isinstance(x, F):
        return str(x)
    raise TypeError(type(x))


def add(values):
    return sum(values, arb(0))


def read_points(parents):
    # Choose actual interior prices, not an average price at a membership label.
    x_breaks = sorted({p.c + sign*p.s for p in parents for sign in (-1, 1)})
    radii = sorted({F(0)} | {p.s for p in parents})
    centers = {}
    for lo, hi in zip(x_breaks, x_breaks[1:]):
        for r, t in zip(radii, radii[1:]):
            x, u = (lo+hi)/2, (r+t)/2
            mark = tuple(i for i,p in enumerate(parents) if abs(x-p.c)<p.s and u<p.s)
            if mark and mark not in centers:
                centers[mark] = x,u
    return centers


def lens(n, differences, edge):
    value = arb(1)
    for dy, multiplicity in differences:
        if not multiplicity:
            continue
        f = 1-ar(dy)/edge
        if not f>0:
            if not f<=0:
                raise ArithmeticError("unresolved facet")
            return arb(0)
        value *= f**multiplicity
    return value


def samples(n, stage, scale):
    parents, d_v, lam, elig, B, R = cross793.fixture(n,stage,scale,physical,geom,original)
    pts = read_points(parents)
    h = 1+F(1,32*n)
    edges = {v:ar(h)*arb(2)**(ar(1+geom.floor_log2(parents[v].m))/n) for v in B}
    M = {v:parents[v].m*d_v[v] for v in B}
    entries = mixed = 0
    sealed = arb(0)
    checked_by_orders = 0
    witness = None
    memo = {}
    for a, rows in sorted(R.items()):
        by_b = defaultdict(dict)
        for (v,b), mass in rows.items():
            by_b[b][v] = mass
        xa,ra = pts[a[1]]
        for b, by_v in sorted(by_b.items()):
            xb,rb = pts[b[1]]
            for opposed in (0,(n-1)//2,n-1):
                terms = []
                for v,mass in sorted(by_v.items()):
                    key = (v,a[1],b[1],opposed)
                    if key not in memo:
                        memo[key] = lens(n,[(abs(xa-xb),1),(abs(ra-rb),n-1-opposed),
                                           (ra+rb,opposed)], edges[v])
                    phi = memo[key]
                    assert phi>0
                    xi = F((a[0]+b[0]+v+len(elig[a])*len(elig[b]))%5,4)
                    nu = xi*parents[v].owner/parents[v].m
                    dens = mass/(lam[a]*lam[b])
                    assert nu/M[v] == dens
                    terms.append((v,ar(nu)/phi,phi/ar(M[v]),ar(dens)))
                p = add(t[3] for t in terms)
                k = add(t[1]*t[2].sqrt() for t in terms)
                direct = add(x[1]*z[1]*(x[2]*z[2]).sqrt() for x in terms for z in terms)
                assert (k*k).overlaps(direct)
                # Any ordering works for the double-sum identity; here it is the q ordering.
                terms.sort(key=lambda t:float(t[2].log()))
                ordered, prev = arb(0),arb(0)
                for i,(v,w,q,dens) in enumerate(terms):
                    if i:
                        v0,w0,q0,dens0=terms[i-1]
                        equal_exactly=(geom.floor_log2(parents[v].m)==geom.floor_log2(parents[v0].m)
                                       and M[v] == M[v0])
                        if not (q>q0 or equal_exactly):
                            raise ArithmeticError("q ordering has not been certified")
                    root=w*q.sqrt()
                    ordered+=root*root+2*root*prev
                    prev+=root
                assert ordered.overlaps(direct)
                numbins=len({geom.floor_log2(parents[t[0]].m) for t in terms})
                within=add(x[1]*z[1]*(x[2]*z[2]).sqrt() for x in terms for z in terms
                           if geom.floor_log2(parents[x[0]].m)==geom.floor_log2(parents[z[0]].m))
                if numbins>1:
                    assert direct>within
                    mixed+=1
                # Raw cross-cap scale is small when the actual central owner cells are tiny.
                ratio=direct/p
                if witness is None and numbins>1:
                    witness=dict(value=ratio,a=a,b=b,opposed_coordinates=opposed,
                                 volume_bins=numbins)
                sealed+=ratio
                checked_by_orders+=1
                entries+=len(terms)
    return dict(n=n,scale=str(scale),physical_middle_terms=entries,point_and_arm_pairs=checked_by_orders,
                pair_tests_with_strict_cross_bin_terms=mixed,summed_point_scores=sealed,
                strict_cross_bin_witness=witness,
                note="Each sign setting is a genuine interior point of the price cell. Representative scores are not spatial integrals.")


def log_profile(n, d):
    # All active coordinates have normalized offset 1/2 at the mode d=0.
    t=arb(d)*LOG2
    return -t+n*(2-(-t/n).exp()).log()


def level_end(n,level,direction):
    # Certify every discrete d in the returned interval by monotonicity.
    # On the left the physical support begins at d>-n.
    def test(m):
        if direction<0 and m>=n:
            return False
        l=log_profile(n,direction*m)
        if l > -level:
            return True
        if l < -level:
            return False
        raise ArithmeticError("threshold unresolved")
    lo,hi=0,1
    while test(hi):
        hi*=2
    while hi-lo>1:
        mid=(hi+lo)//2
        if test(mid):
            lo=mid
        else:
            hi=mid
    return lo


def scalar(n):
    unit=arb(1)
    left,right = (level_end(n,unit,s) for s in (-1,1))
    # Degree dispersion: schematic dyadic-bin capacities; not a realized family of cubes.
    factor=arb(n+2).sqrt()
    w=factor.log()
    l2,r2=(level_end(n,w,s) for s in (-1,1))
    C=left+right+1
    assert ar(C)>ar(n).sqrt()/3 and l2>=left and r2>=right
    return dict(n=n,constant_drop_bins=C,ends=[-left,right],constant_bins_over_sqrt=ar(C)/ar(n).sqrt(),
                dispersion_bins=l2+r2+1,dispersion_ends=[-l2,r2],
                adaptive_bins_over_sqrt_n_log=ar(l2+r2+1)/(arb(n)*w).sqrt())


def clipped(n):
    # Endpoints on coordinate 1 kill all unbroadened receiver tents.
    # All other coordinates give equal receiving and price factors to isolate the repair.
    delta=F(1,8*n)
    x,z=-(1-delta),1-delta
    U,W=x-F(1,4),z+F(1,4)
    h=1+F(1,32*n)
    # n-dimensional price/receiver distances, only the first axis differing; s_d=1.
    omega=F(1,2*n)
    def old(r):
        return max(F(0),1-abs(r)/2)
    def mix(r):
        return (1-omega)*old(r)+omega*max(F(0),1-abs(r)/8)/4
    ph=old(z-x)
    old3=[old(W-x),old(z-U),old(W-U)]
    assert ph==delta and old3==[0,0,0]
    # passive coordinates equal, no expansion loss beyond the documented normalizer.
    passive=ar(mix(0))**(n-1)
    ratios=[ar(mix(y)/ph)*passive for y in (W-x,z-U,W-U)]
    assert all(y>ar(F(1,3)) for y in ratios)
    return dict(n=n,one_axis_true_price_tent=ph,old_receiver_products=old3,
                new_ratios=ratios,within_physical_middle=abs(x)<=1/h and abs(z)<=1/h,
                scope="Real Euclidean point positions in one cube. No full-path or lower bound claim.")


def prefix_budget(n):
    data=frames793.case(n)
    layers=data["normalized_three_layer_price_density"]
    cells=layers["true_predicted_frame_layers_Lambda_volumes"]
    entries=layers["original_right_price_actual_parent_checks"]
    D=[row["actual_D"] for row in entries]
    weights=[m/d for m,d in zip(cells,D)]
    cumulative=[]
    running=F(0)
    for weight in weights:
        running+=weight
        cumulative.append(running)
    G=[1/(d*(1+w)) for d,w in zip(D,cumulative)]
    norm=sum(a*b for a,b in zip(cells,G))
    second=sum(w/(1+v) for w,v in zip(weights,cumulative))
    assert norm==second and ar(norm)<(1+ar(running)).log()
    # The first-entry density has a strictly smaller normalization than the
    # terminal density on early layers, despite sharing one actual source.
    final_G=[1/(d*(1+running)) for d in D]
    assert all(a>b for a,b in zip(G[:-1],final_G[:-1]))
    rows=[]
    for row in entries:
        M=row["diagnostic_M"]
        pm=row["conditional_probability_by_predicted_layer"]
        paid=sum(m for m,g in zip(pm,G) if n*(M*g)**2>=1)
        independent=sum(m for m,d,v in zip(pm,D,cumulative)
                        if n*M*M>=d*d*(1+v)**2)
        assert paid==independent
        rows.append(paid)
    i=1
    q=(G[0]+final_G[0])*entries[i]["diagnostic_M"]/2
    earlier=entries[i]["conditional_probability_by_predicted_layer"][0]
    assert earlier>0 and entries[i]["diagnostic_M"]*G[0]>q>entries[i]["diagnostic_M"]*final_G[0]
    return dict(n=n,layer_increments=weights,prefix_totals=cumulative,
                exact_single_row_integral=norm,certified_log_upper=(1+ar(running)).log(),
                diagnostic_gate_probability_by_parent=rows,
                distinguishing_threshold=q,positive_first_layer_probability=earlier,
                scope="Reference is compact Lebesgue on the actual three-frame example; M is the frozen diagnostic value.")


def main():
    parser=ArgumentParser(description=__doc__)
    io=parser.add_mutually_exclusive_group(required=True)
    io.add_argument("--output",type=Path)
    io.add_argument("--check",type=Path)
    arg=parser.parse_args()
    data=dict(python=sys.executable,version=platform.python_version(),flint=flint.__version__,
              platform=platform.machine(),bits=ctx.prec,
              point_examples=[samples(n,i,F(1)) for i,n in enumerate((4,8,16),1)]+[samples(4,1,F(31,32))],
              analytic_level_width=[scalar(n) for n in (64,256,4096,65536,2**40,2**128)],
              prefix_allocation=[prefix_budget(n) for n in (4,8,16)],
              one_facet=[clipped(n) for n in (64,256,4096,65536,2**40)],
              required_modules={Path(m.__file__).name:sha256(Path(m.__file__).read_bytes()).hexdigest()
                                for m in (cross793,physical,original,geom,frames793)},
              command="python -B shape793.py --check shape793.json")
    data=(json.dumps(data,sort_keys=True,indent=2,default=encode)+"\n").encode()
    if arg.output:
        arg.output.write_bytes(data)
    elif data!=arg.check.read_bytes():
        raise SystemExit("different results")
    else:
        print("shape793: inverse lens squares, level endpoints, true receivers and cumulative allocations agree")


if __name__=="__main__":
    main()
