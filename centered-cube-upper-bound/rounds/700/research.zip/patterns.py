from collections import deque
from multiprocessing import get_context
from functools import lru_cache
from itertools import product
import random,time,socket,os,json,sys

@lru_cache(None)
def ideals(n):
    if not n:return (0,1)
    half=1<<(n-1)
    old=ideals(n-1)
    return tuple(x|(y<<half) for x in old for y in old if y&~x==0)

def deficit(weights,cap,n):
    # Network from demand pattern to compatible location patterns.
    count=len(cap);sink=2*count+1
    g=[{} for _ in range(sink+1)]
    def edge(x,y,c):
        g[x][y]=c;g[y][x]=0
    infinity=sum(weights)+1
    for m,v in enumerate(weights):
        edge(0,1+m,v)
        b=m
        while True:
            edge(1+m,1+count+b,infinity)
            if not b:break
            b=(b-1)&m
    for b,v in enumerate(cap):edge(1+count+b,sink,v)
    sent=0
    while True:
        back={0:None};q=deque([0])
        while q and sink not in back:
            x=q.popleft()
            for y,v in g[x].items():
                if v and y not in back:back[y]=x;q.append(y)
        if sink not in back:break
        delta=infinity;y=sink
        while y:
            x=back[y];delta=min(delta,g[x][y]);y=x
        sent+=delta;y=sink
        while y:
            x=back[y];g[x][y]-=delta;g[y][x]+=delta;y=x
    return sum(weights)-sent

def case(seed):
    begin=time.process_time();rng=random.Random(seed)
    n=2+seed%3
    lo=[-rng.randrange(1,45) for _ in range(n)]
    hi=[rng.randrange(1,45) for _ in range(n)]
    hs=32*n+1;side=2*hs
    good=[max(0,side-n*(u-l)) for l,u in zip(lo,hi)]
    cap=[]
    for m in range(1<<n):
        v=1
        for k,w in enumerate(good):v*=side-w if m>>k&1 else w
        cap.append(v)
    assert sum(cap)==side**n
    centers={tuple(rng.randrange(-31,32) for _ in range(n)) for _ in range(120)}
    small=[0]*len(cap)
    for y in centers:
        m=0
        for k in range(n):
            if y[k]+32<hi[k] or y[k]-32>lo[k]:m|=1<<k
            else:assert hi[k]*n-hs<=y[k]*n-1<=y[k]*n+1<=lo[k]*n+hs
        small[m]+=2**n
    assert deficit(small,cap,n)==0
    # Added arbitrary marginal loads test positive unmatched mass; they
    # need not come from a real first-hit history.
    w=[v+rng.randrange(1+side**n//len(cap)*2) for v in small]
    ans=deficit(w,cap,n)
    brute=max(sum(a-b for m,(a,b) in enumerate(zip(w,cap)) if ideal>>m&1) for ideal in ideals(n))
    assert ans==brute
    return dict(seed=seed,n=n,positive=ans>0,cpu=time.process_time()-begin,pid=os.getpid())
if __name__=='__main__':
    lo,hi,w=map(int,sys.argv[1:]);begin=time.monotonic()
    with get_context('fork').Pool(w) as p:r=p.map(case,range(lo,hi),1)
    print(json.dumps(dict(rows=r,elapsed=time.monotonic()-begin,workers=w,python=sys.version,host=socket.gethostname())))
