"""Compressed genuine translated shell inputs. Decimal results are diagnostics."""
from decimal import Decimal as D,getcontext,ROUND_CEILING
from multiprocessing import get_context
import os,json,time,socket,sys

def case(n):
    getcontext().prec=65
    begin=time.process_time()
    a=32*n;rho=1-D(2)/a;u=rho**n;log2=D(2).ln()
    L=int((D(n).sqrt()*log2/(1-u)).to_integral_value(rounding=ROUND_CEILING))
    t=L*(1-u)/log2
    S=rho**L
    k=1
    while (k+1)**3<=n:k+=1
    # k long axes and n-k parity-shifted short axes.
    rbig=D('2.5');rshort=1/(D(2)*n);R=(k*rbig+(n-k)*rshort)/n
    h=1+D(1)/a;s0=S*(-log2/n).exp();kap=h**n
    # p is the fraction of sources whose upper endpoint on a short axis
    # lies below the other anchor's coordinate 1/n, uniform over full layers.
    p=D(0);radius=D(1)
    for layer in range(L):
        # Count indices m>=0 with 2m+1 < a/(n*radius).
        threshold=(D(a)/(n*radius)-1)/2
        c=max(0,min(a,int(threshold.to_integral_value(rounding=ROUND_CEILING))))
        # Geometric rational tie at layer zero does not occur (a/n=32).
        outer=int(c>0)+int(c==a)
        p+=(D(c)/a-D(c-outer)/a*rho**(n-1))/(1-u)
        radius*=rho
    p/=L
    assert 0<p<1
    H=-(p*p.ln()+(1-p)*(1-p).ln())
    info=(k*rbig+(n-k)*rshort*p+h*s0*(n-k)*H)/(h*s0+R)
    ratio=info/t
    # Log lower bound for the transported budget divided by actual target
    # volume, using the exact prefactor rather than a bounding-box relaxation.
    best=None
    for d in range(1,100):
        delta=D(d)/100
        shrink=1-info/(delta*n)
        x=t*(1-delta)*log2/kap-1
        if shrink<=0 or x<=0:continue
        log_inv=x.ln() if x<=1 else x-1
        # beta - b/t >= 1/4 at all tested parameters.
        bound=(kap/(4*t)).ln()+n*(((s0+R/h)*shrink)/S).ln()-k*log2+log_inv
        best=bound if best is None else max(best,bound)
    return dict(n=n,k=k,L=L,scaled_entropy=str(ratio),p=str(p),bound=str(best) if best is not None else None,cpu=time.process_time()-begin,pid=os.getpid())
if __name__=='__main__':
    lo,hi,step,w=map(int,sys.argv[1:]);start=time.monotonic()
    with get_context('fork').Pool(w) as pool:rows=pool.map(case,range(lo,hi,step),1)
    print(json.dumps(dict(rows=rows,workers=w,host=socket.gethostname(),python=sys.version,elapsed=time.monotonic()-start)))
