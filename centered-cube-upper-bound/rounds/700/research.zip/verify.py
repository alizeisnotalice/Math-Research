import json
from fractions import Fraction
from decimal import Decimal
from pathlib import Path
def read(n):return json.loads(Path(n+'.json').read_text())
dims=set();seeds=set();positive=0
for h in ('mini','laptop'):
    for kind in ('','-pattern'):
        d=read(h+kind);r=d['rows']
        assert len({x['pid'] for x in r})==d['workers']
        print(h,kind,len(r),d['workers'],sum(x['cpu'] for x in r),d['elapsed'])
        if kind:
            seeds.update(x['seed'] for x in r);positive+=sum(x['positive'] for x in r)
        else:
            dims.update(x['n'] for x in r)
            assert all(x['bound'] is None or Decimal(x['bound'])<0 for x in r)
assert dims==set(range(128,65537,128)) and seeds==set(range(5400))
r=read('facecert')
assert len(r)==259 and [x['n'] for x in r if not x['new_pays']]==[4,5,6]
assert all(x['old_below'] for x in r)
print('positive marginal deficits',positive)
