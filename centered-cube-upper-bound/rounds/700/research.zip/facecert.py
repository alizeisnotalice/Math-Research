from flint import arb,ctx
import json
ctx.prec=256
def inv(x):
    if x<0:return arb(0)
    if x<1:return x
    assert x>=1
    return (x-1).exp()
rows=[]
for n in list(range(4,257))+[512,1024,4096,16384,65536,262144]:
    a=32*n
    h=1+arb(1)/a; kap=h**n; b=arb(a)**(-n)
    log2=arb(2).log(); p=1/(2*h); tn=arb(n).sqrt()
    allowance=kap*(arb(3)/2)**n*((1-p)**n+n*p*(1-p)**(n-1))
    W=arb(4)**(1-n)/32
    # For the actual temperature t, sqrt(n)<=t<=sqrt(n)+(W+b)/log2.
    # Compare t times both certificates, divided by V_target.
    deficit=(tn*log2-b-allowance)/kap
    new=4*(arb(1)/2-b/tn)*kap*inv(deficit)
    old=4*arb(1)/2*kap*(arb(2)/3)**n*inv((tn*log2+W)/kap)
    plain=4*kap*(arb(2)/3)**n*inv((tn+(W+b)/log2)/(2*kap))
    old=old.max(plain)
    rows.append(dict(n=n,new_lower=str(new),old_upper=str(old),
                     new_pays=bool(new>1),old_below=bool(old<1),
                     allowance=str(allowance)))
print(json.dumps(rows))
