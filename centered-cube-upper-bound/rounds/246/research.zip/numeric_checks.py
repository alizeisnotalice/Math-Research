#!/usr/bin/env python3
"""R246 finite correlated product clocks. Ordinary mp quadrature, exact event ledgers.
Independent of R245 files; declarations adapted from its finite clock menu.
"""
from fractions import Fraction as F
from pathlib import Path
import argparse, hashlib, json
import mpmath as mp

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def enc(x): return mp.nstr(x,50)
def fm(x): return mp.mpf(x.numerator)/x.denominator
def src(m,g,death=None): return {'mass':F(m),'groups':[(F(a),k) for a,k in g], 'death':F(death) if death else None}
def w(v,t):
    out=F(1)
    for a,k in v['groups']: out*=min(F(1),a/t)**k
    return out
def k(v,t,left=False): return sum(c for a,c in v['groups'] if a<t or (a==t and not left))
def live(v,t,left=False): return v['death'] is None or v['death']>t or (left and v['death']==t)
def state(vs,t,left=False):
    rows=[(v['mass']*w(v,t),k(v,t,left)) for v in vs if live(v,t,left)]
    e=sum((a for a,_ in rows),F()); score=sum((a*b for a,b in rows),F())
    return rows,e,score

def cases():
    rows=[['.8','1','1.2','1.4'],['.9','1.1','1.3','1.5'],['1.05','1.15','1.25','1.55'],['.7','1.1','1.4','1.6']]
    baseline=[src(str(m),[(a,1) for a in r]) for m,r in zip([10,7,5,3],rows)]
    deleted=[src(str(m),[(a,1) for a in r],d) for m,r,d in zip([10,7,5,3],rows,['1.1',None,'1.4',None])]
    return [
      ('initial','heterogeneous_no_birth',2,'1','2',False,[src('1',[('.5',2)]),src('2',[('.5',1),('4',1)]),src('1/3',[('4',2)])]),
      ('initial','all_scores_n',2,'1','2',False,[src('1',[('.5',2)]),src('2',[('.75',2)])]),
      ('pressure','births',4,'1','1.6',False,baseline),
      ('pressure','births_and_deletes',4,'1','1.6',False,deleted),
      ('pressure','coincident_birth_delete',4,'1','2',False,[src('1',[('.5',2),('1.25',2)],'1.25'),src('2',[('1.25',3),('2',1)]),src('1/2',[('.75',1),('1.25',3)],'1.5')]),
      ('pressure','open_terminal',2,'1','2',True,[src('1',[('1',1),('2',1)],'2'),src('2',[('1.25',1),('2',1)])]),
      ('expanded','heterogeneous_n16',16,'1','2',False,[src('1/10',[('.25',4),('1',4),('1.5',4),('4',4)]),src('1',[('.5',8),('1.25',4),('3',4)],'1.5'),src('10',[('.75',4),('1.5',8),('2.5',4)],'2'),src('3',[('1',4),('2',4),('3',4),('4',4)])]),
      ('expanded','heterogeneous_n128',128,'1','2',False,[src('1',[('.5',64),('1.25',64)]),src('1/2',[('1.1',32),('1.5',96)],'1.5'),src('3',[('1.25',128)]),src('1/100',[('3',128)])])]

def exact(c):
    phase,name,n,aa,bb,opened,vs=c; lo,hi=F(aa),F(bb)
    assert all(sum(z for _,z in v['groups'])==n for v in vs)
    events=sorted({lo,hi}|{a for v in vs for a,_ in v['groups'] if lo<a<hi}|{v['death'] for v in vs if v['death'] and lo<v['death']<hi})
    # Extra rational cuts change neither raw births nor the initial score charge.
    cuts=sorted(set(events)|{lo+(hi-lo)/3,lo+2*(hi-lo)/3})
    ints=[]; energy=F(); variance=F(); checks=0
    for a,b in zip(cuts,cuts[1:]):
        mid=(a+b)/2; alive=[v for v in vs if live(v,mid)]
        r,e,sc=state(vs,mid); assert e>0
        pi=[(mass/e,score) for mass,score in r]
        mean=sc/e; d=sum((p*q*max(i-j,0) for p,i in pi for q,j in pi),F())
        assert d<=mean*(1-mean/n); checks+=1
        el=sum((v['mass']*w(v,a) for v in alive),F()); er=sum((v['mass']*w(v,b) for v in alive),F())
        ml=sum((v['mass']*w(v,a)*k(v,mid) for v in alive),F())/el
        mr=sum((v['mass']*w(v,b)*k(v,mid) for v in alive),F())/er
        en=sum((k(v,mid)*v['mass']*(w(v,a)-w(v,b)) for v in alive),F())
        assert en>=0 and ml>=mr; energy+=en; variance+=ml-mr
        ints.append({'lo':str(a),'hi':str(b),'energy':str(en),'variance_integral':str(ml-mr),'midpoint_mean':str(mean),'midpoint_D':str(d),'midpoint_quadratic_slack':str(mean*(1-mean/n)-d)})
    birth=[]; deletes=[]; normalized_birth=F(); delete_mean_jump=F()
    for t in sorted({a for v in vs for a,_ in v['groups'] if lo<a<=hi}|{v['death'] for v in vs if v['death'] and lo<v['death']<=hi}):
        if t==hi and opened: continue
        raw=sum((v['mass']*w(v,t)*sum(ct for a,ct in v['groups'] if a==t) for v in vs if live(v,t,True)),F())
        if raw:
            e_at=sum((v['mass']*w(v,t) for v in vs if live(v,t,True)),F())
            normalized_birth+=raw/e_at
            slots=[idx for idx,(a,b) in enumerate(zip(cuts,cuts[1:])) if a<t<=b]
            assert len(slots)==1
            birth.append({'time':str(t),'raw':str(raw),'ending_segment':slots[0]})
        if any(v['death']==t for v in vs):
            before=sum((v['mass']*w(v,t) for v in vs if live(v,t,True)),F())
            after=sum((v['mass']*w(v,t) for v in vs if live(v,t)),F())
            deleted=sum((v['mass']*w(v,t)*k(v,t) for v in vs if v['death']==t),F())
            assert after>0
            sbefore=sum((v['mass']*w(v,t)*k(v,t) for v in vs if live(v,t,True)),F())
            safter=sum((v['mass']*w(v,t)*k(v,t) for v in vs if live(v,t)),F())
            delete_mean_jump+=safter/after-sbefore/before
            deletes.append({'time':str(t),'e_before':str(before),'e_after':str(after),'deleted_active_score':str(deleted)})
    _,e0,s0=state(vs,lo); _,e1,s1=state(vs,hi,opened)
    br=sum((F(b['raw']) for b in birth),F()); ds=sum((F(d['deleted_active_score']) for d in deletes),F())
    assert energy==s0+br-s1-ds
    assert s0+br<=n*e0
    assert variance==normalized_birth+s0/e0-s1/e1+delete_mean_jump
    # Each refined interval has its own inherited score; telescoping includes events.
    return {'phase':phase,'name':name,'n':n,'tau':str(lo),'T':str(hi),'open_terminal':opened,'sources':[{'mass':str(v['mass']),'groups':[[str(a),ct] for a,ct in v['groups']],'delete':str(v['death']) if v['death'] else None} for v in vs], 'intervals':ints,'births':birth,'deletions':deletes,'e_tau':str(e0),'e_T':str(e1),'initial_score_mass':str(s0),'raw_birth_total':str(br),'terminal_score_mass':str(s1),'deleted_score_mass':str(ds),'energy':str(energy),'variance_integral_exact':str(variance),'normalized_birth_total':str(normalized_birth),'signed_delete_mean_jump':str(delete_mean_jump),'variance_ledger_exact':str(normalized_birth+s0/e0-s1/e1+delete_mean_jump),'raw_initial_plus_birth_slack':str(n*e0-s0-br),'exact_midpoint_checks':checks,'partition_scope':'rational time cuts, not first-passage degree restart algorithm'}

def numeric(c,ex,dps):
    with mp.workdps(dps):
        _,_,n,aa,bb,opened,vs=c; L=mp.log(fm(F(bb)/F(aa)))
        integral=mp.mpc(0)
        for rec in ex['intervals']:
            a,b=F(rec['lo']),F(rec['hi']); mid=(a+b)/2
            alive=[v for v in vs if live(v,mid)]
            ks=[k(v,mid) for v in alive]
            co=[]
            for v in alive:
                cf=v['mass']
                for th,ct in v['groups']:
                    if th<mid: cf*=th**ct
                co.append(mp.log(fm(cf)))
            def fun(u):
                logs=[z-kk*u for z,kk in zip(co,ks)]; mx=max(logs)
                pp=[mp.exp(z-mx) for z in logs]; den=sum(pp); pp=[z/den for z in pp]
                mean=sum(p*kk for p,kk in zip(pp,ks))
                D=sum(pp[i]*pp[j]*abs(ks[i]-ks[j]) for i in range(len(pp)) for j in range(i))
                return mp.mpc(mean,D)
            ua,ub=mp.log(fm(a)),mp.log(fm(b)); pts=[ua,ub]
            for mult in [1,4,16,64]:
                if ua+mp.mpf(mult)/n<ub: pts.append(ua+mp.mpf(mult)/n)
                if ub-mp.mpf(mult)/n>ua: pts.append(ub-mp.mpf(mult)/n)
            integral+=mp.quad(fun,sorted(set(pts)))
        delete_loss=sum((mp.log(fm(F(d['e_before'])/F(d['e_after']))) for d in ex['deletions']),mp.mpf(0))
        Q=mp.log(fm(F(ex['e_tau'])/F(ex['e_T'])))-delete_loss
        V=fm(F(ex['variance_integral_exact'])); D=integral.imag
        quadratic=Q-Q*Q/(n*L); root=mp.sqrt(L*V/2); old=min(Q,n*L/4); new=min(quadratic,root)
        tol=mp.mpf(10)**(-dps+8)
        assert abs(integral.real-Q)<tol*max(1,abs(Q))
        assert D<=new+tol and new<=old+tol and quadratic>=-tol
        return {key:enc(val) for key,val in {'L':L,'Q_log_degree_minus_delete':Q,'actual_delete_logloss':delete_loss,'Q_integrated':integral.real,'D_full_integrated':D,'V_exact_as_mp':V,'quadratic_fee':quadratic,'variance_root_fee':root,'new_fee':new,'old_min_Q_nL4':old,'improvement_old_minus_new':old-new,'D_slack':new-D}.items()}

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json')); ap.add_argument('--contract',type=Path,default=Path(__file__).with_name('task_contract.md')); args=ap.parse_args()
    out={'scope':'Finite arbitrary correlated atomic clocks; ordinary non-interval quadrature. No physical C qualification, FULL, general budget gain or asymptotic claim. Only new R246 quantities; no replay of old R245 suite.','source_sha256':sha(__file__),'contract_sha256':sha(args.contract),'dependencies':{'python':'3.12.14','mpmath':mp.__version__},'cases':[]}
    maximum=mp.mpf(0)
    for c in cases():
        ex=exact(c); low=numeric(c,ex,40); high=numeric(c,ex,70)
        with mp.workdps(100):
            diffs={key:abs(mp.mpf(low[key])-mp.mpf(high[key]))/max(1,abs(mp.mpf(high[key]))) for key in low}
            md=max(diffs.values()); maximum=max(maximum,md)
            assert md<mp.mpf('1e-25')
            comparison={'max_scaled_absolute_difference':enc(md),'normalizer':'max(1,abs(high)); enc50 retains mp40 roundoff','field_differences':{k:enc(v) for k,v in diffs.items()}}
        ex.update({'mp40':low,'mp70':high,'precision_comparison':comparison}); out['cases'].append(ex)
        print(c[1], 'D=',high['D_full_integrated'],'new=',high['new_fee'],flush=True)
    out['counts']={'cases':len(out['cases']),'initial':2,'pressure':4,'expanded':2,'exact_positive_midpoint_checks':sum(c['exact_midpoint_checks'] for c in out['cases']),'birth_event_assignments':sum(len(c['births']) for c in out['cases']),'exact_energy_ledgers':len(out['cases'])}
    out['precision_summary']={'max_scaled_absolute_difference':enc(maximum),'scope':'Independent mp40/mp70 quadrature; not certified interval errors.'}
    args.output.write_text(json.dumps(out,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
    print(json.dumps(out['counts']),flush=True)
if __name__=='__main__': main()
