# R246 独立审核

## 命题先行筛查（未读作者证明）

只审准确时钟和真实位移接口，未改变原测度/后验，不Git/PDF/spawn或改其他人文件。首次目录尚无作者稿/合同；不据缺失文件补造原资格。

### 1. 完整双后验score与固定时钟

对同一完整Π上两个乘积测度槽，0≤k,k′≤n逐点有 `(k−k′)+≤k(1−k′/n)`。取积测度得 `D=E(k−k′)+≤m(1−m/n)`；交换对称和Cauchy另给 `D=.5E|k−k′|≤sqrt(Var(k)/2)`。只需两个槽为同一完整Π，不假设样本内部坐标独立。正门和G/B限制可上放至D；不得换成独立坐标模型。

对长度L=log(T/τ)>0的原固定有效连续时间窗，Q=∫m dlogt在[0,nL]，故

`∫J≤min{Q−Q²/(nL), sqrt[(L/2)∫Var dlogt]}`。

其中第一式用∫m²≥Q²/L，第二式用时间Cauchy；两者是同一J的上界，可以取min。L=0单列零，不除L。未知Q/variance不是输入预算。

### 2. 删除与端点

当e始末均正，原Z有限递减删除且阈值连续w时，连续log导数为−m，真实删除跳另扣log(e−/e)。因此

`Q=log(e_τ/e_T)−Σ_del log(e_{s−}/e_s)`。

出生只改变k，不使w或e跳跃。开放T使用原heavy内部左极限，τ已含其实际事件；同刻先出生后删除。normalized variance恒等式为 `∫Var=B_norm−(m_T−m_τ)+Σ_del Δm`，正号删除补偿不能丢。e_T=0时上述∞−∞不定义，须先正截断；原strict-heavy窗内部末端正下界才使有限式可直接用。新真实删除跳不是原连续N_del信用，已消费N_Z不返回。

### 3. 真实位移桥与可回代范围

令d_i=|y_i−v_i|/b，ξ=c_jt/b，原A_i=bC(d_i)/c_j，k=#{C(d_i)<ξ}。若C(d)≥(1−d)+且0≤ξ<1，活跃坐标必有min(d_i,1)>1−ξ。因此

`k_t(v)≤S(y,v)/(1−ξ)`，`S=Σmin(d_i,1)`，并可与k≤n取min。该不等式实际对所有ξ<1成立；原时钟τ=a/c_j与b≤2a使ξ≥a/b≥1/2，上端ξ=1不允许除1−ξ。严格score等号阈值只影响时间零测集。

与J_geom=max(E,Gsharp,min(S,εn))联用必须是同一对(y,v)。若已认证该对J_geom<t0≤εn，则S<t0，进而k≤min(n,t0/(1−ξ))。只有min(S,εn)低于εn的非饱和范围才反推S上界；t0>εn无此授权。相反，大J_geom不自动提供score收益。

原R242源门通常评价(y,hard-z)，而这里score评价(y,aux-v)。不能因hard-z近或其J_geom低便限制完整Π中的v；须保完整Π，另证真实源对共同关系/条件加权费用。接近ξ=1时位移界退化，积分1/(1−ξ)有对数端点费用，不能称全窗免费可积。

以上候选在所列条件下通过；一般global付款、source交换、参数随x的选择费用均未由此获得。等待作者稿后审。


## 作者稿后严格审核与范围

新task_contract.md已完整实读，定义、允许工具及非闭合验收与初筛一致。restart_energy.md及global_geometry.md已全文审核；严格结论为：**时钟分段责任、完整Π的Gini/方差界、实际阈值面coarea和同槽位移桥通过；没有新增原交通/global根阶付款。**

### 重启责任及显式行费用

RE2按每次实际删除分隔，再在连续e下降λ倍时重启；heavy有效窗度数有正下界，所以截断下段数有限。阈值出生归结束段，下段继承已活跃score。b_l每坐标至多一次，故e_τm_τ+Σb_l≤ne_τ。RE4中的B_norm≤Σb_l/e_l^-≤λB_norm方向正确；较晚的出生仍可能承受更小degree分母，raw责任预算不能支付该归一化量。

RE5/6的a_l=∫segment e Ek²及初末项/真实删除score质量精确抵消，未重置每段n。RE7/8的normalized mean删除补偿为正号且可有两种符号，不能因“删除有利”省略。RE9第一项由normalized birth，第二项由e≥e_l^-及∫m²≥Q_l²/L_l，确均上界真实variance积分；即使显示为两个差，也非负。RE10两个系数分别是TV的1/2与pair的1/√2，RE12使用ΣQ_l²/L_l≥Q²/L正确。该优化费不劣于同窗旧Q行费，但不是一般维数阶改进，且不宣称每段费仅依重启个数。

RE13保原high/dT及两份完整Π，在physical/三腿放松之前使用，不另收节点费用；原外2Λ、β/ν、真实dx、唯一j、history及源依费用未消失。取可测有理λ的countable inf不改变后验，但没有把该行费免费积分成W。N_del仍是连续未来删除反向交通；所有新真实删除原子不登记退款。

### 真实C核、coarea及槽位

GG3的C=h*max(h,φ)在[0,1]等于1−d+∫_.5^{d+.5}φ，导数−1+φ(d+.5)。C(1)<.5由φ对称且(0,.5)有正质量，结合原ξ≥a/b≥.5给d_t<1；ξ<1内部d_t>0，避开|.|尖点。物理坐标v_i上的log A导数倒数为bC/(1−φ)，不是其倒数或缺b因子；用C≤1、φ≤φ0可界b/(1−φ0)。

ν≤f dx的L1密度使各坐标推前在内部层可作a.e.coarea。GG3.3保原Z_t(y)面内限制、w_t及y依full e_t；有限真实删除时刻不影响该连续密度。只给a.e.层而非任意指定面的规范trace，未授L1面帽。GG3.4仍须在原p h_R a/q、β、hardν、high、真实receiver与唯一j下联合支付，不能先提出e_t(y)，也不能把FIRST体积响应当face预算。

GG4正确限制位移桥所处的aux-v槽，未将原(y,hard-z)的J门挪给v；逆w_g也保留。GG5对一般clock子域使用自身A_F、L_F，未因凹函数而擅换全窗A；同窗endpoint-minus-delete-log身份与原N_del区别准确。稿中没有将行严格改善或距离信息冒称新增已付几何门。

### 实际工具与版本

本人实跑216项Fraction有限score检查，全部通过；仅作基本常数/方向诊断，非FULL或一般证明。对应完整简短代码如下，可独立复现，不调用原过程实例：

```python
from fractions import Fraction as F
from itertools import product
checks=0
for n in (1,2,4,16):
    x=[F(0),F(n,2),F(n)]
    for a in product((1,2,3),repeat=3):
        p=[F(k,sum(a)) for k in a]
        m=sum(t*w for t,w in zip(x,p))
        var=sum(w*(t-m)**2 for t,w in zip(x,p))
        D=sum(p[i]*p[j]*max(x[i]-x[j],0)
              for i in range(3) for j in range(3))
        assert D<=m*(1-m/n)
        assert D*D<=var/2
        checks+=2
print('PASS',checks)
```

实际输出PASS 216。GG6作者所报四项float积分仅按稿中有限阈值代数范围理解，未冒称本人重跑；不重跑R117已知混合压力例。主正式数值/未交付整合稿不在本次执行回执内。

| 受审文件 | SHA256 |
|---|---|
| task_contract.md | `7888fc0ec96c31615956b79b2f7b039f8fb71ed05134c7c386c216a0de0456fe` |
| restart_energy.md | `0659fed4393ef0dba84eb4f239c2f1c7a695803f13b37f22ccb6a0cc90277b29` |
| global_geometry.md | `646f9a527607824eabc72c13798cc5b308a9cb64bdb381ca414a7a83c5b5101b` |

本次有界任务完成并停止写入。剩余精确缺口是实际归一化出生面在原source/receiver共同测度下的费用，或同槽score/receiver关联的可付估计；没有通过重启、删除信用、后验替换或源门重命名关闭它。


## 主整合稿补审与最终绑定

主代理新增proof.tex.txt后已全文补审。公式(1)–(3)严格保normalized出生分母、初末score及真实删除补偿；(4)是同一完整Π的两个行上界取min，L=0/零degree行先零，正有限截断避免∞−∞。一般时间子域使用自己的length与mean积分，不擅换全窗Q。辅助来源与hard-z未交换。

(7)给原ν的L1密度经实际C反演的a.e.coarea推前，Z_t仍在面内、完整e_t(y)仍在原y,t积分内；没有把每一任意固定面的L1代表当规范trace，也没有把Jacobian有界当面密度预算。主稿(8)仅是birth责任部分，正文正确保留端点/删除补偿再用(4)，以及真实原outer Cauchy/receiver/source费用。它不声称独立支付birth项等价于整个交通付款。所有原high、q、p、hard核、β、外hardν、history、唯一j和真实dx保留；没有借R223连续N_del或已耗N_Z。

本人提出的两个窄修已实读核实：端点/event的m与score采用k^+=#{A_i≤t}，连续积分仍用原strict版本；ξ出生内部范围与[1/2,1)取交，j=0的ξ=1只按零时间测度端点处理。没有重跑数值。

最终主稿SHA256：`34974b3016e27dc362d5ff597ea9896798b3176010bbd842e14693c953611200`。此前合同及两作者hash绑定保持，正式8例及其主代理迁移重放不在本补审执行范围；root将另行重放audit内216代码。结论仍为严格时钟/位移与coarea工具通过、一般原交通费用未付。至此最终冻结并停止写入。
