# R246：重启责任的精确抵消与实际来源阈值面

**状态：未获得新的原交通付款。** 本稿有界检查 R245 proof (6) 的重启路线。保留每段终端 score 后，重启初始项可以准确抵消；不能消去的是原来源坐标在其真实出生时刻承担的完整归一化分母。下文把该费用展开为实际 C 核的来源面，而非把逆度数改名为一个免费常数。裸行 Gini 的改善仅作附记，不作为本轮主要几何成果。

## GG1. 原对象与重启要求

固定原 (ω,V,j,y)，令

\[
 A_i(y,v)=\frac b{c_j}C(|y_i-v_i|/b),\quad
 w_t(v)=\prod_i\min(1,A_i/t),\quad
 \mu_t=1_{Z_t}w_t\nu,\quad e_t=\mu_t(V),\quad \Pi_t=\mu_t/e_t.
\]

ν 是同一完整硬尾；Z_t 是原有限路径的递减右连续存活域。只在有限截断且 e_t>0 的有效窗 [τ,T] 上使用除法；τ=a/c_j，T≤bc_j。来源坐标 score 采用 k_t^+=#{i:A_i≤t} 的右连续版本，它与原严格版本几乎处处一致。τ 时刻事件已计入初值；同一时刻先计出生，再作实际删除。开放右端从窗内取左极限。

令 m_t=∫k_t^+Π_t。原正 pair score J_t(r) 保 G=S_g、B=D_g、原 κ_t∈[0,1]、high、capture、Ψ 和全部真实来源；正上放到全 Π_t⊗Π_t 只用于下述诊断，不据此改变母账或重用负信用。

对固定原行 r，R245 给

\[
 \int_{J_{far}}J_t(r)\,d\log t
 \le\sqrt{n/2}\left(\int_{J_{far}}e_\tau/e_t\,d\log t\right)^{1/2}.
\]

其外层仍是原

\[
 d\mathcal T(r)=1_{I_{rec}}1_{j(x)=j}q^{-1}p(x,y)h_{R(x)}(x-z)a_\omega
                  \,dx\,\beta_V(dy)\nu_V(dz).
\]

high、heavy 或实际 source-history 门不能通过重启变成新的来源归一化。尤其 hard z 不是 Π_t 的来源标签。

## GG2. 归一化阈值责任：重启可望抵消的全部项

定义原归一化出生量

\[
 B_\Pi(\tau,T)=\int\nu(dv)\sum_{i:\tau<A_i(y,v)\le T}
 1_{Z_{A_i-}}(v)\frac{w_{A_i}(v)}{e_{A_i-}(y)}. \tag{GG2.1}
\]

出生与删除同时发生时，分母和存活域使用出生后的、删除前的值；w 连续。若该时刻仅出生而没有删除，则 e_{A_i-}=e_{A_i}。有限截断下此量有限，例如可用 e_* =inf e_t>0 与 R245 的未归一化出生量作有限性检查；不把该粗界当最终价格。

对实际删除时刻 s，记删除质量 r_s、删除后均值 m_s、被删除部分的出生后 score 均值 m_{del,s}。若 r_s=0，该项置零。则

\[
 \Delta_{del}m_s=m_s-m_{s-}^{postbirth}
     =\frac{r_s}{e_{s-}}(m_s-m_{del,s}),\qquad
 |\Delta_{del}m_s|\le n\frac{r_s}{e_{s-}}. \tag{GG2.2}
\]

有准确恒等式

\[
 \boxed{\int_\tau^T\operatorname{Var}_{\Pi_t}(k_t)\,d\log t
 =m_\tau-m_T+B_\Pi(\tau,T)+\sum_s\Delta_{del}m_s.} \tag{GG2.3}
\]

证明：无出生/删除处，dΠ_t=(m_t−k_t)Π_t dlogt，因而 dm_t=−Var(k_t)dlogt。某源的一次坐标出生使 k 增加一，w 和 e 不跳，故贡献恰为其当前 posterior 质量，非归一化来源质量；对全部源作 Fubini 即得 GG2.1。实际删除则由删除前均值是存活均值与被删均值的凸组合给 GG2.2。把各连续区间和事件相加得到 GG2.3。对非原子来源，按源点逐坐标 Stieltjes 积分后作非负 Fubini，有限性保证相应有符号项合法；不要求源原子化。

若按 e_t 的实际下降量选择任意有限重启分割，在每段保留完整的“初始 m−终端 m”及内部事件，内端点准确抵消，最终仍为 GG2.3。每个原来源坐标只出生一次；不存在因重启而新生的坐标责任。反之，在每段把初始 m 上放成 n 并丢弃末端 m，就会人为制造 n×重启次数。这个抵消不需要更换 Π，也不需要重新采样来源。

**没有消除的项。** GG2.1 中每次出生的分母是 e_{A_i}(y)，不同来源坐标可以有不同出生时刻。R245 授的是 ∑出生 w_{A_i}ν≤ne_τ，不是 ∑出生 w_{A_i}ν/e_{A_i}≤n。重启保留全部终端项后，恰在这里遇到同一个实际归一化困难；把未归一化出生预算除以一个共同 e_τ 或任意子集 H 均不合法。

GG2.2 的原删除事件与 R223 的 N_del 不同：后者是连续未来删除来源的反向交通，并非这里的原子均值跳。即使使用 R117 已证的 ∑r_s/e_{s-} 上界，仍须乘 n 并按同一原外层来源积分，不能当负信用抵消。

## GG3. 实际 C 核把责任定位到有限距离来源面

这一节不更换 β 或 ν。原 β、ν≤f dx 均有 Lebesgue L¹ 密度。以下以 f_ν 表示 ν 的密度；所有面表达都按 coarea 的 dlogt 几乎处处层解释，并与原 β 密度作完整联合积分。它们不依赖 L¹ 代表在单个任意指定超平面上的取值，不声称这些面的点态 trace 有统一上界。

原一维核为 C=h*max(h,φ)，h=1_[−1/2,1/2]，φ 为原对称单峰概率密度，M_φ=φ(0)<1。在 0≤d≤1，直接分开 hard 重叠和外尾得

\[
 C(d)=1-d+\int_{1/2}^{d+1/2}\phi(u)du,
 \qquad C'(d)=-1+\phi(d+1/2). \tag{GG3.1}
\]

又 C(1)=∫_[1/2,3/2]φ<1/2；严格性来自对称概率密度在 (0,1/2) 上有正质量。故当

\[
 \xi=\frac{c_jt}{b}\in[a/b,c_j^2]\subset[1/2,1]
\]

时，C 的反演距离 d_t=C^{-1}(ξ) 在 [0,1) 内；内部 ξ<1 时 d_t>0，避开绝对值的尖点。ξ=1 的端点没有 dlogt 质量，按内部极限处理。

在物理差值 v_i−y_i 上反演 log A_i，Jacobian 为

\[
 \frac{bC(d_t)}{1-\phi(d_t+1/2)}
 \le\frac b{1-M_\phi}. \tag{GG3.2}
\]

因此 GG2.1 可准确写成 ∫_τ^T b_j(t,y)dlogt，其中几乎处处

\[
 b_j(t,y)=\sum_{i=1}^n\sum_{\varepsilon=\pm1}
 \frac{bC(d_t)}{[1-\phi(d_t+1/2)]e_t(y)}
 \int_{\mathbb R^{n-1}}
  1_{Z_t(y)}(v)w_t(y,v)f_\nu(v)\,d\widehat v_i
 \bigg|_{v_i=y_i+\varepsilon b d_t}. \tag{GG3.3}
\]

式中 e_t(y) 仅因固定 y,t 而写在对其余 v 坐标的积分外；它仍是同一完整 ν 的分母，不能移出外层 y,t 积分。Z_t(y) 全部保在面内。有限删除时刻可忽略于该密度式；GG2 的原子均值跳另计。这里不存在远尾反演 Jacobian 爆炸，且所有出生面满足 |y_i−v_i|<b。不能由此推断其 normalized face mass 小：ν 的原 rank 只控制实际出生格质量，FIRST 只控制合法响应的体积积分，两者都没有授予 GG3.3 的来源面密度帽。

保原 outer weight 的下一项实际积分就是

\[
 \mathbb E\sum_{V,j}\int1_{high}\,d\mathcal T(r)
    \int_{J_{far}(r)} b_j(t,y)\,d\log t. \tag{GG3.4}
\]

GG3.3 必须整体代入 GG3.4：真实 receiver x、输入 p(x,y)、共同 hard z、source-pair/history、β(dy)、full e_t(y) 和唯一 j(x) 均仍在。可以对正项使用 Tonelli，但不能先将 y 上的完整 e_t 提出 β 积分；也不能用 FIRST 的 ∫pβ≤q 直接支付乘上这项 source-face 密度的响应。GG3.4 是重启/方差路线的明确未付 source–receiver trace，不是本稿授予的新预算。即使它有某个上界，回到原 J_t 还须检查 Cauchy 所用的原外层 receiver 质量，不能自动把 sqrt(XW) 所产生的系数称为根阶来源价。

## GG4. Score 位移链的适用槽位

原 C(d)≥(1−d)_+ 给严格 active 条件

\[
 A_i(y,v)<t\ \Longrightarrow\
 \min(|y_i-v_i|/b,1)>1-\xi,
\qquad k_t(v)(1-\xi)\le S(y,v):=\sum_i\min(|y_i-v_i|/b,1). \tag{GG4.1}
\]

这可合法用于原辅助 v，但还没有付款。R242 的 J=max(E,Gsharp,T) 控制的是 I_i(y,z)=∫Ω_i h_Ri(x−z)P_y(x)dx 中 soft y 与 **hard z** 的位移。将 GG4.1 中的 v 放进该 J 而把 hard 核仍留在 z，是一次未授权的来源槽替换。

若转回真实 P_y/Q_v 的共同窗口，则必须保原 w_g(y,v)^−θ；已证 R224 的阈值缺口可用，但不能直接把未归一化的 S(y,v) 衰减穿过这个逆权。强 score 可能提供有用距离信息，然而本轮尚无在真实 receiver、目标 FIRST 与完整后验上保留它的全球支付。上述区别是具体接入条件，不是以单坐标不等式重命名一个已付几何门。

## GG5. 附记：不冻 e_τ 的裸行比较，以及其局限

令 H_t(u)=Π_t{k_t>u}，0≤u≤n。完整 iid score 的正 Gini 恰为

\[
 J_t^{full}=\int_0^nH_t(u)(1-H_t(u))du
 \le m_t-m_t^2/n. \tag{GG5.1}
\]

后一步由 ∫H_t=m_t 和 Cauchy。原 J_t≤J_t^{full}。对任何原 clock 子域 F，令 L_F=∫_F dlogt、A_F=∫_F m_t dlogt；若 L_F=0 原项为零，否则

\[
 \int_FJ_t\,d\log t\le A_F-\frac{A_F^2}{nL_F}\le nL_F/4. \tag{GG5.2}
\]

完整区间上的 A 有准确 endpoint 公式

\[
 A=\log(e_\tau/e_T)-\sum_s\log(e_{s-}/e_s). \tag{GG5.3}
\]

这只是原 degree 的连续损失，删除 log 损失扣除是恒等式，并非领取 N_del。对一般 F 不应把 A_F 换成 A 后套 GG5.2，因为其中函数并非全域单调。可与 R245 (6) 保持取 min；没有宣称逐行恒优。

GG5 明确保留接近 score 0 或 n 时的共同速度抵消，但在 m≈n/2 时仍是原线性 n/4 级别；因此不是本轮一般几何突破。其外层 ∫1high dT 价格也未付。仅把 inverse degree 改成 log degree 或这个凹函数，不是新的 root 结论。

## GG6. 实际计算与最终范围

本机 Python/numpy 用 64 点 Gauss–Legendre 在每个事件间的 log-time 区间积分，核对同一个有限阈值过程：n=3，质量 (1,2,1,.5)，阈值分别 (.7,.9,1.1)、(1.3,1.5,2.4)、(2,2.2,2.4)、(.8,1.4,2)，窗 [1,1.8]，第四源在 1.4 的阈值出生后删除。分割端点为 1,1.1,1.3,1.4,1.5,1.8。

实际数值：A=0.4632092062140502，endpoint-minus-jump 为0.46320920621405015；正 Gini 积分0.23556799129062578，profile 上界0.31284409555587367，endpoint 上界0.34153083687053987。Var 积分0.48437494114503266，归一化出生量1.3600365217607822，删除均值跳−0.09753902799957359，GG2.3 右端0.48437494114503277。四项检查均通过，最大所报恒等式误差约1.11e−16。这些阈值仅验证代数、同步事件与归一化方向，不是 C 核 FULL 实例、区间证书或反例。

本轮没有消除 R245 的全局几何瓶颈。准确的重启责任是 GG2.1，实际物理来源形式是 GG3.3，必须与 GG3.4 的原 receiver 权共同支付。保 endpoint 可以避免重复的人工初始 score 账，但不会免费支付真实出生分母；score 位移信息也不能把 auxiliary v 当成 hard z。本文没有改 Π、β/ν 或原母账，没有复用 N_Z，也没有新增另一个门作为目标完成。仅修改本责任文件，有限交付后停止。
