# 第246轮：去权重启筛查与实际阈值出生几何

日期2026-10-17；一般非负L1中心立方体n^(1/2+o(1))上界目标不变。上一轮新加权能量已提交bd791e0，本轮不把无权行估计当一般付款。

准确问题：R245原正量回代仍含∫eτ/e_t。首先筛查按degree重启是否能以同一来源坐标出生责任付费，避免重复每段初始n；进一步把归一化出生预算写回原C核的实际(y,v)几何和真实receiver积分。最终成功须降低原εX+Cε√n polylog W费用；若只得到归约或行界须如实标明。

定义：w_t=∏min(1,A_i/t)，A_i=bC(|y_i−v_i|/b)/c_j；C=h*max(h,φ)，h单位区间指示、φ=h*w、w(r)=∫_0^1 exp(−|r|/a)da。Z_t原递减存活集，ν、β原完整输入子测度，Π_t=1Z_tw_tν/e_t。m=EΠk，D=EΠ⊗Π(k−k′)+。时间L有限且e>0，Q=∫m，V=∫Var。

候选：D≤m(1−m/n)、D≤sqrt(Var/2)，故原带0≤κ≤1的G×B交通≤min{Q−Q²/(nL),sqrt(LV/2)}。Q必须扣实际delete造成的logdegree跳；V必须保归一化出生、终端mean差及signed delete mean跳。每坐标rawbirth至多一次但出生分母e不可删。空窗置零；不写∞−∞。

实际几何候选：在ct/b∈[1/2,1)的出生域，r=C^-1(ct/b)<1。以真实Lebesgue来源密度对(y,v)作coarea，Jacobian bC(r)/|C′(r)|显式保留，目标是完整weighted trace而非假设一个L1表面帽。个别固定t的L1代表无规范trace，用a.e.推前公式。另位移计数k≤Σmin(|y_i−v_i|/b,1)/(1−ct/b)只在同对辅助来源上可用；R242已付deficit属(y,hard-z)，不得偷换为(y,aux-v)。R224已有QG clock log界，不重复计算为成果。

允许工具：R117原归一化过程、R223准确signed母账、R224 C/QG范围、R237来源次序、R245能量，以及CS/Tonelli/coarea。已知约束：N_del连续反向流非删除跳，N_Z已消费；一般后验坐标相关；R117裸方差长路径例已知，不做重复反例搜索。

分工：Astra r217_peak负责实际全局来源与阈值几何(global_geometry.md)；Sol r217_compare负责重启责任账(restart_energy.md)；Sol r217_audit先独立审后读作者稿(audit.md)；Sol r217_numeric负责6–8个有限clock的新策略对照及可迁移脚本/JSON/notes。主代理整合原积分及状态，不改作者文件。无人重复全历史，没有独立任务不满员。

数值仅用于策略和会计：初探、端点同刻压力、扩大维数范围，Fraction中点和责任分配，mp40/70新的unweighted score积分，不重跑旧20组所有检查、不认证FULL/渐近。独审通过后精简归档，单轮提交推送，保持仅新增README和ZIP，不编译PDF。
