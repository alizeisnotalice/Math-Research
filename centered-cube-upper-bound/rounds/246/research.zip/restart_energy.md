# R246: restarting without repeating the coordinate birth budget

This note owns only this file. It gives an explicit, data-adaptive clock
fee and an exact allocation of the initial/birth score responsibilities
across degree restarts. It improves the old row fee when its actual
birth/mean data allow this, but does not prove a universal root row fee
or pay the remaining original source/receiver integral. No deletion
atom below is identified with the original negative traffic N_del.

## RE1. Original window and conventions

Fix original `(omega,V,j,y)` and a nonempty original heavy window I
with endpoints tau,T, before receiver x and hard z. Use the genuine
`mu_t=1_Zt w_t nu_V`, `e_t=||mu_t||`, `Pi_t=mu_t/e_t`, and
`k_t^+=#{i:A_i<=t}`. The strict score and this right-continuous version
agree for almost every log time. Write

    m_t=E_{Pi_t}k_t, L=log(T/tau),
    d_s=1-e_s/e_{s-},
    Delta_s m=d_s(m_keep-m_removed).

The endpoint, birth-before-deletion, and zero-row conventions are
exactly [R245 score_flux.md:9–89](/Users/zhengzhihao/Desktop/T/output/centered_cube_round245_20261017_final_checkpoint/score_flux.md:9).
In particular no event at tau is charged twice, and an open right
endpoint is approached internally. Empty windows contribute zero;
singleton windows have no continuous clock cost. The actual finite
forbidden-block changes are retained in full.

## RE2. Degree restarts and a once-only raw birth ledger

Choose a fixed number lambda>1. Split at every actual forbidden-block
deletion. Within each resulting continuous-degree interval, restart
when e_t first reaches its current starting degree divided by lambda.
The last segment may be shorter. Ordinary ties use the R245 convention:
coordinate births are assigned to the ending segment, and the next
segment starts with that score already active. No threshold birth
creates a new posterior or a new original source.

For each positive-length segment l, write its left/right values as
`e_l^+,m_l^+` and `e_l^-,m_l^-`, respectively. At a deletion these
refer to the after/before values belonging to their own segment.
Then

    1<=e_l^+/e_l^-<=lambda,
    L_l=log(t_l^-/t_l^+),
    Q_l=log(e_l^+/e_l^-)=integral_l m_t dlog t.

There are finitely many restarts: e has a positive lower bound on the
original heavy window and only finitely many deletion atoms. A large
deletion creates one actual new starting value, not a sequence of
empty degree levels. Internal limits cover open endpoints. The cuts
are measurable first passages of the original measurable degree path;
no receiver-dependent test or source is reselected.

Assign to this segment its raw coordinate births

    b_l=integral nu_V(dv) sum_i
       1_{t_l^+<A_i<=t_l^-}1_{v in Z_{A_i-}}w_{A_i}(v). (RE1)

Endpoint flags are interpreted as above when a segment ends at a
deletion. Every original pair (v,i) contributes to at most one b_l.
In particular, exactly as in R245 SF6,

    e_tau m_tau+sum_l b_l<=n e_tau.                   (RE2)

This is a source-coordinate budget, not n anew for every restart.
Indeed a coordinate is active at tau or is born later at most once;
its later raw weight is <=w_tau(v). Deletion can only prevent births.

Let B be the normalized birth measure of R245 SF2. The explicit
restart birth price

    F_lambda=sum_l b_l/e_l^-                           (RE3)

satisfies

    B(I)<=F_lambda<=lambda B(I).                      (RE4)

Proof: at a birth in segment l, `e_l^-<=e_{A_i-}<=e_l^+`.
Integrate the corresponding inequality for its reciprocal against
the positive raw birth measure. Thus no minimum source atom mass or
forest-node count appears in RE3--4. Nevertheless RE2 alone does not
bound RE3: later births can be divided by much smaller degrees.

## RE3. Exact active-score allocation, with negative terminal terms

On a segment without deletion the unnormalized identity in R245 SF3
is

    a_l:=e_l^+ m_l^+ +b_l-e_l^- m_l^-
        =integral_l e_t E_{Pi_t}k_t^2 dlog t >=0.      (RE5)

Let

    D_act,s=integral_{Z_{s-} minus Z_s}k_s^+w_s dnu_V>=0.

Summing RE5 before discarding any endpoint gives the exact ledger

    sum_l a_l=e_tau m_tau+sum_l b_l-e_T m_T
                                      -sum_s D_act,s
               <=n e_tau.                            (RE6)

Thus the apparently repeated starting score `e_l^+m_l^+` is funded by
the previous segment's terminal score. Only the actual raw births
enter as new score responsibility. Removed active-score mass is
subtracted, not reborn at a restart. Dividing each segment by its own
degree and then summing n per segment would destroy this identity.

For normalized means, the equally necessary telescoping relation is

    sum_l(m_l^+-m_l^-)
       =m_tau-m_T+sum_s Delta_s m.                    (RE7)

In particular the endpoint/birth estimate is

    integral_I Var_{Pi_t}k_t dlog t
      <=F_lambda+m_tau-m_T+sum_s Delta_s m.            (RE8)

Here the signed deletion mean can have either sign. The available
born estimate is only `sum_s d_s<=rho_j(T)` from R117 JG15; replacing
the last term by `n rho_j(T)` is a positive upper bound, not a new
negative traffic credit. RE7 avoids charging n at every deletion or
restart, but does not permit omitting this compensation.

## RE4. An explicit optimized clock fee, always no worse than the old one

All quantities in the following fee are endpoint degrees, endpoint
score means, actual raw coordinate births, and segment lengths.
They are not renamed integrals of the unknown variance. For L_l>0 put

    U_l=min{b_l/e_l^-+m_l^+-m_l^-,
             a_l/e_l^- - Q_l^2/L_l},
    D_l=Q_l-Q_l^2/(n L_l).                            (RE9)

Both entries in U_l are nonnegative upper bounds on
`integral_l Var_{Pi_t}k_t dlog t`:
the first follows from the normalized birth identity and RE4 on the
segment; the second from RE5, `e_t>=e_l^-`, and Jensen's lower bound
`integral_l m_t^2 dlog t>=Q_l^2/L_l`. Also `0<=Q_l<=nL_l`.

Define

    C_lambda^TV=sum_l min{D_l, (1/2)sqrt(L_l U_l)},
    C_lambda^pair=sum_l min{D_l, sqrt(L_l U_l/2)}.      (RE10)

Then, for the genuine unchanged normalized posterior,

    integral_I E|k_t-m_t|/2 dlog t<=C_lambda^TV,
    integral_I integral (k_t(v)-k_t(u))_+
                          Pi_t(dv)Pi_t(du)dlog t
                    <=C_lambda^pair.                 (RE11)

Proof of the first terms: for any random K in [0,n] with mean m,

    E|K-m|/2<=m(1-m/n),
    E(K-K')_+<=m(1-m/n),

where K' is an independent draw from the same law. The first is the
convex chord bound on absolute value. For the second use
`|k-k'|<=k+k'-2kk'/n`, then take expectation. Integration and Jensen
give D_l. The second terms of RE10 follow respectively from
`E|K-m|/2<=sqrt(Var K)/2` and
`E(K-K')_+<=sqrt(Var K/2)`, then Cauchy--Schwarz in log time.
These arguments use the same full Pi in both slots; they do not make
the source coordinates independent.

Let

    Q=sum_l Q_l
      =log(e_tau/e_T)-sum_s log(e_{s-}/e_s).

The clock fee always obeys

    C_lambda^TV,C_lambda^pair
       <=sum_l D_l<=Q-Q^2/(nL)<=min{Q,nL/4}.           (RE12)

The middle inequality is Cauchy--Schwarz
`sum Q_l^2/L_l>=Q^2/L`. Thus this fee is never made worse by reporting
a large degree-level count. The subtraction also removes continuous
degree loss caused by a nearly constant score k≈n, which has little
normalized variation. It is a data-adaptive gain, not a universal
improvement of the dimension order. A countable infimum over rational
lambda>1 can be taken, without changing the posterior or the source;
each individual inequality already holds for the same original path.

For calibration, if a window has no births and no deletion, its true
variance integral is exactly `m_tau-m_T<=n`; hence RE11 also gives
the bounds `(1/2)sqrt[nL]` and `sqrt[nL/2]`. This verifies that preserving
the terminal compensation can outperform the direct Q clock price.
It is not registered as a paid special-input branch. In the general
diagonal-mixture pressure mechanism already present in R117, many
threshold births can replenish that mean drop, and the unweighted
variance can be of order n^2. Restarts do not eliminate those births.

## RE5. What the original traffic can and cannot inherit

Keep the exact original mother from R128 RT1 and the same complete
two posteriors. Every original nonnegative positive gate (good/bad,
FA, capture remainder and time restriction) is <=1. Its clock at fixed
original x,y,z is consequently bounded by `C_lambda^pair(j,V,y)` on
the full original heavy window, without replacing hard z by u or v.
In particular, with all the original outer factors retained,

    P_I^rem<=E sum_{V,j} integral 1_high dT_I
                                  C_lambda^pair(j,V,y). (RE13)

There is no added three-leg or physical-node fee in RE13: it acts
before those positive replacements. It is only a row-clock estimate.
For a common dominating-posterior route the corresponding mass is
at most `1+C_lambda^TV+sum_s d_s`, retaining the separate actual
posterior deletion jumps. The original signed pending slot still
has its one factor `2Lambda`; neither these d_s nor D_act,s are its
unused N_del credit.

RE13 does not give `epsilon X+C sqrt(n)polylog(n)W_beta`. FIRST controls
the original unweighted p beta response, not the response with the
source-dependent RE10 fee. Summing RE2 over sources weights it by
their actual initial degree e_tau; dividing by the restart degrees
is exactly the unresolved step in RE3. The source-born estimate pays
the actual forbidden-block deletions, not arbitrary coordinate birth
sets. The hard band controls the original hard z integral, not this
new auxiliary-coordinate birth charge. Nor does unique receiver j
allow one to sum repeated beta/nu source resources for free.

Using only the number of degree restarts recovers the familiar
`sqrt(nL log(e_tau/e_T))` type bound, which in general is dominated
by the old direct clock/degree-loss bounds. It is not a new payment.
The useful bounded output here is instead the once-only coordinate
ledger RE2/RE6 and explicit fee RE9--12, together with the exact
remaining joint-source integral RE13. No minimum source atom mass,
extra negative credit, or general root conclusion has been inserted.

No new numerical experiment is asserted here. The parent is selecting
the numerical diagnostics and independent review for this round.
