# R246：新增无权行界与出生责任检查

最终实际完成8例（初探2、压力4、扩大2），不重跑R245旧20例套件。采用其部分有限clock声明，但脚本完全自包含，不读取R245文件。只验证有限相关原子clock上的新策略和会计；不认证实际C阈值几何、L1输入、FULL、一般来源付款改进或渐近阶。

## 先定方案与实际范围

初探：n=2异score且无birth/delete，以及全部score=n。压力：n=4阈值出生、出生加删除、同刻birth/delete；另n=2开放终点，区分终点事件是否计入。扩大：n=16、128的异质阈值、质量和删除。全部tau=1；T为8/5或2。每个source的正有理质量、全部阈值及重复坐标数、delete时间均保存在JSON。各source完整纳入同一posterior，没有坐标独立假设或截断来源。

在所有阈值/删除处分片，并额外加入窗的1/3、2/3有理时间切点。该划分是合法time partition，不是实现first-passage degree-restart算法；不报告该算法最优性或lambda收费结论。每个birth按(left,right]唯一归属结束段，同刻先birth后delete；开放T不计T的birth/delete。tau事件已含在初始右连续状态。

## 实际结果

|配置|积分Dfull|旧min(Q,nL/4)|新min(Q-Q²/(nL),sqrt(LV/2))|
|---|---:|---:|---:|
|heterogeneous_no_birth|0.2076679764|0.3465735903|0.2941723082|
|all_scores_n|0|0.3465735903|0|
|births|0.09093232507|0.4700036292|0.1529215774|
|births_and_deletes|0.07337044547|0.4700036292|0.1387729630|
|coincident_birth_delete|0.07278041647|0.6931471806|0.1867452513|
|open_terminal|0.04761904762|0.3465735903|0.1284659655|
|heterogeneous_n16|0.4184318917|2.7725887222|1.0768244682|
|heterogeneous_n128|1.2775864605|5.8583423156|5.4715177388|

这些例子中新行费均较旧价小，但这不是一般来源预算已改善的证据。全score=n例体现确定score时D=V=0，旧粗界仍为正。高维出生仍保留归一化birth和删除责任，不能逐段重新收费n或删去birth的degree分母。

精确Fraction检查计数：46个正posterior中点，27个非零birth事件的唯一段归属，8个能量恒等账，8个方差恒等账。每个中点核D<=m(1-m/n)。分片上的能量由k[mu*w(left)-mu*w(right)]精确相加；方差由m(left)-m(right)精确相加。分别独立核：

- energy = initial score mass + raw births - terminal score mass - deleted active score mass；
- initial score mass + raw births <= n*e_tau；
- V = normalized births + m_tau - m_T + signed deletion mean jumps。

相邻段初始score只是继承已有score；全账只计一次initial score mass。删除mean跳保符号，并与连续变化分开。Q按log(e_tau/e_T)扣所有实际log(e_before/e_after)，同时独立积分m核对；未把删除jump称signed母式的连续反向流。

## 数值精度与复现

正式最终脚本实际运行完成一次（在加入方差恒等账后；之前初版也实际完成一次）。每例40/70位独立积分新增m和Dfull，按阈值/delete/额外时间切点及1/n尺度层细分。JSON以50有效位保存各工作精度输出，最大差为3.7216193071362858e-41，归一化分母max(1,abs(high))。这描述工作精度比较，不是区间包围或严格求积误差。精确事件账与上述Fraction不等式不依赖浮点。没有额外timing重跑；父级将作最终包外完整回放。

在解压后的同一目录（含numeric_checks.py和task_contract.md）执行：

```sh
PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor /Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 numeric_checks.py --contract task_contract.md --output replay.json
cmp numeric_checks.json replay.json
```

本机实际Python为3.12.14，上述bundled executable；mpmath 1.3.0来自上述vendor目录。本脚本只需Python标准库和mpmath，不需要numpy/scipy。JSON无runtime、时间戳或绝对输入输出路径，绑定源码和合同SHA256，CLI同时支持--output和--contract。默认输入合同为脚本相邻task_contract.md，默认输出numeric_checks.json。

冻结绑定：源码SHA256 `2c8a073c82d8e8fd51022a75d9bc678a4940ff3fb28bce5e223ebfbcaefa8fbd`；JSON 71302字节、SHA256 `9b97f06124377f7b900ec1f09630cd320d4b74037608b4411c161df23334f55d`；合同SHA256 `7888fc0ec96c31615956b79b2f7b039f8fb71ed05134c7c386c216a0de0456fe`。JSON counts键可供driver直接读取。
