#!/usr/bin/env python3
"""Exact minimum capacity for a zero-cost WHOLE surplus plan on frozen fields."""
from fractions import Fraction as F
from pathlib import Path
from collections import Counter,deque
from itertools import product
import json,sys,hashlib
BASE=Path(__file__).resolve().parent;COUNTS=Counter()
def ck(k,v):
 COUNTS[k]+=1
 assert v,k
def dot(a,b):return sum((F(x)*y for x,y in zip(a,b)),F(0))
def read(p):return json.loads((BASE/p).read_text())
def sha(p):return hashlib.sha256((BASE/p).read_bytes()).hexdigest()
def prepare():
 old=read('r378_numeric_input.json');cases=[]
 keep=['stage','name','n','receivers','A','volumes','source_mass','cells','omega','H','h','kappa','actual_W','original_diagonal','floor','surplus_diagonal']
 pkeep=['v','weight','d','source_cells','target_cells','row','U','L','K','cost']
 for c in old['cases']:
  z={k:c[k] for k in keep};z['plans']=[{k:p[k] for k in pkeep} for p in c['plans']];cases.append(z)
 data=dict(cases=cases,provenance={p:sha(p) for p in ['r378_numeric_input.json','r378_numeric_result.json']},scope='Frozen actual compact L1 source/target cells and all original finite diagnostic marks; receiver quadrature, not native hard traffic. Exact per-v minimum capacity and feasible whole surplus zero-cost plans. No new LP or general dimension claim.')
 (BASE/'r379_numeric_input.json').write_text(json.dumps(data,sort_keys=True,indent=2)+'\n');print('PREPARED minimal frozen fields; all42 v, no old certificates or old residual plans needed')
def fullmarks(c):
 n=c['n'];N=len(c['receivers']);A=c['A'];vol=list(map(F,c['volumes']));x=list(map(F,c['source_mass']));f=[a/b for a,b in zip(x,vol)];R=[F(r['R']) for r in c['receivers']];w=[F(r['weight']) for r in c['receivers']];centers=[list(map(F,r['center'])) for r in c['receivers']];m=[r**n for r in R];mu=[a/b for a,b in zip(w,m)];radii=sorted(set(R));h=F(c['h']);H=F(c['H']);kap=F(c['kappa']);omega=[list(map(F,row)) for row in c['omega']]
 ck('stage2_full_source_same_all_actual_matching',all(dot(row,x)==mass for row,mass in zip(A,m)) and sum(x)==F(c['actual_W']))
 expected=[[F(0)]*len(x) for _ in range(N)]
 for u in range(N):
  for y in range(len(x)):
   past=sum(mu[t]*A[t][y] for t in range(N) if m[t]<m[u]/kap)
   if past<=h:continue
   for l,r in enumerate(radii):
    if r<R[u]:continue
    J=sum(mu[t]*A[t][y] for t in range(N) if R[t]<=r)
    if J>=H:
     ell=r**(-n)-(radii[l+1]**(-n) if l+1<len(radii) else 0)
     expected[u][y]+=h*m[u]*ell/J
 ck('stage2_reconstructed_full_omega_J_past_clock',expected==omega)
 for p in c['plans']:
  v=p['v'];src=p['source_cells'];tgt=p['target_cells'];d=F(p['d']);rows=list(map(F,p['row']));cols=[d*F(u) for u in p['U']];K=[list(map(F,row)) for row in p['K']];L=list(map(F,p['L']));C=[list(map(F,row)) for row in p['cost']]
  ck('stage2_original_source_and_uniform_target_marginals',rows==[vol[y]*(f[y]-1)/m[v] for y in src] and cols==[d*vol[z]/m[v] for z in tgt] and sum(rows)==sum(cols)==d)
  Lv=[];Kv=[]
  for y in src:
   aa=[]
   for u in range(N):
    S=m[u]>kap*m[v] and 2*max(abs(a-b) for a,b in zip(centers[u],centers[v]))>R[u]
    aa.append(mu[u]*(1-m[v]/m[u])/h*omega[u][y]*A[u][y] if S else F(0))
   Lv.append(sum(aa));Kv.append([sum(aa[u]*A[u][z] for u in range(N)) for z in tgt])
  ck('stage2_one_common_objective_all_u_and_original_marks',Lv==L and Kv==K and C==[[L[i]-a for a in row] for i,row in enumerate(K)])
 return True

def zero_box(c,p,i):
 n=c['n'];rec=c['receivers'];v=p['v'];y=p['source_cells'][i];A=c['A'];R=[F(r['R']) for r in rec];m=[r**n for r in R];center=[list(map(F,r['center'])) for r in rec];omega=[list(map(F,row)) for row in c['omega']];kap=F(c['kappa']);C=list(map(F,p['cost'][i]));activeu=[]
 for u in range(len(rec)):
  if m[u]>kap*m[v] and 2*max(abs(a-b) for a,b in zip(center[u],center[v]))>R[u] and omega[u][y]*A[u][y]>0:activeu.append(u)
 lo=[max(center[u][d]-R[u]/2 for u in [v]+activeu) for d in range(n)];hi=[min(center[u][d]+R[u]/2 for u in [v]+activeu) for d in range(n)];volume=F(1)
 for a,b in zip(lo,hi):volume*=max(F(0),b-a)
 target=[]
 for j,z in enumerate(p['target_cells']):
  cell=[[F(a),F(b)] for a,b in c['cells'][z]]
  inside=all(lo[d]<=a and b<=hi[d] for d,(a,b) in enumerate(cell))
  ck('zero_box_cell_incidence_exact',inside==(C[j]==0))
  if inside:target.append(j)
 mass=sum(F(p['U'][j]) for j in target);ck('zero_box_positive_true_uniform_volume',volume>0 and mass==volume/m[v])
 return dict(source_row=i,source_cell=p['source_cells'][i],bounds=[[str(a),str(b)] for a,b in zip(lo,hi)],volume=str(volume),uniform_volume=str(mass),target_positions=target,target_source_cell_ids=[p['target_cells'][j] for j in target],defining_marked_receivers=activeu)
def exact_flow(rows,cols,zero):
 na=len(rows);nt=len(cols);S=0;T=1+na+nt;N=T+1;cap=[[F(0)]*N for _ in range(N)];BIG=sum(rows)+sum(cols)+1
 for i,r in enumerate(rows):cap[S][1+i]=r
 for i in range(na):
  for j in range(nt):
   if zero[i][j]:cap[1+i][1+na+j]=BIG
 for j,b in enumerate(cols):cap[1+na+j][T]=b
 res=[r[:] for r in cap];value=F(0);augment=0
 while True:
  parent=[None]*N;parent[S]=S;q=deque([S])
  while q and parent[T] is None:
   u=q.popleft()
   for v in range(N):
    if parent[v] is None and res[u][v]>0:parent[v]=u;q.append(v)
  if parent[T] is None:break
  v=T;path=[]
  while v!=S:path.append((parent[v],v));v=parent[v]
  amount=min(res[u][v] for u,v in path)
  for u,v in path:res[u][v]-=amount;res[v][u]+=amount
  value+=amount;augment+=1
 flow=[[cap[1+i][1+na+j]-res[1+i][1+na+j] if zero[i][j] else F(0) for j in range(nt)] for i in range(na)]
 ck('zero_transport_primal_feasible',all(a>=0 for row in flow for a in row) and all(sum(row)<=r for row,r in zip(flow,rows)) and all(sum(flow[i][j] for i in range(na))<=cols[j] for j in range(nt)) and sum(sum(row) for row in flow)==value)
 return value,flow,augment

def analyze(c,p):
 r=list(map(F,p['row']));U=list(map(F,p['U']));d=F(p['d']);C=[list(map(F,row)) for row in p['cost']];nr=len(r);nc=len(U)
 ck('original_source_marginal_and_uniform_target_normalizations',all(a>=0 for a in r) and sum(r)==d and all(a>0 for a in U) and sum(U)==1)
 if d==0:
  ck('zero_d_guard_source_is_zero',all(a==0 for a in r));return dict(v=p['v'],d='0',capacity_star='0',lower_certificate=dict(type='zero_source_minimum_nonnegative_capacity',ratio='0'),whole_plan=[['0']*nc for _ in range(nr)],whole_cost='0',active_rows=[],free_rows=list(range(nr)),hall_ratios=[],zero_geometry=[])
 active=[i for i,row in enumerate(C) if any(a>0 for a in row)];free=[i for i,row in enumerate(C) if all(a==0 for a in row)];boxes=[zero_box(c,p,i) for i in active];star=F(1);best=dict(type='total_target_mass',source_demand=str(d),base_capacity=str(d),ratio='1');cuts=[]
 ck('free_rows_have_full_zero_target_neighborhood',all(all(a==0 for a in C[i]) for i in free))
 for bits in product([0,1],repeat=len(active)):
  subset=[i for i,b in zip(active,bits) if b];neighbors=[j for j in range(nc) if any(C[i][j]==0 for i in subset)];demand=sum(r[i] for i in subset);volume=sum(U[j] for j in neighbors);den=d*volume
  if subset:
   ck('nonempty_active_hall_subset_positive_neighbor_volume',den>0);ratio=demand/den
  else:ratio=F(0)
  witness=dict(type='active_hall_subset',source_rows=subset,target_positions=neighbors,target_cell_ids=[p['target_cells'][j] for j in neighbors],source_demand=str(demand),neighbor_uniform_volume=str(volume),base_capacity=str(den),ratio=str(ratio));cuts.append(witness)
  if ratio>star:star=ratio;best=witness
 ck('star_dominates_every_active_hall_ratio',star>=1 and all(F(a['ratio'])<=star for a in cuts))
 ck('sharp_capacity_lower_witness',F(best['ratio'])==star and (best['type']=='total_target_mass' or F(best['source_demand'])==star*F(best['base_capacity'])))
 zero=[[a==0 for a in row] for row in C];targetcap=[star*d*u for u in U];flowvalue,T,augment=exact_flow(r,targetcap,zero)
 ck('whole_source_all_rows_exact_not_only_active',flowvalue==d and [sum(row) for row in T]==r)
 ck('whole_plan_zero_cost_and_exact_target_cap',sum(T[i][j]*C[i][j] for i in range(nr) for j in range(nc))==0 and all(sum(T[i][j] for i in range(nr))<=targetcap[j] for j in range(nc)))
 ck('capacity_star_exact_lower_and_constructive_upper',star==F(best['ratio']) and flowvalue==d)
 return dict(v=p['v'],weight=p['weight'],d=str(d),capacity_star=str(star),active_rows=active,free_rows=free,lower_certificate=best,hall_ratios=cuts,zero_geometry=boxes,whole_plan=[list(map(str,row)) for row in T],target_capacity=list(map(str,targetcap)),target_used=list(map(str,[sum(T[i][j] for i in range(nr)) for j in range(nc)])),source_mass=list(map(str,r)),whole_cost='0',augmentations=augment)
def verify():
 data=read('r379_numeric_input.json');summ=[];certs=[];total=0
 for c in data['cases']:
  fullmarks(c);local=[]
  for p in c['plans']:
   cert=analyze(c,p);cert['name']=c['name'];certs.append(cert);local.append(dict(v=p['v'],capacity_star=cert['capacity_star']));total+=1
  largest=max(F(a['capacity_star']) for a in local);G=F(c['original_diagonal']);floor=F(c['floor']);S=F(c['surplus_diagonal'])
  ck('actual_zero_bad_template_account',G==floor+S)
  ck('observed_capacity_four_suffices_all_receivers',largest<=4)
  summ.append(dict(stage=c['stage'],name=c['name'],n=c['n'],actual_source_W=c['actual_W'],receiver_count=len(c['receivers']),zero_d_receiver_count=sum(F(p['d'])==0 for p in c['plans']),source_cells=len(c['volumes']),all_capacity_stars=local,largest_capacity_star=str(largest),capacity_two_zero_plan_possible_for_all=largest<=2,capacity_four_zero_plan_possible_for_all=largest<=4,original_G=str(G),invariant_floor=str(floor),zero_bad_actual_floor_plus_good=str(G)))
 ck('all42_receiver_plans_present',total==42)
 out=dict(status='PASS',exact_grouped_checks=sum(COUNTS.values()),check_counts=dict(COUNTS),summary=summ,whole_plan_certificates=certs,scope=data['scope'],provenance=data['provenance'])
 (BASE/'r379_numeric_result.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k!='whole_plan_certificates'},sort_keys=True,indent=2))
if __name__=='__main__':prepare() if len(sys.argv)>1 and sys.argv[1]=='prepare' else verify()
