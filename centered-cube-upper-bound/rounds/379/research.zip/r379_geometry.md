# R379 — Paying shallow truncation and retaining only exponentially small geometric overlap

## 1. Exact all-pair partition and result

Keep the complete R378/R377 actual field and plan: full f, actual Lebesgue du and dv, m_u=f(Q_u)=q_uR_u^n, q_-≤q_u≤λ, a≤R≤b≤2a, the original far-mass/outside/not-Bplus masks, source-dependent J, strict past, H, physical clock and h. A current cap-2 plan τ_v has source marginal
\[
 \mu_v^+(dy)={(f(y)-q_v)_+c_v(y)\over m_v}dy.
\]
No plan is reselected in this proof.

On any contributing far-mass pair with I_uv=f(Q_u∩Q_v)>0, put
\[
 r={R_v\over R_u}\in[1/2,1),\quad
 x_i={|u_i-v_i|\over R_u},\quad
 d_i={\big(x_i-(1-r)/2\big)_+\over r}. \tag{1}
\]
Positive overlap ensures 0≤x_i<(1+r)/2<1 and 0≤d_i<1. The exact geometric overlap fraction is
\[
 p_{uv}={|Q_u\cap Q_v|\over R_v^n}=\prod_{i=1}^n(1-d_i). \tag{2}
\]
Pairs with I_uv=0 carry zero cost by source exactness and can be omitted.

Define SH={Σ_i d_i≤n/20} and DEEP={Σ_i d_i>n/20}. These partition every contributing pair without changing any old gate. Write κ=753/800<1. The new receipt is
\[
 \boxed{G_{\rm SH}(\tau)\le{\kappa^n\over h}|E|
 \le{\varepsilon_0\kappa^n\over1+\sqrt n}X_q.} \tag{3}
\]
There is no new W fee and no change of target cap. Every pair left in DEEP obeys
\[
 \boxed{p_{uv}<e^{-n/20}.} \tag{4}
\]
This is a geometric Lebesgue overlap conclusion only. It does not imply that I_uv/m_v is small for arbitrary f.

## 2. A selector-uniform coordinate envelope

For x∈[0,1] define
\[
 \phi(x)=
 \begin{cases}
 0,&0\le x\le1/4,\\
 2x-1/2,&1/4\le x\le1/2,\\
 x,&1/2\le x\le1.
 \end{cases} \tag{5}
\]
For every r∈[1/2,1],
\[
 { (x-(1-r)/2)_+\over r}
 =\big[1/2+(x-1/2)/r\big]_+\ge\phi(x). \tag{6}
\]
Indeed when x≤1/2 the expression before the positive part is minimized at r=1/2; when x≥1/2 it is minimized at r=1. These yield (5), including the two joins. The endpoint r=1 is used only for a valid lower bound; the actual far-mass radius ratio is strictly less than one.

Formula (2) follows directly from one-dimensional interval overlap: the smaller interval has lost fraction d_i, since the larger interval cannot cut both ends when R_u≥R_v. Taking a product of interval lengths concerns Lebesgue volume of a box; it asserts no coordinate independence of f or of the actual receiver selector.

Fix u. Normalize an actual receiver center by v=u+R_u z, so x_i=|z_i|. Every positive-overlap center lies in [-1,1]^n in these coordinates. By (6), its SH condition implies Σφ(|z_i|)≤n/20. Hence
\[
\begin{aligned}
 |\{v\in E:I_{uv}>0,\ R_v<R_u,\ {\rm SH}\}|
 &\le R_u^n\,|\{z\in[-1,1]^n:\sum_i\phi(|z_i|)\le n/20\}|\\
 &\le R_u^n\left[e^{8/20}
        \int_{-1}^1e^{-8\phi(|x|)}dx\right]^n. \tag{7}
\end{aligned}
\]
The last inequality uses 1_{s≤n/20}≤exp(8n/20−8s), followed by the product Lebesgue integral of this explicit envelope. The actual field R_v may be any measurable selector. No integral over an independent radius is introduced.

## 3. Exact integral and rigorous rational constants

Direct integration over the three pieces of φ gives
\[
\begin{aligned}
 I&:=\int_{-1}^1e^{-8\phi(|x|)}dx\\
 &=\frac12+\frac{1-e^{-4}}8+\frac{e^{-4}-e^{-8}}4\\
 &=\frac12+\frac{1+e^{-4}-2e^{-8}}8. \tag{8}
\end{aligned}
\]
The negative last term is correctly retained in the identity and may be dropped for an upper bound.

The following rational Taylor certificates fix all constants without a floating fit:
\[
 e^4>\sum_{j=0}^{7}{4^j\over j!}={16319\over315}>50,
\]
so e^{-4}<1/50 and therefore I<251/400. Also, for x=2/5,
\[
 e^x<
 \sum_{j=0}^4{x^j\over j!}
 +{x^5/5!\over1-x/6}
 ={97901\over65625}<\frac32. \tag{9}
\]
The tail bound in (9) follows because all successive ratios after the first omitted term are at most x/6<1. Thus
\[
 e^{2/5}I<\frac32\,\frac{251}{400}
 =\frac{753}{800}=\kappa<1. \tag{10}
\]
Combining (7) and (10) proves the all-dimensional actual-center capacity
\[
 \boxed{|\{v\in E:I_{uv}>0,\ R_v<R_u,\ {\rm SH}\}|
 \le R_u^n\kappa^n.} \tag{11}
\]
The estimate is valid in every dimension, including small dimensions. It bounds plain dv/R_u^n, not μ(dv).

On DEEP, log(1-d_i)≤−d_i gives (4). If a geometric overlap vanishes, p=0 and the conclusion remains valid, although such a pair already has zero source cost. No lower bound on individual d_i or on the number of deep coordinates is needed: only their actual sum is used.

## 4. Exact original-plan payment and the plain-dv cancellation

Let A_uv be the unchanged far-mass/outside/not-Bplus factor times 1−m_v/m_u. In particular 0≤A_uv≤1 and R_v<R_u on its support. The original cost restricted to SH is
\[
 G_{\rm SH}(\tau)=
 \int_E{du\over hR_u^n}\int_Edv\,A_{uv}1_{\rm SH}
 \int\omega_u(y)c_u(y)(1-c_u(z))\,\tau_v(dy,dz). \tag{12}
\]
The original
\[
 \omega_u(y)=hR_u^n\int_{[R_u,b]}\ell(ds)
 {1_{J_y(s)\ge H}1_{Z_y(m_u/K-)>h}\over J_y(s)}
\]
is kept in this exact formula. Strict mass past lies inside every radius prefix s≥R_u, so the retained denominator exceeds h. The complete physical clock, including its terminal atom, has tail R_u^{-n}. Consequently 0≤ω_u≤1.

Now integrate the true source marginal:
\[
 \int\omega_uc_u(y)(1-c_u(z))\,d\tau_v
 \le\mu_v^+(Q_u)
 \le{I_{uv}\over m_v}\le1. \tag{13}
\]
It is zero when I_uv=0. Full matching m_v=f(Q_v) is what cancels the small-receiver normalization. Inserting (13) into (12) leaves plain dv, allowing (11):
\[
 G_{\rm SH}\le
 \int_E{du\over hR_u^n}
 |\{v:I_{uv}>0,\ R_v<R_u,\ {\rm SH}\}|
 \le\kappa^n|E|/h.
\]
Finally |E|≤X_q/q_- and the fixed h=(1+√n)/(ε₀q_-) give (3). This proves payment for the actual source-exact plan, not a surrogate product plan. The target cap is unused in this local proof and remains unchanged in the surrounding ledger.

## 5. Exact incorporation after R378, with no duplicated payment

For the pre-R378 remainder, SH and DEEP alone give the complete split G=G_SH+G_DEEP and the new fee (3). To retain the R378 sparse payment as well, split into DISJOINT pieces:
\[
 G=G_{\{j\le\lfloor n/8\rfloor\}}
   +G_{\{j>n/8\}\cap{\rm SH}}
   +G_{\{j>n/8\}\cap{\rm DEEP}}. \tag{14}
\]
The first term is already priced by R378, the second is bounded by (3), and the exact remaining kernel has
\[
 j>n/8,\qquad\sum_i d_i>n/20,\qquad p_{uv}<e^{-n/20}, \tag{15}
\]
as well as ALL original far-mass, outside, not-Bplus and source/history gates. Equality at the shallow threshold belongs to the paid piece.

Denote this remaining actual cost by G_rem. Keeping the same complete cap-2 plan and all frozen fields, the hard ledger is
\[
 B_H\le G_{\rm rem}
 +\varepsilon_0\!\left[
 2+{C_n^++3\Gamma_n+\widehat b_n+\kappa^n\over1+\sqrt n}
 \right]X_q+C_{338}W. \tag{16}
\]
Here \widehat b_n is exactly R378's already certified sparse coefficient. There is no additional W tariff; the target-template term remains 3Γ_n. In the full entrance the new receiver fee is precisely
2Λε₀κ^n/(1+√n)X_q. Original entrance terms, C338, H and h remain unchanged. Any later change of ε₀ requires the usual synchronized rebuilding of h-dependent fields and fees.

The R377 joint-Hardy M1 estimate may then be applied to this restricted original kernel, with its actual S_rem, lost-source active set, and capture Cap_rem:
\[
 G_{\rm rem}\le
 S_{\rm rem}+\varepsilon X_q+
 \lambda\log{\lambda\over\varepsilon q_-}\Xi_{A,\rm rem}
 -\operatorname{Cap}_{A,\rm rem}. \tag{17}
\]
Only this actual remaining capture is deducted. No sparse/shallow capture or older return credit is recharged.

## 6. What is and is not proved

The new result pays every actual pair with small total fractional truncation, including pairs having many nonzero but individually shallow faces. It therefore improves the R378 dense remainder: every surviving pair now has exponentially small geometric overlap.

For arbitrary full f, small p_uv does not bound I_uv/m_v or the source-weighted shared loss. No inequality I_uv≤constant·p_uv m_v is assumed. In particular, (15) alone does not pay the remaining M1 balance (17). That source/matching budget remains open; the present proof makes its geometric domain explicit without changing the source law or dropping history marks.

## 7. Actual three-stage local verification

Run locally on 2026-10-18:
python3 /tmp/r379_geometry_check.py

Output:
PASS {'coordinate_geometry': 952, 'rational_constants': 8, 'overlap_product': 120, 'small_dim_body': 10, 'source_payment': 60} total 1150
CERTIFICATES exp4> 16319/315 exp(2/5)< 97901/65625 base< 753/800

Stage 1 checks the exact interval-length formula and lower envelope on a rational grid of common radius ratios and centers; it also checks product-overlap bounds using rigorous rational exponential upper bounds. Stage 2 verifies the rational Taylor certificates, the piecewise integral algebra, and ten exact small-dimensional lower-envelope sublevel volumes. Stage 3 checks source exactness, target cap 2, full-f mass normalization, and conversion to the plain-center payment in sixty finite quadrature plans.

These diagnostics use Fraction arithmetic throughout. They do not claim to be native high-past Lebesgue examples. The universal measurable-selector estimate, full-clock use, and general-field payment are proved analytically above. The script is /tmp/r379_geometry_check.py.
