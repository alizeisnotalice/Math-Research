# R379 — exact minimum capacity for zero-cost whole surplus plans

## Result and finite decision

All 42 original v have an exact minimum capacity c* and an explicit zero-cost **whole surplus** plan at that capacity, including free source rows. The sharp values are:

| Frozen field | v with c*>1 (zero-based) | Their exact c* | All other v | Maximum |
|---|---|---|---|---:|
| Equal 15 intervals | 1,6,12,13 | 2,2,2,2 | 1 | 2 |
| Weighted 15 intervals | 1,6,12,13 | 2,2,2,2 | 1 | 2 |
| Twelve 2D cubes | 1,7 | 30/11,57/17 | 1 | 57/17 |

Every value is independently certified below and constructively attained by a rational full-source max flow. All 42 values, not merely these maxima, are saved in the result. In particular, the R378 cap2 geometric obstruction is removed on these fixed models by capacity augmentation to at most 57/17<4. This explains the earlier capacity-four experiment with a sharp threshold, rather than just confirming a tested integer capacity.

This is finite geometric feasibility evidence only. It does not show that arbitrary dimensions, sources or native hard fields admit a constant or logarithmic capacity bound, and it does not price any general capacity-dependent template.

## Frozen real-source and full-mark contract

The three actual compact piecewise-constant L1 sources, all receiver matching q=1 and m=R^n, receiver cubes, source labels, full finite ω/J/strict-past marks and original clock remain unchanged from R378. The script reconstructs those marks and every common original cost C_v(y,z)=L_v(y)−K_v(y,z) before solving anything.

There are 15,15,12 receiver quadrature points, 16,16,208 complete positive-volume source cells, and actual total source masses 4,4,33/4. Receiver weights are finite positive quadrature, not Lebesgue dx. Original diagnostic κ=6/5, H=h=1/16 in 1D and 1/64 in 2D remain; no native high-dimensional gate/history realization is claimed.

For each v the plan's source is the entire original surplus μ_v^+=(f−1)_+c_v dy/m_v, of mass d_v. It is not the whole original f: “whole” here distinguishes the full surplus marginal, including its free rows, from R378's active-only partial transport. The target cap is c d_vU_v, with the original uniform U_v on actual Q_v. The original floor is kept separately.

## Sharp lower certificate

Call a source row active if its complete cost row has some positive entry; free means every entry is zero. At most two source rows are active in any v. For every subset I of active rows, let N(I) be the union of all their actual zero-cost target cells. Compute exactly

    ratio(I) = [Σ_{i∈I}r_i] / [d_v U_v(N(I))],
    c* = max(1, max_I ratio(I)).

Every nonempty active subset has positive neighbor volume in these inputs. Its full zero set is independently reconstructed as the actual cube intersection Q_v∩⋂Q_u over original positive marked contributions; all complete target-cell memberships and volumes are checked. The source is not replaced by points, and zero target cells are not discarded where f=0.

A zero-cost whole plan must route all demand in I into N(I), so c≥ratio(I). Total source mass also forces c≥1. Any source subset containing a free row has the full target set as its neighborhood, so its ratio is at most d_v/d_v=1 and cannot create an omitted larger constraint. Thus enumerating active subsets suffices for the lower bound. The maximizing cut or total-mass witness is saved for every v.

At d_v=0 the implementation returns the genuine minimum c*=0 over nonnegative capacities, with a zero source and zero plan; it does not label the max-with-one formula sharp there. All 42 actual input v have d_v>0, as recorded by zero_d_receiver_count=0 in each case. Thus this guard is not presented as an exercised zero-d fixture. For every tested positive d_v, total target capacity proves c*≥1.

## Whole-source constructive upper certificate

The script builds a new exact Fraction network using **all** original surplus rows, active and free:

- source capacities r_i;
- zero-cost source→target edges iff C_ij=0;
- target capacities c* d_vU_j.

Rational augmenting paths give a feasible plan. It is then checked that total flow=d_v, **every** row sum equals its original r_i, every target column is within its exact capacity, and the original C cost is exactly zero. The lower witness and attained upper agree, proving that each reported c* is the exact minimum. This is not a source inequality relaxation or an active-only flow passed off as a whole plan.

Every matrix plan defines a constant coupling density on its positive-volume source-cell × target-cell product. The exact source marginal and target cap therefore hold for the underlying continuous source/target cells, not just at sample locations. Receiver integration remains quadrature.

## Independent 2D calculation

The two nontrivial receivers have side 3/2. Their zero-cost boxes are

    v=1: [−1/4,0]×[−3/4,3/4],
    v=7: [0,1/4]×[−3/4,3/4].

Each has true area 3/8 and U_v volume 1/6. The exact ratios are

    v=1: (5/12) / [(11/12)(1/6)] = 30/11,
    v=7: (19/36) / [(17/18)(1/6)] = 57/17.

These use actual surplus source demands 5/12 and 19/36, and actual d_v=11/12,17/18. The saved whole plans also place every free row within the remaining capacity. Thus the larger sharp threshold is 57/17, not merely an upper value inferred from a previous LP status.

At these capacities all coupling bad costs vanish. Original G remains positive and unchanged; the actual sample floor+good equals original G: 41/4224, 143287/11128320, and 1099/310080. This is an exact decomposition identity, not a statement that the original traffic vanishes or that a general enlarged template is free.

The geometric decision is precise: cap2 is genuinely insufficient for these two 2D v, yet a finite augmentation removes their deficit. A general proof would need to bound analogous Hall ratios while paying its capacity-dependent receipt. Nothing here bounds those ratios outside the three samples.

## Execution and portable evidence

Actual local Python execution, followed by a fresh process rerun, passed **579 exact grouped assertions**. These include all 42 whole-source flow certificates, all 42 sharp lower witnesses, 14 nonempty active-subset ratios, twelve actual positive zero boxes and 120 target-cell geometry comparisons, as well as full original mark reconstruction. There are no floating/Decimal tests, no new MATLAB calls, and no old LP reruns.

The first standalone run exposed a missing redundant `col` field after minimizing the snapshot. The verifier now derives that field exactly as d_vU_v rather than storing it; the final self-contained version is what passed the fresh runs. This was a serialization-interface correction, not a changed mathematical input or feasibility repair.

Standalone files: `r379_numeric.py`, `r379_numeric_input.json`, `r379_numeric_result.json`, and these notes. Run:

    /Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 r379_numeric.py

The minimal input omits old LP candidates, duals, and retained/refill plans. It stores only the frozen actual fields/cells/costs needed for reconstruction. The result stores every exact c*, Hall-ratio witness, zero-box geometry and full zero-cost plan. Optional prepare reads frozen R378 input/result with SHA256 provenance; verify reads no older temporary files. No old file or repository is edited.

Scope: real positive-volume L1 source and target cells with full frozen diagnostic marks, finite receiver quadrature rather than dx, not native hard gates or an all-input root theorem. The minimum-capacity conclusion is exact for the declared finite models and is not generalized by fitting their dimensions.
