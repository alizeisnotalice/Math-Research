from fractions import Fraction as F
from math import factorial, comb
counts={'coordinate_geometry':0,'rational_constants':0,'overlap_product':0,'small_dim_body':0,'source_payment':0}
def phi(x):
    return F(0) if x<=F(1,4) else 2*x-F(1,2) if x<=F(1,2) else x
def exp_upper(x,N=80):
    partial=sum((x**j/factorial(j) for j in range(N+1)),F(0))
    assert x<N+2
    return partial+x**(N+1)/factorial(N+1)/(1-x/F(N+2))
# Stage 1: exact coordinate geometry, common radius, and overlap product.
for ir in range(17):
 r=F(1,2)+F(ir,32)
 for ix in range(65):
  x=F(ix,64)
  if x>=(1+r)/2:continue
  d=max(x-(1-r)/2,F(0))/r
  length=max(F(0),min(F(1,2),x+r/2)-max(-F(1,2),x-r/2))
  assert 0<=d<1 and d>=phi(x) and length/r==1-d
  counts['coordinate_geometry']+=1
for n in range(1,13):
 for seed in range(10):
  r=F(1,2)+F(seed%5,10)
  xs=[F((j*3+seed)%11,12)*(1+r)/2 for j in range(n)]
  ds=[max(x-(1-r)/2,F(0))/r for x in xs]
  p=F(1)
  for d in ds:p*=1-d
  S=sum(ds)
  if S: assert p*exp_upper(S)<=1
  else: assert p==1
  counts['overlap_product']+=1
# Stage 2: rational exponential certificates; no floating point.
e4lower=sum((F(4**j,factorial(j)) for j in range(8)),F(0))
assert e4lower==F(16319,315)>50
counts['rational_constants']+=1
e04upper=exp_upper(F(2,5),4)
assert e04upper==F(97901,65625)<F(3,2)
counts['rational_constants']+=1
Iupper=F(1,2)+(1+F(1,50))/8
assert Iupper==F(251,400)
assert F(3,2)*Iupper==F(753,800)<1
counts['rational_constants']+=1
# The piecewise antiderivative is checked as a polynomial in t=e^-4:
# 1/2+(1-t)/8+(t-t^2)/4 = 1/2+(1+t-2t^2)/8.
for t in (F(0),F(1,100),F(1,50),F(1,2),F(1)):
 assert F(1,2)+(1-t)/8+(t-t*t)/4==F(1,2)+(1+t-2*t*t)/8
 counts['rational_constants']+=1
# For n<=10 the envelope sublevel has only the first linear ramp:
# exact cube-plus-l1-simplex volume, before the x=1/2 slope change.
for n in range(1,11):
 t=F(n,20)
 volume=sum((F(comb(n,j),2**(n-j))*t**j/factorial(j)
             for j in range(n+1)),F(0))
 assert volume<=F(753,800)**n
 counts['small_dim_body']+=1
# Stage 3: source-exact plan to plain-center payment, finite exact quadrature.
# The masks here test the algebraic interface; not a native high-past field.
for seed in range(60):
 f=[F(1+(j*3+seed)%9,3) for j in range(8)]
 dy=[F(1,4)]*8
 intervals=[(0,2),(1,4),(2,6),(0,6),(1,8),(0,8)]
 c=[[int(lo<=j<hi) for j in range(8)] for lo,hi in intervals]
 R=[sum(dy[j]*c[i][j] for j in range(8)) for i in range(6)]
 m=[sum(f[j]*dy[j]*c[i][j] for j in range(8)) for i in range(6)]
 q=[m[i]/R[i] for i in range(6)]
 du=[F(1+(i+seed)%4,7) for i in range(6)]
 h=F(2); total=F(0); bound=F(0); plans=[]
 for v in range(6):
  U=[dy[z]*c[v][z]/R[v] for z in range(8)]
  src=[dy[y]*c[v][y]*max(f[y]-q[v],F(0))/m[v] for y in range(8)]
  d=sum(src); anchor=(v+seed)%6
  rbar=sum(U[z]*c[anchor][z] for z in range(8))
  plan=[[src[y]*U[z]*(1+F((y+seed)%3,2)*(c[anchor][z]-rbar))
         for z in range(8)] for y in range(8)]
  assert all(sum(row)==src[y] for y,row in enumerate(plan))
  assert all(sum(plan[y][z] for y in range(8))<=2*d*U[z] for z in range(8))
  plans.append(plan)
 for u in range(6):
  V=F(0)
  for v in range(6):
   mask=m[u]>F(3,2)*m[v] and R[u]>R[v] and (u+v+seed)%3!=0
   if not mask:continue
   overlap=sum(f[y]*dy[y]*c[u][y]*c[v][y] for y in range(8))
   if overlap==0:continue
   V+=du[v]
   A=1-m[v]/m[u]
   term=sum(plans[v][y][z]*F((u+y+seed)%5,4)*c[u][y]*(1-c[u][z])
            for y in range(8) for z in range(8))
   assert term<=overlap/m[v]<=1
   total+=du[u]*du[v]*A*term/(h*R[u])
  bound+=du[u]*V/(h*R[u])
 assert 0<=total<=bound
 counts['source_payment']+=1
print('PASS',counts,'total',sum(counts.values()))
print('CERTIFICATES', 'exp4>',e4lower,'exp(2/5)<',e04upper,'base<',F(753,800))
