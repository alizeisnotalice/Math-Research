# R379 independent audit — FINAL PASS

Status: FINAL PASS for the bounded claims and final reviewed bytes below. Owner scope: only this audit file, no repository/author edits. Independent screens preceded the relevant author proofs; full author/code/numeric and final integration review are complete. The original per-pair low-density observation is qualified as absolute only, and the final source localization uses its fully priced identity plan. No general root closure or uniform covered fraction is certified.

## Original normalized geometry and its correct support

Keep the frozen full-f field,actual Lebesgue E,original q/m/J/H/strict past and full physical clock. Any new complete plan must have first marginal mu_v^+=(f-q_v)_+c_v dy/m_v=d_vP_v, d_v<=1. Let R=R_u, r=R_v/R in[1/2,1], x_i=|v_i-u_i|/R. The true smaller-cube overlap fraction is

p_uv=product_i(1-d_i)_+,
d_i=(x_i-(1-r)/2)_+/r.

On original nonzero source traffic I_uv=f(Q_u intersect Q_v)>0, every x_i<(1+r)/2<=1 and0<=d_i<1, so p=product(1-d_i) without extra positive parts. Without this overlap support the unclipped product could be negative and the finite-domain Laplace integral below would not apply as written. Since f is L1,cube-boundary or zero-volume overlaps have zero source mass. Radius selection remains one actual measurable scalar r(v), not independently optimized coordinate radii.

The exact lower envelope over r in[1/2,1] is

phi(x)=0 for0<=x<=1/4;
phi(x)=2x-1/2 for1/4<=x<=1/2;
phi(x)=x for x>=1/2.

For x>the containment threshold, d_r(x)=1/2+(x-1/2)/r. Its derivative in r has the sign of1/2-x. Thus the minimizing endpoint is r=1/2 for x<=1/2 and r=1 for x>=1/2; the zero region is exactly x<=1/4. This proves phi<=d for every actual r, including both ratio endpoints. No source product or coordinate independence is used.

## Selector-uniform shallow-center capacity and exact constant

Let shallow mean sum_i d_i<=n/20, and retain the original I_uv>0 support. Then sum phi(x_i)<=n/20. Exponential Markov with parameter8 gives the deterministic indicator bound

1_shallow <= exp(2n/5)*product_i exp(-8phi(x_i)).

Integrate actual receiver centers v only, after rescaling by R. Their possible overlap centers lie inside[-1,1]^n. Positive Fubini gives

volume(shallow actual centers)/R^n
<= [exp(2/5)*2 integral_0^1 exp(-8phi(x))dx]^n
= [exp(2/5)*(1/2+(1+exp(-4)-2exp(-8))/8)]^n
<= (753/800)^n=:c_n.

The three pieces of the one-dimensional integral are a flat interval, a slope-two ramp and a slope-one ramp. The negative2exp(-8) term comes from the FINITE endpoint x=1; it must not be retained when integrating over all R without the overlap-support restriction. One may use a weaker infinite-domain bound instead, but that is a different constant. The separation in this volume calculation is a uniform upper envelope for actual center Lebesgue measure, not an assertion about f or the selected radius distribution.

Elementary rational certificates suffice for the final bound: exp(2/5)<3/2 follows from its degree4 positive Taylor sum plus a geometric tail bound whose ratio is at most1/15; exp(4)>50 follows from its degree7 positive Taylor sum. Dropping the negative term gives

(3/2)*(1/2+(1+1/50)/8)=753/800<1.

No decimal fitting or asymptotic estimate is needed, and the proof covers all integer n>=1.

## Actual source-exact payment and old-family accounting

For ANY source-preserving complete common plan tau_v, the original positive bad cost on shallow pairs is

G_shallow=(1/h) integral_E du/R_u^n integral_E dv A_uv1_shallow
 integral omega_u(y)c_u(y)(1-c_u(z))dtau_v(y,z).

All original marks and full physical clock stay fixed. Only after writing this exact integral use0<=omega<=1 and source exactness to bound the inner integral by mu_v^+(Q_u)<=I_uv/m_v<=1; it vanishes if I_uv=0. The remaining measure is PLAIN dv/R_u^n, not dmu_v. Consequently

G_shallow<=c_n|E|/h<=epsilon0*c_n*X_q/(1+sqrt(n)).

There is no new W fee, no source density cap and no altered target/source law. The estimate is valid regardless of the target cap, so a legal enlarged-cap layered plan may use it with its separately synchronized full template price. At fixed h the new family may be split from the same actual old remainder, or a new common plan may be built for the complementary cost and THEN its full shallow part paid. Different-plan remainders cannot be substituted merely by an ordering argument.

The shallow family DOES NOT automatically contain all R378 sparse-protrusion pairs: j<=n/8 still permits sum d_i as large as n/8. Conversely shallow pairs may have many tiny protrusions. To preserve both already paid families, split the same plan on sparse OR shallow, with complement dense AND deep, and one valid upper coefficient is(bhat_n+c_n)*epsilon0/(1+sqrt(n)). A finer union bound could improve this, but adding a new shallow receipt does not justify silently dropping the old sparse restriction or counting either paid branch twice.

## Deep complement: uniform overlap versus actual source mass

On positive-overlap deep pairs,sum d_i>n/20 and log(1-d)<=-d give

p_uv<exp(-n/20).

This is the UNIFORM smaller-cube overlap fraction, not f(Q_u intersect Q_v)/m_v. With any fixed pair threshold T_v=q_v exp(n/40), the original low-density source contribution obeys the exact ABSOLUTE bound

(1/m_v) integral_{Q_u intersect Q_v} f(y)1{f(y)<=T_v}dy
<=exp(n/40)*p_uv<exp(-n/40).

The same upper bound holds for surplus source and for its original marked bad subtraffic, since(f-q_v)_+<=f and all extra marks are in[0,1]. Source density remains evaluated at the ORIGINAL y, and T_v depends on the ACTUAL original q_v. All high-density source contributions must be retained with full marks; an L1 assumption alone gives no input-uniform decay at this dimension-dependent threshold.

The bound is per pair and ABSOLUTE. It does not state that a majority or any fixed fraction of that pair's actual source is high density unless there is also an actual overlap/source-mass lower bound. If alpha_pair=mu_v^+(Q_u), the valid high-density lower bound is(alpha_pair-exp(-n/40))_+. A relative conclusion needs a positive lower threshold on alpha_pair. Moreover an absolute per-pair small number cannot be integrated as a fraction of the ORIGINAL G without a genuine joint pair-load/capacity estimate. The crude possible-center volume is2^n R_u^n, so naive full integration of this bound alone could lose an exponential factor. No such global payment has been proved in this screen.

Thus the low-density observation is an exact retained source decomposition/threshold interface, not automatically an additional absorbable error or a proof that arbitrary L1 inputs are harmless. Outside/notBplus,highpast,J and physical-clock masks must remain in the unpaid high-density and any unpriced low-density remainder.

## Actual reviewer arithmetic and status

Reviewer actually ran5151 rational grid cases for phi<=d at ratio endpoints and intermediate actual r values, plus3 exact rational exponential-series/constant certificates. These are scalar checks, not a numerical proof of the continuous envelope or native highpast realization; the analytic arguments above give those bounded claims. No R379 author proof had been read at that independent screen. Completed author and final accounting review follows. Original entrance/soft/history/scale and limit obligations remain unpaid.

## Additional independent screen: exact low-density identity plan

The proposed auxiliary plan passes, with its full enlarged tariff. Fix T>=1 independent of original source labels except through actual q_v, and split the original surplus measure into mu_low=1{f<=Tq_v}mu_v^+ and mu_high=1{f>Tq_v}mu_v^+, of mass d_H for the high part. Then mu_low<=(T-1)U_v as measures, because (f-q_v)_+1_low<=(T-1)q_v and m_v=q_vR_v^n. Let tau_low(dy,dz)=mu_low(dy)delta_y(dz). In the ORIGINAL common kernel, K_v(y,y)=L_v(y) exactly from c_u(y)^2=c_u(y). Thus C_v(y,y)=0 pointwise wherever the original finite kernels are defined, and this singular diagonal plan really has zero bad cost. It is NOT justified merely by a product-a.e zero statement.

Complete the HIGH source by an actual measurable common plan tau_H with exact source mu_high and target<=t*d_H U_v. Then tau_low+tau_H has the FULL original surplus source marginal, target<= (T-1+t*d_H)U_v, and all bad cost comes from tau_H. Every m/q/f/J/H/past/omega is still defined from the complete original input; the high density gate is a mark on the transport source, not a new matching field. Normalization d_H=0 is handled without dividing by it.

For each original pair the coarse floor+good bound is

p+(T-1+t*d_H)p=(T+t*d_H)p<=(T+t)p.

Thus its actual template charge is(T+t)Gamma, not(t+1)Gamma plus an unpaid identity plan, and not a target cap proportional to the original full d_v unless separately proved. With the proposed T=1+ceil(log_2(n+2)),this is a fixed logarithmic enlargement; epsilon0/h/C338 and the number-of-layers preallocation must be synchronized with that tariff. The same original full-source sparse/shallow positive bounds can apply to the COMPLETED plan, because it is source exact.

This has the same coarse complete price as the direct low-surplus inequality mu_low(Q_u)<=(T-1)p applied with the original marks. It therefore legitimately locates the explicit bad remainder on high-density original sources, but is not an additional free source payment. All high-source mass and its actual geometric deficiency integral must remain. Uniform L1 integrability supplies no general smallness of that high-density mass or its source-weighted cost.

## Bounded shallow-geometry author review

Read /tmp/r379_geometry.md in full and its complete1150-check script after the independent screen. PASS. The author explicitly restricts positive source traffic to I_uv>0 and0<=d_i<1 before using the finite[-1,1]^n center integral. The scalar envelope is uniform over the ONE actual shared radius and uses r=1 only as a valid lower-envelope endpoint. Cube product overlap concerns Lebesgue geometry, not f-product structure. The exact Laplace antiderivative, rational Taylor certificates16319/315>50 and97901/65625<3/2, and final753/800 constant agree with the independent calculation.

The original positive plan formula retains omega/J/H/past and the complete physical clock until source exactness bounds the marked integrand by I_uv/m_v. The resulting plain dv measure is correct. Although the note initially describes a cap2 plan, its local proof uses no target-cap bound, so the source-only payment applies to any separately certified completed t-cap plan as stated in the independent screen. n=1,all threshold equalities and zero overlap are handled without treating a boundary as positive source mass.

The author correctly uses the disjoint partition sparse + dense-and-shallow + dense-and-deep. It neither claims shallow contains sparse nor repays sparse/shallow capture in the remaining Hardy estimate. The exact surviving kernel keeps every old original mark, j>n/8,sum d>n/20 and p<exp(-n/20). Small uniform overlap is expressly distinguished from actual f-mass, and no lower bound on individual depths or universal source fraction is inferred.

The1150 grouped Fraction diagnostics split952 coordinate tests,8 rational constants,120 overlap products,10 small-dimensional body volumes and60 source-plan algebra cases. The finite body formula is used only while the depth threshold remains in the first linear ramp. The exponential series bound is a genuine rational upper enclosure, not a float estimate. Finite source/cube-incidence and selector tests do not realize native highpast Lebesgue fields. The reviewer inspected the code and did not duplicate the parent pipeline; reviewer-local5151 scalar envelope cases and3 rational certificates remain separate. Completed helper/main/ledger/numeric review and SHA binding follow.

## Bounded density-helper author review

Read /tmp/r379_density.md and its complete11660-check script after the independent screen. PASS. The actual Radon-Nikodym density mu_low/U=(f/q_v-1)+1_low<=T-1 has no erroneous d_L factor. The singular diagonal plan is justified by the defining actual-capture integrand c_u(y)^2=c_u(y), not by evaluating a product-a.e representative on a diagonal. The combined floor plus low-source density is<=T U, which yields the stated complete(T+t*d_H)p tariff. All source marks stay at their original y; high-source normalization does not recompute full f/m/q/J/past/omega. d_H=0 and T=1 are defined separately.

The high-source layered-plan migration uses P_H on the SAME actual dyadic relation and unchanged C, with all source factors d_H restored before outer dv integration. Since d_H<=1,the first threshold and finite-depth errors remain epsilon/epsilon' X_q. The same noncircular barB,t then(T+t)Gamma allocation works, and product completion covers t=1. A whole-original-remainder high-source option need not add separate shallow/deep fees; the preferred main instead uses the explicit disjoint pair receipts and remaining high-source kernel. These are alternatives, not simultaneous free credits.

The helper explicitly rejects inferring a global payment from T=exp(n/40) and a small per-pair p. Its geometric-template integral would retain the large T price. A predetermined polylog T is a valid priced localization of the actual source remainder, not a new rate for an L1 density tail. The unproved D_H remains.

The11660 Fraction diagnostics split44+528+11088. The eight source intervals have positive length; all displayed receiver boundaries align with the cell boundaries. The small-cube q/source marginal and actual interval captures are real, while bounded marks/weights do not claim a full native q-band/highpast field for every large receiver. Cell-diagonal transport faithfully represents the zero cost/target of an actual within-cell identity because the capture data are constant on each cell. Uniform/high-source conditional target caps and all receiver tariffs are checked exactly, including source threshold equality,zero surplus and zero high source. No full parent pipeline was duplicated. Completed numerical and current main/ledger/readme review follows.

## Bounded exact minimum-capacity numeric review

Read final numeric note and full Python; inspected saved input/result and verified both recorded R378 provenance hashes against actual dependency bytes. PASS within its finite scope. The minimal snapshot still rebuilds all full source matchings,original finite J/global past/complete physical clock and one common all-u C. Source/target cells are actual positive-volume L1 cells; receiver weights remain quadrature with diagnostic gates. m=R^n and q=1 in code, with W=4,4,33/4. The text's ambiguous matching slash was corrected to 'q=1 and m=R^n' in the final reviewed note; code and certificates were unchanged and no new execution is claimed for that editorial correction.

All42 tested d_v are positive. Total source mass forces capacity c>=1 in those fibers; the explicit d=0 guard correctly returns the genuine nonnegative minimum0, not max(1,...). That guard is NOT claimed as exercised by the42 cases. A source subset containing any FREE row has all target cells as neighbors and ratio<=1. Thus only active-row subsets can force a larger sharp capacity. Every nonempty active subset has positive actual zero-box volume here; this is checked rather than assumed generally. Fourteen nonempty subset ratios and the total-mass lower witness prove a valid sharp LOWER bound for each model.

A new exact all-source zero-edge flow at c_star then attains every original row mass, has target<=c_star*dU and cost0. Free rows are included; this is not the earlier partial active flow. A matrix flow gives an actual constant product-cell density plan, so the source/target constraints hold on those continuous source/target cells. Original marked capture costs are constant on the complete cells. BFS rational max flow and the checked exact lower witness/upper plan suffice for each finite optimum without a general infinite Hall theorem or an LP status shortcut.

The saved exact capacities are2 at v=1,6,12,13 for each1D field and1 otherwise;2D v=1 has30/11,v=7 has57/17,and all others1. The2D ratios use real box volume3/8,uniform volume1/6,source demands5/12,19/36 and original d_v11/12,17/18. Every star has a whole-source feasible plan and matching lower witness. Thus capacity4 suffices for all42 SPECIFIED models, while capacity2 fails in the2D samples. This does not bound general capacities or their source-template tariffs. Cost0 for the auxiliary complete coupling means its entire original G appears in actual floor+good; it does not mean original traffic/G vanishes.

The579 grouped Fraction checks include42 full plans,42 lower witnesses,14 nonempty active ratios,12 true zero boxes/120 cell incidences and full marked-interface reconstruction. The serialization correction deriving the redundant col field exactly as dU is explicitly reported. No new MATLAB/LP call or float fit is used. Parent reports fresh execution; reviewer inspected code/results without repeating the pipeline. Source threshold identity/geometry tests and these finite-capacity results have distinct scopes and are not mixed as general-budget evidence.


## Final integration and complete accounting

Read final main, ledger and readme, including the updated1150/11660/579 execution record and exact finite capacities. PASS. The original full-f field is synchronized only after T and the noncircular layer count t are chosen. The template allocation uses(T+t)Gamma, not the earlier(t+1)Gamma. Its epsilon0<=eta/2 guarantees actual B<=barB. The high-source probability P_H is formed only where d_H>0; all original m/q/J/H/global strict past and omega remain those of full f. The old dyadic inner relation and dense-deep cost are measured with this new source probability, not with a reset input or old source deficiencies. Both d_H and every threshold increment remain inside D_H,deep before integration over actual dv.

The singular low-source identity and actual high-source layer plan have EXACTLY the original full surplus source marginal when combined. Pointwise C(y,y)=0 is valid also for the restricted dense-deep kernel. Therefore the same completed plan can be split on original sparse,dense-shallow,dense-deep pairs. The first two source-only bounds apply without assuming target AC or cap2; the last has only high-source bad cost. The full plan's floor+good is at most(T+t)p, so the original positive decomposition gives exactly the displayed hard receipt with D_H,deep retained. No old M1 capture, priority, variance or direct-low-density cost saving is added again.

The combined geometric fee is

sigma_n=epsilon0*(bhat_n+(753/800)^n)/(1+sqrt(n)).

Since both numerator coefficients are<=1 and1+sqrt(n)>=2,sigma_n<=epsilon0<=eta/2. Thus eta=epsilon=epsilon'=kappa/(7Lambda) yields2Lambda(eta+sigma_n+epsilon+epsilon')<=kappa. This is a slot-only budget. Original8lambda H W,2d_eff A_clock Wnu/H,entrance factor2,outer Lambda=128/119 and recomputed C338 remain. The proof of C338=O_(eta,epsilon)(sqrt(n)log^(3/2)(n+2))*W uses predetermined logarithmic T+t; it does not pay the actual Hall deficiency term or justify exponentially large density thresholds for free.

The newly paid family is shallow fractional truncation in the same original field, alongside the already paid sparse family. All remaining pairs have dense protrusions and exponentially small UNIFORM overlap. They can still carry substantial actual f mass. The final high-source localization is a valid priced auxiliary transport, not an input-uniform L1-tail estimate, and its known template mechanism is not claimed as another independent geometric saving. The finite capacity4 outcome applies to the42 frozen actual-source/quadrature models and is not extrapolated to arbitrary receiver fields or dimensions.

Unpaid obligations remain D_H,deep's general root-order source budget, original H entrance/choice and soft/crossing/entry interfaces, contract-external tails/scales/threshold complements, historical initial/deletion/future-source time atoms, full source/physical-scale aggregation, outer integrations, truncation and limits. Physical terminal atoms do not replace historical atoms. This audit does not re-audit every historical reduction or certify absorbability of the sum of all other slots.

Actual computation scopes are separate: parent reports fresh1150 geometry Fraction checks,11660 density identity/interface Fraction checks and579 exact minimum-capacity certificates/constraints. No new MATLAB/LP call occurred. Reviewer ran5151 rational envelope grid cases plus3 exact exponential-series certificates and inspected all three complete scripts/results without duplicating the parent pipelines. These counts are finite evidence; actual selector geometry, singular diagonal validity and continuous measurable construction are established analytically. The d=0 guard is correctly defined but explicitly NOT claimed to be exercised in the42 numeric cases.

Final bounded decision: PASS for the shallow plain-center payment, exact priced source identity localization, remaining high-source layered interface, finite sharp whole-surplus capacities and synchronized full accounting. No unresolved correction within the review. The general arbitrary-input root upper bound remains open in D_H,deep and other retained original slots.

## Final SHA256 bindings

The following hashes bind the final reviewed bytes and necessary dependencies. Mathematical edits require re-audit; later generated TeX/PDF layout is outside this binding.

```text
2f21e5f1cd81be30e43dd7fdbc1671d705614d9a2079e2685e579ee8dc13aec7  /tmp/r379_main.md
5f577d1d01cfe9ac3d992853c9e92cbe85e1fe5fc4e6758591b1858a8dcdc063  /tmp/r379_ledger.md
bd7bed71046956ca7e7899f477805701720b3e8946b3db08f342a0423021b272  /tmp/r379_readme.md
a961995f6086a06b5158cd3a92c850744d6f6b71cce95e634e4e55b5127e621b  /tmp/r379_geometry.md
d3cc76a7148539bed2a8b6856ae6a1a7e957180d51229d5b37ea2d58a6545e07  /tmp/r379_geometry_check.py
e3a151aeb00d7778dc783d91d704042346e44904e0d2ba4caef4f31a58e344ea  /tmp/r379_density.md
e74d6b3ec4a2db80286cba07b73a1b41a5e0103081bab630bc7567fcd8b3b759  /tmp/r379_density_check.py
00e64d326c3c374d4ce43c2bea3d816e750c91a41bd91b207dd323635d6bab50  /tmp/r379_numeric.md
9ead50a3ff81bce59d113b980b2c7471894b2501114a6249a7754836d07447cd  /tmp/r379_numeric.py
8e210624d31039fd73c45f8b1e31200eb2085ce92f09962f78263cc1e3231275  /tmp/r379_numeric_input.json
29fec1c5cae36ca320d0c6d835d81d2e2b3de5c1fbeef63c5cf5210a33d04c7e  /tmp/r379_numeric_result.json
8d7f0361b15108b014b9fb7ddc8c124e17f268a2ba98ff7bb8ab2489b188e24d  /tmp/r378_layered.md
f7c5342956723a49374dc0e0f631e8c283cbb2ec59f5a26c5dec5e0d287276c3  /tmp/r378_geometry.md
e8990006ae1607d464462c9403b931e725321ffa7099a613619af8484ac59c81  /tmp/r378_main.md
7430c541648750d8734765e3e2554da72786cb9be7107660aeb757cf24850ef3  /tmp/r378_ledger.md
f05044dde46e50430df811d684f22ba1135cd310bca93fbbf7114c565d377a33  /tmp/r378_audit.md
ed06de678d0842b1b133fdd4aafb3380e34d5e6d74705bf70cb3fbe1caa69055  /tmp/r378_numeric_input.json
9b219233d3f5409ae230e64e976c9905e90d1d9f2f6069f96186d28b09a1218c  /tmp/r378_numeric_result.json
16b083e57cd84fe7d3b8b9a077d2211941e7efd340d3bf3bc7fdb0fcaa85a29d  /tmp/r377_geometry.md
3a4122195001d3a0587fff057dbc273ad25920ea71726688feb650b9c154e244  /tmp/r377_ledger.md
16c68acce633ca7df17e8f2506fbc31c4aa00495b89200c84b745289e5b3caa7  /tmp/r376_geometry.md
fac02a43e18ed5dc3d5be7ef67a8ac9e34cbd4dd1e69912d6e29dffda597d81a  /tmp/r370_geometry.md
```
