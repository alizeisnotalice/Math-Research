from fractions import Fraction as F

U=[F(1,8)]*8
xs=[F(2*i+1,16)-F(1,2) for i in range(8)]
receivers=[(F(-3,4),F(3,2)),(F(3,4),F(3,2)),
           (F(0),F(2)),(F(1,2),F(5,4))]
cap=[[F(int(abs(x-c)<=R/2)) for x in xs] for c,R in receivers]
counts=[0,0,0];nonzero=[0,0,0];alllow=[0,0,0]

def row_plan(K,t):
    left=F(1);rho=[F(0)]*len(U)
    for value in sorted(set(K),reverse=True):
        ids=[j for j,x in enumerate(K) if x==value]
        mass=sum(U[j] for j in ids)
        density=min(t,left/mass)
        for j in ids:rho[j]=density
        left-=mass*density
    assert left==0
    return rho

def check(raw,T,t,mode,stage):
    f=list(map(F,raw));q=sum(u*x for u,x in zip(U,f));assert q>0
    floor=[U[i]*min(f[i]/q,F(1)) for i in range(8)]
    plus=[U[i]*max(f[i]/q-1,F(0)) for i in range(8)]
    low=[plus[i] if f[i]<=T*q else F(0) for i in range(8)]
    high=[plus[i]-low[i] for i in range(8)]
    dl,dh=sum(low),sum(high)
    assert all(low[i]<=max(T-1,F(0))*U[i] for i in range(8))
    assert sum(floor)+dl+dh==1
    weights=[F(1,3),F(2,5),F(1,7),F(3,4)]
    mark=[[F(1) if mode==0 else F((i+2*k+mode)%5,4) for i in range(8)] for k in range(4)]
    K=[[sum(weights[k]*mark[k][i]*cap[k][i]*cap[k][j] for k in range(4))
        for j in range(8)] for i in range(8)]
    L=[sum(weights[k]*mark[k][i]*cap[k][i] for k in range(4)) for i in range(8)]
    C=[[L[i]-K[i][j] for j in range(8)] for i in range(8)]
    assert all(C[i][i]==0 and all(x>=0 for x in C[i]) for i in range(8))
    hp=[[high[i]*U[j]*row_plan(K[i],t)[j] for j in range(8)] for i in range(8)]
    plan=[[hp[i][j]+(low[i] if i==j else F(0)) for j in range(8)] for i in range(8)]
    assert all(sum(plan[i])==plus[i] for i in range(8))
    target=[sum(plan[i][j] for i in range(8)) for j in range(8)]
    assert all(target[j]<=((T-1)+t*dh)*U[j] for j in range(8))
    lowcost=sum(low[i]*C[i][i] for i in range(8))
    highcost=sum(hp[i][j]*C[i][j] for i in range(8) for j in range(8))
    bad=sum(plan[i][j]*C[i][j] for i in range(8) for j in range(8))
    assert lowcost==0 and bad==highcost
    orig=sum((floor[i]+plus[i])*L[i] for i in range(8))
    paid=sum(floor[i]*L[i] for i in range(8))+sum(plan[i][j]*K[i][j] for i in range(8) for j in range(8))
    assert orig==paid+bad
    counts[stage]+=7
    for k in range(4):
        p=sum(U[j]*cap[k][j] for j in range(8))
        fpaid=sum(floor[i]*mark[k][i]*cap[k][i] for i in range(8))
        good=sum(plan[i][j]*mark[k][i]*cap[k][i]*cap[k][j] for i in range(8) for j in range(8))
        assert fpaid+good<=(T+t*dh)*p<=(T+t)*p
        counts[stage]+=1
    if dh:nonzero[stage]+=1
    else:alllow[stage]+=1

profiles=[(1,1,1,1,1,1,1,1),(8,0,0,0,0,0,0,0),
          (4,0,0,0,0,0,0,4),(2,0,2,0,2,0,2,0),
          (0,0,1,3,0,0,1,3),(4,4,0,0,0,0,0,0)]
for raw,T in [(profiles[0],F(1)),(profiles[1],F(1)),
              (profiles[1],F(8)),(profiles[2],F(4))]:
    check(raw,T,F(1),0,0)
for raw in profiles:
    for T in (F(1),F(3,2),F(2),F(4)):
        for t in (F(1),F(2)):
            check(raw,T,t,1,1)
for raw in profiles:
    for T in (F(k,4) for k in range(4,25)):
        for t in (F(1),F(2),F(3),F(4)):
            for mode in (0,2):check(raw,T,t,mode,2)
print('PASS stages',counts,'total',sum(counts),'high-source cases',nonzero,
      'zero-high-source cases',alllow)
