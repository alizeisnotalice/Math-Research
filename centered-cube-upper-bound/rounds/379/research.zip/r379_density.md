# R379 — Exact low-density identity transport and the remaining high-density source

## 1. Contract and outcome

Keep the same actual full f≥0 in L1, cubes Q_v, m_v=f(Q_v)=q_vR_v^n, q_-≤q_v≤λ, actual receiver dv and du, and every original J, strict-past gate and physical clock. Let U_v=1_{Q_v}dy/R_v^n. Use the same marked common kernel

\[
 K_v(y,z)=\frac1h\int_E\frac{du}{R_u^n}
 A_{uv}\omega_u(y)c_u(y)c_u(z),\qquad
 L_v(y)=\frac1h\int_E\frac{du}{R_u^n}
 A_{uv}\omega_u(y)c_u(y),\quad C_v=L_v-K_v\ge0.
\]

A may include the new deep pair restriction as well as every old pair mask. No mark is recomputed after the source split. The proof only needs the inherited 0≤A,ω≤1 and R_v≤R_u on the pair support. Write p_uv=U_v(Q_u). The established selector estimate is

\[
 \frac1h\int_E\frac{du}{R_u^n}\int_E A_{uv}p_{uv}\,dv
 \le\frac{\Gamma_n|E|}{h}. \tag{1}
\]

The following is an exact feasible low-source removal with the same price as the elementary density-template bound. It is **not** an improved new payment extracted from exponentially small overlap. Its useful output is a legal common plan, an unchanged high-source problem, and a complete polylogarithmic-capacity ledger.

## 2. Low source has an exact zero-cost diagonal plan

Fix any finite T≥1. Split the actual surplus measure using the receiver's own full-f average:

\[
 \mu_v^+=\frac{(f-q_v)_+c_v}{m_v}dy
 =\mu_{v,L}+\mu_{v,H},
\]

where μ_L uses the condition f(y)≤Tq_v and μ_H its strict complement. Let their masses be d_L,d_H, so d_L+d_H≤1. Their exact densities relative to U_v are

\[
 \frac{d\mu_{v,L}}{dU_v}
 =(f/q_v-1)_+1_{\{f\le Tq_v\}}\le T-1. \tag{2}
\]

This bound is **not** (T−1)d_L. The low plan is the singular identity measure

\[
 \gamma_{v,L}(dy,dz)=\mu_{v,L}(dy)\delta_y(dz). \tag{3}
\]

Its source and target are both μ_L, and its bad cost is exactly zero. Indeed the actual indicator kernel gives, directly and pointwise wherever the original integrals are defined,

\[
 K_v(y,y)=\frac1h\int_E\frac{du}{R_u^n}
 A_{uv}\omega_u(y)c_u(y)^2=L_v(y). \tag{4}
\]

This is not a claim about the diagonal of an arbitrary product-almost-everywhere identity. The defining actual capture indicators establish (4) themselves. Hence singularity creates no missing zero-cost justification. All original source labels and gates stay at y.

Let the floor measure be F_v(dy)=min(f,q_v)c_vdy/m_v. Combining it with μ_L at their original locations gives the sharper direct bound

\[
 \frac{d(F_v+\mu_{v,L})}{dU_v}
 =\min(f/q_v,1)+(f/q_v-1)_+1_{\{f\le Tq_v\}}\le T. \tag{5}
\]

For d_H>0 write P_{v,H}=μ_H/d_H. Choose any measurable common high-source plan with source P_H and target≤tU_v. Multiply it by d_H and add (3). The full surplus plan has exact source μ_v^+ and target≤[(T−1)+td_H]U_v. For every original receiver pair, its marked floor plus good transport is therefore at most

\[
 \boxed{(T+td_H)p_{uv}\le(T+t)p_{uv}.} \tag{6}
\]

Here 0≤ω≤1 is used only for this positive upper bound; the exact high-source bad cost retains ω at its original source. If d_H=0, omit the high plan and its cost entirely. If T=1, μ_L=0 and the construction reduces to the old high-source plan plus floor.

By (1), (6) costs at most

\[
 \boxed{(T+t)\Gamma_n|E|/h.} \tag{7}
\]

There is no extra floor fee added to (7). This replaces the old floor/common-plan template when used on that same original positive integral.

## 3. A high-source layered plan, without changing the underlying field

Apply the R378 finite-dyadic partial-plan construction to **P_H**, with the unchanged actual C_v. When d_H=0 set all following contributions to zero. Let τ_0=εq_-, terminal bound Bbar≥B=A_n/h, and t stages ending at Bbar. For each earlier level let δ_{v,τ_j,∞}^{H} be the missing mass for the explicit actual dyadic inner relation, now measured with P_H and target U_v. This is a new source weight on the same geometric relation, not a redefinition of f, m, q or J.

Positive current-source-density filtering and finite-depth approximation give the high-source bad bound

\[
 G_H\le(\epsilon+\epsilon')X_q+\mathcal D_H,\qquad
 \mathcal D_H=\int_Ed_H(v)\sum_{j=0}^{t-2}
 (\tau_{j+1}-\tau_j)\delta_{v,\tau_j,\infty}^{H}\,dv. \tag{8}
\]

The first term uses d_H≤1 and q_-|E|≤X_q. It does not estimate high-source mass by its ambient volume. The low-source bad cost is zero, so the original positive remainder to which this construction is applied is bounded by (7)+(8). If applied only to the deep pair restriction, every complementary pair component retains its existing separate receipt. No component is silently deleted.

For the R378 original entrance, one may choose the parameters noncircularly as follows:

\[
 \bar B=\frac{A_n\eta q_-}{2(1+\sqrt n)},\qquad
 t=1+\max\left(0,\left\lceil\log_2\frac{\bar B}{\epsilon q_-}\right\rceil\right),
\]

with t=1 if the ratio≤1. Now set

\[
 \mathcal L_{n,T,t}=2+\frac{72+(T+t)\Gamma_n}{1+\sqrt n},\quad
 \epsilon_0=\eta/\mathcal L_{n,T,t},\quad
 h=\frac{1+\sqrt n}{\epsilon_0q_-}.
\]

Then ε_0≤η/2 gives B≤Bbar. Rebuild every original h-dependent gate and mark consistently. With the R378 entrance receipts, the resulting whole-remainder option is

\[
 B_H\le\mathcal D_H+(\eta+\epsilon+\epsilon')X_q+C_{338}W, \tag{9}
\]

where

\[
 C_{338}=\frac\lambda{q_-}
 \left[\frac{2+3\sqrt n+2e^{-\sqrt n}}{\epsilon_0}+1+\sqrt n\right].
\]

Using this option for the whole original remainder avoids adding a second independent shallow/deep receipt; when using it only on the deep branch, keep the other branch's own ledger instead. The original entrance H costs, both original source fees where present, hard-slot multiplier and outer multiplier are unchanged.

In an octave, t=O_{η,ε}(log(n+2)) and Γ_n=O(√(n log(n+2))). Thus any predetermined T=O(log^A(n+2)) preserves

\[
 C_{338}=O_{\eta,\epsilon}\!\left(\sqrt n\left[1+(T+t)\sqrt{\log(n+2)}\right]\right).
\]

For example T=1+log(n+2) gives the usual √n log^(3/2)(n+2) source scale. No dimension dependence is hidden in η or ε. A threshold T=n^c with c>0, or T=exp(n/40), is **not** paid at the desired root-polylog scale by this estimate. Keeping h unchanged leaves their large template coefficient in (7); enlarging h transfers it to C338. No claim of an impossible alternative method is made.

## 4. What the deep-overlap observation does and does not add

On the proposed deep branch p≤exp(−n/20), the pointwise low-density observation with T=exp(n/40) indeed gives T p≤exp(−n/40). It does not bound the actual center integral by that pointwise value: the centers still have to be integrated. Conversely retaining p and using (1) gives exactly TΓ_n|E|/h. The identity plan above realizes that same bound as a valid common transport, so it does not improve the elementary template price or establish an additional deep-branch saving. An argument through p^θ would need its actual selector integral, including all scale costs; none is asserted here.

The remaining source is exactly

\[
 \mu_{v,H}=\frac{(f-q_v)_+c_v}{m_v}1_{\{f>Tq_v\}}dy.
\]

It may have large mass for arbitrary L1 f. In particular neither d_H nor the weighted dyadic defect in (8) is automatically small. The strict pointwise implication f>Tq_- is valid but supplies no rate for an L1 tail at these finite thresholds. The original full-f field is not recomputed on that tail. Hence this note supplies a paid low-density component and an exact high-source interface, not a new estimate of \mathcal D_H or a general root closure. The low receipt itself is the known overlap-template mechanism at a changed threshold, not a new geometric gain.

## 5. Three-stage exact verification

Script: `/tmp/r379_density_check.py`.

It uses actual interval capture matrices on eight positive-length source cells, the exact small-cube average q from each piecewise-constant full profile, and bounded original source marks. Receiver boundaries align with the cells, so the capture diagonal identity is exact. The high-source candidate is a common quantile plan with target≤td_HU. It checks the correct low density cap (without an erroneous factor d_L), boundary equality f=Tq, source marginals, zero diagonal cost, unchanged marked decomposition, total target cap and every receiver's (T+td_H)p bill. It includes zero-surplus and zero-high-source cases.

Actual Fraction execution: **PASS [44,528,11088], total 11660 grouped assertions; high-source cases [1,30,456]; zero-high-source cases [3,18,552].** The stages contain four boundary cases, 48 interface cases and 1008 expanded cases. These finite marked capture checks do not claim the complete native q-band/high-past realization for all large receivers. They validate the local algebra and positive construction, not the remaining global bound.
