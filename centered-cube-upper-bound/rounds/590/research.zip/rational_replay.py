#!/usr/bin/env python3
"""Independent all-rational verification of the frozen R590 two-ring preflight.
No imports from the producer; equality cases are handled exactly.
"""
import argparse, hashlib, json, platform, sys, time
from fractions import Fraction as Q
from functools import lru_cache
from pathlib import Path


def verify():
    t0=time.perf_counter()
    pts=[]; weights=[]
    for cx,a,w in [(0,49,1),(120,69,2)]:
        offsets=sorted(set([(i*a,j*a) for i,j in [(-1,-1),(-1,1),(1,-1),(1,1),(-1,0),(1,0),(0,-1),(0,1)]]))
        pts.extend((cx+x,y) for x,y in offsets); weights.extend([w]*8)
    eta=Q(1,1000); epsilon=Q(1,4)
    @lru_cache(None)
    def high(w,dx100,dy100):
        m=Q(w,8); dx=Q(dx100,100); dy=Q(dy100,100)
        if dx*dx>=m or dy*dy>=m: return False
        p=dx*dy; s=dx+dy
        # 2(m+p-s sqrt(m))^2-m^2 = A-B sqrt(m).
        A=2*(m+p)**2+2*s*s*m-m*m
        B=4*s*(m+p)
        assert A>0 and B>=0
        # A>=B sqrt(m) iff A^2>=B^2 m, both sides nonnegative.
        return A*A>=B*B*m
    data={}; highs=[]; witness=[[],[]]; centers=[(0,0),(120,0)]
    margin_cache=set()
    for mask in range(1,1<<16):
        labels=[i for i in range(16) if mask>>i&1]
        w=sum(weights[i] for i in labels)
        lo=[min(pts[i][j] for i in labels) for j in range(2)]
        hi=[max(pts[i][j] for i in labels) for j in range(2)]
        data[mask]=(w,lo,hi)
        if high(w,hi[0]-lo[0],hi[1]-lo[1]): highs.append(mask)
        for k,c in enumerate(centers):
            d=max(abs(pts[i][j]-c[j]) for i in labels for j in range(2))
            m=Q(w,8); D=Q(d,100)
            inside=m>4*D*D
            assert m!=4*D*D
            key=(w,d)
            if key not in margin_cache:
                if inside: assert m>4*(D+eta)**2
                else: assert D>eta and m<4*(D-eta)**2
                margin_cache.add(key)
            if inside:
                assert not Q(1,2)<=m<1, 'base neighborhood unexpectedly present'
                if 1<=m<=8:witness[k].append(mask)
    used=0; blocks=[]
    for mask in sorted(highs,key=lambda s:(-data[s][0],s)):
        if not used&mask: blocks.append(mask); used|=mask
    assert used==65535 and len(highs)==17
    assert [s for s in highs if s&(s-1)]==[576]
    parents=[]
    for k,c in enumerate(centers):
        p=max(witness[k],key=lambda s:data[s][0]); parents.append(p)
        assert all(s&~p==0 for s in witness[k])
        w,_,_=data[p]
        actual=sum(1<<i for i,z in enumerate(pts) if Q(w,8)>4*Q(max(abs(z[j]-c[j]) for j in range(2)),100)**2)
        assert actual==p
        # Z_epsilon: distance minus eta > sqrt(m_i/epsilon)/2.
        for i,z in enumerate(pts):
            gap=Q(max(abs(z[j]-c[j]) for j in range(2)),100)-eta
            assert gap>0 and gap*gap>Q(weights[i],8)/(4*epsilon)
        # Full selected block bbox+cube, not singleton substitution.
        for s in blocks:
            w,lo,hi=data[s]
            gaps=[Q(lo[j]-c[j],100)-eta for j in range(2)]+[Q(c[j]-hi[j],100)-eta for j in range(2)]
            assert any(gap>0 and gap*gap>Q(w,16) for gap in gaps)
    assert parents==[767,65504]
    assert Q(sum(weights),8)<Q(16,3), 'Top+ not empty'
    shared=parents[0]&parents[1]
    assert data[shared][0]==5
    # Separate R1 pre-screen: fixed origin-zero grid, s=1/2, delta=1/4.
    grid={}
    for z,w in zip(pts,weights):
        key=(z[0]//50,z[1]//50)
        grid[key]=grid.get(key,0)+w
    assert grid[(0,0)]==3 and grid[(1,0)]==2
    assert Q(3,8)>=epsilon and Q(1,4)>=epsilon
    assert Q(3,8)>eta*eta  # P0 lower edge distance sqrt(3/2)/2.
    assert Q(3,10)>eta and Q(1,2)>eta  # P1 receiver margins.
    return {'certificate':'all rational, independently implemented; no Arb or producer imports',
      'nonempty_subsets':65535,'high_masks':highs,'selected_H2_masks':blocks,
      'parents':parents,'parent_masses':[str(Q(data[s][0],8)) for s in parents],
      'shared_mask':shared,'shared_mass':str(Q(data[shared][0],8)),
      'distinct_neighborhood_margin_checks':len(margin_cache),'high_predicate_cases':high.cache_info().currsize,
      'eta':'1/1000','certified_J0_lower_bound':'1/125000',
      'grid_branch_check':{'grid_side':'1/2','origin':['0','0'],'P0_mass':'3/8','P1_mass':'1/4',
        'both_certified_neighborhoods_covered_by_G':True,'full_R1_empty_not_asserted':True},
      'all_assertions_passed':True,
      'scope':'Frozen n=2 input only; all original subset memberships and full H2/Z/base/Top+ exclusions on two entire neighborhoods. No full arrangement or halfcore law estimate.',
      'execution':{'interpreter':sys.executable,'python':platform.python_version(),'runtime_seconds':time.perf_counter()-t0,
        'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}}

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);args=ap.parse_args()
    result=verify();args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(result,ensure_ascii=False))
