#!/usr/bin/env python3
"""Two-ring full subset and actual inherited high-beta H2 preflight only."""
import argparse,hashlib,json,platform,resource,shlex,signal,sys,time
from fractions import Fraction as F
from functools import lru_cache
from pathlib import Path
import flint
from flint import arb,ctx

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=Path(__file__).with_name('ccu_r590_tworing_preflight_results.json'));args=ap.parse_args()
 start=time.perf_counter();ctx.prec=512
 def timeout(*_):raise TimeoutError('120 second preflight guard, no truncated family')
 signal.signal(signal.SIGALRM,timeout);signal.alarm(120)
 positions=[];mu=[];rings=[]
 for cx,a,massu,name in ((0,49,1,'inner'),(120,69,2,'outer')):
  offsets=sorted([(sx*a,sy*a) for sx in (-1,1) for sy in (-1,1)]+[(-a,0),(a,0),(0,-a),(0,a)])
  for x,y in offsets:positions.append((cx+x,y));mu.append(massu);rings.append(name)
 N=16;ALL=65535;eps=F(1,4);eta=F(1,1000);points=[(0,0),(120,0)]
 def af(q):q=F(q);return arb(q.numerator)/q.denominator
 def out(v):return {'Arb512':v.str(65),'absolute_radius':v.rad().str(15)}
 @lru_cache(None)
 def radius(mu8):return af(F(mu8,8)).sqrt()/2
 @lru_cache(None)
 def high_guard(massu,dx,dy):
  # Empty/zero-width C_S cannot be high; compare squared widths as integers.
  if 8*dx*dx>=10000*massu or 8*dy*dy>=10000*massu:return False
  r=radius(massu)*2;beta=(r-af(F(dx,100)))*(r-af(F(dy,100)))/af(F(massu,8));guard=2*beta**2-1
  if guard>0:return True
  if guard<0:return False
  raise ArithmeticError('High-beta equality/unresolved sign; no floating fallback')
 masses=[0]*(ALL+1);xmin=[0]*(ALL+1);xmax=[0]*(ALL+1);ymin=[0]*(ALL+1);ymax=[0]*(ALL+1);dists=[[0]*(ALL+1) for _ in points];high=[];base_at=[[],[]];inband_counts=[0,0];witness_union=[0,0];maxmass=[0,0];maxmasks=[[],[]];margin_pairs=[set(),set()];top_count=0
 for S in range(1,ALL+1):
  bit=S&-S;i=bit.bit_length()-1;T=S^bit;x,y=positions[i];masses[S]=masses[T]+mu[i]
  if T:xmin[S]=min(xmin[T],x);xmax[S]=max(xmax[T],x);ymin[S]=min(ymin[T],y);ymax[S]=max(ymax[T],y)
  else:xmin[S]=xmax[S]=x;ymin[S]=ymax[S]=y
  if high_guard(masses[S],xmax[S]-xmin[S],ymax[S]-ymin[S]):high.append(S)
  if F(16,3)<=F(masses[S],8)<=16:top_count+=1
  for p,(px,py) in enumerate(points):
   D=max(dists[p][T],abs(x-px),abs(y-py));dists[p][S]=D
   # Interior receiver membership is equivalent to m_S>4 dist_inf^2.
   cmp=1250*masses[S]-4*D*D
   assert cmp!=0,'Receiver lies exactly on a subset boundary'
   margin_pairs[p].add((masses[S],D,cmp>0))
   if cmp>0:
    if 4<=masses[S]<8:base_at[p].append(S)
    if 8<=masses[S]<=64:
     inband_counts[p]+=1;witness_union[p]|=S
     if masses[S]>maxmass[p]:maxmass[p]=masses[S];maxmasks[p]=[S]
     elif masses[S]==maxmass[p]:maxmasks[p].append(S)
 used=0;selected=[]
 for S in sorted(high,key=lambda S:(-masses[S],S)):
  if not S&used:selected.append(S);used|=S
 assert used==ALL
 # This is the full inherited high-block rectangle cover, not atom holes.
 blocks=[]
 for S in selected:
  half=af(F(masses[S],4)).sqrt()/2
  B=[(af(F(xmin[S],100))-half,af(F(xmax[S],100))+half),(af(F(ymin[S],100))-half,af(F(ymax[S],100))+half)]
  blocks.append((S,B))
 checks=[]
 for p,point in enumerate(points):
  px,py=map(lambda v:af(F(v,100)),point);parent=witness_union[p]
  assert masses[parent]==maxmass[p] and parent in maxmasks[p]
  captured=sum(1<<i for i,(x,y) in enumerate(positions) if 1250*masses[parent]>4*max(abs(x-point[0]),abs(y-point[1]))**2)
  assert captured==parent
  assert not base_at[p] and top_count==0
  subset_margins=[]
  for m,D,inside in sorted(margin_pairs[p]):
   delta=radius(m)-af(F(D,100));margin=delta if inside else -delta
   assert margin>af(eta)
   subset_margins.append(margin)
  # Every original subset membership is constant on the whole eta receiver box.
  zmargins=[]
  for i,(x,y) in enumerate(positions):
   D=F(max(abs(x-point[0]),abs(y-point[1])),100)
   margin=af(D)-af(F(mu[i],8)/(4*eps)).sqrt();assert margin>af(eta);zmargins.append(margin)
  hguards=[]
  for S,B in blocks:
   margins=[B[0][0]-px,px-B[0][1],B[1][0]-py,py-B[1][1]]
   positives=[(j,v) for j,v in enumerate(margins) if v>af(eta)]
   assert positives,'Actual H2 block reaches center/neighborhood'
   j,v=positives[0];hguards.append({'selected_block_mask':S,'exclusion_face':['left','right','bottom','top'][j],'positive_separation':out(v)})
  # Candidate minima are only ranked approximately; all recorded guards above
  # are individually strict Arb inequalities and are the certificate.
  sm=min(subset_margins,key=lambda a:float(a.mid()));zm=min(zmargins,key=lambda a:float(a.mid()))
  checks.append({'point':[str(F(v,100)) for v in point],'maximal_filled_parent_mask':parent,'maximal_parent_labels':[i for i in range(16) if parent>>i&1],'mass_exact':str(F(masses[parent],8)),
   'maximum_mass_witness_masks':maxmasks[p],'inband_witness_count':inband_counts[p],'captured_at_own_mass_radius_exactly_parent':True,
   'base_witness_count':len(base_at[p]),'Top_plus_witness_count':0,'outside_Z_epsilon':True,'outside_actual_H2':True,
   'all_65535_subset_memberships_constant_on_receiver_box':True,'number_of_distinct_subset_distance_guards':len(margin_pairs[p]),'one_small_subset_boundary_guard':out(sm),'one_small_Z_guard':out(zm),
   'all_selected_H2_block_exclusions':hguards,'certified_receiver_neighborhood_halfside_exact':str(eta),'neighborhood_volume_exact':str((2*eta)**2)})
 assert [masses[v['maximal_filled_parent_mask']] for v in checks]==[10,19]
 shared=checks[0]['maximal_filled_parent_mask']&checks[1]['maximal_filled_parent_mask'];assert masses[shared]==5
 signal.alarm(0)
 result={'scope':'One frozen two-ring n2 full-subset preflight; no full arrangement, halfcore enumeration, LP, law optimization, or general bound.',
 'cube_parameter_convention':'r_S=sqrt(mS/lambda) is SIDE length, coordinate halfwidth r_S/2; H2 block expansion uses halfwidth sqrt(2mS)/2','input':{'n':2,'lambda':1,'L':1,'U':8,'epsilon_exact':str(eps),'W_exact':'3','sources':[{ 'label':i,'ring':rings[i],'position':[str(F(v,100)) for v in positions[i]],'mass_exact':str(F(mu[i],8))} for i in range(16)],'label_order':'inner eight lexicographic offsets, then outer eight lexicographic offsets'},
 'complete_enumeration':{'nonempty_subsets':ALL,'high_beta_subset_count':len(high),'high_beta_masks':high,'selected_original_H2_partition_masks':selected,'Top_plus_eligible_subset_count':top_count,'high_beta_unique_geometry_checks':high_guard.cache_info().currsize},
 'certified_J0_lower_bound_exact':str(2*(2*eta)**2),'H2_definition':{'inherited_definition_script_sha256':'eaedc1d51990f19fe1dc6b9de0a556f682c7f9800018e78fdb7e9a27fb2acadd','source':'Inherited R583 actual implementation, lines 74-90, consistent with the previously replayed original cover; this preflight uses its whole selected blocks.',
   'beta':'product_j (sqrt(mS)-range_j(S))_+/mS, n=2','high_condition':'2 beta^2 >=1; all nonempty positive widths then nonzero comparisons certified Arb512',
   'greedy':'decreasing exact actual subset mass, increasing mask tie; choose source-disjoint blocks until all labels covered',
   'block_rectangle':'bbox(S)+[-sqrt(2mS)/2,sqrt(2mS)/2]^2',
   'blocks':[{'mask':S,'mass_exact':str(F(masses[S],8)),'source_bbox_rational':[[str(F(xmin[S],100)),str(F(xmax[S],100))],[str(F(ymin[S],100)),str(F(ymax[S],100))]],'H2_bounds_Arb512':[[out(a),out(b)] for a,b in B]} for S,B in blocks]},
 'receiver_checks':checks,'shared_labels':[i for i in range(16) if shared>>i&1],'shared_mask':shared,'shared_mass_exact':str(F(masses[shared],8)),'parent_mass_ratio_exact':'19/10',
 'decision':'Both disjoint positive-volume neighborhoods survive original H2, Top_plus, base and Z_epsilon, with distinct maximal filled parents sharing actual labels. This qualifies the input for a subsequent separately frozen correlated-law experiment; it does not prove any source-uniform budget.',
 'certificate_arithmetic':'Subset membership uses exact rational integer squared inequalities. All high-beta, neighborhood and H2/Z separations are Arb512 strict comparisons; no floating sign is used. Approximate minima are display candidates only, not used to assert a universal minimum.',
 'execution':{'interpreter':sys.executable,'python':platform.python_version(),'python_flint':flint.__version__,'precision_bits':ctx.prec,'processes':1,'runtime_seconds':time.perf_counter()-start,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'command':shlex.join([sys.executable,str(Path(__file__).resolve()),*sys.argv[1:]])},'all_assertions_passed':True}
 args.output.write_text(json.dumps(result,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
 print(json.dumps({'high_count':len(high),'selected_H2':selected,'parents':[v['maximal_filled_parent_mask'] for v in checks],'parent_masses':[v['mass_exact'] for v in checks],'shared_mass':str(F(masses[shared],8)),'time_seconds':result['execution']['runtime_seconds'],'peak_rss_bytes':result['execution']['peak_rss_bytes'],'all_assertions_passed':True}))
if __name__=='__main__':main()
