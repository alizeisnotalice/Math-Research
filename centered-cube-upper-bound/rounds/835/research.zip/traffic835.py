"""R835 frozen source traffic on the paired continuous R814 price histories.

The R834 positive-width certified inner rank pools and their full exterior
supports bound the uncomputed true rank pools. All displayed decisions are
made over Q. The archived four-dimensional high-dimensional gate is empty.
"""

import argparse
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
from zipfile import ZipFile


ROUNDS = Path("/Volumes/data/CodexProjects/T/Math-Research-cube-sqrt-20261114/"
              "centered-cube-upper-bound/rounds")
PINS = {
    814: "891d8cbcbd35537e6abc18c938e53b1b4f300327357c24c8d14a51a46ad5e190",
    832: "3eef2e83aab159531aa5b1049715568779e8c599998dde494ce0ea0e238c0303",
    833: "8c37039dba896615b13e4de9c1bfe2a56ee8f539e192c11386285237f2537b17",
    834: "15b8e65b789dbe30cd08ce0b376ae93fd19fa2341b895d15c50a2ed9cee284e8",
}


def show(x):
    return format(float(x), ".12g")


def bin_volume(x):
    # Absolute dyadic bin of the true middle mass of the threshold record.
    d = x.numerator.bit_length() - x.denominator.bit_length()
    if x < F(2)**d:
        d -= 1
    assert F(2)**d <= x < F(2)**(d+1)
    return d


def transpose(rows):
    return {(t,g,x): w for (t,x,g),w in rows.items()}


def build_direction(rows, atoms, mu, bits, mass_bin, denominator, archived, cubes):
    groups = archived["grouped_flow"](rows)
    certificate = archived["source_kernel"](cubes,bits,atoms,mu,groups)
    lower, upper = defaultdict(F), defaultdict(F)
    lower_cancelled, upper_cancelled = defaultdict(F), defaultdict(F)
    pullback = {}
    for g,keys in groups.items():
        group_mass = sum(rows[k] for k in keys)
        anchor_mass, threshold_mass = defaultdict(F), defaultdict(F)
        recall = defaultdict(dict)
        for e in keys:
            t, x, _ = e
            z, d = x[1], mass_bin[t]
            w = rows[e]
            anchor_mass[t] += w
            threshold_mass[z,d] += w
            recall[z,d][e] = w
        for (z,d), weights in recall.items():
            total = sum(weights.values())
            pullback[g,z,d] = {e:w/total for e,w in weights.items()}
        support = sorted({z for z,_ in recall})
        for t,anchor in sorted(anchor_mass.items()):
            for (z,d), threshold in sorted(threshold_mass.items()):
                if z & bits[t]:
                    continue
                # Both orderings give identical anchor/threshold weights.
                # d is the bin of this threshold record i, never of anchor t.
                unscaled = 2 * anchor * threshold / group_mass
                factor = unscaled / denominator[t]
                for y in support:
                    if y & bits[t]:
                        continue
                    for i in range(len(atoms[y])):
                        upper[g,(y,i),d] += factor
                        upper_cancelled[g,(y,i),d] += unscaled
                    for cell, probability in certificate.get((t,z,y),{}).items():
                        lower[g,cell,d] += factor * probability
                        lower_cancelled[g,cell,d] += unscaled * probability

    assert lower and lower.keys() <= upper.keys()
    assert all(0 < w <= upper[k] for k,w in lower.items())
    return lower, upper, pullback, groups, certificate, (lower_cancelled,upper_cancelled)


def field(traffic):
    out = defaultdict(F)
    for (_,cell,_),w in traffic.items():
        out[cell] += w
    return out


def fee_field(traffic, denominator):
    return {key:w/(1+denominator.get(key[1],F(0))) for key,w in traffic.items()}


def physical_density(traffic, mu):
    pairs = defaultdict(lambda: defaultdict(lambda: defaultdict(F)))
    for (g,cell,d),w in traffic.items():
        pairs[cell[0],g[1]][cell][d] += w / mu[g[1]]
    return pairs


def pair_overlap(forward, reverse, mu, atom_mass):
    f, r = physical_density(forward,mu), physical_density(reverse,mu)
    pairs, same_bin = F(0), F(0)
    support, bin_support = F(0), F(0)
    masks, bin_masks = set(), set()
    for (z,q),by_z in f.items():
        by_q = r.get((q,z),{})
        for a,fa in by_z.items():
            for b,rb in by_q.items():
                measure = atom_mass[a] * atom_mass[b]
                pairs += measure * min(sum(fa.values()),sum(rb.values()))
                support += measure
                masks.add((z,q))
                keys = fa.keys() & rb.keys()
                if keys:
                    bin_masks.add((z,q))
                    bin_support += measure
                    same_bin += measure * sum(min(fa[k],rb[k]) for k in keys)
    assert same_bin <= pairs and bin_support <= support
    return pairs, same_bin, support, bin_support, masks, bin_masks


def recall_density(traffic, pullback, mu, atom_mass):
    out = defaultdict(lambda: defaultdict(F))
    recalled, unmatched = F(0), F(0)
    for (g,cell,d),w in traffic.items():
        outcomes = pullback.get((g,cell[0],d))
        if not outcomes:
            unmatched += w * atom_mass[cell]
            continue
        recalled += w * atom_mass[cell]
        for e, prob in outcomes.items():
            # Exact physical q law on its cell. Owner W is the same uniform
            # law throughout this g group, and the other owner is restored by e.
            assert e[1][1] == cell[0] and e[2] == g
            out[e][cell] += prob * w / mu[g[1]]
    assert sum(w*atom_mass[cell]*mu[e[2][1]] for e, values in out.items()
               for cell,w in values.items()) == recalled
    return out, recalled, unmatched


def full_row_overlap(rows, forward, reverse, mu, atom_mass):
    amount, row_mass = F(0), F(0)
    rows_hit = set()
    for e,w in rows.items():
        t,x,g = e
        f, r = forward.get(e,{}), reverse.get((t,g,x),{})
        if not f or not r:
            continue
        rows_hit.add(e)
        z_total = sum(atom_mass[cell] for cell in f)
        q_total = sum(atom_mass[cell] for cell in r)
        row_mass += w * z_total * q_total / (mu[x[1]] * mu[g[1]])
        for a,fa in f.items():
            for b,rb in r.items():
                amount += atom_mass[a]*atom_mass[b]*min(fa,rb)
    return amount, row_mass, rows_hit


def actual_locations(rows, f_global, r_global, mu, atom_mass):
    def by_mask(field):
        totals = defaultdict(F)
        for a,w in field.items():
            if w:
                totals[a[0]] += atom_mass[a]
        return totals

    f, r = by_mask(f_global), by_mask(r_global)
    z, q, both = F(0), F(0), F(0)
    for (_,(_,zm),(_,qm)),w in rows.items():
        p, v = f[zm]/mu[zm], r[qm]/mu[qm]
        assert 0 <= p <= 1 and 0 <= v <= 1
        z += w*p
        q += w*v
        both += w*p*v
    assert both <= min(z,q)
    return z,q,both


def selected_density(rows, traffic, cancelled, mu, atom_mass):
    # S8 compares actual use in G to competitive eligibility in the same G.
    # This is a one-side raw (unpriced) diagnostic before sharing denominators.
    group_mass, group_y, source = defaultdict(F), defaultdict(F), defaultdict(F)
    for (_,(_,z),g),w in rows.items():
        group_mass[g] += w
        group_y[g,z] += w
        source[z] += w/mu[z]
    numerator, s8 = defaultdict(F), defaultdict(F)
    assert cancelled.keys() == traffic.keys()
    for key,w in traffic.items():
        g,cell,_ = key
        h = group_y[g,cell[0]] / (group_mass[g] * mu[cell[0]])
        numerator[cell] += w*h
        s8[cell] += cancelled[key]*h
    assert all(source[cell[0]] > 0 and v > 0 for cell,v in numerator.items())
    assert all(0 < v <= 2*source[cell[0]] for cell,v in s8.items())
    total = sum(w*atom_mass[cell] for cell,w in field(traffic).items())
    return (sum(atom_mass[cell]*a for cell,a in numerator.items()) / total,
            sum(atom_mass[cell]*a for cell,a in s8.items()) / (2*sum(rows.values())))


def report_match(rows, forward, reverse, mu, atom_mass, pullbacks, label):
    right_cost = sum(w*atom_mass[k[1]] for k,w in forward.items())
    left_cost = sum(w*atom_mass[k[1]] for k,w in reverse.items())
    pair, same, pair_mu, same_mu, pairs, same_pairs = pair_overlap(forward,reverse,mu,atom_mass)
    f_rows,f_recalled,f_missing = recall_density(forward,pullbacks[0],mu,atom_mass)
    r_rows,r_recalled,r_missing = recall_density(reverse,pullbacks[1],mu,atom_mass)
    assert f_recalled+f_missing == right_cost and r_recalled+r_missing == left_cost
    strict, strict_mass, identifiers = full_row_overlap(rows,f_rows,r_rows,mu,atom_mass)
    assert 0 <= strict <= same <= pair <= min(right_cost,left_cost)
    raw = sum(rows.values())
    print(" ",label,"match fees",*(show(x) for x in (pair,same,strict)),
          "row mass share",show(strict_mass/raw), "rows",sorted(identifiers))
    print("   matched mu^2 / same-old-bin mu^2",show(pair_mu),show(same_mu),
          "source mask pairs",sorted(pairs),"same-old-bin pairs",sorted(same_pairs))
    print("   recall unavailable fee fractions", show(f_missing/right_cost), show(r_missing/left_cost),
          "candidate masks each side", len(physical_density(forward,mu)),
          len(physical_density(reverse,mu)))
    return (pair,same,strict,strict_mass), (pairs,same_pairs,identifiers)


def extra_sqrt_interval(x, bits=72):
    from math import isqrt

    denominator = 1 << bits
    k = isqrt((x.numerator << (2*bits)) // x.denominator)
    lo = F(k, denominator)
    return lo, lo if lo*lo == x else lo + F(1, denominator)


def extra_arrival_scale(d, bits=72):
    from math import isqrt

    denominator = 1 << bits
    power = F(2)**(d+1)
    k = isqrt(isqrt((power.numerator << (4*bits)) // power.denominator))
    lo = F(k, denominator)
    hi = lo if lo**4 == power else lo + F(1, denominator)
    assert lo**4 <= power <= hi**4
    return lo*F(129,128), hi*F(129,128)


def extra_score_square(left, right, a, share, bilateral):
    from math import prod

    alo, ahi = a
    mins, maxs = [], []
    for (l,h),(p,q) in zip(left,right,strict=True):
        mins.append(max(F(0),p-h,l-q))
        maxs.append(max(abs(l-q),abs(h-p)))
    p_lo = prod(max(F(0),1-v/alo) for v in maxs)
    p_hi = prod(max(F(0),1-v/ahi) for v in mins)
    volumes = []
    for target in (left,right) if bilateral else (right,):
        volumes.append((prod(1+(h-l)/ahi for l,h in target),
                        prod(1+(h-l)/alo for l,h in target)))
    u_lo, u_hi = (max(v[i] for v in volumes) for i in (0,1))
    assert 0 < p_lo <= p_hi <= 1 and 1 < u_lo <= u_hi
    return share/(u_hi*p_hi), share/(u_lo*p_lo)


def traffic_extra_checks(name, rows, atoms, mu, old_bins, row_tools):
    """Precommitted one-box forecasts and exact continuous scored subflows."""
    winner = {z:max(v,key=lambda record: record[1]) for z,v in atoms.items()}
    endpoint, bin_mass, choices = defaultdict(F), defaultdict(F), defaultdict(lambda: defaultdict(F))
    for (t,x,g), w in rows.items():
        d = old_bins[t]
        endpoint[x] += w
        bin_mass[x,d] += w
        choices[x,d][g[1]] += w
    assert rows == transpose(rows) and len(set(old_bins.values())) == 2
    best = {}
    for k, target in choices.items():
        best[k] = max(sorted(target),key=lambda z: target[z]*winner[z][1]/mu[z])
    posterior = {k:w/endpoint[k[0]] for k,w in bin_mass.items()}
    for x in endpoint:
        assert sum(w for (side,_),w in posterior.items() if side == x) == 1
    scale = {d:extra_arrival_scale(d) for d in set(old_bins.values())}
    total = sum(rows.values())
    show_interval = row_tools["interval_text"]
    print("ARRIVAL", name, "all 230 rows use physical z,q with owner laws retained;"
          " forecasts frozen on own full old-parent/source-cell label;"
          " high-dimensional history gate empty")
    main_results = {}
    for policy in ("uniform", "posterior", "posterior-left-uniform-right"):
        for bilateral in (False,True):
            hit = F(0)
            selected_lo = {F(1):F(0),F(1,2):F(0)}
            selected_hi = dict(selected_lo)
            lower, upper = F(0), F(0)
            count = 0
            for (t,x,g), weight in rows.items():
                d = old_bins[t]
                z,q = x[1],g[1]
                if q != best[x,d] or (bilateral and z != best[g,d]):
                    continue
                # The right microcell is the left menu hit: q-z belongs to
                # B_q-z. Restrict z to its fixed microcell for the certified
                # interval; for bilateral forecasts it is also the right hit.
                left,wz = winner[z]
                right,wq = winner[q]
                weight *= wz*wq/(mu[z]*mu[q])
                alpha = F(1,2) if policy == "uniform" else posterior[x,d]
                gamma = posterior[g,d] if policy == "posterior" else F(1,2)
                lo,hi = extra_score_square(left,right,scale[d],alpha*gamma,bilateral)
                hit += weight
                count += 1
                lower += weight*extra_sqrt_interval(lo)[0]
                upper += weight*extra_sqrt_interval(hi)[1]
                for cut in selected_lo:
                    if lo >= cut*cut:
                        selected_lo[cut] += weight
                    if hi >= cut*cut:
                        selected_hi[cut] += weight
            assert count and 0 < hit <= total and 0 < lower <= upper
            assert all(0 <= selected_lo[k] <= selected_hi[k] <= hit for k in selected_lo)
            print(" ",policy,"two-predictors conservative max U" if bilateral else "left forecast U",
                  "microcell hit rows",count,"mass fraction",show(hit/total),
                  "score integral / original mass",show_interval((lower/total,upper/total),13))
            for k in (F(1),F(1,2)):
                print("   threshold",k,"qualified original fraction",
                      show_interval((selected_lo[k]/total,selected_hi[k]/total),13),
                      "certified original mass lower",show(selected_lo[k]))

            if not bilateral:
                main_results[policy] = (lower, upper, selected_lo)
    assert main_results["posterior"][0] > main_results["uniform"][1]
    for threshold in (F(1), F(1, 2)):
        assert main_results["posterior"][2][threshold] > main_results["uniform"][2][threshold] > 0
    print("PASS strict advantage for own-endpoint scale weights on fixed positive-width subcells")


def verify_fixture(name, stage, row_tools, archived):
    rows,cubes,_,m,j,bits,mu = archived["reconstruct"](stage)
    mids = tuple(stage["middle_labels"])
    old_bins = {t:bin_volume(m[t]) for t in mids}
    denominator = {
        t: sum(w for e,w in rows.items() if e[0] == t) * m[t] / j[t] for t in mids
    }
    active = {arm[1] for _,x,g in rows for arm in (x,g)}
    atoms = archived["source_atoms"](cubes,stage["density"],mu,active,row_tools["axis_intervals"])
    atom_mass = {(z,i):w for z,v in atoms.items() for i,(_,w) in enumerate(v)}
    fl,fu,fp,fg,fc,f_cancelled = build_direction(rows,atoms,mu,bits,old_bins,denominator,archived,cubes)
    transposed = transpose(rows)
    rl,ru,rp,_,_,r_cancelled = build_direction(transposed,atoms,mu,bits,old_bins,denominator,archived,cubes)
    assert rows == transposed and fl == rl and fu == ru and f_cancelled == r_cancelled
    fmin,fmax,rmin,rmax = map(field,(fl,fu,rl,ru))
    arc_field,_,_ = archived["active_state"](rows,fg,set(rows),denominator,fc)
    assert arc_field == fmin
    common_min = {s:fmin.get(s,F(0))+rmin.get(s,F(0)) for s in fmin.keys()|rmin.keys()}
    common_max = {s:fmax.get(s,F(0))+rmax.get(s,F(0)) for s in fmax.keys()|rmax.keys()}
    assert all(value <= common_max[s] for s,value in common_min.items())
    total = sum(rows.values())
    print("TRAFFIC",name,"positive rows",len(rows),"true G",len(fg),"positive source boxes",len(atom_mass),
          "true price mass",show(total),"threshold-record true mass bins",old_bins)
    print("  archive high-dimensional condition empty; all fractions use original price rows")
    for label,f,r,f_pos,r_pos,cancelled in (("inner",fl,rl,fmin,rmin,f_cancelled[0]),
                                            ("outer",fu,ru,fmax,rmax,f_cancelled[1])):
        levels = {s:f_pos.get(s,F(0))+r_pos.get(s,F(0)) for s in f_pos.keys()|r_pos.keys()}
        fee = sum(atom_mass[s]*v/(1+v) for s,v in levels.items())
        individual = sum(atom_mass[s]*v/(1+v) for s,v in f_pos.items())
        assert 0 < fee < 2*individual
        real = actual_locations(rows,f_pos,r_pos,mu,atom_mass)
        density, s8 = selected_density(rows,f, cancelled,mu,atom_mass)
        print(" ",label,"one-side raw/fee",show(sum(atom_mass[s]*w for s,w in f_pos.items())),
              show(individual),"reverse equal", f==r,
              "both physical sides union fee",show(fee),
              "separate minus union fee", show(2*individual-fee))
        print("   actual z/q/both source-hit fractions",*(show(w/total) for w in real),
              "first-side pool-weighted actual density",show(density),"S8 integrated fraction",show(s8))
    lower, _ = report_match(rows,fee_field(fl,common_max),fee_field(rl,common_max),
                            mu,atom_mass,(fp,rp),"validated lower")
    upper, _ = report_match(rows,fee_field(fu,common_min),fee_field(ru,common_min),
                            mu,atom_mass,(fp,rp),"validated upper")
    assert all(0 < l <= u for l,u in zip(lower,upper,strict=True))
    lower_global_both = actual_locations(rows,fmin,rmin,mu,atom_mass)[2]
    exact_one_side_lower = sum(atom_mass[s]*w/(1+common_max[s]) for s,w in fmin.items())
    assert 100*upper[3] < lower_global_both and upper[0] < exact_one_side_lower/10**6
    print("  certified upper strict-row / lower globally hit actual mass",show(upper[3]/lower_global_both),
          "upper matched charge / lower one-side charge",show(upper[0]/exact_one_side_lower))
    print("  structural zero from full exterior upper",
          dict(zip(("physical pair","same threshold bin","same full row"),
                   (not x for x in upper[:3]),strict=True)))
    print("  lower absent but upper permits",
          dict(zip(("physical pair","same threshold bin","same full row"),
                   (not l and u>0 for l,u in zip(lower[:3],upper[:3],strict=True)),strict=True)))

    traffic_extra_checks(name, rows, atoms, mu, old_bins, row_tools)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for number in PINS:
        parser.add_argument(f"--archive-{number}",type=Path,default=ROUNDS/str(number)/"research.zip")
    args = parser.parse_args()
    paths = {number:getattr(args,f"archive_{number}") for number in PINS}
    for number,path in paths.items():
        assert sha256(path.read_bytes()).hexdigest() == PINS[number]
        print("PIN",number,PINS[number])
    with ZipFile(paths[834]) as z:
        context = {"__name__":"archived_potential834"}
        exec(compile(z.read("potential834.py"),"potential834.py","exec"),context)
    fixtures,row_tools = context["load_inputs"](paths[814],paths[833])
    for name,stage in fixtures:
        verify_fixture(name,stage,row_tools,context)
    print("PASS same-physical-source, threshold-bin, and full-history traffic bounds")


if __name__ == "__main__":
    main()
