"""Repeat the round-835 checks against the four pinned input archives."""

import argparse
from concurrent.futures import ThreadPoolExecutor
from hashlib import file_digest, sha256
import json
import os
from pathlib import Path
import subprocess
import sys
from zipfile import BadZipFile, ZipFile


PRIOR_ARCHIVES = {
    "814": "891d8cbcbd35537e6abc18c938e53b1b4f300327357c24c8d14a51a46ad5e190",
    "832": "3eef2e83aab159531aa5b1049715568779e8c599998dde494ce0ea0e238c0303",
    "833": "8c37039dba896615b13e4de9c1bfe2a56ee8f539e192c11386285237f2537b17",
    "834": "15b8e65b789dbe30cd08ce0b376ae93fd19fa2341b895d15c50a2ed9cee284e8",
}
ARCHIVE_OPTIONS = tuple((round_number, f"--archive-{round_number}") for round_number in PRIOR_ARCHIVES)
ARCHIVE_LABELS = {round_number: f"<R{round_number} research.zip>" for round_number in PRIOR_ARCHIVES}
CHECKS = (
    ("actors835.py", tuple(item for item in ARCHIVE_OPTIONS if item[0] != "834")),
    ("traffic835.py", ARCHIVE_OPTIONS),
    ("chains835.py", ()),
)
MAX_JOBS = 3
SETTINGS = {"PYTHONHASHSEED": "0", "PYTHONIOENCODING": "utf-8"}
LOG_HEADER = b"Round 835 computational verification\n"


def digest(path):
    with path.open("rb") as source:
        return file_digest(source, "sha256").hexdigest()


def verify_archives(paths):
    member_hashes = {}
    for round_number, expected in PRIOR_ARCHIVES.items():
        path = paths[round_number]
        actual = digest(path)
        if actual != expected:
            raise ValueError(f"R{round_number} archive SHA-256 mismatch: {actual}; expected {expected}")
        with ZipFile(path) as archive:
            manifest = json.loads(archive.read("MANIFEST.json"))
            if manifest["round"] != int(round_number):
                raise ValueError(f"R{round_number} manifest has the wrong round")
            members = manifest["members"]
            names = archive.namelist()
            if len(names) != len(set(names)) or set(names) != set(members) | {"MANIFEST.json"}:
                raise ValueError(f"R{round_number} manifest does not match its ZIP members")
            for name, member_hash in members.items():
                actual_member_hash = sha256(archive.read(name)).hexdigest()
                if actual_member_hash != member_hash:
                    raise ValueError(f"R{round_number} member {name} failed SHA-256 validation")
            member_hashes[round_number] = members
    return member_hashes


def check_arguments(options, paths):
    arguments = []
    for round_number, flag in options:
        arguments.extend((flag, str(paths[round_number])))
    return arguments


def run_check(directory, paths, check):
    script, options = check
    return subprocess.run(
        [sys.executable, "-B", script, *check_arguments(options, paths)],
        cwd=directory,
        env={**os.environ, **SETTINGS},
        capture_output=True,
        check=False,
    )


def heading(script):
    return f"\n===== {script} =====\n".encode()


def write_transcript(evidence, results):
    metadata = json.dumps(evidence, ensure_ascii=False, sort_keys=True).encode()
    sections = [LOG_HEADER, b"Evidence JSON: ", metadata, b"\n"]
    for (script, _), result in zip(CHECKS, results, strict=True):
        sections.extend(
            (
                heading(script),
                b"----- stdout -----\n",
                result.stdout,
                b"\n----- stderr -----\n",
                result.stderr,
                b"\n",
            )
        )
    sections.append(f"\nReplay status: {evidence['status']}\n".encode())
    return b"".join(sections)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for round_number, flag in ARCHIVE_OPTIONS:
        parser.add_argument(flag, type=Path, required=True, help=f"Path to the original R{round_number} research.zip")
    parser.add_argument("--jobs", type=int, choices=range(1, MAX_JOBS + 1), default=MAX_JOBS)
    parser.add_argument("--output", type=Path, help="Save the full transcript here; default is stdout")
    args = parser.parse_args()

    replay = Path(__file__).resolve()
    directory = replay.parent
    paths = {number: getattr(args, f"archive_{number}").resolve() for number in PRIOR_ARCHIVES}
    try:
        archive_members = verify_archives(paths)
    except (OSError, ValueError, KeyError, BadZipFile) as error:
        parser.error(str(error))
    script_hashes = {script: digest(directory / script) for script, _ in CHECKS}
    replay_hash = digest(replay)
    protected_paths = {replay, *paths.values(), *((directory / script) for script in script_hashes)}
    if args.output and args.output.resolve() in protected_paths:
        parser.error("the output must be distinct from all input files")

    with ThreadPoolExecutor(max_workers=args.jobs) as workers:
        pending = [workers.submit(run_check, directory, paths, check) for check in CHECKS]
        results = [job.result() for job in pending]

    for round_number, path in paths.items():
        if digest(path) != PRIOR_ARCHIVES[round_number]:
            parser.error(f"{path} changed during replay")
    if digest(replay) != replay_hash:
        parser.error("the replay script changed during replay")
    for script, script_hash in script_hashes.items():
        if digest(directory / script) != script_hash:
            parser.error(f"{script} changed during replay")

    runs = {}
    for (script, options), result in zip(CHECKS, results, strict=True):
        runs[script] = {
            "arguments": check_arguments(options, ARCHIVE_LABELS),
            "script_sha256": script_hashes[script],
            "exit": result.returncode,
            "stdout_bytes": len(result.stdout),
            "stdout_sha256": sha256(result.stdout).hexdigest(),
            "stderr_bytes": len(result.stderr),
            "stderr_sha256": sha256(result.stderr).hexdigest(),
        }
    passed = all(result.returncode == 0 for result in results)
    evidence = {
        "round": 835,
        "status": "PASS" if passed else "FAIL",
        "python_version": sys.version,
        "dependencies": {},
        "settings": SETTINGS,
        "jobs": args.jobs,
        "inputs": PRIOR_ARCHIVES,
        "input_members": archive_members,
        "replay_sha256": replay_hash,
        "individual_runs": runs,
    }
    transcript = write_transcript(evidence, results)
    if args.output:
        args.output.write_bytes(transcript)
    else:
        sys.stdout.buffer.write(transcript)
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
