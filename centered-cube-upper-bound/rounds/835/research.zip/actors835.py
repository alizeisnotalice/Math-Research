"""Exact positive-width forecasts for one, two, and three real right sources."""

import argparse
from collections import defaultdict
from decimal import Context, Decimal, ROUND_CEILING, ROUND_FLOOR, ROUND_HALF_EVEN
from fractions import Fraction as F
from functools import cache
from hashlib import sha256
from itertools import product
from pathlib import Path
from platform import python_version
from zipfile import ZipFile


ROUNDS = Path(
    "/Volumes/data/CodexProjects/T/Math-Research-cube-sqrt-20261114/"
    "centered-cube-upper-bound/rounds"
)
PINS = {
    814: "891d8cbcbd35537e6abc18c938e53b1b4f300327357c24c8d14a51a46ad5e190",
    832: "3eef2e83aab159531aa5b1049715568779e8c599998dde494ce0ea0e238c0303",
    833: "8c37039dba896615b13e4de9c1bfe2a56ee8f539e192c11386285237f2537b17",
}
FZERO = F(0)


def archive_module(path, member):
    with ZipFile(path) as archive:
        code = archive.read(member)
    print("MEMBER SHA256", member, sha256(code).hexdigest())
    namespace = {"__name__": "archive_" + member.removesuffix(".py")}
    exec(compile(code, member, "exec"), namespace)
    return namespace


def report_interval(x, digits=13):
    scale = 10**digits
    lo = x.numerator * scale // x.denominator
    hi = -((-x.numerator * scale) // x.denominator)

    def text(k):
        return f"{k // scale}.{k % scale:0{digits}d}"

    return text(lo), text(hi)


def two_axis_marginals(cubes, density, source_mass, active, row):
    axes = tuple(row["axis_intervals"](cubes, i, density) for i in range(4))
    others = {((1 << len(cubes)) - 1): F(1)}
    for axis in axes[2:]:
        combined = defaultdict(F)
        for (mask, mass), (a, b, bit, level) in product(others.items(), axis):
            combined[mask & bit] += mass * (b-a) * level
        others = combined
    results = defaultdict(list)
    raw_mass = defaultdict(F)
    for (a, b, m1, d1), (c, d, m2, d2) in product(*axes[:2]):
        by_mask = defaultdict(F)
        for bit, mass in others.items():
            by_mask[bit & m1 & m2] += d1 * d2 * mass
        for mask, dens in by_mask.items():
            raw_mass[mask] += (b-a) * (d-c) * dens
            if mask in active and dens:
                results[mask].append((a, b, c, d, dens/source_mass[mask]))
    assert raw_mass == source_mass and results.keys() == active
    assert all(profile_mass(profile) == 1 for profile in results.values())
    return {mask: tuple(profile) for mask, profile in results.items()}


def profile_mass(profile):
    return sum((b-a) * (d-c) * w for a, b, c, d, w in profile)


def mixture(profile_by_mask, weights):
    rectangles = defaultdict(F)
    for mask, weight in weights.items():
        for a, b, c, d, d0 in profile_by_mask[mask]:
            rectangles[a, b, c, d] += weight*d0
    answer = tuple((*rect, weight) for rect, weight in sorted(rectangles.items()) if weight)
    assert profile_mass(answer) == sum(weights.values())
    return answer


@cache
def project(profile, direction):
    """CDF as a finite sum of positive-part powers with rational coefficients."""
    changes = defaultdict(F)
    for a, b, c, d, w in profile:
        if direction == "axis":
            changes[a] += w*(d-c)
            changes[b] -= w*(d-c)
        else:
            assert direction in ("plus", "minus")
            if direction == "minus":
                c, d = -d, -c
            changes[a+c] += w
            changes[a+d] -= w
            changes[b+c] -= w
            changes[b+d] += w
    terms = tuple(sorted((x, w) for x, w in changes.items() if w))
    assert terms and sum(w for _, w in terms) == 0
    return 1 if direction == "axis" else 2, terms


@cache
def cdf(projected, x):
    deg, terms = projected
    return sum((w*(x-a)**deg for a, w in terms if x > a), FZERO) / deg


@cache
def density_at(projected, x):
    deg, terms = projected
    return sum((w*(x-a)**(deg-1) for a, w in terms if x > a), FZERO)


def polynomial_product(left, right):
    result = [FZERO] * (len(left)+len(right)-1)
    for i, a in enumerate(left):
        for j, b in enumerate(right):
            result[i+j] += a*b
    return result


def projected_moments(anchor, target, half_width, kmax):
    x0, x1 = anchor[1][0][0], anchor[1][-1][0]
    cuts = {a for a, _ in anchor[1]}
    cuts.update(x for a, _ in target[1] for x in (a-half_width, a+half_width) if x0 < x < x1)
    edges = sorted(cuts)
    result = [FZERO]*kmax

    def window(x):
        return cdf(target, x+half_width) - cdf(target, x-half_width)

    for lo, hi in zip(edges, edges[1:]):
        width = hi-lo
        q1 = density_at(anchor, lo+width/4)
        q3 = density_at(anchor, hi-width/4)
        if q1 == q3 == 0:
            continue
        anchor_slope = 2*(q3-q1)
        anchor_line = [q1-anchor_slope/4, anchor_slope]
        start, middle, end = window(lo), window((lo+hi)/2), window(hi)
        assert min(start, middle, end) >= 0
        p2 = 2*(start+end-2*middle)
        prob = [start, end-start-p2, p2]
        current = anchor_line
        for i in range(kmax):
            current = polynomial_product(current, prob)
            result[i] += width * sum(w/(j+1) for j, w in enumerate(current))
    return tuple(result)


def tensor_product(left, right):
    result = defaultdict(F)
    for (i, j), a in left.items():
        for (k, l), b in right.items():
            result[i+k, j+l] += a*b
    return result


def box_moments(anchor, target, half_width, kmax):
    x_cuts = sorted({x for a, b, _, _, _ in target for x in
                     (a-half_width, a+half_width, b-half_width, b+half_width)})
    y_cuts = sorted({y for _, _, c, d, _ in target for y in
                     (c-half_width, c+half_width, d-half_width, d+half_width)})
    result = [FZERO]*kmax

    def length(a, b, x):
        return max(FZERO, min(b, x+half_width)-max(a, x-half_width))

    @cache
    def window(x, y):
        return sum(w*length(a, b, x)*length(c, d, y) for a, b, c, d, w in target)

    for a, b, c, d, weight in anchor:
        x_edges = [a, *(x for x in x_cuts if a < x < b), b]
        y_edges = [c, *(y for y in y_cuts if c < y < d), d]
        for (lo, hi), (bot, top) in product(zip(x_edges, x_edges[1:]), zip(y_edges, y_edges[1:])):
            f00, f10, f01, f11 = (window(x, y) for x, y in
                                   ((lo, bot), (hi, bot), (lo, top), (hi, top)))
            if max(f00, f10, f01, f11) == 0:
                continue
            law = {(0, 0): f00, (1, 0): f10-f00, (0, 1): f01-f00,
                   (1, 1): f11-f10-f01+f00}
            current = {(0, 0): weight*(hi-lo)*(top-bot)}
            for i in range(kmax):
                current = tensor_product(current, law)
                result[i] += sum(v/((m+1)*(n+1)) for (m, n), v in current.items())
    return tuple(result)


def source_groups(rows):
    """Freeze physical z; disintegrate the full right record without seeing u,U."""
    raw = defaultdict(dict)
    for (t, (u, z), (g, q)), weight in rows.items():
        raw[z][t, u, g, q] = weight
    mass = {z: sum(block.values()) for z, block in raw.items()}
    assert sum(mass.values()) == sum(rows.values())
    posteriors = {z: {history: w/mass[z] for history, w in block.items()} for z, block in raw.items()}
    assert all(sum(p.values()) == 1 and min(p.values()) > 0 for p in posteriors.values())
    return mass, posteriors


def verify_moments():
    uniform = ((F(0), F(1), F(0), F(1), F(1)),)
    axis = project(uniform, "axis")
    exact = tuple(2*(1-F(1, 2)**(j+1))/(j+1) for j in (1, 2, 3))
    assert projected_moments(axis, axis, F(1, 2), 3) == exact
    assert box_moments(uniform, uniform, F(1, 2), 3) == tuple(x*x for x in exact)
    for direction in ("plus", "minus"):
        diagonal = project(uniform, direction)
        assert projected_moments(diagonal, diagonal, F(1), 1) == (F(11, 12),)


def checked_moments(values):
    assert all(0 <= x <= 1 for x in values)
    assert all(a >= b for a, b in zip(values, values[1:]))
    assert all(values[0]**i <= x for i, x in enumerate(values, start=1))


def fixture(name, stage, prior, row):
    cubes, _, _, _, _, rows = prior["verified_rows"](stage)
    mu = {cell["mask"]: F(cell["mass"]) for cell in stage["cells"] if F(cell["mass"]) > 0}
    assert all(1 <= F(p["radius"]) < 2 for p in stage["parents"])
    full_degree = max(F(stage["degrees"][t]["full_d"]) for t in stage["middle_labels"])
    assert 0 < full_degree < 1 and stage["dimension"] == 4
    active = {z for _, (_, z), _ in rows} | {q for _, _, (_, q) in rows}
    profiles = two_axis_marginals(tuple(cubes.values()), stage["density"], mu, active, row)
    mass, posteriors = source_groups(rows)
    total = sum(mass.values())
    print("FIXTURE", name, "original positive rows", len(rows), "left source strata", len(mass),
          "physical octave [1,2)", "R", 1, "original mass", total)
    print("R813 HIGH-DEGREE GATE empty", "max full degree", report_interval(full_degree),
          "threshold 2 log(6)^3 > 1")

    diversities = (defaultdict(F), defaultdict(F))
    by_z = {}
    for z, full in posteriors.items():
        mask_weight = defaultdict(F)
        father_mask_weight = defaultdict(lambda: defaultdict(F))
        for (_, _, g, q), p in full.items():
            mask_weight[q] += p
            father_mask_weight[g][q] += p
        father_weight = {g: sum(vals.values()) for g, vals in father_mask_weight.items()}
        assert sum(father_weight.values()) == 1
        target = mixture(profiles, mask_weight)
        by_father = {g: mixture(profiles, weights) for g, weights in father_mask_weight.items()}
        by_z[z] = target, by_father
        for j, d in ((2, diversities[0]), (3, diversities[1])):
            for group in product(tuple(father_weight), repeat=j):
                prob = F(1)
                for g in group:
                    prob *= father_weight[g]
                d[len(set(group))] += prob * mass[z] / total
    assert all(sum(d.values()) == 1 for d in diversities)
    print("NUMBER OF DISTINCT RIGHT FATHERS", [{j: report_interval(w) for j, w in sorted(d.items())}
                                               for d in diversities])

    for eta in (F(1, 8192), F(1, 2048), F(1, 64)):
        half_width = 2 * eta
        sums = defaultdict(lambda: [FZERO]*3)
        forecast = defaultdict(lambda: [FZERO]*2)

        def accumulate(into, label, moments, w):
            for i, x in enumerate(moments):
                into[label][i] += x*w

        for z, (target, by_father) in by_z.items():
            weight = mass[z]/total
            left = profiles[z]
            for direction in ("axis", "plus", "minus"):
                source, right = project(left, direction), project(target, direction)
                moments = projected_moments(source, right, half_width, 3)
                checked_moments(moments)
                accumulate(sums, direction, moments, weight)
                if direction == "plus":
                    same_father = [FZERO]*3
                    for subprofile in by_father.values():
                        component = project(subprofile, direction)
                        for i, x in enumerate(projected_moments(source, component, half_width, 3)):
                            same_father[i] += x
                    diverse = tuple(a-b for a, b in zip(moments, same_father, strict=True))
                    assert diverse[0] == 0 and min(diverse) >= 0
                    accumulate(sums, "plus and at least two fathers", diverse, weight)
                if direction != "minus":
                    accumulate(forecast, direction,
                               projected_moments(right, right, half_width, 2), weight)
            accumulate(sums, "two-axis box", box_moments(left, target, half_width, 3), weight)
            accumulate(forecast, "two-axis box", box_moments(target, target, half_width, 2), weight)

        for label, values in sums.items():
            if label != "plus and at least two fathers":
                checked_moments(values)
        for values in forecast.values():
            checked_moments(values)
        assert all(x <= a for x, a in zip(sums["two-axis box"], sums["axis"], strict=True))
        assert all(x <= a for x, a in zip(forecast["two-axis box"], forecast["axis"], strict=True))
        print("Z-ANCHORED original fractions, k=1,2,3", "eta", eta,
              {k: tuple(report_interval(x) for x in v) for k, v in sums.items()})
        print("Q1-ANCHORED history diagnostic fractions, k=1,2 companions", "eta", eta,
              {k: tuple(report_interval(x) for x in v) for k, v in forecast.items()})


BANDS_FLOOR = Context(prec=55, rounding=ROUND_FLOOR)
BANDS_CEIL = Context(prec=55, rounding=ROUND_CEILING)
BANDS_NEAR = Context(prec=55, rounding=ROUND_HALF_EVEN)


def bands_monotone(interval, op):
    """Outward bounds using correctly rounded Decimal at directed arguments."""
    bounds = []
    for x, ctx, step in zip(interval, (BANDS_FLOOR, BANDS_CEIL),
                            (BANDS_FLOOR.next_minus, BANDS_CEIL.next_plus), strict=True):
        arg = ctx.divide(Decimal(x.numerator), Decimal(x.denominator))
        bounds.append(F(step(op(arg))))
    return tuple(bounds)


def bands_ln(lo, hi=None):
    if hi is None:
        hi = lo
    assert 0 < lo <= hi
    if lo == hi == 1:
        return F(0), F(0)
    return bands_monotone((lo, hi), BANDS_NEAR.ln)


def bands_report(interval, digits=10):
    unit = 10**digits
    lo, hi = (x * unit for x in interval)
    a = lo.numerator // lo.denominator
    b = -((-hi.numerator) // hi.denominator)

    def text(x):
        whole, fract = divmod(abs(x), unit)
        return f"{'-' if x < 0 else ''}{whole}.{fract:0{digits}d}"

    return f"[{text(a)}, {text(b)}]"


def bands_geometry(n, count, stride, active):
    """Certify the same two positive-width boxes in each true last-root band."""
    assert 2 <= n and 0 < active <= n and count > 0 and stride > 0
    pad = F(1, 1024*n)  # source box half side, in units of band side
    sides = tuple(F(1, 2**(stride * j)) for j in range(count))
    centers = tuple(F(8*j) for j in range(count))  # first physical coordinate
    rho_exponent = (count - 1)*stride + 6
    rho = sides[-1] / 64  # equal receiving volume in every band
    assert rho == F(1, 2**rho_exponent)
    for b in sides:
        # Source centers are c_j ± b/4 on the first 'active' coordinates,
        # staying at c_j on other coordinates. Source density is constant
        # on either source box, whose individual mass is b**n/2.
        assert 2*pad < F(1, 2)
        assert b/4 + pad*b + rho/2 < 3*b/8
    if count > 1:
        assert min(y-x for x,y in zip(centers, centers[1:])) == 8
        assert 8 - (F(1, 4) + pad) - rho/2 > 1
    # Any s≤2 sees only the local band, throughout its real receiver box.
    # At 3b/4<s<b it contains its whole band and strictly exceeds.
    # For b<s<=2 its mass is <= b**n < s**n; for s>2 the entire input
    # mass has the geometric upper bound below (no other root can return).
    ratio = F(1, 2**(stride*n))
    assert ratio <= F(1, 4)
    total_cap = 1 / (1-ratio)
    assert total_cap <= F(4, 3) < 2 < 2**n

    # On an ordered cross tile pair, both endpoint widths remain positive.
    # Genuine absolute displacement ranges are wide on active axes and
    # have 0 as their lower endpoint on the other axes.
    div = 1 + F(2, n)
    dlo, dhi = F(1, 2) - 2*pad, F(1, 2) + 2*pad
    assert 0 < dlo <= dhi < 1
    near_low = bands_ln(1 - dlo/div)
    near_high = bands_ln(1 - dhi/div)
    tail = bands_ln(1 - 2*pad/div)
    phi = -active * near_low[1], -active * near_high[0] - (n-active) * tail[0]
    h = phi[0] // 1
    assert h > 0 and h <= phi[0] <= phi[1] < h+1
    assert -n * tail[0] < 1  # Same-tile pairs have distinct label h=0.
    print("BANDS TRUE ROOTS", "n", n, "scale count", count, "b_j", f"2^(-{stride}j)",
          "absolute D_j", f"2^(-{stride*n}j)", "active displaced axes", active,
          "whole cross-row phi", bands_report(phi), "h", h, "future cap every s>b",
          "each two-arm band mass", f"2^(-{rho_exponent*n})",
          "each cross band mass", f"2^(-{rho_exponent*n+1})")
    return pad, h


def bands_risk(n, pad, wide):
    # D=b**n. Normalized menu translation is immaterial. For a real
    # anchor y, center K at the center of the opposite source tile minus y.
    # Use that tile as the narrow prediction. The wide prediction contains
    # it, adds an axis pad of side 1/n, and takes the Minkowski sum of two
    # full generator segments with rows (1/3,±1/3), occurring n/2 times.
    # When scaled by b/(2D)^(1/n)=2^(-1/n), its true cost is the projection
    # polynomial with exact coefficients (1, 2n/3, n^2/18).
    if wide:
        assert n % 2 == 0
        eta = F(1, n)
        sums = F(1), F(2*n, 3), F(n*n, 18)
        assert eta >= 2*pad and F(2, 3) + eta < 1
    else:
        eta = 2*pad
        sums = (F(1),)
    log2 = bands_ln(F(2))
    decay = bands_monotone((-log2[1]/n, -log2[0]/n), BANDS_NEAR.exp)
    assert 0 < decay[0] <= decay[1] < 1
    r = len(sums) - 1
    terms = []
    for a in decay:
        c = 1 + eta*a
        poly = sum(coef * a**k * c**(r-k) for k, coef in enumerate(sums))
        terms.append((bands_ln(c), bands_ln(poly)))
    return (terms[0][0][0]*(n-r) + terms[0][1][0],
            terms[1][0][1]*(n-r) + terms[1][1][1])


def bands_clearance(h, omega_power, log_n, log_risk, p_left, p_right):
    # h - log U + log omega + log alpha + log gamma.
    left, right = bands_ln(p_left), bands_ln(p_right)
    lo = h - log_risk[1] - omega_power*log_n[1] + left[0] + right[0]
    hi = h - log_risk[0] - omega_power*log_n[0] + left[1] + right[1]
    assert lo <= hi and (lo > 0 or hi < 0)
    return lo, hi


def bands_capacity(count, clearance):
    # This is an independent, identical-observation risk table. If k
    # distinct labels pass using the same two budget lists, Cauchy says
    # k sqrt(e^-h U/omega) <= sum sqrt(alpha_s gamma_s) <= 1.
    # Picking k labels and giving each 1/k at both ends attains this bound.
    lo, hi = 0, count+1
    while lo+1 < hi:
        mid = (lo+hi)//2
        if clearance(F(1, mid), F(1, mid))[0] > 0:
            lo = mid
        else:
            hi = mid
    return lo


def bands_case(n, count, stride, active, expected):
    pad, h = bands_geometry(n, count, stride, active)
    uniform = (F(1, count),)*count
    front = tuple(F(1, 2**(j+1)) for j in range(count-1)) + (F(1, 2**(count-1)),)
    local = (F(1),)
    for arr in (uniform, front, local):
        assert min(arr) > 0 and sum(arr) == 1
    # Every true y and q belongs to exactly one physical source tile.
    # Local forecasts know this and use a unit budget at their own label.
    # The other rules intentionally spread that single budget across D_j.
    # Each weights BOTH terminal lists once; no per-row fresh allocation.
    logn = bands_ln(F(n+2))
    for wide, targets in expected.items():
        risk = bands_risk(n, pad, wide)
        print("BANDS MENU", "wide rank-two" if wide else "exact opposite true tile",
              "log U", bands_report(risk))
        for power, answer in zip((0, 1, 4), targets, strict=True):
            def clearance(a, b):
                return bands_clearance(h, power, logn, risk, a, b)

            known = clearance(F(1), F(1))
            one_sided = clearance(F(1), uniform[0])
            equal = clearance(uniform[0], uniform[0])
            local_pass = count * (known[0] > 0)
            equal_pass = count * (equal[0] > 0)
            one_sided_pass = count * (one_sided[0] > 0)
            assert equal_pass <= one_sided_pass <= local_pass
            front_pass = sum(clearance(x, x)[0] > 0 for x in front)
            best_same_observation = bands_capacity(count, clearance)
            assert 0 <= equal_pass <= best_same_observation <= local_pass
            assert 0 <= front_pass <= best_same_observation
            assert (local_pass, equal_pass, best_same_observation) == answer
            print("  omega", f"(n+2)^(-{power})",
                  "whole bands pass local/one-sided-uniform/two-sided-uniform/frontloaded",
                  (local_pass, one_sided_pass, equal_pass, front_pass),
                  "max with shared-observation equal-risk table", best_same_observation,
                  "fraction of whole true mother",
                  tuple(str(F(j, 2*count)) for j in (local_pass, one_sided_pass, equal_pass, front_pass)),
                  "local margin", bands_report(known), "one-sided margin", bands_report(one_sided),
                  "two-sided margin", bands_report(equal))


def bands_cap_checks():
    """Test the exact factor T=n on two previously verified true root families."""
    cases = (
        (16, 3, 1, 4, False, "uniform", (0, 3)),
        (4096, 64, 2, 36, True, "frontloaded", (6, 12)),
    )
    for n, count, stride, active, wide, name, expected in cases:
        pad, h = bands_geometry(n, count, stride, active)
        risk = bands_risk(n, pad, wide)
        ln_n = bands_ln(F(n))
        if name == "uniform":
            weights = (F(1, count),) * count
        else:
            weights = tuple(F(1, 2**(j+1)) for j in range(count-1)) + (F(1, 2**(count-1)),)
        assert sum(weights) == 1 and all(p > 0 for p in weights)
        base, raised = [], []
        for p in weights:
            lo, hi = bands_clearance(h, 0, ln_n, risk, p, p)
            larger = lo + ln_n[0], hi + ln_n[1]
            assert larger[0] > 0 or larger[1] < 0
            assert not lo > 0 or larger[0] > 0
            base.append((lo, hi))
            raised.append(larger)
        paid = sum(lo > 0 for lo, _ in base), sum(lo > 0 for lo, _ in raised)
        assert paid == expected and paid[0] < paid[1]
        added = next(j for j, (before, after) in enumerate(zip(base, raised, strict=True))
                     if before[1] < 0 < after[0])
        left = next((j for j, (_, hi) in enumerate(raised) if hi < 0), None)
        assert (left is None) == (paid[1] == count)
        print("BANDS CAP T=1 vs T=n", "n", n, "true last-root bands", count,
              "forecast", name, "wide rank-two", wide, "h", h,
              "log U", bands_report(risk), "log n", bands_report(ln_n),
              "cross bands admitted", paid, "newly admitted band j", added,
              "margin T=1/T=n", (bands_report(base[added]), bands_report(raised[added])),
              "unpaid cross mass / all true mother", str(F(count-paid[1], 2*count)),
              "same-tile h=0 complement / all true mother", "1/2")
        if left is not None:
            print("BANDS CAP COMPLEMENT", "first excluded cross band j", left,
                  "margin T=n", bands_report(raised[left]))
    print("PASS T=n adds true whole bands and leaves a certified complement")



def bands_overlap_checks():
    """Two prelisted overlapping direction menus on genuine cross-source rows."""
    n, count, stride, active = 16, 3, 1, 4
    source_pad, h = bands_geometry(n, count, stride, active)
    widths = (F(1, 3), F(5, 16))
    shifts = (F(-1, 8), F(1, 8))
    # At any true left anchor y, center the two direction boxes at
    # opposite_tile_center-y plus their respective first-axis shifts.
    # All coordinates are in units of the actual band side b. The true
    # right tile lies in both predictions, even for the extreme endpoints.
    assert all(abs(shift) + source_pad < width/2
               for width, shift in zip(widths, shifts, strict=True))
    intervals = tuple((s-w/2, s+w/2) for s,w in zip(shifts, widths, strict=True))
    assert intervals[0][0] < intervals[1][0] < intervals[0][1] < intervals[1][1]
    assert active > 1 and F(1, 2)-source_pad > max(widths)/2

    alpha = gamma = (F(1, 2), F(1, 2))
    assert sum(alpha) == sum(gamma) == 1
    assert all(a*g == F(1, 4) for a,g in zip(alpha, gamma, strict=True))
    risks = tuple(bands_risk(n, width/2, False) for width in widths)
    scores = tuple(
        tuple(F(1, 2)*x for x in bands_monotone(((h-hi)/2, (h-lo)/2), BANDS_NEAR.exp))
        for lo,hi in risks
    )
    total = tuple(sum(bounds[k] for bounds in scores) for k in range(2))
    threshold = F(1, 4)
    assert threshold**2 * n == 1
    assert all(0 < lo <= hi < threshold for lo,hi in scores)
    assert total[0] > threshold
    # Each observed true endpoint can identify its physical band and
    # assigns its whole budget to these two sublabels of that band's (D,h).
    # Every cross pair hits both sets, and same-tile pairs hit neither.
    print("BANDS OVERLAP score sqrt(alpha gamma exp(h)/U)",
          "n", n, "true scales 1/4,1/2,1", "h", h, "two extra menu labels",
          "physical normalized widths", tuple(map(str, widths)),
          "relative shifts", tuple(map(str, shifts)),
          "log U", tuple(map(bands_report, risks)),
          "individual score intervals", tuple(map(bands_report, scores)),
          "combined score", bands_report(total), "root-scale threshold", str(threshold),
          "jointly passing cross mass / whole true mother", "1/2",
          "same-tile unused complement", "1/2")
    # Direct physical co-containment P_D at a_D=b*2^(1/n). Bound the
    # true displacement of all points in each pair of positive-width cells.
    log2 = bands_ln(F(2))
    a_lo, a_hi = bands_monotone((-log2[1]/n, -log2[0]/n), BANDS_NEAR.exp)
    dlo, dhi = F(1, 2)-2*source_pad, F(1, 2)+2*source_pad
    p_d = ((1-a_hi*dhi)**active * (1-a_hi*2*source_pad)**(n-active),
           (1-a_lo*dlo)**active)
    assert 0 < p_d[0] <= p_d[1] < 1
    log_pd = bands_ln(*p_d)
    physical = tuple(
        tuple(F(1, 2)*x for x in bands_monotone(
            ((-log_pd[1]-hi)/2, (-log_pd[0]-lo)/2), BANDS_NEAR.exp))
        for lo,hi in risks
    )
    physical_total = tuple(sum(bounds[k] for bounds in physical) for k in range(2))
    assert all(0 < lo <= hi < threshold for lo,hi in physical)
    assert physical_total[0] > total[1] > threshold
    print("BANDS OVERLAP physical P_D", bands_report(p_d),
          "individual exact-physical score intervals", tuple(map(bands_report, physical)),
          "combined exact-physical score", bands_report(physical_total),
          "whole positive-width cross cells still require overlap at this threshold")
    print("PASS overlapping positive-width direction menus cross the root-scale threshold")


def bands_checks():
    bands_case(16, 3, 1, 4, {False: ((3,0,2), (0,0,0), (0,0,0))})
    bands_case(256, 32, 3, 16, {False: ((32,32,32), (32,0,9), (0,0,0))})
    bands_case(4096, 64, 2, 36, {
        False: ((64,64,64), (64,64,64), (0,0,0)),
        True: ((64,64,64), (64,0,1), (0,0,0)),
    })
    bands_case(65536, 64, 2, 80, {
        False: ((64,64,64), (64,64,64), (64,64,64)),
        True: ((64,64,64), (64,64,64), (0,0,0)),
    })
    print("PASS all-scale real root bands, dual terminal budgets and interval risk gates")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for round_number in PINS:
        parser.add_argument(f"--archive-{round_number}", metavar="ZIP", type=Path,
                            default=ROUNDS / f"{round_number}/research.zip")
    args = parser.parse_args()
    print("PYTHON", python_version(), "exact rational source and polynomial moments")
    for n, expected in PINS.items():
        path = getattr(args, f"archive_{n}")
        actual = sha256(path.read_bytes()).hexdigest()
        assert actual == expected
        print("ARCHIVE SHA256", n, actual)
    prior = archive_module(args.archive_832, "foot832.py")
    row = archive_module(args.archive_833, "row833.py")
    verify_moments()
    print("SCOPE real 4D finite fixtures, no asymptotic R813 degree or jump gate")
    print("PREDICTIONS absolute raw axis or signed pair-sum after division by 2R;"
          " axis and diagonal bands use the same tolerance on their displayed functional")
    for name, stage in prior["fixtures"](args.archive_814):
        fixture(name, stage, prior, row)
    bands_checks()
    bands_cap_checks()
    bands_overlap_checks()
    print("PASS exact true-z single, double, and triple right-source moments")


if __name__ == "__main__":
    main()

