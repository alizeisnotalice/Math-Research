"""R835 exact finite checks of weighted cone chains and cross-path source reuse.

No archives or third-party modules. The flow weights in these examples are
prescribed rational diagnostics, with positive physical source/receiver cells.
"""

from collections import Counter, defaultdict
from fractions import Fraction as F
from itertools import combinations, zip_longest
from math import factorial


def gaps(x, y):
    return tuple(abs(a - b) for a, b in zip_longest(x, y, fillvalue=F(0)))


def inside(box, cube):
    x, h = box
    y, b = cube
    return max(gaps(x, y), default=0) + h < b / 2


def outside(box, cube):
    x, h = box
    y, b = cube
    return max(gaps(x, y), default=0) - h > b / 2


def cone_edges(n, gamma, parents):
    z = F(1, n)
    partial = sum(z**j / factorial(j) for j in range(21))
    tail = z**21 / factorial(21) / (1 - z / 22)
    inflate = 1 + F(1, 16 * n)
    edges = set()
    for t, (x, a) in parents.items():
        for s, (y, b) in parents.items():
            g = gaps(x, y)
            psi = (1 - gamma) * max(g, default=0) + gamma * sum(g) / n
            cap = inflate * b - 2 * psi
            if cap > (partial + tail) * a:
                assert b > a
                edges.add((t, s))
            else:
                assert cap < partial * a, (n, s, t, "exp enclosure inconclusive")
    assert all((t, s) in edges for t, u in edges for v, s in edges if u == v)
    return edges


def kernels(parents, rows, edges, keep, jump=1):
    groups = defaultdict(list)
    for row, (left, right, _) in rows.items():
        groups[(left, right)[keep]].append(row)
    transfers = defaultdict(F)
    paid_width = 0
    for group in groups.values():
        group.sort(key=lambda t: (parents[t][1], t))
        antichain = max(sum(rows[t][2] for t in family)
                        for size in range(len(group) + 1)
                        for family in combinations(group, size)
                        if not any((r, t) in edges for r, t in combinations(family, 2)))
        if all((r, t) in edges for r, t in combinations(group, 2)):
            # For a total order, weight level sets give the exact chain cover.
            chains = [tuple(t for t in group if rows[t][2] >= index)
                      for index in range(1, max(rows[t][2] for t in group) + 1)]
        else:
            # The other observed groups in these fixtures are antichains.
            assert not any((r, t) in edges for r, t in combinations(group, 2))
            chains = [(t,) for t in group for _ in range(rows[t][2])]
        counts = Counter(t for chain in chains for t in chain)
        assert len(chains) == antichain and counts == {t: rows[t][2] for t in group}
        paid_width += antichain
        for chain in chains:
            for r, t in zip(chain, chain[jump:]):
                assert (r, t) in edges and rows[r][keep] == rows[t][keep]
                transfers[r, t] += F(1, rows[r][2])
    columns = {t: sum(rows[r][2] * w for (r, s), w in transfers.items() if s == t) for t in rows}
    assert all(columns[t] <= rows[t][2] for t in rows)
    assert all(sum(w for (r, _), w in transfers.items() if r == t) <= 1 for t in rows)
    assert sum(row[2] for row in rows.values()) - sum(columns.values()) <= jump * paid_width
    return transfers, paid_width, sum(columns.values()), tuple(columns[t] for t in sorted(rows))


def paths(rows, parents, source, kernels_by_side, sequence):
    flow = {(t,): F(w) for t, (_, _, w) in rows.items()}
    old_hits = F(0)
    new_uses = defaultdict(set)
    for step, keep in enumerate(sequence, 1):
        new_flow = defaultdict(F)
        for past, value in flow.items():
            for (r, s), p in kernels_by_side[keep].items():
                if r != past[-1]:
                    continue
                other = rows[s][1 - keep]
                tag = source[other]
                assert inside(tag, parents[s])
                assert all(inside(tag, parents[t]) or outside(tag, parents[t]) for t in past)
                if any(inside(tag, parents[t]) for t in past):
                    old_hits += value * p
                    continue
                new_flow[past + (s,)] += value * p
        flow = new_flow
        for t, row in rows.items():
            assert sum(w for p, w in flow.items() if p[-1] == t) <= row[2]
    for past, value in flow.items():
        assert value > 0
        for step, keep in enumerate(sequence, 1):
            other = rows[past[step]][1 - keep]
            new_uses[other].add((past, step))
    return sum(flow.values()), old_hits, new_uses


def audit_receivers(n, parents, source):
    # Disjoint central owners and auxiliary positive-volume arm owners,
    # all physically placed. Do not identify their labels when retesting q.
    owners = [(c, b / (64 * n)) for c, b in parents.values()]
    owners += [(c, h / (32 * n)) for c, h in source.values()]
    assert all(h > 0 for _, h in owners)
    assert all(max(gaps(c, d), default=0) > h + k
               for (c, h), (d, k) in combinations(owners, 2))


def test(n, gamma, label, parents, rows, source, sequences):
    assert set(parents) == set(rows) and all(w > 0 for _, _, w in rows.values())
    assert max(b for _, b in parents.values()) < 2 * min(b for _, b in parents.values())
    audit_receivers(n, parents, source)
    for t, (left, right, _) in rows.items():
        assert inside(source[left], parents[t]) and inside(source[right], parents[t])
    edges = cone_edges(n, gamma, parents)
    data = [kernels(parents, rows, edges, keep) for keep in (0, 1)]
    for keep in (0, 1):
        kernels(parents, rows, edges, keep, jump=2)
    print(label, "n", n, "records", len(rows), "weight", sum(row[2] for row in rows.values()),
          "edges", len(edges), "LEFT / RIGHT (width, column sum, columns)",
          [item[1:] for item in data])
    out = []
    for sequence in sequences:
        surviving, old, uses = paths(rows, parents, source, [d[0] for d in data], sequence)
        repeated = {q: sorted({step for _, step in bag}) for q, bag in sorted(uses.items())
                    if len({path for path, _ in bag}) > 1}
        print("  kept-side sequence", sequence, "fresh surviving", surviving,
              "discarded-old weight", old, "cross-path reused source and steps", repeated)
        out.append((surviving, old, repeated))
    return out


def high_dimension(n, staggered):
    v = F(1, n)
    gamma = F(1, (n + 1).bit_length())
    offset = v if staggered else v / 4
    width = v / 64
    source = {
        "LA": ((-F(1, 4),), width),
        "LB": ((-F(1, 3),), width),
        "q0": ((F(1, 5),), width),
        "q": ((F(1, 2) + (2 if staggered else 1) * v,), width),
        "q2": ((F(1, 2) + (4 if staggered else 3) * v,), width),
    }
    if staggered:
        source["qB"] = ((F(1, 2),), width)
    parents = {}
    rows = {}
    right = (("q0", "q", "q2"), ("q0", "qB", "q") if staggered else ("q0", "q", "q2"))
    for a, label in enumerate(("A", "B")):
        for j in range(3):
            key = label + str(j)
            parents[key] = (((1 - 2 * a) * offset, j * v / 16), 1 + 4 * j * v)
            rows[key] = ("L" + label, right[a][j], ((3, 2, 1), (2, 3, 2))[a][j])
    # Uniform density 1 on [-1,1]^n calibrates all central cuboids.
    # No center is strictly overlevel at threshold 1, so no true last roots.
    assert all(max(map(abs, c)) + b / 2 < 1 for c, b in parents.values())
    assert outside(source["q"], parents["A0"])
    assert outside(source["q"], parents["B0"])
    assert outside(source["q"], parents["B1"]) == staggered
    results = test(n, gamma, "STAGGERED" if staggered else "SYNCHRONOUS",
                   parents, rows, source, ((0, 0), (0, 1)))
    surviving, old, reused = results[0]
    assert surviving == F(7, 3) and old == 0
    assert reused["q"] == ([1, 2] if staggered else [1])


def small_grid():
    # The calibrated prefix layout from the round's parallel proof, with
    # genuinely positive cell densities. The 3x3 layout uses mixed gamma.
    n = 512
    gamma = F(1, 2)
    r = 1 + 16 / (n * gamma)
    eps = (r - 1) / 16
    limit = int(n * gamma / 128)
    assert limit == 2 and r**(2 * limit) < 2
    width = eps / 16
    source = {}
    mu = {}
    weights = [F(1)] + [r**(n * h) - r**(n * (h - 1)) for h in (1, 2)]
    assert all(value > 0 for value in weights)
    for h in range(3):
        for k in range(3):
            x, y = (h - F(1, 4)) * eps, (k - F(1, 4)) * eps
            weight = weights[h] * weights[k]
            if h == 0 or k == 0:
                if k == 0:
                    source[f"z{h}"] = ((x, y, F(1, 4)), width)
                    mu[f"z{h}"] = weight / (2 if h == 0 else 1)
                if h == 0:
                    source[f"q{k}"] = ((x, y, -F(1, 4)), width)
                    mu[f"q{k}"] = weight / (2 if k == 0 else 1)
            else:
                source[f"c{h}{k}"] = ((x, y, F(0)), width)
                mu[f"c{h}{k}"] = weight
    assert all(value > 0 for value in mu.values())
    assert all(max(gaps(c, d)) > h + k for (c, h), (d, k) in combinations(source.values(), 2))
    parents, rows = {}, {}
    vals = (1, 2, 1)
    total_mass = sum(mu.values())
    assert total_mass == r**(4 * n)
    for i in range(3):
        for j in range(3):
            t = (i, j)
            b = r**(i + j)
            c = i * eps - b / 2, j * eps - b / 2
            parents[t] = c, b
            rows[t] = f"z{i}", f"q{j}", min(vals[i], vals[j]) + 1
            for cell in source.values():
                assert inside(cell, parents[t]) or outside(cell, parents[t])
            assert sum(mu[q] for q in source if inside(source[q], parents[t])) == b**n
            # Within b+5 eps this center sees all the mass. This is
            # strictly before b_22 for nonterminal centers.
            assert all(inside(cell, (c, b + 5 * eps)) for cell in source.values())
            if t != (2, 2):
                assert b + 5 * eps < r**4
            else:
                assert all(inside(cell, (c, b)) for cell in source.values())
    # The true last root at every listed center is therefore b_22.
    # Only the (2,2) labeled side agrees with its actual last-root side.
    endpoints = {q: source[q] for rec in rows.values() for q in rec[:2]}
    cases = test(n, gamma, "POSITIVE DENSITY 3x3 GRID", parents, rows, endpoints,
                 ((0, 0), (1, 1), (0, 1, 0)))
    assert all(surviving > 0 and old == 0 and repeated for surviving, old, repeated in cases)
    print("  all 9 central masses calibrated; only (2,2) labeled side is a true last root;",
          "true last side at every center", r**4)


if __name__ == "__main__":
    for dimension in (16, 4096, 65536):
        high_dimension(dimension, False)
        high_dimension(dimension, True)
    small_grid()
    print("PASS exact rational tests; prescribed weights, full R813 history unverified")
