"""R131: 12 frozen BD11/14/15 kernel cases, 30/50 digit observations only.

Uses existing mpmath vendor through PYTHONPATH. No computation at import.
No interval certificate, FIRST/FULL realization, or source-budget conclusion.
"""
from argparse import ArgumentParser
from fractions import Fraction as Q
from pathlib import Path
import hashlib
import json
import sys
import time

N = 6561
DIGITS = (30, 50)
MAXDEGREE = 6
MAX_EVALS = 20000
VENDOR = '/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor'
HERE = Path(__file__).resolve().parent
NOTE = HERE / 'joint_denominator_numeric_protocol.md'
EXPECTED_NOTE_SHA = '8483088d4fa336da68ab38ae7bd06ccc6be8960fad1ecf4ff7b42772218d936b' # pre-execution frozen protocol


def sha_bytes(data):
    return hashlib.sha256(data).hexdigest()


def rational(x):
    return {'$q': [str(x.numerator), str(x.denominator)]}


def encode_input(x):
    if isinstance(x, Q): return rational(x)
    if isinstance(x, dict): return {str(k): encode_input(v) for k,v in x.items()}
    if isinstance(x, (list,tuple)): return [encode_input(v) for v in x]
    return x


def group(name):
    gamma = 1 + Q(1,N)
    if name == 'A':
        return dict(group=name,n=N,j=0,gamma=gamma,cj=Q(1),g=Q(1),
                    a=Q(1,2),b=Q(1),L=Q(1),R=Q(1),y=Q(0))
    cj = 1/gamma
    L = (cj+cj/gamma)/2
    R = 1/L
    return dict(group=name,n=N,j=1,gamma=gamma,cj=cj,g=Q(1),
                a=R/2,b=R,L=L,R=R,y=Q(0))


def menu(stage):
    A,B = group('A'),group('B')
    # (ID, group, z, v, zprime, m, physical-softness-formula, theta)
    if stage == 1:
        rows=[(1,A,Q(2),Q(2),Q(-1),1,'near',Q(1,2)),
              (2,A,Q(0),Q(0),Q(0),1,'near',Q(1,2)),
              (3,A,Q(63,64),Q(2),Q(0),2,'near',Q(1,2)),
              (4,A,Q(0),Q(2),Q(2),3,'one',Q(1))]
    elif stage == 2:
        rows=[(5,A,Q(63,64),Q(1,2),Q(2),1,'one',Q(1,2)),
              (6,A,Q(0),Q(1,4096),Q(1,2),2,'one',Q(1)),
              (7,A,Q(0),Q(4),Q(4),3,'near',Q(1,2)),
              (8,A,Q(1,2),Q(-3,4),Q(3,4),1,'very_near',Q(1,2))]
    else:
        L,R,b=B['L'],B['R'],B['b']
        rows=[(9,B,Q(0),Q(1,4096),Q(0),1,'near',Q(1,2)),
              (10,B,(R+L)/2-Q(1,64),2*b,-b,2,'one',Q(1,2)),
              (11,B,R/2,b/2,2*b,3,'very_near',Q(1)),
              (12,B,Q(0),4*b,-4*b,2,'near',Q(1,2))]
    return [dict(**params,id=case_id,stage=stage,z=z,v=v,zprime=zp,m=m,
                 softness=soft,theta_rule='s/32768') for case_id,params,z,v,zp,m,soft,theta in rows]


def legality(case):
    a,b,L,R,g,cj,gamma=(case[k] for k in ('a','b','L','R','g','cj','gamma'))
    return dict(physical_scale_window=(0<a<=L<=b and a<=R<=b and b<=2*a),
                exact_g_relation=L*R==g*g,
                ratio_band=cj/gamma*g<=min(L,R)<=cj*g,
                original_g_window=a/cj<=g<=b*cj,
                cj_definition=cj==gamma**(-case['j']),
                dimension_at_least_6561=case['n']>=6561,
                softness_structural=(case['softness'] in ('one','near','very_near')),
                theta_rule_declared=case['theta_rule']=='s/32768')


class BudgetError(RuntimeError):
    pass


class Probe:
    def __init__(self,mp):
        self.mp=mp
        self.evaluations=0
        self.phi_calls=0
        self.phi_cache={}
        self.C_cache={}

    def number(self,q):
        if isinstance(q,Q): return self.mp.mpf(q.numerator)/q.denominator
        return self.mp.mpf(q)

    def string(self,x):
        return self.mp.nstr(x,n=self.mp.dps)

    def phi(self,x):
        self.phi_calls+=1
        r=abs(x)
        if r in self.phi_cache: return self.phi_cache[r]
        half=self.mp.mpf(1)/2
        def E3(a):
            return half if a==0 else self.mp.expint(3,a)
        value=(1-E3(half-r)-E3(half+r) if r<=half else E3(r-half)-E3(r+half))
        if not self.mp.isfinite(value) or value<=0:
            raise ArithmeticError('nonpositive/nonfinite floating original phi')
        self.phi_cache[r]=value
        return value

    def integrate(self,func,lo,hi,cuts):
        if hi<=lo:
            return self.mp.mpf(0),self.mp.mpf(0),[]
        points=sorted({lo,hi,*(c for c in cuts if lo<c<hi)})
        total,error=self.mp.mpf(0),self.mp.mpf(0)
        pieces=[]
        def wrapped(x):
            self.evaluations+=1
            if self.evaluations>MAX_EVALS:
                raise BudgetError('per-case/per-precision integrand request budget exceeded')
            return func(x)
        for left,right in zip(points,points[1:]):
            value,estimate=self.mp.quad(wrapped,[left,right],method='gauss-legendre',
                                        maxdegree=MAXDEGREE,error=True)
            total+=value
            error+=abs(estimate)
            pieces.append(dict(lo=self.string(left),hi=self.string(right),
                               value=self.string(value),quad_error_estimate=self.string(estimate)))
        return total,error,pieces

    def C(self,d):
        if d in self.C_cache: return self.C_cache[d]
        half=self.mp.mpf(1)/2
        def F(u):
            r=abs(u-d)
            return self.mp.mpf(1) if r<=half else self.phi(r)
        result=self.integrate(F,-half,half,[d-half,d,d+half])
        self.C_cache[d]=result
        if result[0]<=0 or not self.mp.isfinite(result[0]):
            raise ArithmeticError('nonpositive/nonfinite floating original C')
        return result


def observe(mp,case,digits):
    start=time.monotonic()
    with mp.workdps(digits):
        probe=Probe(mp)
        val={k:probe.number(case[k]) for k in ('a','b','L','R','g','cj','gamma','y','z','v','zprime')}
        a,b,L,R,g,cj,gamma,y,z,v,zp=(val[k] for k in ('a','b','L','R','g','cj','gamma','y','z','v','zprime'))
        n=case['n']
        lower=1-mp.power(2,-mp.mpf(1)/n)
        s=(mp.mpf(1) if case['softness']=='one' else lower+mp.power(2,-(24 if case['softness']=='near' else 40)))
        theta=s/32768
        Hq=(case['L'] if case['m']==1 else (min(case['b'],case['gamma']*case['L']) if case['m']==2 else case['b']))
        H=probe.number(Hq)
        kernel_s=mp.mpf(1) if case['m']==3 else s
        legal=legality(case)
        legal['Hm_in_physical_window']=case['a']<=Hq<=case['b']
        legal['strict_softness_observed']=s>lower and s<=1
        legal['theta_BD17_observed']=0<theta<=min(mp.power(2,-15),s/896)
        output=dict(input=encode_input(case),digits=digits,legality=legal,
                    s_lower=probe.string(lower),s_actual=probe.string(s),s_margin=probe.string(s-lower),
                    theta=probe.string(theta),theta_cap=probe.string(min(mp.power(2,-15),s/896)),
                    kernel_s=probe.string(kernel_s),Hm=rational(Hq),
                    status='EXPLORATORY_MPMATH_NOT_INTERVAL',calculations={})
        if not all(legal.values()):
            output.update(status='PARAMETER_LEGALITY_UNDETERMINED',reason='declared menu legality gate not observed')
            return output
        try:
            cv,cv_error,cv_pieces=probe.C(abs(y-v)/b)
            cb,cb_error,cb_pieces=probe.C(abs(y-zp)/b)
            raw_v=b*cv/(cj*g); raw_b=b*cb/(cj*g)
            omega_v=min(mp.mpf(1),raw_v); omega_b=min(mp.mpf(1),raw_b)
            def kernel(u):
                radius=abs((u-v)/H)
                hard=mp.mpf(1) if radius<=mp.mpf(1)/2 else mp.mpf(0)
                return ((1-kernel_s)*hard+kernel_s*probe.phi(radius))/H
            def denominator(u):
                return probe.phi((u-zp)/b)/b
            def ratio_power(u):
                return mp.power(kernel(u)*omega_b/(denominator(u)*omega_v),theta)
            def anchor(u):
                radius=abs((u-y)/L)
                hard=mp.mpf(1) if radius<=mp.mpf(1)/2 else mp.mpf(0)
                return ((1-s)*hard+s*probe.phi(radius))/L
            jlo,jhi=z-R/2,z+R/2
            Iloq=max(case['z']-case['R']/2,case['y']-case['L']/2)
            Ihiq=min(case['z']+case['R']/2,case['y']+case['L']/2)
            ellq=max(Q(0),Ihiq-Iloq)
            ilo,ihi=probe.number(Iloq),probe.number(Ihiq)
            cuts=[y-L/2,y,y+L/2,v-H/2,v,v+H/2,zp-b/2,zp,zp+b/2]
            P0=min(L,R)/(R*L); kappa=mp.mpf(63)/64
            right_h=P0*mp.power(gamma,theta)*mp.exp(7*theta)
            right_soft=P0*kappa
            right_mix=P0*((1-s)*mp.power(gamma,theta)*mp.exp(7*theta)+s*kappa)
            output.update(C_v=probe.string(cv),C_zprime=probe.string(cb),
                 C_error_estimates=dict(v=probe.string(cv_error),zprime=probe.string(cb_error)),
                 C_pieces=dict(v=cv_pieces,zprime=cb_pieces),raw_weight_v=probe.string(raw_v),
                 raw_weight_zprime=probe.string(raw_b),omega_v=probe.string(omega_v),omega_zprime=probe.string(omega_b),
                 I=dict(lo=rational(Iloq),hi=rational(Ihiq),length=rational(ellq),empty=ellq==0),
                 J=dict(lo=probe.string(jlo),hi=probe.string(jhi)),P0=probe.string(P0))
            hard_int,hard_error,hard_pieces=probe.integrate(ratio_power,ilo,ihi,cuts)
            hard=hard_int/(R*L)
            output['calculations']['BD11']=dict(lhs=probe.string(hard),rhs=probe.string(right_h),
                    ratio=probe.string(hard/right_h),observed_le=bool(hard<=right_h),
                    quad_error_estimate=probe.string(hard_error/(R*L)),pieces=hard_pieces)
            soft_int,soft_error,soft_pieces=probe.integrate(lambda u:probe.phi((u-y)/L)*ratio_power(u),jlo,jhi,cuts)
            soft=soft_int/(R*L)
            output['calculations']['BD14']=dict(lhs=probe.string(soft),rhs=probe.string(right_soft),
                    ratio=probe.string(soft/right_soft),observed_le=bool(soft<=right_soft),
                    quad_error_estimate=probe.string(soft_error/(R*L)),pieces=soft_pieces)
            # Independent full integral, not value filled from the mixed identity.
            full_int,full_error,full_pieces=probe.integrate(lambda u:anchor(u)*ratio_power(u),jlo,jhi,cuts)
            full=full_int/R
            mixed=(1-s)*hard+s*soft
            output['calculations']['BD15']=dict(lhs=probe.string(full),rhs=probe.string(right_mix),
                    ratio=probe.string(full/right_mix),observed_le=bool(full<=right_mix),
                    quad_error_estimate=probe.string(full_error/R),pieces=full_pieces,
                    independent_integral=True,mixed_value=probe.string(mixed),
                    full_minus_mixed=probe.string(full-mixed))
            log_ratio=n*mp.log(full)-(n*mp.log(P0)+theta-n*s/128)
            output['specified_m_homotype_BD16']=dict(log_ratio=probe.string(log_ratio),
                   observed_le=bool(log_ratio<=0),
                   meaning='n repeated copies of this specified scalar m only; no three-m sum computed')
        except Exception as error:
            output.update(status='EXCEPTION_WITH_PARTIAL_DATA_PRESERVED',
                          error_type=type(error).__name__,error=str(error))
        output.update(integrand_requests=probe.evaluations,phi_calls=probe.phi_calls,
                      elapsed_seconds=f'{time.monotonic()-start:.3f}',interval_certificate=False,
                      FIRST_FULL_or_source_root_claim=False)
        return output


def compare(mp,observations):
    with mp.workdps(50):
        result={}
        for label in ('BD11','BD14','BD15'):
            if all(label in o.get('calculations',{}) for o in observations):
                result[label+'_ratio_50_minus_30']=mp.nstr(mp.mpf(observations[1]['calculations'][label]['ratio'])-
                                                         mp.mpf(observations[0]['calculations'][label]['ratio']),50)
            else:
                result[label+'_ratio_50_minus_30']=None
        result['interpretation']='precision difference only; not interval error or theorem certification'
        return result


def main():
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('--stage',required=True,choices=('1','2','3','all'))
    parser.add_argument('--output',type=Path)
    args=parser.parse_args()
    try:
        import mpmath as module
        if module.__version__!='1.3.0' or not Path(module.__file__).resolve().is_relative_to(Path(VENDOR)):
            raise RuntimeError('expected existing mpmath 1.3.0 vendor')
        note_bytes=NOTE.read_bytes()
        if sha_bytes(note_bytes)!=EXPECTED_NOTE_SHA:
            raise RuntimeError('pre-execution frozen protocol SHA mismatch')
    except Exception as error:
        print(json.dumps(dict(status='ENVIRONMENT_ERROR',error=str(error))))
        return 2
    stages=(1,2,3) if args.stage=='all' else (int(args.stage),)
    cases=[case for stage in stages for case in menu(stage)]
    result=dict(header=dict(version='R131-joint-denominator-v1',case_count=len(cases),digits=DIGITS,
                 maxdegree=MAXDEGREE,max_integrand_requests_per_case_precision=MAX_EVALS,
                 python=sys.executable,python_version=sys.version,mpmath_version=module.__version__,
                 mpmath_path=module.__file__,code_sha=sha_bytes(Path(__file__).read_bytes()),
                 frozen_protocol_sha=sha_bytes(note_bytes),frozen_protocol_text=note_bytes.decode('utf-8'),
                 analytic_source_sha='99eb6d2c6dd2630639c7ac856ed0552c3c950eec6291e9e3ab86c73d17817a49',
                 source_sha_status='embedded provenance only; not runtime author-source validation',
                 interval_certificate=False,FIRST_FULL_or_source_root_claim=False),cases=[])
    failures=0
    for case in cases:
        observations=[]
        for digits in DIGITS:
            try:
                observation=observe(module.mp,case,digits)
            except Exception as error:
                observation=dict(input=encode_input(case),digits=digits,status='EXCEPTION_PRESERVED',
                                 error_type=type(error).__name__,error=str(error),interval_certificate=False)
            if observation['status']!='EXPLORATORY_MPMATH_NOT_INTERVAL': failures+=1
            observations.append(observation)
        result['cases'].append(dict(id=case['id'],stage=case['stage'],input=encode_input(case),
                    observations=observations,precision_comparison=compare(module.mp,observations)))
    result['summary']=dict(case_count=len(cases),observation_count=2*len(cases),failed_or_undetermined_observations=failures,
                stages=stages,no_menu_expansion=True,no_bound_clipping=True,
                only_original_specified_m=True,interval_certificate=False,FIRST_FULL_or_source_root_claim=False)
    serialized=json.dumps(result,ensure_ascii=False,indent=2,sort_keys=True)
    if args.output:
        args.output.write_text(serialized+'\n',encoding='utf-8')
        print(json.dumps(dict(status='SAVED',output=str(args.output.resolve()),**result['summary'])))
    else:
        print(serialized)
    return 1 if failures else 0


if __name__=='__main__':
    sys.exit(main())
