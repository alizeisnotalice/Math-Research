# 附件：main_integration.md

# 第131轮：共同全软分母与来源积分次序

一般中心立方体极大算子的n^(1/2+o(1))一致弱型上界仍未闭合。本轮严格改善一个实际核接口，没有登记新增一般付款分支。

## 新估计

R130仍保留bad端完整窗口逆核下确界。本轮统一使用原三测试之一P_(1,b)作整个n维的共同分母，分子和分母的3幂精确抵消，仅剩一次三项求和；没有逐坐标选择不同赢家。真实C与φ的位置比较消除bad来源位置，得到
\[
\mathcal I\le3e^\theta e^{-ns/128}\max(L,R)^{-n},
\qquad0<\theta\le\min(2^{-15},s/896).
\]
θ=s/32768对全部实际合法正软度可用。所有位置和合法比例尺度统一；原混合核全部分量保留，真实接收Lebesgue积分不替换为测试概率。作者稿已由Sol先独立核命题后读证明审查通过。

此外，全线而非hard-z载体上有新的倾斜矩上界3e，取θ=1/(134n)。此时不请求soft衰减，不能机械继承θ≤s/896。Astra先独立证明后读主稿审查通过。

## 不重复计作进展的来源回代

先把BD统一常数对硬来源积分，会留下总质量M。主代理尝试反过来先用原硬行帽h_Rν≤4λ再积接收核，得到16eD。独审指出固定参数时直接丢门并用∫p=1已有更强16D/3。因此该回代不算新来源付款，也不是一般根阶分支。本文如实保留这个判断以免后续重复。

实际贡献中Π_t、score在固定ω,V,j,y,t后不依x和外硬z，但L、s、g、双门、RC等可以依x；不能据固定参数积分免费控制自适应接收包络。删除双门会进一步丢失联合来源几何。来源分析保留准确带门接收列，而不是只提出各边最坏值相乘的强猜测。

## 技能与限制

继续使用已加载64项工具中的N04误差预算、D04共同来源约束。有限望远镜必须保留真实阈值跳变、删除项、终端来源质量和尺度费用；产品核不意味着Π的来源坐标独立。没有把技能名称当作新定理，也未声称阅读新的外部全文。

N_Z已消费不返还；N_Zc与Ndel各一次保留。β−ν、hard-z、ν³/e_t²、q、δ、dt/t、Σj和history均按原账保留。最低soft允许ns约常数，核衰减不能自动吸收维度费用。

## 验证状态

解析估计见冻结作者及独审附件。数值菜单须先冻结后实际运行；最终运行范围、异常与程序误差见数值附件。有限精度观察不是区间证书，不认证FIRST或一般上界。只保留详细LaTeX文本与必要复现资产，不编译PDF。

## 历史核对避免重复收费

已审归一化来源漂移及删除跳不自动给score方差积分O(n)。变测试k_t必须计阈值穿越，删除均值跳还可能增加score，粗幅度含n倍删除前质量比。终端来源条件化须恢复α_t²。有限定向检索未定位可直接支付这些项及接收空间/跨j费用的旧定理；本轮不把形式负方差项计为根阶进展。

来源分析SI4–5在实际硬帽有效域精确先积分hard-z，保留接收自适应双门和全部history。待估的联合尾只是原费用的准确表达，不是新证明，也没有另提未经探路的高斯强衰减猜测。

本轮复用已有Agent，各自按准确命题及独立文件责任工作；没有为凑数量重复启动。无法获取按本子任务分拆的实际扣额，不猜模型成本比例。

F01技能主说明、课题接口、方法与来源状态亦已核对：其中GP-BRANCH的私有核和分支规则尚未给出，不能把“两赢家”当成可调用的最大算子定理。因此本轮不引用该高级接口或声称其已提供新付款；下一步若采用几何平均，必须给出本课题真实核、零值约定和完整分支覆盖，另行证明。

## 实际完成的数值验证

冻结三阶段4/4/4共12例，每例原指定m、实际n=6561，保持严格soft下门及两组合法比例尺度。以θ=s/32768，30/50位共24观察，唯一进程退出0，异常/未定0，最大积分请求2745低于20000预算。BD11/14/15最大原始比值分别约0.9999999796、0.5136627453、0.9999493766，未按容差或理论界裁剪。独立full积分与混合分解的最大残差约4.46e-27，最大双精度比值差约4.46e-27；最高积分程序误差估计约2.00e-13，不是区间真误差界。指定m重复n次的对数比较也记录，但不把不同例的m拼成三整维和，仍不认证FIRST或真实来源付款。

数值代码与结果由另一Sol只读独审通过：核对共同分母b^-1、m3与实际anchor软度区别、完整J、独立混合积分、24条记录、异常口径和冻结SHA；没有重新运行。作者原始结果SHA为98127304a849da48e9a11c74602b25178f47846250bdcd44ad87f5dfe07cfb1d，代码及协议哈希见结果header与清单。


# 附件：bad_denominator.md

# R131：用整维全软共同分母消去 bad 来源位置

**结论。** 在原 HC/SA 的固定共同参数接口上，可以不再使用 bad 核的区间下确界。整维共同取 Q*(z′)≥P_(1,b)(x−z′)/3，并取显式 0<θ≤min{2^(−15),s/896}，得到完整四来源接收矩
\[
\boxed{\mathcal I_{actual\ gates}\le
3e^\theta e^{-ns/128}\,[\max(L,R)]^{-n}.}
\tag{BD0}
\]
此界统一于 y,z,z′,v，good 逆权和 bad 位置依赖都被消去。可固定取 θ=s/32768。它是未归一化、保留 hard-z 载体的局部 dx 积分界，不是一般原交通付款，也不是归一化比较概率的指数缺口。

本稿只使用原真实 φ/C、已审 HC5–6、SA3–11 及同一三个整维 FIRST 测试；不改任何旧稿。原正余权、high-pe、FA、Ψ、same ν、β−ν、ν³/e_t²、Σj/time/history 与未消费负项的费用在第 6 节明确保留。

## 1. 精确对象与量词

固定 n≥1 及原合法共同参数 s,L,R,g,j,t，a≤L,R≤b≤2a，实际 s>1−2^(−1/n)，γ=1+1/n。令 m₀=min(L,R)，原比例带给
\[
m_0\le c_jg\le\gamma m_0,\qquad c_jg\le b.
\tag{BD1}
\]
固定四个任意来源位置 y,z,z′,v∈Rⁿ。对各坐标定义
\[
\omega_i(\xi)=\min\{1,bC(|y_i-\xi_i|/b)/(c_jg)\},
\quad w_g(\xi)=\prod_i\omega_i(\xi),
\quad J_i=[z_i-R/2,z_i+R/2].
\]
原三测试为 K_m(x,ξ)=∏_ik_m(x_i−ξ_i)，H₁=L、H₂=L⁺、H₃=b，k_m=q_(s,H_m)（m≤2）、k₃=q_(1,b)，Q*=(K₁+K₂+K₃)/3；记全软整维核 J(x,ξ)=K₃(x,ξ)。

令 p=P_(s,L)(x−y)。\mathcal I_actual gates 是 HC2 左侧，可在任意原贡献接收域 O_E 上保留原全部正门：
\[
\int_{O_E}p\,h_R(x-z)\rho(x,v)
1_{\{p w_g(v)\le KQ^*(v),\ p w_g(z')>KQ^*(z')\}}
\,a_{other}(x)\,dx,
\qquad0\le a_{other}\le1.
\tag{BD2}
\]
其中 a_other 包含实际 high-pe、FA、Ψ、原 history 等；ρ 为实际 RC 余权。本稿不把 O_E 或任何门改判到另一接收点。若参数随 x 变化，不能直接调用这里的固定参数积分定理。

## 2. 共同分母与真实一维核

取同一整维倾斜 η=θ、ξ=0。双绝对门给
\[
1_{G\ge1,B>1}\le
\left[\frac{Q^*(v)w_g(z')}{Q^*(z')w_g(v)}\right]^\theta.
\]
对 0<θ≤1，统一使用**同一个整维全软分母**，有
\[
[Q^*(v)]^\theta[Q^*(z')]^{-\theta}
\le\sum_{m=1}^3 K_m(v)^\theta J(z')^{-\theta}.
\tag{BD3}
\]
理由是分子的 3^(−θ) 次可加帽和分母的 3^θ 帽精确相消。没有坐标间重选分母，没有新来源核，且 K 的门常数也因 η=θ 相消。

定义四来源的一维接收核
\[
\mathcal B_{m,i}=
\frac1R\int_{J_i}q_{s,L}(u-y_i)
\left[\frac{k_m(u-v_i)\omega_i(z')}
{q_{1,b}(u-z'_i)\omega_i(v)}\right]^\theta du.
\tag{BD4}
\]
乘 p h_R 后，只在正上界中用 ρ,a_other≤1，并将接收域扩大到原 hard-z 盒，得到
\[
\mathcal I_{actual\ gates}\le\sum_{m=1}^3\prod_i\mathcal B_{m,i}.
\tag{BD5}
\]
这里的费用仍是一次三项和，无额外 3^n，也没有 SA17 的 bad 下确界因子。

## 3. bad 比值的位置无关控制

由原 φ≤F≤4φ 与 logφ 的 4-Lipschitz 性，
\[
C(d)\le4e^2\phi(d).
\tag{BD6}
\]
BD1 和 b≤2a 给 b/(c_jg)≤2，故 ω_i(z′)≤2C(|y_i−z′_i|/b)。因此对每个 u，
\[
\boxed{\frac{\omega_i(z')}{\phi((u-z'_i)/b)}
\le8e^2\exp\!\left(4\frac{|u-y_i|}{b}\right).}
\tag{BD7}
\]
这是真实 C/φ 的全域比较，常数不依赖 z′；没有使用任何错误的 φ 尾幂。另一方面，已审 SA5 给
\[
\frac{H_mk_m(u-v_i)}{\omega_i(v)}
\le16e^2\exp\!\left(4\frac{|u-y_i|}{L}\right).
\tag{BD8}
\]
注意 q_(1,b)=b^(−1)φ，所以 BD4 的比值准确等于
\[
\frac b{H_m}\,
\frac{H_mk_m(u-v_i)}{\omega_i(v)}
\frac{\omega_i(z')}{\phi((u-z'_i)/b)}.
\tag{BD9}
\]
此处 b/H_m≤2 必须计入；不能把分母 φ 当作带尺度密度而漏掉 b。

## 4. hard/soft 锚点分别估计

将 BD4 中 q_(s,L)(u−y_i) 按原线性混合拆开，记
\[
\mathcal B_{m,i}=(1-s)\mathcal B^h_{m,i}+s\mathcal B^\phi_{m,i}.
\tag{BD10}
\]
这只是原核展开，不假设输入 f 或来源 ν 是乘积。

### hard 锚点

在 I_i=J_i∩[y_i−L/2,y_i+L/2] 上，BD7 的指数至多 e²。因此 BD9 中的 bad 部分及尺度因子至多16e⁴。已审 HC5 与 Hölder 给
\[
\frac1{RL}\int_{I_i}
\left[\frac{H_mk_m(u-v_i)}{\omega_i(v)}\right]^\theta du
\le\frac{m_0}{RL}\gamma^\theta.
\]
因为 log(16e⁴)<7，得到
\[
\boxed{\mathcal B^h_{m,i}\le
\frac{m_0}{RL}\gamma^\theta e^{7\theta}.}
\tag{BD11}
\]
I_i 为空时左边为零。这里的 good 逆权由原交叠长度与 C 抵消，不是把其点态包络放在 hard 部分上；后者会无谓增加费用。

### soft 锚点

将 BD7–9 相乘，并用 L≤b，令 r=(u−y_i)/L，得到比值包络
\[
\frac{k_m(u-v_i)\omega_i(z')}
{q_{1,b}(u-z'_i)\omega_i(v)}
\le A_*e^{8|r|},\qquad A_*=256e^4.
\tag{BD12}
\]
θ=0 的标准化 soft 积分至多ρ₀=31/32（SA8）。令 X 的密度为原 φ；已审且自含的指数矩为
\[
\mathbb E e^{|X|/2}<8/3,\qquad
\mathbb E|X|e^{|X|/2}<5.
\]
对 0≤θ≤1/16，A_*^(1/16)<2、log A_*<10，故
\[
\frac d{d\theta}\left(A_*^\theta\mathbb E e^{8\theta|X|}\right)
<2\left(10\cdot\frac83+8\cdot5\right)=\frac{400}3<134.
\tag{BD13}
\]
由 L/m₀≤2，和 SA11 同样的非负包络扰动步骤给
\[
\frac1{m_0}\int_{J_i}\phi((u-y_i)/L)
\left[\frac{k_m(u-v_i)\omega_i(z')}
{q_{1,b}(u-z'_i)\omega_i(v)}\right]^\theta du
\le\rho_0+268\theta.
\]
当 θ≤2^(−15) 时，268θ<1/64，因而
\[
\boxed{\mathcal B^\phi_{m,i}\le\frac{m_0}{RL}\frac{63}{64}.}
\tag{BD14}
\]
soft 部分在整个 hard-z 区间 J_i 上处理，没有引入任何 bad 下确界。

## 5. 合并、显式 θ 范围与整维价格

记 κ=63/64。BD10–14 给
\[
\mathcal B_{m,i}\le\frac{m_0}{RL}
\left[(1-s)\gamma^\theta e^{7\theta}+s\kappa\right].
\tag{BD15}
\]
逐坐标相乘后，
\[
\begin{split}
\prod_i\mathcal B_{m,i}
&\le\left(\frac{m_0}{RL}\right)^n
\gamma^{n\theta}\exp\left(n[7\theta-s/64]\right)\\
&\le e^\theta e^{-ns/128}
\left(\frac{m_0}{RL}\right)^n,
\end{split}
\tag{BD16}
\]
其中第一步用 γ^θe^(7θ)≥1、1−x≤e^(−x)，第二步要求
\[
\boxed{0<\theta\le\min\{2^{-15},s/896\}.}
\tag{BD17}
\]
因为 7θ≤s/128 且 γ^(nθ)≤e^θ。特别 θ=s/32768 对全部实际 s∈(0,1] 合法。最后将三个整维 m 相加，m₀/(RL)=1/max(L,R)，证得 BD0。

BD0 的单位为 length^(−n)，其指数因子属于未归一化 hard-carrier 接收积分。若把它除以载体总质量∫p h_R，该质量本身也可能随 ns 指数下降，故不推出归一化双门矩小于1；与“删除双门的共同来源矩可以≥1”无冲突。实际最小软度仍允许 ns≈log2，因此也没有统一的大维指数收益。

## 6. 原费用如何保留：source 整合仍未闭合

1. **原 high/FIRST 保留，但未兑换新来源价格。** 同一 x 和同一 ν 仍满足 pe_g≥2Kq、∫Q*ν≤q、∫Jν≤q，并给 ∫_(S_g)w_gν≤e_g/2。BD3 的分母 J 是这套原共同测试之一；证明并未从其容量推出逆核矩帽，而是通过 BD7 直接消去 bad 位置。取得 BD0 不表示 high/RC/全部 history 已被使用来付全局积分。

2. **没有消去 hard-z 来源。** BD4–16 的接收积分始终含 h_R(x−z)，但最终常数对 z 均匀。若把这个常数直接对 ν(z) 积分，就会留下原硬来源总质量 M=‖ν‖，而非原硬行帽 q。粗略说，在一个参数共同、其余门被正扩大且 Π_t 合法固定的块上，即使用 δ_t≤n、两份 Π_t 质量≤1，也仅得形如
   \[
   \frac{3e^\theta n e^{-ns/128}}{q[\max(L,R)]^n}
   \int d\beta(y)\int d\nu(z)
   \tag{BD18}
   \]
   的块价，外加原时间长度和块的合法参数包络费用。这个 M/(q max(L,R)^n) 没有原统一帽。因而原 f∈L¹ 时该粗源积分未必字面为∞，但它仍不能按统一常数乘 W_β 付款；在没有来源总质量/参数总和控制时，也不能保证相应统一求和可积。BD18 只显示把局部常数盲目回乘的损失，不是原实际交通的反例。

3. **双来源分母与自适应不能删。** 真实权重仍是 w_t(z′)w_t(v)ν(z′)ν(v)/e_t²，与外层 ν(z) 形成原 ν³/e_t²；β−ν、Σj、原 dt/t、FA/Ψ、ρ 和 x/y/z history 均保留。虽然 BD0 对 v,z′ 的位置统一，实际 g、D_g/S_g、ρ、s,L,R、q 等依 x，不能据此免费把 Π_g 或这些门提出 x 积分。选择 θ=s/32768 是固定参数定理中的合法选择；在原自适应 x 上逐点这样选，不等于已经有一个可积的共同接收包络。

4. **signed 账不动。** 本稿只给正项上界，没有使用 N_Zc 或 N_del，也不取回 N_Z。原 δ_t 没有得到根阶平均控制；最小 s 域里的 BD0 仅有常数衰减，不能吸收 δ、Σj、尺度网格或全部源费用。任何后续使用必须保留这些尚未支付的项，不能将 BD0 直接填作 εX+C√nW_β。

**最终交付。** 整维全软共同分母确实消除了 SA17 的 bad 位置依赖及区间下确界代价；BD0/BD17 给出全位置、全合法尺度的明确局部矩上界和显式 θ 范围。一般 source 整合、自适应与 signed 根阶预算仍未证明。本轮完成此核改善后停止。


# 附件：bad_denominator_audit.md

# R131 bad denominator：先行独立命题与费用审查

STATEMENT_AUDIT_STATUS: PASS_FOR_FIXED_PARAMETER_RECEIVER_BOUND
GENERAL_SOURCE_BUDGET_STATUS: UNPROVED

本稿未读R131新作者证明，只用R130已审HC/SA及父任务给定候选做独立推导。R130文件不改。可成立版本如下：原合法固定共同参数n、s>0、a≤L,R≤b≤2a、H₁=L、H₂=L⁺、H₃=b，m₀=min(L,R)，原比例带 `m₀≤c_jg≤γm₀` 且c_jg≤b。取

\[
0<\theta\le\min\{2^{-15},s/896\}.
\]

则固定参数、原双绝对门且ρ≤1的接收列有

\[
\int_{O_E}p\,h_R\rho\,1_{\{good,bad\}}dx
\le3e^\theta e^{-ns/128}\max(L,R)^{-n}.
\tag{BD1}
\]

这是保留hard-z后，对任意y,z,z′,v位置的共同列界；右侧不再含bad位置逆核或good逆权。θ=2^(−15)s在全部实际0<s≤1合法。它不是来源价格，尚不能登记一般root付款。

## 1. Q*分母方向及三核费用

good为 `p w_g(v)≤KQ*(v)`，bad为 `p w_g(z′)>KQ*(z′)`，共同θ>0给

\[
1_{good,bad}\le
\left(\frac{Q^*(v)w_g(z')}{Q^*(z')w_g(v)}\right)^\theta.
\]

这是同一θ联合两门，K及p门幂一次抵消，δ/score没有参与或减少。原Q*=(K₁+K₂+J)/3是三个整维乘积的和。由 `Q*(z′)≥J(z′)/3`、0<θ≤1的次幂可加性，

\[
Q^*(v)^\theta\le3^{-\theta}\sum_{m=1}^3 K_m(v)^\theta,
\quad
Q^*(z')^{-\theta}\le3^\theta J(z')^{-\theta}.
\]

因此3^θ与3^(−θ)精确抵消，最终只有一次三项和，外系数1。若先用Q*(v)≤max K_m再求和，则会留下一个合法但较粗的全维3^θ；该因子必须付一次，绝不是每坐标3^θ或3^n。本推导选择前一精确路线。

固定同一m，乘积核与hard-z盒给每坐标目标

\[
T'_{m,i}=\frac1R\int_{J_i}q_{s,L}(u-y_i)
\left[\frac{k_m(u-v_i)}{\omega_i(v)}
\frac{\omega_i(z')}{b^{-1}\phi((u-z'_i)/b)}\right]^\theta du,
\quad J_i=[z_i-R/2,z_i+R/2].
\]

核下界使反向幂变大，方向正确；没有用单一bad测试与每坐标不同的good赢家拼接。

## 2. bad平移比较：PASS，须用原比例带下界

完整C≤4e²φ(d)，因为F≤4φ及logφ的4-Lipschitz。原 `c_jg≥m₀≥a≥b/2` 给

\[
\omega_i(z')\le\frac b{c_jg}C(d)\le2C(d)\le8e^2\phi(d),
\quad d=|y_i-z'_i|/b.
\]

饱和ω=1亦满足这个上界；不能仅由c_jg≤b推出ω≤2C，比例带下界不可省略。设B=8e²，平移Lip给

\[
\frac{\omega_i(z')}{\phi((u-z'_i)/b)}
\le B\exp(4|u-y_i|/b).
\tag{BD2}
\]

因此该坐标的共同ratio≤ `(b/H_m)^θ B^θ exp(4θ|u−y_i|/b)[H_m k_m(u−v_i)/ω_i(v)]^θ`，b/H_m≤2。bad来源位置确已消掉，但每坐标成本需要保留。

## 3. hard/soft完整锚点：独立常数复算

**hard项。** 只在I_i=J_i∩hard-y上积分，|u−y_i|≤L/2，故exp(4θ|u−y_i|/b)≤e^(2θ)。HC5及凹幂Hölder给

\[
H'_{m,i}\le\frac{m_0}{RL}
[(b/H_m)B]^\theta e^{2\theta}\gamma^\theta
\le\frac{m_0}{RL}\gamma^\theta e^{7\theta}.
\tag{BD3}
\]

最后使用2Be²=16e⁴，log(16e⁴)<7。交叠因子(l_i/m₀)^(1−θ)≤1已作正放松，空交集直接零。

**soft项。** SA的good比值包络为A₀ exp(4|u−y_i|/L)，A₀=16e²；BD2及b/H_m≤2叠加后得到完整ratio包络

\[
A_*\exp(8|u-y_i|/L),\qquad A_*=256e^4=A_0^2.
\]

这不是免费沿用SA原指数4的界，必须重新付指数8的扰动。R130已核零倾斜基线≤31/32；对X密度φ，Eexp(|X|/2)<8/3、E|X|exp(|X|/2)<5。令Z(θ)=A_*^θ Eexp(8θ|X|)。θ≤1/16时A_*^θ<2、logA_*<10，故

\[
Z'(\theta)<2[10\cdot(8/3)+8\cdot5]=400/3<134.
\]

L/m₀≤2给soft窗口正扰动≤268θ。θ≤2^(−15)使268θ<1/64（268<512），所以

\[
S'_{m,i}\le\frac{m_0}{RL}\frac{63}{64}.
\tag{BD4}
\]

全部指数矩仍在有限域内；θ≤2^(−15)严格满足旧θ≤2^(−14)限制。这里使用保守参数即可，不靠浮点边界。

由原坐标线性分解q_s=(1−s)h+sφ，T′≤m₀/(RL)[(1−s)γ^θe^(7θ)+s·63/64]。令Cθ=γ^θe^(7θ)≥1，则该括号≤Cθ exp(−s/64)。整维乘积保留全部mixed掩码，给

\[
\prod_iT'_{m,i}\le\max(L,R)^{-n}
 e^\theta\exp[n(7\theta-s/64)].
\]

θ≤s/896恰给7θ≤s/128，得到BD1，三项和只付3一次。若改选粗Q*路线，应再保留全维3^θ；它不是本推导缺项。

## 4. θ随s与原门/score

θ=2^(−15)s对实际s>1−2^(−1/n)>0始终正，且≤2^(−15)及s/896。它不改变good/bad阈值或共同K，不重新选RC捕获，亦不需要删除α_rec=0分支。θ必须在两端、全部n坐标及三核拆分中共同使用；不能逐来源/坐标最优化后省掉费用。

上面列积分固定同一s,L,R及共享j/g。实际s(x)、L(x)、R(x)依x时，θ(x)=c s(x)在点态门不等式仍合法，但**不能**把这些依x参数免费冻结成上述乘积列积分。共同可测包络/选择器及其真实价格仍须证明。δ_t=[k_t(v)−k_t(z′)]_+完全保留；小θ的消逆权不提供δ指数尾或n^(−1/2)损失，也不改变score的量词。原s下端允许ns为常数，因此exp(−ns/128)不能自动吸收Σj、score、时间或自适应费用。

## 5. 来源可积性与准确停点

BD1右侧是**有量纲的核列**，含max(L,R)^(−n)，不是免费维数无关的实际源价格。外层仍 `q^{-1}p h_R a_history dx dβ(y)dν(z)`；内层仍原δ、FA/Ψ、RC余权、Z_t、w_t(z′)w_t(v)/e_t²、dν(z′)dν(v)及dt/t。hard z在推导中作为真实积分盒保留，没有先用硬帽或把z换成辅助z′；β−ν、ν³/e_t²及原history未删除。

固定合法有限截断、有限ν/β及正q/尺度时，这个列界可帮助取得有限的粗正积分；不能声称它证明“来源积分必发散”。然而将列界对原来源积分，Π_t归一化只处理其真实概率部分，δ及原门/时间仍在；外层hard ν(z)、β(y)、q与尺度因子并未转换成线性W_β价格。删除所有位置信息后粗积分可能带总ν质量等额外输入依赖，不能据此登记统一 `εX+C n^(1/2+o(1))W_β`。这些来源费用及外层signed极限依旧未证；得到bad位置无关接收界不等于获得一般来源预算。

N_Zc/N_del仍整个原存活负项各一次，没有随正双门/新列界变窄，也未消费；已消费N_Z不返回。**可成立新结论为BD1固定参数接收估计；一般source/root及实际自适应覆盖仍未获。** 先行独审完成，到此停止，不读取作者证明或修改他人文件。

## 冻结作者稿后审与最终绑定

FINAL_PROOF_AUDIT_STATUS: PASS_FOR_BD0_FIXED_PARAMETER_RECEIVER_BOUND
GENERAL_SOURCE_BUDGET_STATUS: UNPROVED
NEW_ACTUAL_PAYMENT_STATUS: NONE

先行独立推导完成并保存后，依主代理授权读取 `bad_denominator.md`。最终实读、复核SHA-256：`99eb6d2c6dd2630639c7ac856ed0552c3c950eec6291e9e3ab86c73d17817a49`。本审不修改作者稿或R130文件，不执行数值。

1. **BD1–5门与整维拆分PASS。** 作者明列m₀≤c_jg及c_jg≤b，固定所有参数、四来源位置与原O_E。两绝对门使用同一η=θ、ξ=0，K及门p幂抵消；Q*的3^(−θ)与3^θ确实抵消，三整维核求和一次。ρ和a_other≤1只作正扩大，未改原实际余权；没有坐标重选分母。对应本审先行BD1的作者最终BD0范围准确。

2. **BD6–9bad比较PASS。** 完整C≤4e²φ，b/(c_jg)≤2依赖真实比例带下界，饱和ω同样受2C控制。平移logφ给8e²exp(4|u−y|/b)；q_(1,b)=b^(−1)φ使b/H_m必须出现，作者显式保留并用H_m≥L≥a≥b/2得≤2。位置比较常数、核单位及方向均核准。

3. **BD10–14 hard/soft成本PASS。** hard交集内exp(4|u−y|/b)≤e²，b/H≤2合bad常数成16e⁴，log<7；HC5/Hölder给m₀γ^θ/(RL)，无额外H。soft新包络256e⁴与指数8正确，非直接误用SA原指数4的结果。θ≤1/16时导数<400/3<134，窗口放大L/m₀≤2只付一次；268·2^(−15)<1/64，统一soft因子63/64正确。

4. **BD15–17整维合并与θ=s/32768 PASS。** `(1−s)γ^θe^(7θ)+sκ≤γ^θe^(7θ)exp(−s/64)`，故n次方指数为n(7θ−s/64)。θ≤s/896恰使该指数≤−ns/128，γ^(nθ)≤e^θ；θ=s/32768在0<s≤1同时满足θ≤2^(−15)、θ≤s/896及旧θ≤2^(−14)。m₀/(RL)=max(L,R)^(−1)，最后三项求和产生3一次，作者BD0的全部系数、尺度与指数通过。实际s下端只给ns常数量级，作者未声称可吸收任意多项式。

5. **BD18及来源/signed限制PASS于所述诊断范围。** 作者明确BD0为未归一化length^(−n)列界，不能除以可能同样下降的carrier质量后声称比较概率有指数缺口。盲目对hard ν(z)积分留下M/(q max(L,R)^n)；两份固定Π_t至多归一化其概率质量，δ≤n仍要付，时间/块/共同参数费用另在。BD18是固定块的粗价格诊断，未被当作全原槽恒等式或实际反例。原ν³/e_t²、β−ν、q、Σj/time、FA/Ψ、RC与history仍明示；实际θ(x)合法点态选择不证明可积列包络。没有消费N_Zc/N_del，也未取回N_Z。

**最终判定：作者冻结稿BD0及其显式θ域、全位置bad消逆权证明PASS。** 这个核改善改变可用的固定参数接收估计，但没有统一source可积价格或自适应/signed根阶闭合。有限f下粗源积分可能有限；缺的是统一线性root预算，不能以字面发散代替这一准确限制。原账不变，绑定最终SHA后停止。


# 附件：anchor_first.md

# R131：先付硬来源的共同参数列估计

状态：主代理解析推导；独审先行指出固定参数来源预算被更强的直接归一化基线支配，不登记新来源付款。全线倾斜矩的最终证明审查另见附件。它针对原交通中的硬来源积分顺序，不假设输入为特殊函数族；但共同参数条件不能免费推广到接收点自适应参数。

## 命题与真实费用

采用BD1–9原真实核与比例带，固定n≥1、共同s,L,R,g,j,t及非负有限来源ν。设Π_t为原合法子概率，独立接收x和外硬来源z。y,z′,v可任取。令
\[
A(x;y,z',v)=\frac{Q^*(x,v)w_g(z')}{Q^*(x,z')w_g(v)},\qquad \theta=\frac1{134n}.
\tag{AF1}
\]
实际s>0保证各分母正，θ≤1/134<1/16。断言
\[
\int_{\mathbb R^n}P_{s,L}(x-y)A(x;y,z',v)^\theta dx\le3e.
\tag{AF2}
\]
本式没有硬载体，也不要求θ≤s/896，因为不请求BD0的soft指数缺口。

## 核证明

BD3的三整维测试拆分只发生一次，3^θ和3^(-θ)抵消。每坐标比值由BD7–9控制为
\[
\frac{k_m(u-v_i)\omega_i(z')}{q_{1,b}(u-z'_i)\omega_i(v)}
\le A_* e^{8|r|},\quad A_*=256e^4,\quad r=(u-y_i)/L.
\tag{AF3}
\]
硬锚点归一化积分在|r|≤1/2，因log A_*+4=8log2+8<14，至多e^(14θ)。软锚点的全线积分至多
\[
F_\theta=A_*^\theta\mathbb E e^{8\theta|X|},\quad X\sim\phi.
\]
已审原矩E exp(|X|/2)<8/3及E|X|exp(|X|/2)<5，结合θ≤1/16、A_*^(1/16)<2、log A_*<10，给
\[
F'_\theta<2(10\cdot8/3+8\cdot5)=400/3<134.
\]
F_0=1，故F_θ≤1+134θ≤e^(134θ)。实际混合锚点的一维完整积分≤(1-s)e^(14θ)+s e^(134θ)≤e^(134θ)。整维相乘≤e^(134nθ)=e，三整维测试求和给AF2。全程真实dx积分，无来源坐标独立假设。

## 先积分硬来源

在贡献接收域O上，假设原行帽
\[
h_R*\nu(x)\le4\lambda,
\qquad q\ge3\lambda/4.
\tag{AF4}
\]
令0≤a(x,z)≤1保留原接受/history等门，δ_t(z′,v)=[k_t(v)-k_t(z′)]_+。双good/bad绝对门由A^θ支配；其他正门和RC≤1。因此先Tonelli积分z（ν可任意非负L1来源），使用AF4后再扩大x域并用AF2，得到
\[
\begin{split}
&\frac1q\int_O\int p(x,y)h_R(x-z)a(x,z)
\iint\rho\,1_{D_g\times S_g}\delta_t(z',v)
\,d\Pi_t(z')d\Pi_t(v)\,d\nu(z)dx\\
&\le\frac{12e\lambda}{q}\iint\delta_t(z',v)d\Pi_t(z')d\Pi_t(v)
\le16e D_{jyt}.
\end{split}
\tag{AF5}
\]
在此共同参数列里，外硬来源总质量M消失；不是要求M≤q。权重ν²/e_t²仍准确包含在Π_t⊗Π_t内，不能另付M²/e_t²。若history只将原ν限制到子测度，正扩张到ν合法；若其使参数、q、Π或δ依赖z/x，则本式需另做共同块或可支付包络，不能直接交换冻结。

## 留下的主瓶颈

AF5只支付共同参数列的核与硬来源费用。仍需对β(y)、真实dt/t、全部j及接收点自适应参数求总价。0≤k≤n给D≤n/4（独立同分布复制的半平均绝对差），不能直接给sqrt(n)。一般来源Π可能相关，不由产品权重推出坐标独立或方差O(n)。把每个j的AF5相加也会产生层数费用。

本式没有消费N_Zc/N_del，没有取回已消费N_Z，没有把负项乘上新正门。后续需要控制保留来源结构的score/跨层预算，并证明实际自适应参数可使用本列估计；局部可付款不等于一般signed根阶闭合。

## 独审指出的更强已有基线：不登记新来源付款

相同固定参数、原Π与score独立x,z时，可以直接丢掉全部正门，用h_Rν≤4λ及∫p dx=1，得(4λ/q)D≤(16/3)D，比AF5的16eD更强。故AF2是一个全线逆权矩引理，AF5仅说明粗略BD18的M损失可以通过旧操作避免，不构成新的可付款分支。不能为了保留新推导而省略此基线。实际自适应参数、跨j费用和score删除账才是剩余问题。


# 附件：anchor_first_audit.md

# R131 anchor-first：独立命题与来源回代审查

KERNEL_STATEMENT_STATUS: PASS_FOR_FIXED_PARAMETERS
SOURCE_BOUND_STATUS: PASS_BUT_DOMINATED_BY_NORMALIZATION_BASELINE
ROOT_PAYMENT_STATUS: UNPROVED

此稿依据主代理消息中的候选独立证明，未读取主代理的新 anchor-first 证明。已读取 R130 HC/SA 及其原核审查、R131 bad_denominator.md 以核对共同全软分母与 φ/C 定义；下述全线矩与回代判断独立展开。无数值执行，不修改其他文件。

**结论。** 固定共同参数时，θ=1/(134n) 的全线逆权矩 ≤3e 成立，对任意三来源位置统一。提出的 16e 来源正项上界也成立，但直接概率归一化已给更强的 16/3 基线，因此该来源回代本身不是新增付款收益。δ 的均值、自适应接收参数、时间及层求和仍未支付。

## AF1. 准确量词和域

取整数 n≥1，原合法 s∈(1−2^(−1/n),1]，尺度 a≤L,R≤b≤2a，g=√(LR)，γ=1+1/n，m₀=min(L,R)，原比例带满足

\[
m_0\le c_jg\le\gamma m_0,\qquad c_jg\le b.
\tag{AF1}
\]

所有这些参数在一次 x∈Rⁿ 积分中固定，来源位置 y,v,z′ 任意有限实向量。不能只保留 AF1 的两个不等式而删掉 a≤L,R≤b≤2a；下文使用 b/(c_jg)≤2、b/H_m≤2 和 L≤H_m≤b。

记原 h₁=1_[−1/2,1/2]、w(u)=∫₀¹e^(−|u|/r)dr、φ=h₁*w、F=max(h₁,φ)、C(d)=∫_[−1/2,1/2]F(u−d)du。定义

\[
\omega_i(\xi)=\min\{1,bC(|y_i-\xi_i|/b)/(c_jg)\},\quad
w_g(\xi)=\prod_i\omega_i(\xi).
\]

原 Q_x^*=(K₁+K₂+J)/3，其中 K₁=P_{s,L}、K₂=P_{s,L⁺}、J=P_{1,b}，L⁺=min(b,γL)，各核中心为其来源位置。设

\[
\mathscr A(x)=\frac{Q_x^*(v)w_g(z')}{Q_x^*(z')w_g(v)}.
\]

φ,C,ω 均严格正；Q*≥J/3>0，因此该比值可测且没有除零。实际 s 的严格下门照旧保留；本核证明不把边界 s=0 当实际交通。当前核引理不需要 ν 或 Π_t；它们只在后面的来源回代出现。

## AF2. 位置无关的一维包络

沿已审真实核性质，φ≤F≤4φ，logφ 为 4-Lipschitz，0<C≤1。完整 C 的上下比较为

\[
e^{-2}\phi(d)\le C(d)\le4e^2\phi(d).
\tag{AF2}
\]

下界由区间内 φ(u)≥e^(−2)φ(d) 积分得到，上界由 F≤4φ 与相反 Lipschitz 界得到；没有把 C 缩成单个尾分支。

对任意 H∈[L,b] 和 k=q_{s,H}（或 H=b、k=q_{1,b}），Hk(u−v)≤F((u−v)/b)。又 ω(v)≥C(|y−v|/b)，故已审的保守包络为

\[
\frac{Hk(u-v)}{\omega(v)}
\le16e^2\exp(4|u-y|/L).
\tag{AF3}
\]

另一方面，b/(c_jg)≤2，故 ω(z′)≤2C(|y−z′|/b)，包括饱和分支。由 AF2，

\[
\frac{\omega(z')}{\phi((u-z')/b)}
\le8e^2\exp(4|u-y|/b).
\tag{AF4}
\]

令 r=(u−y)/L。因为 q_{1,b}=b⁻¹φ(·/b)，尺度比 b/H≤2 不能漏掉。两式合并得到

\[
V_m(u):=\frac{k_m(u-v)\omega(z')}
 {q_{1,b}(u-z')\omega(v)}
\le256e^4 e^{8|r|}=:A_*e^{8|r|}.
\tag{AF5}
\]

该界对所有 v,z′ 统一，与核尾位置无关。其用途是小正幂矩，不是点态有界；r 的全线增长仍须由锚点核积分。

## AF3. hard 与 soft 全线锚点矩

对 0<θ≤1/16，在 hard 锚点 |r|≤1/2 上，

\[
\int h_L(u-y)V_m(u)^\theta du
\le\exp((\log256+8)\theta)
\le e^{14\theta}.
\tag{AF6}
\]

使用 log2<3/4 即得 log256<6，常数方向严格正确。这里 h_L 已为概率密度，没有 hard-z 长度因子。

soft 锚点令 X 密度为 φ。原卷积可表为 X=U+Y，U 均匀于 [−1/2,1/2]，Y 密度 w，二者独立；这只是核的辅助表示，不对原 f/ν 作产品假设。直接 Tonelli 给

\[
\mathbb E e^{|Y|/2}=2\int_0^1\frac r{1-r/2}dr\le2,
\quad
\mathbb E|Y|e^{|Y|/2}
=2\int_0^1\frac{r^2}{(1-r/2)^2}dr\le8/3.
\]

由 |U|≤1/2、e^(1/4)<4/3 得

\[
\mathbb E e^{|X|/2}<8/3,
\qquad \mathbb E|X|e^{|X|/2}<44/9<5.
\tag{AF7}
\]

写 B(θ)=A_*^θ E e^(8θ|X|)。log A_*<10、A_*^(1/16)<2；在 0≤θ≤1/16 上，用 AF7 支配微分，

\[
B'(\theta)
=A_*^\theta\mathbb E[(\log A_*+8|X|)e^{8\theta|X|}]
<2(10\cdot8/3+8\cdot5)=400/3<134.
\tag{AF8}
\]

因此 B(0)=1 给 B(θ)≤1+134θ≤e^(134θ)，且

\[
\int L^{-1}\phi((u-y)/L)V_m(u)^\theta du
\le B(\theta)\le e^{134\theta}.
\tag{AF9}
\]

全线指数矩确实在 8θ≤1/2<1 的可积域内；没有用有限区间可积性替代整线可积性。原完整混合锚点据此满足

\[
\int q_{s,L}(u-y)V_m(u)^\theta du
\le(1-s)e^{14\theta}+s e^{134\theta}
\le e^{134\theta}.
\tag{AF10}
\]

没有仅保留全 hard 掩码，也未漏 soft 部分。

## AF4. 整维共同分母及 3e

用同一个整维 J(z′) 下界 Q*(z′)≥J(z′)/3。对 0<θ≤1，次幂次可加给

\[
\mathscr A(x)^\theta
\le\sum_{m=1}^3
\left[\frac{K_m(x,v)w_g(z')}{J(x,z')w_g(v)}\right]^\theta.
\tag{AF11}
\]

分子 3^(−θ) 与分母 3^θ 精确消去；同一个 m 在 n 个坐标共同使用，不能生成 3ⁿ 项。对真实 Lebesgue dx 使用乘积核与非负 Tonelli，AF10 得

\[
\int_{\mathbb R^n}P_{s,L}(x-y)\mathscr A(x)^\theta dx
\le\sum_{m=1}^3\prod_{i=1}^n e^{134\theta}
=3e^{134n\theta}.
\tag{AF12}
\]

θ=1/(134n) 对每个 n≥1 都小于 1/16，因而候选结论

\[
\boxed{\int P_{s,L}(x-y)\mathscr A(x)^{1/(134n)}dx\le3e}
\tag{AF13}
\]

成立。此结论本身是全线逆权矩工具，常数不依 s、位置和合法尺度；它不是小于 1 的双门概率界，也不含 score 衰减。

## AF5. 硬来源先积分的准确预算与更强基线

固定共同 s,L,R,g,j,t,y、有限 ν、同一 Π_t。Π_t 以及 δ_t(z′,v)=[k_t(v)−k_t(z′)]_+ 在本次 x 和硬来源 z 积分之前确定，不依赖二者。Π_t=e_t⁻¹1_{Z_t}w_tν，仅在 e_t>0 的纤维定义；e_t=0 按原零交通约定处理。来源位置无须独立坐标，Π_t⊗Π_t 只是原两份辅助来源积分。

设可测接收域 O 上 h_R*ν(x)≤4λ，且 0≤a(x,z,z′,v)≤1 为其余实际正门/RC/FA/Ψ/history 的乘积；可以含更多标签。a 的 x 支撑须在这个帽成立的域内。允许 O 依赖已固定的 y,t 或辅助来源对，只要在先积分 z 时确实有同一帽；不能用仅对单个 z 的局部点值替代完整 h_R*ν。

若 q>0 在该块固定，定义原双门正项块

\[
\begin{split}
\mathcal B={1\over q}\iint\delta_t(z',v)d\Pi_t(z')d\Pi_t(v)
\int_O p(x,y)\int h_R(x-z)a(x,z,z',v)d\nu(z)\\
\qquad\cdot1_{\{p w_g(z')>KQ_x^*(z'),\ p w_g(v)\le KQ_x^*(v)\}}dx.
\end{split}
\tag{AF14}
\]

双门上 𝒜>1。先用硬来源帽、再把正接收域扩大至整线并用 AF13，Tonelli 给

\[
\mathcal B\le{12e\lambda\over q}
\iint\delta_t\,d\Pi_t^{\otimes2}
\le16e\iint\delta_t\,d\Pi_t^{\otimes2},
\qquad q\ge3\lambda/4.
\tag{AF15}
\]

若 q=q(x) 只满足统一下界，不能把 12eλ/q 写成块外标量；直接先用 1/q(x)≤4/(3λ) 仍给末式。hard-z 先积分后没有留下 ν 总质量，也没有保留旧 R^(−n) 再重复领取帽。

**但 AF15 并非该块的最佳已有基线。** 同一条件下直接用全部正门≤1，随后用固定锚点概率密度 ∫p dx=1，即得

\[
\boxed{\mathcal B\le{4\lambda\over q}
\iint\delta_t\,d\Pi_t^{\otimes2}
\le{16\over3}\iint\delta_t\,d\Pi_t^{\otimes2}.}
\tag{AF16}
\]

这一推导不需要 AF13，也不需要 good/bad 门或任何逆权估计。故不能把 AF15 的 16e 标成新来源费用改善；AF13 的意义只在以后确有需要保留倾斜矩的论证中，不能由这一粗回代自动获得收益。

## AF6. 未付费用、实际量词与停止结论

AF14–16 仍保留原 δ_t。对于完整同 Π 双源，`∫δ_t⁺=½E|k_t(V)−k_t(Z′)|`；仅有 0≤k≤n 时可得 ≤n/4（用 [0,n] 上各阈值概率 a(1−a)≤1/4 的层积分），仍是线性 n。没有核/来源几何的附加证明，不能由固定参数 3e 推出 √n score 预算。上界中的全 Π² 是对原终端 D/S 的正扩大，不是把 S_g 误当全 Π 补集。

真实外层 dβ(y)、β−ν、dt/t、EΣ_{V,j}、唯一比例带与全部 history 继续存在。硬帽仅已用于 z 一次；两份 Π 所含 w_tν/e_t 仍在。对每个固定 y,t 的源块有界，不提供整个时间窗、j/尺度网格或可测参数选择器的免费总和。

尤其原 s(x),L(x),R(x),g(x) 会随 x 变化，p_{s(x),L(x)}(x−y) 一般不是一个已归一化的固定概率密度。AF13 与 AF16 都不能逐点选择参数后直接积分；需要真实共同包络及其付费。Π_t 在固定前置标签下可移出，并不使终端门、w_g 或自适应核免费固定。

本审只给正项上界；没有使用 N_{𝒵ᶜ} 或 N_del，也不取回已消费 N_𝒵。FA/RC/Ψ 的放松仅使正上界变粗，未新增捕获覆盖、吸收费或 full 资格。所有 n 的固定核引理成立，不意味着原有限/高维真实交通域被扩展。

**最终判定：候选全线矩 PASS；候选固定参数来源式 PASS，但被 AF16 的直接归一化界支配。不存在由该回代得到的一般根阶闭合。保留 AF13 作为核工具，完成后停止。**

## AF7. 主稿短增量后审与版本绑定

先行 AF1–AF6 完成后才读取主稿 `anchor_first.md`。实际读取 SHA-256：`c251aff33216101ab343df7b71e2ad9bfc3625fe24460aa007f8b2f61bcd51af`。

**增量后审 PASS，无修订要求。** 主稿 AF2 的 3e 全线矩证明与上述独立 AF2–AF4 一致：整维三项仅求和一次，hard 的 14θ、soft 的导数 134、θ=1/(134n) 及完整 mixed 乘积均正确。没有误继承仅用于 BD 指数缺口的 θ≤s/896 限制，也没有借来源坐标独立。

主稿 AF5 在固定共同参数、q 与同一来源/score 独立 x,z 的范围内成立；其文字明确说明这些对象若依赖 x/z，必须另作共同块或支付包络。将 Π 允许为原概率的固定子测度也不破坏非负积分上界；若引用 D≤n/4，则对子质量 m>0 条件化后回乘 m²≤1，m=0 时直接为零。

主稿开头及最后一节已经明确写出更强 `(4λ/q)D≤(16/3)D` 归一化基线，并说明 AF5 只避免粗 BD18 操作中的总质量 M 损失，**不构成新的可付款分支**。中间“支付共同参数列”按这一显式范围理解为已有粗块上界，不登记新的来源预算。实际自适应参数、β、dt/t、j 求和、score 与负项删除账均继续保留。

本次只核主稿差异和文字范围，没有重做长证明、运行数值或修改主稿。固定参数引理与已有基线后审完成；一般根阶付款仍未证明，停止。


# 附件：source_integrability.md

# R131 来源整合：硬来源先积分，保留联合接收核

状态：**原账的精确整理与已有固定参数基线；没有新增一般根阶付款。** 本稿只处理来源整合，不重证 BD0，不把固定参数列界推广到实际自适应选择器。依最后的任务收束，不另提没有真实几何依据的强衰减猜想。

实读接口：R130 `TASK_CONTEXT.md`；R128 `joint_receiver_tail.md` 的 RT1–6；R130 `hard_carrier_joint_geometry.md` 的 HC1–2 与 `soft_anchor_extension.md` 的 SA17；R131 `bad_denominator.md` 的 BD3、BD7–18 及独审。以下在原合法有限交通截断上使用非负 Tonelli；零 e_t 的行按原约定不贡献。所有积分都是原真实 Lebesgue 接收积分。

## 1. 可以先积分什么

固定 \(\xi=(\omega,V,j,y,t)\)，记 \(\nu=\nu_V\)。原来源概率是

\[
d\Pi_\xi(v)=e_t(y)^{-1}1_{Z_t}(v)w_t(y,v)\,d\nu(v),\qquad
\delta_\xi(v,z')=[k_t(v)-k_t(z')]_+.
\tag{SI1}
\]

在这个固定层级，\(\nu,Z_t,w_t,e_t,\Pi_\xi,k_t,\delta_\xi\) 都不依赖接收点 x 或硬来源 z。\(\Pi_\xi\) 是同一个概率测度的两份拷贝；原 \(\nu\) 不要求乘积。

反之，\(p_x(y)=P_{s(x),L(x)}(x-y)\)、\(g(x)=\sqrt{L(x)R(x)}\)、\(w_{g(x)}\)、\(D_{g(x)},S_{g(x)}\)、RC 余权、FA、\(\Psi\) 与 history 一般依赖 x，部分也依赖 z。尤其实际 good/bad 集不能固定后提出 x 积分。它们只可在明确的正上界中放松。

原 \(R(x)\) 是接收选择器，不以硬来源 z 为新的选择参数。在实际贡献域，\(\nu\le f\)、\(h_{R(x)}f(x)\le4\lambda\)、\(q\ge3\lambda/4\)，所以

\[
q^{-1}\int h_{R(x)}(x-z)\,d\nu(z)\le\frac{16}{3}.
\tag{SI2}
\]

若 history 只允许部分 z，则其指示或接受因子在 [0,1] 内，积分仍受 SI2 控制。需要保留“原贡献域”的限定：不能在丢掉原硬帽有效域后，声称 SI2 对所有 x 自动成立。这个先积分 z 的操作本身不要求 s、L、R 对 x 为常数；后续对 p 的积分才遇到自适应困难。

## 2. 保留 history 与双门的精确联合核

把 RT2 中除 p、硬核、两个绝对 good/bad 指示和 \(\delta_\xi\) 外的全部正因子记为

\[
\begin{split}
a^+_\xi(x,z;v,z')={}&1_I1_{\{j(x)=j\}}1_{A_{hi}}
1_{\{t\in J_{far}(x)\}}a_\omega(x,y,z)\\
&\times\Psi\,\chi_{FA}\,\rho_{r}(v),\qquad 0\le a^+_\xi\le1.
\end{split}
\tag{SI3}
\]

所有原参数/history 依赖仍按实际值计算。若正项已与先前已付子支作不交化，相应指示也纳入 SI3。定义

\[
\begin{split}
c_\xi(x;v,z')&=\frac{3}{16q}\int h_{R(x)}(x-z)
a^+_\xi(x,z;v,z')\,d\nu(z),\\
\mathcal B_\xi(v,z')&=\int_{\mathbb R^n}p_x(y)c_\xi(x;v,z')
1_{D_{g(x)}}(z')1_{S_{g(x)}}(v)\,dx .
\end{split}
\tag{SI4}
\]

在贡献域用 SI2，域外按零延拓，得到 \(0\le c_\xi\le1\)。两个集合指示是原严格 bad / 非严格 good 比较，仍含同一 x、同一 Q* 与同一 \(g(x)\)，未替换成辅助比较。该核非负、共同可测，可取扩展非负值；有限截断不被用来假定尚未证明的统一可积性。

原正余交通现在精确等于

\[
\boxed{
P_I^{rem}=\frac{16}{3}\mathbb E\sum_{V,j}\int d\beta_V(y)
\int\frac{dt}{t}\iint
\delta_\xi(v,z')\mathcal B_\xi(v,z')\,
d\Pi_\xi(v)d\Pi_\xi(z').}
\tag{SI5}
\]

时间可在共同确定的外包区间积分，原 \(I_{j,V,y}\) 与 \([\tau_j,h(x)]\) 的限制仍在 SI3 内。SI5 只是对原 \(\nu(z)\) 作 Tonelli，然后重命名所得系数；没有把 \(\nu^3/e_t^2\) 换成免费总容量。两份 \(\nu\) 及 \(e_t^{-2}\) 精确保留在两份 \(\Pi_\xi\) 中，硬 z 则已由真实行帽处理。\(d\beta_V\) 完整保留，尤其 \(\beta_V-\nu_V\) 没有被删除。

SI5 是应继续研究的联合对象。它仍可能利用双门与 score、RC、history 的共同限制；不能用独立最坏值乘积替代后再声称保留了这种收益。

## 3. 固定参数已有基线，比无 hard-carrier 倾斜矩更强

在一个共同固定 \(s,L,R\) 的合法参数块，先用 SI2，再仅在正项中丢掉所有剩余门及余权。因为 \(\int P_{s,L}(x-y)dx=1\)，对每个来源对直接有

\[
\mathcal B_\xi(v,z')\le1,
\qquad
P_{\text{单块},\xi}^{rem}\le\frac{16}{3}\,D_\xi,
\quad
D_\xi:=\iint\delta_\xi(v,z')\,d\Pi_\xi(v)d\Pi_\xi(z').
\tag{SI6}
\]

这里的单块式是在尚未积分 \(d\beta\,dt/t\) 的层级。块的任意接收子集只会减小左侧；若为了覆盖自适应参数而使用许多块，每块这个常数不能免费重复领取。

BD7–8 的包络也可对全实线载体积分：hard 部分受 \(e^{C\theta}\) 控制，soft 部分以全 \(\phi\) 质量 1 为零倾斜基线，受 \(1+C\theta\) 控制；\(\theta\lesssim1/n\) 可给整维常数。但 SI6 直接给归一化常数 1，无需倾斜。因此“先硬帽后全空间矩”的固定块来源价格是旧基线，不是 R131 的新付款。

若反而先对 hard-z 接收列使用 BD0，再无差别积分 \(d\nu(z)\)，就会得到

\[
\frac{3e^\theta e^{-ns/128}}{q\max(L,R)^n}
\|\nu\|\,D_\xi.
\tag{SI7}
\]

SI7 的 \(\|\nu\|/(q\max(L,R)^n)\) 没有统一帽，但这是过早抹掉 hard-z 几何的损失。**它不是无法先积分 z 的根本来源障碍。** FIRST 的局部 \(\int J\,d\nu\le q\) 本来也不蕴含 \(\|\nu\|\le q\)；SI2 才是此处实际可用的支付方式。原有限正 L¹ 输入不意味着任何输入无关的总质量/尺度比。

## 4. 删门后剩余的粗量，只作为诊断

设 \(\Omega_\xi\) 是保留原接收选择器及必要贡献域、比例带和时间支持的一个可测外包，令

\[
A_\xi=\int_{\Omega_\xi}P_{s(x),L(x)}(x-y)\,dx.
\tag{SI8}
\]

正放松给 \(\mathcal B_\xi(v,z')\le A_\xi\)，故 SI5 可粗放为 \((16/3)\mathbb E\sum_{V,j}\int d\beta\int A_\xi D_\xi\,dt/t\)。实际 \(s(x),L(x)\) 变动时不能引用概率核的固定参数归一化来断言 \(A_\xi\le1\)。即使每个固定参数列有界，选择器取值域的包络/覆盖成本也仍需支付。

对同一 \(\Pi_\xi\) 下两个独立 score，令 \(F_r=\Pi_\xi\{k_t\le r\}\)。因为 \(k_t\in\{0,\ldots,n\}\)，有精确恒等式与粗界

\[
D_\xi=\frac12\mathbb E_{\Pi_\xi^2}|k_t(v)-k_t(z')|
=\sum_{r=0}^{n-1}F_r(1-F_r)
\le\frac n4,
\quad
D_\xi\le\sqrt{\operatorname{Var}_{\Pi_\xi}(k_t)/2}.
\tag{SI9}
\]

这只说明归一化两份 \(\nu/e_t\) 后仍有真实 score 费用。\(k_t\) 是 n 个阈值指标的和，但任意原 \(\nu\) 可使坐标相关；没有已证 \(\operatorname{Var}k_t=O(n)\)。high 门 \(pe_g\ge2Kq\) 与 FIRST 只给实际 good 质量的相应限制，不能直接作为无条件 \(\Pi_t\) 方差界。

再由 \(c_j=\gamma^{-j}\)、\(\tau_j=a/c_j\)、\(h(x)\le bc_j e^{-u/n}\)，有

\[
\ell_j:=\int_{a/c_j}^{bc_j e^{-u/n}}\frac{dt}{t}
=\big[\log(b/a)-2j\log\gamma-u/n\big]_+.
\tag{SI10}
\]

空区间取零。非空比例带数至多 \(n+2\)，且 \(\sum_j\ell_j\le(n+2)\log2\)。所以即使额外假定每一 j 的自适应接收质量都能免费取 1，SI9–10 也只给 \(O(n^2)W_\beta\) 的粗价，不能成为根阶结论。真实唯一 \(j(x)\) 并不意味着先逐 j 放松接收域后仍可省去这项求和。

这些界用于指出丢失了什么；**不把独立的 \(A_\xi\) 和 \(D_\xi\) 两个强上界推荐为下一条主要猜想。** 最小实际软度只使 \(ns\) 为常数量级，BD0 的指数因子不能自动吸收上述费用。

## 5. 不拆联合收益的精确尾账与停点

定义保留 SI4 全部几何/history 的联合尾质量

\[
\mathfrak T_\xi(r)
=\iint 1_{\{\delta_\xi(v,z')>r\}}\mathcal B_\xi(v,z')
\,d\Pi_\xi(v)d\Pi_\xi(z'),\qquad 0\le r\le n.
\tag{SI11}
\]

非负层蛋糕精确给

\[
P_I^{rem}=\frac{16}{3}\mathbb E\sum_{V,j}\int d\beta_V(y)
\int\frac{dt}{t}\int_0^n\mathfrak T_\xi(r)\,dr.
\tag{SI12}
\]

若未来从原共同 FIRST、真实来源/接收几何和 history 证明右侧除 \(16/3\) 外的量统一不超过 \(C\sqrt n\,H_nW_\beta\)，其中 \(H_n=n^{o(1)}\)，则该正余槽可按 \((32\Lambda/3)C\sqrt n\,H_nW_\beta\) 支付。这个“若”是精确未付对象的定位，不是非循环的新充分几何引理，更不是本轮贡献。本稿没有为 \(\mathfrak T\) 证明额外衰减、全局容量或新的有限数值证据，也不把无依据的高斯 score 衰减列为猜想。

尚未闭合的是 SI12 在实际自适应核、原双绝对门、共同 \(\Pi_t\)、\(\sum_jdt/t\) 与 history 下的联合预算。没有必要把已可由 SI2 支付的硬 z 再列成总质量难题；也不能抹去双门后要求另一个独立粗 score 界来代替这项联合问题。

全程只整理或上界正余项。\(N_{\mathcal Z^c}\) 与 \(N_{del}\) 仍各在原母式一次，已消费 \(N_{\mathcal Z}\) 不返回；没有用正包络减去另一个负包络。\(\beta-\nu\)、q 的硬帽来源、真实 dx、尺度与时间/history 全部交代。**结论：固定块原来源付款已有；一般自适应联合根预算仍未证明。到精确账与旧基线澄清处停止。**


# 附件：score_energy_history.md

# R131：score能量接口的限定历史核对

**有限搜索结论：在指定R117/118/121/122必要片段及R130已定位记录中，已找到并独审核验的是Π中心化漂移、连续正变差、精确删除跳、近时εX预算和存活子域α²dθ端点式；未定位到另一个已审的“阈值穿越总收费O(n)，因此∫Var(k_t)dt/t≤O(n)+删除项”的一般付款定理。** 不声称全历史不存在该命题。此次不重证旧工具、不研究新路线、不重跑数值，以下变测试公式只澄清待查归约的准确项，不能登记为新进展。

## 已审内容与准确价格

固定原(ω,V,j,y)与合法正尺度窗[τ,h]，Π_t=e_t^−1 1_{Z_t}w_tν，k_t=#{i:α_i<t}，m_t=E_{Π_t}k_t。原有限禁块跳间Z不变、e_h>0时，[R117独审第31–43行](/Users/zhengzhihao/Desktop/T/output/centered_cube_round117_20261014/audit_normalized.md:31) 已证
\[
\partial_{\log t}\Pi_t=(m_t-k_t)\Pi_t,\qquad
e'_t=-e_tm_t/t
\]
仅为a.e.导数。w_t连续，来源原子或稠密坐标折点不产生w的跳；**这不表示随t改变的k_t没有阈值穿越测度**。一般连续删除也不能套跳间恒定公式，见同审第85行。

连续正变差准确为
\[
V_j=\frac12\int_\tau^hE_{\Pi_t}|k_t-m_t|\frac{dt}{t}
\le\frac n4\log(h/\tau),\qquad
V_j\le\int_\tau^h m_t\frac{dt}{t}.
\]
第二式是−dlog e的连续部分，不是方差耗散预算。[R117独审第45–55行](/Users/zhengzhihao/Desktop/T/output/centered_cube_round117_20261014/audit_normalized.md:45) 区分正变差与全变差的1/2。

删除u的原加权质量r_u、删除前质量e_{u−}给跳正变差r_u/e_{u−}，并非r_u/e_u；[精确删除公式](/Users/zhengzhihao/Desktop/T/output/centered_cube_round117_20261014/audit_normalized.md:57) 已审。实际born/light条件下
\[
\sum_u r_u/e_{u-}\le\rho_j
\le\frac{c_j^{n/2}+\sqrt n\,c_j^{3n/2}}\ell,
\quad
\sum_j\rho_j\le
\frac{(2+\sqrt2)+((8+2\sqrt2)/7)\sqrt n}{\ell}.
\]
[R117删除费独审第129–152行](/Users/zhengzhihao/Desktop/T/output/centered_cube_round117_20261014/audit_normalized.md:129) 明确：这只合计归一化跳质量，不含每j初始质量1、连续V_j，更不是真实接收付款。若score均值跳只以0≤k≤n控制，其绝对变化至多n r_u/e_{u−}，不能把无n的JG跳预算直接抄给score能量。

真正已付的时间缩窗是近端：log(g/ℓ_u)≤u/n，连续正变差≤u/4，从而C_near≤uX、树前费2ΛuX，u≤119ε/256足以纳入εX。[R118近时独审](/Users/zhengzhihao/Desktop/T/output/centered_cube_round118_20261014/near_statement_audit.md:69) 第95–104行靠原1_{j(x)=j}保留唯一j，无Σ_j1费。反之，共同来源包络的 [JG20](/Users/zhengzhihao/Desktop/T/output/centered_cube_round117_20261014/joint_geometry.md:182) 仍须真实Σ_{V,j}∫dβ∫B_{j,V,y}dM_{j,V,y}；不同M、β可重复使用，不能凭输出j不交删掉来源求和。

## “均值导数=穿越−方差+删除”的准确待查形式

不能直接把k_t当固定测试函数，写成dm=−Var(k_t)dlog t。固定支持上的正确变测试记账需要正阈值穿越量C_j：每个α_i∈(τ,h]对该来源的k增加1，并用当时的Π_{α_i}加权；连续来源可产生非原子的穿越测度。每个来源最多n次，并不代表这些**随时漂移的概率**加权穿越合计≤n。

为消除严格α<t在单点的约定，取k的右极限版本\(\bar k_t=\#\{i:\alpha_i\le t\}\)，它同原k在dt/t下相同。采用Z右连续；删除与阈值同点时，先以穿越前score记删除，再用删除后Π记阈值穿越，起点τ已初始化，终点采用相应右态。令Δ_u^del m为该删除阶段的均值变化，删掉集合的旧score均值记m_removed、保留集合旧score均值记m_keep，则
\[
\Delta_u^{del}m=\frac{r_u}{e_{u-}}(m_{keep}-m_{removed}),
\qquad |\Delta_u^{del}m|\le n r_u/e_{u-}.
\]
因此所需score平衡应保留
\[
\mathcal E_j:=\int_\tau^h\operatorname{Var}_{\Pi_t}(k_t)\frac{dt}{t}
=C_j+\sum_u\Delta_u^{del}m-(\bar m_h-\bar m_\tau),
\quad
\mathcal E_j\le C_j+n+n\sum_u r_u/e_{u-}.
\]
这是JG漂移对**变测试**需补的记账形式，本次未定位其独立旧审记录，也不以写出该式认证新付款。若要得O(n)+删除，尚需实际C_j≤Cn或等效联合收费；Σ_jρ_j只控制最后的删除项，未支付C_j。删除低score可使均值上升，不能把所有删除项都写成有利耗散。

Cauchy–Schwarz只给条件推论
\[
V_j\le\tfrac12\sqrt{\log(h/\tau)\,\mathcal E_j}.
\]
故一个**另经认证**的O(n)能量帽可把该固定行BV估计降为O(√n)；它本身不是原d𝒯、坏核/实际x包络及Σj的根阶来源价。已有 [JG22–23压力与独审范围](/Users/zhengzhihao/Desktop/T/output/centered_cube_round117_20261014/audit_normalized.md:162) 保留了固定Z、同坐标阈值族的共同支配质量≥nlog2/4；[原公式](/Users/zhengzhihao/Desktop/T/output/centered_cube_round117_20261014/joint_geometry.md:212) 已用于限制仅靠权重单调性降低共同M质量。这是旧核级压力，非FIRST/FULL输入反例，本轮不另造或重算。因而不能从已有JG公式宣称普遍的无条件能量帽已审成立。

## 终端α²、删除与负项后的真实未付量

只留固定终端存活D,O时，原两Π分母保留为α_t²，而非1：α_t=∫_{D∪O}w_tν/e_t、θ_t=∫_Dw_tν/∫_{D∪O}w_tν。已审
\[
S=\int\alpha_t^2d\theta_t
=[\alpha^2\theta]_\tau^h-\int_{(\tau,h]}\theta_t,d(\alpha_t^2)
\le\theta_h-\theta_\tau+2b_\tau/e_h.
\]
[R121独审第13–54行](/Users/zhengzhihao/Desktop/T/output/centered_cube_round121_20261014/signed_statement_audit.md:13) 及 [全文审第45–51行](/Users/zhengzhihao/Desktop/T/output/centered_cube_round121_20261014/signed_proof_audit.md:45) 明确保留初始α_τ²亏损、终端α_h²及Z移除造成的BV跳；端点交叉项和其余源b_τ/e_h仍未给来源价。若改在D∪O内条件归一化来研究score能量，也必须恢复这份α²，不能把条件概率误作原Π。

全当前补集signed差才对应dΠ_t(D)；D×S_g还缺Z_t\Z_g的未来删源，见 [R118独审A4/A5](/Users/zhengzhihao/Desktop/T/output/centered_cube_round118_20261014/causal_audit.md:97)。目前Ψ=1_{𝒵ᶜ}又删去已用的非正后缀pair：全域signed望远镜不能直接上界此补域。R122 [一次负量消费审查](/Users/zhengzhihao/Desktop/T/output/centered_cube_round122_20261014/suffix_sign_statement_audit_private.md:116) 已规定，对通过域消费N_𝒵后只留其补域负项，FA足门正量不领第二份费用。

按 [R130已定位母式](/Users/zhengzhihao/Desktop/T/output/centered_cube_round130_20261014/signed_transport_history.md:1)，当前仍需在同一真实外交通中支付2Λ(P_rem−N_{𝒵ᶜ}−N_del)：N_𝒵ᶜ为整个原Ψ存活负部，不附正FA/RC削减门；N_del为原未来删除资格的连续负pair，不能换成Π跳正变差；二者各一次可用，已消费N_𝒵不可返回。真实dx、β−ν、硬z、q、唯一j、history和两份e分母仍在。目标缺口是该同源/实际门联合空间价格，或有明确C_j/删除/端点/选择成本的条件预算；不是“score形式上有一个−Var”便自动闭合。

搜索范围仅为上述四轮的导数/BV/causal/signed/suffix必要作者与独审片段、R130历史定位；非本任务的softness Fisher、Bernoulli核系数方差不被当作Π_t来源score方差。没有扩大全历史，没有声称取得新的n→√n定理。


# 附件：joint_denominator_numeric_protocol.md

# R131 BD11/14/15：12例真实核双精度协议

**开跑前冻结菜单。** 最终依据 `bad_denominator.md` SHA `99eb6d2c6dd2630639c7ac856ed0552c3c950eec6291e9e3ab86c73d17817a49`及其最终独审。本轮只复核固定参数真实核实现，不认证FIRST/FULL、整维来源价格或root付款。不加AF全线、不新增维度或来源工程。

## 准确对象与最终常数

n=6561，γ=1+1/n，m0=min(L,R)，J=[z−R/2,z+R/2]，I=J∩[y−L/2,y+L/2]。原φ=h1*w由E3两分支计算；C(d)=∫[-1/2,1/2]max(h1,φ)(u−d)du，独立切硬面quad。ω(ξ)=min(1,bC(|y−ξ|/b)/(cjg))。

H1=L,H2=min(b,γL),H3=b；k1/2=q_(s,Hm)，k3=q_(1,b)。共同分母始终q_(1,b)(u−z′)，不能改回k_m坏端下确界，也不能漏b^−1。

θ=s/32768，κ=63/64；核验0<θ≤min(2^−15,s/896)，保留严格实际s>1−2^(−1/n)。近下门s近=1−2^(−1/n)+2^−24，s极近加2^−40；m3的分量软度固定1，但anchor及θ使用实际s。

令D(u)=[k_m(u−v)ω(z′)/(q_(1,b)(u−z′)ω(v))]^θ。独立计算

- hard B_h=(RL)^−1∫I D，比较BD11右侧P0 γ^θ exp(7θ)；
- soft B_φ=(RL)^−1∫J φ((u−y)/L)D，比较BD14右侧P0κ；
- full B=R^−1∫J q_(s,L)(u−y)D，独立于前两积分，比较BD15右侧P0[(1−s)γ^θexp(7θ)+sκ]。

P0=m0/(RL)=1/max(L,R)。另记录full−[(1−s)hard+s soft]；所有值/比未经理论min、容差或预期界裁剪。I空仅hard=0，soft/full仍在完整J积分。

## 三阶段冻结菜单：4/4/4，共12例

全部y=0、g=1。A组j=0,cj=1,L=R=b=1,a=1/2。B组j=1,cj=1/γ，L=(cj+cj/γ)/2,R=1/L,b=R,a=b/2；精确有理数据满足真实比例带及尺度窗。每例只测表中指定m，保留整核区别。

|ID|阶段/组|z|v|z′|m|实际s|
|---|---|---|---|---|---|---|
|1|初探/A|2|2|−1|1|s近|
|2|初探/A|0|0|0|1|s近|
|3|初探/A|63/64|2|0|2|s近|
|4|初探/A|0|2|2|3|1|
|5|压力/A|63/64|1/2|2|1|1|
|6|压力/A|0|1/4096|1/2|2|1|
|7|压力/A|0|4|4|3|s近|
|8|压力/A|1/2|−3/4|3/4|1|s极近|
|9|扩大/B|0|1/4096|0|1|s近|
|10|扩大/B|(R+L)/2−1/64|2b|−b|2|1|
|11|扩大/B|R/2|b/2|2b|3|s极近|
|12|扩大/B|0|4b|−4b|2|s近|

菜单包括I空/短/满/半、饱和/低ω、远good/远bad、strictsoft近下门及s1；B组H1/H2/H3为不同实际尺度。参数若不合法保存UNDETERMINED，不改门、不换例。

## 标量与整维的边界

原Q*=(K1+K2+K3)/3是三个整维乘积的和。分子3^−θ与共同分母3^θ只抵消一次；准确上界为Σ_m∏_i B_(m,i)，不能变成∏_iΣ_m B_(m,i)，更不能把一维Q平均的矩直接取n次方。

同坐标类型重复n次时，指定m的B^n可用log比较BD16的e^θexp(−ns/128)P0^n；这是该固定m乘积的观察。12例并非同一参数下同时测三个m，故不能把不同例拼成整维三项和。最终3项结论来自解析证明，不由此有限标量认证。原共同Q矩一般不因坐标核可积而直接因子化；拆项包络超界也不能反证原共同Q目标。

## 执行与误差预算

既有bundled Python、vendor mpmath1.3.0，不安装；30/50digits各一次，共24观察。沿用R130可靠φ/C及分片实现但只在R131新文件写代码，不修改R130。Gauss–Legendre maxdegree=6，每例每精度总integrand请求≤20000；按anchor、分子和共同分母的中心/φ分支/硬面切分。预算超限或异常保存输入及已算内容，不重启、不临时升阶/增菜单。

误差保存每片quad程序估计、两精度差、原始比及线性分解残差；它们均不是区间误差或定理证书。略超1原样报告，不能按容差叫通过/反例。输出 `joint_denominator_results.json`完整保存全部24观察、冻结源码/协议SHA、实际环境、请求数及异常。唯一进程运行，超时仅poll，不改运行中源码。
