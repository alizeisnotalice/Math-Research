"""Exact sector decomposition and numeric shell costs for variable exceptional axes."""
from fractions import Fraction as F
from itertools import combinations,product
from math import comb
from flint import arb,ctx
import sys,json,platform
ctx.prec=256
def overlap(x,r,t):
    return max(F(0),min(r,x+t)-max(-r,x-t))/(2*t)
def cell(x,k):
    n=len(x)
    t=F(2,3); r=F(17,16); outer=F(9,4)
    A=[overlap(v,r,t) for v in x]; B=[overlap(v,outer,t)-a for v,a in zip(x,A)]
    # Independent integration over exact translation cells.
    parts=[]
    for v in x:
        split=sorted({-t,t}|{a-v for a in (-outer,-r,r,outer) if -t<a-v<t})
        parts.append([((u+w)/2+v,(w-u)/(2*t)) for u,w in zip(split,split[1:])])
    actual=F(0)
    for point in product(*parts):
        if max(abs(v) for v,m in point)<=outer and sum(abs(v)>r for v,m in point)<=k:
            mass=F(1)
            for v,m in point:mass*=m
            actual+=mass
    check=F(0)
    for j in range(k+1):
        for ix in combinations(range(n),j):
            mass=F(1)
            for l in range(n):mass*=B[l] if l in ix else A[l]
            check+=mass
    assert actual==check and 0<=actual<=1
    return str(actual)
def upper(n,k):
    N=arb(n); ln=N.log(); p=1+1/ln; lam=arb(2)**(1/N); h=1+1/(32*N)
    cp=(p-1)/(p+1); b=cp/8
    # Use the exact convolution power on good axes; Jensen on strips.
    q=arb(1); total=arb(0); J=0
    while q>=ln/(4*N):
        T=h*lam*q; R=1+(b+lam/(32*N))*q
        if T<R:good=(R-cp*T)**(1/p)
        else:good=(R/T)*(T-cp*R)**(1/p)
        total+=(h*lam)**n*sum(comb(n,j)*(5*q)**(arb(j)/p)*good**(n-j) for j in range(k+1))
        q/=lam
        J+=1
    return {'n':n,'k':k,'bins':J,'sum_per_n':(total/N).str(16),
            'sum_per_n_log_power':(total/(N*ln**k)).str(16)}
xs=[[F(7,4),F(5,8),F(-11,8)],[F(5,2),F(-5,2),F(1,4),F(0)],
    [F(i,3) for i in (1,-2,3,-4,5,-6)]]
print(json.dumps({'python':sys.executable,'version':platform.python_version(),'bits':256,
 'exact_cells':[[cell(x,k) for k in range(len(x)+1)] for x in xs],
 'shell_upper':[upper(n,k) for n in (16,64,256) for k in (0,1,2,3)]},indent=2))
