"""Full first-hit controls for transported owner centers, with exact coordinate checks."""
from fractions import Fraction as F
from math import isqrt
from flint import arb,ctx,__version__ as flint_version
import platform,sys,json
ctx.prec=256

def run(n,case):
    a=32*n
    sizes=(F(3),F(2),F(3,2),F(1),F(1,16))
    radii=tuple(s/a for s in sizes)
    eta=F(1,a*a)
    coords=[]
    for l in range(n):
        sign=(-1)**l
        choice={'nested':F(1,2),'noncontained':F(5,4),'reflected':F(9,4),'diffuse':F(11,10)+F(3*l,2*n)}[case]
        coords.append((choice*sign,-2+eta,F(0),-sign*F(63,64),sign*F(3,50)))
    def inside(i,j):
        return all(abs(row[i]-row[j])+sizes[i]<=sizes[j] for row in coords)
    assert all(any(abs(row[i]-row[j])>radii[i]+radii[j] for row in coords)
               for i in range(5) for j in range(i))
    assert all(abs(row[i])<sizes[i] for row in coords for i in range(5))
    u=sizes[-1]*(1+F(1,a))
    for line in coords:
        big,neg,mid,small,x=line
        for i,shift in enumerate((0,-1,0)):
            assert abs(x+shift*u-line[i])+radii[-1]<sizes[i]
        assert abs(x-small)-radii[-1]>1+F(6,n)
        assert abs(x-small)-u+radii[-1]<1
    def test(sgn):
        # The entire receiver owner and the small source owner; site w=0.
        return all(abs(row[-1]+sgn*row[-2]-row[0])+radii[-1]+radii[-2]<=sizes[0] for row in coords)
    def fail_all(sgn):
        return any(abs(row[-1]+sgn*row[-2]-row[0])-radii[-1]-radii[-2]>sizes[0] for row in coords)
    if case=='nested': assert inside(3,0)
    else: assert not inside(3,0)
    if case in ('reflected','diffuse'):assert fail_all(1) and test(-1)
    else:assert test(1)
    K=4096*isqrt(n)*a**n
    ell=arb(2).log()/K
    vt=arb(1)/(8*a)**n
    high=vt*ell.expm1()/2
    assert 0<high<vt/4
    log_first=n*arb(32*n).log()+(K-5)*n*arb(4).log()+(-(-ell).expm1()).log()
    assert log_first>(4*arb(6)**n+1).log()
    return dict(n=n,case=case,contained=inside(3,0),identity_hits=test(1),negative_identity_hits=test(-1),
                full_owner_identity_misses=fail_all(1),common_site=0,R_high=str(high),V_T=str(vt),
                log_D_over_K_bounds=[str(log_first/K),str((log_first+arb(3).log())/K)],eta_quarter_excess=0)
print(json.dumps({'python':sys.executable,'version':platform.python_version(),'python_flint':flint_version,'bits':256,
                  'cases':[run(n,c) for n in (256,1024,4096) for c in ('nested','noncontained','reflected','diffuse')]},indent=2))
