#!/usr/bin/env python3
"""Pure-root p-near-one tensor envelope audit, no history assertion."""
from fractions import Fraction as F
from decimal import Decimal as D,localcontext,ROUND_FLOOR
from pathlib import Path
import hashlib,json,math,platform,socket,subprocess,sys
sys.set_int_max_str_digits(1000000)
BASE=Path(__file__).resolve().parent
DIMS=(16,64,256,1024)
SPOTS=[('A_greater_T',F(2),F(1),F(3,2)),('A_equals_T',F(1),F(1),F(2)),
       ('T_greater_A',F(1),F(4),F(3,2)),('T_much_greater_A',F(1),F(16),F(5,4)),
       ('small_A',F(1,4),F(1),F(2))]

def exact_spots():
    rows=[]
    for name,A,T,p in SPOTS:
        m=min(A,T);height=m/T
        # These chosen height^p values are exact rational perfect powers.
        if p.denominator==1:hp=height**p.numerator
        else:
            numroot=round(height.numerator**(1/p.denominator));denroot=round(height.denominator**(1/p.denominator))
            assert numroot**p.denominator==height.numerator and denroot**p.denominator==height.denominator
            hp=F(numroot,denroot)**p.numerator
        plateau=2*abs(A-T)*hp;ramps=4*m*hp/(p+1);I=plateau+ramps
        eta=(p-1)/(p+1)
        formula=2*(A-eta*T) if A>=T else 2*hp*(T-eta*A)
        assert I==formula
        rows.append({'name':name,'A':str(A),'T':str(T),'p':str(p),'height':str(height),
                     'plateau_integral_exact':str(plateau),'ramp_integral_exact':str(ramps),'total_integral_exact':str(I),
                     'branch_T_greater_A':bool(T>A)})
    return rows

def dec_formula(A,T,p):
    m=min(A,T);return 2*(m/T)**p*(abs(A-T)+2*m/(p+1))
def decimal_checks():
    with localcontext() as cc:
        cc.prec=100;rows=[]
        for n in DIMS:
            dn=D(n);lam=(D(2).ln()/dn).exp();a=32*n;h0=1+D(1)/a;t=h0*lam
            p=1+1/dn.ln();eta=(p-1)/(p+1);b=eta/8;c=eta*t-b-lam/a
            lower=dn.ln()/(2*lam*lam*h0*dn);J=int((-lower.ln()/(D(2).ln()/dn)).to_integral_value(rounding=ROUND_FLOOR))
            pref=t**n;tot=[D(0)]*4;s=D(1)
            for j in range(1,J+1):
                s/=lam;T=t*s;A=1+(b+lam/a)*s;Abad=1+(16*b+lam/a)*s
                assert A>=T
                tot[0]+=pref*(A-eta*T)**(dn/p)
                tot[1]+=pref*A**n
                tot[2]+=pref*(1+lam*s/a)**n
                tot[3]+=pref*(Abad-eta*T)**(dn/p)
            rows.append({'n':n,'J':J,'p':str(p),'c':str(c),'sums':[str(x) for x in tot]})
        quad=[]
        quad_cases=[(name,D(aa.numerator)/aa.denominator,D(tt.numerator)/tt.denominator,D(pp.numerator)/pp.denominator) for name,aa,tt,pp in SPOTS]
        for nn in (16,1024):
            lam=(D(2).ln()/nn).exp();a=32*nn;h0=1+D(1)/a;p=1+1/D(nn).ln();eta=(p-1)/(p+1);b=eta/8
            quad_cases.append(('actual_first_shell_n'+str(nn),1+(b+lam/a)/lam,h0,p))
        for name,A,T,p in quad_cases:
            true=dec_formula(A,T,p);m=min(A,T);hp=(m/T)**p;results=[]
            for N in (256,512,1024):
                accum=D(1)
                for j in range(1,N):accum+=(4 if j%2 else 2)*(D(j)/N)**p
                q=accum/(3*N);estimate=2*abs(A-T)*hp+4*m*hp*q
                results.append({'N':N,'quadrature_integral':str(estimate),'error_vs_closed_formula':str(estimate-true)})
            assert abs(D(results[-1]['error_vs_closed_formula']))<D('1e-6')
            quad.append({'name':name,'formula':str(true),'composite_Simpson_ramp':results})
        return {'host':socket.gethostname(),'python':platform.python_version(),'rows':rows,'quadrature':quad}

if '--remote' in sys.argv:
    spots=exact_spots()
    print(json.dumps({'exact_spots':spots,'decimal100':decimal_checks()}));sys.exit(0)

from flint import arb,ctx

def st(x):return x.str(36)
def floorarb(x):
    q=x.floor().unique_fmpz();assert q is not None;return int(q)
def e1_upper_small(x):
    assert 0<x<1
    # E1(x)=-gamma-logx +x-x²/4+x³/18-...; odd truncation bounds above.
    partial=-arb.const_euler()-x.log();term=arb(1)
    low=None
    for k in range(1,22):
        term*=x/k
        partial+=(1 if k%2 else -1)*term/k
        if k==20:low=partial
    assert partial>low
    return partial,low

def params(n):
    N=arb(n);lam=(arb(2).log()/n).exp();a=32*n;h0=1+arb(1)/a;t=h0*lam
    p=1+1/N.log();eta=(p-1)/(p+1);b=eta/8;c=eta*t-b-lam/a
    L=N.log()/(2*lam*lam*h0*N);J=floorarb(-L.log()/(arb(2).log()/n))
    return N,lam,a,h0,t,p,eta,b,c,L,J

def shell_sums(n,bits):
    ctx.prec=bits;N,lam,a,h0,t,p,eta,b,c,L,J=params(n);assert c>0
    cbad=eta*t-16*b-lam/a;assert cbad<0
    pref=t**n;total=[arb(0)]*4;s=arb(1);last=None
    for j in range(1,J+1):
        s/=lam;T=t*s;A=1+(b+lam/a)*s;Abad=1+(16*b+lam/a)*s
        assert A>T
        total[0]+=pref*((A-eta*T).log()*(n/p)).exp()
        total[1]+=pref*A**n
        total[2]+=pref*(1+lam*s/a)**n
        total[3]+=pref*((Abad-eta*T).log()*(n/p)).exp()
        if j==J:last=s
    assert last>=L and last/lam<L
    x=n*c*L/(p*lam);eu,el=e1_upper_small(x)
    upper_per_n=pref*eu/arb(2).log();assert total[0]/n<upper_per_n
    return {'n':n,'J':J,'p':st(p),'eta':st(eta),'b':st(b),'decay_c':st(c),'bad_b_equals_16b_decay_c':st(cbad),
            'lowest_shell_endpoint':st(last),'normalized_sums':[st(x) for x in total],
            'normalized_sums_divided_by_n':[st(x/n) for x in total],
            'sum_modes':['Lp_correct_b','L1_same_positive_b_kernel','L1_b_zero_baseline','Lp_b_times16_failure'],
            'analytic_Lp_sum_over_n_upper':st(upper_per_n),'integral_cutoff_x':st(x),
            'first_shell_A_minus_T_exact_identity':'b/lambda>0; hence all allowed complete shells useA>=T',
            '_values':total}

def huge_bound(n):
    ctx.prec=384;N,lam,a,h0,t,p,eta,b,c,L,J=params(n);assert c>0
    x=n*c*L/(p*lam);upper,lower=e1_upper_small(x);bound=t**n*upper/arb(2).log()
    return {'n':str(n),'J':J,'p':st(p),'decay_c':st(c),'E1_cutoff':st(x),
            'E1_upper':st(upper),'E1_lower':st(lower),'Lp_sum_divided_by_n_upper':st(bound),
            'baseline_L1_sum_divided_by_n_lower':st(t**n*J/n),
            'method':'Geometric shell sum<=n/log2*E1(ncL/(p lambda)); E1 bounded by exact alternating series through odd21. No enumeration ofhugeJ.'}

def uniform_bound():
    ctx.prec=384;ell=arb(16).log();lam=(arb(2).log()/16).exp();p=1+1/ell;h0=1+arb(1)/512
    margin=lam*(2*ell+1)/512
    assert margin<arb(1)/8 and 1-2*ell<0
    xlower=(arb(3)/4)*ell/(2*ell+1)/(2*p*lam**3*h0)
    eu,el=e1_upper_small(xlower);bound=2*(arb(1)/32).exp()*eu/arb(2).log();assert bound<6
    return {'minimum_n':16,'lambda_over_a_divided_by_eta_endpoint':st(margin),
            'E1_cutoff_uniform_lower':st(xlower),'sum_over_n_uniform_upper':st(bound),'simple_constant':6,
            'algebra':'lambda_n and(2logn+1)/n both decrease forn>=16,so lambda/a<=eta/8 follows from the endpoint check. Since t>=1,c=eta*t-eta/8-lambda/a>=3eta/4. The ratio logn/(2logn+1)increases whilep,lambda,h0 decrease,so x=ncL/(p lambda)>=the recorded endpoint lower bound. Also t^n<=2exp(1/32). E1 decreases,therefore the displayed bound applies to the entire scalar shell model forn>=16.'}

def main():
    spots=exact_spots();rows=[];raw=[]
    for n in DIMS:
        low=shell_sums(n,256);high=shell_sums(n,384)
        assert low['J']==high['J'] and all(a.overlaps(b) for a,b in zip(low['_values'],high['_values']))
        raw.append([float(v) for v in high.pop('_values')]);rows.append(high)
    ctx.prec=384;x=arb(7)/32;up,lo=e1_upper_small(x)
    limit=2*(arb(1)/32).exp()*up/arb(2).log()
    cmd=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=5','macbook-math','/Users/zhengzhihao/.venv/bin/python -B - --remote']
    try:
        run=subprocess.run(cmd,input=Path(__file__).read_text(),text=True,capture_output=True,timeout=45)
        remote={'command':cmd,'exit_code':run.returncode,'stderr':run.stderr}
        if run.returncode==0:
            check=json.loads(run.stdout);remote['result']=check;assert check['exact_spots']==spots
            assert len(rows)==len(check['decimal100']['rows'])
            for local,other,values in zip(rows,check['decimal100']['rows'],raw):
                assert (local['n'],local['J'])==(other['n'],other['J'])
                for aa,bb in zip(values,other['sums']):assert abs(aa-float(bb))<=max(1e-12,abs(aa)*1e-12)
            remote['all_checks_passed']=True
    except subprocess.TimeoutExpired:remote={'command':cmd,'timeout_seconds':45}
    result={'host':socket.gethostname(),'python':sys.executable,'python_version':platform.python_version(),
            'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'exact_scalar_spots':spots,'actual_parameter_shell_sums':rows,
            'huge_analytic_bounds':[huge_bound(n) for n in (1<<20,1<<40,1<<64)],
            'limiting_integral_envelope_sum_over_n_upper':st(limit),'uniform_scalar_bound_certificate':uniform_bound(),'remote':remote,
            'definitions':['R=1,lambda=2^(1/n),a=32n,h0=1+1/a,p=1+1/logn,eta=(p-1)/(p+1),b=eta/8. Source shells=s=lambda^(-j),j1..J using the same legitimate lower endpointL=logn/(2lambda²h0n).',
                           'A=Rprime=1+b*s+lambda*s/a,T=h0lambda*s,t=T/s. f(x)=(1_[-A,A]*uniform[-T,T])(x). G=t^n tensor_n f. Its normalized Lp norm is t^n[I_p/(2R)]^(n/p).',
                           'Letm=min(A,T). ExactI_p=integral f^p=2(m/T)^p[abs(A-T)+2m/(p+1)]. Equivalently2(A-etaT)forA>=T,or2(A/T)^p(T-etaA)forT>A. Both branches are verified with real interval spots.',
                           'All allowed actual-parameter shells haveA>T: atj1,A-T=b/lambda>0, and the gap increases as_s decreases. ThusI_p/2=1-cs,c=eta*t-b-lambda/a>0.',
                           'The same positive-b kernel hasL1 mass t^n A^n and may grow faster than logn. The b0L1 baseline is separately recorded and is at leastt^n J,so its sum divided byn grows withJ/n.',
                           'Forc>0,(1-cs)^(n/p)<=exp(-ncs/p). An increasing-inj shell sum is bounded byintegral_j1^(J+1),hence sum/n<=t^n/log2*E1(ncL/(p lambda)). Sincex tends7/32,this gives a finite constant limit envelope.'],
            'scope':['Actual-parameter finite sums are computed over every allowed shell for dimensions16,64,256,1024 with local Arb256/384 and independent remote Decimal100.',
                     'Exact rational plateau/ramp examples includeT>A. Remote composite Simpson quadrature at256/512/1024 panels checks the actual ramp power against the exact scalar formula; quadrature is a numerical spot check, not the source of rigorous interval bounds.',
                     'The deliberately enlargedb=16b reverses decayc and is a negative control. No claim is made that an arbitrary positiveb is allowed.',
                     'Huge dimensions use an explicit analytic geometric-shell bound and interval alternating-series evaluation ofE1, not hidden enumeration. This validates the stated pure-root tensor model; no greedy history or geometric reduction beyond its assumptions is asserted.',
                     'Onlypower.py/json are written. Frozen envelope.py/json are untouched. No Git,remote files,GPU use or background jobs.']}
    (BASE/'power.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'remote_exit':remote.get('exit_code'),'crosscheck':remote.get('all_checks_passed'),
                      'sums_per_n':[{k:r[k] for k in ('n','J','normalized_sums_divided_by_n','analytic_Lp_sum_over_n_upper')} for r in rows],
                      'limit_upper':st(limit)},indent=2))
if __name__=='__main__':main()
