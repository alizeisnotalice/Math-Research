#!/usr/bin/env python3
"""Exact eroded-owner envelope and bounded legitimate-shell sums."""
from fractions import Fraction as F
from pathlib import Path
from decimal import Decimal as D,localcontext,ROUND_FLOOR
import hashlib,json,math,platform,socket,subprocess,sys
sys.set_int_max_str_digits(1000000)
BASE=Path(__file__).resolve().parent
DIMS=(4,16,64,256,1024)

def overlap(B,T,w):return max(F(0),min(B,w+T)-max(-B,w-T))
def envelope(B,T,v,x):
    closest=max(F(0),abs(x)-v)
    return overlap(B,T,closest)
def integrate_piecewise(B,T,v,s):
    end=B+T+v;plateau=abs(B-T)+v
    knots=sorted({F(0),plateau,end})
    result=2*sum(((b-a)*(envelope(B,T,v,a)+envelope(B,T,v,b))/2 for a,b in zip(knots,knots[1:])),F(0))/(2*s)
    return result

def exact_geometry(closed=False):
    rows=[]
    for n in (4,16,64,256):
        lam=1+F(1,n);a=32*n;h0=1+F(1,a);R=F(1)
        for s in (1/lam,F(1,2),F(1,16),F(1,n),F(1,4*n),F(1)):
            B=R-s+lam*s/a;T=h0*lam*s
            for mode,v in [('full_lambda_s',lam*s),('half_s',s/2),('fixed_offset',F(1,1024))]:
                if v>lam*s:continue
                I=2*B*T/s+2*v*min(B,T)/s
                integral=I if closed else integrate_piecewise(B,T,v,s)
                assert integral==I
                checks=[]
                for x in sorted({F(0),v,abs(B-T)+v,B+T+v}|{(B+T+v)*F(j,8) for j in range(9)}):
                    points=[x-v,x+v]
                    if abs(x)<=v:points.append(F(0))
                    actual=max(overlap(B,T,w) for w in points)
                    assert actual==envelope(B,T,v,x)
                    checks.append({'x':str(x),'sup_intersection_length':str(actual)})
                thicken=[]
                for name,b in [('fixed_R_over32',F(1,32)),('inverse_n_R',F(1,n)),('quarter_small_radius',s/4)]:
                    Ib=2*(B+b)*T/s+2*v*min(B+b,T)/s
                    independent=Ib if closed else integrate_piecewise(B+b,T,v,s)
                    assert independent==Ib and Ib>I
                    excess=2*b*T/s+2*v*(min(B+b,T)-min(B,T))/s;assert excess==Ib-I
                    thicken.append({'kind':name,'b':str(b),'B_plus_b':str(B+b),'integral_exact':str(Ib),
                                    'one_dimensional_ratio_exact':str(Ib/I),'n_dimensional_ratio_exact':str((Ib/I)**n),
                                    'excess_exact':str(excess),
                                    'actual_noncontained_small_center':str(R-s+b),
                                    'actual_small_cube_protrusion_past_R':str(b)})
                rows.append({'n':n,'lambda_rational_upper':str(lam),'a':a,'R':'1','s':str(s),'B':str(B),'T':str(T),
                             'mode':mode,'v':str(v),'B_less_than_T':bool(B<T),'integral_exact':str(integral),
                             'normalized_by_2R_exact':str(integral/(2*R)),
                             'normalized_n_dimensional_integral_exact':str((integral/(2*R))**n),
                             'point_checks':checks,'noncontained_thickenings':thicken})
    return rows

def decimal_sums():
    rows=[]
    with localcontext() as cc:
        cc.prec=100
        for n in DIMS:
            dn=D(n);lam=(D(2).ln()/dn).exp();a=32*n;h0=1+D(1)/a;t=h0*lam
            lower=dn.ln()/(2*lam*lam*h0*dn)
            J=int(((-lower.ln())/(D(2).ln()/dn)).to_integral_value(rounding=ROUND_FLOOR))
            terminal=(-D(J)*D(2).ln()/dn).exp();fixed=lam*terminal
            totals=[D(0)]*3;edge=0;s=D(1)
            for j in range(1,J+1):
                s/=lam;B=1-s+lam*s/a;T=t*s
                if B<T:edge+=1
                for k,v in enumerate((lam*s,s/2,fixed)):
                    f=(B*T+v*min(B,T))/s
                    totals[k]+=f**n
            rows.append({'n':n,'J':J,'edge_bins_B_less_T':edge,'terminal_s':str(terminal),
                         'sums':[str(x) for x in totals]})
    return {'host':socket.gethostname(),'python':platform.python_version(),'rows':rows}

if '--remote' in sys.argv:
    exact=exact_geometry(True)
    print(json.dumps({'host':socket.gethostname(),'python':platform.python_version(),
                      'exact_digest':hashlib.sha256(json.dumps(exact,sort_keys=True,separators=(',',':')).encode()).hexdigest(),
                      'decimal100':decimal_sums(),
                      'method':'closed-form convolution area plus dilation plateau; independent Decimal shell sums'}));sys.exit(0)

from flint import arb,ctx

def st(x):return x.str(36)
def floor_arb(x):
    a=x.floor().unique_fmpz();assert a is not None;return int(a)
def sum_shells(n,bits):
    ctx.prec=bits;N=arb(n);lam=(arb(2).log()/n).exp();a=32*n;h0=1+arb(1)/a;t=h0*lam
    lower=N.log()/(2*lam*lam*h0*N);J=floor_arb(-lower.log()/(arb(2).log()/n))
    terminal=(-J*arb(2).log()/n).exp();fixed=lam*terminal
    assert terminal>=lower and terminal/lam<lower
    totals=[arb(0)]*3;edge=0;s=arb(1);head=[]
    for j in range(1,J+1):
        s/=lam;B=1-s+lam*s/a;T=t*s
        assert B<T or B>T
        if B<T:edge+=1
        for k,v in enumerate((lam*s,s/2,fixed)):
            f=(B*T+v*min(B,T))/s;totals[k]+=f**n
        if j in (1,J):head.append({'j':j,'s':st(s),'B':st(B),'T':st(T)})
    return {'n':n,'J':J,'lower_allowed_shell_ratio':st(lower),'terminal_s':st(terminal),
            'edge_bins_B_less_T':edge,'broad_bins_B_ge_T':J-edge,
            'mode_names':['v=lambda*s','v=s/2','v=lambda*s_terminal_fixed_across_shells'],
            'shell_sum_normalized_by_large_volume':[st(x) for x in totals],
            'first_last_shells':head,'_values':totals,'_terminal':terminal}

def asymptotic_counts(n):
    ctx.prec=384;N=arb(n);lam=(arb(2).log()/n).exp();a=32*n;h0=1+arb(1)/a;t=h0*lam;d=1-lam/a;q=lam-d
    lower=N.log()/(2*lam*lam*h0*N);J=floor_arb(-lower.log()/(arb(2).log()/n))
    split=1/(d+t);edge=min(J,-floor_arb(-(d+t).log()/(arb(2).log()/n))-1)
    minimum_broad=t**n;maximum=(t*(1+q*split))**n
    low=(J-edge)*minimum_broad;high=J*maximum
    return {'n':str(n),'J':J,'edge_bins':edge,'broad_bins':J-edge,
            'small_scale_per_bin_limit':st(minimum_broad),
            'maximum_single_bin_normalized_integral':st(maximum),
            'all_shell_sum_lower_bound_from_broad_bins':st(low),'all_shell_sum_upper_bound':st(high),
            'warning':'The direct integral sum is not uniformly bounded overn. Its broad-bin lower bound alone grows proportionally to the allowed shell count.'}

def main():
    exact=exact_geometry();digest=hashlib.sha256(json.dumps(exact,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    sums=[];internal=[]
    for n in DIMS:
        lo=sum_shells(n,256);hi=sum_shells(n,384)
        assert lo['J']==hi['J'] and lo['edge_bins_B_less_T']==hi['edge_bins_B_less_T']
        assert all(a.overlaps(b) for a,b in zip(lo['_values'],hi['_values']))
        internal.append([float(x) for x in hi['_values']]);del hi['_values'];del hi['_terminal'];sums.append(hi)
    cmd=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=5','macbook-math','/Users/zhengzhihao/.venv/bin/python -B - --remote']
    try:
        run=subprocess.run(cmd,input=Path(__file__).read_text(),text=True,capture_output=True,timeout=45)
        remote={'command':cmd,'exit_code':run.returncode,'stderr':run.stderr}
        if run.returncode==0:
            check=json.loads(run.stdout);remote['result']=check;assert check['exact_digest']==digest
            assert len(check['decimal100']['rows'])==len(sums)
            for a,b,values in zip(sums,check['decimal100']['rows'],internal):
                assert (a['n'],a['J'],a['edge_bins_B_less_T'])==(b['n'],b['J'],b['edge_bins_B_less_T'])
                for x,y in zip(values,b['sums']):assert abs(x-float(y))<=max(1e-12,abs(x)*1e-12)
            remote['all_exact_and_decimal_checks_passed']=True
    except subprocess.TimeoutExpired:remote={'command':cmd,'timeout_seconds':45}
    result={'host':socket.gethostname(),'python':sys.executable,'python_version':platform.python_version(),
            'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'exact_digest':digest,
            'exact_geometry':exact,'allowed_shell_sums':sums,
            'large_dimension_bounds':[asymptotic_counts(n) for n in (1<<20,1<<40)],'remote':remote,
            'definitions':['Fixed larger cube radiusR; source shell[s,lambda*s),lambda=2^(1/n),a=32n,h0=1+1/a. Owner erosion box radiusB=R-s+lambda*s/a. Proxy radiusT=h0lambda*s. Witness displacement boundv<=lambda*s.',
                           'I=integral overx sup_{|w-x|<=v}|[-B,B]intersection[w-T,w+T]|/(2s) dx =2BT/s+2v min(B,T)/s. The independent coordinate envelope givesn-dimensionalI^n,normalized by(2R)^n.',
                           'SetR=1 andshells_j=lambda^(-j),j>=1 so all complete shells have upper radius<=R. Minimum permitted lower endpoint isL=log(n)/(2^(1+1/n)h0n)/lambda=log(n)/(2lambda²h0n). J=floor(log(1/L)/loglambda),allj1..J are included.',
                           'Withv=lambda*s,t=h0lambda,d=1-lambda/a,splitz*=1/(d+t),the per-axis normalized integral isf=t[1+(lambda-d)s] forB>=T,or(t+lambda)(1-ds)forB<T. As_s tends0,f^n tends(h0lambda)^n,approximately2exp(1/32). Hence summing separate shell envelopes does not yield a dimension-free bound.',
                           'For genuine noncontainment, a small interval centered atw=R-s+b protrudes past the large parent byb. ReplacingB byB+b strictly raises the integral. Exact excess2bT/s+2v[min(B+b,T)-min(B,T)]/s is recorded; the contained-owner erosion hypothesis no longer applies.'],
            'scope':['Exact rational initial/edge/broad geometries use conservative lambda_upper=1+1/n; actual lambda is used in every allowed-shell sum. Tests coverB<T andB>T,full witness motion,half-radius motion and one fixed displacement bound shared across shells.',
                     'Local exact piecewise trapezoid integration of the true supremum-overlap profile is compared with the closed-form identity on MacBook. Shell sums use local Arb256/384 and independent remote Decimal100 when connected.',
                     'Large-dimension records are explicit upper/lower scalar bounds and shell counts, not enumeration of trillions of shells. They deliberately expose rather than suppress the remaining shell-count cost.',
                     'These are finite integral and tensor-envelope models. No new greedy history or global owner-disjointness reduction is asserted. Onlyenvelope.py/json are written; no Git,remote files,GPU use or background jobs.']}
    (BASE/'envelope.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'remote_exit':remote.get('exit_code'),'crosscheck':remote.get('all_exact_and_decimal_checks_passed'),
                      'exact_geometry_rows':len(exact),'shell_sums':[{k:r[k] for k in ('n','J','edge_bins_B_less_T','shell_sum_normalized_by_large_volume')} for r in sums]},indent=2))
if __name__=='__main__':main()
