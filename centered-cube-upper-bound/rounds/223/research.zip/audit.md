# R223 独立审查

## 作者稿前：signed工具的准确适用条件

已先读本轮task_contract.md，未读作者证明。当前目标仍是原一般n^(1/2+o(1))预算；R222已付显式hard来源列，但原L/soft、双Π、score/clock的联合根阶未证。compare负责恢复当前未消费原负账，本检查点不重复搜史，也不预认其恢复结果。

### 1. 标量恒等式及积分资格

对d=k_v−k_u、d_+=(k_v−k_u)_+、d_-=(k_u−k_v)_+，以及0≤a≤1，准确恒等式为

    a d_+−d_-=a d−(1−a)d_-≤a d。

差恰为−(1−a)(k_u−k_v)_+，方向正确。它逐点成立，不依赖u/v交换、来源独立、score方差或条件期望。原k∈{0,…,n}给有限score；但对signed积分仍应先在原合法共同有限截断上工作，使正、负两项分别有限，或给出等价的共同可积条件，避免∞−∞及未授权的signed Tonelli。若a d_+和d_-可积，则a d也绝对可积，此时同一正基准μ积分即得相同不等式。

已用本机Python/Fraction实际核245组(k_u,k_v,a)，以及每组3个b≥a的负系数组合；恒等式和方向全部通过。只作有限有理代数检查，不是原history或来源预算证据。

### 2. 原signed母账需要同一个正基准

要用于原P−N，μ必须来自同一原交通版本、同一合法截断，保同一外2Λ、q^−1 p_y h_R aω dx β_V(dy)ν_V(dz)、同一ordered good×bad来源域、Ψ/当前共同门、两份完整Π_t与同一clock/process支持。实际L/R/s/g和原capture/history均按原行取值；β与ν不交换，硬z不换辅助u/v，Π不更中心也不增加e_t分母。

允许把仅正项出现的FA、ρ0、当前未付子支指示等合成a∈[0,1]，前提是它们都相对于这个相同基准为正乘子，且原负项在所需负score区域具有至少相应的资格。共同门应保在μ；正项独有的[0,1]门可保在a。原aω的RN单位上界已知，但其取值及正负两项的共同版本仍须相同，不能正项先删aω后把旧负项当作同一无权μ。

更一般若原负项系数是b而非1，则

    a d_+−b d_-=a d+(a−b)d_-。

因此b≥a在d_->0处足以给≤a d；若不同gate导致该支配失败，额外项不能丢。不能仅凭门名称相似就认定μ相同。这个一般式允许原负项比正项保更宽资格，但不自动授予门不匹配处的信用；准确gate/来源版本需由negative_contract原文绑定。

### 3. 负账消费与分支分配

本工具只能调用当前尚未消费的匹配负项。若只对原正项的一个子支使用，可把子支指示并入a，而对母账用其原完整N；这在不等式上合法，但该份N已经在此处分配，不能再给补支或三条腿各消费一次。若分胞/分支使用，须以同一原负测度作明确不交分割，或保一份精确的权分配。

原N_del不是自动等于d_-这一pair负变差；除非另有准确原式识别，不把删除负项混入本逐点工具。它可原位保留一次。GG/GE、反向、suffix及边界信用亦不因重写score而重生。R218浮动已付带不重复领取；将当前浮动带外并入a不重建其FIRST/history身份。

### 4. 必须回到正项放大之前，或证明新的门支配

R222对P的half-density和hardband上界是正量放大；其η是正项实际门的hard条件平均。不能将放大后的正半密度项与原N直接识别为本恒等式的同一μ，也不能把η自动当负项权。要在hardz积分之后用此工具，须先对正负项作同一精确积分/分解，保各自gate系数及同一基准，再证明b≥a；独立对正项用16/3、删门或换核不会使负项系数同步改变。

同理，p_y≤√(K/3)Σ腿的正上界不能用于负项而仍保持所需上界方向；三腿也不能各领取整份原N。原硬帽H/q≤16/3作用于非负量，不能在a d符号变化后作为全项的上界乘子随意替换。需要保同一精确正基准，或分别核正负部分的方向。

### 5. 此工具本身没有的结论

∫a(k_v−k_u)dμ一般不为零。即使底层有Π_t⊗Π_t，ordered good×bad、Ψ、FA/ρ及history通常破坏交换对称性；没有证明μ和a在u↔v下共同对称，就不能交换变量抹掉signed均值。也不能据此假定原score坐标独立或每行variance为根阶。

该重写只给合法的signed上界，尚未给εX+Cε√n polylog(n)W_A。若后续要对signed上界作FIRST、fixedJ或clock结算，仍需原同点/同来源量词及全部费用，不能从符号恒等式直接宣布付款。

## 当前初检结论

标量工具成立，其精确差项及门不匹配时的修正项已写清。当前仅通过“同基准、负score资格支配、原负项未消费且仅一次分配”的适用形式；原R223具体P/N gate匹配待negative_contract恢复，peak准确候选和作者证明交付后再审。本检查点未读取作者新稿，也未预报原signed预算已闭合。

## R128 原RT2的方向独立复核：v是good，z′是bad

按主代理新指示直接读R128冻结proof.md:489–523、613–626、652–667及R117 joint_geometry.md:10–42的原后验定义；没有套旧bad-test公式。RT2写作∫_{D_g}∫_{S_g}…dν(v)dν(z′)，不能把外层D_g仅按出现顺序配v：内层S_g对应先出现的dv。更无歧义的同稿JT128-1（505–510行）明确写∫_{E⊂S_g}(1−b_rec(v))dν(v)∫_{D_g}dν(z′)，score为(k_t(v)−k_t(z′))_+；523行将负项的v域换回S_g。

RT5第658行又明写p w_g(z′)>KQ_x^*(z′)、p w_g(v)≤KQ_x^*(v)，即z′是bad，v是good。capture的E=S_g∩{B=0,A>0}同样一致。因此当前原正变差方向是good(v)−bad(u=z′)，不是把v置于bad D_g。R222原good半密度上放也使用good(v)，与此原域吻合。该方向由实际原式确定，不以哪个端点公式更有利来选择。

## 从后验直接推导端点与删除jump符号

冻结完整实际原行，令terminal bad B=D_g、terminal good G=S_g，B∪G=Z_g；置E_t=Z_t\Z_g。对只含完整Π_t⊗Π_t而无额外pair门的基准，F_B(t)=Π_t(B)。跳间w的log时间导数为−k_t w，故直接求商得到

    F_B′=∫_{G×B}(k_G−k_B)Π_t⊗Π_t
           +∫_{E_t×B}(k_E−k_B)Π_t⊗Π_t。

导数是对log t。B×B内部的反对称项积分为零，这里只用真正产品基准，不把原gated good×bad对当作交换对称。于是当前原方向的净GB通量等于F_B′减E→B signed通量；若反向取BG才是−F_B′减B→E通量，两者不能混用。

在原Jfar时间≤h<g（R128:637），terminal B⊂Z_g在所有这些t中存活；删除只移去B外来源，w在删除时连续，故

    ΔF_B=μ_t(B)(1/e_after−1/e_before)≥0。

在合法重段(ℓ,r)按对应一侧端点，准确积分形式为

    ∫GB_signed dlog t
      =F_B(r−)−F_B(ℓ+)−Σ_(ℓ<d<r)ΔF_B(d)−∫EB_signed dlog t。

当前方向的删除jump符号是负。只有反方向BG才出现负F_B端点和正jump。已用本机Fraction核64组3原子score的F_B′=GB+EB，并核删除B外原子时ΔF_B=2/21>0；这是导数/符号代数，不是原FULL实例。

此工具的额外资格仍须保留：原Ψ、aω/history或FAρ等pair/来源权不自动等于无门F_B导数；若补齐为完整产品，必须显式保缺失门域的signed修正。带时间/来源变化的a也不自动从∫a·GB变成同一个F_B端点；需另算相应test导数/跳跃或分部积分项。N_del与该jump的真实系数、域和未消费状态仍由negative_contract原文恢复，不因符号吻合就可抵消。已将这一方向独审结果报主代理和compare，等待准确作者版本。

## negative_contract.md 作者稿后全文审核

已完整通读NC1–12。另独立窄读R123 proof.md:1120–1193、1046–1062以及R117 joint_geometry.md:72–91，核的是原负域/已消费信用/删除过程，未借旧test端点公式推导本轮方向。原N_del为D_g×(Z_t\Z_g)上的完整连续反向score，未附terminal-good、FA、capture、suffix或额外正预算门；按本轮统一记号即E_t×B的D^-。N_Z已由完整后缀非正工具消费，N_Zc在只付正捕获后全额保一次。R128 SP/MA及当前后续已付正子支不自动消费这些负项，也不制造额外信用。

NC6采用另一条更适合固定test的精确式θD^+−D^-=D−(1−θ)D^+，与先筛工具同样正确；它无需对时变θ求导，未把负项补θ。由完整产品后验导数，NC8严格给：

    P−N_Zc−N_del
      =+F_B终−F_B初−删除jump总和−∫_(E_t×B)D^+
        −∫_(G×B)(1−Ψ)D−∫_(G×B)Ψ(1−θ)D^+。

N_del已和E_t×B signed项合成D^+，用此式后不能再减N_del。NC9的good-test写法也正确：端点反向、jump正号、C_GE无自动符号且N_del另列；它与NC8是两个等价test，不能叠取其有利项。NC8采用左/右内侧值、只计内部跳；后续JB5若用右连续终点并计终点跳，只要配套也是同一连续积分，不冲突。

NC10的jump=F_B(s−)r_del/e_after在原正e域正确，来源是B存活而归一分母下降；原N_del是dt/t pair密度，不能把二者看成同项。一般BV扩展须保完整Stieltjes删除测度，原有限森林不凭此丢弃其他极限费用。后缀域1−Ψ的完整窗signed积分虽≤0，其在NC8前的负号反而是非负回加，旧N_Z耗掉不能让回加免费。截取新子窗时不可无证沿用原完整后缀符号。

NC11同hard基准分别平均正、负，η_+≤η_-,Zc且H=0同取0，所有history依hardz仍在积分内。NC12精确为η_-D−(η_-−η_+)D^+；没有假定两η相等。它在原pH/q共同核下合法，不能把R222正项半密度/16/3放大后仍视为该共同核。三腿负信用、非负hard帽作用于signed函数的方向等边界都写清。作者128组有限Fraction只核代数，不认证物理history/删除付款。全文当前无阻断性错误。

## joint_budget.md 作者稿后全文审核

已完整读JB1–7。统一good−bad、固定terminal B/G与原clock、正门θ和共同Ψ、原h_R/aω/p/q/β/ν_z全部保留；JB2从后验求导，B×B反对称抵消只在完整产品下使用，不假设score坐标独立。JB3与上面的NC8核心相同，JB4分母e_after及正jump正确。JB5对右连续闭端点配套计(l,r]跳，开放端用原域内极限；新增共同时间筛选必须另审其边界，不能把时变正门θ的损失项省掉。

JB6可作为−∫S的安全非负上界：−S=∫(1−Ψ)D^-−∫(1−Ψ)D^+≤∫(1−Ψ)D^-；它不是一般意义下−S的精确等式或最小价格。作者全量等式JB5/JB7仍保S本身，未用假等号消去，因而无阻断。该恢复价是旧suffix域的反向交通，不是可再领取N_Z。正gate损失R只在Ψ域，不能与1−Ψ上的恢复项点态抵消。

JB7乘回原共同1_high dT及2Λ，保真实dx和全部来源/clock，而非R222已放大正项的η。R170旧条件性分支只作为既有接口边界提醒，本轮未实际调用其条件价或称为新增付款；本审核不重审无关旧证明。逐行F_B≤1尚不授εX/root来源价，作者明确保最早未付的边界/suffix与实际reserve比较。19,683组pair代数与3个jump例仅作符号实现核验，未称FULL或新信用。稿件通过准确范围，等待主proof/数值终稿绑定，不冻结整轮。

## Python数值源码、完整JSON与独立重跑

已完整审signed_flux_checks.py（99行）及62302行JSON的原始记录/配方。258配置为初探54、阈值/零组180、扩大24，维数至10000；有限α阈值产生product权及左右导数k，G/B/E分区完整。zero_B/zero_G把相应点移到E、zero_E移出指定未来点，均按当前分区重新计算；empty_Z是明确的零贡献延拓，不冒充e=0时可归一的概率后验。

所有pair计算使用good−bad；unmasked修正确用signed D，未误作D^-。R=GB的Ψ(θD^+−D^-)减EB D^-，corrected RHS=F_B′−EB D^+−unmasked signed−capture正损失，与理论一致。删除只去E中指定点，终端B保留，jump公式符号/分母正确。阈值左右权和e/e_B连续，k的左右值正确改变，未添w的硬原子。

独立本机python3实际另输出/tmp/r223_audit_signed_flux_checks.json，exit0，与交付2,434,134-byte完整JSON逐字节相同。另从每行原α_counts、ν、active/group及mask/θ重构全部258项Fraction：核每个源权/score、e/e_B及导数、GB/EB signed、正部/门损失、完整恒等式、删除jump及所有大数规范hex哈希和bit length；全部通过。90对阈值记录另逐对核源权、e和e_B连续。无活跃Python session。

连续模型a=1/8、[1/4,3/4]、删除1/2中，GB原函数为−a/(t+c)，前段c=2a、后段c=a。代码实际执行自带Fraction多项式求导/交叉乘法，得到R=59/420、FB端点差5/14、jump2/15、EB正项1/12，准确59/420=5/14−2/15−1/12。SymPy在本次Python环境不可用，实际用的是已执行的有理多项式fallback，没有假报SymPy运行。

任意阈值数组、checker/非指示mask测试或上述有限原子不认证实际C核、good/bad绝对门、suffix/history或正L1 FULL输入。普遍数学方向由显式证明承担，有限JSON不提供root预算。

## MATLAB符号源码及独立本机batch复跑

已完整读matlab_symbolic_checks.m及13行JSON。一般协方差、删除jump代数，以及D正/负两支mask恒等式分别化简零；符号等式本身不替代删除质量小于总量等原可积/正分母资格。一般jump的非负性依据真实B存活与e_after>0，不仅依据一条零等式。

在父级确认无MATLAB并发后，独立实际调用/Applications/MATLAB_R2026a.app/bin/matlab -batch，运行当前源码到/tmp/r223_audit_matlab_symbolic_checks.json。进程exit0，输出与交付523-byte JSON逐字节相同，四项均为字符"0"；初始1/3、终端2/3、删除jump12/95、连续端点预算59/285一致。此模型为(1,t^−1,t^−2)、删除3/2、区间[1,2]，其59/285是连续FB导数的端点减jump预算，与Python模型的GB signed净量59/420是不同模型/不同量，不相互混同。MATLAB已退出，无活跃session，已通知父级解除争用等待。

父级记录的MCP jupyter.Idler失败和首次psi符号命名冲突，不列为成功数学证据；独审此次直接batch成功。未编译PDF，未安装新库。实际成功代码、JSON和本机运行才作为符号证据，均不认证一般几何/root目标。

## 主proof/report/driver最终理论审查

proof.tex.txt已完整通读。有限原行、e_t≥e_*>0、有限来源及有限森林跳资格足以给L1求导和Fubini；阈值w连续，有限jump的Stieltjes扣除正确，更一般奇异删除明确须另保完整测度。theorem中的NC8/JB5式完全一致，正门θ无需导数；原N_del已合入EB正项，不重复扣。所有signed项须在共同有限可积合同下处理，不对∞−∞应用Tonelli。

主稿准确撤回早期bad−good工作解释，原R222 good(v)半密度接口保持。外dT的真实p/h_R/aω/q/β/ν_hard、high、唯一j与原截断应与NC1/JB1一致，已要求显示式补1_I1_{j(x)=j}，避免只从外Σj推免费合并。外2Λ一次、两Π已含两个e_t分母，正项三腿上放不各领一份负量。R222正η/16/3不被当作负权。

report已全文审核，不把本轮恒等式或两套有限计算冒称新根阶付款；删除jump有利、suffix回加未付的决策边界清楚。joint_budget JB6终修已明确只为−∫S的安全上界，非一般等式。reproduce.py静态审核：迁移两个源码到包外新目录，依次运行Python和MATLAB而不经shell拼接，MATLAB目录引号有正确转义；比较两份完整JSON并前后verify manifest。--python-only明确标partial，不认证完整复现。最终manifest及父级整包迁移/双备份/Git仍由其实际回执另记，不由本审核预报。

## 最终绑定与冻结结论

已实际核主proof外dT补回共同原截断1_I及唯一j指示，与NC1/JB1同一正基准；原共同有限截断按原标签含义使用，不将其变成新的实际交通。最终171行全文已审，6个label互异、6个ref/eqref均有定义，环境嵌套配对通过。JB6安全上界的终修措辞已实核，其他受审理论/数值未改。

最终文件SHA256：

|文件|SHA256|
|---|---|
|task_contract.md|8bc0407f0ad1234007e4f01d6f4b617bc128dd119a9f2f2e76525783d20f3605|
|negative_contract.md|01675c28b8ff31f02fb23a5620fbda84b7a47f5885392d35b91f5dd20b6b3095|
|joint_budget.md|58e429d64bd14c5ffddc31d2403a17ac57eeaa972f399b60ca04c46951395f18|
|proof.tex.txt|eeedad4c565533fce1aa68ddc87ba64e8b59e306a9f420e3717251985c06ebe9|
|signed_flux_checks.py|6f4bee8daea2db6c82033a42dac94c45e1472fa2bf540b72dfe6a8a7fa170349|
|signed_flux_checks.json|3a4bb3a2287cfffb5cf97b103f11bb27c7cfb99440f8bb0641cdf6e4c4c89ef8|
|matlab_symbolic_checks.m|f7cabfabca4354ee15b04c9672f75ee65054e96b8b8537b7dd9eb5f88e4a5146|
|matlab_symbolic_checks.json|eb6bc6af16f49e2b29e4eccf8b5d827e768813277d648a7134abe564edee9cc0|
|report.md|6e02fea6dd4e8225394576ed54d36573b1aa5a1a6ca05592767ffee168d10612|
|reproduce.py|a8a7b5b7ebd52cffc69fd6b38b1f1d43c4ac84f0f9190c9ad4426d420efe8438|

**冻结结论。** 原good−bad方向、完整负账恢复、连续drift与非负删除jump、bad/good两test的等价账、suffix signed回加和正门损失，以及同原正基准的外2Λ回代均在准确范围通过。R222正项放大未移交给负项；旧N_Z不复活，N_Zc/N_del只在同一等价账内保一次。本轮仅作精确恒等/契约恢复，没有实际消费这些负项去登记新增已付分支，也没有获得一般root来源预算。

最早未付仍是带真实dx/β/ν与双Π的边界及suffix恢复价，或它们与现存有利项的真实联合比较；不能以逐行FB≤1、任意mask有限例或符号零值代替εX+Cε√n polylog(n)W_A。Python与MATLAB两套代码均已独立本机成功运行，完整JSON分别字节一致；Python全部258行另精确重构，90对阈值与两模型分数均核对。没有活跃计算session或待解决阻断。审计至此冻结，父级后续manifest、整包迁移双复现、备份/README与Git回执另记，不要求回头变更本文件。
