function matlab_symbolic_checks(output_file)
% Symbolic identities only; not a FULL input or a root-order estimate.
if nargin == 0
    output_file = fullfile(fileparts(mfilename('fullpath')), 'matlab_symbolic_checks.json');
end
syms b g e kb kg ke positive
F = b/(b+g+e);
drift = simplify(diff(F,b)*(-kb*b)+diff(F,g)*(-kg*g)+diff(F,e)*(-ke*e));
pair = (g*b*(kg-kb)+e*b*(ke-kb))/(b+g+e)^2;
identity = simplify(drift-pair);
assert(isAlways(identity == 0));
syms r positive
jump = simplify(b/(b+g+e-r)-b/(b+g+e));
jump_error = simplify(jump-b*r/((b+g+e)*(b+g+e-r)));
assert(isAlways(jump_error == 0));
syms d positive
syms mask_weight positive_weight real
positive_case = simplify(mask_weight*positive_weight*d-(d-(1-mask_weight)*d-mask_weight*(1-positive_weight)*d));
negative_case = simplify(-mask_weight*d-(-d-(1-mask_weight)*(-d)));
assert(isAlways(positive_case == 0) && isAlways(negative_case == 0));
syms t positive
before = 1/(1+1/t+1/t^2);
after = 1/(1+1/t);
t0 = sym(3)/2;
initial = subs(before,t,1); terminal = subs(after,t,2);
example_jump = simplify(subs(after-before,t,t0));
continuous_budget = simplify(subs(before,t,t0)-initial+terminal-subs(after,t,t0));
endpoint_budget = simplify(terminal-initial-example_jump);
assert(isAlways(continuous_budget == endpoint_budget));
result = struct('schema','R223_symbolic_identity_v1', ...
    'tool','MATLAB Symbolic Math Toolbox', ...
    'covariance_identity_zero',char(identity), ...
    'deletion_jump_identity_zero',char(jump_error), ...
    'positive_mask_identity_zero',char(positive_case), ...
    'negative_mask_identity_zero',char(negative_case), ...
    'example_initial_bad_probability',char(initial), ...
    'example_terminal_bad_probability',char(terminal), ...
    'example_positive_deletion_jump',char(example_jump), ...
    'example_continuous_endpoint_budget',char(continuous_budget), ...
    'scope','Symbolic algebra and endpoint identity; not original full geometry or general root budget');
fid=fopen(output_file,'w'); assert(fid>=0); cleanup=onCleanup(@() fclose(fid));
fprintf(fid,'%s\n',jsonencode(result,'PrettyPrint',true));
disp(jsonencode(result));
end
