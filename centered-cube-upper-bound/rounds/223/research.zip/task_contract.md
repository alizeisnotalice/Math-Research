# R223：半密度联合预算与原负信用

上一轮07d5d47c1d834298465e6632e4eceb8553a38e61已远端接收，本轮起始干净。总体一般n^(1/2+o(1))目标仍未闭合。

最小上下文：R222冻结/Users/zhengzhihao/Desktop/T/output/centered_cube_round222_20261016_final_checkpoint中source_occupancy.md SOCC4/10/11及proof.tex.txt；R128 proof.md604–650原P/N母账。外分母共同q∈[3λ/4,λ]；原aω是RN且0≤aω≤1，原E须保。R222已证全域hardz结算：H=∫hRν≤16q/3；η=∫hR aMρν/H,H0置0，保原1j/clock/全部正门；wg=wbar_cjg≥γ^-n wbar_min(L,R)≥γ^-n wbar_L。因此原P≤(32Λ/3)√(K/3)γ^(n/2)Σ三腿 EΣVj∫βΠτΠτ δτ dτ/τ∫E sqrt(p Kleg)[η+/√wbar_L+η-1rv>a/√wbar_min(L,rv)]dx。全部L,R,s可依x。R≤L时η->0需rv=2||x-v||∞>R≥a。R未完全从η/clock消失，不能免费删η后消失j和时间重数。

两Π已含eτ^-2，固定ωVjyτ独立x,z但依y；不能凭FIRST把βΠ²拆独立。剩余需εX+Cε√n polylog(n)WA。不要再研究hard来源局部质量或重复条件C*桥。旧R220共同硬核定理仅可在保原hR的另一条原量估计上使用，不能在R222无hR余式再领16/3。负账未消费，可回到原signed母式探索匹配抵消，但不准将正项放大后的条件平均自动当负项权。

原可用工具：FIRST同x∫pβ≤q，Q_x^*=(K1+K2+J)/3容量≤q；high p eg≥2Kq=>∫highβ/eτ≤1/(2K)，eτ≥eg；固定J列∫Jν dx=||ν||。无ν≤β、无hardz限Zg、无原score坐标独立性。strictsoft s>1−2^-1/n；current未付浮动带ρ0(wτ−h0)>L0J/p，L0=K√n,h0=L0J/p+K0/(κT)。浮动已付不重领。

任务责任：peak/Astra主攻半密度+双Π/原signed预算joint_budget.md；compare/Sol窄恢复未消费N_Zc,N_del与门匹配negative_contract.md；audit/Sol先独立筛signed合法性和候选再读作者audit.md；numeric/Sol等准确候选后本机三阶段核。不要重复同一高成本路线。非独占代码库，只改各责任文件，无Git/spawn/PDF，完成有限交付停等。
