# R223：尚存负账的共同基准、来源方向与净 score 恒等式

本稿只恢复当前 signed 契约，不登记新的根阶付款。当前可用减项是 **一次** `−2ΛN_{Zc}−2ΛN_del`，`Λ=128/119`；已经用于后缀零费的 N_Z 不回来。N_del 是未来会删去来源在远窗内的连续 `dt/t` 反向配对，不是禁块删点的跳跃原子。R222 的正项硬来源条件平均 η 没有被自动授予负项。

## NC1 原母式与不可混淆的字母

首读本轮合同及指定 [R128 proof.md:604–650](/Users/zhengzhihao/Desktop/T/output/centered_cube_round128_20261014/proof.md:604)。原完整实际行 `r=(ω,V,j,x,y,z_hard,history)` 的共同非负外测度是

\[
 d\mathcal T_I(r)=1_I1_{\{j(x)=j\}}q^{-1}p_y(x)h_{R(x)}(x-z_{hard})
 a_\omega(x,y,z_{hard})\,dx\,\beta_V(dy)\nu_V(dz_{hard}). \tag{NC1}
\]

high 指示 `1_{A_hi}` 在正负双方相同；原远窗是同一 `J_far=I_{j,V,y}∩[τ_j,h]`，h<g。共同 q 为原标量。原 FULL/FIRST/种子/原历史资格在同一 a 和实际行内，不交换 β、ν 或 hard z 与辅助来源。后来的只属于正项的门另列，不能反添给负项。

为彻底消除换字母造成的 score 方向错误，以下不沿用不同稿件中可能互换的 v,u，改用

\[
 \mathsf B=D_g=\{b\in Z_g:p_yw_g(b)>KQ_x^*(b)\},\quad
 \mathsf G=S_g=Z_g\setminus D_g,\quad
 \mathsf E_t=Z_t\setminus Z_g,\qquad
 D_t(c,b)=k_t(c)-k_t(b). \tag{NC2}
\]

这里 b 是 terminal bad，c 是 terminal good 或 future-deleted 来源；`Z_t=G ⊔ B ⊔ E_t` 对 t≤g 成立。

**原文绑定不是凭记忆：**

* [R128:613](/Users/zhengzhihao/Desktop/T/output/centered_cube_round128_20261014/proof.md:613)明写 `δ_t=[k_t(v)−k_t(z′)]_+`；[616–625行](/Users/zhengzhihao/Desktop/T/output/centered_cube_round128_20261014/proof.md:616)的内积分是 `∫_{S_g}…dν(v)`、外积分是 `∫_{D_g}…dν(z′)`。因此在本稿记号中 v=c∈G、z′=b∈B，原 positive 是 D_t(c,b)^+。
* [R128:658](/Users/zhengzhihao/Desktop/T/output/centered_cube_round128_20261014/proof.md:658)的绝对门直接给 `p w_g(z′)>KQ_x^*(z′)` 与 `p w_g(v)≤KQ_x^*(v)`，再次绑定坏 z′、好 v。
* 更早无嵌套积分歧义的 [R119 quantitative_future.md:34–39](/Users/zhengzhihao/Desktop/T/output/centered_cube_round119_20261014/quantitative_future.md:34)定义 D_g 坏集；[47–52行](/Users/zhengzhihao/Desktop/T/output/centered_cube_round119_20261014/quantitative_future.md:47)明写 `δ_t(z′,z″)=[k_t(z″)−k_t(z′)]_+`；[202–203行](/Users/zhengzhihao/Desktop/T/output/centered_cube_round119_20261014/quantitative_future.md:202)明分 z″∈G 与 z″∈E_t。原反向项 [FA20:205–213](/Users/zhengzhihao/Desktop/T/output/centered_cube_round119_20261014/quantitative_future.md:205)则是 `[k_t(z′)−k_t(z″)]_+`。

若另外定义坏减好 `\widetilde D_t=k_t(b)−k_t(c)=−D_t`，则原 positive 是 `(-\widetilde D_t)^+`，negative 是 `\widetilde D_t^+`。不能换了字母又保同一个加号方向。

两份概率核完整为

\[
 \Pi_t(dc)\Pi_t(db)=
 \frac{1_{Z_t}(c)1_{Z_t}(b)w_t(y,c)w_t(y,b)}{e_t(y)^2}\nu_V(dc)\nu_V(db). \tag{NC3}
\]

它已含两分母，不再额外除 e_t²。固定 `(ω,V,j,y,t)` 后此核独立 x 与 hard z；G/B、终端尺度、capture、suffix 和完整行仍按实际 x/history 保留。E_t 不是 terminal good，不能给它补 `p w_g≤KQ_x^*`。

## NC2 正负门与 current 负信用清单

令 Ψ_r(c,b)=1_{Zcal_r^c}(b,c) 为原存活来源对后缀补域。对当前剩余正项，把原 FA 不足门、真实 capture ρ0、mixed/当前浮动带外及其他额外正门准确合为 `θ_r^+(t,c,b)∈[0,1]`。这只是原门的记法，不重算资格，不把它设成自由选择器；外共同行仍是 NC1。

[R128:616–630](/Users/zhengzhihao/Desktop/T/output/centered_cube_round128_20261014/proof.md:616)逐项给以下 contract，乘同一 `1_{A_hi}dT_I` 后外积/期望求和：

\[
\begin{aligned}
 P_r&=\int_{J_{far}}\iint_{G\times B}\Psi_r\theta_r^+D_t^+\,d\Pi_t(c)d\Pi_t(b)\frac{dt}{t},\\
 N_{Zc,r}&=\int_{J_{far}}\iint_{G\times B}\Psi_r D_t^-\,d\Pi_t(c)d\Pi_t(b)\frac{dt}{t},\\
 N_{del,r}&=\int_{J_{far}}\iint_{E_t\times B}D_t^-\,d\Pi_t(c)d\Pi_t(b)\frac{dt}{t}.
\end{aligned} \tag{NC4}
\]

最后一行的来源域与完整负门由 [R123 proof.md:1127–1135](/Users/zhengzhihao/Desktop/T/output/centered_cube_round123_20261014/proof.md:1127)及 [1189行](/Users/zhengzhihao/Desktop/T/output/centered_cube_round123_20261014/proof.md:1189)明确恢复。它不加 Ψ、FA、ρ、terminal-good 或大耗散正预算门。所谓 future-deleted 是该 c 后来从 Z_t 删去，不等于只在其删除时刻计量。

| 信用/费用 | 当前状态及不可重复处 |
|---|---|
| N_Z，存活后缀合格域 | 已消费。原全后缀积分≤0加 e_t^−2 非减的 Stieltjes 分部积分给 P_Z≤N_Z，R123 删除该完整非正分支。[R123:1050–1059](/Users/zhengzhihao/Desktop/T/output/centered_cube_round123_20261014/proof.md:1050)、[1137–1143](/Users/zhengzhihao/Desktop/T/output/centered_cube_round123_20261014/proof.md:1137)。不能再保完整 −N_surv。 |
| N_Zc | 原后缀补域上完整反向负项，未加正 capture/FA/新子支门。R123 当前选择只付正捕获，故完整减项保一次，[1151–1157行](/Users/zhengzhihao/Desktop/T/output/centered_cube_round123_20261014/proof.md:1151)。R128:633明确SP/MA只删已付正子集，负项原位；不调用互斥AS/SF账再用同份负项。 |
| N_del | 完整 E_t×B 的连续反向项保一次；不属于 terminal 存活后缀工具。[R123:1189](/Users/zhengzhihao/Desktop/T/output/centered_cube_round123_20261014/proof.md:1189)。 |
| 初始、跳跃、D_rem、低 pe 等 | 是旧母账另列的正费用/未付项，不是可再扣的一组负退款。[R123:1163–1172](/Users/zhengzhihao/Desktop/T/output/centered_cube_round123_20261014/proof.md:1163)保 `2ΛI_rem+2ΛJ_rem+2ΛD_rem` 及全部旧前缀。 |
| R218浮动带与后续正项工具 | 已付正子支先从 P 中删去；不重新领取其价格，不由正项付款制造新负信用。当前严格补域及其正门在 θ^+ 中保留。 |

全当前 signed 槽准确为

\[
 2\Lambda\,\mathbb E\sum_{V,j}\int 1_{A_{hi}}
 [P_r-N_{Zc,r}-N_{del,r}]\,d\mathcal T_I(r),\quad\Lambda=128/119. \tag{NC5}
\]

原 `2` 来自原 high-bad 回代，Λ来自共同树边界吸收，各一次；没有3、16/3或 γ^(n/2)藏在这些负项里。R222 的这些正上放系数不能反贴到负母式。

## NC3 两个合法净 δ 身份

逐 pair 的基础身份是

\[
 \Psi[\theta^+D^+-D^-]
 =\Psi D-\Psi(1-\theta^+)D^+. \tag{NC6}
\]

损失项非负，θ 的时间变化无需微分。它保整个原反向，不假设负门等于正门。以下只在一个固定实际行及其原完整远窗 `[l,r]` 上写式；先有限共同截断，右端点用 r−、左端用 l+，内部真实删除另列，避免无穷正负相减。

设 `F_B(t)=Π_t(B)`。原禁块恒定段有

\[
 \partial_{\log t}F_B(t)
 =\iint_{(G\cup E_t)\times B}[k_t(c)-k_t(b)]\,d\Pi_t(c)d\Pi_t(b). \tag{NC7}
\]

证明是 `∂logt Π_t(B)=Π_t(B)E_Π k−∫_B k dΠ`；B×B 的反对称积分为零。把 NC6 用于 NC4，再用 NC7，得到完整 bad-test identity

\[
\begin{aligned}
 P_r-N_{Zc,r}-N_{del,r}
 ={}&F_B(r-)-F_B(l+)-\sum_{l<s<r}\Delta F_B(s)\\
 &-\int_l^r\iint_{E_t\times B}D_t^+\,d\Pi_t^2\frac{dt}{t}\\
 &-\int_l^r\iint_{G\times B}(1-\Psi_r)D_t\,d\Pi_t^2\frac{dt}{t}\\
 &-\int_l^r\iint_{G\times B}\Psi_r(1-\theta_r^+)D_t^+\,d\Pi_t^2\frac{dt}{t}.
\end{aligned} \tag{NC8}
\]

其中 `D+D^−=D^+` 正好把 E_t×B 的完整 N_del 合进第二行；用了 NC8 就不能再减另一份 N_del。若采用坏减好 score，则 NC7右边是负的该 score 均值，NC8的端点符号仍由原正项方向决定。

这不是新的时间流付款。第三行必须保：`1−Ψ=1_Zcal` 是先前消费的后缀域，按原完整窗其 signed 积分≤0，故其前面的减号可以产生**非负回加价格**。不能把旧 N_Z 已用这一事实误写成“这个补项现在免费”。新截子窗若不具有原后缀条件，也不能继续使用其符号。第四行是保原正门的有利损失，不从捕获预算再领取同份。

等价地，取 `F_G=Π_t(G)` 可得熟知 good-test 式

\[
 P_r-N_{Zc,r}-N_{del,r}
 =F_G(l+)-F_G(r-)+\sum\Delta F_G
 -\int C_{GE}\frac{dt}{t}-\int H_Z\frac{dt}{t}-\int R_{loss}\frac{dt}{t}-N_{del,r}, \tag{NC9}
\]

其导数依据是 `−∂logt F_G=∫_{G×B}D dΠ²+∫_{G×E_t}(k_g−k_e)dΠ²`，所以端点方向与 NC8 一致。其中 `C_GE=∫_{G×E_t}(k_g−k_e)dΠ²`，`H_Z=∫_{G×B}(1−Ψ)D dΠ²`，`R_loss=∫_{G×B}Ψ(1−θ^+)D^+dΠ²`。此形式保 N_del 另列，但 C_GE 无自动符号。NC8/9是同一母式的两种 test 写法，不能把两份有利项相加。

## NC4 删除跳、连续 dt 与边界的区别

原 [R117 joint_geometry.md:16–23](/Users/zhengzhihao/Desktop/T/output/centered_cube_round117_20261014/joint_geometry.md:16)明确 Z_t 按有限原森林路径右连续、仅有限跳，跳间真正恒定；[76–89行](/Users/zhengzhihao/Desktop/T/output/centered_cube_round117_20261014/joint_geometry.md:76)给

\[
 r_s^{del}=\int_{Z_{s-}\setminus Z_s}w_s\,d\nu,\quad e_{s-}=e_s+r_s^{del},\qquad
 \Delta F_B(s)=F_B(s-)\frac{r_s^{del}}{e_s}\ge0. \tag{NC10}
\]

B⊂Z_g⊂Z_s，故这些真实删除不触及 B；G也不被删。NC10是归一化变化的原子，NC4 的 N_del 则是 `dt/t` 来源对密度；两者不相等、不互相替换。w_t 在坐标阈值连续，k_t只在零测时刻换值，不生成额外 hard 原子。端点删除是否计入须按原一侧值；不能既并入端点又另计一次跳。

如果离开原有限路径资格、另研究一般 BV 删除，NC8中必须以完整非负 Stieltjes 删除测度 `dJ_B` 替代 `ΣΔF_B`，包括连续奇异部分；不能只保原子。本文不把更一般过程冒充当前原 Z，也不从有限截断极限无证删去奇异费用。任意新时间分割均须重列端点；边界函数没有因其数值≤1自动得到 εX 或来源根阶价。

## NC5 与 R222 正条件平均能匹配到哪一步

在尚未放大正核之前，可按同一 hard 后验 `h_Rν/H_R` 分别平均正负权。把原共同 high/j/far/terminal pair/Ψ 指示保在定义中，得到

\[
 \eta_+=H_R^{-1}\int h_Ra\,1_{common}\Psi1_G1_B\theta^+\,d\nu,\qquad
 \eta_{-,Zc}=H_R^{-1}\int h_Ra\,1_{common}\Psi1_G1_B\,d\nu,
 \quad0\le\eta_+\le\eta_{-,Zc}\le1. \tag{NC11}
\]

H_R=0时均取0；若任何历史依 hard z，全部保在积分内。score和原Π固定`(ω,V,j,y,t)`后独立hard z。因此其**原共同核系数**下有精确身份

\[
 \eta_+D^+-\eta_{-,Zc}D^-
 =\eta_{-,Zc}D-(\eta_{-,Zc}-\eta_+)D^+. \tag{NC12}
\]

这是真实可配对的净 δ 式，不把两个η设成相等；N_del另有 E_t×B 的完整负条件平均。NC11不是任意新正上放后的负权授权。

最早不能自动匹配处恰在 R222/SOCC11：正项已用 good 将 p 换成三腿半密度和，又把正 `H_R/q` 换成16/3并比较 w_g的尺度；原负项仍乘其原 `pH_R/q`、原完整负资格。由 `H_R/q≤16/3` 不能同方向上放一个 signed 密度，亦不能把其负项系数升为16/3。类似地，positive halfdensity 三腿和≥原 p，并不使每腿各继承一份原负信用。故欲用 NC8/9/12，必须回到 NC1/4 的原共同基准，或另严格证明放大后的正项与原负项之间的系数比较并保足差价。仅将正η命名成负η不构成该比较。

本机实际用 Fraction 对有限三类来源 G/B/E、非负权、signed score 核对 NC6、NC7的两种 covariance 展开、NC8的无跳 pair 代数及 NC12；这些是代数方向检查，不是 FULL、删除历史或一般来源预算证书。完成有限契约恢复，不扩展未付边界估计。
