# 第223轮：原负信用与有符号后验交通核验

本轮没有取得新的原根阶付款。一般中心立方体n^(1/2+o(1))目标保持，未以符号恒等式或数值样本代替闭合。

## 改变下一步决策的核验

恢复原score方向：R128显式门和R119定义确认good−bad；不能将嵌套积分左边的集合直接配末尾第一个变量。主代理本轮初始bad−good解释已撤回，R222 good端半密度推导本身未因此改变。严格定义b∈B坏、c∈G好，避免原v/z′重名。

固定原行，F_B=Π_t(B)的连续导数等于(G∪E_t)×B上的good/outside−bad signed交通。删除只发生于终端B外，F_B跳跃非负，因此连续积分账减去该跳跃。原N_del是E_t×B的dt反向score，不是删除原子，不能把两者混为同一费用。

完整当前正负账精确等于：后验端点差 − 删除跳 − E×B正交通 − 已移除suffix区域的signed交通 − 正门损失。suffix修正的score必须保signed值。N_Z已由早期suffix分支消费，恢复完整导数时不能丢对应回加价。R222的正项条件平均/半密度/硬帽放大也不能自动移交给负项，更不能三腿各领同一信用。

结果是删除费用不应作为本路线新增正障碍；真正未控制的是带真实接收测度的边界与suffix回加，并须与尚存有利项共同结算。R170已有条件边界分支仅登记为历史工具，不重复报告为新付款。本轮未得到新的共同几何比较，因此不提交根阶已付分支声明。

## 实际工具验证

Python标准库Fraction：258组有限配置、90对阈值连续性检查，n至10000；完整原始JSON主代理实际运行后cmp一致。另有可复现的有理多项式求导/连续窗口证书59/420=5/14−2/15−1/12。阈值/mask有限模型不认证原FULL几何或suffix资格。

本机MATLAB R2026a Symbolic Math Toolbox实际运行，一般后验导数、删除跳、mask正负两支均化简为0。另一模型端点1/3→2/3，删除jump12/95，连续预算59/285。MCP执行入口报jupyter.Idler错误；改用本机matlab -batch，第一次因psi与内置函数名冲突失败，改名后运行成功。bundled Python缺Sympy，未安装新库。报告只将成功的实际运行列为证据。

完整proof.tex.txt、negative_contract.md、joint_budget.md及独审均保留；不编译PDF。所有负信用均未由本轮实际消费。使用N04有限望远镜/误差总账的既有边界，不引用未读论文或假定通用稳定性。实际额度扣减不可获得，不估成本比例。

## 复现

python3 reproduce.py --verify-only检查manifest；完整复现python3 reproduce.py --output-dir <新的包外目录>，需Python及本机MATLAB Symbolic Math Toolbox，可用--matlab-executable指定可执行文件。driver将两个源码迁移到包外运行，比较两份完整JSON并复核前后manifest。--python-only仅复现Python，回执明确标为部分，不认证完整复现。
