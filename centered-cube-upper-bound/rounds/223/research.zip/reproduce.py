#!/usr/bin/env python3
"""Verify and relocate both exact drivers. No PDF compilation."""
import argparse,hashlib,json,shutil,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def verify():
    hashes=json.loads((ROOT/'manifest.json').read_text())
    for name,h in hashes.items():assert digest(ROOT/name)==h,name
    return len(hashes)
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--verify-only',action='store_true');ap.add_argument('--output-dir',type=Path);ap.add_argument('--python-only',action='store_true');ap.add_argument('--matlab-executable');args=ap.parse_args()
    count=verify()
    if args.verify_only:print('verified',count,'manifest hashes');return
    if args.output_dir is None:ap.error('--output-dir required')
    out=args.output_dir.resolve()
    if out==ROOT or ROOT in out.parents:ap.error('output must be outside package')
    matlab=args.matlab_executable or shutil.which('matlab') or '/Applications/MATLAB_R2026a.app/bin/matlab'
    if not args.python_only and not Path(matlab).is_file():ap.error('MATLAB executable unavailable; specify --matlab-executable or request partial --python-only')
    out.mkdir(parents=True,exist_ok=False)
    for name in ('signed_flux_checks.py','matlab_symbolic_checks.m'):shutil.copyfile(ROOT/name,out/name)
    runs=[]
    start=time.monotonic();subprocess.run([sys.executable,str(out/'signed_flux_checks.py'),'--output',str(out/'signed_flux_checks.json')],check=True)
    runs.append({'driver':'signed_flux_checks.py','elapsed_seconds':time.monotonic()-start})
    outputs=['signed_flux_checks.json']
    if not args.python_only:
        # MATLAB string escaping; shell is never used.
        folder=str(out).replace("'","''")
        code="addpath('"+folder+"'); matlab_symbolic_checks"
        start=time.monotonic();subprocess.run([matlab,'-batch',code],check=True)
        runs.append({'driver':'matlab_symbolic_checks.m','elapsed_seconds':time.monotonic()-start});outputs.append('matlab_symbolic_checks.json')
    results=[]
    for name in outputs:
        assert (out/name).read_bytes()==(ROOT/name).read_bytes(),name+' entire JSON differs'
        results.append({'file':name,'sha256':digest(out/name),'complete_json_byte_identical':True})
    assert verify()==count
    receipt={'complete_replay':not args.python_only,'manifest_hashes_before_and_after':count,'runs':runs,'outputs':results,'python':sys.executable,'matlab':None if args.python_only else matlab}
    (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
if __name__=='__main__':main()
