#!/usr/bin/env python3
"""Exact finite signed-flux orientation checks. Unmasked correction uses signed D.
No original geometry, suffix/history gate, actual threshold law or FULL assertion.
"""
import argparse,hashlib,json
from fractions import Fraction as F
from pathlib import Path
HERE=Path(__file__).resolve().parent

def rat(x):return f'{x.numerator}/{x.denominator}'
def val(x,small):
    out={'sha256_hex_numerator_slash_denominator':hashlib.sha256((format(x.numerator,'x')+'/'+format(x.denominator,'x')).encode()).hexdigest(),'sign':(x>0)-(x<0),'numerator_bit_length':abs(x.numerator).bit_length(),'denominator_bit_length':x.denominator.bit_length()}
    if small:out['exact_fraction']=rat(x)
    return out

def recipe(n):
    return [{'id':0,'terminal':'G','nu':F(1),'alpha_counts':[(F(1,8),n)]},{'id':1,'terminal':'B','nu':F(1,2),'alpha_counts':[(F(1,8),max(1,n//3)),(F(1),n-max(1,n//3))]},{'id':2,'terminal':'G','nu':F(2,3),'alpha_counts':[(F(1,2),n//2),(F(1),n-n//2)]},{'id':3,'terminal':'E','nu':F(3,4),'alpha_counts':[(F(1,8),n-1),(F(1),1)]},{'id':4,'terminal':'B','nu':F(1,5),'alpha_counts':[(F(1),n)]}]
def run_case(n,t,side,partition,mask,theta):
    sources=recipe(n);B={1,4};G={0,2};active=set(range(5))
    if partition=='zero_B':B=set()
    if partition=='zero_G':G=set()
    if partition=='zero_E':active.remove(3)
    if partition=='empty_Z':active=set();B=set();G=set()
    E=active-B-G;mass={};k={};records=[]
    for s in sources:
      i=s['id'];w=F(1);ki=0
      for alpha,count in s['alpha_counts']:
        w*=min(F(1),alpha/t)**count
        if alpha<t or (side=='right' and alpha==t):ki+=count
      mass[i]=w*s['nu'] if i in active else F(0);k[i]=ki
      records.append({'id':i,'nu':rat(s['nu']),'alpha_counts':[{'alpha':rat(a),'count':count} for a,count in s['alpha_counts']],'active':i in active,'current_group':'B' if i in B else 'G' if i in G else 'E' if i in E else 'inactive','k_one_sided':ki,'weight_times_nu':val(mass[i],n<=16)})
    e=sum(mass.values(),F(0));eB=sum((mass[i] for i in B),F(0));eprime=-sum((k[i]*mass[i] for i in active),F(0));eBprime=-sum((k[i]*mass[i] for i in B),F(0))
    derivative=(eBprime*e-eB*eprime)/(e*e) if e else F(0)
    GB=F(0);EB=F(0);R=F(0);EBpos=F(0);GBunmasked=F(0);GBcapture=F(0)
    for i in G:
      for j in B:
        D=k[i]-k[j];Dpos=max(D,0);Dneg=max(-D,0);pair=mass[i]*mass[j]/(e*e) if e else F(0);psi=1 if mask=='all' else 0 if mask=='none' else (i+j)%2
        GB+=D*pair;R+=psi*(theta*Dpos-Dneg)*pair;GBunmasked+=(1-psi)*D*pair;GBcapture+=psi*(1-theta)*Dpos*pair
    for i in E:
      for j in B:
        D=k[i]-k[j];pair=mass[i]*mass[j]/(e*e) if e else F(0);EB+=D*pair;EBpos+=max(D,0)*pair;R-=max(-D,0)*pair
    corrected=derivative-EBpos-GBunmasked-GBcapture
    assert derivative==GB+EB and R==corrected
    jump=None
    if 3 in E and e>mass[3]:
      r=mass[3];after=e-r;delta=eB/after-eB/e;formula=eB*r/(e*after);assert delta==formula and delta>=0
      jump={'deleted_E_id':3,'deleted_mass':val(r,n<=16),'e_before':val(e,n<=16),'e_after':val(after,n<=16),'delta_FB':val(delta,n<=16),'jump_formula':val(formula,n<=16),'exact_equality':True,'nonnegative':True,'integral_account_sign':'subtract this positive jump from final-minus-initial when recovering continuous derivative integral'}
    vals={'e':e,'e_B':eB,'e_log_derivative':eprime,'eB_log_derivative':eBprime,'FB_log_derivative_quotient':derivative,'GB_signed_pair':GB,'EB_signed_pair':EB,'signed_density_R':R,'EB_positive_correction':EBpos,'GB_unmasked_SIGNED_D_correction':GBunmasked,'GB_capture_positive_correction':GBcapture,'corrected_rhs':corrected}
    return {'n':n,'t':rat(t),'side':side,'partition':partition,'mask':mask,'theta':rat(theta),'sources':records,'values':{name:val(x,n<=16) for name,x in vals.items()},'checks':{'quotient_derivative_equals_GB_plus_EB':derivative==GB+EB,'complete_corrected_signed_identity':R==corrected,'theta_in_range':0<=theta<=1,'zero_e_branch':e!=0 or derivative==R==0},'E_deletion_jump':jump,'interpretation':'Derivative is off thresholds or the explicitly selected one-sided derivative; arbitrary masks do not certify suffix/history admissibility.'}

# Small exact polynomial algebra for symbolic rational differentiation, no Sympy.
def trim(p):
    p=list(p)
    while len(p)>1 and p[-1]==0:p.pop()
    return p
def mul(p,q):
    out=[F(0)]*(len(p)+len(q)-1)
    for i,x in enumerate(p):
      for j,y in enumerate(q):out[i+j]+=x*y
    return trim(out)
def sub(p,q):return trim([(p[i] if i<len(p) else F(0))-(q[i] if i<len(q) else F(0)) for i in range(max(len(p),len(q)))])
def deriv(p):return trim([i*p[i] for i in range(1,len(p))] or [F(0)])
def rational_derivative(P,Q):return sub(mul(deriv(P),Q),mul(P,deriv(Q))),mul(Q,Q)
def equal_rational(P,Q,A,B):return sub(mul(P,B),mul(A,Q))==[0]
def continuous_certificate():
    a=F(1,8);lo=F(1,4);deleted=F(1,2);hi=F(3,4)
    FB=lambda t,c:t/(t+c);primitive=lambda t,c:-a/(t+c)
    pre=primitive(deleted,2*a)-primitive(lo,2*a);post=primitive(hi,a)-primitive(deleted,a);Rint=pre+post;EBint=pre
    e_before=1+2*a/deleted;r=a/deleted;eB=F(1);jump=eB*r/(e_before*(e_before-r));endpoints=FB(hi,a)-FB(lo,2*a)
    assert Rint==endpoints-jump-EBint
    symbolic=[]
    for c in (2*a,a):
      P,Q=rational_derivative([F(0),F(1)],[c,F(1)]);assert equal_rational(P,Q,[c],mul([c,F(1)],[c,F(1)]))
      U,V=rational_derivative([-a],[c,F(1)]);assert equal_rational(U,V,[a],mul([c,F(1)],[c,F(1)]))
      symbolic.append({'c':rat(c),'FB':'t/(t+c)','ordinary_derivative':'c/(t+c)^2','GB_primitive':'-a/(t+c)','GB_primitive_derivative':'a/(t+c)^2','exact_polynomial_cross_multiplication_passed':True})
    try:
      import sympy
      sympy_status={'available':True,'version':sympy.__version__}
    except ImportError as exc:
      sympy_status={'available':False,'reason':str(exc),'fallback':'Actually executed exact Fraction polynomial quotient differentiation and cross-multiplication.'}
    return {'model':'G:nu1,w=a/t,k1; B:nu1,w1,k0; E:nu1,w=a/t,k1 deleted at t=1/2. Psi=theta=1.','a':rat(a),'lo':rat(lo),'deletion':rat(deleted),'hi':rat(hi),'e_before':'1+2a/t','e_after':'1+a/t','FB_before':'t/(t+2a)','FB_after':'t/(t+a)','R_integral_exact':rat(Rint),'EB_positive_integral_exact':rat(EBint),'positive_deletion_jump_exact':rat(jump),'final_minus_initial_FB_exact':rat(endpoints),'identity_R_equals_endpoints_minus_jump_minus_EBpositive':True,'symbolic_fraction_checks':symbolic,'sympy_status':sympy_status}

def main(output):
    menus=[('initial',(1,2,4),(F(1,4),F(3,4)),('off',),('normal',),(F(0),F(1,2),F(1))),('threshold_zero_gates',(8,16),(F(1,2),),('left','right'),('normal','zero_B','zero_G','zero_E','empty_Z'),(F(0),F(1,2),F(1))),('expanded',(1000,10000),(F(3,4),),('off',),('normal','zero_E'),(F(1,4),F(1)))]
    stages=[]
    for name,ns,ts,sides,parts,thetas in menus:
      rows=[run_case(n,t,side,part,mask,theta) for n in ns for t in ts for side in sides for part in parts for mask in ('all','none','checker') for theta in thetas]
      stages.append({'stage':name,'case_count':len(rows),'cases':rows});print(name,len(rows),'exact cases passed',flush=True)
    threshold_pairs={}
    for row in stages[1]['cases']:
      key=(row['n'],row['t'],row['partition'],row['mask'],row['theta'])
      threshold_pairs.setdefault(key,{})[row['side']]=row
    for pair in threshold_pairs.values():
      assert pair['left']['values']['e']==pair['right']['values']['e'] and pair['left']['values']['e_B']==pair['right']['values']['e_B']
      assert all(a['weight_times_nu']==b['weight_times_nu'] for a,b in zip(pair['left']['sources'],pair['right']['sources']))
    result={'schema':'R223_signed_flux_exact_checks_v1','complete':True,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'arithmetic':'Fraction and arbitrary-precision integer polynomial algebra; no floating point','orientation':{'D':'k_good-k_bad','FB_derivative':'GB signed D + EB signed D','R':'GB Psi*(theta*Dplus-Dminus) - EB Dminus','correction':'FBprime - EB Dplus - GB (1-Psi)*SIGNED_D - GB Psi*(1-theta)*Dplus','unmasked_sign_note':'The unmasked term uses signed D; it is not the negative part Dminus.','jump':'Deleting E mass r gives +eB*r/[e_before*(e_before-r)]; continuous derivative account subtracts this jump.'},'stages':stages,'case_count':sum(stage['case_count'] for stage in stages),'threshold_left_right_weight_continuity_pair_count':len(threshold_pairs),'threshold_left_right_weights_and_eB_e_continuous_exact':True,'continuous_orientation_certificate':continuous_certificate(),'scope':['Finite product-clock, threshold, arbitrary gate and deletion algebra tests only.','Alpha thresholds are not certified actual C geometry; arbitrary Psi is not certified a suffix/history mask.','No original good/bad classification realizability, actual posterior input, general signed theorem or FULL closure certified.','Large rational values are recorded by canonical hex fraction SHA256 and bit lengths; recipes reproduce them.']}
    output.write_text(json.dumps(result,indent=2)+'\n')
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=HERE/'signed_flux_checks.json');args=ap.parse_args();main(args.output)
