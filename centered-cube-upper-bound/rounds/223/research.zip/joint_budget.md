# R223：原共同权下的 signed 联合账与尚未结算的位置

**状态：本稿没有证明新增的原根阶付款。** R222 的全域 hard 来源结算继续有效；本稿回到其之前的原共同来源测度，筛选 signed 路线，给出可以直接核验的全量等式。真正有利的删除项、正门损失与未获授权的 suffix 恢复价分开保留。一般目标仍是 `εX+Cε√n polylog(n)W_A`；以下恒等式不作为该目标的替代结论。

## 1. 原量、方向及允许冻结的对象

使用 R128 `proof.md` 604–650 的 RT1–4；准确负账定义和历史信用定位见本轮 `negative_contract.md`。始终写 `g∈G=S_g` 为 good 辅助源、`b∈B=D_g` 为 bad 辅助源，以避免 RT2 排版中的积分变量歧义。这里下标 g 的物理终端尺度与辅助点 g 仅在本节约定中重名；后文将终端尺度写作 `g_*`。

固定完整实际行 `r=(ω,V,j,x,y,z,history)`，保留

\[
d\mathcal T(r)=1_I1_{j(x)=j}q^{-1}p(x,y)h_{R(x)}(x-z)
 a_\omega(x,y,z)\,dx\,\beta_V(dy)\nu_V(dz),
\qquad 0\le a_\omega\le1.
\tag{JB1}
\]

外层仍有 `EΣ_{V,j}`、原 high 门和系数 `2Λ`。`p,h_R,a_ω` 对辅助时钟不变；实际尺度、接收点、历史没有从该外测度中删除。固定此行，`B,G⊂Z_{g_*}` 对辅助时钟不变，且在原 `J_far⊂[τ_j,g_*]` 上均存活。令

\[
E_t=Z_t\setminus Z_{g_*},\quad Z_t=B\sqcup G\sqcup E_t,
\quad \pi_t=\Pi_{j,V,y,t},\quad D_t(g,b)=k_t(g)-k_t(b).
\]

原正方向是 `good − bad`，不是相反方向。令 `θ_t(g,b)∈[0,1]` 等于当前尚未付款正项的全部额外门与实际余权之积：包括 FA、当前正分支、与已付浮动带的不交化及 `ρ_0`；`Ψ=1_{𝒵^c}` 另行保留。对基准未换为 `ρ_0` 的原量，可将 `ρ_0` 换回实际 `ρ`，代数相同，但不得重领已经支付的 recapture 修复费。

原存活负项只有 `ΨD^-`，不附 `θ`；原删除负项是 `E_t×B` 上的连续交通 `(k_t(e)−k_t(b))^-`，不是删除原子。其精确原范围以 `negative_contract.md` 为准。

## 2. 精确行等式：删除有利，suffix 不可免费恢复

记

\[
F_B(t)=\pi_t(B),\qquad
\mathcal P_t=\int_{G\times B}\Psi\theta D^+\,d\pi_t(g)d\pi_t(b),
\]
\[
\mathcal N_t=\int_{G\times B}\Psi D^-\,d\pi_t(g)d\pi_t(b),\qquad
\mathcal N_{E,t}=\int_{E_t\times B}(k_t(e)-k_t(b))^-\,d\pi_t(e)d\pi_t(b).
\]

在任一原禁块恒定区间，`∂log t w_t=-k_tw_t` 且

\[
\frac{dF_B}{d\log t}
 =\int_{(G\cup E_t)\times B}(k_t(v)-k_t(b))\,d\pi_t(v)d\pi_t(b).
\tag{JB2}
\]

证明：设 `m_t=∫k_tdπ_t`，则 `∂log t π_t(dv)=(m_t-k_t(v))π_t(dv)`。将其在 `B` 上积分；`B×B` 项通过交换两端精确抵消，余下即 JB2。此处是同一后验的代数，不假设 score 坐标独立，也不假设行方差为根阶。

定义三个完全实际的量

\[
\begin{aligned}
U_t&=\int_{E_t\times B}(k_t(e)-k_t(b))^+\,d\pi_t(e)d\pi_t(b),\\
S_t&=\int_{G\times B}(1-\Psi)D_t\,d\pi_t(g)d\pi_t(b),\\
R_t&=\int_{G\times B}\Psi(1-\theta)D_t^+\,d\pi_t(g)d\pi_t(b).
\end{aligned}
\]

则逐时钟严格有

\[
\mathcal P_t-\mathcal N_t-\mathcal N_{E,t}
 =\frac{dF_B}{d\log t}-U_t-S_t-R_t.
\tag{JB3}
\]

只需用 `θD^+−D^-=D−(1−θ)D^+`，再用 `D−D^+=−D^-`。没有为负项配置正项的 η，没有放掉 signed integrand 上的 `Ψ`。

原有限路径的禁块右连续、只有有限跳且跳间恒定（R117 JG1、JG8）。在时刻 `s` 删除来源的未归一化质量记为 `d_s`，删除前总质量为 `e_{s-}`。由于 `B⊂Z_{g_*}` 没有被删，且 `w_t` 连续，

\[
\Delta F_B(s)
 =F_B(s-)\frac{d_s}{e_{s-}-d_s}\ge0.
\tag{JB4}
\]

只在原 `e_s>0` 的时钟域使用此式。对原 `J_far` 的有限闭截断 `[l,r]`，按实际端点约定，JB3 积分得到

\[
\begin{aligned}
\int_l^r(\mathcal P_t-\mathcal N_t-\mathcal N_{E,t})\frac{dt}{t}
={}&F_B(r)-F_B(l)-\sum_{s\in(l,r]}\Delta F_B(s)\\
&-\int_l^rU_t\frac{dt}{t}
-\int_l^rS_t\frac{dt}{t}
-\int_l^rR_t\frac{dt}{t}.
\end{aligned}
\tag{JB5}
\]

开放端取原域内极限。原 heavy 域为初始区间，`J_far` 再与 `[τ_j,h]` 相交仍是区间；不存在将多个免费初始边界合并为一个的问题。如果另行加入非时间独立筛选，必须按其实际区间重新列端点，不能沿用一个 JB5。

**方向后果。** 删除跳、未来源正交通 `U`、未领取的正门损失 `R` 都以负号出现，可保留为实际抵消；删除本身不构成这个 bad 势能的正费用。唯一非定号的内部项为 `S`。对 signed 恢复项可用的安全非负上界为

\[
\int_l^r\!\int_{G\times B}(1-\Psi)(k_t(b)-k_t(g))^+\,d\pi_t(g)d\pi_t(b)\frac{dt}{t}.
\tag{JB6}
\]

它是 suffix 补集上的原反向交通，是 −∫S 的上界而非一般等式，也不是新的可用负信用。该区域历史上已用的 `N_𝒵` 不能再贷给 JB5；亦不能凭 `0≤Ψ≤1` 将 signed `ΨD` 放大为 `D`。

## 3. 完整来源回代与 R222 半密度的边界

将 JB5 乘原 `1_high dT`、再乘 `2Λ` 并作原期望及 `Σ_{V,j}`，就是完整原 signed 母账的精确分解。有限交通截断下先分别积分正负有限项；无限截断的通过仍须使用原账相应的极限规程，而非对未证可积 signed 函数擅用 Tonelli。

因此可合法研究的全局联合式是

\[
2\Lambda\,\mathbb E\sum_{V,j}\int1_{\rm high}d\mathcal T\,
\left\{F_B(r)-F_B(l)-\sum\Delta F_B
-\int(U_t+S_t+R_t)\frac{dt}{t}\right\}.
\tag{JB7}
\]

原 `dx,β,ν_z,a_ω,p,h_R,q^{-1}`、两份依赖同一 `y` 的 `Π_t`、bad 端、clock、比例带、capture/history 均在 JB7 内。没有将 `βΠ_t^2` 拆开，也没有使用 `ν≤β`。

R222 的 `η` 是在**正项已采用 good 半密度上界后**的真实 hard 来源条件平均。其 `H_R/q≤16/3` 只能施于对应非负正项，不能把 JB7 中不同门的负项换成同一个 η，更不能用正的 `16/3` 常数乘一个可能负的后验平均而保持上界方向。故有两条各自合法但不能免费拼接的路线：

- 保留 R222 SOCC11 的半密度、两份 Π 与实际 η，直接付其正联合项；此时负账仍未领取。
- 保留 JB1 的共同原测度并使用 JB7；此时必须实际控制边界与 JB6，或证明它们被 JB5 内仍保留的非负 reserve 抵消。

这不是新 Schur 假设，也没有将未付量取一个常数名称后宣称其有界。

## 4. 本轮筛选结果及最早尚缺步骤

FIRST 只给同一当前 `x` 的 `∫pβ≤q`、`∫Q_x^*ν≤q` 与 high 上的 `∫β/e_t≤1/(2K)`。这些事实没有单独控制 JB7 的 `F_B(r)-F_B(l)`：该边界仍由相同 `y` 的归一化后验及自适应接收参数决定。逐行使用 `F_B≤1` 也未将原外测度结算为所需 `εX` 或根阶来源价。

R170 已证明：在完整 signed 分支、时间独立共同筛选、必要排序/suffix 资格成立且活跃终端来源满足 `w_initial/w_g≤e^M` 时，终端 good 测试的边界及相应删除合并费用为 `(16Λ/9)e^M W_β`；`M≤(log n)/2` 时为根阶。本稿不将此已知条件分支改称新的全域付款，也不将其套到任意 `θ(t,g,b)`。

当前最早需要的新实际证明有两个相接的部分：保原接收来源积分，使 JB7 的**边界与 suffix 补集反向交通**一并受控；或利用实际 capture/history，将其正部与 `ΣΔF_B+∫U+∫R` 作一次合法净结算。现有合同没有授予这一比较。尤其 `R` 只在 `Ψ` 区，而 JB6 在 `1−Ψ` 区，二者不能点态相减后声称抵消；必须来自真实跨时钟或跨来源结构。本稿没有得到该结构，因此未领取新的原预算，也未消费任何负信用。

## 5. 实际本机核验

本轮实际运行本机 Python `fractions.Fraction`，对四原子后验（一个 bad、两个 good、一个未来删除源）执行精确有理核验。权重向量为 `(1,2,3,4)`、`(4,1,2,1)`、`(2,5,1,3)`；四个 score 各遍历 `{0,1,2}`；两个 Ψ 与两个 θ 各遍历 `{0,1/2,1}`。总计 **19,683** 个逐点 JB3 精确等式全部通过。再删除未来原子，**3** 个 JB4 精确等式全部通过。Ψ 的中间值仅扩大代数测试范围；原 Ψ 仍是指示函数。

该计算只检查符号、系数与归一化代数，不认证四原子数据是原立方体输入，不验证 suffix 付款，也不提供全局预算。一般证明是上文显式代数；没有把有限核测试写成几何定理。

交付：准确保留原 signed 联合账与有利删除项，明确最早未付的边界/suffix 比较。一般根阶目标未闭合；本轮无新增已付分支。
