#!/usr/bin/env python3
"""True outer-pair Gram, reused old prices and exact marginal matching."""
import argparse
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
from itertools import combinations_with_replacement, product
import json
from pathlib import Path
import platform
import subprocess
import sys


DEPENDENCIES = {
    'ranks807.py':'50b2ad9c53ccdd94b5c4ccf84b0827e71642152983390cb7cb2f87468edacf9e',
    'ranks807.json':'b35edff1c0c8d097197f5a7017691a71dfcc859ee4fc9e1a57703dfb80bcabac',
    'reverse805.py':'c9a810c2807fa592e0fc76c514738522d8414d2e01c548579856e64d8b7fb17e',
    'reverse805.json':'955de184b852e78a2913ca9e1865404afa746c0425a920c3aa80bf9896dad886',
    'shared805.py':'d35faf62af4a6498cfaff0bd8ce1b59ebdd870143847660c67f02aa0aa10ceab',
}


def total(x):
    return sum(x,F(0))


def ith(mask,i):
    return (mask>>i)&1


def aggregate(masses,relevant):
    out=defaultdict(F)
    for m,w in masses.items():
        if w:
            out[m&relevant]+=w
    return dict(sorted(out.items()))


def restrict_measure(m,name):
    normalizer=total(m.values())
    assert normalizer>0, name
    return {k:w/normalizer for k,w in m.items() if w}


def table_of_h(coefficients,q_cells,y_cells,z_cells):
    H={}
    for x in product(q_cells,y_cells):
        q,y=x
        pairs={t_u:w for t_u,w in coefficients.items() if ith(q,t_u[0]) and ith(y,t_u[1])}
        H[x]={z:total(w for (t,u),w in pairs.items() if ith(z,t) and ith(z,u)) for z in z_cells}
    return H


def gram_totals(H,outer,z_mass):
    """Independent old-price and outer-pair orientations of the same operator."""
    X=[x for x,w in outer.items() if w and any(H[x].values())]
    Z=[z for z,w in z_mass.items() if w and any(H[x][z] for x in X)]
    cols={z:{x:H[x][z] for x in X if H[x][z]} for z in Z}
    rows={x:{z:H[x][z] for z in Z if H[x][z]} for x in X}
    if not X or not Z:
        return None
    trace_outer=total(outer[x]*total(z_mass[z]*v*v for z,v in rows[x].items()) for x in X)
    trace_price=total(z_mass[z]*total(outer[x]*v*v for x,v in cols[z].items()) for z in Z)
    HS_out=F(0)
    for x,xx in combinations_with_replacement(X,2):
        live=rows[x].keys()&rows[xx].keys()
        K=total(z_mass[z]*rows[x][z]*rows[xx][z] for z in live)
        HS_out+=(1 if x==xx else 2)*outer[x]*outer[xx]*K*K
    HS_old=F(0)
    for z,zz in combinations_with_replacement(Z,2):
        live=cols[z].keys()&cols[zz].keys()
        K=total(outer[x]*cols[z][x]*cols[zz][x] for x in live)
        HS_old+=(1 if z==zz else 2)*z_mass[z]*z_mass[zz]*K*K
    assert trace_outer==trace_price>0 and HS_out==HS_old>0
    assert HS_out<=trace_outer**2
    return dict(trace_hh_star_by_outer=trace_outer,trace_hstar_h_by_old=trace_price,
                HS_squared_by_outer=HS_out,HS_squared_by_old_price=HS_old,
                live_outer_count=len(X),live_old_price_count=len(Z),
                live_graph_outer_old_mass=total(outer[x]*z_mass[z] for x in X for z in rows[x]))


def matched_marginals(q,y,sq,sy):
    qr=sorted(q,key=lambda x:(-sq[x],x))
    yr=sorted(y,key=lambda x:(-sy[x],x))
    i=j=0
    a,b=q[qr[0]],y[yr[0]]
    out={}
    while i<len(qr) and j<len(yr):
        weight=min(a,b)
        assert weight>0
        out[qr[i],yr[j]]=weight
        a,b=a-weight,b-weight
        if not a:
            i+=1
            if i<len(qr):
                a=q[qr[i]]
        if not b:
            j+=1
            if j<len(yr):
                b=y[yr[j]]
    assert i==len(qr) and j==len(yr)
    assert all(total(w for (x,z),w in out.items() if x==v)==m for v,m in q.items())
    assert all(total(w for (x,z),w in out.items() if z==v)==m for v,m in y.items())
    return out


def spectral_and_area(H,outer,z_mass):
    assert total(outer.values())==1
    result=gram_totals(H,outer,z_mass)
    if not result:
        return None
    tr=result['trace_hh_star_by_outer']
    HS=result['HS_squared_by_outer']
    rayleigh=total(w*total(m*H[x][z] for x,m in outer.items())**2 for z,w in z_mass.items())
    assert 0<rayleigh and rayleigh**2<=HS<=tr**2
    return dict(**result,constant_unit_vector_Rayleigh=rayleigh,
                normalized_operator_norm_lower=rayleigh/tr,
                normalized_operator_norm_upper_bound_squared=HS/tr**2,
                live_area_probability=result['live_graph_outer_old_mass']/total(z_mass.values()))


def exact_occurrence(witness,middle_mask,small_mask):
    points=witness['points']
    q=[points[v]['actual_parent_membership_mask']&middle_mask for v in ('q1','q2')]
    y=[points[v]['actual_parent_membership_mask']&small_mask for v in ('y1','y2')]
    z=points['z']['actual_parent_membership_mask']&(middle_mask|small_mask)
    q_w=[F(points[v]['actual_chi_subbox_mass']) for v in ('q1','q2')]
    y_w=[F(points[v]['actual_mu_subbox_mass']) for v in ('y1','y2')]
    assert all(v>0 for v in q_w+y_w)
    h=[F(v) for v in witness['true_corner_h']]
    assert len(h)==4 and min(h)>0
    return q,y,z,q_w,y_w


def local_pairing(H,occurrence,z_mass):
    q,y,z,q_w,y_w=occurrence
    l=restrict_measure(dict(enumerate(q_w)),'true q boxes')
    r=restrict_measure(dict(enumerate(y_w)),'true y boxes')
    prod_law={(i,j):l[i]*r[j] for i,j in product(l,r)}
    match=matched_marginals(l,r,{0:F(1),1:F(0)},{0:F(1),1:F(0)})
    merged=[]
    for p in (prod_law,match):
        by_outer=defaultdict(F)
        for (i,j),w in p.items():
            by_outer[q[i],y[j]]+=w
        merged.append(dict(by_outer))
    got=[spectral_and_area(H,p,z_mass) for p in merged]
    means=[total(w*H[x][z] for x,w in p.items()) for p in merged]
    alternating=H[q[0],y[0]][z]-H[q[0],y[1]][z]-H[q[1],y[0]][z]+H[q[1],y[1]][z]
    assert means[1]-means[0]==(match.get((0,0),0)-prod_law[0,0])*alternating
    if q[0]==q[1] or y[0]==y[1]:
        assert merged[0]==merged[1] and got[0]==got[1]
    return dict(same_q_family_membership=q[0]==q[1],same_y_family_membership=y[0]==y[1],
         preserved_q_box_probability=list(l.values()),preserved_y_box_probability=list(r.values()),
         two_box_independent=got[0],two_box_same_index_match=got[1],
         old_price_at_z_independent_mean=means[0],old_price_at_z_paired_mean=means[1],
         old_price_at_z_paired_minus_independent=means[1]-means[0],alternating_four_outer_values_at_true_z=alternating)


def alternate_legal_y(stage,witness,occurrence,small_mask,physical,model,old,ranks):
    """Stay in the frozen second right state, with a different real exterior voxel."""
    q,y,z,q_w,y_w=occurrence
    if q[0]==q[1]:
        return None
    _,boxes,mu,_,_=physical
    u,owner_half,allowed=witness['encoded_rights'][1]
    U=old.box(stage['small_cubes'][u]['G'])
    middles=witness['encoded_lefts'][0][1],witness['encoded_lefts'][1][1]
    halos=[old.box(stage['middle_cubes'][t]['hat']) for t in middles]
    avoid=[tuple(map(F,x['price_point'])) for k,x in witness['points'].items() if k!='y2']
    for row in stage['alternation']['source_atoms']:
        types=[stage['by_t_u'][k] for k in row['active_types']]
        active=sorted(t['t'] for t in types if t['u']==u)
        if active!=allowed:
            continue
        B=old.box(row['representative_cell'])
        x,Q=ranks.point_and_subbox(B,boxes+halos+[U],model,avoid=avoid)
        y_mask=sum(1<<i for i,A in enumerate(boxes) if ranks.strict_contains(x,A))&small_mask
        if y_mask==y[0]:
            continue
        assert model.inside(Q,U) and all(model.volume(model.clip(Q,H))==0 for H in halos)
        real=mu(Q)
        assert real>0
        return (q,[y[0],y_mask],z,q_w,[y_w[0],real]),dict(
            same_encoded_right=witness['encoded_rights'][1],true_legal_y2=x,positive_y2_subbox=Q,
            new_small_membership=y_mask,original_small_membership=y[1],frozen_middle_halos_disjoint=middles,
            unchanged_true_four_corner_h=witness['true_corner_h'])
    return None


def shared_prices(H,occurrence,z_mass,known_u):
    q,y,z,_,_=occurrence
    A={'11':(q[0],y[0]),'12':(q[0],y[1]),'21':(q[1],y[0]),'22':(q[1],y[1])}
    at_origin={k:H[x][z] for k,x in A.items()}
    if not (at_origin['11']*at_origin['22']):
        return dict(status='At least one true observed diagonal is excluded by this additional public hard screen.',
                    public_values_at_frozen_true_z=at_origin)
    cases={}
    for name,src in [('full_source',z_mass),('same_known_small_parent',{z:w for z,w in z_mass.items() if ith(z,known_u)})]:
        P=restrict_measure(src,name)
        def two(a,b):
            common=total(P[z]*H[A[a]][z]*H[A[b]][z] for z in P)
            ind=total(P[z]*H[A[a]][z] for z in P)*total(P[z]*H[A[b]][z] for z in P)
            nonzero=total(P[z] for z in P if H[A[a]][z] and H[A[b]][z])
            ratio=common/ind if ind else None
            assert common>0 or nonzero==0
            return dict(reused_one_z=common,two_independent_z=ind,common_positive_source_probability=nonzero,
                        common_over_independent=ratio)
        cases[name]=dict(true_reference_mass=total(src.values()),frozen_actual_diagonal=two('11','22'),
                         crossed_actual_outer_pairs=two('12','21'))
    return dict(status='Both actual diagonals have positive public h at the frozen true z.',
                public_values_at_frozen_true_z=at_origin,comparisons=cases)


def example(stage,previous,model,old,ranks):
    physical=ranks.physical_atoms(stage,model,old)
    parents,boxes,mu,base,_=physical
    w=previous['fixed_original_anchor_witness']
    M,D=F(w['central_bin']),F(w['small_bin'])
    T,U=stage['middle_cubes'],stage['small_cubes']
    N=len(T)
    mt=[t for t in range(N) if M<=F(T[t]['m'])<2*M]
    sm=[N+u for u in range(len(U)) if D<=F(U[u]['m'])<2*D]
    tm=sum(1<<t for t in mt)
    um=sum(1<<u for u in sm)
    z=aggregate(base['mu'],tm|um)
    q=aggregate(base['chi'],tm)
    y=aggregate(base['mu'],um)
    coeff={}
    ratio={}
    j_over_m2={v:F(p['j'])/F(p['m'])**2 for v,p in enumerate(parents)}
    original={(t['t'],N+t['u']):t for t in stage['by_t_u']}
    for t,u in product(mt,sm):
        mu_overlap=mu(model.clip(boxes[t],boxes[u]))
        assert mu_overlap/F(parents[u]['m'])==F(original[t,u]['q_true'])
        if mu_overlap>0 and F(parents[u]['m'])<F(parents[t]['m']):
            ratio[t,u]=mu_overlap/F(parents[u]['m'])
            coeff[t,u]=j_over_m2[t]*j_over_m2[u]
    assert coeff
    quantiles=sorted(ratio.values())
    threshold=quantiles[(len(ratio)-1)//2]
    upper_threshold=quantiles[(3*len(ratio)-1)//4]
    strict={a:c for a,c in coeff.items() if ratio[a]<threshold}
    strict_upper={a:c for a,c in coeff.items() if ratio[a]<upper_threshold}
    full=table_of_h(coeff,q,y,z)
    occurrence=exact_occurrence(w,tm,um)
    alternative=alternate_legal_y(stage,w,occurrence,um,physical,model,old,ranks)
    q0,y0,z0,_,_=occurrence
    assert all(m in q for m in q0) and all(m in y for m in y0) and z0 in z
    max_q={k:total(j_over_m2[t] for t in mt if ith(k,t) and ith(z0,t)) for k in q}
    max_y={k:total(j_over_m2[u] for u in sm if ith(k,u) and ith(z0,u)) for k in y}
    qprob,yprob=restrict_measure(q,'outer chi'),restrict_measure(y,'outer mu')
    matched=matched_marginals(qprob,yprob,max_q,max_y)
    indep={x:qprob[x[0]]*yprob[x[1]] for x in full}
    outer={x:q[x[0]]*y[x[1]] for x in full}
    assert total(outer.values())==total(base['chi'].values())*total(base['mu'].values())
    for (v,w0),z_row in full.items():
        for zz,h in z_row.items():
            middle=total(j_over_m2[t] for t in mt if ith(v,t) and ith(zz,t))
            small=total(j_over_m2[u] for u in sm if ith(w0,u) and ith(zz,u))
            assert h==middle*small
    known_u=N+previous['fixed_original_anchor_witness']['encoded_rights'][0][0]
    runs=[]
    choices=[('full_public_geometry',coeff,full),('strict_lower_median',strict,table_of_h(strict,q,y,z)),
             ('strict_lower_than_upper_quartile',strict_upper,table_of_h(strict_upper,q,y,z))]
    for name,cs,H in choices:
        full_gram=gram_totals(H,outer,z)
        if not full_gram:
            continue
        normal_ind=spectral_and_area(H,indep,z)
        raw_weight=total(outer.values())
        assert full_gram['trace_hh_star_by_outer']==raw_weight*normal_ind['trace_hh_star_by_outer']
        assert full_gram['HS_squared_by_outer']==raw_weight**2*normal_ind['HS_squared_by_outer']
        matched_result=spectral_and_area(H,matched,z)
        if alternative:
            alt_occurrence,alt_source=alternative
            alt_test=dict(alt_source,comparison=local_pairing(H,alt_occurrence,z))
            if name=='full_public_geometry':
                local=alt_test['comparison']
                assert local['old_price_at_z_paired_minus_independent']!=0
                ind_loc,match_loc=local['two_box_independent'],local['two_box_same_index_match']
                assert ind_loc['live_area_probability']==match_loc['live_area_probability']
                assert ind_loc['normalized_operator_norm_lower']<match_loc['normalized_operator_norm_lower']
        else:
            alt_test=None
        runs.append(dict(name=name,number_physical_pairs=len(cs),outer_weight_once=raw_weight,
                         exact_full_geom_Gram=full_gram,real_square_shared_old_prices=shared_prices(H,occurrence,z,known_u),
                         original_witness_two_box_pairing=local_pairing(H,occurrence,z),
                         local_pairing_with_another_true_external_subbox_in_same_right_state=alt_test,
                         normalized_full_independent=normal_ind,normalized_full_rank_matched=matched_result,
                         public_positive_edges_that_are_not_full_separable=sum(H[x][zz]!=full[x][zz] for x in H for zz in z)))
    return dict(stage=stage['stage'],dimension=stage['n'],middle_M=M,small_D=D,matching_score_root_from_frozen_z=occurrence[2],
        full_q_chi_class_masses=q,full_y_mu_class_masses=y,full_z_mu_class_masses=z,
        original_frozen_true_square_source_points={k:b['price_point'] for k,b in w['points'].items()},
        original_frozen_true_four_corner_h=w['true_corner_h'],
        strict_quantile_gate=dict(kind='strictly below lower median of true positive intersection proportion',threshold=threshold,
            tied_at_threshold=sum(v==threshold for v in ratio.values()),
            true_ratios_by_physical_pair=[dict(t=t,u=u-N,q=x,passes_strict=x<threshold) for (t,u),x in sorted(ratio.items())]),
        strict_upper_quartile_gate=dict(kind='strictly below nearest-rank true positive 3/4 quantile',
           threshold=upper_threshold,tied_at_threshold=sum(v==upper_threshold for v in ratio.values()),
           included_physical_pairs=[(t,u-N) for t,u in sorted(strict_upper)]),
        full_physical_marginal_score_matching=[dict(q=x[0],y=x[1],mass=m) for x,m in matched.items()],runs=runs)


def main():
    here=Path(__file__).resolve().parent
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--r805-dir',type=Path,default=here)
    p.add_argument('--r807-dir',type=Path,default=here)
    group=p.add_mutually_exclusive_group()
    group.add_argument('--output',type=Path)
    group.add_argument('--check',type=Path)
    args=p.parse_args()
    r5,r7=args.r805_dir.resolve(),args.r807_dir.resolve()
    for f,h in DEPENDENCIES.items():
        if f!='reverse805.json':
            assert sha256(((r5 if '805' in f else r7)/f).read_bytes()).hexdigest()==h
    sys.path[:0]=[str(r7),str(r5)]
    import reverse805 as model
    import shared805 as old
    import ranks807 as ranks
    frozen=r5/'reverse805.json'
    raw=frozen.read_bytes() if frozen.is_file() else subprocess.check_output([sys.executable,'-B',str(r5/'reverse805.py')])
    assert sha256(raw).hexdigest()==DEPENDENCIES['reverse805.json']
    reports=[]
    for stage,w in zip(json.loads(raw)['stages'],json.loads((r7/'ranks807.json').read_text())['stages'],strict=True):
        assert stage['stage']==w['stage']
        reports.append(example(stage,w,model,old,ranks))
    assert any(r['normalized_full_rank_matched'] and
               r['normalized_full_rank_matched']['normalized_operator_norm_lower']!=r['normalized_full_independent']['normalized_operator_norm_lower']
               for s in reports for r in s['runs'])
    payload=dict(runtime=dict(python=platform.python_version(),architecture=platform.machine(),arithmetic='Fraction exact'),
        dependencies=DEPENDENCIES,reproduction='python -B pairs808.py --check pairs808.json',stages=reports,
        scope=dict(support='Frozen real physical families and same (M,D) for the three actual R807 right-anchor squares. No new anchor or source point selection. The public h uses G=A. Its outer reference is chi(dq)mu(dy) and old-price reference is mu(dz).',
            hard='True intersection fraction relative to m_small. Two finite hard proxies retain strictly below the nearest-rank quantile at 1/2 and 3/4, across the same positive geometric pairs. Empty operator cases have no recorded quadratic claim.',
            shared='A shared z product is compared to two independent z draws under exactly the same stated probability reference, either full mu or mu restricted to the common known small parent. This checks the public kernel on real point combinations, with original corners independently pinned, without treating h as the entire original path gate.',
            matching='Two actual q/y subboxes preserve their own normalized raw chi/mu marginals. The optional local variant uses a different genuine y2 subbox in the same frozen second right state, preserving z, q, first anchor, all owner marks and all four original gates. For nontrivial outer dependence, a full-support geometric comparison couples the original probability marginals by ordered co-parent scores at the same frozen z. It is a geometric diagnostic and does not add claims about an original gated transport.',
            spectral='Rayleigh on the constant unit outer vector is a rigorous lower bound on lambda_max. The squared HS norm is its squared upper bound. Both normalized against the trace. Live area is the normalized product of the chosen outer law and mu(dz) over h>0.',
            limit='Finite 1/2/3-dimensional true source masks, with stated diagnostic G=A and hard proxy. No high-dimensional residual gate or bound is inferred.'))
    text=json.dumps(payload,sort_keys=True,indent=2,default=str)+'\n'
    if args.output:
        args.output.write_text(text)
    if args.check:
        assert args.check.read_text()==text
    if args.output or args.check:
        for s in reports:
            for r in s['runs']:
                G=r['exact_full_geom_Gram']; C=r['real_square_shared_old_prices']; c=r['normalized_full_rank_matched']
                print(s['stage'],r['name'],r['number_physical_pairs'],'tr,HS²',format(float(G['trace_hh_star_by_outer']),'.7g'),
                      format(float(G['HS_squared_by_outer']),'.7g'), 'shared ratio',
                      format(float(C['comparisons']['same_known_small_parent']['frozen_actual_diagonal']['common_over_independent']),'.7g') if 'comparisons' in C else 'hard excludes witness',
                      'areas product,matched',format(float(r['normalized_full_independent']['live_area_probability']),'.7g'),
                      format(float(c['live_area_probability']),'.7g') if c else None)
        if args.check:
            print('byte-identical')
    else:
        print(text,end='')


if __name__=='__main__':
    main()
