#!/usr/bin/env python3
"""Exact same-price rectangle marginals and source-pocket occupancy."""
import argparse
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
from itertools import product
import json
from pathlib import Path
import platform
import subprocess
import sys


DEPENDENCIES={
    'ranks807.json':'b35edff1c0c8d097197f5a7017691a71dfcc859ee4fc9e1a57703dfb80bcabac',
    'rectangle806.py':'04714603e8dfbc8b7fe6f1f9e431c4fd8cf9c3b671e567e34bd5315244c576be',
    'triples806.py':'203a1f2ff8c6e13b66f77ad81055e71471f87b59ae805a3037c69d4ed0e3ae98',
    'reverse805.py':'c9a810c2807fa592e0fc76c514738522d8414d2e01c548579856e64d8b7fb17e',
    'reverse805.json':'955de184b852e78a2913ca9e1865404afa746c0425a920c3aa80bf9896dad886',
    'shared805.py':'d35faf62af4a6498cfaff0bd8ce1b59ebdd870143847660c67f02aa0aa10ceab',
}


def total(x):
    return sum(x,F(0))


def mask_contains(mask,u):
    return (mask>>u)&1


def square_marginals(H,Ht,lx,ra):
    raw_by_x,right_by_x={},{}
    all_x=[x for x in H if x[0]==0]
    for x in all_x:
        pool=defaultdict(F)
        orig=defaultdict(F)
        for a,h in H[x].items():
            closure=total(lx[xx]*hx*total(ra[aa]*H[x][aa]*H[xx][aa] for aa in H[x].keys()&H[xx].keys())
                          for xx,hx in Ht[a].items())
            assert closure>0
            u=a[0]
            pool[u]+=ra[a]*h*closure
            orig[u]+=ra[a]*h
        right_by_x[x]=dict(pool)
        raw_by_x[x]=dict(orig)
    square=total(lx[x]*total(right_by_x[x].values()) for x in all_x)
    by_gram=total(lx[x]*lx[xx]*total(ra[a]*H[x][a]*H[xx][a] for a in H[x].keys()&H[xx].keys())**2
                 for x,xx in product(all_x,H))
    assert square==by_gram>0
    raw=total(lx[x]*total(raw_by_x[x].values()) for x in all_x)
    assert raw>0
    return right_by_x,raw_by_x,square,raw


def real_b_rows(stage,witness,marks,right_by_x,raw_by_x,mu,model,old):
    grouped=defaultdict(list)
    for x in right_by_x:
        _,t,g,_,W=x
        grouped[g,W].append(x)
    cell_rows=[]
    for (g,W),keys in sorted(grouped.items()):
        B={x:marks[x[1]][x[2:]]['price'] for x in keys}
        owner=marks[keys[0][1]][keys[0][2:]]['owner']
        assert all(marks[x[1]][x[2:]]['owner']==owner for x in keys)
        axes=[]
        for d in range(stage['n']):
            cuts=sorted({edge for box in B.values() for edge in box[d]})
            axes.append([(a,b) for a,b in zip(cuts,cuts[1:])])
        for q_cell in product(*axes):
            true_x=[x for x in keys if model.inside(q_cell,B[x])]
            if not true_x:
                continue
            assert len({x[1] for x in true_x})==len(true_x)
            cell_x_mass=mu(q_cell)*model.volume(owner)
            assert cell_x_mass>0
            p=defaultdict(F)
            p_raw=defaultdict(F)
            t_weight=defaultdict(F)
            for x in true_x:
                for u,w in right_by_x[x].items():
                    p[u]+=cell_x_mass*w
                    t_weight[x[1]]+=cell_x_mass*w
                for u,w in raw_by_x[x].items():
                    p_raw[u]+=cell_x_mass*w
            Wb,raw=total(p.values()),total(p_raw.values())
            assert Wb==total(t_weight.values())>0 and raw>0
            P={u:w/Wb for u,w in p.items()}
            Q={u:w/raw for u,w in p_raw.items()}
            assert total(P.values())==total(Q.values())==1
            cell_rows.append(dict(b=len(cell_rows),physical_g=g,true_q_cell=q_cell,true_W_half=owner,owner_half_id=W,
                outer_reference_mass=cell_x_mass,square_first_edge_mass=Wb,raw_original_edge_mass=raw,
                conditional_u_after_actual_square=P,conditional_u_after_original_first_edge=Q,
                conditional_hidden_middle={t:w/Wb for t,w in t_weight.items()},
                square_vs_original_conditional_u_total_variation=total(abs(P.get(u,0)-Q.get(u,0)) for u in P.keys()|Q.keys())/2))
    seen=[]
    for x in witness['encoded_lefts']:
        _,t,g,_,W=x
        which=len(seen)+1
        point=tuple(map(F,witness['points'][f'q{which}']['price_point']))
        matches=[b['b'] for b in cell_rows if b['physical_g']==g and b['owner_half_id']==W and
                 all(a<=z<=c for z,(a,c) in zip(point,b['true_q_cell']))]
        assert matches
        seen.append(matches)
    return cell_rows,seen


def pocket_atoms(stage,model,old,mu):
    G=[old.box(u['G']) for u in stage['small_cubes']]
    n=stage['n']
    open_axes=[]
    closed_axes=[]
    for d in range(n):
        cuts=sorted({-model.SUPPORT,model.SUPPORT,*(u for B in G for u in B[d])})
        intervals=[]
        samples=set(cuts)
        for a,b in zip(cuts,cuts[1:]):
            c=(a+b)/2
            samples.add(c)
            mask=sum(1<<u for u,B in enumerate(G) if B[d][0]<c<B[d][1])
            intervals.append((mask,mu(((a,b),)) if d==0 else b-a))
        open_axes.append(intervals)
        closed_axes.append([(v,sum(1<<u for u,B in enumerate(G) if B[d][0]<=v<=B[d][1]))
                            for v in sorted(samples)])
    cell=defaultdict(F)
    full=(1<<len(G))-1
    for data in product(*open_axes):
        mask=full
        w=F(1)
        for m,v in data:
            mask &= m
            w *= v
        cell[mask]+=w
    closed={}
    for data in product(*closed_axes):
        mask=full
        for _,m in data:
            mask &= m
        closed.setdefault(mask,tuple(q for q,_ in data))
    actual=[mu(B) for B in G]
    inter=[[mu(model.clip(A,B)) for B in G] for A in G]
    for u,v in product(range(len(G)),repeat=2):
        assert inter[u][v]==total(w for m,w in cell.items() if mask_contains(m,u) and mask_contains(m,v))
    assert all(x>0 for x in actual) and all(inter[u][u]==x for u,x in enumerate(actual))
    return G,cell,closed,actual,inter,cell.get(full,F(0)),closed.get(full)


def compare_occupation(rows,geometry,D):
    _,atoms,closed,mass,inter,_,_=geometry
    Ps=[r['conditional_u_after_actual_square'] for r in rows]
    loads=[]
    for P in Ps:
        def at_mask(m):
            return total(w for u,w in P.items() if mask_contains(m,u))
        cap,mask=max((at_mask(m),m) for m in closed)
        essential=max(at_mask(m) for m in atoms)
        assert 0<essential<=cap<=1
        loads.append(dict(cap=cap,essential_sup=essential,cap_witness=closed[mask],point_load={m:at_mask(m) for m in atoms}))
    pairs=[]
    for i,j in product(range(len(rows)),repeat=2):
        P,Q=Ps[i],Ps[j]
        cap=loads[j]['cap']
        g=loads[j]['point_load']
        by_labels=total(p*q*inter[u][v]/mass[u] for (u,p),(v,q) in product(P.items(),Q.items()))
        by_mu=total(w*g[m]*total(p/mass[u] for u,p in P.items() if mask_contains(m,u)) for m,w in atoms.items())
        D_scaled=total(p*q*inter[u][v]/D for (u,p),(v,q) in product(P.items(),Q.items()))
        D_spatial=total(w*g[m]*total(p/D for u,p in P.items() if mask_contains(m,u)) for m,w in atoms.items())
        prefactor=total(p*mass[u]/D for u,p in P.items())
        assert 0<by_labels==by_mu<=loads[j]['essential_sup']<=cap
        assert 0<D_scaled==D_spatial<=prefactor*cap<=max(mass)/D*cap
        pairs.append(dict(b1=i,b2=j,expectation=by_labels,by_one_common_mu_integral=by_mu,
                          supremum_target=cap,ratio_expectation_to_supremum=by_labels/cap,
                          overlap_over_small_bin_D=D_scaled,by_one_common_mu_integral_over_D=D_spatial,
                          actual_row_mass_factor_bound=prefactor*cap))
    n=len(rows)
    assert n>1
    mother=total(row['square_first_edge_mass'] for row in rows)
    priors={i:r['square_first_edge_mass']/mother for i,r in enumerate(rows)}
    assert total(priors.values())==1
    blind=defaultdict(F)
    for b,P in enumerate(Ps):
        for u,p in P.items():
            blind[u]+=priors[b]*p
    blind_value=total(p*q*inter[u][v]/mass[u] for (u,p),(v,q) in product(blind.items(),repeat=2))
    actual_same=total(priors[x['b1']]*priors[x['b2']]*x['expectation'] for x in pairs if x['b1']==x['b2'])
    actual_different=total(priors[x['b1']]*priors[x['b2']]*x['expectation'] for x in pairs if x['b1']!=x['b2'])
    assert actual_same+actual_different==blind_value
    offdiag=[x for x in pairs if x['b1']!=x['b2']]
    best=min(offdiag,key=lambda x:x['ratio_expectation_to_supremum'])
    largest=max(offdiag,key=lambda x:x['ratio_expectation_to_supremum'])
    lookup={(t['b1'],t['b2']):t['expectation'] for t in pairs}
    diff,i,j=max((abs(v-lookup[b,a]),a,b) for (a,b),v in lookup.items() if a!=b)
    pair_rows=[(p['b1'],p['b2'],p['expectation'],p['supremum_target'],p['overlap_over_small_bin_D'],
                p['actual_row_mass_factor_bound']) for p in pairs]
    digest=sha256(json.dumps(pair_rows,separators=(',',':'),default=str).encode()).hexdigest()
    return dict(per_b_witnessed_loads=[{k:v for k,v in a.items() if k!='point_load'} for a in loads],
        complete_ordered_pair_table_SHA256=digest,all_ordered_pair_equalities_and_bounds_checked=True,
        number_ordered_pairs=len(pairs),number_ordered_distinct_b_pairs=len(offdiag),
        min_distinct_b_ratio=best,max_distinct_b_ratio=largest,
        largest_reversal_difference=dict(b1=i,b2=j,first_denominator=lookup[i,j],second_denominator=lookup[j,i],absolute_difference=diff),
        blinded_same_mother_u=blind,blind_expectation=blind_value,
        mother_weighted_same_b_contribution=actual_same,mother_weighted_distinct_b_contribution=actual_different,
        conditional_distinct_b_expectation=actual_different/(1-total(p*p for p in priors.values())))


def example(stage,frozen,model,old,triples):
    witness=frozen['fixed_original_anchor_witness']
    M,D=F(witness['central_bin']),F(witness['small_bin'])
    Z=old.box(witness['points']['z']['positive_subbox'])
    config=triples.genuine_config(stage,model,old)
    _,marks,_,_,mu,*_=config
    H,Ht,lx,ra=triples.same_z_edges(stage,config,M,D,Z,model,old)
    left=[tuple(x) for x in witness['encoded_lefts']]
    right=[(u,r,tuple(types)) for u,r,types in witness['encoded_rights']]
    assert [H[x][a] for x,a in product(left,right)]==[F(v) for v in witness['true_corner_h']]
    qw,rw,mother,raw=square_marginals(H,Ht,lx,ra)
    rows,frozen_b=real_b_rows(stage,witness,marks,qw,rw,mu,model,old)
    assert total(b['square_first_edge_mass'] for b in rows)==mother
    assert total(b['raw_original_edge_mass'] for b in rows)==raw
    G= pocket_atoms(stage,model,old,mu)
    check=compare_occupation(rows,G,D)
    price_mu=mu(Z)
    assert price_mu==F(witness['points']['z']['actual_mu_subbox_mass'])
    return dict(stage=stage['stage'],dimension=stage['n'],M=M,D=D,
        actual_frozen_shared_old_price_cell=Z,actual_shared_price_mu=price_mu,positive_observed_b_count=len(rows),
        original_t_hidden_in_at_least_two_ways=sum(len(r['conditional_hidden_middle'])>1 for r in rows),
        frozen_g_q_W_witness_matches_b_ids=frozen_b,first_orientation=0,b_rows=rows,
        true_square_first_edge_mother_density_against_mu=mother,true_square_mother_weight_on_frozen_price_cell=mother*price_mu,
        original_first_edge_mother_density_against_mu=raw,original_first_edge_weight_on_frozen_price_cell=raw*price_mu,
        G_source_pockets=G[0],G_true_mu=G[3],G_intersection_true_mu=G[4],G_common_mu=G[5],G_common_witness=G[6],
        maximum_G_mass_over_D=max(G[3])/D,occupancy=check)


def main():
    here=Path(__file__).resolve().parent
    p=argparse.ArgumentParser(description=__doc__)
    for rr in (805,806,807):
        p.add_argument(f'--r{rr}-dir',type=Path,default=here)
    cli=p.add_mutually_exclusive_group()
    cli.add_argument('--output',type=Path)
    cli.add_argument('--check',type=Path)
    args=p.parse_args()
    paths={str(rr):getattr(args,f'r{rr}_dir').resolve() for rr in (805,806,807)}
    for name,digest in DEPENDENCIES.items():
        if name!='reverse805.json':
            code=next(k for k in paths if k in name)
            assert sha256((paths[code]/name).read_bytes()).hexdigest()==digest
    sys.path[:0]=list(map(str,paths.values()))
    import reverse805 as model
    import shared805 as old
    import triples806 as triples
    r=paths['805']/'reverse805.json'
    raw=r.read_bytes() if r.is_file() else subprocess.check_output([sys.executable,'-B',str(r.with_suffix('.py'))])
    assert sha256(raw).hexdigest()==DEPENDENCIES['reverse805.json']
    data=[]
    for st,w in zip(json.loads(raw)['stages'],json.loads((paths['807']/'ranks807.json').read_text())['stages'],strict=True):
        assert st['stage']==w['stage']
        data.append(example(st,w,model,old,triples))
    assert any(s['occupancy']['min_distinct_b_ratio']['ratio_expectation_to_supremum']<1 for s in data)
    report=dict(runtime=dict(python=platform.python_version(),architecture=platform.machine(),arithmetic='Fraction exact'),
        dependencies=DEPENDENCIES,reproduction='python -B occupancy808.py --check occupancy808.json',stages=data,
        scope=dict(original='At the actual frozen shared z subbox, every square uses all four original h corner factors with original direction marks, degrees, true price/owner factors, and legal exterior masses. The primary law is a first-edge marginal of the full actual square product, independently checked by the Gram identity. The original edge-only first law is also recorded.',
            visible='b=(g,physical true q cell, actual uniform W owner half). True q cells simultaneously refine every latent t-specific old price box. The hidden t is summed out. First orientation is fixed, while the second left arm uses both original direction copies.',
            occupancy='Each b independently redraws its actual full square record, then retains the physical u of the first right arm. Source pockets G_u are the actual positive-volume pockets from the fixture. The expectation is calculated separately from intersections and a single integral on real mu. The maximum target load includes closed boundary points. All fixture pockets share a common region, which makes the supremum attainable at one in these examples.',
            pair_table='Every ordered pair is checked. The digest seals its exact table in (b1,b2,E,sup,overlap/D,weighted bound) order. All b distributions and all physical intersection masses are given for replay.',
            mass_factor='Compare overlap/D using the actual weighted E_b[mu(G_u)/D] times the same target supremum. D is the known small-bin endpoint. The coarser maximum G mass over D is also checked.',
            limit='No new anchors or asymptotic thresholds. The original 1/2/3-dimensional physical fixtures retain their stated diagnostic path screens.'))
    text=json.dumps(report,sort_keys=True,indent=2,default=str)+'\n'
    if args.output:
        args.output.write_text(text)
    if args.check:
        assert args.check.read_text()==text
    if args.output or args.check:
        for s in data:
            q=s['occupancy']
            print(s['stage'],s['positive_observed_b_count'],q['number_ordered_distinct_b_pairs'],
                'common source mu',s['G_common_mu'],'minimum maximum distinct ratio display',
                format(float(q['min_distinct_b_ratio']['ratio_expectation_to_supremum']),'.9g'),
                format(float(q['max_distinct_b_ratio']['ratio_expectation_to_supremum']),'.9g'))
        if args.check:
            print('byte-identical')
    else:
        print(text,end='')


if __name__=='__main__':
    main()
