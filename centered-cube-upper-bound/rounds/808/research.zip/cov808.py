#!/usr/bin/env python3
"""Exact price and receiver covariances in a frozen genuine rectangle row."""
import argparse
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
from itertools import product
import json
from math import ceil, floor
from pathlib import Path
import platform
import subprocess
import sys


DEPENDENCIES={
    'ranks807.json':'b35edff1c0c8d097197f5a7017691a71dfcc859ee4fc9e1a57703dfb80bcabac',
    'rectangle806.py':'04714603e8dfbc8b7fe6f1f9e431c4fd8cf9c3b671e567e34bd5315244c576be',
    'triples806.py':'203a1f2ff8c6e13b66f77ad81055e71471f87b59ae805a3037c69d4ed0e3ae98',
    'reverse805.py':'c9a810c2807fa592e0fc76c514738522d8414d2e01c548579856e64d8b7fb17e',
    'reverse805.json':'955de184b852e78a2913ca9e1865404afa746c0425a920c3aa80bf9896dad886',
    'shared805.py':'d35faf62af4a6498cfaff0bd8ce1b59ebdd870143847660c67f02aa0aa10ceab',
}


def total(x):
    return sum(x,F(0))


def trace(A):
    return total(A[i][i] for i in range(len(A)))


def determinant(A):
    M=[row[:] for row in A]
    prod=F(1)
    for i in range(len(M)):
        k=next((r for r in range(i,len(M)) if M[r][i]),None)
        if k is None:
            return F(0)
        if k!=i:
            M[i],M[k]=M[k],M[i]
            prod=-prod
        top=M[i][i]
        prod*=top
        for r in range(i+1,len(M)):
            if M[r][i]:
                a=M[r][i]/top
                M[r][i]=F(0)
                for j in range(i+1,len(M)):
                    M[r][j]-=a*M[i][j]
    return prod


def uniform_moments(box):
    means=[(a+b)/2 for a,b in box]
    variances=[(b-a)**2/12 for a,b in box]
    assert all(a>0 for a in variances)
    return means,variances


def phase_slabs(box,amplitude,model):
    a,b=box[0]
    d=model.HALF_PERIOD
    for k in range(floor(a/d),ceil(b/d)):
        left,right=max(a,k*d),min(b,(k+1)*d)
        if left<right:
            rho=1+amplitude*(-1)**(k%2)
            assert rho>0
            yield rho,((left,right),)+box[1:]


def price_moments(Q,amplitude,model):
    """Integrate raw monomials along the actual first-coordinate phase density."""
    slices=list(phase_slabs(Q,amplitude,model))
    p0,p1,p2=[total(rho*(box[0][1]**(k+1)-box[0][0]**(k+1))/(k+1) for rho,box in slices)
              for k in range(3)]
    means,variances=uniform_moments(Q)
    assert p0*model.volume(Q[1:])==model.source_mass(Q,amplitude)
    means[0]=p1/p0
    variances[0]=p2/p0-means[0]**2
    assert variances[0]>0
    return means,variances,slices


def average_moments(rows):
    """E[X], E[XX^T] and covariance; each component has independent coordinates."""
    n=len(rows[0][1])
    assert total(w for w,_,_ in rows)==1
    mean=[total(w*m[i] for w,m,_ in rows) for i in range(n)]
    raw=[[total(w*(m[i]*m[j]+(v[i] if i==j else 0)) for w,m,v in rows)
          for j in range(n)] for i in range(n)]
    C=[[raw[i][j]-mean[i]*mean[j] for j in range(n)] for i in range(n)]
    return mean,C


def independently_total_covariance(rows):
    n=len(rows[0][1])
    assert total(w for w,_,_ in rows)==1
    mean=[total(w*m[i] for w,m,_ in rows) for i in range(n)]
    vals=[]
    for w,m,v in rows:
        diff=[mi-x for mi,x in zip(m,mean)]
        vals.append((w,diff,v))
    C=[[total(w*(delta[i]*delta[j]+(v[i] if i==j else 0)) for w,delta,v in vals)
        for j in range(n)] for i in range(n)]
    return mean,C


def summarize_covariance(mu,A,n):
    q=[r[:n] for r in A[:n]]
    w=[r[n:] for r in A[n:]]
    cross=[r[n:] for r in A[:n]]
    d=[[q[i][j]+w[i][j]-cross[i][j]-cross[j][i] for j in range(n)] for i in range(n)]
    values=[determinant(B) for B in (A,q,w,d)]
    assert all(v>=0 for v in values)
    return dict(full_mean_q_then_W=mu,full_covariance_q_then_W=A,full_trace=trace(A),full_determinant=values[0],
        q_trace=trace(q),q_determinant=values[1],W_trace=trace(w),W_determinant=values[2],
        cross_covariance_q_vs_W=cross,displacement_q_minus_W_covariance=d,displacement_trace=trace(d),
        displacement_determinant=values[3])


def example(stage,w,model,old,triples):
    f=w['fixed_original_anchor_witness']
    M,D=F(f['central_bin']),F(f['small_bin'])
    Z=old.box(f['points']['z']['positive_subbox'])
    config=triples.genuine_config(stage,model,old)
    _,marks,T,U,mu,*_=config
    H,Ht,lx,ra=triples.same_z_edges(stage,config,M,D,Z,model,old)
    x1,x_witness=map(tuple,f['encoded_lefts'])
    a1,a2=[(u,r,tuple(allowed)) for u,r,allowed in f['encoded_rights']]
    assert [H[x][a] for x,a in product((x1,x_witness),(a1,a2))]==[F(t) for t in f['true_corner_h']]
    def margin(a):
        return total(lx[x]*Ht[a1][x]*Ht[a][x] for x in Ht[a1].keys()&Ht[a].keys())
    c_h=total(ra[a]*h*margin(a) for a,h in H[x1].items())
    assert c_h>0 and H[x1][a2]>0
    post_a2=ra[a2]*H[x1][a2]*margin(a2)/c_h
    assert 0<post_a2<=1
    states=sorted(Ht[a1].keys()&Ht[a2].keys())
    raw={x:lx[x]*H[x][a1]*H[x][a2] for x in states}
    weight=total(raw.values())
    assert weight==margin(a2)>0
    normal={x:v/weight for x,v in raw.items()}
    origin_dirs={d:total(p for x,p in normal.items() if x[0]==d) for d in (0,1)}
    assert all(p==normal[(1-x[0],*x[1:])] for x,p in normal.items())
    assert origin_dirs=={0:F(1,2),1:F(1,2)}
    extra=H[x1][a1]*H[x1][a2]*ra[a1]*ra[a2]/c_h
    assert extra>0 and all(raw[x]*extra/(weight*extra)==p for x,p in normal.items())
    amp=F(stage['true_source_amplitude'])
    n=stage['n']
    const=[F(0)]*n
    joint=[]
    by_phase=[]
    replace_W_half=[]
    replace_W_parent=[]
    replace_Q_mean=[]
    replace_Q_geom=[]
    replace_both=[]
    details=[]
    by_t,by_g,by_tg=defaultdict(F),defaultdict(F),defaultdict(F)
    for x,p in normal.items():
        d,t,g,z,r=x
        Q,W=marks[t][g,z,r]['price'],marks[t][g,z,r]['owner']
        w_mean,w_var=uniform_moments(W)
        q_mean,q_var,slices=price_moments(Q,amp,model)
        q_geo=list(model.center(Q))
        w_parent=list(model.center(old.box(U[g]['owner'])))
        joint.append((p,q_mean+w_mean,q_var+w_var))
        replace_W_half.append((p,q_mean+w_mean,q_var+const))
        replace_W_parent.append((p,q_mean+w_parent,q_var+const))
        replace_Q_mean.append((p,q_mean+w_mean,const+w_var))
        replace_Q_geom.append((p,q_geo+w_mean,const+w_var))
        replace_both.append((p,q_geo+w_parent,const+const))
        physical_mass=mu(Q)
        by_t[t]+=p
        by_g[g]+=p
        by_tg[t,g]+=p
        for rho,box in slices:
            m,v=uniform_moments(box)
            subweight=rho*model.volume(box)/physical_mass
            assert subweight>0
            by_phase.append((p*subweight,m+w_mean,v+w_var))
        assert total(rho*model.volume(box) for rho,box in slices)==physical_mass
        details.append(dict(x2=x,conditional_probability=p,raw_weight=raw[x],actual_lx=lx[x],
                            true_h_to_a1=H[x][a1],true_h_to_a2=H[x][a2],Q_actual_price_box=Q,W_actual_owner_half=W,
                            q_phase_subboxes=len(slices),q_true_conditional_mean=q_mean,q_geometric_center=q_geo,
                            q_true_conditional_coordinate_variances=q_var,W_half_center=w_mean,
                            W_parent_center=w_parent,W_true_conditional_coordinate_variances=w_var))
    assert total(by_t.values())==total(by_g.values())==total(by_tg.values())==1
    mean_actual,cov_actual=average_moments(joint)
    mean_ref,cov_ref=independently_total_covariance(by_phase)
    assert mean_actual==mean_ref and cov_actual==cov_ref
    cases={'actual_full_q_and_W':(mean_actual,cov_actual),
           'replace_W_by_receiving_half_center':average_moments(replace_W_half),
           'replace_W_by_full_owner_center':average_moments(replace_W_parent),
           'replace_Q_by_actual_conditional_mean':average_moments(replace_Q_mean),
           'replace_Q_by_geometric_price_center':average_moments(replace_Q_geom),
           'replace_both_by_geometric_centers':average_moments(replace_both)}
    q_loss=[total(w*v[i] for w,_,v in joint) for i in range(n)]
    w_loss=[total(w*v[n+i] for w,_,v in joint) for i in range(n)]
    for i,j in product(range(2*n),repeat=2):
        assert cov_actual[i][j]-cases['replace_W_by_receiving_half_center'][1][i][j]==(w_loss[i-n] if i==j and i>=n else 0)
        assert cov_actual[i][j]-cases['replace_Q_by_actual_conditional_mean'][1][i][j]==(q_loss[i] if i==j and i<n else 0)
    reports={k:summarize_covariance(m,C,n) for k,(m,C) in cases.items()}
    assert reports['actual_full_q_and_W']['full_determinant']>0
    assert reports['actual_full_q_and_W']['full_trace']>reports['replace_W_by_receiving_half_center']['full_trace']
    assert reports['actual_full_q_and_W']['full_trace']>reports['replace_Q_by_actual_conditional_mean']['full_trace']
    return dict(stage=stage['stage'],dimension=n,M=M,D=D,actual_shared_Z_box=Z,
        actual_shared_z_point=f['points']['z']['price_point'],fixed_x1=x1,fixed_t1=x1[1],fixed_a1=a1,fixed_a2=a2,
        fixed_x1_q1=f['points']['q1']['price_point'],fixed_x1_W1=f['actual_owner_points'][2],
        fixed_y1=f['points']['y1']['price_point'],fixed_y2=f['points']['y2']['price_point'],
        true_c_h_at_fixed_x1_a1=c_h,conditional_probability_of_a2_cell_given_original_root=post_a2,
        raw_x2_row_weight=weight,fixed_factor_including_inverse_c_h=extra,
        positive_encoded_x2_rows=len(states),positive_x2_rows_after_combining_direction_copies=len({x[1:] for x in states}),
        actual_direction_tag_marginal=origin_dirs,middle_label_count=len(by_t),physical_small_label_count=len(by_g),
        physical_middle_small_pair_count=len(by_tg),true_phase_refinement_rows=len(by_phase),
        true_middle_posterior=dict(by_t),true_small_posterior=dict(by_g),
        covariances=reports,raw_moment_and_refined_law_of_total_covariance_equal=True,
        average_true_q_within_component_coordinate_variances=q_loss,
        average_true_W_within_component_coordinate_variances=w_loss,component_rows=details)


def main():
    here=Path(__file__).resolve().parent
    p=argparse.ArgumentParser(description=__doc__)
    for ver in ('805','806','807'):
        p.add_argument(f'--r{ver}-dir',type=Path,default=here)
    cli=p.add_mutually_exclusive_group()
    cli.add_argument('--output',type=Path)
    cli.add_argument('--check',type=Path)
    args=p.parse_args()
    paths={v:getattr(args,f'r{v}_dir').resolve() for v in ('805','806','807')}
    for f,d in DEPENDENCIES.items():
        if f!='reverse805.json':
            v=next(v for v in paths if v in f)
            assert sha256((paths[v]/f).read_bytes()).hexdigest()==d
    sys.path[:0]=list(map(str,paths.values()))
    import reverse805 as model
    import shared805 as old
    import triples806 as triples
    fixture=paths['805']/'reverse805.json'
    raw=fixture.read_bytes() if fixture.is_file() else subprocess.check_output([sys.executable,'-B',str(fixture.with_suffix('.py'))])
    assert sha256(raw).hexdigest()==DEPENDENCIES['reverse805.json']
    data=[]
    for st,w in zip(json.loads(raw)['stages'], json.loads((paths['807']/'ranks807.json').read_text())['stages'],strict=True):
        assert st['stage']==w['stage']
        data.append(example(st,w,model,old,triples))
    report=dict(runtime=dict(python=platform.python_version(),architecture=platform.machine(),arithmetic='Fraction exact'),
        dependencies=DEPENDENCIES,reproduction='python -B cov808.py --check cov808.json',stages=data,
        scope=dict(row='Exactly one already frozen true row per fixture. The common true z, both actual right states a1/a2, and the first left state x1, including t1, are fixed. The second actual left state is sampled using lambda_x2 h(x2,a1) h(x2,a2), with both original direction tags.',
            constants='All factors depending only on the fixed actual first edge, the two fixed right states and c_h(x1,a1) cancel from this conditional x2 law. Original full degrees and both legal exterior masses are retained in h.',
            moments='Q2 and W2 are independent conditional on the complete x2 mark. Q2 uses the actual piecewise positive density on its true price box. W2 is uniform Lebesgue on its actual receiving half. Raw moment integration is independently checked by refining into the exact phase slabs and applying total covariance.',
            centers='Compare actual coordinates with the actual owner half-center, the complete symmetric owner center, the geometric price midpoint, or the true conditional q mean as specified. Conditional centre replacements are calculated in the same original categorical law.',
            geometry='Report full joint and difference covariances, plus marginal traces, determinants and cross covariances. This is a finite genuine-path fixture with its original diagnostic gates, without additional asymptotic assumptions.'))
    text=json.dumps(report,sort_keys=True,indent=2,default=str)+'\n'
    if args.output:
        args.output.write_text(text)
    if args.check:
        assert args.check.read_text()==text
    if args.check or args.output:
        for s in data:
            q=s['covariances']['actual_full_q_and_W']; l=s['covariances']['replace_both_by_geometric_centers']
            print(s['stage'],s['positive_encoded_x2_rows'],s['middle_label_count'],s['physical_small_label_count'],
                'tr/det original',format(float(q['full_trace']),'.9g'),format(float(q['full_determinant']),'.9g'),
                'tr/det both centers',format(float(l['full_trace']),'.9g'),format(float(l['full_determinant']),'.9g'))
        if args.check:
            print('byte-identical')
    else:
        print(text,end='')


if __name__=='__main__':
    main()
