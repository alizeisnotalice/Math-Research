#!/usr/bin/env python3
"""Exact exponents and finite outward-rounded geometric budget diagnostics for R808."""
import argparse
from fractions import Fraction
from math import comb
from pathlib import Path
import platform
import json
import sympy as sp
import flint
from flint import arb, ctx


def algebra():
    M,D,S,Z=sp.symbols("M D S Z", positive=True)
    identities=[(D/M)/(M*D**2)-1/(M**2*D),
                (M/D)*(D/M)-1, (S/Z)*Z/S-1]
    assert all(sp.cancel(v)==0 for v in identities)
    # Product bound for k/n <= 1/16 when lambda <= 1/16 off the first k.
    assert Fraction(256,1)*Fraction(1,16)**15 < Fraction(1,5)**16
    # Three finite exact sparse-box sums and their independent recurrences.
    ans=[]
    for n,k in ((8,2),(48,4),(180,9)):
        direct=sum(comb(n,i)*6**i for i in range(k+1))
        term=1
        replay=1
        for i in range(1,k+1):
            term=term*(n-i+1)*6//i
            replay+=term
        assert replay==direct and direct<=(6*n+1)**k
        ans.append(dict(n=n,k=k,sum=direct))
    return ans


def interval_rows():
    ctx.prec=768
    rows=[]
    for power in (16,32,64,128,256,512,2048,8192):
        n=arb(2)**power
        N=n+2
        ell=N.log()
        L=n.sqrt()*ell**3
        J=n.sqrt()*ell**8
        rlo=n.sqrt()*ell**2
        H=4*(1+n.sqrt()/ell**2)
        B=16*N**5
        fee=(B*H*N**3/L**2).log()-rlo/512
        row=dict(log2_n=power,positive_diagnostic_constants="H=4(1+sqrt(n)/ell^2), B=16N^5; extra N^2 on density test",
                 log_cap_times_N_squared_against_exp_minus_r_over_512=str(fee))
        hi=(n+1)*arb(2).log()
        assert J<hi or J>hi
        row["nonempty_possible"]=bool(J<hi)
        if J<hi:
            # exp(-J/(2n))*(1-exp(-(J/2-log(2))/n-log(h0))).
            # The real-ball expm1 form avoids subtraction of nearly equal numbers.
            half=J/(2*n)
            hlog=(arb(1)/(32*n)).log1p()
            diff=half-arb(2).log()/n-hlog
            delta=(-half).exp()*(-(-diff).expm1())
            assert delta>0 and delta>J/(8*n) and delta<1
            klimit=J/(128*ell)
            sparse=klimit*((6*n+1).log())-J/8
            # radius <= (3+sqrt(n))*s*, net centers in affine slice;
            # diameter normalization allows factor 8.
            net=klimit*(1+8*(3+n.sqrt())/delta).log()-J/16
            union=sparse+net-J/16
            # Costs for the retained-mark operator and packed disjoint sets.
            b0lo=(rlo/(65536*ell)-1)/16
            spec=(B*H*N**3).log()-b0lo/64
            pack=(H*N**3/L**2).log()-(J+rlo/256)/2
            release=(B*H*N**4/L).log()-rlo/512
            assert all(v<0 for v in (fee,sparse,net,union,spec,pack,release))
            row.update(delta_over_J_over_n=str(delta/(J/n)), sparse_log_slack=str(sparse),
                       affine_net_log_slack=str(net),combined_log_slack=str(union),
                       spectral_log_slack=str(spec),private_pair_union_log_slack=str(pack),
                       receiver_budget_log_slack=str(release))
        rows.append(row)
    return rows


def main():
    cli=argparse.ArgumentParser(description=__doc__)
    group=cli.add_mutually_exclusive_group(required=True)
    group.add_argument("--output",type=Path)
    group.add_argument("--check",type=Path)
    args=cli.parse_args()
    data=dict(python=platform.python_version(),machine=platform.machine(),sympy=sp.__version__,
              flint=flint.__version__,exact=algebra(),finite=interval_rows(),precision_bits=ctx.prec,
              scope="Finite tests at the stated constants. General proofs and unspecified absolute constants belong to REPORT.tex.")
    out=json.dumps(data,sort_keys=True,indent=2)+"\n"
    if args.output:
        args.output.write_text(out)
    if args.check and args.check.read_text()!=out:
        raise ValueError("output mismatch")
    print("symbolic identities and exact arithmetic passed; valid scale rows",
          [row["log2_n"] for row in data["finite"] if row["nonempty_possible"]])


if __name__=="__main__":
    main()
