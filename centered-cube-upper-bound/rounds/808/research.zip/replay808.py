#!/usr/bin/env python3
"""Rebuild the R808 four outputs from the archived R806 and R807 inputs."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
from zipfile import ZipFile


def digest(data):
    return hashlib.sha256(data).hexdigest()


def checked(data, expected, name):
    actual=digest(data)
    if actual!=expected:
        raise ValueError(f"{name}: expected {expected}, got {actual}")
    return data


def main():
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--rounds",type=Path,required=True,help="project rounds/ containing 806/ and 807/")
    cli.add_argument("--work",type=Path,required=True,help="new directory for generated files")
    args=cli.parse_args()
    here=Path(__file__).resolve().parent
    spec=json.loads((here/"MANIFEST.json").read_text())
    for name,sha in spec["members"].items():
        checked((here/name).read_bytes(),sha,name)
    rounds=args.rounds.resolve()
    paths={r:rounds/r/"research.zip" for r in ("806","807")}
    for r,path in paths.items():
        checked(path.read_bytes(),spec["base_archives"][r],str(path))
    work=args.work.resolve()
    work.mkdir(parents=True,exist_ok=False)
    for r,path in paths.items():
        with ZipFile(path) as z:
            for name,sha in spec["base_members"][r].items():
                (work/name).write_bytes(checked(z.read(name),sha,name))
    py=[sys.executable,"-B"]
    derived=spec["derived_input"]
    raw=subprocess.check_output(py+["reverse805.py"],cwd=work)
    (work/"reverse805.json").write_bytes(checked(raw,derived["reverse805.json"],"reverse805.json"))
    subprocess.run(py+["ranks807.py","--output","ranks807.json"],cwd=work,check=True)
    checked((work/"ranks807.json").read_bytes(),derived["ranks807.json"],"ranks807.json")
    for name,expected in spec["results"].items():
        script=Path(name).with_suffix(".py")
        (work/script).write_bytes((here/script).read_bytes())
        subprocess.run(py+[str(script),"--output",name],cwd=work,check=True)
        checked((work/name).read_bytes(),expected,name)
        print("SHA256",expected,name)
    print("R808 source, two upstream archives, both reconstructed inputs and four outputs verified.")


if __name__=="__main__":
    main()
