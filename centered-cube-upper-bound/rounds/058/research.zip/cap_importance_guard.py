#!/usr/bin/env python3
"""All-space Lebesgue receiver importance probes for genuine positive atoms.
Source geometry and cap comparisons use exact dyadic integer distances.
The ideal proposal is exact analytically; machine coordinates/energy and formal
sampling bounds do not constitute outward-rounded integral certificates.
"""
from fractions import Fraction as F
from decimal import Decimal,localcontext
from pathlib import Path
import math
import random
import json
import time
from collections import defaultdict
from itertools import product

C=1-math.exp(-1)
Q=math.exp(-1)
FAMILIES=('two_sharp_peaks','equal_mass_nested','correlated_diagonal','random_cloud_unbalanced','one_axis_lattice')


def gram_decimal(vp,precision):
    with localcontext() as ctx:
        ctx.prec=precision;q=(-Decimal(1)).exp();c=1-q
        data=[(Decimal(v.numerator)/Decimal(v.denominator),Decimal(p.numerator)/Decimal(p.denominator)) for v,p in vp]
        total=Decimal(0);diagonal=Decimal(0)
        for i,(vi,pi) in enumerate(data):
            diagonal+=c*pi*pi/(vi*vi)
            for vj,pj in data:
                small,big=sorted((vi,vj));ratio=big/small
                kernel=(2-q-q*ratio*ratio)/(2*big*big) if ratio<=1/q else -c*c/(2*q*big*big)
                total+=pi*pj*kernel
        return +total,+diagonal


def event_energy(relative_volumes,weights):
    events=[]
    for v,p in zip(relative_volumes,weights):events.extend(((v*Q,p*Q),(v,-p)))
    events.sort();coef=0.;pieces=[];i=0
    while i<len(events):
        left=events[i][0];delta=[]
        while i<len(events) and events[i][0]==left:delta.append(events[i][1]);i+=1
        coef=math.fsum((coef,*delta))
        right=events[i][0] if i<len(events) else math.inf
        ratio=left/right
        pieces.append(.5*(coef/left)**2*(1-ratio)*(1+ratio))
    return math.fsum(pieces)


def pack_source(source,requested_N=None,meta=None):
    merged=defaultdict(F)
    for y,p in source:
        assert p>0
        merged[tuple(F(v) for v in y)]+=F(p)
    source=sorted(merged.items());n=len(source[0][0])
    bits=max(v.denominator.bit_length()-1 for y,p in source for v in y)
    assert all(v.denominator&(v.denominator-1)==0 for y,p in source for v in y)
    P=math.lcm(*(p.denominator for y,p in source));nums=[int(p*P) for y,p in source]
    total=sum(nums);W=F(total,P)
    return dict(source=source,n=n,N=len(source),requested_N=requested_N if requested_N is not None else len(source),bits=bits,coords_int=[tuple(int(v*2**bits) for v in y) for y,p in source],coords_float=[tuple(float(v) for v in y) for y,p in source],P=P,pnums=nums,totalnum=total,W=W,weights=[float(p) for y,p in source],meta=meta or {})


def build_source(n,N,family,seed):
    if family.startswith('product_grid_m'):
        m=int(family.rsplit('m',1)[1]);coords=[F(2*j+1-m,2*m) for j in range(m)]
        assert m**n==N
        return pack_source([(tuple(y),F(1,N)) for y in product(coords,repeat=n)],N,dict(family=family,source_seed=seed,points_per_coordinate=m,lower_model_relation='True finite Cartesian atomic lattice pressure geometry; not the complete positive-width periodic-lattice weak lower-bound theorem.'))
    rng=random.Random(seed);points=[];raw=[]
    for j in range(N):
        if family=='equal_mass_nested':y=tuple(F((-1)**(j+i),2**(j+2)) for i in range(n));w=1
        elif family=='correlated_diagonal':y=tuple(F((-1)**i*(2*j+1-N),2*N) for i in range(n));w=1
        elif family=='one_axis_lattice':y=(F(2*j+1-N,2*N),)+(F(0),)*(n-1);w=1
        elif family=='two_sharp_peaks':
            peak=-1 if j<N//2 else 1;offset=F(2*(j%(N//2))+1-N//2,2**12*N)
            y=tuple(F(peak,4)+(-1)**i*offset for i in range(n));w=1
        else:
            y=tuple(F(rng.randrange(-1024,1025),2048) for i in range(n));w=2**rng.randrange(0,8)
        points.append(y);raw.append(w)
    total=sum(raw)
    return pack_source([(y,F(w,total)) for y,w in zip(points,raw)],N,dict(family=family,source_seed=seed))


def receiver_geometry(pack,x):
    pairs=[v.as_integer_ratio() for v in x]
    bits=max(pack['bits'],*(d.bit_length()-1 for a,d in pairs));R=1<<bits
    xs=[a<<(bits-(d.bit_length()-1)) for a,d in pairs]
    shift=bits-pack['bits']
    radii=[max(abs(xs[i]-(y[i]<<shift)) for i in range(pack['n'])) for y in pack['coords_int']]
    return radii,R


def cap_geometry(pack,radii,R,H):
    if not all(radii):return False,None,None,None
    ordered=sorted(zip(radii,pack['pnums']));mass=0;bestmass=0;bestvol=1;volumes={};i=0
    while i<len(ordered):
        radius=ordered[i][0]
        while i<len(ordered) and ordered[i][0]==radius:mass+=ordered[i][1];i+=1
        vol=(2*radius)**pack['n'];volumes[radius]=vol
        if mass*bestvol>bestmass*vol:bestmass,bestvol=mass,vol
    numerator=bestmass*R**pack['n']*H.denominator
    denominator=pack['P']*bestvol*H.numerator
    cap=numerator<=denominator
    bands=tuple(numerator*K>denominator for K in (2,16)) if cap else (False,False)
    return cap,bands,volumes,(bestmass,bestvol)


def sample_receiver(pack,H,rng):
    draw=rng.random()*pack['totalnum'];cum=0;j=pack['N']-1
    for k,p in enumerate(pack['pnums']):
        cum+=p
        if draw<cum:j=k;break
    U=rng.random()
    while U==0:U=rng.random()
    v=float(F(pack['pnums'][j],pack['P'])/H)/U
    side=v if pack['n']==1 else math.exp(math.log(v)/pack['n'])
    face=rng.randrange(pack['n']);sign=1 if rng.getrandbits(1) else -1
    cone=[(sign*.5 if i==face else rng.random()-.5) for i in range(pack['n'])]
    x=tuple(pack['coords_float'][j][i]+side*cone[i] for i in range(pack['n']))
    return x,j,U


def evaluate_receiver(pack,H,x,proposal_j=None,guard=False):
    radii,R=receiver_geometry(pack,x);cap,bands,vols,maxpair=cap_geometry(pack,radii,R,H)
    if maxpair is None:return dict(cap=False,energy_score=0.,diagonal_score=0.,band_scores=(0.,0.),singular=True)
    smallest=min(radii);relative=[(r/smallest)**pack['n'] for r in radii]
    rp=R**pack['n'];supports=[vols[r]*pack['P']*H.numerator>=pn*rp*H.denominator for r,pn in zip(radii,pack['pnums'])]
    if proposal_j is not None:assert supports[proposal_j]
    qcore=math.fsum(p*p/(v*v) for p,v,support in zip(pack['weights'],relative,supports) if support)
    assert qcore>0
    if cap:
        assert all(supports)
        fullcore=math.fsum(p*p/(v*v) for p,v in zip(pack['weights'],relative))
        assert qcore==fullcore
        energy=event_energy(relative,pack['weights']);score=energy/qcore
        assert 0<=score<=C*pack['N']*(1+2e-12)
        vsmall=(2*smallest/R)**pack['n']
        band_scores=tuple(float(H/F(K))*float(H)*vsmall*vsmall/qcore if flag else 0. for K,flag in zip((2,16),bands))
        for K,b in zip((2,16),band_scores):assert 0<=b<=pack['N']*K*(1+2e-12)
    else:energy=0.;score=0.;band_scores=(0.,0.)
    out=dict(cap=cap,energy_score=score,diagonal_score=C if cap else 0.,band_scores=band_scores,singular=False)
    if guard:
        vp=[(F(2*r,R)**pack['n'],p) for r,(y,p) in zip(radii,pack['source'])]
        exact_M=F(maxpair[0]*rp,pack['P']*maxpair[1]);assert (exact_M<=H)==cap
        # Independent Gram at actual source volumes, then normalize by vmin^2.
        gram80,diag80=gram_decimal(vp,80);gram120,diag120=gram_decimal(vp,120)
        event=event_energy(relative,pack['weights'])
        vmin=min(v for v,p in vp)
        with localcontext() as ctx:
            ctx.prec=120;scale=(Decimal(vmin.numerator)/Decimal(vmin.denominator))**2
            target=gram120*scale;relative_error=abs(Decimal.from_float(event)-target)/max(target,Decimal('1e-1000'))
            precision_error=abs(gram80-gram120)/max(gram120,Decimal('1e-1000'))
        assert relative_error<Decimal('2e-11') and precision_error<Decimal('1e-65')
        out['guard']=dict(n=pack['n'],N=pack['N'],M_exact=str(exact_M),H_exact=str(H),cap=cap,event_vs_gram120_relative_error=str(relative_error),gram80_vs120_relative_error=str(precision_error),source_diagonal_decimal=str(diag120),receiver=[str(F(v)) for v in x],complete_proposal_support_count=sum(supports),q_G_simplification_checked=cap)
    return out


def summary(values,bound):
    samples=len(values);mean=math.fsum(values)/samples
    variance=math.fsum((v-mean)**2 for v in values)/(samples-1)
    radius=bound*math.sqrt(math.log(40)/(2*samples))
    return dict(estimate=mean,sample_standard_error=math.sqrt(variance/samples),sample_variance=variance,score_upper_bound=bound,formal_pointwise_95_Hoeffding_radius=radius,formal_pointwise_95_Hoeffding_interval=[max(0.,mean-radius),min(bound,mean+radius)])


def oneatom_guards():
    rows=[]
    for n in (1,2,4,8,16):
        for H,p in ((F(1,8),F(1,4)),(F(1),F(1)),(F(8),F(7))):
            pack=pack_source([(tuple(F(1,4) for i in range(n)),p)])
            rng=random.Random(581000+n+H.numerator)
            scores=[]
            for trial in range(16):
                x,j,U=sample_receiver(pack,H,rng);out=evaluate_receiver(pack,H,x,j,guard=trial==0)
                assert out['cap'] and abs(out['energy_score']-C)<2e-14
                scores.append(out['energy_score'])
            rows.append(dict(n=n,H=str(H),atom_mass=str(p),theory='1-exp(-1)',max_score_minus_theory=max(abs(s-C) for s in scores),receiver_samples=16))
    return rows


def batch_boundary_guards():
    rows=[]
    for n in (1,2,4,8,16):
        source=[((F(-1,2),)+(F(0),)*(n-1),F(1,2)),((F(1,2),)+(F(0),)*(n-1),F(1,2))]
        pack=pack_source(source);x=(0.,)*n
        out=evaluate_receiver(pack,F(1),x,guard=True)
        assert out['cap'] and out['guard']['M_exact']=='1'
        assert abs(out['energy_score']-2*C)<1e-14
        rows.append(dict(n=n,M_exact='1',H_exact='1',equal_volume='1',cap_equality_accepted=True,normalized_point_score=out['energy_score'],event_Gram_guard=out['guard']))
    return rows


def degeneracy_guards():
    rows=[]
    with localcontext() as ctx:
        ctx.prec=120;c=1-(-Decimal(1)).exp()
        for N in (1,8,32,128):
            source=[((F(0),),F(1,N)) for j in range(N)];pack=pack_source(source,N)
            assert pack['N']==1 and pack['W']==1
            rows.append(dict(label_count=N,actual_after_merging=pack['N'],unmerged_proposal_cap_probability=str(Decimal(1)/N),unmerged_cap_score=str(c*N),unmerged_expected_score=str(c),unmerged_score_variance=str(c*c*(N-1)),merged_score=str(c),merged_score_variance='0',interpretation='Proposal label degeneracy changes variance, not the physical energy; duplicates are merged before principal sampling.'))
    return rows


def kernel_distance_guards():
    rows=[]
    for ratio_label in ('1','1.25','2','e_minus_1e-30','e','e_plus_1e-30','4','16','1e6'):
        answers=[]
        for precision in (80,120):
            with localcontext() as ctx:
                ctx.prec=precision;e=Decimal(1).exp();q=1/e;c=1-q
                w={'e_minus_1e-30':e-Decimal('1e-30'),'e':e,'e_plus_1e-30':e+Decimal('1e-30')}.get(ratio_label)
                if w is None:w=Decimal(ratio_label)
                K=(2-q-q*w*w)/(2*w*w) if w<=e else -c*c/(2*q*w*w)
                gram=c+c/(w*w)-2*K
                formula=1-1/(w*w) if w<=e else c*(1+e/(w*w))
                assert abs(gram-formula)<Decimal(10)**(-precision+10)
                answers.append((gram,formula))
        assert abs(answers[0][0]-answers[1][0])<Decimal('1e-65')
        rows.append(dict(volume_ratio=ratio_label,v_normalized=1,kernel_distance_squared_decimal=str(answers[1][0]),piecewise_formula_decimal=str(answers[1][1]),precision_digits=[80,120],interpretation='Hilbert time-kernel difference, not a source or receiver energy lower bound.'))
    cone=[]
    with localcontext() as ctx:
        ctx.prec=120;e=Decimal(1).exp();c=1-1/e
        for n in (8,16,64,256,1024,4096):
            minimum_ratio=(1+Decimal(2)/n)**n;assert minimum_ratio>=e
            lower=c.sqrt()/2*n*(Decimal(n)/4).ln()
            cone.append(dict(n=n,r_over_delta_interval=[2,n/2],minimum_w_over_v_decimal=str(minimum_ratio),Hormander_diagonal_cone_lower_expression=str(lower),status='Analytic cone parameter guard supplied separately; not high-dimensional finite-source sampling.'))
    return dict(kernel_distance_rows=rows,diagonal_cone_parameter_rows=cone)


def same_cube_A2_guards():
    rows=[]
    for n in (1,2,4,8,16,32,64,128):
        for p,H in ((F(1),F(1)),(F(7,4),F(3,2))):
            r0_power=p/(2**n*H)
            Qvolume=2*r0_power
            badvolume=r0_power
            goodvolume=Qvolume-badvolume
            A2=p*goodvolume/(Qvolume*Qvolume)
            factor=F(2)**(n-2)
            assert Qvolume==F(2)**(1-n)*p/H
            assert goodvolume/Qvolume==F(1,2)
            assert A2/H==factor
            rows.append(dict(n=n,atom_mass=str(p),H=str(H),r0_power_n_exact=str(r0_power),Q_definition='[0,2^(1/n)*r0]^n, r0=(p/H)^(1/n)/2; atom at origin, closed Q includes the corner atom.',Q_volume_exact=str(Qvolume),G_bad_Q_volume_exact=str(badvolume),G_good_Q_volume_exact=str(goodvolume),good_fraction_exact='1/2',same_cube_A2_exact=str(A2),same_cube_A2_over_H_exact=str(factor),status='Exact Fraction arithmetic guard for the separately proved geometry. Exponential same-cube testing pressure, not cap-energy growth.'))
    return rows


def source_record(pack,source_id):
    return dict(source_id=source_id,n=pack['n'],requested_N=pack['requested_N'],actual_N=pack['N'],source_mass=str(pack['W']),source_entropy=-math.fsum(float(p/pack['W'])*math.log(float(p/pack['W'])) for y,p in pack['source']),**pack['meta'],source=[dict(position=[str(v) for v in y],weight=str(p)) for y,p in pack['source']])


def principal_probes():
    source_cache={};records=[];rows=[];aggregate=[];guards=[]
    cases=[]
    for stage,N,samples in ((1,8,1024),(2,32,1024),(3,128,2048)):
        for n in (1,2,4,8,16):
            for family in FAMILIES:cases.append((stage,n,N,family,F(1),samples,3))
    for n in (1,4,16):
        for family in ('equal_mass_nested','random_cloud_unbalanced','one_axis_lattice'):
            for H in (F(1,2),F(4)):cases.append((4,n,32,family,H,1024,2))
    for n,m in ((2,4),(3,4),(4,2),(7,2)):
        for H in (F(1),F(4)):cases.append((5,n,m**n,f'product_grid_m{m}',H,2048,2))
    cases=[(stage,n,N,family,H,4096 if (stage==3 and n==2 and family=='equal_mass_nested') or (stage==4 and family=='one_axis_lattice' and H==F(1,2)) else samples,3 if stage==4 and family=='one_axis_lattice' and H==F(1,2) else seeds) for stage,n,N,family,H,samples,seeds in cases]
    for caseindex,(stage,n,N,family,H,samples,seeds) in enumerate(cases):
        key=(n,N,family)
        if key not in source_cache:
            family_index=FAMILIES.index(family) if family in FAMILIES else 5+int(family.rsplit('m',1)[1])
            source_seed=580000+10000*n+100*N+family_index
            pack=build_source(n,N,family,source_seed);source_id=f'n{n}_N{N}_{family}'
            source_cache[key]=(pack,source_id);records.append(source_record(pack,source_id))
        pack,source_id=source_cache[key];combined=[[],[],[],[]]
        for repetition in range(seeds):
            seed=58500000+1000*caseindex+repetition;rng=random.Random(seed)
            energy=[];diagonal=[];band2=[];band16=[];off=[];accepted=0;support_min=pack['N'];maxscore=0.
            for trial in range(samples):
                x,j,U=sample_receiver(pack,H,rng)
                useguard=(repetition==0 and trial==0 and (N==8 or n in (1,16) or family.startswith('product_grid')))
                out=evaluate_receiver(pack,H,x,j,guard=useguard)
                energy.append(out['energy_score']);diagonal.append(out['diagonal_score']);off.append(out['energy_score']-out['diagonal_score']);band2.append(out['band_scores'][0]);band16.append(out['band_scores'][1]);accepted+=int(out['cap']);maxscore=max(maxscore,out['energy_score'])
                if useguard:guards.append(dict(source_id=source_id,seed=seed,**out['guard']))
            for target,values in zip(combined,(energy,diagonal,band2,band16)):target.extend(values)
            offmean=math.fsum(off)/samples
            offse=math.sqrt(math.fsum((v-offmean)**2 for v in off)/(samples-1)/samples)
            row=dict(stage=stage,source_id=source_id,n=n,requested_N=N,actual_N=pack['N'],H=str(H),receiver_seed=seed,receiver_samples=samples,accepted_receiver_count=accepted,max_observed_energy_score=maxscore,cap_energy_over_H_W=summary(energy,C*pack['N']),cap_diagonal_over_H_W=summary(diagonal,C),offdiagonal_over_H_W=dict(estimate=offmean,sample_standard_error=offse),capped_weak_band_K2=summary(band2,pack['N']*2),capped_weak_band_K16=summary(band16,pack['N']*16))
            rows.append(row)
        es,ds,b2s,b16s=combined
        offvalues=[e-d for e,d in zip(es,ds)];offmean=math.fsum(offvalues)/len(offvalues)
        offse=math.sqrt(math.fsum((v-offmean)**2 for v in offvalues)/(len(offvalues)-1)/len(offvalues))
        aggregate.append(dict(stage=stage,source_id=source_id,n=n,requested_N=N,actual_N=pack['N'],H=str(H),receiver_samples=len(es),independent_receiver_seed_count=seeds,cap_energy_over_H_W=summary(es,C*pack['N']),cap_diagonal_over_H_W=summary(ds,C),cap_acceptance_fraction=math.fsum(v/C for v in ds)/len(ds),offdiagonal_over_H_W=dict(estimate=offmean,sample_standard_error=offse),capped_weak_band_K2=summary(b2s,pack['N']*2),capped_weak_band_K16=summary(b16s,pack['N']*16),max_observed_energy_score=max(es)))
        print('done',caseindex+1,len(cases),stage,n,N,family,str(H),'E/HW',round(aggregate[-1]['cap_energy_over_H_W']['estimate'],6),'SE',round(aggregate[-1]['cap_energy_over_H_W']['sample_standard_error'],6),'accept',round(aggregate[-1]['cap_acceptance_fraction'],4),flush=True)
    return records,rows,aggregate,guards


def main():
    start=time.monotonic();atoms=oneatom_guards();batches=batch_boundary_guards();degeneracy=degeneracy_guards();kernels=kernel_distance_guards();A2=same_cube_A2_guards();sources,seedrows,aggregates,guards=principal_probes()
    counts=dict(source_cases=len(sources),source_H_cases=len(aggregates),seed_rows=len(seedrows),principal_receiver_samples=sum(r['receiver_samples'] for r in seedrows),independent_event_Gram_guards=len(guards),oneatom_parameter_guards=len(atoms),oneatom_receiver_samples=sum(r['receiver_samples'] for r in atoms),degeneracy_parameter_guards=len(degeneracy),same_radius_cap_boundary_guards=len(batches),kernel_distance_guards=len(kernels['kernel_distance_rows']),cone_parameter_guards=len(kernels['diagonal_cone_parameter_rows']),same_cube_A2_fraction_guards=len(A2))
    result=dict(round=58,status='PASS',standard_library_only=True,counts=counts,proposal=dict(component='q_j(x)=(p_j/H)/v_j(x)^2 *1{v_j>=p_j/H}, v_j=(2||x-y_j||infinity)^n; each q_j integrates1 against Lebesgue receiver measure.',mixture='Select j with p_j/W; U uniform(0,1), v=(p_j/H)/U; uniform cube-cone face with one coordinate +/-1/2 and others uniform[-1/2,1/2], multiplied by v^(1/n) and translated by y_j.',density='q=sum_j (p_j/W)*q_j. On true G={Mmu<=H}, all components are supported and q=sum_j p_j^2/v_j^2/(WH). Complete support density evaluated before score calculation.',normalized_score='1_G Epoint/(qHW)=1_G Epoint/(sum_j p_j^2/v_j^2); bounded by (1-exp(-1))*actual_N. Source labels are merged before sampling.',weak_band='K=2,16,lambda=H/K, score=lambda*1{lambda<Mmu<=H}/(qW); expectation is this capped weak band only, score bounded actual_N*K.'),scope=dict(space='All-space Lebesgue receiver importance sampling, no receiver-box or radial-volume cutoff. This is not source-measure receiver sampling.',source='True finite positive sources of mass1 in principal cases; fixed geometry across independent receiver seeds; exact coincident atoms merged and counts recorded before/after.',geometry='Dyadic sources and each generated machine receiver interpreted as exact rational points. Equal-radius batches and M/cap/band comparisons use common-denominator integers.',energy='Floating fullscale event integration, independently checked against actual-source Decimal Gram at80/120digits. No scale grid. Arithmetic guards are not outward-rounded certification.',sampling='The ideal continuous iid proposal yields unbiased all-space estimates. Executed pseudorandom machine samples approximate that proposal; sampleSE and formal Hoeffding bounds do not cover transform/rounding bias.',confidence='Per-row formal pointwise95 Hoeffding radius B*sqrt(log(40)/(2S)) for independent exact scores in[0,B]; B=cN for energy, c for diagonal, NK for capped weak bands. Displayed intervals plug machine scores and are not simultaneous, interval-certified integral bounds.',rare_events='Near-coincident clusters can have rare large scores and substantial variance. Small sampleSE does not certify absence of source-count or dimension growth. Unmerged coincident labels illustrate proposal degeneracy.',fitting='No dimension/source-count exponent fit or weak-type theorem inferred. Cone parameters are separate analytic formula guards, not actual high-dimensional source sampling.'),oneatom_guards=atoms,same_radius_cap_boundary_guards=batches,label_degeneracy_guards=degeneracy,kernel_and_cone_guards=kernels,same_cube_A2_guards=A2,sources=sources,seed_results=seedrows,source_H_results=aggregates,event_Gram_guards=guards)
    Path(__file__).with_name('results.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
    print('PASS',counts,'runtime seconds',time.monotonic()-start)

if __name__=='__main__':main()
