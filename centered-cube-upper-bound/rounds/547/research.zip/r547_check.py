import json,sys,platform
from pathlib import Path
import sympy as s
import flint
from flint import arb,ctx
ctx.prec=256
r,l,u,n,z=s.symbols('r l u n z',positive=True)
inner=s.integrate(n*r**(n-1)/l**n,(r,0,l))
outer=s.integrate(n/r,(r,l,u))
assert s.simplify(inner+outer-(1+n*s.log(u/l)))==0
log_expansion=s.series(s.log(1+s.exp(-z/4))/z**2,z,0,3)
assert s.simplify(s.limit(s.log(1+s.exp(-z/4))/z**2-s.log(2)/z**2+1/(8*z),z,0)-s.Rational(1,128))==0
rows=[]
for dim in [4,16,64,256,1024]:
 a=arb(dim); sq=a.sqrt(); radial=2*(1+a*(a+1).log()-sq/4); exponential=2*(1+(-1/(4*sq)).exp())**dim
 assert radial>0 and exponential>0
 rows.append({'n':dim,'radial_bound_arb256':str(radial),'radial_over_sqrt_n_log_n_plus_2':str(radial/(sq*(a+2).log())),'log_exponential_bound_arb256':str(exponential.log())})
out={'purpose':'Verify exact costs of two unsuccessful complete-integral estimates; not evidence for any new geometric theorem or inferred asymptotic order. Orders follow analytic formulas.', 'interpreter':sys.executable,'versions':{'python':platform.python_version(),'sympy':s.__version__,'python_flint':flint.__version__},'precision_bits':256,'command':sys.executable+' '+str(Path(__file__).resolve()),'inner_exact':str(inner),'outer_exact':str(outer),'radial_identity_residual':'0','exponential_log_expansion_z_equals_n_minus_half':str(log_expansion),'exponential_constant_residual':'0','finite_dimensions':rows,'general_asymptotics':'radial/(sqrt(n)*log(n+2)) ~ 2sqrt(n); exponential coefficient = 2 exp(n log 2 - sqrt(n)/8 + 1/128 + O(1/n)). Both fail target fixed root-order polylog cost: radial also exceeds sqrt(n)*log^A(n+2) for every fixed A as n tends to infinity.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
