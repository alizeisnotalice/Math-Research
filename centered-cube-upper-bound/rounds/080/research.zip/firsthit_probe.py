#!/usr/bin/env python3
"""Exact global first-contact certificates for finite positive L1 box fixtures.

No scale grid is substituted for the first hit. All physical breakpoints are
used; each earlier open interval has exact Sturm root exclusion and a negative
polynomial witness. Receivers are point diagnostics in Lebesgue coordinates,
not certificates of event volume or a general weak-type bound. Stdlib only.
"""
from fractions import Fraction as F
from pathlib import Path
from functools import lru_cache
import json, math, random, time

SEED=800611


def clean(x):
    if isinstance(x,F):return str(x)
    if isinstance(x,dict):return {str(k):clean(v) for k,v in x.items()}
    if isinstance(x,(tuple,list)):return [clean(v) for v in x]
    return x


def trim(p):
    p=list(map(F,p))
    while len(p)>1 and not p[-1]:p.pop()
    return tuple(p)


def zero(p):return len(p)==1 and p[0]==0
def add(p,q):return trim([(p[i] if i<len(p) else 0)+(q[i] if i<len(q) else 0) for i in range(max(len(p),len(q)))])
def scale(p,a):return trim([F(a)*x for x in p])
def derivative(p):return trim([i*p[i] for i in range(1,len(p))] or [0])


def multiply(p,q):
    out=[F(0)]*(len(p)+len(q)-1)
    for i,a in enumerate(p):
        for j,b in enumerate(q):out[i+j]+=a*b
    return trim(out)


def evaluate(p,x):
    value=F(0)
    for a in reversed(p):value=value*x+a
    return value


def remainder(p,q):
    assert not zero(q);out=list(p)
    while len(out)>=len(q) and not zero(trim(out)):
        a=out[-1]/q[-1];shift=len(out)-len(q)
        for j,b in enumerate(q):out[shift+j]-=a*b
        out=list(trim(out))
    return trim(out)


@lru_cache(None)
def sturm(p):
    p=trim(p)
    if zero(p):return ()
    seq=[p];d=derivative(p)
    if zero(d):return tuple(seq)
    seq.append(d)
    while True:
        rem=scale(remainder(seq[-2],seq[-1]),-1)
        if zero(rem):break
        # Positive rational scaling preserves the Sturm signs.
        rem=scale(rem,1/abs(rem[-1]));seq.append(rem)
    return tuple(seq)


def sign(x):return 1 if x>0 else -1 if x<0 else 0


def side_sign(p,x,side):
    """Exact one-sided endpoint sign, including repeated roots/gcd zeros."""
    assert side in (-1,1)
    d=p;order=0
    while not zero(d):
        value=evaluate(d,x)
        if value:return sign(value)*(side if order%2 else 1)
        d=derivative(d);order+=1
    return 0


def variation(seq,x,side):
    signs=[side_sign(p,x,side) for p in seq]
    signs=[v for v in signs if v]
    return sum(a!=b for a,b in zip(signs,signs[1:]))


def root_count(p,a,b):
    """Count distinct roots strictly in (a,b), using V(a+)-V(b-)."""
    assert a<b and not zero(p)
    seq=sturm(p);count=variation(seq,a,1)-variation(seq,b,-1)
    assert count>=0
    return count


def overlap(x,c,eps,L):
    return max(F(0),min(x+L/2,c+eps)-max(x-L/2,c-eps))


def capture(src,x,L):
    return sum(w*math.prod(overlap(xx,c,src['epsilon'],L) for xx,c in zip(x,y))/(2*src['epsilon'])**src['n'] for y,w in zip(src['centers'],src['weights']))


def average(src,x,L):
    assert L>0
    return capture(src,x,L)/L**src['n']


def density(src,x):
    eps=src['epsilon']
    assert all(xx!=c-eps and xx!=c+eps for y in src['centers'] for xx,c in zip(x,y)), 'receiver on box boundary excluded in these fixtures'
    return sum(w/(2*eps)**src['n'] for y,w in zip(src['centers'],src['weights']) if all(abs(xx-c)<eps for xx,c in zip(x,y)))


def numerator_polynomial(src,x,a,b):
    # Between all face breakpoints every scalar overlap is affine in L.
    first=(2*a+b)/3;second=(a+2*b)/3;result=(F(0),)
    for y,w in zip(src['centers'],src['weights']):
        term=(F(w),)
        for xx,c in zip(x,y):
            u=overlap(xx,c,src['epsilon'],first);v=overlap(xx,c,src['epsilon'],second)
            slope=(v-u)/(second-first);intercept=u-slope*first
            term=multiply(term,(intercept,slope))
        result=add(result,term)
    for L in (first,second,(a+b)/2):
        assert evaluate(result,L)==capture(src,x,L)*(2*src['epsilon'])**src['n']
    return result


def isolate_first_root(p,a,b,iterations=64):
    assert root_count(p,a,b)>0
    original=(a,b);steps=0
    while steps<iterations or root_count(p,a,b)!=1:
        mid=(a+b)/2;steps+=1
        left=root_count(p,a,mid)
        if left:b=mid
        elif evaluate(p,mid)==0:
            return dict(interval=[mid,mid],singleton_rational_root_certified=True,steps=steps,original_interval=original,
                        isolation_root_count=1,left_sign=side_sign(p,mid,-1),right_sign=side_sign(p,mid,1))
        else:a=mid
        assert steps<=160, 'root isolation exceeded explicit budget'
    assert root_count(p,a,b)==1 and evaluate(p,a)!=0 and evaluate(p,b)!=0
    return dict(interval=[a,b],singleton_rational_root_certified=False,steps=steps,original_interval=original,
                isolation_root_count=1,left_sign=sign(evaluate(p,a)),right_sign=sign(evaluate(p,b)))


def first_contact(src,x):
    n=src['n'];eps=src['epsilon'];lam=src['lambda_value'];fx=density(src,x)
    assert 0<=fx<=lam/2
    breaks=sorted({F(0)}|{2*abs(xx-face) for y in src['centers'] for xx,c in zip(x,y) for face in (c-eps,c+eps)})
    # The terminal all-captured interval is explicit, not an omitted large-scale
    # region. Any first hit must occur before this interval decreases forever.
    tail_end=max(breaks[-1]+1,F(2)*src['W']/lam+1)
    endpoints=breaks+[tail_end];threshold=(F(0),)*n+(lam*(2*eps)**n,)
    intervals=[]
    for idx,(a,b) in enumerate(zip(endpoints,endpoints[1:])):
        numerator=numerator_polynomial(src,x,a,b)
        p=add(numerator,scale(threshold,-1))
        intervals.append(dict(index=idx,left=a,right=b,numerator=numerator,threshold_polynomial=threshold,difference_polynomial=p,
                              terminal_all_captured_interval=(idx==len(endpoints)-2),
                              right_extends_to_infinity=(idx==len(endpoints)-2)))
    assert all(evaluate(intervals[-1]['numerator'],L)==src['W']*(2*eps)**n for L in (breaks[-1]+F(1,2),tail_end))
    assert src['W']/tail_end**n<lam
    prefix=[];hit=None
    for row in intervals:
        a,b=row['left'],row['right'];p=row['difference_polynomial']
        if a>0 and evaluate(p,a)==0:
            assert average(src,x,a)==lam
            hit=dict(interval=[a,a],singleton_rational_root_certified=True,steps=0,at_physical_breakpoint=True,
                     physical_interval_index=row['index'],left_sign=side_sign(intervals[row['index']-1]['difference_polynomial'],a,-1),right_sign=side_sign(p,a,1),
                     original_interval=[a,b],isolation_root_count=1)
            break
        assert not zero(p),'identically zero interval must begin with a first contact breakpoint'
        count=root_count(p,a,b);mid=(a+b)/2
        seq=sturm(p)
        certificate=dict(interval_index=row['index'],left=a,right=b,
                         variation_left_plus=variation(seq,a,1),variation_right_minus=variation(seq,b,-1),open_root_count=count,
                         test_point=mid,test_difference=evaluate(p,mid))
        if count:
            hit=isolate_first_root(p,a,b);hit.update(at_physical_breakpoint=False,physical_interval_index=row['index'],sturm_sequence=seq)
            cutoff=hit['interval'][0]
            exclusion=root_count(p,a,cutoff) if cutoff>a else 0
            assert exclusion==0
            hit['within_interval_earlier_root_exclusion']=dict(left=a,right=cutoff,distinct_open_root_count=exclusion)
            prefix.append(dict(**certificate,role='first_root_interval'))
            break
        assert evaluate(p,mid)<0
        prefix.append(dict(**certificate,role='earlier_strictly_negative_interval'))
        if evaluate(p,b)==0:
            assert average(src,x,b)==lam
            nextp=intervals[row['index']+1]['difference_polynomial'] if row['index']+1<len(intervals) else p
            hit=dict(interval=[b,b],singleton_rational_root_certified=True,steps=0,at_physical_breakpoint=True,
                     physical_interval_index=row['index'],left_sign=side_sign(p,b,-1),right_sign=side_sign(nextp,b,1),
                     original_interval=[a,b],isolation_root_count=1)
            break
    assert hit is not None,'fixture has no global positive first contact'
    lo,hi=hit['interval'];assert lo>0 and hit['left_sign']<0
    classification='upward_crossing' if hit['right_sign']>0 else 'level_plateau' if hit['right_sign']==0 else 'tangent_level_contact'
    hit.update(contact_classification=classification,first_contact_means='Earliest L>0 with A_L>=lambda; tangencies retained and distinguished from strict crossings.')
    ages=[]
    for t in (F(1,16),F(1,8),F(1,4),F(1,2),F(3,4),F(7,8)):
        assert t*hi<lo
        small=capture(src,x,t*hi);small_lower=capture(src,x,t*lo)
        lower=small_lower/(lam*hi**n);upper=small/(lam*lo**n);target=t**n
        earlier_average=average(src,x,t*hi)
        assert earlier_average<lam and 0<=lower<=upper<=target
        ages.append(dict(t_equals_exp_minus_h=t,smaller_scale_upper=t*hi,
                         posterior_age_tail_interval=[lower,upper],target_exp_minus_nh=target,
                         target_minus_certified_upper=target-upper,
                         earlier_average_at_smaller_scale_upper=earlier_average,lambda_minus_earlier_average=lam-earlier_average,
                         exact_interval_age_bound_verified=True))
    positive_witnesses=[]
    for L in breaks[1:]+[src['reference_scale']]:
        if average(src,x,L)>lam:positive_witnesses.append(dict(L=L,average=average(src,x,L)))
    # In these fixtures each strict event has an upward earliest contact. The
    # separate tangent regression has no strict-event assertion.
    assert bool(positive_witnesses)==(classification=='upward_crossing')
    return dict(receiver=x,density_at_receiver=fx,lambda_value=lam,excluded_high_density_fee_premise_verified=True,
                first_contact=hit,all_physical_breakpoints=breaks,all_physical_interval_polynomials=intervals,
                earlier_scale_certificates=prefix,all_previous_positive_scales_strictly_below_lambda=True,
                age_tail_certificates=ages,strict_above_lambda_witness=positive_witnesses[0] if positive_witnesses else None,
                strict_event_claimed=bool(positive_witnesses),
                first_strict_cross_boundary_interval=hit['interval'] if positive_witnesses else None,
                strict_target_scope='The first-contact interval is also the first strict-cross boundary for this upward-crossing fixture.' if positive_witnesses else 'Equality-contact regression only; excluded from the strict above-threshold target event.',
                terminal_scale_cutoff=tail_end,terminal_average_below_lambda=src['W']/tail_end**n,
                terminal_extension_reason='After the last physical face breakpoint capture mass is W, so A_L=W/L^n decreases to zero; the terminal polynomial extends to infinity.',
                receiver_scope='A fixed rational point in original Lebesgue x coordinates; no receiver quadrature and no weak-volume estimate.')


def source(label,n,centers,weights,epsilon,lam,reference_scale=F(2)):
    centers=[tuple(map(F,y)) for y in centers];weights=list(map(F,weights))
    assert all(w>0 for w in weights)
    return dict(label=label,n=n,N=len(centers),centers=centers,weights=weights,epsilon=F(epsilon),lambda_value=F(lam),W=sum(weights),
                actual_input='f(y)=sum_i w_i*1_{box(c_i,epsilon)}(y)/(2epsilon)^n; positive finite L1 density',reference_scale=F(reference_scale))


def fixtures():
    stages=[]
    pilots=[]
    for n in (1,2):
        src=source(f'single_diagonal_n{n}',n,[tuple(F(1) for _ in range(n))],[1],F(1,4),F(1,4**n))
        receivers=[tuple(F(0) for _ in range(n)),tuple(F(1 if j%2==0 else -1,32) for j in range(n)),tuple(F(-1 if j%2==0 else 1,32) for j in range(n))]
        pilots.append((src,receivers))
    tangent=source('tangent_breakpoint_n1',1,[(F(1),)],[1],F(1,4),F(2,5),F(5,2))
    pilots.append((tangent,[(F(0),)]));stages.append(('pilots_and_breakpoint_regression',pilots))
    for stage,specs in [('deep_correlated',((2,3),(4,6))),('wider_dimension_and_source_count',((4,8),(8,12)))]:
        arr=[]
        for n,N in specs:
            rng=random.Random(SEED+100*n+N);eps=F(1,16)
            centers=[]
            for i in range(N):
                main=F(12+i%7,16)
                centers.append(tuple(main+F(rng.randrange(-2,3),64) for _ in range(n)))
            integers=[1+(i%4) for i in range(N)];weights=[F(w,sum(integers)) for w in integers]
            provisional=source('tmp',n,centers,weights,eps,F(1))
            origin=tuple(F(0) for _ in range(n));lam=average(provisional,origin,F(2))/2
            assert lam>0
            # A genuine low-density box near receivers supplies nonzero deep
            # capture-age mass while preserving f(x)=lambda/4<=lambda/2.
            centers.append(origin);weights.append(lam*(2*eps)**n/4)
            src=source(f'{stage}_n{n}_N{N+1}',n,centers,weights,eps,lam)
            receivers=[origin,tuple(F(1 if j%2==0 else -1,64) for j in range(n)),tuple(F(-1 if j%2==0 else 1,64) for j in range(n))]
            arr.append((src,receivers))
        stages.append((stage,arr))
    return stages


def sturm_regressions():
    cases=[((F(0),F(1)),F(-1),F(1),1),((F(1),F(-2),F(1)),F(0),F(2),1),
           ((F(0),F(-1),F(0),F(1)),F(-2),F(2),3),((F(0),F(-1),F(0),F(1)),F(-1),F(1),1),
           ((F(0),F(0),F(0),F(-1)),F(0),F(2),0)]
    out=[]
    for p,a,b,expected in cases:
        count=root_count(p,a,b);assert count==expected
        out.append(dict(polynomial=p,left=a,right=b,expected_distinct_open_roots=expected,certified_open_root_count=count,sturm_sequence=sturm(p)))
    return out


def main():
    start=time.monotonic();records=[];root_regressions=sturm_regressions()
    for stage,fs in fixtures():
        cases=[]
        for src,receivers in fs:
            cases.append(dict(source=src,receivers=[first_contact(src,x) for x in receivers]))
        records.append(dict(stage=stage,cases=cases))
        print(stage,'receiver_certificates',sum(len(c['receivers']) for c in cases),'seconds',round(time.monotonic()-start,3),flush=True)
    receiver_cases=[r for stage in records for case in stage['cases'] for r in case['receivers']]
    out=dict(status='EXACT_VERIFIED',dependencies='Python standard library only',seed=SEED,
             scale_convention='Cube Q(x,L)=x+[-L/2,L/2]^n; A_L=L^-n integral_Q f.',
             overlap_polynomial_convention='Coefficient arrays ascending in L; numerator sum_i w_i product_j overlap_j, threshold lambda*(2epsilon)^n*L^n.',
             sturm_endpoint_convention='V(a+)-V(b-) counts distinct roots strictly in (a,b). Each one-sided sign uses the first nonzero exact Taylor derivative, including common gcd/repeated-root zeros.',
             sturm_regressions=root_regressions,stages=records,
             excluded_density_fee_premise='lambda*|{f>lambda/2}|<=2W by positive L1 Markov payment; only f(x)<=lambda/2 is checked at fixture receiver points.',
             counts=dict(stages=len(records),sources=sum(len(stage['cases']) for stage in records),receiver_certificates=len(receiver_cases),
                         exact_age_tail_comparisons=sum(len(r['age_tail_certificates']) for r in receiver_cases),
                         strict_event_receiver_certificates=sum(r['strict_event_claimed'] for r in receiver_cases),
                         equality_only_receiver_regressions=sum(not r['strict_event_claimed'] for r in receiver_cases),
                         breakpoint_contacts=sum(r['first_contact']['at_physical_breakpoint'] for r in receiver_cases),
                         tangent_level_contacts=sum(r['first_contact']['contact_classification']=='tangent_level_contact' for r in receiver_cases)),
             limitations=['These explicit box fixtures do not prove the general first-hit theorem.',
                          'Receiver points are diagnostics in Lebesgue coordinates, not event-volume or weak-type certificates.',
                          'Tangential threshold equality is distinguished from a strict above-threshold event.',
                          'No finite scale grid or maximizer is substituted for the global earliest contact.'])
    target=Path(__file__).with_name('firsthit_results.json');target.write_text(json.dumps(clean(out),indent=2,sort_keys=True)+'\n')
    print('DONE',out['counts'],'seconds',round(time.monotonic()-start,3),'bytes',target.stat().st_size,flush=True)


if __name__=='__main__':main()
