# 中心立方体第80轮：单侧首达与低占用余项归约

日期：2026-10-11。主目标 **UNPROVED／未完成**。全一般保留基准仍为 O(n log n)，本轮未证明一般 sqrt(n)n^{o(1)} 上界。

## 本轮一般输入的进展

对任意非负 L1 输入，取 S 为使 2^S>=2n 的最小正整数，epsilon=2^-S，alpha=(1-epsilon)^n>=1/2。真实核满足 Psi_epsilon>=alpha H，因此整个细软层尾项可直接吸收，有限望远镜只要求正向层输出越阈。此前为负向输出首达支付跨源相消强迫的要求，已从这条充分证明路线中移除。层内部的负源贡献仍须保留；删除它们会破坏消去。

对每个实际正向层首达，保留其原始有符号硬面通量与有利的背景漂移。大恢复时间或大背景占用组成的 load>=sqrt(n) 支路可按一般质量预算支付；平滑基线、连续高背景、锚点与连续通量例外也全部有显式费用。对任意有限物理尺度族 J subset [1,2]，本轮严格得到

    lambda |{max_J A_L f>lambda}|
      <= C sqrt(n) log^2(2+n) ||f||1
         +lambda |union_(s<S) E_short,s|.

这里 E_short,s 是正文 P80.5 完整定义的原始正向首达事件，已排除连续高背景和已付连续通量例外，且实际 load<sqrt(n)。特别地首达区间长度小于 2/sqrt(n)，其 P_a 占用小于 eta/(a sqrt(n))。**最后这一事件的统一弱体积仍未支付**；全尺度局部化也尚须完成。已付项的 sqrt(n)log²n 不是所求整体上界。

## 新的结构与失败机制

- 全尺度硬立方体首达：先支付 {f>lambda/2} 的 2||f||1 费用，余下实际首达来源后验满足 pi{H>=h}<=exp(-nh)，以及相应矩与指数矩界。这是任意输入的径向约束，不是来源方向独立性或接收体积预算。真实两箱 L1 输入在开观察区域上反驳按方向条件化后的指数尾加强式。
- 保留整个有符号 D 的共同物理来源 duty 给出合法覆盖证书及有限 LP 弱对偶。临界层 a=1/n 的实际 E2 核满足 H/32<=D_+<=H，说明未截断的来源强包络仍需 Omega(n) 费用。单原子的阈值 shutdown 费用为常数，但逐原子独立延伸在大量不同、紧密聚集的正来源上失败。共同来源分组与一致廉价覆盖仍未建立。
- 软层另外证明所有 0<a<=1/n 的正核夹逼 (na/(8e))H<=D_a^+<=(na/2)H。它说明“只控制正输出”合法，而“卷积前删除负核”会重新引入原始硬极大问题。

## 实际验证与证据边界

真实 E2 主程序进行三阶段测试：7组正 L1 箱混合、22个箱分量、592个原始空间接收点、12560个接收点/物理尺度组合、65456个核配置；35组阈值行中有172个核心正向包含检查。望远镜最大浮点残差1.11e-16，尾吸收未发现违反；64/128阶求积细化最大变化6.95e-8。5条实际正向 corridor 的积分恒等式最大残差1.02e-8。这些 corridor 未核验连续高背景及连续通量剔除，因此不称为完整 E_short 成员证书。保留 n16 的稀有事件采样方差失败，不用有限拟合推断维数阶。

另一主程序对真实正 L1 箱输入，用有理分段重叠多项式及 Sturm 序列排除所有更早的根，区分严格上穿与相切等号。三阶段有7组输入、19个接收点，其中18个严格首穿边界和1个排除于严格事件的切触回归；114个精确年龄尾区间通过。独审另外核验376个完整分段多项式、2214个直接重叠恒等式和158个前缀排根记录。首根隔离区间及全部年龄尾区间见下方独立笔记和 firsthit_results.json。固定接收点上的证明型数值不等于正体积弱型界。

两个主程序均由主代理在独立目录重放并逐字节核对 JSON；软层、硬面、覆盖守卫及最终独审实际执行。最终 receipts、哈希和完整执行输出收于 inventory.json。精确有限代数、解析一般证明、求积诊断与采样误差分别标注。

## 技能、来源、归档与复现

已重新检查64项规范技能入口，共277379字节、437个直接本地引用可读，相对第79轮入口未改变。本轮按实际需要使用 A02、B01、D04、G03、M04、N03、L03 等技能的适用边界；没有声称核验了未读文献、未实现的方向捕获树或未证熵预算。覆盖、软层、硬面使用 gpt-6-astra medium；数值、精确实现和独审使用 gpt-6.1-sol high。

所用真实 E2 连续通量、锚点和基线工具依赖 rounds/078/research.zip；有限证书的量化与 Fatou 转移依赖 rounds/079/research.zip。它们不提供未证明的一致廉价证书。所有接收积分保留原始 Lebesgue dx，不用来源概率代替。

解压本轮 research.zip 后，用 Python 3 标准库执行 `python3 -B probe.py` 和 `python3 -B firsthit_probe.py`。proof.md 中四个 Python 代码块依次为 soft_guard、hardface_guard、coverage_guard 和 audit_guard；提取至同目录执行。生产及主代理重放使用 Python 3.12.14。未编译 TeX、未生成 PDF，详细源保存为 proof.tex.txt。

GitHub 仅新增本轮 README 和一个7成员归档，并更新项目总览。中间草稿、重放副本和临时证书检查留在仓库外。一般正向短时低占用首达的统一费用与全尺度回代仍是后续必须完成的证明。

---


# R80 parent: a one-sided reduction to short, low-occupation positive corridors

**Status.** The main bound C_n^square<=sqrt(n)n^{o(1)} remains unproved. This section removes the unnecessary negative-output branch from the sufficient theorem, absorbs the fine tail pointwise, and pays a general positive-corridor load branch. It does not pay the remaining short low-load positive signed-face crossings. It applies to every nonnegative L1 input; the maximal operator on general f is obtained by replacing f with |f|.

The updated 64-tool constraints are retained. D04 requires a single actual joint law before entropy is used; this proof uses no unproved entropy budget. G03's private capture-tree mapping and N03's oscillatory interface are not assumed. Ordinary positivity, the previously proved true-E2 continuous flux bound, and deterministic first-hit integration supply the steps below. No source probability replaces Lebesgue receiver measure.

## P80.1 Positivity absorbs the entire fine tail

Write h=1_{[-1/2,1/2]}, H=h^tensor n, w(z)=integral_0^1 exp(-|z|/r)dr, phi=h*w, psi_a=(1-a)h+a phi and Psi_a=psi_a^tensor n. Fix f>=0 in L1(R^n), W=||f||1, a finite nonempty physical family J subset [1,2], and T=log 2. Put

    A_L=f*H_L, P_a,L=f*(Psi_a)_L,
    u_s(L)=P_(a_s/2),L-P_(a_s),L, a_s=2^(-s).

Choose S as the smallest positive integer with 2^S>=2n, epsilon=2^(-S), and alpha=(1-epsilon)^n. Bernoulli's inequality gives alpha>=1-n epsilon>=1/2. Pointwise

    Psi_epsilon >= alpha H,
    (H-Psi_epsilon)*f <=(1-alpha) A_L,
    alpha A_L <=P_epsilon,L
               =P_1,L+sum_(s=0)^(S-1) u_s(L).                (P1)

The second inequality is one-sided; it does not assert that the signed fine tail is nonnegative. No L1 maximal tail estimate is needed. All infinite remaining soft layers are represented by this exact finite endpoint comparison.

Set lambda>0 and

    eta=alpha lambda/(2S).

If max_J A_L>lambda and max_J P_1,L<=alpha lambda/2, at an actual hard maximizing scale L_H in J, (P1) gives sum_(s<S)u_s(L_H)>alpha lambda/2. Hence some u_s(L_H)>eta. In particular

    {max_J A>lambda} subset {max_J P_1>alpha lambda/2}
                         union union_(s<S){max_J u_s>eta}.   (P2)

Only positive values of the layer outputs are needed. The finite maximum uses a fixed index tie rule, so it is a Borel function. A negative u_s at other scales or layers simply lowers the sum; it does not produce another event to pay. This observation does NOT permit deleting the negative part of the kernel inside u_s=f*D_s. That stronger alteration is audited in the soft and coverage components and can restore the original hard-cube difficulty.

The R78 actual-E2 smooth baseline has the already-proved strong bound

    ||sup_(1<=L<=2) P_1,L||1 <=B_n W,
    B_n=1+T sqrt(7n/3).

Thus the first event in (P2) has lambda-weighted volume at most (2/alpha)B_n W. No negative-corridor forcing, Cmix estimate, or symmetric weak theorem is used.

## P80.2 High background and the continuous/anchor exception

Retain the original positive background

    F_s(L)=(P_(a_s/2),L+P_(a_s),L)/2.

Its kernel is a positive ray-decreasing probability kernel. The R78 window envelope gives ||sup_[1,2] F_s||1<=S_n W, S_n=1+nT. Use the CONTINUOUS high event

    E_high=union_(s<S){sup_[1,2] F_s>B}, B=sqrt(n) S lambda.

The ordinary union bound and Markov give

    lambda |E_high|<=S_n W/sqrt(n).                         (P3)

Using the continuous supremum here is intentional: a finite-library low-background condition alone does not control intermediate times in a continuous first-hit corridor. The coefficient is still independent of the library size. If only a finite-model covering certificate is being transferred, its larger finite-library low event may be used to dominate our smaller event, as explained in the R79 bridge.

For each s the retained R78 decomposition in t=log L is

    u_s(t)=A_s+R_s(t)+Y_s(t), A_s=u_s(0),
    R_s(t)=integral_0^t v_s(r)dr,
    u_s'=c_s+v_s-kappa_s u_s-gamma_s P_(a_s),
    kappa_s=n(1-a_s/2), gamma_s=n a_s/2.                    (P4)

Here c_s is the ORIGINAL signed hard-face difference, not the full moving-latent flux; v_s is the centered continuous difference. For L1 inputs these fields have the almost-everywhere absolutely continuous time representatives justified in R78 by the actual face measures and their L1 convolutions. We use the same source f and all physical scales on [0,T].

Define a single nonnegative exceptional density

    P'(x)=sum_(s<S)(|A_s(x)|+2 sup_(0<=t<=T)|R_s(t,x)|).

The proven anchor and continuous-flux budgets imply

    ||P'||1<=C'_P W,
    C'_P=2 floor(log_2 n)+4+2 C_0 sqrt(n),
    C_0=T sqrt(10/3)(3+2sqrt 2).                            (P5)

Finite truncation only decreases this infinite-layer upper bound. Delete E_cont={P'>eta/4}; its lambda-weighted volume is

    lambda |E_cont| <=(8S/alpha) C'_P W.                    (P6)

This is a strong positive-density estimate, not an addition of weak quasi-norms.

## P80.3 Actual positive corridors retain helpful background drift

Suppose x lies outside E_high and E_cont and max_J u_s(x)>eta. Since |u_s(0,x)|<=eta/4, continuity gives a first hit t_s of level eta in (0,T]. Let rho_s be the last hit of eta/2 before t_s. Then

    u_s(rho_s)=eta/2, u_s(t_s)=eta,
    eta/2<u_s(t)<eta for rho_s<t<t_s.

The definitions use the original u_s from the same input, not independently selected rows. Measurability can be checked directly. For a real z, the condition t_s<z is the union over rational q<z of {sup_[0,q] u_s>=eta}; the supremum equals its countable dense-time version. For a rational q<=t_s, rho_s>=q is equivalent to min_[q,t_s] u_s<=eta/2, because u_s(t_s)=eta and the path is continuous. This variable-interval minimum equals the infimum over rational v in [0,1] of u_s(q+(t_s-q)v), hence is measurable. These tests prove measurability of both times without assuming a general argmax selection theorem. No stochastic stopping theorem is invoked, and rho_s need not be a stopping time.

Write I_s=(rho_s,t_s), d_s=t_s-rho_s. Integration of (P4) gives the exact identity

    eta/2+kappa_s integral_I u_s+gamma_s integral_I P_(a_s)
          =integral_I(c_s+v_s).                            (P7)

The second restoring term has the favorable sign on a positive corridor. Because

    |integral_I v_s|=|R_s(t_s)-R_s(rho_s)|
                      <=2sup|R_s|<=eta/4,

we obtain the exact useful lower bound

    integral_I c_s >=eta/4+kappa_s integral_I u_s
                              +gamma_s integral_I P_(a_s). (P8)

Negative-output corridor identities and their adverse Cmix term are not needed for (P1)--(P8). Signed kernel cancellation within c_s and u_s remains essential.

## P80.4 A general paid load branch, with both layer factors retained

Let Face_b be the positive incoming hard-face measure convolved with f at softness b=a_s/2. Explicitly, before dilation it is

    (1-b) sum_(j=1)^n beta_j tensor psi_b^(other n-1),
    beta=(delta_(-1/2)+delta_(1/2))/2.

The original c_s=Face_b-Face_a obeys c_s<=Face_b. At every time its space integral is kappa_s W. This is an inequality about the actual face densities after convolution with L1 input; it does not bound the unsigned total variation of a different geometric flow.

Define the actual corridor load

    Lambda_s(x)=kappa_s d_s(x)
              +(2gamma_s/eta) integral_(I_s(x)) P_(a_s)(t,x)dt.

Since u_s>=eta/2 on I_s, (P8) yields

    eta(1+2Lambda_s)/4 <=integral_(I_s) Face_b.             (P9)

For any R>0, the one-corridor-per-receiver selection and Tonelli give

    eta |{x in the retained event: Lambda_s>=R}|
          <=4 kappa_s T W/(1+2R).                        (P10)

Indeed, integrate (P9) on that event and bound its selected time interval by [0,T] under the nonnegative Face_b density. No sourcewise private clock or probability on receivers enters this step.

Choose R=sqrt(n). Each layer then has an O(sqrt n) eta-weighted fee. Returning to the ORIGINAL lambda and summing S layers gives, explicitly,

    lambda |union_(s<S) E_load,s|
      <=(2S/alpha) sum_(s<S)4kappa_s T W/(1+2sqrt(n))
      <=8 T n S^2 W/[alpha(1+2sqrt(n))]
      <=8 T sqrt(n) S^2 W.                               (P11)

There are TWO factors S: one from lambda/eta and one from the union. Dropping either would be an incorrect weak-norm summation. The O(sqrt n log^2 n) loss is allowed by the original goal.

## P80.5 The remaining general event, without hidden exceptions

Let E_short,s consist exactly of receivers outside E_high and E_cont with max_J u_s>eta and Lambda_s<sqrt(n), using the original positive first-hit corridor above. Combining (P2), (P3), (P6), and (P11) yields

    lambda |{max_J A>lambda}|
      <= [ (2/alpha)B_n + S_n/sqrt(n)
           +(8S/alpha)C'_P
           +8TnS^2/(alpha(1+2sqrt(n))) ]W
         +lambda |union_(s<S)E_short,s|.                 (P12)

Every already-paid term is O(sqrt(n) log^2(2+n))W and all constants are explicit. The unproved remainder is exactly the last union, not an omitted negative or fine-layer branch.

At each receiver in E_short,s we know simultaneously

    eta/2<u_s<eta on I_s;
    F_s(t)<=B throughout [0,T];
    d_s<sqrt(n)/kappa_s<=2/sqrt(n);
    integral_I P_(a_s)<eta/(a_s sqrt(n));
    integral_I c_s>=eta/4+kappa_s integral_I u_s
                            +gamma_s integral_I P_(a_s).

The time bound may exceed T in small dimensions, which merely makes that particular restriction vacuous. The background integral bound uses a_s>0; all S retained layers have positive a_s. No claim says such short low-load events are rare. They remain possible for sharp positive inputs and are precisely where a shared-source geometric, covering, or random-process budget is still needed.

A sufficient next theorem is lambda|union E_short,s|<=C sqrt(n)log^A(2+n)W, uniformly in f, lambda, n, finite J and S as above. A separately proved bound on each layer must keep the lambda/eta conversion and its layer sum. A signed-layer mixed certificate may instead cover this positive event directly, preserving the same source and original positive selector. Neither existence theorem is established in this section.

For general L1 input the target uses |f|, so positivity at the start loses no generality. For the whole [1,2] window, grow nested finite families dense in scale and use continuity/monotone convergence of A_L. The final all-positive-scale localization still needs a legitimate proof with the desired constants; a one-window reduction is not the global theorem.

## P80.6 Numerical and logical boundaries

The accompanying actual-E2 program evaluates H, Phi and every retained Psi on registered finite physical libraries for nonnegative L1 box mixtures, checks the same-hard-winner telescoping and positive-threshold implication, and retains adverse or degenerate cases. Exact finite algebra is separated from E2 quadrature. No grid maximum is called the continuous maximum.

The soft component supplies the independent load-branch argument and the actual-kernel sign audit. At softness a about 1/n, discarding the negative kernel part makes the positive kernel comparable to the hard cube; that would replace the remaining problem by an equivalent hard maximal problem rather than solve it. The coverage component audits threshold-localized source duties; arbitrary nonatomic input still requires a genuine shared packet construction. The hardface component's actual first-hit source-age law is an additional necessary structure, not an independence assertion or volume budget. All of these statements preserve the unproved status of (P12)'s final term and of the requested global bound.


# R80: paying positive corridors with large damping or background occupation

Status: a general positive-corridor branch is paid at O(sqrt(n)) per layer. The remaining short, low-occupation signed-face branch is not paid. This is not a proof of the centered-cube target. The parent's one-sided finite-layer reduction is essential: it requires positive layer outputs, but does not permit deleting negative contributions inside a layer convolution. A02 is used only to check explicit pointwise domination and its budget direction; no external theorem from the skill is invoked.

## 1. Actual kernels and source

Let h=1_{[-1/2,1/2]}, w(x)=integral_0^1 exp(-|x|/r)dr, phi=h*w, psi_a=(1-a)h+a phi and Psi_a=psi_a^tensor n. Fix a in (0,1], b=a/2, f>=0 in L1, W=integral f, t=log L in [0,T]. Put P_a=f*(Psi_a)_L, u=P_b-P_a, kappa=n(1-b), gamma=na/2. All receivers are measured with dx. The source f, physical scale and receiver are common to every expression.

The established actual E2 flux identity is

    u'=c+v-kappa u-gamma P_a.                       (1)

Here c=F_b-F_a is the signed hard-face difference, F_a>=0 is the convolution with (1-a) sum_j beta_j tensor psi_a on other coordinates, beta=(delta_{-1/2}+delta_{1/2})/2, and v=f*(B_b-B_a)_L is the centered continuous flux. The R78 Fisher calculation gives

    integral F_b dx=kappa W,
    integral |v| dx <= A_a W,
    A_a=sqrt(n V(a))+sqrt(n V(b)), V(a)=10a/3-a^2.   (2)

The flux identity holds in space-time L1 with an absolutely continuous representative for almost every receiver. This follows by integrating the finite hard-face measures over t and Tonelli; no differentiability of f is assumed. We use this representative and actual first hits. Atomic diagnostic inputs require full product jumps at tied hard faces, and are not substituted for this L1 assertion.

## 2. A paid large-load branch on actual positive corridors

Fix eta>0 and omit the anchor event u(0,x)>=eta/2, paid separately by the parent's reduction. If u reaches eta, let tau be its first such hit and rho the last preceding hit of eta/2. Thus I=(rho,tau), d=tau-rho and eta/2<=u<=eta throughout I. This is a deterministic last-exit construction, not a claim that rho is a stopping time. Integrating (1) gives exactly

    eta/2+kappa integral_I u+gamma integral_I P_a
          =integral_I(c+v).                         (3)

Define the dimensionless actual load

    Lambda(x)=kappa d+(2 gamma/eta) integral_I P_a.  (4)

For any measurable subset E_R of these receivers on which Lambda>=R>=0, (3), positivity and (2) give

    eta |E_R| <= 2 T (kappa+A_a)/(1+R) W.            (5)

Proof: the left side of (3) is at least eta(1+Lambda)/2. On its right, c+v<=F_b+|v| pointwise. Integrating over the receiver-dependent corridors is bounded by the integral of this nonnegative expression on the entire space-time window. Equation (2) proves (5). No receiver change of variables, private posterior, finite entropy assumption, or independence of f is used. The event can include any additional actual winner or low-background restrictions.

Taking R=sqrt(n), and using kappa<=n and A_a<=2sqrt(10n/3), gives the explicit general bound

    eta |E_sqrt(n)| <= 2T [sqrt(n)+2sqrt(10/3)] W.   (6)

Consequently, S layers at equal thresholds eta=lambda/(c S), for any fixed c>0, have union budget at most

    lambda |union E_sqrt(n),s|
      <= 2c T S^2 [sqrt(n)+2sqrt(10/3)] W.           (7)

For the parent's S=O(log(n+2)) finite one-sided reduction this is sqrt(n) times a polylogarithm. This pays the indicated general branch, not all positive crossings.

A simpler sufficient branch is d>=h: equation (5) with R=kappa h gives

    eta |E_{d>=h}| <= 2T(kappa+A_a)/(1+kappa h) W.   (8)

The load formulation also pays sufficiently large background occupation even when d is short. Conversely, the residual branch Lambda<sqrt(n) satisfies BOTH

    d<sqrt(n)/kappa<=2/sqrt(n),
    integral_I P_a < eta/(a sqrt(n)).               (9)

These are necessary residual restrictions, not a bound on its receiver volume. In particular small occupation does not by itself pay sharp face arrivals. Retaining gamma P_a improves the split, but (5) still used an O(n) gross face budget divided by a genuinely large load. No such divisor has been proved on the residual branch.

## 3. Why positive output is different from a positive kernel

The actual scalar kernel obeys phi<=phi(0)<=1-3/(4e)<3/4. Indeed
phi(0)=1-2 integral_0^1 r exp(-1/(2r))dr, and restricting the last integral to [1/2,1] proves the displayed bound, using e<3. Also

    phi(1/2)=integral_0^1 r(1-exp(-1/r))dr
       >= [(1-exp(-2))+3(1-exp(-1))]/8 > 1/3.       (10)

For the last strict inequality, e^-1<3/8 gives the rational lower bound 175/512>1/3. Thus phi>=1/3 inside the hard interval.

Let D_a=Psi_b-Psi_a. For every n>=1 and 0<a<=1/n,

    D_a^+ is supported on Q=[-1/2,1/2]^n,
    (na/(8e)) H <= D_a^+ <= (na/2) H, H=1_Q.      (11)

Proof of support: inside Q every psi_b>=psi_a. Outside Q one coordinate has ratio psi_b/psi_a=1/2. Each other coordinate has ratio at most (1-a/2)/(1-a). For n>=2, a<=1/n yields the product ratio at most

    (1/2)(1+1/[2(n-1)])^(n-1) < sqrt(e)/2 <1.

The n=1 statement is immediate, including a=1. On Q telescope the product difference, with r_i=1-b(1-phi_i), s_i=1-a(1-phi_i). Every r_i-s_i lies between a/8 and a/2. Thus the difference lies between (na/8)(1-a)^(n-1) and na/2. For n>=2 the lower factor is at least (1-1/n)^(n-1)>=e^-1; for n=1 the empty product is one. This proves (11).

There are useful additional exact support ranges: n=2, all a<=1; and n<=4, a<=1/2. For the former, the interior coordinate ratio is maximized at a=1 and phi=1/3, giving a value strictly less than 2 by (10), hence the exterior product is less than one. For the latter, the interior ratio is at most 5/4; the exterior product is at most (1/2)(5/4)^3=125/128<1. These support assertions do not assert the fine-layer lower bound outside its stated a<=1/n range.

For every nonnegative input, all physical scales and fine a,

    (na/(8e)) (f*H_L) <= f*(D_a^+)_L
                                   <= (na/2)(f*H_L). (12)

Taking scale suprema preserves both inequalities. At a=1/n the maximal convolution with the positive kernel D_a^+ is comparable with the original hard cube maximal operator, with absolute constants. Therefore replacing (f*D_a)_+ by f*D_a^+ is a legal upper bound, but proving the desired weak estimate for that upper bound is already as hard as the original target. It cannot serve as a cheap payment for positive layer events. This does not contradict the parent's one-sided telescoping: deleting negative OUTPUTS is valid in that upper bound, whereas deleting source contributions destroys cancellation within the positive outputs.

## 4. Remaining interface and validation scope

The general missing estimate is the weak receiver budget for the actual positive corridors satisfying (9), with their signed c and beneficial gamma P_a retained. The hard-face agent's first-hit age representation may address such short arrivals; no automatic implication from small occupation to that budget is claimed here. The earlier negative Cmix branch is auxiliary and not required by the new sufficient one-sided route.

The companion numeric report tests genuine E2 convolutions and the parent's actual common hard winner in three stages. The embedded guard below independently checks actual E2 sign geometry in three dimensional/softness stages, the fine-kernel sandwich, and the exact algebra/constants of (3)-(9). Simpson quadrature is a diagnostic, not an interval certificate. The proofs above establish universal statements; sampled values do not.

The space-time face convolutions in (1)-(5) mean their Radon–Nikodym densities after convolving with f and integrating t. All inequalities between these densities hold almost everywhere. A continuous, jointly measurable representative outside a null receiver set supplies measurable first/last level times by the usual rational-time approximations. The parent's independently paid centered-flux exception can sharpen (5): if |integral_I v|<=eta/4 on the retained receivers, then

    eta |E_R| <= 4 kappa T/(1+2R) W.                (13)

Indeed integral_I c>=eta/4+kappa integral_I u+gamma integral_I P_a>=eta(1+2Lambda)/4. This statement includes its extra paid-exception hypothesis explicitly; (5) needs no such hypothesis. The parent's main reduction supplies the exception through its centered-flux primitive. Both variants give S^2 sqrt(n), not S sqrt(n), when S layers each receive a threshold proportional to lambda/S.

The hard first-hit age constraint concerns the global hard-kernel first hit. It cannot be inserted at the private soft corridor times rho or tau without a separate common-selector argument.

## 5. Independent executable guard

```python
import math, random

def phi(x, N=1200):
    x=abs(x)
    def g(t):
        if not t: return 0.0
        if x<=.5:
            return t*(2-math.exp(-(x+.5)/t)-math.exp(-(.5-x)/t))
        return t*(math.exp(-(x-.5)/t)-math.exp(-(x+.5)/t))
    return (g(0)+g(1)+sum((4 if j%2 else 2)*g(j/N) for j in range(1,N)))/(3*N)

def psi(a,x):
    return (1-a)*(abs(x)<=.5)+a*phi(x)

def prod(xs):
    return math.prod(xs)

rng=random.Random(8001)
checks=0
assert phi(0)<.75 and phi(.5)>1/3
checks+=2
for n,a in [(2,1.0),(4,.5),(8,.125)]:
    low=1.0
    high=-1.0
    for row in range(36):
        xs=[rng.uniform(-.49,.49) for _ in range(n)]
        if row%2: xs[row%n]=rng.choice([-1,1])*rng.uniform(.501,1.7)
        D=prod(psi(a/2,x) for x in xs)-prod(psi(a,x) for x in xs)
        inside=all(abs(x)<=.5 for x in xs)
        assert (D>=-1e-13) if inside else (D<0)
        checks+=1
        if a<=1/n:
            lo=n*a/(8*math.e) if inside else 0
            hi=n*a/2 if inside else 0
            assert lo-1e-13<=max(D,0)<=hi+1e-13
            checks+=1
        low=min(low,D); high=max(high,D)
    print('E2_sign_quad',n,a,'D_range',format(low,'.8g'),format(high,'.8g'))
# A genuine positive L1 box input: tensor uniform [-r,r], mass one.
# The source integrals are quadrature; no atomic source is substituted.
def boxpsi(a,x,L,r=.12,N=40):
    def g(y): return psi(a,(x-y)/L)/L
    step=2*r/N
    return step*(g(-r)+g(r)+sum((4 if j%2 else 2)*g(-r+j*step) for j in range(1,N)))/(6*r)
for n,a in [(2,1.0),(4,.5),(8,.125)]:
    # Stay strictly inside each hard interval so source integration has no jumps.
    x=[.2]*n
    for L in [1,1.2,1.6]:
        pb=prod(boxpsi(a/2,z,L) for z in x)
        pa=prod(boxpsi(a,z,L) for z in x)
        assert pb>pa>0
        if a<=1/n:
            H=L**(-n)
            assert n*a*H/(8*math.e)<=pb-pa<=n*a*H/2
            checks+=1
        checks+=1
    print('L1_box_positive_quad',n,a,'last_u',format(pb-pa,'.8g'))
for n in [1,2,4,8,32,128]:
    for a in [1,.5,.125,1/n]:
        b=a/2; k=n*(1-b); gam=n*a/2
        A=math.sqrt(n*((10/3)*a-a*a))+math.sqrt(n*((10/3)*b-b*b))
        assert 2*(k+A)/(1+math.sqrt(n))<=2*(math.sqrt(n)+2*math.sqrt(10/3))+1e-12
        eta=.3; d=.07; occ=.12
        load=k*d+2*gam*occ/eta
        assert abs(eta/2+k*eta*d/2+gam*occ-eta*(1+load)/2)<1e-12
        assert abs(eta/4+k*eta*d/2+gam*occ-eta*(1+2*load)/4)<1e-12
        checks+=3
print('PASS',checks,'assertions; quadrature diagnostics, no interval certification')
```

Actual guard stdout:

```text
E2_sign_quad 2 1.0 D_range -0.029142473 0.32846671
E2_sign_quad 4 0.5 D_range -0.020090718 0.27340819
E2_sign_quad 8 0.125 D_range -0.011567486 0.18540132
L1_box_positive_quad 2 1.0 last_u 0.1168505
L1_box_positive_quad 4 0.5 last_u 0.039729869
L1_box_positive_quad 8 0.125 last_u 0.0038988309
PASS 230 assertions; quadrature diagnostics, no interval certification
```

Guard SHA256: `79ce78c9a32eea2da21548eba24d9e2ec40c3f94caaee8e4c5a5b078087fd572`.


# R80: paid first-hit selection and its exact source-age constraint

**Status.** No new general square-root bound for positive hardface corridors is proved here. This component establishes a genuine all-input selection rule with a paid exception and a sharp radial posterior constraint. It also gives an actual positive-volume L1 counterexample to the tempting conditional/angular strengthening. The remaining source-direction occupation estimate is explicit. This is not a replacement of the target by a special input class.

Updated skills read in R80: G03 and M04. G03 does not provide a private directional capture theorem from a diagonal/Gram estimate; M04 does not certify a general selector without its measurability conditions. The selector below is constructed directly from continuous cube averages and rational times. R78/R79 J04/E01/J05 boundaries remain in force. No martingale, conditional coordinate independence, or stochastic compensator is inferred.

## 1. A complete paid selection for positive hard crossings

Let f>=0 in L1(R^n), W=integral f, lambda>0, and

    A_r f(x)=(2r)^(-n) integral_(x+[-r,r]^n) f(y)dy.

Here r is half-side length, whereas previous notes used full side L=2r. Let E={sup_(r>0) A_r f>lambda}. Pay

    E0={f>lambda/2}, lambda |E0|<=2W.                         (1)

Outside E0 and the null set of non-Lebesgue points, A_r f(x) tends to f(x)<=lambda/2 as r decreases to zero. Also A_r f(x)<=W/(2r)^n tends to zero at infinity. A_r is continuous for r>0: absolute continuity of the f integral and null boundaries justify this directly. Therefore every x in E\E0 has a finite strictly positive first crossing radius

    r_*(x)=inf{r>0:A_r f(x)>lambda},
    A_(r_*)f(x)=lambda, A_r f(x)<=lambda for every r<r_* .    (2)

The infimum may be taken over positive rationals because the strict crossing set is open in r. Its sublevel events are countable unions of Borel events, so r_* is Borel on the selected set. This is an actual global first hit, not the radius that maximizes the output and not the first point of a finite grid. The rule covers every positive hard crossing after the explicit payment (1); there is no unpaid exceptional input family.

## 2. Exponential age domination of the true captured-source posterior

At each selected receiver define the probability measure

    pi_x(dy)=f(y)1{|x-y|_infty<=r_*}/[lambda(2r_*)^n] dy,
    H_x(y)=log[r_*/|x-y|_infty] >=0.                       (3)

The single point y=x is null for L1 input. H is the logarithmic time since this actual source first entered the centered expanding cube. It is invariant under artificial subdivision of source labels.

For every h>=0, exactly

    pi_x{H>=h}
      =exp(-nh) A_(r_*exp(-h))f(x)/lambda
      <=exp(-nh).                                        (4)

The inequality is the genuine first-hit exclusion (2). Thus the *unconditional captured-source* random variable nH is stochastically dominated by an exponential variable of mean one. Tonelli/layer cake yields, for integers k>=1 and 0<=theta<1,

    E_pi H^k <=k!/n^k,
    E_pi exp(theta nH)<=1/(1-theta).                     (5)

The proof of the exponential moment is 1+integral_0^infty theta n exp(theta nh) pi{H>h}dh. The moment at theta=0 equals one. These bounds are uniform in the input, source count, selected radius, dimension, and threshold. They use the true source posterior only after the receiver x has been chosen under dx; they do not replace receiver volume by source probability.

This differs from the R79 free age truncation: (4) is a constraint supplied by actual first-hit selection, with no age chosen in advance and no large-n approximation. For example a captured source of age at least c/n has posterior mass at most exp(-c), simultaneously for all c>=0.

The scope is essential. At a first crossing only within [r0,2r0], (4) follows merely while r_*exp(-h)>=r0; earlier radii are not controlled. At a first registered grid crossing the corresponding constraint holds only at registered earlier radii. At an arbitrary private positive soft-layer corridor, the hard averages need not have stayed below lambda. None of these selectors may silently be substituted into (4).

## 3. Why radial domination does not create independent directions

Let J_x(y) be the smallest coordinate attaining |x-y|_infty, together with its sign if desired. Neither a uniform conditional distribution of J, conditional exponential ages given J, nor independence of source coordinates follows from (4). Here is an actual L1 example, with positive-volume stability.

Work in n=2 and let f be the sum of two normalized box densities with masses p and 1:

    inner source B1=[1/2,3/5] x [-1/20,1/20], mass p=5/918;
    outer source B2=[-1/20,1/20] x [1,2], mass 1;
    lambda=10/459, r_*=11/10 at x=0.                    (6)

In B1 the dominant source direction is coordinate 1; in B2 it is coordinate 2. At r<1, the hard average is at most p<lambda (and vanishes below r=1/2). For 1<=r<=11/10, the captured mass is p+r-1, so

    A_r(0)=(p+r-1)/(4r^2),
    dA_r/dr=[2(1-p)-r]/(4r^3)>0.

The rational identity (p+1/10)/(4(11/10)^2)=lambda proves that (6) is the actual global first hit, not a scale-grid surrogate. Also f(0)=0, so the paid exception (1) does not remove the receiver.

All inner sources have distance at most 3/5. Taking h=log(4/3) gives r_*exp(-h)=33/40>3/5. Hence

    pi{H>=log(4/3) | J=1}=1 >9/16=exp[-2log(4/3)].      (7)

By contrast, the unconditional old mass is pi(J=1)=25/484, fully consistent with (4). Conditional angular normalization amplifies a small old group; marginal exponential domination does not survive that normalization.

This is not just a single receiver. The explicit open receiver square |x_i|<1/100 works. The source directions remain unique and f(x)=0. Before the outer source enters, A_r<=p/(98/100)^2<lambda. At r=21/20 even the largest outer captured mass p+3/50 gives A_r<lambda; at r=23/20 even the smallest mass p+7/50 gives A_r>lambda. On the relevant interval the derivative numerator 2(1-x_2-p)-r is positive. Thus the true first radius lies in (21/20,23/20), while (3/4)r_*>63/80>61/100 contains every inner source. Conditional age probability in (7) stays exactly one. This proves positive Lebesgue receiver volume for a fixed f and fixed lambda; it is not a lower bound against the desired maximal theorem.

A complementary family shows maximal directional bias while preserving (4). Put a unit-mass source on [1,2] in coordinate 1 and [-1/20,1/20] in every other coordinate. At x=0 choose r_*=1+1/(4n) and lambda=(r_*-1)/(2r_*)^n. All earlier averages are smaller because their derivative numerator is n-(n-1)r>0 through r_*. Every captured source has J=1. The same property holds on a small open receiver neighborhood. Therefore a fixed-coordinate uniformity premise cannot be rescued merely by imposing the exact first-hit age bound.

## 4. Exact remaining source-direction interface

For a measurable subset F of the selected receivers, the posterior identity gives

    lambda |F|
      =integral f(y) [ integral_F (2r_*(x))^(-n)
           1{|x-y|_infty<=r_*(x)} dx ] dy.              (8)

Formula (4) constrains the radial conditional distribution at each receiver in (8), but does not yet bound the mass-weighted source occupation on its right. A sufficient general next theorem must control this occupation by sqrt(n) times a subpolynomial loss, while using the actual common f and first radii, or supply a paid division into directional/source branches. The example above excludes replacing that joint estimate by a conditional exponential-age hypothesis along every direction.

There is a legitimate connection to positive soft layers only when they are evaluated at this same hard first hit: the captured hard-source distribution there satisfies (4). A positive soft layer selected at its own unrelated first corridor does not inherit it. The favorable positive-corridor equation still reads

    eta/2+kappa integral_I u+gamma integral_I P_a
       =integral_I(c_a+v_a),

and both nonnegative drift terms remain on the left. This component neither pays c_a nor claims that (4) alone pays the right side. The separate long-corridor payment in the soft component should not be counted as a short-corridor solution.

## 5. Three-stage guard on actual positive L1 inputs

Each finite-source object below is a positive mixture of normalized physical boxes, not a point-mass surrogate. At x=0, an axis box starts at radius s>=1 in its long direction, has width 1/2, and has short-coordinate support [-1/20,1/20]. Through the selected radius all short directions are captured, so its captured mass is exactly p times clip((r-s)/(1/2),0,1). The chosen r_*=1+1/(4n) lies below n/(n-1) times every active start (n=1 has no upper critical radius); hence the mixture hard average is strictly increasing wherever capture has begun before r_*. The selected lambda therefore defines the exact global first hit. Tail checks use rational q=exp(-h), avoiding numerical first-root inference.

Stage one checks initial single/multiple-box cases. Stage two checks the exact two-box conditional-age counterexample and mixed directions/random positive source masses. Stage three expands dimension and source count independently, includes complete directional bias, and compares exact tail inequalities with floating moment diagnostics. No estimated probability or fitted exponent enters the proof.

```python
from fractions import Fraction as F
from math import log
import random
rng=random.Random(80041)

def mass(boxes,r):
 return sum(p*min(F(1),max(F(0),(r-s)/width)) for p,s,width,j in boxes)

def check(n,boxes):
 r=F(1)+F(1,4*n)
 assert all(s>=1 and s<r<s+w for p,s,w,j in boxes)
 # Exact derivative sign on every active piece before the chosen first hit.
 assert all(n*s-(n-1)*r>0 for p,s,w,j in boxes)
 M=mass(boxes,r);lam=M/(2*r)**n
 assert M>0 and lam>0
 count=0
 for q in [F(1,10),F(1,2),F(9,10)]+[F(1)-F(k,100*n) for k in range(31)]:
  assert mass(boxes,q*r)/M<=q**n
  count+=1
 # Actual posterior E H, using elementary integration of the physical boxes.
 mean=sum(float(p/w)*((float(r-s))-float(s)*log(float(r/s))) for p,s,w,j in boxes)/float(M)
 assert 0<=n*mean<=1+1e-10
 return count,n*mean

# Stage 1: exact first-hit derivative/tails for simple physical L1 boxes.
checks=0
for n in (1,2,4):
 for N in (1,2,4):
  boxes=[(F(1,N),F(1)+F(i,100*n),F(1,2),i%n) for i in range(N)]
  c,m=check(n,boxes);checks+=c
print('stage1 exact tail checks',checks,'physical inputs',9)
# Stage 2: genuine conditional-age failure at a transverse global first hit.
p=F(5,918);lam=F(10,459);r=F(11,10);q=F(3,4)
assert (p+F(1,10))/(4*r*r)==lam
assert p<lam and 2*(1-p)-r>0 and q*r>F(3,5)
assert p/(p+F(1,10))==F(25,484)<=q*q
assert F(1)>q*q # Conditional old probability given J=1 is exactly one.
# Explicit positive-volume receiver square |x_i|<1/100.
assert p/F(98,100)**2<lam
assert (p+F(3,50))/(4*F(21,20)**2)<lam
assert (p+F(7,50))/(4*F(23,20)**2)>lam
assert 2*(1-F(1,100)-p)-F(23,20)>0
assert F(3,4)*F(21,20)>F(61,100)
print('stage2 conditional old probability=1; marginal=25/484; exponential comparison=9/16')
for n in (2,4,8):
 for N in (2,8,32):
  weights=[rng.randrange(1,21) for _ in range(N)];total=sum(weights)
  boxes=[(F(w,total),F(1)+F(rng.randrange(10),100*n),F(1,2),rng.randrange(n)) for w in weights]
  c,m=check(n,boxes);checks+=c
print('stage2 mixed-direction positive L1 inputs',9)
# Stage 3: dimension/source growth, including fully correlated direction.
for n in (16,64,256,1024,4096):
 for N in (1,8,64):
  boxes=[(F(1,N),F(1)+F(i%10,100*n),F(1,2),0) for i in range(N)]
  c,m=check(n,boxes);checks+=c
  assert all(j==0 for p,s,w,j in boxes)
  print('stage3 n',n,'source_boxes',N,'n_times_mean_age',m,'direction=0 with posterior probability1')
print('PASS exact rational tail comparisons',checks,'no source-occupation or sqrt(n) bound claimed')
```


# R80 coverage — one-sided source duties and the critical-layer obstruction

**Status.** The one-sided grouped-source certificate below is valid for arbitrary finite positive input measures. Its finite labelled-noise implementation is an explicit LP on complete Lebesgue cells. No uniform cheap-certificate existence theorem is proved. A new actual-E2 calculation shows that at delta=1/n its cancellation-aware source price is comparable to the hard-cube duty price, including an Omega(n) untruncated price. Threshold shutdown gives a constant-cost certificate for one atom, but its naive sourcewise extension fails on arbitrarily finely split, distinct positive sources. These are tests of the proposed general mechanism, not substitutes for the main theorem. The general sqrt(n)n^{o(1)} weak bound remains open in this work.

B01 was applied only through direct finite weak duality; no infinite-dimensional strong duality is invoked. The objective file, R79 finite-family transfer, and the parent one-sided steering are retained. All receiver integrals below are Lebesgue integrals. The physical input is positive, as permitted by the original maximal operator acting on |f|.

## 1. Actual E2 kernels and a positive-source certificate

Let h=1_{[-1/2,1/2]}, w(z)=integral_0^1 exp(-|z|/r)dr, phi=h*w, psi_a=(1-a)h+a phi, Psi_a=psi_a^{tensor n}, and D_delta=Psi_{delta/2}-Psi_delta. Use D_{delta,L}(x)=L^{-n}D_delta(x/L). Fix a finite physical family J in [1,2], a finite positive source mu, and an actual selector L(x) maximizing T_L=mu*D_{delta,L}, with a deterministic tie convention. E can be the entire selected-low positive event {max_J T>tau, F_{L(x)}<=B}, or the robust-low subset using max_J F<=B. No negative crossing is required.

For a measurable, receiver-independent duty d_y(L) in [0,1], define

    T_d(x)=integral d_y(L(x)) D_{delta,L(x)}(x-y) dmu(y),
    P_delta^+(d)=integral_Rn max(0,max_{L in J} d(L)D_{delta,L}(z)) dz.

Then

    integral_E T_d(x) dx <= integral P_delta^+(d_y) dmu(y).

Indeed each signed summand is bounded above by its nonnegative scale supremum; translate x-y and apply Tonelli to the upper bound. The signed integral is integrable because J is finite and D is integrable. This holds for nonatomic mu without assigning a positive atom mass to each y. The duty must multiply the entire D profile conditional on the original physical y; it is common across all mask/noise realizations. Internal cancellation is therefore retained. This is not the R78 absolute joint-source duty.

Let V_l>=0 be any rigorously paid columns with integral_E V_l<=K_l. If

    T_d(x)+sum_l alpha_l V_l(x)>=tau   a.e. on E, alpha_l>=0,

then

    tau |E| <= integral P_delta^+(d_y)dmu(y)+sum_l alpha_l K_l.       (1)

Every use of a representative column is paid. If instead a capacity-limited representative family is used, impose its actual common-source capacity constraints; neither (1) nor the LP below supplies free repeated source mass. The original selector and original E are fixed when duties are optimized. There is no claim that the residual field is a convolution against a new fixed physical source.

## 2. An executable finite LP retaining the signs

For a finite labelled joint-noise approximation, keep every original Bernoulli mask tag, even when soft noise quantizes to zero. Conditional on physical source y_i of mass p_i, the same finite kernel D_k is used. The anchored kernels D_k(z) are finite signed sums of translated cube indicators. Form the COMPLETE rectangular face arrangement over all k, with bounded cells a of volume v_a and constant kernel values D_{ka}; outside their bounded union every D_k vanishes. Independently form the full receiver arrangement including all translated source faces and all representative faces, then retain exactly the cells r of the actual positive selected-low event. These have volume v_r, actual selector k(r), signed source coefficients A_{ri}=p_i D_{k(r)}(x_r-y_i), and constant paid columns V_{rl}. No sample grid replaces this arrangement.

The primal is

    minimize sum_{i,a} p_i v_a e_{ia}+sum_l K_l alpha_l
    subject to sum_i A_{ri} d_{i,k(r)}+sum_l V_{rl}alpha_l >= tau, all r;
               e_{ia} >= D_{ka}d_{ik}, all i,a,k;
               0<=d_{ik}<=1, e_{ia}>=0, alpha_l>=0.

The epigraph is exactly P_delta^+(d_i), including negative D entries. Thus every feasible point gives (1) for the whole finite-model continuum event. Taking d=1 is feasible, but its cost need not be cheap. This is a finite implementation, not a claim that continuous E2 has finitely many cells. R79 transfers a *uniformly cheap* family if one is found; it does not establish that missing estimate. Quantized phi is not assumed ray decreasing.

For completeness a direct weak dual uses y_r>=0, beta_{iak}>=0, gamma_{ik}>=0:

    maximize tau sum_r y_r - sum_{i,k} gamma_{ik}
    sum_r y_r V_{rl} <= K_l,
    sum_k beta_{iak} <= p_i v_a,
    sum_{r:k(r)=k} y_r A_{ri} <= sum_a beta_{iak} D_{ka}+gamma_{ik}.

Multiplying the primal row, epigraph and upper-bound inequalities proves dual<=primal. Signed A and signed D remain signed. Cell volumes are already incorporated in epigraph costs; y_r is an integrated row multiplier, not a sampled probability. No rank assumption is needed for this weak inequality. These formulas permit certified lower bounds on the proposed certificate price, but no such uniform lower bound for general input is asserted here.

## 3. Critical-layer theorem: cancellation alone does not cheapen the duty

For every n>=2 and delta=1/n, with c=1/32,

    c H <= (D_delta)_+ <= H,
    D_delta<=0 outside [-1/2,1/2]^n.                              (2)

Boundary conventions are immaterial for integrals. Here is a proof with explicit constants. The even decreasing density w gives phi(x)<=phi(0). Since integral w=1,

    1-phi(0)=2 integral_0^1 r exp(-1/(2r))dr >= 1/(2e).

For x inside the cube put a_j=1-phi(x_j), so 1/(2e)<=a_j<=1. Writing P(u)=product_j(1-u a_j),

    D_delta(x)=integral_{delta/2}^{delta} sum_j a_j product_{l!=j}(1-u a_l)du
             >= (1/(2n)) [n/(2e)] (1-1/n)^{n-1}
             >= 1/(4e^2)>1/32.

The last inequality follows from (1-1/n)^{n-1}>=e^{-1} and e^2<8. Also D<=Psi_{delta/2}<=1 inside.

If exactly k>=1 coordinates are outside the cube, the ratio of the two nonnegative endpoints is

    Psi_{delta/2}/Psi_delta
    =2^{-k} product_{j inside}(1-a_j/(2n))/(1-a_j/n)
    <=2^{-k}[(2n-1)/(2n-2)]^{n-k}
    <=(1/2) exp(1/2)<1.

The endpoints are positive since phi>0; hence the signed difference is negative. This proves (2) for the ACTUAL continuous E2 kernel, not merely a finite noise approximation.

Let L_1<...<L_m and v_j=L_j^n,v_0=0. Put

    E_n(d)=sum_j (v_j-v_{j-1}) max_{k>=j} d(L_k)/v_k.

The nested hard cubes give the exact layer formula integral max_k d_k (H)_{L_k}=E_n(d). Equation (2) yields

    (1/32) E_n(d) <= P_{1/n}^+(d) <= E_n(d).                    (3)

Thus retaining the full mask cancellation improves a genuine accounting error but cannot by itself give a sublinear strong envelope price. For the continuous window [1,2], E_n(1)=1+n log 2. Dense finite families tend to this value. In particular P^+(1)>= (1+n log 2)/32. This is an obstruction to this untruncated source price, not a large weak constant. It requires no source-count or scale-count limit hidden in a constant.

## 4. Threshold shutdown works for an atom and fails sourcewise

For mu=p delta_y, E={max_J p D_L(x-y)>tau}, take

    d(L)=min(1, tau L^n/(c p)) 1{L^n<p/tau}, c=1/32.

On any selected crossing, (2) forces x-y in the cube and L^n<p/tau. If d=1 the row is covered. If d<1, p d D_L>=tau. Also d(L)/L^n<=tau/(cp), and all its nonzero scales have volume<p/tau. Therefore E_n(d)<=1/c and (1) costs at most32p, uniformly over J,n,tau. The cutoff is essential: min(1,tau L^n/(cp)) without shutdown retains a logarithmic large-scale tail. This one-atom certificate is only a calibration of the general mechanism.

A naive independent application to masses p_i fails even when all points are distinct. Take W=1, tau=c/2=1/64, N>64 equal masses, all distinct y_i in [-1/8,1/8]^n, and J containing L=1 with every L>=1. For x in [-1/4,1/4]^n all x-y_i are inside the unit cube, so T_1(x)>=c>tau. Nevertheless p_i/tau=64/N<1 and every duty vanishes at EVERY scale in J. Thus T_d=0 on this positive-volume subset of the actual positive-crossing event. For this clustered example F_L<=L^{-n}<=1, so any B>=1 keeps it in the actual selected-low event. This failure is not due to equal-site bookkeeping, a private receiver-dependent representative, a boundary tie, or a finite grid. Refining the source increases N while leaving the difficulty intact.

Aggregation of that cluster into one packet can repair this example; doing so in every geometry requires a common packet construction with a proved total cost. An arbitrary packet does not satisfy the pointwise lower bound D_L*mu_P>=c w_P/L^n whenever only a fraction of it is captured. Consequently replacing p by packet mass in the atom proof is invalid. Assigning an infinitesimal mass to each nonatomic y is likewise invalid. These are precisely the missing steps, not technical limits removed by R79.

## 5. Remaining general target

Find, for every actual positive selected-low event at the finitely many physical soft layers, common physical-source duties and paid representative columns satisfying the rows in (1), with total cost <=sqrt(n) polylog(n) W after the layer sum, independently of source count and J. Alternatively give a paid general decomposition that removes the rows obstructing such a bound. Equation (3) says that a successful proof must genuinely localize scale duty or use representative geometry; the signs alone cannot reduce the critical-layer source envelope below order n. Section 4 shows why localization cannot be performed independently on arbitrarily refined source atoms. This round proves neither the required common packet ownership nor a uniform cheap LP optimum. The main weak theorem is not completed.

## 6. Deterministic three-stage guard

The following stdlib program evaluates the actual continuous E2 phi by midpoint integration of its exact one-dimensional r-integrand. It checks the kernel-sign theorem across dimensions, the exact hard-envelope combinatorics and threshold cutoff over increasing scale families, and distinct clustered-source actual positive winners with their low-background gate. Floating kernel values are diagnostics, not interval certificates; the analytical proofs above certify the claims. No Monte Carlo, receiver-measure replacement, or fitting of a dimension exponent is used. The midpoint resolutions are doubled as a convergence check. The guard does not claim a cheap general LP solution.

```python
from fractions import Fraction as Q
from functools import lru_cache
from math import exp, prod, log

checks=0
@lru_cache(None)
def phi(x, m=2048):
    x=abs(x)
    total=0.0
    for j in range(m):
        r=(j+0.5)/m
        if x<=0.5:
            total+=r*(2-exp(-(0.5-x)/r)-exp(-(0.5+x)/r))
        else:
            total+=r*(exp(-(x-0.5)/r)-exp(-(x+0.5)/r))
    return total/m

def endpoints(x, n, m=2048):
    a=1/n
    v=[phi(float(t),m) for t in x]
    h=[float(abs(t)<=0.5) for t in x]
    return (prod((1-a/2)*s+a/2*t for s,t in zip(h,v)),
            prod((1-a)*s+a*t for s,t in zip(h,v)))

def D(x,n,m=2048):
    u,v=endpoints(x,n,m)
    return u-v

def envelope(n, L, d):
    v=[z**n for z in L]
    return sum((v[j]-(v[j-1] if j else 0))*max(d[k]/v[k] for k in range(j,len(v))) for j in range(len(v)))

# Stage 1: actual E2 signs, inside lower bound, dimension growth.
maxerr=0.0
for n in (2,4,8,16,32):
    for k in range(n+1):
        x=[0.51 if j<k else (0.49 if j%2 else 0.0) for j in range(n)]
        a,b=D(x,n,1024),D(x,n,2048)
        maxerr=max(maxerr,abs(a-b))
        assert (b>=1/32 if k==0 else b<0)
        checks+=1
    for z in (0.0,0.25,0.499):
        assert 1/32<D([z]*n,n)<1
        checks+=1
print('stage1 actual E2 sign checks; midpoint doubling maxdiff',format(maxerr,'.9g'))

# Stage 2: exact duty costs, increasingly dense genuine nested cubes.
for n in (2,4,8,16):
    for m in (3,9,33):
        L=[Q(1)+Q(j,m-1) for j in range(m)]
        full=envelope(n,L,[Q(1)]*m)
        assert 1<=float(full)<=1+n*log(2)+1e-12
        for tau in (Q(1,8),Q(1,64),Q(1,128)):
            d=[min(Q(1),32*tau*z**n) if z**n<1/tau else Q(0) for z in L]
            cost=envelope(n,L,d)
            assert cost<=32
            for z,a in zip(L,d):
                val=D([0.0]*n,n)/float(z**n)
                if val>float(tau):
                    assert float(a)*val>=float(tau)-1e-12
                checks+=1
        checks+=1
print('stage2 exact envelope / threshold-shutdown checks passed')

# Stage 3: actual signed max-selector and low gate; all duties vanish.
# Distinct physical points y_i=(t_i,0,...,0), no noise discretization.
for n,N,m in ((2,128,3),(4,256,5),(8,512,9)):
    ys=[(i+0.5)/N/4-1/8 for i in range(N)]
    L=[1+j/(m-1) for j in range(m)]
    rows=[]
    for xx in (-0.2,0.0,0.2):
        vals=[]; backgrounds=[]
        for ell in L:
            terms=[]; backs=[]
            for y in ys:
                x=[(xx-y)/ell]+[0.0]*(n-1)
                u,v=endpoints(x,n)
                terms.append((u-v)/ell**n)
                backs.append((u+v)/2/ell**n)
            vals.append(sum(terms)/N)
            backgrounds.append(sum(backs)/N)
        winner=max(range(m),key=lambda j:vals[j])
        assert vals[winner]>1/64 and backgrounds[winner]<=1
        assert all(ell**n>=64/N for ell in L)
        rows.append((round(vals[winner],8),winner))
        checks+=1
    print('stage3 n,N,m=',n,N,m,'positive selected-low rows',rows,'duty=0')
print('PASS',checks,'checks')
```

Guard execution result (Python 3, 11 October 2026): **PASS 643 checks**. Stage 1 midpoint-doubling maximum discrepancy was 1.60959407e-08. Stage 3 actual positive winners were always L=1: for (n,N)=(2,128), values 0.18915437/0.18526204/0.18915437; for (4,256), 0.17282561/0.17118349/0.17282561; for (8,512), 0.16574489/0.16498614/0.16574489. All retained the F<=1 gate and all sourcewise duties were zero. These rounded values are diagnostic only. Independent audit of Sections 1–5 reported no mathematical error.


# R80 numerical record: actual one-sided layers and positive corridors

The registered finite-scale one-sided inclusion passed on seven genuine positive L1 box-mixture inputs, including correlated, separated and unequal-weight sources through dimension 16. The program evaluates the actual E2 convolution by one-dimensional quadrature and preserves the original hard-cube winner. It uses no empirical latent-noise prior inside a maximum. These are numerical diagnostics of the new reduction and five positive corridor identities; they do not prove the remaining weak signed-face estimate or the centered-cube goal.

## Objects and selectors

Write h=1_[−1/2,1/2], w(z)=∫_0^1 exp(−|z|/t) dt, φ=h*w, ψ_a=(1−a)h+aφ, and P_a(L,x)=f*(ψ_a^⊗n)_L(x). Thus P_0 is the centered cube average and P_1 is the true E2-smoothed average. Every input is

    f(y)=W Σ_i m_i (2e_i)^−n 1_{y∈y_i+[−e_i,e_i]^n},
    m_i>0, Σ_i m_i=1, ||f||_1=W.

All centers, halfwidths, masses, W and registered scales are saved as rational strings. The positive L1 boxes are integrated as boxes; they are not replaced by atomic sources. For each coordinate, the hard contribution is the physical overlap length divided by 2e_i L. The soft contribution is the φ integral from (x_j−y_ij−e_i)/L to (x_j−y_ij+e_i)/L, divided by 2e_i. Products and the weighted source sum then give P_a.

For S=ceil(log2(2n)), ε=2^−S and α=(1−ε)^n≥1/2, define

    T_s(L,x)=P_{2^(−s−1)}(L,x)−P_{2^−s}(L,x),  0≤s<S.

The layers are signed. The sourcewise tensor majorization P_ε≥αP_0 and exact telescoping give the sufficient one-sided implication

    max_J P_0>λ and max_J P_1≤αλ/2
        ⇒ some T_s(L_H,x)>η,  η=αλ/(2S),

where L_H is the first registered maximizer of P_0. This preserves the SAME physical hard winner in the conclusion. It needs no negative crossing. The program separately registers each layer's first positive-output maximizer L_s in J and its true background F_s=(P_a+P_{a/2})(L_s,x)/2. The final low/high diagnostic threshold is B=√n Sλ. A positive union receiver can belong to both low and high unions via different layers; their reported estimates need not add to the positive union. This selector-background split is a diagnostic convention. The parent's E_high uses sup_[1,2] F_s over continuous scales, including times between registered scales; no such continuous background supremum or E_high membership certificate is computed here.

J={1+j/(K−1):0≤j<K}. Every registered maximum is exhaustive on this finite J. None is claimed to equal the supremum over all physical scales. Ties select the first registered scale in the computed floating fields. The L1 positive profile is max(0,max_s max_J T_s), whereas the absolute profile is max_s max_J |T_s|.

## Pilot, pressure and expansion

| Stage / input | n | Box components | Centers and widths | W | Receivers | K | Seed |
|---|---:|---:|---|---:|---:|---:|---:|
| Pilot: one box | 1 | 1 | center 0; e=1/4 | 1 | 48 | 5 | 801000 |
| Pilot: one box | 2 | 1 | center (0,0); e=1/4 | 1 | 64 | 9 | 801100 |
| Pressure: four separated | 2 | 4 | all (±3/2,±3/2); e=1/8; equal masses | 1 | 96 | 17 | 801200 |
| Pressure: correlated two | 4 | 2 | diagonal centers ±1/2; e=1/8,1/4; masses 1/3,2/3 | 1 | 96 | 17 | 801300 |
| Expanded: unequal microboxes | 4 | 8 | diagonal j/4, −4≤j≤3; e=1/32; masses (j+5)/36 | 3 | 128 | 33 | 801400 |
| Expanded: correlated four | 8 | 4 | diagonal −1,−1/2,1/2,1; e=1/8; masses .1,.2,.3,.4 | 1 | 96 | 33 | 801500 |
| Expanded: narrow correlated two | 16 | 2 | diagonal ±1/4; e=1/64,1/8; masses 1/4,3/4 | 1 | 64 | 17 | 801600 |

The same receiver cloud is evaluated at λ/W∈{1/1024,1/256,1/64,1/16,1/4}; it is not independently resampled at each threshold. The archive contains all 35 threshold statistic rows, eight events per row, actual core examples, finite-scale selectors and true backgrounds. Saved statistics and seeds permit replay; it does not save every receiver coordinate or score.

There are 22 box components across seven inputs, 592 receiver draws, 12,560 main receiver-scale evaluations, 65,456 main P_a profiles and 40,336 main signed layer differences. These counts exclude proposal evaluation, quadrature refinement and corridor searches/integrals. The 2,960 receiver-threshold decisions contained 172 core checks, with the same receiver potentially counted at several thresholds. The two one-box pilots had no observed core receivers, so their implication checks are vacuous on those clouds. The separated, correlated-two, unequal-micro, correlated-four and n16 cases contributed respectively 1,24,28,74,45 core checks. All passed the same-H-winner inclusion; the minimum observed positive margin max_s T_s(L_H)−η was 0.0001860308. This is a floating diagnostic margin, not an interval certificate for the true φ values or a margin bound on unsampled receivers.

The maximum observed telescoping residual was 1.11023e−16 and the tail-majorization violation was zero. An independent algebraic part uses 56 rational tensor fixtures in dimensions 1,2,3,4,8,16,64: 112 exact Fraction equality/inequality checks passed. It retained 171 negative layer entries. Those synthetic bounded rational φ fixtures certify the tested algebra only; they are separate from the actual E2 quadrature and do not make an actual integral certificate.

## Original receiver measure and pressure findings

The receiver proposal is the genuine density

    q(x)=[P_0(1,x)+P_1(1,x)+P_0(2,x)+P_1(2,x)]/(4W).

A receiver is sampled by choosing an original source box by m_i, sampling y uniformly in that box, choosing L=1 or 2 equally, and choosing the H or Φ displacement equally. The Φ displacement is U+Z, with U uniform on [−1/2,1/2] and Z conditional on T=√V a symmetric Laplace random variable of scale T. This is the E2 noise law. Receiver weights for an event E are λ1_E/(Wq(x)), preserving the original dx measure; profile weights are value/q(x). In the ideal continuous law with exact q these are importance integrals, not source-weighted receiver integrals.

The implementation computes q by the same φ quadrature. Python's finite random generator and the recorded logarithm floor 2^−53 approximate the ideal continuous sampling law. The reported SE is the sample standard deviation divided by √R of these computed receiver weights. It excludes q/field quadrature bias, threshold classification errors and machine-law error. It is not a confidence interval or a certified error bound. A reported zero means no sampled hits. No general bound is inferred from it. There is no training optimization or held-out stage: the formulas, registered scales and thresholds are fixed before drawing these diagnostic clouds. Quadrature refinement is a computational check, not an independent sample batch.

Three representative observations (values are approximate λ|E|/W estimates ± receiver SE):

* The correlated n4 input at λ/W=1/4 gave hard/core 0.39217±0.09105, smooth 0 with no observed hits, and positive union 1.22745±0.21435. All 17 observed core receivers had a positive layer at their original hard winner. This tests the genuinely active one-sided branch.
* For the same n4 input at λ/W=1/1024, the positive union was 0.46675±0.14900, but the additional absolute-only event was 1.11007±0.34450 (15 receivers). Positive output and absolute output are materially different diagnostic sets. This does not authorize discarding negative source contributions inside a positive output.
* The n16 narrow correlated input at λ/W=1/256 gave core 0.09168±0.05463 (12 hits) and positive union 17.71688±17.62382 (13 hits). The SE nearly matches the positive estimate, indicating an unstable rare-event importance estimate under this endpoint proposal. This failure is retained, with its original parameters and seed. It is not evidence of a mathematical counterexample, an inferred dimensional growth rate or a sharp weak bound. The n16 positive-profile L1 estimate is similarly noisy, about 7.20472 with SE about 3.01554 (the complete current value is in JSON).

Fields use 64 Simpson panels for the one-dimensional mixing parameter t∈[0,1]. All scales and all P_a values for the first four receivers of each case were recomputed with 128 panels. The maximum observed absolute difference was 6.95047e−8. This spot refinement is not a uniform enclosure for all fields or thresholds. No rigorous φ interval is constructed, so none of the numerical E2 event rows is labelled a rational certificate.

## Actual positive corridor accounts

The supplementary continuous-scale calculation uses the precise actual equation with a>0, b=a/2,

    u=P_b−P_a, κ=n(1−b), γ=n(a−b),
    du/dlogL=c+v−κu−γP_a.

Here c is the signed hard-face difference and v is the signed centered continuous E2 difference; neither is replaced by an absolute envelope. For each source box the face terms and continuous terms are integrated from the same source, same receiver and same physical L. Source-face changes occur at L=2|x_j−y_ij±e_i|; these physical breakpoints are stored and split the log-scale quadrature. A fixed midpoint face mask is used within each segment to avoid assigning a Simpson endpoint the adjacent segment's face value.

The search requires u(1)<η/2, uses η=W/64, and finds the first positive η bracket on a 128-step physical grid augmented with every box-face breakpoint. It then finds the last half-threshold bracket before that hit and bisects each bracket 35 times. These are diagnostics of continuous actual u. A finite bracket search does not certify the first continuous hit or last continuous half hit. The saved 65 interior values are an additional check, not proof that η/2≤u≤η throughout the interval. This supplemental η is separately registered and does not redefine the main λ-dependent event thresholds.

Three corridors were found at n2,a=1 and two at n4,a=1/2. No qualifying n8,a=1/8 bracket was found among that case's 96 receiver samples; this is not an absence theorem. Each stored corridor evaluates

    η/2+κ∫u+γ∫P_a = ∫c+∫v,
    Λ=κd+(2γ/η)∫P_a, d=log(tau/rho),
    η(1+Λ)/2 ≤ ∫c+∫v.

The integrals use logL and are refined from (16 scale panels,64 kernel panels) to (32,128), on each physical segment. Across the five records the maximum absolute identity residual was 1.01250e−8, and the maximum sum of integral refinement differences was 1.06522e−8. All sampled corridor minima/maxima agreed with the expected half-to-full threshold range to rounding. Their log lengths .07652–.13637 are below 1/√n; their loads .35353–.97143 are below √n. They therefore probe the short, low-load corridor mechanism that remains unpaid. The parent's continuous background and centered-flux exception gates were not tested, so these records do not certify membership in the fully retained E_short event. They do not demonstrate the large-load weak budget.

For example, one n2 corridor has d=.09666968, η=.015625, κ=γ=1. Its accounts are κ∫u=.001151107, γ∫P_a=.002006725, ∫c=.010997078 and ∫v=−.000026736. The negative continuous contribution is preserved. The load lower margin is .000395885. One n4 corridor has d=.13637246, κ=3, γ=1, κ∫u=.004814951, γ∫P_a=.004393038, ∫c=.015745718 and ∫v=.001274770; its load lower margin is .001618720. Positive loads and small residuals are diagnostics, not certified root/integral enclosures.

## Reproduction and frozen files

From the extracted artifact directory run `python3 -B probe.py`; it requires only the Python standard library and writes `results.json` next to its source. The main frozen run used bundled Python 3.12.14, completed in 11.576820334 seconds and exited successfully. Wall time is printed but not inserted into the deterministic JSON. The initial development run used the older diagnostic B=4√n Sλ and a signed positive-profile statistic; the final run aligns B=√n Sλ and uses the positive part for the profile. These changes do not alter the same-H-winner inclusion or corridor accounts. The final archive is the registered result; the initial JSON was not retained as a separate artifact.

* `probe.py`: SHA-256 `32c70b19a34a1cf3d9a33b4aa563609bcbfbc5177235e5b8ee6b24182a312886`.
* `results.json`: SHA-256 `37a3d030dd44070eb24980c3f96a0c2985f56e6d77a9334fb131c1aea2aac0a1`.

Independent audit receipt: the auditor copied the frozen program to a temporary directory and replayed it in 11.643171 seconds, with exit 0, empty stderr and byte-identical JSON. An alternative Laplace-CDF primitive, without importing the main program, reconstructed 30 saved core examples and 766 registered-scale queries, including original box fields and proposal q; the maximum difference was 2.22045e−16. The saved hard/positive selectors, B=√n Sλ, raw-hit inclusion and five corridor identity/load accounts passed the independent checks. This agreement does not turn the common numerical quadrature into a rigorous integral enclosure.

The finite one-sided algebra does not pay the remaining general positive short-corridor signed-face budget. No asymptotic dimensional or source-count order is fitted, and the target remains unproved.


# R80 exact first-hit fixtures

The standalone standard-library guard verifies 19 receiver certificates from seven actual positive L1 box inputs in three stages. Eighteen receivers belong to a strict above-threshold event. One tangent equality regression is excluded from that target event. All 114 rational posterior-age comparisons pass.

| Stage | Dimensions | Source boxes per input | Receivers | Purpose |
|---|---|---|---:|---|
| Pilots and breakpoint regression | 1, 2 | 1 | 7 | Simple crossings and an exact tangent contact |
| Deep correlated | 2, 4 | 4, 7 | 6 | Correlated far sources and a low-density background |
| Wider dimension and source count | 4, 8 | 9, 13 | 6 | Separate dimension and source-count growth |

The actual source density is f(y)=sum_i w_i 1_{c_i+[-epsilon,epsilon]^n}(y)/(2epsilon)^n, with positive rational weights and W=sum_i w_i. Sources are physical boxes, including overlaps. The cube has full side length L and A_L=L^(-n) integral_{x+[-L/2,L/2]^n} f. Source lists, weights, receivers, thresholds and coefficients are saved as exact rational strings. The seed is 800611. Correlated cases have f(x)=lambda/4 from their background box; pilots have f(x)=0. Every receiver satisfies f(x)<=lambda/2.

## Full-scale certificate

Every physical face breakpoint 2|x_j-(c_ij+-epsilon)| is included. Between consecutive breakpoints each overlap is affine in L, giving an exact polynomial numerator of degree at most n. The threshold polynomial is lambda(2epsilon)^n L^n. The results contain 376 complete physical-interval polynomials, with coefficients in ascending powers of L.

The guard scans from zero. Every complete interval before the first contact has zero distinct open roots and a negative rational test value. Sturm remainders are normalized only by positive factors. Endpoint signs use the first nonzero exact Taylor derivative, handling repeated roots and zero endpoints. V(a+)-V(b-) counts roots strictly inside (a,b). Five elementary regressions independently exercise repeated roots and endpoint exclusions.

The first root is a rational singleton or an interval produced by 64 rational bisections. Each nonsingleton interval has exactly one root, nonzero endpoint signs and an earlier-root exclusion inside its original physical interval. Breakpoint contacts use direct equality. After the final face breakpoint all mass is captured: A_L=W/L^n decreases forever. The terminal polynomial extends to infinity, so large scales are not omitted.

The first_contact field denotes the earliest L>0 with A_L>=lambda. For all 18 strict-event fixtures its right sign is positive, making it also inf{L:A_L>lambda}; first_strict_cross_boundary_interval records this boundary. The tangent regression has n=1, box [3/4,5/4] and lambda=2/5. Its average rises to 2/5 at L=5/2 and decreases thereafter. It provides equality only, with a null strict boundary. A level touch is therefore not counted as a strict event.

## Posterior age interval

At contact L*, captured mass is lambda(L*)^n. Put H=log[L*/(2|x-y|_infinity)]. For t=exp(-h) in {1/16,1/8,1/4,1/2,3/4,7/8}, let [l,u] enclose L*. Nested cubes and positive mass give

    capture(tl)/(lambda u^n)
      <= posterior{H>=h}
      <= capture(tu)/(lambda l^n) <= t^n.

Each comparison also checks tu<l and A_(tu)<lambda. Thus the smaller scale precedes the globally certified contact. A first grid hit or a first hit within a truncated scale window would not supply this premise. These are exact checks at six specified h values; the all-h theorem is the separate analytic proof in hardface.md.

## Replay and scope

Run python3 firsthit_probe.py from any directory. The script writes firsthit_results.json beside itself, requires only the Python standard library and runs in approximately one second. The output has no wall-clock fields and replays byte for byte. No quadrature, sampled scale maximum or Monte Carlo estimate enters the certificates.

Independent audit reconstructed all physical breakpoints and checked 376 overlap-polynomial identities at 2,214 rational direct-overlap points. It rebuilt 158 prefix Sturm checks with independent endpoint signs and recomputed all 114 age intervals. All passed. A temporary-directory standalone replay reproduced the JSON byte for byte. The final strict-event metadata clarification changes no polynomial, root bracket or age interval.

These certificates cover explicit inputs and finite receiver points in original Lebesgue coordinates. They do not certify event volume, a weak-type estimate, a general first-hit theorem, directional independence or a square-root bound. The separate analytic proof provides the general selection and age lemma. Its high-density payment is lambda|{f>lambda/2}|<=2W; this guard checks only the density premise at its finite receivers.


# 第80轮独立审计

主目标 \(C_n^\square\le\sqrt n\,n^{o(1)}\) 仍未证明。本轮一般输入的有效进展是一侧 finite-layer 归约、fine tail 的点态吸收和大 load 正向 corridor 的支付。最终未付项明确是低背景、短时间、低 occupation 的正向 signed-face 事件；此外，从单个物理窗口到所有正尺度的目标常数仍需合法归约。

## 解析结论与范围

父稿 P80.1–P80.6 已逐步独立核验。先取原输入的绝对值 \(f\ge0\)，令 \(2^S\ge2n\)、\(\epsilon=2^{-S}\)、\(\alpha=(1-\epsilon)^n\ge1/2\)，则 \(\Psi_\epsilon\ge\alpha H\)。因此在同一个原硬立方体有限库赢家处，\(\max_JH*f>\lambda\) 且 \(\max_J\Phi*f\le\alpha\lambda/2\) 蕴含某个真实 signed 层差 \(u_s>\eta=\alpha\lambda/(2S)\)。这直接吸收全部 fine tail，不需要其双侧强极大估计。负层输出不必另外支付；层内负来源贡献仍须保留。

父稿的连续高背景事件、anchor 与 centered-flux 异常密度 \(P'\) 使用实际共同输入和 Lebesgue 接收测度。连续 \(\sup F_s\) 门槛不能换成有限库门槛后用于中间 corridor。已核验 \(\lambda|E_{\rm high}|\le S_nW/\sqrt n\) 与 \(\lambda|E_{\rm cont}|\le(8S/\alpha)C'_PW\)，以及 first/last level times 的直接 dense-time 可测性论证。无需借用一般 argmax 选择定理。

正向 corridor 的真实恒等式为
\[
\eta/2+\kappa\int_Iu+\gamma\int_IP_a=\int_I(c+v).
\]
在 \(P'\) 异常之外，\(\int_Ic\ge\eta/4+\kappa\int_Iu+\gamma\int_IP_a\)。定义 \(\Lambda=\kappa|I|+(2\gamma/\eta)\int_IP_a\)，由真实 incoming face 的正时空密度得
\[
\eta|E_{\Lambda\ge R}|\le 4\kappa TW/(1+2R).
\]
取 \(R=\sqrt n\) 后逐层为 \(O(\sqrt n)\)，但返回原阈值并合并 \(S\) 层必须保留两个 \(S\)：总费为 \(O(\sqrt nS^2)\)。审计早期消息曾漏写 \(\lambda/\eta\) 的因子；最终正文及独立守卫已经更正。父稿 P12 的所有已付项与剩余事件包含方向正确，未偷偷恢复负向 forcing。

soft 组件的 load 支付、Fisher 质量前提及额外核支持范围均通过审计。在 fine 层 \(a\le1/n\)，真实 E2 的 \(D_a^+\) 与 \(naH\) 双边可比；因而用 \(f*D_a^+\) 支配正输出虽然合法，却重新遇到原硬立方体极大目标的支付难度。

coverage 组件的实际临界层 \(H/32\le(D_{1/n})_+\le H\)、完整 signed physical-source duty 的 \(P^+\asymp E_n(d)\)、有限 cell LP 与 weak dual 方向均正确。未截断价格仍为 \(\Omega(n)\)，这是强包络机制的障碍，不是弱界反例。单原子 shutdown 的 \(32p\) 费用正确；对 \(N>64\) 个 distinct clustered sources 分别 shutdown，会在实际 selected-low 正体积事件全部失效。一般共同 packet 构造与统一廉价 LP 尚未证明。

hardface 组件的 paid global hard first-hit 规则有效：先支付 \(\{f>\lambda/2\}\) 的 \(2W\)，真实 \(L^1\) 接收点的首个严格 crossing 边界满足 \(A_{r_*}f=\lambda\)。真实 captured-source 后验有 \(\pi_x\{H\ge h\}\le e^{-nh}\)，但这只是未按方向条件化的年龄约束。two-box \(L^1\) 输入在显式开接收区域 \(|x_i|<1/100\) 上给出方向条件化概率1，高于 \(9/16\)；所有常数已独立复算。该规则不能移到 finite-window 下端、注册网格或 private soft corridor。它尚不支付来源 occupation。

## 独立数值与证书核验

独立守卫不导入主脚本。已完成以下有限核验：

- 120个完整 arrival 集的实际正原子硬立方体赢家及 root-free 年龄捕获比较；另保存窗口下端 fresh 比例可为0的范围反例。
- 120个共同输入接收点上的精确有限有理噪声 telescope，100个满足父稿点态 tail 吸收的正向归约；42个正向 corridor/误差恒等式、30个 load 恒等式和5个阈值聚合。有限噪声 fixture 明确不是 E2，只认证代数与硬几何。
- 主 `results.json` 的30个 saved core examples、766个注册尺度查询：独立用 Laplace CDF primitive 重算实际 source-box fields 与 importance proposal，最大差 \(2.220446049250313\times10^{-16}\)。原硬赢家、正向 layer selectors、\(B=\sqrt nS\lambda\)、raw-hit 包含以及5个保存的 corridor/load accounts 均通过。
- `firsthit_results.json` 的19个真实 \(L^1\) box 接收点：376个完整物理区间多项式、2214个独立 direct-overlap identity points、158个重建的 prefix Sturm checks、114个有理年龄区间。18个严格事件与1个 equality-only regression 明确区分，不把 tangent contact 认证为严格 crossing。

真实 E2 求积、有限接收点 importance statistics、机器随机采样与 soft corridor 的网格括根均只是诊断。接收点 SE 不包括求积、proposal 与阈值分类误差。5个 soft corridor 未认证父稿连续 \(F\) 与 \(P'\) 全部门槛，不能充当 P12 完整剩余事件的 membership 证书。Sturm 与年龄有理区间认证固定 box 接收点的根和几何，不能代替 Lebesgue 弱事件体积。

## 冻结与可移植复现

四个主文件的冻结 SHA256 均已核对。独立临时目录重放 `probe.py`：exit0、stderr空、JSON逐字节一致，11.643171秒；最终 `firsthit_probe.py` 同样逐字节重放通过，0.529687秒。其最后修改只澄清18个 strict event 与1个 equality-only regression，已重新核验。

| 文件 | SHA256 |
|---|---|
| `probe.py` | `32c70b19a34a1cf3d9a33b4aa563609bcbfbc5177235e5b8ee6b24182a312886` |
| `results.json` | `37a3d030dd44070eb24980c3f96a0c2985f56e6d77a9334fb131c1aea2aac0a1` |
| `firsthit_probe.py` | `2e81607ccfeac4e3f25ad432d77e74ae689cae93ad8fdfd1c660edc68a80f553` |
| `firsthit_results.json` | `ddc946cdcf0e99d6486da6aa528fef3d5097968cb03cc0f31f23effe2594c81e` |

三个嵌入组件守卫已独立提取重放：soft `79ce78c9a32eea2da21548eba24d9e2ec40c3f94caaee8e4c5a5b078087fd572`，PASS230；hardface `7a6fd9c4e9b475e3c7d34864414272b929a407f8ed6da3aa89c35b1bfeda35da`，PASS1122个有理 tail comparisons；coverage `eaecb60d17c536dfa581e82f499f292e461c74b97c09d4d4c1f6deada9983e81`，PASS643。各实际 E2 积分值仍仅诊断，解析证明承担一般结论。

归档的独审复现只要求四个主 py/json 与合并 `proof.md`，或由其提取的三个 component guard py。它不要求归档外的 component md：先读本目录 extracted guard，否则开发目录 component md，最后按冻结 hash 从合并 proof 的 Python fence 定位。没有 Git 操作、他人文件修改或 PDF 编译。

最终独审守卫 SHA256 为 `be28e9fc1ba17d8287bfe5622bbdadad2dc11106b616854c3842493cfff5b914`。无 component md 的临时归档目录、仅从合并 proof 提取冻结 fences 的路径：PASS，5.425325秒；无合并 proof、只用已提取三个 component guard 的路径：PASS，5.422693秒。两次均 exit0、stderr空、完整 saved-data 核验及组件重放通过。父代理的六项独立重放也全部通过，完整 receipt 保存在其清单中。报告与守卫现冻结，无未完成的复现步骤；数学目标的未付项仍如开头所述。


## 最终独审守卫 audit_guard.py

```python
#!/usr/bin/env python3
"""R80 independent one-sided reduction and actual hard-winner checks.
The rational finite noise law supports algebra/geometry only, not actual E2
continuous budgets. Portable archive needs four frozen main files and merged
proof.md, or the three extracted component guard files.
"""
from fractions import Fraction as Q
from itertools import product
from pathlib import Path
import math,json,time,hashlib,re,subprocess,tempfile,sys
from functools import lru_cache
BASE=Path(__file__).resolve().parent

def hard(v):return Q(int(abs(v)<=Q(1,2)))
def phi_fixture(v):
    return sum(weight*hard(v-noise) for noise,weight in [(Q(-1),Q(1,4)),(Q(0),Q(1,2)),(Q(1),Q(1,4))])

def endpoint(sites,masses,x,L,a):
    total=Q(0)
    for y,w in zip(sites,masses):
        total+=w*math.prod((1-a)*hard((xx-yy)/L)+a*phi_fixture((xx-yy)/L) for xx,yy in zip(x,y))/L**len(x)
    return total

def one_sided_actual_fixtures():
    rows=positive=parent_positive=0;S=4;epsilon=Q(1,1<<S)
    for n in (1,2,3,4):
        sites=list(product((Q(-1,4),Q(1,4)),repeat=n));masses=[Q(1,len(sites))]*len(sites)
        for x in product((Q(-1,4),Q(0),Q(1,4)),repeat=n):
            scales=sorted({Q(1),Q(2)}|{2*max(abs(xx-yy) for xx,yy in zip(x,y)) for y in sites if 1<2*max(abs(xx-yy) for xx,yy in zip(x,y))<=2})
            L=max(scales,key=lambda L:(endpoint(sites,masses,x,L,Q(0)),-L))
            H=endpoint(sites,masses,x,L,Q(0));Phi=endpoint(sites,masses,x,L,Q(1))
            Ts=[endpoint(sites,masses,x,L,Q(1,1<<(s+1)))-endpoint(sites,masses,x,L,Q(1,1<<s)) for s in range(S)]
            tail=H-endpoint(sites,masses,x,L,epsilon)
            assert H==Phi+sum(Ts)+tail
            alpha=(1-epsilon)**n
            assert alpha>=Q(1,2)
            assert endpoint(sites,masses,x,L,epsilon)>=alpha*H
            lam=H/2
            if Phi<=lam/4 and abs(tail)<=lam/4:
                assert sum(Ts)>lam/2
                assert any(T>lam/(2*S) for T in Ts)
                assert any(T>lam/(4*S) for T in Ts)
                positive+=1
            Phi_max=max(endpoint(sites,masses,x,z,Q(1)) for z in scales)
            if Phi_max<=alpha*lam/2:
                eta=alpha*lam/(2*S)
                assert sum(Ts)>alpha*lam/2
                assert max(Ts)>eta
                parent_positive+=1
            rows+=1
    assert positive>0
    # General scalar threshold proof retains exactly the same selected L:
    # if each T_s<=lambda/(4S), telescope is <=3lambda/4.
    for S in (1,2,4,16,64):
        lam=Q(7,3);assert lam/4+lam/4+S*lam/(4*S)==3*lam/4<lam
    return {'actual_hard_selected_receiver_rows':rows,'positive_core_slack_rows':positive,'parent_pointwise_tail_absorption_positive_rows':parent_positive,'scope':'Exact common positive atomic input, physical hard-window winner and rational finite-probability noise telescope. Noise fixture is not E2; only geometry/algebra is certified.'}

def global_winner_and_age():
    rows=oldchecks=0
    for n in (1,2,3,4):
        sites=list(product((Q(-1,4),Q(1,4)),repeat=n));masses=[Q(1,len(sites))]*len(sites)
        for x in product((Q(-3,4),Q(0),Q(3,4)),repeat=n):
            if x in sites:continue
            arrivals=sorted({2*max(abs(xx-yy) for xx,yy in zip(x,y)) for y in sites})
            H=lambda L:sum(w for y,w in zip(sites,masses) if 2*max(abs(xx-yy) for xx,yy in zip(x,y))<=L)/L**n
            L=max(arrivals,key=lambda L:(H(L),-L))
            captured=sum(w for y,w in zip(sites,masses) if 2*max(abs(xx-yy) for xx,yy in zip(x,y))<=L)
            # r=(n+2)^(1/n): use exact integer powers, no root rounding.
            old=sum(w for y,w in zip(sites,masses) if (n+2)*(2*max(abs(xx-yy) for xx,yy in zip(x,y)))**n<=L**n)
            assert (n+2)*old<=captured
            assert captured-old>=Q(n+1,n+2)*captured
            rows+=1;oldchecks+=1
    # One actual source attains its global winner at the first arrival.
    n=4;L=Q(2);A=Q(2)
    assert (n+2)*A**n>L**n
    # A finite-window winner at the lower endpoint need not have this fresh
    # fraction: a single source with arrival 1/5 is old at L=1 in [1,2].
    n=1;L=Q(1);A=Q(1,5)
    assert (n+2)*A**n<=L**n
    assert n+2>1
    return {'global_complete_arrival_winners':rows,'exact_log_age_posterior_checks':oldchecks,'one_source_fresh_fraction':'1','window_lower_endpoint_counterexample':{'n':1,'arrival':'1/5','window':['1','2'],'winner':'1','fresh_fraction':'0'},'scope':'Actual positive hardcube all-scale winners; shows fresh capture is large, not a counterexample to weak volume.'}

def positive_corridor_algebra():
    checks=0
    for n in (1,2,8,64,4096):
        for a in (Q(1),Q(1,2),Q(1,16),Q(1,1024)):
            kappa=n*(1-a/2);gamma=n*a/2
            for eta,Pa,Z in ((Q(1),Q(4),Q(3,4)),(Q(1,16),Q(1,4),Q(1,32))):
                incoming=eta/2+kappa*Z+gamma*Pa
                assert incoming>=eta/2+kappa*Z
                # Positive crossing's original background contributes on the
                # helpful left side; no absorption or negative Cmix is needed.
                assert incoming-gamma*Pa-kappa*Z==eta/2
                checks+=1
    # Absolute core errors transfer one-sided threshold with slack.
    for T,error in ((Q(1),Q(1,4)),(Q(1,16),Q(1,256))):
        tau=T/2;approx=T-error
        assert error<tau and approx>tau-error
    return {'exact_positive_corridor_and_error_cases':checks+2,'scope':'Original kappa/gamma sign and one-sided slack algebra; signed face crossing volume remains unproved.'}

def positive_load_budget():
    checks=0
    for n in (1,4,16,256,4096):
        R=math.isqrt(n)
        for a in (Q(1),Q(1,2),Q(1,64)):
            kappa=n*(1-a/2);gamma=n*a/2
            for eta,d,occupation in ((Q(1),Q(1,8),Q(1,4)),(Q(1,16),Q(3,4),Q(1,32))):
                load=kappa*d+2*gamma*occupation/eta
                minimum=eta/2+kappa*eta*d/2+gamma*occupation
                assert minimum==eta*(1+load)/2
                # Global Face_b mass kappa*W, and a valid upper bound A on
                # the continuous flux, imply this conditional Markov fee.
                # Taking A<=4sqrt(n) suffices for dimension bookkeeping.
                A=4*R;T=Q(7,10);W=Q(3,2)
                fee=2*T*(kappa+A)*W/(1+R)
                assert fee<=10*T*R*W
                # After paying the positive continuous majorant P', the
                # remaining incoming signed face obeys the stronger variant.
                face_minimum=eta/4+kappa*eta*d/2+gamma*occupation
                assert face_minimum==eta*(1+2*load)/4
                checks+=1
    aggregations=0
    for S in (1,2,4,16,64):
        alpha=Q(3,4);lam=Q(7,3);eta=alpha*lam/(2*S)
        per_layer_eta_fee=Q(5,2)
        target_union_fee=lam/eta*S*per_layer_eta_fee
        assert target_union_fee==2*S*S*per_layer_eta_fee/alpha
        aggregations+=1
    return {'rational_positive_load_identities':checks,'exact_threshold_union_aggregations':aggregations,'scope':'Conditional full-spacetime Markov budget algebra; actual E2 face/flux mass premises remain analytic, target union has S^2 factor, low-load event is unpaid.'}

@lru_cache(None)
def independent_phi_cdf(x):
    # Alternate actual E2 evaluation: integrate the Laplace CDF primitive
    # over the hard interval, then over the scale law 2r dr.
    M=64
    def primitive(v,r):
        return .5*r*math.exp(v/r) if v<0 else v+.5*r*math.exp(-v/r)
    total=0.
    for j in range(1,M+1):
        r=j/M;value=2*r*(primitive(x+.5,r)-primitive(x-.5,r))
        total+=(1 if j==M else 4 if j%2 else 2)*value
    return total/(3*M)

def independent_box_endpoint(src,x,L,a):
    L=float(Q(L));a=float(Q(a));out=0.
    for ys,e,m in zip(src['centers'],src['halfwidths'],src['mass_fractions']):
        e=float(Q(e));factors=[]
        for xx,yy in zip(x,ys):
            d=xx-float(Q(yy))
            h=max(0.,min(d+e,L/2)-max(d-e,-L/2))/(2*e*L)
            p=(independent_phi_cdf((d+e)/L)-independent_phi_cdf((d-e)/L))/(2*e)
            factors.append((1-a)*h+a*p)
        out+=float(Q(src['W'])*Q(m))*math.prod(factors)
    return out

def saved_numeric():
    path=BASE/'results.json'
    if not path.is_file():return {'status':'pending_frozen_main'}
    data=json.loads(path.read_text());rows=queries=corridors=0;error=0.
    for case in data['cases']:
        n=case['input']['n'];S=case['S'];alpha=Q(case['alpha']);epsilon=Q(case['epsilon'])
        assert epsilon==Q(1,2**S) and alpha==(1-epsilon)**n and alpha>=Q(1,2)
        assert 2**S>=2*n and (S==1 or 2**(S-1)<2*n)
        R=case['receiver_count']
        for th,events in case['events'].items():
            hits={k:v['observed_receiver_hits'] for k,v in events.items()}
            assert all(0<=v<=R for v in hits.values())
            assert hits['core']<=hits['hard'] and hits['core']<=hits['positive_union']
            assert hits['positive_union']<=hits['absolute_union']
            assert hits['negative_only']==hits['absolute_union']-hits['positive_union']
            assert max(hits['positive_low_union'],hits['positive_high_union'])<=hits['positive_union']<=hits['positive_low_union']+hits['positive_high_union']
            for row in case['core_examples'][th]:
                x=row['x'];J=case['physical_J'];src=case['input']
                values=[[independent_box_endpoint(src,x,L,a) for a in [Q(0)]+[Q(1,2**s) for s in range(S+1)]] for L in J]
                hidx=max(range(len(J)),key=lambda j:values[j][0]);H=values[hidx][0]
                Ts=[[v[s+2]-v[s+1] for v in values] for s in range(S)]
                pidx=[max(range(len(J)),key=lambda j:T[j]) for T in Ts]
                q=sum(independent_box_endpoint(src,x,L,a) for L in case['proposal_physical_scales'] for a in case['proposal_softness_parameters'])/(len(case['proposal_physical_scales'])*len(case['proposal_softness_parameters'])*float(Q(src['W'])))
                calculated=[H,max(v[1] for v in values),q,values[hidx][-1]]+[T[j] for T,j in zip(Ts,pidx)]
                saved=[row['hard_max'],row['smooth_max'],row['proposal_density'],row['tail_at_hard_winner']]+row['positive_layer_maxima']
                error=max(error,max(abs(v-w) for v,w in zip(calculated,saved)))
                assert J[hidx]==row['hard_winner_L']
                assert [J[j] for j in pidx]==row['positive_layer_selectors']
                assert max(T[hidx] for T in Ts)>row['eta']
                assert abs(row['B']-math.sqrt(n)*S*row['lambda_value'])<1e-12
                rows+=1;queries+=len(J)
        for row in case['positive_corridors']:
            ints=row['integrals'];eta=row['eta'];k=row['kappa'];g=row['gamma']
            lhs=eta/2+k*ints['u']+g*ints['Pa'];rhs=ints['c']+ints['v']
            assert abs(lhs-row['identity_lhs'])<1e-12 and abs(rhs-row['identity_rhs'])<1e-12
            load=k*math.log(row['tau_L']/row['rho_L'])+2*g*ints['Pa']/eta
            assert abs(load-row['load'])<1e-12
            corridors+=1
    assert error<1e-9
    return {'saved_core_examples':rows,'independent_registered_scale_queries':queries,'alternate_laplace_CDF_max_difference':error,'saved_corridor_identity_rows':corridors,'scope':'Independent original-box field/proposal recomputation at saved points and raw-hit consistency; same floating quadrature resolution, no continuum/interval certificate.'}

def peval(p,x):return sum(c*x**j for j,c in enumerate(p))
def ptrim(p):
    p=list(p)
    while len(p)>1 and not p[-1]:p.pop()
    return p
def prem(p,q):
    p=ptrim(p)
    while len(p)>=len(q) and any(p):
        shift=len(p)-len(q);factor=p[-1]/q[-1]
        for j,c in enumerate(q):p[j+shift]-=factor*c
        p=ptrim(p)
    return p
def pseq(p):
    seq=[ptrim(p)];d=ptrim([j*p[j] for j in range(1,len(p))] or [Q(0)])
    if not any(d):return seq
    seq.append(d)
    while True:
        r=[-c for c in prem(seq[-2],seq[-1])]
        if not any(r):return seq
        seq.append([c/abs(r[-1]) for c in r])
def pside(p,x,side):
    for order in range(len(p)):
        coefficient=sum(p[j]*math.comb(j,order)*x**(j-order) for j in range(order,len(p)))
        if coefficient:return (1 if coefficient>0 else -1)*side**order
    return 0
def pvariation(seq,x,side):
    signs=[pside(p,x,side) for p in seq];signs=[s for s in signs if s]
    return sum(a!=b for a,b in zip(signs,signs[1:]))
def pcount(p,a,b):return pvariation(pseq(p),a,1)-pvariation(pseq(p),b,-1)
def actual_capture(src,x,L):
    e=Q(src['epsilon']);n=src['n']
    return sum(Q(w)*math.prod(max(Q(0),min(xx+L/2,cc+e)-max(xx-L/2,cc-e)) for xx,cc in zip(x,map(Q,y)))/(2*e)**n for y,w in zip(src['centers'],src['weights']))

def saved_firsthit():
    path=BASE/'firsthit_results.json'
    if not path.is_file():return {'status':'pending_frozen_firsthit'}
    data=json.loads(path.read_text());rows=polys=identities=prefixes=ages=strict=tangent=0
    for stage in data['stages']:
        for case in stage['cases']:
            src=case['source'];n=src['n'];e=Q(src['epsilon']);lam=Q(src['lambda_value'])
            for row in case['receivers']:
                x=list(map(Q,row['receiver']));hit=row['first_contact'];lo,hi=map(Q,hit['interval']);assert 0<lo<=hi
                expected=sorted({Q(0)}|{2*abs(xx-cc-s*e) for y in src['centers'] for xx,cc in zip(x,map(Q,y)) for s in (-1,1)})
                assert expected==list(map(Q,row['all_physical_breakpoints']))
                intervals=row['all_physical_interval_polynomials']
                for cell in intervals:
                    a,b=Q(cell['left']),Q(cell['right']);p=list(map(Q,cell['numerator']));diff=list(map(Q,cell['difference_polynomial']))
                    for j in range(1,n+2):
                        L=a+(b-a)*Q(j,n+2)
                        assert peval(p,L)==actual_capture(src,x,L)*(2*e)**n
                        assert peval(diff,L)==peval(p,L)-lam*(2*e)**n*L**n
                        identities+=1
                    polys+=1
                for cert in row['earlier_scale_certificates']:
                    cell=intervals[cert['interval_index']];p=list(map(Q,cell['difference_polynomial']));a,b=Q(cert['left']),Q(cert['right']);seq=pseq(p)
                    assert pvariation(seq,a,1)==cert['variation_left_plus'] and pvariation(seq,b,-1)==cert['variation_right_minus']
                    assert pcount(p,a,b)==cert['open_root_count']
                    assert peval(p,Q(cert['test_point']))==Q(cert['test_difference'])
                    if cert['role']=='earlier_strictly_negative_interval':assert cert['open_root_count']==0 and Q(cert['test_difference'])<0
                    prefixes+=1
                cell=intervals[hit['physical_interval_index']];p=list(map(Q,cell['difference_polynomial']));a=Q(cell['left'])
                if lo==hi:
                    assert actual_capture(src,x,lo)==lam*lo**n
                    if a<lo:assert pcount(p,a,lo)==0
                    idx=hit['physical_interval_index']
                    rp=list(map(Q,intervals[idx+1]['difference_polynomial'])) if lo==Q(cell['right']) and idx+1<len(intervals) else p
                    assert pside(rp,lo,1)==hit['right_sign']
                else:
                    assert pcount(p,lo,hi)==1 and pcount(p,a,lo)==0
                    assert peval(p,lo)<0 and pside(p,hi,1)==hit['right_sign']
                for cert in row['age_tail_certificates']:
                    t=Q(cert['t_equals_exp_minus_h']);lower=actual_capture(src,x,t*lo)/(lam*hi**n);upper=actual_capture(src,x,t*hi)/(lam*lo**n)
                    assert [lower,upper]==list(map(Q,cert['posterior_age_tail_interval']))
                    assert 0<=lower<=upper<=t**n==Q(cert['target_exp_minus_nh'])
                    ages+=1
                witness=row['strict_above_lambda_witness']
                if witness:assert actual_capture(src,x,Q(witness['L']))>lam*Q(witness['L'])**n
                if hit['contact_classification']=='upward_crossing':
                    assert row['first_strict_cross_boundary_interval']==hit['interval'] and witness
                    strict+=1
                else:
                    assert row['first_strict_cross_boundary_interval'] is None and not row['strict_event_claimed']
                    tangent+=1
                rows+=1
    assert rows==data['counts']['receiver_certificates'] and ages==data['counts']['exact_age_tail_comparisons']
    assert strict==data['counts']['strict_event_receiver_certificates'] and tangent==data['counts']['equality_only_receiver_regressions']
    return {'actual_box_receiver_certificates':rows,'strict_event_receivers':strict,'equality_only_regressions':tangent,'complete_interval_polynomials':polys,'direct_overlap_polynomial_identity_points':identities,'independent_prefix_sturm_checks':prefixes,'rational_root_age_bounds':ages,'scope':'Exact saved actual L1-box geometry, full physical intervals, earliest-contact root exclusion and age posterior intervals; fixed receivers only, no weak-volume estimate.'}

def component_guard(component,expected):
    direct=BASE/(component+'_guard.py')
    if direct.is_file():payload=direct.read_bytes();origin=direct.name
    else:
        origin=component+'.md' if (BASE/(component+'.md')).is_file() else 'proof.md'
        path=BASE/origin
        if not path.is_file():raise FileNotFoundError('Archive needs '+component+'_guard.py or merged proof.md frozen fence')
        fences=re.findall(r'```python\n(.*?)\n```',path.read_text(),re.S)
        matches=[(f+'\n').encode() for f in fences if hashlib.sha256((f+'\n').encode()).hexdigest()==expected]
        assert len(matches)==1;payload=matches[0]
    assert hashlib.sha256(payload).hexdigest()==expected
    return payload,origin

def package_replays():
    expected={'probe.py':'32c70b19a34a1cf3d9a33b4aa563609bcbfbc5177235e5b8ee6b24182a312886','results.json':'37a3d030dd44070eb24980c3f96a0c2985f56e6d77a9334fb131c1aea2aac0a1','firsthit_probe.py':'2e81607ccfeac4e3f25ad432d77e74ae689cae93ad8fdfd1c660edc68a80f553','firsthit_results.json':'ddc946cdcf0e99d6486da6aa528fef3d5097968cb03cc0f31f23effe2594c81e'}
    for name,h in expected.items():assert hashlib.sha256((BASE/name).read_bytes()).hexdigest()==h
    receipts=[]
    with tempfile.TemporaryDirectory(prefix='r80-independent-guards-') as tmp:
        for component,h in [('soft','79ce78c9a32eea2da21548eba24d9e2ec40c3f94caaee8e4c5a5b078087fd572'),('hardface','7a6fd9c4e9b475e3c7d34864414272b929a407f8ed6da3aa89c35b1bfeda35da'),('coverage','eaecb60d17c536dfa581e82f499f292e461c74b97c09d4d4c1f6deada9983e81')]:
            payload,origin=component_guard(component,h);path=Path(tmp)/(component+'_guard.py');path.write_bytes(payload);start=time.perf_counter()
            proc=subprocess.run([sys.executable,'-B',str(path)],capture_output=True,text=True,check=True);assert proc.stderr==''
            receipts.append({'component':component,'package_source':origin,'guard_sha256':h,'seconds':round(time.perf_counter()-start,4),'stdout':proc.stdout.strip()})
    return {'frozen_numeric_hashes':expected,'component_replays':receipts,'scope':'Frozen main source/data hashes plus independent saved-data verification and component replays. Main full-program byte replay recorded separately in audit.md.'}

def main():
    start=time.perf_counter();out={'status':'PASS','one_sided':one_sided_actual_fixtures(),'global_age':global_winner_and_age(),'corridor':positive_corridor_algebra(),'positive_load':positive_load_budget(),'saved_numeric':saved_numeric(),'saved_firsthit':saved_firsthit(),'package_replays':package_replays()}
    out['elapsed_seconds']=round(time.perf_counter()-start,4);print(json.dumps(out,sort_keys=True))
if __name__=='__main__':main()
```
