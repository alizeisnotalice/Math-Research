#!/usr/bin/env python3
"""R80 actual positive finite-J telescoping and positive-corridor diagnostics.
No empirical latent prior, gridmax continuum claim, or quadrature certificate.
"""
from fractions import Fraction as Q
from pathlib import Path
from functools import lru_cache
import math,random,itertools,json,time,hashlib

def clean(o):
 if isinstance(o,Q):return str(o)
 if isinstance(o,dict):return {str(k):clean(v) for k,v in o.items()}
 if isinstance(o,(list,tuple)):return [clean(v) for v in o]
 return o

def setup(n):
 S=(2*n-1).bit_length();eps=Q(1,2**S);alpha=(1-eps)**n;assert alpha>=Q(1,2)
 return S,eps,alpha

def algebra_guard():
 rng=random.Random(80019);checks=0;negative=0
 for n in (1,2,3,4,8,16,64):
  S,eps,alpha=setup(n)
  for _ in range(8):
   h=[Q(rng.randrange(2)) for j in range(n)];phi=[Q(rng.randrange(1,8),8) for j in range(n)]
   vals=[math.prod((1-a)*hh+a*pp for hh,pp in zip(h,phi)) for a in [Q(1,2**s) for s in range(S+1)]];H=math.prod(h)
   assert vals[-1]>=alpha*H;assert sum(vals[s+1]-vals[s] for s in range(S))==vals[-1]-vals[0];checks+=2
   negative+=sum(vals[s+1]<vals[s] for s in range(S))
 return dict(status='PASS',exact_rational_checks=checks,observed_negative_layer_entries=negative,scope='Exact algebraic tensor fixtures with bounded rational phi; not E2 quadrature certificates. Negative entries retain signed layer scope.')

@lru_cache(maxsize=400000)
def phi_tail(u,M=64):
 u=abs(float(u))
 if u==0:return .5
 def f(t):
  if not t:return 0.
  if u>=.5:return t*t*math.exp(-(u-.5)/t)*(-math.expm1(-1/t))
  return 2*t*(.5-u)+t*t*(math.exp(-(.5-u)/t)-math.exp(-(u+.5)/t))
 return (f(0)+f(1)+sum((4 if j%2 else 2)*f(j/M) for j in range(1,M)))/(3*M)

def phi_int(lo,hi,M=64):
 if lo>=0:return phi_tail(lo,M)-phi_tail(hi,M)
 if hi<=0:return phi_tail(-hi,M)-phi_tail(-lo,M)
 return 1-phi_tail(-lo,M)-phi_tail(hi,M)

@lru_cache(maxsize=200000)
def phi_value(u,M=64):
 u=abs(float(u))
 def f(t):
  if not t:return 0.
  if u>=.5:return t*math.exp(-(u-.5)/t)*(-math.expm1(-1/t))
  return t*(2-math.exp(-(.5-u)/t)-math.exp(-(u+.5)/t))
 return (f(0)+f(1)+sum((4 if j%2 else 2)*f(j/M) for j in range(1,M)))/(3*M)

def source(name,n,centers,halfwidths,masses,W=1):
 assert sum(map(Q,masses))==1
 return dict(name=name,n=n,centers=[tuple(map(Q,c)) for c in centers],halfwidths=list(map(Q,halfwidths)),mass_fractions=list(map(Q,masses)),W=Q(W),input='Positive normalized product-box mixture, original L1 source; no atomic replacement.')

def fixtures():
 return [('pilot',source('one_box_n1',1,[(0,)],[Q(1,4)],[1]),48,5),('pilot',source('one_box_n2',2,[(0,0)],[Q(1,4)],[1]),64,9),('pressure',source('four_separated_n2',2,list(itertools.product((Q(-3,2),Q(3,2)),repeat=2)),[Q(1,8)]*4,[Q(1,4)]*4),96,17),('pressure',source('correlated_two_n4',4,[(Q(-1,2),)*4,(Q(1,2),)*4],[Q(1,8),Q(1,4)],[Q(1,3),Q(2,3)]),96,17),('expanded',source('unequal_micro_n4',4,[(Q(j,4),)*4 for j in range(-4,4)],[Q(1,32)]*8,[Q(j,36) for j in range(1,9)],3),128,33),('expanded',source('correlated_four_n8',8,[(Q(j,2),)*8 for j in(-2,-1,1,2)],[Q(1,8)]*4,[Q(1,10),Q(2,10),Q(3,10),Q(4,10)]),96,33),('expanded',source('narrow_correlated_two_n16',16,[(Q(-1,4),)*16,(Q(1,4),)*16],[Q(1,64),Q(1,8)],[Q(1,4),Q(3,4)]),64,17)]

def coordinate(d,e,L,M):
 hard=max(0.,min(d+e,L/2)-max(d-e,-L/2))/(2*e*L)
 soft=phi_int((d-e)/L,(d+e)/L,M)/(2*e)
 return hard,soft

def P_all(src,x,L,params,M=64):
 L=float(L);out=[0.]*len(params)
 for y,e,m in zip(src['centers'],src['halfwidths'],src['mass_fractions']):
  e=float(e);pairs=[coordinate(xx-float(yy),e,L,M) for xx,yy in zip(x,y)]
  for j,a in enumerate(params):out[j]+=float(src['W']*m)*math.prod((1-float(a))*h+float(a)*p for h,p in pairs)
 return out

def noise(rng):
 t=math.sqrt(rng.random());return (1 if rng.random()<.5 else -1)*t*(-math.log(max(rng.random(),2**-53)))

def draw_source(src,rng):
 u=rng.random();acc=0.;idx=len(src['centers'])-1
 for j,m in enumerate(src['mass_fractions']):
  acc+=float(m)
  if u<acc:idx=j;break
 return [float(y)+(2*rng.random()-1)*float(src['halfwidths'][idx]) for y in src['centers'][idx]]

def cloud(src,R,seed):
 rng=random.Random(seed);out=[]
 for j in range(R):
  y=draw_source(src,rng);L=(1.,2.)[rng.randrange(2)];soft=rng.randrange(2)
  x=[v+L*(rng.random()-.5+(noise(rng) if soft else 0.)) for v in y]
  q=sum(sum(P_all(src,x,l,[0,1])) for l in(1,2))/(4*float(src['W']));assert q>0
  out.append((x,q))
 return out

def first_argmax(v):return max(range(len(v)),key=lambda j:v[j])

def stats(v):
 m=sum(v)/len(v);return dict(mean=m,receiver_SE=math.sqrt(sum((z-m)**2 for z in v)/(len(v)*(len(v)-1))),receivers=len(v))

def physical_breaks(src,x,lo=1.,hi=2.):
 return sorted(set(2*abs(Q(xx)-yy+sgn*e) for y,e in zip(src['centers'],src['halfwidths']) for xx,yy in zip(x,y) for sgn in(-1,1) if lo<2*abs(Q(xx)-yy+sgn*e)<hi))

def flux_fields(src,x,L,a,M=64,face_masks=None):
 a=float(a);b=a/2;n=src['n'];tot={k:0. for k in('u','Pa','c','v')}
 for idx,(y,e,m) in enumerate(zip(src['centers'],src['halfwidths'],src['mass_fractions'])):
  e=float(e);d=[xx-float(yy) for xx,yy in zip(x,y)];pairs=[coordinate(v,e,L,M) for v in d];results=[]
  for p in (b,a):
   psi=[(1-p)*hh+p*ff for hh,ff in pairs];prod=math.prod(psi);B=[];beta=[]
   for j,(v,(hh,ff)) in enumerate(zip(d,pairs)):
    low=(v-e)/L;high=(v+e)/L
    B.append(-p*(1-p)*hh+p*(1-p)*ff-p*(high*phi_value(high,M)-low*phi_value(low,M))/(2*e))
    flags=face_masks[idx][j] if face_masks is not None else (abs(v-L/2)<e,abs(v+L/2)<e)
    beta.append(sum(flags)/(4*e))
   results.append((prod,prod*sum(B[j]/psi[j] for j in range(n)),(1-p)*prod*sum(beta[j]/psi[j] for j in range(n))))
  weight=float(src['W']*m);tot['u']+=weight*(results[0][0]-results[1][0]);tot['Pa']+=weight*results[1][0];tot['v']+=weight*(results[0][1]-results[1][1]);tot['c']+=weight*(results[0][2]-results[1][2])
 return tot

def bisect_hit(f,lo,hi,level):
 for j in range(35):
  mid=(lo+hi)/2
  if f(mid)>=level:hi=mid
  else:lo=mid
 return (lo+hi)/2

def corridor(src,x,a,eta):
 def u(L):p=P_all(src,x,L,[a/2,a]);return p[0]-p[1]
 if u(1)>=eta/2:return None
 grid=sorted(set([1+j/128 for j in range(129)]+[float(z) for z in physical_breaks(src,x)]));values=[u(L) for L in grid];hit=next((j for j in range(1,len(grid)) if values[j]>=eta and values[j-1]<eta),None)
 if hit is None:return None
 tau=bisect_hit(u,grid[hit-1],grid[hit],eta)
 below=next((j for j in range(hit-1,-1,-1) if values[j]<eta/2),None)
 if below is None:return None
 rho=bisect_hit(u,grid[below],min(grid[below+1],tau),eta/2)
 knots=[rho]+[float(z) for z in physical_breaks(src,x,rho,tau)]+[tau];kappa=src['n']*(1-float(a)/2);gamma=src['n']*float(a)/2
 def integrate(Mscale,Mphi):
  out={k:0. for k in('u','Pa','c','v')}
  for left,right in zip(knots,knots[1:]):
   midpoint=(left+right)/2;fm=[[(abs(xx-float(yy)-midpoint/2)<float(e),abs(xx-float(yy)+midpoint/2)<float(e)) for xx,yy in zip(x,y)] for y,e in zip(src['centers'],src['halfwidths'])]
   A=math.log(left);B=math.log(right);step=(B-A)/Mscale
   for j in range(Mscale+1):
    f=flux_fields(src,x,math.exp(A+j*step),a,Mphi,fm);weight=step/3*(1 if j in(0,Mscale) else 4 if j%2 else 2)
    for key in out:out[key]+=weight*f[key]
  return out
 coarse=integrate(16,64);fine=integrate(32,128);d=math.log(tau/rho);load=kappa*d+2*gamma*fine['Pa']/eta;lhs=eta/2+kappa*fine['u']+gamma*fine['Pa'];rhs=fine['c']+fine['v'];bounds=[u(rho+(tau-rho)*j/64) for j in range(65)]
 return dict(x=x,a=a,eta=eta,rho_L=rho,tau_L=tau,log_length=d,kappa=kappa,gamma=gamma,integrals=fine,damping_charge=kappa*fine['u'],positive_forcing_charge=gamma*fine['Pa'],identity_lhs=lhs,identity_rhs=rhs,identity_residual=rhs-lhs,refinement_difference=sum(abs(fine[k]-coarse[k]) for k in fine),load=load,load_lower_lhs=eta*(1+load)/2,load_lower_margin=rhs-eta*(1+load)/2,registered_u_min=min(bounds),registered_u_max=max(bounds),physical_face_breaks=physical_breaks(src,x,rho,tau),long_cutoff=1/math.sqrt(src['n']),scope='Actual continuous E2 box-input u, first 128-grid positive bracket and last half-threshold bracket, bisection/Simpson diagnostics. No certified global first-hit/root or integral error.')

def run_case(i,stage,src,R,K):
 n=src['n'];S,eps,alpha=setup(n);params=[Q(1,2**s) for s in range(S+1)];J=[Q(1)+Q(j,K-1) for j in range(K)];seed=801000+100*i;receivers=cloud(src,R,seed);core_margins=[];theta=(Q(1,1024),Q(1,256),Q(1,64),Q(1,16),Q(1,4));eventvalues={str(th):{k:[] for k in('hard','smooth','core','positive_union','absolute_union','negative_only','positive_low_union','positive_high_union')} for th in theta};examples={str(th):[] for th in theta};tel=tail=refine=0.;profilevalues=[];corridors=[]
 for row,(x,q) in enumerate(receivers):
  evaluated=[P_all(src,x,L,[Q(0)]+params) for L in J];hard=[v[0] for v in evaluated];Hj=first_argmax(hard);Hmax=hard[Hj];smooth=max(v[1] for v in evaluated);Ts=[[v[s+2]-v[s+1] for v in evaluated] for s in range(S)];selectors=[first_argmax(v) for v in Ts];positive=[v[j] for v,j in zip(Ts,selectors)];absolute=[max(map(abs,v)) for v in Ts];F=[(evaluated[j][s+1]+evaluated[j][s+2])/2 for s,j in enumerate(selectors)];same=[v[Hj] for v in Ts]
  tel=max(tel,max(abs(sum(v[s+2]-v[s+1] for s in range(S))-(v[-1]-v[1])) for v in evaluated));tail=max(tail,max(float(alpha)*v[0]-v[-1] for v in evaluated));assert all(v[-1]>=float(alpha)*v[0]-1e-11*float(src['W']) for v in evaluated)
  if row<4:
   fine=[P_all(src,x,L,[Q(0)]+params,128) for L in J];refine=max(refine,max(abs(a-b) for v,w in zip(evaluated,fine) for a,b in zip(v,w)))
  for th in theta:
   lam=float(th*src['W']);eta=float(alpha)*lam/(2*S);B=math.sqrt(n)*S*lam;hard_event=Hmax>lam;smooth_event=smooth>float(alpha)*lam/2;core=hard_event and not smooth_event;pos=any(z>eta for z in positive);abs_event=any(z>eta for z in absolute);low=any(z>eta and ff<=B for z,ff in zip(positive,F));high=any(z>eta and ff>B for z,ff in zip(positive,F));assert not core or max(same)>eta-1e-12*float(src['W'])
   if core:core_margins.append(max(same)-eta)
   labels=(hard_event,smooth_event,core,pos,abs_event,abs_event and not pos,low,high)
   for key,event in zip(eventvalues[str(th)],labels):eventvalues[str(th)][key].append(lam*float(event)/(q*float(src['W'])))
   if core and len(examples[str(th)])<2:examples[str(th)].append(dict(x=x,proposal_density=q,lambda_value=lam,eta=eta,B=B,hard_winner_L=J[Hj],hard_max=Hmax,smooth_max=smooth,tail_at_hard_winner=evaluated[Hj][-1],alpha_H_at_winner=float(alpha)*Hmax,T_at_hard_winner=same,positive_layer_maxima=positive,positive_layer_selectors=[J[j] for j in selectors],true_background_at_positive_selectors=F,inclusion_margin=max(same)-eta))
  profilevalues.append(dict(hard_max=Hmax,smooth_max=smooth,positive_max=max(0.,max(positive)),absolute_max=max(absolute)))
  # Only genuine kernel u; no empirical prior inside the optimization.
  if len(corridors)<3 and i in(2,3,5):
   a={2:Q(1),3:Q(1,2),5:Q(1,8)}[i];eta=float(src['W'])/64;c=corridor(src,x,a,eta)
   if c is not None:c['proposal_density']=q;corridors.append(c)
 return dict(stage=stage,input=src,S=S,epsilon=eps,alpha=alpha,physical_J=J,receiver_seed=seed,receiver_count=R,proposal_softness_parameters=[Q(0),Q(1)],proposal_physical_scales=[Q(1),Q(2)],proposal='equal H/Phi at scales1,2 divided by4W; true kernel sourcebox density, original dx',events={th:{key:dict(stats(v),observed_receiver_hits=sum(z>0 for z in v)) for key,v in rows.items()} for th,rows in eventvalues.items()},core_examples=examples,registered_core_checks=len(core_margins),minimum_core_inclusion_margin=min(core_margins) if core_margins else None,max_telescoping_residual=tel,max_tail_majorization_violation=max(tail,0),first_four_64_128_kernel_refinement_max=refine,profile_L1={k:stats([p[k]/q for p,(_,q) in zip(profilevalues,receivers)]) for k in profilevalues[0]},positive_corridors=corridors,scope='Exhaustive registered finite-J selector of actual sourcebox E2 quadrature fields. Receiver importance statistics only; no empiricalprior max, continuum scale max or integration certificate.')

def main():
 start=time.monotonic();guard=algebra_guard();rows=[]
 for i,(stage,src,R,K) in enumerate(fixtures()):print(stage,src['name'],flush=True);rows.append(run_case(i,stage,src,R,K))
 out=dict(status='PASS',algebra_guard=guard,cases=rows,definition='Ts=P_(2^(-s-1))-P_(2^(-s)); same original Hwinner, signed Ts retained. eps=2^-ceil(log2(2n)), alpha=(1-eps)^n>=1/2. FiniteJ maxH>lambda and maxPhi<=alpha lambda/2 implies some positiveTs at sameHwinner >alpha lambda/(2S). TrueFs=(Pa+Pb)/2 at original positiveTs-selector; B=sqrt(n)S lambda.',scope='General one-sided finite-family reduction audited numerically on registered L1inputs. Exact rational algebra guard only; actual E2 quadrature, dx sampling and refined positive-corridor identities remain diagnostic. Goal unproved; no fitted source/dimension order.')
 path=Path(__file__).with_name('results.json');path.write_text(json.dumps(clean(out),sort_keys=True,separators=(',',':'))+'\n');print('PASS',time.monotonic()-start,'seconds',hashlib.sha256(path.read_bytes()).hexdigest())
if __name__=='__main__':main()
