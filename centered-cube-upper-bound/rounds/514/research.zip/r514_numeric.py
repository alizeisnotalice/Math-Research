#!/usr/bin/env python3
"""R514 exact positive-Lebesgue receiver packets, continuous windows and legal swaps."""
from fractions import Fraction as Q
from pathlib import Path
import json,sys,platform,time
ROOT=Path(__file__).resolve().parent
checks=0

def ck(x):
 global checks
 assert bool(x)
 checks+=1

def profile(a,b,R):
 out={}
 for knot,c in [(a-R/2,1),(b-R/2,-1),(a+R/2,-1),(b+R/2,1)]:out[knot]=out.get(knot,Q(0))+Q(c)/R
 return {k:v for k,v in out.items() if v}

def poly(p,x):
 A=B=Q(0)
 for k,c in p.items():
  if k<x:A-=c*k;B+=c
 return A,B

def profileinner(p,q,lo=None,hi=None):
 knots=sorted(set(p)|set(q))
 if lo is not None:knots=sorted({lo,hi,*[k for k in knots if lo<k<hi]})
 out=Q(0)
 for a,b in zip(knots,knots[1:]):
  A,B=poly(p,(a+b)/2);C,D=poly(q,(a+b)/2)
  out+=A*C*(b-a)+(A*D+B*C)*(b*b-a*a)/2+B*D*(b**3-a**3)/3
 return out

def component(a,b,R,scale=Q(1)):
 # gamma=4; R=1 or2 and true mass m=R, hence window shifts 0 or1/2.
 return {'profile':profile(a,b,R),'window_start':Q(0) if R==1 else Q(1,2),'scale':scale}

def inner(F,G,lo=None,hi=None):
 return sum((f['scale']*g['scale']*max(Q(0),1-abs(f['window_start']-g['window_start']))*profileinner(f['profile'],g['profile'],lo,hi) for f in F for g in G),Q(0))

def scaled(F,c):return [{**f,'scale':f['scale']*c} for f in F]
def norm(F):return inner(F,F)

def model(d,e,constant=False):
 A=(-d-e,-d+e);B=(d-e,d+e);rA=Q(1);rB=Q(1) if constant else Q(2)
 old=[component(*A,rA),component(*B,rB)]
 new=[component(*A,rB),component(*B,rA)]
 diff=new+scaled(old,-1);Qold=norm(old);Qnew=norm(new);D=norm(diff)
 ck(Qold==Qnew);ck(D>=0)
 ck(d>e and d+e<Q(1,2));ck(Q(2)+d+e<3)
 # All old, reassigned D_B, and comparison V_B boxes are fully inside f=1[-3,3].
 # Consequently mass=radius and q=1 for every actual Lebesgue center, not only samples.
 volume=4*e;W=Q(6);C=2*e/rA+2*e/rB
 source_loss=2*d # since displacement2d<min radius
 ck(source_loss<min(rA,rB))
 fee=2*e*source_loss*(1/rA+1/rB)
 geom_parent_energy=2*e*2*source_loss*(1/rA**2+1/rB**2)
 win_overlap=1-abs((Q(0) if rA==1 else Q(1,2))-(Q(0) if rB==1 else Q(1,2)))
 same_center_parent_per_B=1/rA+1/rB-2*min(rA,rB)/(rA*rB)*win_overlap
 original_parent_energy=volume*same_center_parent_per_B
 corelo=-Q(1,2)+d+e;corehi=Q(1,2)-d-e
 coreQ=inner(old,old,corelo,corehi);coreD=inner(diff,diff,corelo,corehi)
 ck(coreQ>0 and coreD==0);ck(coreQ<=Qold)
 scoreloss=-inner(old,diff)
 ck(scoreloss==D/2);ck(scoreloss<=C*fee)
 ck(D<=volume*geom_parent_energy) # Jensen comparison, not an extremality argument.
 if constant:ck(D==0 and original_parent_energy==0)
 else:ck(D>0 and original_parent_energy>0)
 # Center-independent p=(delta_1+delta_2)/2. Every candidate is legal, kappa=1.
 G1=[component(*A,Q(1)),component(*B,Q(1))]
 G2=[component(*A,Q(2)),component(*B,Q(2))]
 accepted=scaled(G1,Q(1,2))+scaled(G2,Q(1,2));Aenergy=norm(accepted)
 accepted_swap_average=scaled(old+new,Q(1,2))
 if not constant:
  ck(norm(accepted+scaled(accepted_swap_average,-1))==0)
  ck(Qold==Aenergy+D/4)
 accepted_variance=norm(G1+scaled(G2,-1))/4
 ck((norm(G1)+norm(G2))/2==Aenergy+accepted_variance)
 # A<=1 and integral_sigma A<=1 follow from profile bound3e<1.
 ck(3*e<1);ck(Aenergy<=3*e*volume);ck(Aenergy<=W)
 return {'type':'constant_radius_zero_difference_baseline' if constant else 'nonconstant_shared_radius_swap','d':d,'e':e,'packet_A':A,'packet_B':B,'receiver_volume':volume,'radii_A_B':[rA,rB],'f':'1[-3,3]','W':W,'S':1,'gamma':4,'q_original_and_cross':1,'density_band_r':1,'T':'A translated +2d; B translated -2d, exact Lebesgue swap','Qbar_original_exact':Qold,'Qbar_reassigned_exact':Qnew,'difference_field_energy_exact':D,'difference_over_Qbar_exact':D/Qold,'old_to_new_per_parent_energy_integral_exact':original_parent_energy,'geometry_D_minus_V_per_parent_energy_integral_exact':geom_parent_energy,'geometry_parent_Jensen_bound_exact':volume*geom_parent_energy,'geometry_loss_fee_exact':fee,'window_motion_fee_exact':0,'actual_field_cap_C':C,'actual_score_loss_exact':scoreloss,'G7_style_bound_using_actual_field_cap':2*C*fee,'not_using_global_extremality':True,'invariant_source_core':[corelo,corehi],'invariant_core_Qbar_exact':coreQ,'invariant_core_difference_energy_exact':coreD,'normalized_Qbar_by_receiver_volume_squared':Qold/volume**2,'normalized_difference_energy_by_receiver_volume_squared':D/volume**2,'accepted_baseline':{'p':'1/2 delta_1 +1/2 delta_2','kappa':1,'all_candidates_accepted':True,'A_energy_exact':Aenergy,'A_pointwise_and_sigma_integral_bound':3*e,'A_L1_mu_sigma_exact':volume,'source_bound_W':W,'G1_energy_exact':norm(G1),'G2_energy_exact':norm(G2),'radius_probability_variance_exact':accepted_variance,'nonconstant_swap_variance_exact':D/4 if not constant else None,'mean_constant_radius_energy_minus_Qbar':(norm(G1)+norm(G2))/2-Qold,'scope':'baseline is computed, but original model is not certified globally maximal'}}

def main():
 start=time.perf_counter();models=[model(Q(1,8),Q(1,32)),model(Q(1,32),Q(1,128)),model(Q(1,128),Q(1,512)),model(Q(1,8),Q(1,32),True)]
 for z in models:print(z['type'],'d',z['d'],'Qbar',z['Qbar_original_exact'],'difference',z['difference_field_energy_exact'],'ratio',z['difference_over_Qbar_exact'],'fee',z['geometry_loss_fee_exact'],flush=True)
 def ser(x):
  if isinstance(x,Q):return str(x)
  raise TypeError(type(x))
 out={'scope':'four exact true L1/positive-Lebesgue models; no global extremality/coercivity certificate','environment':{'executable':sys.executable,'python':platform.python_version()},'models':models,'checks':checks,'seconds':time.perf_counter()-start}
 (ROOT/'r514_numeric.json').write_text(json.dumps(out,default=ser,indent=2)+'\n')
 print('PASS exact continuous-window packet swaps, invariant core, real source fees and accepted-baseline variance certificates')
if __name__=='__main__':main()
