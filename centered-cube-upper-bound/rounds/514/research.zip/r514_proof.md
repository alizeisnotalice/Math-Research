# R514 主证明：一次来源平均基线与有价接受回代

## 1. 原合同与目标

沿R513：μ=f dx≥0，W=μ(ℝⁿ)<∞，E为真实Lebesgue中心，0<a≤R_B≤b≤2a，m_B=q_BR_Bⁿ，q≤q_B≤λ=rq，q>0。γ>1固定。极值辅助域统一t=S；所有原接受历史留在原流，辅助替代不重生成历史。H=L²(μ×dσ)，k_B=S R_B^-n 1_QB(y)1_[logγmB,logγmB+1](σ)，L=∫E k_B dB，Q=||L||²。原流由R513满足R_*≤2√(DW Q)，D=1+logγr+nlogγ(b/a)。域内任一混合合法选择所得场≤C=S[1+log(γr)]，含X费用回原流保X*≤rX_original。

本轮给出真实一次W支付的共同半径平均场，不声称已经构造覆盖全部困难中心的分布。

## 2. 中心无关的半径试投：完整保留拒绝

令p为[a,b]上的概率，可以依赖整个固定μ及配置，但不能依赖具体接收中心B或来源pair。定义F_R={B∈E:qRⁿ≤μQ(B,R)≤λRⁿ}，κ(B)=∫1_F_R(B)p(dR)。提议R时在F_R使用R，其余中心保旧半径。每个R给同原域的共同合法selector，未忽略拒绝中心。

接受平均场和被接受旧场分别为
\[
 A=\int p(dR)\int_{F_R}k(B,R)dB,\qquad
 K_\kappa=\int_E\kappa(B)k_BdB.
\]
完整平均替代为L−Kκ+A。所有积分可由正性Tonelli定义；E有限测度：q|E|≤∫E m_B/R_BⁿdB≤W(2b)ⁿ/aⁿ（粗界只保证有限，不用于维数预算）。

对每固定y,R，中心域{B:y∈Q(B,R)}体积Rⁿ，真实合法掩码及窗指示都≤1，故
\[
0\le A(y,\sigma)\le S,\qquad
\int A(y,\sigma)d\sigma\le S.
\]
因此得到维数、分层数、μ集中程度均无关的实付估计
\[
\boxed{\|A\|_H^2\le S^2W.}\tag{P1}
\]
第一式不是来源密度帽：它来自真实接收中心体积。第二式保留窗长恰1。不可把p换成任意依赖B的概率后继续使用(P1)。

## 3. 比差场三角更省的回代

定义真实score亏损
\[
 d(R)=\langle L,\int_{F_R}[k_B-k(B,R)]dB\rangle,
 \qquad \mathcal D_p=\int d(R)p(dR)=\langle L,K_\kappa-A\rangle.
\]
若L是同一可行域全局最大场，则每个R替代合法，平方展开给2d(R)≥||∫F_R(k(B,R)−k_B)dB||²≥0，故D_p≥0。这是逐同步替代，而不是独立重画来源。

当κ≥κ0>0几乎处处，非负性给
\[
\kappa_0 Q\le\langle L,K_\kappa\rangle
=\mathcal D_p+\langle L,A\rangle
\le\mathcal D_p+S\sqrt{WQ}.
\]
解关于√Q的二次式，或用S√(WQ)≤κ0Q/2+S²W/(2κ0)，得
\[
\sqrt Q\le\frac{S\sqrt W+\sqrt{S^2W+4\kappa_0\mathcal D_p}}{2\kappa_0},\qquad
\boxed{Q\le\frac{S^2}{\kappa_0^2}W+\frac{2}{\kappa_0}\mathcal D_p.}\tag{P2}
\]
关键是亏损仅付κ0的一次逆幂，而非先用差场三角所得二次逆幂。

不假设全覆盖：令Elo={κ<κ0}，Llo=∫Elo k_BdB，保真实交叉score Elo_score=〈L,Llo〉。由Kκ≥κ0(L−Llo)得
\[
\boxed{Q\le S^2\kappa_0^{-2}W+2\kappa_0^{-1}\mathcal D_p+2\langle L,L_{lo}\rangle.}\tag{P3}
\]
这里交叉score不能换成||Llo||²。已有窗帽只给〈L,Llo〉≤C∫Llo=CS∫Elo q_BdB；这是显式未付X费用，不是自动小量。

P1一般成立；P2/P3的代数甚至无需极值，但只有同域极值才保证D_p非负及已证同步交换界。把“平均场小”直接说成“原场小”会遗漏D_p和拒绝交叉项。

## 4. 条件化与一步逆接受率：采用独立几何稿的加强

geometry证明更适合继续攻坚的版本。设good中心具有真实合法动作概率π_B，统一被一个中心无关有限半径测度ρ支配，ρ([a,b])=M；并且同一极值score满足
\[
\int[\psi(B,R_B)-\psi(B,R)]\pi_B(dR)\le\eta q_B.
\]
定义其平均场A_good。真实密度带和质量窗的中心包络保证A_good≤C；ρ支配及中心体积给∫σA_good≤SM，所以||A_good||²≤CSMW。将原good场score与A_good比较，并保bad交叉score，得到
\[
\boxed{Q\le CSMW+2\eta X_{good}+2\langle L,L_{bad}\rangle
\le CSMW+2\eta X_{good}+2CSX_{bad}.}\tag{P4}
\]
例如p给近最佳合法集合G_B(η)的质量≥κ0，则取π_B=p|G_B/p(G_B)，ρ=p/κ0，M=1/κ0；来源费用只损失一个κ0逆幂。这里条件化不改变μ，没有把新动作的历史当原历史；它仅用于原raw场的辅助上界。

该结论真正已付的是共同支配平均场的W费用。共同测度ρ覆盖足够多真实近最佳纤维仍未证；不能从每个纤维非空推出有限M，更不能推出M多对数。

## 5. 与原根阶目标的准确连接

若未来在同一辅助极值上能构造M≤K log^A(n+2)，且ηXgood+CSXbad≤ζX（或以同阶W费替代其中一部分），P4给Q≤CSKW log^A+2ζX。回代R513后
\[
R_*\le\varepsilon X+\frac{2D\zeta}{\varepsilon}W
+2\sqrt{DCSK\log^A(n+2)}W.
\]
所以ζ必须按D及入口额度选择，例如ζ≤ε/(2√D)使中项≤√D W；不得将固定ζ免费吸收。X*≤rX_original、原入口64(128/119)/(1−32δ_old−16η_old)及其他全部槽费用另计。本稿未取得所需M与ζ，也没有改变总目标。

本轮新支点是来源预算已经可对同一个平均场证明；下一步要构造真正覆盖且低score损失的共同半径测度，而非再证明平均场存在。一般n^(1/2+o(1))弱型上界未闭合。
