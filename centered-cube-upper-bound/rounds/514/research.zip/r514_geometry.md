# R514：条件化合法动作的平均场可一次来源付款

本轮得到一个实际可付的平均场，来源费用只含覆盖率的一次倒数。它给原极值场的明确“平均场＋未替代包＋变化场”分解，且所有动作保持真实密度带与中心边缘。尚未在任意 L1 输入上构造所需的多对数覆盖；冻结带允许连续变化的单点可行纤维，因此该覆盖不能直接假设。

## 1. 冻结对象与新桥的输入

沿 R513，μ=f dx≥0，W=μ(R^n)<∞，真实中心 E，a≤R≤b≤2a，q≤m(B,R)/R^n≤λ=rq。γ>1、r、S 固定。只考虑辅助统一 t=S 的最大共同选择 R_B；原 t≤S 与旧 gate 的正支配、回代仍沿主证明，不重跑历史。

令 H=L²(μ×dσ)，

\[
k(B,R)=S R^{-n}1_{Q(B,R)}(y)
1_{[\log_\gamma m(B,R),\log_\gamma m(B,R)+1]}(\sigma),
\quad L=\int_E k(B,R_B)dB,\quad Q=\|L\|_H^2.
\]

真实窗帽为 0≤L≤C，C=S[1+log(γr)]。任何保中心边缘的合法混合动作，其窗场也满足同一帽 C；不要求各中心动作相同。记 q_B=m(B,R_B)/R_B^n、X=∫E q_B dB，score 为 ψ(B,R)=〈L,k(B,R)〉。

固定 η≥0，定义真实近最佳动作集

\[
G_B(\eta)=\{R\in[a,b]:qR^n\le m(B,R)\le\lambda R^n,
\ \psi(B,R)\ge\psi(B,R_B)-\eta q_B\}.\tag{1}
\]

这是来源抽样之前确定的动作集。其依赖 μ、B、极值场允许；它不能依赖某一来源对或旧 history。由于物理核在合法图上连续，集合图可测，以下归一化是可测的。

新桥的几何输入是一个**不随中心 B 改变的有限半径测度** ρ，以及可测中心包 E₀，使

\[
\rho(G_B(\eta))\ge1\quad(B\in E_0),\qquad M=\rho([a,b])<\infty.\tag{2}
\]

ρ 可依赖整个输入和极值选择；条件是同一个 ρ 同时覆盖全部 E₀。令 E₁=E\E₀，X_i=∫_(E_i)q_BdB。

## 2. 条件化后的平均场：来源付款为 CSMW

在 E₀ 上定义概率动作核

\[
\pi_B(dR)=\frac{1_{G_B(\eta)}(R)\rho(dR)}{\rho(G_B(\eta))}.
\tag{3}
\]

则 π_B≤ρ，且每个动作真实合法、score 亏损≤ηq_B。置

\[
A(y,\sigma)=\int_{E_0}\int k(B,R)(y,\sigma)\pi_B(dR)dB.
\]

由真实 band 与每中心总质量 1，有 A≤C。另一方面，对每个 y，先积分真实质量窗（长度恒为 1），再用 π_B≤ρ 与真实 Lebesgue 中心几何：

\[
\begin{aligned}
\int A(y,\sigma)d\sigma
&=S\int_{E_0}\int R^{-n}1_{Q(B,R)}(y)\pi_B(dR)dB\\
&\le S\int \rho(dR)R^{-n}|E_0\cap Q(y,R)|\le SM.
\end{aligned}\tag{4}
\]

最后一项只用了 |Q(y,R)|=R^n；没有给扩大盒套来源密度帽。于是

\[
\boxed{\|A\|_H^2\le CSMW.}\tag{5}
\]

这是已证明的**一次 μ 来源预算**。它既不含 X，也不含 μ²、中心体积 |E| 或一般 selector 的 A_n。真实质量窗虽随 B,R 变化，只用长度 1 与合法窗帽，故不会增加层数。

特别，若有中心无关概率 p 且 p(G_B(η))≥κ₀>0 于 E₀，可取 ρ=p/κ₀，得到

\[
\|A\|^2\le CS\kappa_0^{-1}W.\tag{6}
\]

这里是接受率**一次逆幂**。若不条件化而直接把拒绝质量留给旧动作，基于未归一接受场的来源费通常为 κ₀^{-2}；(3) 在不改变真实动作合法性的情况下避免了该额外逆幂。

## 3. 明确平均算子 P 与真实随机替代

在中心—动作空间 (E₀×[a,b],dB π_B(dR)) 上，定义 H 值纤维平均

\[
(P\Phi)(B,R)=\int\Phi(B,T)\pi_B(dT).
\]

P²=P，是该辅助空间上的条件期望；源空间始终是 H=L²(μ×dσ)。P 不是 μ 空间的平移算子，也不是对原来源后验重新采样。对物理核 Φ(B,R)=k(B,R)，中心合成 ∫E₀PΦ dB 恰为 A。一般 P 不变函数并无 W 预算；(5) 专门来自物理核和共同半径支配测度 ρ。不能把中心—动作空间的正交性直接搬到 H。

概率核 π_B 可用一个与来源无关的公共 u∈(0,1) 的可测分位数 R(B,u) 实现。在 E₁ 上保持 R_B，在 E₀ 上采用 R(B,u)。每个 u 都是一条真正合法的共同选择器，中心边缘始终为 dB|E；同一 B 对所有来源使用同一 R(B,u)。未引入对每个来源独立选择半径。

记 L₀=∫E₀k_BdB、L₁=∫E₁k_BdB，L=L₀+L₁。平均后的完整场是 A+L₁。对每个 u 应用冻结极值的合法同步 EX，再对 u 平均和 Jensen，给

\[
\|L_0-A\|_H^2\le2D_0,\quad
D_0=\int_{E_0}\int[\psi(B,R_B)-\psi(B,R)]\pi_B(dR)dB
\le\eta X_0.\tag{7}
\]

因此实际分解为

\[
\boxed{L=A+L_1+(L_0-A).}\tag{8}
\]

A 已由 (5) 支付；变化场由 (7) 控制；未替代包 L₁ 保留在式中，不当作免费不变部分。其费用为真实 X₁，下一节准确列出。没有宣称 P 不变子空间全部可由 W 支付。

## 4. 比三角回代更省的完整平方桥

由 score 的定义和 (1)，

\[
Q=\langle L,A\rangle+D_0+\langle L,L_1\rangle
\le\sqrt{Q}\sqrt{CSMW}+\eta X_0+CSX_1.\tag{9}
\]

这里 〈L,L₁〉≤C∫L₁dμdσ=CSX₁。应用 2√(QB)≤Q+B，严格得到

\[
\boxed{Q\le CSMW+2\eta X_0+2CSX_1.}\tag{10}
\]

可见 P/EX 解释了平均与变化的关系，但最省的最终预算只需合法近最佳 score 与一次 Cauchy，不再多付差场三角常数。

若能对任意输入构造 M≤M(n)、X₁≤βX，则

\[
Q\le CSM(n)W+(2\eta+2CS\beta)X.\tag{11}
\]

例如取 η≤δ/4、β≤δ/(4CS)，得到 Q≤CSM(n)W+δX。固定 r,S,γ 时 C 与维数无关；M(n) 为多对数便是原连续窗所需的平方来源桥。辅助极值的 X 与原 X 比较时仍须保 X*≤rX_original；需要原误差 δ_original 时应在辅助域使用 δ≤δ_original/r。

## 5. 真正剩余的几何任务与冻结 band 的边界

本轮没有证明 (2) 可在 X₁ 小、M 多对数的同时实现。精确未证任务现为：对真实近最佳合法集合 G_B(η)，构造同一个有限半径覆盖测度 ρ，代价 M 多对数，并把未覆盖中心的 X 质量降到 βX；或者另以一次 W 支付那些未覆盖中心的实际场。这个输入不能由“每个 B 至少有旧半径”代替，也不能先对每个来源对挑覆盖半径。

冻结 band 已容许一个必须明确处理的情形：合法动作可为随 B 连续变化的单点，任何有限 ρ 不能覆盖这些中心。一个短的真实核查是 n=1，μ(dx)=x²1_[−3,3]dx，E=[5/6,9/10]，a=1、b=2、q=λ=1。所有相关区间均在 [−3,3] 内，精确有

\[
\frac{\mu Q(B,R)}R=B^2+\frac{R^2}{12}.
\]

故唯一合法半径 R_B=√(12(1−B²))∈(1,2)，在 E 上严格单调。任意有限 ρ 仅有可数个正质量原子，所以 ρ({R_B})=0 对 a.e. B；此时 G_B(η) 无论 η 多大都仍是唯一合法半径。这里未用来否定原 Q 目标，只核查“共同近最佳半径覆盖”不能直接作为冻结合同的普遍引理。对这种刚性动作纤维，须有额外来源付款，或经过有价密度带放松；本稿没有丢弃它。

即使 r>1 使部分纤维有区间，当前仍无量化覆盖或带边界补集预算。固定倍数扩大 band 后产生新的极值问题，不能把其合法动作免费接到旧极值的 EX。以上没有继续做新放松，也没有声称小亏损必然给足够场变化。

## 6. 本机精确核验

实际运行本机 `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python -I`，用 SymPy 得到上述真实区间平均 B²+R²/12；用 Fraction 核条件概率的支配关系、能量帽与端点半径，核对二次回代恒等式。结果：`PASS 33 exact conditional-envelope and quadratic-bridge checks`。这些是代数/模型核验；(4)—(10) 的一般维数证明由正文的 Tonelli、真实中心体积与 Cauchy 给出。

```python
from fractions import Fraction as F
import sympy as sp
x,B,R=sp.symbols('x B R',real=True, positive=True)
avg=sp.simplify(sp.integrate(x*x,(x,B-R/2,B+R/2))/R)
assert avg==B**2+R**2/12
for b in (F(5,6),F(9,10)):
 r2=12*(1-b*b)
 assert F(1)<r2<F(4)
count=0
for probability in ([F(1,3),F(2,3)],[F(1,4),F(1,2),F(1,4)]):
 N=len(probability)
 for mask in range(1,2**N):
  kappa=sum(p for i,p in enumerate(probability) if mask>>i&1)
  pi=[p/kappa if mask>>i&1 else F(0) for i,p in enumerate(probability)]
  assert sum(pi)==1
  assert all(pi[i]<=probability[i]/kappa for i in range(N))
  count+=2
for C in (F(1),F(3,2),F(2)):
 for row in ([F(1,4),F(3,4)],[F(1),F(1,2),F(0)],[F(0),F(0)]):
  if max(row)<=C:
   assert sum(v*v for v in row)<=C*sum(row)
   count+=1
z,h,e=sp.symbols('z h e',nonnegative=True)
assert sp.expand((z-h)**2+2*(h*z+e-z*z))==h*h+2*e-z*z
print('PASS',count+4,'exact conditional-envelope and quadratic-bridge checks')
```
