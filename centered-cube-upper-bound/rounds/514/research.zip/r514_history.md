# R514 来源与复现

起始仓库 /Users/zhengzhihao/Math-Research-centered-cube-work，main b01c5fd3316d89b162b03dcfb3cdb7e2f9765f2b；git status干净。上一轮改变权威仓库且已推送，分类为进展。

主代理、复用Astra high几何、Sol high独审、Sol medium精确数值按互不冲突/tmp文件分工；无新增无关Agent。只有主代理归档与git。

继续使用64项数学工具中的M03范围约束，重新读取SKILL及provenance：并无适用本问题的一般稳定性常数，不把极值存在等同于强制性。曾查看F05接口说明，但本轮未调用外部谱定理；本轮所有新正估计由真实中心体积、Tonelli、窗帽、Cauchy和有价条件化直接证明。

既有合同来自[R513](https://github.com/alizeisnotalice/Math-Research/tree/main/centered-cube-upper-bound/rounds/513)及R512归档。本轮不重新声明旧完整链独审；原父逐项支配和极值输入沿此前证明。用户第486轮后路线建议保留为来源过程不可混用与累计账约束，没有把该Palm链能量代换到本轮场上。

实际解释器 /Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python，Python3.12.14，SymPy1.14.0；Fraction为本轮精确模型主工具。MATLAB、Arb、优化求解器本轮未使用，不列为证据；未安装软件。

重放：将geometry中Python围栏提取为geometry_0.py；在独立目录执行解释器-I。数值脚本自行生成JSON。规范比对只去掉顶层seconds计时，其余字段与stdout逐字比对。最终归档再次解压重放并校验manifest。数值模型四组，有限范围与非极值状态明确；没有从低维检查外推一般证明。
