# R256 先行计划

仅6个真实正体积L1盒来源，n=1/2每阶段各1；初探共同core、压力分离簇、扩大相邻簇。接收域从不交胞筛选，n1胞边1/8共32候选、n2胞边1/4共256候选；来源每盒边≤d=1/(8ceil√n)。R_j=1+j/16。所有胞/来源参数、质量和体积使用Fraction。

每胞全octave上界为各上取整尺度的expanded-box捕获质量/(R_j−1/16)^n，首R=1另分母1；保整个接收胞扩张η。选入E仅当此上界≤4λ（λ1）。若夹逼平方和上界超过通用价格，只记enclosure未认证，不当定理反例。

全域diagonal使用各来源的完整sup上/下界平方；common-scale diag/cross固定同一R_j。同窗两响应之差保有符号区间，cross用四端点乘法。core仅指整个接收胞在同一R下完整捕获所有来源支撑，其他部分单列，不能把中心值当积分或把每槽最优尺度混成共同尺度。后续记录精确实际结果；一般cap预算/根阶不由有限模型证明。

## 最终实际模型与范围

仅6例，三阶段各n=1,2；全部来源为正体积小盒上的常密度，质量不移动。a=1,b=2,λ=1，d=D=1/(8ceil√n)，所以n1为1/8、n2为1/16，每个sourcebox side≤d。每个盒的质量/中心/边长完整保存JSON。来源盒只在零测边界可能接触，μ_i可视为原μ限制；不是来源点云。

初探common_core为质量各1的两个近盒；压力separated_clusters为两个分离簇、每簇两个质量1盒，簇中心坐标±5/4、簇内首坐标偏移±d/2。扩大adjacent_clusters的**最终参数**按主代理新近对任务调整为三个质量各2的盒：首坐标中心−D/8、0、D/8，其余坐标0，各边D/8。此调整取代最初远间距adjacent试参，最终模型仍只有6例。近簇的不同sourcebox间P_D严格正，原off-diagonal保留；未因D截掉full source。

receiver候选胞均铺在[-2,2]^n：n1边1/8、32胞；n2边1/4、16²=256胞。不交仅忽略边界零测集，E为通过cap认证的整个胞之并。初探/分离簇所有胞入选；近簇n1入选20胞、n2入选220胞。总816/864胞，真实体积依次4、16、4、16、5/2、55/4（不同维度的体积不相加解释为同一空间体积）。

## cap与积分的精确方向

每个胞中心c、胞边η。R_j=1+j/16,j0…16，任何R∈(R_{j−1},R_j]、胞内x都有Q_R(x)⊂Q_{R_j+η}(c)。共同来源上界为μ(Q_{R_j+η}(c))/(R_j−1/16)^n；R=1单列分母1（j1也为1）。不是各槽分别选R后合成cap。入选只用这些有理共同上界的最大值≤4，因而认证整个胞及连续R∈[1,2]的Mμ≤4。候选胞共14688次尺度上界评价，未把有限R网格当连续sup相等。

固定R，胞内响应由μ_i(Q_{R−η}(c))/R^n与μ_i(Q_{R+η}(c))/R^n夹逼。体积乘上下界后累加，才是Lebesgue积分夹逼。对角sup平方和下界用各有限R的响应下界取max；上界用各来源全octave包络取max。原共同尺度记录始终同一R_j并保全来源。两窗[1,3/2]、[3/2,2]的有符号差先作区间相减，cross用四端点乘法，允许负界；不把它强制裁成正数，也不冒称该夹逼给出实际cross符号。

102个common-scale记录分别列全diag/cross、全来源完整捕获core/其他部分，并额外按每对来源是否均完整捕获分解cross。12个有符号窗口记录使用同样规则（两端都要完整捕获才归pair core）。全部来源共同core为空不等于所有pair来自边界；分离簇内部仍有局部共同core。例如n1分离簇在R1的cross夹逼[3,4]中，pair完整捕获core项精确为3，不能将其误归边界innovation。非core标签只是几何分区，不认证历史创新或付费归因。

## 新核心Z_D：实际来源双积分

不作random shift数值积分。采用主代理给定三次原函数
F(u)=((u+D)_+³−2u_+³+(u−D)_+³)/(6D)，其二阶导为P_D(u)=(1−|u|/D)_+。任意两个来源区间交集的双积分为
F(β−γ)−F(α−γ)−F(β−δ)+F(α−δ)。

将每个sourcebox分别与Q_{R±η}(c)相交，各坐标的精确双积分相乘，再乘完整两个source密度及R^(−2n)。P_D和h_R均非负，所以inner/outer交集确给整个receivercell的Z_D上下界；包括同一来源的self-pair及不同来源的全部off-diagonal。这里使用的是盒内的真实连续y,z积分，不是source-centre P_D。

每个receivercell选择同一个R_j：最大化总guaranteed lower response μ(Q_{R_j−η}(c))/R_j^n，平局取首个。该规则由有理数精确执行、在胞内常值，所有来源共用它。先试center-response-max规则时近簇的下包络为0（η比source宽，不能据此说真实Z为0）；最终使用上述稳健lower-response规则，在相同cells/grid上得到严格正offdiag下界，没有加样本或模型。

7项primitive Fraction自测实际通过：两个尺度的同区间积分2D²/3、交换对称、平移、缩放、远离支撑为零及非负/体积上界。它们核对实现，不替代作者原函数恒等式证明。

最终六例Z_D积分夹逼，依common n1/n2、separated n1/n2、adjacent n1/n2顺序，约为[2.325782,2.393073]、[1.463557,1.542423]、[4.343145,4.409743]、[2.955780,3.057207]、[2.924490,4.365896]、[.772751,3.301758]。近簇offdiag严格正下界为188229/107648与39931/98304，约1.748560、.406199；没有只靠上界非零来声称实际非零。

## 预算、实际统计与局限

κ_D=2+nlog(1+D)≤2+nD；本轮有理保守预算8λ(2+nD)Σm_i分别为34、34、68、68、102、102。6例的原individual-sup²积分上包络分别约3.241096、5.049843、6.018389、9.415785、2.710035、4.848007，全部小于对应预算；6例Z_D上包络也全部小于同一预算。因此均有真实receiver integral的有限有理预算证据，未把中心点响应当积分。与较大保守κ上界比较只是有限较弱证据，通用精确κ定理由作者/独审证明，不能由6例反推。

实际counts：6 true_L1_models、18 source_boxes、7 primitive_exact_checks、816 selected/864 candidate receivercells、14688 exact_cap_upper_evaluations、102 common_scale_integral_records、12 signed_innovation_records、6+6个预算上包络认证。18个40/70位显示字段仅为κ的log和比值诊断，50位序列化保留两精度差异；最大相对差7.8087610833031837637654982275412027942996406776891e−42（分母max(1,|高精值|)）。所有核心几何/cap/Z_D/预算夹逼用Fraction，无浮点区间API或求积误差声称。

这不是一般root/FULL、历史资格或远来源pair预算证书；近对预算不允许免费删除远pair。模型中的实际μ、E、共同R及L1体积均显式固定，未从低维结果猜维数阶。签名innovation包络宽或跨零时只记未决，不把它说成反例或确定符号。未安装库、未调用QP、未重跑旧轮。

## 可移植重放

解压包中在脚本与合同同目录执行：

```sh
PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor \
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 \
numeric_checks.py --contract task_contract.md --output numeric_checks.replay.json
```

本机实际使用Python3.12.14与mpmath1.3.0（上述vendor）；标准库Fraction承担精确证书，mpmath只做普通显示/多精度一致性。脚本自足，无旧checkpoint/NumPy/SciPy/MATLAB依赖；JSON绑定脚本和合同SHA，不含耗时/时间戳/本机路径。最终包外完整逐字节复现由主代理执行。当前正式运行已经完成，后续只冻结文件。
