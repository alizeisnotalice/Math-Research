#!/usr/bin/env python3
"""R256 finite positive-volume receiver/source boxes, exact rational enclosures."""
import argparse,hashlib,itertools,json,math
from pathlib import Path
from fractions import Fraction as F
import mpmath as mp

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def fs(x):return str(x.numerator)+'/'+str(x.denominator)
def outpair(v):return list(map(fs,v))
def add(a,b):return(a[0]+b[0],a[1]+b[1])
def mul(a,b):
    q=[x*y for x in a for y in b];return(min(q),max(q))
def sq(a):return(F(0)if a[0]<=0<=a[1]else min(x*x for x in a),max(x*x for x in a))
def sub(a,b):return(a[0]-b[1],a[1]-b[0])
def sumints(v):return(sum((x[0]for x in v),F(0)),sum((x[1]for x in v),F(0)))
def scale(v,w):assert w>=0;return(v[0]*w,v[1]*w)
def capture(box,c,R):
    if R<=0:return F(0)
    ans=box['mass']
    for z,l,x in zip(box['centre'],box['side'],c):
        ans*=max(F(0),min(z+l/2,x+R/2)-max(z-l/2,x-R/2))/l
    return ans

def response(box,c,R,eta,n):return(capture(box,c,R-eta)/R**n,capture(box,c,R+eta)/R**n)
def fullupper(box,c,eta,n,L):
    return max(capture(box,c,1+F(j,L)+eta)/(F(1)if j==0 else 1+F(j-1,L))**n for j in range(L+1))
def fullycaptured(boxes,c,R,eta):
    return all(abs(x-z)+(l+eta)/2<=R/2 for b in boxes for x,z,l in zip(c,b['centre'],b['side']))
def box(mass,c,side):return {'mass':F(mass),'centre':list(map(F,c)),'side':[F(side)]*len(c)}
def menu():
    out=[]
    for phase,family in [('initial','common_core'),('stress','separated_clusters'),('expanded','adjacent_clusters')]:
        for n in [1,2]:
            rt=math.isqrt(n)+(math.isqrt(n)**2<n);d=F(1,8*rt)
            if family=='common_core':boxes=[box(1,[-d/2]*n,d/2),box(1,[d/2]*n,d/4)]
            elif family=='separated_clusters':
                boxes=[]
                for sign in [-1,1]:
                    for offset in [-d/2,d/2]:
                        c=[sign*F(5,4)]*n;c[0]+=offset;boxes.append(box(1,c,d/2))
            else:
                boxes=[box(2,[-d/8]+[F(0)]*(n-1),d/8),box(2,[F(0)]*n,d/8),box(2,[d/8]+[F(0)]*(n-1),d/8)]
            out.append((phase,family,n,d,boxes))
    return out

def primitive(u,D):
    pos=lambda x:max(F(0),x)
    return (pos(u+D)**3-2*pos(u)**3+pos(u-D)**3)/(6*D)
def pair_interval(alpha,beta,gamma,delta,D):
    if beta<=alpha or delta<=gamma:return F(0)
    return primitive(beta-gamma,D)-primitive(alpha-gamma,D)-primitive(beta-delta,D)+primitive(alpha-delta,D)
def primitive_checks():
    checks=[]
    for D in [F(1),F(3,8)]:
        v=pair_interval(F(0),D,F(0),D,D);assert v==2*D*D/3;checks.append(fs(v))
    args=(F(-1,4),F(1,8),F(0),F(3,8),F(1,8));a,b,c,d,D=args;v=pair_interval(*args)
    assert v==pair_interval(c,d,a,b,D);checks.append(fs(v))
    assert v==pair_interval(a+7,b+7,c+7,d+7,D);checks.append(fs(v))
    k=F(3,2);assert pair_interval(a*k,b*k,c*k,d*k,D*k)==v*k*k;checks.append(fs(v*k*k))
    assert pair_interval(F(0),F(1,8),F(1),F(9,8),F(1,4))==0;checks.append('0/1')
    assert 0<=v<=(b-a)*(d-c);checks.append(fs(v))
    return checks

def source_pair(box1,box2,c,W,R,D,n):
    density=box1['mass']*box2['mass'];ans=F(1)
    for z,l,w,q,x in zip(box1['centre'],box1['side'],box2['centre'],box2['side'],c):
        alpha=max(z-l/2,x-W/2);beta=min(z+l/2,x+W/2)
        gamma=max(w-q/2,x-W/2);delta=min(w+q/2,x+W/2)
        val=pair_interval(alpha,beta,gamma,delta,D)
        assert val>=0
        ans*=val;density/=l*q
    return density*ans/R**(2*n)
def near_receiver_enclosure(boxes,c,R,eta,D,n):
    diag=(F(0),F(0));cross=(F(0),F(0))
    for i,b in enumerate(boxes):
        for j,bb in enumerate(boxes):
            val=(source_pair(b,bb,c,R-eta,R,D,n),source_pair(b,bb,c,R+eta,R,D,n))
            assert val[0]<=val[1]
            if i==j:diag=add(diag,val)
            else:cross=add(cross,val)
    return diag,cross

def allcases():
    rows=[]
    for phase,family,n,d,boxes in menu():
        eta=F(1,8)if n==1 else F(1,4);count=int(4/eta);L=16;volume=eta**n;lam=F(1)
        cells=[];rejected=0;capchecks=0
        for inds in itertools.product(range(count),repeat=n):
            c=[-F(2)+eta*(F(i)+F(1,2))for i in inds]
            # For cap, use summed mass at one common upper R, never slotwise best R.
            cap=max(sum((capture(b,c,1+F(j,L)+eta)for b in boxes),F(0))/(F(1)if j==0 else 1+F(j-1,L))**n for j in range(L+1));capchecks+=L+1
            if cap<=4*lam:cells.append((c,cap))
            else:rejected+=1
        assert cells
        diag=(F(0),F(0));gridtotal=(F(0),F(0));corevolume=F(0)
        common=[];delta=[]
        # Receiver integral of sum_i(M mu_i)^2, full continuum upper/fixed-grid lower.
        for c,cap in cells:
            indiv=[];totals=[]
            for b in boxes:
                lower=max(response(b,c,1+F(j,L),eta,n)[0]for j in range(L+1))
                upper=fullupper(b,c,eta,n,L);assert lower<=upper
                indiv.append((lower*lower,upper*upper))
            diag=add(diag,scale(sumints(indiv),volume))
            rr=[sumints([response(b,c,1+F(j,L),eta,n)for b in boxes])for j in range(L+1)]
            gridtotal=add(gridtotal,scale((max(v[0]for v in rr)**2,max(v[1]for v in rr)**2),volume))
        # Responses and signed innovations at the SAME R and SAME receiver cells.
        for j in range(L+1):
            R=1+F(j,L);records={key:(F(0),F(0))for key in ['diag','cross','total','core_diag','core_cross','noncore_diag','noncore_cross','pair_fullycaptured_cross','pair_other_cross']};corevol=F(0)
            for c,cap in cells:
                v=[response(b,c,R,eta,n)for b in boxes]
                di=sumints([sq(x)for x in v]);cr=scale(sumints([mul(v[i],v[k])for i in range(len(v))for k in range(i)]),2);tot=sq(sumints(v))
                core=fullycaptured(boxes,c,R,eta);prefix='core_'if core else'noncore_'
                for name,iv in [('diag',di),('cross',cr),('total',tot),(prefix+'diag',di),(prefix+'cross',cr)]:records[name]=add(records[name],scale(iv,volume))
                for ii in range(len(v)):
                    for kk in range(ii):
                        paircore=fullycaptured([boxes[ii],boxes[kk]],c,R,eta)
                        key='pair_fullycaptured_cross'if paircore else'pair_other_cross'
                        records[key]=add(records[key],scale(mul(v[ii],v[kk]),2*volume))
                if core:corevol+=volume
            common.append({'R':fs(R),'fully_captured_core_volume':fs(corevol),**{k:outpair(v)for k,v in records.items()}})
        for left,right in [(F(1),F(3,2)),(F(3,2),F(2))]:
            records={key:(F(0),F(0))for key in ['diag','cross','total','core_diag','core_cross','noncore_diag','noncore_cross','pair_fullycaptured_cross','pair_other_cross']};corevol=F(0)
            for c,cap in cells:
                v=[sub(response(b,c,right,eta,n),response(b,c,left,eta,n))for b in boxes]
                di=sumints([sq(x)for x in v]);cr=scale(sumints([mul(v[i],v[k])for i in range(len(v))for k in range(i)]),2);tot=sq(sumints(v))
                core=fullycaptured(boxes,c,left,eta)and fullycaptured(boxes,c,right,eta);prefix='core_'if core else'noncore_'
                for name,iv in [('diag',di),('cross',cr),('total',tot),(prefix+'diag',di),(prefix+'cross',cr)]:records[name]=add(records[name],scale(iv,volume))
                for ii in range(len(v)):
                    for kk in range(ii):
                        paircore=fullycaptured([boxes[ii],boxes[kk]],c,left,eta)and fullycaptured([boxes[ii],boxes[kk]],c,right,eta)
                        key='pair_fullycaptured_cross'if paircore else'pair_other_cross'
                        records[key]=add(records[key],scale(mul(v[ii],v[kk]),2*volume))
                if core:corevol+=volume
            delta.append({'s':fs(left),'t':fs(right),'both_scale_core_volume':fs(corevol),**{k:outpair(v)for k,v in records.items()}})
        near_diag=(F(0),F(0));near_cross=(F(0),F(0));chosen={}
        for c,cap in cells:
            j=max(range(L+1),key=lambda jj:sum((capture(bb,c,1+F(jj,L)-eta)for bb in boxes),F(0))/(1+F(jj,L))**n)
            R=1+F(j,L);chosen[j]=chosen.get(j,0)+1
            nd,nc=near_receiver_enclosure(boxes,c,R,eta,d,n)
            near_diag=add(near_diag,scale(nd,volume));near_cross=add(near_cross,scale(nc,volume))
        near_total=add(near_diag,near_cross)
        if family=='adjacent_clusters':assert near_cross[0]>0
        mass=sum((b['mass']for b in boxes),F(0));kappa=2+n*d;budget=8*lam*kappa*mass
        assert diag[0]<=diag[1]
        row={'phase':phase,'family':family,'n':n,'a':'1/1','b':'2/1','lambda':fs(lam),'d':fs(d),'eta':fs(eta),'source_boxes':[{'mass':fs(b['mass']),'centre':list(map(fs,b['centre'])),'side':list(map(fs,b['side']))}for b in boxes],'total_source_mass':fs(mass),'candidate_receiver_cells':count**n,'selected_receiver_cells':len(cells),'rejected_receiver_cells':rejected,'receiver_volume':fs(len(cells)*volume),'receiver_cells':[{'centre':list(map(fs,c)),'full_octave_common_source_cap_upper':fs(cap)}for c,cap in cells],'max_cap_upper':fs(max(v for c,v in cells)),'scale_grid_divisions':L,'exact_cap_upper_evaluations':capchecks,'continuum_diagonal_sup_square_integral':outpair(diag),'finite_common_grid_total_max_square_integral':outpair(gridtotal),'kappa_rational_upper':fs(kappa),'diagonal_budget_rational_upper':fs(budget),'upper_enclosure_below_budget':diag[1]<=budget,'budget_minus_enclosure_upper':fs(budget-diag[1]),'common_scale_integral_enclosures':common,'signed_innovation_enclosures':delta,'near_pair_D':fs(d),'near_pair_scale_selection':'Per receiver cell choose first grid R maximizing the total guaranteed lower response mu(Q_(R-eta)(centre))/R^n; one common R for all sources.','near_pair_chosen_common_R_counts':{str(j):v for j,v in sorted(chosen.items())},'near_pair_diag_integral':outpair(near_diag),'near_pair_offdiag_integral':outpair(near_cross),'near_pair_Z_integral':outpair(near_total),'near_pair_upper_enclosure_below_budget':near_total[1]<=budget,'near_pair_budget_minus_upper':fs(budget-near_total[1]),'scope':'Positive-volume receiver integral enclosures; finite-grid lower bounds are not equality to continuum supremum. Noncore is a geometric partition label, not a historical innovation theorem.'}
        rows.append(row)
    return rows

def mpvalues(rows,dps):
    with mp.workdps(dps):
        out=[]
        for r in rows:
            n=r['n'];d=F(r['d']);mass=F(r['total_source_mass']);up=F(r['continuum_diagonal_sup_square_integral'][1]);kappa=2+n*mp.log(1+mp.mpf(d.numerator)/d.denominator)
            out.append({'name':r['family']+'_'+str(n),'kappa_log':mp.nstr(kappa,50),'universal_budget_log':mp.nstr(8*kappa*mass.numerator/mass.denominator,50),'enclosure_over_rational_budget':mp.nstr(mp.mpf(up.numerator)/up.denominator/(mp.mpf(F(r['diagonal_budget_rational_upper']).numerator)/F(r['diagonal_budget_rational_upper']).denominator),50)})
        return out

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));ap.add_argument('--contract',type=Path,default=Path(__file__).with_name('task_contract.md'));a=ap.parse_args();primitives=primitive_checks();rows=allcases();low=mpvalues(rows,40);high=mpvalues(rows,70)
    with mp.workdps(100):
        diff=[abs(mp.mpf(x[k])-mp.mpf(y[k]))/max(1,abs(mp.mpf(y[k])))for x,y in zip(low,high)for k in x if k!='name'];maxdiff=mp.nstr(max(diff),50);assert max(diff)<mp.mpf('1e-36')
    result={'schema':'R256-local-cap-cluster-v1','script_sha256':sha(__file__),'contract_sha256':sha(a.contract),'counts':{'true_L1_models':len(rows),'primitive_exact_checks':len(primitives),'source_boxes':sum(len(r['source_boxes'])for r in rows),'selected_receiver_cells':sum(r['selected_receiver_cells']for r in rows),'candidate_receiver_cells':sum(r['candidate_receiver_cells']for r in rows),'exact_cap_upper_evaluations':sum(r['exact_cap_upper_evaluations']for r in rows),'common_scale_integral_records':sum(len(r['common_scale_integral_enclosures'])for r in rows),'signed_innovation_records':sum(len(r['signed_innovation_enclosures'])for r in rows),'budget_enclosure_certified_models':sum(r['upper_enclosure_below_budget']for r in rows),'precision_fields_compared':len(diff),'near_pair_budget_enclosure_certified_models':sum(r['near_pair_upper_enclosure_below_budget']for r in rows)},'primitive_exact_results':primitives,'models':rows,'mp40':low,'mp70':high,'precision_max_relative_difference':maxdiff,'scope':'Exact Fraction receiver-cell geometry and integral enclosures, finite actual L1 sources. All-octave cap certified on each whole selected cell; no FULL/history/root or general proof claim. MP logarithmic diagnostics are not interval certificates.'}
    a.output.write_text(json.dumps(result,ensure_ascii=False,sort_keys=True,indent=2)+'\n');print(json.dumps({'counts':result['counts'],'maxdiff':maxdiff}))
if __name__=='__main__':main()
