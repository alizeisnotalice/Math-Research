# R256：保留真实接收域的共同核心与跨簇缺口

## LG1. 范围与结论

令 \(n\ge1\)、\(0<a\le b\le2a\)、\(\lambda>0\)，\(\mu\) 为任意非负有限 \(L^1(\mathbb R^n)\) 测度，\(W=\mu(\mathbb R^n)\)。记 \(h_R=R^{-n}1_{[-R/2,R/2]^n}\)、\(A_R=h_R*\mu\)，并固定真实可测域
\[
 E\subset\{M_{[a,b]}\mu\le4\lambda\}.
\]
以下所有接收积分均保留同一个 \(E\)。不把该条件改为来源密度帽，也不改变来源。

本稿未证明任意不交尺度窗的局部根阶平方和。可严格保留的内容是：真实局部二次核、共同核心的端点支付、长窗根阶界，以及单簇最大响应的对角预算。首次未付项是短窗中的真实 signed 跨簇捕获交互；满空间平移不变二次核不能直接替代它。R256 的随机网格近来源对新付款由其他责任稿给出，本稿不重复其证明，也不把本稿的恒等式算作新增全交通付款。

## LG2. 局部二次核不能换成满空间核

对有限不交尺度区间 \([s_j,t_j]\subset[a,b]\)，令
\[
 Q_E=\sum_j\int_E(A_{t_j}-A_{s_j})^2\,dx.
\]
精确地，
\[
 Q_E=\iint \mathcal B_E(y,z)\,d\mu(y)d\mu(z),
\quad
 \mathcal B_E(y,z)=\sum_j\int_E
 [h_{t_j}(x-y)-h_{s_j}(x-y)]
 [h_{t_j}(x-z)-h_{s_j}(x-z)]\,dx. \tag{LG2.1}
\]
它一般依赖 \(y,z\) 两个变量，不仅依赖 \(y-z\)。R255 对满空间
\(K_s+K_t-2h_s*h_t\) 的正主控因此不能未经证明用于 \(\mathcal B_E\)。

所有展开均绝对可积：\(A_R\le4\lambda\) 于 \(E\)，且 \(\int_E A_R\le W\)，所以
\(\int_E(A_s+A_t)^2\le16\lambda W\)。这同时允许对可数真实来源分块作 Tonelli/绝对收敛展开。

## LG3. 保共同核心的精确局部式

固定一窗 \([s,t]\)，置
\[
 q=(s/t)^n,\qquad V_{s,t}=A_t-qA_s
 =t^{-n}\mu(Q_t(x)\setminus Q_s(x))\ge0,
\quad \mathcal E_E(R)=\int_E A_R^2.
\]
逐点平方展开给
\[
 \int_E(A_t-A_s)^2
 =\mathcal E_E(t)-\mathcal E_E(s)
 +2(1-q)\mathcal E_E(s)-2\int_E A_sV_{s,t}. \tag{LG3.1}
\]
最后一项是真实共同核心与新捕获来源的交叉量，不能删去后仍声称使用了抵消。

把给定区间之间以及两端的空隙补齐成 \([a,b]\) 的有限分割，新增的平方积分非负。于是原 \(Q_E\) 不超过该分割上的精确和
\[
 \mathcal E_E(b)-\mathcal E_E(a)
 +2\sum_j\left[(1-q_j)\mathcal E_E(s_j)
                -\int_E A_{s_j}V_j\right]. \tag{LG3.2}
\]
例如仅删除最后负项，利用 \(1-e^{-n\delta}\le n\delta\)，只得到
\[
 Q_E\le4\lambda W[1+2n\log(b/a)], \tag{LG3.3}
\]
不是目标的根阶预算。式 (LG3.2) 是未付项的精确位置，不是新的已付估计。

共同核心本身可以一次收费。令
\(m_0(x)=\mu(Q_a(x))\)、\(C_R(x)=R^{-n}m_0(x)\)。任意有限不交区间都有
\[
 \sum_j[C_{t_j}(x)-C_{s_j}(x)]^2
 \le C_a(x)^2-C_b(x)^2,
\]
因为对非负单调下降序列，\((u-v)^2\le u^2-v^2\)，并可补齐空隙。因此
\[
 \sum_j\int_E(C_{t_j}-C_{s_j})^2\le4\lambda W. \tag{LG3.4}
\]
这里 \(m_0\) 依赖真实接收点 \(x\)，不被当作新的静态来源测度。对 \(A_R-C_R\) 与核心的交互仍须保留；(LG3.4) 不能独自控制全部响应。

## LG4. 长窗已付款；短窗尚缺抵消

若 \(\log(t_j/s_j)\ge n^{-1/2}\)，不交性给窗数至多
\(\lfloor\sqrt n\log(b/a)\rfloor\)。由于两响应非负，
\[
 \int_E(A_t-A_s)^2\le\mathcal E_E(t)+\mathcal E_E(s)
 \le8\lambda W.
\]
故所有长窗的总价至多
\[
 8\lambda W\sqrt n\log(b/a). \tag{LG4.1}
\]
剩下只有短窗。将短窗也按次数直接付 \(8\lambda W\) 不合法；有限窗数可以任意大。

## LG5. 真正可支付的簇最大值对角

取任意可数真实限制分解 \(\mu=\sum_C\mu_C\)，每个 \(\mu_C\) 支撑于完整边长 \(d\) 的立方体，且 \(m_C=\|\mu_C\|\)。R251 已证
\[
 u|\{M_{[a,b]}\mu_C>u\}|\le\kappa_d m_C,
 \qquad \kappa_d=2+n\log(1+d/a).
\]
因 \(\mu_C\le\mu\)，在原 \(E\) 上 \(M\mu_C\le4\lambda\)。逐簇 layer-cake 后再 Tonelli 得
\[
 \sum_C\int_E(M\mu_C)^2
 \le\sum_C\int_0^{4\lambda}2u\frac{\kappa_dm_C}{u}\,du
 =8\lambda\kappa_d W. \tag{LG5.1}
\]
当 \(d=a/(8\sqrt n)\) 时 \(\kappa_d\le2+\sqrt n/8\)。该价没有簇数或熵费，且允许每簇内部任意 \(L^1\) 集中。

但 (LG5.1) 是最大响应的簇对角，不自动控制每簇多窗平方和，更不能把真实跨簇项随机化删去。若额外已知同一窗族满足
\(\sum_j|\Delta_j A^C|^2\le L(M\mu_C)^2\)，则其对角可付 \(8L\lambda\kappa_dW\)；本稿没有授予这样的统一 \(L\)。

## LG6. 首次未付的具体空间交互

令 \(A_R^C=h_R*\mu_C\)、\(V_j^C=A_{t_j}^C-q_jA_{s_j}^C\ge0\)。式 (LG3.2) 内的 signed 项精确展开为
\[
 \sum_{j,C,D}\int_E A_{s_j}^C
 \big[(1-q_j)A_{s_j}^D-V_j^D\big]dx. \tag{LG6.1}
\]
同一个 \(C,D,x\) 的衰减与新捕获必须共同处理。已完全捕获来源的衰减有 (LG3.4) 的端点机制；多个簇近同步进入立方体所产生的交互没有被 (LG5.1) 支付。

这可以在真实空间中定位：若簇中心为 \(z_C\)、边长为 \(d\)，则除端点零测集外，
\[
 R<2\|x-z_C\|_\infty-d\Rightarrow A_R^C=0,
 \qquad R>2\|x-z_C\|_\infty+d\Rightarrow A_R^C=m_CR^{-n}.
\]
部分捕获只在两者之间；然而不同簇的此区间可以重叠。不能假设一般位置、不能按来源簇数免费求和，也不能把原确定性平方随机化。

另一个合法但过早失损的式子是
\[
 |\Delta_j A|^2\le8\lambda\sum_C
 \frac{(A_{t_j}^C-A_{s_j}^C)^2}{A_{t_j}^C+A_{s_j}^C}\quad(x\in E), \tag{LG6.2}
\]
零分母项定义为零。这是加权 Cauchy 与完整响应帽的结果；它舍弃局部振幅和 (LG3.1) 的负信用。它本身没有给出所需根阶总价，故不把其右边命名为新势后宣布闭合。

本轮其他责任稿的随机网格近来源对预算支付单个实际共同尺度 R 下的近对硬平方，包含跨原簇的近对；它不自动支付多窗的 signed 近对增量，直接逐窗用端点平方估计仍会复制窗数。因此本稿的多窗对象仍需一个同时保留近、远来源对及共同核心信用的跨窗证明，不能说结合该单尺度预算后只剩远对。式 (LG6.1) 的一般根阶上界目前未证，本稿不声称新增原全交通付款。

## LG7. 最小可复现代数检查

以下标准库代码已实际运行，输出 `rational_checks: 4`。它只检查三窗精确展开和共同核心平方望远镜；不是实际接收/来源构造，也不是一般不等式的数值证明。

```python
from fractions import Fraction as F
R = [F(1), F(5, 4), F(3, 2), F(2)]
N = [F(2), F(3), F(7, 2), F(5)]
n = 3
A = [m / r**n for m, r in zip(N, R)]
checks = 0
for s, t, As, At in zip(R, R[1:], A, A[1:]):
    q = (s / t)**n
    V = At - q * As
    assert V >= 0
    assert (At - As)**2 == At**2 - As**2 + 2*(1-q)*As**2 - 2*As*V
    checks += 1
C = [N[0] / r**n for r in R]
assert sum((v-u)**2 for u, v in zip(C, C[1:])) <= C[0]**2 - C[-1]**2
checks += 1
print({'rational_checks': checks,
       'scope': 'algebraic identities only; not a receiver/source construction'})
```
