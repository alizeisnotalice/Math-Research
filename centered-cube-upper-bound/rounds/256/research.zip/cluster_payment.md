# R256: entropy-free near-source pair payment at the actual common receiver scale

The new paid object is a true near-source pair part of the squared hard
response, including pairs across any previously fixed cell boundary.
It yields a measurable receiver share of the original response. It is
not a new source fraction, and the weighted pair complement 1-P_D
(including the unretained part of nearby pairs) remains unpaid.
No source is moved, made uniform, or assigned its own receiver scale.

## CP1. Original data and certified constants

Let mu>=0 be a finite L1 source on R^n, W=||mu||, a>0, lambda>0,
a<=b<=2a, and M=M_[a,b]. Keep a finite measurable actual receiver E with

    Mmu<=4lambda on E, X=lambda|E|,
    R(x) in [a,b] one common measurable receiver scale,
    H(x)=(h_{R(x)}*mu)(x).

Fix the R255 energy smoothing length d=a/(8sqrt(n)). Let C_n denote
any proved R255 coarse maximal constant satisfying, uniformly for all
positive L1 sources sigma,

    ||M sigma||_2^2<=C_n E_d(sigma),
    E_d(sigma)=integral K_d(y-z)sigma(dy)sigma(dz),
    K_d=h_d*h_d, C_n=O(sqrt(n)log^2(n+2)).             (CP1)

This is the certified R255 theorem, with its full finite-grid/prefix
constant; no density or source independence is added here. All uses
of E_d below keep this one physical d.

Independently choose one package side D>0. A valid full-package weak
coefficient is

    kappa_D=min{(1+D/a)^n,
                2+n log(1+D/a), 1+n log(b/a)}.       (CP2)

The old support-volume and whole-octave column coefficients are valid
for every D. R251 supplies the displayed second coefficient for D<=a;
for D>a it cannot be the minimum, since it exceeds 1+n log2
and hence exceeds 1+n log(b/a). Thus CP2
is valid for every D without extending that theorem's stated range.
Any smaller separately proved package weak coefficient can replace it.
For a source sigma supported in one D-cube, mass m,

    t|{M sigma>t}|<=kappa_D m.                        (CP3)

In particular at D=d, kappa_d<=2+sqrt(n)/8.

## CP2. Fixed-package square budget with no label entropy

For any disjoint source decomposition mu=sum_j mu_j into sources
supported in D-cubes, put m_j=||mu_j|| and F_j=1_E Mmu_j. Positivity
gives F_j<=4lambda, separately for every j. It does not give
sum_j F_j<=4lambda. Height also gives F_j<=m_j/a^n. Layer cake and
CP3 prove the actual L2-square budget

    integral_E F_j^2 dx
       <=2kappa_D m_j min(4lambda,m_j/a^n)
       <=8lambda kappa_D m_j.                        (CP4)

CP1 gives the simultaneous energy price C_n E_d(mu_j). Hence

    integral_E sum_j F_j^2 dx<=sum_j b_j,
    b_j=min{2kappa_D m_j min(4lambda,m_j/a^n),
                                      C_n E_d(mu_j)}. (CP5)

In particular this is at most 8lambda kappa_D W, without a source
cap, cell count, overlap count, or graph entropy. Countably many
packages are handled by nonnegative Tonelli. This does not bound
(sum_j F_j)^2 by sum_j F_j^2; off-diagonal interactions are not erased.

The two bounds in b_j are actual computable source quantities; the
minimum is taken separately before summing and therefore can improve
on taking the minimum only after aggregation. It is not an unnamed
norm or a presumed bound for a residual source.

## CP3. Same-cell probabilities retain real near-source interactions

For s in [0,D)^n, use the half-open D-grid translated by s and let
mu_C^s=mu|C. The partition is formed in source space, independently
of x and the actual common scale R(x). Let

    P_D(v)=product_i(1-|v_i|/D)_+,
    Z_D(x)=integral h_R(x-y)h_R(x-z)P_D(y-z)mu(dy)mu(dz),
                                                    R=R(x).

For fixed y,z, P_D(y-z) is exactly the probability, under normalized
uniform translation s, that y and z are in the same grid cell. Thus
the exact identity is

    Z_D(x)=(1/D^n)integral_[0,D)^n
                    sum_C [(h_{R(x)}*mu_C^s)(x)]^2 ds. (CP6)

Here R(x) is the same for all source cells and all shifts. This is an identity of the
actual source pairs. Kernel-coordinate products do not assert any
independence of the source or its posterior.

Joint measurability follows from the half-open cell indicators and
the actual measurable kernel. If maxima are used in CP4, positive
L1 convolution is continuous in R and the supremum can be taken over
rational scales. All integrands in CP6 are nonnegative, so Tonelli
justifies countable cells and the continuous average. The source
decomposition changes with s only within this explicitly averaged
identity; it is not inserted as a shift-independent extracted source.

Apply CP5 for each shift before averaging. Define the explicit mixed
source price

    B_D=(1/D^n)integral_[0,D)^n sum_C
       min{2kappa_D m_C(s) min(4lambda,m_C(s)/a^n),
                                      C_n E_d(mu_C^s)}ds. (CP7)

Then the true common-scale receiver/source estimate is

    integral_E Z_D dx<=B_D<=8lambda kappa_D W.         (CP8)

There is no epsilon error per cell or shift. The source mass sums to
W for every partition and is averaged once with total weight one.

## CP4. The source-energy alternative is a true product kernel

The same same-cell identity inside E_d gives

    Ecap_{d,D}(mu):=(1/D^n)integral_[0,D)^n
                                sum_C E_d(mu_C^s)ds
       =integral K_d(y-z)P_D(y-z)mu(dy)mu(dz).        (CP9)

Therefore the full explicit minimum is

    integral_E Z_D dx<=B_D
         <=min{8lambda kappa_D W,C_n Ecap_{d,D}(mu)},
    0<=Ecap_{d,D}(mu)<=E_d(mu).                      (CP10)

The source kernel in CP9 is known explicitly; it is not the original
unpaid traffic renamed. For D=d it is d^n K_d(v)^2 and its Lebesgue
integral is (2/3)^n. This last statement concerns the kernel mass only.
It does NOT imply Ecap_{d,d}(mu)<=(2/3)^n E_d(mu) for arbitrary mu.
For example n=d=1 and mu=1_[0,1]dx give E_d=2/3, Ecap=1/2, so even
this genuine L1 example violates that proposed relative factor.
No exponential source gain is inferred without additional actual
source geometry.

## CP5. Root-priced response share, with one receiver error

Since 0<=P_D<=1, one has 0<=Z_D<=H^2. Define the actual receiver share

    eta_D(x)=sqrt(Z_D(x))/H(x) if H(x)>0,
    eta_D(x)=0 if H(x)=0.

It is measurable and lies in [0,1]. It is not a source fraction theta
and is not a modification of any original posterior. Young's scalar
inequality gives the genuine paid allocation

    integral_E eta_D H dx=integral_E sqrt(Z_D)dx
       <=epsilon X+B_D/(4epsilon lambda)
       <=epsilon X+(2kappa_D/epsilon)W.              (CP11)

At D=d this is at most

    epsilon X+(4+sqrt(n)/4)W/epsilon.               (CP12)

Thus it is an entropy-free root-price part for an arbitrary original
positive source, including arbitrary high coarse-cell masses. The
unpaid remainder is exactly integral_E(H-sqrt(Z_D))dx. Equivalently
the remaining squared-pair quantity is the nonnegative expression

    H^2-Z_D=integral h_R(x-y)h_R(x-z)
                              [1-P_D(y-z)]mu(dy)mu(dz). (CP13)

Neither its size nor its energy is bounded by CP8 or CP11. It cannot
be declared small because the paid part has no entropy.

If an actual geometric certificate gives Z_D>=gamma H^2 on a stated
receiver domain, gamma>0, the whole hard response there is paid by

    integral_E H dx<=epsilon X+B_D/(4epsilon lambda gamma).
                                                               (CP14)

The certificate, its domain, and gamma must be proved for the actual
source/receiver pair. It is not supplied by CP6. The familiar case
of at most L contributing cells for a fixed partition gives gamma=1/L
for that partition's square sum; this is a valid old bounded-overlap
corollary, not claimed as a new general source settlement here.

## CP6. Metric near-source off-diagonal payment

For nonnegative u_i with sum u_i<=1, product_i(1-u_i)>=1-sum_i u_i.
Hence P_D(y-z)>=1/2 whenever ||y-z||_1<=D/2. Define the true near-pair
quantity at the same actual common R by

    N_D(x)=integral_{||y-z||_1<=D/2}
                         h_R(x-y)h_R(x-z)mu(dy)mu(dz).

It satisfies pointwise N_D<=2Z_D and N_D<=H^2. Therefore

    integral_E N_D dx<=2B_D<=16lambda kappa_D W,
    integral_E sqrt(N_D)dx
       <=epsilon X+B_D/(2epsilon lambda)
       <=epsilon X+(4kappa_D/epsilon)W.             (CP15)

For L1 sources the exact diagonal y=z has zero pair measure. Thus
CP15 genuinely includes a positive-volume near-source off-diagonal,
including pairs straddling an arbitrarily fixed original cell boundary.
The metric condition is not a replacement for the original source
gates or an assertion that all contributing source pairs are near.

## CP7. Finite choices, common scale, and original traffic

A finite deterministic grid plan also works. For fixed shifts s_j,
nonnegative scalar weights w_j summing to one, and fixed package
partitions of side D, put Z_plan=sum_j w_j sum_C H_C,sj^2 and use
the same weighted sum of CP5 prices. All preceding receiver-share
and Young steps hold, with one total receiver error. Weights are
fixed before the receiver integral; they are not free functions of x.

For several physical package sizes D_j one may similarly take a fixed
convex combination of the Z_Dj and their prices B_Dj. If instead one
takes max_j Z_Dj, its valid square budget is sum_j B_Dj. There is no
free multiple-D maximum or uncharged scale/source reassignment. The
energy smoothing length d remains the same in every Ecap unless a
separate valid comparison is paid.

If an original positive traffic density P(x) has a pointwise certified
domination P(x)<=C_dom H(x), then eta_D P is paid with

    integral_E eta_D P dx<=epsilon X
                              +C_dom^2 B_D/(4epsilon lambda).

One uses the internal Young error epsilon/C_dom. The complementary
traffic share remains untouched. Integral domination alone does not
authorize multiplying its two sides by eta_D. No double posterior is
cropped or rebuilt, no negative credit is used twice, and no source
ledger over different parent histories is inferred here.

## CP8. Actual joint-source extension

Let beta,nu be positive finite L1 sources with beta,nu<=f and retain
the genuine receiver condition E subset {Mf<=4lambda}. No ordering
between beta and nu is required. Keep one and the same actual scale
R(x) for both sources. Write H_beta=h_R*beta, H_nu=h_R*nu and define

    Z_D(beta,nu)(x)=integral h_R(x-y)h_R(x-z)
                                  P_D(y-z)beta(dy)nu(dz).

The joint same-cell identity is exactly the normalized shift average
of sum_C H_beta,C H_nu,C. Cauchy--Schwarz on the product measure
dx times normalized ds times counting measure on cells gives

    integral_E Z_D(beta,nu)dx
       <=sqrt(B_D(beta) B_D(nu))
       <=8lambda kappa_D sqrt(W_beta W_nu)
       <=4lambda kappa_D(W_beta+W_nu),              (CP16)

where each B_D is the actual CP7 price for that source, using the
same E,R,d,D,lambda. This also retains the source-energy alternative

    integral_E Z_D(beta,nu)dx
       <=C_n sqrt(Ecap_{d,D}(beta)Ecap_{d,D}(nu)).   (CP17)

The energy bound follows either from CP16's first line and CP10,
or directly from Cauchy--Schwarz after the per-cell R255 estimates.
No mixed-source rank or source independence has been used.

Pointwise 0<=Z_D(beta,nu)<=H_beta H_nu. Thus sqrt(Z_D) is a
measurable receiver share of sqrt(H_beta H_nu), with ratio zero
when this latter quantity is zero. In particular

    integral_E sqrt(Z_D(beta,nu))dx
       <=epsilon X+(2kappa_D/epsilon)sqrt(W_beta W_nu)
       <=epsilon X+(kappa_D/epsilon)(W_beta+W_nu).   (CP18)

The actual cross-source near-pair quantity with ||y-z||_1<=D/2
satisfies N_D(beta,nu)<=2Z_D(beta,nu) and <=H_beta H_nu, so

    integral_E N_D(beta,nu)dx
       <=16lambda kappa_D sqrt(W_beta W_nu),
    integral_E sqrt(N_D(beta,nu))dx
       <=epsilon X+(4kappa_D/epsilon)sqrt(W_beta W_nu). (CP19)

At D=d these are root-order source prices. Their square-root
allocations are receiver/source-pair shares, not extracted source
fractions. Arbitrary original double-posterior weights, normalizers,
capture restrictions and prefactors have not disappeared: only a
separately proved pointwise domination of an original positive
density by the displayed bare responses permits the corresponding
CP7 allocation, with its full C_dom^2 price. No claim is made that
CP16 is already the original weighted double-Pi traffic integral.

## CP9. Bounded exact checks, independently reproducible

The following Python standard-library script was actually executed
locally, exit 0: `PASS 17 exact Fraction checks`. It uses genuine
L1 source mu=1_[0,1]dx, n=a=lambda=1, E=[0,1], R(x)=2, d=1/8.
Here Mmu<=1 everywhere, so the receiver upper cap is valid; this
is not a construction of a FULL historical instance. For each D,
the exact shifted-cell sum and source-pair integral agree. The
checks test formulas and a false relative-energy shortcut; they
are not evidence for payment of the unpaid complementary traffic.

```python
from fractions import Fraction as F

def mul(a, b):
    c = [F(0)] * (len(a) + len(b) - 1)
    for i, x in enumerate(a):
        for j, y in enumerate(b):
            c[i+j] += x*y
    return c

def integ(p, h):
    return sum(v*h**(i+1)/F(i+1) for i, v in enumerate(p))

d = F(1, 8)
checks = 0
for D in [d, F(1, 4), F(1, 2), F(1)]:
    pair = 2*integ(mul([1, -1/D], [1, -1]), D)
    # Partial masses s,D-s and 1/D-1 full cells of mass D.
    shift = integ([D*D+(1/D-1)*D*D, -2*D, F(2)], D)/D
    assert pair == shift == D-D*D/3
    checks += 1
    Z, H = pair/4, F(1, 2)
    near = (D-D*D/4)/4
    assert 0 <= Z <= H*H and 0 <= near <= min(H*H, 2*Z)
    checks += 1
    Ecap = 2/d*integ(mul(mul([1, -1/d], [1, -1/D]), [1, -1]), d)
    Ed = 1-d/3
    assert 0 <= Ecap <= Ed
    checks += 1
    print('D', D, 'Z', Z, 'near', near, 'Ecap', Ecap, 'Ed', Ed)

for n in [1, 2, 4, 16]:
    assert (1-F(1, 2*n))**n >= F(1, 2)
    checks += 1

# Genuine L1 warning with d=D=1, mu=1_[0,1]dx.
Ed = 2*integ(mul([1, -1], [1, -1]), F(1))
Ec = 2*integ(mul(mul([1, -1], [1, -1]), [1, -1]), F(1))
assert Ed == F(2, 3) and Ec == F(1, 2) and Ec > F(2, 3)*Ed
checks += 1
print('PASS', checks, 'exact Fraction checks')
```

Actual output:

```text
D 1/8 Z 23/768 near 31/1024 Ecap 31/48 Ed 23/24
D 1/4 Z 11/192 near 15/256 Ecap 77/96 Ed 23/24
D 1/2 Z 5/48 near 7/64 Ecap 169/192 Ed 23/24
D 1 Z 1/6 near 3/16 Ecap 353/384 Ed 23/24
PASS 17 exact Fraction checks
```
