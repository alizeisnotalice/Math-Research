# R256 独立审计

## 命题先行初筛（未读作者证明）

本文件是唯一编辑责任，未改其他工作者文件。初次读取时256/work尚未创建；按主代理明确责任创建本文件，等待正式合同。历史仅窄读R251冻结主稿的单cluster弱型工具；R255已证能量接口沿用，不重复审核。

### B：真实接收帽下的任意正分解对角平方预算

**PASS，一般严格结论。** 设mu=sum_i mu_i为可数正L1分解，各mu_i支撑于完整边长<=d=a/(8sqrt n)的cube，m_i=mass(mu_i)，F_i=M_[a,b]mu_i。正性给实际E上F_i<=Mmu<=4lambda，并非给sum_iF_i同一帽。R251对任意块内分布授u|{F_i>u}|<=kappa m_i，其中kappa=2+nlog(1+d/a)。因此真实Lebesgue层积分/Tonelli给

`integral_E sum_i F_i² = sum_i integral_0^(4lambda) 2u |E intersect {F_i>u}| du <=8lambda kappa sum_i m_i`。

无限分解先有限和、再非负单调极限；mass0项为0，无log(m_i)、胞数或邻接entropy。mu_i可重叠，只须正分解和mu仍为原来源；分析不能重建实际posterior。若每块side更小，仍可用共同kappa或各自kappa_i。d尺度代入并用log(1+x)<=x，得到更直观的

`integral_E sum_i F_i² <=lambda(16+sqrt n)mass(mu)`。

这是真实一般对角平方预算，非数值例或输入density/rank假设，也不要求receiver E有限体积（若原任务要求有限则自动满足）。lambda=0可直接由响应为0处理；通常保lambda>0。严格/非严格超水平端点不影响layercake。

### A：全来源尺度增量与squareoperator接回的最早缺口

R255对同一原来源已付sum_j||Delta_j h*mu||²<=C sqrt(nlog n)E_d(mu)，但actualE帽并不单独给E_d(mu)<=C lambda mass；不可直接替换右端。候选A要求在相同actualE/真实dx下直接给全来源增量平方的局部估计，现仍待作者证明，不能以B作认证。

B控制sum_i Fi²，不控制(sum_i Fi)²；后者包含正cross。把mu=sum mu_i代入每个尺度增量时亦有cross_i,i'。合法接回需要另证实际向量算子的frame/Bessel或Gram支配及其常数，并保同一receiver选择器/所有原weights；不能把来源块叫不同labels就授正交或免费随机符号。即便每块有B，按窗逐项|Delta|²<=4Fi²仍会复制窗口数，不能省略该价格。相同全来源的不同实际窗口也不是彼此来源独立副本。

建设性基线：响应在E上属于[0,4lambda]，故每窗|Delta|²<=4lambda|Delta|。尺度分布导数的face与bulk总质量为2n/R，真实来源Tonelli给全空间尺度总变差<=2nlog(b/a)mass。因此可获得O(nlog(b/a))lambda mass的保守局部平方增量价。该工具只作量级/方向校准，未当新root；若作者声称降至root，应明确哪一共同几何估计减少了face/bulk绝对值损失，而不是复述已付能量或改名cross预算。

本人本轮实际运行6个Fraction粗胞常数核验n=1,4,16,64,256,4096，验证8[2+n/(8sqrt n)]=16+sqrt n，全部PASS。一般B的证明是上面的layercake，不靠有限核验。尚未读作者稿，等待准确候选及主整合。


## 新核心命题先行独筛：连续平移的真实近来源对预算

**PASS。** 在作者证明之前独立核验如下。任意D>0，s均匀分布于[0,D)^n并用归一化D^-n ds，半开网格C_k^s=s+Dk+[0,D)^n，mu_C^s为原mu限制。对于固定y,z，每坐标的same-cell shift比例为(1−|y_i−z_i|/D)+；独立的只是分析shift各坐标，不是来源或原Π。因此

`E_s sum_C 1_C(y)1_C(z)=P_D(y−z)=product_i(1−|y_i−z_i|/D)+`。

原mu为L1，全部固定shift的网格边界是null hyperplanes，故分解无漏质量；半开格即使不使用这一点也给严格可测partition。固定原actualR(x)与E之后，所有积分非负，Tonelli合法，精确得到

`Z_D(x)=E_s sum_C [(h_{R(x)}*mu_C^s)(x)]²`。

actualR可依原来源/原x；不能在analysis shift后重新选择来源或为每源使用不同R。E保Mmu<=4lambda，故任一cell响应不大于4lambda。每cell任意原块内形状由R251的kappa_D=2+nlog(1+D/a) weak预算付，再Tonelli countable/shift平均，给

`integral_E Z_D <=8lambda kappa_D mass(mu)`。

这已经控制真实同cell source pairs里的cross，并非只控制原子或μ×μ的对角（L1来源的对角本来零测）。P_D>=1−sum_i |v_i|/D>=1/2在||v||1<=D/2上成立，因而

`integral_E integral_(||y−z||1<=D/2) h_{R(x)}(x−y)h_{R(x)}(x−z) dmu(y)dmu(z) dx <=16lambda kappa_D mass(mu)`。

D=a/(8sqrt n)给不超过lambda(32+2sqrt n)mass；任意D=Ca/sqrt n也有O_C(sqrt n)质量价。该分支可为空或很小，不声称所有来源pair占固定正比例。

第二价：对同一固定shift各原cell先用R255 full maximal能量，之后平均，得到

`integral_E Z_D <= P_n(d,ell) integral integral K_d(y−z) P_D(y−z) dmu(y)dmu(z)`，

其中d=a/(8sqrt n)，D独立任意；右端能量不要求D=d。常数与cell/shift无关，所有同变量pair保留，两个正上界可以取min而无菜单费。不把P_D能量换成更小的其它来源/平滑尺度。正性给Z_D<=(h_Rmu)²；准确残余是权1−P_D的同源pair贡献，尚未付。固定近距离硬indicator预算与P_D预算是两个可用支配，不能将重叠正交通作为两个不交新信用累加。

原fullΠ及另一来源槽不因本二次恒等式改变；若应用到原traffic，仍须先认证实际母式到该硬平方/近对kernel的有价支配，并保prefactors、真实dx和所有门。一般weak1和远对残余未闭合。

### 本人实际几何诊断（可重放）

以下18项Fraction计算是same-cell几何有限诊断，通用恒等式由上面解析证明；不属于原FULL模型或正式numeric菜单。

```python
from fractions import Fraction as F
import math

def prob(y,z,D):
 cuts=sorted({F(0),D,y%D,z%D});ans=F(0)
 for l,r in zip(cuts,cuts[1:]):
  s=(l+r)/2
  if (y-s)//D==(z-s)//D:ans+=(r-l)/D
 return ans
pairs=[([F(0),F(0)],[F(0),F(0)]),
 ([F(-1,3),F(1,7)],[F(1,3),F(2,7)]),
 ([F(1),F(-1)],[F(0),F(-1,2)]),
 ([F(1,2),F(1,4)],[F(3,2),F(3,8)]),
 ([F(1,8),F(-1,8)],[F(3,8),F(1,8)]),
 ([F(9,4),F(-13,8)],[F(17,8),F(-3,2)])]
checks=0
for y,z in pairs:
 for yi,zi in zip(y,z):
  assert prob(yi,zi,F(1))==max(F(0),1-abs(yi-zi));checks+=1
for v in [[F(0)],[F(1,2)],[F(1,4),F(1,4)],
          [F(1,8)]*4,[F(1,16)]*8,[F(1,3),F(1,6)]]:
 assert sum(map(abs,v))<=F(1,2)
 assert math.prod(max(F(0),1-abs(x))for x in v)>=F(1,2);checks+=1
print('PASS',checks,'exact same-cell/near-pair geometric diagnostics; not FULL')
```

实际输出：`PASS 18 exact same-cell/near-pair geometric diagnostics; not FULL`。等待作者完整稿和主整合终审，目前不冻结。


## cluster_payment.md 作者稿后审核

**CP1–7全文PASS。** 本节在先行独筛与18项几何算术实际执行后才读作者稿。受审当前SHA256：`e40b5d1b9fa32c913f64cad3002b93d4376bc9fe60783ec81791674cc3e772f0`，最终冻结时再统一绑定。

CP2三合法weak系数取min安全；D>a时whole-octave系数已更小，所以不依赖R251超出原陈述范围。CP4还保每块height m/a^n，有限/可数分解每项先取weak与energy价格min，再求和/shift平均均是同一个正量的真实上界。κ_D可依D任意大，但d固定为R255平滑尺度，没有将D和d混同。

CP6精确计入同胞pair，归一化shift、真实半开partition及L1/可测性全齐；countable Tonelli不要求source coordinates独立。CP9的Ecap是真实K_d P_D product，非未付账改名；D=d的kernel质量(2/3)^n只说明Lebesgue mass，作者明确禁止当任意来源相对收益。n=d=1、mu=1_[0,1]的E_d=2/3、Ecap=1/2分别由2 integral_0^1(1−r)^2 dr与2 integral_0^1(1−r)^3 dr可直接精确核实，数值例方向正确。

eta=sqrt Z/H的0分支、可测与[0,1]资格正确，CP11/12的单receiver Young价是εX+B_D/(4ελ)，d粗尺度给(4+sqrt n/4)mass/ε。真实near-pair N<=2Z的CP15两常数亦正确；它含L1正体积offdiag，没声称占全部pair固定比例。CP14若另给Z>=γH²，整response价需γ^-1，作者完整保留。H−sqrt Z与H²−Z都是准确非负残余，未将它们混为相同函数。

有限shift/多D固定凸组合保持一次receivererror，取max需sum budgets，原d能量另付。CP7只有pointwise认证P(x)<=C_dom H(x)才可给eta P付款；integral支配不能免费乘eta。C_dom²与原双Π、父历史、sourceledger边界都保。本文因此确有一般真实近来源pair预算与response分配，但不认证A/远pair/一般weak1。


## 主稿与辅助局部几何审核

主proof全文一般定理**PASS**：对角、连续同胞平均两个价、实际近ℓ1集合和两原来源βν全部保持真实E/同一个R。主B_D是min{averaged weak价,averaged energy价}，CP附件的min-before-average可以更尖但主稿未混用。βν版本在receiver×shift×cell的同一个乘积测度上作Cauchy，需要且明确保双侧actualcap与共同R；βν<=f是合法充分条件，不授混合source的rank或posterior重建。主稿的1−P_D残余精确包含远对和未全保留的近对，未误称纯far指标。近set为ℓ1球，不是ℓ∞盒。

CP8/CP9新增已读，cross energy两侧及响应share常数均正确。本人实际从作者最终Markdown提取CP9脚本执行：17项Fraction检查全部PASS，四行真L1的Z/near/Ecap/Ed与稿内输出逐行相同；不当作FULL实例。其sourceE=[0,1]、R2对全部source恰全捕获，故H1/2、Z的receiver积分计算成立。

localized_geometry LG2–6全部显示公式已独审：真实局部kernel依y,z双变量，不能移用translation invariant全空间kernel。LG3共core精确平方展开、补gap、端点4lambda W一次付款与longwindow root价正确；LG6.2 weightedCauchy为8lambda系数，零分母定义充分。LG7四项Fraction代码本人已从Markdown实际提取执行，PASS4，仅代数检查。

**辅助scope窄修已发作者/主代理，待落实：** LG6末段不能说CP结合后A多窗局部二次核“只剩远来源对”。CP支付一个共同actualR的近pair硬平方或response share，并不自动支付sum_windows signed近pair增量；直接用端点响应仍有窗口数费用。A的近/远signed跨窗接桥均须另证，或给出确切已付近increment推导。这个问题不影响主proof一般近对定理，但最终辅助稿须收窄文字。

## 数值实现初审（等待最终冻结）

已完整读取当前源码。真实receiver cell fullside eta时，Q_(R−eta)(center)包含于Q_R(x)包含于Q_(R+eta)(center)；源码据此用精确capture质量夹逼整个cell而非只中心。R连续区间用质量上端R_j+eta与分母下端R_(j−1)^n，且先sum全source再取R上界，故actual全octave cap确被认证，不把slotwise最优当共同R。每个来源的diag maximal可独立sup，这是被审对角对象自身定义，不是更换原H的尺度。

primitive的二阶导是P_D的一维tent，四端点差精确积分sourcepair。源码的source_pair在R±eta中心box上作真实裁剪、保持同一归一分母R^(2n)并以非负P_D夹逼；tensor只用于实际sourcebox形状。adjacent源的cross下界>0直接来自receiver体积包络，非点值或y=z原子。当前命名near_pair_Z实际上为P_D加权量而非metric N_D，应在notes明确，两者理论仅N<=2Z，不混证据。

n2中d=1/(8ceil sqrt n)=1/16不等于理论a/(8sqrt2)，是更小的实际package side；通用D定理适用但应明记此finite参数。数值预算用κ上界2+nd而非含log的精确κ，有限证书应按该明确较松root价报告。diagonal/cross labels指指定sourcebox标签，不是pair集合y=z。等待最终notes/hash/统计核对后冻结。


### 初筛6项粗胞常数诊断代码

这是本轮最初实际运行的标准库Fraction算术，可与18项same-cell代码分别重放，不作正式物理实例计数。

```python
from fractions import Fraction as F
import math
for n in [1,4,16,64,256,4096]:
 r=math.isqrt(n); assert r*r==n
 d=F(1,8*r); kap=2+n*d
 assert 8*kap==16+r
print('PASS 6 exact coarse-cell diagonal constants: 8*kappa_upper=16+sqrt(n)')
```

## 最终数值说明窄审

最终notes已明确n2的D=d=1/(8ceil sqrt n)=1/16、正体积receivercells、所有sourcebox参数和全R[1,2]夹逼方向。P_D加权Z与metric近对N分开，box-label的diag/self-pair不等于原pair对角y=z。有限预算以较松κ上界2+nD认证，不由此冒称精确κ系数已在数值证；通用κ预算来自已证引理。common-cap先sum source再取R，完全保同一个共同scale。signed innovations允许跨零，不据宽包络认定符号。

本人实际核对最终numeric JSON/source/contract自绑定、AST，以及全部6模型的whole-cell cap<=4lambda、diag上包络<=有理价、Z上包络<=同价的guards，全部PASS。统计6模型/18sourceboxes、816选入/864候选胞、14688cap评价、102共同R记录、12signed窗、7primitive检查、6+6预算证书、18精度字段均与JSON一致。mp差7.80876108330318e−42仅log/比值显示非interval。正式完整脚本仍由root包外重放，不把作者执行当本人。几何primitive的样本自检不替代其二阶导解析公式；本审已从源码核该公式与全interval capture夹逼。


## 唯一辅助scope修复复核

已实读localized_geometry.md最终SHA0312b27dea4a8d1cb50795649f987d8b8fddfc03138295757bc339165b6cd0c6第128行：明确单R近对硬平方预算不自动支付多窗signed近增量，A仍需保留近、远及core信用的跨窗证明。上方提出的唯一待修措辞现已解决，LG全文PASS。该修复不否定本轮CP/main已付的单共同尺度一般近来源pair预算；只是禁止把不同对象未证接桥隐藏。


## 最终结论与证据归属

**PASS，可冻结；无待修阻断。** 本轮确已得到任意正有限L1原来源、真实接收cap和同一actualR下的一般同胞tent加权pair预算及ℓ1近对无权预算，包括跨先验胞界的真实offdiag。βν双原来源的版本保持同一receiver/shift/cell底测度与双侧cap，未改原来源或Π。其平方根给可测receiver share的质量付款，不冒称来源fraction、全response付款或原双后验总账。

CP最终c884575仅收窄complement措辞：1−P_D也包括未保留近对；数学、附码不变。主稿同样区分精确response残余H−sqrt Z、pair平方补量、metric N与weighted Z。A的所有窗口局部平方增量仍未证；LG末段已修，不再将单R近对预算等同多窗近increment付款。R223信用、原FULL/history和全部prefactors仍未支付的部分准确保留。

本人实际执行证据为：audit附码18项Fraction same-cell/近pair几何和6项常数核算；作者CP9全部17项真L1/Fraction算术（输出逐行一致）；LG7全部4项精确代数。最终numeric的全部实际6模型cap/双预算JSON guards、script/contract自绑定和两个Python AST本人实际核对PASS。正式完整numeric生成与包外字节重放由作者/主代理执行，本审未冒称本人重跑全部14688cap或完整JSON生成。

最终report/driver静审PASS。报告统计816/864、14688、102、12、7、18与JSON/notes一致，sourcebox-label diag和D=n2参数明确，普通精度和Fraction证据分开。driver在临时目录实际重算完整numeric、比较JSON字节、断言两个6模型预算菜单、抽audit/CP/LG的全部Python块执行，并做manifest前后核验，不改原文件、不编译PDF。最终归档回执由主代理另存，不需据回执再改本audit。

### 最终受审SHA256

不绑定audit自身，避免清单循环；下列版本变更须重新核对。

|文件|SHA256|
|---|---|
|task_contract.md|`9952a633daed865e0b6e1aab8bdfa44246c12d81cda8550320dc8e961ed60d84`|
|proof.tex.txt|`6838be541a05b0b308d3e9f24576b7bb949cd1e03e052341becb91f1b6f003a0`|
|cluster_payment.md|`c884575548e72291a35c1726e5190465084ec4e746b6e4b4df65e9cc1cbf8f40`|
|localized_geometry.md|`0312b27dea4a8d1cb50795649f987d8b8fddfc03138295757bc339165b6cd0c6`|
|report.md|`834c29942d9a830c29fa9f9b505bb31036ccd1e9b3ab5e12f79e84348725ba51`|
|reproduce.py|`3d58d3bbe4ce60f5513a931ee8031f330b20f6df3181bc169c7bd7720ad6cf7f`|
|numeric_checks.py|`62d5e6ce910e28c484e4c82a6342a81a8b8eff47cdb968643d8a8b571b42d97a`|
|numeric_checks.json|`9529c012ee673a8d283fb7c4dc58b0dd4b48215e11fdec67c3d0cb36e38c733e`|
|numeric_notes.md|`bfec49b946ea6e351afa2b68032517bdaa3ca791412b94e7783e8c4d0e500a04`|

R256独立审计完成，audit.md冻结并停止写入。
