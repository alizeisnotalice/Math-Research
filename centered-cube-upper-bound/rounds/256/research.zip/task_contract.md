# R256 合同：真实接收帽下的共同来源近对预算

基线：R255，12fdeba196d37c169e5e9fbe4e2e28def415bf07。一般弱型目标保持未闭合。

定义：h_R=R^-n1_cube，a≤R≤b≤2a，μ≥0有限L1，E⊂{M_[a,b]μ≤4λ}为真实勒贝格域，R(x)是同一原来源的共同可测尺度。来源分块是原μ的限制，不移动质量。

新命题：sideD网格连续均匀平移的同胞概率P_D(v)=∏(1−|v_i|/D)+；Z_D(x)=∬h_R(x−y)h_R(x−z)P_D(y−z)dμ(y)dμ(z)。证明∫E Z_D≤8λκ_D||μ||，κ_D=2+nlog(1+D/a)，以及≤P_n(d,ell)∬K_d(v)P_D(v)μμ（R255最大能量价，d=a/(8√n)）。当||y−z||1≤D/2，P_D≥1/2，故该真实近对平方响应≤16λκ_D||μ||。D=a/(8√n)使质量费用根阶。远来源对必须保留，不得宣称完整闭合。

准确候选A：任意不交窗的局部平方增量≤C√npolylog λmass；当前尚未证明。Astra检查局部共同core负能量与batch跨来源几何，保最小未证桥；不将归约当A证明。

允许工具：R251小支持来源的weak价（保其2+nlog），R255任意正L1最大能量，Tonelli、CS、layercake与精确同胞概率。禁止直接把全空间signed核换成E截断核、假设一般来源独立、任意sourcecap、无条件Bessel或免费删除cross。L03精确计算边界继续适用；实际运行本机Python。

职责：peak仅localized_geometry.md；compare仅cluster_payment.md；audit仅audit.md；numeric仅numeric_checks.py/json及numeric_notes.md；主代理合同、详细LaTeX、报告、复现、归档提交。多人共享不覆盖，无子代理git或PDF。

三阶段数值：至多6个真实正体积sourcebox/receivercell模型，n1/2，实际E须用有理全尺度上界认证cap；单个共同R的对角/cross包络和近对量保留实际接收体积。中心值只作诊断，不作积分证书。扩展仅针对新samecell几何恒等式，不以数值推一般阶数。

成功：独审新一般近sourcepair根阶预算及源能量互补；真实高source的远pair、原全历史交通仍待支付。仅有限证据不能认证最终引理。每轮独立压缩归档与推送，控制文件数量、不编译PDF。
