"""R814 4D source-cell distance diagnostics and l1 Steiner certificates.

Exact rational cell decomposition gives inner/outer bounds, not pointwise
integration through oblique l1 facets. High-n tests are separate Arb checks.
"""

from collections import defaultdict
from fractions import Fraction as F
from itertools import product
from math import comb, factorial
import argparse, json, zipfile
import flint
from flint import arb, ctx

D_VALUES = (F(0), F(1, 8), F(1, 2), F(1), F(2))


def distance_bounds(box, target):
    lo = sum((max(F(0), a - d, c - b) for (a, b), (c, d) in zip(box, target)), F(0))
    hi = sum((max(F(0), c - a, b - d) for (a, b), (c, d) in zip(box, target)), F(0))
    return lo, hi


def owner_inf_bounds(a, b):
    low = max(max(F(0), x1 - y2, y1 - x2) for (x1, x2), (y1, y2) in zip(a, b))
    high = max(max(abs(x1 - y2), abs(x2 - y1)) for (x1, x2), (y1, y2) in zip(a, b))
    return low, high


def cube_coeff(n, k):
    return F(comb(n, k) * 2**k, factorial(k))


def check_steiner():
    # 1D interval length L+2r; 2D square L²+4Lr+2r².
    assert [cube_coeff(1, k) for k in range(2)] == [1, 2]
    assert [cube_coeff(2, k) for k in range(3)] == [1, 4, 2]
    for side, radius in ((F(3, 2), F(2, 3)), (F(1), F(1, 4))):
        # Independent 1D extension and 2D enclosing square minus corner triangles.
        assert side + 2 * radius == sum(
            cube_coeff(1, k) * side ** (1 - k) * radius**k for k in range(2)
        )
        assert (side + 2 * radius) ** 2 - 2 * radius**2 == sum(
            cube_coeff(2, k) * side ** (2 - k) * radius**k for k in range(3)
        )
    for n in range(1, 9):
        for r in (F(0), F(1, 4), F(1)):
            # Count k selected normal directions, two signs, simplex r^k/k!.
            direct = sum(
                F(comb(n, k)) * 2**k * r**k / factorial(k) for k in range(n + 1)
            )
            assert direct == sum(cube_coeff(n, k) * r**k for k in range(n + 1))
    print("Steiner exact: L^n sum_k binom(n,k)*2^k*(r/L)^k/k!; 1D and 2D checked, n<=8")


def classify_cells(stage, interval_mass):
    parents = stage["parents"]
    n = stage["dimension"]
    assert n == 4
    boxes = [[tuple(map(F, axis)) for axis in p["box"]] for p in parents]
    old = [p for p in parents if p["role"] == "old"]
    faces = []
    half = F(stage["density"]["bump_half_width"])
    for i in range(n):
        endpoints = sorted({F(-8), F(8), *(x for b in boxes for x in b[i])})
        segments = []
        for a, b in zip(endpoints, endpoints[1:]):
            mid = (a + b) / 2
            mask = sum(
                p["bit"]
                for p, box in zip(parents, boxes)
                if box[i][0] < mid < box[i][1]
            )
            segments.append((a, b, mask, interval_mass(a, b, half)))
        faces.append(segments)
    total = defaultdict(F)
    lower = defaultdict(F)
    upper = defaultdict(F)
    pieces = 0
    target = {p["id"]: [tuple(map(F, axis)) for axis in p["box"]] for p in old}
    for parts in product(*faces):
        mask = parts[0][2] & parts[1][2] & parts[2][2] & parts[3][2]
        if not mask:
            continue
        box = tuple((v[0], v[1]) for v in parts)
        w = parts[0][3] * parts[1][3] * parts[2][3] * parts[3][3]
        if w == 0:
            continue
        total[mask] += w
        pieces += 1
        for p in old:
            lo, hi = distance_bounds(box, target[p["id"]])
            for d in D_VALUES:
                key = (mask, p["id"], d)
                if d == 0:
                    if mask & p["bit"]:
                        lower[key] += w
                        upper[key] += w
                else:
                    if hi <= d:
                        lower[key] += w
                    if lo < d:
                        upper[key] += w
    expected = {x["mask"]: F(x["mass"]) for x in stage["cells"] if x["mask"]}
    assert dict(total) == expected
    for p in old:
        for mask, m in total.items():
            for d in D_VALUES:
                assert 0 <= lower[mask, p["id"], d] <= upper[mask, p["id"], d] <= m
    return total, lower, upper, pieces


def run(name, stage, ns):
    parents = {p["id"]: p for p in stage["parents"]}
    mass, lower, upper, pieces = classify_cells(stage, ns["interval_mass"])
    total = F(0)
    old_lo = F(0)
    old_hi = F(0)
    count = 0
    accum = {d: [F(0), F(0), F(0), F(0)] for d in D_VALUES}
    total_overlap = F(0)
    separation_hist = defaultdict(F)
    closed_touch_weight = F(0)
    positive_mu_intersection_weight = F(0)
    root_counts = defaultdict(int)
    q95_total = F(0)
    q95 = {d: [F(0), F(0)] for d in D_VALUES}
    half = F(stage["density"]["bump_half_width"])
    for root in stage["roots_cross"]:
        u, g = parents[root["u"]], parents[root["g"]]
        owner_u = [tuple(map(F, a)) for a in u["owner"]]
        owner_g = [tuple(map(F, a)) for a in g["owner"]]
        mn, mx = owner_inf_bounds(owner_u, owner_g)
        diagnostic = max(F(u["radius"]), F(g["radius"]))
        has_old = mn <= diagnostic
        all_old = mx <= diagnostic
        intersection = ns["intersection"](
            tuple(tuple(map(F, a)) for a in u["box"]),
            tuple(tuple(map(F, a)) for a in g["box"]),
        )
        gaps = [hi - lo for lo, hi in intersection]
        separated_axes = sum(gap < 0 for gap in gaps)
        tangent = separated_axes == 0 and any(gap == 0 for gap in gaps)
        root_counts[separated_axes] += 1
        overlap = ns["mass"](intersection, half) / min(F(u["m"]), F(g["m"]))
        assert 0 <= overlap <= 1
        coef = F(root["coefficient"])
        root_total = F(0)
        for z, q in product(root["z_masks"], root["q_masks"]):
            weight = coef * mass[z] * mass[q]
            root_total += weight
            total += weight
            total_overlap += weight * overlap
            count += 1
            if all_old:
                old_lo += weight
            if has_old:
                old_hi += weight
            if q == 95:
                q95_total += weight
            for d in D_VALUES:
                # q near A_u OR z near A_g; z and q are independent in
                # each original coefficient, so complement probabilities multiply.
                lq = lower[q, u["id"], d] / mass[q]
                uq = upper[q, u["id"], d] / mass[q]
                lz = lower[z, g["id"], d] / mass[z]
                uz = upper[z, g["id"], d] / mass[z]
                lp = 1 - (1 - lq) * (1 - lz)
                up = 1 - (1 - uq) * (1 - uz)
                assert 0 <= lp <= up <= 1
                acc = accum[d]
                acc[0] += weight * lp
                acc[1] += weight * up
                acc[2] += weight * lp * overlap
                acc[3] += weight * up * overlap
                if q == 95:
                    q95[d][0] += weight * lp
                    q95[d][1] += weight * up
        assert root_total == F(root["root_mass"])
        separation_hist[separated_axes] += root_total
        if tangent:
            closed_touch_weight += root_total
        if overlap > 0:
            positive_mu_intersection_weight += root_total
    assert total == F(stage["benchmarks"]["cross"]["mother"])
    print(
        "\nFIXTURE",
        name,
        "positive source pieces",
        pieces,
        "physical cross rows",
        count,
        "total=",
        total,
        "q95=",
        q95_total,
    )
    assert sum(separation_hist.values(), F(0)) == total
    print(
        "closed-box separating-axis histogram (strict gap, exact normalized weights):",
        {i: str(separation_hist[i] / total) for i in range(5)},
    )
    print(
        "closed-box separating-axis counts per root:",
        {i: root_counts[i] for i in range(5)},
    )
    print(
        "closed boxes intersect fraction=",
        float(separation_hist[0] / total),
        "tangent fraction=",
        float(closed_touch_weight / total),
        "positive mu-intersection fraction=",
        float(positive_mu_intersection_weight / total),
    )
    print(
        "old owner distance mass/total lower upper:",
        float(old_lo / total),
        float(old_hi / total),
    )
    for d in D_VALUES:
        a, b, c, e = accum[d]
        print(
            "new d=",
            d,
            "all hit range=",
            float(a / total),
            float(b / total),
            "hit-weighted overlap/total range=",
            float(c / total),
            float(e / total),
            "q95 hit range=",
            float(q95[d][0] / q95_total),
            float(q95[d][1] / q95_total),
        )
        print(
            "  residual overlap/total range=",
            float((total_overlap - e) / total),
            float((total_overlap - c) / total),
            "exact=",
            (total_overlap - e) / total,
            (total_overlap - c) / total,
        )
        print(
            "  exact all hit=",
            a / total,
            b / total,
            "weighted overlap=",
            c / total,
            e / total,
        )


def high_n():
    ctx.prec = 384
    print(
        "\nArb",
        flint.__version__,
        "FLINT",
        flint.__FLINT_VERSION__,
        "precision",
        ctx.prec,
    )
    for j in (4, 32, 128, 160, 256, 512):
        n = arb(2) ** j
        N = n + 2
        logN = N.log()
        J = n.sqrt() * logN**8
        d = J**2 / (1024 * n)
        # Logarithmic tests prevent overflow and preserve exact inequalities.
        margin1 = J / 2 - (logN + arb(2).log() + arb(1) / 32 + 2 * (n * d).sqrt())
        margin2 = d / 32 - logN
        enlarged_tail_margin = d / 512 - logN
        margin3 = n * arb(2).log() - J
        margin4 = n - d

        def status(x):
            return "true" if x > 0 else ("false" if x < 0 else "unresolved")

        print(
            "n=2^",
            j,
            "J<n log2:",
            status(margin3),
            "d<n:",
            status(margin4),
            "tube absorption:",
            status(margin1),
            "exp tail absorption:",
            status(margin2),
            "new exp tail /256 to /512:",
            status(enlarged_tail_margin),
            "d=",
            d.str(10),
            "J/n=",
            (J / n).str(10),
        )


def bernoulli_checks():
    # Nonidentical rational parameters; retain only terms below the threshold.
    ctx.prec = 384
    patterns = [
        (16, [F(1, 8), F(1, 4), F(1, 2), F(3, 4)]),
        (64, [F(1, 10), F(1, 3), F(2, 3), F(9, 10)]),
        (128, [F(1, 4), F(1, 2), F(3, 4), F(7, 8)]),
        (256, [F(1, 16), F(3, 8), F(5, 8), F(15, 16)]),
        (512, [F(1, 5), F(2, 5), F(3, 5), F(4, 5)]),
    ]
    print("\nNonuniform Bernoulli independent exact-rational PMF, C=1:")
    for n, pattern in patterns:
        probs = [pattern[i % len(pattern)] for i in range(n)]
        A = sum(probs, F(0))
        threshold = A / 64
        # Strict inequality k<threshold: integers 0,...,ceil(threshold)-1.
        last = (threshold.numerator - 1) // threshold.denominator
        dp = [F(1)] + [F(0)] * last
        for p in probs:
            updated = [F(0)] * (last + 1)
            for k in range(last + 1):
                updated[k] += dp[k] * (1 - p)
                if k:
                    updated[k] += dp[k - 1] * p
            dp = updated
        probability = sum(dp, F(0))
        value = arb(probability.numerator) / probability.denominator
        bound = (-(arb(A.numerator) / A.denominator) / 256).exp()
        assert value < bound
        print(
            "n=",
            n,
            "pattern=",
            list(map(str, pattern)),
            "A=",
            A,
            "last=",
            last,
            "P~",
            value.str(8),
            "bound~",
            bound.str(8),
        )


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--archive", required=True)
args = parser.parse_args()
check_steiner()
with zipfile.ZipFile(args.archive) as z:
    rebuilt = json.loads(z.read("comb814-rebuilt.json"))["stages"][0]
    ns = {"__name__": "comb811_archived"}
    exec(compile(z.read("comb811.py"), "comb811.py", "exec"), ns)
    name, n, h, middle, old = ns["FIXTURES"][-1]
    original = ns["fixture"](name, n, h, middle, old)
    run("original", original, ns)
    run("rebuilt", rebuilt, ns)
high_n()
bernoulli_checks()
print(
    "PASS: exact rational cell bounds and Arb signs; low-dimensional gate diagnostic only"
)
