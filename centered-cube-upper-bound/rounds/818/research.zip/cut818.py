"""Exact finite source/receiver cut on R814's actual q=95 rows.

This is an R818 simplified pricing test on the original R814 four-dimensional
comb fixtures; the high-dimensional R813 long-jump gate has no positive sample.
The original bilateral parent coefficient and source-cell masses are retained.
"""

from collections import defaultdict, deque
from fractions import Fraction as F
import argparse
import json
import zipfile


class Network:
    def __init__(self, n):
        self.graph = [[] for _ in range(n)]

    def add(self, a, b, cap):
        assert cap >= 0
        forward = [b, cap, len(self.graph[b])]
        backward = [a, F(0), len(self.graph[a])]
        self.graph[a].append(forward)
        self.graph[b].append(backward)

    def cut(self, source, sink):
        total = F(0)
        while True:
            level = [-1] * len(self.graph)
            level[source] = 0
            queue = deque([source])
            while queue:
                v = queue.popleft()
                for to, cap, _ in self.graph[v]:
                    if cap > 0 and level[to] < 0:
                        level[to] = level[v] + 1
                        queue.append(to)
            if level[sink] < 0:
                break
            it = [0] * len(self.graph)

            def push(v, flow):
                if v == sink:
                    return flow
                while it[v] < len(self.graph[v]):
                    edge = self.graph[v][it[v]]
                    to, cap, rev = edge
                    if cap > 0 and level[to] == level[v] + 1:
                        got = push(to, min(flow, cap))
                        if got:
                            edge[1] -= got
                            self.graph[to][rev][1] += got
                            return got
                    it[v] += 1
                return F(0)

            while sent := push(source, F(10) ** 100):
                total += sent
        seen = {source}
        queue = deque([source])
        while queue:
            v = queue.popleft()
            for to, cap, _ in self.graph[v]:
                if cap > 0 and to not in seen:
                    seen.add(to)
                    queue.append(to)
        return total, seen


def solve(rows, parents, masses, q, rho, layered=False):
    old = [p for p in parents.values() if p["role"] == "old" and q & p["bit"]]
    right_weights = {p["id"]: F(p["j"]) / F(p["m"]) for p in old}
    denom = sum(right_weights.values(), F(0))
    assert denom > 0
    receiver_cost = {}
    levels = defaultdict(set)
    edges = set()
    for row in rows:
        t, u, g, z = row["t"], row["left_parent"], row["right_parent"], row["z_mask"]
        assert g in right_weights and F(row["weight"]) > 0
        inv_m = 1 / F(parents[t]["m"])
        left_key = (t, z) if layered else z
        levels[left_key].add(inv_m)
        owner = (t, g, u)
        receiver_cost[owner] = (
            rho
            * F(parents[t]["j"])
            / F(parents[t]["m"]) ** 2
            * F(parents[u]["owner_volume"])
            * right_weights[g]
            / denom
        )
        edges.add((left_key, inv_m, owner))
    # Each selected source tier forces payment of all smaller tiers; edge arcs
    # encode coverage. Its cut capacity is the maximum 1/m_t, never a sum.
    tier_nodes = [(k, x) for k in sorted(levels, key=str) for x in sorted(levels[k])]
    receiver_nodes = sorted(receiver_cost)
    ids = {("s", k, x): i + 1 for i, (k, x) in enumerate(tier_nodes)}
    ids.update(
        {("r", *k): i + 1 + len(tier_nodes) for i, k in enumerate(receiver_nodes)}
    )
    start, finish = 0, 1 + len(tier_nodes) + len(receiver_nodes)
    graph = Network(finish + 1)
    pure_source = F(0)
    for key in levels:
        z = key[1] if layered else key
        previous = F(0)
        old_node = None
        for level in sorted(levels[key]):
            node = ids["s", key, level]
            graph.add(start, node, masses[z] * (level - previous))
            if old_node is not None:
                graph.add(old_node, node, F(10) ** 90)
            old_node, previous = node, level
        pure_source += masses[z] * previous
    pure_receiver = sum(receiver_cost.values(), F(0))
    for owner in receiver_nodes:
        graph.add(ids["r", *owner], finish, receiver_cost[owner])
    for key, level, owner in edges:
        graph.add(ids["s", key, level], ids["r", *owner], F(10) ** 90)
    best, reachable = graph.cut(start, finish)
    selected_sources = {
        (key, lev) for key, lev in tier_nodes if ids["s", key, lev] not in reachable
    }
    selected_receivers = {
        owner for owner in receiver_nodes if ids["r", *owner] in reachable
    }
    assert all(
        (key, lev) in selected_sources or owner in selected_receivers
        for key, lev, owner in edges
    )
    source_cost = F(0)
    source_choices = []
    for key in levels:
        sel = [lev for k, lev in selected_sources if k == key]
        if sel:
            z = key[1] if layered else key
            source_cost += masses[z] * max(sel)
            source_choices.append((str(key), str(max(sel))))
    receive_cost = sum((receiver_cost[k] for k in selected_receivers), F(0))
    assert best == source_cost + receive_cost
    assert best <= min(pure_source, pure_receiver)
    return {
        "mixed": best,
        "source": pure_source,
        "receiver": pure_receiver,
        "source_component": source_cost,
        "receiver_component": receive_cost,
        "selected_sources": source_choices,
        "selected_receivers": sorted(selected_receivers),
        "receiver_count": len(receiver_nodes),
        "edge_count": len(edges),
        "denom": denom,
    }


def run(name, stage, saved):
    assert stage["dimension"] == 4
    parents = {p["id"]: p for p in stage["parents"]}
    masses = {cell["mask"]: F(cell["mass"]) for cell in stage["cells"]}
    rows = saved["rows"]
    q = saved["q_mask"]
    assert q == 95 and len(rows) == 58
    assert sum(F(row["weight"]) for row in rows) == F(saved["subflow_original_mass"])
    # Independently reconstruct each marked row from the full original mother
    # coefficient and true q/z cell masses in the archived geometric fixture.
    rebuilt_rows = defaultdict(F)
    for root in stage["roots_cross"]:
        if q not in root["q_masks"]:
            continue
        for z in root["z_masks"]:
            key = (root["t"], root["u"], root["g"], z)
            rebuilt_rows[key] += F(root["coefficient"]) * masses[z] * masses[q]
    saved_rows = {
        (r["t"], r["left_parent"], r["right_parent"], r["z_mask"]): F(r["weight"])
        for r in rows
    }
    assert dict(rebuilt_rows) == saved_rows
    for r in rows:
        print(
            "ROW t,z,u,g,weight,mu_z,mt,Eu,Eg:",
            r["t"],
            r["z_mask"],
            r["left_parent"],
            r["right_parent"],
            r["weight"],
            masses[r["z_mask"]],
            parents[r["t"]]["m"],
            parents[r["left_parent"]]["owner_volume"],
            parents[r["right_parent"]]["owner_volume"],
        )
    print(
        "\nFIXTURE",
        name,
        "original q95 row mass=",
        saved["subflow_original_mass"],
        "rows=",
        len(rows),
    )
    print(
        "physical q mass=",
        masses[q],
        "actual z cells=",
        sorted({r["z_mask"] for r in rows}),
    )
    grouped = defaultdict(lambda: F(0))
    for r in rows:
        grouped[(r["t"], r["left_parent"], r["right_parent"])] += F(r["weight"])
    print(
        "original bilateral groups=",
        len(grouped),
        "middle price bins=",
        sorted({r["middle_volume_bin"] for r in rows}),
        "left price bins=",
        sorted({r["left_volume_bin"] for r in rows}),
    )
    baseline = solve(rows, parents, masses, q, F(1))
    print(
        "reference right normalization=",
        baseline["denom"],
        "receiver vertices=",
        baseline["receiver_count"],
        "source/receiver edges=",
        baseline["edge_count"],
    )
    scale = baseline["source"] / baseline["receiver"]
    for layered in (False, True):
        print("SOURCE_MODEL", "per-(t,z)" if layered else "shared-z-max-1/m")
        reference = solve(rows, parents, masses, q, F(1), layered)
        scale = reference["source"] / reference["receiver"]
        for ratio in (
            F(1, 1000),
            F(1, 100),
            F(1, 20),
            F(1, 10),
            F(1, 4),
            F(1, 2),
            F(3, 4),
            F(1),
            F(5, 4),
            F(2),
            F(4),
            F(10),
            F(100),
            F(1000),
        ):
            rho = scale * ratio
            out = solve(rows, parents, masses, q, rho, layered)
            strict = out["mixed"] < min(out["source"], out["receiver"])
            print(
                "rho/pure_cross=",
                ratio,
                "mixed/pure_source=",
                float(out["mixed"] / out["source"]),
                "pure_receiver/pure_source=",
                float(out["receiver"] / out["source"]),
                "strict=",
                strict,
                "selected_sources=",
                out["selected_sources"],
                "selected_receiver_count=",
                len(out["selected_receivers"]),
            )
            if strict:
                print(
                    "STRICT detail rho=",
                    rho,
                    "source=",
                    out["source_component"],
                    "receivers=",
                    out["receiver_component"],
                    "receiver_vertices=",
                    out["selected_receivers"],
                )
    print(
        "ALL 58 original marked bilateral rows covered; covered original row mass (not a constructed physical payment flow)=",
        saved["subflow_original_mass"],
    )


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--archive", required=True, help="R814 research.zip")
args = parser.parse_args()
with zipfile.ZipFile(args.archive) as archive:
    cells = json.loads(archive.read("cell814.json"))
    rebuilt = json.loads(archive.read("comb814-rebuilt.json"))["stages"][0]
    # Rebuild original from the archived exact generator, no files are extracted.
    namespace = {"__name__": "archived_comb811"}
    exec(compile(archive.read("comb811.py"), "comb811.py", "exec"), namespace)
    name, n, h, middle, old = namespace["FIXTURES"][-1]
    original = namespace["fixture"](name, n, h, middle, old)
    run("original", original, cells["original"])
    run("rebuilt", rebuilt, cells["rebuilt"])
print("PASS: exact rational min-cut; R813 high-dimensional gate empty in n=4")
