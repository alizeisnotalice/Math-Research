"""Exact R814 same-cell, same-right-volume-bin finite union experiment.

Inputs are continuous product-comb measures, reconstructed from the archived
fixture. No R813 long-jump conclusion is drawn from these n=4 diagnostics.
"""

import argparse
import json
import zipfile
from collections import defaultdict
from fractions import Fraction as F
from itertools import product

KS = (1, 2, 8, 32)


def run(label, stage):
    assert stage["dimension"] == 4
    parents = {p["id"]: p for p in stage["parents"]}
    cells = {c["mask"]: F(c["mass"]) for c in stage["cells"]}
    groups = defaultdict(lambda: defaultdict(F))
    total = F(0)
    records = 0
    for root in stage["roots_cross"]:
        t, u, g = (root[k] for k in ("t", "u", "g"))
        if F(parents[u]["m"]) > F(parents[g]["m"]):
            continue
        D = F(parents[g]["volume_bin"])
        assert D <= F(parents[g]["m"]) < 2 * D
        coefficient = F(root["coefficient"])
        for z, q in product(root["z_masks"], root["q_masks"]):
            assert z & parents[u]["bit"] and z & parents[t]["bit"]
            assert q & parents[g]["bit"] and q & parents[t]["bit"]
            weight = coefficient * cells[z] * cells[q]
            assert weight > 0
            groups[q, D][t, u, g] += weight
            total += weight
            records += 1
    assert total > 0
    print(
        "\nFIXTURE",
        label,
        "4D filtered m_u<=m_g",
        "rows",
        records,
        "(q,D) groups",
        len(groups),
        "original mass",
        total,
    )
    # Since every record density relative to mu is constant on each membership mask,
    # q's conditional distribution inside a mask is its original mu restriction;
    # row density depends on q only through its membership bits.
    sums = {k: F(0) for k in KS}
    full_sum = F(0)
    original_pair = F(0)
    original_pair_min = F(0)
    multi = []
    active_groups = 0
    for (q, D), rows in sorted(groups.items()):
        group_mass = sum(rows.values(), F(0))
        by_u = defaultdict(F)
        by_g = defaultdict(F)
        for (t, u, g), weight in rows.items():
            by_u[u] += weight
            by_g[g] += weight
        pi = {u: w / group_mass for u, w in by_u.items()}
        pg = {g: w / group_mass for g, w in by_g.items()}
        assert sum(pi.values(), F(0)) == sum(pg.values(), F(0)) == 1
        assert all(0 < v <= 1 for v in pi.values())
        phi = {
            mask: sum((p for u, p in pi.items() if mask & parents[u]["bit"]), F(0))
            for mask in cells
        }
        values = {k: F(0) for k in KS}
        covered = F(0)
        for g, g_prob in pg.items():
            source_cells = [
                (mask, mass) for mask, mass in cells.items() if mask & parents[g]["bit"]
            ]
            mg = F(parents[g]["m"])
            assert sum((mass for _, mass in source_cells), F(0)) == mg
            for mask, mass in source_cells:
                x = phi[mask]
                assert 0 <= x <= 1
                for k in KS:
                    values[k] += g_prob * mass * (1 - (1 - x) ** k) / mg
                if x > 0:
                    covered += g_prob * mass / mg
        assert all(0 <= values[k] <= 1 for k in KS)
        assert values[1] <= values[2] <= values[8] <= values[32] <= covered <= 1
        assert all(values[k] <= k * values[1] for k in KS)
        # Matched-pair diagnostic retains actual u,g dependence.
        own = F(0)
        own_min = F(0)
        for (t, u, g), weight in rows.items():
            intersection = sum(
                (
                    mass
                    for mask, mass in cells.items()
                    if mask & parents[g]["bit"] and mask & parents[u]["bit"]
                ),
                F(0),
            )
            mg = F(parents[g]["m"])
            mu = F(parents[u]["m"])
            own += weight / group_mass * intersection / mg
            own_min += weight / group_mass * intersection / min(mu, mg)
        for k in KS:
            sums[k] += group_mass * values[k]
        full_sum += group_mass * covered
        original_pair += group_mass * own
        original_pair_min += group_mass * own_min
        nt = len({t for t, u, g in rows})
        nu = len(pi)
        ng = len(pg)
        if values[1] > 0:
            active_groups += 1
        if nt >= 2:
            multi.append((group_mass, q, D, nt, nu, ng, values, covered, own))
    assert multi
    print(
        "active groups=",
        active_groups,
        "groups with multiple middle parents=",
        len(multi),
    )
    print(
        "overall redrawn Z ratios",
        {k: float(sums[k] / total) for k in KS},
        "full union=",
        float(full_sum / total),
    )
    print(
        "weighted Z32-Z1=",
        float((sums[32] - sums[1]) / total),
        "union-Z1=",
        float((full_sum - sums[1]) / total),
    )
    print(
        "actual paired overlap /m_g=",
        float(original_pair / total),
        "actual paired overlap /min(m_u,m_g)=",
        float(original_pair_min / total),
    )
    print("total accounted row mass exact=", total)
    for group_mass, q, D, nt, nu, ng, values, covered, own in sorted(
        multi, reverse=True
    )[:4]:
        print(
            "multi q,D=",
            q,
            D,
            "parents t,u,g=",
            nt,
            nu,
            ng,
            "group_mass=",
            group_mass,
            "Z1,Z2,Z8,Z32,union=",
            *[float(values[k]) for k in KS],
            float(covered),
            "original matched=",
            float(own)
        )
    return total


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--archive", required=True)
args = parser.parse_args()
with zipfile.ZipFile(args.archive) as z:
    rebuilt = json.loads(z.read("comb814-rebuilt.json"))["stages"][0]
    ns = {"__name__": "comb811_archived"}
    exec(compile(z.read("comb811.py"), "comb811.py", "exec"), ns)
    name, n, h, middles, olds = ns["FIXTURES"][-1]
    original = ns["fixture"](name, n, h, middles, olds)
    run("original", original)
    run("rebuilt", rebuilt)
print(
    "PASS: exact Fraction, true mu cell support; n=4 R813 long-jump gate has no positive sample"
)
