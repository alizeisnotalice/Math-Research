"""Replay the round 818 diagnostics. Requires python-flint and the original round 814 archive."""
import argparse
from fractions import Fraction
from hashlib import sha256
import json
import os
from pathlib import Path
import subprocess
import sys
import zipfile

import flint
from flint import arb, ctx

SOURCE_HASH = "891d8cbcbd35537e6abc18c938e53b1b4f300327357c24c8d14a51a46ad5e190"
HERE = Path(__file__).resolve().parent


def clamp_checks():
    points = range(-3, 4)
    intervals = [(a, b) for a in points for b in points if a <= b]
    count = contacts = 0
    for a, b in intervals:
        for c, d in intervals:
            gap = max(0, a - d, c - b)
            for q in range(c, d + 1):
                projected = min(b, max(a, q))
                assert gap == max(0, c - projected, projected - d)
                assert (gap == 0) == (c <= projected <= d)
                count += 1
                contacts += min(b, d) == max(a, c)
    print("integer closed-interval clamping:", count, "cases,", contacts, "point contacts")


def tight_mean_tests():
    """Stress the allowed worst mean m=A/32, using exact, nonidentical probabilities."""
    ctx.prec = 384
    pattern = [Fraction(1, 64), Fraction(3, 64), Fraction(5, 64), Fraction(7, 64)]
    for n in (16, 128, 512):
        probabilities = (pattern * (n // len(pattern)))
        mean = sum(probabilities)
        distance = 32 * mean
        assert distance <= 4 * n
        stop = (distance / 64).__ceil__() - 1
        lower = [Fraction(0)] * (stop + 1)
        lower[0] = 1
        for prob in probabilities:
            for j in range(stop, -1, -1):
                lower[j] = (1 - prob) * lower[j] + (prob * lower[j-1] if j else 0)
        exact = sum(lower)
        p = arb(exact.numerator) / exact.denominator
        bound = (-arb(distance.numerator) / (256 * distance.denominator)).exp()
        assert p < bound
        print("extreme mean A=32m", "n", n, "A", distance, "last", stop,
              "tail", p.str(12), "upper", bound.str(12))


def certificates(archive):
    with zipfile.ZipFile(archive) as data:
        for name in ("original", "rebuilt"):
            report = json.loads(data.read("mu814-" + name + "-1.json"))
            assert report["events"] == 357 and report["columns"] == 1041
            total = Fraction(report["original_mass"])
            for result in report["results"]:
                cells = result["by_right_cell"].values()
                feasible = sum(Fraction(row["paid"]) for row in cells)
                lower, upper = Fraction(result["lower"]), Fraction(result["upper"])
                assert sum(Fraction(row["mass"]) for row in cells) == total
                assert all(0 <= Fraction(row["paid"]) <= Fraction(row["mass"]) for row in cells)
                assert total * lower == feasible and 0 <= lower <= upper <= 1
                assert 1 - sum(map(Fraction, result["dual_delta"])) + sum(
                    map(Fraction, result["dual_source"])) + sum(map(Fraction, result["dual_target"])) == upper
                print("archived R814", name, "mode", result["mode"], "actual paid", feasible,
                      "paid/total (rounded)", float(lower), "upper (rounded)", float(upper))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--r814", required=True, type=Path)
    archive = parser.parse_args().r814.resolve()
    digest = sha256(archive.read_bytes()).hexdigest()
    if digest != SOURCE_HASH:
        raise ValueError("the round 814 input archive differs from the audited version")
    print("python", sys.version.split()[0], "python-flint", flint.__version__,
          "FLINT", flint.__FLINT_VERSION__, "round 814 sha256", digest)
    clamp_checks()
    tight_mean_tests()
    certificates(archive)
    for script in ("cut818.py", "steiner818.py", "union818.py"):
        result = subprocess.run([sys.executable, "-B", str(HERE / script), "--archive", str(archive)],
                                check=True, capture_output=True, env={**os.environ, "PYTHONHASHSEED": "0"})
        print(script, "full stdout sha256", sha256(result.stdout).hexdigest())
        print(result.stdout.decode("utf-8").rstrip())
    print("PASS: exact finite diagnostics, interval checks and archived row-accounting replay.")


if __name__ == "__main__":
    main()
