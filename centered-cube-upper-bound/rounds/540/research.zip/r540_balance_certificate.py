from pathlib import Path
import json,sys,platform
from fractions import Fraction
import sympy as s
import flint
from flint import arb,ctx
ctx.prec=256
n,r=s.symbols('n r',positive=True)
b=(1+r)/2;U=2-b;L=2-(n-1)*b/n
g0=-s.Integer(1);g2=1/r-1;c0=L;c2=L-1/(2*n)-1/(2*n*r)
identities={
 'weight_sum':s.simplify(r+(1-r)-1),
 'all_source_axis_balance':s.simplify(r*g2+(1-r)*g0),
 'mixed_mass_charge_minus_U':s.simplify(r*c2+(1-r)*c0-U),
 'none_branch_euler':s.simplify(b*g0/n+c0-U),
 'both_branch_euler':s.simplify(b*g2/n+c2-U),
 'L_excess':s.simplify(L-U-b/n)
}
assert all(v==0 for v in identities.values())
# All transverse signs paired with their negatives, equal weights within each branch.
# At equal masses r^n=1/2, hence 2*r^(n-1)=1/r.
out=[]
for nn in [2,1,3,4,8,16,64,256]:
 rr=(-arb(2).log()/nn).exp();bb=(1+rr)/2;uu=2-bb;ll=2-(nn-1)*bb/nn
 none=(1-rr)/2;both=rr/2
 assert none>0 and both>0
 axis=rr*(1/rr-1)+(1-rr)*(-1)
 charge=rr*(ll-arb(1)/(2*nn)-1/(2*nn*rr))+(1-rr)*ll
 assert axis.contains(0) and (charge-uu).contains(0)
 record=dict(n=nn,stage='initial' if nn==2 else 'degenerate_pressure' if nn==1 else 'expanded_dimension',r_interval=str(rr),U_interval=str(uu),L_interval=str(ll),weights=[str(none),str(none),str(both),str(both)],axis_residual=str(axis),charge_residual=str(charge-uu))
 # Full 3-box exact union formula along actual one-sided position perturbations.
 # Tangential containment checked with strict interval inequalities.
 tests=[]
 if nn<=8:
  for delta in [-1,1]:
   for power in [6,8,10]:
    t=arb(10)**(-power)
    assert t<(1-rr)/2 and bb+t<1 and bb-t>rr
    val=1+(1-bb-delta*t)*(1-t)**(nn-1)-(t/rr if delta<0 else 0)
    derivative=(-1-(nn-1)*(1-bb)) if delta>0 else (1-1/rr-(nn-1)*(1-bb))
    error=(val-uu)/t-derivative
    # Certify this error cap only at the listed finite parameters.
    assert abs(error)<2*nn*nn*t
    tests.append(dict(delta=delta,t=f'1e-{power}',difference_quotient=str((val-uu)/t),derivative=str(derivative),error=str(error),verified_error_bound=f'{2*nn*nn}*1e-{power}'))
 record['full_union_path_checks']=tests;out.append(record)
# A base zero-width joint box must not be discarded before taking branch gradients.
def one_dim_union(d):
    intervals=[(Fraction(-1,4),Fraction(1,4)),(d-Fraction(1,4),d+Fraction(1,4)),(d-Fraction(1,2),Fraction(1,2))]
    intervals=sorted((l,h) for l,h in intervals if l<h)
    total=Fraction(0); l,h=intervals[0]
    for a,b in intervals[1:]:
        if a>h:total+=h-l;l,h=a,b
        else:h=max(h,b)
    return total+h-l
zero_width=[]
assert one_dim_union(Fraction(1))==1
for den in [100,10000,1000000]:
    t=Fraction(1,den)
    right=(one_dim_union(1+t)-1)/t;left=(one_dim_union(1-t)-1)/t
    assert right==0 and left==1
    zero_width.append(dict(step=str(t),right_derivative=str(right),left_direction_derivative=str(left)))
result=dict(scope='Exact symbolic shared-weight identities plus strict interval calibration of true two-source full-union branches. Global extremality used only for n=2 from R538; no general upper bound.',executable=sys.executable,versions=dict(python=platform.python_version(),sympy=s.__version__,flint=flint.__version__),precision_bits=256,zero_width_branch_checks=zero_width,symbolic_assumption='n>=1 integer, r=2^(-1/n); identities substitute r^(n-1)=1/(2r)',identities={k:str(v) for k,v in identities.items()},results=out)
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2));print(json.dumps({'symbolic_identities':len(identities),'dimensions':len(out),'path_checks':sum(len(v['full_union_path_checks']) for v in out),'all_passed':True}))
