from fractions import Fraction as Q
from math import comb, log, sqrt, nextafter, inf
from flint import arb, fmpq, ctx
import argparse, json, sys, hashlib, platform, flint, time, resource
from pathlib import Path
p=argparse.ArgumentParser()
p.add_argument('--source-result',type=Path,default=Path(__file__).resolve().parent/'source_result.json')
p.add_argument('--output',type=Path,default=Path(__file__).resolve().parent/'interval.json')
a=p.parse_args()
wall=time.perf_counter(); cpu=time.process_time()
orig=a.source_result
def A(q): return arb(fmpq(q.numerator,q.denominator))
def ep(x):
 l=x.lower().man_exp(); u=x.upper().man_exp()
 return {'lower':[str(l[0]),int(l[1])], 'upper':[str(u[0]),int(u[1])], 'display':x.str(45)}
def frac_ep(pair): return Q(int(pair[0]))*Q(2)**int(pair[1])
def coeff(n,t):
 q=1+1/(2*t); h=(1+1/t)/2
 terms=[Q(comb(n-1,j))*q**(n-1-j)*Q(-1,2)**j*(1-t**(-j))/j for j in range(1,n)]
 return Q(n)-Q(n,2)*q**(n-1), 1-h**n-Q(n,2)*sum(terms,Q(0))
def calc(n,t,bits):
 ctx.prec=bits
 k,c=coeff(n,t); B=A(c)+A(k)*A(t).log(); assert B>0
 F=(A((1+1/t)**n).sqrt()+B.sqrt())**2
 return {'B':ep(B),'F':ep(F),'log_coefficient':str(k),'rational_constant':str(c)}
def overlap(x,y): return max(frac_ep(x['lower']),frac_ep(y['lower']))<=min(frac_ep(x['upper']),frac_ep(y['upper']))
def floatcalc(n,t):
 k,c=coeff(n,t); b=float(c)+float(k)*log(float(t)); return b,(sqrt(float((1+1/t)**n))+sqrt(b))**2
old=json.loads(orig.read_text()); cases=[(7,Q(3391749,524288)),(7,Q(6))]+[(n,Q(n)) for n in (2,4,8,16,32)]
rows=[]
for n,t in cases:
 x=calc(n,t,256); y=calc(n,t,512); fb,ff=floatcalc(n,t)
 row={'n':n,'t':str(t),'precision_256':x,'precision_512':y,'overlap_256_512':{v:overlap(x[v],y[v]) for v in ('B','F')},'float':{'B_hex':fb.hex(),'F_hex':ff.hex()}}
 for name,z in [('B',fb),('F',ff)]:
  iv=y[name]; d=Q.from_float(z); lo=frac_ep(iv['lower']); hi=frac_ep(iv['upper']); row['float'][name+'_absolute_error_upper']=nextafter(float(max(abs(d-lo),abs(d-hi))),inf)
 if n==7:
  iv=old['candidate_interval'] if t!=6 else old['R027_winner_interval']; row['original_F_overlap']=overlap(y['F'],iv); row['original_F_contains_512']=frac_ep(iv['lower'])<=frac_ep(y['F']['lower']) and frac_ep(y['F']['upper'])<=frac_ep(iv['upper'])
 rows.append(row)
assert all(all(r['overlap_256_512'].values()) for r in rows)
assert all(r['original_F_contains_512'] for r in rows[:2])
assert frac_ep(rows[0]['precision_512']['F']['upper']) < frac_ep(rows[1]['precision_512']['F']['lower'])
out={'python':sys.version,'sys_executable':sys.executable,'flint':flint.__version__,'platform':platform.platform(),'command_argv':[sys.executable]+sys.argv,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'original_result_sha256':hashlib.sha256(orig.read_bytes()).hexdigest(),'wall_seconds':time.perf_counter()-wall,'cpu_seconds':time.process_time()-cpu,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'rows':rows,'scope':'Scalar certificates only. Implication for C7 depends on separately reviewed and accepted theory; finite numerical cases do not prove a general claim.'}
a.output.write_text(json.dumps(out,indent=2)+'\n')
