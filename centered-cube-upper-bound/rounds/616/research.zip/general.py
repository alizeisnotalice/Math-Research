import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS'):
 os.environ[k]='1'
import sys, platform, time, math, json, resource, argparse, pathlib, shlex
import numpy as np, scipy
from scipy.integrate import quad
from scipy.optimize import minimize_scalar

parser=argparse.ArgumentParser()
parser.add_argument('--output-dir', default=str(pathlib.Path(__file__).resolve().parent))
args=parser.parse_args()
output_dir=pathlib.Path(args.output_dir)
output_dir.mkdir(parents=True,exist_ok=True)
NS=[7,16,32,64,128,256,512,1024,4096]
calls={'integr_u':0,'integr_w':0}
start=time.time()
def integr_u(n,x):
 calls['integr_u']+=1
 e=math.exp(-x)
 f=lambda u: math.exp((n-1)*math.log1p((e-math.exp(-u))/2))
 return quad(f,0,x,epsabs=2e-12,epsrel=2e-12,limit=300)[0]
def integr_w(n,x):
 calls['integr_w']+=1
 q=(n-1)/2; a=q*math.exp(-x); top=q*(-math.expm1(-x))
 def f(w):
  return math.exp((n-1)*math.log1p(-w/(n-1)))/(w+a)
 return quad(f,0,top,epsabs=2e-12,epsrel=2e-12,limit=300,points=[a] if a<top else None)[0]
def vals(n,x,method=integr_u):
 J=method(n,x); lhalf=math.log1p(math.exp(-x))-math.log(2)
 D=-math.expm1(n*lhalf)
 B=D+n*x-n*J/2
 B0=D+n*x/2
 logA=n*math.log1p(math.exp(-x))
 if B<=0: return None
 logF=2*np.logaddexp(logA/2,math.log(B)/2)
 return float(logF),B,B0,J,logA

def objective(n,x):
 v=vals(n,x)
 return v[0] if v else float('inf')
results=[]
for n in NS:
 before=calls.copy(); optimizer_nfev=[]
 hi=max(20.,2*math.log(n)); lo=1e-7
 grid=np.linspace(lo,hi,201); z=[objective(n,float(x)) for x in grid]
 inds=[i for i in range(1,len(grid)-1) if z[i]<=z[i-1] and z[i]<=z[i+1]]
 candidates=[(z[0],lo),(z[-1],hi)]
 for i in inds:
  r=minimize_scalar(lambda x:objective(n,x),bounds=(float(grid[i-1]),float(grid[i+1])),method='bounded',options={'xatol':1e-13,'maxiter':500})
  optimizer_nfev.append(int(r.nfev))
  candidates.append((float(r.fun),float(r.x)))
 lf,x=min(candidates); v=vals(n,x); v2=vals(n,x,integr_w); _,B,B0,J,logA=v
 F=math.exp(lf); F0=(math.exp(logA/2)+math.sqrt(B0))**2
 row={'n':n,'search_x_bounds':[lo,hi],'grid_points':len(grid),'grid_basin_count':len(inds),'x':x,'t':math.exp(x),'F':F,'F_over_sqrt_n':F/math.sqrt(n),'F_over_n_log_n':F/(n*math.log(n)),'t_log_n_over_n':math.exp(x)*math.log(n)/n,'B':B,'B0_lower_baseline':B0,'B_increase_over_B0':B-B0,'F_increase_over_F0':F-F0,'B_minus_n_logt_over_2':B-n*x/2,'integral_u':J,'integral_w':v2[3],'integral_abs_difference':abs(J-v2[3]),'relative_B_difference':abs(B-v2[1])/B,'F0':F0,'optimizer':'grid plus bounded local minimization, log F'}
 if n==7:
  i=min(range(len(z)),key=z.__getitem__)
  row['three_stage_n7']={'coarse_grid_x':float(grid[i]),'coarse_grid_F':math.exp(z[i]),'bounded_x':x,'bounded_F':F,'fine_grid_step':1e-5,'fine_grid_best_x':None,'fine_grid_best_F':None}
  fine=[x+k*1e-5 for k in range(-100,101)]; j=min(range(len(fine)),key=lambda k:objective(n,fine[k])); row['three_stage_n7']['fine_grid_best_x']=fine[j]; row['three_stage_n7']['fine_grid_best_F']=math.exp(objective(n,fine[j]))
 row['optimizer_nfev_per_basin']=optimizer_nfev
 row['integral_calls']={k:calls[k]-before[k] for k in calls}
 row['B_lower']=row.pop('B0_lower_baseline')
 row['B_minus_B_lower']=row.pop('B_increase_over_B0')
 row['F_increase_over_F_lower']=row.pop('F_increase_over_F0')
 row['F_lower']=row.pop('F0')
 row['B_old']=1+n*x
 row['B_old_minus_B_cap']=row['B_old']-B
 row['B_cap_over_B_old']=B/row['B_old']
 row['cap_saving_fraction']=row['B_old_minus_B_cap']/row['B_old']
 results.append(row)
 print(json.dumps(row,ensure_ascii=False),flush=True)
usage=resource.getrusage(resource.RUSAGE_SELF)
out={'date':'2026-10-28 Asia/Shanghai','command':shlex.join([sys.executable]+sys.argv),'thread_environment':{k:os.environ.get(k) for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS')},'python':sys.version,'numpy':np.__version__,'scipy':scipy.__version__,'platform':platform.platform(),'elapsed_seconds':time.time()-start,'peak_rss_bytes_macos':usage.ru_maxrss,'definitions':{'B_old':'1+n*log(t), R025 original baseline','B_lower':'1-((1+1/t)/2)^n+(n/2)*log(t), lower baseline obtained by replacing integral by log(t)','cap_saving':'B_old-B_cap; ratio B_cap/B_old','scope':'numerical bounded searches only, no global optimality or proof claim'},'search_provenance':'201 grid points were chosen in this run; the instruction did not prescribe a grid size.','integral_calls':calls.copy(),'results':results}
with (output_dir/'ccu_seven_20261028_general.json').open('w') as f: json.dump(out,f,indent=2,ensure_ascii=False)
with (output_dir/'ccu_seven_20261028_general.md').open('w') as f:
 f.write('# Finite numerical search (not a certificate)\n\n`'+out['command']+'`\n\nPython '+out['python']+'; NumPy '+out['numpy']+'; SciPy '+out['scipy']+'; '+out['platform']+'\n\nElapsed %.3f s; peak RSS %.3f MiB.\n\n'%(out['elapsed_seconds'],usage.ru_maxrss/2**20))
 f.write('R025 original baseline B_old = 1+n log t. Cap saving is B_old−B_cap and relative saving is (B_old−B_cap)/B_old. The separate lower baseline B_lower = 1−((1+1/t)/2)^n+(n/2)log t arises by replacing the integral by log t; B_cap−B_lower is included in JSON.\n\n')
 f.write('| n | t | F | F/sqrt(n) | F/(n log n) | t log(n)/n | B_cap | B_old | B_old−B_cap | B_cap/B_old | optimizer nfev | u calls | w calls |\n|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|\n')
 for r in results:
  f.write('| %d | %.10g | %.10g | %.10g | %.10g | %.10g | %.10g | %.10g | %.10g | %.10g | %s | %d | %d |\n'%(r['n'],r['t'],r['F'],r['F_over_sqrt_n'],r['F_over_n_log_n'],r['t_log_n_over_n'],r['B'],r['B_old'],r['B_old_minus_B_cap'],r['B_cap_over_B_old'],str(r['optimizer_nfev_per_basin']),r['integral_calls']['integr_u'],r['integral_calls']['integr_w']))
 f.write('\nEach row searched x=log t in [1e-7, max(20, 2 log n)] using a 201-point grid newly chosen for this run (the instruction did not freeze the point count), followed by bounded minimization of each detected grid basin; endpoints were included. Two quadratures were compared at the candidates; max absolute difference %.3g. Floating-point results are not rigorous bounds, and grid search can miss basins.\n\n'%max(r['integral_abs_difference'] for r in results))
 f.write('Actual calls in this run: '+json.dumps(calls)+'; these counts do not describe the original run. Optimizer nfev is recorded separately for every detected basin.\n\n')
 f.write('Seven-dimensional three stages: '+json.dumps(results[0]['three_stage_n7'])+'\n')
