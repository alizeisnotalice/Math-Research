# R616 最终必要核验

日期：2026-10-28。审查仅涉及有理证书、修正 selection 的真实保存账及 bridge 公式；没有重复标量渐近审查，没有修改作者脚本，没有新做参数搜索。全部执行使用 `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python`。

## 1. 结论

目前核验范围内未发现决定性数学错误。严格有理标量证书通过；修正后的严格开边界 selection 保存账通过 36 个既有案例、180 条诊断行的独立定向重放；bridge 的 (M1)–(M4) 在所写同一次 finite selection 合同下成立。

尚未证明一般维的 `sqrt(n) polylog(n)` 目标，也未把 R027 的 selection 联合付款连接成 R520 原来源/全费用下的目标吸收。有限诊断只检查 (M1) 与 (M3) 的几何外放松之前的账，不验证 `H_T` 的数值或维数收益。

主报告、12个真实 profile-cap 案例、可移植运行数据与一个固定实例的严格矩形证书现均已完成必要核验，见第5–7节。未重跑大规模采样。

## 2. 有理证书：通过范围

审查文件：`/tmp/ccu_seven_20261028_rational.py`。独立执行输出：`/tmp/ccu_r616_audit_rational.json`，严格检查 PASS。

* 设 `z=(t−1)/(t+1)`。对 0<z<1，`log t=2 sum_(j≥0) z^(2j+1)/(2j+1)`。截断前 count 项是下界；剩余分母均≥2count+1，故代码的 `2 z^(2count+1)/[(2count+1)(1−z²)]` 是合法上尾界。不存在遗漏首项或指数偏一。
* 二项式积分中 `j≥1` 项为 `(1−t^(−j))/j`；常数部分及 log 系数 `n−(n/2)(1+1/(2t))^(n−1)` 均正确。log 系数为负时交换上下端点，代码方向正确；两条实际七维记录的系数均正，通用负系数分支的正确性由这一显式单调性检查确认。
* sqrt 端点仅用 Fraction 与 `isqrt`。`floor(sqrt(floor(x)))=floor(sqrt(x))` 保证左端不超过真实平方根；右端再加 1 保证严格大于真实平方根。代码还精确断言平方端点关系。正端点相加再平方保持区间方向。
* 两个已证明的严格数值上界分别是：
  `F_7(3391749/524288)<24.554960525965`；
  `F_7(6)<24.576989510218`。
  代码还严格证明第一点的整个 F 区间低于第二点区间。近似显示值分别为 `24.5549605259647` 与 `24.576989510217157`；这些显示值不是证书依据。
* 这证明两个选定参数的严格标量上界以及两者的严格比较，不证明全局最优参数或最优常数。结合已认证的 R027 几何定理才能转为算子上界。

## 3. 严格开边界 selection：通过范围

当前脚本：`/tmp/ccu_seven_20261028_selection.py`。

**本次核验的正确保存账**：`/tmp/ccu_seven_20261028_replay_selection/ccu_seven_20261028_selection.json`。其保存脚本 SHA256 与当前脚本完全一致。根 `/tmp/ccu_seven_20261028_selection.json` 是保留的旧闭边界账，指纹不同，本审查不将其归属当前版本，也不建议归档旧账充作严格开边界结果。

独立定向重放的是已有 36 个案例，不是新参数实验。核验结果 PASS：

* 案例集合准确覆盖 n∈{2,3}、τ∈{1/4,1}、N∈{256,1024,4096}、base∈{1000,2000,3000}，seed=base+n；36/36 complete，共180条 m∈{1,2,4,8,16} 诊断。重建全部候选流并核对 candidate 哈希、全部 greedy 接受/拒绝决策、selected 哈希与每个保存增量的网格格数。
* 所有候选 x=0 均在其 a-star 内。quarter-grid 中，`cells/4^n` 是实际小立方体增量体积，星体积为 `(2aR/4)^n`，故 `w=cells/(16R)^n` 的归一化正确。半开格仅用于计算体积，边界为 Lebesgue 零集。
* 实际中心捕获是严格 `3|y_k−y_j|<32R_j` 的逐坐标条件，与 b=32/3 的开星体一致。这里不能用中心落在边界是“零测”来改成 ≤，因为中心来自离散候选。保存账中共 68083 个“正增量已选 cube 到后来候选”的边界 pair，故修正有实际意义；该计数包含后来拒绝的候选，不能读成已选 cube 对的数目。
* `den=lcm((16R)^n)`，每次增量整数权重≤den/8^n，任一 eligibility accumulator≤N den/8^n。代码在 Python 整数中检查 `N den<2^63 8^n`，因此 int64 加法不会溢出。当前 n=2/3、坐标/半径范围也使 int16 存储及 int32 距离运算安全；没有声称这些坐标类型对任意扩展参数自动安全。
* 使用保存的真实 selected records 独立重算所有180行 Fraction 权重、prefix 捕获次数、所有 witness 的此前负载、`O_P,R_P,tail,O_all,R_all`、两个 slack 及单 witness 同 prefix residual，全部与 JSON 一致；所有 witness 负载≤τ，(M1) 与 pre-geometry (M3) 全部通过。

确切限制：这些诊断没有积分 `H_T`，没有验证 (M3) 几何包络紧度，没有 n=7 或一般 n 的源测度结论，也没有证明 source-coupled Target。N 嵌套的是原候选流；按半径重排并重新 selection 后，已选集合不必嵌套。

## 4. Bridge：定义、几何与原输入连接

审查 `/tmp/ccu_seven_20261028_bridge_sol.md`，并对照指定 R027 `sources/author.md` 和 `/tmp/ccu_r604_original_contract.md`。

* (M1) 正确：对同一次 selection 的 (S) 乘 λ_k≥0 后相加，再限制到 S_x，得到 `sum_j w_j c_j≤τΛ`。逐项恒等式 `1+(c−1)_+=c+(1−c)_+` 给出所写方向。自项与晚于 witness 的项确实留在 residual 中，未被免费支付。
* (M2) 是实际不交 increments 的精确积分恒等式，系数 `(2a)^(−n)` 正确。Λ=1 时 c_j≤1、O_T=0，residual 只是单 witness residual 的凸平均；该分支不能凭空产生交集收益。
* (M3) 正确：prefix 的 index 早于全部 witnesses，故 `r_j/r0≥s`；未被任何 witness 捕获的 prefix 项，由最小半径 witness 推出 `r_j<t r0`。实际增量点满足 `||z||∞<r_j/r0` 与每个 `||u_k−z||∞>c r_j/r0`，从而进入所写共同 cap 域，且权重由 `m_s(z)^(−n)` 控制。Jacobian 恰产生 `P=((a+1)/a)^n`。若 s≥t，prefix 未捕获残差为空，令 H_T=0 合法。
* (M3) 保留 `mτ、W_tail、O_P`，并能退回 R027 的最后最小半径 witness；不同半径 witnesses 的中心盒不能继续套同一 `[-α,α]^n`，稿件已明确此限制。
* (M4) 由 R027 的同一次 selection cover 与坏星平均条件推出，方向正确。作 source 积分时应选择可测的非空 T(x)（在 W(x)>0 时）；W=0 处可将整条括号定义为0，避免空集 min/max 的无定义。这是表述补全，不改变现有 finite-family 证明。
* R604 原合同中的真实 dB、原 t_B、phase/质量窗与 `G²J` 及 low/rapid/top 费用均没有被 (M1)–(M4) 自动支付。稿件第5节正确承认这一点。R027 的 τ 与实际 I_j 不能分别冒充 R520 的旧 score 信用与 v(B,g)。

仍未证的准确目标是：对同一 f、同一次合法 selection/source，选择 witnesses 并证明 `(1+A_a/τ)∫|f|[mτ+W_tail+PH_T−O_P]≤C sqrt(n) polylog(n)||f||_1`，或者建立可回代原 R520 全母账的等价吸收式。单独 cap 交集缩小、有限样本的 U_m 改善或 scalar 七维改进均不足以替代该目标。

## 5. 主报告与实际 cap 采样补审

已读 `/tmp/ccu_r616_final/REPORT.tex` 当前理论及实验说明，以及 `/tmp/ccu_r616_actual_caps_run.py`、其真正输出 `/tmp/ccu_r616_actual_caps_results.json`。没有重跑大规模 Sobol 计算。

**当前主报告通过范围。** finite selection、cover、源积分到一般 L1/全尺度的转移、单 witness 面积分、scalar 极限、全参数族渐近与多 witness 完整账均与此前审查吻合。报告中的 `ell_a=alpha ell_t` 为准确恒等式，故有限 a 比较方向正确。报告明确目标尚未闭合，未将标量族下界误写为 C_n 下界，未将 R027 τ 识别为旧能量信用。W=0 处几何括号定义0的表述补全由父任务安排加入。

**采样换元通过。** 对固定 s<t，内区 `||z||∞<s` 的归一化质量为 `2^(−n)s^(−n)(2s)^n=1`，均匀点 `z=s(2U−1)` 正确。壳区均匀选择 2n 个面、其余 n−1 坐标均匀，半径按 logρ 在 [log s,log t] 均匀，径向归一化质量为 `n dρ/ρ`，故权 `n log(t/s)` 正确。代码的面指标、坐标覆盖、半径、内外排除条件均实现这一公式。不同积分部分及 m 使用共同点不影响积分正确性，且有利于 paired 比较。s≥t 时 H_T=0 与理论一致。

**实际 witness 归一化通过。** reverse 后的前 m 个 witnesses 恰为原正贡献序列的最后 m 个。最后正贡献项半径是这些 witnesses 共同的最小 r0；quarter 坐标和 quarter 半径同时约去，所以 `u=y_integer/(9 r0_integer)` 准确。`s=max(r_k/r0)` 随 m 单独计算，未强行采用共同中心角盒。`c=29/27`、`P=(9/8)^n` 正确。每个 m 的 tail 与 O_P 直接读取并匹配已核验 replay 账，预算正是 `U_m=mτ+tail+P H_T−O_P`。

**来源及保存账通过。** 12 个 N=4096 既有案例完整覆盖 n=2/3、τ=1/4或1、各三 seed；12/12 complete。输出保存的输入 SHA256 与 replay JSON 匹配，脚本 SHA256 与当前脚本匹配，selected SHA 与对应原案例匹配，最后16个实际 witnesses 与 r0 全部逐项匹配。分别对 2^16 与 2^20 两阶段、共120条已保存行，根据 accepted counts 独立重算 H、U、相对单 witness 差、两 scramble 均值及 SE，全部通过。没有重抽样或重新积分。

**数值解释边界。** 两 scramble 下均值标准误的公式 `|delta_1−delta_2|/2` 算术正确，但仅有2次重复，不能充作严格置信区间、误差上界或几何证书。浮点 s、log及边界比较也没有 interval 验证。特别是零接受计数不能单独推出 H_T=0。

当前 2^20 保存数据中，11/12 案例存在至少一种 m>1 的负均值差，9/12 案例的 m=8 差为负。因此若后文选择一个案例给严格证书，应写“选定一例严格认证”，不能写“只有一例数值改善”。这组点态比较不验证 source 积分、统一策略或一般维指数。

`actual_caps_results.tex` 及选定案例证书的最终版本核验见第6–7节。

## 6. 选定有限实例的严格矩形证书补审

已审 `/tmp/ccu_r616_joint_cert.py/json/md` 当前实现。它选择 n=3、N=4096、seed=1003、τ=1/4 的同一已重放 selection，取最后8个正贡献 witnesses；不是声称只有这一例存在数值改善。

矩形证书的数学实现通过：`r0=6` 的 quarter 单位给 `u=y/54`，以108为共同分母，witness坐标为2y、网格每边1/4对应整数长度27，覆盖 `[-3,3]^3` 的24³个盒。`s1=1` 与 `s8=4/3` 对应108与144。

在每盒上，`mn=max(s108,各坐标最小绝对值)` 与 `mx=max(s108,各坐标最大绝对值)` 分别是108m_s的准确最小/最大值。若每个 witness 均有某坐标的最小盒距离≥(29/27)mx，则全盒处于共同未捕获域，用最大m的负三次方提供合法下界；若存在一个 witness 的各坐标最大盒距离均严格小于(29/27)mn，则全盒被捕获，可从上界排除。其余盒全部计入上界，以最小m的负三次方控制。单盒归一化质量因子为 `(1/4)^3/2^3=1/512`，因此代码的 `108^3/(512*mx^3)` 与 `108^3/(512*mn^3)` 正确。边界多重归属仅影响零体积集。

费用从同一 selected_records 的严格捕获重新算出，分别为 `tail1=1/18432,O1=0,tail8=26623/9437184,O8=682739/524288`；这与原120条保存行相应费用一致。source/ref与脚本hash当前匹配。精确有理端点直接比较确认：

* `U1≥340981909603127/97917861888000>3.48`；
* `U8≤645721362374309/783342895104000<0.825`；
* `U8−U1≤−2082133914450707/783342895104000<−2.65`。

这是严格的一个有限实际 selection 包络改善，已不依赖 Sobol 误差或未审核的 selection 生成。它既不证明这些 U 是实际负载的最优界，也不建立源积分或一般维目标。最终添加命令行路径与 s/r0 断言的版本及主报告插入段落也已通过，见第7节。


## 7. 最终可移植版本与主报告插入段落：通过

最终采样代码 `/tmp/ccu_r616_actual_caps_portable.py` 与回放输出 `/tmp/ccu_r616_actual_caps_replay/ccu_r616_actual_caps_results.json` 的脚本 SHA256 匹配；保存输入 SHA256 与同一已核验 replay selection 匹配。逐案例对照原数值输出，12个案例的状态、身份、selected指纹、r0、全部 witnesses、两阶段全部计数与数学输出完全一致。可移植改动只有命令行输入/输出、workers及性能记录等接口，没有改变数学采样。保存的回放墙钟1.55655秒、worker CPU合计10.752458秒、worker峰值内存之和1.25372 GiB，与报告近似显示一致；内存之和不是同时峰值，报告已明确。

最终严格证书代码 `/tmp/ccu_r616_joint_cert_portable.py` 及 `/tmp/ccu_r616_joint_cert_replay.json` 的代码指纹匹配。新断言明确核对 r0=6 为两组最小半径、s1=1、s8=4/3；这些值正是整数矩形缩放所需。其 witnesses、全部有理几何端点与费用和原证书完全一致，三条严格小数结论再次由 Fraction 精确比较通过。

证书最终命令的 reference 仍指向原 `/tmp/ccu_r616_actual_caps_results.json`，保存 reference_sha256 与它匹配。它没有指向可移植回放输出；两者所有数学内容已经逐案例核对完全一致。因此此 reference 来源差别不产生数学缺口，也不需要重跑大计算。归档时应保留来源哈希/实际命令的这一事实，不将 reference 哈希改写成另一个文件的指纹。

最终 `/tmp/ccu_r616_final/REPORT.tex` 与 `actual_caps_results.tex` 的新增文字准确写明11/12例存在采样改善、9/12例U8改善，并把严格证书描述为“选定一例”，没有混淆。内cube/shell权重、s/r0、实际尾与信用、两scramble的非严格误差性质、精确证书的矩形上下界、费用与三个最终严格结论均与已核材料一致。W=0处完整括号定义0及W>0处非空可测 witness选择也已补全。

**最终通过范围：** 两个严格七维标量证书；修正selection的36个真实案例与180行精确账；12个实际profile的采样数学、保存计数与完整费用比较；一个已核合法selection上的严格多witness包络改善；以及对此范围准确的主报告表述。

**仍未证目标：** 一般n的统一 witness策略、source-integrated付款、n^(1/2+o(1))上界，以及回代原R520全母账的严格吸收。固定实例的正向结果没有关闭这些缺口。此次审查没有新增参数搜索或维数实验，没有修改作者脚本。

## 8. 最终归档来源核对（取代第7节暂存 reference 路径说明）

只读核验 `/tmp/ccu_r616_final/` 的最终归档成员，未重新运行计算。`joint_cert.py` 与已审 portable 证书原字节一致，`actual_caps.py` 与已审 portable 采样脚本原字节一致。最终 `joint_cert.json` 保存的 source/reference/code SHA256 分别准确绑定该目录的 `selection.json`、`actual_caps.json`、`joint_cert.py`；最终 `actual_caps.json` 的输入/代码指纹也分别准确绑定 `selection.json`、`actual_caps.py`。

最终证书实际命令为归档目录内 `joint_cert.py --input selection.json --reference actual_caps.json --output joint_cert.json`（JSON保存绝对路径）。因此最终 reference 现已绑定归档的 portable actual 结果，不再采用第7节所记暂存的原数值文件引用。全部 H1/H8 区间、U1/U8及其差的有理端点、尾与重叠费用、witnesses及其index与已审证书一致；三条严格小数结论仍全部通过准确 Fraction 比较。

已读新增 `REPRODUCE.md`。其一般证明、待付款联合账、有限严格证书与浮点探索的分级正确；reference只核见证/费用而不以浮点H作严格证明、旧闭边界账排除、partial/超时解释、采样SE非严格、原corner扫描的旧代码指纹与可移植入口区别、一般根阶目标尚未闭合等边界均准确。没有发现需要阻止归档的来源或证据范围错误。本次未重审理论、未扫描、未重跑数值。
