# R616 复现与证据分级

目标仍是任意正 L1、真实勒贝格接收测度、全部尺度的一般根阶弱型上界；未闭合。REPORT.tex 与 actual_caps_results.tex 是完整本轮报告，不编译 PDF。

本轮结果分为：

1. 一般证明：七维项目的 cube-cap 机制迁移到所有 n；该完整单见证界族最优表达式为 n log n − n log log n + O(n log log n/log n)。这不是实际 C_n 的下界。
2. 一般但尚未付款的联合账：同一次实际 selection 上保留多见证捕获、重复信用、尾项与覆盖系数。完整来源加权积分仍未证根阶预算。
3. 有限严格证书：两个七维标量值；36 个真实有限 selection 的精确账；一个实际三维 selection 的 U8<U1 几何包络改进（全费用保留）。均不自动外推维数阶。
4. 浮点探索：广维数标量扫描、非实际 corner cap 诊断、12 个实际 profile 的联合几何采样。误差字段不构成严格置信区间。

## 解释器与执行

已实用解释器：
`/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python`

保存结果记录 Python 3.12.14、NumPy 2.5.4、SciPy 1.18.1、python-flint 0.9.0；每份记录为相应实际命令/平台/版本，而非环境文件替代新计算验证。报告中的本机硬件15逻辑CPU、24GiB由系统实查；不声称始终满载。MATLAB尝试没有返回数学结果，不计入证据。

在解压目录执行（可自行将 python 换为上述解释器）：

```sh
python verify.py
python rational.py --output /tmp/r616-rational-replay.json
python interval.py --source-result source_result.json --output /tmp/r616-interval-replay.json
python joint_cert.py --input selection.json --reference actual_caps.json --output /tmp/r616-joint-replay.json
python selection.py --output-dir /tmp/r616-selection-replay
python actual_caps.py --input selection.json --output-dir /tmp/r616-actual-replay --workers 12
python general.py --output-dir /tmp/r616-general-replay
```

前三个数值入口分别为纯有理标量证书、Arb 标量交叉核验、固定实例纯有理矩形包络。joint_cert 的主证书只需要 selection 记录；reference 仅核对见证列表与精确费用，不以其中浮点 H 值建立界。

selection.py 重建36个候选流并按严格开边界重新选取；输出名为 ccu_seven_20261028_selection.json。默认110秒保护可能在较慢电脑产生 partial，必须检查全部36 complete，不把 partial 当完成。独审已独立重放候选接受拒绝、每个实际增量格数及180行账目。

actual_caps.py 使用12个独立profile/至多12进程，各BLAS1线程；--workers可降低并发。单任务保护150秒，future收集超时175秒不是进程强杀截止，进程池清理仍会等待任务结束。输入SHA绑定修复后的 selection.json；实际12个case两阶段120行均已完成。2^16是2^20的前缀，两个scramble的配对经验SE不具有严格覆盖保证。保存的结果来自可移植入口的一次重放，与原计算逐项计数一致；无必要保存两份相同数学结果。总CPU10.75秒、墙时1.56秒是该次运行记录，不表示后续一直运行。

## 非实际 corner 多 cap 诊断

multicap.json 与 multicap.md 是原实际扫描记录，绑定 multicap_original.py 的字节哈希。multicap.py 是只增加路径参数及只读核验的入口，未重跑全扫描，不能将旧记录伪归属新版哈希。保留原码是为了该证据来源能核验，不是额外探索分支。

```sh
python multicap.py --verify-saved multicap.json
python multicap.py --output-dir /tmp/r616-corner-replay
```

只读核验不重新计算积分；复现扫描将产生新运行收据。原报告 screen_note 的筛选用浮点值，只作诊断，不升级为严格区间证书。这些角点可能不能由实际 selection 同时实现，原 tail/信用未测量，不能代替 actual_caps 的账目。

## 修复及归档

旧闭边界 selection 记录已在本机保留，未装入最终包。boundary_comparison.json 记录同输入修复后的变化：6个选中族变化、16个诊断case变化，边界计数定义含后来拒绝的候选。新的 selection.json 哈希与正确源码一致。源项目未更改；SOURCES.json 中 local commit 和 adopted R025 描述只代表读取时本地快照，不能据此断言另一个项目的当前 GitHub 状态。

AUDIT.md 为独立关键审查；SCALAR_AUDIT.md 保留解析部分，删除无独立复现入口的附加浮点表。最终报告自足，不额外打包重复作者长稿、阶段草稿或PDF。MANIFEST.json绑定所有最终成员。verify.py检查归档指纹及有限证据间的对应关系，不替代报告的几何证明或一般上界。
