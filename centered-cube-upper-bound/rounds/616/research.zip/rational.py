"""Independent rational log/square-root certificates; no Arb dependency."""
from fractions import Fraction as Q
from math import comb, isqrt
from pathlib import Path
import argparse, hashlib, json, platform, sys, time

def log_bounds(t, count=256):
    z = (t-1)/(t+1)
    assert 0 < z < 1
    lo = 2*sum((z**(2*j+1)/Q(2*j+1) for j in range(count)), Q(0))
    # Every denominator in the positive remaining series is >= 2*count+1.
    err = 2*z**(2*count+1)/(Q(2*count+1)*(1-z*z))
    return lo, lo+err

def sqrt_bounds(lo, hi, digits=55):
    assert 0 < lo <= hi
    scale = 10**digits
    left = isqrt(lo.numerator*scale**2//lo.denominator)
    right = isqrt(hi.numerator*scale**2//hi.denominator)+1
    out = Q(left,scale), Q(right,scale)
    assert out[0]**2 <= lo and hi < out[1]**2
    return out

def calculate(n,t):
    q=1+1/(2*t)
    ell=(1+1/t)/2
    # Integrate the binomial polynomial in 1/rho, retaining the sign of log.
    const=1-ell**n
    for j in range(1,n):
        const-=Q(n,2)*comb(n-1,j)*q**(n-1-j)*Q(-1,2)**j*(1-t**(-j))/j
    coefficient=Q(n)-Q(n,2)*q**(n-1)
    ll,lu=log_bounds(t)
    bl,bu=(const+coefficient*ll,const+coefficient*lu) if coefficient>=0 else (const+coefficient*lu,const+coefficient*ll)
    al,au=sqrt_bounds((1+1/t)**n,(1+1/t)**n)
    sl,su=sqrt_bounds(bl,bu)
    fl,fu=(al+sl)**2,(au+su)**2
    return {'n':n,'t':str(t),'log_coefficient':str(coefficient),
            'log_interval':[str(ll),str(lu)], 'B_interval':[str(bl),str(bu)],
            'F_interval':[str(fl),str(fu)],'display_float':float((fl+fu)/2)}

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'))
    args=p.parse_args(); wall=time.perf_counter(); cpu=time.process_time()
    rows=[calculate(7,Q(3391749,524288)),calculate(7,Q(6))]
    assert Q(rows[0]['F_interval'][1])<Q(24554960525965,10**12)
    assert Q(rows[1]['F_interval'][1])<Q(24576989510218,10**12)
    assert Q(rows[0]['F_interval'][1])<Q(rows[1]['F_interval'][0])
    out={'python':sys.version,'platform':platform.platform(),
         'command':[sys.executable,*sys.argv],'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
         'log_terms':256,'sqrt_decimal_digits':55,'rows':rows,
         'wall_seconds':time.perf_counter()-wall,'cpu_seconds':time.process_time()-cpu,
         'scope':'Strict rational scalar enclosures only; no optimizer or operator claim without the geometric theorem.'}
    args.output.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({'strict_checks':'PASS','F_display':[r['display_float'] for r in rows],
                      'wall_seconds':out['wall_seconds']},indent=2))
