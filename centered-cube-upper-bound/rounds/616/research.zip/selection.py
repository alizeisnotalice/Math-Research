import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS'): os.environ[k]='1'
import numpy as np
from fractions import Fraction as Q
from math import lcm
import hashlib,json,time,sys,platform,random,argparse,shlex
from pathlib import Path
start=time.monotonic(); deadline=start+110
parser=argparse.ArgumentParser(); parser.add_argument('--output-dir',default=str(Path(__file__).resolve().parent)); args=parser.parse_args()
outdir=Path(args.output_dir); outdir.mkdir(parents=True,exist_ok=True)
outpath=outdir/'ccu_seven_20261028_selection.json'; mdpath=outdir/'ccu_seven_20261028_selection.md'
def jsq(q): return [q.numerator,q.denominator]
def captured(center,other,R): return all(3*abs(int(a)-int(b)) < 32*R for a,b in zip(center,other))
def sample(n,N,seed):
 rng=random.Random(seed); seen=set(); seq=[]
 # Draw one underlying uniform stream for nested N cases.
 while len(seq)<N:
  R=rng.choice((8,6,4)); lim=8*R-2
  y=tuple(rng.randint(-lim,lim) for _ in range(n)); z=(R,)+y
  if z not in seen: seen.add(z); seq.append(z)
 return sorted(enumerate(seq),key=lambda p:(-p[1][0],p[0]))
def run(n,tau,N,seed):
 seq=sample(n,N,seed); centers=np.array([z[1][1:] for z in seq],dtype=np.int16); radii=np.array([z[1][0] for z in seq],dtype=np.int16)
 # Half-open cell grid [k/4,(k+1)/4), coverage equivalent up to cube boundaries.
 offset=70; cover=np.zeros((140,)*n,dtype=np.bool_)
 den=lcm(*[(16*R)**n for R in (8,6,4)]); loads=np.zeros(N,dtype=np.int64)
 assert N*den < 2**63 * 8**n, 'eligibility accumulator may overflow'
 assert np.all(centers-radii[:,None]+offset>=0) and np.all(centers+radii[:,None]+offset<=140), 'cell grid too small'
 selected=[]; pos=[]; timer=time.monotonic(); boundary_pairs=0
 for i in range(N):
  if time.monotonic()>deadline: return {'n':n,'tau':jsq(tau),'N':N,'seed':seed,'status':'time_limit_partial','processed':i,'selected_count':len(selected)}
  if int(loads[i])*tau.denominator > tau.numerator*den: continue
  R=int(radii[i]); y=centers[i]; slices=tuple(slice(int(c)-R+offset,int(c)+R+offset) for c in y)
  block=cover[slices]; cells=block.size-int(np.count_nonzero(block)); block[...] = True
  wnum=cells*(den//((16*R)**n))
  selected.append([R,*[int(v) for v in y],cells]); pos.append(i)
  if wnum and i+1<N:
   distance=3*np.abs(centers[i+1:].astype(np.int32)-y.astype(np.int32))
   boundary_pairs+=int(np.count_nonzero(np.all(distance <= 32*R,axis=1) & np.any(distance == 32*R,axis=1)))
   mask=np.all(distance < 32*R,axis=1)
   loads[i+1:]+=mask*wnum
 positives=[z for z in selected if z[-1]>0]
 weights=[Q(z[-1],(16*z[0])**n) for z in positives]; W=sum(weights,Q(0)); diag=[]
 for m in (1,2,4,8,16):
  if len(positives)<m: continue
  split=len(positives)-m; witnesses=positives[split:]
  cs=[sum(captured(w[1:-1],z[1:-1],z[0]) for w in witnesses) for z in positives[:split]]
  op=sum((w*max(c-1,0) for w,c in zip(weights[:split],cs)),Q(0))
  rp=sum((w*(c==0) for w,c in zip(weights[:split],cs)),Q(0)); tail=sum(weights[split:],Q(0))
  last=witnesses[-1]; single=sum((w*(not captured(last[1:-1],z[1:-1],z[0])) for z,w in zip(positives[:split],weights[:split])),Q(0))
  csall=[sum(captured(w[1:-1],z[1:-1],z[0]) for w in witnesses if positives.index(w)>j) for j,z in enumerate(positives)]
  ot=sum((w*max(c-1,0) for w,c in zip(weights,csall)),Q(0)); rt=sum((w*max(1-c,0) for w,c in zip(weights,csall)),Q(0))
  witness_loads=[]
  for j in range(split,len(positives)):
   y=positives[j][1:-1]; witness_loads.append(sum((w for z,w in zip(positives[:j],weights[:j]) if captured(y,z[1:-1],z[0])),Q(0)))
  assert all(x<=tau for x in witness_loads)
  assert W+op<=m*tau+tail+rp
  assert W+ot<=m*tau+rt
  assert rp<=single
  diag.append({'m':m,'W':jsq(W),'tail':jsq(tail),'c_j_prefix':cs,'O_P':jsq(op),'R_P':jsq(rp),'m_tau':jsq(m*tau),'prefix_single_last_witness_uncaptured':jsq(single),'witness_prior_loads':list(map(jsq,witness_loads)),'M3_pre_geometry_slack':jsq(m*tau+tail+rp-W-op),'M1_slack':jsq(m*tau+rt-W-ot),'O_all':jsq(ot),'R_all':jsq(rt)})
 return {'n':n,'tau':jsq(tau),'N':N,'seed':seed,'status':'complete','elapsed_seconds':time.monotonic()-timer,'selected_count':len(selected),'positive_count':len(positives),'selected_records':selected,'candidate_sha256':hashlib.sha256(json.dumps(seq,separators=(',',':')).encode()).hexdigest(),'selected_sha256':hashlib.sha256(json.dumps(selected,separators=(',',':')).encode()).hexdigest(),'w_denominator_lcm':den,'overflow_bound_numerator':N*den,'overflow_bound_denominator':8**n,'boundary_pairs_selected_positive_to_later_candidates':boundary_pairs,'diagnostics':diag}
results=[]; plans=[(n,Q(tau),N,base+n) for base in (1000,2000,3000) for N in (256,1024,4096) for n in (2,3) for tau in (Q(1,4),Q(1))]
meta={'description':'finite cell-occupancy selection at x=0; no C_n bound','command':shlex.join([sys.executable]+sys.argv),'python':sys.version,'numpy':np.__version__,'platform':platform.platform(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'seed_rule':'base+n, base in 1000,2000,3000; identical nested input for each tau','candidate_order':'distinct stream sampled uniformly by radius then center; stable radius descending','grid':'quarter-grid cells, radii in quarter units, star condition norm(y)_infty < a*r - 1/4','capture':'open bB: 3*abs(center difference)<32*R in every coordinate','boundary_pairs_definition':'pairs of a positive selected cube and a later candidate (including later rejected candidates) on that cube open-star boundary','parameters':{'a':8,'t':3,'b':[32,3]},'results':results}
def save():
 meta['elapsed_seconds']=time.monotonic()-start
 outpath.write_text(json.dumps(meta,separators=(',',':')))
 lines=['# Finite selection and multi-witness diagnostic','',f"Command `{meta['command']}`; source SHA256 `{meta['script_sha256']}`. Python {sys.version}; NumPy {np.__version__}. Elapsed {meta['elapsed_seconds']:.3f} s.",'','x=0; a=8, t=3, b=32/3; quarter-grid centers and radii; radii are processed descending. Candidate stream is distinct, seeded, and nested across N for fixed n. Weights, eligibility, and all reported witness quantities are exact rational arithmetic. Small-cube volume ignores cell boundaries; eligibility and witness capture use the strict open-star condition, since candidate centers can lie on a boundary. The previous closed-boundary run is a different finite contract. This is a finite point-load diagnostic, not a bound on C_n or a source-measure estimate.','','| n | τ | N | seed | status | selected | positive | m | W | tail | O_P | R_P | single prefix residual | mτ |','|---:|---:|---:|---:|:---|---:|---:|---:|---:|---:|---:|---:|---:|---:|']
 def fmt(v): return f'{v[0]}/{v[1]} ({v[0]/v[1]:.6g})'
 for r in results:
  for d in r.get('diagnostics',[]): lines.append('| %s | %s | %s | %s | %s | %s | %s | %s | %s | %s | %s | %s | %s | %s |'%(r['n'],fmt(r['tau']),r['N'],r['seed'],r['status'],r['selected_count'],r['positive_count'],d['m'],fmt(d['W']),fmt(d['tail']),fmt(d['O_P']),fmt(d['R_P']),fmt(d['prefix_single_last_witness_uncaptured']),fmt(d['m_tau'])))
  if r['status']!='complete': lines.append(f"\nIncomplete: {r}")
 lines += ['','Exact prefix capture multiplicities, witness loads, boundary-hit pair counts, overflow checks, selected cube coordinates and increment cell counts, and checksums are in the JSON. M1 and the pre-geometry M3 inequalities were checked exactly in every reported row. Single-witness residual uses the same prefix and the last witness.','',f"Completed {sum(r['status']=='complete' for r in results)} cases in total; current invocation planned {len(plans)} new cases. Single-process execution; BLAS thread environment set to 1."]
 mdpath.write_text('\n'.join(lines)+'\n')
for n,tau,N,seed in plans:
 if time.monotonic()>deadline: break
 r=run(n,tau,N,seed); results.append(r); save(); print('done',n,str(tau),N,r['status'],r['selected_count'],flush=True)
 if r['status']!='complete': break
save()
