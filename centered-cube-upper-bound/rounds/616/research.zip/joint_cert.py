import json, hashlib, sys, time, platform, resource, argparse
from pathlib import Path
from fractions import Fraction as Q
from itertools import product
start=time.perf_counter(); cpu=time.process_time()
p=argparse.ArgumentParser()
p.add_argument('--input',type=Path,default=Path(__file__).resolve().parent/'selection.json')
p.add_argument('--reference',type=Path,default=Path(__file__).resolve().parent/'actual_caps.json')
p.add_argument('--output',type=Path,default=Path(__file__).resolve().parent/'joint_cert.json')
args=p.parse_args()
src=args.input; ref=args.reference
d=json.loads(src.read_text()); matches=[r for r in d['results'] if r['n']==3 and r['N']==4096 and r['seed']==1003 and r['tau']==[1,4]]; assert len(matches)==1
rec=matches[0]['selected_records']; pos=[(i,x) for i,x in enumerate(rec) if x[-1]>0]; witnesses=pos[-8:][::-1]; assert len(witnesses)==8 and all(max(abs(v) for v in x[1:4])<8*x[0] for _,x in pos)
refcase=[r for r in json.loads(ref.read_text())['results'] if r['n']==3 and r['N']==4096 and r['seed']==1003 and r['tau']==[1,4]]; assert len(refcase)==1 and [x for _,x in pos[-16:][::-1]]==refcase[0]['witnesses_last_first']
def weight(x): return Q(x[4],(16*x[0])**3)
def cost(m):
 ks=witnesses[:m]; k0=min(i for i,_ in ks); tail=sum((weight(x) for i,x in pos if i>=k0),Q()); overlap=Q()
 for i,x in pos:
  if i>=k0: continue
  q=sum(all(3*abs(x[d]-w[d])<32*x[0] for d in range(1,4)) for j,w in ks if j>i)
  overlap+=weight(x)*max(0,q-1)
 return tail,overlap
T1,O1=cost(1); T8,O8=cost(8)
for m,T,O in [(1,T1,O1),(8,T8,O8)]:
 row=next(x for x in refcase[0]['stages']['20']['rows'] if x['m']==m); assert Q(*row['tail_exact'])==T and Q(*row['O_P_exact'])==O
r0=witnesses[0][1][0]; assert r0==6
assert r0 == min(w[0] for _,w in witnesses[:1])
assert r0 == min(w[0] for _,w in witnesses[:8])
assert Q(max(w[0] for _,w in witnesses[:1]),r0)==1
assert Q(max(w[0] for _,w in witnesses[:8]),r0)==Q(4,3)
# Common denominator 108: witness coordinates y/(9*r0), cell endpoints grid i/4.
points=[[2*v for v in w[1:4]] for _,w in witnesses]; c=Q(29,27)
def bounds(m,s108):
 lower=Q(); upper=Q(); nlo=nhi=0
 for inds in product(range(-12,12),repeat=3):
  lo=[27*i for i in inds]; hi=[x+27 for x in lo]
  minabs=[0 if l<=0<=h else min(abs(l),abs(h)) for l,h in zip(lo,hi)]
  maxabs=[max(abs(l),abs(h)) for l,h in zip(lo,hi)]
  mn=max(s108,*minabs); mx=max(s108,*maxabs)
  # A whole cell is uncaptured if each witness has some coordinate with min distance >= c*max radial scale.
  guaranteed=all(any(27*(0 if l<=u<=h else min(abs(u-l),abs(u-h)))>=29*mx for l,h,u in zip(lo,hi,p)) for p in points[:m])
  # A whole cell is captured if one witness has every coordinate strictly within c*min radial scale.
  captured=any(all(27*max(abs(u-l),abs(u-h))<29*mn for l,h,u in zip(lo,hi,p)) for p in points[:m])
  if guaranteed: lower+=Q(108**3,512*mx**3); nlo+=1
  if not captured: upper+=Q(108**3,512*mn**3); nhi+=1
 return lower,upper,nlo,nhi
L1,V1,n1,_=bounds(1,108); L8,V8,_,n8=bounds(8,144)
P=Q(9,8)**3; delta_upper=7*Q(1,4)+T8-T1-O8+O1+P*(V8-L1)
assert delta_upper<0
fmt=lambda x:[str(x.numerator),str(x.denominator)]
hashfile=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
out={'n':3,'N':4096,'seed':1003,'tau':'1/4','selected_count':len(rec),'positive_count':len(pos),'witnesses_last_first':[x for _,x in witnesses],'witness_indices':[i for i,_ in witnesses],'s1':'1','s8':'4/3','c':'29/27','P':'729/512','grid_step':'1/4','grid_cells':24**3,'H1_lower':fmt(L1),'H1_upper':fmt(V1),'H8_lower':fmt(L8),'H8_upper':fmt(V8),'U1_lower':fmt(Q(1,4)+T1-O1+P*L1),'U8_upper':fmt(2+T8-O8+P*V8),'U8_minus_U1_upper':fmt(delta_upper),'tail1':fmt(T1),'tail8':fmt(T8),'overlap1':fmt(O1),'overlap8':fmt(O8),'H1_guaranteed_cells':n1,'H8_not_wholly_captured_cells':n8,'source_sha256':hashfile(src),'reference_sha256':hashfile(ref),'script_sha256':hashfile(Path(__file__)),'command_argv':[sys.executable]+sys.argv,'python':sys.version,'platform':platform.platform(),'wall_seconds':time.perf_counter()-start,'cpu_seconds':time.process_time()-cpu,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'scope':'fixed scalar geometric case only, conditional on the specified selection input, no C_n conclusion'}
args.output.write_text(json.dumps(out,indent=2)+'\n')
for k in ('H1_lower','H1_upper','H8_lower','H8_upper','U1_lower','U8_upper','U8_minus_U1_upper'): print(k,float(Q(*map(int,out[k]))))
print('costs',T1,T8,O1,O8,'seconds',out['wall_seconds'])
