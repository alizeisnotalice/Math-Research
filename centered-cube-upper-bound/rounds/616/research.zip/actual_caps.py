import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS'): os.environ[k]='1'
import concurrent.futures, time, json, sys, platform, hashlib, math, shlex, resource, argparse
from fractions import Fraction
from pathlib import Path
import numpy as np, scipy
from scipy.stats import qmc

PARSER=argparse.ArgumentParser()
PARSER.add_argument('--input',type=Path,default=Path(__file__).resolve().parent/'selection.json')
PARSER.add_argument('--output-dir',type=Path,default=Path(__file__).resolve().parent)
PARSER.add_argument('--workers',type=int,default=12)
STAGES=(16,20); BATCH=2**14; MS=(1,2,4,8,16); A=8; T=3.; C=29./27.; P=lambda n:(9/8)**n

def task(r):
 start=time.monotonic(); cpu_start=time.process_time(); n=r['n']; positive=[x for x in r['selected_records'] if x[-1]>0]; assert len(positive)>=16
 witnesses=positive[-16:][::-1]; r0=witnesses[0][0]; assert all(w[0]>=r0 for w in witnesses)
 u=np.array([np.array(w[1:-1],dtype=float)/(9*r0) for w in witnesses]); radii=[w[0]/r0 for w in witnesses]
 ss={m:max(radii[:m]) for m in MS}; groups={s:[m for m in MS if ss[m]==s] for s in set(ss.values())}
 totals={e:{m:[] for m in MS} for e in STAGES}
 for scramble in range(2):
  # Independent scrambles; common points across every m and both integration pieces.
  rng=qmc.Sobol(d=n+2,scramble=True,seed=100000+100*r['seed']+10*n+scramble)
  counts={s:np.zeros((2,5),dtype=np.int64) for s in groups}
  for step in range(2**20//BATCH):
   if time.monotonic()-start>150: return {'status':'partial_timeout','n':n,'seed':r['seed'],'tau':r['tau'],'completed_blocks':step,'scramble':scramble}
   sample=rng.random(BATCH); face=np.minimum((sample[:,0]*(2*n)).astype(int),2*n-1); dim=face//2; sign=np.where(face%2,1.,-1.)
   for s,mset in groups.items():
    if s>=T: continue
    zi=s*(2*sample[:,2:2+n]-1); rr=s*np.exp(math.log(T/s)*sample[:,1]); zo=rr[:,None]*(2*sample[:,2:2+n]-1); zo[np.arange(BATCH),dim]=sign*rr
    im=np.ones(BATCH,dtype=bool); om=np.ones(BATCH,dtype=bool)
    for j in range(max(mset)):
     im &= np.max(np.abs(zi-u[j]),axis=1)>=C*s
     om &= np.max(np.abs(zo-u[j]),axis=1)>=C*rr
     m=j+1
     if m in mset:
      ix=MS.index(m); counts[s][0,ix]+=np.count_nonzero(im); counts[s][1,ix]+=np.count_nonzero(om)
   if (step+1)*BATCH in (2**16,2**20):
    exp=int(math.log2((step+1)*BATCH)); size=2**exp
    for m in MS:
     s=ss[m]; vals=counts[s][:,MS.index(m)]
     h=0. if s>=T else (int(vals[0])+n*math.log(T/s)*int(vals[1]))/size
     totals[exp][m].append({'H':h,'inner_accepted':int(vals[0]),'shell_accepted':int(vals[1])})
 diag={d['m']:d for d in r['diagnostics']}; rat=lambda v:float(Fraction(*v)); tau=rat(r['tau']); result={}
 for exp in STAGES:
  u1=[tau+rat(diag[1]['tail'])+P(n)*v['H'] for v in totals[exp][1]]; rows=[]
  for m in MS:
   d=diag[m]; h=totals[exp][m]; ums=[m*tau+rat(d['tail'])+P(n)*v['H']-rat(d['O_P']) for v in h]; dif=[ums[i]-u1[i] for i in range(2)]
   rows.append({'m':m,'s':ss[m],'tail_exact':d['tail'],'O_P_exact':d['O_P'],'H_replicates':h,'U_replicates':ums,'delta_to_single_replicates':dif,'delta_mean':sum(dif)/2,'delta_se_two_scrambles':abs(dif[0]-dif[1])/2,'H_mean':sum(v['H'] for v in h)/2})
  result[str(exp)]={'sample_size_per_scramble':2**exp,'single_U_replicates':u1,'rows':rows}
 return {'status':'complete','n':n,'N':r['N'],'seed':r['seed'],'tau':r['tau'],'selected_sha256':r['selected_sha256'],'r0_quarter_units':r0,'witnesses_last_first':witnesses,'elapsed_seconds':time.monotonic()-start,'worker_cpu_seconds':time.process_time()-cpu_start,'peak_rss_bytes_macos':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'stages':result}

def main():
 args=PARSER.parse_args(); assert 1<=args.workers<=12, 'workers must be between 1 and 12'
 INPUT=args.input; args.output_dir.mkdir(parents=True,exist_ok=True)
 OUT=args.output_dir/'ccu_r616_actual_caps_results.json'; REPORT=args.output_dir/'ccu_r616_actual_caps_report.md'
 inp=json.loads(INPUT.read_text()); profiles=[r for r in inp['results'] if r['N']==4096 and r['status']=='complete']; assert len(profiles)==12
 out={'input_file':str(INPUT),'input_sha256':hashlib.sha256(INPUT.read_bytes()).hexdigest(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'command':shlex.join([sys.executable]+sys.argv),'python':sys.version,'numpy':np.__version__,'scipy':scipy.__version__,'platform':platform.platform(),'workers':args.workers,'blas_threads':1,'batch':BATCH,'scrambles':2,'sampling':'inner weight 1; shell weight n log(t/s); two independent scrambled Sobol sequences, common points across m; 2^16 prefix of 2^20','error':'paired scramble standard error abs(delta_1-delta_2)/2; n=2 replicates only, heuristic not rigorous','results':[]}
 started=time.monotonic()
 def save():
  out['elapsed_seconds']=time.monotonic()-started; out['sum_worker_cpu_seconds']=sum(r.get('worker_cpu_seconds',0) for r in out['results']); OUT.write_text(json.dumps(out,indent=2))
  lines=['# Actual multi-witness geometric cap comparison','',f"Input SHA256 `{out['input_sha256']}`; script SHA256 `{out['script_sha256']}`.",'',f"Command `{out['command']}`; Python {sys.version}; NumPy {np.__version__}; SciPy {scipy.__version__}; workers {out['workers']}, BLAS threads 1; elapsed {out['elapsed_seconds']:.2f} s.",'','Each row reports the paired two-scramble estimate U_m−U_1, for 2^20 Sobol samples per scramble; negative values favor m witnesses. U uses the true actual tail and overlap credit plus the sampled geometric envelope; all selections and weights were already fixed. The standard error uses only two scrambles and is not a rigorous confidence interval or certificate. 2^16 and acceptance counts are preserved in JSON.','','| n | tau | seed | m | s | H | U_m−U_1 | paired SE |','|---:|---:|---:|---:|---:|---:|---:|---:|']
  for r in sorted(out['results'],key=lambda x:(x['n'],x['seed'],x['tau'])):
   if r['status']!='complete': lines.append(f"\nPartial: {r}");continue
   for d in r['stages']['20']['rows']:
    lines.append('| %d | %s/%s | %d | %d | %.5g | %.8g | %.8g | %.3g |'%(r['n'],*r['tau'],r['seed'],d['m'],d['s'],d['H_mean'],d['delta_mean'],d['delta_se_two_scrambles']))
  lines+=['', 'This is a finite set of pointwise numerical comparisons. It does not establish a bound for C_n, a source-weighted estimate, or a universal witness policy.']
  REPORT.write_text('\n'.join(lines)+'\n')
 with concurrent.futures.ProcessPoolExecutor(max_workers=args.workers) as pool:
  futures=[pool.submit(task,r) for r in profiles]
  for fut in concurrent.futures.as_completed(futures,timeout=175):
   try: out['results'].append(fut.result())
   except Exception as e: out['results'].append({'status':'error','error':repr(e)})
   save();print('completed',len(out['results']),out['results'][-1]['status'],flush=True)
 save()
if __name__=='__main__':main()
