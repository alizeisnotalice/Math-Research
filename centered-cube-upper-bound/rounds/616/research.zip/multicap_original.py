import numpy as np, scipy, json, math, hashlib, sys, time, datetime
from scipy.stats import qmc
from scipy.integrate import quad
from scipy.linalg import hadamard
start=time.monotonic(); cpu=time.process_time(); utc=datetime.datetime.now(datetime.timezone.utc).isoformat()
a=24.;t=6.;c=27/25;alpha=24/25
H=hadamard(32)
def patterns(n):
 single=np.full((1,n),alpha); opposite=np.r_[single,-single]
 return {'single':single,'opposite':opposite,'hadamard4':np.unique(H[:4,:n],axis=0)*alpha,'hadamard8':np.unique(H[:8,:n],axis=0)*alpha}
def exact(n):
 ell=lambda r:(1+c-alpha/r)/2
 return 1-ell(1)**n+quad(lambda r:n*(1-ell(r)**(n-1)/2)/r,1,t,epsabs=1e-11)[0]
def run(n,seed,pow_):
 pats=patterns(n); blocks=16; bit=pow_-4; entries=[]
 for rep in range(blocks):
  s=qmc.Sobol(2*n+1,scramble=True,seed=seed+rep)
  sums=np.zeros(4); size=2**bit; chunk=min(2**14,size)
  for _ in range(size//chunk):
   x=s.random(chunk); ball=2*x[:,:n]-1; v=2*x[:,n:2*n]-1
   v/=np.max(np.abs(v),axis=1)[:,None]; rho=np.exp(math.log(t)*x[:,-1]); z=v*rho[:,None]
   for i,us in enumerate(pats.values()):
    ib=np.ones(chunk,dtype=bool); iz=np.ones(chunk,dtype=bool)
    for u in us:
     ib &= np.max(np.abs(ball-u),axis=1)>=c
     iz &= np.max(np.abs(z-u),axis=1)>=c*rho
    sums[i]+=ib.sum()+n*math.log(t)*iz.sum()
  entries.append(sums/size)
 arr=np.array(entries); dif=arr[:,0,None]-arr
 return {'N':2**pow_,'mean':dict(zip(pats,map(float,arr.mean(axis=0)))),'se':dict(zip(pats,map(float,arr.std(axis=0,ddof=1)/4))),'delta':dict(zip(pats,map(float,dif.mean(axis=0)))),'delta_se':dict(zip(pats,map(float,dif.std(axis=0,ddof=1)/4)))}
result={'parameters':{'a':a,'t':t,'alpha':alpha,'c':c},'utc_start':utc,'command':'/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_seven_20261028_multicap.py','python':sys.version,'numpy':np.__version__,'scipy':scipy.__version__,'sha256':hashlib.sha256(open(__file__,'rb').read()).hexdigest(),'seeds':[20261028,20261128],'method':'Uniform inner cube and log-radius shell, directions obtained by normalizing independent uniform cube points by max absolute coordinate; same samples used for all witness families. 16 independent scrambled Sobol blocks per seed; SE is between-block sample standard deviation divided by 4.','rows':[]}
for n in [3,7,16,32]:
 pats=patterns(n); A=(1+1/t+1/a)**n; P=(25/24)**n; hs=exact(n); E=a**(-n)+P*hs; tau=math.sqrt(A*E)
 row={'n':n,'m':{key:len(p) for key,p in pats.items()},'patterns':{key:p.tolist() for key,p in pats.items()},'A':A,'P':P,'H_single_face':hs,'E':E,'tau':tau,'runs':{}}
 for power in (16,20):
  for seed in (20261028,20261128): row['runs'][f'{power}_{seed}']=run(n,seed,power)
 result['rows'].append(row)
result['elapsed_s']=time.monotonic()-start; result['cpu_s']=time.process_time()-cpu; result['utc_end']=datetime.datetime.now(datetime.timezone.utc).isoformat()
with open('/tmp/ccu_seven_20261028_multicap.json','w') as f:json.dump(result,f,indent=2)
with open('/tmp/ccu_seven_20261028_multicap.md','w') as f:
 f.write('# 多 cap 数值诊断\n\n')
 f.write(f"运行 UTC {utc} 至 {result['utc_end']}；Python {sys.version.split()[0]}，NumPy {np.__version__}，SciPy {scipy.__version__}；CPU {result['cpu_s']:.1f} 秒，耗时 {result['elapsed_s']:.1f} 秒。脚本 SHA-256 `{result['sha256']}`。命令 `{result['command']}`。\n\n")
 f.write('采用 Sylvester 32 阶 Hadamard 矩阵前 4/8 行、前 n 列，去重；每组同时包括全正角点。两种子各使用 16 个独立随机扰动 Sobol 子块，每个 n 先做 2^16 再做 2^20；表中为 2^20 结果，误差是子块经验标准误，非严格界。单/多 witness 使用相同点，直接估计差。内立方体均匀抽样；壳使用对数均匀半径、均匀立方体点除以其最大绝对值得到的壳方向。积分测度对应原始定义，不应用多 cap 面公式。\n\n')
 f.write('τ = √(A E)，A=(1+1/t+1/a)^n，P=(25/24)^n，E=a^(-n)+P H_single；单 cap 角点 H 另用一维公式计算。比较需要 P(H_single−H_T)，而不只是 H 的差。\n\n')
 f.write('| n | 家族 | m | H单−H多，种子1 ± SE | 种子2 ± SE | P × 减少量，种子1 | 新增 (m−1)τ |\n|---:|---|---:|---:|---:|---:|---:|\n')
 for row in result['rows']:
  r1=row['runs']['20_20261028'];r2=row['runs']['20_20261128']
  for key in ('opposite','hadamard4','hadamard8'):
   f.write(f"| {row['n']} | {key} | {row['m'][key]} | {r1['delta'][key]:.6g} ± {r1['delta_se'][key]:.2g} | {r2['delta'][key]:.6g} ± {r2['delta_se'][key]:.2g} | {row['P']*r1['delta'][key]:.6g} | {(row['m'][key]-1)*row['tau']:.6g} |\n")
 f.write('\n这些几何量不能单独证明支付：原账还包含新增的 (m−1)τ、实际 tail 以及重复捕获信用 O_P。它们都依赖同一次实际 selection，未在此计算。角点作为闭包几何测试也不证明对应的多个 witnesses 必然可由实际 selection 实现。所有数值均为诊断，不是严格数值证书或一般维数结论。\n')
print('elapsed',result['elapsed_s'],'cpu',result['cpu_s'])
