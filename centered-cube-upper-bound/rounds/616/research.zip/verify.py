"""Archive/source consistency and exact saved-certificate checks; not a general theorem prover."""
from pathlib import Path
from fractions import Fraction as Q
import hashlib,json,math
D=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda name:json.loads((D/name).read_text())
manifest=read('MANIFEST.json')
assert set(manifest)=={p.name for p in D.iterdir() if p.is_file() and p.name!='MANIFEST.json'}
for name,m in manifest.items():
 assert sha(D/name)==m['sha256'] and (D/name).stat().st_size==m['bytes'],name
for name,code in [('selection.json','selection.py'),('rational.json','rational.py'),('interval.json','interval.py'),('actual_caps.json','actual_caps.py'),('joint_cert.json','joint_cert.py')]:
 assert read(name)['script_sha256']==sha(D/code),name
assert read('multicap.json')['sha256']==sha(D/'multicap_original.py')
assert read('interval.json')['original_result_sha256']==sha(D/'source_result.json')
s=read('selection.json'); assert len(s['results'])==36
assert all(r['status']=='complete' for r in s['results'])
assert sum(len(r['diagnostics']) for r in s['results'])==180
assert sum(r['boundary_pairs_selected_positive_to_later_candidates'] for r in s['results'])==68083
for r in s['results']:
 for d in r['diagnostics']:
  assert Q(*d['W'])+Q(*d['O_P'])<=Q(*d['m_tau'])+Q(*d['tail'])+Q(*d['R_P'])
  assert Q(*d['M1_slack'])>=0
ac=read('actual_caps.json'); assert ac['input_sha256']==sha(D/'selection.json')
assert len(ac['results'])==12 and all(r['status']=='complete' for r in ac['results'])
records={(r['n'],r['seed'],tuple(r['tau'])):r for r in s['results'] if r['N']==4096}
for r in ac['results']:
 original=records[(r['n'],r['seed'],tuple(r['tau']))]
 assert r['selected_sha256']==original['selected_sha256']
 diag={d['m']:d for d in original['diagnostics']}
 for exp,stage in r['stages'].items():
  assert int(exp) in (16,20) and stage['sample_size_per_scramble']==2**int(exp)
  for row in stage['rows']:
   m=row['m']; assert row['tail_exact']==diag[m]['tail'] and row['O_P_exact']==diag[m]['O_P']
   for i,rep in enumerate(row['H_replicates']):
    H=0. if row['s']>=3 else (rep['inner_accepted']+r['n']*math.log(3/row['s'])*rep['shell_accepted'])/(2**int(exp))
    assert math.isclose(H,rep['H'],rel_tol=1e-13,abs_tol=1e-13)
    U=m*float(Q(*r['tau']))+float(Q(*row['tail_exact']))+(9/8)**r['n']*H-float(Q(*row['O_P_exact']))
    assert math.isclose(U,row['U_replicates'][i],rel_tol=1e-13,abs_tol=1e-13)
assert sum(any(d['m']>1 and d['delta_mean']<0 for d in r['stages']['20']['rows']) for r in ac['results'])==11
jc=read('joint_cert.json'); assert jc['source_sha256']==sha(D/'selection.json') and jc['reference_sha256']==sha(D/'actual_caps.json')
q=lambda k:Q(*map(int,jc[k]))
assert q('U1_lower')>Q(348,100) and q('U8_upper')<Q(825,1000) and q('U8_minus_U1_upper')<Q(-265,100)
ra=read('rational.json')['rows']
assert Q(ra[0]['F_interval'][1])<Q(24554960525965,10**12)
assert Q(ra[1]['F_interval'][1])<Q(24576989510218,10**12)
assert Q(ra[0]['F_interval'][1])<Q(ra[1]['F_interval'][0])
print('PASS: archive hashes, 36/180 exact ledgers, 12 actual profiles, and saved strict rational endpoints. No general root-order claim.')
