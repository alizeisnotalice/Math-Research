# R616 多 cap 脚本与来源

旧结果的实际运行命令：

```sh
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_seven_20261028_multicap.py
```

旧代码 SHA-256：`37b45fa6239341c1ef3f7162913d249fd5edece700006454c2a16b53d1f0b360`。旧 JSON 中记录的哈希与此一致；结果和报告对应旧代码，生成于 2026-10-27 16:54:47–16:54:52 UTC。旧报告和 JSON 随后附加了几何上限筛选说明；原采样结果未被更改。

新代码 SHA-256：`ae328ac661bf56cec3a6641d394bd7c74633c4d9c78ad92c351c1152453fe604`。新脚本的计算、参数、维数、两阶段、种子和算法沿用旧脚本；变化为可配置输出路径、真实记录新运行命令，以及新增只读验证入口。**新代码没有重放扫描**；不能把旧结果声称为新代码实际产生。

路径修改的核心差异（生成新文件名以避免覆盖原结果）：

```diff
- open('/tmp/ccu_seven_20261028_multicap.json','w')
+ open(args.output_dir / 'ccu_r616_multicap.json','w')
- open('/tmp/ccu_seven_20261028_multicap.md','w')
+ open(args.output_dir / 'ccu_r616_multicap.md','w')
```

命令记录改为 `shlex.join([sys.executable, *sys.argv])`；新增命令行解析与只读验证块。默认输出到脚本所在目录；可通过 `--output-dir` 指定其他目录。

本次实际执行了以下只读检查，未重新计算：

```sh
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r616_multicap_portable.py --verify-saved /tmp/ccu_seven_20261028_multicap.json
```

检查通过：4 个维数、各 4 个命名家族，2 个采样阶段采用同一对种子；每阶段的样本数与家族字段完整。检查还读取同名 Markdown，确认其明确声明 tail 和重复捕获信用未测量。验证不复算积分、不核验随机样本逐点结果，也不构成严格数值证书。样本误差仅为经验诊断。
