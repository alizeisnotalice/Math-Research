# R666: exact positive endpoint pressure plus a paid correction

Goal pure general C_n<=K sqrt(n), arbitrary L1, all centered common-radius scales, fixed Lebesgue. Not proved. R665 was pushed as 04abcfb674db52aab8378ec91f1067e786f42b2c; R666 commit hash belongs to Git, not this precommit record.

Actual new theorem: change only auxiliary centers to independent Unif(B_i), keeping true Fi, q, history, first-k, original L_h, all masks. Then E|S'(1)| = P_box + C_box with 0<=C_box<=16U/31. P_box takes positive part at each conditional coordinate slice BEFORE integration and expectation; cannot replace it by a global positive part. All n coordinates and inverse widths a/(2si) remain.

The correction is paid by simultaneous inner/outer thresholds forcing vr(v)<=w_i. Eligibility expands, so r(v) nondecreasing and integral r(v)1_{vr(v)<=w_i} dv<=w_i. Two receiver bands and all n directions give 16n/a c0^(n-1) U<=16U/31. Thick inner-parent correction cancels the signed endpoint term; do not reintroduce a linear fee by separating them. Full account uses B'_n<11 plus this correction, without another Delta. If P_box<=AU were proved uniformly, recovery gives (1+e^(1/16))[16384(23+32/31+2A)+2e^(33/32)]sqrt(n). This premise is OPEN.

A2_BOX_JITTER has self-contained actual conditional pressure, nonnegative decomposition and proof. S1 independently audits formulas, geometry, coefficients and final report. A1_TRUE_FLUX is a bounded unsuccessful complementary attempt: true-owner Palm cancellation alone does not permit using fixed-target iid concentration after selecting the largest visible target. Do not rerun it as a new insight. MAIN_SLICE was a precursor, superseded by the main report/A2; no need to archive the draft.

Next attack must pay P_box itself using full actual geometric dependence, or prove a real summable recurrence with all endpoints paid. Merely changing law, restating Palm, deleting selection, bounding entire parent shells, or adding more low-dimensional tests is not an improvement. Uniform B is an auxiliary law; it does not inherit disjoint Fi capacity.

Actual computations: 32 Boolean scalar identities and 5 Fraction coefficient points in MAIN_EXACT_CHECK.json; author MATLAB 30912 local slice cases, tolerance1e-10, zero failures, not actual high-T near inputs. MATLAB process13959 was closed and absence checked by author. No need to reopen just to inspect version. No PDF compilation. verify.py checks records, algebra, TeX and final audit hashes; it does not certify the remaining pressure. Missing exact MATLAB provenance must be honestly recorded, not guessed.

Configuration at most2Astra and5Sol; Terra/Luna only useful bounded tasks. Current A1/A2 author tasks delivered; audit finishing final hashes. Reuse context, do not count finished agents active. Temp files remain on data disk. Once round finalized, archive only final report, necessary author/audit/provenance and reproduction materials; independently commit/push following repo rules.
