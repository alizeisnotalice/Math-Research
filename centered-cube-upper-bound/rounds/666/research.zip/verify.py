"""Exact scalar checks and archive structure; does not prove the open pressure bound."""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
import ast, hashlib, json, re, sys
p=Path(__file__).resolve().parent
cases=0
for M,C,D,O,I in product((0,1),repeat=5):
    b=M*((1-C)*O-D*I); phi=M*(1-C)*O
    assert phi==max(b,0)+M*(1-C)*D*O*I
    cases+=1
rows=[]
for n in (1,2,16,256,1024):
    z=F(1,2)*F(32*n+1,32*n)**(n-1)
    assert z<F(16,31)
    rows.append({'n':n,'coefficient_float_display':float(z),'exact_fraction_bound_pass':True})
assert F(23)+F(32,31)==F(745,31)
old=json.loads((p/'MAIN_EXACT_CHECK.json').read_text())
assert old['boolean_cases']==cases and old['coefficient_checks']==rows
tex=(p/'REPORT.tex').read_text();stack=[]
assert all(ord(c)>=32 or c in '\n\r\t' for c in tex)
for m in re.finditer(r'\\(begin|end)\{([^}]+)\}',tex):
    kind,env=m.groups()
    if kind=='begin':stack.append(env)
    else:assert stack and stack.pop()==env
assert not stack
ast.parse((p/'verify.py').read_text())
audit=(p/'S1_LAW_AUDIT.md').read_text()
for name in ('REPORT.tex','A2_BOX_JITTER.md'):
    assert hashlib.sha256((p/name).read_bytes()).hexdigest() in audit, 'Missing final audit binding: '+name
manifest=p/'MANIFEST.json'; ms='not present; verify separately after packaging'
if manifest.exists():
    for name,v in json.loads(manifest.read_text())['members'].items():
        f=p/name; assert f.stat().st_size==v['bytes'] and hashlib.sha256(f.read_bytes()).hexdigest()==v['sha256']
    ms='PASS'
print(json.dumps({'status':'PASS','python':sys.version,'boolean_cases':cases,'fraction_points':5,'conditional_constant':'745/31+2A','audit_bindings':'PASS','tex_structure':'PASS; no PDF compiled','matlab_replayed_here':False,'manifest':ms,'global_pressure_bound':'UNPROVED'},indent=2))
