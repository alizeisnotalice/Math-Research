# R666 A1：真实 owner 随机化与完整暴露通量的停点

本文件只使用 TASK、R665 REPORT §§2–4 及 R662 的真实共点浓缩证明与共享 key 公式。结论：**没有证明完整实际暴露通量的绝对期望预算，也没有得到能改善完整预算的新上界。** 下面记录一个保留全部依赖的精确计算入口，并定位在它之后实际缺少的步骤。它不是条件归约意义上的研究闭环，也不是原问题的反例。

## 1. 决定性公式：singleton Palm 展开后，真实 owner 密度恰好消掉 q

固定所有实际构造数据，令 b=8，m=k。省略 q_i=0 的标签。对每个 i，保留其他标签的完整 [0,b] Poisson 历史及所有其他辅助中心；将 i 的历史设置为唯一事件 (i,t)，中心设置为 u∈F_i。重新按**原来的全部目标 I_h、原来的 first-k 规则、全部 L_h、共同历史、P′ 和未来重复剪枝 Q′_rep** 计算实际集合 S′_k(v)。

用

\[
 \Phi_i(t,u;\eta_{-i},u_{-i})
 =\sum_{\ell,\sigma}\int_0^1
   \int_{\Gamma^{\,i,t,u}_{i\ell\sigma}(v)}R_h\,
           d\mathcal H^{n-1}\,dv
 \tag{A1}
\]

表示其中由 i 支撑的完整实际暴露通量。没有把 Γ 换成未裁剪的整张面，没有先对目标求和，也没有去掉其他 key 遮挡。

R665 的实际通量恒等式与 N_i=1 的 Poisson 密度给出

\[
\boxed{
 \mathbb E|S'_k(1)|
 =\sum_i\frac{e^{-bq_i}}{d_i}
       \int_{F_i}\int_0^b
       \mathbb E_{-i}\Phi_i(t,u;\eta_{-i},u_{-i})\,dt\,du .
}
\tag{A2}
\]

证明只有两步。支撑源必为 singleton，所以只需 N_i=1 的项；其唯一事件落在 dt 的概率是 q_i e^{-bq_i}dt。再用真正的辅助中心密度 du/|F_i|，以及 |F_i|=q_i d_i，即得到 q_i/|F_i|=1/d_i。其他历史和中心独立于这一条件，故 E_-i 正确。所有积分非负，有限家族下 Tonelli 直接适用。

这是唯一在本路线中真正利用 Unif(F_i) 而完全消去小 owner 体积分母的公式。由 F_i 两两不交，也可把外部求和写成 u∈F:=∪F_i 上的单个积分，令 i=i(u)、s=s_i、q=q_i。**但 E_-i 的背景过程仍随 i(u) 改变，不能据此宣布获得了一个平移不变的共同空间过程。**

(A2) 中没有把“第 i 个源被选为支撑源”的概率与投影面积相乘；两者仍在 Φ_i 内。因而它保留了题目要求的代表选择偏差和并集重叠。时间 t 的积分也是对完整最终历史的非预测性积分，不是把未来剪枝改成了可预测补偿。

## 2. 一源、一法向、一横线给出的精确事件是什么

对几乎处处的 (v,y)，由 R665 的横线唯一面结论，定义

\[
 J_{i\ell\sigma}(v,y)=
 \begin{cases}
 R_h,&\text{该横线存在由 }(i,\ell,\sigma)\text{ 支撑的实际移动暴露面},\\
 0,&\text{没有这样的面}.
 \end{cases}
\]

同一面若有多个正内迹 piece，它们的 R_h 相等，因此 J 定义无歧义。于是

\[
 \Phi_i=\sum_{\ell,\sigma}\int_0^1\int_{\mathbb R^{n-1}}
 J_{i\ell\sigma}(v,y)\,dy\,dv,
 \qquad 0\le J_{i\ell\sigma}\le c_0s_i.                    \tag{A3}
\]

进一步可写成精确 layer-cake：

\[
 \mathbb E_{-i}\Phi_i
 =\sum_{\ell,\sigma}\int_0^1\int_{\mathbb R^{n-1}}
   \int_0^{c_0s_i}
   \Pr_{-i}\{J_{i\ell\sigma}(v,y)>r\}\,dr\,dy\,dv.       \tag{A4}
\]

这里的事件同时要求实际目标已完成、i 在其完整 first-k key 中且支撑该法向、横线通过扩张后的投影、原 L_h 允许该点、该面未被其他 key 隐藏、该点不在 P′∪Q′_rep。它是最终整个配置的事件。

R665 的最大投影包络 R* 可以给 J 上界，但以 R* 代 J 会移除上面最后几种信息。对 R* 再作 layer-cake，得到的是

\[
 \Pr\{\exists h:\ h\text{ 在该历史中合格},\ R_h>r,
        \ y\in\pi_\ell(K'_{h,k}+vR_hQ)\},                 \tag{A5}
\]

即一个目标事件的并集概率。横线唯一性说明实现后只剩一张实际面；它不把 (A5) 中“存在某个 h”的概率改成某个事先固定 h 的概率。

## 3. admission 没有丢，但尚未支付 (A4)

在 (A2) 每个允许的 u∈F_i 以及每个其他辅助中心的实现上，R665 的继承 admission 都保留：

\[
 \sum_{j<i}q_j\mathbf1_{Q(u_j,(1-1/a)s_j)}(u)\le1.        \tag{A6}
\]

因此这里没有先随机化后抛弃真实 admission 的问题。其控制对象是**源位置 u 上前序源的内缩立方体负荷**。需要支付的 (A4) 则在远离该源位置的移动面横截面上，并由最终 first-k 共同交及所有遮挡决定。现有材料没有给出将 (A6) 转成这些横截面概率之全局可积上界的传输、覆盖或联合偏差不等式。

需要全局论证；不是必须逐源证明 E_-i Φ_i≤C d_i。这种逐源条件估计更强，本文件既没有假设它必要，也没有把它列为已经接近完成的替代目标。

## 4. 共点浓缩插入的具体失败位置

R662 的浓缩估计适用于**事先固定的**实际共点源集 I_h，标签在 q_i/T_h 下无条件 iid 抽取；它给出原未加撇共同交的强指数体积收缩。它没有直接声明 primed 家族满足完全相同常数的定理。即便额外授予 primed 家族同样强的无条件局部估计，下面的全局问题仍存在。

在 (A4) 内，实际负责该横线的目标 h 由整个 key、中心 u、其他辅助中心及所有其他 keys 共同选择。条件于这个选择，标签 law 不是已证明定理中的无条件 iid law。若转用 R662 的代表公式，正是不能去掉的 H_h(v)ρ_h(v) 联合项；现在真实遮挡和支撑条件只会再增加选择条件。

因此以下两种操作均无证明：

\[
 \mathbb E[H_h\rho_h]
   \le(\mathbb EH_h)(\mathbb E\rho_h),\qquad
 \mathbb E\max_h Z_h\le\max_h\mathbb EZ_h.                \tag{A7}
\]

删去选择权重当然可以，但回到对 h 的求和后，R662 的来源量仍是反复使用的 U_h，未变成一次支付的 U。不能将固定 i、法向和横线的“只出现一张面”理解为“已经为随机胜出目标选到了一个无偏样本”。

这一失败不只是常数选择。简单概率诊断：令 J 均匀取 M 个值，Y_h=ρ_h=1_{J=h}。每个 E Y_h=1/M，而 E max_h Y_h=1；同时 E(Y_hρ_h)=1/M，比 E Y_h·Eρ_h 大 M 倍。这只是否定 (A7) 这类抽象交换的逻辑依据，**不是满足本题实际 admission/near 构造的反例，也不否定目标全局不等式。**

## 5. 丢掉真实 selector 后，完整预算确实回到指数费

这是已有壳层障碍在 (A2) 中的精确核对，不作为新进展计入。

每张 i 支撑面的半径 R_h≤c_0s_i，其 transverse projection 在
π_ℓ Q(u_i,c_0s_i(1+v)) 内。因此 (A3) 只用几何包络给出

\[
 \begin{aligned}
 \Phi_i
 &\le 2n\int_0^1 c_0s_i[2c_0s_i(1+v)]^{n-1}\,dv\\
 &=c_0^n(2^n-1)d_i.
 \end{aligned}                                                   \tag{A8}
\]

代入 (A2) 后仍是

\[
 \mathbb E|S'_k(1)|
 \le b c_0^n(2^n-1)\sum_i e^{-bq_i}|F_i|.                \tag{A9}
\]

保留一个实际 key 的所有 k 个事件，可以给更好的已知类型壳层证书：S′_k 中任何点的覆盖 key 没有任何全局重复标签，故至少属于 k 个不同 singleton 源的外壳 A′_i+c_0s_iQ\A′_i。于是

\[
 \mathbb E|S'_k(1)|
 \le\frac{b}{k}c_0^n(2^n-1)
          \sum_i e^{-bq_i}|F_i|
 \le\frac8k c_0^n(2^n-1)U.                              \tag{A10}
\]

(A10) 保留 shared history 和 future repeats 后仍是全局合法上界，但其量级就是任务明确排除的指数壳层费。它展示了：owner 密度消除、真实 singleton law、横线唯一性及简单 key 计数合并后，仍没有出现支付投影面积所缺的衰减。

## 6. 实际执行的轻量算术核验

使用已安装 Python 3.15.0、标准库 Fraction 做精确计算，无安装、无随机模拟、无重计算。以下代码运行在 stdin；仅本 Markdown 文件是本工作者写出的文件。

```python
from fractions import Fraction
from math import comb, isqrt
import sys
print('Python', sys.version.split()[0])
for n in range(1, 17):
    c = Fraction(32*n+1, 32*n)
    integral = sum(Fraction(comb(n-1,j),j+1) for j in range(n))
    coefficient = n*c**n*integral
    assert coefficient == c**n*(2**n-1)
print('Exact projection coefficient identities: 16/16 passed')
for n in (2**20,2**24):
    assert isqrt(n)**2 == n
    k = 32768*isqrt(n)
    assert k & (k-1) == 0
    p = n + 2 - (k.bit_length()-1)
    print('n=',n,' k=',k,' shell_fee >= 2^',p,sep='')
for M in (2, 17, 1000000):
    EY=Fraction(1,M)
    Erho=Fraction(1,M)
    EYrho=Fraction(1,M)
    assert EYrho == M*EY*Erho
    print('selector M=',M,' covariance-factor=',EYrho/(EY*Erho),sep='')
```

实际 stdout：

```text
Python 3.15.0
Exact projection coefficient identities: 16/16 passed
n=1048576 k=33554432 shell_fee >= 2^1048553
n=16777216 k=134217728 shell_fee >= 2^16777191
selector M=2 covariance-factor=2
selector M=17 covariance-factor=17
selector M=1000000 covariance-factor=1000000
```

大维度输出只使用 c_0^n≥1 与 2^n−1≥2^{n−1}，核对 (A10) 的**上界系数本身**仍巨大；它不是 S′_k 的下界。n=1,…,16 的精确恒等式仅核对 (A8) 的积分代数；不声称这些维度存在 near 输入。全部一般性判断来自上面的公式证明，而不是这些有限算术点。

## 最终停点

可以精确保留真正 owner law、全部共享 first-k 历史、代表选择、实际并集重叠、继承 admission 和未来重复剪枝；(A2) 是这种保留的可检查表达。**本工作未找到在该表达上产生全局绝对预算的步骤。** 具体欠缺的是选中暴露横截面的联合概率/面积估计，而非一个遗漏的 q_i 密度因子、局部共点定理常数或目标重复计数常数。不得据此上调主定理状态。
