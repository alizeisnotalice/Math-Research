# R666 A2 — box jitter: a paid parent correction and the remaining endpoint pressure

Status: a new **whole-family O(U) payment** is proved below, for the correction between signed coordinate variation and positive exposed growth. The full flux is reduced exactly to a nonnegative endpoint-pressure functional plus this paid correction. The endpoint-pressure functional is still unbounded by an absolute multiple of U; the original theorem and full S8/S′ target remain open. No impossibility claim is made.

This note uses only the frozen actual construction of TASK and R665 REPORT §§2–4. All original q_i, I_h, L_h, target radii, completed full first-k keys, shared Poisson history, and future-repeat pruning are retained. The centers alone now have the independent auxiliary law Unif(B_i). This is never a product assumption on the original input f.

## 1. Law change and notation

Write a=32n, c0=1+1/a, B_i=Q(y_i,s_i/a), d_i=(2s_i)^n, U=Σ_i q_i d_i. Independently sample u_i uniformly in B_i for q_i>0 and set A′_i=Q(u_i,c0s_i). Containment, the additional cost Δ_n U< U/3, and the full paid-union fee B′_n U<11U from R665 require only u_i∈B_i and therefore remain valid. The actual full-key geometry and exposed-face flux identity remain valid because this new center law is absolutely continuous.

Let S(v)=S′_k(v), with the unchanged history and original L_h. Every key with a label satisfying N_j≥2 has its whole v-halo in Q′_rep, for 0≤v≤1. Consequently, when representing S(v), one may retain exactly the completed keys all of whose labels satisfy N_j=1. This is an equality after the original repeat mask, not an independent-event replacement.

For every such completed key J_h, the original witness remains in all its primed parents, and

    K′_h + v R_h Q = ⋂_{j∈J_h} Q(u_j, c0 s_j + v R_h).

This distributivity holds for nonempty axis-parallel box intersections. It also holds at the jitter endpoints. It retains every member of the full key.

## 2. Exact conditional slice, including both masks

Fix i with N_i=1, a coordinate ℓ, the entire history, x∈R^n, v∈(0,1], all other centers, and all coordinates of u_i except t=u_{iℓ}. Define

    h=s_i/a,  w=2h,  c=c0s_i,  J=[y_{iℓ}−h,y_{iℓ}+h].

Conditionally, t is uniform on J. Define the following quantities, all independent of t:

* M=1{x∉P′_{−i}∪Q′_rep}. Because N_i=1, Q′_rep is independent of u_i.
* C=1 if at least one retained full key not containing i covers x, including its original L_h clip.
* A retained key containing i is eligible if x∈L_h, all expanded-parent constraints of every j≠i in that key hold, and all transverse (coordinates other than ℓ) expanded-parent constraints of i hold.
* r is the largest R_h among these eligible keys; r=0 if there is no eligible key.
* D=1 if |x_j−u_{ij}|≤c for every j≠ℓ; it is the transverse membership indicator of the marked parent A′_i.

For r>0 the exact indicator f(t)=1{x∈S(v)} is

    f(t)=M [ C OR 1{|t−xℓ|≤c+vr} ] [1−D 1{|t−xℓ|≤c}].       (2.1)

The single interval in (2.1) is the union of all eligible containing-i intervals: they have the same center xℓ and nested radii c+vR_h. This maximization changes neither target eligibility nor event selection. If r=0, use only the C term in the first bracket. All quantities below have weight r and vanish in that case.

Put e=sign(xℓ−y_{iℓ}) (either sign at equality), and

    t_near=y_{iℓ}+eh,    t_far=y_{iℓ}−eh,
    t_out=xℓ−e(c+vr),    t_in=xℓ−ec,
    O=1{t_out∈int J},    I=1{t_in∈int J}.

Because c>h, each radius has at most one of its two thresholds in J. Whenever a threshold is present, e points from the center interval toward x. Endpoint equality cases are interpreted by the inside traces and are null in the subsequent integrals. Formulas involving r apply only for r>0.

The expected true positive moving-face flux, from this source and coordinate and including both orientations, has density

    φ = M(1−C) (r/w) O.                                    (2.2)

Indeed, at an outer face the i-parent mask is absent since c+vr>c; the outside-source masks contribute M, and coverage by any key excluding i hides the face exactly when C=1. Uniform averaging over t gives the actual density 1/w=a/(2s_i). The maximum eligible radius is the velocity of that exposed union face. This also follows directly from the R665 common-support and one-face theorem.

Define the signed endpoint expression

    b = (r/w)[f(t_near)−f(t_far)].                           (2.3)

Direct differentiation of (2.1), or its two interval jumps, gives

    b = M(r/w)[(1−C)O − D I],
    φ = b + M D (r/w) I.                                   (2.4)

The marked-parent term in (2.4) cannot simply be discarded: signed variation is not positive exposed growth.

## 3. Exact nonnegative decomposition; global correction payment

Since M,C,D,O,I are binary, (2.4) implies the stronger identity

    φ = b_+ + j,
    j = M(1−C)D (r/w) O I.                                 (3.1)

Here b_+=max(b,0) is taken **for this conditional slice before any integration or expectation**. It is not the positive part of an integrated signed sum. For example, when both outer and inner thresholds cross, C=0 and D=1, both endpoint values of S are zero: b=0, while φ=j=M r/w.

If both thresholds are in J, their separation vr cannot exceed w. Thus

    j(v) ≤ D I [r(v)/w] 1{v r(v)≤w}.                       (3.2)

For fixed history, x and all frozen center coordinates, every eligibility constraint expands as v increases. The eligible target collection grows, so r(v) is nondecreasing. The original L_h clips are fixed. Hence

    ∫_0^1 r(v) 1{v r(v)≤w} dv ≤ w.                         (3.3)

Proof: v r(v) is nondecreasing, so its ≤w set is an initial interval. If its endpoint is t*, then r(v)≤r(t*−) there and t* r(t*−)≤w; consequently the integral is at most t* r(t*−)≤w. The empty interval, endpoint 1 and finite jumps are handled by one-sided limits. No derivative of r is used. C(v) can vary: its factor was bounded by one in (3.2). M,D,I are independent of v.

Combining (3.2)–(3.3),

    ∫_0^1 j(v) dv ≤ D I.                                   (3.4)

For fixed transverse u_i, the receiver measure of D I is exactly

    ∫_{R^n} D I dx = 2 w (2c)^(n−1).                       (3.5)

There are two disjoint normal slabs of width w, and the transverse section is the parent section of side 2c. Tonelli applies to these nonnegative quantities. Summing every coordinate, every source, and the unchanged history, and using Pr(N_i=1)≤8q_i, gives

    C_box := Σ_i Σ_ℓ ∫ dx E_{−(iℓ)}[1{N_i=1} ∫_0^1 j(v)dv]
           ≤ Σ_i 8q_i n · 2w_i (2c0s_i)^(n−1)
           = (16n/a)c0^(n−1) U
           ≤ (16/31) U.                                   (3.6)

This payment includes all n directions and the real inverse-width coefficient. The n/a factor is bounded because a=32n. The last inequality uses c0^(n−1)≤c0^n≤32/31.

An equivalent way to see the improvement is that when vr>w and the parent threshold is in J, the outer threshold cannot be in J; the negative signed endpoint term cancels the whole parent correction. Paying the parent correction on that portion separately would manufacture a spurious order-n loss. The exact overlap identity (3.1) captures this cancellation, including C=1.

## 4. What is still required to pay the full flux

Let E_{−(iℓ)} mean integration over the full Poisson law and every auxiliary coordinate except u_{iℓ}. Define

    P_box = Σ_i Σ_ℓ ∫_0^1 ∫_{R^n}
              E_{−(iℓ)}[1{N_i=1} (r_iℓ(x,v)/w_i)
                  [f_iℓ(t_near)−f_iℓ(t_far)]_+] dx dv.     (4.1)

Every f in (4.1) is the actual fully pruned S indicator under its single pinned coordinate. In particular it retains arbitrary union overlaps, all original L_h, full first-k lists, other marked parents, and the future-repeat union. The same key may contribute through different coordinates; none of these n summands has been suppressed.

Integrating the R665 exact exposed-face identity and (3.1) proves

    E|S′_k(1)| = P_box + C_box,
    0≤C_box≤(16/31)U.                                      (4.2)

Thus a sufficient remaining global assertion is P_box≤A0 U for an absolute A0. It would give the original target with A=A0+16/31, and R665's unchanged full account would complete the theorem. Conversely, because P_box≤E|S′_k(1)|, an absolute full-flux bound implies this endpoint-pressure bound. So the remaining pressure is equivalent up to the already paid additive constant, rather than a larger all-boundary envelope.

The precise unpaid term is the positive difference between the near and far pinned-coordinate values in (4.1), with coefficient

    r/w_i = (a c0/2)(s_h/s_i)

on the target radius realizing r. The radius s_h here is that of an actual eligible full key. A product-law assertion or the fact that i is common to all current covering keys does not itself bound the space integral of this endpoint difference. There is still a sum over all n coordinates. The argument above pays only the part where the marked-parent inner boundary can cancel that difference; it does not establish the required collective full-key spatial concentration for the positive pressure.

An attempted further simplification would replace the pinned S indicators by an entire expanded parent or discard C, M, and the other full-key constraints. That recovers an exponential spatial envelope and does not close (4.1). Nor does Unif(B_i) inherit the disjoint-owner capacity associated with Unif(F_i). No such substitution is used in (4.2).

The new result is therefore a genuinely global paid correction and an exact unpaid endpoint functional, not a proof of the general dimension-free flux estimate and not a claim that uniform box jitter cannot prove it.

## 5. Jumps, verification, and independent audit

No differentiation in x or v of the eligible-target maximum is used in the slice argument. The only derivative/threshold calculation is in the frozen coordinate t, from which r,C,M,D are independent. The identification with the actual v flux uses R665's regular exposed faces, outside its finite collision parameters. Eligibility changes and changes of maximizing target occur at the original box-face arrangement; they do not create missing additional positive v flux. Equivalently one applies the established flux identity first, then conditionally integrates each face in t. All expected identities use Fubini/Tonelli on finite input; positive terms are bounded by finite geometric envelopes.

The proof decision for calculation was to verify (3.1) across mask configurations and both orientations, especially the cancellation when both thresholds lie in J. An actual MATLAB run tested s=1, a=32, c0=33/32; six v values (1/132,1/66,1/33,0.1,0.5,1); two positive r values; both normal orientations; 161 shifted normal receiver coordinates; and all eight choices of M,C,D. There were 30,912 checks and zero failures at tolerance 1e−10. This is a finite diagnostic for the local algebra, not an actual high-T near-input experiment or a proof of (4.1). The general identities and constant (3.6) are proved analytically above.

The independent agent r665_final_account checked the slice identity, monotonicity/time integration, the two-slab receiver volume, every n and width factor, and the constant 16/31. It reported PASS for these claims and explicitly retained the unpaid positive endpoint pressure. This audit does not certify the full AU target.


## 6. Exact reproduction record for the completed MATLAB run

This section transcribes the actual evaluate_matlab_code call and returned output. MATLAB version was **not recorded**. MATLAB was not reopened to retrieve its version. The test used ordinary floating-point MATLAB arithmetic and tolerance 1e−10.

Exact inputs: s=1, a=32, c=33/32, h=1/32, w=1/16; v=[1/132,1/66,1/33,0.1,0.5,1]; r=[c/2,c]=[33/64,33/32]; sign∈{−1,1}; off=(-80:80)/1024+1/8192; x=sign·(c+off). All M,C,D∈{0,1} were tested. The supplied code was:

```matlab
r666_fail=0;
r666_count=0;
r666_s=1;
r666_a=32;
r666_c=33/32;
r666_h=1/32;
r666_w=1/16;
for r666_v=[1/132 1/66 1/33 0.1 0.5 1]
    for r666_r=[r666_c/2 r666_c]
        for r666_sign=[-1 1]
            for r666_off=(-80:80)/1024+1/8192
                r666_x=r666_sign*(r666_c+r666_off);
                r666_e=sign(r666_x);
                r666_out=abs(r666_x-r666_e*(r666_c+r666_v*r666_r))<r666_h;
                r666_in=abs(r666_x-r666_e*r666_c)<r666_h;
                for r666_M=0:1
                    for r666_C=0:1
                        for r666_D=0:1
                            r666_near=r666_e*r666_h;
                            r666_far=-r666_near;
                            r666_fn=r666_M*(r666_C || abs(r666_near-r666_x)<=r666_c+r666_v*r666_r)*(1-r666_D*(abs(r666_near-r666_x)<=r666_c));
                            r666_ff=r666_M*(r666_C || abs(r666_far-r666_x)<=r666_c+r666_v*r666_r)*(1-r666_D*(abs(r666_far-r666_x)<=r666_c));
                            r666_b=r666_r*(r666_fn-r666_ff)/r666_w;
                            r666_phi=r666_M*(1-r666_C)*r666_r/r666_w*r666_out;
                            r666_j=r666_M*(1-r666_C)*r666_D*r666_r/r666_w*r666_out*r666_in;
                            r666_fail=r666_fail+(abs(r666_phi-max(r666_b,0)-r666_j)>1e-10);
                            r666_count=r666_count+1;
                        end
                    end
                end
            end
        end
    end
end
fprintf('R666 slice checks=%d failures=%d correction_bound=%0.15g PID=%d\n',r666_count,r666_fail,16/31,feature('getpid'));
```

The actual tool input was this same code flattened into semicolon-separated statements, with each loop-closing `end;`; the displayed line breaks above are formatting only. The actual returned output was:

```text
R666 slice checks=30912 failures=0 correction_bound=0.516129032258065 PID=13959
```

After the note was saved, the actual subsequent MATLAB call was `exit;`. The MCP call reported `matlab error:` with no diagnostic text because its session exited. The independent process check was then run using exec_command with sandbox_permissions=require_escalated:

```sh
ps -p 13959 -o pid=,comm=
```

It returned exit code 1 and empty output, confirming PID 13959 no longer existed. No version query or further MATLAB launch followed this exit check.

Archive amendment: the independent auditor identified that the explanatory example after (3.1) had omitted the factor M. Only that example was corrected from `φ=j=r/w` to `φ=j=M r/w`; the displayed proof identities, estimates and their scope were unchanged. This reproduction section is newly appended.
