# R666 uniform-B 辅助律独立命题审查

**独立结论：改律及 R665 几何继承 PASS；uniform-B 空间分部积分合法但有真实边界和逆宽度费用，不构成全局 AU 证明。** 本文件先读本轮 TASK，再独立完成下述审核；未读任一 Astra 作者稿。仅沿用已证 R665 同一真实原输入，不重读历史、不运行几何扫描、不改其他文件、不 Git/PDF/MATLAB。

## 1. 合同与保留量词

固定任意 n≥1、任意有限实际原输入、全部原 qᵢ、Iₕ、Lₕ、共同 witness、半径序、所有真实 first-m keys、原代表及一条实际有限共享 Poisson history。a=32n，c₀=1+1/a，Bᵢ=Q(yᵢ,sᵢ/a)，Aᵢ=Q(yᵢ,sᵢ)，dᵢ=(2sᵢ)ⁿ，真实不交 Fᵢ 仍满足 |Fᵢ|=qᵢdᵢ，0≤qᵢ≤a⁻ⁿ，U=Σ|Fᵢ|。

只将辅助位置律改为跨来源独立 uᵢ∼Unif(Bᵢ)，并与整条原 Poisson history 独立。正 rate 来源足够；qᵢ=0 来源无事件，可略去。父盒仍 Aᵢ′=Q(uᵢ,c₀sᵢ)。不更改 q，不重建 Iₕ、key 或 clip，不将辅助位置视作新 owner，也不重新求 primed packing。

## 2. 包含、Δ 费用和 R665 几何全部保留

对每个允许中心 uᵢ∈Bᵢ，有 Aᵢ⊂Aᵢ′ 及

Aᵢ+c₀sᵢQ ⊂ Aᵢ′+c₀sᵢQ。

逐路径 Ωₖ(1)⊂Ωₖ′(1)，P⊂P′，Qrep⊂Qrep′，从而

S₈ ⊂ (P′\P) ∪ (Qrep′\Qrep) ∪ Sₖ′(1)。

位移后的盒体积仍完全相同；原 Poisson rate 与 [0,8] 全局 counts 不变。因此联合新 uniform-B/Poisson 期望严格满足

E|S₈| ≤ E_B|Sₖ′(1)| + Δₙ U，

Δₙ = 8(c₀ⁿ−1)+32a⁻ⁿ[(2c₀)ⁿ−(1+c₀)ⁿ] ≤ 287/992 < 1/3。

同理完整新 union 两费仍是 Bₙ′U，Bₙ′=8c₀ⁿ+32(2c₀/a)ⁿ≤5119/496<11。这里只需要中心落在 Bᵢ、盒体积和 qᵢ≤a⁻ⁿ；不使用中心支撑于 Fᵢ。完整两费以外不另加 Δ。

R665 common-support、同 source/normal/横向线唯一 moving exposed face、projection 上包络及 actual exposed-flux 恒等式全部保留，量词不变：固定有限实际 history 和 m，几乎必然于辅助中心，除有限 v 外，在正则 moving exposed traces 的 H^(n−1) 几乎处处成立。理由是：

1. 跨来源 uniform-B 中心独立且绝对连续，坐标边际无原子，故不同来源的 offset ties 几乎必然排除；同一个中心的 product coordinates 在本证明中不额外需要。
2. uᵢ 几乎必然位于 Bᵢ 内部，原 common witness 因而严格位于新父盒内部，actual key cores 保持非空且满维。
3. 同 source/normal 的 one-face 证明只用原半径序、同一横向线确实穿过各相应 expanded boxes、Lₕ 嵌套及 common mask；均未改变。有限 v 例外、固定边界和横向交线的排除不能删除。
4. Ni≥2 的来源 key 仍被全局 repeated union 遮住；全局未来 repeat pruning、所有 first-key 依赖均保留。

于是新 law 下 E_B|Sₖ′(1)| 仍等于实际正增长通量的联合期望；若能对所有原输入证明 E_B|Sₖ′(1)|≤AU（A 绝对且独立于 n），则 R665 条件恢复原封不动适用。但这里尚未支付该期望。

## 3. uniform-B 空间分部积分：准确边界和系数

固定 i、坐标 ℓ，令 rᵢ=sᵢ/a，α=yᵢ,ℓ−rᵢ，β=yᵢ,ℓ+rᵢ，坐标全宽

wᵢ=β−α=2sᵢ/a。

固定其他所有来源中心、历史以及 uᵢ 的其余坐标 z。对沿该坐标绝对连续的可积观测 G，或用一侧 trace 与分布导数解释的 BV 观测，精确恒等式为

E_{uᵢ}[∂_{uᵢ,ℓ}G] = (1/wᵢ) E_z[G(β,z)−G(α,z)]
                       = (a/(2sᵢ)) E_z[G(β,z)−G(α,z)]。

BV 版本左侧应理解为 `(1/|Bᵢ|)∫_{Bᵢ}dD_ℓG`，不能把跳跃分布导数漏成几乎处处经典导数。有限 box arrangements 的 indicator/volume 观测可逐坐标使用 BV traces；任意未注明正则性的可测 G 不能直接书写经典导数。

把 pᵢ=1_Bᵢ/|Bᵢ| 看作整空间密度，其分布导数是

D_ℓpᵢ = |Bᵢ|⁻¹ (H^(n−1)|lower-face − H^(n−1)|upper-face)。

每个面的归一化总质量为 1/wᵢ=a/(2sᵢ)，两面总变差为

||D_ℓpᵢ|| = 2/wᵢ = a/sᵢ。

所有 n 个坐标合计 2n 个面，坐标总变差之和为 n a/sᵢ。没有周期边界或零边界条件，故上下两面均须保留。虽然每个面在 uniform-B 的体积概率下为零，这些面携带密度导数的全部奇异质量；不能以“几乎必然在内部”为由删掉。边界应使用从 Bᵢ 内部取得的 traces，不能将只在体积 a.s. 证明的非退化结论自动用于面测度。

对于 |G|≤M，得到

|E ∂_ℓG| ≤ aM/sᵢ。

若 0≤G≤M，利用同一横向位置的端点差≤M 可改为 aM/(2sᵢ)。这些只控制净 signed derivative，不是 E|∂G| 或正变差；后两者不能用端点差自动替换。有限区间内部的 bump 就可端点全零而正负变差都非零。

若对非恒定权重 W 使用分部积分，W 足够正则时精确有

E[W ∂_ℓG] = (1/wᵢ)E_z[(WG)(β,z)−(WG)(α,z)] − E[G ∂_ℓW]。

若 W 是按 actual supporting target、max radius 或 visible selector 选出的分段量，须计入其分布导数/跳跃 trace；不能把随位置改变的选择权重当常数提出。单个固定 key 的 Rₕ 是常数，但 union 上的归属/最大值未必常数。

## 4. 位移比较的同一费用

沿一个坐标平移 δ，两个均匀盒密度的精确 L¹ 距离为

||pᵢ(·−δeℓ)−pᵢ||₁ = 2 min{1, |δ|/wᵢ}。

相应概率 total variation（定义为半 L¹）是 min{1,|δ|/wᵢ}。因此 infinitesimal 一坐标总变差率仍为 2/wᵢ=a/sᵢ；每侧 boundary strip 的概率率是 1/wᵢ。移位比较必须保留离开/进入 Bᵢ 的 strip，不能要求移后的 uniform-B law 等于原 law。新律确实给了旧任意 Fᵢ 所没有的显式 translation 预算，但这个预算随 1/sᵢ 和 a 增长。

对 actual halo 速度 Rₕ=c₀sₕ（原合同 sₕ≤sᵢ），每个坐标面的逆宽度乘速度为

Rₕ/wᵢ = (a c₀/2)(sₕ/sᵢ) = ((a+1)/2)(sₕ/sᵢ) ≤ (a+1)/2。

若两面按总变差一起支付，则为

2Rₕ/wᵢ = (a+1)(sₕ/sᵢ) ≤ a+1。

a=32n，所以这本身不是维数独立常数；再逐坐标求和可能再带 n。可否利用实际半径比、source occurrence、正负结构或不同 sources/normals 的竞争消去这些费用，需要额外全族证明。以上归一化系数不是最终通量上界，因为还存在真实的横向面积/边界 incidence 积分，尚未控制。用 whole parent 的全部边界来包络会恢复已知的大体积费用，不能据此认证 AU。

## 5. 不交 owner 不能转移为新辅助位置的容量

真实 Fᵢ 仍不交，故 Σ1_Fᵢ≤1 且 U=Σ|Fᵢ|，这些原输入事实完整保留。可是将其质量在 Bᵢ 上摊匀后的辅助 source-mass density 是

ρ_B(x)=Σᵢ |Fᵢ| 1_Bᵢ(x)/|Bᵢ| = aⁿ Σᵢ qᵢ 1_Bᵢ(x)。

没有从 Fᵢ 不交自动推出 ρ_B≤1 的论证。虽然逐来源 aⁿqᵢ≤1，但多个 Bᵢ 可重叠，不能对来源求和后仍当作一个容量。仅用当前已给的原 packing 可立即合法取得的粗界为

ρ_B(x) ≤ aⁿ Σᵢ qᵢ1_Aᵢ(x) ≤ aⁿτ，Lebesgue-a.e.。

本式只是可认证的粗界，不主张它最优，也不主张具体 actual family 必须达到它。任何更小的全族容量界都须由 actual admission/owner 结构另证；不能把辅助 product law 当作原输入 f 的 product law、密度帽或新 parent packing。

## 6. 合法 IBP 与全局通量之间的明确缺口

uniform-B 只解决“辅助 law 有可计算空间变分”这一合法性问题。要将其用于 S′，还必须明确整个 observable 对 uᵢ 的变化，包括 cores、union visibility、P′/Qrep′ masks 和支持选择；它们的空间导数不能只保留想付的 exposed outer faces。原 first-m event lists 固定不代表它们的几何 union 对中心变化是单调的。

此外两向 outward growth 通量是非负量，单一有向空间导数是正负面差；分部积分仅支付 signed difference，绝不能无证替换为两个方向正通量之和。使用正变差需要独立 domination 或选择论证，并保留其边界/逆宽度费用。R665 的局部 spatial-position pivotality 保留，但不等于全局单调性、event deletion pivotality 或已付 variation budget。

因此本审查不认证全局 E_B|Sₖ′(1)|≤AU，也不否定存在更精细全局证明。精确剩余任务仍是对所有真实有限输入，以统一绝对 A 支付 actual full exposed flux；改律的合法性和显式边界费用不能替代它。

## 7. 本机实际轻量精确检查

实际调用用户已有 Python 3.12 环境及 SymPy，仅核对新归一化公式；未做数值/几何扫描。短程序如下（为遵守单文件写入约定而嵌入本文件）：

```python
import sympy as S
n,si,sh,qi,di=S.symbols('n si sh qi di', positive=True)
a=32*n; c=1+1/a; w=2*si/a; R=c*sh
print(S.factor(1/w))
print(S.factor(2/w))
print(S.factor(R/w))
print(S.factor(2*R/w))
print(S.cancel(qi*di/(di/a**n)))
assert S.simplify(R/w-(a+1)*sh/(2*si))==0
```

实际输出依次为：`16*n/si`、`32*n/si`、`sh*(32*n+1)/(2*si)`、`sh*(32*n+1)/si`、`32**n*n**n*qi`。最后一式即 aⁿqᵢ。它们是精确符号恒等式的实现核对；通用边界证明与量词已在上文给出。

## 8. 有界交付

已审清改律后的包含与 Δ、R665 几何继承、uniform-B 的边界/逆宽度/平移费用以及不交 owner 容量不能免费转移的范围。未读 Astra 作者稿，未认证未知全局 AU。指定独立命题审查完成，交付后停止；若收到作者新增具体预算再按单独指令定点核查。

## 9. 主代理 MAIN_SLICE 的独立正文复核

按追加指令已读取同目录 `MAIN_SLICE.md`；这不是 Astra 作者稿。**其 exact one-coordinate occupancy statement PASS，限所写的 conditional identity 范围。**

固定 history 且 Nᵢ=1、x、v∈[0,1]、其他来源中心及 uᵢ 横向坐标，令 t=uᵢ,ℓ，c=c₀sᵢ。原 common witness 保证每个相关 core 非空，因此 box intersection 的 vRₕ expansion 等价于各 parent 分别加同一个 vRₕ 后的坐标约束。排除 i 的所有约束以及原 clip 都与 t 无关。每个 eligible key 给同中心区间 |t−xℓ|≤c+vRₕ，非空 eligible 家族的 union 正是最大 Rₕ 的区间。

必须保留 MAIN_SLICE 对 empty eligible 的单列：空家族不贡献任何 interval，不能用 r=0 后仍加入 |t−xℓ|≤c 来替代。这时 occupancy 为 D(x)H₀[1−Ctrans 1_{|t−xℓ|≤c}]。

若 eligible 非空，设 r=Rmax，Iout=1_{|t−xℓ|≤c+vr}，Iin=1_{|t−xℓ|≤c}，则 Iin≤Iout（v≥0）。因此

[H₀∨Iout][1−Ctrans Iin]
=H₀+(1−H₀)Iout−Ctrans Iin。

这正给出正文的 conditional probability

D(x)[H₀+(1−H₀)p(c+vr)−Ctrans p(c)]。

特别是负 parent 项不带 H₀ 或 (1−H₀) 因子，正文写法正确。Nᵢ=1 只去掉 i 自己的 repeat mask；marked parent Pᵢ 仍存在，必须保留 Ctrans 与 axial parent subtraction。H₀ 包括所有 completed keys 不含 i 的竞争，与 t 无关，不能删去。

eligible 与 H₀ 随 v 可变化；其变化只在有限阈值发生，但对固定其他参数的 full conditional-occupation variation 可产生真实跳项。正文对“局部固定 eligible/H₀ 时的 axial term”与“完整 v 变化”作了正确区分。只有把 R665 actual face flux 作为起点，才能另行提取每个 source/coordinate 的 axial face 项，而不把本 conditional probability 的普通 v 导数漏项。MAIN_SLICE 未声称 AU，范围正确。

## 10. 新 endpoint-pressure 非负分解：先独立核验

随后收到 A2 作者准确公式，并按父代理要求独立复核，未把其结论当作证明。下述记号避免与上一节 D(x)、Ctrans 混淆：M 是其他 marked/repeated labels 的 fixed-mask complement；C 是至少一个不含 i 的 completed key 的覆盖指示；D 是 i-parent 的横向未扩张包含指示。保持 Nᵢ=1、固定 history、x、其他中心和 uᵢ 横向坐标，v∈(0,1]。所有 quantities 都允许依赖 x、v 和条件数据，惟 M、D 不随 v 改变。

写 w=2sᵢ/a，J=[α,β]，c=c₀sᵢ。eligible 含 i 的 keys 定义完全沿用第9节；r=max Rₕ，空家族单独置 r=0 并令本节通量、b 与 correction 全为0。对 r>0，设 e=sign(xℓ−yᵢ,ℓ)，忽略 dx 零集 xℓ=yᵢ,ℓ（也可在该处任取 e=±1），near=yᵢ,ℓ+ew/2，far=yᵢ,ℓ−ew/2，

tout=xℓ−e(c+vr)，tin=xℓ−ec，O=1_{tout∈J}，I=1_{tin∈J}。

由于 c>w/2，半径至少 c 的 interval 在 J 内至多有一个阈值；靠近 J 的阈值正是上述取法。端点 equality 使用 one-sided traces 或在 x 的零集外解释。令 f(t) 是第9节真实 occupancy indicator，则

f(near)−f(far)=M[(1−C)O−DI]。

定义局部 signed endpoint pressure

b=(r/w)[f(near)−f(far)]。

真实 source-i/coordinate-ℓ 正 axial flux 的 conditional density 是

φ=M(1−C)(r/w)O。

这是实际 faces 的 axial flux，而不是把整个 conditional occupancy 对 v 求导。r、C 的横向/其他来源 eligibility 随 v 变化不应在这里另造或删去 axial face；它们的其他 face 贡献已经在 R665 full source/coordinate flux 求和中逐个列出。mask 的 spatial-parent correction 则由下面的恒等式保留。

对 M,C,D,O,I 的每个 Boolean 情形直接计算，得到精确非负分解

φ = b₊ + M(1−C)D(r/w)OI，b₊=max{b,0}。

证明只需 b=M(r/w)[(1−C)O−DI]：若 (1−C)O=0，则 φ=0、b≤0、correction=0；若 (1−C)O=1，则 DI=0 时 b=φ，DI=1 时 b=0 且 correction=φ。故该恒等式无需分别对 signed B 与大 J 粗放大。

**正部顺序是实质要求。** b₊ 必须在每个固定 history、x、v、其他中心及横向坐标的局部 scalar b 上先取，再积分/取期望。不能改成 (∫b)₊、(E b)₊，也不是某个全局 signed pressure B 的正部；这些交换一般会低估真实正压项。

## 11. 真正可支付的全族 parent correction

若 OI=1，则两个阈值都在同一个宽 w 区间，而 |tout−tin|=vr，故必有 vr≤w。固定 x、history 和全部其他位置参数，eligible 随 v 单调增加，因为所有 expanded-parent 坐标约束随 v 扩大、原 clip 固定。于是 r(v) 是有限、非负、非减函数（空家族时0）。因 v r(v) 非减，其 ≤w 的 sublevel 是初始区间；若其终点为 T，则

∫₀¹ r(v)1_{v r(v)≤w}dv ≤ T r(T−) ≤ w。

端点、跳点不影响 dv 积分；T=0 的情形直接为0。该证明保留 r(v) 的真实 eligibility 变化，不要求 r 恒定。M、D 固定于 v；C(v) 即便变化，上界中只用 0≤M(1−C)≤1，所以不会破坏这一付款。

因此单个 source/coordinate correction 的 v 积分至多 D I。对 xℓ，I=1 的 inner-threshold 两条带各宽 w，总长度2w；D 的横向父盒体积为 (2c₀sᵢ)^(n−1)。所以对任意 Nᵢ=1 的固定 history 及其余位置，积分 x 后的 correction ≤

2w(2c₀sᵢ)^(n−1)。

该上界不依赖 history、其他 source positions 或 uᵢ 的横向位置，故平均后使用原概率 Pr(Nᵢ=1)≤8qᵢ，求所有 n 个坐标与来源：

E correction ≤ Σᵢ 8qᵢ n·2wᵢ(2c₀sᵢ)^(n−1)
             = (16n/a)c₀^(n−1) Σᵢ qᵢdᵢ
             ≤ (16/31)U。

最后用 a=32n 与 c₀^(n−1)≤32/31。这是真正全族、绝对 source 付款；没有把新 auxiliary law 假充 owner 容量，也没有调用 primed packing。

厚层抵消同样准确：若 vr>w 且 I=1，则 tout 已在 J 外的 far 侧，outer interval 覆盖整个 J，故 O=0。此时 signed b 为负 parent 项，恰与原 signed 分解中的 parent J 逐slice 抵消。M 或 C 的值不改变这个点态抵消；空 eligible 由 r=0 单列。上面的非负分解将唯一尚需额外支付的 overlap 精确限制在 thin vr≤w 区间，免去分别给 B、J 粗上界所产生的 O(n) 费用。

将 φ 对真实所有 sources/coordinates、x、v、history 和其他辅助位置求和积分，R665 full exposed-flux identity 给出

E_B|Sₖ′(1)| = Pressure₊ + Correction，

0≤Correction≤16U/31，

其中 Pressure₊ 是上述逐slice b₊ 的积分/期望。**Pressure₊≤A₀U 尚未证明。** 因而这是新可付项及更精确的全局剩余表达，仍不是 AU 闭合。若未来独立证明统一 Pressure₊≤A₀U，才可取 A=A₀+16/31 进入旧恢复。

## 12. 作者稿绑定状态

已向 A2 作者索取准确文件路径与最终哈希。以上是先独立审核其精确 statement 与父代理 MAIN_SLICE；待作者稿形成只再对照非负分解、positive-part 顺序、空 eligible、v∈(0,1]、薄层付款与未闭合范围，不扩展为重复作者任务。

## 13. 最终作者稿、主报告整合与哈希绑定

**最终处分：新增数学命题及主报告整合 PASS。** 已在第1–11节先独立审核 statement 后，读取并定点对照 A2 正文。最初 A2 SHA-256 为 `254e862010b69984893046ff1c7b339757a1fc603051b712c2aa04fca30037cc`；发现其 §3 解释例句漏 M：当 O=I=1、C=0、D=1 时应为 φ=j=M r/w，而非无条件 φ=j=r/w。作者已修正该例句；主数学公式本来正确。

最终实际读取的 A2_BOX_JITTER.md SHA-256：

`5da0657ad7b6811066e4957efde68351c4e849cf4c51e2f8d13479bcb42944a1`。

最终稿明确 empty eligible 的处理、v∈(0,1]、both orientations、endpoint 内 traces、local positive-part 次序、r(v) 非减证明、C(v) 可变但在修正上界中仅用≤1、以及16/31的全族预算。其 §§2–4 与本审查独立证明完全一致。作者 §6 新增实际 MATLAB 输入代码/所报输出、版本未记录及正常 exit/进程核验记录。本代理仅阅读该记录，未重复运行或重启 MATLAB；本代理的数学 PASS 依赖通用解析证明，而非30912次有限诊断。

MAIN_SLICE.md 所读 SHA-256：

`8bc04610ef5a10018eac444501ab249a3f70142c5eb406aaf30ca25dc1db6c3d`。

主 REPORT.tex 初读 SHA-256 为 `05789a5c52f0a76f5f67c2854a07a500ab9c8971a042229ca885265299ceb4f5`；该时刻是标明 draft 的版本。其式(3)–(7)已经与作者数学内容完全一致，未发现必须修正的数学错误。我建议将“other exposed-coordinate faces”改为“other source/coordinate exposed faces”，避免把 eligibility 变化误读为只能来自不同坐标；主代理已采纳。主代理也更新了最终审查状态及作者实际 MATLAB 诊断的准确范围。

最终实际读取的 REPORT.tex SHA-256：

`4cbe25e98dd40ae527cebf338585eb1bbec0d00cd6af0739d1bb69e9b1b8e78a`。

最终定点结论：

- 式(3)是固定全部其他数据后的 source/coordinate 真正 axial face flux；不是漏掉 eligibility/H₀变化的 full-v derivative。式(4)逐slice Boolean 分解正确，正部在其余积分/期望之前，双法向由 receiver 两侧全部计入。
- 空 eligible 没被偷换为 radius-zero interval；其带 r 的 pressure/flux/correction 全置0，同时真实 occupancy 的无i key覆盖仍保留。Pᵢ mask、其他 marked/repeated masks 和完整 keys 均保留。
- 式(5)–(7)通过原 full flux identity 与 Tonelli 整合，薄层 monotonicity 付款正确。原始 O(n) parent envelope 并未被当作新费用，取代它的确切 overlap correction 才支付16U/31。
- 式(8)完整两 union 费最多11U，再加已证修正16U/31和未付 pressure；没有再加 Δ，没有重复支付 parent correction。
- 式(9)的条件常数正确：`1+2(11+16/31+A)=23+32/31+2A`。再乘 τ=16384√n 并处理 Kfar 后，原-parent packing 与旧有限恢复给出的表达与主报告一致。A 必须对所有维数和全部真实有限输入统一。
- 主报告保留 pressure 的全部实际 first-key 依赖、普通 Lebesgue receiver、visibility 及未来 repeat pruning。uniform-B law 不被赋予假的 owner 容量。最终状态仍明确 pressure≤AU、纯√n一般界及旧n^(1/2+o(1))目标未证明。

本轮独立 law audit、MAIN_SLICE 独审、A2 精确非负分解及16/31付款、最终主报告定点整合均已完成。无剩余必须修复点；新付 parent correction 以外的正端点 pressure 仍 OPEN。只追加本S1文件；无 Git、PDF、MATLAB或重复旧数学实验。交付后停止。
