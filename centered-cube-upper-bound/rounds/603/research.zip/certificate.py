#!/usr/bin/env python3
"""R603 bounded scalar and subset-count certificate; no geometric simulation."""
import argparse,hashlib,itertools,json,platform,shlex,sys,time
from fractions import Fraction as F
from pathlib import Path
import sympy as s

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));a=ap.parse_args();start=time.perf_counter()
 C,q,theta,zeta,t,sigma,K,r,eta=s.symbols('C q theta zeta t sigma K r eta',positive=True)
 raw=C/(1-theta/q)-q
 res1=s.factor(raw-q*((C-q)+theta)/(q-theta));assert res1==0
 slack1=s.factor(s.Rational(4,3)*(zeta+theta)-(raw.subs(C,q+zeta)));assert s.simplify(slack1-(zeta+theta)*(q-4*theta)/(3*(q-theta)))==0
 f=(K*t+r)/(eta*(C*t-zeta));fs=(K+r/sigma)/(eta*(C-zeta/sigma))
 mono=s.factor(fs-f);want=(t-sigma)*(C*r+K*zeta)/(eta*(C*sigma-zeta)*(C*t-zeta));assert s.simplify(mono-want)==0
 derivative=s.factor(s.diff(f,t));assert s.simplify(derivative+(C*r+K*zeta)/(eta*(C*t-zeta)**2))==0
 worst=fs.subs(r,s.Rational(4,3)*(zeta+theta));lim=s.simplify(s.limit(worst,zeta,0,dir='+'));assert s.simplify(lim-(K+s.Rational(4,3)*theta/sigma)/(eta*C))==0
 finalslack=s.factor((K+s.Rational(4,3))/(eta*C)-lim);assert s.simplify(finalslack-4*(sigma-theta)/(3*eta*C*sigma))==0
 first=[]
 for qq,th,zz in itertools.product(map(F,['2','3','100']),map(F,['1/1000','1/4','1/2']),map(F,['0','1/1000000','1','100'])):
  cc=qq+zz;gap=cc/(1-th/qq)-qq;assert gap==qq*(zz+th)/(qq-th) and gap<=F(4,3)*(zz+th)
  first.append({'q':str(qq),'theta':str(th),'zeta_C_minus_q':str(zz),'gap_exact':str(gap),'upper_slack_exact':str(F(4,3)*(zz+th)-gap)})
 second_counts={'initial':0,'near_boundary':0,'wide_range':0};witness={};limitcases=0
 # Fixed grid; zeta is a fraction of C*sigma, always C*sigma>zeta.
 for cc,sg,er,kk,fr,tt,rrkind in itertools.product(map(F,['2','100']),map(F,['1/1000','1']),map(F,['1/100','1']),map(F,['0','1','100']),map(F,['0','1/2','999/1000']),('sigma','midpoint','one'),('zero','one','price_cap')):
  if sg==1 and tt!='sigma':continue
  zz=fr*cc*sg;th=sg/2;rr={'zero':F(0),'one':F(1),'price_cap':F(4,3)*(zz+th)}[rrkind];tv={'sigma':sg,'midpoint':(sg+1)/2,'one':F(1)}[tt]
  assert sg<=tv<=1
  bound=(kk*tv+rr)/(er*(cc*tv-zz));uniform=(kk+rr/sg)/(er*(cc-zz/sg));assert bound<=uniform
  assert uniform-bound==(tv-sg)*(cc*rr+kk*zz)/(er*(cc*sg-zz)*(cc*tv-zz))
  # Scalar price decomposition with W=1: nonnegative I0 can only reduce the unpaid amount.
  Bout=rr;price=kk*tv;I0=min(F(1,7),price+Bout);unpaid=price-I0+Bout;assert 0<=unpaid<=kk*tv+rr
  stage='near_boundary' if fr==F(999,1000) else ('initial' if cc==2 and sg==1 and tt=='sigma' else 'wide_range');second_counts[stage]+=1
  if stage not in witness:witness[stage]={'C':str(cc),'sigma':str(sg),'zeta':str(zz),'eta':str(er),'K':str(kk),'r':str(rr),'t':str(tv),'actual_t_bound':str(bound),'uniform_t_ge_sigma_bound':str(uniform)}
 for cc,sg,thratio,er,kk in itertools.product(map(F,['2','100']),map(F,['1/1000','1']),map(F,['1/1000000','1/2','1']),map(F,['1/100','1']),map(F,['0','1','100'])):
  th=thratio*min(sg,F(1,2))
  assert 0<th<=min(sg,F(1,2))
  limvalue=(kk+F(4,3)*th/sg)/(er*cc);assert limvalue<=(kk+F(4,3))/(er*cc);limitcases+=1
 subsets=[]
 for dim in range(1,9):
  masses=[F((i+1)**2,2*i+3) for i in range(dim)];lhs=F(0);incidences=0
  for mask in range(1,1<<dim):
   for i in range(dim):
    if mask>>i&1:lhs+=masses[i];incidences+=1
  rhs=2**(dim-1)*sum(masses,F(0));assert lhs==rhs and incidences==dim*2**(dim-1)
  subsets.append({'d':dim,'positive_masses':list(map(str,masses)),'nonempty_subsets_enumerated':(1<<dim)-1,'source_subset_incidences':incidences,'lhs_exact':str(lhs),'rhs_exact':str(rhs)})
 # Formal sum: each fixed source belongs to one subset for every choice of d-1 others.
 j,d=s.symbols('j d',integer=True,nonnegative=True);binomial_sum=s.summation(s.binomial(d,j),(j,0,d));assert s.simplify(binomial_sum-2**d)==0
 out={'scope':'Only scalar identities/directions and finite subset source counting. No real receiver geometry, price bound premise, gain, integral or root theorem is certified.','symbolics':{'gap_identity_residual':str(res1),'gap_upper_slack':str(slack1),'t_uniform_minus_pointwise':str(mono),'pointwise_t_derivative':str(derivative),'zeta_to_zero_limit':str(lim),'final_limit_slack_theta_le_sigma':str(finalslack),'binomial_subset_sum_residual':str(s.simplify(binomial_sum-2**d))},'proof_conditions':{'part1':'q>=2,0<theta<=1/2,C>=q,zeta=C-q. Gap slack=(zeta+theta)(q-4theta)/(3(q-theta))>=0.','part2':'Additionally assume price<=K*Delta, Delta=tW>=sigmaW, I0>=0, Bout<=rW, total lambda-integral L >=(Ct-zeta)W, and 0<=fprime<=1 everywhere, and bad region has1-fprime>=eta>0. Then bad fill fraction<= (Kt+r)/(eta(Ct-zeta)). K,r>=0 and Csigma>zeta give monotonicity for t>=sigma. This certificate does not establish these geometric premises.','limit':'Use r<=4/3(zeta+theta), then take zeta->0. If theta<=sigma, limit<=(K+4/3)/(eta*C). This is not the same bound for arbitrary positive zeta.','part3':'For each fixed label i, exactly2^(d-1) subsets contain i. Summing positive mi proves the identity; this is source-incidence counting only, not a dimension budget.'},'phase1_initial_gap_rows':first,'phase2_boundary_and_wide_counts':second_counts,'auxiliary_unpaid_choice':'W=1;price=Kt;Bout=r;I0=min(1/7,price+Bout), so unpaid is nonnegative. This auxiliary scalar construction is not a real geometric input.','phase2_representative_witnesses':witness,'phase2_grid':{'C':['2','100'],'sigma':['1/1000','1'],'eta':['1/100','1'],'K':['0','1','100'],'zeta_over_Csigma':['0','1/2','999/1000'],'t':['sigma','(sigma+1)/2','1; duplicate values removed'],'r':['0','1','4/3*(zeta+theta)'],'theta_for_pointwise':'sigma/2'},'limit_case_count':limitcases,'limit_grid':{'C':['2','100'],'sigma':['1/1000','1'],'theta_ratio':['1/1000000','1/2','1'],'theta_definition':'theta_ratio*min(sigma,1/2)','eta':['1/100','1'],'K':['0','1','100'],'scope':'Limit grid obeys theta<=min(sigma,1/2).'},'phase3_subset_checks':subsets,'all_assertions_passed':True,'execution':{'interpreter':sys.executable,'python':platform.python_version(),'sympy':s.__version__,'processes':1,'runtime_seconds':time.perf_counter()-start,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'command':shlex.join([sys.executable,*sys.argv])}}
 a.output.write_text(json.dumps(out,indent=2,sort_keys=True)+'\n');print(json.dumps({'gap_cases':len(first),'pointwise_cases':sum(second_counts.values()),'limit_cases':limitcases,'subset_dimensions':8,'execution':out['execution']}))
if __name__=='__main__':main()
