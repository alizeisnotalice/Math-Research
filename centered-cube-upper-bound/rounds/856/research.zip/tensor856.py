"""R856: physical product occupation matrices and exact tilted spectral bound.

For each endpoint pair, use the genuine unit-volume left box.
The degree-k error coefficient is its measure with exactly k misses.
With 0<tau<1, sum_{k<=d} c_k <= tau^(-d) sum_k tau^k c_k,
without fixing the missed coordinates. Each one-axis factor is
T+tau*(1-T) <= T+tau. Nonnegative entrywise domination implies
operator-norm domination via absolute test vectors, so tensor
factorization and the triangle inequality give the stated bound.
"""

from fractions import Fraction as F
from itertools import product
from math import prod
import sys

from flint import arb, ctx, __version__ as flint_version


LEFT=(F(0),F(-11,32))
RIGHT=(F(8,32),F(19,32))
M=((F(24,32),F(13,32)),(F(13,32),F(2,32)))
TAU=F(1,256)
HALF=F(1,2)


def aq(x):
    x=F(x)
    return arb(x.numerator)/x.denominator


def physical_cells(s,z):
    low,high=s-HALF,s+HALF
    ends=sorted({low,high}|{p for p in (z-HALF,z+HALF) if low<p<high})
    return tuple((b-a, int(abs((a+b)/2-z)>HALF))
                 for a,b in zip(ends,ends[1:]))


def counts_geometry(s,z):
    counts=[F(0)]*(len(s)+1)
    for slab in product(*(physical_cells(a,b) for a,b in zip(s,z))):
        counts[sum(miss for length,miss in slab)] += prod(length for length,miss in slab)
    assert sum(counts)==1
    return tuple(counts)


def counts_polynomial(T):
    counts=[F(1)]
    for p in T:
        nxt=[F(0)]*(len(counts)+1)
        for j,v in enumerate(counts):
            nxt[j]+=p*v
            nxt[j+1]+=(1-p)*v
        counts=nxt
    return tuple(counts)


def physical_validation():
    assert tuple(tuple(sum(l for l,miss in physical_cells(s,z) if not miss)
                       for z in RIGHT) for s in LEFT)==M
    checks=0
    for n in range(1,5):
        min_zero=F(1)
        widest=F(0)
        for left,right in product(product(range(2),repeat=n),repeat=2):
            s=tuple(LEFT[i] for i in left)
            z=tuple(RIGHT[i] for i in right)
            T=tuple(M[i][j] for i,j in zip(left,right))
            physical=counts_geometry(s,z)
            assert physical==counts_geometry(z,s)==counts_polynomial(T)
            assert physical[0]>0
            min_zero=min(min_zero,physical[0])
            tilt=prod(t+TAU*(1-t) for t in T)
            loose=prod(t+TAU for t in T)
            assert tilt<=loose
            for d in range(0,min(2,n)+1):
                actual=sum(physical[:d+1])
                assert actual<=TAU**(-d)*tilt<=TAU**(-d)*loose
                checks+=1
                widest=max(widest,actual if d==1 else F(0))
        assert min_zero==F(1,16)**n
        print("n",n,"true signed pairs",4**n,"; minimum positive d=0 volume",min_zero,
              "; largest d=1 volume",widest,"; physical transpose replay exact.")
    assert checks==1016
    print("Checked",checks,"physical support inequalities for d<=2 and all real label pairs.")

    # Positive-width refinement. With two independent uniform small
    # packets, differences stay strictly in (0,1). The overlap is
    # affine in the two source coordinates, so its packet average
    # is exactly the centre overlap M. Fubini and independence yield
    # the same polynomial under the uniformly filled source packets.
    eps=F(1,16384)
    for s,z in product(LEFT,RIGHT):
        assert 0<z-s-2*eps<z-s+2*eps<1
        assert max(abs(s),abs(z))+eps+HALF+1<4
    print("Positive-width packets of halfside 1/16384 in uniform height 3/2: same matrix after actual source averaging.")
    print("Unit physical witnesses contain both marks at d=0; d>0 specifies a geometric allowance of misses.")


def eigenvalues_positive_case(A):
    a,b=A[0]
    c,d=A[1]
    assert b==c and a+d>0
    disc=((aq(a-d))**2+4*aq(b)**2).sqrt()
    return (aq(a+d)+disc)/2,(aq(a+d)-disc)/2


def high_density_pressure():
    # Many distinct real anchors close to opposite faces. A cell can
    # be tiny while the norm is bounded below by the all-ones test.
    for size in (32,256,1024):
        step=F(1,8*size**2)
        shift=1-F(2,size)
        width=(size-1)*step
        assert 0<shift-width<shift+width<1
        max_entry=1-shift+width
        assert max_entry<F(17,8*size)
        # T_ij=2/size+(i-j)*step. Its average is exactly 2/size.
        # e=(1,...,1)/sqrt(size), so |e^T T e|=2, also after transpose.
        all_ones_test=size*(1-shift)
        assert all_ones_test==2
        print("Dense physical",size,"x",size,"pressure: max entry",max_entry,
              "; norm >= 2 by normalized ones, also for transpose.")


def norm_checks():
    ctx.prec=192
    row_max=max(sum(row) for row in M)
    col_max=max(sum(col) for col in zip(*M))
    assert row_max==col_max==F(37,32)
    rho,negative=eigenvalues_positive_case(M)
    expected=(13+arb(290).sqrt())/32
    assert rho.overlaps(expected) and 0 < -negative < rho
    assert 32*F(47,50)-13>0 and (32*F(47,50)-13)**2>290
    assert 1023**256>256*1000**256
    factor=F(1023,1000)*(F(47,50)+2*TAU)
    assert factor<F(97,100)

    tilt_matrix=tuple(tuple(v+TAU*(1-v) for v in row) for row in M)
    loose_matrix=tuple(tuple(v+TAU for v in row) for row in M)
    tilted,_=eigenvalues_positive_case(tilt_matrix)
    loose,_=eigenvalues_positive_case(loose_matrix)
    cap=rho+2*aq(TAU)
    assert rho<tilted<loose<cap<1
    print("M spectral rho=(13+sqrt(290))/32",rho.str(12),
          "; largest row and column sums",row_max,col_max)
    print("Exact rational majorant factor",factor,"< 97/100.")
    print("For arbitrary n, d=floor(n/256), the tau-generating sum allows the missed axes to be chosen after the centre.")
    print("Log2: pure norm | max row=column | row*column | tilted | coarse bound | (97/100)^n")
    log2=arb(2).log()
    for n in (64,256,1024,4096):
        d=n//256
        values=(n*rho.log()/log2,n*aq(row_max).log()/log2,2*n*aq(row_max).log()/log2,
                8*d+n*tilted.log()/log2,8*d+n*cap.log()/log2,n*aq(F(97,100)).log()/log2)
        assert values[0]<0<values[1]<values[2]
        assert values[3]<values[4]<values[5]<0
        print("  n",n,"d",d,":",*(v.str(9) for v in values))


if __name__=="__main__":
    print("Python",sys.version.split()[0],"python-flint",flint_version,"| exact Fraction and 192-bit Arb")
    physical_validation()
    norm_checks()
    high_density_pressure()
    print("All assertions passed. True geometric product occupation family.")
