#!/usr/bin/env python3
"""Check the R856 receiver fee on the two archived R814 source-mask 95 fibers."""
import argparse
import json
from collections import defaultdict
from fractions import Fraction as F
from itertools import combinations, product
from math import prod
from zipfile import ZipFile


def read_box(box):
    return [(F(lo), F(hi)) for lo, hi in box]


def intersection(x, y):
    return [(max(a, c), min(b, d)) for (a, b), (c, d) in zip(x, y)]


def volume(box):
    return prod(max(F(0), hi - lo) for lo, hi in box)


def check(name, stage, trace, width):
    density = stage["density"]
    lo0, hi0 = map(F, density["support"])
    period, phase = F(density["period"]), F(density["bump_center_mod_period"])
    floor = F(density["density_floor_one_axis"])
    excess = (1 - floor) * period / (2 * width)

    def primitive(x):
        cycle, rem = divmod(x, period)
        return 2 * width * cycle + min(2 * width, max(F(0), rem - phase + width))

    def source_mass(box):
        total = F(1)
        for lo, hi in box:
            lo, hi = max(lo, lo0), min(hi, hi0)
            if hi <= lo:
                return F(0)
            total *= floor * (hi - lo) + excess * (primitive(hi) - primitive(lo))
        return total

    parents = {p["id"]: p for p in stage["parents"]}
    boxes = {i: read_box(p["box"]) for i, p in parents.items()}
    owners = {i: read_box(p["owner"]) for i, p in parents.items()}
    assert all(volume(intersection(owners[i], owners[j])) == 0
               for i, j in combinations(parents, 2))
    assert all(volume(owners[i]) == F(p["owner_volume"]) for i, p in parents.items())
    m = {i: F(p["m"]) for i, p in parents.items()}
    j = {i: F(p["j"]) for i, p in parents.items()}
    assert all(m[i] == source_mass(boxes[i]) == volume(boxes[i]) for i in parents)
    mask = trace["q_mask"]
    assert mask == 95 and len(trace["rows"]) == 58
    # On each true face-membership cell only the indicators depend on q.
    # The common factor dmu(q) cancels from all conditional probabilities.
    contains_q = {i for i, p in parents.items() if mask & p["bit"]}
    cell = [(lo0, hi0)] * stage["dimension"]
    for i in contains_q:
        cell = intersection(cell, boxes[i])
    qmass = F(0)
    missing = sorted(parents.keys() - contains_q)
    for pattern in product((0, 1), repeat=len(missing)):
        box = cell
        for i, take in zip(missing, pattern):
            if take:
                box = intersection(box, boxes[i])
        qmass += (-1)**sum(pattern) * source_mass(box)
    assert qmass == F(trace["q_mass"]) > 0

    middle = stage["middle_labels"]
    old = [i for i, p in parents.items() if p["role"] == "old"]
    # sigma and H are built from geometry and the original mother, before reading row weights.
    sigma, H, left = {}, {}, {}
    for t in middle:
        contact = {i: source_mass(intersection(boxes[t], boxes[i])) for i in parents}
        degree = sum(j[i]*contact[i]/(m[i]*m[t]) for i in parents if i != t)
        assert degree == F(trace["t_full_degrees"][t])
        eligible = {i for i in old if F(parents[i]["radius"]) < F(parents[t]["radius"])}
        right = {g: j[g]/(m[g]*m[t]) if g in eligible & contains_q and t in contains_q
                 else F(0) for g in old}
        c = sum(right.values())
        assert c > 0
        sigma[t] = j[t]*c
        for u in old:
            left[t, u] = j[u]*contact[u]/(m[u]*m[t]) if u in eligible else F(0)
            for g in old:
                H[t, u, g] = left[t, u]*right[g]/(degree*c)

    rec, middle_mass = defaultdict(F), defaultdict(F)
    for row in trace["rows"]:
        t, u, g = row["t"], row["left_parent"], row["right_parent"]
        assert parents[u]["volume_bin"] != parents[g]["volume_bin"]
        w = F(row["weight"])
        rec[u, g] += w
        middle_mass[t] += w
    total = sum(rec.values())
    assert total == F(trace["subflow_original_mass"])
    p = {c: w/total for c, w in rec.items()}
    pi = {t: middle_mass[t]/total for t in middle}
    f = {t: middle_mass[t]/(qmass*sigma[t]) for t in middle}
    alpha, K = {}, {}
    for u, g in p:
        support = [t for t in middle if H[t, u, g] > 0 and f[t] > 0]
        alpha[u, g] = sum(pi[t] for t in support)
        K[u, g] = (sum(sigma[t]*H[t, u, g] for t in support)
                   / sum(sigma[t]*f[t] for t in support))
        assert alpha[u, g]*K[u, g] == p[u, g]
    # p and K here are integrals on E_u x E_g. Both densities are constant there.
    energy = sum(p[c]**2/K[c] for c in p)
    assert energy == sum(p[c]*alpha[c] for c in p)
    one = sum(w*sum(pi[t] for t in middle if left[t, u] > 0) for (u, g), w in p.items())
    assert energy <= one

    need, half = F(1, 2), F(0)
    for c in sorted(p, key=lambda x: K[x]/p[x]):
        price = K[c]/p[c]
        take = min(need, p[c])
        half += price*take
        need -= take
        if not need:
            break
    # Lebesgue owners can be cut fractionally; the last price certifies the dual optimum.
    dual = price/2 - sum(max(F(0), price*p[c] - K[c]) for c in p)
    assert need == 0 and half == dual
    print(f"{name} width={width} records={len(trace['rows'])} middles={len(pi)} receiver_pairs={len(p)}")
    for label, value in [("source_fiber_share", F(trace["subflow_share"])),
                         ("compatible_left_receiver", one),
                         ("integral_p_squared_over_K=compatible_both_receivers", energy),
                         ("half_mass_capacity=dual", half),
                         ("K_on_positive_receiver_support", sum(K.values()))]:
        print(f"  {label} {value} ({float(value):.12g})")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive", required=True)
    args = parser.parse_args()
    with ZipFile(args.archive) as archive:
        trace = json.loads(archive.read("cell814.json"))
        stage = json.loads(archive.read("comb814-rebuilt.json"))["stages"][0]
    assert F(stage["density"]["bump_half_width"]) == F(1, 1024)
    print("Mask 95 is a true parent-membership cell. The conditional law is constant for mu-a.e. physical q there.")
    print("Exact mother coefficients use true comb intersections, full degrees and disjoint Lebesgue owners.")
    for name, width in [("original", F(1, 2048)), ("rebuilt", F(1, 1024))]:
        check(name, stage, trace[name], width)


if __name__ == "__main__":
    main()
