"""Verify a flat R856 release and byte-replay its six certificates."""
from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path
from subprocess import run
from tempfile import TemporaryDirectory
from zipfile import ZipFile
import json
import os
import sys

PARENTS = {
    "814": "891d8cbcbd35537e6abc18c938e53b1b4f300327357c24c8d14a51a46ad5e190",
    "855": "9c21d7d15028d512d89bd69416d6d03f47d48ce891f4adbfaeefdf8a00624814",
}
PROGRAMS = (
    ("anchor856", "--archive", "814"),
    ("matching856", "--archive", "814"),
    ("swaps856", "--handoff", "855"),
    ("tensor856", None, None),
    ("private856", "--archive", "814"),
    ("shared856", "--archive", "814"),
)
CERTIFICATES = frozenset(f"{name}.{ext}" for name, _, _ in PROGRAMS for ext in ("py", "txt"))
RELEASE = CERTIFICATES | {"REPORT.tex", "replay856.py"}
ARCHIVED = RELEASE | {"MANIFEST.json"}
SCRIPTS = frozenset(name + ".py" for name, _, _ in PROGRAMS)


def digest(data):
    return sha256(data).hexdigest()


def verify(condition, message):
    if not condition:
        raise ValueError(message)


def unique_object(pairs):
    obj = {}
    for key, val in pairs:
        verify(key not in obj, f"duplicate manifest key: {key}")
        obj[key] = val
    return obj


def verify_manifest(files):
    manifest = json.loads(files["MANIFEST.json"], object_pairs_hook=unique_object)
    verify(isinstance(manifest, dict)
           and set(manifest) == {"round", "sha256", "parents"}
           and type(manifest["round"]) is int and manifest["round"] == 856,
           "unexpected R856 manifest schema")
    verify(manifest["parents"] == PARENTS, "R856 manifest parent pins differ")
    manifest_sha = manifest["sha256"]
    verify(isinstance(manifest_sha, dict) and set(manifest_sha) == RELEASE,
           "manifest SHA entries must cover all and only the 14 non-manifest members")
    for name in sorted(RELEASE):
        actual = digest(files[name])
        verify(actual == manifest_sha[name], f"R856 SHA-256 mismatch for {name}: {actual}")


def read_release(archive, here, smoke):
    if archive is not None:
        with ZipFile(archive) as bundle:
            names = bundle.namelist()
            verify(len(names) == 15 and set(names) == ARCHIVED,
                   "R856 ZIP must have exactly the 15 distinct flat member names")
            bad_crc = bundle.testzip()
            verify(bad_crc is None, f"R856 CRC failed for {bad_crc}")
            files = {name: bundle.read(name) for name in ARCHIVED}
        verify_manifest(files)
        return files, "ZIP member CRC and manifest SHA verified; archive SHA-256 " + digest(archive.read_bytes())
    if smoke:
        return ({name: (here / name).read_bytes() for name in CERTIFICATES},
                "explicit scratch smoke: six expected outputs, without an assembled release manifest")
    files = {name: (here / name).read_bytes() for name in ARCHIVED}
    verify_manifest(files)
    return files, "unpacked release: complete manifest member SHA verified"


def verify_parents(rounds):
    paths = {name: (rounds / name / "research.zip").resolve(strict=True) for name in PARENTS}
    for name, path in paths.items():
        actual = digest(path.read_bytes())
        verify(actual == PARENTS[name], f"R{name} archive SHA-256 mismatch: {actual}")
    return paths


def difference(expected, actual):
    index = next((i for i, (a, b) in enumerate(zip(expected, actual)) if a != b),
                 min(len(expected), len(actual)))
    line = expected.count(b"\n", 0, index) + 1
    return (f"first differing byte {index + 1}, expected line {line}; "
            f"expected SHA={digest(expected)}, actual SHA={digest(actual)}")


def replay(files, parents, work):
    environment = os.environ.copy()
    environment.pop("PYTHONPATH", None)
    environment.pop("PYTHONHOME", None)
    for key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
                "VECLIB_MAXIMUM_THREADS", "NUMEXPR_NUM_THREADS"):
        environment[key] = "1"
    with TemporaryDirectory(prefix="replay856-", dir=work) as tmp:
        folder = Path(tmp)
        verify(not any(folder.iterdir()), "new replay directory was not empty")
        for name in sorted(SCRIPTS):
            (folder / name).write_bytes(files[name])
        for program, flag, dependency in PROGRAMS:
            command = [sys.executable, "-B", "-s", program + ".py"]
            if dependency is not None:
                command.extend([flag, str(parents[dependency])])
            job = run(command, cwd=folder, env=environment, capture_output=True, timeout=60)
            verify(job.returncode == 0,
                   f"{program}: exit {job.returncode}\n{job.stderr.decode(errors='replace')}")
            verify(not job.stderr, f"{program}: unexpected stderr\n{job.stderr.decode(errors='replace')}")
            expected = files[program + ".txt"]
            if job.stdout != expected:
                raise ValueError(f"{program}: {difference(expected, job.stdout)}")
            print(f"{program}: exit 0, {len(expected)} stdout bytes match", flush=True)
        verify({p.name for p in folder.iterdir()} == SCRIPTS,
               "unexpected files were created by a certificate")
        for name in SCRIPTS:
            verify((folder / name).read_bytes() == files[name], f"replay script was modified: {name}")
        cleaned = folder
    verify(not cleaned.exists(), "temporary replay directory survived cleanup")


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--rounds", type=Path, required=True,
                        help="checkout's rounds directory, read-only")
    parser.add_argument("--work", type=Path, required=True,
                        help="existing directory under which a temporary directory is created")
    input_mode = parser.add_mutually_exclusive_group()
    input_mode.add_argument("--archive", type=Path, help="optional flat R856 ZIP")
    input_mode.add_argument("--smoke", action="store_true",
                            help="explicit pre-archive smoke from this script's scratch directory")
    args = parser.parse_args()
    work = args.work.resolve(strict=True)
    verify(work.is_dir(), "--work must be an existing directory")
    parents = verify_parents(args.rounds.resolve(strict=True))
    release, mode = read_release(args.archive, Path(__file__).resolve().parent, args.smoke)
    print("Python", sys.version.split()[0], "| parent R814 and R855 archives pinned", flush=True)
    print(mode, flush=True)
    replay(release, parents, work)
    verify_parents(args.rounds.resolve(strict=True))
    print("Verified six complete outputs; child processes exited and temporary files were removed.")


if __name__ == "__main__":
    main()
