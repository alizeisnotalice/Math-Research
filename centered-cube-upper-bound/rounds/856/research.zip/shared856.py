"""R856: exact fixed-right-source common-middle occupation and half-mass tests."""

from argparse import ArgumentParser
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
from itertools import product
from pathlib import Path
import sys


from flint import arb, ctx, __version__ as flint_version


ANCHOR_PIN="cceb24b5436e0a7c6dd49ace5aa4cb6a348a5b2f2803e14e5b59b9a224b3d61b"
MOMENTS=(1,2,4,8,16)


def aq(value):
    value=F(value)
    return arb(value.numerator)/value.denominator


def series(values,digits=8):
    return tuple(aq(x).str(digits) for x in values)


def load_dependency(path):
    content=path.read_bytes()
    assert sha256(content).hexdigest()==ANCHOR_PIN
    env={"__name__":"anchor856_fixed_input","__file__":str(path)}
    exec(compile(content,str(path),"exec"),env)
    return env


def half_cost(src,coverage,power,total):
    # Rearranging by coverage suffices: take all available source at
    # the largest values first. The actual source density is nonatomic,
    # so the required fraction of the last true cell is attainable.
    need=total/2
    amount=F(0)
    for w in sorted(coverage,key=coverage.get,reverse=True):
        p=coverage[w]**power
        if p==0 or need==0:
            break
        take=min(src[w],need/p)
        need-=take*p
        amount+=take
    assert need==0
    return amount


def middle_statistics(D,weights,src,parents):
    mass=sum(weights.values())
    law={t:v/mass for t,v in weights.items()}
    assert all(v>0 for v in law.values()) and sum(law.values())==1
    cells={mask:sum((v for t,v in law.items() if mask&parents[t]["bit"]),F(0))
           for mask in src}
    union=sum(src[w] for w,p in cells.items() if p>0)
    inter=sum(src[w] for w,p in cells.items() if p==1)
    assert 0<inter<=union
    powers={r:sum(src[w]*p**r for w,p in cells.items()) for r in MOMENTS}
    assert powers[1]==sum(v*parents[t]["m"] for t,v in law.items())
    assert union>=powers[1]>=powers[2]>=powers[4]>=powers[8]>=powers[16]>=inter

    for r in (2,4):
        explicit=F(0)
        # Direct enumeration of r original independent middle parents;
        # each intersection consists of its true source membership cells.
        for parents_r in product(law,repeat=r):
            active=0
            probability=F(1)
            for t in parents_r:
                active|=parents[t]["bit"]
                probability*=law[t]
            joint_mass=sum(v for w,v in src.items() if w&active==active)
            explicit+=probability*joint_mass
        assert explicit==powers[r]

    cost1=half_cost(src,cells,1,powers[1])
    cost8=half_cost(src,cells,8,powers[8])
    holder_square=(powers[1]/2)**2/powers[2]
    holder8=(powers[8]/2)**2/powers[16]
    assert cost1>=holder_square>0 and cost8>=holder8>0
    assert all((cost1**(r-1))*powers[r]>=(powers[1]/2)**r for r in (2,4,8,16))
    data=tuple(powers[r]/D for r in MOMENTS)
    costs=(cost1/D,holder_square/D,cost8/D,holder8/D)
    return mass,law,len([p for p in cells.values() if p]),union,inter,data,costs


def geometry(archive,anchor):
    env=load_dependency(anchor)
    stage,old95=env["load"](archive)
    parents,mids,src,_,_,_,_,_,raw,_,_=env["reconstruct"](stage,old95)
    groups=defaultdict(lambda:defaultdict(F))
    used=set()
    jumps=[]
    for (t,left,right),amount in raw.items():
        u,g=left[0],right[0]
        qmask=right[1]
        assert all(1<=parents[i]["radius"]<2 for i in (t,u,g))
        assert qmask&parents[t]["bit"] and qmask&parents[g]["bit"]
        D=parents[t]["volume_bin"]
        assert D<=parents[t]["m"]<2*D
        groups[qmask,1,D][t]+=amount
        used.update((t,u,g))
        jumps.append(parents[t]["m"]/max(parents[u]["m"],parents[g]["m"]))
    assert len(raw)==920
    total=sum(raw.values())
    q95=sum(v for (q,O,D),w in groups.items() if q==95 for v in w.values())
    assert q95==F(old95["subflow_original_mass"])
    assert sum(v for w in groups.values() for v in w.values())==total
    occupied=sum(parents[t]["bit"] for t in used)
    exact_cells=tuple((w,m) for w,m in sorted(src.items()) if w&occupied)
    assert len(exact_cells)>0 and all(m>0 for w,m in exact_cells)
    print("Pinned R814",env["PIN"],"; anchor856 source",ANCHOR_PIN)
    print("Complete 920 raw plane terms, physical radius octave [1,2), exact absolute D.")
    print("  Whole sample actual source mass",sum(src.values()),"; source mass in all used parent boxes",
          sum(m for _,m in exact_cells),"; positive membership cells",len(exact_cells))
    print("  All used positive source cells (mask, exact true mass):",
          tuple((w,str(m)) for w,m in exact_cells))
    print("  Positive fixed-q cells (mask, exact true source mass):",
          tuple((q,str(src[q])) for q in sorted({q for q,O,D in groups})))
    print("  Real ratios m_t/max(m_u,m_g) min/max",min(jumps),max(jumps),
          "; archived finite active-arm model uses no large-J qualification.")

    entries={}
    header="  q-mask, O, D; true middle law; positive cells; union/intersection mu; moments/D r=1,2,4,8,16"
    print(header)
    for (q,O,D),weights in sorted(groups.items()):
        row=middle_statistics(D,weights,src,parents)
        entries[q,O,D]=row
        s,law,n,union,inter,moments,costs=row
        assert s/src[q]>0
        print("  ",q,O,D,series(law.values()),tuple(law),n,str(union),str(inter),series(moments))
        if q==95:
            print("     q95 exact marginal density interval",aq(s/src[q]).str(9),
                  "; half p: minimum/Holder(r=2), half p^8: minimum/Holder(r=2)",
                  series(costs))

    print("  Full expanded Γ:",aq(total).str(9),"; archived q95 Γ:",aq(q95).str(9),
          "; q95 share",aq(q95/total).str(9),"; groups",len(entries))
    for name,items in (("q95",tuple(v for k,v in entries.items() if k[0]==95)),
                       ("all actual q cells",tuple(entries.values()))):
        baseline=sum(x[0] for x in items)
        means=tuple(sum(x[0]*x[5][j] for x in items)/baseline for j in range(len(MOMENTS)))
        minimum=tuple(sum(x[0]*x[6][j] for x in items)/baseline for j in range(4))
        print("  Γ-weighted ratio summary",name,"moments/D",series(means),
              "; groupwise minimum and Holder cost/D",series(minimum))
    print("r=2 and r=4 checked by explicit independent-parent tuples for every group.")


def high_dimensions():
    ctx.prec=384
    C1=arb(32)
    print("Illustrative high-load constants C1=32, H=N^4; actual J=sqrt(n)*ln(N)^8, Q=J/2, N=n+2.")
    print("Bracket r by [256*n/J,1+256*n/J]; choose gamma=exp(-J/(8r)).")
    ln10=arb(10).log()
    for k in (512,4096):
        n=2**k
        N=n+2
        lnN=arb(N).log()
        J=arb(2**(k//2))*lnN**8
        r0=256*arb(n)/J
        r1=r0+1
        assert r0>1
        # r*log(C1/gamma)=r*log(C1)+J/8 exactly.
        hi_base=-arb(3)/8
        left=hi_base+r0*C1.log()/J+C1*n/(r1*J)
        right=hi_base+r1*C1.log()/J+C1*n/(r0*J)
        gamma_low=-J/(8*r0)
        gamma_high=-J/(8*r1)
        low_load_lo=(5*lnN+gamma_low)/ln10
        low_load_hi=(5*lnN+gamma_high)/ln10
        assert left> -arb(1)/3 and right< -arb(6)/25
        assert (C1*n/(r0*J)).overlaps(arb(1)/8)
        excess_lo=r0*C1.log()/J-1/(8*r1)
        excess_hi=r1*C1.log()/J
        assert 0<excess_lo and 0<excess_hi
        assert low_load_hi< -1000
        print("  n=2^"+str(k),"log10 r lower scale",(r0.log()/ln10).str(9),
              "; relative rounding <= (1/r0)",(1/r0).str(8))
        print("     high exponent/J lower,upper:",left.str(15),right.str(15))
        print("     excess above -1/4 lower,upper:",excess_lo.str(9),excess_hi.str(9))
        print("     log10(N*H*gamma) lower,upper:",low_load_lo.str(9),low_load_hi.str(9))


if __name__=="__main__":
    parser=ArgumentParser()
    parser.add_argument("--archive",type=Path,required=True)
    args=parser.parse_args()
    ctx.prec=192
    print("Python",sys.version.split()[0],"python-flint",flint_version,"| Fraction and Arb")
    geometry(args.archive,Path(__file__).with_name("anchor856.py"))
    high_dimensions()
    print("All assertions passed. Finite fixed-q example and an illustrative asymptotic parameter check.")
