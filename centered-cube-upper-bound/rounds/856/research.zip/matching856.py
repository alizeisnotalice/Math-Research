"""Exact global versus parentwise partial matching on the reconstructed R814 flow."""
from argparse import ArgumentParser
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
from math import lcm
from pathlib import Path
from runpy import run_path
import sys


def maximum_assignment(weights):
    if not weights:
        return F(0), frozenset(), (0, 0, 0)
    aa = sorted({a for (a, _), w in weights.items() if w})
    bb = sorted({b for (_, b), w in weights.items() if w})
    n = max(len(aa), len(bb))
    base = lcm(*(x.denominator for x in weights.values()))
    cells = [[0] * n for _ in range(n)]
    ra, cb = {a: i for i, a in enumerate(aa)}, {b: j for j, b in enumerate(bb)}
    for (a, b), w in weights.items():
        assert w > 0
        cells[ra[a]][cb[b]] = w.numerator * (base // w.denominator)
    top = max(map(max, cells))
    c = [[top - a for a in row] for row in cells]
    u, v, p = [0] * (n + 1), [0] * (n + 1), [0] * (n + 1)
    for i in range(1, n + 1):
        p[0] = i
        j0 = 0
        slack = [None] * (n + 1)
        used = [False] * (n + 1)
        prior = [0] * (n + 1)
        while True:
            used[j0] = True
            i0 = p[j0]
            for j in range(1, n + 1):
                if not used[j]:
                    reduced = c[i0 - 1][j - 1] - u[i0] - v[j]
                    if slack[j] is None or reduced < slack[j]:
                        slack[j], prior[j] = reduced, j0
            j1 = min((j for j in range(1, n + 1) if not used[j]),
                     key=lambda j: (slack[j], j))
            delta = slack[j1]
            for j in range(n + 1):
                if used[j]:
                    u[p[j]] += delta
                    v[j] -= delta
                elif j:
                    slack[j] -= delta
            j0 = j1
            if not p[j0]:
                break
        while j0:
            before = prior[j0]
            p[j0] = p[before]
            j0 = before

    assert sorted(p[1:]) == list(range(1, n + 1))
    alpha = [top - vi for vi in u[1:]]
    beta = [-vi for vi in v[1:]]
    shift = min(beta)
    alpha = [x + shift for x in alpha]
    beta = [x - shift for x in beta]
    assert min(alpha + beta) >= 0
    assert all(alpha[i] + beta[j] >= cells[i][j] for i in range(n) for j in range(n))
    primal = sum(cells[p[j] - 1][j - 1] for j in range(1, n + 1))
    assert primal == sum(alpha) + sum(beta)
    assert all(x == 0 for x in alpha[len(aa):] + beta[len(bb):])
    assert primal == sum(alpha[:len(aa)]) + sum(beta[:len(bb)])
    assert all(alpha[p[j] - 1] + beta[j - 1] == cells[p[j] - 1][j - 1] for j in range(1, n + 1))
    # Zero dummy edges only complete the assignment; the paid labels stay original.
    plan = frozenset((aa[p[j] - 1], bb[j - 1]) for j in range(1, n + 1)
                     if cells[p[j] - 1][j - 1])
    assert len({a for a, _ in plan}) == len({b for _, b in plan}) == len(plan)
    value = F(primal, base)
    assert value == sum(weights[e] for e in plan)
    return value, plan, (len(aa), len(bb), base.bit_length())


def capacities(parents, raw, chosen):
    full = [defaultdict(F), defaultdict(F)]
    paid = [defaultdict(F), defaultdict(F)]
    for (t, x, y), mass in raw.items():
        for side, x0 in enumerate((x, y)):
            full[side][x0[0], x0[2]] += mass
            if (t, x, y) in chosen:
                paid[side][x0[0], x0[2]] += mass
    for a, b in zip(full, paid):
        for (u, half), w in a.items():
            assert b[u, half] <= w <= parents[u]["owner_volume"] / 2
    z = sum(raw[key] for key in chosen)
    assert all(sum(side.values()) == z for side in paid)


def audit(parents, raw, label, print_interval):
    parents_v = sorted({t for t, _, _ in raw})
    aggregate = defaultdict(F)
    by_t = {t: defaultdict(F) for t in parents_v}
    for (t, x, y), w in raw.items():
        cell = label(x), label(y)
        aggregate[cell] += w
        by_t[t][cell] += w
    global_value, global_pair, dimensions = maximum_assignment(aggregate)
    local = {t: maximum_assignment(tab) for t, tab in by_t.items()}
    local_value = sum((u[0] for u in local.values()), F(0))
    no_match = sum(raw.values())
    part_keys = {(t, x, y) for t, x, y in raw if (label(x), label(y)) in local[t][1]}
    global_keys = {(t, x, y) for t, x, y in raw if (label(x), label(y)) in global_pair}
    assert local_value == sum(raw[key] for key in part_keys)
    assert global_value == sum(raw[key] for key in global_keys)
    assert 0 < global_value <= local_value <= no_match
    capacities(parents, raw, part_keys)
    capacities(parents, raw, global_keys)
    print("  matching labels L/R, integer denominator bits:", dimensions,
          "; exact positive matches global/per-t:", len(global_pair), [len(y[1]) for y in local.values()])
    print("  paid share of selected original F: per-parent / fixed global / unconstrained:",
          print_interval(local_value / no_match), print_interval(global_value / no_match), "1")
    print("  absolute per-parent and global original payment:",
          print_interval(local_value), print_interval(global_value))
    print("  parentwise optimum versus same fixed global table by actual t:",
          [(t, print_interval(local[t][0]), print_interval(sum(
              (raw[key] for key in global_keys if key[0] == t), F(0)))) for t in parents_v])
    print("  Every reported value has equal integer primal/dual bounds and both true owner-half checks.")
    return global_pair, global_value, local_value


def label_price(x):
    return x[1]


def label_full(x):
    return x


if __name__ == "__main__":
    parser = ArgumentParser()
    parser.add_argument("--archive", required=True, type=Path, help="pinned R814 research.zip")
    argument = parser.parse_args()
    helper = Path(__file__).with_name("anchor856.py")
    model = run_path(str(helper))
    stage, qref = model["load"](argument.archive)
    parents, _, _, _, _, _, _, _, raw, _, _ = model["reconstruct"](stage, qref)
    def fmt(w):
        return model["outward"](w) if w else "0"
    print("Companion anchor856.py SHA-256:", sha256(helper.read_bytes()).hexdigest())
    print("Python", sys.version.split()[0], "Fraction and exact integer Hungarian; pin", model["PIN"])
    print("Original 4D narrow comb and full archived d; 34 cross roots, 920 positive half-box records.")
    assert len(raw) == 920
    print("I: all original records with true source-cell labels")
    coarse = audit(parents, raw, label_price, fmt)
    print("II: fixed original right source cell q=95, same data seen through each label choice")
    hard = {key: w for key, w in raw.items() if key[2][1] == 95}
    hard_mass = sum(hard.values())
    assert hard_mass == F(qref["subflow_original_mass"])
    hard_c = audit(parents, hard, label_price, fmt)
    hard_f = audit(parents, hard, label_full, fmt)
    print("III: all original records with (parent,source cell,actual owner-half) labels")
    fine = audit(parents, raw, label_full, fmt)
    for label, name, fixed, rebuilt in ((label_price, "price", coarse, hard_c),
                                       (label_full, "full half", fine, hard_f)):
        fresh = {(t, x, y) for t, x, y in hard if (label(x), label(y)) in fixed[0]}
        restricted = sum(hard[r] for r in fresh)
        capacities(parents, hard, fresh)
        assert 0 <= restricted <= rebuilt[1]
        print("q=95", name, "fixed full-data table restricted to right source / refit global on that source:",
              fmt(restricted / hard_mass), fmt(rebuilt[1] / hard_mass))
