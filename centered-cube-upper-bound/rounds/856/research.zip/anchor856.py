"""Exact anchored square-function and fixed-table audit of R814's true comb."""
from argparse import ArgumentParser
from collections import defaultdict
from decimal import Decimal, localcontext, ROUND_CEILING, ROUND_FLOOR
from fractions import Fraction as F
from hashlib import sha256
from itertools import product
from pathlib import Path
from zipfile import ZipFile
import json
import sys
import sympy

PIN = "891d8cbcbd35537e6abc18c938e53b1b4f300327357c24c8d14a51a46ad5e190"


def total(values):
    return sum(values, F(0))


def outward(lo, hi=None):
    hi = lo if hi is None else hi

    def show(x, mode):
        with localcontext() as ctx:
            ctx.prec = 9
            ctx.rounding = mode
            return f"{Decimal(x.numerator) / Decimal(x.denominator):.8E}"

    return f"[{show(lo, ROUND_FLOOR)},{show(hi, ROUND_CEILING)}]"


def load(path):
    assert sha256(path.read_bytes()).hexdigest() == PIN
    with ZipFile(path) as archive:
        manifest = json.loads(archive.read("MANIFEST.json"))
        entries = {}
        for name in ("comb811.py", "cell814.json"):
            content = archive.read(name)
            assert sha256(content).hexdigest() == manifest["members"][name]
            entries[name] = content
    env = {"__name__": "r814_fixture", "__file__": "comb811.py"}
    exec(compile(entries["comb811.py"], "comb811.py", "exec"), env)
    stage = env["fixture"](*env["FIXTURES"][-1])
    assert stage["dimension"] == 4 and stage["density"]["bump_half_width"] == F(1, 2048)
    return stage, json.loads(entries["cell814.json"])["original"]


def allowed(parents, point):
    return sum(p["bit"] for p in parents.values()
               if all(a < x < b for (a, b), x in zip(p["box"], point)))


def representatives(stage, parents, mids):
    all_faces = tuple(p["box"] for p in parents.values())
    full = sum(p["bit"] for p in parents.values())
    masks = {full: ()}
    for i in range(stage["dimension"]):
        bounds = sorted({*stage["density"]["support"],
                         *(a for parent in all_faces for a in parent[i])})
        by_axis = {}
        for a, b in zip(bounds, bounds[1:]):
            x = (a + b) / 2
            mask = sum(p["bit"] for p in parents.values() if p["box"][i][0] < x < p["box"][i][1])
            by_axis.setdefault(mask, (a, b))
        nxt = {}
        for old, rectangle in masks.items():
            for membership, interval in by_axis.items():
                nxt.setdefault(old & membership, rectangle + (interval,))
        masks = nxt
    midbits = sum(parents[t]["bit"] for t in mids)
    reps = {}
    for mask in sorted(masks):
        sig = mask & midbits
        if not sig or sig in reps:
            continue
        rectangle = masks[mask]
        points = []
        for j in (1, 2):
            point = tuple(a + (b - a) * F(j if i == 0 else 1, 3 if i == 0 else 2)
                          for i, (a, b) in enumerate(rectangle))
            assert allowed(parents, point) == mask
            points.append(point)
        assert points[0] != points[1]
        reps[sig] = points
    return reps, midbits


def reconstruct(stage, check95):
    parents = {p["id"]: p for p in stage["parents"]}
    mids = sorted(p["id"] for p in parents.values() if p["role"] == "middle")
    old = sorted(p["id"] for p in parents.values() if p["role"] == "old")
    src = {cell["mask"]: cell["mass"] for cell in stage["cells"]}
    reps, midbits = representatives(stage, parents, mids)
    box_bits = {key: p["bit"] for key, p in parents.items()}
    I = {t: parents[t]["j"] for t in mids}
    d = {t: parents[t]["full_d"] for t in mids}
    alternate = {t: parents[t]["old_d"] for t in mids}
    assert d == {t: stage["degrees"][t]["full_d"] for t in mids}
    assert all(d[t] > alternate[t] > 0 for t in mids)
    for p in parents.values():
        assert total(mass for mask, mass in src.items() if mask & p["bit"]) == p["m"]
    lam = {}
    for u in old:
        q = parents[u]
        for z, mass in src.items():
            if z & q["bit"]:
                for side in (0, 1):
                    lam[u, z, side] = q["j"] * mass / (2 * q["m"])
    for u in old:
        assert total(amt for (g, _, _), amt in lam.items() if u == g) == parents[u]["j"]
    h = {t: set() for t in mids}
    for t in mids:
        for key in lam:
            u, z, _ = key
            if u in stage["degrees"][t]["old_terms"] and z & box_bits[t]:
                h[t].add(key)
        assert total(lam[key] for key in h[t]) / parents[t]["m"] == alternate[t]
    raw = {}
    from95 = defaultdict(F)
    assert len(stage["roots_cross"]) == 34
    for root in stage["roots_cross"]:
        t, u, g = (root[key] for key in ("t", "u", "g"))
        mark = F(1, parents[t]["m"] ** 2 * d[t])
        orig = F(0)
        for z, q, b, w in product(root["z_masks"], root["q_masks"], (0, 1), (0, 1)):
            x, y = (u, z, b), (g, q, w)
            assert x in h[t] and y in h[t]
            value = I[t] * mark * lam[x] * lam[y]
            assert value > 0
            raw[t, x, y] = value
            orig += value
            if q == 95:
                from95[t, u, g, z] += value
        assert orig == root["root_mass"]
    old95 = {(r["t"], r["left_parent"], r["right_parent"], r["z_mask"]): F(r["weight"])
             for r in check95["rows"]}
    assert from95 == old95
    assert total(from95.values()) == F(check95["subflow_original_mass"])
    assert total(raw.values()) == stage["benchmarks"]["cross"]["mother"]
    return parents, mids, src, I, d, alternate, lam, h, raw, reps, midbits


def spectral(mids, parents, lam, h, I, degree, active, prefix):
    if not active:
        return
    a = {t: I[t] / (parents[t]["m"] ** 2 * degree[t]) for t in active}
    c = {(t, s): total(lam[i] for i in h[t] & h[s]) for t, s in product(active, repeat=2)}
    trace = total(c[t, t] * a[t] for t in active)
    assert trace > 0

    def rational(value):
        return sympy.Rational(value.numerator, value.denominator)

    matrix = sympy.Matrix([[rational(c[t, s] * a[s] / trace) for s in active] for t in active])
    roots = matrix.charpoly().as_poly().intervals(eps=sympy.Rational(1, 10 ** 9))
    intervals = [(max(F(0), F(int(a0.p), int(a0.q))), F(int(b0.p), int(b0.q)))
                 for ((a0, b0), count) in roots for _ in range(count)]
    assert len(intervals) == len(active) and all(0 <= lo <= hi <= 1 for lo, hi in intervals)
    assert total(lo for lo, _ in intervals) <= 1 <= total(hi for _, hi in intervals)
    print("  ", prefix, list(active), "trace/independent row budgets", outward(trace),
          "; exact eigenvalues/trace", [outward(lo, hi) for lo, hi in intervals],
          "; fixed single L2 budget optimum", outward(*(trace * x for x in intervals[-1])))
    return trace, intervals[-1]


def tables(parents, mids, raw, reps, midbits, h):
    observe = defaultdict(set)
    for t, row in h.items():
        for X in row:
            observe[X].add(t)
    shared = next((x, sorted(ts)) for x, ts in sorted(observe.items()) if len(ts) >= 2)
    assert len({tuple(parents[t]["center"]) for t in shared[1]}) == len(shared[1])
    for t in mids:
        assert allowed(parents, tuple(parents[t]["center"])) & parents[t]["bit"]
    lo_bin = min(p["volume_bin"] for p in parents.values() if p["role"] == "old")

    def probabilities(X, with_receiver):
        u, z, side = X
        sig = z & midbits
        if with_receiver:
            coeffs = (F(side == 0), F(side == 1))
        else:
            coeffs = (F(3, 5), F(4, 5))
            if parents[u]["volume_bin"] != lo_bin:
                coeffs = coeffs[::-1]
        assert sum(x ** 2 for x in coeffs) == 1
        return {(sig, i): root for i, root in enumerate(coeffs) if root}

    print("  same visible X across different t (invalid temporary-parent lookup):", shared)
    print("  a common positive source-cell signature covers all middle parents:", midbits in reps)
    bases = [defaultdict(F), defaultdict(F)]
    for (t, x, y), weight in raw.items():
        for i, X in enumerate((x, y)):
            bases[i][X[0], X[2]] += weight
    M = total(raw.values())
    assert midbits in reps
    universal_p = reps[midbits][0]
    assert all(allowed(parents, universal_p) & parents[t]["bit"] for t, _, _ in raw)
    assert all(amt <= parents[u]["owner_volume"] / 2 for side in bases for (u, _), amt in side.items())
    print("  bare label and owner constraints admit a constant common anchor, paid/F=1, p=", universal_p)
    print("  original cross mother F:", outward(M))
    witness = None
    for receiver in (False, True):
        collected = [defaultdict(F), defaultdict(F)]
        amount = product_amount = F(0)
        for (t, x, y), weight in raw.items():
            a, b = map(lambda X: probabilities(X, receiver), (x, y))
            shared = [label for label in a.keys() & b.keys()
                      if allowed(parents, reps[label[0]][label[1]]) & parents[t]["bit"]]
            hit = total(a[label] * b[label] for label in shared)
            independent = total((a[label] * b[label]) ** 2 for label in shared)
            assert 0 <= independent <= hit <= 1
            assigned = weight * hit
            amount += assigned
            product_amount += weight * independent
            for i, X in enumerate((x, y)):
                collected[i][X[0], X[2]] += assigned
            if witness is None and 0 < independent < hit:
                witness = t, x, y, weight, hit, weight * hit, weight * independent
        for side in (0, 1):
            assert total(collected[side].values()) == amount
            for receiver_half, charge in collected[side].items():
                assert charge <= bases[side][receiver_half] <= parents[receiver_half[0]]["owner_volume"] / 2
        ratios = [max(2 * amt / parents[u]["owner_volume"] for (u, _), amt in marginal.items())
                  for marginal in collected]
        print("  fixed table", "with true U/W half" if receiver else "own parent/source only",
              "paid/F and ordinary product/F", outward(amount / M), outward(product_amount / M),
              "; paid original", outward(amount))
        print("    max densities relative to both true disjoint receiver Lebesgue marginals:",
              *(outward(x) for x in ratios))
    assert witness is not None
    t, x, y, weight, hit, paid, wrong = witness
    print("  actual positive branch t, (u,zmask,U-half), (g,qmask,W-half):", t, x, y,
          "; Hellinger weight", hit)
    print("    two actual anchor coordinates:", reps[x[1] & midbits])
    print("    original, paid, product-paid exact:", weight, paid, wrong)


if __name__ == "__main__":
    parser = ArgumentParser()
    parser.add_argument("--archive", required=True, type=Path, help="rounds/814/research.zip at pinned digest")
    stage, check95 = load(parser.parse_args().archive)
    parents, mids, src, I, d, alt, lam, h, raw, reps, midbits = reconstruct(stage, check95)
    print("Python", sys.version.split()[0], "SymPy", sympy.__version__, "exact Fraction/real-root isolation.")
    print("Pinned R814 archive:", PIN)
    print("True 4D comb width=1/2048, 34 cross-bin roots, exact archived q=95 branch projection.")
    print("Archived diagnostic active-arm chi only; high-dimensional history predicates untested.")
    print("Mothers, observed arms, true price cells:", len(raw), len(lam), len(src))
    for t in mids:
        print("  t,I(v),m_t,d_full,d_old:", t, I[t], parents[t]["m"], d[t], alt[t])
    print("GRAM (T T*): supplier weight lambda=(j_u/m_u)*mu(cell)/2 per true half.")
    full_trace, full_top = spectral(mids, parents, lam, h, I, d, mids, "no anchor/full degree")
    for sig in sorted(reps):
        group = [t for t in mids if sig & parents[t]["bit"]]
        spectral(mids, parents, lam, h, I, d, group, f"fixed true source p/signature {sig}")
    old_trace, old_top = spectral(mids, parents, lam, h, I, alt, mids, "post-gate old-degree renormalization")
    print("  replacing d by old_d multiplies trace by", outward(old_trace / full_trace),
          "and top eigenvalue by",
          outward(old_trace * old_top[0] / (full_trace * full_top[1]),
                  old_trace * old_top[1] / (full_trace * full_top[0])))
    print("FIXED PROBABILITY TABLES: temporary per-parent ideal=1, with incompatible observation lookup.")
    print("Same-signature anchors are two distinct real points in one positive source cell.")
    print("Own-parent/source table uses square weights (9/25,16/25), possibly exchanged by small-parent bin.")
    print("Real-receiver table selects the matching public label from its original owner half.")
    tables(parents, mids, raw, reps, midbits, h)
