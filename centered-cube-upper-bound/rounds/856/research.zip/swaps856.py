"""R856: fixed real q cross-centre recapture and same-Xi refresh."""

from argparse import ArgumentParser
from decimal import Decimal, localcontext
from fractions import Fraction as F
from hashlib import sha256
from itertools import product
from pathlib import Path
from zipfile import ZipFile
import sys


PIN = "9c21d7d15028d512d89bd69416d6d03f47d48ce891f4adbfaeefdf8a00624814"
SQRT2 = (F(1414213,10**6),F(1414214,10**6))
RATIO = F(9,8)


def show(x):
    with localcontext() as c:
        c.prec=10
        return str(Decimal(x.numerator)/Decimal(x.denominator))


def archive(path):
    assert sha256(path.read_bytes()).hexdigest()==PIN
    with ZipFile(path) as bundle:
        raw=bundle.read("joint855.py")
    env={"__name__":"joint855_replay_dependency","__file__":"joint855.py"}
    exec(compile(raw,"joint855.py","exec"),env)
    return env


def contains_all(center,core,x,packet,radius):
    distance=abs(x-center)
    error=core+packet
    if distance+error < radius[0]:
        return True
    assert distance-error>radius[1]
    return False


def whitney(center,core,x,packet,side):
    d=abs(x-center)
    e=core+packet
    assert e<d
    near = (F(1,2)-(d+e)/side[0],F(1,2)-(d-e)/side[1])
    assert 0<near[0]<=near[1]<F(1,2)
    depth=0
    bound=F(1,2)
    while near[1]<bound/RATIO:
        depth+=1
        bound/=RATIO
    assert bound/RATIO<near[0]<=near[1]<bound
    return ("+" if center>x else "-",depth)


def coupling(weights,hit):
    # Fixed j, two exact endpoints and two exact Whitney cells.
    # Each block weight is the original k_Xi integral on that block.
    total=sum(weights)
    joint={(i,j):a*b/total for (i,a),(j,b) in product(enumerate(weights),repeat=2)}
    for i,a in enumerate(weights):
        assert sum(joint[i,j] for j in range(len(weights)))==a
        assert sum(joint[j,i] for j in range(len(weights)))==a
    fresh=sum(v for (i,j),v in joint.items() if not hit[i] and hit[j])/total
    lost=sum(v for (i,j),v in joint.items() if hit[i] and not hit[j])/total
    capture=sum(w for w,h in zip(weights,hit) if h)/total
    assert fresh==lost==capture*(1-capture)
    assert sum(v for (i,j),v in joint.items() if hit[i] or hit[j])/total==capture+fresh
    return capture,fresh,capture+fresh


def archived_probe(env):
    n=4
    root_raw,correction,branch=env["geometry"](n)
    e,h=env["SOURCE_HALF"],env["ROOT_HALF"]
    theta=env["LABEL_MID"]
    s,q,p=-2*theta,2*theta,F(1,4)
    Uearly=(F(1),F(1))
    top=(env["lower_bin_side"](n)/2,F(1))
    low_center=theta
    low_margin=env["CHILD_STEP"]+2*env["CHILD_HALF"]
    top_labels=(whitney(F(0),h,s,e,(F(2),)*2),whitney(F(0),h,q,e,(F(2),)*2))
    low_labels=(whitney(low_center,low_margin,p,e,Uearly),
                whitney(low_center,low_margin,q,e,Uearly))
    assert contains_all(low_center,low_margin,p,e,(F(1,2),)*2)
    assert contains_all(low_center,low_margin,q,e,(F(1,2),)*2)
    assert contains_all(F(0),h,s,e,top) and contains_all(F(0),h,q,e,top)
    assert contains_all(F(0),h,p,e,top)
    assert not contains_all(low_center,low_margin,s,e,(F(1,2),)*2)
    assert coupling(branch[1],(False,False))==(0,0,0)
    print("Archived local probe, n=4, actual bins (4,0). Whitney labels valid on both real old cores.")
    print("  top labels",top_labels,"; lower labels",low_labels,"; given fixed q packet centre",q)
    print("  Large->small 0, small->large 1, swapped geometric support 0; same-Xi new capture 0.")
    print("  Parent mark and denominator use pinned joint855 geometry, lower q-arm raw weights",branch[1])


def constructed(n,k_hit):
    assert SQRT2[0]**2<2<SQRT2[1]**2
    ep=F(1,8192)
    e=F(1,16384)
    s,q,p=F(-133,256), F(77,128), F(-1,4)
    high=F(0)
    low_mid=F(3,16)
    shift=F(1,1024)
    early=(low_mid-shift,low_mid+shift)
    assert all(b-a>2*ep for a,b in zip(sorted((s,p,q)),sorted((s,p,q))[1:]))
    assert all(b-a>2*e for a,b in zip((high,*early),early))
    assert max(abs(v) for v in (high,*early))+e+1<4
    high_radius=(F(1),)*2
    old_radius=tuple(u/2 for u in SQRT2)
    assert all(contains_all(high,e,a,ep,high_radius) for a in (s,p,q))
    assert all(contains_all(c,e,a,ep,old_radius) for c,a in product(early,(p,q)))
    hit=tuple(contains_all(c,e,s,ep,old_radius) for c in early)
    assert hit==(True,False)
    top_labels=tuple(whitney(high,e,a,ep,(F(2),)*2) for a in (s,q))
    # Re-draw only within Xi of the original left packet p and common q.
    low_labels=tuple(whitney(low_mid,shift+e,a,ep,SQRT2) for a in (p,q))
    assert all(tuple(whitney(c,e,a,ep,SQRT2) for a in (p,q))==low_labels for c in early)

    # All actual rows share q, lambda=1, and one physical source cut:
    # sigma=3/2 on [-4,4]^n, eta restricted to the three packets.
    # Root true sides 2, early sqrt(2); n even gives rational volumes.
    D_high=F(2)**n
    D_low=F(2)**(n//2)
    m=F(3,2)*(2*ep)**n
    E=(2*e)**n
    base_h=E*m/D_high**2
    base_l=E*m/D_low**2
    # G above: marks read on the physical recipient AND real left end.
    # High G values for (s,p) are (1,1/2); early accepted block has
    # k_hit for both, early missed block has G(p)=1 and s absent.
    k_high_p=F(1,2)
    high_s=base_h
    high_p=base_h*k_high_p
    low_p=(base_l*k_hit,base_l)
    low_s=(base_l*k_hit,F(0))
    r_total=high_s+high_p+sum(low_p)+sum(low_s)
    assert r_total>0 and all(w>0 for w in low_p)
    assert sum(low_p)/r_total<1
    # Two actual draws under R_q/R_q(all), then condition on
    # first (higher j,s packet) and second (lower j,p packet).
    ordered_stratum=high_s*sum(low_p)/r_total**2
    assert 0<ordered_stratum<1
    capture,new,best=coupling(low_p,hit)
    assert capture==k_hit/(1+k_hit)
    weighted_swap=capture*k_hit*k_high_p
    early_geometric_left=E/D_low**2
    assert early_geometric_left>0 and low_s[0]==early_geometric_left*m*k_hit

    print("Constructed dimension",n,"true bins",(n,n//2),"with original kappa(hit,miss)",(k_hit,F(1)))
    print("  Same actual q and unchanged Whitney labels:",top_labels,low_labels)
    print("  Fixed-q whole raw row",show(r_total),"; ordered-stratum probability",show(ordered_stratum))
    print("  Early physical cross-section fraction 1/2; actual-raw capture",capture,
          "; reverse geometric capture 1; swap support pass",capture,
          "; weighted by swapped kappas",weighted_swap)
    print("  Same-Xi refresh, both original receiver marginals checked exactly:",
          "gained =",new,"= lost; old/new total =",capture,
          "; fresh hit given initial miss",new/(1-capture))
    print("  Best-of-two interpolation would score",best,
          "and assign a larger marginal to the capture core.")
    print("  Unconditional ordered cross hit on fixed-q row",show(ordered_stratum*capture),
          "; gain and loss on that whole row",show(ordered_stratum*new),
          "; early original row for upper left source",show(sum(low_s)))


if __name__=="__main__":
    parser=ArgumentParser()
    parser.add_argument("--handoff",type=Path,required=True)
    args=parser.parse_args()
    print("Python",sys.version.split()[0],"| exact Fraction and strict rational sqrt(2) geometry")
    print("Pinned R855 ZIP",PIN)
    env=archive(args.handoff)
    archived_probe(env)
    for n,w in ((8,F(1,3)),(64,F(1,31)),(256,F(1,31))):
        constructed(n,w)
    print("All assertions passed. Positive boxes and local fixed-q conditioning; finite geometry scope.")
