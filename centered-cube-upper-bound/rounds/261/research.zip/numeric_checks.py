#!/usr/bin/env python3
"""R261 exact bounded suffix pair and deletion-cap diagnostics; no FULL."""
import argparse,hashlib,json
from pathlib import Path
from fractions import Fraction as F

def fs(x):return str(x.numerator)+'/'+str(x.denominator)
def prod(v):
    z=F(1)
    for x in v:z*=x
    return z

def w(A,t):return prod(min(F(1),a/t)for a in A)
def score(A,t):return sum(a<t for a in A)
def events(B,C):return sorted({F(1,2),F(1)}|{a for a in B+C if F(1,2)<a<1})
def integral_piece(B,C,left,right):
    mid=(left+right)/2;kb=score(B,mid);kc=score(C,mid);den=kb+kc
    return F(0)if den==0 else F(kb-kc,den)*(w(B,left)*w(C,left)-w(B,right)*w(C,right))
def suffix_data(B,C):
    knots=events(B,C);U={knots[-1]:F(0)}
    for left,right in reversed(list(zip(knots,knots[1:]))):U[left]=U[right]+integral_piece(B,C,left,right)
    def at(t):
        if t in U:return U[t]
        for a,b in zip(knots,knots[1:]):
            if a<t<b:return U[b]+integral_piece(B,C,t,b)
        raise ValueError(t)
    return knots,U,at

def pair_menu():
    rows=[]
    for phase,n in [('initial',2),('stress',8),('expanded',32)]:
        rows.extend([(phase,n,'ordered', [F(1,2)]*n,[F(1)]*n),(phase,n,'identical',([F(1,4),F(1,2),F(3,4),F(1)]*(n//4+1))[:n],([F(1,4),F(1,2),F(3,4),F(1)]*(n//4+1))[:n]),(phase,n,'reverse_rejected',[F(1)]*n,[F(1,2)]*n),(phase,n,'nonmonotone_short_negative',[F(1,2)+F(1,64*n)]*n,[F(1,2)]*(n//2)+[F(7,8)]*(n//2)),(phase,n,'nonmonotone_long_negative_rejected',[F(3,4)]*n,[F(1,2)]*(n//2)+[F(7,8)]*(n//2)),(phase,n,'threshold_endpoints',[F(1,4)]*(n//2)+[F(1,2)]*(n//2),[F(3,4)]*(n//2)+[F(1)]*(n//2))])
    return rows

def pair_checks():
    rows=[]
    for phase,n,name,B,C in pair_menu():
        assert len(B)==len(C)==n and all(F(1,4)<=a<=1 for a in B+C)
        knots,Uk,U=suffix_data(B,C);eligible=all(v>=0 for v in Uk.values());ratio1=w(C,F(1))/w(B,F(1));alpha=1/ratio1
        mids=[(a+b)/2 for a,b in zip(knots,knots[1:])];samples=sorted(set(knots+mids));checks=[];differences=[score(B,t)-score(C,t)for t in mids]
        for s in samples:
            wb=w(B,s);wc=w(C,s);u=U(s);bound=wb*wc-alpha*wc*wc;odds=wc/wb;gap=bound-u
            if eligible:assert u>=0 and gap>=0 and odds<=ratio1
            checks.append({'s':fs(s),'U':fs(u),'product':fs(wb*wc),'squared_bound':fs(bound),'bound_minus_U':fs(gap),'odds':fs(odds),'terminal_odds_minus_current':fs(ratio1-odds),'improvement_over_product_bound':fs(alpha*wc*wc)})
        increases=any(a<b for a,b in zip(differences,differences[1:]));decreases=any(a>b for a,b in zip(differences,differences[1:]));nz=[(v>0)-(v<0)for v in differences if v]
        rows.append({'phase':phase,'n':n,'name':name,'B_thresholds':list(map(fs,B)),'C_thresholds':list(map(fs,C)),'knots':list(map(fs,knots)),'U_at_knots':[fs(Uk[t])for t in knots],'suffix_eligible_alltime':eligible,'suffix_certificate_method':'U has fixed derivative sign on each score-constant interval; nonnegative endpoint values certify every s.','interval_score_differences':differences,'score_difference_not_monotone':increases and decreases,'score_sign_changes':sum(a!=b for a,b in zip(nz,nz[1:])),'samples':checks,'sample_min_squared_bound_margin':fs(min(F(c['bound_minus_U'])for c in checks)),'terminal_odds':fs(ratio1),'scope':'Candidate inequalities asserted only for suffix-eligible finite pairs. Endpoint/midpoint candidate checks are finite, not a general proof.'})
    return rows

def ccap_piece(mass,wc1,BT,BH):
    if BH==0:
        assert BT==0
        return F(0)
    return mass*wc1*BT*BT/BH

def deletion_checks():
    rows=[]
    for phase,n in [('initial',2),('stress',8),('expanded',32)]:
        B=[F(1,2)]*n;goods=[([F(1)]*n,F(8)),([F(7,8)]*n,F(4))];t=F(5,8);WB=w(B,t);WGs=sum(mass*w(C,t)for C,mass in goods);post=WB+WGs
        Utotal=F(0);L=F(0)
        for C,mass in goods:
            knots,vals,U=suffix_data(B,C);assert all(v>=0 for v in vals.values());Utotal+=mass*U(t);L+=mass*(WB*w(C,t)-w(B,F(1))/w(C,F(1))*w(C,t)**2)
        assert Utotal==L>=0
        graph_L=WB*WGs;graph_S=sum(mass*w(C,t)**2*w(B,F(1))/w(C,F(1))for C,mass in goods)
        graph_Ccap=sum(ccap_piece(mass,w(C,F(1)),WB,w(B,F(1)))for C,mass in goods)
        quadratic=graph_L-graph_L**2/graph_Ccap
        assert Utotal<=graph_L-graph_S<=quadratic<=graph_Ccap/4
        graph_nodes=[{'good_mass':fs(mass),'good_current_weight':fs(w(C,t)),'good_terminal_weight':fs(w(C,F(1))),'BTZ':fs(WB),'BHZ':fs(w(B,F(1)))}for C,mass in goods]
        for label,removed in [('unpaid_small_delete',F(1,100)),('paid_large_delete',256/WB)]:
            pre=post+removed;delta_inv=1/post**2-1/pre**2;jumpFB=WB*removed/(pre*post);recovery=delta_inv*Utotal;upper=delta_inv*L;threshold=WB*pre*post/(pre+post)
            cap=L<=threshold;absorbed=upper<=jumpFB
            assert cap==absorbed and recovery<=upper
            assert cap==(label=='paid_large_delete')
            quadratic_net=delta_inv*quadratic-jumpFB;actual_net=recovery-jumpFB;automatic=graph_Ccap/(4*WB)*(1/post+1/pre)
            assert actual_net<=quadratic_net
            if automatic<=1:assert quadratic_net<=0
            rows.append({'phase':phase,'n':n,'label':label,'clock':['1/2','1/1'],'delete_time':fs(t),'terminal_B_thresholds':list(map(fs,B)),'terminal_good_sources':[{'mass':fs(mass),'thresholds':list(map(fs,C))}for C,mass in goods],'future_deleted_E':{'mass':fs(removed),'thresholds':['1/1']*n},'WB':fs(WB),'current_WG':fs(WGs),'e_pre':fs(pre),'e_post':fs(post),'suffix_sum_U':fs(Utotal),'squared_bound_L':fs(L),'naive_product_bound':fs(WB*WGs),'improvement_naive_minus_L':fs(WB*WGs-L),'delta_e_inverse_square':fs(delta_inv),'recovery_atom':fs(recovery),'recovery_upper':fs(upper),'delta_FB':fs(jumpFB),'exact_cap_threshold':fs(threshold),'cap_holds':cap,'absorption_margin_deltaFB_minus_upper':fs(jumpFB-upper),'suffix_graph_nodes':graph_nodes,'graph_L':fs(graph_L),'graph_S':fs(graph_S),'graph_Ccap':fs(graph_Ccap),'graph_L_minus_S':fs(graph_L-graph_S),'graph_quadratic_bound_L_minus_Lsquare_over_Ccap':fs(quadratic),'graph_Ccap_quarter':fs(graph_Ccap/4),'actual_net_recovery_minus_jump':fs(actual_net),'quadratic_net_recovery_upper':fs(quadratic_net),'automatic_criterion_value':fs(automatic),'automatic_criterion_holds':automatic<=1,'actual_net_absorbed':actual_net<=0,'scope':'One decreasing finite carrier, terminal B/G never deleted. Toy endpoint 1; no identification of original h with g and B/G are fixed labels, not certified original good/high gates; no FULL/history qualification.'})
    return rows

def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));a=p.parse_args();assert ccap_piece(F(1),F(1),F(0),F(0))==0;pairs=pair_checks();deletes=deletion_checks();eligible=[r for r in pairs if r['suffix_eligible_alltime']]
    result={'schema':'R261-exact-suffix-v2','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'counts':{'pair_cases':len(pairs),'suffix_eligible_pairs':len(eligible),'suffix_ineligible_pairs':len(pairs)-len(eligible),'eligible_nonmonotone_score_pairs':sum(v['score_difference_not_monotone']for v in eligible),'eligible_endpoint_midpoint_checks':sum(len(v['samples'])for v in eligible),'deletion_cases':len(deletes),'paid_deletion_caps':sum(v['cap_holds']for v in deletes),'unpaid_deletion_caps':sum(not v['cap_holds']for v in deletes),'jump_graph_chain_checks':len(deletes),'automatic_absorption_criterion_holds':sum(v['automatic_criterion_holds']for v in deletes),'Ccap_zero_convention_checks':1},'pairs':pairs,'deletions':deletes,'minimum_eligible_sample_margin':fs(min(F(v['sample_min_squared_bound_margin'])for v in eligible)),'scope':'All numeric comparisons are exact Fraction. Suffix predicate certified alltime for these finite rational laws; finite candidate checks and cap examples are not a proof of general/original FULL lemma. Original h/g distinction and source qualifications are not modeled.'}
    a.output.write_text(json.dumps(result,ensure_ascii=False,sort_keys=True,indent=2)+'\n');print(json.dumps({'counts':result['counts'],'minimum_eligible_sample_margin':result['minimum_eligible_sample_margin']}))
if __name__=='__main__':main()
