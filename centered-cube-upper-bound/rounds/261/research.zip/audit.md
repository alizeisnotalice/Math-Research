# R261 独立审查

审查者Sol high，r217_audit，先独立检查精确命题，未把作者结论当证据；后读最终LaTeX全文。来源审查由另一Sol r217_compare完成，主代理复核原R223/R170片段。

1. 原后缀条件：每一后缀U≥0且端点真实h。独立令q=B/C，得U'=C²q'，Stieltjes分部给q(t)−q(h)=U(t)/C(t)²+∫U d(C^-2)。因此端点二次界正确，不能只用初端U≥0。单阈值B=1/t,C=1给尖锐权重例，非FULL。
2. 保原图Cauchy：BhZ=0⇒BtZ=0；L²≤SC，UΣ≤L−S≤L−L²/C≤C/4。C0单列。另一bad行平方Qrow亦正确；图边不得补齐。
3. t≤h≤g且G/B同一terminal集合不删；wt/wh≤(h/t)^n，good桥∫Gwh≤(g/h)^nKq/p，故C≤WB(g/t)^nKq/p正确。没有补造h时good≤1/2。
4. 真实删除净额Δ(e^-2)H−ΔFB，阈值WB e−e+/(e−+e+)和ratio正确。零跳/WB0直接零；p0先排。仅同一图同一原子的储备一份。
5. 窄读R123 current_ledger G123-2，确认原门以[τ,h]定义。R223 NC8补域1−Ψ=Zcal，故261.8与实际signed回代方向正确。端点、内部删除跳、连续恢复、Ndel区别完整。
6. 主稿末读PASS。唯一可读性建议已落实：在261.6旁再次说明C0的L−L²/C分支取零。没有宣称连续恢复已付，没有一般root误报。

代理另做有限诊断只辅助独审；本轮可复现数字只以归档numeric_checks.py及JSON为准。主代理读完整脚本，纠正结果字段terminal_WG为current_WG，并明确B/G标签不认证原good/high。该改动不改变计算。
