"""Exact alternating fibre pruning on the same R850 true-box terminal flows."""
from argparse import ArgumentParser
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
from itertools import product
from pathlib import Path
from zipfile import ZipFile
import sys

PIN = "d7e0cc5e31eb94cd6bb536dca40af122bc4793adfdf0dfb43e0e2b94be01c674"


def fixture(path):
    assert sha256(path.read_bytes()).hexdigest() == PIN
    with ZipFile(path) as archive:
        name = "handoff850.py"
        module = {"__name__": "same_box_dependency", "__file__": name}
        exec(compile(archive.read(name), name, "exec"), module)
    return module


def original(module, rows, n, h, depth):
    p, bare, d, _ = module["kernels"](rows, n, h)
    k = [{end ^ 1: prob for end, prob in row.items()} for row in p]
    powers = module["powers"](k)
    death = [1 - sum(row.values()) for row in p]
    future = []
    for y in range(len(p)):
        value = sum(r * death[end] for level in powers[depth - 1:]
                    for end, r in level[y].items())
        assert value == sum(powers[depth - 1][y].values())
        future.append(value)
    assert len(rows) * 2 == len(p)
    frozen = [defaultdict(F), defaultdict(F)]
    for side in (0, 1):
        for i, root in enumerate(rows):
            for y, proposed in bare[2 * i + side].items():
                assert y % 2 != side
                assert proposed == rows[y // 2].fraction / d
                frozen[side][y // 2] += root.fraction * proposed
    helper = [defaultdict(F), defaultdict(F)]
    for side in (0, 1):
        for index, mass in frozen[side].items():
            b = mass / rows[index].fraction
            assert 0 < b <= 1
            j = rows[index].bin
            assert j not in helper[side] or helper[side][j] == b
            helper[side][j] = b
    flow = {}
    for i, root in enumerate(rows):
        left, right = p[2 * i], p[2 * i + 1]
        for y, first in left.items():
            for z, second in right.items():
                value = root.fraction * first * future[y] * second * future[z]
                if value:
                    flow[i, y // 2, z // 2] = value
    assert flow
    for side in (0, 1):
        mass = group(flow, side)
        assert all(0 < value <= frozen[side][y] for y, value in mass.items())
    return flow, frozen, helper


def group(flow, side):
    weights = defaultdict(F)
    for key, value in flow.items():
        weights[key[side + 1]] += value
    return weights


def low(mass, frozen, theta):
    return {y for y, value in mass.items() if 0 < value < frozen[y] * theta}


def two_way(rows, packet, y, frozen, mass, theta):
    b_y = frozen / rows[y].fraction
    assert 0 <= mass <= frozen and 0 < b_y <= 1
    p_B = mass / frozen
    W = rows[y].g * packet * p_B
    Gamma = rows[y].g * packet * theta
    kappa = b_y * rows[y].g * p_B
    assert 0 <= kappa <= 1 and W / (rows[y].g * packet) == p_B
    row_degree = kappa * packet
    column_degree = kappa * packet  # both real source packets have mass packet
    assert row_degree == b_y * W
    assert (p_B < theta) == (W < Gamma) == (column_degree < b_y * Gamma)
    return p_B, b_y, kappa, row_degree


def audit_physical_ratio(rows, packet, frozen, thresholds, flows):
    for side in (0, 1):
        for y, B in group(flows, side).items():
            two_way(rows, packet, y, frozen[side][y], B, thresholds[side])


def prune(rows, packet, base, frozen, theta):
    initial = [group(base, i) for i in (0, 1)]
    flags = [low(initial[i], frozen[i], theta[i]) for i in (0, 1)]
    static_union = sum(value for (_, y, z), value in base.items()
                       if y in flags[0] or z in flags[1])
    static_side = [sum(initial[i][y] for y in flags[i]) for i in (0, 1)]
    live = base.copy()
    charged = [defaultdict(F), defaultdict(F)]
    removed_keys = set()
    charged_fibres = [set(), set()]
    sweeps = []
    for sweep in range(1, len(rows) * 2 + 1):
        round_record = []
        for side in (0, 1):
            groups = group(live, side)
            cut = low(groups, frozen[side], theta[side])
            reverse_cut = {y for y, amt in groups.items() if two_way(
                rows, packet, y, frozen[side][y], amt, theta[side])[3]
                < frozen[side][y] / rows[y].fraction * rows[y].g * packet * theta[side]}
            assert cut == reverse_cut
            assert not cut & charged_fibres[side]
            charged_fibres[side] |= cut
            old = sum(groups[y] for y in cut)
            round_record.append((len(cut), old))
            for key in tuple(live):
                if key[side + 1] in cut:
                    assert key not in removed_keys
                    removed_keys.add(key)
                    charged[side][key[0]] += live.pop(key)
            assert old <= sum(frozen[side][y] * theta[side] for y in cut)
        if not any(size for size, _ in round_record):
            break
        sweeps.append(round_record)
    else:
        raise AssertionError("did not reach the fixed point")
    cap = [sum((frozen[i][y] * theta[i] for y in charged_fibres[i]), F(0)) for i in (0, 1)]
    first_delete = [sum(x.values(), F(0)) for x in charged]
    assert all(real <= bound for real, bound in zip(first_delete, cap))
    assert all(not low(group(live, i), frozen[i], theta[i]) for i in (0, 1))
    assert len(removed_keys) + len(live) == len(base)
    assert sum(base[key] for key in removed_keys) == sum(first_delete)
    assert static_union <= sum(first_delete) == sum(base.values()) - sum(live.values())
    for root in range(len(rows)):
        mass = sum(x for (i, _, _), x in base.items() if i == root)
        remains = sum(x for (i, _, _), x in live.items() if i == root)
        assert remains + sum(c[root] for c in charged) == mass <= rows[root].fraction
    audit_physical_ratio(rows, packet, frozen, theta, base)
    audit_physical_ratio(rows, packet, frozen, theta, live)
    return live, static_side, static_union, sweeps, first_delete, cap, charged


def index(rows, slot):
    return next(i for i, row in enumerate(rows) if row.slot == slot and row.x == 0)


def run(module, n, h, depth, theta):
    rows, _, packet = module["real_fixture"](n)
    base, frozen, b = original(module, rows, n, h, depth)
    live, side, union, sweeps, first, budget, charges = prune(rows, packet, base, frozen, theta)
    print(f"n={n}, H/t={h}, both arms require total r>={depth}, θ(left,right)={theta}")
    fu = sum(base.values())
    print("  exact root F=59·F0, F0=t*packet; joint tested B/F:", fu / 59,
          "; max pre-geometry whole-bin b_y:", max(b[0].values()), max(b[1].values()))
    print("  initial left/right, initial union, first full sweep, converged deleted / B:",
          side[0] / fu, side[1] / fu, union / fu, sum(x for _, x in sweeps[0]) / fu,
          sum(first) / fu)
    print("  first-charge left/right and frozen threshold bills / F:",
          *(x / 59 for x in (*first, *budget)), "; remaining B/F", sum(live.values(), F(0)) / 59)
    print("  successive sweeps (left count,mass/F0; right count,mass/F0):")
    for i, pair in enumerate(sweeps, 1):
        print("   ", i, *[(count, str(weight)) for count, weight in pair])
    if n == 64 and h == 8:
        groups = group(base, 0)
        left_cut = low(groups, frozen[0], theta[0])
        y, z = index(rows, 16), index(rows, 17)
        left16 = groups[y] / frozen[0][y]
        right17 = group(base, 1)[z] / frozen[1][z]
        after = {key: weight for key, weight in base.items() if key[1] not in left_cut}
        right17_after = group(after, 1)[z] / frozen[1][z]
        assert left16 == F(9, 32) and right17 == F(3, 8) > theta[1] > right17_after > 0
        print("  planned cascade p_B=W/(g*packet): L16 =", left16,
              "; R17 before/after L pass", right17, right17_after,
              "; first-proposal b(16,17)", b[0][16], b[1][17])
        assert sum(first) > union and len(sweeps) >= 2
    if n == 64 and h == 7:
        y = index(rows, 30)
        survived = group(live, 0)[y]
        p_B, b_y, kappa, degree = two_way(rows, packet, y, frozen[0][y], survived, theta[0])
        assert 0 < kappa <= 1

        def kernel(w, u):
            return kappa if (w, u) == (0, 1) else F(0)

        four_square = sum(packet ** 4 * kernel(w, u) * kernel(wp, u)
                          * kernel(w, up) * kernel(wp, up)
                          for w, wp, u, up in product((0, 1), repeat=4))
        assert four_square == degree ** 4 > 0
        print("  fixed actual y in live core 30; b,p, κ/g, two-way degree/(g*packet),")
        print("  four-cycle/(g*packet)^4, four-cycle/degree^4:",
              b_y, p_B, kappa / rows[y].g, degree / (rows[y].g * packet),
              four_square / (rows[y].g * packet) ** 4, four_square / degree ** 4)
    for k, charge in enumerate(charges):
        paid = [(r.slot, str(r.x), str(charge[i])) for i, r in enumerate(rows) if charge[i]]
        print("  nonzero real root charges side", k, "(slot,x,mass/F0):", paid)


if __name__ == "__main__":
    parser = ArgumentParser()
    parser.add_argument("--handoff", required=True, type=Path, help="pinned R850 research.zip")
    module = fixture(parser.parse_args().handoff)
    print("Python", sys.version.split()[0], "Fraction exact; pinned R850 fixture.")
    print("Bare proposal includes u>=2H and the full first J1 bin gate; geometry and deep terminal events follow.")
    print("Each continuing arm starts P then folds K, retaining the same fresh continuous source after P.")
    print("Frozen groups are same-side retained packet and same true middle core across ALL roots.")
    print("W_B/(g_y*packet)=p_B, cut at strict p_B<theta. Conditioning uses proposal, not acceptance.")
    print("Reverse degree uses b_y times the W cutoff and gives the same first-paid fibres here.")
    run(module, 64, 7, 2, (F(1, 49), F(1, 49)))
    run(module, 64, 8, 2, (F(5, 16), F(5, 16)))
    run(module, 256, 8, 3, (F(1, 8), F(9, 64)))
