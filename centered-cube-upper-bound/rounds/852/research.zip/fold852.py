"""Exact folded kernel, same-source physical handoff, and middle integral bound."""
from argparse import ArgumentParser
from bisect import bisect_left, bisect_right
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
from math import isqrt
from pathlib import Path
from zipfile import ZipFile
import sys

PIN = "d7e0cc5e31eb94cd6bb536dca40af122bc4793adfdf0dfb43e0e2b94be01c674"


def source_model(path):
    assert sha256(path.read_bytes()).hexdigest() == PIN
    with ZipFile(path) as zip:
        name = "handoff850.py"
        env = {"__name__": "handoff850_box_dependency", "__file__": name}
        exec(compile(zip.read(name), name, "exec"), env)
    return env


def advance(vector, matrix):
    output = defaultdict(F)
    for e, mass in vector.items():
        for f, weight in matrix[e].items():
            output[f] += mass * weight
    return dict(output)


def compose(p, q):
    return [advance(row, q) for row in p]


def transpose(matrix, mu):
    result = [{} for _ in matrix]
    for e, row in enumerate(matrix):
        for f, value in row.items():
            result[f][e] = mu[e] * value / mu[f]
    return result


def caps(matrix):
    return [sum(row.values(), F(0)) for row in matrix]


def terminal(p, k, v, mu):
    mu_dict = dict(enumerate(mu))
    kill = [1 - q for q in caps(p)]
    assert [1 - q for q in caps(k)] == kill
    delta = {e: m * alpha for e, (m, alpha) in enumerate(zip(mu, kill)) if alpha}
    reverse_recovered = defaultdict(F)
    per_root = [F(0)] * len(mu)
    depths = []
    for step in v:
        incoming = advance(mu_dict, step)
        assert all(incoming.get(e, 0) <= m for e, m in mu_dict.items())
        reverse = advance(delta, transpose(step, mu))
        depths.append(sum(reverse.values()) / sum(mu))
        for e, val in reverse.items():
            reverse_recovered[e] += val
        for e, row in enumerate(step):
            exits = sum(weight * kill[f] for f, weight in row.items())
            per_root[e] += exits
            assert reverse.get(e, 0) == mu[e] * exits
    assert reverse_recovered == mu_dict and all(x == 1 for x in per_root)
    arriving_p = advance(mu_dict, p)
    born_p = [mu[e] - arriving_p.get(e, 0) for e in range(len(mu))]
    arriving_k = advance(mu_dict, k)
    born_k = {e: mu[e] - arriving_k.get(e, 0) for e in range(len(mu))}
    assert all(x >= 0 for x in born_k.values())
    assert all(born_k[e] == born_p[e ^ 1] for e in born_k)
    basis = {e: x for e, x in born_k.items() if x}
    occupancy = defaultdict(F)
    while basis:
        for e, amt in basis.items():
            occupancy[e] += amt
        basis = advance(basis, k)
    assert occupancy == mu_dict
    assert all(occupancy[e] * kill[e] == delta.get(e, 0) for e in mu_dict)
    return depths


def middle_audit(n, rows, p, bare, k_powers, v, mu, t, packet, h, d):
    b = 1 + isqrt(n - 1)
    times = [r.bin for r in rows for _ in (0, 1)]
    true_h = [r.volume * r.g / r.side ** (2 * n) for r in rows]
    assert all(hj == t * r.fraction / packet for hj, r in zip(true_h, rows))
    bins = defaultdict(F)
    for row, hj in zip(rows, true_h):
        bins[row.bin] += hj
    assert len(bins) == 59 and set(bins.values()) == {t / packet}
    ordered = sorted(bins)
    mu0 = t * packet / 2
    coefficient = mu0 * 2 / (d * t) ** 2
    per_bin = coefficient * (t / packet)
    assert per_bin == 1 / d ** 2
    first = []
    for index, row in enumerate(rows):
        # The true ordered rank intervals have length t in every occupied bin.
        # Check the whole first-window eligible bin set without using bare.
        accepted_bins = {other.bin for other in rows
                         if row.slot >= 2 * h and row.bin >= other.bin + b + 1
                         and h <= row.slot - other.slot - 1
                         and row.slot - other.slot + 1 <= h + d}
        for phase in (0, 1):
            assert accepted_bins == {times[f] for f in bare[2 * index + phase]}
            first.append(accepted_bins)
    for level in k_powers[1:]:
        for e, row in enumerate(level):
            for f, prob in row.items():
                assert e % 2 == f % 2 and prob <= mu[f] / d
    table = []
    tests = 0
    for r, level in enumerate(v[2:], 2):
        r_gap = (r - 1) * (b + 1)
        max_density = max_geo = max_window = F(0)
        hits_geo = hits_window = positive = 0
        for e, row in enumerate(level):
            low_first = times[e] - b - 1
            for f, mass in enumerate(mu):
                tests += 1
                density = row.get(f, F(0)) / mass
                high_last = times[f] + r_gap
                if e % 2 == f % 2 or high_last > low_first:
                    assert density == 0
                    continue
                coarse_count = bisect_right(ordered, low_first) - bisect_left(ordered, high_last)
                window_count = sum(high_last <= j <= low_first for j in first[e])
                coarse_cap, window_cap = per_bin * coarse_count, per_bin * window_count
                assert 0 <= density <= window_cap <= coarse_cap
                if not density:
                    continue
                positive += 1
                selected_h = F(0)
                represented = F(0)
                for g in p[e]:
                    onward = k_powers[r - 1][g].get(f, 0)
                    if onward:
                        assert high_last <= times[g] <= low_first and times[g] in first[e]
                        hg = true_h[g // 2]
                        assert p[e][g] == mu[g] / d
                        conditional = d * onward / mass
                        assert 0 < conditional <= 1
                        selected_h += hg
                        represented += hg * conditional
                assert density == coefficient * represented <= coefficient * selected_h <= window_cap
                max_density = max(density, max_density)
                max_geo = max(density / coarse_cap, max_geo)
                max_window = max(density / window_cap, max_window)
                hits_geo += density == coarse_cap
                hits_window += density == window_cap
        table.append((r, positive, max_density, max_geo, max_window, hits_geo, hits_window))
    return table, tests


def physical_witness(model, n, rows, p, k):
    slot = (58, 49, 40, 31, 22, 13)
    states = [model["normal_state"](rows, slot[0])]
    states += [model["normal_state"](rows, s, 1) for s in slot[1:]]
    for level, (e, f) in enumerate(zip(states, states[1:])):
        assert f in (p if level == 0 else k)[e]

    def pick(pack, fresh):
        center = F(1 if pack else -1, 16)
        z = center + F(fresh, 2 ** 14)
        assert abs(z - center) < F(1, 128)
        return (z,) + (F(0),) * (n - 1)

    # These are actual members of the continuous packet. The pushes copy
    # the original retained coordinate, not a resampled point in its packet.
    a, z = pick(0, 0), pick(1, 0)
    root_retained = a
    z_new = pick(1, 1)
    assert z_new != z
    at_first = a, z_new
    assert at_first[0] is root_retained
    for depth in range(2, len(states)):
        a_old = a
        a = pick(0, depth)
        current = a, at_first[1]
        assert current[1] is z_new and a != a_old
    assert current[0] != root_retained
    return slot, root_retained[0], z_new[0], current[0][0]


def one(model, n, h):
    rows, t, packet = model["real_fixture"](n)
    p, bare, d, _ = model["kernels"](rows, n, h)
    mu = [rr.fraction for rr in rows for _ in (0, 1)]  # units mu0, symmetric under C
    k = [{f ^ 1: prob for f, prob in row.items()} for row in p]
    assert all(e % 2 != f % 2 for e, row in enumerate(p) for f in row)
    assert all(e % 2 == f % 2 for e, row in enumerate(k) for f in row)
    k_powers = model["powers"](k)
    identity = k_powers[0]
    v = [identity] + [compose(p, level) for level in k_powers]
    while not any(v[-1]):
        v.pop()
    assert len(v) <= n // (2 + isqrt(n - 1)) + 1
    depth = terminal(p, k, v, mu)
    results, tests = middle_audit(n, rows, p, bare, k_powers, v, mu, t, packet, h, d)
    samples = physical_witness(model, n, rows, p, k)
    print(f"n={n}, H/t={h}, d/t={d}, max depth={len(v)-1}, all tagged pair tests r>=2={tests}")
    print("  depths of normalized terminal mass:", " ".join(map(str, depth)))
    print("  r, positive tagged pairs, max mu0*q, max ratio range, max ratio first-window, "
          "saturation counts range/window:")
    for vals in results:
        print("   ", " ".join(map(str, vals)))
    print("  true slot path; actual root a_1, retained u_1 through final, fresh final private:",
          samples[0], *samples[1:])
    print("  exact substationarity, pointwise terminal and reverse Delta recovery, K births.")


if __name__ == "__main__":
    parser = ArgumentParser()
    parser.add_argument("--handoff", required=True, type=Path,
                        help="R850 research.zip at the pinned digest")
    arg = parser.parse_args()
    model = source_model(arg.handoff)
    print("Python", sys.version.split()[0], "Fraction exact; SHA-256 R850 dependency", PIN)
    print("Ptest uses the existing reduced-H true whole-bin geometry gate, not the general high-load gates.")
    print("C flips only the label; K=P C retains exactly the same active source. "
          "P first makes the terminal active source fresh. V_r has density for r>=2.")
    print("q is relative to real tagged mu; so tabulated density is scaled by mu0=t*packet_mass/2.")
    for n, h in ((64, 7), (64, 8), (256, 8)):
        one(model, n, h)
