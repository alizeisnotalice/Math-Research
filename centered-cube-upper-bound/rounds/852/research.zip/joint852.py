"""Two independent deep folded arms from one physical unlabelled root."""
from argparse import ArgumentParser
from collections import defaultdict
from decimal import Decimal, localcontext
from fractions import Fraction as F
from hashlib import sha256
from itertools import product
from math import prod
from pathlib import Path
from zipfile import ZipFile
import sys

PIN = "d7e0cc5e31eb94cd6bb536dca40af122bc4793adfdf0dfb43e0e2b94be01c674"


def module(path):
    assert sha256(path.read_bytes()).hexdigest() == PIN
    with ZipFile(path) as archive:
        name = "handoff850.py"
        env = {"__name__": "real_fixture_dependency", "__file__": name}
        exec(compile(archive.read(name), name, "exec"), env)
    return env


def fmt(x):
    with localcontext() as ctx:
        ctx.prec = 16
        return f"{Decimal(x.numerator) / Decimal(x.denominator):.8E}"


def terminal_arms(p, k_powers):
    death = [1 - sum(row.values(), F(0)) for row in p]
    arrows = []
    for e, row in enumerate(p):
        out = defaultdict(F)
        for mid, first in row.items():
            assert e % 2 != mid % 2
            for power in k_powers[4:]:  # r-1>=4
                for terminal, continuation in power[mid].items():
                    assert mid % 2 == terminal % 2
                    out[mid, terminal] += first * continuation * death[terminal]
        # Telescoping all actual terminal stops equals entering K^4.
        assert sum(out.values()) == sum(first * sum(k_powers[4][mid].values())
                                        for mid, first in row.items())
        arrows.append(out)
    return death, arrows


def projection(arm, rows, choice):
    result = defaultdict(F)
    for (mid, end), value in arm.items():
        if choice == "middle-core":
            key = mid // 2
        elif choice == "middle-bin":
            key = rows[mid // 2].bin
        else:
            key = end // 2
        result[key] += value
    return result


def joint_stats(rows, arms):
    full = sum(r.fraction for r in rows)  # F measured in units t*packet_mass
    joint = F(0)
    coincident = defaultdict(F)
    num_roots = 0
    focus = F(0)
    for i, root in enumerate(rows):
        arm0, arm1 = arms[2 * i], arms[2 * i + 1]
        first, second = sum(arm0.values()), sum(arm1.values())
        assert first == second  # property of this source-packet fixture
        if first and second:
            num_roots += 1
        if root.slot == 58 and root.x == 0:
            focus = first
        joint += root.fraction * first * second
        for choice in ("middle-core", "middle-bin", "terminal-core"):
            a, b = projection(arm0, rows, choice), projection(arm1, rows, choice)
            coincident[choice] += root.fraction * sum(value * b.get(key, 0)
                                                     for key, value in a.items())
    assert 0 < coincident["middle-core"] <= coincident["middle-bin"] <= joint
    return full, joint, coincident, num_roots, focus


def exposed_integral(model, n, rows, t, packet, p, k, death, arms, h):
    root = model["normal_state"](rows, 58)
    paths = ((58, 49, 40, 31, 22, 13),
             (58, 49, 40, 31, 22, 13) if h == 7 else (58, 47, 38, 29, 20, 11))
    chosen = []
    for label, path in enumerate(paths):
        states = [model["normal_state"](rows, path[0], label)]
        states += [model["normal_state"](rows, j, 1 - label) for j in path[1:]]
        prob = p[states[0]][states[1]] * prod(k[e][f] for e, f in zip(states[1:], states[2:]))
        assert death[states[-1]] == 1
        prob *= death[states[-1]]
        assert 0 < prob <= arms[states[0]][states[1], states[-1]]
        chosen.append((rows[states[1] // 2], rows[states[-1] // 2], prob))
    q0, q1 = chosen
    # These two points are fixed terminal private ends: A for arm0, B for arm1.
    z_private = (F(-1, 16) + F(3, 16384), F(1, 16) + F(5, 16384))
    assert abs(z_private[0] + F(1, 16)) < F(1, 128)
    assert abs(z_private[1] - F(1, 16)) < F(1, 128)
    root_row = rows[root // 2]
    obs = root_row, q0[0], q1[0], q0[1], q1[1]

    def g(row, a, z):
        return row.g if (a, z) == (0, 1) else F(0)

    # A/B integration represents true disjoint PACK^n boxes, not atomic sources.
    # Root ordered (a,q); mids (a,u),(v,q); tails (private_A,u),(v,private_B).
    terms = [g(obs[0], a, q) * g(obs[1], a, u) * g(obs[2], v, q)
             * g(obs[3], 0, u) * g(obs[4], v, 1)
             for a, q, u, v in product((0, 1), repeat=4)]
    assert sum(term > 0 for term in terms) == 1
    numerator = packet ** 4 * sum(terms)
    receiver_factor = prod(x.volume / x.side ** (2 * n) for x in obs)
    normalized = numerator * receiver_factor * packet / t ** 5
    assert normalized == prod(x.fraction for x in obs)
    assert root_row.g == root_row.side ** 128 / (3 * 2 ** 131)
    wrong = normalized * root_row.g
    assert 0 < wrong < normalized
    print("  specific first-middle/terminal slots by arm:", (paths[0][1], paths[0][-1]),
          (paths[1][1], paths[1][-1]), "exact full path conditional product", q0[2] * q1[2])
    print("  fixed terminal private first coordinates", *z_private,
          "; exposed 4-source numerator*receiver_factor*packet/t^5:", normalized,
          "; duplicated-root version:", fmt(wrong))
    print("  exact wrong/correct = root g = (%s)^128/(3*2^131);" % root_row.side,
          "each actual middle and terminal has one g, including two independent draws in one core.")


def run(model, n, h):
    rows, t, packet = model["real_fixture"](n)
    p, _, _, _ = model["kernels"](rows, n, h)
    k = [{f ^ 1: x for f, x in row.items()} for row in p]
    k_powers = model["powers"](k)
    death, arms = terminal_arms(p, k_powers)
    full, joint, same, roots, focus = joint_stats(rows, arms)
    assert 2 * full == 118
    print(f"n={n}, H/t={h}, positive unlabelled root cores={roots}, test requires total r>=5:")
    print("  joint terminal mass/F:", joint / full, "; individual arm probability from slot 58:", focus)
    print("  conditional on two deep terminals: same middle core/bin, same terminal core:",
          same["middle-core"] / joint, same["middle-bin"] / joint, same["terminal-core"] / joint)
    print("  same actual continuous middle center = 0; opposite retained packet pair = 1.")
    exposed_integral(model, n, rows, t, packet, p, k, death, arms, h)


if __name__ == "__main__":
    parser = ArgumentParser()
    parser.add_argument("--handoff", required=True, type=Path,
                        help="R850 research.zip with the pinned SHA-256")
    model = module(parser.parse_args().handoff)
    print("Python", sys.version.split()[0], "Fraction exact; display decimals rounded.")
    print("Pinned R850 archive SHA-256:", PIN)
    print("Real positive-width boxes, reduced whole-bin rank parameters and geometric test gate.")
    print("Starting from one actual root, its two oriented arms use independent auxiliary draws.")
    print("Exposed numerator only: interior K factors are outside it; no terminal-private integration.")
    for n, h in ((64, 7), (64, 8), (256, 8)):
        run(model, n, h)
