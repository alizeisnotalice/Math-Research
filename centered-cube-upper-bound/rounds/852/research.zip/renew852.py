"""R852 pure continuous rank renewal with exact Irwin--Hall replay.

Normalize H=1; increments have law Unif[1,1+1/A].
Uniform all-s proof: u_L=f_L*U, where U is the expected counting
measure of a single path with inter-point distance >=1. Each
superlevel set of the symmetric unimodal f_L is an interval.
It contains no more than its length plus one path points.
Layer cake gives u_L <= 1+sup(f_L) at every s.
"""

from decimal import Decimal, ROUND_CEILING, ROUND_FLOOR, localcontext
from fractions import Fraction as F
from functools import cache
from math import ceil, comb, factorial, floor
import sys


@cache
def coefficients(r):
    return tuple((-1)**j*comb(r,j) for j in range(r//2+1))


@cache
def fac(r):
    return factorial(r)


def irwin_density(r,x):
    """Density of r independent Unif[0,1] at a rational coordinate."""
    if r==1:
        return F(int(0<x<1))  # endpoints can be assigned arbitrarily
    if not 0<x<r:
        return F(0)
    x = min(x,r-x)
    num,den = x.numerator,x.denominator
    upper = num//den
    exponent = r-1
    value = sum(c*(num-j*den)**exponent for j,c in enumerate(coefficients(r)[:upper+1]))
    assert value>=0
    return F(value,fac(exponent)*den**exponent)


def irwin_cdf(r,x):
    """Independent full-support formula needed only for recurrence probes."""
    if x<=0:
        return F(0)
    if x>=r:
        return F(1)
    return sum((-1)**j*comb(r,j)*(x-j)**r for j in range(floor(x)+1))/fac(r)


def normalized_step(A,r,s):
    return A*irwin_density(r,A*(s-r))


def renewal(A,L,s):
    # Exact summation: all omitted r have s outside the physical support.
    lower=max(L,ceil(A*s/(A+1)))
    upper=floor(s)
    return sum((normalized_step(A,r,s) for r in range(lower,upper+1)),F(0))


def display(value,rounding=None):
    with localcontext() as ctx:
        ctx.prec=14
        if rounding is not None:
            ctx.rounding=rounding
        return str(Decimal(value.numerator)/Decimal(value.denominator))


def enclosure(value):
    return f"[{display(value,ROUND_FLOOR)}, {display(value,ROUND_CEILING)}]"


def formula_checks():
    tests=0
    for r in (2,3,4,8,16):
        for j in range(4*r+1):
            x=F(j,4)
            via_cdf=irwin_cdf(r-1,x)-irwin_cdf(r-1,x-1)
            assert irwin_density(r,x)==via_cdf
            tests+=1
    assert irwin_density(2,F(1,7))==F(1,7)
    assert irwin_density(2,F(9,7))==F(5,7)
    print("Independent uniform-CDF recurrence checked at",tests,"exact rational points.")


def replay(A):
    L=A*A
    exact_peak=normalized_step(A,L,F(L)*(1+F(1,2*A)))
    global_bound=1+exact_peak
    assert global_bound<3
    short_s=1+F(1,2*A)
    short=renewal(A,1,short_s)
    assert short==A and renewal(A,L,short_s)==0

    # Three predrawn spatial regions, later two with differing phases.
    # These are point probes, separate from the all-s analytic bound.
    near=tuple(F(L)+F(j,4) for j in range(4*(2*A+3)+1))
    middle=tuple(2*L+F(j,8) for j in range(17))
    late=tuple(4*L+F(j,8) for j in (0,1,4,7,8))
    probes=sorted(set(near+middle+late))
    values={s:renewal(A,L,s) for s in probes}
    assert all(0<=value<=global_bound for value in values.values())
    maximizing_s=max(values,key=values.__getitem__)
    sample_max=values[maximizing_s]
    late_mean=F(2*A,2*A+1)
    assert values[L]==0 and sample_max>0

    print("A=H/d",A,"L",L,"; isolated early peak",short,
          "; exact global upper 1+peak(f_L)",enclosure(global_bound))
    print("  sampled max",enclosure(sample_max),"at s/H",maximizing_s,
          "among",len(probes),"rational points through",max(probes))
    print("  tail at s/H=2L,4L:",display(values[2*L]),display(values[4*L]),
          "; inverse normalized mean",late_mean)
    print("  max in the first scan window / one-step peak:",display(max(values[s] for s in near)/short))


if __name__=="__main__":
    print("Python",sys.version.split()[0],"| exact Fraction, no floating-point path sampling.")
    print("Reported densities are H*sum_(r>=L) f_r(s), with L=ceil((H/d)^2).")
    formula_checks()
    for ratio in (2,4,8,16):
        replay(ratio)
    print("All exact assertions passed. The global upper uses separated continuous paths and unimodality.")
    print("Scope of this replay: the continuous convolution kernel with carried rank.")
