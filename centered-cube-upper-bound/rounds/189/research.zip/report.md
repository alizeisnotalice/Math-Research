# 第189轮：原随机停止几何的大块近对吸收

一般中心立方体极大算子的n^(1/2+o(1))一致弱型上界仍未闭合。本轮取得实际可吸收子支，而不是把剩余项另起名字：原初始停止块边长足够大的近outer–bad来源交通，其真实接收费用可压到任意预定ε∫q dx。

## 准确结论与核心证明

原current选择和输入先于FULL随机网格平移固定。网格的每个确定层S相位联合均匀；这是原FULL树，不能用后来R107的另一个粗网格替代。任意适应的停止块只要边长≥S，就包含来源y所在S格。因此与块外来源u的配对必跨S格，概率至多min(1,||y−u||1/S)，无需对停止深度求和。

先对原完整时间行取固定近bad子集及初始大块指示，保留same-alpha、目标权和全部历史，再用R183完整删除估计与R188实际λ≤current product。逐样本丢同V标签并正放到固定f⊗f后，依赖网格的来源和接受权已被合法消去；FIRST使剩余current product归一质量≤1。故原子支满足

 Raw^{r,S} ≤ [16Λ/(3Kκ)] min(1,r/S) ∫E q dx。

原真实互反门另给每坐标|yi−ui|/b<Rκ=1+log(2/κ)，因此||y−u||1≤bRκD_b。K=1时Rκ≤1+log6，与维度无关。这改进同一笔吸收的所需块尺度，不是第二次付款。

对R188硬近域ζ²D_b<16B_n，可取r(x)=16bRκB_n/ζ(x)²，再选最小原层S(x)≥[16Λ/(3Kκ)]r(x)/ε。只要选择在平移前固定，逐x平均不给所选尺度数收费。超顶层时该大块子支为空，不冒称覆盖。

## 剩余问题与边界

未支付的是小初始停止块中的近outer–bad、极小good重叠联合交通，以及其他原mother分支。light块的质量帽不等于边界密度帽，heavy fallback不享light帽。目标未来放大不能靠当前target小质量免费消去，详见Astra辅助稿。没有给一般HB16或最终弱型上界盖章。

只在同一合法原窗口使用current归一；不同窗口仍须按原总账分配ε。真实Lebesgue接收测度、原硬帽和外系数保留。证明先有限接收截断，不用∞−∞声称吸收或完成全局极限。

## 实际验证与交付范围

本机Python Fraction实际运行48个相位例（1–3维）、26,624个一维停止比较及36个固定current的自适应衰减例；mpmath 1.3.0实际完成4个维度、40/60位共40次半径核评估。前者为有限精确算术，后者为有限高精度诊断而非区间证书；均不构造原FULL/alpha实例，不代替一般证明。数值代理独立审代码并隔离重放完整JSON；数学代理先独筛再审全文。原law另由来源代理窄读原文核定。

主证明见stopping_boundary_geometry.md和详细proof.tex.txt；原接口见grid_boundary_budget.md，辅助未来目标账见joint_geometry.md。64项工具中的G03只用于来源/算子资格审查，不输入未经证明的捕获树或PSD平方函数结论。D01正测度模型资格不被当作免费强对偶。实际1 Astra high、2 Sol high、1 Sol medium分工，无可获得扣额明细，不猜成本。

不编译PDF。归档仅保本报告、证明、独审、必要脚本与结果。运行python3 reproduce.py --verify-only核哈希；在有mpmath的环境用python3 reproduce.py --output-dir <不存在的新目录>重放全部结果。本机已有库可用PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor，无需安装。
