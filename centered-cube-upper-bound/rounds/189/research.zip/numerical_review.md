# R189 independent boundary-check review

The main `stopping_boundary_geometry.md`, `boundary_checks.py`, and existing JSON were independently read. No substantive implementation or scope correction was found. This review covers finite SB1/SB2 arithmetic and the stated elementary geometry; it does not certify the original forest, its phase law, HB16, or a linear source/receiver payment.

## SB1 and stopping-count verification

The proof uses the correct deterministic implication: a stopping node containing y whose side is at least the deterministic grid scale ell contains the ell-cell of y. Thus u outside that node cannot lie in y's ell-cell. It requires no independence of the stopping rule. Half-open cell membership is retained consistently.

The script enumerates every binary dyadic stopping partition on [0,8) down to side 1. The recursive counts are a0=1, a1=1+a0²=2, a2=1+a1²=5, a3=1+a2²=26. Every partition has four tested deterministic scales, and every scale has 16 choices each of y and u, so the recorded count is exactly 26·4·16²=26624. Points are half-integers in [0,8), including internal stopping/grid boundaries. The tested implication checks the side qualification before comparing floor-grid indices.

The comment about a finest fallback concerns inclusion of finest-size blocks in this finite structural enumeration; it does not generate or verify an original heavy/fallback qualification. These are one-dimensional finite partitions, not arbitrary-dimensional original forests. The general nested-cell implication is supplied by the written proof, not by the finite count.

## SB2 phase probability and count verification

The 48 displacement cases are 5 one-dimensional, 4² two-dimensional, and 3³ three-dimensional cases. Each phase vector is enumerated independently over all m^n midpoint choices, with m=8. The displacement coordinates are integer multiples of 1/m. For such displacements the cell-membership breakpoints lie at phase-bin endpoints, so membership is constant inside each bin and midpoint counting gives the exact continuous uniform-phase probability; it is not an approximate quadrature for these cases.

Fraction floor division matches the half-open cell convention. The computed separation probability is compared exactly with 1−Π(1−|d_i|/ell)+ and the union upper bound min(1,Σ|d_i|/ell). Zero, full-cell, and beyond-cell displacement are included, and all assertions pass. The product enumeration uses jointly uniform phases. It would not justify the product formula from marginal uniformity alone; the text correctly limits that case to the union bound.

## Scope of the written source statement

SB3 correctly fixes the dominating measure and nonnegative weight before averaging the random grid and uses positive product-measure domination/Tonelli. It explicitly retains the quadratic dominating-measure price. The text also identifies the unavailable steps: actual original grid qualification, small stopping blocks, possibly random scale, and weights such as 1/e_g, q, current selection and psi that may depend on the grid. Nothing in the finite checker removes those costs or establishes a receiver-independent weight. No extra numerical search or coverage claim was requested or needed.

## Single isolated replay

Only the script was copied outside the repository. The actual command was:

```sh
python3 /tmp/r189_boundary_review/boundary_checks.py
```

This standard-library-only replay exited zero and printed `phase_cases: 48` and `stop_partition_checks: 26624`. Its complete JSON bytes were compared with the main output using `read_bytes()` equality and matched exactly. No fields were ignored, no mpmath dependency was used, and no owner file was modified.

Reviewed SHA256:

- `stopping_boundary_geometry.md`: `5800430a5d73d5808622e279b21496e9f04ba80f0f907c5a8d54cbc0eeda0d54`
- `boundary_checks.py`: `4da93ea49f0949598a35fe4c95d9e546761c6638915e89dda052124dbeb9dc9b`
- `boundary_checks.json`: `3a09bfc02b39abca810906f433e1be7ac83881607dfce2e5f66c5af6baf8ac17`

The review and replay are complete. No further sample expansion is implied.

## Additional fixed-current adaptive-capacity checks

The new `adaptive_capacity_checks.py/json` was independently read. All 36 cases are counted correctly as three support sizes (4,8,16), four radii (1/8,1/2,1,2), and three modes (full, phase-adaptive attenuation, concentrated). Support size 4 supplies 12 initial cases; size 8 supplies 12 pressure cases, including concentrated zero displacement and phase attenuation; size 16 supplies 12 expanded cases. This is a finite one-dimensional scalar SB5–SB6 model, not an actual-alpha, stopping-rule, HB10, original-forest, or FULL certificate. The expanded mathematical SB4–SB7 proof is the separate mathematical auditor's responsibility.

The triangular masses sum exactly to one, and the concentrated mode has exactly unit mass at one point. The source product remains fixed across all phases; the phase-dependent factor is merely a subunit attenuation in {0,1/7,...,6/7}. No phase-dependent renormalization is performed. The code retains the near-pair condition |y−u|≤radius and split event on the same phase before summing fixed product masses, and divides by the eight equally weighted phases. All positions are multiples of 1/8, so the midpoint phase calculation is exact on its phase bins, as in the original SB2 checks. The bound min(1,radius) uses grid scale 1. Concentrated mass gives zero split traffic, not an omitted diagonal contribution.

Exactly one additional isolated replay copied only this new script into `/tmp/r189_adaptive_capacity_review/` and ran:

```sh
python3 /tmp/r189_adaptive_capacity_review/adaptive_capacity_checks.py
```

It exited zero, reported 36 passing cases, and its complete JSON bytes matched the main output. The earlier 48 phase cases and 26624 stopping comparisons were not rerun, and no owner script was changed. No substantive issue was found; no new search or sample expansion is proposed.

The earlier stopping-document hash records the SB1–SB3 review checkpoint. The main document was subsequently extended; its present hash is listed only as a cross-reference, without assigning this numerical review responsibility for the full new proof.

Additional reviewed SHA256:

- `adaptive_capacity_checks.py`: `d8b5050dee14775cf86c1e2701f929acaedd79e1e65c987b768367efb9ff43f4`

- `adaptive_capacity_checks.json`: `57bb4e8c1c2175b13165d3ff3115b52137af07f781dbd09413d7561db07edbcb`

- Extended `stopping_boundary_geometry.md` (cross-reference): `9dbd7975a04a04f1b3074dfcc367eb854fddaedc686b698afb86188240449684`

## Additional reciprocal-radius diagnostic review

The new `reciprocal_radius_checks.py/json` was statically reviewed. The E4 second-difference formula C(d)=E4(d−1)−2E4(d)+E4(d+1) is correct for d≥1: the averaging interval lies outside the hard core except for a measure-zero touching point at d=1, so C=h*φ=h*h*w there. Integrating φ(r)=E3(r−1/2)−E3(r+1/2) across that interval gives exactly this expression. It is not extended to d<1.

The script correctly computes κ_n=[1+(1+1/n)^(-n)]/3 using log1p, and Rκ=1+log(2/κ). For each requested d it checks positive C≤exp(1−d), and at or beyond Rκ it checks C<κ/2. The strict threshold is consistent with the analytic w(r)<exp(−r) for r>0, not an assertion that a non-strict upper inequality by itself becomes strict. In the original reciprocal argument, the separate premise C(d_i)>κ/2 excludes d_i≥Rκ; that original premise/qualification is not generated by this script.

The count is 4 dimensions (2,16,256,1000000) × 2 precisions (40,60) × 5 distances (1,1.5,2,Rκ,Rκ+1/2)=40 actual evaluations. Both precision loops execute assertions. The JSON retains the final 60-dps block (20 C values); it records both precision levels but does not pretend to save all 40 values. The explicit cross-precision test compares the two radius values within 1e-35. These finite-dps tests are not interval enclosures, a uniform proof, or FULL/source-history instances.

One isolated replay copied only the new script to `/tmp/r189_reciprocal_radius_review/` and ran the actual command:

```sh
PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor python3 /tmp/r189_reciprocal_radius_review/reciprocal_radius_checks.py
```

It exited zero, reported all 40 evaluations passed, and its complete JSON bytes equalled the main output. No old script was rerun and no owner file was edited. No substantive issue or further sample expansion was found necessary.

Additional reviewed SHA256:

- `reciprocal_radius_checks.py`: `c41d5ed169cdf11958188e672121ed251c55e15b8f21aa81aa6073bfcbd5e306`

- `reciprocal_radius_checks.json`: `caaaf736d2aab786be4e0022c6b206fb1d75f76f93d5f1b4b193e60b8997545c`
