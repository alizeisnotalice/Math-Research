from fractions import Fraction as F
from pathlib import Path
import json
rows=[]
for count in [4,8,16]:
 positions=[F(i,8) for i in range(count)]
 for radius in [F(1,8),F(1,2),F(1),F(2)]:
  for mode in ['full','phase_adaptive','concentrated']:
   masses=[F(i+1,count*(count+1)//2) for i in range(count)]
   if mode=='concentrated':masses=[F(int(i==0)) for i in range(count)]
   total=F(0)
   for k in range(8):
    theta=F(2*k+1,16)
    for i,y in enumerate(positions):
     for j,u in enumerate(positions):
      if abs(y-u)>radius or (y-theta)//1==(u-theta)//1:continue
      attenuation=F(1) if mode!='phase_adaptive' else F((i+2*j+k)%7,7)
      total+=masses[i]*masses[j]*attenuation/8
   bound=min(F(1),radius)
   assert total<=bound
   rows.append({'count':count,'radius':str(radius),'mode':mode,'weighted_average':str(total),'bound':str(bound)})
out={'cases':len(rows),'rows':rows,'scope':'Exact finite fixed-current product capacity with phase-dependent attenuations; checks SB5-SB6 algebra only, not actual alpha or FULL realization.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print({'cases':len(rows),'passed':True})
