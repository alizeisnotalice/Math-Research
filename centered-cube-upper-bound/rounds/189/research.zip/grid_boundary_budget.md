# R189：原网格 law、适应来源与大停止块的实际边界吸收

本稿核定原来源接口，并将父稿 `stopping_boundary_geometry.md` 的单尺度 padding 接回 R188 HB 的实际 current 双容量测度。所得是一个真正可选任意小接收费的原子支：初始停止块足够大，且 outer–bad 来源对足够近。停止规则、β、ν 均可依赖网格；没有把它们当成独立变量。没有证明未付近对必有足够大的停止块，也没有支付其小块补集。

## GB1．实际随机 law 与两个森林的区别

本次亲读 `output/cube_general_20261003/概率接口阶段证明.tex` 2664–2725 行，以及 `high_marked_receipts/route.md` HR1–HR3。原 FULL 来源森林的准确 law 为

\[
 d_0=a/n,\quad J=\lceil\log_2(2G_n/d_0)\rceil,
 \quad D_{\rm top}=2^Jd_0,
 \quad\vartheta\sim\operatorname{Unif}([0,D_{\rm top})^n),
\]
\[
 \mathcal D_\ell(\vartheta)
 =\{\vartheta+2^\ell d_0(k+[0,1)^n):k\in\mathbb Z^n\},
 \qquad 0\le\ell\le J.                              \tag{GB1}
\]

全部层共用同一个平移、同一个原点，全部格半开；每个非顶层格有唯一二倍边长父格。每个顶格形成深度 J 的树。原出生网格不随此平移改变。`G_n=O(an log(n+2))` 是 HR2 原来源距离上限，原实际维数范围及其固定常数不在本稿改变。因此每一确定层 `S=2^ell d_0` 的相位 `vartheta mod S` 在 `[0,S)^n` 联合均匀。

给每个孩子、方向的额外 receipt 币在给定 θ 后按 HR3 的概率抽取，一次冻结供全部输出使用。后来的来源提取和剩余 β、ν 可以依赖 θ 及这些币；本稿不会再对它们声称独立。

R107 N8 的 `ξ~Unif([0,S_new)^n)` 及最细 `256na` 是后来为 soft 点与整个 hard winner 共同落叶而新增的另一套空间叶森林。N8 明示其独立于原 FULL 森林。不能用这个较粗最细尺度替代 GB1 的 `d_0=a/n`。本稿中的 `A_{j,t}` 是原 FULL 网格节点，不是后来的终端叶 V、运输 piece 或 maxflow cut；也不把节点改成 `A_{j,t}∩V` 后仍称其为同尺寸立方体。

## GB2．停止规则、原初始支持和 current 的先后顺序

R113 `proof.md` B8–B10、B20（77–91、174–184 行）以及 R114 S3–S4（235–250 行）使用的正是 GB1 原 FULL 森林及原 `h(A)=μ_hi(A∩B)`。阈值

\[
 H_j(t)=qt^n\max\{1,\sqrt n\,c_{j+1}^n,
                                      \sqrt n(t/b)^n\}
\]

在每个原路径上取最粗 `h(A)≤H_j(t)` 节点，没有 light 节点时取原最细格。等阈值归 light。故所有 `A_{j,t}(y)` 均为 GB1 某层节点，边长至少 d_0，最大为 D_top，但没有由这些公式得到统一更大的最小边长。light 仅有质量帽 `h(A)≤H_j(t)`；fallback 不享该帽。任意正 L1 输入的 h 质量与格侧长之间没有本稿可用的统一密度比较。

实际 R188 HB8 的 bad 集有更准确的初始支持。已审 R183 `reciprocal_capture_geometry.md` §1 明文要求

\[
 R_y\subset Z_{\ell_y}(y)
 =D_V(y)\cap\bigl(T_0(y)\setminus A_{j,\ell_y}(y)\bigr). \tag{GB2}
\]

`ell_y` 是该完整原行的初始时刻，原右连续删除约定保留。它以及 j、终端 g、high 和历史都可依赖原随机性；GB2 仍保证每个实际 u 跨**初始**停止块。不能将 GB2 自动换成 u 跨终端块，因为 R_y 可包含稍后被删除的来源。

原 HR1 先固定完整 retained `μ=μ_hi`、原 q、未 cut FIRST、原 `σ(x),L_s(x),R_h(x)` 及接收域，再在 HR3 引入 θ。原完整输入满足

\[
 p_x(z)=P_{\sigma(x),L_s(x)}(x-z),\qquad
 P_{\sigma(x),L_s(x)}f(x)=q,\qquad
 \int p_x\,d\mu_{\rm hi}\le q.                     \tag{GB3}
\]

本稿只用最后一个不等式。`μ_hi=f1_{f>q√n} dz≤f dz` 以及 p、q、E 在 θ 抽取前固定；来源子分解、原历史和共同叶可以在其后变化。若还带其他事先随机变量，可以先固定它们，使用原 θ 的条件均匀 law。不得先条件化后验来源、停块或接受事件，再要求 θ 仍均匀。后来新增的 ξ 独立于原变量，也不改变这一先后顺序。

## GB3．适应来源可以被支配，实际 current 权不能偷换

同一个原来源构造中，终端叶 V 不交，原共同父 `A_{V,ω}=μ_hi|V`，并有

\[
 \beta_{V,\omega},\nu_{V,\omega}\le A_{V,\omega},\qquad
 \sum_V\beta_{V,\omega}\otimes\nu_{V,\omega}
                         \le\mu_{\rm hi}\otimes\mu_{\rm hi}. \tag{GB4}
\]

这是逐 ω 的正测度支配：分别写两份相对 μ_hi 的密度，保留同 V 标签，互不交叶使密度和不超过1。没有乘两个独立来源期望，也不要求 `ν≤β`。更换窗口或重复运行菜单后，不能未经原父预算合并使用 GB4。

仅有 GB4 的未加权边界质量价本身是二次来源价。能接回本轮的关键是 HB10 的**实际**乘积支配，固定 x 时

\[
 \lambda_{x,V}(dy,du)
 \le {p_x(y)p_x(u)\over q^2}\,
                   \beta_{V,\omega}(dy)\nu_{V,\omega}(du),
 \qquad 0\le\psi_y\le1.                            \tag{GB5}
\]

λ 中原 high、互反、`1/e_g`、初始 `w_ell` 和同 α 的 ψ 不独立于 θ。GB5 先逐 ω 正向放大这些权，再以 GB4 将来源放大到固定 μ_hi；GB3 保证剩余 current 乘积在取 θ 期望前已经固定。若 current 本来依赖所平均的 θ，该步骤不能使用固定点分格概率；只能另证公共正包络并支付其费用。本轮原先后顺序避免了这项新增 selector 价。

## GB4．大初始停止块的实际接收吸收

固定一个**确定**原网格层 `S=2^ell d_0` 和确定 `r≥0`。在原 λ 上保留

\[
 \mathcal L_{S,r}:
 \operatorname{side}(A_{j,\ell_y}(y))\ge S,
 \quad\|y-u\|_1\le r.                              \tag{GB6}
\]

所有原 mask 保留；初始 j、ell_y 无需确定。由 GB2 及父稿 SB1，GB6 的每个实际 pair 都跨固定 S 层格：若两点同 S 格，则该 S 格包含在 y 的初始停止块内，矛盾。这是逐样本包含关系，即使停止时刻和格质量适应于 θ 也成立。因此只需一次固定尺度的分格事件，**不对所有较粗停止层求和**。

父稿 SB2 给固定点对的准确分格概率

\[
 \pi_S(y,u)=1-\prod_i(1-|y_i-u_i|/S)_+
             \le\min\{1,\|y-u\|_1/S\}.             \tag{GB7}
\]

依次用 GB5、GB4、正 Tonelli、GB7 与 GB3，得到实际 receiver 行预算

\[
\begin{split}
 \mathbb E_\omega\sum_V\int
                   1_{\mathcal L_{S,r}}\psi_y\,d\lambda_{x,V}
 &\le {1\over q^2}\iint_{\|y-u\|_1\le r}
       p_x(y)p_x(u)\pi_S(y,u)\,d\mu_{\rm hi}(y)d\mu_{\rm hi}(u)\\
 &\le\min\{1,r/S\}
        \left({\int p_x\,d\mu_{\rm hi}\over q}\right)^2
 \le\min\{1,r/S\}.                                 \tag{GB8}
\end{split}

若只平均 θ 及后加随机性，这也是条件于全部合法事先数据的同一不等式。把原额外指示放在左侧只减小正积分。原同 α 在实际 ψ 中完整保留，只在 GB8 的上界用 ψ≤1，不另用 capture 信用。

由原 HB13 的系数，GB8 真正给出

\[
 \operatorname{Raw}_{\mathcal L_{S,r}}
 \le {16\Lambda\over3K\kappa}\min\{1,r/S\}
                      \int_{E_{\rm rec}}q\,dx.       \tag{GB9}
\]

这不是 `||μ||²` 来源价，而是原 receiver 费。若要付款不超过任意预定 `ε∫q dx`，可取 `r/S≤3Kκ ε/(16Λ)`。本稿只对一组预定 S,r 领一次接收额度；若分别应用多个菜单后相加，费用也相加，不能每支各领完整 ε。

## GB5．与实际截断位移近域的接口

由 GB2 的原距离帽，每个实际 pair 满足

\[
 |y_i-u_i|\le bR_n,\quad R_n=5\log n+1/2,
 \qquad D_b(y,u)=\sum_i\min\{|y_i-u_i|/b,1\}.
\]

记 `Rbar_n=max(1,R_n)`。逐坐标有 `z≤Rbar_n min(z,1)`，故

\[
 \|y-u\|_1\le b\bar R_n D_b(y,u).                  \tag{GB10}
\]

因此原 `D_b≤d` 近域中，大初始块支 `side A_initial≥S` 可在 GB8–9 取 `r=b Rbar_n d`。给定 d 和接收额度，可选满足所需不等式的最小确定网格层 S；若没有层达到要求，不能臆造一个超过 D_top 的格，而该小系数分支为空或无法凭本式付款。若达到，dyadic 向上取整只使 S 至多比要求值大两倍；GB9 仍使用真实 r/S，不产生层数费用。

不能用截断位移本身替换未截断位移而漏掉 Rbar_n。整个 near 补集必须保留

\[
 \{D_b>d\}\quad\text{或}\quad
 \{D_b\le d,\ \operatorname{side}(A_{j,\ell_y}(y))<S\}. \tag{GB11}
\]

前者只能按已有分离付款及其准确参数另处理；后者没有被 GB8 控制。特别，原 min side 只有 `d_0=a/n`；直接取 S=d_0 时系数为 `min(1,n b Rbar_n d/a)`，对本轮一般近域通常没有吸收小量。原 mass-light 停止条件、Born 的 ν 帽以及 β 的 RN 来源身份均没有在本稿证明 GB11 小块部分有小质量。不是把新增未知小块门称为一般闭合。

## GB6．精确费用及检查点结论

GB8 允许初始停止层、j 和其时刻适应于 θ，因为 GB6 的跨块事件由同一个固定 S 格的分离统摄；没有改变原森林，也没有把来源与 θ 当独立。它先在固定 x 保留原 current FIRST 容量，再按真实 Lebesgue dx 积分。λ 已经在原唯一 j 行完成 HB 的完整时间界；本稿不再展开 j/time 菜单，不重复支付删除或重领负 suffix 信用。不同原窗口仍按原总账处理，不因各窗各有 GB9 而取得免费无限次 ε 吸收。

本次得到的实际新接口是 GB8–GB9 的大初始停止块接收吸收；其原 law、先后顺序和来源支配已从原定义核定。父稿 SB 的一般几何证明和有限算术检验不等于本稿重新认证 FULL 实例；本文也没有构造新的实例或使用有限试验推断一般 root 界。尚缺的首个具体条件是原剩余近对在初始停止块小于所需确定层 S 时的联合 current 加权付款。没有来源密度帽、`ν≤β` 或独立 padding 可免费填补该缺口。
