# R189 独立短筛与后审

仅写本文件，不Git/spawn/他人文件、不运行数值。已读task_contract.md及R188外部冻结HB8–16实际定义；以下先筛准确候选后读本轮证明。一般目标仍未闭合。

## 1. 准确目标与合法交换

目标为同一原剩余域上的EΣV∫q dx∫ψ_yλ_x,V，付预分配ε接收费及√n polylog来源价，或保留原同一行四非负缺口后的版本。λ≤Pβ_x,V⊗Pν_x,V且两current边缘总容量≤1，ψ含原same-alpha targetloss；二者依receiver和原seed，不能作为fixed reference移出dx。β、ν只共父，不互相支配。

正Tonelli允许原ω/x/source/time积分换序，但不能将ω相关权重与padding事件概率相乘。可先用逐ω正测度支配βω⊗νω≤f⊗f，并放0≤aψ≤1；这会丢掉部分联合信息但方向合法。随后若其余测试F(x,y,u)在随机相位前固定（或可由已收费的固定菜单支配），才可对fixed source point pair使用padding概率。原current selector、接收域、q/window和实际支持是否先于相位必须独立核；不能因为输入f固定就自动把所有后验/选择器视为独立。

## 2. 主padding准确候选的独立事件证明

假设同一随机轴平行嵌套dyadic grid，ℓ为其共同确定层，不只是任意具有某种uniform相位的长度。该层相位在[0,ℓ)^n联合均匀。任意可依ω/f选择的停止分区，若y所在块Aω(y)边长≥ℓ，则该层Qℓ(y)⊂Aω(y)。u处于不同停止块意味着u∉Aω(y)，故y,u在层ℓ已经分开；u块无需同样大。此为逐ω包含，非停止规则独立性，无所有level的union费。

半开格给边界唯一归属。固定y,u的exact split概率为

    1−∏_i(1−|y_i−u_i|/ℓ)_+ ≤ min(1,||y−u||1/ℓ)。

包含距离0、距离恰ℓ及相位边界的正确版本。因βω⊗νω≤f⊗f逐ω成立，对fixed非负可测F(y,u)正Tonelli得到

    E∫F 1_cross,large βω(dy)νω(du)
       ≤∫F min(1,||y−u||1/ℓ) f(dy)f(du)。

可对一般有限正f用扩展非负积分；若要有限价格另需右边可积。随机来源和停止规则可依ω，不需与事件独立。该式仍是二次输入测度价，不自动为HB16线性WA或原ε接收费。

## 3. 原模型应用必须保留的资格/尺度账

当前未独核原FULL森林具备上述uniform mod-ℓ law；R107新增ξ森林不可替换R113/114原A_j,t。原半开共同分区只证明partition，不证明随机law。若原格还含随机dilation或层间相关平移，须按实际law条件化并证明所用ℓ确为该同一嵌套层；不能直接套另一个平移网格。

从HB16到§2，若F含ω相关current kernel、aψ、不同row/window或受选Erec，不能直接移出E。仅有Σβ≤f不足以解决这些残余；同时正支配ν及核/接收选择的冻结或有价包络才足够。有限同一current菜单可逐项支配共同pair核并真实收菜单数；不能假定零费。若把接收域扩到固定大域，ε费用也必须记到该大域，不能自动称原Erec费用。

只有y大块的包含不解决small-stop-block补集。若证明改用多ℓ层而不是固定层包含，需真实层费用或可和权重；不同window/父来源复用亦收费。原负信用与四缺口仅所属同一row一次使用，不为padding补集另造信用。

## 4. Astra物理位移候选的独筛

原reciprocal wg(y,u)>κ与ξ_g∈[.5,1]给每因子>κ，因此C(|y_i−u_i|/b)>κξ_g≥κ/2。令Rκ=C^(-1)(κ/2)，则每坐标di<Rκ，

    ||y−u||1/b ≤max(1,Rκ)D_b(y,u)。

这是在原reciprocal域内把clipped距离转未截断距离的合法新增资格。对同一原b,j,g/ξ，log min(1,C/ξ)对logC为1-Lip，故logC的已证L_C（可取18保守）给

    |log w_ξ(y,v)−log w_ξ(u,v)|
          ≤L_C max(1,Rκ)D_b(y,u)。

不多收1/ξ，但两个ξ若不同须另加相应n log比例费。w_ξ(u,v)是同一原行参数的物理辅助权，不自动继承另一u-row history。tiny权转移的指数因子须完整保留；必要support不等于weighted付款，尚待作者准确新预算。

## 5. 第一阶段检查点

主固定层padding候选与Astra位移候选在明确假设下通过独筛。原FULL随机law、HB16实际测试的冻结/有价支配、smallblock补集及二次输入到目标来源/接收预算仍待证明。本轮只短筛，等待准确成稿一次后审，不重复Astra攻坚或扩反例列表。

## 6. 实际大初始块子支：先独筛、后读SB4–7

先收到主代理/来源Sol的准确命题，独推后才读取stopping_boundary_geometry.md全文。SB1–7数学通过；原FULL law/current先后由来源Sol另作原文定位，本审计未重复历史抽取。

整行必须先固定R'_y=R_y∩{||y−u||1≤r}及χ_y=1{side A_{j,ell}(y)≥S}，保持原A、α、Π及删除。R183完整删除行对R'给同一ψ的N'_ell/e_g界，随后λ'=χ1_near λ；此顺序正确，非把瞬时停止块门搬过饱和FTC。R_y⊂Z_ell保证u不在这个初始cube，逐ω的coarse包含只需该cube为同一原网格节点，不要求j/ell或停止规则独立。半开边界不产生遗漏。

SB5正放ψ与HB密度、按V共父支配再丢同V标签，方向正确；不需要ν≤β。条件于所有预θ固定数据，且原θ仍为所述均匀law时，剩余p_x(y)p_x(u)/q²固定，SB2和共同FIRST ∫p_x f≤q给

    EΣV∫ψ λ'≤min(1,r/S)。

原接收域E与q也预θ固定，正Tonelli保留实际dx；故SB7常数Crec=16Λ/(3Kκ)正确。选择实际存在的确定网格层S≥Crec r/ε（可向上取层）支付该子支ε∫E qdx，无time/j/停止深度费用。若只知道均匀边缘而非对预冻结数据的合法条件law，须补此资格；当前来源消息称原HR1–3确按该顺序引入单θ。不能把依θ的测试/接收域留下再直接套概率。

D_y帽给r=b max(1,5log n+1/2)d的回代正确，但b、r、S须在所用θ平均前固定（先以单window常数为准）。当所需S超出top，结论只是大块支空；small initial block、远bad源及其他mother不被此付款。多window/不同receiver带的ε须按原总账明确分配。SB4–7是新明确子支的真实接收费，不是HB16全体证明。

## 7. 原来源稿与preθ接收选层

已全文读grid_boundary_budget.md：GB1–3明确原FULL单θ、原层a·2^ell/n及current/E先后；不是R107新增ξ。按来源稿所列亲读定位使用这些资格，不重复历史抽取。GB4、GB8–10与§6一致，通过；同α留在实际ψ中，仅正放大时才用ψ≤1。

主代理后送SB8先独筛通过：每个preθ固定x可从原有限层中可测选择S(x)，同时选择preθ的r(x)。逐x应用SB2再Tonelli，若Crec r(x)/S(x)≤ε统一成立，所得仍为ε∫E qdx，不乘选中层的个数。不能让S选择使用所平均θ的初始块/来源。不存在足够层时该大块支空，不能写为已支付全部near支。R188 hard带的r(x)=16b Rbar_n B_n/(1−s(x))²须只在其已证hard带及同一preθ窗口参数下使用；不同窗口仍另账。

## 8. 有限代码的静态核验范围

已读boundary_checks.py、adaptive_capacity_checks.py及numerical_review.md，不执行重跑。前者48相位case按5+4²+3³计，半开floor与整倍1/8位移的相位中点枚举确为这些有限case的exact概率；26个深度3停止分区给26·4·16²=26624结构比较。后者3支持大小×4半径×3模式=36，固定概率产品、同相位split/near、phase-dependent因子始终≤1且未重新归一，正确测试SB5–6的有限支配代数。重放成功仅按独立numerical_review记载；本审计没有运行实验。两脚本不实现原capture/FULL，也不为全维HB16认证。

## 9. reciprocal实际距离改进的独筛

Astra准确Rκ候选先于成稿独筛通过。原w(r)≤e^(−|r|)；d≥1时C(d)=(h*h*w)(d)，因为该C窗完全在F=φ区域。h*h为支持[-1,1]的概率核，故C(d)≤e^(1−d)。reciprocal给每个C(di)>κξ_g≥κ/2；置Rκ=1+log(2/κ)>1，di≥Rκ将矛盾，故di<Rκ，进而

    ||y−u||1≤bRκ D_b(y,u)。

实际K=1有κ≥1/3，所以Rκ≤1+log6；不再需原carrier的O(log n)坐标帽。这个改进只把同一个SB/GB预算中的r替为bRκd，不能重复领取ε；非reciprocal域没有这项资格。same-ξ的good-overlap物理转移仍需保留L_C RκD_b指数费，必要支持不自动变付款。

## 10. 作者全文与最终整合范围

已全文读joint_geometry.md：JG5–12的Rκ证明与同一次SB/GB接收付款通过。JG13未来损失测度总质量恰ψ；JG14用high和good得(1−ψ)ρJ(e^Ω−1)/(6q)，常数及方向正确。JG15高A的小current容量另需同一合法J的FIRST Jν≤q，作者已明确，不从current容量独自反推。JG16固定同ell/g的函数B(logC)斜率0或−1，故anchor转移常数18而非36；JG17的加性e^H−1完整保留。该目标放大仍未有smallblock全局价。

已全文读proof.tex.txt，并窄核最终SB9/Rκ替换、report.md与reproduce.py。整合的16Λ/(3Kκ)、真实接收域、先完整时间子行后λ、共父正产品支配及preθ receiver选层均与已审主链一致。只支付原reciprocal正J-share指定大初始块近对支；无第二笔Rκ付款，无其他mother闭合声明。数值review含三脚本独立重放记录：48相位/26624停止、36衰减与40个40/60dps半径诊断；后者非interval且JSON只保末精度块，标签准确。reciprocal_radius_checks.py的E4二阶差分仅用d≥1，静态未见错误，本审计未执行任何脚本。

reproduce.py核归档manifest后将三脚本复制到新目录，逐项实际执行并逐byte比较JSON，失败非零；依赖mpmath另需可用环境，报告已明示。manifest/自身不进入下面绑定，也不把尚未执行的最终归档driver声称为本审计运行。没有编译PDF。

结论：上述明确子支及必要第三槽接口通过。一般HB16与small initial block的good未来放大仍未付，原最终弱型上界未闭合。至此停止数学扩展，只绑定最终字节。

## 11. 最终字节绑定与冻结

已窄读Astra最后§3 preθ逐x选层修订，与SB8一致，无新增数学。以下SHA256由本审计实算；绑定14个其余最终文件，不绑定自身、后造manifest或归档外README。hash仅绑定所述审查范围，不使有限数值成为一般证明。

| 文件 | SHA256 |
|---|---|
| adaptive_capacity_checks.json | 57bb4e8c1c2175b13165d3ff3115b52137af07f781dbd09413d7561db07edbcb |
| adaptive_capacity_checks.py | d8b5050dee14775cf86c1e2701f929acaedd79e1e65c987b768367efb9ff43f4 |
| boundary_checks.json | 3a09bfc02b39abca810906f433e1be7ac83881607dfce2e5f66c5af6baf8ac17 |
| boundary_checks.py | 4da93ea49f0949598a35fe4c95d9e546761c6638915e89dda052124dbeb9dc9b |
| grid_boundary_budget.md | 3a55e59f5dc836d875be767f1d4f85a87f1add1dfaff00ad8f3fde89dc25010d |
| joint_geometry.md | c5b0f89d2e7de319a3f55cffe802c7b72fe8f75eb748c6066d5de4462607cd30 |
| numerical_review.md | f20f8a370e1ebf023ec7d7633cb93c509a0737ce56e9755f7a2885ab27ad6707 |
| proof.tex.txt | cae8eab75fc614f68661bfba6ca60d605b4fd4e352e48f37485a686f26d6881e |
| reciprocal_radius_checks.json | caaaf736d2aab786be4e0022c6b206fb1d75f76f93d5f1b4b193e60b8997545c |
| reciprocal_radius_checks.py | c41d5ed169cdf11958188e672121ed251c55e15b8f21aa81aa6073bfcbd5e306 |
| report.md | 5b5d6b924393c9f829f3081c94f24a3fb70d5305a3f619f861f8d2d457a9004e |
| reproduce.py | 9173b08555bd7d4e71ca61f1aff59ec71ca59ec54aeb0eaff5fa4ca0f1120375 |
| stopping_boundary_geometry.md | 6df5c7e8ad78f88b040d957edee63b0e6bc8a95f7ff330db42d784f5d689f63e |
| task_contract.md | 9077e7d51d7d051c261b8fd9b7adcbd69f45ae5704829ab3c0cc3b3e9cf36099 |

冻结结论：指定大初始停止块近reciprocal正J-share子支的实际接收吸收通过；Rκ改善同一价格。small初始块的未来target放大及一般HB16仍未闭合。未运行数值、未Git、未编译、未改他人文件；本轮审计停止。
