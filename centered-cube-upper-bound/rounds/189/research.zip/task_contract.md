# R189：近来源对的联合几何预算

上一轮为实际进展：R188已独审、归档、重放并推送，HEAD c3dcf3d5de02de52032097e5585e5c63daf3ed54。一般目标未闭合。本轮开始工作区干净。

准确目标是R188 HB16（或保留实际四缺口的较弱版本）：EΣV∫q dx∫ψλ ≤ εE∫q dx + Cε sqrt(n)polylog(n)WA。保持任意正L1输入、真实Lebesgue接收域、原same-alpha/current/FIRST、所有原窗口和来源费用。R188外来源—坏来源分离区域已支付；本轮关注其近对补集和极小good重叠，不换成特殊函数类。

冻结工具及定义：仓库外R188 final_checkpoint中的HB、OB、SR；R183完整删除行、R185亲和、R187全软尾。λ依赖x，只是实际current product的密度≤1；来源互支配、停止边界密度帽和无费固定参考均不可假定。

分工：Astra r166_raw_budget独占joint_geometry.md；Sol r166_exact_certificate独占grid_boundary_budget.md；Sol r164_audit独占independent_audit.md。主代理负责具体推导、有限计算和整合。复用上下文，不子代理Git或spawn，不覆盖其他文件。每项有界任务交付即停，审计先筛命题后读证明。

主代理考察固定输入支配下的随机停止边界费用，先明确网格law及最小尺度条件；不会将自适应来源与随机网格假定独立。数值需实际本机运行，有限模型不证明原几何。完整研究完成后才单独归档提交，不编译PDF。
