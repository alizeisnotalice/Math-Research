import json
from pathlib import Path
import mpmath as mp
rows=[]
for n in [2,16,256,1000000]:
 vals=[]
 for precision in [40,60]:
  mp.mp.dps=precision
  k=(1+mp.exp(-n*mp.log1p(mp.mpf(1)/n)))/3
  radius=1+mp.log(2/k)
  local=[]
  for d in [mp.mpf(1),mp.mpf('1.5'),mp.mpf(2),radius,radius+mp.mpf('.5')]:
   c=mp.expint(4,d-1)-2*mp.expint(4,d)+mp.expint(4,d+1)
   upper=mp.exp(1-d)
   assert 0<c<=upper
   if d>=radius:assert c<k/2
   local.append({'d':mp.nstr(d,30),'C':mp.nstr(c,30),'upper':mp.nstr(upper,30)})
  vals.append((radius,local))
 assert abs(vals[0][0]-vals[1][0])<mp.mpf('1e-35')
 rows.append({'n':n,'kappa':mp.nstr(k,30),'R_kappa':mp.nstr(radius,30),'rows':vals[-1][1]})
Path(__file__).with_suffix('.json').write_text(json.dumps({'dimensions':4,'evaluations':40,'precisions':[40,60],'rows':rows,'scope':'Finite high precision diagnostics, not interval enclosures. C formula is only for d>=1; no original FULL realization.'},indent=2)+'\n')
print('40 high precision reciprocal-radius evaluations passed')
