from fractions import Fraction as F
from itertools import product
from pathlib import Path
import json

def phase(n, m, delta):
    same=0
    for a in product(range(m),repeat=n):
        # phase midpoints avoid boundary, delta integer/m
        yes=True
        for ai,di in zip(a,delta):
            theta=F(2*ai+1,2*m)
            yes &= ((-theta)//1 == (F(di,m)-theta)//1)
        same+=int(yes)
    exact=1-F(same,m**n)
    formula=1
    for di in delta:formula*=max(F(0),1-F(abs(di),m))
    formula=1-formula
    assert exact==formula
    assert exact<=min(F(1),sum(F(abs(di),m) for di in delta))
    return {'n':n,'m':m,'delta':delta,'probability':str(exact)}

def partitions(lo,size):
    yield [(lo,lo+size)]
    if size>1:
        half=size//2
        for a in partitions(lo,half):
            for b in partitions(lo+half,half):yield a+b

rows=[]
for n,m,ds in [(1,8,[0,1,7,8,11]),(2,8,[0,1,4,8]),(3,8,[0,1,4])]:
    for d in product(ds,repeat=n):rows.append(phase(n,m,d))
checks=0
# Exhaust every dyadic stop partition on [0,8), including heavy finest fallback.
for part in partitions(0,8):
 for ell in [1,2,4,8]:
  for y,u in product(range(16),repeat=2):
   y,u=F(y,2),F(u,2)
   block=next((l,r) for l,r in part if l<=y<r)
   if block[1]-block[0]>=ell and not(block[0]<=u<block[1]):
    assert y//ell != u//ell
   checks+=1
result={'phase_cases':len(rows),'phase_rows':rows,'stop_partition_checks':checks,'stages':['initial:1D','pressure:zero/full displacement and unequal stops','expanded:2D/3D phases and all depth3 binary partitions'],'scope':'Finite exact arithmetic checks of SB1/SB2; no original current/alpha/forest realization or HB16 certification.'}
out=Path(__file__).with_suffix('.json');out.write_text(json.dumps(result,indent=2)+'\n');print({'phase_cases':len(rows),'stop_partition_checks':checks})
