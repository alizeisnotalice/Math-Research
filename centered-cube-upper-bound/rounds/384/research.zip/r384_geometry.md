# R384 — Full-source witnesses lift a window receipt to entire receiver rows

## 1. Frozen core and precise new claim

Keep the complete R383 flow contract, including actual Lebesgue du,dv, full f, m_u=f(Q_u)=q_uR_u^n, q_-≤q_u≤λ, all original outside/dense/deep/not-Bplus and strict far/past gates, the original reciprocal J, and the physical clock including its terminal atom. No plan, target bound, or field-defining threshold is changed.

Use the frozen quantities from /tmp/r383_flow.md §§2–3:

π_u(dy)=f(y)c_u(y)dy/m_u,
α_u(y)=the original clock-averaged marked row density,
A_u=∫α_u dπ_u,
E_hi={A_u>2δ},  Y_u={α_u>δ},   0<δ≤1/3.

Write a_u=∫_{Y_u}α_u dπ_u for u∈E_hi. Then 0≤α_u≤1, a_u>δ, and

G_core=∫_{E_hi}q_u a_u du.

More precisely, the (u,y) marginal of the original core cost is
q_u du π_u(dy) α_u(y)1_{Y_u}(y). The original (m_u−m_v) increment and all clock/receiver labels have already been integrated **exactly** into α_u; they are not replaced or paid again in this note.

Fix any measurable closed source-window map

I(y)=[L(y),U(y)],  0<L(y)≤U(y)<∞,
w_u(y)=1_{m_u∈I(y)},
F_u=∫w_u(y)π_u(dy).

F_u uses the complete full-f capture law, including sources outside Y_u and sources carrying no original traffic. It is not the original cost-weighted in-window fraction. For a fixed C≥1 define

E_lift={u∈E_hi:a_u≤C F_u}.

Pay the following union of two disjoint pieces:

* all original core traffic from u∈E_lift;
* for u∈E_hi\E_lift, only traffic whose actual source y has w_u(y)=1.

Its total cost G_paid obeys

G_paid ≤ P_C := (Cλ/q_-)∫ f(y)[1+log(U(y)/L(y))]dy.             (1)

If the logarithmic window width is at most D, then

                    P_C ≤ Cλ(1+D)W/q_-.                       (2)

The exact remaining original traffic has the additional gates

             a_u>C F_u,                 m_u∉I(y).             (3)

No source, pair, or clock label is otherwise discarded in the definition of this remainder. In particular the result is valid if the initial core already contains some different source-window-complement marks.

For C=2 and D=√n, the new source fee is

                    2λ(1+√n)W/q_-,                           (4)

with no δ inverse, no B* factor, and no new receiver-budget or target-cap fee. This is a genuine root-order payment for the indicated union; it does not assert that the union covers the entire core.

## 2. Exact row comparison and actual-center payment

Let b_u=∫_{Y_u}α_u(y)w_u(y)π_u(dy). Because 0≤α_u≤1,

                         0≤b_u≤F_u.

The paid row density is precisely

p_u=1_{E_lift}a_u+1_{E_hi\E_lift}b_u.

On E_lift its definition gives a_u≤C F_u. On its complement b_u≤F_u≤C F_u. Therefore

G_paid=∫_{E_hi}q_u p_u du≤C∫_E q_u F_u du
      =C∫f(y)∫_E c_u(y)w_u(y)du/R_u^n dy.                     (5)

The last equality uses full matching m_u=q_uR_u^n and positive Tonelli. The witnessing source integrated on the right need not equal the source of the traffic being paid on the left. This is a lawful use of an independent additional sample from π_u as an accounting device; it assumes neither independence of f coordinates nor independence in the original transport plan.

For fixed y, set ρ=2||u−y||∞ and z=q_-ρ^n. Actual capture implies m_u≥z. Hence

c_u(y)1_{L≤m_u≤U}/m_u
 ≤1_{z≤U}/max(L,z).

The actual-center radial envelope has integral (1+log(U/L))/q_-. Since R_u^−n=q_u/m_u≤λ/m_u, insertion in (5) proves (1). This is the same certified center envelope as R382, now applied to a **different paid cost**: whole-row traffic selected by a full-f witness. No independent radius integration or density cap is introduced. Closed zero-width windows retain their constant 1 price.

No new operator reversibility assumption is needed. In particular no du L² estimate is transferred to m_u du or q_u du.

## 3. Exact residual information and single-fee ledger

Let G_res=G_core−G_paid. Its row density on E_hi\E_lift is

r_u=a_u−b_u≥a_u−F_u>(1−1/C)a_u.                               (6)

For C>1, a_u>δ implies

r_u>δ(1−1/C),
π_u(Y_u∩{m_u∉I(y)})≥r_u>δ(1−1/C).                            (7)

Thus for C=2 every remaining receiver captures more than δm_u/2 of its actual full-f mass in Y_u outside the window; its original retained row cost exceeds δ/2 relative to q_u du. The small receiver v is not asserted to inherit any of these properties. For C=1 the exact bound r_u≥a_u−F_u>0 remains, but no positive uniform δ fraction is claimed.

The original screening gave G_original≤3δX_q+G_core. Therefore the complete replacement is

G_original≤3δX_q+P_C+G_res.                                   (8)

If an existing BH ledger is BH≤G_original+E_old X_q+S_old, then

BH≤G_res+(E_old+3δ)X_q+S_old+P_C.                             (9)

If one starts with a ledger already containing the R383 screening fee, it is NOT added again. In the full entrance with multiplier 2Λ, the new source price is exactly 2ΛP_C. All prior plan/template/entrance costs and parameters remain unchanged.

This union receipt **replaces** the old current-source window payment for this slot. Its price is C times the window envelope, not the old price plus C times that price. On low-lift rows the old in-window branch is included once; on high-lift rows it is part of the already-paid whole row. If the old window branch has already been charged in a different fixed ledger, one must rewrite that ledger or charge a genuinely additional receipt; no free retroactive expansion is claimed.

Unlike a witness restricted to Y_u, the full-f F_u can remain positive even if the starting θ already excludes current sources lying in this same window. In that case b_u=0, but witness sources carrying zero original cost can still justify payment of an entire row when a_u≤CF_u. The theorem and its fee are unchanged.

A static threshold is available as a weaker corollary: since a_u≤1, every row with F_u≥κ is paid by taking C=1/κ. The adaptive rule avoids that unnecessary κ inverse when a_u is small. The main result uses C=2.

## 4. Strictly new coverage: exact cube/source diagnostic

The following example tests the difference between the two paid branches. It uses actual four-dimensional axis-parallel cubes and a single full integrable f with exact matching. Receiver integration is **finite positive quadrature, not Lebesgue du**, so it is not offered as a native realization of the continuous hard-past field or as a test of the center-capacity theorem.

Take n=4,

Q_v=[0,1/2]^4,
Q_u=[17/40,57/40]×[-1/4,3/4]^3,
R_v=1/2, R_u=1,
q_v=9/10, q_u=19/20,
m_v=9/160, m_u=19/20.

Inside their intersection choose disjoint source boxes

D_1=[17/40,87/200]×[0,1/2]^3,
D_2=[87/200,89/200]×[0,1/2]^3,

each of volume 1/800. Set f=5 on D_1∪D_2, f=35/48 on Q_v outside these boxes, f=14323/15216 on Q_u\Q_v, and f=0 elsewhere. Direct integration gives precisely the stated m_v,m_u and q band [3/4,1]. Take the high-source threshold T=4, and the target law uniform on Q_v for each high source. Only D_1,D_2 carry positive high-source traffic.

The original far gate holds: m_u/m_v=152/9>8>e²=exp(√4). The center separation is 27/40 in the first coordinate. Thus 2dist=27/20>3^(1/4), since (27/20)^4>3, which verifies the original outside gate. There is one protruding coordinate, exceeding n/8; its truncation d=17/20 exceeds n/20. The geometric capture fraction is p=3/20. For the R369 Bplus threshold, β=5/4 and s_eff=1/2 give allowance 1/40, whereas the actual total excess is 17/20. Thus this pair is outside Bplus as well.

Assign receiver quadrature weights w_v=100 and w_u=1, and literal gates h=H=400. These are the example’s fixed literal gate values; the example does not verify the synchronized R379 field/parameter selection or its full historical eligibility. In particular weights 100 and 1 are not continuous Lebesgue du. At either high source,

Z=16000/9>400,
J=304180/171>400.

The large receiver sits at r=b=1, so its complete normalized physical clock is the terminal atom. Its true marked source density is

α=(Z/J)(1−m_v/m_u)(1−q_v/5)(1−p)=99671/152090.

Take δ=1/1000. Then Y_u=D_1∪D_2 and

a_u=99671/11558840>2δ.

Choose the closed source window [m_u,m_u] on D_1, and [m_u/4,m_u/4] elsewhere. It has logarithmic width zero, and

F_u=π_u(D_1)=1/152,
a_u=2αF_u<2F_u.

The adaptive C=2 receipt therefore pays the whole row. The old current-source window branch pays only D_1. The original strictly positive cost from D_2, whose actual source is outside its window, is

q_u w_u π_u(D_2)α=99671/24334400>0.                             (10)

This proves a strict difference of coverage in the exact marked-flow algebra with actual cube/source matching. The large quadrature weights must not be substituted for Lebesgue center volume in (5); the continuous receipt itself is proved independently in §2.

## 5. Choice scope and remaining problem

The theorem holds for every preselected measurable full source-window map I(y). It may depend on the frozen full field and a fixed chosen plan. The quantities α,Y,a are computed from the starting core and remain frozen while its paid pieces are partitioned. The whole-row trigger depends on this actual plan: a newly constructed plan cannot inherit the old E_lift qualification. Changing the plan requires recomputing α,Y,a and the qualification, or a separate proof; no R378 plan-reconstruction option is asserted here.

One may compare finitely many entire window-map candidates having a common price bound and choose one by its total actual paid cost, without multiplying the price by the number of candidates. However F_u couples different source points through π_u. Independent maximization at each source of the old current-traffic coverage does not establish optimality of this nonlinear receiver-lift payoff.

No theorem here produces a window map that covers all core receivers or bounds G_res. The new actual result is the root-price union receipt, with the strict full-f residual guarantees (6)–(7). General source-window coverage and the remaining jointly marked traffic are still unproved. Small geometric overlap is never used as a bound on f-mass.

## 6. Reproducible three-stage exact verification

Executed locally:

python3 /tmp/r384_geometry_check.py

PASS {'adaptive_union': 24608, 'cube_witness': 243,
      'center_envelope': 256} total 25107
strictly new positive cube-quadrature rows 243

Stage 1 checks the frozen posterior core, adaptive union identity/price and residual lower bounds with exact Fraction arithmetic, including equality in the paid threshold. Stage 2 varies the actual four-dimensional full-f matching example, receiver quadrature weights and δ; all 243 cases have strictly positive old-source-window-complement cost paid by the whole-row rule. It also verifies original exp(√4) far, outside/dense/deep/not-Bplus gates using exact rational certificates, including a rational Taylor upper certificate e²<8. Stage 3 checks the actual-center pointwise envelope used analytically in §2. No numerical fit, new infinite-flow claim, or density cap is used.
