from fractions import Fraction as F
from itertools import product
from math import factorial
counts={'adaptive_union':0,'cube_witness':0,'center_envelope':0}
new_positive=0
# Stage 1: exact full-source posterior, frozen alpha/Y, actual row density.
for delta in (F(1,20),F(1,10),F(1,5)):
 for p0 in (F(1,8),F(1,4),F(1,2)):
  for p1 in (F(1,8),F(1,4)):
   p=[p0,p1,1-p0-p1]
   for alpha in product((F(0),delta,F(1,2),F(1)),repeat=3):
    A=sum(p[i]*alpha[i] for i in range(3))
    if A<=2*delta:continue
    Y=[int(x>delta) for x in alpha]
    core=sum(p[i]*alpha[i]*Y[i] for i in range(3))
    assert core>A-delta and core>delta
    assert sum(p[i]*Y[i] for i in range(3))>delta/(1-delta)
    for mark in product((0,1),repeat=3):
     witness=sum(p[i]*mark[i] for i in range(3))
     inside=sum(p[i]*alpha[i]*Y[i]*mark[i] for i in range(3))
     for C in (F(1),F(3,2),F(2),F(3)):
      whole=int(core<=C*witness)
      paid=core if whole else inside
      residual=F(0) if whole else core-inside
      assert paid+residual==core
      assert paid<=C*witness
      if not whole:
       assert residual>=core-witness>(1-1/C)*core
       assert sum(p[i]*Y[i]*(1-mark[i]) for i in range(3))>=residual
      counts['adaptive_union']+=1
# Stage 2: true 4D cube intersections and full-f matching, but receiver weights
# are finite quadrature, explicitly NOT Lebesgue du.
# e^2<8 via rational Taylor plus geometric tail.
s=sum(F(2**k,factorial(k)) for k in range(11))
remainder=F(2**11,factorial(11))/(1-F(2,12))
assert s+remainder<8
n=4;Rv=F(1,2);Ru=F(1);qv=F(9,10);mv=qv*Rv**n
volv=Rv**n;volu=F(1);overlap=F(3,40)*F(1,2)**3
atomvol=F(1,100)*F(1,2)**3
pgeom=overlap/volv
# u-v center displacement = 27/40 in the first coordinate only.
assert F(27,20)**4>3 # outside 2dist > 3^(1/4) Ru
assert 1>F(n,8) and 1-pgeom>F(n,20) # dense and deep
beta=1+F(1,n);seff=Rv
bplus=n*((1+beta)*seff-Ru)**2/(4*beta*seff)
assert F(27,20)-(Ru-Rv)>bplus
for peak,qu,wv,wu,delta in product((F(5),F(6),F(7)),(F(9,10),F(19,20),F(1)),
                                 (F(100),F(1000),F(10000)),(F(1,10),F(1),F(10)),
                                 (F(1,2000),F(1,1000),F(1,500))):
 mu=qu
 low=(mv-2*peak*atomvol)/(volv-2*atomvol)
 intermass=2*peak*atomvol+low*(overlap-2*atomvol)
 bg=(mu-intermass)/(volu-overlap)
 assert 0<low<4*qv and 0<bg<4*qv and peak>4*qu
 assert 2*peak*atomvol+low*(volv-2*atomvol)==mv
 assert intermass+bg*(volu-overlap)==mu
 assert mu>8*mv # original K=e^sqrt(4)=e^2<8, strictly far
 Z=wv/mv;J=Z+wu/mu
 assert Z>400 and J>=400 # literal strict-past and J gates
 # Large receiver is at r=b=1, so complete physical nu is the terminal atom.
 alpha=(Z/J)*(1-mv/mu)*(1-qv/peak)*(1-pgeom)
 pi_atom=peak*atomvol/mu
 core=2*pi_atom*alpha
 assert alpha>delta and core>2*delta
 witness=pi_atom # source window [mu,mu] on first high atom only
 inside=pi_atom*alpha
 assert core<=2*witness
 original=wu*wv*(1-mv/mu)*(2*atomvol)*(peak-qv)/mv/J*(1-pgeom)
 assert original==qu*wu*core
 old_unpaid=qu*wu*(core-inside)
 assert old_unpaid>0 # actual current source misses the window, but whole row is paid
 new_positive+=1
 counts['cube_witness']+=1
# Stage 3: pointwise envelope used for actual selected Lebesgue centers.
qm=F(3,4)
for n,rho,q,R,L,U in product(range(1,5),(F(1,4),F(1,2),F(1)),(qm,F(1)),
                            (F(1,2),F(1),F(2)),(F(1,2),F(1)),(F(1),F(2))):
 if L>U or rho>R:continue
 mass=q*R**n;z=qm*rho**n
 lhs=F(int(L<=mass<=U),1)/mass
 rhs=F(0) if z>U else 1/max(L,z)
 assert lhs<=rhs
 counts['center_envelope']+=1
print('PASS',counts,'total',sum(counts.values()),'strictly new positive cube-quadrature rows',new_positive)
