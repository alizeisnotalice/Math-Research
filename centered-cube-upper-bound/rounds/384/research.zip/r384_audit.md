# R384 independent audit — FINAL PASS

Final bounded proof, complete-code, exact-example and full-ledger review is complete. The full-source whole-row/window union receipt and its same-price fractional strengthening pass. No substantive issue remains. General window construction/coverage, the actual residual and inherited outer/soft/history/scale budgets are unproved. Only this audit was modified; previous interfaces were used as specified, not comprehensively re-audited.

Independent screens below are retained as chronology. Their pending status is superseded by the final proof reviews and byte bindings.

## 1. Precise input and the fixed source-window capacity

Let the original core cost be a finite positive marked measure whose (u,y) marginal is

    q_u du * phi_u(y) pi_u(dy),
    pi_u(dy)=f(y)c_u(y)dy/m_u,
    0<=phi_u(y)<=1.

In the R383 construction phi_u=1_{Aorig_u>2delta}1_{alpha_u(y)>delta}alpha_u(y), and its actual row density Acore_u=integral phi_u d pi_u obeys Acore_u>delta on every surviving receiver, up to the actual du-null conventions. Original Y_u={alpha_u>delta} satisfies pi_u(Y_u)>delta/(1-delta), and core source is contained in Y_u. These are the SAME frozen plan, not probabilities recalculated from a truncated source. The full source f, not high/surplus alone, normalizes pi_u.

Choose ONE jointly measurable closed source-only mass window I(y)=[L(y),U(y)] with0<L<=U<infinity and log(U/L)<=D. Its membership event is m_u in I(y). The endpoints may depend on the full frozen field/plan but may not be privately chosen for u. Define

    F_u=pi_u{m_u in I(y)}.

It is measurable by the original joint fields and Tonelli. Then exactly

    integral_E q_u F_u du
      =integral f(y) integral_E c_u(y)1_{m_u in I(y)}du/R_u^n dy
      <=lambda(1+D)W/q_-.

The equality uses q_u/m_u=R_u^-n. The inequality is the R382 actual-center closed mass-window envelope. It keeps the entire true source and actual receiver du, has no B_star factor, and includes equality endpoints and zero-width mass atoms. If widths are variable, retain lambda/q_- integral f[1+log(U/L)] rather than replace them by a finite constant unless that integral is known finite. W=0 gives zero traffic; zero-source rows elsewhere are ignored. No source independence, density ceiling or source-counting partition is needed.

A window private to u would invalidate this uniform center integral. The fact that F_u is itself receiver-dependent is legitimate because it is derived from ONE source-only window, not an arbitrarily selected posterior event per receiver.

## 2. Initial kappa witness candidate: PASS

First use F_u^Y=pi_u[Y_u intersect {m_u in I(y)}]. For a fixed constant kappa>0, let hit receivers be surviving core receivers with F_u^Y>=kappa. Their WHOLE original core row cost is at most q_u du, not just the part sourced inside the window. Since q_u<=q_u F_u^Y/kappa on hits, their total cost is at most

    lambda(1+D)W/(kappa q_-).

This is a real integrated whole-row bound even if actual traffic is largely sourced outside the window. Dropping Y for the center-capacity upper bound only enlarges it. No target-plan marginal is changed by this positive cost restriction. Threshold equality belongs to the paid set and the complementary receiver set has F_u^Y<kappa.

For0<delta<=1/3 set kappa=delta/[2(1-delta)]. R383 gives pi_uY_u>2kappa. Every unpaid surviving receiver therefore has

    pi_u[Y_u intersect {m_u outside I(y)}]>kappa,

or equivalently its captured full-f mass there exceeds kappa*m_u. This does not show that this mass is disjoint across u or that it has an acceptable global source capacity.

Noncircularity is essential. If alpha/Y was defined using a prior LARGE-u complement factor1_{m_u outside I(y)} for this SAME window, then F_u^Y=0 identically. The kappa criterion cannot recover that previously removed traffic. A new window, or restarting from the fixed plan's cost BEFORE that window deletion and replacing its old fee, is necessary. A small-v-only window deletion does not by itself imply this particular large-window zero statement. There is no free repeated source charge.

## 3. Stronger relative whole-row/source-window union: PASS

Now use the COMPLETE posterior witness F_u=pi_u{m_u in I(y)}, without requiring Y. Fix a constant C>=1. Split the same core measure in this exact order:

1. If Acore_u<=C F_u, pay the entire core row.
2. On the remaining receivers Acore_u>C F_u, pay only actual core traffic whose OLD source y satisfies m_u in I(y).
3. Retain the remaining original traffic, with both the strong-row and source-outside-window marks.

Write Awin_u=integral phi_u 1_window d pi_u<=F_u. The paid density is Acore on weak rows and Awin on strong rows. Therefore

    Paid <= C integral q_u F_u du
         <= C lambda(1+D)W/q_-.

The two positive pieces do not overlap, and their price does not add a second full window fee. For C=2 and D=sqrt(n) this is a root-order source receipt2lambda(1+sqrt(n))W/q_-, with no delta^-1 factor, no new X coefficient, no B_star and no change to target/template or physical clock. It pays a superset of the OLD actual source-window branch on this SAME fixed core measure. It does not imply a fixed covered fraction or that its complete RHS is always smaller, since its allowed source price is C times the old window price.

On every retained strong receiver,

    Ares_u=Acore_u-Awin_u >=Acore_u-F_u
           >(1-1/C)Acore_u.

For C>1 the surviving R383 core also has Acore_u>delta, hence

    Ares_u>delta(1-1/C),
    pi_u[Y_u intersect window_complement]>=Ares_u
                                      >delta(1-1/C).

At C=1 only the nonnegative/strictly positive versions are available; one may not claim a positive uniform delta multiple there. At F_u=0 a positive row is strong and Awin=0; at Acore=F=0 the paid row is zero. Weak threshold equality is paid, so there is no lost boundary case. All source/radius mass atoms and original strict-past qualifications remain in their original places.

The COMPLETE-posterior F can be positive even when the witness window has zero actual core traffic. This legitimately buys some other source's cost, because the proof charges q_u F_u as captured full-f witness mass through the actual center envelope. It is not an independence or transport coupling assertion. In particular this stronger criterion does not have the F^Y=0 vacuity merely because alpha already excludes the same window. If applied AFTER an older payment it is a new positive receipt with its own source fee; it cannot reuse that older fee for free. To claim a replacement tariff and strict enlargement of a prior branch, rebuild the joint positive split from the SAME not-yet-deleted cost.

## 4. Plan dependence, window selection and optional reconstruction

The theorem is uniform for any fixed original flow satisfying the stated receiver/source marginal domination, but its weak-row event is computed from THAT flow's actual Acore. Choosing an anchor/window from a fixed full plan is legal. It may depend on all original costs, while remaining one function of y for every u. No general selection theorem is needed for a prescribed measurable window.

However this is a nonlinear receiver trigger: Acore<=C*pi_u(window) couples all source points in one receiver. R382's sourcewise finite Gamma_y score maximization does not automatically optimize this new paid objective independently for each y. Any optimization claim must give its correct global candidate class and exact feasible selection. Pointwise adaptive choices per receiver remain outside the center envelope theorem.

If a new plan is constructed after freezing weak rows from an old plan, the whole-row payment bound itself need NOT survive: the new actual cost on those rows could exceed Cq_uF_u. This is stronger than merely losing an old optimal coverage rate. Unlike an ordinary source-window receipt, arbitrary source exactness alone does not preserve an OLD plan's weak-row trigger. One must recompute Acore/weak rows for the new plan or prove a separate domination preserving their cost. Likewise the R383 alpha/Y/low-row absorption must refer to the chosen actual flow. A residual-kernel R378 reconstruction based on old plan-triggered masks cannot be declared a complete new same-price plan without those additional facts.

For this initial candidate the safest complete accounting is the SAME fixed plan, exact positive Paid+Residual identity, unchanged target capacity and all original outer factors/previously chosen fees. The new source coefficient is multiplied by2Lambda at the original entrance. No old Hall upper bill may be reduced by subtracting this positive payment, and no original square, return/capture credit or previously paid window is spent twice. The core/strong-row and source-outside complement remains unpaid. All old H, soft/history/extreme-scale/threshold/limit obligations remain.

## 5. Bounded code evidence reviewed

After independently deriving these statements, read the complete parent script r384_lift_check.py. Its3600 Fraction cases are partitioned432/1008/2160 over finite posterior masses, row densities and C values. It correctly checks the weak/strong cost partition, paid<=CF, conservation, residual>=A-F and strict positive C>1 residual fraction. The additional uncounted exact example has F=1/4, zero actual window traffic, A=1/2,C=2, so a wholly different source's positive traffic is legitimately paid at threshold equality. This is an abstract probability example, not an original cube/history realization or a general root result. Parent confirms the actual full run; this reviewer did not repeat it or merge counts with any other script.

Screen decision: the initial kappa criterion and the stronger C-union receipt pass under the precise source-only/frozen-flow quantifiers above. The stronger C2 construction has the displayed root branch price but no general coverage guarantee. The author proof, real-cube diagnostic and complete ledger are reviewed below.

## 6. Provisional current main/ledger/readme integration: PASS

Read the current r384_main.md, complete inherited-plus-increment ledger and readme. The new preferred block explicitly restarts from the fixed same-plan original G before deleting this particular source window, applies R383's low-flow absorption and then the new whole-row/window union to its actual core. The new F_lift=C lambda(1+D)/q_- replaces the previous optional window tariff; F2 is not charged again. The actual R_lift, not an old Hall upper deficiency, is retained. No old epsilon/epsilon-prime approximation fee is added in this exact-cost option.

The X coefficient remains eta+sigma_n+epsilon383, and source price is C338+F_lift. Entrance keeps8lambda H W,2d_eff A_n W_nu/H,2R_lift, twice the actual receiver/source fees, then Lambda. With sigma<=eta/2, eta=kappa/(6Lambda), epsilon383=kappa/(4Lambda), this slot's coefficient is<=kappa; the stated kappa<=1 also ensures the inherited epsilon383<=1 condition. No new X coefficient, target capacity, t, h or template is introduced by this lift. Other historical/soft/extreme-scale/threshold/aggregation/limit obligations remain explicit.

The main correctly forbids transferring old weak-row eligibility to a changed plan and does not invoke an unconditional R378 residual reconstruction for the nonlinear trigger. Source-only windows are fixed simultaneously, and the old independent-y traffic-score optimization is not called a global optimizer of this nonlinear row objective. The new exact paid union contains the OLD large-u source-window piece of the SAME core; it does not automatically contain an independently paid small-v window branch or the complete old two-endpoint F2 family. The current main does not make that broader comparison. The final author proof, finite-cube evidence and byte bindings follow.

## 7. Final author geometry proof and complete script: PASS

Read r384_geometry.md and the complete geometry_check.py after the independent screen. The input core's actual (u,y) marginal is the R383 q_u du*pi_u(dy)*alpha_u(y)1_Y, not an independent resampling model or a recomputed source. The author defines F using full pi_u, distinguishes it from actual traffic inside the window, and pays exactly two disjoint cost restrictions. Their per-row bound by Cq_uF_u is correct for C>=1, including weak threshold equality, F=0 and all zero rows. The source integral uses q_u/m_u=R_u^-n and the actual-center closed-window envelope, so price is exactly C lambda/q_- integral f[1+log(U/L)], with no B_star or delta inverse. C2 and width sqrt(n) have the stated root source price. No hidden target-capacity or independence assertion is used.

For the main union's strong rows, a-b>=a-F>(1-1/C)a and a>delta correctly imply both the residual row-density lower bound and captured full-f Y/window-complement mass bound. C1 only supplies a positive/nonnegative version, not a uniform positive delta fraction. The static full-F threshold corollary has its usual probability range0<kappa<=1; no negative or zero inverse is needed in the actual C2 construction. The author correctly distinguishes the full witness from the initially narrower Y-only witness and permits a positive witness with zero actual window traffic. New sampling there is only an accounting representation, not a change to the original plan or its source/target dependence.

The author makes the required plan-dependence and nonlinear-selection restrictions explicit. Its trigger is computed from this SAME frozen actual core. It cannot survive an arbitrary new plan merely because source exactness is retained. No unconditional old R378 residual reconstruction is asserted for the lifted trigger. Finite entire window-map candidates can be compared as whole complete bounds; the old sourcewise independent coverage optimizer is not called optimal for this coupled whole-row payoff. The exact unpaid actual traffic is retained with its original marks.

## 8. Exact finite-cube witness and numerical limits: PASS

Independently checked the explicit example's geometry and rational constants, and read all243 varying cube/source/weight cases in the code. Q_v has volume1/16. The actual intersection has volume3/320 and target geometric fraction3/20. The two disjoint D boxes each have volume1/800 and lie inside that intersection. Peak density5 and residual density35/48 give m_v=9/160; the actual outside density14323/15216 gives m_u=19/20. These are masses from ONE full positive integrable source, not independently assigned matches. The code varies peak/qu and recomputes the two low densities with the same mass equalities, so no mismatched source is hidden in the pressure cases.

For the displayed example, center separation27/40 gives2dist=27/20>3^(1/4), exactly the outside gate. There is one protruding coordinate with normalized truncation17/20, exceeding n/8 and n/20 respectively in the stated count/sum tests. The R369 Bplus allowance is1/40 versus actual excess17/20. The exact mass ratio152/9>8>e^2 proves strict original exponential far order using a certified rational Taylor upper bound. Literal quadrature past is16000/9 and J=304180/171, both above400. Large R=b=1 has its full normalized physical clock at the real terminal atom, not an invented initial-scale atom.

The true marked posterior density is alpha=99671/152090 and the total core row a=99671/11558840. With delta=.001 its only positive alpha source set is D1 union D2 and it satisfies the R383 screening thresholds. The source-window witness on D1 is F=1/152, so a=2alpha F<2F and the whole-row rule pays all of it. The old large-u current-source window pays only D1; the positive new D2 traffic is exactly99671/24334400. This proves strict coverage difference for that SAME finite marked core and window. It does not compare against every older budget option, imply a fixed positive covered share, or show that the full complete upper bound is always improved. It especially does not establish inclusion of an independently paid small-v or whole two-end F2 family.

Receiver weights100 and1 are finite positive quadrature, not Lebesgue center volume. Consequently its enormous J and literal h=H=400 do not certify the synchronized R379 field, history/selector eligibility, or a native continuous high-past model. The continuous center payment theorem is proved analytically; these weights are not inserted into that center envelope. The example is not a difficult epsilon-X/root-W lower test, and no such claim is made. The author/main explicitly retain this scope.

Parent confirms an actual fresh25107 grouped Fraction run:24608 posterior/union cases,243 finite-cube witnesses and256 center pointwise envelope tests. The243 cases all have strictly positive newly paid old-window-complement traffic. These do not replace the analytic continuum proof or certify a general source/window construction. This reviewer also actually ran5 separate rational checks of the displayed background density, Z/J, alpha, core row and D2 cost; those are separate reviewer evidence and not added to the parent count.

## 9. Optional fractional strengthening and revised parent script: PASS

Independently screened the statement, then read final r384_fractional.md and the COMPLETE revised r384_lift_check.py. Write a for actual core row density, b for actual in-window cost and F for the full witness. Because b<=min(a,F) and C>=1, P=min(a,CF) lies in[b,a]. If a>b the stated t=(P-b)/(a-b) is measurable and in[0,1]. If a=b, a<=F<=CF and P=a, so all cost is already paid; no0/0 occurs, including a=b=0. The exact positive remainder is the factor1-t on original window-complement traffic and has row density(a-CF)_+. It retains the entire original source/receiver/clock/target/history labels.

Its paid density is still <=CF, so the whole source price is unchanged. It is at least the whole-row union payment for each row on the SAME plan/window/C and therefore its exact residual is no larger. It does not retain the union's uniform delta/2 residual-density guarantee; the final appendix and ledger explicitly decline that inference. If a further optional low-residual row deletion at threshold zeta is performed, its actual cost is<=zeta X_q and the complete entrance needs2Lambda zeta X_q. The main ledger does NOT perform that optional deletion, so its earlier kappa allocation remains unchanged. The two positive decompositions are alternative complete bounds, not additional credits charged together.

The revised3600-case parent script uses the same432/1008/2160 parameter groups and now checks fractional mark feasibility, zero denominators, positive-part equality and comparison to union in each existing group. Parent confirms a fresh successful rerun. These are additional assertions on the SAME groups, not another independent3600 configurations to add to the round total. The abstract zero-window-traffic example is valid finite probability algebra and is not presented as a native cube realization. No solver/argmax/strong-duality claim is introduced by this appendix.

## 10. Final main/complete ledger/readme: PASS

Read the final texts after the comparison-scope and fractional appendices. The new preferred bound starts from the fixed same-plan original G BEFORE deleting this window, then applies the R383 low-flow payment and the new lift. F_lift=C lambda(1+D)/q_- replaces the optional old F2 tariff instead of adding or recycling that old credit. The core remainder is actual R_lift or, as a complete same-price alternative, actual R_frac=integral q(a-CF)_+. No old Hall upper bill is reduced by subtracting a positive payment, no old square is spent again, and no old weak-row eligibility is transferred to a changed plan. The fixed plan/target cap, h,t and template are unchanged.

The hard bound has receiver coefficient eta+sigma_n+epsilon383 and source price C338+F_lift. The complete entrance preserves8lambda H W,2d_eff A_n W_nu/H, twice the exact residual/receiver/source fees, then Lambda. With sigma<=eta/2, eta=kappa/(6Lambda) and epsilon383=kappa/(4Lambda), this slot's total receiver coefficient is<=kappa for the stated0<kappa<=1. There is no new receiver coefficient in the lift/fractional payment itself. Optional zeta deletion would require another allocation, which is stated and not silently used.

Only the old large-u source-window part of the SAME core is automatically included in the enlarged paid union. The main expressly excludes a broader claim about all small-v/two-end or historical paid families. Actual source witness sets are not disjoint across receivers and no source-mass lower bound is summed for free. Source-only window existence/coverage and the original high-cost/source-outside residual budget remain unproved. The source/target-history, H-selection, soft/crossing/entry, tail/wide-distance/low-pe/extreme-scale/threshold complements, all-scale/source aggregation, truncation and limit-exchange obligations all remain explicit.

Parent round total is28707 grouped exact Fraction cases=25107+3600, with revised assertions in the same3600 groups counted only once. No new MATLAB/optimizer, ordinary floating fit or PDF compile is claimed. This reviewer read every proof/code and used only the separate5 rational constant checks rather than repeat either parent pipeline. Archive extraction/re-execution, LaTeX typesetting and repository operations are outside this audit.

Final decision: FINAL PASS for the precise new whole-row and fractional receipts and their complete alternative ledgers. General n^(1/2+o(1)) closure, window construction and the actual complementary budgets remain unresolved.

## 11. Final SHA256 bindings

Exact reviewed current files follow; the audit hash is reported separately after saving.

- `/tmp/r384_main.md` — `5065c1e6b6f636def7d4900e01da0665d5a07903011d4b5717a2ac478aa308a1`
- `/tmp/r384_ledger.md` — `a03ecc61e1f1e5a49998bee22587fca9efe4a42ba5e4b04fe313a72610a798f0`
- `/tmp/r384_readme.md` — `b7ebd0c34b65dce90000a91c95b67d7430137a5f6efefd6f0fc185ad97f8da46`
- `/tmp/r384_geometry.md` — `34a95c9a1059d6f9c181f8d610fed3931c2af4953b39bfa0a1d4dc783402732a`
- `/tmp/r384_geometry_check.py` — `c8d7c8303dc67460a7c2ecbd7f9eedb58a8e8b0c7a6e5c79d9da05f7f58c2f04`
- `/tmp/r384_fractional.md` — `efb108db097035acf964613d14d2f4df69e10a3946c7d02892b4bf29df42eb6b`
- `/tmp/r384_lift_check.py` — `4750b3f72737bc5fddd40e2042db2c1f0cfc28f3605a357c98df38424970d4d1`

Necessary inherited interfaces, used at their stated boundaries rather than comprehensively re-audited:

- `/tmp/r383_flow.md` — `3870009b3c82a3a051e379ea6636940ff583ca945f645d371d0a813e9880c4cd`
- `/tmp/r383_geometry.md` — `d517afb88200f231b3ff30ce9424522e51df9be4a18a9dad6c072d1426f478ae`
- `/tmp/r383_ledger.md` — `445da37e4f5e826f3b3e5829a170cdf72509d38d7bd7ee937aaf2b5071ec1b80`
- `/tmp/r383_audit.md` — `94151daa6423c20f5f972e318a67005d9ca5145728e01b4762268a6121befe20`
- `/tmp/r382_geometry.md` — `e596a311e4eca9be309c10aafe75db0e1938aa815dd258538461bdf0d47f2944`
- `/tmp/r382_selection.md` — `d0bd157001bcec7a3836a3bf757d3a7cf8f902eb9496dc1b40e9ada9fc301f79`
- `/tmp/r379_ledger.md` — `5f577d1d01cfe9ac3d992853c9e92cbe85e1fe5fc4e6758591b1858a8dcdc063`
- `/tmp/r378_layered.md` — `8d7f0361b15108b014b9fb7ddc8c124e17f268a2ba98ff7bb8ab2489b188e24d`

FINAL PASS. Review stopped; no author/repository edits and no general-closure claim.
