from fractions import Fraction as F
from itertools import product
counts={'initial':0,'boundary':0,'expanded':0}
for stage,den in [('initial',4),('boundary',8),('expanded',16)]:
 for pnum in range(1,den):
  p=F(pnum,den)
  for a,b in product([F(0),F(1,8),F(1,3),F(1,2),F(2,3),F(1)],repeat=2):
   for C in [F(1),F(3,2),F(2),F(4)]:
    A=p*a+(1-p)*b; witness=p; windowcost=p*a
    whole=A<=C*witness
    paid=A if whole else windowcost
    residual=A-paid
    assert paid<=C*witness
    assert paid+residual==A
    if not whole:
     assert residual>=A-witness
     if C>1:assert residual>(1-1/C)*A
    paid_fractional=min(A,C*witness)
    assert windowcost<=paid_fractional<=A
    if A==windowcost:
     assert paid_fractional==A
     residue_fractional=F(0)
    else:
     t=(paid_fractional-windowcost)/(A-windowcost)
     assert 0<=t<=1
     residue_fractional=(1-t)*(A-windowcost)
    assert residue_fractional==max(F(0),A-C*witness)
    assert residue_fractional<=residual
    counts[stage]+=1
# A witness source with zero original traffic can pay a wholly different source.
p=F(1,4);A=F(3,4)*F(2,3);C=F(2)
assert A==C*p and p*0==0 and A>0
print('PASS',counts,'total',sum(counts.values()),'strict expanded-source example',A)
