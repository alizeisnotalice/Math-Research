# R321 — an actual high-softness middle-capture branch has a root source receipt

## Result and scope

Keep the original U,J,A,beta,nu,ell_n,FIRST and selected-radius cap from `/tmp/r320_pair_geometry.md`. Write

    delta_n=1/(2 sqrt(n)), s_*=1-delta_n,
    E_+={x in E:s(x)>=s_*}, E_-={x in E:s(x)<s_*}.

These are restrictions of the actual receiver data, not selectors of a replacement field. For every endpoint-independent original weight 0<=v(y,z,r)<=1, and every measurable pair restriction D (symmetry is unnecessary here), define N_(D,+)^v by inserting 1_(E_+)(u) into the ORIGINAL capturing-u baseline N_D^v. Then

    N_(D,+)^v <= (4lambda/q_-) Z_n(b/a) W_beta,
    Z_n(b/a)=1+B/2+sqrt(n)log(b/a)(D_0+1+M/2),             (1)

where the absolute constants below are analytic upper bounds. In particular b/a<=2 gives the analytically certified Z_n<13 sqrt(n), and 4lambda/q_-=16/3.

This pays the actual high-softness capturing-endpoint part of the middle annulus h<||u-w||_infinity<=2t. It also pays its actual oriented positive loss, since that loss is bounded by its baseline. No statement identifies this oriented loss with a symmetric-pair difference formula. The complementary low-softness capturing-endpoint part remains unpaid.

For the original tent, put

    A_+(y,z,r)=integral_(R(u)<=r) U_y(u)c_u(z)1_(E_+)(u)du,
    C_(long,+)=integral_LOW beta nu ell_n v A_+ 1_(J>=2H).

Then C_(long,+) satisfies (1), with the original v, full A,J and threshold unchanged. This is a strict root payment of a physical part of C_long, not a new projection or a conditional assertion about a replacement source. The identity C_long=C_(long,+)+C_(long,-) is a positive actual allocation.

No source density bound, source product, virtual receiver cap, component FIRST, free translation of E/alpha/R, or beta-nu comparison is used. Indeed this branch only uses alpha<=1 and the same-actual-R cap. Every original entry coefficient, aspect/history qualification, lambda d factor and positive outer integral is retained and multiplies its entire receipt. The proof does not provide a bound for all of B_H or C_long and does not claim the requested general epsilon X estimate.

## 1. One-dimensional analytic constants

Let h=1_[-1/2,1/2], w(t)=integral_0^1 exp(-|t|/u)du, phi=h*w and f_s=(1-s)h+s phi. Both h and phi have integral one. Set

    c=(1-exp(-1))/2,
    K=17/6+1/(12c),
    B=sqrt(2/c), D_0=sqrt(2+2K), Q=2+sqrt(K),
    M=Q+2D_0 B+1+B.                                      (2)

A rational certificate for the stated constant 13 is as follows. The positive
Taylor series for exp(1) gives e>8/3, so

    c>5/16, K<31/10, B<51/20, D_0<29/10,
    Q<19/5, M<1107/50.

Each square-root comparison follows by squaring positive rationals. The fourth-
order positive Taylor polynomial for exp(7/10) is greater than 2, hence
log(2)<7/10. Since n>=1 and b/a<=2, the exact formula (1) therefore gives

    Z_n/sqrt(n)
      <=1+B/2+log(2)(D_0+1+M/2)
      <91/40+(7/10)(1497/100)=6377/500=12.754<13.

This rational argument certifies the advertised bound; the floating-point
values in Section 5 remain diagnostics only.

On |x|<=1/2,

    phi(x)>=phi(1/2)=integral_0^1 u(1-exp(-1/u))du>=c,
    |phi'(x)|<=1.

The first inequality follows because phi is even and nonincreasing in |x|; w is even and decreasing. For x=1/2+t>=1/2,

    phi(x)=integral_0^1 u(1-exp(-1/u))exp(-t/u)du,
    -phi'(x)=integral_0^1 (1-exp(-1/u))exp(-t/u)du.

Cauchy-Schwarz in u gives

    phi'(x)^2/phi(x)
       <=integral_0^1 u^(-1)(1-exp(-1/u))exp(-t/u)du.

Consequently

    integral_R x^2 phi'(x)^2/phi(x) dx
    <=1/(12c)+2 integral_0^1 (1/4+u+2u^2)du=K.             (3)

All following s satisfy s>=1/2. On the full real line let

    b_s=(phi-h)/f_s,
    a_s=-f_s-s x phi'(x), aScore_s=a_s/f_s.

Expectation below is against f_s(x)dx. Then

    E b_s=0, E b_s^2<=B^2,
    E aScore_s=-(1-s), E aScore_s^2<=D_0^2,
    integral |partial_s a_s| dx<=Q.                       (4)

For b_s, use f_s>=s phi and

    integral (phi-h)^2/phi = integral h/phi -1<=1/c-1.

For aScore_s, use (p+q)^2<=2p^2+2q^2 and s^2/f_s<=s/phi, followed by (3). The mean follows from integral x phi'=-1. Finally partial_s a_s=-(phi-h)-x phi', whose L1 norm is <=2+sqrt(K). These estimates include the tails and require no numerical constants to be trusted.

## 2. Distributional scale derivative and every mixed term

Write F_s(x)=product_(i=1)^n f_s(x_i). Differentiating the dilated density L^(-n)F_s(x/L) with respect to log L gives, after dilation back to L=1, the signed measure

    T_s = [sum_i a_s(x_i) product_(j!=i) f_s(x_j)] dx
          +(1-s)/2 sum_i sum_(e=+-1)
              delta_(x_i=e/2) product_(j!=i) f_s(x_j) dx_(-i).
                                                                    (5)

In particular the hard-face measures are POSITIVE in this scale derivative. They are not dropped. Their total mass is n(1-s). The absolutely continuous part has L1 norm bounded by sqrt(n)D_0+n(1-s), using (4) and independence under F_s. Thus

    ||T_s||_TV <= sqrt(n)D_0+2n(1-s).                    (6)

Also ||partial_s F_s||_1<=sqrt(n)B.

The s derivative of the absolutely continuous part of (5) contains exactly

    sum_i (partial_s a_s)(x_i) product_(j!=i)f_s(x_j)
    +sum_(i!=j) a_s(x_i)(phi-h)(x_j)
                                      product_(k!=i,j)f_s(x_k).     (7)

The first sum costs at most nQ. For the second sum, take independent X_i~f_s and write A_i=aScore_s(X_i), B_i=b_s(X_i). The cross sum is (sum A_i)(sum B_i)-sum A_i B_i. Hence its expected absolute value is at most

    sqrt(n D_0^2+n^2(1-s)^2) sqrt(n B^2)+n D_0 B
    <=2nD_0B+n^(3/2)(1-s)B.                              (8)

Here E(sum B_i)^2<=nB^2 and E(sum A_i)^2<=nD_0^2+n^2(1-s)^2; no cancellation is presumed inside an absolute value.

The s derivative of the face part has two terms: differentiating (1-s), costing n, and differentiating the other n-1 factors, costing at most n(1-s)sqrt(n-1)B. Therefore for 1-s<=delta_n,

    ||partial_s T_s||_TV
    <=n[Q+2D_0B+1+2sqrt(n)(1-s)B]<=nM.                  (9)

Equations (7)-(9) explicitly retain all cross terms and all hard-face terms. Scaling is an L1/total-variation isometry, so these bounds hold at every L with the measure dL/L.

## 3. Positive envelope with simultaneous common s and selected L

There is a measurable pointwise majorant G(x) for

    sup_(s_*<=s<=1, a<=L<=b) L^(-n)F_s(x/L)

whose integral is bounded by Z_n(b/a) from (1). Here is a positive-measure construction, which also handles the moving jumps of h.

Start with the positive density P_(s_*,a), add the measure integral_(s_*)^1 |partial_s P_(s,a)|ds, add the scale-path total variation integral_a^b |T_(s_*,L)|dL/L, and add the mixed total variation integral_(s_*)^1 integral_a^b |partial_s T_(s,L)|dL/L ds. Call their sum G(x)dx. The scale-integrated face terms are absolutely continuous: for each face x_i=+-L/2, integrating dL/L sweeps ordinary Lebesgue measure in coordinate x_i; products in the remaining coordinates are densities. Thus this positive majorant really is a density, not a singular measure that could be evaluated freely at receivers.

The two-parameter fundamental theorem of calculus, in BV form for L and the ordinary absolutely continuous form for s, proves the majorization. Equivalently, first bound the variation in s at L=a, then the variation in L at s=s_*, and bound the change of the scale derivative from s_* to s by the mixed variation. For fixed x, moving hard boundaries have one-sided traces; the envelope includes the larger trace. Values at simultaneous multiple faces occur on a Lebesgue-null set (ties |x_i|=|x_j|). On a single face the larger trace dominates either convention for h. Thus the bound applies almost everywhere simultaneously to all s,L, including measurable selected s(x),L(x).

Using (6), (9) and delta_n=1/(2sqrt(n)),

    integral G
      <=1+delta_n sqrt(n)B
         +log(b/a)[sqrt(n)D_0+2n delta_n+delta_n nM]
      =1+B/2+sqrt(n)log(b/a)(D_0+1+M/2).                 (10)

This is a common-s product estimate throughout. There is no coordinatewise soft-parameter maximization, no degree expansion giving hypothetical component FIRST, and no omission of scale ratios in [a,b].

## 4. Actual receipt and the remaining middle core

For every source y, the original field satisfies

    integral_(E_+) U_y(u)du <= q_-^(-1) integral G(u-y)du
                            <= Z_n/q_-.                 (11)

This is a kernel envelope upper bound, and does NOT translate the actual E, alpha, R or its hard cap. To pay N_(D,+)^v, drop D and v positively and integrate its w endpoint to the SAME full J_y(r). Then

    N_(D,+)^v
      <= integral beta(dy) integral_(E_+) U_y(u)
                         nu(Q_(R(u))(u)) ell_n([R(u),b])du
      <=4lambda integral beta(dy) integral_(E_+) U_y(u)du
      <=(4lambda/q_-)Z_n W_beta.                         (12)

The first inequality also drops J>=H positively. The inclusive identity ell_n([R,b])=R^(-n) is exact including the top radius atom, and the cap is applied ONLY at the actual receiver u and its actual R(u). Radius/history atoms and aspect factors are not averaged away. Equation (12) also proves the tent C_(long,+) receipt by positive domination.

For the original physical middle loss, retain the original oriented form

    L_mid=integral beta nu ell_n 1_(J>=H)/J
             integral U_y(u)U_y(w)c_u(z)(1-c_w(z))1_mid du dw.

Insert 1_(E_+)(u)+1_(E_-)(u)=1. Its plus part is bounded by (12); the minus part is exactly the remaining original positive kernel. Symmetry of the uncut full expression is compatible with this allocation, but the individual oriented summands are not asserted symmetric.

Combining with the already paid original near/far receipts gives, for their original h,t,

    B_H^v <= epsilon_beta W_beta+epsilon_nu W_nu
             +(4lambda/q_-)Z_n W_beta+L_(mid,-)^v.        (13)

For C_long one analogously has C_long<= (4lambda/q_-)Z_n W_beta+C_(long,-). This is the concrete improvement: the high-softness part of the previously unpaid middle capture is now removed at root cost. The residual problem is the actual capturing receivers with s<1-1/(2sqrt(n)); neither a small epsilon X coefficient nor a general root payment for that residual has been obtained. Applying (6) over a fixed positive length of s exposes the n(1-s) hard-face term; applying (9) over that length likewise costs order n. This identifies where the present argument stops, rather than treating a finer projection as payment.

## 5. Executed local check

The local Python standard library evaluated the explicit analytic constants (2):

    c=0.31606027941427883, K=3.0969961178115546,
    B=2.5155331099942426, D_0=2.8625150192834115,
    Q=3.7598284341979347, M=21.676864161918637,
    1+B/2=2.2577665549971213,
    D_0+1+M/2=14.700947100242729,
    1+B/2+log(2)(D_0+1+M/2)=12.447686589091273.

These floating-point outputs are numerical diagnostics only; the inequalities and dimension-free constants are proved analytically above. Neither the default nor bundled Python has SciPy installed. No source realization or claimed full-bound numerical test was made.

Only `/tmp/r321_middle_core.md` and optional same-prefix calculation files are authored by this task. Other agents' files and Git are unchanged.
