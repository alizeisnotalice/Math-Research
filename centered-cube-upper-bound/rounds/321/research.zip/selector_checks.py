from fractions import Fraction as F
from math import comb
from decimal import Decimal,localcontext
ct={'scale_cancellation':0,'contraction_coefficient':0,'radial_selector':0,'refinement':0}
with localcontext() as ctx:
 ctx.prec=65
 def dec(x):return Decimal(x.numerator)/Decimal(x.denominator)
 for n in (1,2,8,32,128):
  cs=[F(comb(n,k)*k**k*(n-k)**(n-k),n**n) for k in range(n+1)]
  C=sum(cs);Cr=sum(c*F(19,20)**k for k,c in enumerate(cs))
  assert 1<=Cr<C and Cr<=20;ct['contraction_coefficient']+=1
  for r in (F(1),F(5,4),F(3,2),F(2)):
   b=F(2)
   assert r**n*(b**(-n)+(r**(-n)-b**(-n)))==1;ct['scale_cancellation']+=1
   target=1+n*dec(r).ln();old=F(0)
   for steps in (16,64,256):
    ls=[1+(r-1)*F(j,steps) for j in range(steps+1)]
    val=1+sum((ls[j]**n-ls[j-1]**n)/ls[j]**n for j in range(1,len(ls)))
    assert dec(val)<=target+Decimal('1e-55');ct['radial_selector']+=1
    assert val>=old;ct['refinement']+=1
    old=val
print('PASS',ct)
