from fractions import Fraction as F
from math import factorial
from pathlib import Path
import sys,json
try:
 import mpmath as mp
except ImportError:
 sys.path.insert(0,"/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor")
 import mpmath as mp
counts={"rational_constant":0,"dimension_budget":0,"fisher_integral":0}
def ck(v,k):
 assert v,k
 counts[k]+=1
ck(sum(F(1,factorial(j)) for j in range(5))>F(8,3),"rational_constant")
ck(sum(F(7,10)**j/factorial(j) for j in range(5))>2,"rational_constant")
c=F(5,16);K=F(17,6)+1/(12*c);B=F(51,20);D=F(29,10);Q=F(19,5)
ck(K==F(31,10),"rational_constant")
ck(B*B>2/c,"rational_constant")
ck(D*D>2+2*K,"rational_constant")
ck((Q-2)**2>K,"rational_constant")
M=Q+2*D*B+1+B
ck(M==F(1107,50),"rational_constant")
ck(1+B/2+F(7,10)*(D+1+M/2)==F(6377,500)<13,"rational_constant")
# Exact high-soft window scaling in square dimensions, including n=1.
for k in (1,2,4,8,16,64,256):
 n=k*k;delta=F(1,2*k)
 for ratioLogBound in (F(0),F(1,10),F(7,10)):
  bound=1+delta*k*B+ratioLogBound*(k*D+2*n*delta+delta*n*M)
  ck(bound<=13*k,"dimension_budget")
  ck(n*delta==F(k,2),"dimension_budget")
  ck(2*k*delta==1,"dimension_budget")
# Independent actual phi Fisher integral. Truncated integral only, ordinary
# high-precision quadrature, NOT an interval certificate of the full integral.
results=[]
for prec,endpoint in ((20,8),(30,16),(40,32)):
 mp.mp.dps=prec
 def phi(x):
  if x<=mp.mpf('.5'):return 1-mp.expint(3,mp.mpf('.5')-x)-mp.expint(3,mp.mpf('.5')+x)
  return mp.expint(3,x-mp.mpf('.5'))-mp.expint(3,x+mp.mpf('.5'))
 def derivative(x):return mp.expint(2,x+mp.mpf('.5'))-mp.expint(2,abs(x-mp.mpf('.5')))
 actual=2*mp.quad(lambda x:x*x*derivative(x)**2/phi(x),[0,mp.mpf('.5'),1,2,4,endpoint])
 bound=mp.mpf(17)/6+1/(12*((1-mp.exp(-1))/2))
 ck(0<actual<bound,"fisher_integral")
 results.append({"precision":prec,"endpoint":endpoint,"partial_fisher":str(actual),"analytic_full_upper":str(bound)})
 print("FISHER",results[-1],flush=True)
print(json.dumps({"status":"PASS","counts":counts,"total":sum(counts.values()),"fisher":results,"scope":"Exact rational constants and scalar dimension budgets; actual phi quadrature is truncated non-certified evidence. Full Fisher bound and all-input receipt are analytic proofs."},sort_keys=True))
