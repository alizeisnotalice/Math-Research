#!/usr/bin/env python3
"""R321 exact nested-grid actual-source certificate; standard library only."""
from fractions import Fraction as F
from math import isqrt
from collections import Counter
from pathlib import Path
import json
counts=Counter()
def ck(key,b):
 counts[key]+=1
 assert b,key

def contains(I,J):return I[0]<=J[0] and J[1]<=I[1]
def source_mass_in_box(B,n,s):
 def fraction(center,side):
  v=F(1)
  for (lo,hi),c in zip(B,center):v*=max(F(0),min(hi,c+side/2)-max(lo,c-side/2))/side
  return v
 return 3*fraction([F(0)]*n,s)+8100*fraction([F(2)]+[F(0)]*(n-1),F(1,2))
def native(n):
 k=isqrt(n);s=F(2,n*n);d0=F(1,n*n);d1=F(1,n);m=F(3,2**n)
 local=3-k*s**n;remote=8100-F(k,2**n);eta=local/3;HV=eta*(1-s)**n
 ck('positive_residual',0<local<3 and remote>0)
 ck('continuous_local_capture',(1-s)/2+s/2==F(1,2))
 ck('continuous_remote_exclusion',F(7,4)-(1-s)/2>1)
 ck('native_hardband',2<3<=4)
 ck('native_row_cap',local/3<=1)
 ck('ownership_macro_containment',s/2<=F(1,2) and F(9,4)<=F(5,2))
 ck('ownership_capture_failure',local/(local+remote)<F(1,2*k))
 ck('harmonic_failure',local/(local+remote)<F(1,k))
 ck('component_connected_heavy',2<=3 and local+remote>3**k)
 ck('native_contribution',local>=F(1,6144))
 ck('old_deep_integer',3*k*3**k<2**n)
 ck('old_high_average',m*k**n>k)
 paths=[]
 for sign in [-1,1]:
  units=k;path=[];orthant=(-s/2,F(0)) if sign<0 else (F(0),s/2)
  while True:
   width=F(units,n);I=(-width,F(0)) if sign<0 else (F(0),width)
   ck('old_path_contains_orthant',contains(I,orthant))
   ck('old_path_mass_unchanged',3*(s/2)**n/s**n==m)
   path.append(units)
   if units==1:break
   child=(units+1)//2 if sign<0 else units//2
   near=(-F(child,n),F(0)) if sign<0 else (F(0),F(child,n))
   ck('floorceil_near_child_contains',contains(near,orthant))
   far=(-width,-F(child,n)) if sign<0 else (F(child,n),width)
   ck('floorceil_other_child_empty',far[1]<=orthant[0] or orthant[1]<=far[0])
   ck('pruning_balance_failure',m>m/2)
   units=child
  paths.append(dict(sign=sign,integer_fine_widths=path,terminal_mass=m))
 ck('old_root_mass_once',2**n*m==3)
 ck('old_fine_width_legal',s/2<F(1,n))
 tinymax=3*(d0/s)**n
 ck('allseed_tiny_local_inactive',tinymax<F(1,k))
 ck('allseed_tiny_remote_inactive',8100*2**n*d0**n<F(1,k))
 ck('tiny_cannot_meet_both',d0<F(7,4)-s/2)
 ck('root_remote_inactive',8100*2**n*d1**n<F(1,k))
 ck('root_cannot_meet_both',d1<F(7,4)-s/2)
 ck('root_contains_cluster_possible',s<d1)
 probability=(1-s/d1)**n
 ck('root_positive_fraction',probability>F(1,16))
 ck('root_mass_gate',3>F(1,k))
 ck('positive_increment',probability*HV>0)
 B=(1+d1)**n
 ck('root_factor_bound',B<3)
 ck('unchanged_absorption',1/(1-F(1,768)-F(1,128))==F(768,761))
 return dict(n=n,k=k,s=s,delta0=d0,delta1=d1,old_paths=paths,old_packet_mass=m,local_residual=local,remote_residual=remote,native_traffic=HV,tiny_local_cell_mass_upper=tinymax,old_tiny_paid=F(0),root_containment_probability=probability,new_increment_lower=probability*HV,root_inflation=B,root_source_once_cost_upper=3*k*B)
def nested(n):
 k=isqrt(n);d0=F(1,n*n);d1=F(1,n);s=2*d0
 # The exact root-phase intervals [j*d0,(j+1)*d0) partition[0,d1).
 intervals=[(j*d0,(j+1)*d0) for j in range(n)]
 ck('joint_phase_partition',intervals[0][0]==0 and intervals[-1][1]==d1 and all(intervals[j][1]==intervals[j+1][0] for j in range(n-1)))
 ck('joint_phase_uniform_density',F(1,n)/d0==1/d1)
 samples=0;active_roots=0;strict_increment=0
 for phase in [F(0),d0/4,d0/2]:
  for j in sorted({0,1,n//2,n-1}):
   rootphase=phase+j*d0
   for z in [-s/2,-s/4,F(0),s/4,s/2,F(7,4),F(2),F(9,4)]:
    fineindex=(z-phase)//d0;rootindex=(z-rootphase)//d1
    C=(phase+fineindex*d0,phase+(fineindex+1)*d0)
    D=(rootphase+rootindex*d1,rootphase+(rootindex+1)*d1)
    ck('actual_nested_interval',contains(D,C))
    ck('root_boundary_on_tiny_grid',(D[0]-phase)/d0==int((D[0]-phase)/d0))
    # Remaining axes use the ORIGINAL source location0 with identical seeds.
    C0index=(F(0)-phase)//d0;D0index=(F(0)-rootphase)//d1
    C0=(phase+C0index*d0,phase+(C0index+1)*d0);D0=(rootphase+D0index*d1,rootphase+(D0index+1)*d1)
    CB=[C]+[C0]*(n-1);DB=[D]+[D0]*(n-1)
    mc=source_mass_in_box(CB,n,s);md=source_mass_in_box(DB,n,s)
    ck('actual_fullsource_mass_monotone',0<=mc<=md)
    ck('actual_tiny_inactive',mc<F(1,k))
    for tau in sorted({F(1,k)}|({mc} if mc else set())|({md} if md else set())):
     old=mc>=tau;increment=mc<tau<=md;root=md>=tau;left=md<tau
     ck('union_equals_root',int(old)+int(increment)==int(root))
     ck('oldleft_increment_rootleft',int(mc<tau)==int(increment)+int(left))
     ck('rootfailure_inside_oldfailure',not left or mc<tau)
    active_roots+=md>=F(1,k);strict_increment+=mc<F(1,k)<=md;samples+=1
 # On the containment phase d1/2 in every coordinate there is one local root.
 root=(-d1/2,d1/2);mass=source_mass_in_box([root]*n,n,s)
 ck('contained_actual_root_mass',mass==3)
 ck('root_volume_R_one',(1+d1)**n<=k*mass*(1+d1)**n)
 return dict(n=n,seed_source_cases=samples,actual_R1_root_success=active_roots,actual_R1_strict_increment=strict_increment,phase_uniform_density=1/d1,root_children_per_axis=n,root_children_count=n**n)
def serial(x):
 if isinstance(x,F):return str(x)
 if isinstance(x,dict):return {k:serial(v) for k,v in x.items()}
 if isinstance(x,(list,tuple)):return [serial(v) for v in x]
 return x

def main():
 models=[];nestedmodels=[];stages=[]
 before=sum(counts.values());models.append(native(16));stages.append(dict(stage='initial_native',checks=sum(counts.values())-before,n=[16]))
 before=sum(counts.values());nestedmodels=[nested(n) for n in [16,36,64]];stages.append(dict(stage='nested_seed_boundary',checks=sum(counts.values())-before,n=[16,36,64]))
 before=sum(counts.values());models.extend(native(n) for n in [36,64]);stages.append(dict(stage='expanded_native',checks=sum(counts.values())-before,n=[36,64]))
 result=dict(status='PASS',arithmetic='Fraction/integer',total_checks=sum(counts.values()),check_counts=dict(counts),stages=stages,models=models,nested_seed_diagnostics=nestedmodels,scope='Actual positive-L1 source and native positive-volume subset, exact finite algebra plus analytical coordinate/tensor arguments. Not full-band enumeration, complete history reconstruction or root-budget closure for remaining traffic.',source='Local uniform Q_(2/n²)(0) fullmass3; remote uniform Q_(1/2)(2e1) fullmass8100; original residual(f-sqrt(n))_+.',settlement='Old tiny-paid plus increment is the same root-paid union on the canonical joint seed lift; one root price replaces G320, never adds G320 and G_root.',analytic_bridges=['Uniform sigma0 and independent uniform integerJ yield rootphaseuniform because n adjacent intervals tile[0,delta1), with equal density1/delta1.','Tiny-grid boundary alignment proves every root is a disjoint union ofn^n tinycells for each seed; no product enumeration is needed.','All phases tiny-cell local mass <=3(delta0/s)^n and remote mass <=8100*2^n delta0^n, each <1/k; no cell meets both components.','The root good-phase interval has lengthdelta1-s; independent phases give exact probability(1-2/n)^n.','Each seed active root source mass<=3 since remote roots are subthreshold; the general row-volume theorem supplies k(1+1/n)^n times that mass.'])
 Path(__file__).with_suffix('.json').write_text(json.dumps(serial(result),sort_keys=True,indent=2)+'\n')
 print(json.dumps({k:result[k] for k in ['status','total_checks','check_counts','stages']},sort_keys=True))
if __name__=='__main__':main()
