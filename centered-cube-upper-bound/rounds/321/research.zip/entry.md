# R321 — one nested root capacity budget replaces the tiny-grid bill

**Proved:** couple the existing R320 tiny-grid seed to ONE coarser source-frozen root grid. The old paid traffic plus a genuinely new part of the exact old unpaid traffic equals root-paid traffic pointwise in this joint lift. A single root row-volume receipt pays that union. It REPLACES the old tiny-grid fee; it is not added once per scale. At root width a/n the combined price is at most `e sqrt(n)` times the actual preactive root source mass.

The new part is nonempty on actual native high-average/old-deep traffic where R320 pays ZERO for every tiny-grid phase. A verified compact-source fixture gives a constant positive new fraction. Original deep packets, source, selector, all old high/low/tag classifications and original dx are unchanged. The exact root-failure integral remains unpaid. Only `/tmp/r321_entry.md` was written.

## 1. Exact original measure and the old unpaid lift

Use the fields of `/tmp/r319_entry.md` and the actual R320 construction. Let U be R319's combined positive unpaid measure

`U=T_hi+T_lo,rej`,

`dU=A_U(x,z)h_R(x-z)dx nu(dz)`,

`nu=(f-sqrt(n)lambda)_+dz`, `X=lambda|E|`.

Every original native and R318 aggregate-deep factor remains in A_U. The old source-packet high/low split and any R319 tag-rejection weight are also retained there. The original selector R(x) belongs to[a,b], b<=2a, on the COMPLETE original band E. The actual receiver row satisfies

`integral A_U(x,z)h_R(x-z)nu(dz)<=lambda 1_E(x)`. (1)

This follows from domination by the original normalized complete-source traffic; no average-density assumption is used.

R320 used a frozen phase `sigma_0` uniform in `[0,delta_0)^n`, `delta_0=a/n^2`, for the tiny grid C. Put

`tau(x)=lambda R(x)^n/sqrt(n)`, `m_C=integral_C f`.

The canonical joint lift retains this original probability seed. On that lift R320's exact old allocations are

`dU_oldpaid=1_{m_(C_sigma0(z))>=tau(x)}dU dP(sigma_0)`,

`dU_oldleft=1_{m_(C_sigma0(z))<tau(x)}dU dP(sigma_0)`. (2)

Their projections are precisely the previously defined paid measure and U_left. Retaining the canonical seed is a disintegration of the existing positive allocation, not a redefinition of U_left. The complete source f is used in all cell masses, while the unchanged actual hard source remains nu.

## 2. Source-frozen nested root construction

Fix an INTEGER M>=1. Choose another frozen seed J, uniform in `{0,...,M-1}^n`, independent of sigma_0. Define

`delta_root=M delta_0`, `sigma_root=sigma_0+delta_0 J`. (3)

The marginal root phase is uniform in `[0,delta_root)^n`. Root grid cells D have side delta_root. Their boundary coordinates are also boundary coordinates of the old tiny grid. Therefore every D is the union of exactly M^n old tiny cells, and for every original source z its tiny cell is contained in its root:

`C_sigma0(z) subset D_sigmaroot(z)`,

`m_(C_sigma0(z))<=m_(D_sigmaroot(z))`. (4)

All phases, groupings and root masses are frozen before receivers are selected. No root-scale choice is made after seeing R(x). Neither the old R318 packet P nor its full mass/deep gate is changed. In particular a new root average is NOT substituted for the existing high/low source classification, and no new tag-acceptance assumption is made.

On the joint lift with both seeds define

`dU_increment=1_{m_C<tau<=m_D}dU dP(sigma_0)dP(J)`,

`dU_rootleft=1_{m_D<tau}dU dP(sigma_0)dP(J)`. (5)

The increment is an ACTUAL positive submeasure of the old U_left. Since m_C<=m_D, the indicator identities are pointwise:

`1_{m_C>=tau}+1_{m_C<tau<=m_D}=1_{m_D>=tau}`,

`1_{m_D<tau}<=1_{m_C<tau}`. (6)

Equality cases are paid. Consequently

`U_oldpaid+U_increment=U_rootpaid`,

`U_oldleft=U_increment+U_rootleft`,

`U=U_rootpaid+U_rootleft` (after the appropriate seed projections). (7)

The old-paid projection is unchanged on adding the probability seed J. These identities establish actual coverage; they do not compare two unrelated summary remainders.

## 3. One root source budget for the entire union

For a frozen root D put

`m_D=integral_D f`, `r_D=(m_D sqrt(n)/lambda)^(1/n)`.

The root-paid gate is equivalently R<=r_D. If this branch is active, r_D>=a. Let t_D=min(b,r_D). Its receiver set is contained in `D+Q_(t_D)`. Applying only the TOTAL row bound(1) to EACH root gives

`||U_rootpaid,D||<=lambda(t_D+delta_root)^n`

` <=sqrt(n)m_D(1+delta_root/a)^n`. (8)

Receivers of distinct roots may overlap; source roots partition the original complete f. Only preactive roots with

`m_D>=lambda a^n/sqrt(n)`

can contribute. Define their actual full-source budget

`W_act,root(sigma_root)=sum_{D:m_D>=lambda a^n/sqrt(n)}m_D<=W`.

Sum(8), then average the NORMALIZED joint probability in(3). Its root marginal is uniform, so

`||U_oldpaid||+||U_increment||=||U_rootpaid||<=G_root`,

`G_root=sqrt(n)(1+M/n^2)^n E W_act,root`. (9)

This is the actual source-once price on the root mass field. It does not require a source density cap, a capture-fraction lower bound, an L2 estimate for f, or positive domination by an enlarged hard kernel.

The principal choice is **M=n**, hence

`delta_root=a/n`,

`G_root=sqrt(n)(1+1/n)^n E W_act,root<=e sqrt(n)E W_act,root`. (10)

The exact factor `(1+1/n)^n` and the actual root active mass are retained. This constant geometric inflation is justified here; an a/sqrt(n) isotropic root would have a generally unacceptable exp(sqrt(n)) factor and is not treated as harmless.

The old R320 tiny-grid price G320 is REPLACED by(9)/(10), because the latter prices the actual union in(7). This is not an algebraic subtraction of two upper bounds. One returns to R319's exact U and applies the new joint-union receipt. Earlier P104, R318 and R319 source fees are still added: they can use some of the same original source and are separate actual branches.

## 4. Nested scales are settled once; other roots are not a free supremum

For any frozen hierarchy of integer refinements of this root grid, every finer cell containing z has full f mass at most m_D. The SAME capacity threshold tau(x) is used at every level. Thus every success at ANY finer nested scale is a subset of root success. If the root is included, the union of all nested success events equals root success. The one budget(9) controls that union without a depth or scale-count factor. This includes the original tiny cells (refinement factor n in the principal construction), and any further nested integer subdivisions.

No receiver-dependent 'first successful scale' is declared a frozen new source package. The root grid is already fixed; the pointwise mass monotonicity proves the coverage. Different shifts or nonnested roots cannot be combined by a free supremum. A normalized probability mixture of different root choices would pay its ACTUAL weighted sum of(9), with correspondingly averaged paid fractions. Unnormalized scale copies cost their full sum unless a further source allocation is proved.

A useful parameterized single-root choice keeps integer nesting explicit. For any fixed L>0, choose `M=ceil(n L)`. Then

`delta_root=M a/n^2`, `(1+M/n^2)^n<=exp(M/n)<=exp(L+1/n)`.

In particular if a fixed A>0 is chosen and `L=A loglog(n+2)`, the budget has the honest bound

`G_root<=exp(1/n)sqrt(n)[log(n+2)]^A E W_act,root`. (11)

This is a choice of one root family with its displayed geometric factor, not simultaneous free access to every L. The principal result(10) uses exactly M=n and needs no logarithmic loss.

## 5. Strict newly paid native traffic where R320 pays nothing

Use n=k^2 with even k=4,6,8 (n16,36,64), a=lambda=1, b=2. Fix OLD original fine cells side1/n and OLD R318 coarse roots side1/k, with a vertex at0. These phases subdivide the integer-centered ownership grid. Set

`delta_0=1/n^2`, `delta_root=1/n`, `s=2/n^2`.

Put a uniform local cube Q_s(0) of full source mass3, and an external cube Q_(1/2)(2e_1) of full source mass8100. Their respective densities are `3/s^n` and `8100*2^n`. The two f-positive ownership cells are A0 and A2, and the actual residual masses are

`v_local=3-k s^n`, `v_ext=8100-k 2^(-n)`. (12)

Each of the2^n old coarse roots touching0 receives one orthant of local source, full mass3/2^n. Each orthant is attached to its root corner, with coordinate width s/2=1/n^2<1/n. At every allowed R318 split along old fine boundaries the entire orthant stays in one child, down to the old fine grid. Thus every nonzero terminal packet on its path has mass3/2^n and volume at most k^(-n), so its old average is at least

`3(k/2)^n>k`.

This proves the actual old HIGH-average classification. It is also old aggregate-deep at R=1:

`3/2^n<exp(-k)/k`, (13)

using the exact sufficient inequalities `3k*3^k<2^n` for the stated three dimensions, together with e<3. No original packet is changed or merged for this qualification.

For receivers in `V=Q_(1-s)(0)`, every r in[1,2] captures the entire local cube and excludes the external cube (nearest external coordinate distance at least5/4+s/2>1). Hence

`h_r*f=3/r^n`, `M=3`, `R*=1`, `G_N=1/3` on V.

Choose K0 containing the finite complete source. The two ownership cells are connected (index distance2), their side5 macro-packages contain all source, and

`(v_local+v_ext)/(2k)>v_local`,

`v_local/(v_local+v_ext)<1/k`,

`v_local+v_ext>3^k>exp(k)`.

Thus every contributing ownership capture gate fails, Theta=0, the harmonic deficiency holds, the non-small capture gate holds, and the fixed component is heavy. The exact native local traffic on V is positive, belongs to the CURRENT old aggregate-deep/high-average unpaid measure U, and has mass

`H_V=(v_local/3)(1-s)^n>0`. (14)

Now consider the ORIGINAL R320 tiny grid, at ANY phase. Any tiny cell captures local full mass at most

`(3/s^n)delta_0^n=3/2^n<1/k`.

Its external full mass is at most `8100(2/n^2)^n<1/k`, and no tiny cell meets both cubes. Therefore EVERY tiny cell is below the frozen preactive threshold1/k. R320 pays zero on this input for EVERY phase, and its actual U_left equals U. This is stronger than relying on a rare rejected phase.

For the NEW root grid, a uniform root phase contains the entire local cube in one root with probability

`q=(1-s/delta_root)^n=(1-2/n)^n>1/16` (the stated dimensions). (15)

On this event that root has full mass3>1/k=tau at R=1, while the fine cell is still below threshold. Thus it is EXACTLY the new increment in(5). The new paid mass obeys

`||U_increment||>=q H_V>H_V/16>0`. (16)

Root cells meeting only the external source have mass at most `8100(2/n)^n<1/k`, so they are not preactive. Root side1/n is too small to meet both cubes. Therefore `W_act,root<=3` at every seed, and the cost of the entire joint union is at most `3k(1+1/n)^n`. No source budget8100 is charged by this new receipt on the diagnostic.

This example verifies a strict increase in scope INSIDE the exact old unpaid traffic. It uses neither a uniform lower bound on the old tag theta nor a pointwise source cap. It does not claim that arbitrary U_left has a constant fraction satisfying the new root gate.

## 6. Complete entrance with the old bill replaced

R319's actual epsilon=1/128 entrance, BEFORE applying a tiny-grid fee, was

`X<=(768/761){P104(f,lambda)+S318+8C2^2 sqrt(n)W_lo+||U||}`.

Use(7),(9) on this exact U. The new usable complete-band result is

`X<=(768/761){P104(f,lambda)+S318+8C2^2 sqrt(n)W_lo`

`                                  +G_root+H_rootleft}`. (17)

G320 is absent; it has been superseded by the one root certificate for old-paid plus increment. There is no new output loss, so the original raw loss remains7/768. The original W_lo, classifications and L2 upper-bound density are not redefined using root averages.

The remaining exact positive integral is

`H_rootleft=E_(sigma0,J) integral 1_{m_(D_sigmaroot(z))<lambda R(x)^n/sqrt(n)}dU`.

It is an actual submeasure of the old U_left, with all original source fields, masks and dx retained. Its root-order price is NOT proved. The strict progress is the joint-union budget(9), the scale-cost consolidation, and the positive new intersection(16). Further coarsening beyond a/n incurs its true factor in(11); no free physical-scale or shift supremum closes this remaining integral.

## 7. Actual computations and independent audit

Local Python/Fraction execution verified the old-deep/high-average, all native macro/heavy and source-capacity inequalities for n16,36,64. It verified original tiny-cell inactivity and new external-root inactivity exactly. It also checked180 exact one-coordinate instances of the nested phase construction (multiple rational phases, offsets and source locations), all PASS. These arithmetic tests support the analytic set-containment proof(4), rather than replacing it.

Executed values were:

| n | old tiny paid mass | new root containment q | root factor (1+1/n)^n | lower new mass qH_V |
|---|---:|---:|---:|---:|
|16|0|0.1180670870|2.6379284974|0.1041427087|
|36|0|0.1277470812|2.6814644203|0.1208383756|
|64|0|0.1310840325|2.6973449526|0.1270500312|

The probabilities and factors are exact rational expressions in(15)/(10); decimal values only illustrate their size. The numeric author received the complete three-stage native fixture and nested-seed parameters for independent certificates; no unreturned certificate is assumed here. `/root/r285_final_audit` independently screened the coupled-phase identity, one-budget replacement and strict new fixture, reporting PASS. It confirmed the old U_left can be retained in its canonical original seed lift, and that repricing the actual union is essential. No historical FULL or global weak-bound conclusion is inferred.
