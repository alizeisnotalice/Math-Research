# R321 independent preauthor screen — source domination and geometric capacities

Ownership: only /tmp/r321_audit.md, no Git or other author's file edits. Written before reading any R321 author proof. The target is the original R320 B_H middle source geometry / high-J low-A C_long, not a replacement projection or an assumed root estimate. This is a bounded constructive contract screen; final history and author comparisons are pending.

## 1. Source domination must be tied to its actual ceiling

The old fields remain U_y(x)=1_E alpha P_s,L(x-y)/q, rho=integral beta U<=1, original R,L,q,s and full J/A/v. A measure inequality beta<=f alone says P*beta<=P*f or beta(C)<=f(C); it supplies no numerical capacity unless the SAME complete f response is bounded at the SAME actual receiver and the SAME kernel/scale. In particular same-selected-R nu cap and rho<=1 do not imply a full all-radius f cap, a future-softness f cap, or any cap centered at source y or a virtual receiver.

If the matched actual contract additionally certifies h_t*f(x)<=4lambda for all t in[a,b], x in the original E, then for every such actual x,t:

 beta(Q_t(x))<=4lambda t^n if beta<=f;
 nu(Q_t(x))<=4lambda t^n if nu<=f;
 beta(Q_t(x))+nu(Q_t(x))<=4lambda t^n if beta+nu<=f.

The last line is STRONGER than separate beta<=f and nu<=f, which only give a sum bounded by 8lambda t^n. Two slots of the same original residual source can each be dominated by f while their sum is not. A history chain or a repeated source copy must not be silently strengthened to beta+nu<=f. The inequality must hold for the actual original sources at every retained seed/outer parameter, before applying the proposed allocation; source restrictions inherit it, but recomputing e_g/m or changing the source inputs is not allowed.

Shared capacity on one common actual cube gives beta(C)nu(C)<=f(C)^2/4. This is a LOCAL mass product after both sources have been restricted to the SAME certified C. There is no pointwise dy dz bound beta(dy)nu(dz)<=f(dy)f(dz)/4 at unrelated source points. A symmetric pair integration can use its own explicitly symmetrized measure inequality, but the physical asymmetric soft/hard kernel or original oriented mask is not automatically symmetric in y,z.

## 2. Actual source halos: valid radius direction and positive paid windows

If captured z belongs to a frozen source packet P of infinity diameter d, then P is contained in Q_(R+2d)(x) at the SAME original receiver. Where R+2d<=b and nu<=f (or full mass field mP=integral_P f is used), the complete f cap yields

 mP<=4lambda(R+2d)^n<=4lambda Kp R^n,
 Kp=(1+2d/a)^n.

This is an upper mass bound and hence a LOWER bound R^n>=mP/(4lambda Kp). It does not imply a birth upper bound or pay all captured P traffic. A separate genuine positive gate mP>=c R^n, c>0 frozen, supplies the upper endpoint R^n<=mP/c. On this allocated gate a fixed legal radius window has nth-log width <=log_+(4lambda Kp/c), clipped to[a,b]. Original FIRST then gives a source-once hard-column envelope receipt for nu|P (with the actual gate's coefficient). A top-overflow R>b-2d branch needs its own legal top-window price. These packet-window payments are legitimate constructive uses of domination; they do not assert that the complementary low-mass traffic is small.

The full source masses used to define a packet must stay the full original ones. Summing a source partition bills nu(P) once, whereas overlapping support masses or receiver supports require the actual allocation/energy bookkeeping. No exponential packet count is necessary for the source column sum, but geometric enlargement Kp itself must remain, or enter the logarithmic window exactly. Bounds outside[a,b] are not inherited.

For the soft source y, being close to an actual receiver is a separately specified event. The hard component has support Q_L(x). Positive soft coordinates do not: they have actual tails. Thus beta<=f cannot turn all soft source traffic into beta(Q_L(x)) or a hard halo. One may retain a fixed near-y event and pay the exact remaining soft receiver tail by R320's proven source-linear tail receipt; its q_-H/threshold costs and unpriced middle complement remain. Enlarging a near-y halo beyond b, or translating its center to y, requires a new bound rather than the old all-radius cap.

## 3. A stronger shared-soft headroom interface, conditional on the true source sum

Suppose in addition the original SAME actual full-soft response satisfies P_s,L*f(x)<=q(x), AND beta+nu<=f. Since alpha<=1,

 rho_beta(x):=integral alpha P_s,L(x-y)beta(dy)/q(x),
 rho_beta(x)+(P_s,L*nu)(x)/q(x)<=1.

This is a genuine joint-source capacity and no component FIRST is used. Define the actual kernel overlap floor

 c(x)=R(x)^n essinf_{z in Q_R(x)}P_s,L(x-z).

Then P_s,L*nu>=c(x) h_R*nu. On a positive c gate the actual mixed receiver row is at most

 rho_beta h_R*nu <= q rho_beta(1-rho_beta)/c <=q/(4c).

All original additional masks only reduce this row. For R<=L, the true phi inside >=1/4 gives the explicit floor

 c>=(R/L)^n(1-3s/4)^n.

It retains ALL softness and scale-ratio losses. For s=0 and R>L, c may be zero, and no positive floor is granted. For an actual c>=c0>0 gate the displayed bound is an actual receiver/output budget <=X/(4c0) when q<=lambda; it is not an arbitrary-small epsilonX or source-root budget. c can be tiny and the gate may be empty under the full original feasibility conditions. Original outer coefficients must multiply this budget before any absorption claim. No unconditional result follows until the history agent certifies BOTH the same full-soft ceiling and beta+nu<=f for this original target.

Separate beta<=f,nu<=f with the same soft ceiling only gives rho_beta+(P*nu)/q<=2 and the weaker bound rho_beta h_R*nu<=q rho_beta(2-rho_beta)/c<=q/c, since rho_beta<=1. This must not be reported with the factor1/4 shared-source saving. Alternatively genuinely disjoint source allocations may satisfy a sum inequality, but their exact remaining pair traffic/cross terms and source multiplicity have to be preserved.

## 4. Quantifiers of a possible real high-J/low-A saving

All such local capacities refer to each original actual receiver, while C_long integrates common source y, two receivers, original low A<H and J>=L_*H, plus actual z and ell layers. To change its budget one needs a source-conserving estimate linking those certified halos at the two actual receivers, with the actual full-J normalization, original alpha/masks, scale atoms, source measure and outer clocks retained. A local beta/nu cube capacity is not already that integrated estimate. Projection identities alone also do not supply it. Conversely the capacities above are usable positive constraints and packet-window/headroom gates; this screen does not rule out the geometric route.

## 5. Local computations actually executed

Local Python standard-library exact Fractions:22 shared-cube capacity/AM-GM checks;60 shared-soft headroom inequalities;18 packet lower-radius direction checks. Total100 assertions PASS. These finite algebraic checks are not original-input realizations, history certification, or evidence for a new generic root bound. The inequalities and their hypotheses above are analytic. No R319/R320 test was repeated, and no broad counterexample search was performed.

## 6. Pending bounded comparison

Await the actual original source contract and precise author candidates. The source inequalities, complete-f response ceiling, receiver centers, legal radius interval, source copies, support of soft versus hard components, and any new output loss must be checked explicitly. No general B_H middle/C_long root-source price, native residual payment, or full weak-bound closure is asserted in this initial screen.

## 7. Independent nested-source-grid screen before author proof

The nested-phase construction is sound. With delta0=a/n², uniform sigma0 in[0,delta0)^n and independent J uniform{0,...,n-1}^n, sigma1=sigma0+delta0 J is uniform in[0,delta1)^n, delta1=a/n. Every coarse cell is a union of the tiny cells from the SAME original seed, so mC<=mD. At the original threshold tau=lambda R^n/sqrt(n), finepass implies coarsepass. Therefore old finepaid plus new finefail/coarsepass equals coarsepaid pointwise in the canonical joint lift of the unchanged R319 measure. Repricing that joint union by ONE coarse row-volume fee <=e sqrt(n)W is legitimate; subtracting numerical upper bounds would not be. Coarsefail remains exact and implies finefail. Further nested smaller-scale successes form a subset of coarsepass and introduce no independent fee if actually allocated through this identity.

The proposed n16/n64 cluster side s=2/n² has every tiny-cell local mass <=3/2^n<1/sqrt(n), so the R320 tiny receipt pays zero on this cluster for EVERY shift. Its orthant width1/n² remains below the old fine width1/n, so the R318 old corner trajectory and old-deep/high-average status remain supportable. Coarse whole-cluster containment probability (1-2/n)^n is positive and exceeds1/16 in these two cases. Native/remote masks require the same explicit final fixture audit as R320; no new generic accepted fraction is asserted.

## 8. Independent high-softness envelope screen before author proof

For s in[s0,1], s0=1-1/(2sqrt(n))>=1/2, write epsilon=1-s and f_s=epsilon h+s phi. The s-score a_s=(phi-h)/f_s has mean zero under f_s and |a_s|<=3: inside the hard interval f_s>=phi>=1/4, outside a_s=1/s<=2. The ordinary BODY dilation score b_s=-1-s t phi'/f_s has mean -epsilon, NOT zero. Its variance is bounded uniformly by a finite constant: a crude proof uses |phi'|<=1 inside, phi>=1/4 there, and the explicit exponential tail lower bound phi(t)>=(1/4)exp[-(4/3)(|t|+1/2)] with |phi'|<=exp(1/2-|t|) outside. The dilation derivative also has positive hard-face measure of total variation n epsilon. Thus its total variation is O(sqrt(n)+n epsilon)=O(sqrt(n)) on the proposed window.

The mixed s/logL BODY derivative has terms P[(sum a_s)(sum b_s)+sum partial_s b_s]. The first is O(n) by centered a-score and the nonzero b-mean n epsilon=O(sqrt(n)); the second is O(n), since partial_s b_s=-t phi' h/f_s² is supported in the hard interval and uniformly integrable. Mixed hard-face variation is at most n+n epsilon O(sqrt(n))=O(n), using the mean-zero other-coordinate s-score before Cauchy-Schwarz, rather than a triangle sum that would incorrectly cost n²epsilon. Integrating mixed variation over the s window of length1/(2sqrt(n)) yields O(sqrt(n)).

A two-parameter positive envelope can therefore be proved by fixed-x s/logL BV/FTC, INCLUDING moving hard-face measures and endpoint traces. No assertion of ordinary Banach-L1 differentiability of a moving hard indicator is valid. With that interface supplied, its L1 mass is O(sqrt(n)) on b/a<=2. At the original capturing endpoint, alpha<=1, same-R nu cap and the inclusive ell tail then price the actual high-s capturing BASELINE by (4lambda/q_-)*envelope_mass Wbeta. Bad U, full J, actual R/source/history gates remain; no component FIRST or An duplication is granted. This is a genuine potentially new paid positive branch, not payment of the all-soft/middle complement. Sharper constants await author audit; no floating value is used for this screen.

## 9. Author comparisons after independent screens

Read /tmp/r321_entry.md (current SHA256 bf37eadec4f3b62a1735c1ed267186ba2cbcefafc852b9e33586796c39ba4d9c). The exact canonical two-seed allocation, integer nested-root construction, source-once row-volume bound and replacement of the old tiny bill agree with §7. The new increment is a genuine positive submeasure of old U_left; old-paid plus increment is the jointly repriced root-paid measure, not an inequality between unrelated bounds. Current R318 packet/high-average/tag masks remain. The single-root parameter L has its actual exp(L+1/n) fee and is not a free scale supremum. Checked the actual n16/36/64 source/receiver subset geometry, old corner-path mass, native gates, zero old tiny coverage and positive new root containment: consistent with the analytic construction. Exact root-failure traffic remains unpaid. No correction requested.

Read /tmp/r321_selector_geometry.md, SHA256 423fb6a9a1c1f76726baae3cf875230b24f5132272c02a6ee7dc363b52128002. The prefix/aspect union quantifier is correct; no source or global J saving follows from that restriction alone. Its auxiliary A capacity first envelopes actual selected kernels and only then convolves with the fixed prefix cube. The exact single-scale cancellation includes both endpoints. The reused R303 contraction and safe20 coefficient bound are legitimate; the stated e² upper bound can be proved by summing j=0..5 and bounding the remaining positive series geometrically:109/15+28/225=1663/225<8. The hard radial-selector illustration is explicitly a relaxed capacity example, not a native/history counterexample and not an integrated source-budget obstruction. Its 145 diagnostics include85 exact Fraction comparisons (20scale,5coefficient,60refinement) and60 ordinary65-digit Decimal radial-value comparisons; neither is a uniform proof. No correction requested.

Read the complete /tmp/r321_middle_core.md after the independent high-softness screen. Its K=17/6+1/(12c) is rigorous: outside x=1/2+t, mixture Cauchy-Schwarz gives the u^-1 integral; integrating (t+1/2)^2 exp(-t/u) contributes1/4+u+2u². The inside integral is <=1/(12c). The ordinary dilation BODY score mean is correctly -(1-s); its independent-coordinate second moment retains n²(1-s)². Every off-diagonal mixed term and mixed moving-face measure is retained. The fixed-x BV/FTC and coarea argument supplies an actual measurable density envelope simultaneous in selected s,L, with one-sided traces, not a fictitious ordinary L1 derivative of moving hard faces. Its same-R source cap is used at the actual capturing endpoint before receiver extension; full bad U/J and qualifications remain. No extra An, component FIRST, source product or source-density cap is introduced.

Requested one bounded correction: replace the Result's unproved rounded decimal Z<=12.448sqrt(n) corollary with the exact analytic Z expression or safe13sqrt(n). The analytic exact constants already prove a root receipt; ordinary float values in §5 alone are not a strict rounded-constant certificate. The parent's supplied safe13 rational derivation was independently checked: e>8/3 gives c>5/16,K<31/10,B<51/20,D0<29/10,Q<19/5,M<1107/50, so Z/sqrt(n)<91/40+(7/10)(1497/100)=12.754<13, using log2<7/10 from the positive exponential series. No numerical rerun needed for this textual theorem correction.

The high-soft receipt certifies a valid actual subbranch under its stated inherited fields. It has not by itself certified a NONZERO intersection with every current historical qualifier or superiority to any earlier paid ns-tail. If the exact current target also retains ns<=D, that compatibility must be checked explicitly. This is a scope/novel-coverage guard, not a defect in the analytic envelope theorem. No universal middle or C_long payment follows for the remaining s<1-1/(2sqrt(n)) captures.

## 10. Decisive original-source provenance spot check — correction required

Read /tmp/r321_source_contract.md and spot-read the actual frozen R237 source_ledger.md lines17–33/39–85, R244 receiver_ledger.md lines9–29 and R301 r301_geometry.md lines5–38 from their archives. The abstract R301 theorem indeed allows arbitrary beta,nu, and its FIRST capacity is a receiver-side bound. However the new provenance note's broad negative conclusion about matched original beta<=f and nu<=beta is not supported by those records: R237 SL1 line25 explicitly records the later COUPLED flow nu<=zeta_sigma*<=beta^c=alpha-eta_alpha^c<=alpha, and lines28–33 cite the audited downstream chain.

To resolve that exact point, read frozen R113 coupled_transport.md lines51–84 and R226 archive source_geometry.md lines9–28. R113 C7/C8 preserves hard nu in the actual coupled soft residual. R226 lines14–16 explicitly identify R114 input beta=beta^c (not the earlier independent flow), preserve nu<=beta, and quote R116's nu<=beta<=f dx. R226 SG1 lines20–28 states the actual retained-leaf contract

 0<=nu_V<=beta_V=beta_V^c<=alpha_V<=f dx.

Thus this is a legitimate additional source-order interface WHEN the current original slot is explicitly matched to that coupled lineage; it is not merely a leaf-total comparison. The general abstract R301 theorem does not automatically inherit it by notation. beta+nu<=f remains unproved and does not follow from this stronger chain. No density cap, reverse inequality beta<=nu, soft rank, low beta leaf mean or common posterior identity follows.

Parent and source-lineage author were notified with these decisive original references. Final provenance note must distinguish the early independent soft flow, the later actual coupled flow, and the abstract arbitrary-source theorem before final integration is bound. This bounded check does not reopen all history or certify an unprovided target-map identity; it prevents discarding a genuine original source contract or assuming a false stronger source sum.

## 11. Corrections resolved and historical high-softness coverage

Read the revised source_contract finding, coupled-lineage paragraph and complete minimal-contract conclusion: it now explicitly grants nu<=beta^c<=alpha<=f for the correctly named coupled lineage, while keeping the abstract-slot identity separate and not assuming beta+nu<=f. The substantive provenance correction in §10 is resolved for that revised note. No global target map is newly certified by this bounded spot check.

Read the revised high-softness Result and rational safe13 certificate. It now uses exact analytic constants, with Z_n<13sqrt(n) rigorously proved by the rational chain checked in §9. The earlier rounded-decimal theorem concern is resolved. Its s/logL variation and actual source receipt remain unchanged.

Read /tmp/r321_highsoft_scope.md, then spot-checked actual R281 integration.md:3,21 and R288 README.md:23,30. The matched R279/R281 current near remainder retains ns+R2<=D; for fixed outer constants it eventually excludes s>=1-1/(2sqrt(n)), and R288 already pays its high-s physical exceptions when applicable. Thus the valid new high-soft envelope lemma is NOT certified as a strict new asymptotic unpaid branch of that matched near route. The abstract R301/R302 low-pe/aspect theorem does not restate this gate or establish the missing exact ancestor domination; neither a missing gate nor a match can be inferred from labels. The note correctly keeps these application lineages separate. The original locator for the R288 high-s paragraph was notified and corrected to line23; no formula changes were needed.

Read the independent cluster certificate scope and initial code: the non-dyadic k6 path, exact source masses, actual native receiver subset and seed/source containment calculations are appropriately certified by rational arithmetic, not sampled uniform-phase probabilities. Analytic interval tiling establishes the continuous seed marginal and strict new acceptance event. Its exact finite tests do not enumerate the full band or solve H_rootleft. Primary fresh logs and final artifact bindings remain pending.


## 12. Final integrated receipt — PASS within scope

Read final checkpoint combined.md and research.tex, including the final two clarity changes: D=O(log(n+2)) is explicitly limited to fixed legal outer parameters, and M_y(r)=integral A_yz(r)nu(dz) is the captured first moment, not the grid integer parameter. The source-contract correction, safe13 rational constant and high-softness matched-route coverage qualification are all incorporated. No mathematical correction remains pending.

The new native joint-union fee G_root genuinely REPLACES G320 by an exact allocation identity and is added to all earlier P104/S318/R319 source bills. The exact H_rootleft remains, with no universal accepted fraction. The raw native output loss stays7/768 and the multiplier768/761 is unchanged. The high-soft joint envelope is a valid analytic root-source tool, but it is not counted as new asymptotic unpaid coverage on the matched R279/R281 route already addressed by R288. The auxiliary prefix capacity is not presented as a source-linear payment. Correctly matched coupled nu<=beta^c<=f can be used as a source order, not a density cap, source-sum inequality or unproved abstract-slot identity.

Read all three primary fresh execution logs/code: cluster3792 exact Fraction/integer assertions; highsoft74=71 exact rational/dimension assertions+3 ordinary truncated mpmath Fisher quadratures (20/30/40 digits at endpoints8/16/32); selector145=85 exact Fraction assertions+60 ordinary65-digit Decimal radial comparisons. Thus total4011=3948 exact+63 ordinary high-precision diagnostics. They are assertion counts, not distinct input realizations or proof of the remaining uniform estimate. The highsoft Fisher full bound is analytic, not inferred from truncated numerical integrals. The cluster certificate covers a genuine positive-L1 native RECEIVER SUBSET in n16/36/64 and its seed geometry, not the full band/history or the unpaid remainder. This reviewer's own100 exact checks in §5 are separate and are not added to that primary total.

Verified all five current checkpoint proof/scope copies byte-identical to their /tmp originals, final cluster script/JSON byte-identical to the numeric author's frozen files, and the extracted selector script equal to its embedded proof code after whitespace trimming. The references manifest explicitly locates historical bytes without claiming all referenced proofs were reread. Only the decisive provenance/scope excerpts described above were independently spot-checked here; this is not a new audit of every historical connector. No PDF compilation or redundant test rerun was performed.

## 13. Exact remaining gap and freeze

PASS for the bounded analytic results, corrected provenance/scope notes and final static integration. No general root price for original B_H middle source geometry or the retained high-J low-A capture is established. Native H_rootleft remains exact and unpaid. Source order alone supplies no boundary-mass decay; the two target entrances are not identified or freely combined. Original slot maps, broad-distance and low-pe/extreme-aspect costs, initial/deletion/future-deleted terms, every physical-scale and outer coefficient, and a global uniform epsilon sum still require their original separate ledger. The native7/768 is not a certificate of total global absorption. General n^(1/2+o(1)) weak closure is NOT certified.

Final SHA256 bindings follow. These are the current bytes reviewed; no further changes are covered by this receipt.

- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round321_20261018_final_checkpoint/cluster_checks.json`: `e18e88e4b9edca4f3f40e4cbba3dbc4d45dec1ef01b0d41d46997710731ce147`
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round321_20261018_final_checkpoint/cluster_checks.log`: `09e1ff420772557737a1b439ac6f2da53e2fc854c2292b2c00227f23c5a4fe5e`
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round321_20261018_final_checkpoint/cluster_checks.py`: `f26f3622685db1df3552ad632183f22d6fb55eb78361b8c1d71e9e796ea00a9c`
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round321_20261018_final_checkpoint/combined.md`: `3ab3dfc7e05d368ec29ea1ee2c992cd51c153453fd8137a4e2761f9c1d68b976`
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round321_20261018_final_checkpoint/entry.md`: `bf37eadec4f3b62a1735c1ed267186ba2cbcefafc852b9e33586796c39ba4d9c`
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round321_20261018_final_checkpoint/highsoft.md`: `cf0946d21aec85abc2c3b733c33ba26b166342ca8b2940a1f5a52e4835dc91e1`
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round321_20261018_final_checkpoint/highsoft_checks.log`: `90feb6514224c1eb1a77c619a36e760b2db30b82eb0da9003ef84ece044de12b`
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round321_20261018_final_checkpoint/highsoft_checks.py`: `1b00813263a21fe57e581ba09931ab0d6e537d8b4ba0c81f765c7a64112d618e`
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round321_20261018_final_checkpoint/highsoft_scope.md`: `6673ad96d671a8be4e8162f304e1f546a1e96510627501497f6ee6ad3df6e01b`
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round321_20261018_final_checkpoint/research.tex`: `3390def8200b8c0119a079dd07755b325757848b16cfb2f634ecb3f6288a57ec`
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round321_20261018_final_checkpoint/selector_capacity.md`: `423fb6a9a1c1f76726baae3cf875230b24f5132272c02a6ee7dc363b52128002`
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round321_20261018_final_checkpoint/selector_checks.log`: `61daaafea6b7aa1c98c298063b139938d633bc20f6c65fd670b7ca0b01c63ce8`
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round321_20261018_final_checkpoint/selector_checks.py`: `ff0b31f106e45fcd33979d60e569fdd19a229d1f71e734e7f79cfecc9734aaaf`
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round321_20261018_final_checkpoint/source_contract.md`: `7249975b1eb7bb8a3ecef1f9227215456244db64aaa2393fa4c38e0f94463aea`
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round321_20261018_final_checkpoint/source_references.json`: `971bc809826ff87470a40c14d14b4f8575b3f050d25d54e634721fba2c2ef7bd`

Ownership respected: only /tmp/r321_audit.md written by this reviewer. No Git/repository or other author file edit, no full-history re-audit, and no expanded search. Final bounded audit frozen.
