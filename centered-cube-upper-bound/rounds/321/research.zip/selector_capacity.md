# R321 — what prefix/aspect restrictions actually buy

## 1. Quantifier screen and result

Keep the original actual U_y,A_yz,J_y, q>=q_-, a<=L,R<=b<=2a, full common softness s, original FIRST and source/history masks. On the retained aspect branch assume

    min(1,(L/R)^(n/2))>=v0,  0<v0<=1.

For a fixed prefix a<=r<=b this is L>=v0^(2/n)R with R<=r. As a restriction on the UNION of soft-scale selectors it excludes nothing: R=a is admissible for every L in[a,b]. Thus these two gates alone do not improve the available J envelope or the conditional row-tail denominator q_-H in R320. This does not assert optimality of the old global A_n Csoft_n envelope; a sharper joint-softness/scale theorem would be a different input, not a consequence of these gates. No claim realizes every historical qualification by an arbitrary relaxed selector.

There is a useful but auxiliary capture-capacity improvement:

    A_yz(r)<=C_n(rho)[1+n log(r/a)]/q_-,             (1)
    C_n(rho)=sum_(k=0)^n c_nk rho^k<=1/(1-rho),
    c_nk=max_s binom(n,k)s^k(1-s)^(n-k),
    rho=1-2 integral_0^1 u exp(-3/(2u))du<1.

It holds uniformly in y,z, r and the actual receiver-dependent selectors/masks. The strict coordinate contraction is the EXISTING R303 lemma `/tmp/r303_soft_gap.md`; the calculation here uses one soft-scale envelope and a fixed prefix cube, rather than its two independent scale envelopes. It is not counted as a new source payment or a new contraction theorem.

This replaces the old pointwise cap A<=J<=A_n Csoft_n/q_- by a dimension-free coefficient times the smaller prefix logarithm. For a fully explicit coarse constant one can use C_n(rho)<20: 1-rho>=(7/16)e^(-2)>7/128>1/20, integrating only u in[3/4,1]. The elementary series bound e^2<=1663/225<8 proves the stated rational comparison. The sharper R303 coefficient may be kept instead.

## 2. Legal one-scale calculation

An actual captured endpoint with R(x)<=r lies in Q_r(z). Drop only positive restrictions, after retaining the original q bound:

    A_yz(r)<=q_-^(-1) integral_(Q_r(z))
                                sup_(s,L in[a,b])P_(s,L)(x-y)dx.

Use the ORIGINAL common-s positive expansion P_(s,L)=sum_k b_nk(s)Q_(k,L), with normalized fixed-degree ray-decreasing profiles Q_k and c_nk=max_s b_nk(s). The scale envelope is

    K(x)=sum_k c_nk [b^(-n)Q_k(x/b)
                      +n integral_a^b L^(-n)Q_k(x/L)dL/L].

The R303 fixed-scale tensor inequality, valid for L,r in[a,b], is

    (Q_(k,L)*h_r)(z-y)<=rho^k max(L,r)^(-n).

No selected scale has been put inside a fixed convolution. First the actual receiver integrand is bounded by K; only then is the ordinary fixed-prefix convolution with h_r evaluated. With mu(dL)=delta_b+n dL/L,

    A_yz(r)<=q_-^(-1)r^n C_n(rho)
                                integral max(L,r)^(-n)mu(dL).

The exact single-scale cancellation is

    integral max(L,r)^(-n)mu(dL)
      =b^(-n)+n r^(-n)log(r/a)+(r^(-n)-b^(-n))
      =r^(-n)[1+n log(r/a)].                       (2)

This proves (1), including r=a,b and a=b. It uses neither a component FIRST nor a beta/nu order. The original aspect gate may be retained in A but was not needed for this upper bound. One must not insert it into the auxiliary independent dilation variables without a separate qualification-preserving proof.

## 3. Why this does not pay a new bottom or long-distance branch

The scale factor in (1) cannot be removed merely by prefix/aspect geometry. In the relaxed hard-selector family, take y=z=0, s=0, E=Q_r(0), q constant, and

    L(x)=R(x)=max(a,2|x|_infinity).

Then L=R satisfies even v0=1, all scales are <=r, and the actual row integral at those source points is

    q A_00(r)=q J_0(r)=1+n integral_a^r dL/L
                                        =1+n log(r/a).

This is a selector-capacity example only, not an original low-pe/history traffic counterexample, and it says nothing against separately qualified high-softness branches. It proves the unavoidable logarithmic scale factor for the broad capacity class, not sharpness of the old product A_n Csoft_n.

Turning (1) into a common-source estimate still requires original FIRST:

    C_z(r)=integral A_yz(r)beta(dy)<=r^n,
    C_z(r)<=W_beta C_n(rho)[1+n log(r/a)]/q_-.

Their minimum is the familiar mass/entropy alternative. Spending the second bound after nu integration as though W_beta W_nu were a source-linear fee would be invalid. No new paid bottom branch follows from this capacity alone; the existing R319/R320 bottom and distance receipts remain the applicable source budgets.

Specifically R320's missed-endpoint long baseline uses

    [integral U_y(w)1{|w-y|>t}dw]/J_y(r).

The present prefix/aspect gates leave every soft L available in its numerator and do not increase its high-row lower bound J>=H. The capturing-endpoint tail there is already paid by the SAME-radius nu cap, which cancels R^n before the soft row-tail integral is evaluated. Replacing that step by (1) would introduce the unpaid cross-source mass rather than improve the source-linear coefficient. Thus this note does not change C_long or its source prices.

The capacity (1) can certify that a proposed gate A>=Kd is empty whenever Kd exceeds its right side, and can be used in an actual numerical certificate. R316 has already removed saturated high-A occupancy without an added fee. No integrated root estimate for the remaining low-A geometry is obtained here. The current high-soft joint-envelope route is separate and is not duplicated.

## 4. Executed bounded diagnostics

The exact Fraction/65-digit Decimal code below returned `PASS {'scale_cancellation': 20, 'contraction_coefficient': 5, 'radial_selector': 60, 'refinement': 60}`. The contraction coefficient is tested at the safe rational upper value19/20, not inferred numerically for the true profile. The radial selectors are finite hard-shell approximations; they check the selector-capacity calculation, not original source/history realizability or a source budget. Formula(2) and the source-scope conclusions are analytic.

```python
from fractions import Fraction as F
from math import comb
from decimal import Decimal,localcontext
ct={'scale_cancellation':0,'contraction_coefficient':0,'radial_selector':0,'refinement':0}
with localcontext() as ctx:
 ctx.prec=65
 def dec(x):return Decimal(x.numerator)/Decimal(x.denominator)
 for n in (1,2,8,32,128):
  cs=[F(comb(n,k)*k**k*(n-k)**(n-k),n**n) for k in range(n+1)]
  C=sum(cs);Cr=sum(c*F(19,20)**k for k,c in enumerate(cs))
  assert 1<=Cr<C and Cr<=20;ct['contraction_coefficient']+=1
  for r in (F(1),F(5,4),F(3,2),F(2)):
   b=F(2)
   assert r**n*(b**(-n)+(r**(-n)-b**(-n)))==1;ct['scale_cancellation']+=1
   target=1+n*dec(r).ln();old=F(0)
   for steps in (16,64,256):
    ls=[1+(r-1)*F(j,steps) for j in range(steps+1)]
    val=1+sum((ls[j]**n-ls[j-1]**n)/ls[j]**n for j in range(1,len(ls)))
    assert dec(val)<=target+Decimal('1e-55');ct['radial_selector']+=1
    assert val>=old;ct['refinement']+=1
    old=val
print('PASS',ct)
```

Only `/tmp/r321_selector_geometry.md` is authored here. Other authors' files and Git are unchanged.
