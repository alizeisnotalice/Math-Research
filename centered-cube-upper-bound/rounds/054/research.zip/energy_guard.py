#!/usr/bin/env python3
"""Cube multiplier energy and true band-energy pressure, standard library only.

Spectral samples are multiplier tests, not plane waves asserted to belong to
L2(R^n). Log-scale Simpson refinement is numerical, not a rigorous quadrature
interval. Its omitted tails have explicit analytic envelopes, displayed with
Decimal arithmetic. Atom band-energy formulas are exact analytic identities;
positive-width 1D spikes have closed integral formulas checked at two precisions.
Neither large squared band energy nor spectral samples imply a weak-type bound.
"""
from decimal import Decimal, localcontext
from fractions import Fraction as F
from pathlib import Path
import hashlib
import json
import math
import random
import time


def ds(x):
    return format(x, '.24E') if x else '0'


def dec(x):
    x = F(x)
    return Decimal(x.numerator) / Decimal(x.denominator)


def sinc_log(z):
    if abs(z) < 1e-4:
        value = 1 - z*z/6 + z**4/120 - z**6/5040
    else:
        value = math.sin(z) / z
    if value == 0:
        return 0, -math.inf
    return (1 if value > 0 else -1), math.log(abs(value))


def difference_product(theta, t, r):
    sign1, sign2, log1, log2 = 1, 1, 0., 0.
    for v in theta:
        if v == 0:
            continue
        a, b = sinc_log(t*v), sinc_log(r*t*v)
        sign1 *= a[0]
        sign2 *= b[0]
        log1 += a[1]
        log2 += b[1]
    if sign1 == sign2:
        high, low = max(log1, log2), min(log1, log2)
        if high < -745:
            return 0.
        return sign1 * math.exp(high) * (-math.expm1(low-high))
    return sign1 * math.exp(log1) - sign2 * math.exp(log2)


def simpson_energy(theta, n, low, high, resolution):
    left, right = math.log(low), math.log(high)
    steps = math.ceil((right-left)*resolution)
    if steps % 2:
        steps += 1
    step = (right-left)/steps
    r = math.exp(1/n)
    total = 0.
    for i in range(steps+1):
        t = math.exp(left+i*step)
        f = n*difference_product(theta, t, r)**2
        total += (1 if i in (0, steps) else 4 if i % 2 else 2)*f
    answer = total*step/3
    assert answer >= 0 and math.isfinite(answer)
    return answer, steps


def squared_product_tail(theta, start, factor):
    """Integral_start^infinity prod min(1,1/(factor*t*|theta_i|))^2 dt/t."""
    values = sorted((factor*Decimal.from_float(abs(x)) for x in theta if x), reverse=True)
    k, logc, low, answer = 0, Decimal(0), start, Decimal(0)
    for value in values:
        threshold = 1/value
        if threshold <= low:
            k += 1
            logc -= 2*value.ln()
        else:
            if k:
                amplitude = (logc-2*k*low.ln()).exp()
                answer += amplitude*(1-(low/threshold)**(2*k))/(2*k)
            else:
                answer += (threshold/low).ln()
            low = threshold
            k += 1
            logc -= 2*value.ln()
    assert k > 0
    answer += (logc-2*k*low.ln()).exp()/(2*k)
    assert answer > 0
    return answer


def directions(n):
    rng = random.Random(540000+n)
    raw = {'axis': [1.]+[0.]*(n-1), 'equal': [1.]*n,
           'dyadic': [2.**(-i) for i in range(n)],
           'strong_anisotropic': [1.]+[2.**(-20-i) for i in range(n-1)],
           'random_signed': [rng.uniform(-1,1) for _ in range(n)]}
    for name, vector in raw.items():
        length = math.sqrt(sum(x*x for x in vector))
        theta = [x/length for x in vector]
        assert abs(sum(x*x for x in theta)-1) < 1e-13
        yield name, theta


def spectral_guards():
    out = []
    for n in (1,2,4,8,16,32,64,128,256):
        for name, theta in directions(n):
            low, high = 2.**(-16), 512.*math.sqrt(n)
            estimates = []
            resolutions=(16,32,64,128,256) if name in ('axis','strong_anisotropic') else (16,32,64)
            for resolution in resolutions:
                energy, steps = simpson_energy(theta,n,low,high,resolution)
                estimates.append({'log_resolution': resolution, 'simpson_steps': steps,
                                  'interior_energy_estimate': format(energy,'.17g')})
            r = (Decimal(1)/n).exp()
            s2 = sum((Decimal.from_float(x)**2 for x in theta),Decimal(0))
            low_tail = Decimal(n)*(r*r-1)**2*s2*s2*Decimal.from_float(low)**4/144
            high_tail = 2*n*(squared_product_tail(theta,Decimal.from_float(high),Decimal(1))
                             +squared_product_tail(theta,Decimal.from_float(high),r))
            closed=None
            if name=='axis':
                def Faxis(z):
                    return z*z*z.ln()/2-Decimal(3)*z*z/4 if z else Decimal(0)
                candidate=n*(4/r*(Faxis((r+1)/2)-Faxis((r-1)/2))-r.ln()+3)
                closed={'axis_closed_formula_candidate_decimal':ds(candidate),
                        'last_quad_minus_candidate_decimal':ds(Decimal(estimates[-1]['interior_energy_estimate'])-candidate),
                        'status':'closed analytic formula independently validated in the accompanying proof; quadrature comparison is not a numerical certificate'}
            out.append({'n':n,'direction':name,'theta_float':theta,'random_seed':540000+n if name=='random_signed' else None,
                        'multiplier_convention':'prod sinc(t theta_i), uniform[-1,1]^n; Fourier rescaling from side-one cube leaves dt/t energy unchanged',
                        'integration_t_interval':[format(low,'.17g'),format(high,'.17g')],
                        'refinements':estimates,'tail_lower':'0',
                        'axis_closed_formula_crosscheck':closed,
                        'low_tail_analytic_upper_decimal':ds(low_tail),
                        'high_tail_analytic_upper_decimal':ds(high_tail),
                        'refinement_last_difference':format(abs(float(estimates[-1]['interior_energy_estimate'])-float(estimates[-2]['interior_energy_estimate'])),'.17g'),
                        'status':'multiplier numerical integration with analytic tail envelopes; interior quadrature not interval-certified'})
    return out


def atom_band_guards():
    out=[]
    lam=F(1,16)
    c=1-(-Decimal(1)).exp()
    assert dec(lam)*4<c
    for n in (2,4,8,16,32,64,128,256):
        T=Decimal(n)*Decimal(2).ln()
        rho0=(1-T).exp()
        assert T>1
        energy_over_lambda=T-1-Decimal('1.5')*dec(lam)*(1-rho0)
        positive_variation=dec(lam)*(1-rho0)
        for rho in (rho0,(rho0).sqrt(),Decimal(1)):
            d=rho.ln()
            for level in (dec(lam),2*dec(lam)):
                u=d-1-(1-level*rho).ln()
                assert -T<=u<=0
                B=(1/rho)-(-u-1).exp()
                assert abs(B-level)<Decimal('1e-65')*(1+1/rho)
        assert energy_over_lambda>0 and positive_variation<dec(lam)
        out.append({'n':n,'T_definition':'n log(2)','lambda':'1/16','rho0_definition':'exp(1-T)','rho1':'1',
                    'logvolume_window':'[-T,0]','physical_side_window':'[1/2,1]',
                    'source':'unit atom at origin','energy_over_lambda_mass_decimal':ds(energy_over_lambda),
                    'core_positive_variation_decimal':ds(positive_variation),
                    'identity':'E/lambda=T-1-(3/32)(1-exp(1-T))',
                    'status':'exact atom formula with Decimal evaluation; not a weak lower bound'})
    for k in (1,2,4,8,16,32,64,128,256):
        rho0=F(1,2**k)
        energy_over_lambda=Decimal(k)*Decimal(2).ln()-Decimal('1.5')*dec(lam)*(1-dec(rho0))
        assert energy_over_lambda>0
        out.append({'radial_dyadic_exponent':k,'lambda':'1/16','rho0_exact':str(rho0),'rho1':'1',
                    'energy_over_lambda_mass_decimal':ds(energy_over_lambda),
                    'identity':'E/lambda=k log(2)-(3/32)(1-2^(-k))',
                    'status':'analytic radial-annulus formula; dimension-free annulus coordinate, not extra sources'})
    return out


def spike_energy(T_integer, divisor, precision):
    with localcontext() as ctx:
        ctx.prec=precision
        lam=Decimal(1)/16
        rho0=(Decimal(1)-T_integer).exp()
        eta=lam*rho0*rho0/divisor
        assert eta>0 and 2*eta<rho0
        # Sufficient parameters for the separately proved all-rho crossing
        # estimates. The three receivers below only cross-check the formula.
        assert 2*eta<=rho0/4
        assert 4*eta/(rho0*rho0-4*eta*eta)<=lam/15
        assert 2*eta/(rho0*(rho0-2*eta))<lam
        assert Decimal(2)/15>2*lam
        assert Decimal(4)/5-2*lam>(-Decimal(1)).exp()
        def C(rho):
            return ((rho+2*eta)/(rho-2*eta)).ln()/(4*eta)
        def primitive(rho):
            return ((rho+2*eta)*(rho+2*eta).ln()-(rho-2*eta)*(rho-2*eta).ln()-4*eta)/(4*eta)
        for rho in (rho0,rho0.sqrt(),Decimal(1)):
            const=C(rho)
            # Both band crossings follow complete birth and precede the next
            # lower endpoint entering the profile. In this region B=C-e^-u-1.
            assert const-1/(rho+2*eta)<lam
            for level in (lam,2*lam):
                u=-1-(const-level).ln()
                assert (rho+2*eta).ln()-1<u<(rho-2*eta).ln()
                assert -T_integer<u<0
                recovered=const-(-u-1).exp()
                assert abs(recovered-level)<Decimal(10)**(-precision+15)*(1+const)
        integral_C=primitive(Decimal(1))-primitive(rho0)
        energy=lam*integral_C-Decimal('1.5')*lam*lam*(1-rho0)
        atom=lam*(T_integer-1)-Decimal('1.5')*lam*lam*(1-rho0)
        assert energy>=atom and energy>0
        return eta,energy/lam,atom/lam


def positive_spike_guards():
    out=[]
    for T in (2,4,8,16):
        for divisor in (64,4096):
            eta,e,atom=spike_energy(T,divisor,80)
            _,refined,_=spike_energy(T,divisor,120)
            assert abs(e-refined)<=Decimal('1e-45')*abs(refined)
            out.append({'dimension':1,'T':T,'eta_divisor':divisor,'eta_decimal':ds(eta),
                        'source':'(1/(2 eta)) indicator[-eta,eta]','source_mass':'1','source_nonnegative':True,
                        'receiver_annulus':'rho=2|x| in [exp(1-T),1]','lambda':'1/16',
                        'exact_positive_width_integral_definition':'E/lambda=integral_rho0^1 log((rho+2eta)/(rho-2eta))/(4eta) d rho -(3/32)(1-rho0)',
                        'energy_over_lambda_mass_decimal':ds(refined),'atom_comparison_decimal':ds(atom),
                        'precision_digits':[80,120],
                        'all_rho_coverage':'Sufficient small-eta parameter inequalities checked; full-rho implication is proved analytically, not inferred from three samples.',
                        'status':'actual 1D positive-width L1 source; closed spatial/time integral, Decimal stability guard; T is window depth, not dimension'})
    return out


def capped_atom_guards():
    out=[]
    lam=Decimal(1)/16
    for n in (2,4,8,16,32,64,128,256):
        T=Decimal(n)*Decimal(2).ln()
        for cap in (32,64,256,1024):
            rho_min=max((1-T).exp(),1/(cap*lam))
            assert 0<rho_min<1
            energy=rho_min.ln()*(-1)-Decimal('1.5')*lam*(1-rho_min)
            assert 0<energy<=(cap*lam).ln()
            out.append({'n':n,'M_cap_multiple':cap,'lambda':'1/16','rho_min_decimal':ds(rho_min),
                        'capped_energy_over_lambda_mass_decimal':ds(energy),
                        'log_cap_lambda_upper_decimal':ds((cap*lam).ln()),
                        'status':'exact single-atom cap formula only; no arbitrary-source capped-energy theorem'})
    return out


def fullscale_capped_atom_guards():
    """Independent rising/descending a-integral vs the fullscale closed form."""
    out=[]
    c=1-(-Decimal(1)).exp()
    cfloat=float(c)
    for cap in (1,2,3,4,8,16,64,256):
        if Decimal(cap)<=1/c:
            exact=Decimal(0)
            branch='K<=1/c: zero'
        elif Decimal(cap)<=2/c:
            exact=c*cap-1-(c*cap).ln()
            branch='1/c<K<=2/c: cK-1-log(cK)'
        else:
            exact=1-Decimal(2).ln()+(c*cap/2).ln()
            branch='K>=2/c: 1-log(2)+log(cK/2)'
        # z=a/lambda. At each receiver b=min(2,cz). Rising contributes
        # z(b-1)-(b^2-1)/2; descending contributes (b^2-1)/2.
        # Divide by z^2 and integrate dz, with logz substitution below.
        rising=descending=0.
        if cap>1/cfloat:
            edges=sorted({math.log(1/cfloat),math.log(cap)}|
                         ({math.log(2/cfloat)} if cap>2/cfloat else set()))
            for left,right in zip(edges,edges[1:]):
                steps=1024
                step=(right-left)/steps
                sums=[0.,0.]
                for i in range(steps+1):
                    z=math.exp(left+i*step)
                    b=min(2.,cfloat*z)
                    decaying=(b*b-1)/(2*z)
                    ascending=(z*(b-1)-(b*b-1)/2)/z
                    factor=1 if i in (0,steps) else 4 if i%2 else 2
                    sums[0]+=factor*ascending
                    sums[1]+=factor*decaying
                rising+=sums[0]*step/3
                descending+=sums[1]*step/3
        numerical=rising+descending
        error=abs(Decimal.from_float(numerical)-exact)
        assert exact>=0 and error<Decimal('1e-9')
        out.append({'M_cap_multiple':cap,'dimension_scope':'any n for the atom radial-volume coordinate',
                    'c_definition':'1-exp(-1)','formula_branch':branch,
                    'fullscale_energy_over_lambda_mass_decimal':ds(exact),
                    'rising_a_integral_numeric':format(rising,'.17g'),
                    'descending_a_integral_numeric':format(descending,'.17g'),
                    'independent_a_integral_error_decimal':ds(error),
                    'source':'unit atom at origin','receiver_restriction':'M(x)<=K lambda',
                    'status':'analytic fullscale atom formula, independently checked by split a-integrals; no arbitrary-source capped-energy theorem'})
    return out


def positive_box_spatial_difference(side,L,r):
    boundaries=sorted({-(side+v)/2 for v in (L,r*L)}|{(side+v)/2 for v in (L,r*L)}|
                      {-(abs(side-v))/2 for v in (L,r*L)}|{abs(side-v)/2 for v in (L,r*L)})
    def average(x,width):
        overlap=max(0.,min(side/2,x+width/2)-max(-side/2,x-width/2))
        return overlap/(side*width)
    total=0.
    for left,right in zip(boundaries,boundaries[1:]):
        a=average(left,r*L)-average(left,L)
        b=average(right,r*L)-average(right,L)
        total+=(right-left)*(a*a+a*b+b*b)/3
    assert total>=0
    return total


def positive_box_L2_guards():
    out=[]
    r=math.e
    for side in (1.,1/64):
        estimates=[]
        for resolution in (16,32,64):
            steps=40*resolution
            total=0.
            for i in range(steps+1):
                u=-20+i/resolution
                # Divide by ||f||_2^2=1/side. Spatial integral is exact
                # piecewise-linear-square integration up to floating arithmetic.
                value=side*positive_box_spatial_difference(side,side*math.exp(u),r)
                total+=(1 if i in (0,steps) else 4 if i%2 else 2)*value
            value=total/(3*resolution)
            assert value>0
            estimates.append({'log_resolution':resolution,'energy_over_L2_squared_estimate':format(value,'.17g')})
        out.append({'dimension':1,'source':'(1/side) indicator centered interval of side side',
                    'side':format(side,'.17g'),'source_mass':'1','source_L2_squared':format(1/side,'.17g'),
                    'log_relative_scale_window':[-20,20],'refinements':estimates,
                    'low_tail_upper':format((r+1)*math.exp(-20),'.17g'),
                    'high_tail_upper':format(2*(1+1/r)*math.exp(-20),'.17g'),
                    'status':'actual positive L1 intersect L2 source; exact spatial cell formula, numerical logscale quadrature; not a spectral plane-wave input'})
    assert abs(float(out[0]['refinements'][-1]['energy_over_L2_squared_estimate'])-
               float(out[1]['refinements'][-1]['energy_over_L2_squared_estimate']))<1e-12
    return out


def main():
    start=time.monotonic()
    with localcontext() as ctx:
        ctx.prec=90
        spectrum=spectral_guards()
        atoms=atom_band_guards()
        spikes=positive_spike_guards()
        capped=capped_atom_guards()
        fullcap=fullscale_capped_atom_guards()
        boxes=positive_box_L2_guards()
        counts={'multiplier_direction_cases':len(spectrum),'atom_radial_band_cases':len(atoms),
                'positive_width_source_band_cases':len(spikes),
                'capped_single_atom_cases':len(capped),'fullscale_capped_single_atom_cases':len(fullcap),
                'actual_positive_box_L2_cases':len(boxes)}
        data={'round':54,'status':'PASS','standard_library_only':True,'counts':counts,
              'total_parameter_cases':sum(counts.values()),'spectral_quadrature_refinements':sum(len(r['refinements']) for r in spectrum),
              'spectral_dimension_phase_groups':[[1,2,4],[8,16,32],[64,128,256]],
              'phase_note':'Named parameter families in one execution, not independent-run claims.',
              'scope':{'spectral':'Numerical multiplier tests, not non-L2 plane-wave inputs. Spectral energy bound requires separate analytic proof.',
                       'quadrature':'3 finite logt Simpson levels generally, 5 for axis/near-axis; displayed analytic omitted-tail bounds do not certify interior quadrature error.',
                       'band_obstruction':'Large squared derivative energy on actual threshold band can occur while positive variation stays bounded; it is not a weak-type lower bound.',
                       'positive_width':'Closed actual L1 spike calculation in dimension one only; extension to high-dimensional positive cubes is a separate a.e/Fatou argument, not numerically enumerated.',
                       'fitting':'No dimension or frequency order fit; no unknown operator constant assigned.'},
              'multiplier_energy':spectrum,'atom_band_energy':atoms,'positive_width_band_energy':spikes,
              'capped_atom_band_energy':capped,'fullscale_capped_atom_band_energy':fullcap,
              'actual_positive_box_L2_energy':boxes}
        p=Path(__file__).with_name('results.json')
        p.write_text(json.dumps(data,sort_keys=True,indent=2)+'\n')
        print('PASS',sum(counts.values()),counts)
        print('Runtime seconds:',round(time.monotonic()-start,3))


if __name__=='__main__':
    main()
