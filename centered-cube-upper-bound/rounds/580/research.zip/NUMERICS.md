# R580 n4 complete reanchoring flow certificate

Frozen input: all 16 Boolean vertices {0,1}^4, each mass 1, lambda=1, band [1,16], original H2=[-rho/2,1+rho/2]^4 with rho=2^(1/4). No n5 run or sampled centers. This is the complete repeated-edge integral, rather than a single counterexample or total-J reading.

## Actual witnesses and complete integration

Write r_k=2^(k/4), a_k=1/r_k-1/2, e_k=-rho/(2r_k), c_(l,k)=(1-r_l/2)/r_k. At x=r_k u, u in Q0, every coordinate captures anchor 0 and actual mass is 2^j where j=count(u_j>a_k). Larger actual filled witnesses have masses 2^l. Thus frozen last-selection is exactly j=k, min u<e_k, and count(u_j>c_(l,k))<l for every l>k. The finite d=1..4 bound uses |S|<=2^d and betaS<=(1-2^(-d/4))^d<=1-2^(-1/4)<1/2, so only singleton high blocks occur. The original H2 is checked throughout.

All old a/e/c thresholds, reanchoring pullbacks 1/r_3-threshold, and both boundary-layer thresholds/pullbacks enter the partition. There are 27 coordinate bins, with 27405 occupancy multisets, each integrated with multiplicity 4!/product(c_i!). Exact endpoint inequalities certify whole-box predicates; no midpoints are used. Boundaries have measure zero. Old-chain occupancy counts are []:23143, [2]:720, [3]:3422, [2,3]:120. Consequently all repeat weight is in those 120 [2,3] boxes, with no omitted repeat level. Every one of four actual new vertices is checked on every repeat box (480 tests). The unweighted test-count split 455 first/25 nonfirst is not a volume ratio.

For each old edge 4->8, every h in T minus S gets mass share 1/4. Reflected new parameter is w_j=u_j when h_j=0, and w_j=1/r_3-u_j when h_j=1. The code checks w in Q0, new level 3 charged, and all q<3 for prior charging.

## Full repeated-edge results

All totals below are per original anchor with Lebesgue du on Q0. JSON stores exact Fraction coefficients in Q(2^(1/4)) and Arb512 balls; decimals here are displays.

| Quantity | Display |
|---|---:|
| Complete repeated-edge weight E | 0.00146586771764741078 |
| New-first weight (share 1/4) | 0.00139348878330529015 |
| New-nonfirst weight (share 1/4) | 0.0000723789343421206259 |
| New-first / E | 0.95062382951015356804 |
| New-nonfirst / E | 0.04937617048984643196 |

Independently, E=12(1/2-a_2)^2(c_(3,2)-a_3)(e_2+1/2), checked exactly against the entire partition sum. First+nonfirst=E has exact residual 0. With the conserved factor Delta/mT=1/2, the old edge weight is 0.0007329338588237053894; new first/nonfirst weights are 0.0006967443916526450765 and 0.00003618946717106031295, each label share 1/8. Conservation again is exact. Global original-anchor totals have symmetry factor 16, recorded separately; the table is not silently multiplied by 16.

## Positive nonfirst whole-box witness

Set t=1/r_3 and c=c_(3,2). The entire open box

    (t-c,1/2) x (a_2,t-a_2) x (a_3,c) x (-1/2,e_2)

has old/new chains [2,3] after reanchoring to h=(1,0,1,0). Its positive exact volume is -37/16-sqrt(2)/4+9*2^(1/4)/16+19*2^(3/4)/16, displayed 0.00000459782332887752709. Endpoint min/max counts certify the whole box, without sampling. This confirms the supplied candidate endpoints independently of the complete integral.

## Boundary and limits

Distinct definitions: delta_radius=1-r_2/r_3, delta_mass=Delta/mT=1/2. The corresponding normalized half-thicknesses are 0.07955179237314272848 and 1/4. Every actual new-label flow lies in both layers, and both exact layer-flow integrals equal E. A newly free coordinate gives normalized margin 1/2-max|w_j| strictly below c_(3,2)-a_3=0.01789966618382645768, itself strictly below both half-thicknesses.

The L03 rational/interval workflow is used. Integral arithmetic error is 0; all geometric signs are certified by Arb512 separating nonzero exact algebraic expressions from zero, with no unresolved comparisons. Ratios are rigorous outward-rounded balls, not ordinary floating comparisons; the printed nonfirst-ratio ball radius is at most 4.74e-62. This does not assert that the skill's generic interval API has been separately validated.

Decision: a new source from T minus S need not be a first charge. The mass-share ledger conserves, and all new anchors satisfy the measured boundary condition. These facts do not establish dissipation or cumulative incoming source-column capacity. This finite n4 certificate does not imply a general dimension bound and does not include root's separate n3 example. No expansion is performed.

## Actual reproduction record

    OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 /Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r580_flow_probe.py --output /tmp/ccu_r580_flow_probe.json

Python 3.12.14; python-flint 0.9.0; SymPy 1.14.0. One process, runtime 0.2133927910035709s; peak RSS 72433664 bytes (120s/500MB cap).

Code SHA256: `138ef9b5e628c80e3b22893bdafb69f6e587b1555f44170e38b1bd1ad8034769`.


## 三维、四维的复现与范围

本包的 cycle_certificate.py 对八源输入作255个子集检查、全连续接收盒的10项严格余量、准确矩阵与Jacobian；cycle_certificate.json 是实际输出。其一般几何论证见 REPORT.tex 和 AUDITS.md。flow_probe.py 与 flow_probe.json 是上面完整四维积分。两份代码保持作者定版字节。

解压后使用同目录脚本名，将上面历史命令的绝对脚本路径替换为 cycle_certificate.py 或 flow_probe.py。两者均接受 --output reproduced.json；不要覆写原记录。REPLAYS.json 保存两次独立重放的比较规则、哈希、版本、命令和实测运行记录。三维只忽略命令与时间；四维另忽略峰值内存，其他所有确定字段均一致。重放同一代码不等于第二算法。

任务索引：n3几何由主代理构造、Sol独审，主代理代码由互补Sol重放；n4完整域代码由数值Sol编写执行，主代理独立重放。计算各一个进程，未启动重型优化或并行扫描。未运行MATLAB、未编译PDF。没有由有限维结果外推一般常数。采用本机L03有理/区间工作流，技能的通用API未验收状态不被改写；只将这些实际运行及直接解析证明作为证据。
