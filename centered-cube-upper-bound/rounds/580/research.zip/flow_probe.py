"""Frozen n4 Boolean actual last-charge handoff flow, complete u partition."""
from fractions import Fraction as Q
from itertools import combinations_with_replacement
from math import factorial,comb
from pathlib import Path
import argparse,json,sys,platform,time,resource,shlex,signal
import sympy as S
import flint
from flint import arb,ctx
ctx.prec=512
parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=Path(__file__).resolve().parent/'flow_probe.json');args=parser.parse_args();START=time.perf_counter()
def timeout(sig,frame):raise TimeoutError('Frozen 120-second cap')
signal.signal(signal.SIGALRM,timeout);signal.alarm(120)
N=4;ZERO=(Q(0),)*4;ONE=(Q(1),Q(0),Q(0),Q(0));ALPHA=(Q(0),Q(1),Q(0),Q(0));A=(arb(2).log()/4).exp();SIGN_COUNT=0;SCACHE={}
def rat(x):return (Q(x),Q(0),Q(0),Q(0))
def add(x,y):return tuple(a+b for a,b in zip(x,y))
def neg(x):return tuple(-a for a in x)
def sub(x,y):return add(x,neg(y))
def scale(x,c):return tuple(a*Q(c) for a in x)
def mul(x,y):
 z=[Q(0)]*4
 for i,a in enumerate(x):
  if not a:continue
  for j,b in enumerate(y):
   if b:z[(i+j)%4]+=a*b*(2 if i+j>=4 else 1)
 return tuple(z)
def power(x,k):
 v=ONE
 for _ in range(k):v=mul(v,x)
 return v
def aq(x):x=Q(x);return arb(x.numerator)/x.denominator
def av(x):return sum((aq(c)*A**i for i,c in enumerate(x)),arb(0))
def sign(x):
 global SIGN_COUNT
 if x==ZERO:return 0
 if x in SCACHE:return SCACHE[x]
 SIGN_COUNT+=1;v=av(x)
 if v>0:s=1
 elif v<0:s=-1
 else:raise AssertionError('Unresolved algebraic sign')
 SCACHE[x]=s;return s
def expr(x):return str(sum(S.Rational(c.numerator,c.denominator)*2**S.Rational(i,4) for i,c in enumerate(x)))
def out(x):return {'basis':'1,2^(1/4),sqrt2,2^(3/4)','exact_coefficients':list(map(str,x)),'expression':expr(x),'Arb512':av(x).str(60)}
r=[power(ALPHA,k) for k in range(5)]
inv=[ONE]+[scale(power(ALPHA,4-k),Q(1,2)) for k in range(1,5)]
for k in range(5):assert mul(r[k],inv[k])==ONE
half=rat(Q(1,2));loQ=neg(half);hiQ=half
ak=[sub(inv[k],half) for k in range(5)]
ek=[neg(scale(mul(ALPHA,inv[k]),Q(1,2))) for k in range(5)]
ck={(k,l):sub(inv[k],scale(mul(r[l],inv[k]),Q(1,2))) for k in range(5) for l in range(k+1,5)}
# Only possible old multi-charge edge is k2 -> k3; all k0..4 tested below.
shift=inv[3]
delta_radius=sub(ONE,mul(r[2],inv[3]));delta_mass=Q(1,2)
tau_radius=scale(delta_radius,Q(1,2));tau_mass=rat(delta_mass/2)
zrad=sub(half,tau_radius);zmass=sub(half,tau_mass)
thresholds=set(ak+ek+list(ck.values())+[zrad,neg(zrad),zmass,neg(zmass)])
# Full pullback of every event threshold for a new bit1 anchor at l3.
endpoints={loQ,hiQ}
for t in thresholds|{sub(shift,t) for t in thresholds}:
 if sign(sub(t,loQ))>0 and sign(sub(hiQ,t))>0:endpoints.add(t)
from functools import cmp_to_key
ends=sorted(endpoints,key=cmp_to_key(lambda x,y:sign(sub(x,y))))
bins=list(zip(ends,ends[1:]));B=len(bins);count_expected=comb(B+3,4)
print(json.dumps({'stage':'exact_partition_frozen','intervals':B,'occupancy_vectors':count_expected}),flush=True)
assert count_expected<=300000
assert all(sign(sub(hi,lo))>0 for lo,hi in bins)
assert sub(ends[-1],ends[0])==ONE
# Scalar high-beta guard: actual subset has q<=2^d, hence beta<=f_d.
b=1/arb(4).sqrt();f1=-(-arb(2).log()/4).expm1();assert f1<b
for d in range(2,5):assert (-(-d*arb(2).log()/4).expm1())**d<f1
T=list(thresholds);tid={x:i for i,x in enumerate(T)}
# gt/lt tables certified on complete open bins, not sampled midpoints.
GT=[[],[]];LT=[[],[]]
for bit in (0,1):
 for lo,hi in bins:
  wl,wh=(lo,hi) if bit==0 else (sub(shift,hi),sub(shift,lo))
  g=[];l=[]
  for t in T:
   if sign(sub(wl,t))>=0:g.append(True)
   elif sign(sub(wh,t))<=0:g.append(False)
   else:raise AssertionError('A transformed threshold crosses a bin')
   if sign(sub(wh,t))<=0:l.append(True)
   elif sign(sub(wl,t))>=0:l.append(False)
   else:raise AssertionError('A transformed threshold crosses a bin')
  GT[bit].append(g);LT[bit].append(l)
def chain(indices,bits):
 charged=[]
 for k in range(5):
  if not any(LT[h][i][tid[ek[k]]] for i,h in zip(indices,bits)):continue
  if sum(GT[h][i][tid[ak[k]]] for i,h in zip(indices,bits))!=k:continue
  if any(sum(GT[h][i][tid[ck[k,l]]] for i,h in zip(indices,bits))>=l for l in range(k+1,5)):continue
  charged.append(k)
 return charged
lengths=[sub(hi,lo) for lo,hi in bins];lp=[[power(x,k) for k in range(5)] for x in lengths]
def cellvol(indices):
 counts={}
 for i in indices:counts[i]=counts.get(i,0)+1
 v=ONE;den=1
 for i,c in counts.items():v=mul(v,lp[i][c]);den*=factorial(c)
 return v,Q(factorial(4),den)
repeat=ZERO;first=ZERO;nonfirst=ZERO;conserved=ZERO;first_cons=ZERO;nonfirst_cons=ZERO;brad=ZERO;bmass=ZERO
seen=0;positive_cells=0;old_chain_counts={};new_chain_counts={};failure=None;boundary_failure=None
for indices in combinations_with_replacement(range(B),4):
 seen+=1;old=chain(indices,(0,0,0,0));old_chain_counts[str(old)]=old_chain_counts.get(str(old),0)+1
 assert all(k in [2,3] for k in old)
 if len(old)<2:continue
 assert old==[2,3];positive_cells+=1
 vc,multiplicity=cellvol(indices);weighted=scale(vc,multiplicity);assert sign(weighted)>0
 freeS=sum(1<<j for j,i in enumerate(indices) if GT[0][i][tid[ak[2]]]);freeT=sum(1<<j for j,i in enumerate(indices) if GT[0][i][tid[ak[3]]])
 assert freeS.bit_count()==2 and freeT.bit_count()==3 and freeS&freeT==freeS
 hlist=[h for h in range(16) if not h&~freeT and h&~freeS]
 assert len(hlist)==4
 nfirst=nnon=nr=nm=0
 for h in hlist:
  bits=tuple((h>>j)&1 for j in range(4))
  for i,bit in zip(indices,bits):
   lo,hi=bins[i];wl,wh=(lo,hi) if bit==0 else (sub(shift,hi),sub(shift,lo))
   assert sign(sub(wl,loQ))>=0 and sign(sub(hiQ,wh))>=0
  new=chain(indices,bits);assert 3 in new
  new_chain_counts[str(new)]=new_chain_counts.get(str(new),0)+1
  isfirst=not any(q<3 for q in new)
  nfirst+=isfirst;nnon+=not isfirst
  rad=any(GT[bit][i][tid[zrad]] or LT[bit][i][tid[neg(zrad)]] for i,bit in zip(indices,bits))
  mass=any(GT[bit][i][tid[zmass]] or LT[bit][i][tid[neg(zmass)]] for i,bit in zip(indices,bits))
  nr+=rad;nm+=mass
  if not isfirst and failure is None:
   failure={'canonical_cell_bins':list(indices),'open_u_box':[[out(e) for e in bins[i]] for i in indices],'new_anchor_h_bits':bits,'old_chain':old,'new_chain':new,'canonical_box_volume':out(vc),'coordinate_permutation_multiplicity':str(multiplicity),'edge_delta_mass':4,'mT':8,'new_anchor_share':'1/4','conserved_new_anchor_share':'1/8','radius_half_layer':rad,'mass_half_layer':mass}
  if (not rad or not mass) and boundary_failure is None:boundary_failure={'indices':indices,'h':bits,'radius':rad,'mass':mass}
 assert nfirst+nnon==4
 repeat=add(repeat,weighted);first=add(first,scale(weighted,Q(nfirst,4)));nonfirst=add(nonfirst,scale(weighted,Q(nnon,4)))
 conserved=add(conserved,scale(weighted,Q(1,2)));first_cons=add(first_cons,scale(weighted,Q(nfirst,8)));nonfirst_cons=add(nonfirst_cons,scale(weighted,Q(nnon,8)))
 brad=add(brad,scale(weighted,Q(nr,4)));bmass=add(bmass,scale(weighted,Q(nm,4)))
assert seen==count_expected and positive_cells>0 and failure is not None
assert add(first,nonfirst)==repeat and add(first_cons,nonfirst_cons)==conserved and conserved==scale(repeat,Q(1,2))
assert sign(nonfirst)>0 and sign(first)>0
# Independent closed expression for total repeat rectangle geometry (same full integral).
c32=ck[2,3];widthStrong=sub(half,ak[2]);widthAdded=sub(c32,ak[3]);widthLow=sub(ek[2],loQ)
closed_repeat=scale(mul(mul(power(widthStrong,2),widthAdded),widthLow),12)
assert closed_repeat==repeat
# Source-first failure on root's explicit positive box, checked without midpoint.
rect=[(sub(shift,c32),half),(ak[2],sub(shift,ak[2])),(ak[3],c32),(loQ,ek[2])]
def rectchain(rect,bits):
 wr=[pair if bit==0 else (sub(shift,pair[1]),sub(shift,pair[0])) for pair,bit in zip(rect,bits)]
 def count_gt(t):return (sum(sign(sub(lo,t))>=0 for lo,hi in wr),sum(sign(sub(hi,t))>0 for lo,hi in wr))
 def outside(t):return (any(sign(sub(hi,t))<=0 for lo,hi in wr),any(sign(sub(lo,t))<0 for lo,hi in wr))
 outlevels=[]
 for k in range(5):
  omin,omax=outside(ek[k]);amin,amax=count_gt(ak[k]);later=[(l,count_gt(ck[k,l])) for l in range(k+1,5)]
  if omin and amin==amax==k and all(cmax<l for l,(cmin,cmax) in later):outlevels.append(k)
  else:assert not omax or k<amin or k>amax or any(cmin>=l for l,(cmin,cmax) in later)
 return outlevels
rectvolume=ONE
for lo,hi in rect:assert sign(sub(hi,lo))>0;rectvolume=mul(rectvolume,sub(hi,lo))
assert rectchain(rect,(0,0,0,0))==[2,3] and rectchain(rect,(1,0,1,0))==[2,3]
assert brad==repeat and bmass==repeat
# Maximum margin bound supplied by the newly free coordinate, valid on all old edges.
assert sign(sub(tau_radius,widthAdded))>0 and sign(sub(tau_mass,widthAdded))>0
result={'status':'PASS_COMPLETE_N4_ACTUAL_REANCHOR_FIRST_AND_BOUNDARY_FLOW','model':{'n':4,'vertices':'all16 vertices {0,1}^4, each actual mass1','lambda':1,'band':[1,16],'original_H2':'[-rho/2,1+rho/2]^4, rho=2^(1/4)','old_anchor':[0,0,0,0],'all_original_last_charge_levels_tested':[0,1,2,3,4],'only_possible_charge_levels_observed':[2,3],'r_k':'2^(k/4), k0..4; charge conditions exactly frozen formulas','new_anchor_reflection':'w_j=u_j if h_j=0; w_j=1/r_l-u_j if h_j=1','flow_measure':'For each old-anchor u and consecutive old edge, unit edge weight split by m_h/Delta=1/4 to every actual h in T minus S. Conserved version uses extra Delta/mT=1/2, so each h has1/8.','dimension_expansion':False},'partition':{'field':'Q(2^(1/4)), exact Fraction coefficients, alpha^4=2','interval_count':B,'all_occupancy_vectors':seen,'positive_repeat_occupancy_vectors':positive_cells,'coordinate_permutations':'multinomial4!/product(count!), exact; new-label sum is invariant under the same permutation','all_endpoint_expressions':[expr(e) for e in ends],'old_chain_occupancy_counts':old_chain_counts,'new_chain_counts_on_positive_old_cells':new_chain_counts,'whole_bin_gt_lt_certified':True,'no_sampled_centers_or_midpoints':True},'repeat_total_weight_per_old_anchor':out(repeat),'new_first_weight_mh_over_Delta':out(first),'new_nonfirst_weight_mh_over_Delta':out(nonfirst),'new_first_fraction_Arb':(av(first)/av(repeat)).str(60),'new_nonfirst_fraction_Arb':(av(nonfirst)/av(repeat)).str(60),'conserved_old_edge_weight_Delta_over_mT':out(conserved),'conserved_new_first_weight':out(first_cons),'conserved_new_nonfirst_weight':out(nonfirst_cons),'weight_conservation_exact_residual':'0','all_original_anchors_symmetry_factor':16,'global_conserved_old_flow_by_symmetry':out(scale(conserved,16)),'delta_radius':out(delta_radius),'delta_mass_exact':'1/2','radius_half_layer_thickness_normalized':out(tau_radius),'mass_half_layer_thickness_normalized':out(tau_mass),'radius_layer_flow_weight':out(brad),'mass_layer_flow_weight':out(bmass),'all_flow_within_both_layers':boundary_failure is None,'actual_normalized_margin_uniform_upper_from_new_coordinate':out(widthAdded),'first_positive_nonfirst_partition_cell':failure,'explicit_root_box_certificate':{'open_u_box':[[out(e) for e in pair] for pair in rect],'new_anchor_h_bits':[1,0,1,0],'old_chain':[2,3],'new_chain':[2,3],'positive_box_volume':out(rectvolume),'new_anchor_not_first':True,'endpoints_verified_not_float_hint':True},'independent_repeat_formula':{'expression':'12*(1/2-a2)^2*(c32-a3)*(e2+1/2)','matches_complete_partition_exactly':True},'finite_original_high_beta_guard':{'f1_Arb':f1.str(60),'b_Arb':b.str(60),'all_d2_3_4_below_f1':True,'actual_subset_coverage':'|S|<=2^d gives betaS<=(1-2^(-d/4))^d<=f1<b for d1..4, hence all original blocks singleton'},'exact_integral_arithmetic_error':'0','precision_bits':512,'certified_nonzero_sign_decisions':SIGN_COUNT,'comparison_unresolved':0,'interpreter':sys.executable,'python_version':platform.python_version(),'python_flint_version':flint.__version__,'sympy_version':S.__version__,'command':'OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 '+shlex.join([sys.executable]+sys.argv),'runtime_seconds':time.perf_counter()-START,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'processes':1,'scope':'Only frozen n4 full-u actual last-cell handoff experiment; nonfirst positive disproves an always-first shortcut, not a general flow-capacity/dissipation theorem. Delta/mT conservation is only the measured edge ledger, not unweighted source-column capacity.'}
args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');signal.alarm(0)
print(json.dumps({k:result[k] for k in ['status','new_first_fraction_Arb','new_nonfirst_fraction_Arb','all_flow_within_both_layers','runtime_seconds','peak_rss_bytes']},indent=2))
for k in ['repeat_total_weight_per_old_anchor','new_first_weight_mh_over_Delta','new_nonfirst_weight_mh_over_Delta','conserved_old_edge_weight_Delta_over_mT']:print(k,result[k]['Arb512'])
