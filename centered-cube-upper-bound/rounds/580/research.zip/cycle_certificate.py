"""Exact finite source/Markov checks and Arb bounds for an entire 3-D receiver box."""
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import argparse,json,time,sys,platform,hashlib
import flint,sympy as S
from flint import arb,ctx
ctx.prec=256
ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));args=ap.parse_args();start=time.perf_counter()
def ar(q):q=F(q);return arb(q.numerator)/q.denominator
def st(v):return v.str(60)
a=F(9,10);eps=F(1,100);z=list(product([-F(1,2),F(1,2)],[-F(1,2),F(1,2)],[-a,a]));assert len(z)==8
r={k:arb(k)**(arb(1)/3) for k in range(1,9)};b=1/arb(3).sqrt();rho=r[2];s=r[4]/2;delta=1-s
counts={'singleton_high':0,'nonsingle_low':0,'empty_nonsingle':0}
for mask in range(1,256):
 ids=[i for i in range(8) if mask>>i&1];k=len(ids);beta=arb(1);empty=False
 for j in range(3):
  d=max(z[i][j] for i in ids)-min(z[i][j] for i in ids)
  width=1-ar(d)/r[k]
  if width<0:beta=arb(0);empty=True;break
  assert width>0
  beta*=width
 if k==1:assert beta==1 and beta>=b;counts['singleton_high']+=1
 else:
  assert beta<ar(F(1,2)) and beta<b;counts['nonsingle_low']+=1
  if empty:counts['empty_nonsingle']+=1
assert counts['singleton_high']==8 and counts['nonsingle_low']==247
# Guard every point of E, every original anchor, and its same-plane four-source predecessor.
# Max/Min formulas use coordinate symmetry, not point sampling.
y12abs=delta/2+s*ar(eps)
y3min=delta*ar(a)-s*ar(eps);y3max=delta*ar(a)+s*ar(eps)
gap=ar(a)-rho/2
margins={
 'rho_gt_one_for_exact_H2_first_two_axes':rho-1,
 'third_H2_components_disjoint':gap,
 'E_inside_T8_receiver':1-ar(a+eps),
 'E_outside_original_H2':gap-ar(eps),
 'prior_y_first_two_coordinates_capture_both_values':s-ar(F(1,2))-y12abs,
 'prior_y_captures_own_third_plane':s*(1-ar(a+eps)),
 'prior_y_excludes_other_plane_even_at_r8':ar(a)+y3min-1,
 'prior_y_outside_H2':gap-y3max,
 'prior_y_third_sign_fixed':y3min,
 'all_witness_masses_below_top_threshold':ar(F(32,3)-8)
}
for key,value in margins.items():assert value>0,(key,st(value))
# Whole labels, equal weights; destination state keeps x and T fixed, resets u_j=(x-z_j)/2.
P=[[F(1,4) if z[i][2]!=z[j][2] else F(0) for j in range(8)] for i in range(8)]
assert all(sum(row)==1 for row in P)
assert all(sum(P[i][j] for i in range(8))==1 for j in range(8))
M=S.Matrix([[S.Rational(p.numerator,p.denominator) for p in row] for row in P]);q=S.symbols('q');poly=S.expand(M.charpoly(q).as_expr());assert S.expand(poly-q**6*(q-1)*(q+1))==0
assert M*S.ones(8,1)==S.ones(8,1)
assert S.ones(1,8)*M==S.ones(1,8)
volume=(2*eps)**3;assert volume==F(1,125000)
# Each original anchor's image of E in normalized u has volume |E|/r8^3=|E|/8.
account={'receiver_E_volume_exact':str(volume),'W_exact':'8','source_parameter_E_volume_each_exact':str(volume/8),'all_anchors_current_repeat_cost_exact':str(volume),'new_source_first_fraction_exact':'0','new_source_nonfirst_fraction_exact':'1','delta_mass_exact':'1/2','weighted_repeat_cost_exact':str(volume/2),'uniform_stationary_weights_exact':['1/8']*8,'current_repeat_cost_over_W_exact':str(volume/8)}
result={'status':'PASS_COMPLETE_255_SUBSETS_AND_CONTINUUM_RECEIVER_BOX_GUARDS','input':{'n':3,'lambda':1,'L':1,'U':16,'W':8,'sources_exact':[[str(x) for x in p] for p in z],'receiver_E':'[-1/100,1/100]^3','model_scope':'Actual full mass band; E is a positive-volume subregion of the complete Rlo, not a quadrature or a replacement of its whole measure.'},'counts':counts,'all_nonsingle_beta_lt_half_certified':True,'uniform_nonsingle_beta_gap_lower_Arb':st(b-ar(F(1,2))),'rho_Arb':st(rho),'s_r4_over_r8_Arb':st(s),'delta_radius_Arb':st(delta),'continuum_geometric_margins_Arb':{k:st(v) for k,v in margins.items()},'account':account,'P_exact':[[str(x) for x in row] for row in P],'characteristic_polynomial':str(poly),'spectral_radius_exact':'1','stationary_row_and_column_checks':True,'transition_scope':'Keep the same current receiver x in E and T=all8. At each anchor i use its own u_i=(x-z_i)/2 and immediate predecessor S_i=its third-coordinate plane. Send to T minus S_i with true mass probabilities 1/4. Recompute u_j at destination. Not a Markov claim holding the same u across anchors.','proof_scope':'Arb certifies margins uniformly on the entire rational box E. Filled-product labels and band/H2 argument identify consecutive actual masses4 and8; all high-beta subsets enumerated. Matrix exact rational/SymPy. This refutes new-source-is-first and a strictly positive leakage or bounded positive per-step potential drift for THIS unchanged-state redistribution. It does not refute other joint potentials, collapse/payment of cyclic classes, full J bounds or the general maximal target.','precision_bits':256,'interpreter':sys.executable,'python_version':platform.python_version(),'python_flint_version':flint.__version__,'sympy_version':S.__version__,'command':' '.join([sys.executable]+sys.argv),'runtime_seconds':time.perf_counter()-start}
args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'status':result['status'],'counts':counts,'margins':result['continuum_geometric_margins_Arb'],'account':account,'charpoly':str(poly),'runtime_seconds':result['runtime_seconds']},ensure_ascii=False,indent=2))
