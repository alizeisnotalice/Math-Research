#!/usr/bin/env python3
"""R162 archive and finite-numeric replay; does not certify the general theorem."""
import argparse,ast,hashlib,json,re,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--output',required=True,type=Path);ap.add_argument('--vendor');ap.add_argument('--verify-existing',action='store_true');a=ap.parse_args()
m=json.loads((root/'manifest.json').read_text())
for name,digest in m['sha256'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
for name in ['numeric.py','reproduce.py']:ast.parse((root/name).read_text())
stack=[]
for kind,name in re.findall(r'\\(begin|end)\{([^}]+)\}',(root/'research.tex').read_text()):
 if kind=='begin':stack.append(name)
 else:assert stack.pop()==name
assert not stack
if not a.verify_existing:
 assert not a.output.exists(),'Use a new output path'
 cmd=[sys.executable,str(root/'numeric.py'),'--output',str(a.output)]
 if a.vendor:cmd+=['--vendor',a.vendor]
 subprocess.run(cmd,check=True)
x=json.loads((root/'numeric.json').read_text());y=json.loads(a.output.read_text())
for key,name in [('source_sha256','numeric.py'),('contract_sha256','task_contract.md')]:
 assert y[key]==hashlib.sha256((root/name).read_bytes()).hexdigest(),key

def compare(x,y,path=''):
 if isinstance(x,dict):
  assert x.keys()==y.keys(),path
  for k in x:
   if path=='' and k=='runtime':continue
   compare(x[k],y[k],path+'/'+k)
 elif isinstance(x,list):
  assert len(x)==len(y),path
  for i,(u,v) in enumerate(zip(x,y)):compare(u,v,path+'/'+str(i))
 elif isinstance(x,float):assert abs(x-y)<=1e-10*max(1,abs(x)),path
 else:assert x==y,path
compare(x,y)
print('PASS: hashes, Python syntax, TeX environment balance, finite mathematical-field comparison. Existing-output mode runs no numerical job. Tolerance is not an integration error certificate.')
