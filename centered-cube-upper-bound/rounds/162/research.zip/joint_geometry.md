# R162：共同 alpha 平方余量门的准确外价与未付低核尾

状态：有限检查点。本文将 R136 OS11、R144 C5 的已有平方余量工具接到同一个实际接收付款合同，得到来源相关阈值的完整付款证书。它不构成新的中间 soft 联合空间估计；一般剩余交通仍未闭合。未使用数值作为证明，未变更原 alpha、来源或负项。

## 1. 原量与依赖范围

固定任意原合法行、原有限正来源 nu 和实际时间 t。全部 soft、尺度、history、good/bad 身份及核值可以依实际接收 x；不先冻结选择器。保留
\[
 d\Pi_t(u)=1_{Z_{j,t}}(u)w_t(u)\,d\nu(u)/e_t,
 \quad \delta(v,u)=(k_t(v)-k_t(u))_+,
 \quad A_v=T\Delta_v.
 \tag{JG1}
\]
取实际 terminal bad 域的任意可测子域 \(\mathcal B_v\subset D_0\subset D_g\cap Z_{j,t}\)。其他原正门可留在原交通中，估计时只按不超过 1 放松。不能加回非 bad 来源后使用下面的余额。

用不同记号区分原参数 D 与 good 自身剩余：
\[
 d_v=(1-DK_{0,v}/A_v)_+,\qquad
 x_v=\alpha J_v/A_v,\qquad \rho_v=(d_v-x_v)_+.
 \tag{JG2}
\]
主计算分支为 \(D>0,A_v>0,e_t>0,Q_J>0\)。原中间 soft 的 J、K0、wt 在有限来源点严格正；非零有限 nu 给 QJ>0。A_v=0、e_t=0 等沿原零交通约定，不计算商；d_v=0 时 rho_v=0。D=0 若超出原正参数合同，不属于本付款证书，不能用以下除 D 的式子处理。无限积分的截断保持原 nu、e、alpha、核和所有门固定，只截断非负积分，不重算归一化量。

原 alpha producer 给
\[
 \alpha Q_J=Dq-\int U\,d\nu
 \ge D\int_{D_g}K_0\,d\nu.
 \tag{JG3}
\]
这里用 q≥∫K0、U=0 于 Dg、其余来源 U≤DK0。原共同 alpha 未按 v 或 t 优化。

历史定位已经实际阅读：R136 research.zip 中 ordered_score_capacity.md 的 OS11–14 已证明平方余量及指出外费未付；R144 research.zip 中 capacity.md 的 C1–C6 已给完全相同核比与平方帽，C10–C12 已支付固定阈值高核支。本稿不把这些代数重新登记为新结果。

## 2. 保留 good 自身消费的容量式

令 B=∫Dg K0 dnu。JG3 给 B≤alpha QJ/D。由
\[
 x(d-x)_+\le d^2/4\quad (x,d\ge0)
\]
得到
\[
 B\rho_v\le {Q_J\over4D J_v}
                 {(A_v-DK_{0,v})_+^2\over A_v},
 \tag{JG4}
\]
并且，保留原三核责任 \(\chi_{J,v}=J_v/(3Q_v)\)，
\[
 B\rho_v\chi_{J,v}
 \le {Q_J(A_v-DK_{0,v})_+^2\over12D A_vQ_v}.
 \tag{JG5}
\]
这比先删除 good 自身 DK0 消费保留了平方因子；但 JG4–5 本身没有实际接收空间预算，且正是已有平方工具的同量纲表达。alpha=0 时 JG3 给 B=0，实际 bad 后验质量为零（原 K0 严格正），不通过除 alpha 处理。

## 3. 来源相关阈值：同一旧价格的更大可付门

只在 δ>0 的实际 pair 上定义
\[
 c_t(v,u)={D K_{0,u}J_v e_t\over Q_J A_v w_t(u)\delta(v,u)}.
 \tag{JG6}
\]
对任何固定实际 v 和实际 pair 子域 F，有
\[
 \int_{\mathcal B_v\cap F}c_t(v,u)\delta(v,u)d\Pi_t(u)
 ={D J_v\over Q_J A_v}
      \int_{\mathcal B_v\cap F}K_{0,u}d\nu(u)
 \le x_v.
 \tag{JG7}
\]
这是同一 alpha 的余额；不同 v 的右端不作为独立容量相加。最后只对所得统一数值帽按原概率 Pi(v) 平均。

给定任意预先常数 N>0，令
\[
 G_N(v,u)=\{c_t(v,u)\ge N d_v^2\}.
\]
当 d_v>0，JG7 与 JG2 给
\[
 \rho_v\int_{\mathcal B_v}\delta\,1_{G_N}d\Pi_t(u)
 \le {\rho_vx_v\over Nd_v^2}\le {1\over4N}.
 \tag{JG8}
\]
当 d_v=0，左边直接为零，不求 0/0。等号归入 G_N；δ=0 先删除零交通。加入 χJ≤1、原 good、FA 等正门仍成立。于是 good 来源按实际 Pi(v) 平均后的完整 pair 系数≤1/(4N)。没有替换 Pi 为共同 mu，因此没有 eta 损失、eta 下界或来源独立假设。

JG8 也可直接由 R144 C5 对每个固定 v 取其允许的、与积分变量 u 无关的阈值 N d_v² 得到。因此它是旧工具的阈值接合，不是新的共同几何机制。

取与 R144 完全相同的
\[
 N=\eta_n={4(n+1)^2\over3n}.
 \tag{JG9}
\]
新门包含旧门 {c≥eta_n}，多覆盖的准确差集为
\[
 \{d_v>0,\ \eta_n d_v^2\le c_t(v,u)<\eta_n\}.
 \tag{JG10}
\]
这里只证明集合包含和估计；未认证这个差集在原 FULL 压力输入上非空或贡献显著。不能用自由标量数值代替原几何实现。

## 4. 原 hard、时间、唯一 j 与接收外价

付款仅用于原合法 hard 接收域：原 a_omega 资格、terminal good/bad、原窗口和唯一 j 指示完整保留，先剔除此前其他已付正支。准确继承域 G_leg 仍须有原 Hhat<Lplus、C_J≤3、v∈S_g、u∈D0，以及原 Psi、FA、hard、history 和窗口资格；本稿不扩大到已丢失这些资格的松弛域。对本轮实际 J 责任支，χJ只作为≤1的正门保留，不把三核 good 门改写成单 J good 门。

先在实际 x 使用原
\[
 q(x)^{-1}\int h_{R_{scale}}(x-z)a_\omega(x,y,z)d\nu(z)
 \le16/3.
\]
JG8 的来源消尽帽与外 hard 来源 z 无关；依赖 z 的其他正门只在取得上界时删除。原所有非空时间窗包含于共同 [a,b]，因为 tau_j=a/c_j≥a，原上端≤bc_j≤b；所以时间价≤log(b/a)≤log2。来源与整窗帽形成后才消去唯一 j，然后支付原实际 s,L 的共同接收包络
\[
 \int\sup_{s,L}P_{s,L}(x-y)dx\le3(2n+3)D_n,
 \qquad D_n\le3\sqrt n.
 \tag{JG11}
\]
以上恰为 R144 C11–C12 所调用的 JT13–14 同域合同。保留原外 beta，不以 nu 代 beta；原外标签聚合仍为 Wbeta。由外 2Lambda、hard16/3、JG8、时间和接收包络，准确有
\[
 \begin{aligned}
 2\Lambda P_{G_N}^{leg,J}
 &\le {8\Lambda\log2\,(2n+3)D_n\over N}W_\beta,\\
 2\Lambda P_{G_{\eta_n}}^{leg,J}
 &\le {6\Lambda n\log2\,(2n+3)D_n\over(n+1)^2}W_\beta\\
 &\le36\Lambda\log2\sqrt nW_\beta
 <25\Lambda\sqrt nW_\beta.
 \end{aligned}
 \tag{JG12}
\]
不把单位时间帽直接当作外费用；不重复领取 hard16/3。此价格对实际自适应接收参数成立，未冻结参数或漏付选择器。

旧固定门与 JG10 差集可由 JG12 **一份替换证书**覆盖：账上将旧 fixed-c 高支证书换成 G_eta_n 的证书。若保留旧证书不替换而另给差集记费用，则不能声称该另记项免费。本稿未使其他已付支、futurebad、删除项或负项增加覆盖。

## 5. 一般中间 soft 剩余的唯一具体障碍

正剩余 d_v>0 中，严格补集恰为
\[
 K_{0,u}J_v
 <{\eta_n d_v^2 Q_JA_v\over D e_t}
       w_t(u)\delta(v,u).
 \tag{JG13}
\]
它同时保留原 good/bad 的真实三核似然夹层
\[
 {K\over3}H_u{J_u\over w_g(u)}<p
 \le {K\over3}H_v{J_v\over w_g(v)},
 \quad H_v={K_{1,v}+K_{2,v}+J_v\over J_v}.
 \tag{JG14}
\]
不能在这里删除 H_v、H_u 后使用单 J 的 good/bad 门。也不能从低核质量推低后验质量：JG7 控制 ∫cδPi，而原交通用 ∫δPi；JG13 恰在两者转换系数很小的区域。

更明确地，对 fixed v，未付坏端为
\[
 {1\over e_t}\int_{\mathcal B_v}
 \delta(v,u)w_t(u)
 1_{\{K_{0,u}/[w_t(u)\delta(v,u)]<\kappa_v\}}d\nu(u),
 \quad
 \kappa_v={\eta_n d_v^2Q_JA_v\over D J_ve_t}.
 \tag{JG15}
\]
JG15 不是新能量或已付预算，只明确还须估计的低 K0 后验尾。共同 alpha 只控制其中的 K0 加权质量；JG14 才提供同一接收点的另一几何信息。当前未证明两者交叠经实际 p dx、rho_v chiJ_v Pi(v)、完整 dt/t 与原 beta/history 聚合有根阶上界。

其原外费用必须仍写成
\[
 2\Lambda\mathbb E\sum_{V,j}\int d\beta_V(y)
 \int {dt\over t}\int dx\,{p_x\over q(x)}
 \int d\nu(z)\,h_{R_{scale}}(x-z)a_\omega
 \left[\iint \chi_{orig}\rho_v\chi_{J,v}\delta(v,u)
 1_{\{c_t<\eta_nd_v^2\}}d\Pi_t(v)d\Pi_t(u)\right].
 \tag{JG16}
\]
内层 chi_orig 保留原 good、bad、history、唯一 j 及所有 z 依赖门（上式各积分依从左至右的作用域，z 的积分涵盖后面的 pair 积分）。JG16 尚无新的根阶或 epsilon-X 上界。它不是本轮已支付成果。

当前能决定下一轮的切口是：在 JG13 的低 K0/wt score 尾上，用 JG14 的实际双来源似然约束与 p(x-y) 同点估计，而不能分别最坏化来源位置和时间，或将固定参数 small-ball 概率直接当自适应接收积分。辅助 small-ball 的选择器及远交叉费用也不由本稿支付。

有限结论：已有平方容量可将旧高核付款门精确扩大为 c≥eta_n d_v²，完整费用仍为25Lambda sqrt(n) Wbeta（替换旧证书）。这项优化未证明一般中间 soft 的联合空间增益；严格补集 JG13–16 仍是本轮未付量。到此停止，不扩展新的特殊来源模型。
