# R162：真实核的成对近交叉小区间工具及其接收选择费用

筛查结论：全 good/bad 门不是一个小区间事件，不能据此声称无条件小球付款。可以证明一个对全部中间 soft 有效、带明确几何条件的近交叉界：若两源在 \(m\) 个坐标上从两侧跨过整个接收 core，则真实对数似然对比在长度 \(\ell\) 的任意区间中的概率至多
\[
\boxed{\min\{1,\;4(1+2\ell)/\sqrt{m+1}\}.}
\]
下面自证这个结论，不调用 Gaussian、logconcave 或外部小球定理。另给远交叉的显式条件指数界，并列出合法的 \((s,L)\) 网格费用；这些费用尚不足以单独支付原全部交通。

## 1. 准确的两个对数似然门

全部对象沿本轮合同。固定合法 \(s,L,y,v,u\) 及终端 \(g\)，令
\[
p(x)=P_{s,L}(x-y),\quad L_t(x)=J_t(x)/w_g(t),\quad
H_t(x)=(K_{1,t}+K_{2,t}+J_t)/J_t,\qquad t=v,u.
\]
这里 \(H_t\) 是三个乘积核的**和**除以 \(J_t\)，不把它伪装成乘积。\(K>0\) 保持原值，定义
\[
A_t(x)=\log\frac{(K/3)L_t(x)}{p(x)}.
\]
在原 \(0<s<1\) 域，\(p,J_t\) 正，所以对数有定义。准确 good/bad 门给
\[
A_u< -\log H_u,\qquad A_v\ge-\log H_v.
\tag{1}
\]
若另外保留实际门 \(H_v\le1+\epsilon\)，\(\epsilon\ge0\)，由于 \(H_u\ge1\)，可放松为
\[
A_u<0,\qquad A_v\ge-\eta,\qquad \eta:=\log(1+\epsilon).
\tag{2}
\]
这只强制对比统计量
\[
D_g(x):=A_v-A_u
=Z(x)+c_g,
\]
\[
Z(x)=\sum_i\log\frac{\varphi((x_i-v_i)/b)}{\varphi((x_i-u_i)/b)},
\qquad c_g=\log\frac{w_g(u)}{w_g(v)}
\tag{3}
\]
满足 \(D_g> -\eta\)，**没有强制上界**。因此，对给定 \(h\ge0\)，只能把门分为
\[
\mathcal N_h=\{\text{原 pair 门},\ H_v\le1+\epsilon,\ D_g\le h\},
\qquad
\mathcal F_h=\{\text{原 pair 门},\ H_v\le1+\epsilon,\ D_g>h\}.
\]
近交叉支满足 \(D_g\in(-\eta,h]\)，远交叉支必须另付。所有 \(w_g\) 都是终端权；本文件没有将它替换为当前时间权 \(w_z\)。

## 2. 一个直接可核的两侧跨 core 条件

称坐标 \(i\) 为 crossing coordinate，如果
\[
v_i\le y_i-b,\quad u_i\ge y_i+b,
\qquad\text{或者反向。}
\tag{4}
\]
令这种坐标数为 \(m\)。这是量化源位置条件，不将它与原 score 差 \((k_v-k_u)_+\) 混同。

原核具有下列初等性质：
\[
\varphi(1/2)=\int_0^1r(1-e^{-1/r})dr>1/4,
\quad \|p_s\|_\infty\le1,
\quad -\partial_t\log\varphi(t)\ge1\quad(t\ge1/2).
\tag{5}
\]
最后一个式子来自尾表示
\(\varphi(t)=\int_0^1r(1-e^{-1/r})e^{-(t-1/2)/r}dr\)：负对数导数是 \(1/r\) 的正加权平均。

在 crossing coordinate 的接收 core \([y_i-L/2,y_i+L/2]\) 上，两个源距离均至少 \(b/2\)。故
\[
Z_i(x_i)=\log\frac{\varphi((x_i-v_i)/b)}{\varphi((x_i-u_i)/b)}
\]
单调，且 \(|Z_i'|\ge2/b\)。接收 core 两端的 quarter 区间
\[
I_i^-=[y_i-L/2,y_i-L/4],\qquad
I_i^+=[y_i+L/4,y_i+L/2]
\]
在 \(p\,dx\) 的第 \(i\) 个坐标边缘下各有概率至少 \(1/16\)：归一化 core 内
\((1-s)+s\varphi\ge\varphi(1/2)>1/4\)，quarter 长度是归一化长度 \(1/4\)。这对全部 \(0\le s\le1\) 有效。

两端 quarter 的距离至少 \(L/2\)，所以对应的 \(Z_i\) 值集合之间有有序间隙至少
\[
(2/b)(L/2)=L/b\ge1/2.
\tag{6}
\]
方向相反时只交换高、低值集合。此后不需要全空间单调性。

## 3. 自足的 Bernoulli 分解与区间界

从每个 crossing coordinate 的低值、高值集合中各抽出恰好 \(1/16\) 的概率质量。于是其 \(Z_i\) 的分布可以表示为：以概率 \(1/8\) 激活；激活后用一个公平 Bernoulli 变量选择一个低值或高值；其余概率使用剩余分布。低、高抽样值可先同时独立抽出，再用公平币选择；任意这样的两值之差都至少 \(1/2\)。各坐标的这一构造可独立进行，因为在固定接收核 \(p\) 下接收坐标独立。没有要求源测度独立。

条件于激活集合、所有预抽样的低/高值和剩余坐标后，随机性仅是 \(k\) 个公平币。若一个区间长度严格小于 \(1/2\)，使和落入该区间的子集构成 antichain：一个真包含关系会让和至少增加 \(1/2\)。

该 antichain 的大小至多 \(\binom{k}{\lfloor k/2\rfloor}\)，可直接证明：随机排列给出一条均匀随机最大子集链，antichain 与每条链最多交一次；故
\(\sum_{S\in\mathcal A}\binom{k}{|S|}^{-1}\le1\)，再用最大二项式系数即可。又
\[
\frac{\binom{k}{\lfloor k/2\rfloor}}{2^k}
\le\sqrt{\frac2{k+1}}.
\tag{7}
\]
例如偶数 \(k=2r\) 时，中心概率等于
\(\prod_{j=1}^r(1-1/(2j))\le e^{-(1/2)\sum_{j=1}^r1/j}\le(r+1)^{-1/2}\)；奇数由相邻偶数式得到。\(k=0\) 时右边大于 1，也合法。

激活数 \(N\sim\mathrm{Bin}(m,1/8)\)。由 Cauchy，
\[
\mathbb E\sqrt{\frac2{N+1}}
\le\sqrt{2\mathbb E\frac1{N+1}},
\qquad
\mathbb E\frac1{N+1}
=\frac8{m+1}\{1-(7/8)^{m+1}\}\le\frac8{m+1}.
\]
于是，长度小于 \(1/2\) 的任意区间概率至多 \(4/\sqrt{m+1}\)。把长度为 \(\ell\) 的区间覆盖为 \(\lfloor2\ell\rfloor+1\) 个长度小于 \(1/2\) 的区间，得到
\[
\boxed{\quad
\int_{\{D_g\in I\}}P_{s,L}(x-y)dx
\le\min\left\{1,\frac{4(\lfloor2|I|\rfloor+1)}{\sqrt{m+1}}\right\}
\le\min\left\{1,\frac{4(1+2|I|)}{\sqrt{m+1}}\right\}.
\quad} \tag{8}
\]
任意源归一化常数 \(c_g\) 只平移区间，不影响这个固定参数估计。若 \(m=0\)，本式只给平凡帽 1。

特别地，固定参数的近交叉支满足
\[
\boxed{\quad
\int_{\mathcal N_h}p(x)dx
\le\min\left\{1,\frac{4[1+2(h+\log(1+\epsilon))]}{\sqrt{m+1}}\right\}.
\quad} \tag{9}
\]
没有删除 \(H_v\) 门，也没有声称 \(\mathcal F_h\) 是空集。

## 4. 单坐标细式及一个可实际计算的远交叉条件界

如果至少一个 crossing coordinate 存在，其两个源的 tail-to-tail bridge 包含 \([y_i-b/2,y_i+b/2]\)。在该 bridge 上 \(|Z_i'|\ge2/b\)，而接收坐标密度至多 \(1/L\le2/b\)。条件于其余坐标，区间长 \(\ell\) 的原像概率至多 \(\ell\)。bridge 外的接收概率至多 \(s\kappa\)，其中
\(\kappa=1-\int_{-1/2}^{1/2}\varphi\)。所以另有固定参数界
\[
\Pr_p(D_g\in I)\le\min\{1,|I|+s\kappa\}.
\tag{10}
\]
这项不含 \(m^{-1/2}\) 增益，不向全 selector 免费延伸。

远交叉还可用一个完全显式的源中心条件支付，虽然该条件并非普遍满足。先核原核的全局 \(4\)-Lipschitz 对数界：core 内 \(\varphi\ge\varphi(1/2)>1/4\)，而 \(\varphi'(t)=w(t+1/2)-w(t-1/2)\) 的绝对值至多 1；tail 内负对数导数是 \(1/r\) 的倾斜均值，随 tail 位移非增（导数为负方差），其端点值不超过 \(1/\varphi(1/2)<4\)。故该全局界成立，并给
\[
|Z(x)-Z(y)|\le8\sum_i|x_i-y_i|/b.
\tag{11}
\]
若 \(X\sim p_s\)，对 \(0\le a<1\)，由 \(\varphi=h*w\)、三角不等式及 \(U\sim h,W\sim w\)，
\[
\mathbb E e^{a|X|}
\le e^{a/2}\left[(1-s)+\frac{s}{1-a}\right].
\tag{12}
\]
确实 \(\mathbb E e^{a|W|}=\int_0^1 2r/(1-ar)dr\le(1-a)^{-1}\)。独立乘积、(11)、Markov 因而给任意 \(0<t<1/8\) 的明确上界
\[
\Pr_p(D_g>h)
\le\exp\left[-t(h-D_g(y))+4tn
+n\log\left(1+\frac{8st}{1-8t}\right)\right].
\tag{13}
\]
这里以 \(L/b\le1\) 放松了矩母函数。取具体 \(t=1/16\)，不留下未估计的变分泛函：
\[
\boxed{\quad
\Pr_p(D_g>h)\le
\min\{1,\exp[-(h-D_g(y))/16+n(1/4+\log(1+s))]\}.
\quad} \tag{14}
\]
其中 \(D_g(y)\) 直接由原 \(\varphi\) 与终端 \(w_g\) 计算。如果
\(D_g(y)\le h-16n(1/4+\log(1+s)+\tau)\)，则远交叉概率至多 \(e^{-n\tau}\)。该条件失败时保留帽 1，不宣称远交叉已付。将 (9)、(14) 相加是一个对所有中间 \(s\) 合法的条件 pair 界。

## 5. 接收 selector 和终端权变化的准确费用

固定 pair 概率 (8) 不能直接替代实际接收 selector 的积分。先把终端变化写清楚：令 \(\gamma=\log z_g\) 在一个实际合法紧区间 \(\Gamma=[\gamma_0,\gamma_1]\) 内变化，且
\[
c(\gamma)=\sum_i\min(0,\log C_i(u)-\gamma)
-\sum_i\min(0,\log C_i(v)-\gamma).
\]
记 \(c_-\)、\(c_+\) 为该函数在 \(\Gamma\) 上的最小、最大值，\(\Omega=c_+-c_-\)。这是可直接计算的有限量：只需在区间两端及落在区间内的 \(2n\) 个 \(\log C_i(u),\log C_i(v)\) 折点取值。并且
\[
\Omega\le n(\gamma_1-\gamma_0).
\tag{15}
\]
几乎处处的导数是终端 score 差 \(k_{z_g}(v)-k_{z_g}(u)\)；这里仍非当前时间 \(z\) 的 score。若固定 \(c_j\) 且 \(g\in[a,b]\)，实际 \(\Gamma\) 长度至多 \(\log2\)，但不能因此将 \(\Omega\) 当作维数无关常数。

对所有终端 \(g\) 同时，近交叉必要事件包含在固定区间事件
\[
Z(x)\in(-\eta-c_+,\ h-c_-],\qquad
\ell_\Gamma=h+\eta+\Omega.
\tag{16}
\]
对 \(0\le s\le S\le1\)，沿已核的 soft 区间格点和向上尺度格点：soft 点至多 \(n\)，尺度点至多 \(n+1\)，逐点 \(P_{s,L}\le e^2P_{u,H}\)。格点 \(u\le S\)，且 (8) 在全部格点成立。于是任何合法接收 selector 满足
\[
\boxed{\quad
\int\sup_{s\le S,L}P_{s,L}(x-y)
\mathbf1_{\{Z\in(-\eta-c_+,h-c_-]\}}dx
\le e^2n(n+1)
\min\left\{1,\frac{4(1+2\ell_\Gamma)}{\sqrt{m+1}}\right\}.
\quad} \tag{17}
\]
若 \(g\) 固定则 \(\Omega=0\)。若 \(\epsilon\) 也被选择，(17) 仅在当前分支给定了同一个上界 \(\epsilon\le\epsilon_0\) 后，用 \(\eta=\log(1+\epsilon_0)\) 适用。

远交叉同理，令 \(D_+(y)=Z(y)+c_+\)，把 (14) 的 \(s\) 换成 \(S\)，并支付同一个 \(e^2n(n+1)\) 网格费用。两支相加给实际参数选择的一个明确条件价。

即使 \(m\asymp n\)、\(\ell_\Gamma=O(1)\)，(17) 的粗价仍为 \(O(n^{3/2})\)，尚非原根阶预算；原 score、后验、hard、外 \(\beta\) 和共同时间均未在本文件消失。若 \(\Omega\) 达 \(O(n)\)，此处的小区间收益还可能完全消失。因此工具的可用方向是联合固定参数/小终端振幅的 pair 几何，不是将来源与时间分别取最坏后宣称付款。

## 6. 退化及近阈值源不能漏掉

若 \(v=u\)，则 \(D_g\equiv0\)；固定参数精确 good/bad 同时发生当然为空，但任何只针对对比统计量的无条件反原子界都失败。若两源同向且彼此接近，对比也可几乎退化。

更具体地，在 \(b=1,y=0\) 时，任取 \(d_0\in(0,1/2)\)。有
\(C'(d_0)=\varphi(d_0+1/2)-1<0\)，且 \(z=C(d_0)\in(1/2,1)\)。取每个坐标 \(v_i=d_0+e,u_i=d_0-e\)，则小 \(e>0\) 时当前 score 可有 \(k_z(v)-k_z(u)=n\)。可是全局 \(4\)-Lipschitz 对数界和 \(C\) 的局部连续正性保证 \(D_g(x)=O(ne)\)，一致于 \(x\)，只要固定的终端权也按原连续公式计算。因此令 \(e\) 比给定区间宽度更小，区间概率可达 1。不能把原 score 差直接当成 (8) 的 crossing-coordinate 数；近阈值源的窄时间现象仍须原共同时间路线支付。

本文件的实际新增是：真实中间 soft 的 crossing-coordinate 区间界 (8)、准确 near/far 门 (9)、显式远交叉条件界 (14)，以及 selector/终端振幅费用 (17)。没有把全 pair 门当成小球，没有假设来源坐标独立，没有重算共同 \(\alpha\)，也没有为 \(H_v\le1+\epsilon\) 门或其补集虚构付款。

