#!/usr/bin/env python3
"""R162 actual 1D log-moment and common-receiver pair diagnostics; quadrature is exploratory."""
from pathlib import Path
from fractions import Fraction as F
import argparse,hashlib,json,math,sys,warnings
ROOT=Path(__file__).resolve().parent
COUNTS={'phi_float':0,'C_float':0,'quad_pieces':0,'phi_mp':0,'C_mp':0}
SP=MP=None
GL={}

def Cfun(d):
    COUNTS['C_float']+=1;d=abs(float(d))
    if d==0:return 1.
    E=lambda x:float(MP.expint(4,MP.mpf(x))) if x else 1/3
    return 1-d+1/3-E(1)-E(d)+E(d+1) if d<=1 else E(d-1)-2*E(d)+E(d+1)
def phi(x):
    COUNTS['phi_float']+=1;r=abs(float(x));E=lambda x:float(MP.expint(3,MP.mpf(x))) if x else .5
    return 1-E(.5-r)-E(.5+r) if r<=.5 else E(r-.5)-E(r+.5)
def mp_phi(x):
    COUNTS['phi_mp']+=1;r=abs(x);h=MP.mpf('.5');E=lambda k,x:MP.mpf(1)/(k-1) if not x else MP.expint(k,x)
    return 1-E(3,h-r)-E(3,h+r) if r<=h else E(3,r-h)-E(3,r+h)
def mp_C(d):
    COUNTS['C_mp']+=1;d=abs(d);E=lambda x:MP.mpf(1)/3 if not x else MP.expint(4,x)
    if not d:return MP.mpf(1)
    return 1-d+MP.mpf(1)/3-E(1)-E(d)+E(d+1) if d<=1 else E(d-1)-2*E(d)+E(d+1)
def root_upper(q,den=8,digits=80):
    scale=10**digits;lo=0;hi=max(scale,(q.numerator*scale**den//q.denominator)+1)
    while lo+1<hi:
        mid=(lo+hi)//2
        if mid**den*q.denominator<=q.numerator*scale**den:lo=mid
        else:hi=mid
    r=F(lo,scale);return r if r**den==q else F(lo+1,scale)
def exp_negative_upper(x,N=256):
    assert x>=0;t=a=F(1)
    for j in range(1,N+1):t*=x/j;a+=t
    return 1/a

def tail_bound(s,L,d,R,theta=F(1,8),remote=False):
    # Rigorous analytic majorant using C(d)>=1/4 exp[-4(d+1)/3].
    if not s:return F(0)
    a=1-theta;coeff=root_upper((s/L)**a.numerator,a.denominator)
    if not remote:
        rate=a/L+theta;X=rate*R-F(1,2)-theta*d-F(4,3)*theta*(d+1);assert X>0
        return 2*coeff*root_upper(F(4)**theta.numerator,theta.denominator)*exp_negative_upper(X)/rate
    # 2 sinh(1/2)>1, so its negative theta power <=1.
    rates=[a/L-theta,a/L+theta];assert min(rates)>0
    return coeff*sum(exp_negative_upper(r*R-a/2)/r for r in rates)
def tail(s,L,d,R=F(48)):
    # |log(phi_shift/(C*p))|<=A+B|x|; log t<=t for t>=1.
    A=4+4*L/s+1/L+F(8,3)*(d+1);B=F(4,3)*(1+1/L)
    e=exp_negative_upper(R/L-F(1,2));mass=2*s*e;v=A+B*R
    return dict(mass=float(mass),abs_first=float(mass*(v+B*L)),raw_second=float(mass*(v*v+2*B*L*v+2*B*B*L*L)),formula='exact rational exponential majorant; decimal displays not outward endpoints')

def main():
    import time
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=ROOT/'numeric.json');ap.add_argument('--vendor',default='/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor');args=ap.parse_args();sys.path.insert(0,args.vendor)
    global MP,SP
    import numpy as np
    import mpmath as mp
    MP=mp;SP=np;mp.mp.dps=35;started=time.monotonic()
    roots={}
    for z in [F(1,2),F(3,4)]:
        lo,hi=0.,2.
        for _ in range(44):
            mid=(lo+hi)/2
            if Cfun(mid)>float(z):lo=mid
            else:hi=mid
        roots[str(z)]=(lo+hi)/2
    ds=[0.,.5,1.,2.,8.,roots['1/2'],roots['3/4']];basecache={};rows=[];pairs=[]
    def grid(L,order):
        key=(L,order)
        if key in basecache:return basecache[key]
        cuts=sorted(set([-48.,48.,-float(L)/2,0.,float(L)/2]+[d+sg*.5 for d in ds for sg in [-1,1]]));nodes,weights=np.polynomial.legendre.leggauss(order)
        x=np.concatenate([(l+r)/2+(r-l)/2*nodes for l,r in zip(cuts,cuts[1:])]);w=np.concatenate([(r-l)/2*weights for l,r in zip(cuts,cuts[1:])]);soft=np.array([phi(float(t)/float(L)) for t in x]);hard=(abs(x)<float(L)/2).astype(float)
        shifted={d:np.array([phi(float(t)-d) for t in x]) for d in ds};basecache[key]=(x,w,soft,hard,shifted);return basecache[key]
    def evaluate(s,L,d,order=96):
        x,w,soft,hard,shifted=grid(L,order);p=((1-float(s))*hard+float(s)*soft)/float(L)
        j=shifted.get(d)
        if j is None:j=np.array([phi(float(t)-d) for t in x]);shifted[d]=j
        ell=np.log(j)-math.log(Cfun(d))-np.log(p);mass=float(sum(w*p));a=float(sum(w*p*ell));second=float(sum(w*p*ell*ell));return a,second-a*a,mass,ell,p,w
    for L in [F(1),F(1,2),F(3,4)]:
        for s in [F(1,20),F(1,10),F(1,4),F(1,2)]:
            chosen=ds if L==1 else [0.,1.,8.]
            for d in chosen:
                a,v,m,*_=evaluate(s,L,d);a48,v48,*_=evaluate(s,L,d,48)
                rows.append(dict(stage='initial' if L==1 and d in [0.,.5,1.,2.,8.] else ('threshold_pressure' if L==1 else 'expanded'),s=str(s),L=str(L),d=d,C=Cfun(d),logC=math.log(Cfun(d)),drift=a,variance=v,truncated_mass=m,order_discrepancy=dict(drift=abs(a-a48),variance=abs(v-v48)),tail=tail(s,L,F(str(d)))))
            if L==1:
                for du,dv in [(0.,roots['3/4']),(roots['3/4'],roots['1/2']),(roots['1/2'],1.),(1.,2.),(2.,8.)]:
                    au,vu,m,eu,p,w=evaluate(s,L,du);av,vv,_,ev,*_=evaluate(s,L,dv);cross=float(sum(w*p*eu*ev));cov=cross-au*av
                    pairs.append(dict(s=str(s),L=str(L),du=du,dv=dv,Cu=Cfun(du),Cv=Cfun(dv),common_x_covariance=cov,variance_log_difference=vu+vv-2*cov,mean_logLv_minus_logLu=av-au,score_separation_z_interval=[min(Cfun(du),Cfun(dv)),max(Cfun(du),Cfun(dv))],note='same x and same p; unequal displacement, no symmetric delta-zero claim'))
    print('main52 completed',flush=True)
    brackets=[]
    for s in [F(1,20),F(1,10),F(1,4),F(1,2)]:
        initial=[r for r in rows if r['L']=='1' and r['s']==str(s) and r['stage']=='initial'];initial.sort(key=lambda r:r['d'])
        for a,b in zip(initial,initial[1:]):
            if a['drift']*b['drift']<0:
                lo,hi=a['d'],b['d'];flo=a['drift']
                for _ in range(10):
                    mid=(lo+hi)/2;f=evaluate(s,F(1),mid)[0]
                    if flo*f<=0:hi=mid
                    else:lo=mid;flo=f
                brackets.append(dict(s=str(s),L='1',lo=lo,hi=hi,drift_lo=evaluate(s,F(1),lo)[0],drift_hi=evaluate(s,F(1),hi)[0],certified=False))
    for row in rows:
        row['drift_with_terminal_wzg']={str(zg):row['drift']+math.log(max(row['C'],float(zg))) for zg in [F(1,2),F(3,4),F(7,8),F(1)]}
    for pair in pairs:
        lo=max(.5,min(pair['Cu'],pair['Cv']));hi=min(1.,max(pair['Cu'],pair['Cv']))
        pair['legal_score_z_open_interval']=[lo,hi] if hi-lo>1e-10 else None
        pair['terminal_zg_checks']=[]
        for zg in [F(3,4),F(7,8),F(1)]:
            top=min(hi,float(zg))
            pair['terminal_zg_checks'].append(dict(terminal_zg=str(zg),mean_logLv_minus_logLu=pair['mean_logLv_minus_logLu']+math.log(max(pair['Cv'],float(zg))/max(pair['Cu'],float(zg))),time_z_open_score_interval_below_terminal=[lo,top] if top-lo>1e-10 else None))
        pair['score_boundary_note']='Numerical C roots; endpoint equality not certified. No legal score separation asserted when interval empty.'
    # Bounded checks of the new cross-core geometry, separate from log-moment menu.
    quad_quarter=[]
    for order in [48,96]:
        nodes,weights=np.polynomial.legendre.leggauss(order)
        quad_quarter.append(sum(float(ww)*phi(3/8+float(xx)/8)/8 for xx,ww in zip(nodes,weights)))
    crossing=[]
    for stage,ss,ll,vv,uu in [('initial',.25,1.,-1.,1.),('pressure',1.,.5,-1.,1.),('pressure',0.,.5,-1.,1.),('expanded',.05,.75,-4.,1.),('expanded',.5,1.,-1.,8.),('expanded',.5,.5,-4.,8.)]:
        zz=lambda xx:math.log(phi(xx-vv))-math.log(phi(xx-uu))
        gap=abs(zz(-ll/4)-zz(ll/4));quarter=(1-ss)/4+ss*quad_quarter[1]
        assert gap>=.5-1e-12 and quarter>=1/16-1e-12
        crossing.append(dict(stage=stage,s=ss,L=ll,v=vv,u=uu,quarter_mass=quarter,quarter_order_difference=ss*abs(quad_quarter[1]-quad_quarter[0]),ordered_value_gap=gap,scope='finite kernel diagnostic; analytic proof supplies uniform 1/16 mass and 1/2 gap, not numerical tolerances'))
    binomial_checks=[]
    for stage,ks in [('initial',range(0,17)),('pressure',[31,32,63,64,255,256]),('expanded',[511,512,1023,1024])]:
        for kk in ks:
            prob=F(math.comb(kk,kk//2),2**kk)
            assert prob*prob<=F(2,kk+1)
            binomial_checks.append(dict(stage=stage,k=kk,central_bound_exact=True))
    capacity_checks=[]
    for stage,ns in [('initial',[1,2,4,8]),('pressure',[63,64,65,255,256,257]),('expanded',[1024,65536,10**9])]:
        for nn in ns:
            threshold=F(4*(nn+1)**2,3*nn)
            assert F(nn*(2*nn+3),(nn+1)**2)<=2
            for dd in [F(0),F(1,1000),F(1,4),F(1,2),F(1)]:
                assert threshold*dd*dd<=threshold
                for rr in [F(0),F(1,4),F(1,2),F(3,4),F(1),F(2)]:
                    xx=dd*rr;rho=max(F(0),dd-xx)
                    cap=F(0) if dd==0 else rho*xx/(threshold*dd*dd)
                    assert cap<=1/(4*threshold)
            capacity_checks.append(dict(stage=stage,n=nn,exact_scalar_checks=True))
    # exp(25/36)>2 gives 36 log 2<25, without a decimal logarithm.
    assert sum((F(25,36)**kk/math.factorial(kk) for kk in range(10)),F(0))>2
    out=dict(status='FINITE_KERNEL_LOG_MOMENT_DIAGNOSTIC',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),contract_sha256=hashlib.sha256((ROOT/'task_contract.md').read_bytes()).hexdigest(),capacity_exact_checks=capacity_checks,cross_core_checks=crossing,binomial_exact_checks=binomial_checks,threshold_roots=roots,rows=rows,pairs_same_x=pairs,numerical_drift_root_brackets=brackets,summary=dict(rows=len(rows),pairs=len(pairs),positive_drift_rows=sum(r['drift']>0 for r in rows),max_drift=max(r['drift'] for r in rows),min_drift=min(r['drift'] for r in rows),max_drift_order_difference=max(r['order_discrepancy']['drift'] for r in rows),max_variance_order_difference=max(r['order_discrepancy']['variance'] for r in rows)),runtime=dict(python=sys.executable,numpy=np.__version__,mpmath=mp.__version__,vendor=args.vendor,elapsed_seconds=time.monotonic()-started),execution=dict(producer_runs=3,successful=3,failed=0,function_counts=COUNTS,new_original_receivers=0),scope=['Finite actual 1D geometry, not original FULL traffic','No K/Q/alpha/rho replacement or inference','Roots and quadrature are numerical, not interval certificates','Raw tail moment analytic majorants are rational internally; mean/variance finite numerical estimates not certified','Terminal zg in likelihood weights is distinct from current time z<=zg; no entire time-history certification','Covariance uses same x under p; covariance tail controlled by half sum of raw second-tail bounds; no independent-source product'])
    args.output.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps(out['summary']));print(brackets)
if __name__=='__main__':main()
