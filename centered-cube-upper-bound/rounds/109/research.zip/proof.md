# R109 概述：来源质量与误差账目

## 审核结论

混合类型估计 M1–M13 与其总账接合 V1–V11 均已数学独审 PASS。共同目标容量帽与同一尺度上的张量差分，把原组合型数费替换为 `C_*²Q_r²`。取

`r = max(1, floor(log_729 n))`

时，来源费用为 `O_ε(√n log n)`，并在原割上控制同时移动至多 r 个坐标的宏观管并。固定三阶段检验与一次隔离重放已经完成；数值记录见最终验证章。

## 来源与误差账

- 新网络的混合类型计划对整份提取来源付款，费用并入 V3、V6；高占比 receiver 交通另以 V5 付款。两项相加，不能以来源已付款为由抵消高占比费用。
- R109 替换 R108 U10 来源方案中的单轴提取费用；旧短邻域菜单仍保留。V8 中的来源费用 `K_{η,r}W_{η*}` 包含短菜单与新网络的总账，未漏计网络或类型数。
- 原联合门、deep top-k 与重尾条件均在新余源上重新建立；软硬来源费用仍相加。积分使用原真实 `dx` 与原共同选择器，未将不同类型的尺度上确界混作同尺度估计。
- 原误差项仍为 `Λ(ε+δ+kκ_n)X`，并保留原树前费用。新费用没有消去这些原项，也没有新增未经说明的误差抵消。
- 低占比余交通 `T_thin,r` 在 V8 括号内系数仍为 1，回代后乘共同 Λ，尚未付款。宏观管并界不能单独推出该项为零；一般目标仍 **UNPROVED**。

本概述只记录已审主文档中的估计、费用与未闭合项，不增加未证假设。


## R109候选：共同尺度矩形族的张量差分付款

## 1. 准确命题

固定整数n≥1、0≤k≤n、a>0、ρ∈[1,3]。对每个k元坐标子集I，D_I在I上为ρ，其他坐标为1；A_{I,t}是以x为中心、全边长分别为ρt和t的归一化矩形平均。给非负s_I∈L1∩L∞，满足Σ_I s_I≤τ，令W=Σ_I∫s_I。成立如下估计
\[
\left\|\sup_{a\le t\le2a}\sum_{|I|=k}A_{I,t}s_I\right\|_2
\le C_* Q_k\sqrt{\tau W},\qquad
C_*=1+32\log2,\quad Q_k=\sum_{j=0}^k8^j\sqrt{\binom kj}\le9^k.
\tag{M1}
\]
上确界在所有类型的**同一个尺度t**上；本命题不声称控制Σ_I sup_t A_{I,t}s_I。原正输运比较的接收尺度R(x)确实对所有类型相同，故M1足以使用。

## 2. 一维张量收缩与导数预算

令h(u)=sin(u)/u，h(0)=1，δ(u)=h(ρu)−h(u)，θ=1/64，v(u)=(h(u),δ(u)/8)。使用以下完全显式标量界：
\[
\|v(u)\|_2\le1,\qquad
\|u v'(u)\|_2\le32(1-\|v(u)\|_2).
\tag{M2}
\]
ρ在[1,3]上一致。

证明：当|u|≤1，积分h(u)=∫_0^1 cos(ut)dt给
\[
|\delta(u)|\le\frac{\rho^2-1}{6}u^2\le\frac43u^2,
\quad |u h'(u)|\le u^2/3,
\quad |u\delta'(u)|\le(\rho^2+1)u^2/3\le10u^2/3.
\tag{M3}
\]
首个不等式由cos在ρut与ut间积分、|sin z|≤|z|得到。Taylor交错界给0<h(u)≤1−19u²/120，因此h(u)²≤1−19u²/120。于是
\[
\|v(u)\|_2^2\le1-\frac{47}{360}u^2,
\quad1-\|v(u)\|_2\ge\frac{47}{720}u^2,
\quad\|u v'(u)\|_2\le\frac{\sqrt{41}}{12}u^2.
\tag{M4}
\]
显然最后的导数界小于32倍的loss；u=0时两边均为零。

当|u|≥1，sinc在[1,π]上正且递减，在π外绝对值≤1/π，故|h(u)|≤sin1<6/7。由|δ|≤2，
\[
\|v(u)\|_2^2\le36/49+1/16=625/784,
\quad1-\|v(u)\|_2\ge3/28.
\tag{M5}
\]
恒等式u h'(u)=cosu−h(u)给|u h'|≤2，|uδ'|≤4。因此||uv'||≤√17/2<3≤32·3/28。M2成立。

对任意频率ξ及尺度t，令u_q=πtξ_q。向量
\[
V_t(\xi)=\bigotimes_{q=1}^n v(u_q)
\]
的坐标由所有子集J标记，相应坐标是8^{−|J|}m_J(t,ξ)，其中
\[
m_J(t,\xi)=\prod_{q\in J}\delta(u_q)\prod_{q\notin J}h(u_q).
\tag{M6}
\]
各b_q=||v(u_q)||在[0,1]。M2及tensor求导给
\[
\|V_t\|\le1,\qquad
\|t\partial_tV_t\|
\le32\sum_q(1-b_q)\prod_{r\ne q}b_r\le32.
\tag{M7}
\]
最后一和是独立Bernoulli恰好一次失败的概率，也可直接展开∏[b_q+(1−b_q)]=1。零b_q不除法，故无端点遗漏。特别对每个固定j，
\[
\sum_{|J|=j}|m_J|^2\le64^j,\qquad
\sum_{|J|=j}|t\partial_t m_J|^2\le32^2 64^j.
\tag{M8}
\]
这是向量符号的欧氏预算，不是各类型标量范数之和，也不调用未经匹配的MZ定理。

## 3. 同一尺度展开、共享帽与局部最大估计

矩形平均的Fourier乘子准确为∏_{q∈I}(h+δ)(u_q)∏_{q∉I}h(u_q)。因此令
\[
g_J=\sum_{\substack{|I|=k\\I\supset J}}s_I,
\qquad T_{J,t}\text{的乘子为 }m_J(t,\xi),
\]
有有限恒等式
\[
\sum_{|I|=k} A_{I,t}s_I
=\sum_{j=0}^k L_{j,t},\qquad
L_{j,t}=\sum_{|J|=j}T_{J,t}g_J.
\tag{M9}
\]
非负与共同帽给0≤g_J≤τ，以及Σ_{|J|=j}g_J=binom(k,j)Σ_I s_I；故
\[
\sum_{|J|=j}\|g_J\|_2^2\le\binom kj\tau W.
\tag{M10}
\]
这一步没有binom(n,j)费用。Plancherel、频率处Cauchy与M8给
\[
\|L_{j,t}\|_2\le8^j\left(\sum_{|J|=j}\|g_J\|_2^2\right)^{1/2},
\quad
\|t\partial_t L_{j,t}\|_2\le32\,8^j\left(\sum_{|J|=j}\|g_J\|_2^2\right)^{1/2}.
\tag{M11}
\]
先对光滑紧支撑输入，逐点微积分及Minkowski给
\[
\left\|\sup_{a\le t\le2a}|L_{j,t}|\right\|_2
\le\|L_{j,a}\|_2+\int_a^{2a}\|t\partial_tL_{j,t}\|_2\frac{dt}{t}
\le C_*8^j\sqrt{\binom kj\tau W}.
\tag{M12}
\]
对j作有限求和即M1；sqrt binom(k,j)≤binom(k,j)给Q_k≤9^k。

一般输入的合法极限按下列步骤完成：用共同非负光滑近似恒等核及共同空间截断构造s_I^{(m)}，保证Σs_I^{(m)}≤τ，Σ∫s_I^{(m)}≤W，且逐型L2收敛。先取有限个有理t，A_{I,t}的L2连续性与有限max传递M1；再对可数有理t单调扩大。对局部可积输入，固定x的矩形平均关于t>0连续（绝对连续积分和盒边界零Lebesgue测度），故有理尺度sup等于所有尺度sup。不得略过这一步将符号微分直接当成任意粗糙输入的逐点导数。

## 4. 原输运费用的严格后果

令实际矩形D'_I在k坐标上为3+2/n，其余1+2/n，ρ=(3+2/n)/(1+2/n)∈[1,3]，t=(1+2/n)R(x)，F=detD'_I。给共享目标帽Σs_I≤τ的类型正计划，其原立方体提取源η满足h_Rη≤FΣ_I A_{I,t}s_I。由M1，对任意原共同选择器R(x)∈[a,2a]，
\[
T_\eta\le\varepsilon X+
\frac{F^2 C_*^2Q_k^2\tau}{4\varepsilon\lambda}W_\eta.
\tag{M13}
\]
这是整份类型提取源的全receiver付款，不是仅低活跃类型数分支，因此有资格保留原来源maxflow residual的k坐标邻域cut。

用F≤3^k e²及Q_k≤9^k，有F²Q_k²≤729^k e⁴。若τ=bλ/√n且729^k≤n，则M13为显式O(b√n)来源价格。它使一次改变至多k≈log n/log729个坐标的接收尺度邻域成为可付几何。所有费用常数保留；这仍不是完整n坐标cube halo或一般弱型上界的闭合。

本节量词、常数、粗糙输入极限和整份来源付款已经独立审核；实际网络与原联合总账接合另见V1–V11。有限数值的完成情况及范围单列。

## R109：对数个坐标的接收尺度几何进入原总账

继承R108 U1–U15、R107全部原门和费用。不改变任意正L1输入、真实dx、原共同选择器、软硬联合资格。

## 1. 网络阶数与单一共同容量

用 r 区分新网络活动坐标数与原 deep top-k 参数 k。对 n≥512，令
\[
r_n=\max\{1,\max\{j\in\mathbb Z_{\ge0}:729^j\le n\}\},
\quad \ell_n=1+\log n,\quad \tau_r=\ell_n\lambda/\sqrt n.
\tag{V1}
\]
则1≤r_n≤n，729^{r_n}≤2n（512≤n<729时由729≤2n，其余由定义）。不得在小维数声称 r_n≥2。

在每个R107共同终端叶 V 上，对同一原来源σ_V、原d=a/n细格的真实pieces P_i=C_i∩V建有限网络。源i与目标j相邻当且仅当不同的格坐标数≤r_n，且每个坐标的指标差≤n。全部方向及类型共用目标容量τ_r|P_j|。内部边容量可取σ_V(V)+τ_r|V|，足以执行此前有限最大流证明。每条边的变动坐标集合补齐到一个r_n元集合I，按预定字典序唯一指派，不能复制流量。

这给一个计划π、提取η^{(r)}、余源ζ^{(r)}和割源集合A_V；割邻域目标并N_V饱和。类型目标密度s_I满足Σ_Is_I≤τ_r，而不是每种类型分别领取τ_r。每条边对所有源点z、目标点y均满足
\[
|z_q-y_q|\le(a+d)\quad(q\in I),\qquad
|z_q-y_q|\le d\quad(q\notin I).
\tag{V2}
\]
因此在原R(x)∈[a,2a]下，正核包含给M13的固定矩形D'_I，F_{n,r}=(3+2/n)^r(1+2/n)^{n-r}。所有类型使用同一t=(1+2/n)R(x)。跨叶相加因叶不交而保留共同目标密度帽；随后在同一原种子概率空间积分。

## 2. 与短邻域菜单共同抽取及其准确价格

把此网络与R107全部短邻域菜单作用于同一原σ_V。沿此前冻结的piece顺序取提取比例运行最大值，以比例增量缩放相应计划，得到σ_V=η_V^*+ζ_V^*。缩放保持类型共享目标帽，来源增量质量之和恰为||η_V^*||；不能把各网络原提取质量直接相加。

对每个增量网络取原真实receiver上的共同尺度L2比较。新网络的L2平方系数为F_{n,r}²C_*²Q_r²τ_r；旧短网络的平方系数总和为C2²Bλ√n，其中\(B=e^4+e^8/(1-e^{-4})\)。网络之间先对这些平方系数与质量用Cauchy，再对实际receiver和种子用Cauchy–Young，仅付一次εX：
\[
T_{\eta^*}\le\varepsilon X+
\left[\frac{C_2^2B\sqrt n}{4\varepsilon}
+\frac{F_{n,r}^2C_*^2Q_r^2\ell_n}{4\varepsilon\sqrt n}\right]W_{\eta^*}.
\tag{V3}
\]
M1的共同尺度仅在一个网络内部要求；跨网络这里使用已经付出的L2三角/Cauchy预算。无网络数、叶数或\(\binom nr\)遗漏。若需更小有限维常数，可在新网络费用中将C_*²Q_r²替换为min{C_*²Q_r²,C2²binom(n,r)}，本轮不依赖该优化。

未缩放新网络计划在A_V上的限制仍给
\[
\pi_V^A:\eta_V^A\longleftrightarrow\tau_r1_{N_V}dy,
\qquad\eta_V^A\le\eta_V^*,\quad
\tau_r|N_V|=\|\eta_V^A\|.
\tag{V4}
\]
不能将缩放后的计划冒充饱和见证。它的来源边缘受运行最大值提取支配，故后续高占比来源费用可以由Wη*支付，但要与V3相加。

## 3. 重建真实尾源并付款

在新的ζ*上从头重建原top-k尾源ν_V、低尾行、轻尾叶、软硬质量比分支和平方列分支；顺序及原门与R108相同，所有对应质量都使用新方案。令r_V^0为实际尾行，r_V为已通过原均衡重尾二元门后的行，正行有r_V^0>δλ、r_V≤4λ，且整个Q_x⊂V。定义ρ_V=|N_V∩Q_x|/R(x)^n。U8同样给
\[
T_{\{\rho_V\ge1/\ell_n\}}
\le4C_2^2\ell_n\sqrt n\,W_{\eta^A}
\le4C_2^2\ell_n\sqrt n\,W_{\eta^*}.
\tag{V5}
\]
因此令
\[
K_{\eta,r}=\frac{C_2^2B\sqrt n}{4\varepsilon}
+\frac{F_{n,r}^2C_*^2Q_r^2\ell_n}{4\varepsilon\sqrt n}
+4C_2^2\ell_n\sqrt n,
\tag{V6}
\]
\[
K_{\eta,r}\le\sqrt n\left[
\frac{C_2^2B}{4\varepsilon}
+\frac{2e^4C_*^2\ell_n}{4\varepsilon}
+4C_2^2\ell_n\right]=O_\varepsilon(\sqrt n\log n).
\tag{V7}
\]
全部新来源费用仍根阶对数级；常数虽较大但显式。

以新真实低占比交通T_{thin,r}替代旧Tthin，原完整账为
\[
\begin{aligned}
R_{\rm out}\le{}&P_{104}+B_{105}W_\mu+C_hA_n^{\rm far}W_{\rm hi}\\
&+\left[\frac1{768}+\Lambda(\varepsilon+\delta+k\kappa_n)\right]X\\
&+\Lambda\left[A_n^{\rm tree}W_{\rm stop}
+K_{\eta,r}W_{\eta^*}+A_n^{\rm tail}(\delta)W_{\rm light}
+C_{\rm mix}K_s\sqrt n\,W_{\rm hi}+T_{\rm thin,r}\right],
\end{aligned}
\tag{V8}
\]
其中Λ=128/119，旧P104及所有继承常数准确如R108 U10–U12；五类新硬来源仍相加为Wtree≤Wμ。软来源预算继续与硬来源预算相加，不做免费抵消。V8无新增X误差，仍含未付交通的系数1。

## 4. 对数维接收尺度管并的真实新约束

共同余源由所有原割源piece并的交S_V承载。定义
\[
\mathcal H_{r,a,V}(S)=\{y\in V:\exists z\in S,
\#\{q:y_q\ne z_q\}\le r,\ \|y-z\|_\infty\le a\}.
\tag{V9}
\]
此处S是有限半开piece并（可取边界的零测度修正），所以该集合可测；可直接按有限r元坐标子集、piece及其坐标区间扩张表达。格指标位移≤n，故\(\mathcal H_{r,a,V}(S_V)\subset N_V\)（边界按相同半开约定或几乎处处解释）。加上低均值σ_V(V)≤K256λ|V|/√n及饱和容量，得
\[
|S_V|\le K_{256}|V|/n,\qquad
|\mathcal H_{r_n,a,V}(S_V)|\le|N_V|\le K_{256}|V|/\ell_n.
\tag{V10}
\]
每个剩余实际接收cube继续满足
\[
|N_V\cap Q_x|<R(x)^n/\ell_n,\qquad
\nu_V(Q_x)>\delta\lambda R(x)^n.
\tag{V11}
\]
原短邻域全部保留，原FULL联合禁同块门、deep top-k自身归一化限制、重尾量级和软硬总质量比较均对新重建的同一尾源成立。这次改变了剩余交通的必要几何条件：从单坐标管并提升为同时移动r_n个坐标的管并，同时仍按整份提取源付款。它不等于完整n坐标halo；仍无点态密度帽可直接将V11矛盾化。下一瓶颈是利用V10的高阶坐标扩张与原软硬联合门支付Tthin,r，而不是把该余项宣布为零。

## R109：共同尺度张量估计的三阶段固定检验

# R109：共同尺度张量估计的三阶段固定检验

本方案在计算前冻结。目标是检验 M2、M7–M10 的实现和边界，定位常数/维度遗漏；一般性证明以已独审的 M1–M13 为准。全部有限浮点扫描只是证据，不是区间证明。使用 Python 标准库 math、random、fractions；不安装软件，不调用全局优化器，不改变参数后重复扫描。

## 一、初步标量探路

记 h(u)=sin(u)/u，δ=h(ρu)−h(u)，v=(h,δ/8)，w=(cos(u)−h(u),[cos(ρu)−h(ρu)−cos(u)+h(u)]/8)。记录 ||v||≤1、||w||≤32(1−||v||) 的最坏有限样本和位置。

固定 ρ=1+j/16（j=0,…,32），u=i/64（i=0,…,1024）；包括 u=0。小 |u|<0.1 时使用 q(u)=1−h(u)=Σ_{m=1}^{20}(-1)^(m+1)u^(2m)/(2m+1)!、w_h(u)=−Σ 2m term_m；对 ρu 同样使用这套多项式（仅此分支中|ρu|<0.3）。δ=q(u)−q(ρu)。损失用 (2q−q²−δ²/64)/(1+||v||) 计算，避免直接1−||v||的抵消。|u|≥0.1使用sin/cos公式。u=0比值约定0。小u多项式是有限浮点计算，不能称作有理区间证书。

## 二、已知强型失败边界及准确展开压力检验

边界集合：ρ∈{1,1+2^-20,2,3−2^-20,3}；u∈{0,2^-30,2^-20,2^-10,0.1,1,1±2^-20,π,2π,10π,100π}，并在π、2π、10π左右分别加±2^-20。检验同一标量式。ρ=1所有差分应为0；零频应不收费。

固定随机种子10920261013。坐标q与rank均从0计，子集I取itertools.combinations(range(n),k)的字典序，rank即从0开始的该序号。对 n=2,4,8，ρ=1,2,3，各构造两组频率：u_q=(q+1)/(2n)；u_q=(-1)^q(0.1+3q/n)。显式枚举所有J，比较 tensor范数、导数范数与下述递推；分别核 M8 各j层。对所有0≤k≤n，给每个k元I确定复系数 z_I=(rank(I)+1)/(1+binom(n,k))+i*(-1)^rank(I)/3，比较 Σ_I z_I∏_{q∈I}h(ρu_q)∏_{q∉I}h(u_q) 与 M9 的按J展开。这里只检验代数恒等式，不声称复系数满足非负共享帽。

另外在同一 n,k 上，以 s_I=(rank(I)+1)/Σ_I(rank(I)+1) 的单点概率向量检验 g_J=Σ_{I⊃J}s_I，Σ_{|J|=j}g_J=binom(k,j)，Σg_J²≤binom(k,j)。这些是共享帽计数的有限示例。缺少共同尺度或缺少共享帽不在命题内，不测试伪强型；历史反例边界由命题量词保留。

## 三、扩大维数和频率范围

标量扩大：ρ=1+j/64（j=0,…,128），u=10^(-8+12i/512)（i=0,…,512），再加负u，以检验h、δ、v和w=u v'的偶对称（未乘u的导数才为奇函数）。记录与阶段一分开的极值。

张量维数 n∈{1,2,8,64,1024,16384}，ρ∈{1,2,3}，四种频率族：全部0；全部1/sqrt(n)；u_q=(1+(q mod 7))/sqrt(n)；先创建一次random.Random(10920261013)，按所列n递增、ρ递增、频率族所列顺序、q递增的嵌套循环，仅在第四族每个q先调用getrandbits(1)得到sign（0→−1，1→+1），再调用uniform(-6,2)，生成 u_q=sign·10^Uniform(-6,2)。其他阶段与频率族不消耗此RNG。无需显式枚举2^n：令 A=||V||²,B=||DV||²,C=<V,DV>，初值(1,0,0)，局部 a=||v||²,b=||w||²,c=<v,w>，更新

 A'=Aa，B'=Ba+Ab+2Cc，C'=Ca+Ac。

所有更新必须用旧值同时计算；记录 A≤1、0≤B≤1024 的最大误差，不允许静默把负B截断成0后算通过。浮点容差仅作实现验收：所有范数/预算 ≤理论界+1e-10；代数恒等式用 |差|≤1e-10(1+|左|+|右|)，再单列实际最大误差。

费用诊断：对整数 n∈{512,729,1024,10000,10^6,10^9,10^12,10^30}，用纯整数循环确定最大 k 使729^k≤n，并逐一检查729^(k+1)>n；不靠浮点log取整。记录 k 与保守费用比729^k/n。只据此选择可付款网络阶数；C2不赋数值，新旧价格不宣称有限n时必然优于旧式。

## 四、精确常数证书与交付

Fraction 精确核验 19/120−1/36=47/360，1/9+100/576=41/144，41/144<(32·47/720)^2，36/49+1/16=625/784=(25/28)^2，17/4<9<(32·3/28)^2。sin(1)<6/7 可用 Taylor 上界1−1/6+1/120<6/7；只认证这些有理常数关系，不认证整条浮点网格。标量的一般区间证明仍由M3–M5承担。

交付 numeric.py、numeric_output.json、numeric_results.md。先静态审核后一次执行 --record（拒绝已有输出），只读重放一次必须字节一致；输出应有参数、样本数、最坏点、误差、精确检查与scope，不保存每个网格点。失败应保留具体样本并报告UNKNOWN，不自改参数。作者不扩展范围，关键数学结论由Sol及主代理审核。

## R109 固定数值检查结果

本页仅记录已保存的 `numeric_output.json`（5,410 B，SHA256 `e48806f1091300434040cba3855499adc7620c0f8bd8a354b6eb249542511139`）。一次固定执行状态为 `PASS`，18 项断言均通过。结果涵盖有限浮点样本、有限张量代数核对和六项 Fraction 常数关系，不构成一般定理的数值证明。

## 固定三阶段扫描

| 阶段 | 固定样本数 | 最大 \(\|v\|\) | 最大 \(\|w\|/(1-\|v\|)\) | 最大值点 \((\rho,u)\) |
|---|---:|---:|---:|---|
| 标量网格 | 33,825 | 1 | 2.828139425753452 | (3, 0.015625) |
| 端点及抵消压力集合 | 90 | 1 | 2.8284271247461903 | (3, 9.313225746154785×10⁻¹⁰) |
| 扩大正负对数网格 | 132,354 | 1 | 2.8284271247461903 | (3, 10⁻⁸) |

第一阶段使用 \(\rho=1+j/16\)、\(j=0,\ldots,32\)，\(u=i/64\)、\(i=0,\ldots,1024\)。第二阶段使用协议固定的5个 \(\rho\) 和18个 \(u\)。第三阶段使用 \(\rho=1+j/64\)、\(j=0,\ldots,128\)，以及513个正频率和对应负频率。记录的最大负 loss 均不大于零；扩大网格的最坏偶性分量差为0，点位 \(\rho=1\)、\(u=10^{-8}\)。其余点上各分量也按同一组冻结网格逐点比较。

小频率分支保留 q 多项式直接计算稳定 loss。上述结果显示这些固定样本未发现超过约 2.829 的比值；不能据此推出连续频率上的 M2，也不改变已证明的32常数。

## 张量、展开和共享帽核对

小维显式组合检查覆盖 n=2,4,8、ρ=1,2,3、两组协议频率；M9/M10 的独立 (n,ρ,family,k) 组合共102组。A/B/C 与显式子集和的最大绝对误差为 3.3306690738754696×10⁻¹⁶，最大归一化误差为 1.1879841797587972×10⁻¹⁶，均出现在 n=2、ρ=3、第一频率族的 A 项。M8 最大有符号预算超额为 -0.09959977567159373，记录点为 n=2、ρ=1、第一族、j=0、m层；没有预算超额为正。共享帽计数的最大记录误差为0。

M9 复系数展开与按 J 展开的最大绝对误差为 3.197442612087707×10⁻¹⁴，最大归一化误差为 6.443959592708236×10⁻¹⁶；两者最坏点均为 n=8、ρ=2、第一频率族、k=4。JSON 中的左右复数按实部/虚部保存。以上仅核对指定的有限代数展开及单点概率帽示例。

大维部分按规定的 n、ρ 和四种频率族检查了72组递推，最大 n 为16,384。记录的最大 A-1 为0（n=1、ρ=1、零频率族），最大 B-1024 为 -1023.4412773551646（n=2、ρ=3、随机族），最小未截断 B 为0（同属零频率样本）。未发现该固定菜单中的递推预算反例；这些数值不覆盖其他频率向量或一般张量定理。

## 精确常数与费用阶数

Fraction 精确检查通过以下六项关系：

\[
\frac{19}{120}-\frac1{36}=\frac{47}{360},\qquad
\frac19+\frac{100}{576}=\frac{41}{144},\qquad
\frac{41}{144}<\left(32\frac{47}{720}\right)^2;
\]
\[
\frac{36}{49}+\frac1{16}=\frac{625}{784}=\left(\frac{25}{28}\right)^2,\qquad
\frac{17}{4}<9<\left(32\frac3{28}\right)^2,\qquad
1-\frac16+\frac1{120}=\frac{101}{120}<\frac67.
\]

按纯整数循环求出的最大 \(k\)（\(729^k\le n<729^{k+1}\)）为：\(n=512:0\)，729:1，1,024:1，10,000:1，\(10^6:2\)，\(10^9:3\)，\(10^{12}:4\)，\(10^{30}:10\)。这里 \(n=512\) 时数值诊断的 \(k=\lfloor\log_{729}n\rfloor=0\)；V1 网络的阶数定义为 \(r=\max(1,k)\)，故 \(r=1\)，并且 \(729^r=729\le2n=1024\)。这两种阶数不能混淆，也不等同于原 deep 网络中的 top-k 参数。

数值记录没有发现违反协议的有限样本；它只覆盖固定网格和给定的72组张量递推。结果与采用已证明的 \(729^k\) 预算相容，没有提供调优该预算的证据，也不构成对其他预算的比较结论。

## 结论边界

本次浮点扫描不认证整个连续频率区间，不证明 M1–M13 一般结论，不改变32常数，也不闭合一般端点、全尺度上确界或全局网络估计。通过项只表示指定样本及精确分数关系符合实现容差。

## 验证、复现与证据范围

一般目标状态仍为 **UNPROVED**。主代理完成 M1–M13 和 V1–V11 推导；Sol high 先独立检查命题及量词，再阅读证明，对共享帽计数、标量与张量常数、粗糙输入极限、固定类型指派、整份增量来源、原门及全局回代分别给出数学 PASS。当前剩余责任仍为 V8 中的真实低占比质量可比重尾交通。

本轮按更新后64项技能中的 F05 方法核对向量乘子的实际预算与共同参数，按 L03 区分有限浮点探路、精确有理常数与一般证明。没有把某个技能名称当作未经验证的混合类型定理，也没有声称读完或验证全部64项及全部原始文献。M2–M12的关键估计在正文自含证明。

固定数值协议先审核，Luna 实现由 Sol 独立静态核验；修正小频率稳定量被覆写、递推下界未进入判定、误差统计及结果序列化问题后才执行。参数和容差没有因运行结果改变。主代理一次记录通过：三组标量样本数为33825、90、132354，小维展开102组，大维张量72组至n=16384；6条有理常数关系通过。浮点容差为1e-10，完整具体最坏点和误差见保存输出，不能把该容差当作向外舍入的区间认证。费用诊断的整数幂测试与网络r=max(1,k)修正分别记录。

主代理仅复制numeric.py到新临时目录，再执行一次默认只读模式，exit 0且stderr为空，5410字节输出与numeric_output.json逐字节一致，SHA256为`e48806f1091300434040cba3855499adc7620c0f8bd8a354b6eb249542511139`。保存结果已由Sol medium独立只读核对，计数、极值、证据范围及回执一致。测试运行环境Python 3.14.6，标准库实现，无第三方包。这里默认模式会重新计算同一固定实验，区别于上一轮只核保存流候选的验证器。记录生产1次、隔离复现1次，总计2次固定实验执行；归档阶段不再次执行。跨平台浮点末位可能不同，数学证据范围不依赖字节相同假设。

归档恰含proof.md、proof.tex.txt、inventory.json。proof.md原样内嵌numeric.py及numeric_output.json两份必要文件，文件头记录字节长度和SHA256。将归档解压至空目录后，以下脚本提取并核验完整字节：

```python
from pathlib import Path
import hashlib, re
raw = Path('proof.md').read_bytes()
out = Path('reproduced')
out.mkdir(exist_ok=True)
allowed = {'numeric.py', 'numeric_output.json'}
seen = set()
pat = rb'<!-- REPRO-FILE-BEGIN name="([A-Za-z0-9_.]+)" bytes="([0-9]+)" sha256="([0-9a-f]{64})" -->\n````[a-z]+\n'
for hit in re.finditer(pat, raw):
    name = hit[1].decode()
    assert name in allowed and name not in seen
    data = raw[hit.end():hit.end()+int(hit[2])]
    assert hashlib.sha256(data).hexdigest() == hit[3].decode()
    assert raw[hit.end()+len(data):].startswith(b'````\n<!-- REPRO-FILE-END -->')
    (out/name).write_bytes(data)
    seen.add(name)
assert seen == allowed
```

进入reproduced执行`python3 numeric.py`，比较stdout与保存输出。若需重新记录，另建空目录仅复制numeric.py，执行`python3 numeric.py --record`；程序拒绝覆盖已有numeric_output.json。任何额外复现须单独计数，不能混入本轮已完成次数。

归档仅检查已保存证据、正文显示公式逐式次序、LaTeX环境和括号、源文件及资产哈希、ZIP成员字节和CRC。不编译LaTeX，不生成PDF。私人额度及协作记录、旧草稿、下一轮候选和重复原始文献不纳入。有限样本未发现违反所检式的点，既不认证任意输入，也不证明一般端点闭合；正文的一般估计由独立解析证明负责。


## 原样复现文件

以下代码块内容按原始字节保存；先按验证章节的长度及哈希提取，再运行所需命令。

### numeric.py

<!-- REPRO-FILE-BEGIN name="numeric.py" bytes="19072" sha256="147a0e135f9138955f49e05cfefb37f39eefd102baa0da9e13cd5f7827a1e548" -->
````python
#!/usr/bin/env python3
"""Frozen R109 finite numerical pressure checks; standard library only."""
import argparse
import itertools
import json
import math
import random
import sys
from fractions import Fraction as F
from pathlib import Path

OUT = Path(__file__).with_name("numeric_output.json")
TOL = 1e-10
CURRENT = {"phase": "initialization"}


def scalar(u, rho):
    """Return h, delta, v norm, w norm, stable loss, and components."""
    if abs(u) < 0.1:
        def small(x):
            terms = []
            term = 0.0
            for m in range(1, 21):
                term_m = ((-1.0) ** (m + 1)) * x ** (2 * m) / math.factorial(2 * m + 1)
                terms.append(term_m)
                term += term_m
            return term, -sum(2 * m * terms[m - 1] for m in range(1, 21))
        q, wh = small(u)
        qr, whr = small(rho * u)
        h, hr = 1.0 - q, 1.0 - qr
        delta = q - qr
        wd = (whr - wh) / 8.0
    else:
        h = math.sin(u) / u
        hr = math.sin(rho * u) / (rho * u)
        delta = hr - h
        wh = math.cos(u) - h
        whr = math.cos(rho * u) - hr
        wd = (whr - wh) / 8.0
        q = 1.0 - h
    v0, v1 = h, delta / 8.0
    w0, w1 = wh, wd
    vnorm = math.hypot(v0, v1)
    wnorm = math.hypot(w0, w1)
    loss = (2.0 * q - q * q - delta * delta / 64.0) / (1.0 + vnorm)
    ratio = 0.0 if u == 0.0 else wnorm / loss if loss > 0.0 else math.inf
    if not all(math.isfinite(x) for x in (h, delta, v0, v1, w0, w1, vnorm, wnorm, loss, ratio)):
        CURRENT.update({"phase": "scalar", "rho": rho, "u": u})
        raise ArithmeticError("non-finite scalar sample")
    return {"h": h, "delta": delta, "v": (v0, v1), "w": (w0, w1),
            "vnorm": vnorm, "wnorm": wnorm, "loss": loss, "ratio": ratio}


def record_ext(ext, value, point):
    if ext is None or value > ext["value"]:
        return {"value": value, "point": point}
    return ext


def scalar_scan(rhos, us, name):
    worst_v = worst_ratio = worst_loss = None
    max_abs_even = {"value": -1.0, "point": None, "object": None,
                    "left": None, "right": None}
    count = 0
    for rho in rhos:
        for u in us:
            d = scalar(u, rho)
            count += 1
            CURRENT.update({"phase": name, "rho": rho, "u": u})
            worst_v = record_ext(worst_v, d["vnorm"], {"rho": rho, "u": u})
            worst_ratio = record_ext(worst_ratio, d["ratio"], {"rho": rho, "u": u})
            worst_loss = record_ext(worst_loss, -d["loss"], {"rho": rho, "u": u})
            if name == "expanded_signed":
                dn = scalar(-u, rho)
                pairs = [("h", d["h"], dn["h"]), ("delta", d["delta"], dn["delta"]),
                         ("v[0]", d["v"][0], dn["v"][0]), ("v[1]", d["v"][1], dn["v"][1]),
                         ("w[0]", d["w"][0], dn["w"][0]), ("w[1]", d["w"][1], dn["w"][1])]
                for obj, left, right in pairs:
                    err = abs(left-right)
                    if err > max_abs_even["value"]:
                        max_abs_even = {"value": err, "point": {"rho": rho, "u": u},
                                        "object": obj, "left": left, "right": right}
    return {"name": name, "sample_count": count, "max_v_norm": worst_v,
            "max_w_over_loss": worst_ratio, "max_negative_loss": worst_loss,
            "max_even_symmetry_error": max_abs_even}


def explicit_tensor(us, rho):
    vs, ws = [], []
    for u in us:
        d = scalar(u, rho)
        vs.append(d["v"])
        ws.append(d["w"])
    n = len(us)
    # Enumerate coordinates by subset, explicitly, for the small-dimensional identity checks.
    V, DV = {}, {}
    for mask in range(1 << n):
        subset = tuple(q for q in range(n) if mask & (1 << q))
        val, der = 1.0, 0.0
        for q in range(n):
            factor = vs[q][1] if q in subset else vs[q][0]
            deriv_factor = ws[q][1] if q in subset else ws[q][0]
            der = der * factor + val * deriv_factor
            val *= factor
        V[subset], DV[subset] = val, der
    return V, DV


def tensor_recurrence(us, rho):
    A, B, C = 1.0, 0.0, 0.0
    for u in us:
        d = scalar(u, rho)
        a = d["vnorm"] ** 2
        b = d["wnorm"] ** 2
        c = d["v"][0] * d["w"][0] + d["v"][1] * d["w"][1]
        oldA, oldB, oldC = A, B, C
        A, B, C = oldA * a, oldB * a + oldA * b + 2.0 * oldC * c, oldC * a + oldA * c
    return A, B, C


def frequency_sets(n, rng=None):
    yield "zero", [0.0] * n
    yield "flat", [1.0 / math.sqrt(n)] * n
    yield "mod7", [(1 + (q % 7)) / math.sqrt(n) for q in range(n)]
    assert rng is not None
    vals = []
    for _q in range(n):
        sign = -1 if rng.getrandbits(1) == 0 else 1
        vals.append(sign * 10.0 ** rng.uniform(-6.0, 2.0))
    yield "random", vals


def small_tensor_checks():
    max_tensor_abs = {"value": -1.0, "point": None}
    max_tensor_relative = {"value": -1.0, "point": None}
    max_m8_err = {"value": -1.0, "point": None, "kind": None}
    max_m9_abs = {"value": -1.0, "point": None}
    max_m9_relative = {"value": -1.0, "point": None}
    max_hat_err = {"value": -1.0, "point": None, "kind": None}
    samples = 0
    for n in (2, 4, 8):
        for rho in (1.0, 2.0, 3.0):
            families = (([(q + 1) / (2 * n) for q in range(n)]),
                        [((-1) ** q) * (0.1 + 3 * q / n) for q in range(n)])
            for us in families:
                family_id = families.index(us)
                CURRENT.update({"phase": "small_tensor", "n": n, "rho": rho,
                                "family": family_id})
                V, DV = explicit_tensor(us, rho)
                CURRENT.update({"phase": "small_tensor_recurrence", "n": n, "rho": rho,
                                "family": family_id})
                A, B, C = tensor_recurrence(us, rho)
                if not all(math.isfinite(x) for x in (A, B, C)):
                    raise ArithmeticError("non-finite explicit tensor recurrence")
                tensor_pairs = [("A", A, sum(x*x for x in V.values())),
                                ("B", B, sum(x*x for x in DV.values())),
                                ("C", C, sum(V[J]*DV[J] for J in V))]
                for label, left, right in tensor_pairs:
                    ae = abs(left-right)
                    re = ae / (1.0 + abs(left) + abs(right))
                    point = {"n": n, "rho": rho, "family": family_id,
                             "quantity": label, "left": left, "right": right}
                    if ae > max_tensor_abs["value"]:
                        max_tensor_abs = {"value": ae, "point": point}
                    if re > max_tensor_relative["value"]:
                        max_tensor_relative = {"value": re, "point": point}
                for j in range(n + 1):
                    CURRENT.update({"phase": "M8", "n": n, "rho": rho,
                                    "family": family_id, "j": j})
                    jsets = list(itertools.combinations(range(n), j))
                    m = {J: 8**j * V[J] for J in jsets}
                    dm = {J: 8**j * DV[J] for J in jsets}
                    for kind, val, bound in (("m", sum(x*x for x in m.values()), 64**j),
                                              ("dm", sum(x*x for x in dm.values()), 32**2*64**j)):
                        excess = val-bound
                        if excess > max_m8_err["value"]:
                            max_m8_err = {"value": excess, "point": {"n": n, "rho": rho,
                                "family": family_id, "j": j, "kind": kind,
                                "value": val, "bound": bound}, "kind": kind}
                # M9/M10 depend on n,rho,frequency family,k, but not on the M8 j loop.
                coord = [scalar(u, rho) for u in us]
                for k in range(n + 1):
                    CURRENT.update({"phase": "M9_M10", "n": n, "rho": rho,
                                    "family": family_id, "k": k})
                    isets = list(itertools.combinations(range(n), k))
                    z = {I: complex((rank + 1) / (1 + math.comb(n, k)), (-1)**rank / 3)
                         for rank, I in enumerate(isets)}
                    expanded = 0j
                    for I in isets:
                        term = z[I]
                        for q in range(n):
                            term *= (coord[q]["h"] + coord[q]["delta"]) if q in I else coord[q]["h"]
                        expanded += term
                    via_j = 0j
                    for jj in range(k + 1):
                        CURRENT.update({"phase": "M10", "n": n, "rho": rho,
                                        "family": family_id, "k": k, "j": jj})
                        for J in itertools.combinations(range(n), jj):
                            g = sum((z[I] for I in isets if set(J).issubset(I)), 0j)
                            via_j += g * (8**jj * V[J])
                    m9abs = abs(expanded-via_j)
                    m9rel = m9abs/(1.0+abs(expanded)+abs(via_j))
                    def complex_pair(zval):
                        return {"real": zval.real, "imag": zval.imag}
                    m9point = {"n": n, "rho": rho, "family": family_id,
                               "k": k, "left": complex_pair(expanded),
                               "right": complex_pair(via_j)}
                    if m9abs > max_m9_abs["value"]:
                        max_m9_abs = {"value": m9abs, "point": m9point}
                    if m9rel > max_m9_relative["value"]:
                        max_m9_relative = {"value": m9rel, "point": m9point}
                    weights = {I: rank + 1 for rank, I in enumerate(isets)}
                    total = sum(weights.values())
                    s = {I: F(w, total) for I, w in weights.items()}
                    for jj in range(k + 1):
                        jsets2 = list(itertools.combinations(range(n), jj))
                        gs = [sum((s[I] for I in isets if set(J).issubset(I)), F(0)) for J in jsets2]
                        sumerr = float(abs(sum(gs, F(0))-math.comb(k,jj)))
                        sqexcess = float(sum((x*x for x in gs), F(0))-math.comb(k,jj))
                        for kind, err in (("sum", sumerr), ("squared_sum", sqexcess)):
                            if err > max_hat_err["value"]:
                                max_hat_err = {"value": err, "kind": kind,
                                    "point": {"n": n, "rho": rho, "family": family_id,
                                              "k": k, "j": jj, "value": err}}
                    samples += 1
    return {"sample_count": samples,
            "tensor_recurrence_error": {"max_abs": max_tensor_abs,
                                        "max_normalized": max_tensor_relative},
            "M8_max_budget_excess": max_m8_err,
            "M9_expansion_error": {"max_abs": max_m9_abs,
                                   "max_normalized": max_m9_relative},
            "shared_hat_error": max_hat_err}


def exact_constants():
    checks = {
        "19/120 - 1/36 = 47/360": F(19,120) - F(1,36) == F(47,360),
        "1/9 + 100/576 = 41/144": F(1,9) + F(100,576) == F(41,144),
        "41/144 < (32*47/720)^2": F(41,144) < (F(32)*F(47,720))**2,
        "36/49 + 1/16 = 625/784 = (25/28)^2": F(36,49)+F(1,16) == F(625,784) == F(25,28)**2,
        "17/4 < 9 < (32*3/28)^2": F(17,4) < 9 < (F(32)*F(3,28))**2,
        "sin(1) Taylor upper < 6/7": F(1)-F(1,6)+F(1,120) < F(6,7),
    }
    return {"checks": checks, "all_pass": all(checks.values()),
            "exact_values": {"47/360": str(F(47,360)), "41/144": str(F(41,144)),
                             "625/784": str(F(625,784))}}


def integer_costs():
    out = []
    for n in (512, 729, 1024, 10000, 10**6, 10**9, 10**12, 10**30):
        k, power = 0, 1
        while power * 729 <= n:
            power *= 729
            k += 1
        assert power <= n and power * 729 > n
        out.append({"n": str(n), "k": k, "729_power_k": str(power),
                    "next_power_exceeds_n": power * 729 > n,
                    "conservative_ratio": str(F(power, n))})
    return out


def run():
    stage1 = scalar_scan([1.0 + j/16.0 for j in range(33)], [i/64.0 for i in range(1025)], "stage1")
    boundary_rhos = (1.0, 1.0+2**-20, 2.0, 3.0-2**-20, 3.0)
    core = (0.0, 2**-30, 2**-20, 2**-10, 0.1, 1.0, 1.0-2**-20, 1.0+2**-20,
            math.pi, 2*math.pi, 10*math.pi, 100*math.pi)
    boundary_us = sorted(set(core + tuple(c+d for c in (math.pi,2*math.pi,10*math.pi) for d in (-2**-20,2**-20))))
    stage2 = scalar_scan(boundary_rhos, boundary_us, "boundary")
    expanded_us = [10.0**(-8.0 + 12.0*i/512.0) for i in range(513)]
    expanded_us = [x for u in expanded_us for x in (u, -u)]
    stage3 = scalar_scan([1.0+j/64.0 for j in range(129)], expanded_us, "expanded_signed")
    small = small_tensor_checks()
    rng = random.Random(10920261013)
    tensor_n = []
    max_A_excess = max_B_excess = -math.inf
    min_B = 0.0
    min_B_point = None
    max_A_point = max_B_point = None
    tensor_samples = 0
    for n in (1, 2, 8, 64, 1024, 16384):
        for rho in (1.0, 2.0, 3.0):
            for family, us in frequency_sets(n, rng):
                CURRENT.update({"phase": "large_tensor", "n": n, "rho": rho, "family": family})
                A, B, _C = tensor_recurrence(us, rho)
                if not all(math.isfinite(x) for x in (A, B)):
                    raise ArithmeticError("non-finite large tensor recurrence")
                ae, be = A - 1.0, B - 1024.0
                if max_A_point is None or ae > max_A_excess:
                    max_A_excess, max_A_point = ae, {"n":n,"rho":rho,"family":family}
                if max_B_point is None or be > max_B_excess:
                    max_B_excess, max_B_point = be, {"n":n,"rho":rho,"family":family}
                if min_B_point is None or B < min_B:
                    min_B, min_B_point = B, {"n":n,"rho":rho,"family":family}
                tensor_samples += 1
    constants = exact_constants()
    checks = [stage1["max_v_norm"]["value"] <= 1+TOL,
              stage1["max_w_over_loss"]["value"] <= 32+TOL,
              stage2["max_v_norm"]["value"] <= 1+TOL,
              stage2["max_w_over_loss"]["value"] <= 32+TOL,
              stage1["max_negative_loss"]["value"] <= TOL,
              stage2["max_negative_loss"]["value"] <= TOL,
              stage3["max_v_norm"]["value"] <= 1+TOL,
              stage3["max_w_over_loss"]["value"] <= 32+TOL,
              stage3["max_negative_loss"]["value"] <= TOL,
              stage3["max_even_symmetry_error"]["value"] <= TOL,
              small["tensor_recurrence_error"]["max_normalized"]["value"] <= TOL,
              small["M9_expansion_error"]["max_normalized"]["value"] <= TOL,
              small["M8_max_budget_excess"]["value"] <= TOL,
              small["shared_hat_error"]["value"] <= TOL,
              max_A_excess <= TOL, max_B_excess <= TOL, min_B >= -TOL,
              constants["all_pass"]]
    return {"status": "PASS" if all(checks) else "UNKNOWN",
            "protocol": "R109 fixed three-stage numerical pressure checks",
            "parameters": {"rho_stage1": "1+j/16, j=0..32", "u_stage1": "i/64, i=0..1024",
                           "boundary_rho_count": len(boundary_rhos), "boundary_u_count": len(boundary_us),
                           "expanded_rho": "1+j/64, j=0..128", "expanded_signed_u_count": len(expanded_us),
                           "tensor_n": [1,2,8,64,1024,16384], "tensor_rho": [1,2,3],
                           "tensor_seed": 10920261013, "tolerance": TOL},
            "scalar_scans": [stage1, stage2, stage3], "small_explicit_tensor_checks": small,
            "large_tensor_recurrence": {"sample_count": tensor_samples,
                "max_A_minus_1": max_A_excess, "max_A_point": max_A_point,
                "min_B_without_clipping": min_B,
                "min_B_point": min_B_point,
                "max_B_minus_1024": max_B_excess, "max_B_point": max_B_point},
            "integer_cost_diagnostic": integer_costs(), "fraction_constants": constants,
            "assertion_count": len(checks), "failed_assertions": [i for i, ok in enumerate(checks) if not ok],
            "failure_sample_points": {"scalar_stage1": stage1["max_w_over_loss"]["point"],
                "scalar_boundary": stage2["max_w_over_loss"]["point"],
                "scalar_expanded": stage3["max_w_over_loss"]["point"],
                "symmetry": stage3["max_even_symmetry_error"]["point"],
                "small_tensor_abs": small["tensor_recurrence_error"]["max_abs"]["point"],
                "small_tensor_normalized": small["tensor_recurrence_error"]["max_normalized"]["point"],
                "M8": small["M8_max_budget_excess"]["point"],
                "M9_abs": small["M9_expansion_error"]["max_abs"]["point"],
                "M9_normalized": small["M9_expansion_error"]["max_normalized"]["point"],
                "shared_hat": small["shared_hat_error"]["point"],
                "tensor_A": max_A_point, "tensor_B_upper": max_B_point,
                "tensor_B_lower": min_B_point},
            "scope": "Finite floating-point samples and exact listed rational identities only; no interval certification, no proof of M1-M13, and no general endpoint or network closure."}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--record", action="store_true", help="write one result; refuse to overwrite")
    args = parser.parse_args()
    if args.record and OUT.exists():
        print("UNKNOWN: refusing to overwrite existing numeric_output.json", file=sys.stderr)
        return 2
    try:
        result = run()
    except Exception as exc:  # preserve failure as UNKNOWN with concrete failure detail
        result = {"status": "UNKNOWN", "protocol": "R109 fixed three-stage numerical pressure checks",
                  "failure": {"type": type(exc).__name__, "message": str(exc),
                              "context": dict(CURRENT)},
                  "scope": "Incomplete run; no claim of successful checks."}
    def finite_json(value):
        if isinstance(value, float) and not math.isfinite(value):
            return "Infinity" if value > 0 else "-Infinity" if value < 0 else "NaN"
        if isinstance(value, dict):
            return {k: finite_json(v) for k, v in value.items()}
        if isinstance(value, (tuple, list)):
            return [finite_json(v) for v in value]
        return value
    result = finite_json(result)
    payload = (json.dumps(result, sort_keys=True, ensure_ascii=False, separators=(",", ":"), allow_nan=False) + "\n").encode("utf-8")
    if args.record:
        try:
            with OUT.open("xb") as f:
                f.write(payload)
        except FileExistsError:
            print("UNKNOWN: refusing to overwrite existing numeric_output.json", file=sys.stderr)
            return 2
    sys.stdout.buffer.write(payload)
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
````
<!-- REPRO-FILE-END -->

### numeric_output.json

<!-- REPRO-FILE-BEGIN name="numeric_output.json" bytes="5410" sha256="e48806f1091300434040cba3855499adc7620c0f8bd8a354b6eb249542511139" -->
````json
{"assertion_count":18,"failed_assertions":[],"failure_sample_points":{"M8":{"bound":1,"family":0,"j":0,"kind":"m","n":2,"rho":1.0,"value":0.9004002243284063},"M9_abs":{"family":0,"k":4,"left":{"imag":-0.09687047050722311,"real":24.309417961903705},"n":8,"rho":2.0,"right":{"imag":-0.09687047050722312,"real":24.309417961903673}},"M9_normalized":{"family":0,"k":4,"left":{"imag":-0.09687047050722311,"real":24.309417961903705},"n":8,"rho":2.0,"right":{"imag":-0.09687047050722312,"real":24.309417961903673}},"scalar_boundary":{"rho":3.0,"u":9.313225746154785e-10},"scalar_expanded":{"rho":3.0,"u":1e-08},"scalar_stage1":{"rho":3.0,"u":0.015625},"shared_hat":{"family":0,"j":0,"k":0,"n":2,"rho":1.0,"value":0.0},"small_tensor_abs":{"family":0,"left":0.9018154158213256,"n":2,"quantity":"A","rho":3.0,"right":0.901815415821326},"small_tensor_normalized":{"family":0,"left":0.9018154158213256,"n":2,"quantity":"A","rho":3.0,"right":0.901815415821326},"symmetry":{"rho":1.0,"u":1e-08},"tensor_A":{"family":"zero","n":1,"rho":1.0},"tensor_B_lower":{"family":"zero","n":1,"rho":1.0},"tensor_B_upper":{"family":"random","n":2,"rho":3.0}},"fraction_constants":{"all_pass":true,"checks":{"1/9 + 100/576 = 41/144":true,"17/4 < 9 < (32*3/28)^2":true,"19/120 - 1/36 = 47/360":true,"36/49 + 1/16 = 625/784 = (25/28)^2":true,"41/144 < (32*47/720)^2":true,"sin(1) Taylor upper < 6/7":true},"exact_values":{"41/144":"41/144","47/360":"47/360","625/784":"625/784"}},"integer_cost_diagnostic":[{"729_power_k":"1","conservative_ratio":"1/512","k":0,"n":"512","next_power_exceeds_n":true},{"729_power_k":"729","conservative_ratio":"1","k":1,"n":"729","next_power_exceeds_n":true},{"729_power_k":"729","conservative_ratio":"729/1024","k":1,"n":"1024","next_power_exceeds_n":true},{"729_power_k":"729","conservative_ratio":"729/10000","k":1,"n":"10000","next_power_exceeds_n":true},{"729_power_k":"531441","conservative_ratio":"531441/1000000","k":2,"n":"1000000","next_power_exceeds_n":true},{"729_power_k":"387420489","conservative_ratio":"387420489/1000000000","k":3,"n":"1000000000","next_power_exceeds_n":true},{"729_power_k":"282429536481","conservative_ratio":"282429536481/1000000000000","k":4,"n":"1000000000000","next_power_exceeds_n":true},{"729_power_k":"42391158275216203514294433201","conservative_ratio":"42391158275216203514294433201/1000000000000000000000000000000","k":10,"n":"1000000000000000000000000000000","next_power_exceeds_n":true}],"large_tensor_recurrence":{"max_A_minus_1":0.0,"max_A_point":{"family":"zero","n":1,"rho":1.0},"max_B_minus_1024":-1023.4412773551646,"max_B_point":{"family":"random","n":2,"rho":3.0},"min_B_point":{"family":"zero","n":1,"rho":1.0},"min_B_without_clipping":0.0,"sample_count":72},"parameters":{"boundary_rho_count":5,"boundary_u_count":18,"expanded_rho":"1+j/64, j=0..128","expanded_signed_u_count":1026,"rho_stage1":"1+j/16, j=0..32","tensor_n":[1,2,8,64,1024,16384],"tensor_rho":[1,2,3],"tensor_seed":10920261013,"tolerance":1e-10,"u_stage1":"i/64, i=0..1024"},"protocol":"R109 fixed three-stage numerical pressure checks","scalar_scans":[{"max_even_symmetry_error":{"left":null,"object":null,"point":null,"right":null,"value":-1.0},"max_negative_loss":{"point":{"rho":1.0,"u":0.0},"value":-0.0},"max_v_norm":{"point":{"rho":1.0,"u":0.0},"value":1.0},"max_w_over_loss":{"point":{"rho":3.0,"u":0.015625},"value":2.828139425753452},"name":"stage1","sample_count":33825},{"max_even_symmetry_error":{"left":null,"object":null,"point":null,"right":null,"value":-1.0},"max_negative_loss":{"point":{"rho":1.0,"u":0.0},"value":-0.0},"max_v_norm":{"point":{"rho":1.0,"u":0.0},"value":1.0},"max_w_over_loss":{"point":{"rho":3.0,"u":9.313225746154785e-10},"value":2.8284271247461903},"name":"boundary","sample_count":90},{"max_even_symmetry_error":{"left":1.0,"object":"h","point":{"rho":1.0,"u":1e-08},"right":1.0,"value":0.0},"max_negative_loss":{"point":{"rho":1.0,"u":1e-08},"value":-1.6666666666666667e-17},"max_v_norm":{"point":{"rho":1.0,"u":1e-08},"value":1.0},"max_w_over_loss":{"point":{"rho":3.0,"u":1e-08},"value":2.8284271247461903},"name":"expanded_signed","sample_count":132354}],"scope":"Finite floating-point samples and exact listed rational identities only; no interval certification, no proof of M1-M13, and no general endpoint or network closure.","small_explicit_tensor_checks":{"M8_max_budget_excess":{"kind":"m","point":{"bound":1,"family":0,"j":0,"kind":"m","n":2,"rho":1.0,"value":0.9004002243284063},"value":-0.09959977567159373},"M9_expansion_error":{"max_abs":{"point":{"family":0,"k":4,"left":{"imag":-0.09687047050722311,"real":24.309417961903705},"n":8,"rho":2.0,"right":{"imag":-0.09687047050722312,"real":24.309417961903673}},"value":3.197442612087707e-14},"max_normalized":{"point":{"family":0,"k":4,"left":{"imag":-0.09687047050722311,"real":24.309417961903705},"n":8,"rho":2.0,"right":{"imag":-0.09687047050722312,"real":24.309417961903673}},"value":6.443959592708236e-16}},"sample_count":102,"shared_hat_error":{"kind":"sum","point":{"family":0,"j":0,"k":0,"n":2,"rho":1.0,"value":0.0},"value":0.0},"tensor_recurrence_error":{"max_abs":{"point":{"family":0,"left":0.9018154158213256,"n":2,"quantity":"A","rho":3.0,"right":0.901815415821326},"value":3.3306690738754696e-16},"max_normalized":{"point":{"family":0,"left":0.9018154158213256,"n":2,"quantity":"A","rho":3.0,"right":0.901815415821326},"value":1.1879841797587972e-16}}},"status":"PASS"}
````
<!-- REPRO-FILE-END -->
