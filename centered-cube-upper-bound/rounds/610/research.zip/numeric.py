"""R610 exact probability bridge and adjacent nested-cube formulas only."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1';os.environ['MKL_NUM_THREADS']='1'
from fractions import Fraction as Q
from math import comb
from pathlib import Path
import time,json,sys,platform,hashlib,resource
import sympy as sp
import flint
from flint import arb,ctx
START=time.perf_counter();ctx.prec=256

def A(q):
 q=Q(q);return arb(q.numerator)/q.denominator
def iv(q):return {'lo_exact':str(q.lower().fmpq()),'hi_exact':str(q.upper().fmpq()),'display':q.str(32)}
def direct(d,s):
 assert 0<s<1
 return sum((Q(comb(d,k))*s**k*(1-s)**(d-k)*abs(k-d*s) for k in range(d+1)),Q(0))/(s*(1-s))
def local(d,j,s):return 2*d*Q(comb(d-1,j))*s**j*(1-s)**(d-1-j)
def closed(d,s):
 if s==0 or s==1:return Q(2*d)
 return local(d,(d*s).numerator//(d*s).denominator,s)
def integral(d):
 assert d>=2 and d%2==0, "exact half-bridge implementation requires even d>=2"
 out=Q(0);pieces=[]
 for j in range(d//2):
  lo=Q(j,d);hi=Q(j+1,d);m=d-1-j
  value=sum((Q(2*d*comb(d-1,j)*comb(m,l))*(-1)**l*(hi**(j+l+1)-lo**(j+l+1))/Q(j+l+1) for l in range(m+1)),Q(0))
  assert value>0
  out+=value;pieces.append({'j':j,'lo':str(lo),'hi':str(hi),'integral_exact':str(value)})
 return out,pieces
rows=[]
for d in [2,4,8,16,32,64]:
 for s in [Q(1,10*d),Q(1,d),Q(1,4),Q(1,2),Q(d-1,d)]:assert direct(d,s)==closed(d,s)
 for j in range(1,d):
  s=Q(j,d);assert local(d,j-1,s)==local(d,j,s)==direct(d,s)
 assert local(d,0,Q(0))==2*d and local(d,d-1,Q(1))==2*d
 I,pieces=integral(d);bound=arb.pi()*A(d).sqrt()/2
 assert A(I)<bound
 rows.append({'stage':'initial' if d<=8 else 'expanded_dimension','d':d,'half_bridge_integral_exact':str(I),'half_bridge_integral':iv(A(I)),'integral_over_sqrt_d':iv(A(I)/A(d).sqrt()),'Cauchy_upper_pi_over_2_sqrt_d':iv(bound),'strict_upper_margin':iv(bound-A(I)),'polynomial_pieces':pieces,'direct_binomial_sum_equals_closed_formula':True,'all_integer_ds_interior_breakpoints_left_equals_right_exact':True,'endpoint_limits':'D(0+)=D(1-)=2d; endpoint signed measure derivative TV also 2d for disjoint probabilities'})
# Independent exact symbolic check of the endpoint density polynomials.
s=sp.symbols('s',positive=True)
assert sp.integrate(1/sp.sqrt(s*(1-s)),(s,0,sp.Rational(1,2)))==sp.pi/2
# The binomial positive-tail telescoping identity is proved in the report.
boundary=[{'d':8,'s':'0+','D_limit_exact':'16','guard':'endpoint treated separately, not singular quotient'},
 {'d':8,'s':'1-','D_limit_exact':'16','guard':'endpoint treated separately, not floor(d)=d'},
 {'d':8,'s':'1/4','ds':'2','left_polynomial_exact':str(local(8,1,Q(1,4))),'right_polynomial_exact':str(local(8,2,Q(1,4))),'direct_exact':str(direct(8,Q(1,4)))},
 {'d':16,'s':'1/2','ds':'8','left_polynomial_exact':str(local(16,7,Q(1,2))),'right_polynomial_exact':str(local(16,8,Q(1,2))),'direct_exact':str(direct(16,Q(1,2)))}]
cube_rows=[]
for d,N,label in [(2,2,'N=d'),(2,4,'N=d^2'),(2,400,'N=100d^2'),(8,8,'N=d'),(8,64,'N=d^2'),(8,6400,'N=100d^2'),(64,4096,'N=d^2'),(64,409600,'N=100d^2')]:
 ratio=Q(2*N+1,2*N+3);L1=2*(1-ratio**d)
 # Direct split into inner cube and annulus, normalized uniform densities.
 v0=(2*N+1)**d;v1=(2*N+3)**d
 split=Q(v0)*(Q(1,v0)-Q(1,v1))+Q(v1-v0,v1)
 assert split==L1 and 0<L1<2
 cube_rows.append({'d':d,'N':N,'scaling':label,'L1_exact':str(L1),'L1':iv(A(L1)),'N_times_L1':iv(A(N*L1)),'limiting_value_fixed_d':'2d='+str(2*d),'N_times_L1_over_2d':iv(A(N*L1/Q(2*d))),'direct_inner_annulus_split_residual':'0'})
# General fixed-integer-d limit uses finite binomial expansion in epsilon=2/(2N+3).
Nsym,dsym=sp.symbols('N d',positive=True)
assert sp.limit(2*Nsym*dsym*2/(2*Nsym+3),Nsym,sp.oo)==2*dsym
# Recovery obstruction for arbitrary correlated mixtures of old-interval/full-shell blocks.
tsym,delta_symbol=sp.symbols('t delta',positive=True)
sstar=tsym**2*delta_symbol/(1+tsym**2*delta_symbol)
assert sp.simplify(sstar/(1-sstar)-tsym**2*delta_symbol)==0
assert sp.simplify((1-sstar)*(1+tsym**2*delta_symbol)-1)==0
one_affinity=sp.sqrt(1-sstar)+tsym*sp.sqrt(delta_symbol)*sp.sqrt(sstar)
assert sp.simplify(one_affinity**2-(1+tsym**2*delta_symbol))==0
assert sp.simplify(sp.diff(sp.log(1+tsym**2*delta_symbol)-sp.log(1+tsym*delta_symbol),delta_symbol).subs(delta_symbol,0)-(tsym**2-tsym))==0
recovery_rows=[]
for dim,rootdim in [(16,4),(64,8),(256,16)]:
 for M,label in [(1,'M=1'),(rootdim,'M=sqrt(n)'),(dim,'M=n')]:
  delta=(arb(2).log()/M).exp()-1
  tvalue=A(Q(1,2));radius=1+tvalue*delta
  Hmax=((A(dim)/2)*((1+tvalue*tvalue*delta).log()-radius.log())).exp()
  L1lower=2*(1-Hmax)
  cost=2*M*(1-(-A(Q(dim,M))*arb(2).log()).exp())
  assert Hmax>0 and Hmax<1 and L1lower>0 and cost>0
  if M==dim:assert (cost-dim).contains(0)
  recovery_rows.append({'n':dim,'M':M,'regime':label,'t':'1/2','delta':iv(delta),'intermediate_radius':iv(radius),'s_star':iv(tvalue*tvalue*delta/(1+tvalue*tvalue*delta)),'Hellinger_affinity_max':iv(Hmax),'L1_distance_uniform_lower_bound':iv(L1lower),'endpoint_TV_total_cost':iv(cost),'cost_over_sqrt_n':iv(cost/A(dim).sqrt()),'cost_over_n':iv(cost/dim),'M_equals_n_cost_identity':('cost=n exact formula' if M==dim else 'not applicable')})
recovery={'assumptions':'Each coordinate label chooses uniform old interval length1 or uniform full outer shell length delta. Any probability law w_S over subsets is allowed, including correlated labels and mixtures pi. Intermediate actual cube has side1+t delta, t=1/2.','affinity_formula':'affinity=r^(-n/2) sum_S sqrt(w_S) t^|S| delta^(|S|/2)',
 'sharp_Cauchy_maximum':'Hmax=[(1+t^2 delta)/(1+t delta)]^(n/2); Cauchy uses sum w_S=1 and sum_S (t^2 delta)^|S|=(1+t^2 delta)^n',
 'optimizer':'w_S=(t^2 delta)^|S|/(1+t^2 delta)^n, equivalently independent labels with s_star=t^2 delta/(1+t^2 delta); arbitrary correlated/mixture labels cannot improve the maximum',
 'symbolic_optimizer_checks':'s_star/(1-s_star)=t^2 delta; (1-s_star)(1+t^2 delta)=1; [sqrt(1-s_star)+t sqrt(delta) sqrt(s_star)]^2=1+t^2 delta; all exact SymPy residual0',
 'L1_bound':'Every such mixture P obeys ||P-U_r||_1 >= 2(1-affinity(P,U_r)) >= 2(1-Hmax).',
 'equal_ratio_bridges':'M intervals cover side range[1,2], delta=2^(1/M)-1; total endpoint TV=2M(1-2^(-n/M)). Scaling preserves the norm.',
 'analytic_regimes':'For M->infinity, log Hmax = -(ln2)n/(8M)+O(n/M^2). M=sqrt(n) gives Hmax->0 and L1 lower bound->2, endpoint cost/sqrt(n)->2. M=n gives Hmax->2^(-1/8), lower bound->2(1-2^(-1/8)), endpoint cost=n exactly. Uniform approximation error->0 requires M/n->infinity, and then endpoint cost/n->2ln2. M=1 has Hmax=(5/6)^(n/2), endpoint cost->2.',
 'scope':'Excludes free recovery through uniform L1 approximation by these block mixtures plus additive total variation across equal-ratio bridges. Not a good-lambda/maximal recovery counterexample, not an all-scale weak-type bound.',
 'rows':recovery_rows}
out={'status':'PASS_BRIDGE_CUBE_AND_9_RECOVERY_AFFINITY_ROWS','bridge_formula':'D_d(s)=E|K-ds|/[s(1-s)] = 2d binom(d-1,floor(ds)) s^floor(ds)(1-s)^(d-1-floor(ds)), 0<s<1; endpoints TV derivative=2d separately. K~Bin(d,s).','bridge_assumptions':'mu,nu are mutually disjoint-support probability measures, lambda_s=(1-s)mu+s nu, product lambda_s^tensor d; score norm equals binomial count sum exactly.','rows':rows,'recovery':recovery,'boundary_checks':boundary,'cube_rows':cube_rows,'analytic_Cauchy_bound':'Var K=ds(1-s), hence D<=sqrt(d)/sqrt(s(1-s)); integral_0^(1/2) D ds <= (pi/2)sqrt(d). Exact symbolic scalar integral pi/2 checked.','cube_analytic_limit':'For fixed integer d, epsilon=2/(2N+3), 1-(1-epsilon)^d=d epsilon+O_d(epsilon^2); thus N*L1 -> 2d. Remainder is a finite binomial sum, not extrapolation of the table.','evidence_boundary':'Probability interpolation only, no cube all-scale embedding, no source/center Gram model, no general weak-type upper bound. Cube adjacent-average formula is a separate deterministic L1 computation. No p=1 use of an Lp theorem.','error_policy':'All binomial sums, breakpoint comparisons, polynomial integrals and cube norms are exact Fraction. Arb256 encloses conversions, sqrt/pi and normalizations. No sampling/quadrature or float sign decisions.','versions':{'python':platform.python_version(),'sympy':sp.__version__,'python_flint':flint.__version__},'interpreter':sys.executable,'command':[sys.executable,*sys.argv],'arb_bits':ctx.prec,'processes':1,'BLAS_threads':1,'runtime_seconds':time.perf_counter()-START,'peak_rss_bytes_macos':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
output=Path(sys.argv[1]) if len(sys.argv)>1 else Path('/tmp/ccu_r610_bridge_numeric.json');output.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'status':out['status'],'bridge':[{'d':r['d'],'I':r['half_bridge_integral']['display'],'I_over_sqrt_d':r['integral_over_sqrt_d']['display']} for r in rows],'seconds':out['runtime_seconds'],'script_sha256':out['script_sha256']},indent=2))
