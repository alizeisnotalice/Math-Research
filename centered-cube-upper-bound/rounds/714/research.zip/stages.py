"""R714 deep actual common-cell history, exact stage clocks and shared budget.

Only stages.json is written. Arb256/384 certificate; MacBook Decimal110 check
runs through stdin without installing software or writing remote files.
"""
from pathlib import Path
import hashlib,json,platform,socket,subprocess,sys
from flint import arb,ctx


def st(x):return x.str(38)


def floor_unique(x):
    v=x.floor().unique_fmpz();assert v is not None
    return int(v)


def calculate(b,K,bits,receiver_case='unit'):
    ctx.prec=bits;A=arb
    n=1<<b;a=32*n;clock=1<<(b//2);ln2=A(2).log();L=b*ln2;t=A(clock)/ln2
    beta=(-n*A(a).log()).exp();g=(-A(2)/a).log1p();h=1+A(1)/a
    log_sj=A(0) if receiver_case=='unit' else ln2+g
    sj=log_sj.exp()
    assert sj<2 and sj>=1
    W=-(n*g).expm1();endpoint=K*clock-beta
    J=floor_unique(endpoint/W);e=endpoint-J*W
    assert e>0 and e<W
    logR=ln2-(J+1)*g;R=logR.exp();logP=n*g-W/t
    alpha=-(-beta/t).expm1();alphaW=-(-W/t).expm1()
    # Every quantity here is scaled by the common R^n factor. Positive tail
    # formulas avoid subtracting almost identical gigantic prefix budgets.
    def tail(c):
        ell=floor_unique(c/W)
        assert ell<=J
        if ell==J:
            return (n*ell*g-c/t).exp()*(-(-(endpoint-c)/t).expm1())
        first=(n*ell*g-c/t).exp()*(-(-((ell+1)*W-c)/t).expm1())
        start=ell+1;count=J-start
        middle=(n*start*g-start*W/t).exp()*alphaW*(-(count*logP).expm1())/(-logP.expm1()) if count else A(0)
        last=(n*J*g-J*W/t).exp()*(-(-e/t).expm1())
        return first+middle+last
    trigger=(n*ln2-n*logR-endpoint/t).exp()*alpha
    receive_clock=(-2*n*ln2).exp()
    receiver=(-K*ln2+n*log_sj-n*logR).exp()*(-(-receive_clock/t).expm1())
    Dscaled=tail(A(0))+trigger+receiver
    Vscaled=-(n*J*g).expm1()+e*(n*J*g).exp()
    Vscaled+=(n*ln2+beta.log()-n*logR).exp()+(n*log_sj-2*n*ln2-n*logR).exp()
    shared=A(0);stage_rows=[]
    boundary_deficit=2*alpha+(beta/t).expm1()
    assert boundary_deficit>0 and boundary_deficit<1
    theoretical_price_log=t*(1-boundary_deficit)/(2*(n*h.log()).exp())-2
    assert theoretical_price_log>0
    for k in range(1,K+1):
        delta=A(2)**(-k);start=(k-1)*clock;end=k*clock
        # Eligibility uses exact clock ordinals i>=(k-1)N, never floating r.
        currency=(2**k)*(tail(A(start))+trigger+receiver)
        shared+=currency
        # Drop the first and last update, then use only complete shells wholly
        # inside the resulting stage. At k=K the deleted last update is trigger.
        first_layer=floor_unique(A(start)/W)+1
        stop_layer=floor_unique((end-beta)/W)
        assert first_layer<stop_layer
        full_stage_mass=(-first_layer*W/t).exp()*(-(-(stop_layer-first_layer)*W/t).expm1())
        norm_interior=full_stage_mass/delta
        edge=norm_interior*(-W/t).exp()/(a*W)
        assert norm_interior>0 and norm_interior<1 and edge>0
        stage_radius=(logR+floor_unique(A(start)/W)*g).exp()
        log_defect=1024*L+n*((4*stage_radius*(A(4)/n+A(1)/a)).log()-log_sj)
        assert log_defect<0
        ell_first=floor_unique((A(start)+beta)/W)
        ell_last=floor_unique((A(end)-2*beta)/W)
        actual_price_log=n*g*(ell_first-ell_last)+(clock-3*beta)/t
        assert actual_price_log>=theoretical_price_log
        first_price_log=n*(ln2+logR+ell_first*g)-A(start)/t-beta/t
        last_price_log=n*(ln2+logR+ell_last*g)-A(end)/t+2*beta/t
        next_gap=None
        if k<K:
            ell_next=floor_unique((A(end)+beta)/W)
            # Preserve the exact tiny clock gap instead of subtracting big logs.
            next_gap=n*g*(ell_last-ell_next)+3*beta/t
            assert next_gap>0
        # All legal first-global-crossing cells contain every prefix update.
        # Thus their stage-difference pools and trimmed pools coincide exactly.
        stage_rows.append({'k':k,'delta_exact':f'2^-{k}',
                           'first_cross_update_count_symbolic':f'{k}*sqrt(n)*a^n',
                           'stage_ordinals_symbolic':f'[{k-1}*N,{k}*N-1]',
                           'global_load_at_first_cross_exact':f'1-2^-{k}',
                           'normalized_theta_sum_exact':'1',
                           'trimmed_normalized_sum_formula':'1-2*(1-exp(-beta/t))-(exp(beta/t)-1)',
                           'log10_trimmed_normalized_deficit':st(boundary_deficit.log()/A(10).log()),
                           'complete_shell_layer_count':str(stop_layer-first_layer),
                           'normalized_complete_shell_mass':st(norm_interior),
                           'normalized_edge_type_weight_lower':st(edge),
                           'max_stage_source_radius':st(stage_radius),
                           'first_internal_price_log':st(first_price_log),
                           'last_internal_price_log':st(last_price_log),
                           'actual_first_over_last_price_log':st(actual_price_log),
                           'theoretical_first_over_last_price_log_lower':st(theoretical_price_log),
                           'actual_over_theoretical_price_log':st(actual_price_log/theoretical_price_log),
                           'log_previous_last_over_next_first':st(next_gap) if next_gap is not None else None,
                           'stage_full_menu_Hall_log10_relative_defect_upper':st(log_defect/A(10).log()),
                           'stage_source_currency_scaled_by_Rn':st(currency),
                           'all_stage_menus_same_pool':True,'selected_origin':'0'})
    ratio=shared*t/Vscaled
    assert ratio<4 and ratio>1
    # Original half-threshold R_high uses only the first N early updates.
    half_layers=floor_unique(A(clock)/W)
    full_half_mass=-(-half_layers*W/t).expm1()
    q0=3*b//16+1
    nf=max(0,floor_unique(A(a)/2*(A('.25')/R-A('.05'))-1))
    p=A(nf)/a;B=n//2;mass=(B*(-p).log1p()).exp();tailprob=mass
    for j in range(1,q0):
        mass*=A(B+1-j)/j*p/(1-p);tailprob+=mass
    bad=full_half_mass*(W/t).exp()*2*tailprob/W
    high_lower=full_half_mass-bad
    assert high_lower>A('.49') and high_lower<A('.5')
    assert A('.05')>A(6)/n and 2*q0*ln2>A('.375')*L
    assert R<2*h*n/L
    assert R>2 and R*(J*g).exp()>2
    assert (R*((J+1)*g).exp()-2).contains(0)
    logVT=n*(log_sj-ln2);logD=n*ln2+n*logR+Dscaled.log()
    logV=n*ln2+n*logR+Vscaled.log();logratio=logD-logVT
    norm_upper=(-logratio-A(4*clock).log())/A(10).log()
    norm_lower=((high_lower-A('.25')).log()-A(clock).log()-logratio)/A(10).log()
    # The actual receiving residual is <=2^-K, including the exactly first row.
    assert beta/t<ln2
    # Same origin matches every selected stage source to every actual receiver.
    # Each source charge is at most (s_j/8)^n times its normalized source value.
    all_stage_charge=K # before optional boundary deletion, in units of VT
    log_direct_stage_upper=n*(log_sj-3*ln2)+shared.log()+n*ln2+n*logR
    assert log_direct_stage_upper>=A(all_stage_charge).log()+logVT
    first_pool_last_layer=floor_unique((A(clock)-beta)/W)
    min_volume_log=n*(logR+first_pool_last_layer*g-log_sj)
    min_volume_theory=-K*ln2+(K-1)*theoretical_price_log
    assert min_volume_log>=min_volume_theory
    return {'b':b,'n':f'2^{b}','K':K,'receiver_case':receiver_case,'receiver_radius':st(sj),
            'receiver_entry_residual_exact':f'2^-{K}',
            't_definition':'sqrt(n)/log2','unique_local_interpreter':sys.executable,
            'J':str(J),'R':st(R),'original_high_q0':q0,'original_high_favorable_digits':str(nf),
            'original_half_threshold_high_weight_lower_every_owner_point':st(high_lower),
            'original_half_threshold_high_weight_upper':'1/2',
            'V':st(logV.exp()),'VT_exact':f'2^-{n}' if receiver_case=='unit' else f'(1-2/a)^{n}',
            'VT':st(logVT.exp()),'D':st(logD.exp()),
            'shared_currency_over_V_over_t':st(ratio),
            'shared_currency_over_4V_over_t':st(ratio/4),
            'shared_currency_over_naive_KV_over_t':st(ratio/K),
            'shared_currency_log10':st((shared.log()+n*ln2+n*logR)/A(10).log()),
            'log10_original_normalized_excess_lower':st(norm_lower),
            'log10_VT_over_4sqrt_n_D':st(norm_upper),
            'per_source_stage_charge_currency_factor_exact':f'(s_j/8)^{n}',
            'first_half_pool_min_di_over_dj_log':st(min_volume_log),
            'first_half_pool_min_di_over_dj_theoretical_log_lower':st(min_volume_theory),
            'first_half_min_volume_log_over_Kminus1_sqrt_n':st(min_volume_log/((K-1)*clock)),
            'stage_2_through_K_price_intervals_strictly_decreasing':True,
            'all_untrimmed_stages_receiving_charge_exact':f'{K}*VT',
            'all_stage_centers_singleton':'{0}',
            'stage_rows':stage_rows,'precision_bits':bits,
            '_values':(ratio,high_lower,logratio,norm_upper,min_volume_log,theoretical_price_log),
            '_remote_values':[float(ratio),float(high_lower),float(logratio),float(norm_upper),float(min_volume_log)]}


REMOTE=r'''
from decimal import Decimal as D,localcontext,MAX_EMAX,MIN_EMIN
import json,socket,sys
with localcontext() as c:
 c.prec=110;c.Emax=MAX_EMAX;c.Emin=MIN_EMIN
 rows=[]
 for b in [16,32,64]:
  for K in [4,8,16]:
   n=1<<b;a=32*n;clock=1<<(b//2);l2=D(2).ln();L=D(b)*l2;t=D(clock)/l2
   g=(1-D(2)/a).ln();W=1-(D(n)*g).exp();J=int(D(K*clock)/W);e=D(K*clock)-J*W
   logR=l2-D(J+1)*g;logP=D(n)*g-W/t;alphaW=1-(-W/t).exp()
   def tail(start):
    ell=int(D(start)/W)
    first=(D(n*ell)*g-D(start)/t).exp()*(1-(-(D(ell+1)*W-D(start))/t).exp())
    lower=ell+1;count=J-lower
    PJ=(D(count)*logP).exp() if D(count)*logP>-1000 else D(0)
    middle=(D(n*lower)*g-D(lower)*W/t).exp()*alphaW*(1-PJ)/(1-logP.exp()) if count else D(0)
    last=(D(n*J)*g-D(J)*W/t).exp()*(1-(-e/t).exp())
    return first+middle+last
   Vscaled=1-(1-e)*(D(n*J)*g).exp()
   Dscaled=tail(0)
   shared=sum(D(2**k)*tail((k-1)*clock) for k in range(1,K+1))
   ratio=shared*t/Vscaled
   half=int(D(clock)/W);high=1-(-D(half)*W/t).exp()
   for receiver_case in ['unit','near_trigger']:
    logsj=D(0) if receiver_case=='unit' else l2+g
    logratio=D(n)*logR+Dscaled.ln()+2*D(n)*l2-D(n)*logsj
    norm=(-logratio-D(4*clock).ln())/D(10).ln()
    minvolume=D(n)*(logR+D(half)*g-logsj)
    rows.append({'b':b,'K':K,'receiver_case':receiver_case,'J':str(J),'values':[str(ratio),str(high),str(logratio),str(norm),str(minvolume)]})
 print(json.dumps({'host':socket.gethostname(),'python':sys.version,'backend':'Decimal110 approximate; beta0,receiver clock and negligible high failure omitted','rows':rows}))
'''


def main():
    rows=[]
    for b in [16,32,64]:
        for K in [4,8,16]:
            for receiver_case in ['unit','near_trigger']:
                low=calculate(b,K,256,receiver_case);high=calculate(b,K,384,receiver_case)
                assert low['J']==high['J'] and low['original_high_favorable_digits']==high['original_high_favorable_digits']
                for x,y in zip(low['_values'],high['_values']):assert x.overlaps(y)
                del high['_values'];rows.append(high)
    command=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=5','macbook-math','/Users/zhengzhihao/.venv/bin/python -B -']
    run=subprocess.run(command,input=REMOTE,text=True,capture_output=True,timeout=40)
    remote={'command':command,'exit_code':run.returncode,'stderr':run.stderr}
    if run.returncode==0:
        remote['result']=json.loads(run.stdout)
        for local,other in zip(rows,remote['result']['rows']):
            assert local['b']==other['b'] and local['K']==other['K'] and local['J']==other['J'] and local['receiver_case']==other['receiver_case']
            for x,y in zip(local['_remote_values'],other['values']):assert abs(x-float(y))<=max(1e-12,abs(x)*1e-12)
        remote['crosscheck_passed']=True
    else:remote['stdout']=run.stdout
    for row in rows:del row['_remote_values']
    result={'host':socket.gethostname(),'python':sys.executable,'python_version':platform.python_version(),
            'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'rows':rows,'remote':remote,
            'history':['Unfolded R713 shells with total clock K*sqrt(n). Early label count K*N-1 where N=sqrt(n)*a^n, terminal trigger Q(0,2) is update K*N. Each full owner has v_i/d_i=beta0=a^-n.',
                       'All parents contain the same positive origin cell. Early radii>2, trigger2, receivers radius1 or2*rho<2 give the actual greedy shell/lex order. Residual after update h is exactly2^(-h/N). Receiver entry residual is2^-K.',
                       'Receivers have full tiny cores tiling the signed rectangle scaled by s_j. The two pressure cases have s_j=1 or2*rho. VT=(s_j/2)^n, and receiver raw clock remains4^-n. V includes every early core, trigger core and receiver core; D scales only its receiving term by s_j^n.',
                       'Every dyadic stage k first crosses global load1-delta_k exactly at integer update k*N. Global total load equals this threshold. Any positive legal threshold cell must contain every positive prefix update, so all stage menus have identical pools, including origin.',
                       'Stage k is source ordinals[(k-1)N,kN-1]. Its exact theta sum is delta_k. We conservatively delete its first and last updates. The normalized deficit is2*(1-exp(-beta0/t))+exp(beta0/t)-1, recorded logarithmically.',
                       'At k=K the last deleted update is the terminal trigger. Complete shell layers strictly inside each trimmed interval remain; every such layer has both extreme coordinate edge types.'],
            'shared_currency':['Define delta_k=2^-k and S=sum_{i,k}d_i theta_i/delta_k *1_{r_i<=2delta_k}. Capacity equality is determined by integer clocks, never by rounded Arb comparison.',
                               'For each source t*d_i*theta_i<=v_i*r_i. The geometric sum r_i*sum_{eligible k}delta_k^-1 is<=4. Therefore S<=4V/t for the same complete source budget.',
                               'Numerically S is computed as sum_k2^k times the actual source-budget tail starting at clock(k-1)*sqrt(n), plus trigger and all receiving sources. Positive compressed tail formulas avoid catastrophic cancellation.',
                               'The program reports S/(V/t), S/(4V/t), and S/(K*V/t), displaying the saving compared with a fresh V/t budget for every stage.'],
            'high_Hall_matching':['Original R_high remains the R706 half-threshold integral. Its origin first-hit pool is exactly the firstN early donors; it is not the full deep pool and not the terminal trigger pool.',
                                  'Original high lower uses complete shells before the first half crossing and binomial opposite-sign exterior conflicts, uniformly for every point of every actual receiving owner.',
                                  'For s_j=2*rho>1 the old s_j=1 favorable-digit bound remains conservative; original intervals have opposite signs around0 regardless of the larger u=h*s_j. Both scaled owner rectangles remain inside the radius2 cavity.',
                                  'Every selected stage menu consists of all positive cells at that stage first global crossing. All such cells contain the entire prefix; stage-difference pools after deletion coincide on every menu cell. This is not an assertion about arbitrary later enlarged menus.',
                                  'Complete interior stage shells contain both extreme coordinate types. Their expanded intersections, including the union over all legal stage menu cells, lie in Q(0,R_stage*(4/n+1/a)). Stage Hall relative defect is bounded by n^1024*(4R_stage*(4/n+1/a)/s_j)^n.',
                                  'All stages share the same physical origin by construction. For any actual source in a stage, its normalized receiving charge is theta_i/delta_k*VT<=(s_j/8)^n*d_i*theta_i/delta_k because s_i>=2.',
                                  'Summing normalized stage charges uses at most(s_j/8)^n*S<=4*(s_j/8)^n*V/t; source budgets are shared, not issued independently K times. The center bag remains the singleton{0}.'],
            'price_certificate':['For each trimmed stage the first internal ordinal is(k-1)N+1 and last is kN-2. True prices are d_i*r_i. Their log ratio is computed directly from exact clock differences and integer shell indices.',
                                 'Every actual internal price log ratio is at least t*(1-boundary_loss)/(2*h^n)-2, with the same conservative boundary loss used in the normalized stage sum.',
                                 'Adjacent stage intervals strictly descend. The gap between previous last and next first is computed as n*g*(ell_last-ell_next)+3*beta0/t, preserving even astronomically tiny positive gaps without subtracting rounded absolute logs.',
                                 'The original half-pool minimum d_i/d_j has log at least -K*log2+(K-1)*(t*(1-boundary_loss)/(2*h^n)-2). The near-trigger receiver case removes the artificial n*log2 excess: the actual log is Theta((K-1)*sqrt(n)), as directly reported.'],
            'scope':['Eighteen genuine finite histories with b16,32,64 and K4,8,16, each with two receiving radii; no simulation substitutes for actual tiny owners or clock thresholds.',
                     'All local reported enclosures use Arb384, crosschecked against256 bits with identical certified floors. Tiny strict boundary qualifications are proved by exact integer clocks, not inferred from overlapping intervals.',
                     'Remote Decimal110 is an independent approximate check with explicitly negligible terms omitted, not the rigorous certificate.',
                     'All stage origins coincide intentionally; this experiment gives no independence claim for general unrelated histories.',
                     'Only stages.py and stages.json are written in this folder; no Git changes, no remote files, and no launched process remains.']}
    output=Path(__file__).with_name('stages.json');output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'output':str(output),'remote_exit':run.returncode,'remote_crosscheck':remote.get('crosscheck_passed',False),
                      'rows':[{k:r[k] for k in ['b','K','receiver_case','shared_currency_over_V_over_t','first_half_pool_min_di_over_dj_log','first_half_pool_min_di_over_dj_theoretical_log_lower','first_half_min_volume_log_over_Kminus1_sqrt_n']} for r in rows]},indent=2))


if __name__=='__main__':main()
