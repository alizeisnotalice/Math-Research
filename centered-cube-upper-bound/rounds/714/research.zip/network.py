"""Exact cuts for small stage-choice networks, checked against integer maxflow."""
from itertools import product
from random import Random
from scipy.sparse import csr_matrix
from scipy.sparse.csgraph import maximum_flow

def verify(rng, rows, stages, demand):
    volumes=[rng.randint(1,9) for _ in range(rows)]
    # Within a stage, shared spatial atom; all stages share the last two source labels.
    caps=[rng.randint(0,4) for _ in range(stages+2)]
    edges=[]
    free=set()
    for j,k in product(range(rows),range(stages)):
        idx=j*stages+k
        edges.append({v for v in (k,stages,stages+1) if rng.random()<.4})
        if rng.randrange(13)==0: free.add(idx)
    big=1+demand*sum(volumes)
    start=1+rows; dest=start+len(edges); end=dest+len(caps)
    graph=[[0]*(end+1) for _ in range(end+1)]
    for j,v in enumerate(volumes):
        graph[0][j+1]=demand*v
        for k in range(stages):
            idx=j*stages+k; node=start+idx
            graph[j+1][node]=v
            if idx in free: graph[node][end]=big
            for h in edges[idx]: graph[node][dest+h]=big
    for h,v in enumerate(caps): graph[dest+h][end]=v
    expected=demand*sum(volumes)-int(maximum_flow(csr_matrix(graph),0,end).flow_value)
    # For fixed sink set, put every compatible stage on the row side, and choose
    # each row iff its resulting contribution is positive.
    defects=[]
    for mask in range(1<<len(caps)):
        sinks={h for h in range(len(caps)) if mask&(1<<h)}
        val=-sum(caps[h] for h in sinks)
        for j,v in enumerate(volumes):
            retained=sum((i not in free and edges[i]<=sinks) for i in range(j*stages,(j+1)*stages))
            val+=max(0,demand-stages+retained)*v
        defects.append(val)
    assert expected==max(defects)
    return expected
rng=Random(714)
for rows,stages in ((3,3),(6,5),(9,8)):
    for m in sorted({1,2,stages}):
        vals=[verify(rng,rows,stages,m) for _ in range(40)]
        print(rows,stages,m,len(vals),sum(v>0 for v in vals),max(vals))
