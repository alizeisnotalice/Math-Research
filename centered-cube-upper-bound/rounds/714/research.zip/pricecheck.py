"""Check the continuous-depth law against full first-pool minima in stages.json."""
import json
from pathlib import Path
from flint import arb,ctx
ctx.prec=384
data=json.loads(Path(__file__).with_name('stages.json').read_text())
for row in data['rows']:
    b,K=row['b'],row['K']
    n=1<<b
    t=arb(1<<(b//2))/arb(2).log()
    h=1+arb(1)/(32*n)
    # Include every possible later receiver update in the upper limit on depth.
    x=(K-1)*arb(2).log()+(-2*n*arb(2).log()).exp()/t
    coefficient=t/h**n-7*t.sqrt()
    assert coefficient>0
    upper_for_predicted=coefficient*x-6
    actual=arb(row['first_half_pool_min_di_over_dj_log'])
    assert actual>upper_for_predicted
    if K==16:
        print(b,row['receiver_case'],(upper_for_predicted/actual).str(12))
print('verified',len(data['rows']))
