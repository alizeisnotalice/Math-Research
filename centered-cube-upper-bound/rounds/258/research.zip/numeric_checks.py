#!/usr/bin/env python3
"""R258 bounded finite-law signed-ledger diagnostics, not FULL."""
import argparse,hashlib,json,math
from pathlib import Path
from fractions import Fraction as F
import mpmath as mp
NAMES=['P','N','NE','U','S','R','drift']
PSI=[[1,0],[1,1]]
THETA=[[F(1,2),F(0)],[F(1),F(1,3)]]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def fs(x):return str(x.numerator)+'/'+str(x.denominator)
def enc(x):return mp.nstr(x,50)
def m(x):return mp.mpf(x.numerator)/x.denominator if isinstance(x,F)else mp.mpf(x)
def prod(a):
    v=1
    for x in a:v*=x
    return v

def models():
    patterns=[[F(0)],[F(1,2),F(1)],[F(1),F(2)],[F(0),F(1,4)],[F(0),F(1,4)],[F(2),F(1,2)]]
    massmenus=[[F(1),F(2,3),F(3,2),F(1,2),F(1,4),F(2)],[F(1,100),F(3),F(2),F(1,1000),F(100),F(1,10)],[F(1,10**8),F(1),F(1,100),F(2),F(10**6),F(1,10**4)]]
    rows=[]
    for phase,n,masses in zip(['initial','stress','expanded'],[2,8,32],massmenus):
        sources=[]
        for i,p in enumerate(patterns):sources.append({'id':i,'terminal_class':'B'if i<2 else'G'if i<4 else'E','mass':masses[i],'distances':[p[j%len(p)]for j in range(n)],'delete':None if i<4 else F(1,2)if i==4 else F(3,4)})
        rows.append({'phase':phase,'n':n,'sources':sources})
    return rows

def law_at(sources,thresholds,t,kind='fraction',before=False):
    weights=[];scores=[]
    for src,A in zip(sources,thresholds):
        alive=src['delete']is None or (t<=src['delete']if before else t<src['delete'])
        weights.append(src['mass']*prod(min(1,a/t)for a in A)if alive else 0)
        scores.append(sum(a<t for a in A))
    e=sum(weights);assert e>0
    pi=[w/e for w in weights]
    return weights,scores,e,pi

def terms(pi,k,theta=THETA):
    z={name:0 for name in NAMES}
    for gi,c in enumerate([2,3]):
        for bi,b in enumerate([0,1]):
            D=k[c]-k[b];v=pi[c]*pi[b];positive=max(0,D);negative=max(0,-D);psi=PSI[gi][bi];th=theta[gi][bi]
            z['P']+=v*psi*th*positive;z['N']+=v*psi*negative;z['S']+=v*(1-psi)*D;z['R']+=v*psi*(1-th)*positive;z['drift']+=v*D
    for c in [4,5]:
        for b in [0,1]:
            D=k[c]-k[b];v=pi[c]*pi[b];z['NE']+=v*max(0,-D);z['U']+=v*max(0,D);z['drift']+=v*D
    return z

def rational_checks(model):
    sources=model['sources'];lookup={F(0):F(1),F(1,4):F(7,8),F(1,2):F(5,8),F(1):F(1,8),F(2):F(1,32)}
    A=[[lookup[d]for d in src['distances']]for src in sources]
    if model['n']==8:A[4][0]=F(1,2) # birth/delete coincidence only in abstract rational diagnostic
    events=sorted({F(1,4),F(1)}|{a for aa in A for a in aa if F(1,4)<a<1}|{src['delete']for src in sources if src['delete']is not None})
    mids=[]
    for lo,hi in zip(events,events[1:]):
        t=(lo+hi)/2;w,k,e,pi=law_at(sources,A,t);z=terms(pi,k);eB=w[0]+w[1];kB=k[0]*w[0]+k[1]*w[1]
        derivative=(eB*sum(x*y for x,y in zip(w,k))-e*kB)/e**2
        assert derivative==z['drift']
        assert z['P']-z['N']-z['NE']==derivative-z['U']-z['S']-z['R']
        for eta in [F(0),F(1,2),F(1)]:assert eta*(z['P']-z['N']-z['NE'])==eta*(derivative-z['U']-z['S']-z['R'])
        mids.append({'left':fs(lo),'right':fs(hi),'midpoint':fs(t),'k':k,'posterior':list(map(fs,pi)),'quotient_derivative':fs(derivative),'ledger':{name:fs(F(v))for name,v in z.items()}})
    jumps=[]
    for t in [F(1,2),F(3,4)]:
        wb,_,eb,_=law_at(sources,A,t,before=True);wa,_,ea,_=law_at(sources,A,t);FBb=(wb[0]+wb[1])/eb;FBa=(wa[0]+wa[1])/ea;r=eb-ea;formula=(wb[0]+wb[1])*r/(eb*ea)
        assert FBa-FBb==formula>=0
        jumps.append({'time':fs(t),'removed_mass_weight':fs(r),'jump':fs(formula)})
    return {'n':model['n'],'phase':model['phase'],'thresholds':[[fs(x)for x in aa]for aa in A],'midpoints':mids,'jumps':jumps,'scope':'Independent rational product-clock algebra template, not the actual C kernel or a certified approximation of it.'}

def overlap_C(d):
    E=lambda x:mp.expint(4,x)
    def iphi(x):
        return x+E(mp.mpf('.5')+x)-E(mp.mpf('.5')-x)if x<=mp.mpf('.5')else mp.mpf('.5')-E(x-mp.mpf('.5'))+E(x+mp.mpf('.5'))
    x=m(d)
    return max(mp.mpf(0),1-x)+iphi(x+mp.mpf('.5'))-iphi(max(mp.mpf('.5'),x-mp.mpf('.5')))

def actual_law(model,dps):
    with mp.workdps(dps):
        sources=[{**s,'mass':m(s['mass']),'delete':None if s['delete']is None else m(s['delete'])}for s in model['sources']]
        lookup={d:overlap_C(d)for s in model['sources']for d in s['distances']};A=[[lookup[d]for d in s['distances']]for s in model['sources']]
        tau=mp.mpf('.25');g=mp.mpf(1);events=sorted({tau,g}|{a for aa in A for a in aa if tau<a<g}|{s['delete']for s in sources if s['delete']is not None})
        totals={key:mp.mpf(0)for key in NAMES};segments=[]
        theta=[[m(v)for v in row]for row in THETA]
        for left,right in zip(events,events[1:]):
            mid=(left+right)/2;weights,k,e,pi=law_at(sources,A,mid);alive=[src['delete']is None or mid<src['delete']for src in sources]
            coeff=[src['mass']*prod(a for a in aa if a<mid)if alive[i]else mp.mpf(0)for i,(src,aa)in enumerate(zip(sources,A))]
            # Repeated-coordinate thresholds multiply as repeated factors in coeff.
            def integrand(t,key):
                ww=[cc*t**(-kk)for cc,kk in zip(coeff,k)];ee=sum(ww);pp=[v/ee for v in ww]
                return terms(pp,k,theta)[key]/t
            vals={key:mp.quad(lambda t:integrand(t,key),[left,right])for key in NAMES}
            point=terms(pi,k,theta);assert abs(point['P']-point['N']-point['NE']-point['drift']+point['U']+point['S']+point['R'])<mp.mpf('1e-32')
            for key in NAMES:totals[key]+=vals[key]
            segments.append({'left':enc(left),'right':enc(right),'alive':alive,'scores':k,'integrals':{key:enc(v)for key,v in vals.items()}})
        def FB(t,before=False):
            w,k,e,pi=law_at(sources,A,t,before=before);return pi[0]+pi[1]
        jumps=[];jump_values=[]
        for t in [mp.mpf('.5'),mp.mpf('.75')]:
            wb,_,eb,_=law_at(sources,A,t,before=True);wa,_,ea,_=law_at(sources,A,t);removed=eb-ea;jump=(wb[0]+wb[1])*removed/(eb*ea)
            assert jump>=0 and abs(FB(t)-FB(t,True)-jump)<mp.mpf('1e-32')
            jump_values.append(jump);jumps.append({'time':enc(t),'removed_weight':enc(removed),'jump':enc(jump)})
        start=FB(tau);end=FB(g,True);js=sum(jump_values)
        lhs=totals['P']-totals['N']-totals['NE'];rhs=end-start-js-totals['U']-totals['S']-totals['R'];res=lhs-rhs
        assert abs(res)<mp.mpf('1e-30')and abs(totals['drift']-(end-start-js))<mp.mpf('1e-30')
        rows=[]
        for eta in [mp.mpf(0),mp.mpf('.5'),mp.mpf(1)]:rows.append({'eta':enc(eta),'weighted_lhs':enc(eta*lhs),'weighted_rhs':enc(eta*rhs),'residual':enc(eta*res)})
        return {'phase':model['phase'],'n':model['n'],'C_values':{fs(d):enc(v)for d,v in sorted(lookup.items())},'segments':segments,'totals':{k:enc(v)for k,v in totals.items()},'FB_start':enc(start),'FB_end':enc(end),'deletions':jumps,'lhs':enc(lhs),'rhs':enc(rhs),'residual':enc(res),'near_rows':rows,'scope':'Actual C(d) overlap weights, finite atomic law with arbitrary terminal B/G; not original Q-good/bad qualification, not L1 FULL/history.'}

def gates(dps):
    with mp.workdps(dps):
        zeta=mp.sqrt(1-mp.exp(-4)/4);c=1-zeta;rows=[]
        for n in [2,32,512,10**6,10**8,10**9,10**12]:
            lower=-mp.expm1(-mp.log(2)/n);dn=1000*mp.sqrt(mp.log(n+2)/n);upper=1-dn;strong=2*mp.log(n)/(c*n)
            rows.append({'n':n,'original_lower_open':enc(lower),'d_n':enc(dn),'original_upper_closed':enc(upper),'original_soft_range_nonempty':lower<upper,'MG7_strong_threshold':enc(strong),'MG7_original_intersection_nonempty':max(lower,strong)<=upper and lower<upper,'lower_covers_MG7_threshold':lower>=strong})
        tail=[]
        for n in [2,32,512,10**6,10**9]:
            k0=int(mp.ceil(2*mp.log(n)/abs(mp.log(zeta))));empty=k0>n;row={'n':n,'k0':k0,'empty_high_label_tail':empty,'scope':'Soft-mixture label count is not the original overlap score.'}
            if not empty:
                factor=mp.exp(mp.log(n)+mp.mpf(k0)*mp.log(zeta)/2);assert factor<=1
                checks=[]
                for k in sorted({k0,(n+k0)//2,n}):
                    ss=mp.mpf(k)/n
                    if k==n:logprob=mp.mpf(0)
                    else:
                        with mp.extradps(20):logbinom=mp.loggamma(n+1)-mp.loggamma(k+1)-mp.loggamma(n-k+1)
                        logprob=logbinom+k*mp.log(ss)+(n-k)*mp.log1p(-ss)
                    loglhs=logprob+k*mp.log(zeta);logrhs=k0*mp.log(zeta);assert loglhs<=logrhs
                    checks.append({'k':k,'s_maximizer':enc(ss),'log_binomial_weighted_lhs':enc(loglhs),'log_tail_bound':enc(logrhs)})
                row.update({'n_zeta_to_k0_half':enc(factor),'selected_k_checks':checks})
            tail.append(row)
        return {'zeta':enc(zeta),'original_soft_gate_rows':rows,'high_label_tail_rows':tail}

def numericfields(obj,prefix=''):
    out={}
    if isinstance(obj,dict):
        for k,v in obj.items():
            if isinstance(v,str):
                try:out[prefix+k]=mp.mpf(v)
                except ValueError:pass
            elif isinstance(v,(dict,list)):out.update(numericfields(v,prefix+k+'/'))
    elif isinstance(obj,list):
        for i,v in enumerate(obj):out.update(numericfields(v,prefix+str(i)+'/'))
    return out

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));ap.add_argument('--contract',type=Path,default=Path(__file__).with_name('task_contract.md'));a=ap.parse_args();models0=models();rat=[rational_checks(v)for v in models0];lo={'actual_laws':[actual_law(v,40)for v in models0],'scalar':gates(40)};hi={'actual_laws':[actual_law(v,70)for v in models0],'scalar':gates(70)}
    with mp.workdps(100):
        x=numericfields(lo);y=numericfields(hi);assert x.keys()==y.keys();diff=[abs(x[k]-y[k])/max(1,abs(y[k]))for k in x];maxdiff=enc(max(diff));assert max(diff)<mp.mpf('1e-28')
    geometry=[{'phase':v['phase'],'n':v['n'],'sources':[{'id':s['id'],'terminal_class':s['terminal_class'],'mass':fs(s['mass']),'distances_from_y0':list(map(fs,s['distances'])),'delete':None if s['delete']is None else fs(s['delete'])}for s in v['sources']]}for v in models0]
    result={'schema':'R258-signed-near-ledger-v1','script_sha256':sha(__file__),'contract_sha256':sha(a.contract),'counts':{'actual_overlap_laws':3,'rational_midpoint_checks':sum(len(v['midpoints'])for v in rat),'rational_jump_checks':sum(len(v['jumps'])for v in rat),'actual_interval_records_per_precision':sum(len(v['segments'])for v in hi['actual_laws']),'actual_deletion_records_per_precision':6,'original_soft_gate_rows':7,'high_label_tail_rows':5,'nonempty_label_tail_k_checks_per_precision':sum(len(v.get('selected_k_checks',[]))for v in hi['scalar']['high_label_tail_rows']),'precision_fields_compared':len(diff)},'source_geometry':geometry,'suffix_Psi':PSI,'capture_theta':[[fs(v)for v in r]for r in THETA],'near_definition':{'D':'1/4','y':'all zero','eta1':'z=terminal B0=all zero, l1 distance=0','eta0':'z=terminal B1, l1 distance>=1/2>D/2','eta_half':'artificial linear split check, not a distance indicator','scope':'All near factors are row constants; every boundary, deletion and signed term is multiplied identically.'},'rational_checks':rat,'mp40':lo,'mp70':hi,'precision_max_relative_difference':maxdiff,'scope':'Finite overlap-weight laws and scalar implementation checks, not FULL or a general proof. Rational templates are distinct from actual C kernel. Ordinary mp quadrature is non-interval.'}
    a.output.write_text(json.dumps(result,ensure_ascii=False,sort_keys=True,indent=2)+'\n');print(json.dumps({'counts':result['counts'],'maxdiff':maxdiff}))
if __name__=='__main__':main()
