# R258: the original clock score and the soft-coordinate kernel law

This bounded source audit distinguishes the original auxiliary posterior
from a latent representation of its receiver kernel. It proves an exact
conditional-label identity and a genuine FIRST-weighted posterior bridge.
The latter retains its full importance/normalization cost. It does not
prove that low actual softness pays the original positive Gini.

## PB1. Exact original objects and qualifications

| Frozen original reference | Formula and quantifier |
|---|---|
| [R116 astra_first.md:9–16](/Users/zhengzhihao/Desktop/T/output/centered_cube_round116_20261014/astra_first.md:9) | `h=1[-1/2,1/2]`, `w(u)=integral_0^1 exp(-|u|/r)dr`, `phi=h*w`; both w and phi integrate to one. `P_s,L(x-y)=L^-n product_i f_s((x_i-y_i)/L)`, `f_s=(1-s)h+s phi`. One common scalar s is used. |
| [R113 coupled_transport.md:51–72](/Users/zhengzhihao/Desktop/T/output/centered_cube_round113_20261014/coupled_transport.md:51) | Beta is an actual residual of the soft input alpha under the coupled source transport. The actual hard tail nu is retained and satisfies `nu<=beta<=alpha`. These are spatial source submeasures, not distributions of soft-coordinate labels. |
| [R117 joint_geometry.md:9–23](/Users/zhengzhihao/Desktop/T/output/centered_cube_round117_20261014/joint_geometry.md:9) | Fix original seed, leaf V, source y and ratio index j. `A_i(y,v)=b C(|y_i-v_i|/b)/c_j`, `w_t(y,v)=product_i min(1,A_i/t)`, `Z_t=D_V(y) intersect (T_0(y) minus A_(j,t)(y))`, `Pi_t=1_Zt w_t nu_V/e_t`, `e_t=integral_Zt w_t nu_V`. The capital forbidden block A_(j,t) is different from the scalar coordinate threshold A_i. |
| [R116 astra_first.md:17–22](/Users/zhengzhihao/Desktop/T/output/centered_cube_round116_20261014/astra_first.md:17) | `F=max(h,phi)`, `C(d)=integral_[-1/2,1/2] F(u-d)du`. Thus the threshold potential uses this fixed hard/soft maximum, not the actual f_s. |
| [R117 joint_geometry.md:71–74,103–115](/Users/zhengzhihao/Desktop/T/output/centered_cube_round117_20261014/joint_geometry.md:71) | `k_t(y,v)=sum_i 1_{A_i(y,v)<t}` lies in `[0,n]`; off forbidden-block jumps, `partial_logt w_t=-k_t w_t`, `partial_logt Pi_t=(m_t-k_t)Pi_t`, `m_t=integral k_t Pi_t`. |
| [R128 proof.md:636–650](/Users/zhengzhihao/Desktop/T/output/centered_cube_round128_20261014/proof.md:636) | For fixed `(omega,V,j,y,t)`, nu, Z_t, w_t, e_t and Pi_t are constructed before receiver x and are independent of original hard z. The terminal good/bad sets, physical g, actual s,L,R and original capture/history gates may depend on x. |
| [R128 proof.md:604–630](/Users/zhengzhihao/Desktop/T/output/centered_cube_round128_20261014/proof.md:604) | The positive mother measure is `q^-1 p_y(x) h_R(x-z) a_omega dx beta_V(dy)nu_V(dz)`, with two factors of the same Pi_t, positive score `[k_t(y,v)-k_t(y,u)]_+`, actual gates, original clock and outer `2Lambda E sum_(V,j)`. |

The actual softness interval is

    1-2^(-1/n)<s(x)<=1-d_n,
    d_n=1000 sqrt(log(n+2)/n),                         (PB1)

with `L<=b-2a/n` and `n>4*10^6 log(n+2)` in the inherited remaining
branch. The lower gate is recorded in R128 proof.md:14,35, and the upper
gate and dimension restriction in R117 joint_geometry.md:5. In particular
d_n is the gap below one; the upper bound is not s<=d_n. Neither the
pure-hard endpoint s=0 nor a low-dimensional numerical law becomes an
actual original input. Empty intersections contribute zero.

## PB2. What the soft-coordinate labels really mean

Fix one kernel evaluation, with `u_i=(x_i-y_i)/L`,
`a_i=h(u_i)`, `b_i=phi(u_i)`, and `0<s<1`. The exact expansion is

    product_i[(1-s)a_i+s b_i]
       =sum_(S subset [n]) s^|S|(1-s)^(n-|S|)
                            product_(i in S)b_i product_(i notin S)a_i. (PB2)

There is a valid generative representation: first take independent
Bernoulli(s) labels, then generate each normalized receiver coordinate
with h or phi according to its label. For fixed s,L this is a probability
kernel for every fixed spatial source y. No source law for y is needed.

After conditioning on this receiver displacement, however, the labels
have independent Bernoulli probabilities

    r_i(s;x,y)=s b_i/[(1-s)a_i+s b_i],
    M_s(x,y):=E(|S| | x,y)=sum_i r_i.                 (PB3)

Strict actual s>0 and phi>0 make the denominators positive. Formula PB3
is obtained by dividing each nonnegative summand in PB2 by its sum.
It gives the exact soft-parameter score

    s(1-s) partial_s log P_s,L(x-y)=M_s(x,y)-ns.      (PB4)

For each coordinate, subtract s from PB3 to obtain
`r_i-s=s(1-s)(b_i-a_i)/f_s(u_i)`; summing proves PB4.

On the hard core, r_i<=s because a_i=1 and b_i<=1. Outside that
coordinate's core, a_i=0 and r_i=1, however small positive s is. Thus
even the kernel's own conditional label count is not generally <=ns.
For fixed s,L, before imposing E or any other receiver gate, normalization
does give the full-Lebesgue identity

    integral P_s,L(x-y) M_s(x,y)dx=ns.               (PB5)

Its proof integrates PB2 term by term: each product component is a
normalized density. With actual adaptive s(x),L(x), a receiver cut,
or an extra clock-posterior weight, PB5 is not an authorized ns bound.
One must retain and pay the altered receiver integral.

## PB3. Why the original score is a different random variable

The MG2--6 argument of R257 mixed_geometry.md expands the original
P_s,L(x-y) kernel by a soft-coordinate set S. Its k=|S| is PB2's kernel
label. The subsequent positive rectangle mixture truncates phi only
inside the common hard window, and pays its countable mixture weights
and weak-sum entropy. These operations do not introduce S into nu,
Z_t, or the actual posterior Pi_t.

In contrast the clock score is the deterministic spatial function

    k_t(y,v)=sum_i 1_{ b C(|y_i-v_i|/b) < c_j t }.    (PB6)

Its coordinates involve the two spatial sources y and auxiliary v,
the ratio index and clock time. They involve neither a Bernoulli label
nor the actual receiver softness. Holding the original outer sources,
y,j,t fixed leaves this formula and Pi_t fixed as functions of v; this
is a statement about their actual arguments, not permission to change
s in a FULL input while holding all original qualifications fixed.

The source-pair near gate from R257 restricts soft y and actual hard z.
It does not identify auxiliary v with z. The original source-born
restriction on v is already in Z_t, while the hard-z capture/history
gate remains in the mother measure. They cannot be exchanged.
Consequently neither `k_t<=|S|` nor `Gini(Pi_t,k_t)<=O(ns)` follows
from identifying the displayed symbols. A proof may exploit original
terminal tests and receiver geometry jointly, but it needs an additional
estimate rather than the independent kernel-label prior alone.

## PB4. A true FIRST-weighted comparison, with the entire cost retained

Fix an actual receiver x, the same original y,j,t, and write
`p_v=P_s(x),L(x)(x-v)`. The original actual FIRST and nu<=f give the
subprobability measure

    Sigma_x(dv)=p_v nu_V(dv)/q,
    Sigma_x(R^n)<=1.                                (PB7)

For strict actual s>0, p_v>0. On a nonempty original heavy row,
for every nonnegative measurable psi the exact identity is

    integral psi(v)Pi_t(dv)
       =(q/e_t) integral psi(v)1_Zt(v)
                              [w_t(y,v)/p_v] Sigma_x(dv). (PB8)

There is no independence assumption in this Radon--Nikodym identity.
It shows precisely the cost of changing from the actual test-kernel
source to the clock posterior. Applying PB2--3 inside Sigma_x does not
delete the inverse p_v or e_t. For two copies, the actual cost is the
product of both factors `q w_t/(e_t p_v)`, not a single normalizer.
The remaining original beta(dy), hard nu(dz), actual dx and history
are still outside this identity.

A sharper one-sided bridge is available on the original terminal good
set G, at an actual t<=g. Define

    Q_x^*(v)=[P_s,L(x-v)+P_s,L+(x-v)+P_1,b(x-v)]/3,
    G subset Z_g intersect {p_y w_g(y,v)<=K Q_x^*(v)}.

R117 JG3--4 (lines 34--45) and R128 RT5 give exactly this common test
and `integral Q_x^* nu<=q`. Since each coordinate satisfies
`min(1,A_i/t)<= (g/t) min(1,A_i/g)`,

    1_G(v)Pi_t(dv)
       <= [K/(p_y e_t)](g/t)^n 1_G(v)Q_x^*(v)nu_V(dv). (PB9)

All target kernels use the same actual receiver, not parameters chosen
separately for v. In particular for B subset Z_g disjoint from G,

    integral_(G x B) [k_t(v)-k_t(u)]_+ Pi_t(dv)Pi_t(du)
       <=[K/(p_y e_t)](g/t)^n Pi_t(B)
                       integral_G k_t(y,v)Q_x^*(v)nu_V(dv). (PB10)

This follows by the elementary bound `[k_t(v)-k_t(u)]_+<=k_t(v)`
and PB9, with no cropping of the posterior normalizer. Extra original
positive gates can be retained inside the integrals, or removed upward;
the right side is not declared to be another FULL traffic.

Ordinary FIRST only gives `integral_G k_t Q_x^*nu<=nq`. Any better
low-softness estimate must improve this score-weighted test/source
integral, or its full receiver/clock integral, using actual geometry.
It must include the J=P_1,b third leg, whose kernel has softness one
even when the actual s(x) is tiny. No actual-s Bernoulli prior controls
that leg's latent soft-coordinate count. Existing paid J subparts must
be removed once before any new payment is registered.

## PB5. What is and is not supplied for the next step

The unqualified row bound remains the proved iid Gini estimate n/4
for k_t in `[0,n]`; the low actual s does not change its proof or its
posterior law. MG2--6 pays a genuine near-source response column, not
the score-weighted quantity in PB10. The original lower softness gate
is only of order 1/n, so the R257 factor `n exp(-cns/2)` need not become
bounded on all actual low-soft rows.

PB3--5 can be used when a proposed receiver calculation actually
contains the soft kernel and the correct kernel label. PB8--10 are the
legal transfer formulas for that calculation toward the original
posterior. The earliest missing step is a joint receiver/source bound
for PB10 with its real `e_t^-1(g/t)^n`, the original beta source, hard
z and its near/capture gate, not a replacement of clock k_t by the
kernel label. This audit has not proved a new low-soft positive payment.
It also has not supplied a FULL counterexample to such a future joint
inequality. Negative credits and the already paid strong-soft branch
are unchanged.

## PB6. Bounded local kernel diagnostics

The following local Python computation was actually run with mpmath
1.3.0, 60 decimal digits. It uses the true phi integral, checks PB2 and
PB4, and records that one off-core coordinate has conditional soft
probability exactly one. It is a kernel-identity diagnostic in n=3,
not a source/history model, a low-dimensional FULL input, or a numerical
counterexample to the original geometric target. Quadrature is ordinary
high precision, not interval arithmetic; the identities are proved above.

```python
import sys, itertools
sys.path.insert(0, '/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
import mpmath as m
m.mp.dps = 60

def phi(v):
    d = abs(v)
    if d <= m.mpf('.5'):
        return m.quad(lambda r: 2*r-r*m.exp(-(.5-d)/r)
                      -r*m.exp(-(.5+d)/r) if r else 0, [0,1])
    return m.quad(lambda r: r*(m.exp(-(d-.5)/r)
                  -m.exp(-(d+.5)/r)) if r else 0, [0,1])

pts = [m.mpf(x) for x in ['0','.25','.75']]
b = [phi(v) for v in pts]
a = [m.mpf(int(abs(v)<=m.mpf('.5'))) for v in pts]
checks, err = 0, m.mpf(0)
for s in map(m.mpf, ['.001','.01','.2','.8']):
    fs = [(1-s)*x+s*y for x,y in zip(a,b)]
    H = m.fprod(fs)
    expansion = m.fsum(m.fprod([s*b[i] if mask[i] else (1-s)*a[i]
                        for i in range(3)])
                        for mask in itertools.product([0,1],repeat=3))
    err = max(err,abs(H-expansion))
    assert m.almosteq(H,expansion)
    checks += 1
    soft = m.fsum(s*y/f for y,f in zip(b,fs))
    score = s*(1-s)*m.fsum((y-x)/f for x,y,f in zip(a,b,fs))
    err = max(err,abs(score-(soft-3*s)))
    assert m.almosteq(score,soft-3*s)
    checks += 1
    assert s*b[2]/fs[2] == 1
    checks += 1
    print('s',s,'E_kernel_soft',m.nstr(soft,24),
          'ns',m.nstr(3*s,12),'forced_outside',1)
print('PASS',checks,'kernel-identity diagnostics; max_error',
      m.nstr(err,12),'mpmath',m.__version__)
```

Actual output:

```text
s 0.001 E_kernel_soft 1.00107783705436826345889 ns 0.003 forced_outside 1
s 0.01 E_kernel_soft 1.01082327007200657475005 ns 0.03 forced_outside 1
s 0.2 E_kernel_soft 1.23734109080761886421966 ns 0.6 forced_outside 1
s 0.8 E_kernel_soft 2.36568659421853423323943 ns 2.4 forced_outside 1
PASS 12 kernel-identity diagnostics; max_error 1.55575381947e-61 mpmath 1.3.0
```
