# R258 先行三阶段方案

固定3个有限law（n2初探/n8压力/n32扩大），每例2个terminal B、2个terminal G、2个未来删除E，E在t1/2、3/4删；τ1/4,g1，分片包含所有激活threshold与删除时刻。terminal B/G是任意固定分割，不冒称由原Q门生成。

actual overlap law使用真实C(d)=∫h max(h,phi)的E4公式，A_i=C(|y_i−v_i|)，b=cj=1；mp40/70积分保持全部后验与signed补项。另独立有理threshold模板只用于Fraction midpoint/删除恒等式，不把它称actual C。

nearη由固定外row(y,z)的有理距离定义，η0/1乘整套边界/跳/所有正负项；附η1/2只是线性分账诊断，不叫真实near指标。不对posterior pair任意加mask后仍沿用FB边界。Ψ固定0/1，θ有理[0,1]，包括zero/full压力。只补原soft上下门、MG7强门和高标签尾k0若干scalar；不重跑全部混合谱。

## 最终实际范围及计数

已完成三阶段且不扩模型：n=2 initial、n=8 stress、n=32 expanded。每例6个有限源：B0/B1、G0/G1终端一直存活，E0/E1分别在1/2、3/4删去。τ=1/4、g=1。质量、每个坐标的有理位移、删除时刻完整写在JSON；B/G只是固定terminal分割，不声称由原Q门生成。有限原子law不是正L1或FULL输入。

尤其b=cj=1、τ=1/4,g=1是扩大的toy clock，其log长度为log4。它不满足原b≤2a且τ=a/cj的octave几何（若取a=τ则b/a=4）。这里actual overlap law仅指真实C函数生成A，不是原RT4合法全尺度窗；不把它当原log2费用的数值证据。原signed边界恒等式不依赖clock长度，tail的一般log2仍来自原文资格。

正式实际counts为3 actual_overlap_laws、15 rational_midpoint_checks、6 rational_jump_checks、每精度15 actual_interval_records与6 actual_deletion_records；另7原soft门scalar、5高label尾scalar（2例尾非空、每精度共6个k检查），289个40/70保存数值字段。全部断言通过。counts数的是记录/检查位置，不将一个midpoint内多条代数断言算成多个新模型。

## 实际overlap核与独立有理模板

actual C(d)=∫[-.5,.5]max(h(u−d),phi(u−d))du；h在core为1，而phi≤1，故分出真实hard overlap再用phi的E4原函数计算余段，非人工soft-mixture标签。b=cj=1，A_i=C(|y_i−v_i|)，y=0；wt=∏min(1,A_i/t)，k=#{Ai<t}。同一scalar t用于所有坐标和所有源。

C(0)=1，C(1/4)≈.8274907122372365，C(1/2)≈.6280349911147240，C(1)≈.1862311918978722，C(2)≈.04368185179717205。这些actual C值是普通40/70位E4计算，不称有理证书。每条law按所有(A_i∈(τ,g))及删除时刻分片，端点不重复计dt；g处threshold的score值只影响零测点。分片内部k固定，νwt写成coeff·t^(−k)，保完整存活Z的归一e_t，没有只在G/B上重新归一。

独立Fraction模板把5类位移映为A={1,7/8,5/8,1/8,1/32}，**不是**actual C的认证近似；n8另把一个未来E坐标的threshold设1/2，精确覆盖同一时刻birth/delete。每个无事件midpoint直接核quotient导数等于完整G×B加E×B signed pair和，逐项核JB5；η0、1/2、1又各核一次线性账。删除时刻用同一wt、before/after两个support，核ΔFB=eB·removed/[e_before(e_before−removed)]≥0。没有删除terminal B/G，也没有把threshold当FB跳。

## 同一signed账及near

固定Ψ=[[1,0],[1,1]]，θ=[[1/2,0],[1,1/3]]。正方向D=k_good−k_bad。所有完整pair积分类保持同一Pi²：

P=∫G×B ΨθD+，N=∫G×B ΨD−，NE=∫E×B D−，U=∫E×B D+，S=∫G×B(1−Ψ)D，R=∫G×B Ψ(1−θ)D+。

这里S保signed D，绝不是D−；NE是连续clock项，不是删除jump。实际数值核

P−N−NE=FB_end−FB_start−Σjump−∫(U+S+R)。

所有t积分使用dt/t；分片局部函数在开区间有固定score，但endpoint处wt连续；跳原子单独计算。跳之和保原始工作精度，没有从50位显示字段重读参与70位residual。n2/n8/n32的70位residual分别约−3.96e−72、−2.89e−71、−1.35e−78。

near是外row时间不变η，而非任意posterior pair mask：Dnear=1/4，外y0，z=B0时l1距离0故η1；z=B1时距离>Dnear/2故η0。边界、跳、P/N/NE/U/S/R全乘同一个η。η1/2仅作人工线性分账检查，不叫距离near事件；不能给每pair另加η(c,b)后仍保同一个FB边界。相应near/far负项只是同一原账的互补份额，不提供第二次信用。该工具检验不核原hard z接收或FIRST/history门。

n2的P/N/NE约.0524483/.0439250/.0100750；n8约.0362430/.0641878/.00857434；n32约9.84570e−8/6.85944e−8/8.99063e−9。n8在第一次删除的jump约.984659，FB_end−FB_start约.948240，而连续drift积分约−.0364508；丢jump会直接改变账方向。保U/S/R后才能得到同一signed量。这些数值只说明实现确实含非零正、负、删除与恢复项，不证明一般付款界或原FULL资格。

## 原soft门和高label尾

实际采用原d_n=1000sqrt(log(n+2)/n)，不是1000sqrt(log(n+2))/n。原下门开：s>1−2^(−1/n)，原上门闭：s≤1−d_n。7行n2/32/512/10^6/10^8/10^9/10^12中，前4行原soft范围为空；n10^8之后所列3行有非空范围。n10^6虽然MG7标量阈值≈.012055落在[0,1]，原上门≈−2.71692，故原交仍为空；不得沿用R257“合法scalar soft”来声称该维原branch非空。n10^9的原上门≈.856044、MG7强门≈1.80825e−5；原下门≈6.93147e−10远低于强门。所有7行均显示下门不覆盖MG7强门。

高label尾为P的人工soft展开S，不是上文actual overlap score k_t。ζ=sqrt(1−e^-4/4)，k0=ceil(2logn/|logζ|)。5行n2/32/512/10^6/10^9的k0为605、3021、5438、12042、18062，前三行k0>n尾为空。后两行nζ^(k0/2)约.99904693、.99971711≤1；但n10^6原soft范围仍为空，两种资格不混合。

每个非空尾只取k0、中间整数、n共3个k，并在s=k/n（对应普通二项质量最大者）用loggamma检查log[binom(n,k)s^k(1−s)^(n−k)ζ^k]≤k0logζ；没有枚举百万/十亿坐标。loggamma相减使用20位内部guard，仍仅普通高精度；这条scalar辅助不把originalscore限制为label数，不新增FULL实例或原boundary付款。

## 精度与复现

actual C/实际piecewise积分与scalar均40/70工作精度复算；50位序列化保留两精度差异。289项最大相对差5.870710805883e−38（分母max(1,|70位值|)）。此一致性不是向外舍入区间或积分误差证书；Fraction模板的中点/跳恒等式才是精确有限代数证据。一般JB5及near边界付款由作者和独审证明，数值不替代通用恒等式。新价32Λ/√3 sqrt(Kκ)的来源/receiver资格未在这些有限law中构造，未重跑旧全部谱。

解压包中在脚本、合同同目录执行：

```sh
PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor \
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 \
numeric_checks.py --contract task_contract.md --output numeric_checks.replay.json
```

本机实际Python3.12.14、mpmath1.3.0（vendor如上），标准库Fraction；没有额外安装、MATLAB/NumPy/SciPy或旧checkpoint依赖。JSON无耗时/时间戳/本机路径，绑定当前脚本与合同SHA。沿用已读取L03技能的精确/普通mp边界，不声称通用interval API。正式完整运行已完成，主代理从包外副本唯一完整重放；本责任三文件现冻结，不继续扩模型。
