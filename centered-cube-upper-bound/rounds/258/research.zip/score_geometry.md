# R258：软标签尾的实际正份额付款与少标签 score 接口

## SG1. 量词、已证依赖及范围

固定 \(n\ge1\)、\(\lambda,q>0\)、\(0<a\le b\le2a\)、\(0<d\le a/2\)。沿用 R257 冻结 mixed_geometry.md 的原核、实际共同选择器、真实接收域与来源。尤其
\[
 P_{s(x),L(x)}*\beta\le q,\qquad M_{[a,b]}\nu\le4\lambda\quad\text{on }E,
\]
以及 \(L,R\in[a,b]\)。实际原软度下门是 \(s>1-2^{-1/n}\)，上门是
\(s\le1-1000\sqrt{\log(n+2)/n}\)；下门并不蕴含 R257 的强软度阈值。

记 R257 MG3–4 的固定绝对常数和已证费用为
\[
 \epsilon=\tfrac12e^{-4},\quad \gamma=1+\epsilon/2,
 \zeta=\sqrt{1-\epsilon/2}\in(0,1),\quad
 \kappa_d=2+n\log(1+d/a),\quad
 K_n(d)\le C_*\kappa_d\log(n+2).
\]
\(K_n(d)\) 的显式公式及零、一、二阶半径对数矩全部保持 R257 MG4.4；本稿不把它改成新的免费常数。

本稿的实际新付款仅是原正核展开中的高软标签尾。它不依赖“原 score 由标签数支配”这一未授关系。少标签硬残余的一般根阶付款仍未得到；SG4–5 给出可核的准确接口，不将其视为已付结论。

## SG2. 原核的非负标签份额与统一弱型

对 \(S\subset\{1,\ldots,n\}\)，定义归一概率核
\[
 H_{S,L}(u)=L^{-n}\prod_{i\notin S}h_1(u_i/L)
                         \prod_{i\in S}\varphi(u_i/L).
\]
原核有精确的有限正展开
\[
 P_{s,L}=\sum_S s^{|S|}(1-s)^{n-|S|}H_{S,L}. \tag{SG2.1}
\]
对非负标签权 \(b(k)\)，令
\(P^{[b]}_{s,L}=\sum_S b(|S|)s^{|S|}(1-s)^{n-|S|}H_{S,L}\)，并记
\(B_b=\max_{0\le k\le n}b(k)\zeta^k\)。

若 \(\sigma\) 支撑于边长 \(d\) 的簇 \(C\)，中心为 \(z_C\)，则
\[
 u\left|\left\{x\in Q_{b+d}(z_C):
  \sup_{0\le s\le1,\ a\le L\le b}P^{[b]}_{s,L}*\sigma(x)>u\right\}\right|
 \le B_b K_n(d)\|\sigma\|. \tag{SG2.2}
\]
其中 \(Q_{b+d}\) 中的 \(b\) 是物理窗上端，不是标签权函数。

证明。在这个共同硬窗口内，逐个原标签分量把 \(\varphi\) 准确截为
\(\psi=\varphi1_{[-3/2,3/2]}\)。R257 MG3 的正混合给
\(\psi\le\sum_\ell w_\ell h_{r_\ell}\)，且 \(w_\ell=\zeta\omega_\ell\)。对固定 \(|S|=k\) 的矩形分量，系数为
\[
 b(k)s^k(1-s)^{n-k}\zeta^k\prod_{i\in S}\omega_{\ell_i}
 \le\frac{B_b}{{n\choose k}}\prod_{i\in S}\omega_{\ell_i},
\]
因为二项分布单项不超过一。其余各向异性弱型、可数阈值预算与半径矩完全是 R257 MG2–4 的同一证明，故常数恰为 \(B_bK_n(d)\)。这一步没有用 overall soft supremum 的高度帽。

例如任意固定整数 \(m\ge1\)，\(b(k)=(k+1)^m\) 的弱型也有与 \(n\) 无关的额外常数，因为
\[
 B_b\le\zeta^{-1}\left(\frac{m}{e|\log\zeta|}\right)^m.
\]
但此加权核通常不再小于原 \(P\)，不能同时声称其 actual selected 响应仍被 \(q\) 截住。下面只对 \(b\le1\) 的尾份额使用这个高度帽。

## SG3. 高标签尾：完整来源、score 与时钟付款

给定整数 \(k_0\ge0\)，先在原有限展开中定义
\[
 P^{\ge k_0}_{s,L}=\sum_{|S|\ge k_0}s^{|S|}(1-s)^{n-|S|}H_{S,L}.
\]
若 \(k_0>n\)，它恒为零。它满足 \(0\le P^{\ge k_0}_{s,L}\le P_{s,L}\)；在 \(P>0\) 处
\(\theta_{\rm tail}=P^{\ge k_0}/P\in[0,1]\)，\(P=0\) 时置零。这是原正核的确切子份额，不是更换来源或后验。

由 SG2，簇的全软度尾上确界弱价不超过
\(\zeta^{k_0}K_n(d)\|\sigma\|\)。对 actual selected 尾响应，原 FIRST 仍给高度 \(\le q\)。因此原簇 soft-square layer cake、hard-square 预算、两次 Cauchy 与平移网格平均完全如 R257 MG5–6，得到
\[
 \int_E\iint P^{\ge k_0}_{s(x),L(x)}(x-y)h_{R(x)}(x-z)
       P_d(y-z)\,d\beta(y)d\nu(z)dx
 \le4\sqrt{q\lambda}\,\zeta^{k_0/2}\sqrt{K_n(d)\kappa_d}
       \sqrt{\|\beta\|\|\nu\|}. \tag{SG3.1}
\]
真实近对指标 \(1_{\{\|y-z\|_1\le d/2\}}\) 的右价乘二。截断 \(\varphi\to\psi\) 只用于共同硬窗口上的证明；原被付款的核始终是上述 \(P^{\ge k_0}\)。

在已经付掉的正子项之外，将原正余交通乘 \(\theta_{\rm tail}\) 与真实近对指标。全部原 history/capture/high/good/bad 正门保留，原双 \(\Pi_t\) 不裁源。R257 actual_bridge AB4–5 已认证：逐原行 gated Gini \(\le n/4\)、原 far clock 长度 \(\le\log2\)，先逐 \(x\) 合并唯一 \(j(x)\)，receiver-leaf 门不交。再使用 \(3\lambda/4\le q\le\lambda\) 与唯一外因子 \(2\Lambda/q\)，得
\[
 \mathcal P_{\rm near,tail}
 \le\frac{8\Lambda\log2}{\sqrt3}\,
 n\zeta^{k_0/2}\sqrt{K_n(d)\kappa_d}\,W_{\rm pair},
 \quad W_{\rm pair}=\mathbb E\sum_V\sqrt{\|\beta_V\|\|\nu_V\|}. \tag{SG3.2}
\]
这一步支付了原 score 与 clock，未使用未消费负信用。若前轮 strong-soft/core 等份额已付，只在其未付补量上分配本尾份额；正上界仍是 SG3.2，不能重复领取。

取
\[
 d=\frac a{8\sqrt n},\qquad
 k_0=\left\lceil\frac{2\log n}{|\log\zeta|}\right\rceil.
\]
则 \(n\zeta^{k_0/2}\le1\)。若 \(k_0>n\)，尾份额为空；\(n=1\) 时 \(k_0=0\)，公式仍成立。于是
\[
 \mathcal P_{\rm near,tail}
 \le\frac{8\Lambda\log2}{\sqrt3}\sqrt{C_*}
 (2+\sqrt n/8)\sqrt{\log(n+2)}\,W_{\rm pair}. \tag{SG3.3}
\]
原 \(\nu_V\le\beta_V\le\alpha_V\) 与原来源总账给 \(W_{\rm pair}\le\|f\|_1\)。本结论允许全部原软度，因而也覆盖低软度中的相应非负尾份额；不声称此尾份额占固定比例，更不把它当作一般低软度问题的完成。

## SG4. 少标签与原 score 的准确共同窗口关系

原 \(k_t(y,v)=\#\{i:bC(|y_i-v_i|/b)/c_j<t\}\) 取决于实际辅助来源 \(v\)，与核展开的 \(S\) 不是同一对象。原后验 \(\Pi_t\) 由完整 \(\nu\)、\(Z_t,w_t,e_t\) 构成，核标签没有成为它的坐标标签。

仍有一个合法的固定参数窗口桥。设 \(S,T\) 分别为 \(H_{S,L}(x-y)\)、\(H_{T,A}(x-v)\) 的标签，\(L,A\in[a,b]\)，\(\xi=c_jt/b\in(0,1)\)。定义
\[
 g=\min\left\{1,\frac{[b(1-\xi)-|L-A|/2]_+}{\min(L,A)}\right\}.
\]
由 \(C(u)\ge(1-u)_+\)，每个 active 坐标满足
\(|y_i-v_i|>b(1-\xi)\)。若又有 \(i\notin S\cup T\)，同一接收坐标的两个硬区间交长是
\[
 \left[\min(L,A)-[|y_i-v_i|-|L-A|/2]_+\right]_+,
\]
至多 \(\min(L,A)(1-g)\)。因此固定标签的真实 Hellinger affinity 满足
\[
 \int_{\mathbb R^n}\sqrt{H_{S,L}(x-y)H_{T,A}(x-v)}\,dx
 \le (1-g)^{[k_t(y,v)-|S\cup T|]_+}. \tag{SG4.1}
\]
证明：硬硬 active 坐标的积分为交长除以 \(\sqrt{LA}\)，至多 \(1-g\)；其余坐标由概率核 Cauchy 至多一；最后逐坐标乘积。指数零时右边定义为一，包括 \(g=1\)。

SG4.1 保留实际位移，是兼容 R224 共同窗口工具的准确低标签接口；它不是 \(k_t\le C|S|\)。只控制来源 \(y\) 的少标签并不控制未来测试槽的 \(T\)。原第三腿 \(J=P_{1,b}\) 的标签为全体坐标，SG4.1 在该腿退为平凡界；还须保其真实软窗口几何。更不能把固定 \(L,A,S,T\) 的积分不等式直接应用到依 \(x\) 变化的选择器，或丢掉原 hard-source 后再复用它。

## SG5. 原未来测试归一化仍未付；本轮范围

本轮 posterior_bridge.md PB9–10 恢复的合法原输入是：terminal-good \(G\subset Z_g\)，\(t\le g\) 时
\[
 1_G\Pi_t(dv)
 \le\frac{K}{p_y e_t(y)}\left(\frac gt\right)^n
       1_GQ_x^*(v)\,d\nu(v). \tag{SG5.1}
\]
于是 \(G\times B\) 正 score 可上控为
\[
 \frac{K}{p_y e_t(y)}\left(\frac gt\right)^n\Pi_t(B)
       \int_G k_t(y,v)Q_x^*(v)\,d\nu(v). \tag{SG5.2}
\]
FIRST 目前只直接给 \(\int Q_x^*d\nu\le q\)，因而裸替换仍只有 \(\int k_tQ_x^*d\nu\le nq\)。\(e_t(y)\)、时钟放大因子与真实 \(Q^*\) 三腿不能删去。SG4.1 的空间亏损要进入 SG5.2，必须保同一个实际接收窗口、hard \(z\) 来源、\(y\)-依赖后验及所有选择器费用；本稿没有证明这一步的全局根阶预算。

所以 SG3 是一个合法辅助正份额付款，而不是把混合标签矩改名为原 score 预算。少标签近来源残余和远来源仍未闭合。父稿的同一原 signed 账近来源边界支付是另一合法结论；本稿不借其边界界恢复已耗的 suffix 负账。

## SG6. 本机可复现标量检查

以下代码已实际运行通过 65 项检查：60 项有理加权二项尾检查、5 项原 \(\zeta\) 的阈值检查。前者用一般 \(\zeta=9/10\) 检查代数，而非原空间核数值；后者为浮点检查。它们都不是一般实际交通证明。

```python
from fractions import Fraction as F
from math import comb, exp, log, sqrt, ceil
zeta = F(9, 10)
checks = 0
for n in (1, 4, 8, 16):
    for s in (F(1, 10), F(1, 2), F(9, 10)):
        for k0 in (0, 1, n//2, n, n+1):
            tail = sum((F(comb(n,k))*s**k*(1-s)**(n-k)*zeta**k
                        for k in range(k0, n+1)), F(0))
            assert tail <= zeta**k0
            checks += 1
z = sqrt(1-exp(-4)/4)
for n in (1, 2, 100, 10**6, 10**12):
    k0 = ceil(2*log(n)/abs(log(z)))
    assert log(n) + k0*log(z)/2 <= 1e-12
    checks += 1
print({'checks': checks, 'scope': 'label algebra and threshold only'})
```
