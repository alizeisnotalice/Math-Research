# R258 独立审计

## 命题先行初筛（未读本轮作者稿）

本审只编辑audit.md，不改他人文件。已读合同，窄读冻结R223 negative_contract NC1–NC10及joint_budget JB1–JB7；沿用已独审R257 MG5–6/AB原量合同。原soft下门s>1−2^(−1/n)不能改成强soft MG7门，原score并非人工混合标签。当前只审真实near signed边界。

### 静态near同权分割及方向

令d=a/(8sqrt n)，eta=1{||y−z_hard||1<=d/2}。固定完整行(ω,V,j,x,y,z_hard,history)后eta对aux clock完全不变，也不依辅助good/bad来源。因此可乘原NC8/JB5的整条行等式；同一eta须用于当前未消费P、N_Zc、N_del以及边界、suffix、有利U/R和真实删除jump。eta与1−eta精确拆分全部原母账，不是只截P再借两次完整N，也不按新gate重建Π或G/B。

方向保持原good−bad。对原单个非空Jfar interval、按原一侧endpoint convention，记DeltaFB=FB(r)−FB(l)，原等式为

`P−N_Zc−N_del=DeltaFB−sum jump−integral U−integral S−integral R`。

B是terminal bad，故原删除不触B且jump>=0；U>=0,R>=0。S=integral_(G×B)(1−Psi)(kg−kb) Π²为原suffix补域signed项，未自动非负。于是

`eta(P−N_Zc−N_del)<=eta[1+integral(-S_t)+ dlogt]`，

也可保更精确的DeltaFB及全部联合有利储备。(-S_t)+是pair积分之后的正部；若用pairwise反向正差上放则更松，不可误写一般等号。已经消费的N_Z没有因eta或边界已付而恢复，N_del是E_t×B的连续反向交通，不是真实删除原子；NC8用过它后不能再减第二次。

### 原窗口与真实receiver/source回代

原heavy域是initial interval，Jfar再与[τ_j,h]相交仍是一interval；eta没有制造时间新切口。DeltaFB<=1是每行概率边界，不需score n/4或logclock费用。若另将time拆成多段或使用t依赖筛选，必须重列全部endpoint，不能仍只付一个1。

乘原2Λ high dT，保actualsource βdy ν(dz_hard)、真实dx、p=P_actuals,L、h_actualR、q^-1和所有receivercap资格。边界上放1后一致于各j，所以先此行上界，再以实际sum_j1_{j(x)=j}<=1消标签；不取多个clock或source-dependent j菜单。V通过原source mass账相加，不靠‘x只一个V’偷去费用。

R257 MG5–6在s0=0对两actualsoft/hard尺度授真near来源列价

`integral_E integral_near p_y h_R βν dx <=8sqrt(q lambda) sqrt(K_n(d) kappa_d) sqrt(Wβ Wν)`。

这里FIRST只给原actual selected softresponse帽，硬all[a,b]帽由真实receiver合同授；不能drop aω后扩到无帽x。乘原2Λ/q、q>=3lambda/4，得到完整near行边界总价

`C_boundary=(32Λ/sqrt3) sqrt(K_n(d) kappa_d) W_pair`。

系数解析为16Λsqrt(lambda/q)<=32Λ/sqrt3；没有再乘n、log2或第二份Λ。W_pair=E sumV sqrt(Wβ,V Wν,V)<=Wβ<=W_A<=W_hi<=||f||，保原ν<=β<=α和seed内不交V。K_n<=C_*κ log(n+2)、κ<=2+sqrt n/8，故该边界确获root乘sqrtlog质量付款，包含原lowsoft near域，不是用R257强soft阈值来代替。

这证明的是边界价格而非全部near signed付款。准确仍需支付同一原外测度下eta integral(-S_t)+，或给其与jump/U/R的真实联合抵消。有限共同截断先保所有项有限/正负分别积分；不能对未证可积signed量擅用Tonelli。当前正门theta包括此前已付正子份额剔除，R_loss因此按实际完整定义保留，不将其作为额外独立新负信用反复消费。

### 本人实际有限算术检查（可重放）

下列标准库Fraction代码实际运行，8个静态near分割等式加3个系数平方比较共11项PASS。它是原同Π行代数的有限诊断，不认证FULL或suffix付款；一般NC8来自已证原公式。

```python
from fractions import Fraction as F
p=[F(1,10),F(2,10),F(3,10),F(4,10)]
checks=0
for k in [(0,1,2,3),(2,0,3,1),(1,3,0,2),(4,4,0,0)]:
 P=N=U=S=R=F(0);NE=F(0)
 for i,psi,th in [(1,F(0),F(1,3)),(2,F(1),F(2,3))]:
  D=k[i]-k[0];base=p[i]*p[0]
  P+=base*psi*th*max(D,0);N+=base*psi*max(-D,0)
  S+=base*(1-psi)*D;R+=base*psi*(1-th)*max(D,0)
 De=k[3]-k[0];NE=p[3]*p[0]*max(-De,0);U=p[3]*p[0]*max(De,0)
 deriv=p[0]*(sum(w*v for w,v in zip(p,k))-k[0])
 lhs=P-N-NE;rhs=deriv-U-S-R
 for eta in [F(0),F(1)]:
  assert eta*lhs==eta*rhs
  assert eta*lhs+(1-eta)*lhs==lhs
  checks+=1
for qratio in [F(3,4),F(7,8),F(1)]:
 assert F(256)/qratio<=F(1024,3);checks+=1
print('PASS',checks,'static signed partition and squared boundary-coefficient checks; not FULL')
```

实际输出：`PASS 11 static signed partition and squared boundary-coefficient checks; not FULL`。等待作者本轮精确稿、主整合及正式数值边界后终审，不冻结。


## posterior_bridge.md 作者稿后审查

**PB1–PB6及PB8–10公式PASS。** 受审当前SHA332a2c6c83b3d8d914ba89ce5f68dcf7b451311f76d82ca9e370898c9b874816。实际source/Π与kernel Bernoulli标签严格区分。固定核位移的条件标签概率r_i=sφ/f_s，核参数partial_s score为sum r_i−ns正确；硬core r_i<=s、offcore r_i=1也正确。PB5只对固定s,L全空间Lebesgue积分授ns，不向actual adaptive receiver/clock转移。

PB8是精确RN换基而非无价posterior domination，保q w_t/(e_t p_v)；两Π必须保两份该因子。terminal-good PB9由w_t<=(g/t)^n w_g及p_y w_g<=K Q*得到，p_y不是p_v，e_t仍原同y分母；PB10保Pi_t(B)与scoreweighted Q*积分，FIRST仅给nq而非低soft。J纯软第三腿的标签全n，不能由actuals先验消去。来源hardz与auxv不识别，所有原RN/history仍在母式中。

本人实际从PB6 Markdown提取运行12项普通mp60 kernel诊断，四行条件soft标签及maxerror1.55575381947e−61与作者输出一致。它不是FULL或原score反例；通用公式已解析核过。

## 高标签正核份额命题的独立预审（未读作者SG证明）

令P_tail为原P_s,L非负有限展开中|S|>=k0部分。0<=P_tail<=P，原P=0时ratio置0；只乘尚未付正项，不给原负项另加该正门。k0>n尾为空，n1取k00。

共同hardwindow内φ=ψ、ψ<=sum_l w_l h_rl，w_l=ζω_l。binom(n,k)s^k(1−s)^(n−k)<=1，所以k>=k0的每个矩形系数<=ζ^k0/binom(n,k) product ω_l。沿R257已经付清的可数π/aspect弱和，P_tail restricted弱价<=ζ^k0 K_n mass。原actualselected height由P_tail<=P继承，故soft-hard Cauchy平均给bare true-near价为原R257(G)右端乘ζ^(k0/2)。原完整score/clock仍用n/4、log2，不假定score<=标签；因此原tail-positive近对费<=8Λlog2/√3 ·nζ^(k0/2)sqrt(K_nκ)W_pair。k0=ceil[2log n/|logζ|]使该n因子<=1，对所有actualsoft合法但不保证尾份额占正比例。

更一般b(k)>=0的restricted弱常数有sup_k[b(k)ζ^k]K_n；只有b<=1或另有实际height证书才可接同cap平方步骤，不能免费把多项式label权当原FIRST。若同时使用tail付款和near signed边界，应先从正项扣tail并更新θ，R_loss随实际θ增加，负N只保一次；或将两定理作为独立可用估计，不声称tail消suffix。

固定标签forced-hard affinity先筛亦成立：若C(d)>= (1−d)+，k_t活跃坐标给距离>b(1−ξ)。不在S∪T的这类坐标都是两个核的hard坐标，归一hard区间交长至多(1−g)，g=clip((b(1−ξ)−|L−A|/2)+/min(L,A),0,1)；其它坐标affinity<=1，所以固定参数tensor价<=(1−g)^(k_t−|S∪T|)+。指数0时约定1，含g1；J标签全n时无此强制硬gap。不把它授予自适应receiver列或原PB9逆权/source预算。

## 主整合初审待修点

主边界(B)常数32Λ/√3、全部soft覆盖和保suffix Rem方向均正确；无n或logclock额外费。发现主(J)把‘内侧端点’措辞与sum_(l,r]删除混用：NC8内侧需FB(r−)−FB(l+)与sum_(l,r)；或明确JB5右连续闭端约定才用sum_(l,r]。已通知root窄修、同步边界定义。另要求首参数句显式n>=1。预算无需改变，待最终版本实读后解除。


## 最终作者稿及整合结论（冻结）

**结论：本轮所列范围内 PASS，无待修阻断；不认证一般全局闭合。**

已全文审 score_geometry.md SG1–6：SG2 保原有限正标签展开；共同硬窗口截断、原 R257 的可数弱和阈值与半径矩费用全部继承，尾系数 ζ^k0 的方向正确。一般 b(k) 的弱型不授实际高度帽；SG3 仅对 P_tail≤P 接原 FIRST、双来源与同一 actual Π 的 n/4 Gini、原 log2 时钟。得到 8Λlog2/√3·nζ^(k0/2)√(K_nκ)W_pair 的原正子份额价，k0>n、n=1、零核比值均有明确定义。SG4 固定标签交长/affinity、SG5 同 y 分母与 (g/t)^n 费用正确，未将它们变为自适应列或少标签一般付款。本人实际抽取并运行 SG6：65 项全部通过（60 Fraction 标签代数、5 普通浮点阈值）；不是实际交通数值证书。

最终 proof.tex.txt 已解除前述端点/n 资格问题：(J) 与边界统一采用 FB(r−)−FB(l+)−Σ_(l<t<r)ΔFB；n 是整数且 n≥1。已实读最终全文。其 (B) 是整个原 near 时钟区间的**边界根阶价**，常数 32Λ/√3；Rem 保原后缀恢复，真实删除、连续 N_E、有利 U/R 与旧已耗 N_Z 清楚分开。没有用 score/clock 第二次乘边界，也没有将负信用分配两次。先支付高标签正尾再更新 θ/R、然后对余量用 (J) 的并用段合法；不声称尾项支付 S。

最终 numeric_checks.py 已静读，JSON 与 notes 的参数/计数/源绑定核对一致。真实 C 函数生成阈值的三个有限原子 law 与独立 Fraction 阈值模板严格区分；分段保同一完整 Π，真实删除跳独立于连续 N_E，near 行常量乘整套账。15 中点、6 删除的 Fraction 检查、每精度 15 积分段及 6 删除记录、7 原 soft 门、5 尾门的计数和 289 精度字段均与保存 JSON 一致。最大相对变化 5.870710805883e−38 是普通 mp40/70 一致性，非区间误差证书。任意固定 G/B、原子来源、人工 η=1/2 不冒充原 FULL；尤其 b=cj=1、τ=1/4,g=1 是 log4 toy clock，不能认证原 RT4 octave 或 tail 证明所用 log2。这项范围澄清已经落入 notes、主稿及报告。本人没有再次运行整套正式 JSON；作者及主代理报告的实际完整运行与本人的源码/保存输出审查分开记录，最终包外 replay 由主代理随后执行。

report.md 与 reproduce.py 末版静审通过。报告未把已付边界称为完整 near signed，也未把高标签尾宣称占固定比例。driver 验 manifest 前后、完整 JSON 逐字节重放及 audit/PB/SG 三稿的 Python 附录；它验证有限证据，不替代解析证明，也未提前宣称最终包外执行成功。本人本轮实际独立附录检查为 audit 11、PB 12、SG 65；不把它们混成新的 FULL 模型数。

仍未付：同原负账下的 near 后缀联合恢复、低 soft/低标签的一般 score 与三 future 腿归一化费用、互补远来源及全局总预算。固定标签 affinity 和 FIRST RN 桥不是这些费用的付款。全部原 β/ν、真实 dx、hard z、actual 选择器与 Π 分母保留；不授新的来源裁剪或信用。

## 最终受审 SHA256

以下绑定当前九件，audit 不自绑定，避免 manifest 循环。冻结后本文件停止写入；主代理的后续外置复现以独立 receipt 登记。

| 文件 | SHA256 |
|---|---|
| task_contract.md | dc13580b36d0b2c3e577d455198ef2064aefeea8eac7821a89130cb96e2d6dee |
| proof.tex.txt | abb334ddaed84377cab60372e741399328325af86761dc60eb0105884ff686a3 |
| posterior_bridge.md | 332a2c6c83b3d8d914ba89ce5f68dcf7b451311f76d82ca9e370898c9b874816 |
| score_geometry.md | 8ca44f99eeb60645115da3976f79215fe505603a4d98b1a8eec30dea1fa4ae86 |
| numeric_checks.py | 3409e43709192f283634efa5ffd78a9cc40fd9fc32d23a8e1c2f846b4d503b83 |
| numeric_checks.json | b3e51c9ce60fc1c53b981c23b69e2fc660754034a9821686ea8615fa4ca514ca |
| numeric_notes.md | b51f86f6cf65379c473a91069cbcfee85525ba3cd2b3382d2a16f1ed01fd71a9 |
| report.md | 08a871c5b03fe16b579e7a5e24f7e8a635afdb86420b2e34a6cb1d22959f30d2 |
| reproduce.py | ae1821379d390c42fa9d054b68bf745d50d8454d79840a580b8f27df12aa35f4 |
