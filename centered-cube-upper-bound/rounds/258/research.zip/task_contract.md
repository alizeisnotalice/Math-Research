# R258：近来源原signed边界与低软度score接口

基线R257 cb737c1f04360e51576e4179b92232d16bb4a98f，上一轮为实质进展且已推送。本轮目标仍是一般n^(1/2+o(1))一致弱型，不将近来源子支当全局闭合。

先核原soft下门为s>1−2^(−1/n)，上门s≤1−1000sqrt(log(n+2)/n)，不能宣称下门覆盖MG7阈值2logn/(cn)。原score k_t(y,v)=#{bC(|y_i−v_i|/b)/c_j<t}与P_s,L人工soft-mixture标签不是同一变量，不预设score≤混合坐标数。

主攻两准确问题：(A)能否借原terminal-good和共同future核连接score与可付款的几何缺陷？只准原参数/门；(B)将R223 JB5原signed恒等式乘时间不变原near指标，利用R257无score全soft near来源列价支付边界。若成功必须保完整suffix恢复及有利储备，负信用只按同一near/far分割一次；不得把边界付款说成signed总量已付。

允许工具：R257 MG2–6及AB原q/FIRST/clock/source合同，R223 NC/JB恒等式，R224共同overlap。未知桥明确保留，不采用人工标签独立性。所有接收测度为真实dx，q∈[3λ/4,λ]，来源ν≤β≤α按种子不交leaf，Λ仅原一次。

分工：peak仅score_geometry.md，compare仅posterior_bridge.md，audit仅audit.md，numeric仅numeric_checks.py/json与numeric_notes.md，主代理proof.tex.txt/report.md/reproduce.py及合同。多人共享，不覆盖别人的文件，子Agent不git/PDF、不自行扩研究范围。审查先独立筛命题再读作者。

沿用L03技能：本机Fraction/普通mp数值分开；三阶段有限诊断不当一般证明。本轮若有真正边界预算推进即完整记录，若仅归约则如实说明。每轮独审复现后独立commit/push origin/main，紧凑归档不编译PDF。
