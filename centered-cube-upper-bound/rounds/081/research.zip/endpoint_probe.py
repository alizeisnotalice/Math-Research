#!/usr/bin/env python3
"""R81 common certified hard first-contact, actual E2 endpoint diagnostics.
Exact hard geometry is separate from non-certified E2 Simpson/resolvent gates.
Positive L1 source boxes; fixed rational receiver points, no weak-volume claim.
"""
from fractions import Fraction as F
from pathlib import Path
from functools import lru_cache
import json, math, random, time

SEED=800611


def clean(x):
    if isinstance(x,F):return str(x)
    if isinstance(x,dict):return {str(k):clean(v) for k,v in x.items()}
    if isinstance(x,(tuple,list)):return [clean(v) for v in x]
    return x


def trim(p):
    p=list(map(F,p))
    while len(p)>1 and not p[-1]:p.pop()
    return tuple(p)


def zero(p):return len(p)==1 and p[0]==0
def add(p,q):return trim([(p[i] if i<len(p) else 0)+(q[i] if i<len(q) else 0) for i in range(max(len(p),len(q)))])
def scale(p,a):return trim([F(a)*x for x in p])
def derivative(p):return trim([i*p[i] for i in range(1,len(p))] or [0])


def multiply(p,q):
    out=[F(0)]*(len(p)+len(q)-1)
    for i,a in enumerate(p):
        for j,b in enumerate(q):out[i+j]+=a*b
    return trim(out)


def evaluate(p,x):
    value=F(0)
    for a in reversed(p):value=value*x+a
    return value


def remainder(p,q):
    assert not zero(q);out=list(p)
    while len(out)>=len(q) and not zero(trim(out)):
        a=out[-1]/q[-1];shift=len(out)-len(q)
        for j,b in enumerate(q):out[shift+j]-=a*b
        out=list(trim(out))
    return trim(out)


@lru_cache(None)
def sturm(p):
    p=trim(p)
    if zero(p):return ()
    seq=[p];d=derivative(p)
    if zero(d):return tuple(seq)
    seq.append(d)
    while True:
        rem=scale(remainder(seq[-2],seq[-1]),-1)
        if zero(rem):break
        # Positive rational scaling preserves the Sturm signs.
        rem=scale(rem,1/abs(rem[-1]));seq.append(rem)
    return tuple(seq)


def sign(x):return 1 if x>0 else -1 if x<0 else 0


def side_sign(p,x,side):
    """Exact one-sided endpoint sign, including repeated roots/gcd zeros."""
    assert side in (-1,1)
    d=p;order=0
    while not zero(d):
        value=evaluate(d,x)
        if value:return sign(value)*(side if order%2 else 1)
        d=derivative(d);order+=1
    return 0


def variation(seq,x,side):
    signs=[side_sign(p,x,side) for p in seq]
    signs=[v for v in signs if v]
    return sum(a!=b for a,b in zip(signs,signs[1:]))


def root_count(p,a,b):
    """Count distinct roots strictly in (a,b), using V(a+)-V(b-)."""
    assert a<b and not zero(p)
    seq=sturm(p);count=variation(seq,a,1)-variation(seq,b,-1)
    assert count>=0
    return count


def overlap(x,c,eps,L):
    return max(F(0),min(x+L/2,c+eps)-max(x-L/2,c-eps))


def capture(src,x,L):
    return sum(w*math.prod(overlap(xx,c,src['epsilon'],L) for xx,c in zip(x,y))/(2*src['epsilon'])**src['n'] for y,w in zip(src['centers'],src['weights']))


def average(src,x,L):
    assert L>0
    return capture(src,x,L)/L**src['n']


def density(src,x):
    eps=src['epsilon']
    assert all(xx!=c-eps and xx!=c+eps for y in src['centers'] for xx,c in zip(x,y)), 'receiver on box boundary excluded in these fixtures'
    return sum(w/(2*eps)**src['n'] for y,w in zip(src['centers'],src['weights']) if all(abs(xx-c)<eps for xx,c in zip(x,y)))


def numerator_polynomial(src,x,a,b):
    # Between all face breakpoints every scalar overlap is affine in L.
    first=(2*a+b)/3;second=(a+2*b)/3;result=(F(0),)
    for y,w in zip(src['centers'],src['weights']):
        term=(F(w),)
        for xx,c in zip(x,y):
            u=overlap(xx,c,src['epsilon'],first);v=overlap(xx,c,src['epsilon'],second)
            slope=(v-u)/(second-first);intercept=u-slope*first
            term=multiply(term,(intercept,slope))
        result=add(result,term)
    for L in (first,second,(a+b)/2):
        assert evaluate(result,L)==capture(src,x,L)*(2*src['epsilon'])**src['n']
    return result


def isolate_first_root(p,a,b,iterations=64):
    assert root_count(p,a,b)>0
    original=(a,b);steps=0
    while steps<iterations or root_count(p,a,b)!=1:
        mid=(a+b)/2;steps+=1
        left=root_count(p,a,mid)
        if left:b=mid
        elif evaluate(p,mid)==0:
            return dict(interval=[mid,mid],singleton_rational_root_certified=True,steps=steps,original_interval=original,
                        isolation_root_count=1,left_sign=side_sign(p,mid,-1),right_sign=side_sign(p,mid,1))
        else:a=mid
        assert steps<=160, 'root isolation exceeded explicit budget'
    assert root_count(p,a,b)==1 and evaluate(p,a)!=0 and evaluate(p,b)!=0
    return dict(interval=[a,b],singleton_rational_root_certified=False,steps=steps,original_interval=original,
                isolation_root_count=1,left_sign=sign(evaluate(p,a)),right_sign=sign(evaluate(p,b)))


def first_contact(src,x):
    n=src['n'];eps=src['epsilon'];lam=src['lambda_value'];fx=density(src,x)
    assert 0<=fx<=lam/2
    breaks=sorted({F(0)}|{2*abs(xx-face) for y in src['centers'] for xx,c in zip(x,y) for face in (c-eps,c+eps)})
    # The terminal all-captured interval is explicit, not an omitted large-scale
    # region. Any first hit must occur before this interval decreases forever.
    tail_end=max(breaks[-1]+1,F(2)*src['W']/lam+1)
    endpoints=breaks+[tail_end];threshold=(F(0),)*n+(lam*(2*eps)**n,)
    intervals=[]
    for idx,(a,b) in enumerate(zip(endpoints,endpoints[1:])):
        numerator=numerator_polynomial(src,x,a,b)
        p=add(numerator,scale(threshold,-1))
        intervals.append(dict(index=idx,left=a,right=b,numerator=numerator,threshold_polynomial=threshold,difference_polynomial=p,
                              terminal_all_captured_interval=(idx==len(endpoints)-2),
                              right_extends_to_infinity=(idx==len(endpoints)-2)))
    assert all(evaluate(intervals[-1]['numerator'],L)==src['W']*(2*eps)**n for L in (breaks[-1]+F(1,2),tail_end))
    assert src['W']/tail_end**n<lam
    prefix=[];hit=None
    for row in intervals:
        a,b=row['left'],row['right'];p=row['difference_polynomial']
        if a>0 and evaluate(p,a)==0:
            assert average(src,x,a)==lam
            hit=dict(interval=[a,a],singleton_rational_root_certified=True,steps=0,at_physical_breakpoint=True,
                     physical_interval_index=row['index'],left_sign=side_sign(intervals[row['index']-1]['difference_polynomial'],a,-1),right_sign=side_sign(p,a,1),
                     original_interval=[a,b],isolation_root_count=1)
            break
        assert not zero(p),'identically zero interval must begin with a first contact breakpoint'
        count=root_count(p,a,b);mid=(a+b)/2
        seq=sturm(p)
        certificate=dict(interval_index=row['index'],left=a,right=b,
                         variation_left_plus=variation(seq,a,1),variation_right_minus=variation(seq,b,-1),open_root_count=count,
                         test_point=mid,test_difference=evaluate(p,mid))
        if count:
            hit=isolate_first_root(p,a,b);hit.update(at_physical_breakpoint=False,physical_interval_index=row['index'],sturm_sequence=seq)
            cutoff=hit['interval'][0]
            exclusion=root_count(p,a,cutoff) if cutoff>a else 0
            assert exclusion==0
            hit['within_interval_earlier_root_exclusion']=dict(left=a,right=cutoff,distinct_open_root_count=exclusion)
            prefix.append(dict(**certificate,role='first_root_interval'))
            break
        assert evaluate(p,mid)<0
        prefix.append(dict(**certificate,role='earlier_strictly_negative_interval'))
        if evaluate(p,b)==0:
            assert average(src,x,b)==lam
            nextp=intervals[row['index']+1]['difference_polynomial'] if row['index']+1<len(intervals) else p
            hit=dict(interval=[b,b],singleton_rational_root_certified=True,steps=0,at_physical_breakpoint=True,
                     physical_interval_index=row['index'],left_sign=side_sign(p,b,-1),right_sign=side_sign(nextp,b,1),
                     original_interval=[a,b],isolation_root_count=1)
            break
    assert hit is not None,'fixture has no global positive first contact'
    lo,hi=hit['interval'];assert lo>0 and hit['left_sign']<0
    classification='upward_crossing' if hit['right_sign']>0 else 'level_plateau' if hit['right_sign']==0 else 'tangent_level_contact'
    hit.update(contact_classification=classification,first_contact_means='Earliest L>0 with A_L>=lambda; tangencies retained and distinguished from strict crossings.')
    ages=[]
    for t in (F(1,16),F(1,8),F(1,4),F(1,2),F(3,4),F(7,8)):
        assert t*hi<lo
        small=capture(src,x,t*hi);small_lower=capture(src,x,t*lo)
        lower=small_lower/(lam*hi**n);upper=small/(lam*lo**n);target=t**n
        earlier_average=average(src,x,t*hi)
        assert earlier_average<lam and 0<=lower<=upper<=target
        ages.append(dict(t_equals_exp_minus_h=t,smaller_scale_upper=t*hi,
                         posterior_age_tail_interval=[lower,upper],target_exp_minus_nh=target,
                         target_minus_certified_upper=target-upper,
                         earlier_average_at_smaller_scale_upper=earlier_average,lambda_minus_earlier_average=lam-earlier_average,
                         exact_interval_age_bound_verified=True))
    positive_witnesses=[]
    for L in breaks[1:]+[src['reference_scale']]:
        if average(src,x,L)>lam:positive_witnesses.append(dict(L=L,average=average(src,x,L)))
    # In these fixtures each strict event has an upward earliest contact. The
    # separate tangent regression has no strict-event assertion.
    assert bool(positive_witnesses)==(classification=='upward_crossing')
    return dict(receiver=x,density_at_receiver=fx,lambda_value=lam,excluded_high_density_fee_premise_verified=True,
                first_contact=hit,all_physical_breakpoints=breaks,all_physical_interval_polynomials=intervals,
                earlier_scale_certificates=prefix,all_previous_positive_scales_strictly_below_lambda=True,
                age_tail_certificates=ages,strict_above_lambda_witness=positive_witnesses[0] if positive_witnesses else None,
                strict_event_claimed=bool(positive_witnesses),
                first_strict_cross_boundary_interval=hit['interval'] if positive_witnesses else None,
                strict_target_scope='The first-contact interval is also the first strict-cross boundary for this upward-crossing fixture.' if positive_witnesses else 'Equality-contact regression only; excluded from the strict above-threshold target event.',
                terminal_scale_cutoff=tail_end,terminal_average_below_lambda=src['W']/tail_end**n,
                terminal_extension_reason='After the last physical face breakpoint capture mass is W, so A_L=W/L^n decreases to zero; the terminal polynomial extends to infinity.',
                receiver_scope='A fixed rational point in original Lebesgue x coordinates; no receiver quadrature and no weak-volume estimate.')


def source(label,n,centers,weights,epsilon,lam,reference_scale=F(2)):
    centers=[tuple(map(F,y)) for y in centers];weights=list(map(F,weights))
    assert all(w>0 for w in weights)
    return dict(label=label,n=n,N=len(centers),centers=centers,weights=weights,epsilon=F(epsilon),lambda_value=F(lam),W=sum(weights),
                actual_input='f(y)=sum_i w_i*1_{box(c_i,epsilon)}(y)/(2epsilon)^n; positive finite L1 density',reference_scale=F(reference_scale))



@lru_cache(maxsize=400000)
def phi_tail(u,M=64):
 u=abs(float(u))
 if u==0:return .5
 def f(t):
  if not t:return 0.
  if u>=.5:return t*t*math.exp(-(u-.5)/t)*(-math.expm1(-1/t))
  return 2*t*(.5-u)+t*t*(math.exp(-(.5-u)/t)-math.exp(-(u+.5)/t))
 return (f(0)+f(1)+sum((4 if j%2 else 2)*f(j/M) for j in range(1,M)))/(3*M)

def phi_int(lo,hi,M=64):
 if lo>=0:return phi_tail(lo,M)-phi_tail(hi,M)
 if hi<=0:return phi_tail(-hi,M)-phi_tail(-lo,M)
 return 1-phi_tail(-lo,M)-phi_tail(hi,M)

@lru_cache(maxsize=200000)
def phi_value(u,M=64):
 u=abs(float(u))
 def f(t):
  if not t:return 0.
  if u>=.5:return t*math.exp(-(u-.5)/t)*(-math.expm1(-1/t))
  return t*(2-math.exp(-(.5-u)/t)-math.exp(-(u+.5)/t))
 return (f(0)+f(1)+sum((4 if j%2 else 2)*f(j/M) for j in range(1,M)))/(3*M)


def setup(n,refined=False):
    target=2*n*n if refined else 2*n
    S=(target-1).bit_length();eps=F(1,2**S);alpha=(1-eps)**n
    assert eps<=F(1,2*n) and alpha>=F(1,2)
    remainder_mass=n*(1-eps)*(1-(1-eps)**(n-1))
    if refined:assert remainder_mass<=F(1,2)
    return dict(depth=S,epsilon=eps,alpha=alpha,kappa=n*(1-eps),face_remainder_kernel_mass=remainder_mass,mode='fine_2n2' if refined else 'standard_2n')


def fixtures():
    stages=[];pilot=[]
    for n in (1,2):
        width=F(1,64);center=F(3,4);lam=F(3,4)/(2*(center+width))**n
        src=source(f'narrow_single_n{n}',n,[(center,)*n],[1],width,lam)
        xs=[(F(0),)*n,tuple(F(1 if j%2==0 else -1,512) for j in range(n)),tuple(F(-1 if j%2==0 else 1,512) for j in range(n))]
        pilot.append((src,xs))
    stages.append(('pilot',pilot))
    for stage,specs in [('pressure',((2,3),(4,6))),('expanded',((4,8),(8,12)))]:
        cases=[]
        for n,N in specs:
            rng=random.Random(SEED+100*n+N);eps=F(1,16)
            centers=[tuple(F(12+i%7,16)+F(rng.randrange(-2,3),64) for _ in range(n)) for i in range(N)]
            ints=[1+i%4 for i in range(N)];weights=[F(w,sum(ints)) for w in ints]
            tmp=source('tmp',n,centers,weights,eps,1);lam=average(tmp,(F(0),)*n,F(2))/2
            centers.append((F(0),)*n);weights.append(lam*(2*eps)**n/4)
            src=source(f'correlated_n{n}_N{N+1}',n,centers,weights,eps,lam)
            xs=[(F(0),)*n,tuple(F(1 if j%2==0 else -1,64) for j in range(n)),tuple(F(-1 if j%2==0 else 1,64) for j in range(n))]
            cases.append((src,xs))
        stages.append((stage,cases))
    n=16;eps=F(1,64);centers=[(c,)*n for c in(F(3,4),F(17,20),F(19,20))];weights=[F(1,6),F(1,3),F(1,2)];lam=F(1,2**17)
    centers.append((F(0),)*n);weights.append(lam*(2*eps)**n/4)
    src=source('directional_correlated_n16_N4',n,centers,weights,eps,lam)
    stages[-1][1].append((src,[(F(0),)*n,tuple(F(1 if j%2==0 else -1,1024) for j in range(n)),tuple(F(-1 if j%2==0 else 1,1024) for j in range(n))]))
    return stages


def coordinate(d,e,L,M=64):
    hard=max(0.,min(d+e,L/2)-max(d-e,-L/2))/(2*e*L)
    soft=phi_int((d-e)/L,(d+e)/L,M)/(2*e)
    return hard,soft


def kernels(src,x,L,params,M=64):
    e=float(src['epsilon']);out=[0.]*len(params)
    for y,w in zip(src['centers'],src['weights']):
        pairs=[coordinate(float(xx-yy),e,L,M) for xx,yy in zip(x,y)]
        for j,p in enumerate(params):out[j]+=float(w)*math.prod((1-float(p))*h+float(p)*f for h,f in pairs)
    return out


def inside_split(src,x,L,params,M=128):
    """Physical y in the SAME hard first-hit cube, with original source density."""
    e=float(src['epsilon']);inside=[0.]*len(params);source_rows=[]
    for y,w in zip(src['centers'],src['weights']):
        pairs=[];lengths=[]
        for xx,yy in zip(x,y):
            d=float(xx-yy);low=max(d-e,-L/2);high=min(d+e,L/2);length=max(0.,high-low);lengths.append(length)
            h=length/(2*e*L);f=phi_int(low/L,high/L,M)/(2*e) if length else 0.
            pairs.append((h,f))
        vals=[float(w)*math.prod((1-float(p))*h+float(p)*f for h,f in pairs) for p in params]
        for j,z in enumerate(vals):inside[j]+=z
        source_rows.append(dict(center=y,source_weight=w,captured_mass=float(w)*math.prod(z/(2*e) for z in lengths),inside_values=vals))
    total=kernels(src,x,L,params,M);outside=[a-b for a,b in zip(total,inside)];hard=capture(src,x,F(L))/F(L)**src['n']
    assert max(abs(total[0]-float(hard)),abs(inside[0]-float(hard)))<1e-10*float(src['W'])
    assert all(z>=-1e-13*float(src['W']) for z in outside)
    return dict(parameters=params,total=total,inside=inside,outside=outside,source_rows=source_rows,hard_average_at_float_tau=hard,
                inside_posterior_kernel_expectations=[z/float(hard) for z in inside],
                scope='Inside means original source y in physical Q(x,tau), not noise activation. E2 values diagnostic. Hardposterior age law is assigned only to this captured y measure. Outside soft sources are kept separately.')


def physical_breaks(src,x,left=1.,right=2.):
    return sorted(set(float(2*abs(xx-yy+sgn*src['epsilon'])) for y in src['centers'] for xx,yy in zip(x,y) for sgn in(-1,1) if left<float(2*abs(xx-yy+sgn*src['epsilon']))<right))


def fields(src,x,L,eps,M=64,masks=None):
    e=float(src['epsilon']);eps=float(eps);n=src['n'];out=dict(U=0.,P1=0.,Face=0.,FaceH=0.,FaceR=0.,v=0.)
    for idx,(y,w) in enumerate(zip(src['centers'],src['weights'])):
        d=[float(xx-yy) for xx,yy in zip(x,y)];pairs=[coordinate(z,e,L,M) for z in d];values=[]
        for p in(eps,1.):
            psi=[(1-p)*h+p*f for h,f in pairs];prod=math.prod(psi);B=[];beta=[]
            for j,(z,(h,f)) in enumerate(zip(d,pairs)):
                lo=(z-e)/L;hi=(z+e)/L
                B.append(-p*(1-p)*h+p*(1-p)*f-p*(hi*phi_value(hi,M)-lo*phi_value(lo,M))/(2*e))
                flags=masks[idx][j] if masks is not None else (abs(z-L/2)<e,abs(z+L/2)<e)
                beta.append(sum(flags)/(4*e))
            if p==0:
                centered=0.;face=sum(beta[j]*math.prod(psi[k] for k in range(n) if k!=j) for j in range(n))
            else:
                centered=prod*sum(bb/pp for bb,pp in zip(B,psi));face=(1-p)*prod*sum(bb/pp for bb,pp in zip(beta,psi))
            values.append((prod,centered,face))
        weight=float(w);out['U']+=weight*(values[0][0]-values[1][0]);out['P1']+=weight*values[1][0];out['Face']+=weight*values[0][2];out['v']+=weight*(values[0][1]-values[1][1])
        hardface=sum(beta[j]*math.prod(pairs[k][0] for k in range(n) if k!=j) for j in range(n));remainder=values[0][2]-(1-eps)**n*hardface
        assert remainder>=-1e-12*float(src['W'])
        out['FaceH']+=weight*hardface;out['FaceR']+=weight*remainder
    return out


def integration(src,x,eps,lo,hi,tau,Mscale,Mphi,extra=()):
    """logL integral; fixed physical face masks on each smooth segment."""
    if hi<=lo:return dict(U=0.,P1=0.,Face=0.,FaceH=0.,FaceR=0.,v=0.,damped_Face=0.,damped_FaceH=0.,damped_FaceR=0.,damped_v=0.,damped_P1=0.,R_prefix_values=[0.],nodes=0)
    kappa=src['n']*(1-float(eps));knots=sorted(set([lo,hi]+physical_breaks(src,x,lo,hi)+[z for z in extra if lo<z<hi]));out={k:0. for k in('U','P1','Face','FaceH','FaceR','v','damped_Face','damped_FaceH','damped_FaceR','damped_v','damped_P1')};prefix=[0.];nodes=0
    for left,right in zip(knots,knots[1:]):
        middle=(left+right)/2;masks=[[(abs(float(xx-yy)-middle/2)<float(src['epsilon']),abs(float(xx-yy)+middle/2)<float(src['epsilon'])) for xx,yy in zip(x,y)] for y in src['centers']]
        A=math.log(left);B=math.log(right);step=(B-A)/Mscale;segment_v=0.
        for j in range(Mscale+1):
            L=math.exp(A+j*step);f=fields(src,x,L,eps,Mphi,masks);nodes+=1
            weight=step/3*(1 if j in(0,Mscale) else 4 if j%2 else 2);damping=(L/tau)**kappa
            for key in('U','P1','Face','FaceH','FaceR','v'):out[key]+=weight*f[key]
            for key in('Face','FaceH','FaceR','v','P1'):out['damped_'+key]+=weight*damping*f[key]
            segment_v+=weight*f['v']
        prefix.append(prefix[-1]+segment_v)
    out.update(R_prefix_values=prefix,nodes=nodes,knots=knots)
    return out


def bisect(f,left,right,level):
    for _ in range(38):
        mid=(left+right)/2
        if f(mid)>=level:right=mid
        else:left=mid
    return (left+right)/2


@lru_cache(None)
def eighth_root(n):
    lo=F(0);hi=F(1)
    for _ in range(80):
        mid=(lo+hi)/2
        if mid**n<=F(1,8):lo=mid
        else:hi=mid
    assert lo**n<=F(1,8)<=hi**n
    return lo,hi


def zero_fresh_certificate(src,x,tau_interval):
    lo,hi=tau_interval;n=src['n'];lam=src['lambda_value'];cl,ch=eighth_root(n)
    # max(1,tau/8^(1/n)) is monotone; no logarithm enters the exact interval.
    start_lo=max(F(1),lo*cl);start_hi=max(F(1),hi*ch)
    cap_lo=capture(src,x,start_lo);cap_hi=capture(src,x,start_hi);cap1=capture(src,x,F(1))
    fresh_lo=lam-cap_hi/lo**n;fresh_hi=lam-cap_lo/hi**n
    old_lo=max(F(0),(cap_lo-cap1)/hi**n);old_hi=max(F(0),(cap_hi-cap1)/lo**n)
    assert start_hi<lo and average(src,x,start_hi)<lam
    assert old_hi<=lam/8 and fresh_lo<=fresh_hi
    return dict(eighth_root_interval=[cl,ch],physical_start_interval=[start_lo,start_hi],earlier_average_at_start_upper=average(src,x,start_hi),
        capture_start_interval=[cap_lo,cap_hi],pure_hard_fresh_interval=[fresh_lo,fresh_hi],old_face_interval=[old_lo,old_hi],old_face_upper=old_hi,old_target=lam/8,
        scope='Exact Fraction root-power/capture brackets at same globally certified hardfirsthit. Fresh hardface equals lambda-capture(start)/tau^n; oldhardface equals [capture(start)-capture(1)]/tau^n. No E2 term in this certificate.')


def endpoint_record(src,x,hard,setting):
    n=src['n'];eps=setting['epsilon'];alpha=setting['alpha'];kappa=float(setting['kappa']);lam=float(src['lambda_value']);theta=float(alpha)*lam/2
    bracket=hard['first_contact']['interval'];tau=float((bracket[0]+bracket[1])/2);T=math.log(2);tstar=math.log(tau)
    assert 1<tau<=2 and hard['strict_event_claimed']
    same=kernels(src,x,tau,[0,eps,1],128);same64=kernels(src,x,tau,[0,eps,1],64);U=same[1]-same[2];u0v=kernels(src,x,1,[eps,1],128);U0=u0v[0]-u0v[1]
    # Physical grid plus every boxface; diagnostics cannot certify continuum gates.
    grid=sorted(set([2**(j/64) for j in range(65)]+physical_breaks(src,x)));sample=[kernels(src,x,L,[eps,1],128) for L in grid];smooth=max(v[1] for v in sample)
    zero_mode=setting['mode']=='hard_zero'
    h=math.log(8)/n if zero_mode else math.log(n+2)/(2*kappa);cut=max(1.,tau*math.exp(-h));prefix_grid=[L for L in grid if L<tau]
    coarse=integration(src,x,eps,1.,tau,tau,4,64,extra=prefix_grid+[cut]);fine=integration(src,x,eps,1.,tau,tau,8,128,extra=prefix_grid+[cut]);whole=integration(src,x,eps,1.,2.,tau,8,128,extra=grid)
    zero_cert=zero_fresh_certificate(src,x,bracket) if zero_mode else None
    old=integration(src,x,eps,1.,cut,tau,8,128);fresh=integration(src,x,eps,cut,tau,tau,8,128)
    raw_Z=fresh['damped_Face']-kappa*fresh['damped_P1']
    purehard_mid=float(sum(zero_cert['pure_hard_fresh_interval'])/2) if zero_mode else None
    Z=purehard_mid-kappa*fresh['damped_P1'] if zero_mode else raw_Z
    old_face=old['damped_Face'];Rsup=max(map(abs,whole['R_prefix_values']));Qcont=abs(U0)+2*Rsup
    reconstructed=math.exp(-kappa*tstar)*U0+fine['damped_Face']+fine['damped_v']-kappa*fine['damped_P1'];residual=U-reconstructed
    integrated_lhs=U-U0+kappa*fine['U']+kappa*fine['P1'];integrated_rhs=fine['Face']+fine['v']
    gates=dict(exact_low_source_density=hard['excluded_high_density_fee_premise_verified'],exact_global_hard_firsthit=True,exact_A1_below_lambda=average(src,x,F(1))<src['lambda_value'],
               same_tau_smooth=same[2]<=theta,registered_window_smooth=smooth<=theta,registered_Qcont=Qcont<=theta/4,computed_old_face=old_face<=theta/4)
    if zero_mode:
        gates['exact_zero_old_bound']=zero_cert['old_face_upper']<=src['lambda_value']/8
    allgates=all(gates.values());assert not allgates or Z>=theta/2-1e-8*float(src['W'])
    uvals=[v[0]-v[1] for v in sample];corridor=None
    if U0<theta/2 and U>=theta:
        before=sorted(set([1.,tau]+[L for L in grid if L<tau]));vv=[kernels(src,x,L,[eps,1],128) for L in before];us=[v[0]-v[1] for v in vv]
        j=next((j for j in range(len(before)-2,-1,-1) if us[j]<theta/2),None)
        if j is not None:
            def uf(L):p=kernels(src,x,L,[eps,1],128);return p[0]-p[1]
            rho=bisect(uf,before[j],before[j+1],theta/2);c=integration(src,x,eps,rho,tau,tau,8,128);d=math.log(tau/rho);load=kappa*d+2*kappa*c['P1']/theta
            corridor=dict(rho=rho,tau=tau,theta=theta,log_length=d,load=load,U_at_rho=uf(rho),U_at_same_hard_tau=U,
                          integrals={key:c[key] for key in('Face','v','U','P1')},identity_residual=c['Face']+c['v']-(U-uf(rho)+kappa*c['U']+kappa*c['P1']),
                          lower_load_margin=c['Face']+c['v']-theta*(1+load)/2,
                          scope='Last half-threshold bracket on registered physical path, numerically bisected; same global certified HARD tau. U may exceed theta before tau. No certified continuous last-half root or general event membership.')
    split=inside_split(src,x,tau,[0,eps,1])
    minimal_anchor=average(src,x,F(1))<src['lambda_value']/2
    return dict(setting=setting,lambda_value=src['lambda_value'],theta=theta,same_hard_tau=tau,hard_tau_exact_interval=bracket,U_same_tau=U,U_anchor_L1=U0,
                endpoint_values=same,endpoint_tail_majorization_margin=same[1]-float(alpha)*same[0],endpoint_U_threshold_margin=U-theta,endpoint_64_128_refinement=max(abs(a-b) for a,b in zip(same,same64)),inside_outside_at_same_tau=split,
                registered_physical_grid=grid,registered_smooth_sup=smooth,registered_R_sup=Rsup,Qcont=Qcont,gates=gates,all_registered_gates_pass=allgates,
                minimal_anchor_gate=minimal_anchor,minimal_zero_registered_gates_pass=zero_mode and minimal_anchor and smooth<=lam/2 and same[2]<=lam/2,
                resolvent=dict(kappa=kappa,tstar=tstar,h=h,fresh_log_length=math.log(tau/cut),old_cut_physical_L=cut,anchor_damped=math.exp(-kappa*tstar)*U0,
                    damped_face=fine['damped_Face'],damped_v=fine['damped_v'],negative_background=-kappa*fine['damped_P1'],reconstructed_U=reconstructed,identity_residual=residual,
                    coarse_fine_difference=sum(abs(fine[key]-coarse[key]) for key in('U','P1','Face','FaceH','FaceR','v','damped_Face','damped_FaceH','damped_FaceR','damped_v','damped_P1')),
                    undamped_identity_residual=integrated_rhs-integrated_lhs,old_face=old_face,fresh_face=fresh['damped_Face'],fresh_negative_background=-kappa*fresh['damped_P1'],fresh_signed_Z=Z,fresh_signed_with_raw_face_quadrature=raw_Z,fresh_hard_basis='exact capture interval midpoint' if zero_mode else 'face quadrature',fresh_pure_hard_exact_midpoint=purehard_mid,fresh_target=theta/2,fresh_margin=Z-theta/2,minimal_zero_fresh_target=7*lam/16 if zero_mode else None,minimal_zero_fresh_margin=Z-7*lam/16 if zero_mode else None,
                    old_face_envelope=math.exp(-kappa*h)*whole['Face'],old_envelope_damping=math.exp(-kappa*h),old_envelope_margin=math.exp(-kappa*h)*whole['Face']-old_face,
                    source_face_window=whole['Face'],face_H_window=whole['FaceH'],face_remainder_window=whole['FaceR'],damped_face_H=fine['damped_FaceH'],damped_face_remainder=fine['damped_FaceR'],old_face_H=old['damped_FaceH'],old_face_remainder=old['damped_FaceR'],fresh_face_H=fresh['damped_FaceH'],fresh_face_remainder=fresh['damped_FaceR'],face_decomposition_residual=fine['damped_Face']-(float(alpha)*fine['damped_FaceH']+fine['damped_FaceR']),quadrature_nodes=fine['nodes']+coarse['nodes']+whole['nodes']+old['nodes']+fresh['nodes']),
                positive_corridor=corridor,hard_zero_fresh_certificate=zero_cert,hard_zero_fresh_quadrature_difference=fresh['damped_Face']-float(sum(zero_cert['pure_hard_fresh_interval'])/2) if zero_mode else None,scope='Fixed original Lebesgue receiver point, exact hardfirsthit only. True E2 endpoint sourcebox/flux integrals by Simpson quadrature. All smooth, continuous primitive, oldface and last-half-root numerical gates are diagnostic, not certified continuum enclosures. No receivervolume claim.')


def main():
    start=time.monotonic();out=[]
    for stage,cases in fixtures():
        rows=[]
        for src,xs in cases:
            rr=[]
            for x in xs:
                hard=first_contact(src,x);records=[endpoint_record(src,x,hard,setup(src['n'],r)) for r in(False,True)]+[endpoint_record(src,x,hard,dict(depth=0,epsilon=F(0),alpha=F(1),kappa=F(src['n']),face_remainder_kernel_mass=F(0),mode='hard_zero'))]
                rr.append(dict(receiver=x,hard_firsthit_certificate=hard,endpoint_records=records))
            rows.append(dict(source=src,receivers=rr));print(stage,src['label'],'elapsed',round(time.monotonic()-start,3),flush=True)
        out.append(dict(stage=stage,cases=rows))
    records=[r for s in out for c in s['cases'] for x in c['receivers'] for r in x['endpoint_records']]
    obj=dict(status='PASS',seed=SEED,stages=out,counts=dict(stages=len(out),inputs=sum(len(s['cases']) for s in out),receiver_point_certificates=len(records)//3,endpoint_records=len(records),same_tau_smooth_pass=sum(r['gates']['same_tau_smooth'] for r in records),all_registered_gates_pass=sum(r['all_registered_gates_pass'] for r in records),minimal_zero_registered_gates_pass=sum(r['minimal_zero_registered_gates_pass'] for r in records),positive_corridors=sum(r['positive_corridor'] is not None for r in records),quadrature_nodes=sum(r['resolvent']['quadrature_nodes'] for r in records)),
             definition='U=Pepsilon-P1; epsilon in{0,dyadic<=1/(2n),dyadic<=1/(2n²)}, alpha=(1-epsilon)^n, theta=alpha lambda/2, kappa=n(1-epsilon). Actual Ulogderivative=Faceepsilon+(Bepsilon-B1)*f-kappa U-kappa P1. SAME exact global hardfirsthit tau in[1,2], no private softwinner substitution.',
             scope='Exact rational/Sturm hard first-contact and captured-source age comparisons for registered positiveL1 boxinputs at fixed rational receiver points. E2 sourceintegrals, flux/resolvent, smoothsup and Qcont gates numerical only. No empiricalnoise prior, continuousgate certificate, eventvolume or targetweakbound.')
    path=Path(__file__).with_name('endpoint_results.json');path.write_text(json.dumps(clean(obj),sort_keys=True,separators=(',',':'))+'\n');print('PASS',obj['counts'],'seconds',time.monotonic()-start,flush=True)
if __name__=='__main__':main()
