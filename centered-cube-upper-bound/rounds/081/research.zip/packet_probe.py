#!/usr/bin/env python3
"""Complete-cell finite labelled-noise packet-duty LP with rational witnesses.

Finite algebra model, not an E2 approximation certificate. Float simplex only
finds candidates; independently rebuilt Fraction inequalities certify bounds.
"""
from fractions import Fraction as F
from pathlib import Path
from itertools import product
from math import prod
import json, time, hashlib


def clean(x):
    if isinstance(x,F):return str(x)
    if isinstance(x,dict):return {str(k):clean(v) for k,v in x.items()}
    if isinstance(x,(tuple,list)):return [clean(v) for v in x]
    return x


def fixture(label,n,coordinates,scales,tau,delta=None,weights=None,background_bound=F(1)):
    centers=[tuple(map(F,y)) for y in coordinates]
    weights=list(map(F,weights or [F(1,len(centers))]*len(centers)))
    assert len(set(centers))==len(centers) and all(p>0 for p in weights)
    return dict(label=label,n=n,N=len(centers),centers=centers,weights=weights,
                physical_source_type='Positive finite atomic measure on distinct physical sites; not an L1 box-density fixture.',
                scales=list(map(F,scales)),delta=F(delta or F(1,n)),tau=F(tau),background_bound=F(background_bound))


def kernel_values(n,delta,L):
    # Coordinate soft law: shifts -1,0,1 with probabilities 1/4,1/2,1/4.
    # Interior coordinate state: central, shifted outer tile, or no support.
    out=[]
    for m in range(n+1):
        alpha=(1-delta/4)**(n-m)*(delta/8)**m/L**n
        beta=(1-delta/2)**(n-m)*(delta/4)**m/L**n
        out.append((alpha-beta,(alpha+beta)/2))
    out.append((F(0),F(0)))
    return out


def noise_certificate(n,delta):
    endpoints=[]
    for a in (delta/2,delta):
        labels=[('hard',F(0),1-a),('soft',F(-1),a/4),('soft',F(0),a/2),('soft',F(1),a/4)]
        joint=[]
        for terms in product(labels,repeat=n):
            joint.append(dict(tags=[z[0] for z in terms],shifts=[z[1] for z in terms],probability=prod(z[2] for z in terms)))
        assert sum(t['probability'] for t in joint)==1
        endpoints.append(dict(a=a,labels=joint,mass=F(1)))
    return dict(soft_coordinate_law=[[-1,F(1,4)],[0,F(1,2)],[1,F(1,4)]],
                original_hard_and_soft_zero_labels_distinct=True,endpoints=endpoints,
                approximation_scope='Exact finite probability-noise algebra model; no quantitative bridge to actual E2 is supplied.')


def arrangement(src):
    n,N,K=src['n'],src['N'],len(src['scales'])
    # Every shifted cube face, including zero-shift hard and soft labels.
    axes=[]
    for j in range(n):
        axes.append(sorted({y[j]+L*(z+side) for y in src['centers'] for L in src['scales']
                            for z in (F(-1),F(0),F(1)) for side in (F(-1,2),F(1,2))}))
    lengths=[[b-a for a,b in zip(axis,axis[1:])] for axis in axes]
    mids=[[(a+b)/2 for a,b in zip(axis,axis[1:])] for axis in axes]
    states=[]
    for j in range(n):
        axis_states=[]
        for x in mids[j]:
            row=[]
            for y in src['centers']:
                for L in src['scales']:
                    z=abs((x-y[j])/L)
                    row.append(0 if z<F(1,2) else 1 if z<F(3,2) else 2)
            axis_states.append(row)
        states.append(axis_states)
    kval=[kernel_values(n,src['delta'],L) for L in src['scales']]
    patterns={};cells=0;digest=hashlib.sha256();outside=0
    for indices in product(*(range(len(x)) for x in lengths)):
        volume=prod(lengths[j][indices[j]] for j in range(n));ds=[];fs=[]
        for i,p in enumerate(src['weights']):
            for k in range(K):
                s=[states[j][indices[j]][i*K+k] for j in range(n)]
                m=n+1 if 2 in s else sum(s)
                d,f=kval[k][m];ds.append(p*d);fs.append(p*f)
        key=tuple(ds+fs)
        if key not in patterns:patterns[key]=dict(volume=F(0),cell_count=0,representative=[mids[j][indices[j]] for j in range(n)])
        row=patterns[key];row['volume']+=volume;row['cell_count']+=1;cells+=1
        digest.update((str(indices)+':'+str(volume)+':'+str(key)+'\n').encode())
        if not any(fs):outside+=1
    records=[];events=[];ties=0
    for key,item in patterns.items():
        ds=key[:N*K];fs=key[N*K:]
        T=[sum(ds[i*K+k] for i in range(N)) for k in range(K)]
        B=[sum(fs[i*K+k] for i in range(N)) for k in range(K)]
        winner=max(range(K),key=lambda k:(T[k],-k))
        positive_crossing=T[winner]>src['tau'];selected_low=B[winner]<=src['background_bound']
        event=positive_crossing and selected_low
        if event and sum(t==T[winner] for t in T)>1:ties+=item['cell_count']
        rec=dict(**item,weighted_signed_source_fields=list(ds),weighted_source_backgrounds=list(fs),
                 T=T,F=B,winner=winner,event=event,positive_crossing=positive_crossing,selected_low=selected_low)
        records.append(rec)
        if event:events.append(rec)
    volume=sum(r['volume'] for r in events)
    assert volume>0
    kernel_mass_residuals=[]
    for i in range(N):
        for k in range(K):
            signed_mass=sum(r['volume']*r['weighted_signed_source_fields'][i*K+k] for r in records)
            background_mass=sum(r['volume']*r['weighted_source_backgrounds'][i*K+k] for r in records)
            assert signed_mass==0 and background_mass==src['weights'][i]
            kernel_mass_residuals.append(dict(source=i,scale=k,signed_mass=signed_mass,background_mass=background_mass))
    return dict(axes=axes,cell_count=cells,field_pattern_count=len(records),event_cell_count=sum(r['cell_count'] for r in events),
                positive_crossing_volume=sum(r['volume'] for r in records if r['positive_crossing']),
                excluded_by_selected_low_gate_volume=sum(r['volume'] for r in records if r['positive_crossing'] and not r['selected_low']),
                event_pattern_count=len(events),event_volume=volume,tau_event_volume=src['tau']*volume,
                winner_tie_cell_count=ties,zero_field_cell_count=outside,complete_cell_digest=digest.hexdigest(),
                bounded_outer_box_volume=prod(axis[-1]-axis[0] for axis in axes),
                exact_kernel_mass_checks=kernel_mass_residuals,field_patterns=records),events


def packet_model(src,arr,events,packets):
    N,K=src['N'],len(src['scales']);packets=[tuple(p) for p in packets]
    assert all(P and len(set(P))==len(P) and all(0<=i<N for i in P) for P in packets)
    prices=[];positive_only_omitted=[]
    for P in packets:
        patterns={};omitted=F(0)
        for r in arr['field_patterns']:
            signed=tuple(sum(r['weighted_signed_source_fields'][i*K+k] for i in P) for k in range(K))
            # q>=0: negative coordinates are redundant in max(0,q_k G_k).
            key=tuple(max(F(0),z) for z in signed)
            if not any(key):omitted+=r['volume'];continue
            patterns[key]=patterns.get(key,F(0))+r['volume']
        prices.append([dict(field=list(v),volume=w) for v,w in patterns.items()])
        positive_only_omitted.append(omitted)
    rows={}
    for r in events:
        k=r['winner'];a=tuple(sum(r['weighted_signed_source_fields'][i*K+k] for i in P) for P in packets)
        key=(k,a)
        if key not in rows:rows[key]=dict(winner=k,coefficients=list(a),volume=F(0),cell_count=0,representative=r['representative'])
        rows[key]['volume']+=r['volume'];rows[key]['cell_count']+=r['cell_count']
    return dict(packets=packets,price_patterns=prices,omitted_nonpositive_pattern_volumes=positive_only_omitted,
                event_rows=list(rows.values()),event_volume=arr['event_volume'],N=N,K=K)


def simplex_candidate(A,b,c):
    """Floating max c*x subject A*x<=b, x>=0. Used only to find witnesses."""
    m=len(b);v=len(c);rows=[[float(z) for z in row]+[float(i==j) for j in range(m)]+[float(b[i])] for i,row in enumerate(A)]
    reduced=list(map(float,c))+[0.0]*m;basis=list(range(v,v+m));pivots=0;value=0.0
    while True:
        candidates=[j for j,z in enumerate(reduced) if z>1e-9]
        if not candidates:break
        entering=max(candidates,key=lambda j:(reduced[j],-j))
        eligible=[i for i,row in enumerate(rows) if row[entering]>1e-10]
        assert eligible,'candidate dual reported unbounded'
        leaving=min(eligible,key=lambda i:(max(0.0,rows[i][-1])/rows[i][entering],basis[i]))
        pivot=rows[leaving][entering];row=[z/pivot for z in rows[leaving]];rows[leaving]=row
        for i in range(m):
            if i!=leaving:
                a=rows[i][entering]
                if abs(a)>1e-13:rows[i]=[z-a*t for z,t in zip(rows[i],row)]
        a=reduced[entering];value+=a*row[-1];reduced=[z-a*t for z,t in zip(reduced,row[:-1])]
        basis[leaving]=entering;pivots+=1
        assert pivots<5000,'bounded simplex pivot budget'
    x=[0.0]*v
    for i,j in enumerate(basis):
        if j<v:x[j]=max(0.0,rows[i][-1])
    u=[max(0.0,-reduced[v+i]) for i in range(m)]
    primal_res=max([0.0]+[sum(float(a)*z for a,z in zip(row,x))-float(rhs) for row,rhs in zip(A,b)])
    dual_res=max([0.0]+[float(c[j])-sum(float(A[i][j])*u[i] for i in range(m)) for j in range(v)])
    return x,u,dict(pivots=pivots,float_objective=value,float_max_dual_constraint_residual=primal_res,
                    float_max_primal_constraint_residual=dual_res,candidate_only=True)


def build_dual(model,tau):
    N,K=model['N'],model['K'];G=len(model['packets']);R=len(model['event_rows'])
    beta_keys=[]
    for g,patterns in enumerate(model['price_patterns']):
        for a,pat in enumerate(patterns):
            for k,d in enumerate(pat['field']):
                if d>0:beta_keys.append((g,a,k))
    beta_index={key:R+j for j,key in enumerate(beta_keys)}
    gamma_start=R+len(beta_keys);kappa_start=gamma_start+G*K;v=kappa_start+N
    A=[];b=[]
    for g in range(G):
        for k in range(K):
            row=[F(0)]*v
            for r,event in enumerate(model['event_rows']):
                if event['winner']==k:row[r]=event['coefficients'][g]
            for a,pat in enumerate(model['price_patterns'][g]):
                if pat['field'][k]>0:row[beta_index[g,a,k]]=-pat['field'][k]
            row[gamma_start+g*K+k]=-1;A.append(row);b.append(F(0))
    price_row_keys=[]
    for g,patterns in enumerate(model['price_patterns']):
        for a,pat in enumerate(patterns):
            row=[F(0)]*v
            for k in range(K):
                if (g,a,k) in beta_index:row[beta_index[g,a,k]]=1
            A.append(row);b.append(pat['volume']);price_row_keys.append((g,a))
    for g,P in enumerate(model['packets']):
        row=[F(0)]*v
        for k in range(K):row[gamma_start+g*K+k]=1
        for i in P:row[kappa_start+i]=-1
        A.append(row);b.append(F(0))
    c=[tau]*R+[F(0)]*(len(beta_keys)+G*K)+[F(-1)]*N
    return A,b,c,dict(beta_keys=beta_keys,gamma_start=gamma_start,kappa_start=kappa_start,price_row_keys=price_row_keys)


def rational_nonnegative(x):return max(F(0),F(str(round(x,10))))


def certify(model,src):
    tau=src['tau'];N,K=model['N'],model['K'];G=len(model['packets']);R=len(model['event_rows'])
    A,b,c,index=build_dual(model,tau);x,u,diagnostic=simplex_candidate(A,b,c)
    q=[[rational_nonnegative(u[g*K+k]) for k in range(K)] for g in range(G)]
    theta_offset=G*K+len(index['price_row_keys']);theta=[rational_nonnegative(z) for z in u[theta_offset:theta_offset+G]]
    q=[[min(z,theta[g]) for z in row] for g,row in enumerate(q)]
    loads=[sum(theta[g] for g,P in enumerate(model['packets']) if i in P) for i in range(N)]
    capscale=min([F(1)]+[1/z for z in loads if z>1])
    theta=[z*capscale for z in theta];q=[[z*capscale for z in row] for row in q]
    # Feasible all-source fallback is supplied by a disjoint partition present
    # in this library, never by free columns or repeated source mass.
    fallback=[];covered=set()
    for g,P in enumerate(model['packets']):
        if not covered.intersection(P):fallback.append(g);covered.update(P)
        if len(covered)==N:break
    assert covered==set(range(N))
    q0=[[F(g in fallback)]*K for g in range(G)];th0=[F(g in fallback) for g in range(G)]
    eta=F(0)
    for row in model['event_rows']:
        k=row['winner'];v=sum(a*q[g][k] for g,a in enumerate(row['coefficients']))
        full=sum(a*q0[g][k] for g,a in enumerate(row['coefficients']));assert full>tau
        if v<tau:eta=max(eta,(tau-v)/(full-v))
    assert 0<=eta<=1
    theta=[(1-eta)*z+eta*t for z,t in zip(theta,th0)]
    q=[[(1-eta)*z+eta*t for z,t in zip(row,fallbackrow)] for row,fallbackrow in zip(q,q0)]
    # Remove unused capacity in a degenerate candidate without changing q/cost.
    theta=[max(row) for row in q]
    epigraph=[[max([F(0)]+[q[g][k]*d for k,d in enumerate(pat['field'])]) for pat in patterns] for g,patterns in enumerate(model['price_patterns'])]
    upper=sum(pat['volume']*e for patterns,es in zip(model['price_patterns'],epigraph) for pat,e in zip(patterns,es))
    y=[rational_nonnegative(z) for z in x[:R]]
    beta=[[[F(0)]*K for _ in patterns] for patterns in model['price_patterns']]
    for j,(g,a,k) in enumerate(index['beta_keys']):beta[g][a][k]=rational_nonnegative(x[R+j])
    budgetscale=F(1)
    for patterns,bs in zip(model['price_patterns'],beta):
        for pat,row in zip(patterns,bs):
            s=sum(row)
            if s>pat['volume']:budgetscale=min(budgetscale,pat['volume']/s)
    y=[z*budgetscale for z in y];beta=[[[z*budgetscale for z in row] for row in bs] for bs in beta]
    gamma=[]
    for g,patterns in enumerate(model['price_patterns']):
        row=[]
        for k in range(K):
            lhs=sum(y[r]*event['coefficients'][g] for r,event in enumerate(model['event_rows']) if event['winner']==k)
            rhs=sum(beta[g][a][k]*pat['field'][k] for a,pat in enumerate(patterns))
            row.append(max(F(0),lhs-rhs))
        gamma.append(row)
    kappa=[rational_nonnegative(z)*budgetscale for z in x[index['kappa_start']:index['kappa_start']+N]]
    extra=max([F(0)]+[(sum(gamma[g])-sum(kappa[i] for i in P))/len(P) for g,P in enumerate(model['packets'])])
    kappa=[z+extra for z in kappa];lower=tau*sum(y)-sum(kappa)
    if lower<0:y=[F(0)]*R;beta=[[[F(0)]*K for _ in ps] for ps in model['price_patterns']];gamma=[[F(0)]*K for _ in range(G)];kappa=[F(0)]*N;lower=F(0)
    # Independent exact residual computation from saved witnesses.
    loads=[sum(theta[g] for g,P in enumerate(model['packets']) if i in P) for i in range(N)]
    row_slacks=[sum(a*q[g][row['winner']] for g,a in enumerate(row['coefficients']))-tau for row in model['event_rows']]
    epi_slacks=[epigraph[g][a]-q[g][k]*d for g,ps in enumerate(model['price_patterns']) for a,pat in enumerate(ps) for k,d in enumerate(pat['field'])]
    beta_slacks=[pat['volume']-sum(beta[g][a]) for g,ps in enumerate(model['price_patterns']) for a,pat in enumerate(ps)]
    gamma_slacks=[sum(beta[g][a][k]*pat['field'][k] for a,pat in enumerate(ps))+gamma[g][k]-sum(y[r]*event['coefficients'][g] for r,event in enumerate(model['event_rows']) if event['winner']==k) for g,ps in enumerate(model['price_patterns']) for k in range(K)]
    capacity_dual_slacks=[sum(kappa[i] for i in P)-sum(gamma[g]) for g,P in enumerate(model['packets'])]
    assert all(z>=0 for z in row_slacks+epi_slacks+beta_slacks+gamma_slacks+capacity_dual_slacks)
    assert all(0<=theta[g] and all(0<=z<=theta[g] for z in q[g]) for g in range(G)) and max(loads)<=1
    assert lower<=upper and upper>=tau*model['event_volume']
    fullcost=sum(pat['volume']*max(pat['field']) for patterns in model['price_patterns'] for pat in patterns) if all(len(P)==1 for P in model['packets']) else None
    return dict(packets=model['packets'],price_patterns=model['price_patterns'],omitted_nonpositive_pattern_volumes=model['omitted_nonpositive_pattern_volumes'],
                event_rows=model['event_rows'],primal=dict(q=q,theta=theta,epigraph=epigraph,source_loads=loads),
                dual=dict(y=y,beta=beta,gamma=gamma,kappa=kappa),lower_bound=lower,upper_bound=upper,certificate_gap=upper-lower,
                tau_event_volume=tau*model['event_volume'],upper_minus_tau_event_volume=upper-tau*model['event_volume'],
                upper_over_tau_event_volume=upper/(tau*model['event_volume']),full_singleton_duty_cost=fullcost,
                repair=dict(primal_capacity_scale=capscale,primal_blend_to_full_partition=eta,dual_budget_scale=budgetscale,dual_uniform_kappa_increment=extra),
                exact_residuals=dict(min_row_slack=min(row_slacks),min_epigraph_slack=min(epi_slacks),min_beta_budget_slack=min(beta_slacks),
                                     min_signed_field_dual_slack=min(gamma_slacks),min_packet_capacity_dual_slack=min(capacity_dual_slacks),max_source_load=max(loads),
                                     primal_feasible=True,dual_feasible=True,weak_duality_verified=True),
                candidate=diagnostic,lp_size=dict(dual_rows=len(b),dual_variables=len(c),aggregated_event_rows=R,packet_count=G,price_patterns=sum(map(len,model['price_patterns']))))


def fixtures():
    scales=[F(1),F(3,2),F(2)];out=[]
    for N in (2,3,5,16):
        ys=[(F(2*i-N+1,16*N),) for i in range(N)]
        out.append(('distinct_cluster_refinement',fixture('cluster_n1_N'+str(N),1,ys,scales,F(1,8))))
    out.append(('correlated_and_separated',fixture('separated_n1_N4',1,[(F(-3,4),),(F(-5,8),),(F(5,8),),(F(3,4),)],scales,F(1,32))))
    out.append(('correlated_and_separated',fixture('noise_spacing_cancellation_n1_N2',1,[(F(0),),(F(1),)],scales,F(1,32))))
    out.append(('correlated_and_separated',fixture('correlated_n2_N3',2,[(F(-1,8),F(-1,8)),(F(0),F(0)),(F(1,8),F(1,8))],scales,F(1,8))))
    out.append(('correlated_and_separated',fixture('deep_n2_N4',2,[(F(-1),F(0)),(F(-1,16),F(0)),(F(1,16),F(0)),(F(1),F(0))],scales,F(1,32),weights=[F(1,8),F(3,8),F(3,8),F(1,8)])))
    out.append(('dimension_and_scale_family',fixture('n1_four_scales_N3',1,[(F(-1,8),),(F(0),),(F(1,8),)],[F(1),F(4,3),F(5,3),F(2)],F(1,8))))
    out.append(('dimension_and_scale_family',fixture('active_low_background_gate_n1_N3',1,[(F(-1,8),),(F(0),),(F(1,8),)],scales,F(1,8),background_bound=F(1,2))))
    out.append(('dimension_and_scale_family',fixture('n3_two_scales_N3',3,[(F(-1,8),F(0),F(0)),(F(0),F(0),F(0)),(F(1,8),F(0),F(0))],[F(1),F(2)],F(1,8))))
    return out


def libraries(N):
    singles=[(i,) for i in range(N)]
    # Adjacent fixed partition includes genuinely different physical sites.
    partition=[tuple(range(i,min(i+2,N))) for i in range(0,N,2)]
    if N<=3:family=[tuple(i for i in range(N) if mask>>i&1) for mask in range(1,1<<N)]
    else:family=singles+[tuple(range(N))]+[P for P in partition if len(P)>1]
    return [('singletons',singles),('fixed_adjacent_partition',partition),('whole_input_packet',[tuple(range(N))]),('capacity_packet_family',family)]


def main():
    start=time.monotonic();records=[]
    for stage,src in fixtures():
        arr,events=arrangement(src);variants=[]
        for name,packets in libraries(src['N']):
            model=packet_model(src,arr,events,packets);cert=certify(model,src);cert['library']=name;variants.append(cert)
            if name=='singletons':
                c0=kernel_values(src['n'],src['delta'],F(1))[0][0];previous=F(0)
                expected=[]
                for j,L in enumerate(src['scales']):
                    expected.append((tuple(c0/z**src['n'] if k>=j else F(0) for k,z in enumerate(src['scales'])),L**src['n']-previous))
                    previous=L**src['n']
                for i,patterns in enumerate(model['price_patterns']):
                    want={tuple(src['weights'][i]*z for z in field):volume for field,volume in expected}
                    assert {tuple(pat['field']):pat['volume'] for pat in patterns}==want
                cert['exact_singleton_translation_price_check']=True
        # Failed naive sourcewise shutdown: exact finite-model row residuals.
        c0=kernel_values(src['n'],src['delta'],F(1))[0][0]
        duties=[[min(F(1),src['tau']*L**src['n']/(c0*p)) if L**src['n']<p/src['tau'] else F(0) for L in src['scales']] for p in src['weights']]
        failures=[]
        for r in events:
            k=r['winner'];td=sum(duties[i][k]*r['weighted_signed_source_fields'][i*len(src['scales'])+k] for i in range(src['N']))
            if td<src['tau']:failures.append((r['volume'],td))
        records.append(dict(stage=stage,source=src,noise=noise_certificate(src['n'],src['delta']),arrangement=arr,variants=variants,
                            naive_atom_shutdown=dict(duties=duties,failing_event_volume=sum(v for v,t in failures),
                                                     total_event_volume=arr['event_volume'],minimum_T_d=min((t for v,t in failures),default=None),
                                                     formula_scope='Finite-law central positive coefficient replaces c; no packet capture lower bound assumed.')))
        print(src['label'],'cells',arr['cell_count'],'rows',arr['event_pattern_count'],'LPs',len(variants),'seconds',round(time.monotonic()-start,3),flush=True)
    out=dict(status='RATIONAL_PRIMAL_DUAL_BOUNDS_VERIFIED',dependencies='Python standard library only',
             model='Finite labelled probability-noise algebra model, not a certificate for the actual continuous E2 kernel.',
             kernel='D_delta,L=L^-n[(h*((1-delta/2)delta0+(delta/2)nu))^tensor n - (h*((1-delta)delta0+delta nu))^tensor n](x/L).',
             F_definition='Average of the two nonnegative endpoint kernels, convolved with the same physical source.',
             selector='Smallest scale index maximizing original signed T; event T_winner>tau and F_winner<=B.',
             research_scope='Independent R80 adjacent signed-layer packet mechanism test; not a certificate for a merged-endpoint event selected at a common hard first hit.',
             cell_scope='Complete original dx face arrangement. Outer complement has all finite kernels zero. Boundaries have Lebesgue measure zero.',
             packet_primal='q_Pk<=theta_P; sum_{P containing i}theta_P<=1; signed selected rows sum_P q_P,k(r)G_P,k(r)>=tau. Price integral max(0,max_k q_Pk G_Pk).',
             packet_dual='y,beta,gamma,kappa>=0; sum_k beta_Pak<=v_a; sum_r:k(r)=k y_r G_Prk<=sum_a beta_Pak G_Pak+gamma_Pk; sum_k gamma_Pk<=sum_i in P kappa_i. Objective tau sum y - sum kappa.',
             epigraph_reduction='For q>=0 negative field coordinates are redundant; positive-clamped identical patterns have exactly summed dx volumes. Signed event fields are retained.',
             reduced_dual_lift='For each positive-clamped pattern distribute beta among original cells proportionally to their volumes; assign zero beta to negative coordinates and nonpositive patterns. This gives a feasible original signed epigraph dual with the same objective.',
             representative_columns='None',fixtures=records,
             counts=dict(stages=3,fixtures=len(records),LP_certificates=sum(len(r['variants']) for r in records),
                         complete_cells=sum(r['arrangement']['cell_count'] for r in records)),
             limitations=['No quantitative finite-noise to E2 transfer is supplied.',
                          'Library packet optimum is enclosed by rational feasible bounds; float simplex is candidate-only.',
                          'Finite source and scale counts remain explicit; no uniform N/J bound or fitted dimension order is inferred.',
                          'Fixed packet success in these fixtures does not establish a general packet construction.'])
    p=Path(__file__).with_name('packet_results.json');p.write_text(json.dumps(clean(out),sort_keys=True,indent=2)+'\n')
    print('PASS',out['counts'],'seconds',round(time.monotonic()-start,3),'bytes',p.stat().st_size,flush=True)


if __name__=='__main__':main()
