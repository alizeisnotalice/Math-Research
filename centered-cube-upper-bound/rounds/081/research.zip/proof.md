# 中心立方体第81轮：共同硬首达、来源几何与全尺度返回

日期：2026-10-11。主目标 **UNPROVED／未完成**。本轮没有证明一般 sqrt(n)n^{o(1)} 上界；全一般保留基准仍为 O(n log n)。上一轮已产生实际证明、数值证据和远端确认提交，属于实质进展；本轮从该状态继续。

## 一般路线的变化

第80轮的全部软层可以先有符号合并。更直接地，硬端点本身有精确方程：若 A 是硬立方体平均、P 是真实 E2 平滑基线，则 U=A-P 满足 U'=Face_H-B_1*f-nU-nP。硬面在与任意 L1 输入卷积并积分时间后有真实 L1 密度，故这里不要求输入可微，也无需给硬示性核编造有限 Fisher 信息。

主代理与独审进一步将已付条件简化到两项：固定物理窗口 [1,2] 的初始硬平均 A_1>=lambda/2，以及连续平滑上确界 sup P>lambda/2。它们在原始阈值下的合计费用是

    [4+2(log2)sqrt(7n/3)] ||f||1.

余下原始硬越阈事件在同一硬首次等号接触处，可准确表示为长度至多 log8/n 的近期硬面阻尼积分减平滑背景。该有符号余量至少7lambda/16。**这个下界在保留事件上自动成立，并非稀有性估计**；本轮没有把已付 O(sqrt n) 项当作整体上界。真正未付的仍是这些接收点的统一弱体积。

相较第80轮，这个充分接口不再需要逐软层阈值和 S² 收费，也不需要主路线中的私有软首达、细尾或连续通量剔除。旧的有限软端点及其误差预算仍然正确，作为可选工具保留。

## 严格新接口及排除的捷径

1. **近期硬面核精确等于外壳。** 阻尼率 n、记忆 log8/n 时，其质量为7/8；完整物理尺度窗口的强来源包络却精确等于7/8+n log2。任意短记忆不能直接推出低阶强来源费用。正文同时给出一般阻尼率和有限共同 duty 的准确径向分段价格。
2. **共同首达的来源雅可比。** 对光滑输入与几乎所有阈值，真实首达映射 x↦(x-y)/r(x) 给出完整来源占用恒等式，保留非临界逆像的多重性及 |1-z·∇r|^{-1}。源积分中的临界集由实际 L1 源测度和 Tonelli 处理。固定窗口版本与正 L1 极限均已说明。径向年龄尾只限制归一化谱，尚未控制其总费用。
3. **真实反例限制覆盖策略。** 一般收缩映射的费用公式合法，但其自然 Lipschitz 下包络在全维稠密立方体 L1 输入上没有任何保留接收点接触；一维多区间 L1 输入还能在正来源测度集上产生任意多首达逆像。因此不能要求每个来源分别有统一费用。
4. **共同分组必须保留容量。** 本轮给出允许跨物理位置消去的分组证书及完整有限 LP。实际 E2 的“许多微小远处控制源＋一个大源”构造证明，整个输入仅用一个共同尺度 duty 时，其强价格可为 Omega(n)，即使真实连续背景保持低水平。该构造尚未认证为新主余项事件，不能称为目标弱界反例。有限噪声 LP 测试同时保留分组改善与恶化案例。
5. **全尺度接口已补齐。** 按 Naor–Tao 原文公式(11)，一般输入的固定倍尺度窗口弱常数 mathfrak B_n 满足 C_n^square<=C_loc log(n+2) mathfrak B_n，没有额外 n 项。微倍增、半边长／全边长转换、有限窗口并集、端点 p=1 均逐项核验。故当前主目标欠项集中于一个固定窗口中的一般弱体积预算；全尺度返回现为已证条件转移。

## 数值、证书及复现

每条采用的接口均有初步、压力、扩大参数三个阶段，并区分解析结论、精确有限证书、求积及采样诊断。

- 实际 E2 端点程序使用7组正 L1 输入、39个箱分量、21个精确硬首达接收点，411个分段多项式及126个有理年龄比较；同一批接收点登记63个硬／软端点记录。硬近期通量有来源捕获量的精确区间公式，平滑积分仍属求积。原始粗硬面求积在 n16 出现约5%偏差，明确保留为失败诊断，未用作已认证数值。
- 分组程序使用有限有理噪声模型，完整重建2992个空间单元，产生11个实例、44个有理 LP 上下界，其中12个上下界完全相等，最大间隙约9.54e-10。完整单元、原始有符号赢家、背景筛选、来源容量、价格和弱对偶均由独审另行核验。这是有限模型证书，不是连续 E2 或主剩余事件的统一廉价覆盖。
- 父守卫、软层、硬面、覆盖、局部化及最终独审分别保留可运行代码。两个主程序在主代理独立目录重放，冻结 JSON 按字节核对；实际回执、哈希和执行输出见 inventory.json。有限检验不证明未决一般弱界。

解压 research.zip 后执行 `python3 -B endpoint_probe.py` 和 `python3 -B packet_probe.py`。生产及父重放使用 Python 3.12.14，两个程序只需标准库。proof.md 六个 Python 代码块依次为 parent、soft、hardface、coverage、localization、audit 守卫，提取到同目录后运行。proof.tex.txt 保存详细 LaTeX 源，仅静态检查，不编译、不生成 PDF。

## 工具、依赖与剩余问题

64项规范技能入口和直接引用已重新检查；只按实际读取范围使用 A02、E03、G03、M04、M02、N04、L03 等边界及学术文献检索技能，不声称所有候选外文定理均已读完。覆盖、软层、硬面使用 Astra medium；数值、有限 LP、独审和文献局部化使用 Sol high。

真实 E2 基线及通量依赖第78轮，必要的量化／条件转移依赖第79轮，单侧归约及反例工具依赖第80轮。新局部化引用 [Naor–Tao 作者原文](https://web.math.princeton.edu/~naor/homepage%20files/HLM.pdf)，准确版本和原文页码见本轮文献组件。

**剩余主定理：** 对同一原始输入、实际首次接触和 Lebesgue 接收点，证明来源雅可比／多重覆盖的质量加权费用，或另一等效的一般窗口弱型费用，至多 sqrt(n)n^{o(1)}。年龄短、正余量大、有限 LP 可行、单来源廉价都不能替代这个命题。若该窗口预算成立，现已核验的全尺度转移只再付一个对数。

GitHub 只新增本轮 README 和一个7成员研究归档，另更新项目总览。所有草稿及重放副本留在仓库外。

---


# R81 parent: exact recent-arrival kernel and its source-duty cost

**Status.** These exact formulas clarify the remaining common-selector problem; they do not bound its weak receiver volume. The parent re-read the full goal and the updated E03/M02 skills. E03 requires a genuine common tree mass flow before telescoping; M02 requires an actual closed convex separation setting. Neither supplies a missing packet or geometric theorem here. No Bellman constant or separation theorem is invoked below.

## 1. Integrating the actual hard face gives a shell

Let H=1_{[-1/2,1/2]^n}, and let Face_H be the positive measure

    sum_(j=1)^n beta_j tensor h^(other coordinates),
    beta=(delta_(-1/2)+delta_(1/2))/2.

Its mass is n. As distributions in t=log L, dH_(e^t)/dt=Face_H,(e^t)-nH_(e^t). Integrating this identity in L1 after convolution with any f>=0 in L1 is legitimate: both face and volume terms have integrable space-time L1 densities on every compact time window. Fubini then gives an absolutely continuous time representative for almost every receiver. This includes the unsmoothed endpoint a=0.

For h>0 and kappa>0 put beta=n-kappa and define the finite positive resolvent measure

    K_(h,kappa)=integral_0^h exp(-kappa s) (Face_H)_(exp(-s)) ds.

This has the following Lebesgue density, with rho(z)=2||z||_infinity:

    K_(h,kappa)(z)=rho(z)^(-beta)
                         1_{exp(-h)<rho(z)<1}.                 (R1)

To see the normalization, on the region where coordinate j uniquely attains the maximum absolute coordinate, its face factor is delta(z_j-sign(z_j)exp(-s)/2)/2. Integrating in s cancels the face displacement derivative exp(-s)/2; the remaining n-dimensional dilation contributes exp(ns), while the damping contributes exp(-kappa s). Thus the density is exp((n-kappa)s)=rho^(-beta). Tied maximal coordinates and the two endpoint surfaces have Lebesgue measure zero, so the formula defines the integrated measure without extra face masses. Equivalently test against continuous compactly supported functions and partition the cube into its 2n pyramids.

Since |{rho<r}|=r^n, (R1) gives

    ||K_(h,kappa)||1=n(1-exp(-kappa h))/kappa.                 (R2)

In the direct hard-endpoint route kappa=n, so K_(h,n) is exactly the indicator of the outer cube shell, with mass 1-exp(-nh). No new smoothing or noise law is involved.

## 2. Exact connection to the same hard first hit

Fix a receiver x with an actual hard first hit L*=exp(tau) of level lambda. For global first hit, all smaller positive scales have A_L<=lambda. For first hit within [1,2], only the scales in [1,L*] have this property, and it is this weaker fact that is used on the truncated time interval below. Put

    pi_x(dy)=f(y)H_((L*))(x-y)dy/lambda,
    age(y)=log[L*/(2||x-y||_infinity)].

This is the true captured-source probability measure. It is introduced after the receiver has been selected under Lebesgue dx; it does not replace that receiver measure.

For any 0<ell<=tau, the recent face integral ending at this SAME hard hit obeys

    integral_(tau-ell)^tau exp[-kappa(tau-r)]
                  (f*Face_H,(exp(r)))(x) dr
       = (f*(K_(ell,kappa))_(L*))(x)
       = lambda E_pi[exp((n-kappa)age) 1_{age<ell}].          (R3)

For kappa=n it is simply

    lambda - exp(-n ell) A_(L* exp(-ell))(x).                (R4)

The only source boundary in this calculation is actual hard capture. A softened/noisy source posterior would not inherit the hard first-hit age law. Formula (R3) uses no such change of posterior, no coordinate independence and no conditional direction hypothesis.

Choose h=log(8)/n and ell=min(h,tau). When tau>=h, first-hit exclusion at L*exp(-h)>=1 gives

    7lambda/8 <= fresh hard face <=lambda.                 (R5)

Thus a time interval of length O(1/n) retains a fixed, large fraction of the captured mass. It is not a small-mass exceptional event. For tau<h, (R4) instead reads lambda-exp(-n tau)A_1; one must retain the anchor rather than use an unavailable earlier scale. The soft component pays that anchor explicitly.

At a retained hit with sup_[1,2]P_1<=lambda/2 and tau>=h, the recent smooth subtraction is at most

    n integral_(tau-h)^tau exp[-n(tau-r)]P_1(r)dr
        <=(lambda/2)(1-exp(-nh))=7lambda/16.

Consequently the recent signed hard-face-minus-smooth resolvent is at least 7lambda/16. Its lambda/4 threshold is automatically satisfied on these retained hard hits; it is an exact alternative representation of the hard event, not a proof that its receivers are rare. A successful next estimate must use their common spatial/source geometry.

## 3. Minimal paid gates for the whole fixed window

The audit supplied a further exact simplification of the positive-endpoint reduction. Let T=log2, A_t=f*H_(exp(t)), and P_t=f*Phi_(exp(t)), where Phi is the retained actual E2 smooth product kernel. Its already-proved strong window constant is B_n=1+T sqrt(7n/3). Pay the two sets {A_0>=lambda/2} and {sup_[0,T]P_t>lambda/2}, at lambda-volume cost at most (2+2B_n)W.

Every remaining receiver in {sup_[0,T]A_t>lambda} has a first window level contact tau=inf{t in [0,T]:A_t>=lambda}>0, with A_t<lambda for t<tau. This includes any earlier tangency, and need not be the first strict-superlevel boundary; the original target event still requires a strict crossing somewhere in the window. Write h=log8/n, ell=min(h,tau), t0=tau-ell and q=exp(-n ell). For the ACTUAL incoming hard face define

    Z_tau=integral_t0^tau exp[-n(tau-r)]
                                [Face_H*f(r)-nP_r] dr.

By (R4), exactly

    Z_tau=lambda-q A_t0-n integral_t0^tau exp[-n(tau-r)]P_r dr
          >=lambda/2+q(lambda/2-A_t0).                    (R8)

If tau>=h, q=1/8 and A_t0<=lambda, so Z_tau>=7lambda/16. If tau<h, t0=0 and A_0<lambda/2, so Z_tau>=lambda/2. Thus all such retained hard hits have Z_tau>=7lambda/16, without paying a centered-flux primitive exception or any positive-softness face error. This uses the actual integrated hard-face identity and does not rely on differentiating the unknown f pointwise.

The resulting paid coefficient is

    2+2B_n = 4+2T sqrt(7n/3)=O(sqrt(n)).                  (R9)

The remaining receivers are exactly the retained hard-first-hit set with its common-source, short-memory representation (R8). The large recent surplus is automatic there, so it does NOT reduce the outstanding weak-volume problem. This is a simpler sufficient interface, not a new proof that C_n has the paid coefficient (R9). The finite-softness and continuous-primitive versions in the soft component remain valid optional tools; the minimal hard-endpoint interface needs neither. Whole-window continuity and first-hit measurability follow from the same L1 distributional derivative and countable time tests used above. The separate localization component supplies only a conditional transfer from an actual proved window weak bound to all scales.

## 4. Short memory does not lower the unrestricted strong source price

For the full physical scale window [1,2], the exact source envelope is

    integral sup_(1<=L<=2) (K_(h,kappa))_L(z) dz
        = n(1-exp(-kappa h))/kappa + n log 2.               (R6)

Indeed, for a fixed rho=2||z||_infinity, admissible scales satisfy rho<=L<=exp(h)rho and 1<=L<=2. The value is rho^(-beta)L^(-kappa), hence the maximum occurs at L=max(1,rho). On exp(-h)<rho<1 this gives rho^(-beta), producing the first term in (R6); on 1<=rho<=2 it gives rho^(-n), whose radial integral is n log 2. Other radii contribute zero. We use h>0; no interchange of the limit h down to zero with an uncountable pointwise supremum is claimed.

For kappa=n and h=log8/n, (R6) is exactly 7/8+n log2. Thus the current recent-arrival cutoff does not yield a sqrt(n) strong source envelope, even though its memory is O(1/n). This is an analytic obstruction to one proposed payment mechanism, not a lower bound on the desired weak constant. In particular, a receiver-dependent choice L*(x) cannot be charged as though all receivers used the same shell.

There is also an exact finite-library duty formula. Given positive L_j and receiver-independent d_j>=0, let q=exp(-h). Partition the radial line at all qL_j and L_j. On a cell (a,b), the active set is J_(a,b)={j:qL_j<=a<b<=L_j}. Then

    integral max(0,max_j d_j(K_(h,kappa))_(L_j)(z))dz
      = sum_cells [n(b^kappa-a^kappa)/kappa]
                         max_(j in J_(a,b)) d_j L_j^(-kappa), (R7)

with empty maxima zero. This is an exact common-duty price, not a random clock or a sample of receiver cells. In the hard case, radial volume v=rho^n makes every cell contribution its volume length times max_j(d_j/L_j^n). It is useful for the proposed shared-source certificates, but it does not prove that feasible cheap duties exist.

## 5. Three-stage exact and numerical checks

The guard below uses exact rational radial volumes for the hard shell with q^n=1/8. Its stage-three comparison with the logarithmic analytic upper formula is a floating diagnostic; the formula is proved above independently. It checks an independent layer-cake evaluation of the maximum, refinement/scale-family growth, and a lower bound from geometrically separated physical scales. The latter is also analytic: if L_(j+1)^n=8L_j^n, the shells have disjoint interiors and each costs7/8, so m such scales cost7m/8. With L_j=2^(3j/n), 0<=j<=floor(n/3), all scales lie in [1,2] and m=floor(n/3)+1; these side lengths need not be rational, but their volumes8^j are exact integers. The resulting Omega(n) obstruction is therefore not a numerical fit. None of these strong prices is claimed to be a weak maximal constant.

```python
from fractions import Fraction as F
import math,random
rng=random.Random(81031)
checks=0

def price(volumes,duties,c=F(1,8)):
    knots=sorted(set([c*v for v in volumes]+volumes))
    return sum((b-a)*max([F(0)]+[d/v for v,d in zip(volumes,duties) if c*v<=a and b<=v]) for a,b in zip(knots,knots[1:]))

def union_length(intervals):
    if not intervals:return F(0)
    intervals=sorted(intervals);a,b=intervals[0];out=F(0)
    for c,d in intervals[1:]:
        if c>b:out+=b-a;a,b=c,d
        else:b=max(b,d)
    return out+b-a

def layercake(volumes,duties,c=F(1,8)):
    heights=sorted(set([F(0)]+[d/v for v,d in zip(volumes,duties)]))
    return sum((b-a)*union_length([(c*v,v) for v,d in zip(volumes,duties) if d/v>=b]) for a,b in zip(heights,heights[1:]))

# Stage1: independent exact interval-vs-layercake price.
for n in (1,2,4):
    for N in (2,5,9):
        vols=[(F(1)+F(j,N-1))**n for j in range(N)]
        for k in range(7):
            duties=[F(rng.randrange(0,17),16) for _ in vols]
            assert price(vols,duties)==layercake(vols,duties)
            assert F(0)<=price(vols,duties)<=sum(duties)
            checks+=1
print('stage1 exact independent prices',checks)

# Stage2: adversarial isolated spikes and fully shared duty; no small-h gain.
for n in (3,6,12,24,48,96):
    vols=[F(8)**j for j in range(n//3+1)]
    assert max(vols)<=F(2)**n
    full=price(vols,[F(1)]*len(vols))
    assert full==F(7,8)*len(vols)
    for j in range(len(vols)):
        d=[F(int(i==j)) for i in range(len(vols))]
        assert price(vols,d)==F(7,8)
        checks+=1
    print('stage2 n',n,'physical_scales',len(vols),'exact_full_price',str(full))

# Stage3: nested physical libraries approach the exact continuous formula.
for n in (1,4,16,64):
    old=F(0)
    for m in (4,16,64,256):
        vols=[(F(1)+F(j,m))**n for j in range(m+1)]
        val=price(vols,[F(1)]*len(vols))
        assert val>=old and float(val)<=7/8+n*math.log(2)+1e-10
        old=val;checks+=1
    print('stage3 n',n,'finite_price',float(old),'continuous_analytic',7/8+n*math.log(2))
print('PASS',checks,'finite checks; rational prices exact, log upper comparison floating diagnostic; continuous formula proved analytically, no weak bound claimed')
```


# R81: one endpoint, one hard selector, and a paid terminal resolvent

**Status.** This is a general one-window reduction with all paid terms O(sqrt(n)). It merges the entire finite soft sum, removes the R80 layer-union factors, and pays the old part of an adaptive damping resolvent. The unproved remainder is a signed terminal-window face surplus at the SAME actual hard first hit. No weak bound for that remainder or for the global centered-cube maximal operator is claimed.

A02's explicit domination and error-budget direction are used. No stopping theorem, entropy of an arbitrary input, independent source coordinates, or unproved total-variation cancellation is assumed. This supersedes the private-layer selector in the sufficient interface, not the earlier valid results.

## 1. Actual E2 endpoint identity

For f>=0 in L1(R^n), write W=||f||1, h=1_{[-1/2,1/2]}, H=h^tensor n, w(x)=integral_0^1 exp(-|x|/r)dr, phi=h*w, psi_a=(1-a)h+a phi and Psi_a=psi_a^tensor n. In this section the physical window is FIXED: L=e^t, 0<=t<=T=log 2. Put A(t)=f*H_(e^t), P_a(t)=f*(Psi_a)_(e^t).

Choose a dyadic epsilon<=1/(2n), alpha=(1-epsilon)^n>=1/2 and kappa=n(1-epsilon). The finite sum of all adjacent soft layers from 1 down to epsilon is exactly

    U=P_epsilon-P_1;  alpha A<=P_epsilon.             (1)

Let Face_a be the convolution with the nonnegative dilated measure (1-a) sum_j beta_j tensor psi_a on the other coordinates, beta=(delta_-1/2+delta_1/2)/2. The established actual E2 flux gives

    U'=Face_epsilon+v-kappa U-kappa P_1,
    v=f*(B_epsilon-B_1)_(e^t).                       (2)

In particular Face_1=0. The layerwise signed face differences telescope to the SINGLE positive Face_epsilon. The restoring terms remain; deleting them is not justified. The full signed source contributions inside U also remain.

With V(a)=10a/3-a^2 and

    D_n= sqrt(n V(epsilon))+sqrt(7n/3),
    B_n=1+T sqrt(7n/3),

R78's actual E2 Fisher calculation supplies

    integral Face_epsilon(t,x)dx=kappa W,
    integral |v(t,x)|dx<=D_n W,
    ||sup_[0,T] P_1||1<=B_n W.                       (3)

Moreover D_n<=sqrt(5/3)+sqrt(7n/3). Define R(t)=integral_0^t v. Then ||sup|R|||1<=T D_n W and ||U(0)||1<=2W. All identities concern the absolutely continuous time representatives for almost every receiver supplied by the space-time L1 face and continuous flux densities. No pointwise density is asserted for an unconvolved singular face kernel.

## 2. Preserve the actual hard first hit

Fix lambda>0. Let E be {sup_[0,T] A>lambda}. Delete the anchor event A(0)>=lambda, of lambda-weighted volume at most W. For each remaining x in E, let tau(x)=inf{t in [0,T]: A(t,x)>=lambda} be the first level contact, so A(tau,x)=lambda. An earlier tangency is included in this definition; this is not the alternative first strict-superlevel boundary. Continuity gives tau in (0,T], with A(t,x)<lambda for 0<=t<tau. The measurable first-hit selection follows from rational-time suprema. This is the first hit in this fixed window, not an assertion about all smaller positive scales.

Put theta=alpha lambda/2. Delete the smooth event sup P_1>theta, at cost (2B_n/alpha)W. At the SAME hard tau, equation (1) then gives

    U(tau)>=alpha lambda-P_1(tau)>=theta.             (4)

There is no private layer winner, no threshold divided by the number of layers, and no private U first hit. Also delete

    Q(x)=|U(0,x)|+2 sup_[0,T]|R(t,x)|>theta/4.        (5)

Since ||Q||1<=(2+2T D_n)W, this costs

    lambda |{Q>theta/4}|<=16(1+T D_n)W/alpha.         (6)

These bounds are on Lebesgue receiver measure, for the original arbitrary source f. They do not assign a probability distribution to receivers.

## 3. Exact adaptive damping resolvent and an old-flux payment

Integrating (2) at this same tau gives

    U(tau)=exp(-kappa tau)U(0)
      +integral_0^tau exp(-kappa(tau-r))
           [Face_epsilon(r)+v(r)-kappa P_1(r)]dr.    (7)

Integration by parts against R proves

    |integral_0^tau exp(-kappa(tau-r))v(r)dr|
       <=2 sup_[0,T]|R|.                             (8)

Indeed the integral is R(tau)-kappa integral_0^tau exp(-kappa(tau-r))R(r)dr, since R(0)=0. Equations (4)-(5) imply

    integral_0^tau exp(-kappa(tau-r))
                  [Face_epsilon(r)-kappa P_1(r)]dr
       >=3theta/4.                                  (9)

Take

    ell=log(n+2)/(2kappa), q=(n+2)^(-1/2),
    t0=max(0,tau-ell),
    O(x)=integral_0^t0 exp(-kappa(tau-r))Face_epsilon(r,x)dr.

For EVERY adaptive tau in [0,T], pointwise

    O(x)<=q integral_0^T Face_epsilon(r,x)dr,
    integral O dx<=q kappa T W.                      (10)

When tau<=ell the old integral is empty. Otherwise every old r has tau-r>=ell. Thus (10) uses only positivity and Tonelli, with no false independence of tau and f.

Delete O>theta/4, at lambda-weighted cost

    8 kappa T W/[alpha sqrt(n+2)].                   (11)

On the residual event, define the fresh SIGNED surplus

    Z(x)=integral_t0^tau exp(-kappa(tau-r))
                   [Face_epsilon(r,x)-kappa P_1(r,x)]dr.

Subtract the old signed contribution from (9). Its value is at most O, because the old background is nonnegative. Therefore

    Z(x)>=theta/2=alpha lambda/4.                    (12)

This subtraction keeps the fresh background term with its correct sign. It does not replace a signed convolution by its positive kernel part.

Combining the four paid events yields the explicit all-input estimate

    lambda |E| <= C_paid(n,epsilon) W+lambda |E_fresh|,
    C_paid=1+2B_n/alpha+16(1+T D_n)/alpha
                              +8kappa T/[alpha sqrt(n+2)]. (13)

Here E_fresh means precisely E outside those four exceptions, evaluated at its original hard tau. In particular C_paid=O(sqrt(n)) uniformly in the dyadic depth. The remaining event satisfies (12), with window length at most ell=O(log(n+2)/n). There is no S or S^2 cost. Finite physical libraries are covered by E, and dense increasing libraries recover its continuous version by continuity. No receiver-dependent rescaling of the physical window is used; the all-scale localization question remains separate.

Equation (13) is a stronger general sufficient interface than R80's union of short private-layer corridors. It is not a proof that the last term is small. A large fresh face surplus can arise on a very short interval; its gross source budget is still of order n if one takes the supremum or discards the remaining sign without further geometry.

## 4. Optional exact transfer to hard captured sources

If a direct hard-source-age representation is desired, choose the slightly finer dyadic epsilon<=1/(2n^2). This changes no layer-union cost because no layer union is used. Before convolution, positivity and the all-hard mask give

    Face_epsilon kernel=alpha Face_H kernel+G_epsilon,
    G_epsilon>=0,
    mass G_epsilon=kappa-alpha n
       =n[(1-epsilon)-(1-epsilon)^n]
       <=n(n-1)epsilon<=1/2.                        (14)

For n=1 this remainder is zero. Its full selected damped integral is bounded by the unweighted full-window positive convolution, whose L1 mass is at most T W/2. Hence deleting the additional event

    integral_0^T f*(G_epsilon)_(e^r)(x)dr>theta/4

costs at most 4T W/alpha in original lambda units. On the retained event (12) improves to the hard-face statement

    integral_t0^tau exp(-kappa(tau-r))
           [alpha Face_H(r,x)-kappa P_1(r,x)]dr
        >=theta/4=alpha lambda/8.                   (15)

Every hard-face contribution here is from an original source that enters the actual centered hard cube between t0 and tau. No external noisy-source posterior is introduced.

For clarity, if a_y=log(2||x-y||_infinity)>0 is its entry time, the exact representation of the positive hard term is

    integral_t0^tau exp(-kappa(tau-r))Face_H(r,x)dr
      =exp(-n tau) integral f(y)
           exp((n-kappa)(tau-a_y)) 1_{t0<a_y<=tau}dy. (16)

Boundary conventions affect a null set for L1 sources; if t0=0, sources already captured at scale one are not new arrivals. Formula (16) follows from d/dt of the nested cube mass, or by Tonelli on its one-entry Stieltjes measure. It retains the ORIGINAL y and dx. The factor exp((n-kappa)age), with n-kappa=n epsilon, is explicit; no conditional weak norms are averaged.

The common first-hit age bound at tau only controls source radii already inside the hard cube, and only ages whose earlier comparison scale is in the fixed window. Formula (16) now meets that scope. It still does not provide a receiver-volume payment for (15). In the limit epsilon down to zero this interface returns the hard dilation identity minus the smooth background. Thus the merging and old-flux payment simplify the sufficient theorem; they must not be advertised as new cancellation in the hard kernel itself.

## 4a. Principal hard-endpoint corollary: no old-flux exception

The cleanest sufficient statement takes epsilon=0 directly, rather than taking a limit in an unproved assertion. Put U=A-P_1, alpha=1, kappa=n and v=-f*(B_1)_(e^t). The hard identity A'=Face_H-nA holds distributionally; its space-time derivative is in L1 on the fixed window because the face and drift terms have masses nTW. Consequently its almost-everywhere time representative is absolutely continuous. Thus all preceding resolvent steps are valid at epsilon=0, with

    D_n=sqrt(7n/3), theta=lambda/2.                  (17)

This requires no Fisher estimate for h: B_0 is exactly zero, and only the smooth endpoint P_1 uses Fisher information.

At the original hard first contact, the old HARD resolvent has an additional exact pointwise bound. For any ell>0 and tau>=ell,

    O_H=integral_0^(tau-ell) exp(-n(tau-r))Face_H(r)dr
       =exp(-n ell)A(tau-ell)-exp(-n tau)A(0)
       <=exp(-n ell)lambda.                         (18)

For tau<ell it is zero. The equality is the hard dilation identity integrated only to tau-ell; the inequality uses f>=0 and the same hard first-hit condition A(tau-ell)<=lambda. It would be invalid at an arbitrary private soft selector.

Choose ell_*=log(8)/n. Then O_H<=lambda/8=theta/4 pointwise, so no old-flux exceptional set is needed at all. Let E_* be E outside exactly the hard anchor, the smooth event sup P_1>lambda/2, and Q>lambda/8, with Q=|A(0)-P_1(0)|+2sup|integral_0^t(-f*B_1)|. The main clean estimate is

    lambda |E| <=[19+18T sqrt(7n/3)]W+lambda |E_*|.  (19)

Every x in E_*, at its original hard first contact tau, obeys

    integral_(tau-ell_*)+^tau exp(-n(tau-r))
                       [Face_H(r,x)-nP_1(r,x)]dr
       >=lambda/4.                                 (20)

The terminal window is now O(1/n), and the face has no noise labels or outside captured sources. This is an exact sufficient interface, not a claimed payment for E_*.

There is an important obstruction to treating (20) itself as a rare surplus. If tau>=ell_* and sup P_1<=lambda/2, then independently of Q the left side of (20) is

    lambda-(1/8)A(tau-ell_*)
              -n integral_(tau-ell_*)^tau exp(-n(tau-r))P_1(r)dr
       >=lambda-(lambda/8)-(lambda/2)(7/8)
       =7lambda/16.                                (21)

Thus for these receivers its lambda/4 threshold is automatic. A terminal shell captures substantial source mass; it is not a small-mass error. The new reduction aligns the source and selector and removes unnecessary fees, but further receiver geometry or a joint source-capacity argument is still needed. This obstruction is algebraic and holds for the actual hard first contact, rather than an unrelated surrogate process.

## 5. Proof status and diagnostics

The principal clean general result is (19)-(20); (13) and (14)-(16) retain the finite soft-endpoint version. All preserve the actual common hard selector. The missing theorem is a bound for the terminal signed surplus (12), or its refined form (15), on the exact retained event. The hardface agent's geometric contact/noncontact split is a possible additional source of receiver-volume control, not an assumption made here.

The independent embedded guard below uses actual E2 scalar quadrature in three stages. It checks finite-layer telescoping, face telescoping, the positive all-hard remainder and mass constants, and true product-box L1 endpoint values. Quadrature is diagnostic, not an interval certificate. The companion endpoint_probe tests common hard first-hit flux and resolvent identities for nonnegative L1 box mixtures; its grid/first-hit certification scope is recorded separately. No numerical result proves the missing general bound.

```python
import math
from functools import lru_cache

@lru_cache(None)
def phi(x,N=400):
    x=abs(x)
    def g(r):
        if not r: return 0.0
        if x<=.5:
            return r*(2-math.exp(-(x+.5)/r)-math.exp(-(.5-x)/r))
        return r*(math.exp(-(x-.5)/r)-math.exp(-(x+.5)/r))
    return (g(0)+g(1)+sum((4 if j%2 else 2)*g(j/N) for j in range(1,N)))/(3*N)

def simp(fun,l,r,N=40):
    return (r-l)*(fun(l)+fun(r)+sum((4 if j%2 else 2)*fun(l+(r-l)*j/N) for j in range(1,N)))/(3*N)

def scalar(a,x): return (1-a)*(abs(x)<=.5)+a*phi(x)
def tensor(a,xs): return math.prod(scalar(a,x) for x in xs)
def box(a,x,L,r=.12):
    hard=max(0,min(r,x+L/2)-max(-r,x-L/2))/(2*r*L)
    soft=simp(phi,(x-r)/L,(x+r)/L)/(2*r)
    return (1-a)*hard+a*soft

def boxface(x,L,r=.12):
    return ((abs(x-L/2)<r)+(abs(x+L/2)<r))/(4*r)

def fields(a,xs,L):
    ps=[box(a,x,L) for x in xs]
    P=math.prod(ps)
    F=(1-a)*sum(boxface(x,L)*math.prod(ps[k] for k in range(len(xs)) if k!=j) for j,x in enumerate(xs))
    return P,F

checks=0
T=math.log(2)
for n in [2,4,8]:
    S=math.ceil(math.log2(2*n*n)); eps=2**(-S)
    alpha=(1-eps)**n; k=n*(1-eps)
    mass=k-n*alpha
    assert 0<=mass<=n*(n-1)*eps<=.5
    assert alpha>=.5
    ell=math.log(n+2)/(2*k); q=1/math.sqrt(n+2)
    assert abs(math.exp(-k*ell)-q)<1e-14
    checks+=3
    xs=[.55]+[.1]*(n-1)
    max_tel=max_face=0.
    for L in [1.,1.1,1.4,1.8,2.]:
        vals=[fields(2**(-s),xs,L) for s in range(S+1)]
        pe,fe=vals[-1]; p1,f1=vals[0]
        total=sum(vals[s+1][0]-vals[s][0] for s in range(S))
        fac=sum(vals[s+1][1]-vals[s][1] for s in range(S))
        max_tel=max(max_tel,abs(total-(pe-p1)))
        max_face=max(max_face,abs(fac-fe))
        ph,fh=fields(0.,xs,L)
        assert abs(total-(pe-p1))<1e-12
        assert abs(fac-fe)<1e-12 and f1==0
        assert pe+1e-13>=alpha*ph
        assert fe+1e-13>=alpha*fh
        checks+=4
    D=math.sqrt(n*((10/3)*eps-eps*eps))+math.sqrt(7*n/3)
    B=1+T*math.sqrt(7*n/3)
    paid=1+2*B/alpha+16*(1+T*D)/alpha+8*k*T/(alpha*math.sqrt(n+2))
    # Pointwise old-clock domination for arbitrary selected terminal times.
    for tau in [.02,.2,T]:
        for j in range(21):
            r=max(0,tau-ell)*j/20
            if tau>=ell:
                assert math.exp(-k*(tau-r))<=q+1e-14
                checks+=1
    print('stage',n,'eps',eps,'E2_L1_tel',format(max_tel,'.3g'),'face_tel',format(max_face,'.3g'),'remainder_mass',format(mass,'.8g'),'paid',format(paid,'.8g'))
# Algebra for integration by parts on an arbitrary AC primitive R(t)=t^2.
# This checks the resolvent identity, not an empirical source model.
for k in [.5,2,8]:
    for tau in [.1,.4,T]:
        direct=simp(lambda r:math.exp(-k*(tau-r))*2*r,0,tau,400)
        parts=tau*tau-k*simp(lambda r:math.exp(-k*(tau-r))*r*r,0,tau,400)
        assert abs(direct-parts)<1e-9
        assert abs(direct)<=2*tau*tau
        checks+=2
# Hard-endpoint first-contact bound: adversarial previous levels up to lambda.
for n in [2,8,32]:
    ell=math.log(8)/n
    for lam in [.03,1.,11.]:
        for fraction in [0.,.25,.99,1.]:
            previous=fraction*lam
            old=math.exp(-n*ell)*previous
            fresh_lower=lam-old-(lam/2)*(1-math.exp(-n*ell))
            assert old<=lam/8+1e-13
            assert fresh_lower>=7*lam/16-1e-13
            checks+=2
    paid0=19+18*T*math.sqrt(7*n/3)
    print('hard_endpoint',n,'terminal_width',format(ell,'.8g'),'paid',format(paid0,'.8g'))
print('PASS',checks,'assertions; E2 Simpson diagnostics, not interval certification')
```

Actual stdout:

```text
stage 2 eps 0.125 E2_L1_tel 0 face_tel 0 remainder_mass 0.21875 paid 79.023962
stage 4 eps 0.03125 E2_L1_tel 2.78e-17 face_tel 0 remainder_mass 0.35204697 paid 82.765735
stage 8 eps 0.0078125 E2_L1_tel 0 face_tel 0 remainder_mass 0.42403967 paid 97.765106
hard_endpoint 2 terminal_width 1.0397208 paid 45.952643
hard_endpoint 8 terminal_width 0.25993019 paid 72.905286
hard_endpoint 32 terminal_width 0.064982548 paid 126.81057
PASS 243 assertions; E2 Simpson diagnostics, not interval certification
```

Guard SHA256: `4895847b83a379ae14bc17bba23698659d151ef40eb0a91e59694dd1d3df3dac`.


# R81: the actual first-hit source Jacobian and a failed contraction cover

**Status.** The desired general square-root weak bound is still unproved. This component obtains an exact source-occupation/coarea interface for the common hard first hit. It identifies both the Jacobian and the multiplicity that a new packing theorem must control. A natural Lipschitz contraction payment is proved, then shown to cover none of the remaining receivers of an actual dense cube input. A separate actual one-dimensional L1 construction rules out uniform per-source multiplicity or occupation bounds. Neither counterexample contradicts a mass-weighted weak bound.

Updated G03/M04 boundaries from R80 are retained, together with J04/E01/J05: no private capture operator, selector theorem, or compensator is supplied by a skill name. The first selector and its regularity are justified below. All receiver integrations use dx. The soft component treats the merged endpoint at this same selector; private soft first corridors are not substituted here.

## 1. Common first-hit selector and the regular class

Use half-side radius r and A_r f(x)=(2r)^(-n) integral_(x+[-r,r]^n)f. For f>=0, lambda>0, pay {f>lambda/2} at lambda-volume <=2||f||_1. At the remaining Lebesgue points with Mf>lambda, define the actual global first strict crossing

    r(x)=inf{r>0:A_r f(x)>lambda}.

Then r is positive and finite, A_(r(x))f(x)=lambda, and every earlier average is <=lambda. Rational radii give a Borel selector by continuity. The R80 source posterior is

    pi_x(dy)=f(y)1{|x-y|_infty<=r(x)}dy/[lambda(2r(x))^n],
    H_x(y)=log[r(x)/|x-y|_infty],
    pi_x{H>=h}<=exp(-nh).                                      (1)

For the differential identity initially take f>=0 smooth with compact support. For almost every lambda, the first selector is locally C1 at almost every selected receiver. Here is the needed justification rather than an unproved selector regularity premise. For each fixed x, the critical values of the C1 function r->A_r f(x) have one-dimensional measure zero: on any compact radius interval, cover {A'_r=0} by the open set {|A'_r|<epsilon}; its interval components have total length at most the interval length, and their image lengths are at most epsilon times those lengths. Exhaust the positive radius axis and let epsilon decrease to zero. The joint critical-value set is Borel: restrict (x,r) to compact boxes, take the closed critical set, and map it continuously to (x,A_r f(x)); then exhaust by compact boxes. Fubini therefore excludes, for almost every lambda, almost every x having any critical radius at value lambda. At a remaining first hit the radial derivative is strictly positive. There is no earlier tangency at value lambda; continuity, the strict small-radius gap f(x)<=lambda/2, and compactness away from zero exclude a suddenly appearing earlier root nearby. The implicit function theorem therefore supplies the same first-hit branch locally as a C1 function.

A uniform weak estimate proved on this regular class would suffice for all nonnegative L1 inputs: approximate f in L1 by nonnegative smooth compactly supported functions, select admissible levels lambda_j converging to lambda, and use convergence at every fixed positive radius and Fatou. For any Mf(x)>lambda, some fixed radius has a strict margin, which persists in the approximants. Thus no dimension or source-count loss is introduced by using the regular class as the proof interface. This does not itself prove the missing estimate.

The same interface applies to the retained physical side-length window [1,2], equivalently half-side r in [1/2,1]. On receivers with A_(1/2)f<lambda/2 and sup_(1/2<=s<=1)A_s f>lambda, use r_w(x)=inf{s in [1/2,1]:A_s f(x)>lambda}. Then 1/2<r_w<1, A_(r_w)f=lambda, and every earlier in-window average is <=lambda. For smooth inputs and generic lambda, the same compact critical-value/Fubini argument gives a noncritical first root; the strict paid-anchor gap and compactness of [1/2,r_w] exclude earlier roots nearby. Thus r_w is locally C1 almost everywhere, with no small-radius argument needed. All Jacobian and occupation identities below hold unchanged with this same r_w. Its posterior age bound is asserted only when r_w exp(-h)>=1/2; earlier radii outside the window have not been tested. In particular, applying (6) uniformly at h0 to this window selector requires restricting E to {r_w exp(-h0)>=1/2}.

## 2. Exact source occupation, with its Jacobian and multiplicity

Let E be a measurable subset of the regular selected receivers and write W=||f||_1. For fixed source y define

    Phi_y(x)=(x-y)/r(x),
    D_y(x)=1-Phi_y(x) dot grad r(x).

At regular points,

    det D_x Phi_y(x)=r(x)^(-n) D_y(x).                         (2)

This is the rank-one determinant identity applied to r^(-1)I-r^(-2)(x-y) tensor grad r. The capture condition is Phi_y(x) in Q=[-1,1]^n. On the subset where D_y!=0, cover by countably many inverse-function charts, partition them disjointly, and apply ordinary change of variables on each chart. The result is

    integral_E (2r(x))^(-n) 1_capture dx
      =2^(-n) integral_Q sum_(x in E: Phi_y(x)=z)
                       1/|1-z dot grad r(x)| dz               (3)

apart from the possible contribution of {D_y=0}. This caveat cannot simply be dropped for every individual y. But it disappears after the required mass-weighted source integration: for fixed x with grad r(x)!=0, the condition D_y(x)=0 defines an affine hyperplane in y, null for f(y)dy; when grad r(x)=0 the determinant factor equals one. Tonelli therefore gives exactly

    lambda |E|
      =2^(-n) integral f(y) integral_Q
          sum_(x in E: x=y+r(x)z)
               1/|1-z dot grad r(x)| dz dy.                    (4)

Every preimage sum in (3)--(5) is explicitly restricted to D_y(x)!=0; critical preimages are omitted, so no zero denominator is assigned a value. The preceding Tonelli argument accounts for precisely the omitted source-weighted domain. Both sides may first be truncated to bounded receiver sets and then increased. Formula (4) is an actual common-source mass identity, not a uniform-in-y estimate. It retains every noncritical preimage and the absolute Jacobian.

The radial link is explicit. Let sigma be cone probability measure on the boundary of [-1,1]^n (each face has weight 1/(2n), with uniform tangential coordinates). Write z=exp(-h)omega. Then 2^(-n)dz=n exp(-nh)dh sigma(domega), so (4) becomes

    lambda |E| = integral f(y) integral_0^infty n exp(-nh)
      integral_boundaryQ sum_(x in E: x=y+exp(-h)r(x)omega)
        1/|1-exp(-h)omega dot grad r(x)| sigma(domega) dh dy.    (5)

This is the requested connection from radial age to dx occupation. The exponential radial density already occurs in geometric volume; the unresolved factor is the jointly source-weighted angular Jacobian and multiplicity.

For every h0>=0, inserting h>=h0 in (5) equals

    lambda integral_E pi_x{H>=h0} dx <=exp(-nh0)lambda|E|.       (6)

Thus the R80 tail constrains the *normalized* weighted radial spectrum in (5). It does not bound its total mass: the unknown lambda|E| appears on the right of (6) as well. Neither conditional angular independence nor an independent source clock follows.

## 3. A true contraction payment, including the precise coverage requirement

Suppose g:R^n->[0,infinity) is globally q-Lipschitz for the infinity norm, and consider a receiver set C on which g>0 and

    g(x)<=r(x)<=R g(x),       qR<1.                            (7)

The fixed-source map x->(x-y)/g(x) is injective on its capture domain |x-y|_infty<=R g(x): if two points have the same image z, they solve x=y+g(x)z, and the Lipschitz contraction q|z|_infty<1 forces equality. Its Jacobian is at least g^(-n)(1-qR), almost everywhere. For nonsmooth g, apply the Lipschitz area formula on bounded patches where g is bounded below by a positive constant; the map is Lipschitz there and injective on the capture domain. Rademacher differentiability gives the stated Jacobian almost everywhere, and countable exhaustion removes the patch restrictions. No smoothing is used to preserve the contact constraint. Therefore

    integral_C (2r(x))^(-n)1_capture dx <=R^n/(1-qR),
    lambda |C|<=R^n/(1-qR) W.                                (8)

For exact contact R=1, q=1-n^(-1/2), n>1, the fee is sqrt(n)W. At n=1 take q=0 and positive constant g. Slight enlargements R=1+O(1/n) retain a square-root fee when 1-q is of order n^(-1/2). This is a correct sufficient payment, but the coverage condition (7) must be proved from the same input.

A natural shared candidate is the maximal Lipschitz minorant

    g_q(x)=inf_(z in E) [r(z)+q|x-z|_infty].                    (9)

It is finite and q-Lipschitz if E is nonempty, and satisfies g_q<=r on E. The exact contact set {g_q=r} is Borel. Pointwise small gradients on disconnected pieces of E do not imply the global contraction needed in (8); (9) avoids that invalid step. The next section shows that even this legitimate global construction can be entirely empty on the relevant receivers.

## 4. All-dimensional actual L1 obstruction: no contraction cover remains

Fix S=[-a,a]^n, f=c1_S with c=2^(n+1)lambda, and let E be its hard crossing set outside S. Then f(x)=0 on E, so none of E is removed by the paid {f>lambda/2} exception. Write d=dist_infty(x,S)>0 for x in E and let y be a closest point of S. Necessarily

    r(x)>d,                                                  (10)

because the cube of radius d touches S in a null set and has zero captured mass.

For 0<t<1 put z_t=y+t(x-y). This lies outside S and tends to y. Use the actual radius R_t=4ntd. For sufficiently small t, the cube centered at z_t meets the local orthant of S; in every coordinate its intersection length is at least R_t-td. Consequently its captured fraction is at least

    2^(-n)(1-1/(4n))^n,

and its average is at least 2lambda(1-1/(4n))^n>=3lambda/2, by Bernoulli's inequality. Thus z_t is in the actual E and its first radius is at most R_t, which tends to zero. Applying (9) gives

    g_q(x)<=lim_(t->0)[R_t+q|x-z_t|_infty]=q d.               (11)

Hence the contact set is empty for every q<=1. More strongly, every proposed enlarged contact condition r<=R g_q with qR<1 is impossible, since it would imply r<=Rq d<d, contradicting (10). This excludes the entire contraction-envelope coverage strategy on this fixed genuine L1 input, in every dimension, rather than merely exhibiting an unfortunate local gradient. It is not a counterexample to the desired weak bound: the input can have a cheap weak crossing set while this particular covering mechanism supplies zero coverage.

Any repair must therefore pay a noncontact source/receiver branch by a new argument, or allow noncontractive maps and control their source-weighted multiplicity. One cannot present (8) as a completed general square-root branch covering a meaningful fraction without proving that additional fact.

## 5. Actual first-hit multiplicity can be arbitrarily large, already in dimension one

Uniform bounds on each source or on the number of preimages in (4) are also too strong. Set lambda=1 and

    f_N=4 1_[0,1]+4 sum_(k=1)^N 1_[R_k,2R_k], R_k=100^k.

This is a positive L1 density, with W_N=4(1+sum R_k). Let M_(k-1)=4(1+sum_(j<k)R_j). For every source y in [0,1] and every z in [2/5,3/5], set

    B_k=R_k-M_(k-1)/4,
    x_k(y,z)=[y+2z B_k]/(1+2z),
    r_k(y,z)=2[B_k-y]/(1+2z).                                (12)

Then x_k-y=z r_k. The receiver lies in the empty gap after the previous source cluster and before R_k, so f_N(x_k)=0. At radius r_k, all earlier intervals are captured, the kth interval is partially captured, and later intervals are absent. Captured mass is

    M_(k-1)+4(x_k+r_k-R_k)=2r_k.

Before the kth interval starts entering, every possible average is at most M_(k-1)/[2(x_k-2R_(k-1))]<1 (replace 2R_0 by 1 for k=1). After the kth interval starts entering, the actual average is bounded above by [M_(k-1)+4(x+r-R_k)]/(2r). This upper envelope increases strictly and first equals one at (12); it is exact near that radius, where all earlier intervals are captured. These inequalities follow directly from the factor-100 separation and are checked rationally below. Thus r_k is the actual global first hit, not merely a solution of the level equation.

On this branch r(x)=2B_k-2x, so r'=-2 and the Jacobian factor at z is 1+2z. The N receiver branches are disjoint. Each y in [0,1] therefore has at least N preimages for every z in [2/5,3/5], giving the genuine source occupation lower bound

    integral_E [2r(x)]^(-1)1{|x-y|<=r(x)} dx
      >=(N/2) integral_(2/5)^(3/5) dz/(1+2z)
      =(N/4)log(11/9).                                      (13)

This is a positive source-measure set of y, not a single exceptional atom. The total input mass grows with N, so (13) does not contradict a mass-weighted weak estimate even in dimension one. It shows exactly why the remaining theorem must exploit the common source budget rather than require a uniform per-source Jacobian/multiplicity bound.

## 6. Remaining general theorem

For the regular common first-hit selector, the exact missing estimate is an input-uniform bound of order sqrt(n) times a subpolynomial loss for the right side of (4), divided by W. The R80 radial law, the R81 positive endpoint/terminal-window payments, and (4) may be used jointly, but none alone controls the joint angular factor and multiplicity. The dense cube example invalidates contraction-envelope coverage; (13) invalidates uniform-per-source replacement of the mass average. No new general square-root closure is claimed.

The soft component's noised face measure also contains sources outside the hard captured cube. The hard posterior in (1) cannot be applied to those sources without its separate positive remainder payment. This component does not modify or duplicate that payment.

## 7. Three-stage actual-input guard

The standard-library guard verifies exact first-hit equations, exclusion of all earlier radii on the indicated physical pieces, and the actual Jacobian factors. It then expands the number of source intervals and checks the multi-preimage construction. Finally it checks the all-dimensional dense-cube contraction obstruction with rational inequalities. The only logarithmic evaluation is the diagnostic value of the proved coefficient log(11/9)/4. No finite sample proves the unresolved mass-weighted estimate.

```python
from fractions import Fraction as F
from math import log

def branch(k,y,z):
 R=100**k
 prev=[100**j for j in range(1,k)]
 M=F(4)*(1+sum(prev))
 right=F(1) if k==1 else F(2*prev[-1])
 B=F(R)-M/4
 x=(y+2*z*B)/(1+2*z);r=2*(B-y)/(1+2*z)
 assert x-y==z*r and x>right and x<R
 assert x-r<0 and R<x+r<2*R
 assert M+4*(x+r-R)==2*r
 # Before current source entry, old mass cannot reach the threshold.
 assert M/(2*(x-right))<1
 assert R-x>0 and r>R-x
 # On the entering piece the upper envelope is 2+[M+4x-4R]/(2radius), increasing; it is exact near the root.
 assert M+4*x-4*R<0
 assert 1-z*F(-2)==1+2*z>0
 return x,r
# Stage 1: exact physical first-hit/source Jacobian identities.
checks=0
for k in (1,2):
 for y in (F(0),F(1,2),F(1)):
  for z in (F(2,5),F(1,2),F(3,5)):
   branch(k,y,z);checks+=1
print('stage1 exact actual first-hit cases',checks)
# Stage 2: N genuine source branches, same positive source set y in [0,1].
for N in (1,4,16,64):
 for y in (F(0),F(1,3),F(1)):
  last=F(-1)
  for k in range(1,N+1):
   low,_=branch(k,y,F(2,5));high,_=branch(k,y,F(3,5))
   assert last<low<high
   last=high;checks+=2
 print('stage2 N',N,'per-source lower coefficient',N*log(11/9)/4)
# Stage 3: actual dense cube input, all-dimensional contraction obstruction.
for n in (1,2,4,16,64,256,1024):
 density_ratio=F(2)*(1-F(1,4*n))**n
 assert density_ratio>=F(3,2)>1
 d=F(1,100*n)
 q=F(3,4);R=F(5,4)
 assert q*R<1 and q*R*d<d
 # At corner receiver 1+d, local trial radius 4nd stays in the cube's local orthant.
 radius=4*n*d
 assert radius<2 and radius>d
 assert F(2)*(1-d/radius)**n==density_ratio
 print('stage3 n',n,'trialradius',radius,'capture average > lambda; R*g_q < distance < first radius')
print('PASS exact branch checks',checks,'no general occupation bound claimed')
```


# R81 coverage: common physical packets, and a real obstruction to one-packet duty

**Status.** A common-source packet certificate is formulated with explicit ownership, signed physical fields, and full Lebesgue event rows. Its finite implementation is being tested independently. A new actual-E2 theorem disproves uniformly cheap **one-packet scalar-duty** covering of all positive continuous-low events: many tiny, distant controlling sources force duty at different scales, and a large source then pays an order-n envelope. The construction uses positive L1 box densities and finite physical scales. It does not establish that these receivers survive the parent continuous-flux exception and short-load filter. Therefore it is not a counterexample to the remaining short-event theorem or the main weak bound. No general cheap common-packet existence theorem is proved.

Read in this round: R80 parent_reduction.md, coverage.md, hardface.md and the updated E03 skill. E03's tree-flow condition is not inferred from captured cubes with different centers. The original receiver measure remains dx. No Git operation or TeX compilation is performed.

## 1. A common physical-source packet candidate

Let mu>=0 be the original finite physical input, and let D_{a,L}=L^{-n}(Psi_{a/2}-Psi_a)(x/L) be the actual E2 contrast. Let E be a specified original positive event and L(x) its original selector. It may be the selected-low event, the continuous-low subset, or the parent short-event subset. The construction must cover the chosen E, not an independently selected collection of favorable rows.

Choose positive physical submeasures nu_P with

    sum_P nu_P <= mu,

and a common vector d_P(L) in [0,1] for each packet. Both choices are independent of x. Define

    U(x)=sum_P d_P(L(x)) (nu_P*D_{a,L(x)})(x),
    C_P=integral_Rn max(0,max_(L in J) d_P(L)(nu_P*D_{a,L})(z)) dz.

If U(x)>=tau a.e. on E, then

    tau |E| <=sum_P C_P.                                      (PC)

Proof: each signed packet summand is bounded above by its nonnegative scale maximum; integrate on E and then extend each nonnegative bound to all space. No positivity of the signed convolution is used. The measure constraint is actual common-source ownership, not a private copy of mu for each receiver. For nonatomic mu, write dnu_P=a_P(y)dmu, a_P>=0, sum a_P<=1. If desired this is an honest partition on mu(dy)du: assign disjoint intervals of lengths a_P(y) in the same auxiliary u in [0,1]. This creates no additional physical mass and does not alter any physical convolution. The price retains cancellation both across original Bernoulli/noise labels and across physical positions within each packet.

Paid representative columns can be added exactly as in R80: if U+sum alpha_l V_l>=tau and integral_E V_l<=K_l, add sum alpha_l K_l to the cost. Repeated use is paid or is subject to separately imposed actual capacities. A uniform upper bound on the infimum of this cost is a new existence assertion, not a consequence of (PC).

### Finite library implementation

For mu=sum_i p_i delta_yi, a fixed binary packet P has field G_{P,k}=sum_(i in P)p_i D_k(.-y_i). Use variables theta_P>=0 and q_Pk with

    0<=q_Pk<=theta_P,    sum_(P contains i)theta_P<=1.

Then nu_P=theta_P mu|P, and q_Pk=theta_P d_Pk. The actual cell rows are

    sum_P q_P,k(r) G_P,k(r)(x_r)>=tau.

Using a COMPLETE physical source/noise/scale face arrangement in the finite labelled-noise model, let G_Pka be the constant field on spatial cell a with exact volume v_a. The price epigraph is

    e_Pa>=0, e_Pa>=q_Pk G_Pka for every k;
    minimize sum_P,a v_a e_Pa.

This is an ordinary finite LP with linear ownership constraints and signed row coefficients. The same physical positions are used for price and receiver fields: independently translating every site in P to the origin would be an incorrect price. Singleton packets recover the sourcewise R80 model. Adding whole-input and other packets can improve the optimum, but restricting to a prescribed partition can worsen it. Arbitrary fractional physical submeasures are allowed in (PC); a finite binary library is only a restricted test class and is not asserted to capture its full optimum. Continuous E2 does not have a finite rectangular arrangement; finite-noise computations alone are not E2 theorems.

## 2. Why hard first-hit ages do not provide ownership automatically

R80 hardface proved for general positive L1 input, after the paid {f>lambda/2} branch, an actual hard first-hit radius r_*(x) with A_r* f=lambda and A_r f<=lambda for r<r_*. Its captured-source posterior satisfies

    pi_x{log(r_*/|x-y|_infty)>=h}<=exp(-nh).

This is a conditional statement at each receiver under one fixed input. It supplies neither a common partition nu_P nor a bound on sum_P C_P. First-hit rows at different centers have nonnested source sets. A per-receiver packet selected from a recent shell is therefore not a packet in (PC) unless its reuse of each physical source has a proved allocation and budget. In addition, the independent positive soft-layer first corridor in the parent reduction does not inherit the hard first-hit age inequality. This round does not make that substitution.

One tempting obstruction was examined and rejected: a tiny uniform cube does not immediately force order-n first-hit duty on all of its source. At a low first-hit level only thin source caps are captured; merging all such captures across scales without measuring their source mass would overstate the cost. This rejected route is not used in the theorem below.

## 3. Critical-layer facts retained with their exact role

For a=1/n, n>=2, R80 proved for the ACTUAL E2 kernel

    c H <= (D_a)_+ <= H,    D_a<=0 outside the unit cube,
    c=1/32.                                                  (K)

Briefly, phi(x)<=phi(0)<=1-1/(2e). Inside the cube, with b_i=1-phi(x_i), integrate the derivative of product_i(1-u b_i) from 1/(2n) to 1/n to obtain D_a>=1/(4e^2)>1/32. With k outside coordinates the ratio Psi_(a/2)/Psi_a is at most 2^-k[(2n-1)/(2n-2)]^(n-k)<=exp(1/2)/2<1. Also every psi_a<=1. When one coordinate satisfies |z_1|>1/2,

    Psi_a(z)<=a phi(z_1)<=a exp[-(|z_1|-1/2)],
    |D_a(z)|<=Psi_a(z), F_a(z)<=Psi_a(z),                    (T)

where the last two inequalities use D_a<=0 outside and F_a=(Psi_(a/2)+Psi_a)/2. The elementary phi tail bound follows by integrating w(t)<=exp(-|t|) over an interval of length one. These bounds are actual analytic kernels; no ray monotonicity of a discretization is assumed.

## 4. Main obstruction: one common packet costs Omega(n)

**Theorem.** For every integer n>=6 there is a positive compactly supported L1 density f of mass W<2, a finite J subset [1,2], and tau>0 such that E={max_J f*D_a,L>tau, sup_[1,2] f*F_a,L<=67 tau} contains positive-volume blocks. If a single common duty d:J->[0,1] covers this event through

    d(L(x)) (f*D_a,L(x))(x)>=tau a.e. on E,

where L(x) is the original maximizing selector, then its one-packet price obeys

    integral max(0,max_J d(L)(f*D_a,L)) >= floor(n/6)/5000.     (O)

In particular this price divided by W is at least floor(n/6)/10000. Along dimensions that are powers of two, a=1/n is exactly one of the retained dyadic soft layers. This rules out a uniformly sublinear one-packet price for the stated positive continuous-low class. It says nothing against multi-packet certificates, separately paid exception branches, or the main weak maximal theorem.

### Construction and positive-volume winner blocks

Put m=floor(n/6), epsilon=1/(100n), h=epsilon/8, R=20n,

    L_j=2^(6j/n), v_j=L_j^n=64^j, 1<=j<=m,
    tau=2^(-2n)/128, p_j=64 tau v_j,
    y_0=0, y_j=R j e_1.

Let b_h be the normalized indicator of [-h,h]^n, and take

    f=b_h +sum_(j=1)^m p_j b_h(.-y_j).

All sources are genuine positive L1 boxes. Since sum 64^j<64^(m+1)/63 and 64^m<=2^n,

    sum p_j <(4096/63) tau 2^n <2^(-n),  W<2.

For controller j use the open receiver cube U_j whose every coordinate relative to y_j lies in

    ( L_j(1-3epsilon/2)/2, L_j(1-epsilon)/2 ).

Every point of its own source box lies inside the L_j receiver cube. At every earlier registered scale all n coordinates of its own source are outside the receiver cube. Indeed (1-2epsilon)^n>=1-2n epsilon=49/50>1/64, and the perturbation h is smaller than the displayed margins. All other source boxes are outside in coordinate one at all scales in [1,2].

Uniformly at all these receivers and scales, the TOTAL contribution of foreign sources to either the absolute signed field or the positive background is at most

    (2/n) exp(-10n+2) <= tau/4.                              (F)

The distance bound uses |x_1-y_ell,1-z_1|>=R-2, division by L<=2, the further half-unit in (T), and W<2. For a deliberately loose verification, exp(-10n+2)<=2^(-10n+2), so (F) follows already for n>=2.

At scale L_j, (K) gives the own contrast >=c p_j/v_j=2tau; foreign contrasts are nonpositive and bounded by tau/4. Thus T_Lj>=7tau/4. At an earlier registered scale every source contrast is nonpositive. At a later registered scale the own contrast is at most p_j/v_(j+1)=tau, and all foreign contrasts remain nonpositive. Consequently L_j is the unique actual registered signed maximizer on the whole positive-volume U_j. Moreover T_Lj<=p_j/v_j=64tau.

### Continuous low-background gate

This is checked at every physical L, not just J. If L>=L_j(1-3epsilon), then the own background is bounded by

    p_j/L^n <=64tau/(1-3epsilon)^n <=(6400/97)tau<66tau.

If L<L_j(1-3epsilon), all n coordinates of every own-source displacement are outside the hard cube. Both endpoint products are then at most a^n=n^(-n). Since L>=1 and v_j<=2^n, the own background is at most

    p_j n^(-n)<=64tau(2/n)^n<=64tau.

Adding (F) proves F_L<67tau throughout [1,2]. Thus U_j is genuinely inside E. It cannot be dismissed merely as a high-background artifact. Its membership in the parent's E_cont complement or short-load branch is NOT claimed.

### Duty forcing and anchor price

The row inequality on U_j and T_Lj<=64tau force d(L_j)>=1/64, for every j. Around the large anchor, restrict x to the centered cube of side L_j-2h. Its entire anchor source is captured, so its own contrast is >=c/v_j. All controllers have nonpositive foreign contrast of total magnitude <=tau/4<=c/(2v_j). Hence

    T_Lj(x)>=c/(2v_j) on that eroded anchor cube.

Write V_j=(L_j-2h)^n and V_0=0. These cubes are nested. Since 2nh=1/400,

    V_j>=(399/400)v_j,
    (V_j-V_(j-1))/v_j >=399/400-1/64>49/50

for j>=2; the first shell satisfies the stronger 399/400 bound. On shell j, use its own scale L_j in the positive maximum. Therefore

    price >=(c/128)sum_j (V_j-V_(j-1))/v_j
           >=(1/4096)(49/50)m >m/5000.

This proves (O). The cost arises from one large source forced to stay active by tiny, distant controllers. Its total mass is not repeated; this is exactly why a single shared duty is insufficient. The receiver blocks have very small volumes, and no lower bound on the weak maximal constant follows from this source-envelope cost.

## 5. Consequence for the next general attempt

The singleton model fails arbitrary refinement (R80); the whole-input model can pay order n even on actual positive continuous-low events (Section 4). Fixed partitions can also miss useful cancellations. Hence the next meaningful experiment is the shared-capacity packet program of Section 1, allowing data-dependent physical grouping and distinct common scale duties, with every overlap paid. This is a concrete implementable candidate, not an assertion that its optimum is cheap.

To close the parent's remaining theorem one must cover its actual short low-load receivers, or pay those receivers by an independent branch, with total sqrt(n) times a subpolynomial factor. The obstruction here has not been checked against the continuous-flux exception and is not advertised as surviving it. No tree mass flow, angular independence, private receiver packet, or favorable finite-grid replacement is inferred. The dimension-uniform common packet existence estimate remains unproved.

## 6. Three-stage guard and independent finite-model tests

The embedded program below checks exact construction constants, actual positive L1 box fields and original finite-library maximizers with a dense continuous-background diagnostic, then increases dimension and controller count. The continuous gate is certified by the proof, not by sampling. Actual E2 one-dimensional factors are evaluated by deterministic midpoint quadrature; doubling checks are diagnostic, not interval arithmetic. Source box averages retain the exact hard overlap and integrate the soft factor. Independent implementation-agent complete-cell LP results are reported separately; its finite labelled law is not silently equated with E2.

```python
from fractions import Fraction as Q
from functools import lru_cache
from math import exp, prod, floor
checks=0

@lru_cache(None)
def phi(x,M):
    x=abs(x);v=0.0
    for j in range(M):
        r=(j+0.5)/M
        if x<=0.5:
            v+=r*(2-exp(-(0.5-x)/r)-exp(-(0.5+x)/r))
        else:
            v+=r*(exp(-(x-0.5)/r)-exp(-(x+0.5)/r))
    return v/M

@lru_cache(None)
def factors(x,L,h,n,M):
    hard=max(0.0,min(h,x+L/2)-max(-h,x-L/2))/(2*h)
    # Two midpoint nodes for the tiny physical source interval.
    soft=sum(phi(abs((x-u)/L),M) for u in (-h/2,h/2))/2
    a=1/n
    return ((1-a/2)*hard+(a/2)*soft,(1-a)*hard+a*soft)

def fields(n,m,j,L,M=256):
    eps=1/(100*n);h=eps/8;R=20*n
    Lj=2**(6*j/n);offset=Lj*(1-1.25*eps)/2
    tau=2.0**(-2*n)/128
    Ts=Fs=0.0
    for k in range(m+1):
        # All field results divided by tau to avoid tiny thresholds.
        massratio=1/tau if k==0 else 64.0*64**k
        a1,b1=factors((j-k)*R+offset,L,h,n,M)
        a2,b2=factors(offset,L,h,n,M)
        aa=a1*a2**(n-1)/L**n;bb=b1*b2**(n-1)/L**n
        Ts+=massratio*(aa-bb);Fs+=massratio*(aa+bb)/2
    return Ts,Fs

# Stage 1: exact constants, source masses, price shells.
for n in range(6,79):
    m=n//6;tau=Q(1,128*2**(2*n))
    ps=[64*tau*64**j for j in range(1,m+1)]
    assert sum(ps)<Q(1,2**n)
    assert Q(399,400)-Q(1,64)>Q(49,50)
    assert Q(49,50)*m/4096>Q(m,5000)
    assert Q(2**3,n*2**(10*n))<=tau/4
    # Bernoulli bound for the continuous low gate.
    assert Q(6400,97)+Q(1,4)<67
    assert Q(64)*Q(2,n)**n<=64
    checks+=6
print('stage1 exact construction checks',checks)

# Stage 2: actual L1 E2 fields, finite true winner, dense background diagnostic.
maxerr=0.0
for n in (6,12,24):
    m=n//6;J=[2**(6*j/n) for j in range(1,m+1)]
    mesh=sorted(set(J+[1+q/32 for q in range(33)]))
    for j in range(1,m+1):
        vals=[fields(n,m,j,L) for L in J]
        winner=max(range(m),key=lambda k:vals[k][0])
        assert winner==j-1
        assert 1.75<vals[winner][0]<=64
        assert all(vals[k][0]<=1+1e-8 for k in range(j,m))
        bg=max(fields(n,m,j,L)[1] for L in mesh)
        assert bg<67
        finer=fields(n,m,j,J[j-1],512)
        maxerr=max(maxerr,abs(vals[j-1][0]-finer[0]))
        checks+=4
    print('stage2 n,m',n,m,'last T/tau',round(vals[-1][0],9),'max grid F/tau',round(bg,9))
print('stage2 doubled r-quadrature max T/tau discrepancy',format(maxerr,'.9g'))

# Stage 3: dimension and number of controlling sources vary separately.
for n in (36,48,72):
    for m in sorted(set((1,n//12,n//6))):
        J=[2**(6*j/n) for j in range(1,m+1)]
        forced=[]
        for j in range(1,m+1):
            vals=[fields(n,m,j,L,128)[0] for L in J]
            assert max(range(m),key=lambda k:vals[k])==j-1
            assert 1.75<vals[j-1]<=64
            forced.append(1/vals[j-1])
            assert forced[-1]>=1/64
            # Includes registered scales and seventeen physical samples.
            assert max(fields(n,m,j,L,128)[1] for L in J+[1+q/16 for q in range(17)])<67
            checks+=4
        h=1/(800*n);old=0.0;lower=0.0
        # Anchor lower-bound price; finite selected rows force every d_j.
        for L,d in zip(J,forced):
            V=(L-2*h)**n
            lower+=(V-old)*d/(64*L**n)
            old=V
        assert lower>m/5000
        checks+=1
        print('stage3 n,controllers',n,m,'anchor price lower diagnostic',round(lower,8),'analytic floor',m/5000)
print('PASS',checks,'checks; all quadrature values diagnostic, proofs certify inequalities')
```

**Execution:** PASS 643 checks. The maximum doubled-r quadrature discrepancy in the displayed T/tau values was 7.10063978e-06. At n=6,12,24, last-controller T/tau was respectively 13.147501385, 12.760505643, 12.576345280; the diagnostic maximum grid backgrounds were 40.254443912, 40.628102452, 40.808242588. The proof supplies the continuous bound 67. Stage 3 varied n=36,48,72 and controller counts independently up to 12. These numerical values have no theorem role.

The independently read `packet_numeric.md` reports 44 rational primal/dual brackets from 11 complete-cell finite-noise fixtures, maximum gap below 9.54e-10. It preserves adverse cases: at N=16 the optimized singleton price is about .203125 while the whole-input price is about .242158; fixed partitions can also worsen singleton prices. For the finite-noise spacing pair the exact singleton optimum is 13/64 and whole-input optimum 33/256, demonstrating genuine physical-position cancellation. The finite law has shifts (-1,0,1) and probabilities (1/4,1/2,1/4); no E2 approximation error is asserted. The implementation agent owns those files and their replay. These tests motivate adaptive shared packets but do not prove their uniform price.


# R81: verified factor-two to all-scale localization

**Status: PROVED transfer; OPEN local core.** A uniform general-input weak (1,1) bound on the fixed full-side window `[1,2]` does imply an all-scale bound with an `O(log(n+2))` factor. There is no additional additive or multiplicative `n` cost in this transfer. The short-time hard-face residual in R81 remains unproved, so this result does not complete the main square-root theorem.

The symbol `mathfrak B_n` below denotes the window operator constant, and is different from the smooth-kernel quantity called `B_n` in `soft.md`.

## 1. Primary theorem and retained history

Primary source: Assaf Naor and Terence Tao, *Random martingales and localization of maximal inequalities*, Journal of Functional Analysis **259** (2010), no. 3, 731–779, DOI [10.1016/j.jfa.2009.12.009](https://doi.org/10.1016/j.jfa.2009.12.009). The identity and publication metadata were checked against the [publisher record](https://www.sciencedirect.com/science/article/pii/S0022123609005126) and the [author publication list](https://web.math.princeton.edu/~naor/). The actual theorem was read in the [author-hosted 41-page PDF](https://web.math.princeton.edu/~naor/homepage%20files/HLM.pdf), not inferred from an abstract. The page numbers below are this PDF's printed page numbers, not journal pagination.

The extracted-text evidence positions are:

| Position | What was checked |
|---|---|
| p. 2 | Separable metric, Radon measure, closed balls of positive finite measure |
| pp. 4–5, (8), Theorem 1.1, (10) | Microdoubling and localization to radius ratio equal to the microdoubling parameter |
| pp. 5–6, (11) | Explicit `p=1` specialization and arbitrary integer subdivision |
| p. 11, Theorem 2.1, (23)–(25) | Modified Doob theorem includes `p=1` |
| pp. 16–19, (43)–(55) | Proof of Theorem 1.1; finite measure/support reduction and random padded partitions |

To distinguish the physical dimension from the source's microdoubling parameter, call the latter `d`. The weak endpoint statement actually needed here is the source's (11): for each integer `m>=1`,

\[
 \|M_R\|_{1\to1,\infty}
 \le \kappa_{\rm NT}\left[
 K+m\left(1+\frac{\log\log K}{1+\log d}\right)
 \sup_{r>0}\|M_{R\cap[r,d^{1/m}r]}\|_{1\to1,\infty}\right].\tag{L81.1}
\]

Here `d>1`, `K>=5`, and `mu(B(x,(1+1/d)r))<=K mu(B(x,r))`. We use `K=6`, so any endpoint convention on the lower bound for `K` is immaterial. The displayed implicit constant is universal; no numerical value for `kappa_NT` is claimed. The endpoint is explicit in (11), so no limiting interpolation argument from `p>1` is being used. The random partition construction is imported as part of the published theorem; this note does not claim the unsmoothed cube averages themselves form a martingale.

Prior-history search: `output/centered_cube_round0*` and the actual retained directory `Math-Research-euclidean-20261010/centered-cube-upper-bound` were searched for Naor–Tao/microdoubling/localization. My initial relative lookup of `Math-Research-centered-cube-work/centered-cube-upper-bound` under the task directory failed; this was only a failed path lookup. The parent's authoritative check confirms the active clone at `/Users/zhengzhihao/Math-Research-centered-cube-work`, commit `dbd0f0b`. R69's `energy_to_weak.md`, Section 4, already verifies the physical ratio-`max(n,2)` version. We retain that result. The incremental contribution here is its precise finite subdivision into factor-two physical windows, plus the R81 residual return. Earlier rounds calling full-scale localization an outstanding dependency can now use the theorem below once their own uniform window bound is established.

## 2. General-input factor-two transfer

For `f>=0` in `L1(R^n)`, let

\[
 A_Lf(x)=L^{-n}\int_{x+[-L/2,L/2]^n}f(y)\,dy,
 \quad M_{[a,b]}f=\sup_{a\le L\le b}A_Lf,
 \quad \mathfrak B_n=\|M_{[1,2]}\|_{1\to1,\infty}.
\]

**Theorem L81.2 (proved).** There is an absolute `C_loc` such that, for every integer `n>=1`,

\[
 C_n^\square\le C_{\rm loc}\log(n+2)\,\mathfrak B_n.\tag{L81.2}
\]

Proof. Equip `R^n` with `l_infinity` distance and Lebesgue measure. Its metric balls are precisely the centered cubes of radius `r=L/2`. The metric is separable, the measure is Radon, and ball volume is `(2r)^n`. Set

\[
 d_n=\max(n,2),\qquad m_n=\lceil\log_2d_n\rceil\ge1.
\]

Microdoubling is genuinely dimension-independent:

\[
 \frac{|B(x,(1+1/d_n)r)|}{|B(x,r)|}
 =(1+1/d_n)^n\le e<3<6.\tag{L81.3}
\]

The first inequality follows from `log(1+u)<=u` and `n<=d_n`; the elementary `e<3` follows from its power series, since `k!>=2^{k-1}` for `k>=2`, with strict inequality for `k>=3`. Thus all hypotheses of (L81.1) hold with `K=6`, including `n=1` through `d_1=2`.

The dilation `f_a(z)=f(az)` has `||f_a||1=a^{-n}||f||1` and

\[
 A_Lf(az)=A_{L/a}f_a(z).
\]

Consequently `||M_[a,2a]||_(1->1,infinity)=mathfrak B_n` for every `a>0`. This exact identity gives uniformity in the physical starting scale. Since `d_n^{1/m_n}<=2`, the subwindow norm in (L81.1) is at most `mathfrak B_n`. Hence

\[
 C_n^\square\le\kappa_{\rm NT}
 \left[6+m_n\left(1+\frac{\log\log6}{1+\log d_n}\right)\mathfrak B_n\right].\tag{L81.4}
\]

The radius/full-side conversion multiplies both window endpoints by `2`; it does not change their ratio or incur a factor `2^n`.

For completeness `mathfrak B_n>=1`: use `f=1_[-R,R]^n`, take the fixed scale `L=1`, and take thresholds `1-epsilon`. On `[-R+1/2,R-1/2]^n`, the average is `1`. The weak ratio tends to `1-epsilon` as `R` tends to infinity, then to `1` as `epsilon` tends to zero. Also `0<loglog6<1`, so its coefficient in (L81.4) is less than `2`. Since `m_n>=1`,

\[
 C_n^\square\le8\kappa_{\rm NT}m_n\mathfrak B_n
 \le8\kappa_{\rm NT}\left(1+\frac{\log d_n}{\log2}\right)\mathfrak B_n.
\]

Because `d_n<=n+2` and `log(n+2)>=log3`, one valid declared constant is

\[
 C_{\rm loc}=8\kappa_{\rm NT}(1/\log3+1/\log2).
\]

This proves (L81.2). No input count, atom count, temporal depth, or scale-library cardinality enters the constant.

One can also derive the factor `m_n` directly from the larger window: subdivide `[a,d_na]` into `[a d_n^{j/m_n},a d_n^{(j+1)/m_n}]`, `0<=j<m_n`. At the SAME threshold `lambda`, the level set of the maximum is the union of these `m_n` level sets. Each has volume at most `mathfrak B_n||f||1/lambda`. This is a finite union of maxima, so no summation inequality for weak quasi-norms of additive operators is being assumed. It is not a union over infinitely many factor-two windows; the latter would have infinite cost. Naor–Tao supplies the latter all-scale step.

## 3. Finite-library and R81 residual return

If a bound `B` is proved uniformly for every finite physical scale set `J subset [1,2]` and every nonnegative `L1` input, then `mathfrak B_n<=B`. Indeed, for fixed `x`, the integral over a moving cube is continuous in `L>0`, by dominated convergence and the zero Lebesgue measure of cube boundaries. Take nested finite sets whose union is dense in `[1,2]`; their maxima increase to the continuous-window supremum. The strict superlevel sets increase to the corresponding window event, so monotone convergence preserves the weak constant. This is a proof for `L1` densities. Atomic endpoint conventions, if used in another module, require that module's separate transfer argument.

Use `P_n=C_paid(n,epsilon)` from R81 `soft.md`, (13). The result there is already uniform for arbitrary nonnegative `L1` input and gives

\[
 \lambda|\{M_{[1,2]}f>\lambda\}|
 \le P_n\|f\|_1+\lambda|E_{\rm fresh}(f,\lambda)|,
 \quad P_n=O(\sqrt n).
\]

The following is the exact missing-hypothesis return:

\[
 \bigl[\ \forall f\ge0,\lambda>0:\ 
 \lambda|E_{\rm fresh}(f,\lambda)|\le D_n\|f\|_1\ \bigr]
 \Longrightarrow
 \mathfrak B_n\le P_n+D_n
 \Longrightarrow
 C_n^\square\le C_{\rm loc}\log(n+2)(P_n+D_n).\tag{L81.5}
\]

The first implication uses R81's actual level-set inequality, so there is no new threshold-splitting loss in this accounting. `D_n=O(sqrt(n) log^b(n+2))` would give `C_n^square=O(sqrt(n) log^{b+1}(n+2))`; `D_n=sqrt(n)n^{o(1)}` would give the requested square-root subpower result because `loglog(n+2)/log n` tends to zero. The residual hypothesis is **OPEN**.

If instead the optional hard-face version of `soft.md`, (14)–(15), is used, its extra paid term `4 log2/alpha` must be included in `P_n`; it is `O(1)` because `alpha>=1/2`. The same transfer applies to its retained event with its actual threshold `alpha lambda/8`. No private temporal normalization or receiver-dependent starting window is justified by this theorem.

**Minimal hard-endpoint variant.** The newer `parent_radial.md`, Section 3, (R8)–(R9), proves a distinct precise interface using only the anchor gate `{A_0>=lambda/2}` and the smooth gate `{sup P_t>lambda/2}`. Let `E_hard(f,lambda)` be exactly the remaining hard-first-hit receivers after those two deletions. With `T=log2`, its paid coefficient is

\[
 P_n^{\rm hard}=4+2T\sqrt{7n/3},\qquad
 \lambda|\{M_{[1,2]}f>\lambda\}|
 \le P_n^{\rm hard}\|f\|_1+\lambda|E_{\rm hard}(f,\lambda)|.
\]

Every receiver in that retained set automatically satisfies its same-selector signed incoming hard-face resolvent inequality `Z_tau>=7lambda/16`, with memory `min(log8/n,tau)`. This identity uses no continuous-primitive exception and no positive-softness face-error payment. It does not itself bound the remaining receiver volume. Therefore the exact optional return is

\[
 \bigl[\ \forall f\ge0,\lambda>0:\
 \lambda|E_{\rm hard}(f,\lambda)|\le D_n^{\rm hard}\|f\|_1\ \bigr]
 \Longrightarrow
 C_n^\square\le C_{\rm loc}\log(n+2)
 \left[4+2(\log2)\sqrt{7n/3}+D_n^{\rm hard}\right].\tag{L81.6}
\]

The retained-set hypothesis is still open. Its large recent surplus is automatic on the retained hard event and must not be called an independently rare event. This newer alternative leaves the valid soft versions above intact.

An elementary unconditional reference budget is `mathfrak B_n<=2n`: partition `[1,2]` into `n` windows with endpoints `2^{j/n}`. For `L` in one such window with upper endpoint `b`, positivity gives `A_Lf<=2 A_bf`; each `A_b` is an `L1` contraction. The finite level-set union costs `2n`. Thus (L81.2) alone recovers an `O(n log(n+2))` all-input upper bound and does not improve its dimensional exponent without the new core budget.

## 4. Three-stage exact algebra guard

This guard checks the scale subdivision and integer conventions, and detects an invalid choice of a fixed microdoubling parameter. It does not test or prove the missing weak residual estimate. All assertions use exact integers/rationals; there is no floating logarithm near a power-of-two boundary. Large dimensions in stage 3 only test the subdivision, while the analytic proof (L81.3) handles microdoubling at all dimensions.

```python
from fractions import Fraction
from math import factorial

def guard(n, micro=True):
    d = max(n, 2)
    m = (d - 1).bit_length()       # exact ceil(log_2 d), d >= 2
    assert 2**(m - 1) < d <= 2**m
    assert m >= 1
    if micro:
        assert (d + 1)**n < 3 * d**n
    return m

stages = [
    list(range(1, 33)),
    sorted({2**k + j for k in range(1, 13) for j in (-1, 0, 1)}),
    sorted({2**k + j for k in (16, 32, 64, 128, 256, 512, 1024)
            for j in (-1, 0, 1)}),
]
for i, ns in enumerate(stages, 1):
    ms = [guard(n, micro=i < 3) for n in ns]
    print('stage', i, 'dimensions', len(ns),
          'm-range', min(ms), max(ms), 'passed')
assert Fraction(3, 2)**5 > 6  # physical n=5, invalid fixed d=2, K=6
assert sum((Fraction(1, factorial(k)) for k in range(65)), Fraction()) < 3
print('fixed microparameter d=2 fails K=6 at physical n=5; detected')
print('all exact integer/rational assertions passed; analytic all-n proof still required')
```

Actual run (2026-10-11, Python 3, deterministic; no seed needed):

```text
stage 1 dimensions 32 m-range 1 5 passed
stage 2 dimensions 35 m-range 1 13 passed
stage 3 dimensions 21 m-range 16 1025 passed
fixed microparameter d=2 fails K=6 at physical n=5; detected
all exact integer/rational assertions passed; analytic all-n proof still required
```

The fixed choice `d=2` cannot be used to obtain a constant-factor global transfer for increasing physical `n`: its microdoubling ratio is `(3/2)^n`, so the theorem's additive `K` then grows exponentially. This detects an assumption failure, not a counterexample to the square-root target. Likewise a bound only for a selected source class, or only for a receiver-normalized window, is insufficient to bound the general operator norm `mathfrak B_n`.

## 5. Search/read record and skill scope

Actual primary query: exact title restricted to arXiv, ScienceDirect, Springer, and the Princeton author domain; accessed 2026-10-11. Source identity is verified. Reading scope is the theorem, endpoint corollary, relevant modified Doob statement, and localization proof, not the entire 41-page article. No claim of a new literature search over unrelated tools is made. The author PDF's pages are not transplanted into journal pagination.

The academic-literature-search skill was used for primary-source identity and evidence location. N04 was read as a check against an unpaid infinite window sum: the proof instead uses the published all-scale norm localization and an explicit finite union. L03 was read for the exact arithmetic guard; no certified floating interval package or numerical proof of a general weak bound is claimed. Those skill provenance tables do not substitute for the original theorem.

Verified BibTeX for the cited publication (the author-PDF page locations above remain separate):

```bibtex
@article{NaorTao2010Localization,
  author = {Naor, Assaf and Tao, Terence},
  title = {Random martingales and localization of maximal inequalities},
  journal = {Journal of Functional Analysis},
  year = {2010},
  volume = {259},
  number = {3},
  pages = {731--779},
  doi = {10.1016/j.jfa.2009.12.009}
}
```

**Final dependency:** the whole-scale localization link is now proved at the claimed logarithmic cost. The remaining main-theorem obstruction is an all-input, all-threshold budget for the actual R81 short terminal hard-face surplus (or another sufficient local core bound). A square-root theorem is not established here.


# R81 actual endpoint and common hard first-hit numerical record

The three-stage calculation uses seven genuine positive L1 box-mixture inputs and 21 fixed rational receiver points. Every receiver has a certified GLOBAL hard first contact, and every endpoint calculation uses that same physical scale. The principal ε=0 variant has 18 numerical minimal-gate passes out of 21 points; the remaining three n1 points fail the smooth gate. This is a point diagnostic, not a receiver-volume estimate or proof of the centered-cube target.

The actual E2 source convolution is integrated directly. No empirical noise prior or independently optimized soft winner enters the calculation. The archive also retains standard and finer positive ε comparisons, and separates captured original sources from outside-source soft contributions.

## Input, first contact and three stages

The input is the positive density

    f(y)=Σ_i w_i (2e)^−n 1_{y∈c_i+[−e,e]^n},  W=Σ_i w_i=||f||_1.

Boxes may overlap; all masses remain positive. Centers, widths, weights, thresholds and receiver coordinates are registered as exact rational strings. For C(L)=∫_{Q(x,L)}f and A(L)=C(L)/L^n, the hard first contact is the earliest L>0 with A(L)≥λ. Every registered point is a strict upward-crossing case, so this is also the boundary of the first strict above-threshold event. All physical L* lie in (1,2), and A(1)<λ/2 is checked exactly at every point. The stronger original source-density premise f(x)≤λ/2 is also checked, although the final minimal endpoint interface does not need it.

| Stage / input | n | Boxes | Source geometry | Receiver points | λ |
|---|---:|---:|---|---:|---|
| Pilot: narrow single | 1 | 1 | center 3/4, e=1/64 | 3 | 24/49 |
| Pilot: narrow single | 2 | 1 | center (3/4,3/4), e=1/64 | 3 | 768/2401 |
| Pressure: correlated | 2 | 4 | 3 near-diagonal far boxes plus local background; e=1/16 | 3 | 1/8 |
| Pressure: correlated | 4 | 7 | 6 near-diagonal far boxes plus local background; e=1/16 | 3 | 17709/851968 |
| Expanded: correlated | 4 | 9 | 8 near-diagonal far boxes plus local background; e=1/16 | 3 | 52087/2621440 |
| Expanded: correlated | 8 | 13 | 12 near-diagonal far boxes plus local background; e=1/16 | 3 | 1629763/1610612736 |
| Expanded: directional correlated | 16 | 4 | diagonal far centers 3/4,17/20,19/20 plus background; e=1/64 | 3 | 1/131072 |

Pilot far mass is one. Its threshold is 3/4 of the fully captured average at L=2(3/4+1/64). The near-diagonal fixtures reuse the R80 physical source construction: main coordinate (12+i mod 7)/16, independent registered jitter from {−2,−1,0,1,2}/64, and normalized weights proportional to 1+i mod 4. The far-source average at L=2 and x=0 fixes λ at half that average. The added local box has mass λ(2e)^n/4. Thus f(x)=λ/4 on the selected local receiver points, but its captured mass and contribution to W are small. The n16 far masses are 1/6,1/3,1/2, with the same λ/4-density background construction. Its far centers share a strong coordinate direction; no angular independence is assumed.

Each input uses x=0 and two alternating-sign perturbations: ±1/512 in the pilots, ±1/64 in the near-diagonal cases, and ±1/1024 for n16. These are prescribed rational points in original Lebesgue coordinates, not draws from a source-weighted receiver law. There is no Monte Carlo, dx integration, SE, training or held-out sample in this round. A source list containing 39 box components across the seven inputs is not 39 distinct proof hypotheses.

The correlated source RNG base is 800611, with seeds base+100n+N BEFORE adding the background box: 800814,801017,801019,801423. The pilots and n16 input are deterministic. All complete source lists are in JSON, so replay does not depend on an external source generator or earlier artifact.

Between each pair of physical face breakpoints 2|x_j−(c_ij±e)|, hard captured mass is an exact polynomial in L. The program copies the audited R80 Fraction/Sturm mechanism into a standalone file, scans from L=0, excludes every earlier root and records negative witnesses. The terminal all-captured region extends to infinity. Each first root is an exact rational singleton or a 64-step rational isolating interval with exactly one root. The archive contains 411 physical-interval polynomials and 126 exact captured-posterior age comparisons at exp(−h)∈{1/16,1/8,1/4,1/2,3/4,7/8}. These certificates concern the registered hard geometry and captured source posterior; they do not prove an event-volume bound or certify E2 integrals.

## Endpoint and exact hard-zero fresh contribution

Let h=1_[−1/2,1/2], φ=h*w with w(z)=∫_0^1 exp(−|z|/t)dt, ψ_ε=(1−ε)h+εφ and P_ε(L)=f*(ψ_ε^⊗n)_L. The merged endpoint is U=P_ε−P_1, with α=(1−ε)^n and κ=n(1−ε). Three settings are evaluated at every SAME hard contact:

* Standard dyadic ε≤1/(2n).
* Finer dyadic ε≤1/(2n²).
* Principal hard-zero ε=0: U=A−P_1, α=1 and κ=n.

There are 63 labelled endpoint records. The two positive ε settings coincide for n1, so three of those labels duplicate a parameter value. They are not extra independent evidence. The positive settings preserve their original fixtures rather than being discarded after the hard-zero route was chosen.

With t=log L, the actual equation is

    U'=Face_ε+v−κU−κP_1,  v=f*(B_ε−B_1).

Face_ε is positive; v is signed and retained. The same-source, same-scale resolvent from L=1 to L* is

    U(L*)=(L*)^−κ U(1)
          +∫_0^logL* e^−κ(logL*−r)[Face_ε(r)+v(r)−κP_1(r)]dr.

For positive ε, θ=αλ/2, h_age=log(n+2)/(2κ), and fresh begins at max(1,L*exp(−h_age)). The program records the original stronger filters: smooth maximum≤θ, Q_cont=|U(1)|+2sup|∫v|≤θ/4, and old face≤θ/4. Their smooth/primitive checks use a registered physical path and quadrature; they do not certify continuous suprema.

For ε=0, θ=λ/2, h_age=log8/n and ξ=min(h_age,logL*). Write L0=L*e^−ξ. The exact hard fresh contribution is

    F_fresh=∫fresh e^−n(logL*−r)Face_H(r)dr
           =λ−C(L0)/(L*)^n.

The old hard contribution from L=1 is [C(L0)−C(1)]/(L*)^n. First contact gives old≤λ/8 when ξ=h_age, and old=0 when L0=1. The program brackets 8^−1/n by 80 exact rational bisections, combines it with the certified L* interval, and uses monotonic captured mass to certify intervals for F_fresh and old. All 21 old bounds pass exactly. In these particular fixtures the old interval is [0,0]: only the already captured local box is present before the fresh far-source arrivals. This does not establish zero old traffic for arbitrary inputs.

The primary hard-zero signed quantity uses that exact hard interval midpoint and the actual numerical E2 occupation:

    Z_fresh=F_fresh−n∫fresh e^−n(logL*−r)P_1(r)dr.

Only F_fresh and the old hard bound are rational certificates. Z_fresh remains a numerical E2 value. The raw hard-face quadrature result is saved separately; it is not silently substituted for the exact captured-mass expression.

The final minimal flags are A(1)<λ/2 (exact) and registered P_1 maximum≤λ/2, including P_1 at the same hard contact. Under the TRUE continuous smooth condition, first contact and these minimal premises already force Z_fresh≥7λ/16. A large fresh value is therefore expected; it does not identify a rare residual event or pay its receiver volume. The program also retains Q_cont as a stronger diagnostic filter, without treating it as necessary for the minimal interface.

## Findings and verified gate scope

All hard contacts and A(1)<λ/2 premises are exact. There are 48 same-contact smooth passes among the 63 endpoint rows. Twelve rows pass every original stronger numerical filter: six fine-ε records at n8/n16 and six hard-zero records at the same points. For the principal ε=0 route, 18 of 21 points pass the minimal REGISTERED smooth flag; only the three n1 points fail it. No row has a certified continuous smooth or Q_cont gate, because finite path sampling and ordinary Simpson quadrature are not interval enclosures. The reported flags must not be read as full continuum event-membership certificates.

Representative origin results (rounded diagnostics):

| Principal ε=0 input | L* | Registered sup P_1/(λ/2) | Q_cont/(λ/2) | Z_fresh/λ |
|---|---:|---:|---:|---:|
| Pilot n1 | 1.51513 | 1.06303 | 1.12095 | .82268 |
| Pilot n2 | 1.52257 | .42376 | .46868 | .88349 |
| Correlated n2 | 1.70390 | .86348 | .98906 | .72627 |
| Correlated n4,7 boxes | 1.77069 | .21201 | .28092 | .91162 |
| Correlated n4,9 boxes | 1.61380 | .24344 | .31253 | .90261 |
| Correlated n8 | 1.59007 | .01315 | .01889 | .99443 |
| Directional n16 | 1.51961 | .00002503 | .00004085 | .99999 |

The n1 failure is retained even though its fresh signed value is large. The n2/n4 cases pass the minimal flags while failing the stronger Q_cont filter. The new route does not require selecting different fixtures to avoid those failures. Fine positive ε substantially lowers Q_cont compared with the standard setting, but the zero endpoint removes the B_ε contribution entirely. These are comparisons at prescribed points; no dimension-growth order or generalized input extremizer is fitted.

For positive ε the program additionally checks the decomposition Face_ε=αFace_H+Face_remainder, keeping the nonnegative remainder. Its kernel mass is exactly κ[1−(1−ε)^(n−1)]. Each finer setting has rational mass≤1/2. The maximum observed damped decomposition residual was 6.93889e−17. This kernel-mass guard certifies the registered coefficient inequality, whereas the evaluated source-face integrals remain numerical.

## Captured posterior and outside sources

At the SAME hard-contact cube, each original source box is clipped to Q(x,L*). The convolution is split by ORIGINAL SOURCE y into inside and outside parts, with the same original density normalization. The conditional posterior is the normalized captured y measure; it is a mixture of clipped physical boxes, not an atomic replacement. The code saves each source's captured mass and inside endpoint contributions, as well as total, inside and outside P_ε/P_1. Soft values are evaluated at the floating midpoint representation of the exact hard-root bracket and remain diagnostic.

Outside sources are material. At the origin of the n8 case, only about 13.8043% of P_1 at contact comes from captured sources; the rest comes from outside Q. In n16 only about 3.0712% does. No captured-posterior age law is assigned to these outside sources or to noise displacements. The outside signed endpoint need not always be negative: for the fine n16 setting it is about +.00562θ, while for fine n8 it is about −.00214θ. The full sign is retained. These facts prevent treating the entire soft convolution as an expectation under the hard captured posterior.

## Numerical integration, corridors and an explicit quadrature failure

All actual E2 source integrals use the φ tail primitive and Simpson integration of its true mixing parameter t∈[0,1]. Endpoint values are compared at 64 and 128 panels; the maximum absolute difference is 1.75920e−6. The source-box hard overlaps are exact in the hard certificates. The resolvent uses 4/64 versus 8/128 scale/kernel panel refinements per segment, splitting at every physical source-face breakpoint and at the registered 65-point geometric path L=2^(j/64). A fixed face mask within each segment handles one-sided face values. The maximum full resolvent residual is 1.07721e−9; maximum undamped identity residual 9.45106e−10. The maximum sum of integral refinement differences is 3.55874e−6. Neither refinement nor a small residual encloses the true integral error or certifies a threshold sign.

A separate fresh-face calculation uses eight panels per physical segment without the additional geometric path knots. For the n16 origin it overestimates the exact hard fresh contribution by 3.81469e−7, approximately 5% of λ. Its raw signed result is about 1.04999λ, while the primary exact-hard/numerical-E2 result is .99999λ. This exposed pressure failure is preserved in `fresh_signed_with_raw_face_quadrature` and `hard_zero_fresh_quadrature_difference`. It is why the principal hard contribution uses the captured-mass certificate. The discrepancy is quadrature error, not a mathematical counterexample or receiver sampling error. The separate fresh calculation is not enclosed by the full-path resolvent refinement; positive-ε fresh scores likewise remain diagnostic.

There are 54 supplementary positive last-half corridors. Each uses the last registered U=θ/2 bracket before the SAME hard L*, followed by numerical bisection. Their endpoint U(L*) may exceed θ, and interior U is allowed to exceed θ. They are not private soft first-hit corridors. Their identity accounts use

    U(L*)−U(rho)+κ∫U+κ∫P_1=∫Face_ε+∫v,
    load=κlog(L*/rho)+(2κ/θ)∫P_1.

The maximum saved corridor identity residual is 1.89284e−10. For the origin n8 hard-zero record its length is about .0250682 and load .205809; for n16 its length is about .00286995 and load .0459214. These are short, low-load examples of actual common-hard endpoint geometry. Last-half root selection and continuous gates remain uncertified, and the large fresh signed value is automatic under the minimal hypotheses. Neither these point records nor their small loads prove a weak-volume payment.

There are 92,166 counted primary flux quadrature nodes across the 63 records. This count covers coarse/fine resolvent, full-window primitive, old and fresh integrations; it excludes kernel-profile evaluations, root searches and supplementary corridor integration nodes. No source or receiver Monte Carlo uncertainty is hidden in this deterministic count.

## Replay and frozen artifacts

From the extracted artifact directory run `python3 -B endpoint_probe.py`. It uses only the standard library and writes `endpoint_results.json` beside its source. The program embeds its hard geometry and actual E2 primitives, and does not import the old R80 files. Runtime is printed, not stored in JSON. The final seed-metadata correction uses the actual correlated-source RNG base 800611 and changes no physical source or numerical field.

The frozen production run used bundled Python 3.12.14, exited successfully, and took 11.806450958 seconds.

* `endpoint_probe.py`: SHA-256 `655673fc19eaa8dd18c97b5c22814a3b3f67b007e528d8fe51ffdaf17222b1a8`.
* `endpoint_results.json`: SHA-256 `84907a15a1bf401fe1dbeb824c1e3c9fae5a3e2fff2265d64934c6c02f3d6663`.

Independent audit receipt: 21 global hard contacts, 411 complete interval polynomials checked at 2,854 direct rational overlap points, 169 independent prefix-Sturm checks, all 126 age bounds, 63 same-contact endpoint records, and the 21 new hard-zero exact fresh/old brackets passed. An alternative Laplace-CDF calculation reconstructed the saved E2 endpoints with maximum difference 1.776e−15; this is a floating diagnostic agreement, not a φ interval certificate. A standalone temporary-copy replay completed in 12.3414605 seconds with exit 0, empty stderr and byte-identical JSON. The audit reviewed the raw n16 quadrature failure, continuum-gate limitations and captured/outside-source distinction without finding a remaining implementation issue.

The exact part certifies registered first-contact geometry, captured age comparisons, hard-zero fresh/old brackets and finite coefficient masses. Actual E2 integrals, smooth/primitive gates, signed fresh E2 values and last-half corridors remain numerical diagnostics. Fixed receiver points supply no event volume, and the centered-cube goal remains unproved.


# R81 complete-cell packet-duty LP

The guard gives rational feasible primal and dual bounds for 44 finite-model LPs from 11 physical-source fixtures. It constructs all 2,992 bounded rectangular face cells in the original receiver coordinates. Packet optimization repairs the failed atomwise shutdown example, but whole-input packets and fixed partitions can both cost more than optimized singletons. These results test the R80 adjacent signed-layer mechanism; they do not certify the new merged-endpoint event selected at a common hard first hit.

## Model and exact spatial accounting

The physical source is a positive atomic measure mu=sum_i p_i delta_y_i on distinct sites, with total mass one. It is not an L1 box-density fixture. Each coordinate soft-noise law has shifts (-1,0,1) and probabilities (1/4,1/2,1/4). The hard zero-shift and soft zero-shift labels remain distinct in every Bernoulli endpoint expansion. The endpoint probability sums are checked exactly.

With h=1_{[-1/2,1/2]} and g=h*nu, use psi_a=(1-a)h+ag and the actual finite-law signed kernel D_delta=psi_(delta/2)^tensor n-psi_delta^tensor n. Delta=1/n here. At physical scale L each tensor kernel has factor L^(-n). F is the average of the same two nonnegative endpoints. T and F are convolved with the same original source measure. This finite probability law is an algebra model: no approximation error or quantitative transfer to the continuous E2 noise is supplied.

The original selector maximizes the signed T over the fixed physical scale family, with the smallest scale index resolving ties. The frozen event is T_winner>tau and F_winner<=B. No duty optimization changes the winner or event. An active gate fixture with B=1/2 has original positive-event volume 5/4, excludes volume 3/4 and retains volume 1/2. Other fixtures use B=1.

All faces y_ij+L(z+-1/2), for every source, scale and noise shift, enter the full coordinate arrangement. The complement of its bounded outer rectangle has all kernel fields zero. Boundaries have zero Lebesgue measure. Values at rational cell midpoints are exact because the fields are constant on each cell; this is a complete arrangement, not a sampled receiver grid. Identical full source-field patterns are aggregated with exactly summed cell volumes. Signed kernel integrals are zero, and each weighted source F integral is p_i, checked separately at every scale.

## Paid packet primal and weak dual

For a fixed nonempty physical subset P, define G_Pk(x)=sum_{i in P}p_i D_k(x-y_i). Its true spatial location is retained. Variables q_Pk and theta_P satisfy

    0<=q_Pk<=theta_P, theta_P>=0,
    sum_{P containing i}theta_P<=1 for each original physical source i.

On every retained original-winner cell, sum_P q_P,k(r)G_P,k(r)>=tau. The price is the exact integral of max(0,max_k q_Pk G_Pk). An epigraph on the complete arrangement represents this price. There are no representative columns. The saved source duty profiles are q, and theta is normalized to max_k q_Pk to remove unused capacity.

For q>=0, a negative coordinate in an epigraph field vector never contributes to its positive maximum. The guard therefore clamps those coordinates to zero and aggregates identical positive vectors. It retains the original signed receiver rows. The dual has y_r,beta_Pak,gamma_Pk,kappa_i>=0 and

    sum_k beta_Pak<=v_a,
    sum_{r:k(r)=k} y_r G_Prk <= sum_a beta_Pak G_Pak + gamma_Pk,
    sum_k gamma_Pk <= sum_{i in P} kappa_i.

Its objective is tau sum_r y_r-sum_i kappa_i. Reduced beta lifts to the original signed arrangement by distributing it among its cells proportionally to their volumes and assigning zero to negative coordinates. Thus direct finite weak duality gives lower<=LP optimum<=upper. Singleton prices are also independently checked against their translated nested-cube annuli, confirming that p_i is included once in G and not counted again in the spatial price.

A standard-library floating simplex proposes candidates only. The guard rounds them to rational numbers, scales any excessive source or beta capacities, blends a deficient primal toward a feasible full disjoint partition, recomputes every exact epigraph, and enlarges dual capacity prices to cover every residual. It then checks all row, epigraph, budget and capacity inequalities using Fraction arithmetic. Every fixture has rigorous rational lower and upper bounds. The largest absolute gap is 39039/40960000000000, approximately 9.53101e-10; twelve certificates have zero gap. Full witnesses and residuals are saved in packet_results.json. Solver floating residuals are diagnostics and are not the certificates.

## Three stages and observed costs

Stage one refines distinct nearby one-dimensional sources through N=2,3,5,16, with three scales 1,3/2,2. Stage two includes separated sites, a pair exactly one noise displacement apart, two-dimensional diagonal correlation and deep separated sources. Stage three changes the scale family to four scales, activates the low-background gate and extends dimension to n=3 with two scales. Source count, dimension and scale count stay explicit.

The following costs are rounded displays of the saved rational upper bounds, with lower bounds within the gap reported above. They are certificate prices, rather than event-volume estimates.

| Fixture | N | n | Singleton | Fixed adjacent partition | Whole input packet | Capacity packet family |
|---|---:|---:|---:|---:|---:|---:|
| Distinct cluster | 2 | 1 | 0.187500 | 0.183594 | 0.183594 | 0.183594 |
| Distinct cluster | 3 | 1 | 0.187500 | 0.185185 | 0.182292 | 0.182292 |
| Distinct cluster | 5 | 1 | 0.206250 | 0.214618 | 0.230714 | 0.202760 |
| Distinct cluster | 16 | 1 | 0.203125 | 0.202515 | 0.242158 | 0.202515 |
| Separated sites | 4 | 1 | 0.203125 | 0.200000 | 0.128125 | 0.128125 |
| Noise-spacing pair | 2 | 1 | 0.203125 | 0.128906 | 0.128906 | 0.128906 |
| Correlated diagonal | 3 | 2 | 0.189307 | 0.187539 | 0.177019 | 0.174144 |
| Deep sources | 4 | 2 | 0.163452 | 0.163904 | 0.148818 | 0.148818 |
| Four-scale family | 3 | 1 | 0.208333 | 0.202083 | 0.192708 | 0.192708 |
| Active low-F gate | 3 | 1 | 0.187500 | 0.180556 | 0.171875 | 0.171875 |
| Dimension extension | 3 | 3 | 0.125000 | 0.123135 | 0.121271 | 0.121271 |

For N<=3 the capacity family contains every nonempty source subset. For N>3 it contains all singletons, the whole input and adjacent pairs. It is a specified finite library, so its enclosed optimum is not an optimization over all possible packets at those larger N. The fixed partition need not contain the singleton feasible choices and can therefore cost more.

Across these LPs the certified upper price divided by tau|E| ranges from approximately 1.021739 to 3.000000. The price-minus-tau|E| and the ratio are stored separately from the primal-dual certificate gap for every variant. No comparison is normalized by source probability in place of receiver volume.

The N=16 cluster has sites (2i-15)/256, i=0,...,15, masses 1/16 and tau=1/8. Atomwise shutdown uses a cutoff L^n<p_i/tau; it sets every duty to zero at every allowed scale. It consequently fails on the entire original selected-low event, whose exact volume is 181/128. The LP duties cover that entire event. They select only some physical sources and use primarily the first two scales, rather than shutting down every refined atom. The whole packet also covers it, but its certified optimal price is strictly larger than the singleton price. The finite refinement test does not establish a source-count independent construction.

For the pair y=0,1 with masses 1/2 and tau=1/32, spatial positive centers overlap negative halos of the other source. The exact singleton optimum is 13/64; the exact whole-packet optimum is 33/256, with theta=3/4 and q=(1/2,3/4,1/4). The original event has volume 5/2, so tau|E|=5/64 and the whole-packet price is 33/20 times this quantity. Atomwise shutdown fails on volume 3/2. This is genuine physical-site cancellation within the finite law; translating both sites back to zero would give the wrong price.

## Replay and limits

Run python3 packet_probe.py. The script uses only the Python standard library and writes packet_results.json beside itself. On the present machine the complete replay takes about one second, with all rational checks passing. Sources, scales, thresholds, labels, axes, field patterns, packet libraries, duties and dual witnesses are saved, so no hidden random seed or representative-selection step is needed.

The results establish finite-model feasible prices and bounds for the complete original dx events. They do not establish continuous-E2 estimates, a general cheap packet construction, a uniform source-count or scale-count bound, an n-order law or the parent merged-endpoint short-event claim. Whole-packet success in some examples and its failure to improve others are both retained as evidence about the mechanism.


# R81 independent proof and certificate audit

**Final status: the stated interfaces and frozen finite certificates pass this audit; the general square-root upper bound remains UNPROVED.** The new task is a uniform receiver-volume budget for the actual retained hard-first-hit event. Neither a large recent surplus, a source-envelope price nor the displayed finite LP optima supplies that budget.

This audit owns only `audit.md` and `audit_guard.py`. It does not modify the proof or numerical authors' files, operate Git, or compile a PDF. Updated A02/L03/M04 scope checks are used for domination direction, rational weak duality and actual measurable selection. A skill name supplies no missing theorem. The checks below retain original Lebesgue receiver coordinates and common physical inputs.

## 1. General mathematical interfaces

The merged endpoint identity is correct: for epsilon in [0,1), alpha=(1-epsilon)^n and kappa=n(1-epsilon), U=P_epsilon-P_1 satisfies

    U'=Face_epsilon+v-kappa U-kappa P_1,
    v=f*(B_epsilon-B_1).

Face_1 vanishes. The same actual hard contact is used for every term. Integrating the signed v against the damping kernel costs at most twice its primitive supremum, by integration by parts. Positivity bounds the adaptive old face by the unweighted full-window face integral; subtracting its signed contribution in the proof uses the correct upper direction. The optional positive remainder has mass kappa-alpha n<=n(n-1)epsilon, hence at most 1/2 in the finer setting. These statements need a fixed physical window and an actual common selector; they do not apply after private receiver rescaling.

The direct epsilon=0 route is valid without Fisher information for the hard indicator. B_0 is zero. Convolution of the hard face and drift with an L1 density gives an L1 space-time derivative on every compact scale window, and Fubini gives an absolutely continuous time representative for almost every receiver. Thus A'=Face_H*f-nA holds at this endpoint too.

The parent's minimal payment is a further valid simplification. Pay A_0>=lambda/2 and sup P_1>lambda/2. At the remaining first window contact tau, put ell=min(log8/n,tau), t0=tau-ell and q=exp(-n ell). The exact signed recent quantity is

    Z=lambda-q A_t0-n integral_t0^tau exp[-n(tau-r)]P_1(r)dr
      >=lambda/2+q(lambda/2-A_t0).

For tau>=log8/n it is at least 7lambda/16; for tau<log8/n the paid anchor gives at least lambda/2. The paid coefficient is exactly 4+2(log2)sqrt(7n/3). No primitive or positive-softness exception is needed for this particular interface. **The surplus threshold is automatic on the retained event and does not make that event rare.** The stronger optional soft interface and its paid coefficient remain valid.

The integrated hard-face resolvent has density rho^{-(n-kappa)} on exp(-h)<rho<1, rho=2||z||_infinity. Its mass is n(1-exp(-kappa h))/kappa. Its continuous [1,2] strong envelope is that mass plus n log2. The finite common-duty radial-cell formula uses the factor n(b^kappa-a^kappa)/kappa and is normalized correctly. Shell endpoint surfaces and tied maximum coordinates are null for L1 integration. The continuous envelope is an a.e. supremum formula for h>0; taking h to zero before an uncountable supremum is not justified. In particular h=log8/n still costs 7/8+n log2 under this unrestricted strong payment.

## 2. Selection, source ownership and geometric obstructions

The hardface regular-class argument is legitimate for smooth compactly supported input and almost every level: one-dimensional critical values are null, the joint critical-value set is Borel under compact exhaustion, and a first noncritical contact has a locally common C1 branch. Uniform general-input weak bounds can be transferred from that class through positive L1 approximation, admissible levels and strict-margin/Fatou arguments.

The source coarea formula retains the absolute Jacobian 1/|1-z dot grad r| and all **noncritical** preimages. Critical receiver-source pairs have zero mass after integration against an L1 source, because for fixed receiver they lie on a source hyperplane. This is not a pointwise-in-source assertion and does not extend to source atoms. The corrected explicit noncritical-sum convention avoids division by zero. The fixed-window bridge uses ages only when the earlier comparison radius remains in the window. Its integrated tail statement is restricted accordingly.

The global Lipschitz contraction payment R^n/(1-qR) is correct on its stated capture/contact set, using injection and the Lipschitz area formula on positive-g patches. Its dense-cube obstruction concerns that particular global-hard covering mechanism after the density exception. It is not asserted to survive the parent's minimal smooth/anchor deletions. The actual one-dimensional multi-interval construction excludes uniform per-source multiplicity bounds, while its growing total mass prevents a weak-bound contradiction.

The common physical packet inequality is valid under actual ownership sum nu_P<=mu and receiver-independent duties. Signed source cancellation is retained in both rows and spatial prices. The new continuous-E2 controller construction has mass W<2, unique original registered winners, a truly continuous F<67tau gate, and one-packet price at least floor(n/6)/5000. The tail, eroded-cube shell and duty-forcing constants check out. At powers of two its critical softness is a retained dyadic layer. This rules out the stated cheap one-packet mechanism; it does not rule out multiple packets or establish membership in the remaining merged-endpoint event.

Soft convolution at a hard contact includes original physical sources outside the hard captured cube. The hard posterior age law cannot be assigned to those sources or to a shifted-noise posterior. The numerical split keeps these contributions and their signs; no conditional angular independence is assumed.

## 3. Verified local-to-global transfer

I independently read the explicit weak endpoint equation (11), printed pages 5–6, in the [Naor–Tao author PDF](https://web.math.princeton.edu/~naor/homepage%20files/HLM.pdf). Its subdivision formula matches the localization component. For Lebesgue cubes, d=max(n,2), K=6 and m=ceil(log2 d) satisfy the hypotheses. Exact physical dilation and the ratio-two subdivision give an absolute O(log(n+2)) transfer from a uniform general-input [1,2] weak constant. No additional n or 2^n factor enters. The source's universal implicit constant is not evaluated numerically. The local retained-event budget is still an open hypothesis; localization does not prove it.

## 4. Independent finite computations

The independent guard imports neither main script. It reconstructs the finite labelled probability law directly from its three shifts and weights, rather than reusing the production compressed-state formula. It independently rebuilds every original source/scale coordinate face, exact cell volume, signed winner, selected F gate and packet spatial price. It then verifies both rational sides of weak duality.

| Check | Actual count / result | Scope |
|---|---|---|
| Original dx arrangement | 2,992 full cells | Exact finite probability-noise model |
| Packet price reconstruction | 889 positive field patterns | Signed physical source positions retained |
| Rational LP witnesses | 44 brackets; 1,778 row/dual/budget checks | Exact primal feasibility and dual upper control of constraints |
| Maximum LP gap | 39039/40960000000000 | Twelve production brackets have zero gap |
| Endpoint geometry | 21 strict upward global first hits | Positive L1 box inputs at fixed rational receivers |
| Full hard interval fields | 411 polynomials; 2,854 direct overlap identities | Complete physical arrangement, including decreasing terminal tail |
| Earlier root exclusions | 169 independently recomputed prefix Sturm checks | One-sided signs computed by binomial/Taylor coefficients |
| Hard captured-age comparisons | 126 exact rational bounds | Captured original source posterior only |
| New epsilon-zero recent terms | 21 exact fresh/old capture brackets | Same certified hard root and exact nth-root bounds |
| Endpoint accounting | 63 same-contact records | Positive epsilon comparisons plus principal zero endpoint |
| Alternate actual E2 CDF | Maximum endpoint difference 1.77636e-15 | Floating diagnostic at the same quadrature resolution |
| Independent new algebra | 160 rational budget checks; 4 primitive checks | Conditional fixed-window identities |
| Finite shell envelopes | 36 exact checks | Strong source prices, not weak receiver-volume bounds |

The packet fixtures use positive atomic physical sources and an actual finite labelled noise law. They test the R80 adjacent contrast, not continuous E2 or the new merged common-hard event. Full nonempty packet enumeration is only for N<=3; larger libraries contain singletons, whole input and adjacent pairs. Clamping negative price coordinates is valid for q>=0 and does not clamp the original signed event rows. The reduced beta witnesses lift to the signed arrangement by allocating volume-proportionally and discarding beta on nonpositive coordinates. Floating simplex output proposes witnesses only; the independently verified Fraction brackets establish their claimed finite scope.

The endpoint exact part certifies hard geometry and recent captured mass. Its E2 integrals, continuous smooth/primitive gates and supplementary last-half root selection are uncertified quadrature diagnostics. Eighteen registered minimal-gate passes are not eighteen continuous event-membership certificates. Fixed receiver points supply no event volume or standard error. The n16 raw fresh-face quadrature overcount of about 5% of lambda is retained; the primary zero endpoint instead uses an exact hard-capture interval midpoint minus a numerical E2 occupation, which is still a mixed, uncertified signed value. This limitation is stated in the numerical report.

## 5. Actual replay receipts and frozen requirements

Independent standalone temporary-directory replays, using only each copied main source, exited 0 with empty stderr and produced byte-identical frozen JSON: packet 0.502424 seconds and endpoint 12.341460 seconds. The final source/result hashes are:

| File | SHA-256 |
|---|---|
| packet_probe.py | b3a3c6deddf9e3dbd697643edf9677f1bce56baccfe66e9cf966bd126778dd44 |
| packet_results.json | 9fc5717c52a26043a8e6bad85c7d008725cc6bf866550e5221b4bc8147019c5f |
| endpoint_probe.py | 655673fc19eaa8dd18c97b5c22814a3b3f67b007e528d8fe51ffdaf17222b1a8 |
| endpoint_results.json | 84907a15a1bf401fe1dbeb824c1e3c9fae5a3e2fff2265d64934c6c02f3d6663 |

The final audit guard also reruns all five frozen component guards. Parent: 148 finite checks, including a floating log-upper diagnostic; soft: 243 checks; hardface: 528 exact branch checks plus a diagnostic logarithmic display; coverage: 643 construction/field checks with uncertified E2 quadrature; localization: exact integer/rational subdivision checks. The proofs, not the diagnostics, supply their continuous statements.

The guard verifies these embedded-code hashes:

| Component | SHA-256 |
|---|---|
| parent radial | 380917fc865d58dd1f34231d961824da8e20abd1336aee48d13c4fb6d9567745 |
| soft | 4895847b83a379ae14bc17bba23698659d151ef40eb0a91e59694dd1d3df3dac |
| hardface | 2d6f6161b22d1ee102e86b3ff725c36ab3e1caed7ee169f2e117007927eb4c94 |
| coverage | 310cc1f8e82f0675570bdd733d59e6668ca37e2098ab6354bd3aedd85bb3a611 |
| localization | e9359971510179f76d310e8b84f0d7f53ee882a6e01c4477ad046129e3cb62e1 |

**Portability was actually tested in both directions.** In a temporary directory containing the four frozen main files, the extracted audit guard and only merged `proof.md` with six Python fences, the guard passed in 2.711726 seconds; all five component origins were `proof.md`. No separate component Markdown or Python file was present. In a second run with only the five extracted component guards and no `proof.md`, it passed in 2.709798 seconds. Extracted `*_guard.py` takes priority; separate component Markdown is development fallback only. The audit checks the main file hashes but does not redundantly rerun the expensive numerical programs.

The final guard hash is `cb540343833e15c491c18c88759154c65600815520461f747baaccfb015dcb74`. There is no extra Python fence in this audit narrative; the integration appends the guard once as the sixth fence. No unresolved concrete arithmetic bug remains in the frozen artifacts. The unresolved mathematical requirement is the all-input, all-threshold receiver-volume bound for the retained common-hard event.


## 最终独审守卫 audit_guard.py

```python
#!/usr/bin/env python3
"""R81 independent fixed-window endpoint and complete-cell packet checks.
Finite-law LP certificates are separate from actual E2 diagnostics and the
unproved uniform receiver-volume estimate. No main script is imported.
"""
from fractions import Fraction as Q
from pathlib import Path
from itertools import product
from functools import lru_cache
import math,json,hashlib,re,subprocess,tempfile,sys,time
BASE=Path(__file__).resolve().parent

def new_budget_algebra():
    checks=0
    for n in (1,2,4,8,16,64,256,1024):
        for eps in (Q(0),Q(1,2*n),Q(1,2*n*n)):
            alpha=(1-eps)**n;kappa=n*(1-eps)
            assert alpha>=Q(1,2)
            assert kappa*kappa/Q(n+2)<=n
            remainder=kappa-alpha*n
            assert 0<=remainder<=n*(n-1)*eps
            if eps<=Q(1,2*n*n):assert remainder<=Q(1,2)
            checks+=4
        # At epsilon=0 and the common hard first contact, exact old/fresh
        # identities reduce to ordinary captured-source masses.
        lam=Q(7,5);q=Q(1,8)
        for earlier,anchor in ((lam,Q(0)),(lam/2,lam/4)):
            old=q*earlier-q*anchor
            assert 0<=old<=lam/8
            fresh=lam-q*earlier
            background_upper=lam*(1-q)/2
            assert fresh-background_upper>=7*lam/16
            checks+=3
        # A stronger anchor payment A0<lambda/2 handles tau<h with no
        # continuous-flux exception. This is conditional budget algebra.
        for q,anchor in ((Q(1),lam/4),(Q(3,4),lam/3)):
            assert lam-q*anchor-lam*(1-q)/2>=lam/2
            checks+=1
    # Exact summation by parts for the weighted primitive bound.
    primitive_checks=0
    for m in (1,2,8,32):
        R=[Q(0)]+[Q((j*j)%5-2,2) for j in range(1,m+1)]
        weights=[Q(1,2**(m-j)) for j in range(1,m+1)]
        weighted=sum(s*(R[j]-R[j-1]) for j,s in enumerate(weights,1))
        by_parts=R[-1]-sum((weights[j]-weights[j-1])*R[j] for j in range(1,m))
        assert weighted==by_parts and abs(weighted)<=2*max(map(abs,R))
        primitive_checks+=1
    return {'rational_endpoint_budget_checks':checks,'weighted_primitive_checks':primitive_checks,'scope':'New endpoint residual/positive remainder and scalar first-hit budget identities; analytic fixed-window and common-selector premises remain necessary.'}

def finite_shell_prices():
    cases=0
    for n in (1,2,4,8):
        for K in (2,4,8):
            scales=[Q(1)+Q(j,K-1) for j in range(K)]
            for q in (Q(1,2),Q(3,4),Q(1023,1024)):
                axes=sorted({q*L for L in scales}|set(scales));price=Q(0)
                for a,b in zip(axes,axes[1:]):
                    r=(a+b)/2
                    density=max([Q(0)]+[L**(-n) for L in scales if q*L<r<L])
                    price+=(b**n-a**n)*density
                assert price>=1-q**n
                if q==Q(1023,1024):assert price==K*(1-q**n)
                cases+=1
    return {'exact_finite_shell_envelopes':cases,'scope':'Whole-source kernel envelope, fixed finite physical library. Thin age does not itself bound adaptive receiver occupation; continuous envelope has n log2 term.'}

def h(x):return Q(abs(x)<Q(1,2))
def finite_coordinate(a,x):
    return (1-a)*h(x)+a*(h(x+1)/4+h(x)/2+h(x-1)/4)

def packet_saved():
    data=json.loads((BASE/'packet_results.json').read_text());cell_count=certs=pricepatterns=constraints=0;maxgap=Q(0)
    for fixture in data['fixtures']:
        src=fixture['source'];n,N=src['n'],src['N'];ys=[list(map(Q,y)) for y in src['centers']];ps=list(map(Q,src['weights']));Ls=list(map(Q,src['scales']));K=len(Ls);delta=Q(src['delta']);tau=Q(src['tau']);B=Q(src['background_bound'])
        assert len({tuple(y) for y in ys})==N and all(p>0 for p in ps)
        axes=[sorted({y[j]+L*(z+s) for y in ys for L in Ls for z in (-1,0,1) for s in (Q(-1,2),Q(1,2))}) for j in range(n)]
        assert axes==[list(map(Q,a)) for a in fixture['arrangement']['axes']]
        patterns={};cells=0
        for indices in product(*(range(len(a)-1) for a in axes)):
            x=[(axes[j][i]+axes[j][i+1])/2 for j,i in enumerate(indices)];vol=math.prod(axes[j][i+1]-axes[j][i] for j,i in enumerate(indices));ds=[];fs=[]
            for y,p in zip(ys,ps):
                for L in Ls:
                    u=p*math.prod(finite_coordinate(delta/2,(xx-yy)/L) for xx,yy in zip(x,y))/L**n
                    v=p*math.prod(finite_coordinate(delta,(xx-yy)/L) for xx,yy in zip(x,y))/L**n
                    ds.append(u-v);fs.append((u+v)/2)
            key=tuple(ds+fs)
            if key not in patterns:patterns[key]=[Q(0),0]
            patterns[key][0]+=vol;patterns[key][1]+=1;cells+=1
        saved={tuple(map(Q,r['weighted_signed_source_fields']+r['weighted_source_backgrounds'])):[Q(r['volume']),r['cell_count']] for r in fixture['arrangement']['field_patterns']}
        assert saved==patterns and cells==fixture['arrangement']['cell_count'];cell_count+=cells
        events=[];eventvolume=Q(0)
        for key,(vol,count) in patterns.items():
            ds,fs=key[:N*K],key[N*K:];T=[sum(ds[i*K+k] for i in range(N)) for k in range(K)];F=[sum(fs[i*K+k] for i in range(N)) for k in range(K)];winner=max(range(K),key=lambda k:(T[k],-k))
            if T[winner]>tau and F[winner]<=B:events.append((winner,ds,vol,count));eventvolume+=vol
        assert eventvolume==Q(fixture['arrangement']['event_volume'])
        for i in range(N):
            for k in range(K):
                assert sum(v*key[i*K+k] for key,(v,c) in patterns.items())==0
                assert sum(v*key[N*K+i*K+k] for key,(v,c) in patterns.items())==ps[i]
        for cert in fixture['variants']:
            packets=cert['packets'];G=len(packets);assert all(P and len(set(P))==len(P) for P in packets)
            rebuilt_prices=[];rebuilt_rows={}
            for P in packets:
                priced={}
                for key,(vol,count) in patterns.items():
                    field=tuple(max(Q(0),sum(key[i*K+k] for i in P)) for k in range(K))
                    if any(field):priced[field]=priced.get(field,Q(0))+vol
                rebuilt_prices.append(priced)
            for k,ds,vol,count in events:
                coefficients=tuple(sum(ds[i*K+k] for i in P) for P in packets);key=(k,coefficients)
                if key not in rebuilt_rows:rebuilt_rows[key]=[Q(0),0]
                rebuilt_rows[key][0]+=vol;rebuilt_rows[key][1]+=count
            assert rebuilt_rows=={(r['winner'],tuple(map(Q,r['coefficients']))):[Q(r['volume']),r['cell_count']] for r in cert['event_rows']}
            for g,priced in enumerate(rebuilt_prices):assert priced=={tuple(map(Q,p['field'])):Q(p['volume']) for p in cert['price_patterns'][g]}
            q=[list(map(Q,row)) for row in cert['primal']['q']];theta=list(map(Q,cert['primal']['theta']));epi=[list(map(Q,row)) for row in cert['primal']['epigraph']]
            assert all(0<=v<=theta[g] for g,row in enumerate(q) for v in row)
            assert all(sum(theta[g] for g,P in enumerate(packets) if i in P)<=1 for i in range(N))
            upper=Q(0)
            for g,pats in enumerate(cert['price_patterns']):
                for a,pat in enumerate(pats):
                    field=list(map(Q,pat['field']));assert epi[g][a]==max([Q(0)]+[q[g][k]*field[k] for k in range(K)])
                    upper+=Q(pat['volume'])*epi[g][a];pricepatterns+=1
            for row in cert['event_rows']:
                assert sum(Q(a)*q[g][row['winner']] for g,a in enumerate(row['coefficients']))>=tau;constraints+=1
            dual=cert['dual'];y=list(map(Q,dual['y']));beta=[[list(map(Q,r)) for r in ps] for ps in dual['beta']];gamma=[list(map(Q,r)) for r in dual['gamma']];kappa=list(map(Q,dual['kappa']))
            assert all(v>=0 for v in y+kappa+[v for r in gamma for v in r]+[v for ps in beta for r in ps for v in r])
            for g,pats in enumerate(cert['price_patterns']):
                for a,pat in enumerate(pats):assert sum(beta[g][a])<=Q(pat['volume']);constraints+=1
                for k in range(K):
                    lhs=sum(y[r]*Q(row['coefficients'][g]) for r,row in enumerate(cert['event_rows']) if row['winner']==k)
                    rhs=sum(beta[g][a][k]*Q(pat['field'][k]) for a,pat in enumerate(pats))+gamma[g][k]
                    assert lhs<=rhs;constraints+=1
                assert sum(gamma[g])<=sum(kappa[i] for i in packets[g]);constraints+=1
            lower=tau*sum(y)-sum(kappa)
            assert lower==Q(cert['lower_bound'])<=upper==Q(cert['upper_bound'])
            assert upper>=tau*eventvolume and upper-lower==Q(cert['certificate_gap'])
            maxgap=max(maxgap,upper-lower);certs+=1
    assert cell_count==data['counts']['complete_cells'] and certs==data['counts']['LP_certificates']
    return {'independent_original_dx_cells':cell_count,'rational_packet_LP_brackets':certs,'independent_packet_price_patterns':pricepatterns,'primal_dual_inequalities':constraints,'max_gap':str(maxgap),'scope':'Exact finite labelled-noise/positive atomic-source adjacent-layer LP, original signed winner and selected F gate; no continuous E2 or merged-firsthit existence certificate.'}

def peval(p,x):return sum(c*x**j for j,c in enumerate(p))
def ptrim(p):
    p=list(p)
    while len(p)>1 and not p[-1]:p.pop()
    return p
def prem(p,q):
    p=ptrim(p)
    while len(p)>=len(q) and any(p):
        shift=len(p)-len(q);factor=p[-1]/q[-1]
        for j,c in enumerate(q):p[j+shift]-=factor*c
        p=ptrim(p)
    return p
def pseq(p):
    seq=[ptrim(p)];d=ptrim([j*p[j] for j in range(1,len(p))] or [Q(0)])
    if not any(d):return seq
    seq.append(d)
    while True:
        r=[-c for c in prem(seq[-2],seq[-1])]
        if not any(r):return seq
        seq.append([c/abs(r[-1]) for c in r])
def pside(p,x,side):
    for order in range(len(p)):
        coefficient=sum(p[j]*math.comb(j,order)*x**(j-order) for j in range(order,len(p)))
        if coefficient:return (1 if coefficient>0 else -1)*side**order
    return 0
def pvariation(seq,x,side):
    signs=[pside(p,x,side) for p in seq];signs=[s for s in signs if s]
    return sum(a!=b for a,b in zip(signs,signs[1:]))
def pcount(p,a,b):return pvariation(pseq(p),a,1)-pvariation(pseq(p),b,-1)
def actual_capture(src,x,L):
    e=Q(src['epsilon']);n=src['n']
    return sum(Q(w)*math.prod(max(Q(0),min(xx+L/2,cc+e)-max(xx-L/2,cc-e)) for xx,cc in zip(x,map(Q,y)))/(2*e)**n for y,w in zip(src['centers'],src['weights']))


def endpoint_saved():
    data=json.loads((BASE/'endpoint_results.json').read_text());rows=polys=identities=prefixes=ages=records=zero_certs=0;error=0.
    for stage in data['stages']:
        for case in stage['cases']:
            src=case['source'];n=src['n'];e=Q(src['epsilon']);lam=Q(src['lambda_value'])
            assert sum(map(Q,src['weights']))==Q(src['W'])
            for wrapper in case['receivers']:
                row=wrapper['hard_firsthit_certificate'];x=list(map(Q,row['receiver']));hit=row['first_contact'];lo,hi=map(Q,hit['interval']);assert 1<lo<=hi<=2
                expected=sorted({Q(0)}|{2*abs(xx-cc-s*e) for y in src['centers'] for xx,cc in zip(x,map(Q,y)) for s in (-1,1)})
                assert expected==list(map(Q,row['all_physical_breakpoints']))
                intervals=row['all_physical_interval_polynomials']
                for cell in intervals:
                    a,b=Q(cell['left']),Q(cell['right']);p=list(map(Q,cell['numerator']));diff=list(map(Q,cell['difference_polynomial']))
                    for j in range(1,n+2):
                        L=a+(b-a)*Q(j,n+2)
                        assert peval(p,L)==actual_capture(src,x,L)*(2*e)**n
                        assert peval(diff,L)==peval(p,L)-lam*(2*e)**n*L**n
                        identities+=1
                    polys+=1
                for cert in row['earlier_scale_certificates']:
                    cell=intervals[cert['interval_index']];p=list(map(Q,cell['difference_polynomial']));a,b=Q(cert['left']),Q(cert['right']);seq=pseq(p)
                    assert pvariation(seq,a,1)==cert['variation_left_plus'] and pvariation(seq,b,-1)==cert['variation_right_minus']
                    assert pcount(p,a,b)==cert['open_root_count']
                    assert peval(p,Q(cert['test_point']))==Q(cert['test_difference'])
                    if cert['role']=='earlier_strictly_negative_interval':assert cert['open_root_count']==0 and Q(cert['test_difference'])<0
                    prefixes+=1
                cell=intervals[hit['physical_interval_index']];p=list(map(Q,cell['difference_polynomial']));a=Q(cell['left'])
                if lo==hi:
                    assert actual_capture(src,x,lo)==lam*lo**n
                    if a<lo:assert pcount(p,a,lo)==0
                else:
                    assert pcount(p,lo,hi)==1 and pcount(p,a,lo)==0
                    assert peval(p,lo)<0<peval(p,hi)
                assert hit['contact_classification']=='upward_crossing' and row['strict_event_claimed']
                witness=row['strict_above_lambda_witness'];assert actual_capture(src,x,Q(witness['L']))>lam*Q(witness['L'])**n
                assert row['first_strict_cross_boundary_interval']==hit['interval']
                last=intervals[-1];cut=Q(row['terminal_scale_cutoff'])
                assert actual_capture(src,x,cut)==Q(src['W']) and Q(src['W'])/cut**n<lam
                for cert in row['age_tail_certificates']:
                    t=Q(cert['t_equals_exp_minus_h']);lower=actual_capture(src,x,t*lo)/(lam*hi**n);upper=actual_capture(src,x,t*hi)/(lam*lo**n)
                    assert [lower,upper]==list(map(Q,cert['posterior_age_tail_interval']))
                    assert 0<=lower<=upper<=t**n==Q(cert['target_exp_minus_nh']);ages+=1
                for rec in wrapper['endpoint_records']:
                    setting=rec['setting'];eps=Q(setting['epsilon']);alpha=(1-eps)**n
                    assert alpha==Q(setting['alpha']) and Q(setting['kappa'])==n*(1-eps)
                    assert Q(setting['face_remainder_kernel_mass'])==n*(1-eps)-n*alpha
                    assert list(map(Q,rec['hard_tau_exact_interval']))==[lo,hi]
                    L=rec['same_hard_tau'];calculated=alternate_endpoint(src,x,L,[Q(0),eps,Q(1)])
                    error=max(error,max(abs(z-v) for z,v in zip(calculated,rec['endpoint_values'])))
                    split=rec['inside_outside_at_same_tau']
                    assert max(abs(t-i-o) for t,i,o in zip(split['total'],split['inside'],split['outside']))<1e-12
                    assert all(z>=-1e-12 for z in split['outside'])
                    if eps==0:
                        cert=rec['hard_zero_fresh_certificate'];cl,ch=map(Q,cert['eighth_root_interval']);assert cl**n<=Q(1,8)<=ch**n
                        sl,sh=max(Q(1),lo*cl),max(Q(1),hi*ch)
                        assert [sl,sh]==list(map(Q,cert['physical_start_interval']))
                        ca,cb,c1=actual_capture(src,x,sl),actual_capture(src,x,sh),actual_capture(src,x,Q(1))
                        assert [ca,cb]==list(map(Q,cert['capture_start_interval']))
                        fresh=[lam-cb/lo**n,lam-ca/hi**n];old=[max(Q(0),(ca-c1)/hi**n),max(Q(0),(cb-c1)/lo**n)]
                        assert fresh==list(map(Q,cert['pure_hard_fresh_interval'])) and old==list(map(Q,cert['old_face_interval']))
                        assert old[1]<=lam/8 and fresh[0]<=fresh[1]
                        assert rec['minimal_anchor_gate']==(c1<lam/2)
                        assert abs(rec['resolvent']['fresh_pure_hard_exact_midpoint']-float(sum(fresh)/2))<1e-15
                        zero_certs+=1
                    records+=1
                rows+=1
    assert rows==21 and polys==411 and ages==126 and records==63 and zero_certs==21
    assert error<1e-8
    return {'actual_box_receiver_certificates':rows,'complete_interval_polynomials':polys,'direct_overlap_polynomial_identity_points':identities,'independent_prefix_sturm_checks':prefixes,'rational_root_age_bounds':ages,'same_hard_endpoint_records':records,'new_exact_zero_fresh_capture_brackets':zero_certs,'alternate_E2_CDF_max_difference':error,'scope':'Exact global hard geometry/root/capture and new epsilon-zero brackets; true E2 endpoint values independently recomputed by floating CDF quadrature, not outward intervals or continuous gates. Fixed original dx points only.'}

@lru_cache(None)
def alternate_cdf(x):
    # Independent Laplace CDF antiderivative integrated over hard interval.
    M=128;out=0.
    def primitive(v,t):return .5*t*math.exp(v/t) if v<0 else v+.5*t*math.exp(-v/t)
    for j in range(1,M+1):
        t=j/M;v=2*t*(primitive(x+.5,t)-primitive(x-.5,t))
        out+=(1 if j==M else 4 if j%2 else 2)*v
    return out/(3*M)

def alternate_endpoint(src,x,L,params):
    e=float(Q(src['epsilon']));out=[0.]*len(params)
    for y,w in zip(src['centers'],src['weights']):
        pairs=[]
        for xx,yy in zip(x,map(Q,y)):
            d=float(xx-yy);a=max(0.,min(d+e,L/2)-max(d-e,-L/2))/(2*e*L)
            b=(alternate_cdf((d+e)/L)-alternate_cdf((d-e)/L))/(2*e);pairs.append((a,b))
        for j,p in enumerate(params):out[j]+=float(Q(w))*math.prod((1-float(p))*a+float(p)*b for a,b in pairs)
    return out


MAIN_HASHES={
 'packet_probe.py':'b3a3c6deddf9e3dbd697643edf9677f1bce56baccfe66e9cf966bd126778dd44',
 'packet_results.json':'9fc5717c52a26043a8e6bad85c7d008725cc6bf866550e5221b4bc8147019c5f',
 'endpoint_probe.py':'655673fc19eaa8dd18c97b5c22814a3b3f67b007e528d8fe51ffdaf17222b1a8',
 'endpoint_results.json':'84907a15a1bf401fe1dbeb824c1e3c9fae5a3e2fff2265d64934c6c02f3d6663'}
COMPONENT_HASHES={
 'parent_radial':'380917fc865d58dd1f34231d961824da8e20abd1336aee48d13c4fb6d9567745',
 'soft':'4895847b83a379ae14bc17bba23698659d151ef40eb0a91e59694dd1d3df3dac',
 'hardface':'2d6f6161b22d1ee102e86b3ff725c36ab3e1caed7ee169f2e117007927eb4c94',
 'coverage':'310cc1f8e82f0675570bdd733d59e6668ca37e2098ab6354bd3aedd85bb3a611',
 'localization':'e9359971510179f76d310e8b84f0d7f53ee882a6e01c4477ad046129e3cb62e1'}

def frozen_inputs():
    for name,expected in MAIN_HASHES.items():
        assert hashlib.sha256((BASE/name).read_bytes()).hexdigest()==expected,name
    return dict(MAIN_HASHES)

def component_payload(name,expected):
    # Archive path: proof.md alone holds all component guards. Extracted
    # *_guard.py takes priority, while separate MD files are development-only.
    candidates=[BASE/(name+'_guard.py')]
    if name=='parent_radial':candidates.append(BASE/'parent_guard.py')
    for path in candidates:
        if path.is_file():
            raw=path.read_bytes();assert hashlib.sha256(raw).hexdigest()==expected,path.name
            return raw,path.name
    for path in (BASE/(name+'.md'),BASE/'proof.md'):
        if path.is_file():
            fences=re.findall(r'^```python\n(.*?)^```[ \t]*$',path.read_text(),re.M|re.S)
            matched=[code.encode() for code in fences if hashlib.sha256(code.encode()).hexdigest()==expected]
            if matched:
                assert len(matched)==1,(name,'duplicate frozen fence')
                return matched[0],path.name
    raise FileNotFoundError('Need frozen '+name+'_guard.py or its hash-matching Python fence in proof.md')

def component_replays():
    receipts=[]
    for name,expected in COMPONENT_HASHES.items():
        payload,origin=component_payload(name,expected)
        with tempfile.TemporaryDirectory(prefix='r81-component-') as td:
            path=Path(td)/'guard.py';path.write_bytes(payload)
            start=time.perf_counter();run=subprocess.run([sys.executable,'-B',str(path)],cwd=td,capture_output=True,text=True,timeout=60)
            assert run.returncode==0 and not run.stderr,(name,run.returncode,run.stderr,run.stdout)
            receipts.append({'component':name,'sha256':expected,'origin':origin,'exit':0,'empty_stderr':True,'elapsed_seconds':round(time.perf_counter()-start,4)})
    return receipts

def main():
    start=time.perf_counter();hashes=frozen_inputs();out={'status':'PASS','frozen_main_hashes':hashes,'component_replays':component_replays(),'new_endpoint_algebra':new_budget_algebra(),'thin_shell':finite_shell_prices(),'packet_saved':packet_saved(),'endpoint_saved':endpoint_saved()};out['elapsed_seconds']=round(time.perf_counter()-start,4);print(json.dumps(out,sort_keys=True))
if __name__=='__main__':main()
```
