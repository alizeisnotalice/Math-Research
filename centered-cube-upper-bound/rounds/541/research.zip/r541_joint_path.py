import sys,platform,time,json
from pathlib import Path
import numpy as np
import sympy as sp
import flint
from flint import arb,ctx
START=time.monotonic();evaluations=0

def full_union(x,w):
 global evaluations
 evaluations+=1;x=np.asarray(x,float);w=np.asarray(w,float);rect=[]
 for mask in range(1,1<<len(w)):
  ids=[i for i in range(len(w)) if mask>>i&1];half=np.sqrt(sum(w[i] for i in ids))/2
  lo=np.max(x[ids],axis=0)-half;hi=np.min(x[ids],axis=0)+half
  if np.all(hi>lo):rect.append((lo,hi))
 edges=np.unique([p[j][0] for p in rect for j in (0,1)]);ans=0.
 for a,b in zip(edges[:-1],edges[1:]):
  mid=(a+b)/2;ys=sorted((lo[1],hi[1]) for lo,hi in rect if lo[0]<mid<hi[0])
  if not ys:continue
  lo,hi=ys[0];length=0.
  for c,d in ys[1:]:
   if c>hi:length+=hi-lo;lo,hi=c,d
   else:hi=max(hi,d)
  ans+=(b-a)*(length+hi-lo)
 return float(ans)

def probe_joint_path(x,m,v,eta,acceleration_x=None,acceleration_m=None,steps=(1e-2,1e-3,1e-4,1e-5)):
 # Arbitrary N: actually evaluate the whole deformed configuration at every step.
 x=np.asarray(x,float);m=np.asarray(m,float);v=np.asarray(v,float);eta=np.asarray(eta,float)
 ax=np.zeros_like(x) if acceleration_x is None else np.asarray(acceleration_x,float);am=np.zeros_like(m) if acceleration_m is None else np.asarray(acceleration_m,float)
 assert abs(eta.sum())<1e-12 and abs(am.sum())<1e-12
 u0=full_union(x,m);rows=[]
 for t in steps:
  wt=m+t*eta+t*t*am/2
  if np.min(wt)<=0:continue
  xt=x+t*v+t*t*ax/2;ut=full_union(xt,wt)
  rows.append(dict(t=t,U=ut,first_quotient=(ut-u0)/t,unsubtracted_second_quotient=2*(ut-u0)/t**2))
 return dict(U0=u0,rows=rows,scope='Only finite quotients, no inferred derivative or second-order certificate.')
q=sp.symbols('q',nonnegative=True);a=sp.sqrt(sp.Rational(1,2)+q);c=sp.sqrt(sp.Rational(1,2)-q);b=(1+c)/2
U=sp.simplify(2-b-a*(a-c)/2);U0=sp.simplify(U.subs(q,0));L=sp.simplify(sp.diff(U,q).subs(q,0));H=sp.simplify(sp.diff(U,q,2).subs(q,0));b0=float((1+sp.sqrt(sp.Rational(1,2)))/2)
# Both contacts require a=c; optimal b among collinear positions is the smaller contact.
stages={'near_half':[.5+s*10.**(-k) for k in (2,4,6) for s in (-1,1)],'simplex_boundary_pressure':[1e-6,1e-4,.001,.999,.9999,.999999],'expanded_mass_range':[.05,.15,.25,.35,.45,.55,.65,.75,.85,.95]}
results=[]
for stage,ms in stages.items():
 for mass in ms:
  aa=np.sqrt(max(mass,1-mass));cc=np.sqrt(min(mass,1-mass));bb=(1+cc)/2
  actual=full_union([[0,0],[bb,0]],[mass,1-mass]);fixed=full_union([[0,0],[b0,0]],[mass,1-mass]);opposite=full_union([[0,0],[(1+aa)/2,0]],[mass,1-mass]);exact=float(U.subs(q,abs(sp.Float(mass,40)-sp.Rational(1,2))).evalf(35))
  results.append(dict(stage=stage,m=mass,b_contact=bb,U_full_union=actual,U_contact_formula=exact,formula_abs_error=abs(actual-exact),U_fixed_position=fixed,U_other_contact=opposite,one_sided_mass_quotient=(actual-float(U0))/abs(mass-.5)))
# Genuine nonzero mass velocity, contact-corrected via an exact nonlinear path.
contact_rows=[]
for t in (1e-2,1e-3,1e-4,1e-5,1e-6):
 mass=.5+t;bb=(1+np.sqrt(1-mass))/2;ut=full_union([[0,0],[bb,0]],[mass,1-mass]);contact_rows.append(dict(t=t,U=ut,first_quotient=(ut-float(U0))/t,unsubtracted_second_quotient=2*(ut-float(U0))/t**2,second_quotient_after_true_linear_subtraction=2*(ut-float(U0)-float(L)*t)/t**2))
# Zero velocity reparameterization illustrates why a t^2 path does not create a nonzero critical direction.
t=sp.symbols('t',real=True);zero_velocity_series=sp.series(U.subs(q,t*t),t,0,5)
ctx.prec=192
arb_rows=[]
for stage,qstrings in [('near_half',['1/100','1/10000','1/1000000']),('simplex_boundary_pressure',['499999/1000000','4999/10000','499/1000']),('expanded_mass_range',['1/20','3/20','1/4','7/20','9/20'])]:
 for qs in qstrings:
  qr=sp.Rational(qs);qa=arb(int(qr.p))/arb(int(qr.q));ua=arb(5)/4-qa/2+(1-4*qa*qa).sqrt()/4-(2-4*qa).sqrt()/4;u0a=arb(3)/2-arb(2).sqrt()/4;da=(ua-u0a)/qa
  arb_rows.append(dict(stage=stage,q_rational=qs,U_interval_arb192=str(ua),one_sided_slope_interval_arb192=str(da),strict_negative_slope=bool(da<0)))
direction_rows=[];rf=np.sqrt(.5)
for eta,beta,gamma in [(1,-1,0),(1,0,0),(1,1,0),(0,-1,0),(0,1,0),(0,0,1)]:
 predicted=-beta-(1-b0)*abs(gamma)-rf*(max(eta/(4*rf)-beta,0)+max(-eta/(4*rf)-beta,0))
 vals=[]
 for hh in (1e-4,1e-6):
  actual=(full_union([[0,0],[b0+hh*beta,hh*gamma]],[.5+hh*eta,.5-hh*eta])-float(U0))/hh
  vals.append(dict(t=hh,actual_slope=actual,prediction_error=actual-predicted))
 direction_rows.append(dict(eta=eta,beta=beta,gamma=gamma,predicted_directional_slope=predicted,rows=vals))
out=dict(command=sys.executable+' '+str(Path(__file__).resolve()),versions=dict(python=platform.python_version(),numpy=np.__version__,sympy=sp.__version__,python_flint=flint.__version__),seed=None,scope='Exact collinear two-source contact-path calibration plus executable arbitrary-N complete-union path evaluator. No all-N or all-dimensional bound, and no joint global-optimality claim.',mass_domain='0<m<1, old total mass held exactly 1',symbolic=dict(q='abs(m-1/2)',larger_root=str(a),smaller_root=str(c),contact_path_b=str(b),U=str(U),U0=str(U0),one_sided_first_derivative=str(L),one_sided_second_derivative=str(H),actual_directional_formula='-beta-(1-b0)*abs(gamma)-r*(max(eta/(4*r)-beta,0)+max(-eta/(4*r)-beta,0)), r=1/sqrt(2)',max_over_beta='(sqrt(2)/4-1/2)*abs(eta)-(1-b0)*abs(gamma)',anchored_first_order_critical_cone='Only zero velocity in this two-source calibration',series=str(sp.series(U,q,0,4)),zero_velocity_reparameterized_series=str(zero_velocity_series),two_contacts_compatibility='b=(1+sqrt(m))/2=(1+sqrt(1-m))/2 iff m=1/2'),arb_precision_bits=192,arb_exact_rational_contact_calibration=arb_rows,complete_union_directional_checks=direction_rows,stages=stages,calibration_rows=results,nonzero_velocity_contact_path=contact_rows,arbitrary_N_example=probe_joint_path([[0,0],[b0,0]],[.5,.5],[[0,0],[-1/(2*np.sqrt(2)),0]],[1,-1]),evaluation_count=evaluations,elapsed_seconds=time.monotonic()-START)
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2));print(json.dumps(out['symbolic'],indent=2));print('max area error',max(r['formula_abs_error'] for r in results))
