import sys,platform,time,json
from pathlib import Path
import numpy as np
START=time.monotonic();B=(1+np.sqrt(.5))/2;XOLD=np.array([[0.,0.],[B,0.]]);WOLD=np.array([.5,.5]);DELTAS=[1e-3,1e-5,1e-7];EVALS=0

def rectangles(x,w):
 out=[]
 for mask in range(1,1<<len(w)):
  ids=[i for i in range(len(w)) if (mask>>i)&1];half=np.sqrt(sum(w[i] for i in ids))/2
  lo=np.max(x[ids],axis=0)-half;hi=np.min(x[ids],axis=0)+half
  if np.all(hi>lo):out.append((lo,hi,mask))
 return out

def union(rect):
 global EVALS
 EVALS+=1
 if not rect:return 0.
 edges=np.unique([p[j][0] for p in rect for j in (0,1)]);ans=0.
 for a,b in zip(edges[:-1],edges[1:]):
  mid=(a+b)/2;iv=sorted((lo[1],hi[1]) for lo,hi,_ in rect if lo[0]<mid<hi[0])
  if not iv:continue
  low,high=iv[0];length=0.
  for c,d in iv[1:]:
   if c>high:length+=high-low;low,high=c,d
   else:high=max(high,d)
  ans+=(b-a)*(length+high-low)
 return float(ans)

def grid_union(rect):
 ex=np.unique([p[j][0] for p in rect for j in (0,1)]);ey=np.unique([p[j][1] for p in rect for j in (0,1)]);cx=(ex[:-1]+ex[1:])/2;cy=(ey[:-1]+ey[1:])/2;ok=np.zeros((len(cx),len(cy)),bool)
 for lo,hi,_ in rect:ok|=((cx[:,None]>lo[0])&(cx[:,None]<hi[0])&(cy[None,:]>lo[1])&(cy[None,:]<hi[1]))
 return float(np.sum(ok*np.diff(ex)[:,None]*np.diff(ey)[None,:]))
OLD=rectangles(XOLD,WOLD);U0=union(OLD);HALF=np.sqrt(.5)/2
features={
 'old_source_0':(0,0),'old_source_1':(B,0),'old_sources_midpoint':(B/2,0),'far_from_receiving_union':(2,1),
 'left_singleton_pair_vertical_seam_center':(HALF,0),'right_singleton_pair_vertical_seam_center':(.5,0),
 'left_seam_upper_junction':(HALF,HALF),'right_seam_upper_junction':(.5,HALF),
 'pair_upper_boundary_midpoint':(B/2,.5),'singleton_0_upper_boundary_midpoint':(0,HALF),
 'singleton_0_outer_corner':(-HALF,HALF),'pair_upper_left_corner':(HALF,.5),
 'source_cube_boundary_example_0':(.5,.5),'source_cube_boundary_example_1':(B-.5,.5),
 'old_source_0_boundary_at_unit_cube':(0,.5)}
points=[(name,list(v),'feature') for name,v in features.items()]
for i,a in enumerate(np.linspace(-1.2,2.1,23)):
 for j,b in enumerate(np.linspace(-1.,1.,17)):points.append((f'grid_{i}_{j}',[float(a),float(b)],'grid'))
results=[]
for name,z,kind in points:
 rows=[];x=np.r_[XOLD,[z]]
 for delta in DELTAS:
  rect=rectangles(x,np.r_[WOLD,delta]);a=union(rect);single=[p for p in rect if p[2]==4];mixed=[p for p in rect if p[2] in (5,6,7)]
  singles_excess=union(OLD+single)-U0;mixed_excess=union(OLD+mixed)-U0;gain=a-U0
  row=dict(delta=delta,U_delta=a,difference_quotient=gain/delta,normalized_first_order_candidate=gain/delta-U0,actual_normalized_difference_quotient=(a/(1+delta)-U0)/delta,new_singleton_excess_over_delta=singles_excess/delta,mixed_excess_over_delta=mixed_excess/delta,singleton_mixed_overlap_excess_over_delta=(singles_excess+mixed_excess-gain)/delta,positive_new_mixed_masks=[p[2] for p in mixed],overlap_difference_quotient_divided_by_sqrt_delta=(singles_excess+mixed_excess-gain)/(delta*np.sqrt(delta)))
  if kind=='feature':row['independent_grid_absolute_difference']=abs(a-grid_union(rect))
  rows.append(row)
 results.append(dict(name=name,z=z,kind=kind,rows=rows))
assert EVALS<=10000
summaries=[]
for delta in DELTAS:
 rows=[(p,next(r for r in p['rows'] if r['delta']==delta)) for p in results];top=sorted(rows,key=lambda pr:pr[1]['difference_quotient'],reverse=True)[:5]
 summaries.append(dict(delta=delta,top_difference_quotients=[dict(name=p['name'],z=p['z'],D=r['difference_quotient'],normalized_candidate=r['normalized_first_order_candidate']) for p,r in top]))
out=dict(scope='Finite insertion probes for full receiving union, not derivative existence, optimization, or a general bound. Old masses remain 1/2 each; new mass delta makes total 1+delta. D_delta-U0 is the first-order normalized candidate, and exact normalized finite difference also recorded.',command=sys.executable+' '+str(Path(__file__).resolve()),versions=dict(python=platform.python_version(),numpy=np.__version__),seed=None,deterministic_grid=dict(x=[-1.2,2.1,23],y=[-1,1,17]),b=B,old_positions=XOLD.tolist(),old_masses=WOLD.tolist(),U0=U0,U0_formula='2-b',U0_formula_error=U0-(2-B),deltas=DELTAS,point_count=len(points),union_evaluation_count=EVALS,elapsed_seconds=time.monotonic()-START,feature_rows=[p for p in results if p['kind']=='feature'],grid_rows=[p for p in results if p['kind']=='grid'],summaries=summaries,review_checks=['Singleton has side sqrt(delta), area delta, so its uncovered fraction depends on whether z is interior, exterior, edge, or corner of old union.','Mixed boxes for masks 5,6,7 arise from extrema constraints involving the new source; at delta=0 they are subsets of old receiving union, but can activate or meet old boundaries for delta>0.','At old source, adding label combines masses at same location; source count changes and old positive-mass coordinate gradients do not parameterize this boundary insertion.','Difference quotients at seams require exact one-sided contact analysis; floating agreement and finite delta stability are not proof of a general derivative.'])
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2))
print(json.dumps({k:out[k] for k in ['U0','point_count','union_evaluation_count','elapsed_seconds','summaries']},indent=2))
for p in out['feature_rows']:print(p['name'],p['z'],[(r['difference_quotient'],r['new_singleton_excess_over_delta'],r['mixed_excess_over_delta']) for r in p['rows']])
