"""Same exact q, two independent original R814 cross records, all price bins.

A q membership cell has positive mu mass. Inside it every original row's
q-density relative to mu is constant, so both rows use the same physical q.
All record weights, closed-coordinate intersections and proxy membership
checks are exact. The physical-geometry and proxy events are different.
"""

import argparse
from collections import defaultdict
from dataclasses import dataclass
from fractions import Fraction as F
from hashlib import sha256
from itertools import product
import json
from pathlib import Path
from zipfile import ZipFile

from flint import arb, ctx

PIN = '891d8cbcbd35537e6abc18c938e53b1b4f300327357c24c8d14a51a46ad5e190'


@dataclass(frozen=True)
class Parent:
    side: F
    volume: F
    volume_bin: F
    bit: int
    box: tuple


@dataclass(frozen=True)
class Record:
    t: str
    u: str
    g: str
    z: int
    q: int
    mass: F


def compare(new, old):
    return (new > old) - (new < old)


def direction(new_side):
    return {-1: '<', 0: '=', 1: '>'}[new_side]


def signed_gap(first, second):
    return max(max(l1, l2) - min(r1, r2)
               for (l1, r1), (l2, r2) in zip(first.box, second.box))


def event_key(left, right):
    return ('yes' if left else 'no', 'yes' if right else 'no')


def display_events(label, table, mass, full):
    print(label)
    for key, value in sorted(table.items()):
        prob = value / mass
        exact = ('exact', prob) if full else ()
        print(' ', key, 'probability', format(float(prob), '.11g'), *exact)


def geometry(name, stage, full):
    n = stage['dimension']
    parents = {
        p['id']: Parent(2 * F(p['radius']), F(p['m']), F(p['volume_bin']), p['bit'],
                        tuple(tuple(map(F, interval)) for interval in p['box']))
        for p in stage['parents']
    }
    for p in parents.values():
        assert len(p.box) == n and p.side**n == p.volume
        assert all(hi - lo == p.side for lo, hi in p.box)
        assert p.volume_bin <= p.volume < 2 * p.volume_bin
    cells = {c['mask']: F(c['mass']) for c in stage['cells']}
    groups = defaultdict(list)
    mother = F(0)
    min_original_small_ratio = F(1)
    for root in stage['roots_cross']:
        t, u, g = (root[key] for key in ('t', 'u', 'g'))
        min_original_small_ratio = min(min_original_small_ratio,
                                       parents[u].volume / parents[t].volume,
                                       parents[g].volume / parents[t].volume)
        for z, q in product(root['z_masks'], root['q_masks']):
            assert all(mask & parents[label].bit for mask, label in
                       ((z, t), (z, u), (q, t), (q, g)))
            weight = F(root['coefficient']) * cells[z] * cells[q]
            assert weight > 0
            groups[q].append(Record(t, u, g, z, q, weight))
            mother += weight
    assert len(stage['roots_cross']) == 34 and sum(map(len, groups.values())) == 230
    assert mother == F(stage['benchmarks']['cross']['mother'])
    j = arb(n).sqrt() * arb(n + 2).log()**8
    assert -((arb(min_original_small_ratio.numerator) /
              min_original_small_ratio.denominator).log()) < j
    print('FIXTURE', name, 'n', n, 'q_cells', len(groups),
          'cross_roots', 34, 'positive_source_records', 230, 'mother', mother)
    print('HIGH_J empty', 'J=', j.str(14), 'min original scale volume ratio=', min_original_small_ratio)

    grouped = defaultdict(F)
    physical = defaultdict(F)
    proxy = defaultdict(F)
    physical_nesting = defaultdict(F)
    all_nonproxy_flows = defaultdict(F)
    touching = F(0)
    coupled_total = F(0)
    cross_gaps = set()
    witness_disjoint = None
    witness_proxy = None
    disjoint_left_labels = set()
    full_oriented_count = 0
    gaps = {(a, b): signed_gap(pa, pb) for a, pa in parents.items() for b, pb in parents.items()}
    for q, records in groups.items():
        q_mass = sum((record.mass for record in records), F(0))
        for old in records:
            recovered = F(0)
            for new in records:
                assert old.q == new.q == q
                full_oriented_count += 1
                mass = old.mass * new.mass / q_mass
                recovered += mass
                coupled_total += mass
                old_t, new_t = parents[old.t], parents[new.t]
                side_comparison = compare(new_t.side, old_t.side)
                bin_comparison = compare(new_t.volume_bin, old_t.volume_bin)
                assert bin_comparison == 0 or side_comparison == bin_comparison
                gap_forward, gap_reverse = gaps[new.t, old.u], gaps[old.t, new.u]
                cross_gaps.add(gap_forward)
                physical_forward, physical_reverse = gap_forward <= 0, gap_reverse <= 0
                if gap_forward == 0 or gap_reverse == 0:
                    touching += mass
                proxy_forward = bool(old.z & new_t.bit)
                proxy_reverse = bool(new.z & old_t.bit)
                assert not proxy_forward or physical_forward
                assert not proxy_reverse or physical_reverse
                physical_pair = event_key(physical_forward, physical_reverse)
                proxy_pair = event_key(proxy_forward, proxy_reverse)
                witness_labels = (q, old.t, old.u, old.g, old.z, new.t, new.u, new.g, new.z)
                if not physical_forward and (witness_disjoint is None or gap_forward > witness_disjoint[0]):
                    witness_disjoint = (gap_forward, witness_labels, mass)
                if (physical_forward and not proxy_forward and
                        (witness_proxy is None or mass > witness_proxy[2])):
                    witness_proxy = (gap_forward, witness_labels, mass)
                physical[sum((physical_forward, physical_reverse))] += mass
                proxy[sum((proxy_forward, proxy_reverse))] += mass
                physical_nesting[(direction(side_comparison), direction(bin_comparison))] += mass
                grouped[(direction(side_comparison), direction(bin_comparison),
                         *physical_pair, *proxy_pair)] += mass
                if physical_forward and not proxy_forward:
                    all_nonproxy_flows[(direction(side_comparison), direction(bin_comparison))] += mass
                if gaps[old.u, new.u] > 0:
                    disjoint_left_labels.add((old.u, new.u))
            assert recovered == old.mass
    assert coupled_total == sum(grouped.values(), F(0)) == mother
    assert sum(physical.values(), F(0)) == sum(proxy.values(), F(0)) == mother
    assert sum(q.mass for rows in groups.values() for q in rows) == mother
    for (side, price, a, b, c, d), weight in grouped.items():
        reverse = {'<': '>', '=': '=', '>': '<'}
        assert grouped[(reverse[side], reverse[price], b, a, d, c)] == weight

    print('ORDERED conditional product count=', full_oriented_count, 'max attainable signed cross gap=', max(cross_gaps),
          'physical face-touching original probability=', touching / mother)
    display_events('ALL PHYSICAL opposite-direction successes #0,#1,#2',
                   {k: physical[k] for k in range(3)}, mother, full)
    display_events('ALL PROXY opposite-direction successes #0,#1,#2',
                   {k: proxy[k] for k in range(3)}, mother, full)
    display_events('SCALE counts (new side vs old side, new D vs old D)', physical_nesting, mother, full)
    display_events('COMBOS (side, D, physical-forward, physical-reverse, proxy-forward, proxy-reverse)', grouped, mother, full)
    display_events('FORWARD physical intersection with proxy failure (side,D)', all_nonproxy_flows, mother, full)
    for event, witness in (('disjoint', witness_disjoint), ('physical-only', witness_proxy)):
        if witness is not None:
            gap, labels, weight = witness
            normalized = weight / mother
            exact = ('exact', normalized) if full else ()
            print('FORWARD witness', event, 'gap', gap,
                  '(q,t,u,g,z,t_new,u_new,g_new,z_new)', labels,
                  'probability', format(float(normalized), '.11g'), *exact)
    disjoint = [(a, b, str(gap)) for (a, b), gap in gaps.items() if a < b and gap > 0]
    print('FULL TRUE PARENT FAMILY disjoint pairs and gaps=', disjoint,
          'same-q coupled left-parent disjoint labels=', sorted(disjoint_left_labels))
    return physical[2] == mother, bool(disjoint), bool(disjoint_left_labels)


def as_arb(x):
    return arb(x.numerator) / x.denominator


def projection_constant():
    # After squaring, divide by J^2 for J>0. The J=0 case is equality.
    coefficient = F(4 * 32, 2**16)
    assert coefficient == F(1, 512)
    minimum_h_sigma = 4 * coefficient
    assert minimum_h_sigma == F(1, 128)
    for n, j, sigma in product((1, 4, 64, 512, 2**40), (F(0), F(3, 2), F(11)),
                               (F(1, 2), F(3, 4), F(1))):
        h = 1 + F(1, 32 * n)
        b = j**2 / (2**16 * n)
        lhs_squared = 4 * 32 * n * b / (h * sigma)
        assert lhs_squared == coefficient * j**2 / (h * sigma)
        assert lhs_squared <= (j / 16)**2 <= (j / 2)**2
    print('EXACT projection threshold h*sigma >=', minimum_h_sigma,
          'and dimension-free bound J/16 when sigma>=1/2')
    for n in (2**60, 2**80, 2**100, 2**120):
        h = 1 + F(1, 32 * n)
        J = arb(n).sqrt() * arb(n + 2).log()**8
        sigma = (-J / n).exp()
        if sigma >= arb(1) / 2:
            b = J**2 / (2**16 * n)
            assert 2 * (32 * n * b / (as_arb(h) * sigma)).sqrt() < J / 16
        print('ARB replay n=', n, 'sigma=', sigma.str(12))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--archive', type=Path, required=True)
    parser.add_argument('--compact', action='store_true', help='omit lengthy fraction displays')
    args = parser.parse_args()
    assert sha256(args.archive.read_bytes()).hexdigest() == PIN
    ctx.prec = 192
    with ZipFile(args.archive) as archive:
        rebuilt = json.loads(archive.read('comb814-rebuilt.json'))['stages'][0]
        archived = {'__name__': 'archived_comb811'}
        exec(compile(archive.read('comb811.py'), 'comb811.py', 'exec'), archived)
        original = archived['fixture'](*archived['FIXTURES'][-1])
    first = geometry('original', original, not args.compact)
    second = geometry('rebuilt', rebuilt, not args.compact)
    print('COMPARISON all-intersect / any-disjoint-family / shared-q-left-disjoint:', first, second)
    projection_constant()
    print('PASS')


if __name__ == '__main__':
    main()
