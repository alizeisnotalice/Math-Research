"""Exact and outward-rounded certificates for the round 830 geometry constants.

The reference box has side s, with s**n = 2*D; all lengths below are in units
of s. A full ambient L1 ball of radius 2*delta*n therefore has relative volume
A. Its intersection with any support can only have smaller volume.
"""

from fractions import Fraction as F
from math import factorial

from flint import arb, ctx, fmpq

DELTA = F(1, 256)
TARGET = F(15, 32)
UNIFORM_BOUND = F(495, 1792)
POOL_PRICES = (F(3), F(5), F(3, 5))


def as_arb(value):
    value = F(value)
    return arb(fmpq(value.numerator, value.denominator))


def geometry(n):
    h = 1 + F(1, 32 * n)
    affine_dimension = n // 64
    radius_ball = 2 * DELTA * n
    radius_net = DELTA * n
    owner_axis_error = (h - 1) / 2
    assert F(1, 2) + owner_axis_error == h / 2
    assert 2 * n * owner_axis_error == F(1, 32) == 8 * DELTA
    assert 2 * n * owner_axis_error / radius_net == F(8, n)
    # The affine points within one tube radius of the q box have diameter
    # at most (h + 2*delta)*n in the restricted L1 norm. Pack disjoint
    # half-separation balls and compare to a ball about one packed point.
    slice_diameter = h * n + 2 * radius_net
    net_price = 1 + 2 * slice_diameter / radius_net
    assert net_price == 5 + 2 * h / DELTA == 517 + F(16, n)
    assert net_price <= 533
    assert radius_ball == 2 * radius_net == F(n, 128)
    assert (radius_ball <= F(1, 2)) == (n <= 64)
    assert (radius_ball <= 1) == (n <= 128)
    return net_price, affine_dimension


def exact_check(n):
    net_price, affine_dimension = geometry(n)
    k = int((arb(n) / 16).exp().floor().unique_fmpz())
    ball = (4 * DELTA * n) ** n / factorial(n)
    tube = net_price ** affine_dimension * ball
    assert ball == (F(n, 64) ** n) / factorial(n)
    for price in POOL_PRICES:
        assert k**2 * price**n * ball < TARGET**n
        assert k**2 * price**n * tube < TARGET**n
    # Even two terms charged at the largest stated pool price fit.
    assert k**2 * 5**n * (ball + tube) < TARGET**n
    return k, ball, tube


def dimension_free_certificate():
    # e < 11/4: sum terms 0,...,4 exactly, then geometric majorant
    # for 1/5! + 1/6! + ... with ratio at most 1/6.
    e_upper = sum((F(1, factorial(j)) for j in range(5)), F(0))
    e_upper += F(1, factorial(5)) / (1 - F(1, 6))
    assert e_upper < F(11, 4)
    # e**(1/8) <= 1/(1-1/8), and n! >= (n/e)**n
    # by comparison of sum log j with the integral over [1,n].
    assert F(1, 1) / (1 - F(1, 8)) == F(8, 7)
    assert 533 < F(9, 8) ** 64
    assert F(8, 7) * 5 * F(9, 8) * 4 * DELTA * F(11, 4) == UNIFORM_BOUND
    assert UNIFORM_BOUND < TARGET
    assert 2 * UNIFORM_BOUND**2 < TARGET**2
    assert 2 * 5 * 4 * DELTA < TARGET
    print('EXACT analytic envelope per contribution:', UNIFORM_BOUND)
    print('EXACT two-term envelope: n=1 directly; n>=2 by 2*a**2 < target**2')


def large_check(n):
    net_price, affine_dimension = geometry(n)
    log_ball = n * as_arb(4 * DELTA * n).log() - arb(n + 1).lgamma()
    log_net = affine_dimension * as_arb(net_price).log()
    # k**2 <= e**(n/8), so this avoids forming exponentially big integers.
    log_envelope = arb(n) / 8 + n * arb(5).log() + log_ball + log_net
    log_combined_envelope = log_envelope + arb(2).log()
    assert log_envelope / n < as_arb(UNIFORM_BOUND).log()
    assert log_combined_envelope / n < as_arb(TARGET).log()
    print('ARB lower/upper enclosing', n, 'combined nth root',
          (log_combined_envelope / n).exp())


def thickness_checks():
    dimensions = (2, 3, 8, 32, 64, 128, 512, 4096, 2**20)
    for n in dimensions:
        for c in (1, 2):
            # c=1: one combined door per axis; c=2: two separate doors.
            v = F(c, n**2)
            missing_excess = -(1 - as_arb(v)).log()
            assert 0 < missing_excess < as_arb(v / (1 - v))
        # Uniform density n**4 on a concentric subbox attains the
        # leading coefficient four as dimension tends to infinity.
        log_n = arb(n).log()
        example_missing = n * (1 - (-4 * log_n / n).exp())
        assert 0 < example_missing < 4 * log_n
    # For the optional empirical-extrema statement with tau=4 log(n+2)/n^2,
    # 8 log(n+2)/n decreases for n>=128 by differentiation.
    assert 8 * arb(130).log() / 128 < as_arb(F(1, 2))
    print('ARB center-box log correction and sharpness examples:', dimensions)


def main():
    ctx.prec = 192
    for n in range(1, 64):
        exact_check(n)
    print('EXACT small dimensions with Arb-certified floor(k): 1..63')
    boundary = (63, 64, 65, 127, 128, 129, 255, 256, 257, 511, 512, 513)
    for n in boundary:
        exact_check(n)
    print('EXACT first affine-rank and geometric radius boundaries:', boundary)
    print('EXACT q box side h*s and two-end owner-to-center error s/32')
    dimension_free_certificate()
    for n in (64, 128, 512, 4096, 2**16, 2**20, 2**24, 2**30):
        large_check(n)
    thickness_checks()
    print('PASS')


if __name__ == '__main__':
    main()
