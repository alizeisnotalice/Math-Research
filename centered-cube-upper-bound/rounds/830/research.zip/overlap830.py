"""R830. Rational enclosures for local positive-density cube examples.

Run: python3 -B overlap830.py
A displayed [lo, hi] is rounded outwards. All integrations in this
script are over the physical source measure or Lebesgue center volume.
The illustrative middle-parent law is specified below; no archived
R813 histories, selectors, or receiving marginals are simulated.
"""
from dataclasses import dataclass
from fractions import Fraction as F
from itertools import product
from math import prod


D = F(1, 2)
SPLITS = 8
UNIT = 10**12
EPSILON = F(1, 1024)


def cube(center, side):
    return tuple((x - side / 2, x + side / 2) for x in center)


def intersect(*boxes):
    return tuple((max(b[d][0] for b in boxes), min(b[d][1] for b in boxes))
                 for d in range(len(boxes[0])))


def volume(box):
    return prod(max(F(0), hi - lo) for lo, hi in box)


def mu(box, source):
    return sum((rho * volume(intersect(box, support))
                for support, rho in source), F(0))


def enlarged(box, delta):
    return tuple((lo - delta, hi + delta) for lo, hi in box)


def format_interval(lo, hi, places=8):
    if lo == hi and lo.denominator <= 65536:
        return str(lo)
    denom = 10**places
    lower = (lo.numerator * denom) // lo.denominator
    upper = -((-hi.numerator * denom) // hi.denominator)
    def as_decimal(integer):
        return f'{integer // denom}.{integer % denom:0{places}d}'
    return '[' + as_decimal(lower) + ', ' + as_decimal(upper) + ']'


def reduced_ratio(weight, bounds, k):
    lo, hi = bounds
    assert lo > 0
    return (weight / (D * hi**(k - 1)), weight / (D * lo**(k - 1)))


@dataclass(frozen=True)
class Example:
    name: str
    source: tuple
    b: F
    parent_centers: tuple
    z: tuple
    q: tuple
    average_cap: F
    calibrated: bool


def fixture(n, mode):
    if n == 1:
        b = F(3, 4)
        centers = ((F(0),),)
        z, q = (-F(1, 16),), (F(1, 16),)
        adjacent_start, adjacent_width = F(13, 32), F(1, 32)
    elif n == 2:
        b = F(7, 8)
        shift = F(1, 32)
        centers = ((-shift, F(0)), (shift, F(0)), (F(0), shift))
        z, q = (-F(1, 16), -shift), (F(1, 16), shift)
        adjacent_start, adjacent_width = F(31, 64), F(1, 64)
    else:
        raise ValueError(n)
    support = ((F(-2), F(2)),) * n
    baseline = F(64) if mode == 'plateau' else F(1)
    source = [(support, baseline)]
    average_cap = baseline
    if mode in ('near', 'far'):
        start, width = (adjacent_start, adjacent_width) if mode == 'near' else (F(9, 8), F(1, 32))
        mass_per_slice = F(8)
        for axis in range(n):
            for interval in ((start, start + width), (-start - width, -start)):
                slab = list(support)
                slab[axis] = interval
                assert all(volume(intersect(tuple(slab), cube(c, b))) == 0 for c in centers)
                source.append((tuple(slab), mass_per_slice / width))
        # Any centered cube meeting a slab has length at least this
        # distance doubled. Each slab contributes at most mass_per_slice
        # times the (n-1)-dimensional face area of the centered cube.
        min_side_for_slab = 2 * (start - max(abs(x) for c in centers for x in c))
        assert min_side_for_slab > 0
        average_cap += 2 * n * mass_per_slice / min_side_for_slab
    assert average_cap <= 256
    return Example(f'n={n} {mode}', tuple(source), b, centers, z, q, average_cap, mode != 'plateau')


def enclosing_integrals(example, outer, pair_domain, pair_domain_outer):
    # Shifted source endpoints split each center axis into intervals
    # on which each overlap length is affine. The mass is multiaffine
    # within the resulting boxes, so its extrema occur at grid corners.
    w = 1 + F(1, 32 * len(example.z))
    half = w / 2
    cuts = []
    for d, (left, right) in enumerate(outer):
        edges = {left, right, *pair_domain[d], *pair_domain_outer[d]}
        for box, _rho in example.source:
            for x in box[d]:
                for edge in (x - half, x + half):
                    if left < edge < right:
                        edges.add(edge)
        ordered = sorted(edges)
        cuts.append(tuple(p + (q - p) * i / SPLITS
                          for p, q in zip(ordered, ordered[1:])
                          for i in range(SPLITS)) + (right,))
    grid_mass = {a: mu(cube(a, w), example.source) for a in product(*cuts)}
    lo_k = hi_k = lo_row = hi_row = 0
    for cell in product(*(tuple(zip(axis, axis[1:])) for axis in cuts)):
        vals = [grid_mass[a] for a in product(*cell)]
        lo_mass, hi_mass = min(vals), max(vals)
        vol = volume(cell)
        row_lo = UNIT * vol * lo_mass / (D * (D + lo_mass))
        row_hi = UNIT * vol * hi_mass / (D * (D + hi_mass))
        lo_row += row_lo.numerator // row_lo.denominator
        hi_row += -((-row_hi.numerator) // row_hi.denominator)
        if all(l <= a <= b <= r for (a, b), (l, r) in zip(cell, pair_domain_outer)):
            k_hi = UNIT * vol / (D + lo_mass)
            hi_k += -((-k_hi.numerator) // k_hi.denominator)
        if all(l <= a <= b <= r for (a, b), (l, r) in zip(cell, pair_domain)):
            k_lo = UNIT * vol / (D + hi_mass)
            lo_k += k_lo.numerator // k_lo.denominator
    ans = (F(lo_k, UNIT), F(hi_k, UNIT)), (F(lo_row, UNIT), F(hi_row, UNIT))
    row_ceiling = volume(outer) / D
    assert ans[1][1] < row_ceiling
    return ans


def run(example):
    n = len(example.z)
    w = 1 + F(1, 32 * n)
    parents = tuple(cube(c, example.b) for c in example.parent_centers)
    volumes = [volume(parent) for parent in parents]
    masses = [mu(parent, example.source) for parent in parents]
    assert all(D <= m < 2 * D for m in volumes)
    assert (masses == volumes) == example.calibrated
    common = intersect(*parents)
    assert all(l + EPSILON < min(z, q) and max(z, q) < r - EPSILON
               for (l, r), z, q in zip(common, example.z, example.q))
    owners = tuple(cube(c, example.b / (32 * n)) for c in example.parent_centers)
    assert all(volume(intersect(u, v)) == 0
               for i, u in enumerate(owners) for v in owners[i + 1:])
    # Illustrative fixed-endpoint probabilities, with j_t=|E_t|.
    # They follow the factor j_t/m_t^2 for calibrated parents and
    # assign uniform probabilities to the single-parent control.
    weights = [volume(owner) / m**2 for owner, m in zip(owners, volumes)]
    probabilities = [wt / sum(weights) for wt in weights]
    end_z, end_q = cube(example.z, w), cube(example.q, w)
    pair_domain = intersect(end_z, end_q)
    kernel, row = enclosing_integrals(example, end_z, pair_domain, pair_domain)
    kernel_neighborhood, _unused = enclosing_integrals(
        example, enlarged(end_z, EPSILON),
        enlarged(pair_domain, -EPSILON), enlarged(pair_domain, EPSILON))
    assert kernel_neighborhood[0] <= kernel[0] <= kernel[1] <= kernel_neighborhood[1]
    if example.name.endswith('far'):
        assert kernel[0] <= volume(pair_domain) / (D + w**n) <= kernel[1]
    print(example.name, 'true calibration' if example.calibrated else 'NONCALIBRATED')
    print('  physical parent masses', [str(m) for m in masses],
          'volumes', [str(m) for m in volumes],
          'maximal cap <=', example.average_cap)
    print('  total physical mass =', mu(((F(-2), F(2)),) * n, example.source),
          'common all parents =', mu(common, example.source))
    print('  K =', format_interval(*kernel),
          'K/(|center intersection|/D) =',
          format_interval(*(x * D / volume(pair_domain) for x in kernel)))
    print('  K, uniform in two endpoint boxes of side 1/512 =',
          format_interval(*kernel_neighborhood))
    print('  integral K(z,q)dmu(q)/D =', format_interval(*row),
          'Fubini bound =', w**n / D)
    print('  chosen parent probabilities =', [str(x) for x in probabilities])
    for k in (2, 3):
        probabilities_times_masses = [
            prod(probabilities[i] for i in ix)
            * mu(intersect(*(parents[i] for i in ix)), example.source)
            for ix in product(range(len(parents)), repeat=k)]
        weighted_common = sum(probabilities_times_masses)
        print(f'  k={k}, weighted common =', weighted_common,
              'ratio weighted common/(D*K^(k-1)) =',
              format_interval(*reduced_ratio(weighted_common, kernel, k)))
    if len(parents) == 3:
        print('  all three distinct ratio =',
              format_interval(*reduced_ratio(mu(common, example.source), kernel, 3)))
    return kernel, row, kernel_neighborhood


def high_dimensional_bound(n):
    # A compactly supported density 1 on [-2,2]^n, plus equal-mass
    # boxes of half-side delta around +/-3/4 e_j. Moving those centers
    # to +/-3/2 e_j produces the equal-total-mass far comparison.
    assert n >= 2
    w = 1 + F(1, 32 * n)
    b = 1 - F(1, 4 * n)
    shift = b / (16 * n)
    delta = F(1, 2**(2 * n + 8))
    radius = F(3, 4)
    spike_mass = F(7, 5)**n / (2 * n)
    parent_mass = b**n
    common = parent_mass * (1 - F(1, 8 * n))
    assert D <= parent_mass < 2 * D
    assert shift > b / (32 * n)  # disjoint physical owners
    assert radius - delta > b / 2 + shift  # outside every parent
    assert 2 * (radius - delta - shift) >= F(7, 5)  # maximal cap <= 2
    assert w + delta < F(3, 2) - delta  # far spikes invisible
    assert w + delta < 2  # density-one base covers all kernel windows
    assert common >= F(45, 64)
    assert delta < b / 2 - shift
    assert 0 < 2 * radius - w + 2 * delta < w - 2 * delta

    # Uniformly for z,q in the positive-density box [-delta,delta]^n.
    # A center a outside the outer shell and the inner bad cube
    # captures an entire spike; the proofs of the two exceptional
    # volumes use the sup norm and Lebesgue cube volume.
    shell = (w + 2 * delta)**n - (w - 2 * delta)**n
    inner = (2 * radius - w + 2 * delta)**n
    kernel_low = (w - 2 * delta)**n / (D + w**n + 2 * n * spike_mass)
    kernel_high = (shell + inner) / D + w**n / (D + spike_mass)
    far = (w - 2 * delta)**n / (D + w**n), w**n / (D + w**n)
    assert 0 < kernel_low < kernel_high < far[0]
    print('n=', n, 'near and far parents calibrated, centered maximal cap <= 2')
    print('  common all three =', format_interval(common, common, 12))
    print('  K near =', format_interval(kernel_low, kernel_high, 12),
          'K far =', format_interval(*far, 12))
    print('  all distinct k=3 ratio enclosure =',
          format_interval(*reduced_ratio(common, (kernel_low, kernel_high), 3), 6))
    print('  near Fubini row / its upper bound =',
          format_interval(1 - D * kernel_high / w**n, 1 - D * kernel_low / w**n, 12))


def main():
    print('Q_w uses side w=h*(2D)^(1/n), D=1/2, 8 subdivisions per break interval.')
    a = run(fixture(1, 'base'))
    b = run(fixture(1, 'plateau'))
    c = run(fixture(1, 'near'))
    d = run(fixture(1, 'far'))
    assert c[2][1] < d[2][0]
    assert b[0][1] < c[0][0] and c[0][1] < a[0][0]
    e = run(fixture(2, 'base'))
    f = run(fixture(2, 'near'))
    g = run(fixture(2, 'far'))
    assert f[2][1] < min(e[2][0], g[2][0])
    for n in (16, 64):
        high_dimensional_bound(n)


if __name__ == '__main__':
    main()

