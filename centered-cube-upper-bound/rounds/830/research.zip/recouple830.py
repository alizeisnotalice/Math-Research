r"""R814 exact reversible source/receiver recoupling, two source modes.

For each real positive source-cell record, q is drawn under its true source
law and p independently under mu|A_u or mu|(A_u\A_t). Membership masks
are sufficient for conditional row probabilities in the archived product-comb
model. Sharing W or (U,W) uses the R814 explicit conditionally uniform owner
law and essentially disjoint physical owner boxes: the observed labels are
then g or (u,g). All fractions are exact; n=4 is not a high-J sample.
"""

import argparse, json, zipfile, hashlib
from collections import defaultdict
from fractions import Fraction as F
from itertools import product

PIN = "891d8cbcbd35537e6abc18c938e53b1b4f300327357c24c8d14a51a46ad5e190"


def statistics(name, stage, external):
    parents = {p["id"]: p for p in stage["parents"]}
    cells = {c["mask"]: F(c["mass"]) for c in stage["cells"]}
    rows = []
    for root in stage["roots_cross"]:
        t, u, g = (root[x] for x in ("t", "u", "g"))
        D = F(parents[t]["volume_bin"])
        assert D <= F(parents[t]["m"]) < 2 * D
        for z, q in product(root["z_masks"], root["q_masks"]):
            rows.append(
                (t, u, g, z, q, D, F(root["coefficient"]) * cells[z] * cells[q])
            )
    M = sum((r[-1] for r in rows), F(0))
    assert len(rows) == 230 and M == F(stage["benchmarks"]["cross"]["mother"])
    contributions = []
    for t, u, g, z, q, D, w in rows:
        assert q & parents[t]["bit"] and q & parents[g]["bit"]
        pmasks = [
            (p, m)
            for p, m in cells.items()
            if p & parents[u]["bit"] and (not external or not p & parents[t]["bit"])
        ]
        ptotal = sum((m for p, m in pmasks), F(0))
        assert ptotal > 0, (t, u, "external p unavailable")
        if not external:
            assert ptotal == F(parents[u]["m"])
        for p, mu in pmasks:
            contributions.append(((t, u, g, z, q, D), (q, p), w / M * mu / ptotal))
    assert sum((v for _, _, v in contributions), F(0)) == 1
    print(
        "\nFIXTURE",
        name,
        "p_source=",
        "Au_minus_At" if external else "Au",
        "original true rows=",
        len(rows),
        "actual source-mask pieces=",
        len(contributions),
        "original_mass=",
        M,
    )
    baseline = defaultdict(F)
    for record, qp, w in contributions:
        baseline[record] += w
    marginal_t = defaultdict(F)
    marginal_g = defaultdict(F)
    marginal_D = defaultdict(F)
    for rec, w in baseline.items():
        marginal_t[rec[0]] += w
        marginal_g[rec[2]] += w
        marginal_D[rec[5]] += w
    print(
        "original physical-t marginal=",
        {k: str(v) for k, v in marginal_t.items()},
        "price-bin marginal=",
        {str(k): str(v) for k, v in marginal_D.items()},
    )
    for mode in ("independent", "shared_q", "shared_qp", "shared_qp_W", "shared_qp_UW"):
        channels = defaultdict(lambda: defaultdict(F))
        for rec, (q, p), w in contributions:
            if mode == "independent":
                key = ("independent",)
            elif mode == "shared_q":
                key = (q,)
            elif mode == "shared_qp":
                key = (q, p)
            elif mode == "shared_qp_W":
                key = (q, p, rec[2])
            else:
                key = (q, p, rec[1], rec[2])
            channels[key][rec] += w
        samet = sameg = sameu = samerec = sameroot = up = down = F(0)
        recovered = defaultdict(F)
        for key, weights in channels.items():
            mass = sum(weights.values(), F(0))
            bt = defaultdict(F)
            bg = defaultdict(F)
            bu = defaultdict(F)
            bD = defaultdict(F)
            broot = defaultdict(F)
            for rec, w in weights.items():
                t, u, g, z, q, D = rec
                bt[t] += w
                bg[g] += w
                bu[u] += w
                bD[D] += w
                broot[t, u, g] += w
                recovered[rec] += w
            samet += sum((v * v / mass for v in bt.values()), F(0))
            sameg += sum((v * v / mass for v in bg.values()), F(0))
            sameu += sum((v * v / mass for v in bu.values()), F(0))
            samerec += sum((v * v / mass for v in weights.values()), F(0))
            sameroot += sum((v * v / mass for v in broot.values()), F(0))
            prices = sorted(bD)
            up += sum(
                (bD[x] * bD[y] / mass for x in prices for y in prices if y > x), F(0)
            )
            down += sum(
                (bD[x] * bD[y] / mass for x in prices for y in prices if y < x), F(0)
            )
        assert dict(recovered) == dict(baseline)
        assert up == down and 0 <= samet <= 1 and 0 <= samerec <= sameroot <= samet <= 1
        assert 0 <= sameg <= 1 and 0 <= sameu <= 1 and 2 * up <= 1 - samet
        if mode == "independent":
            assert samet == sum((v * v for v in marginal_t.values()), F(0))
            assert sameg == sum((v * v for v in marginal_g.values()), F(0))
            assert up == sum(
                (marginal_D[x] * marginal_D[y] for x in marginal_D for y in marginal_D if y > x),
                F(0),
            )
        if mode in ("shared_qp_W", "shared_qp_UW"):
            assert sameg == 1
        if mode == "shared_qp_UW":
            assert sameu == 1
        print(
            "MODE",
            mode,
            "channels=",
            len(channels),
            "same_t=",
            float(samet),
            "strict_up=",
            float(up),
            "strict_down=",
            float(down),
            "same_g=",
            float(sameg),
            "same_u=",
            float(sameu),
            "same_tug=",
            float(sameroot),
            "same_230_record_label=",
            float(samerec),
            "other_t_acceptance=",
            float(1 - samet),
            "up_after_forcing_other_t=",
            float(up / (1 - samet)) if samet < 1 else None,
            "other_label_acceptance=",
            float(1 - samerec),
            "up_after_forcing_other_label=",
            float(up / (1 - samerec)) if samerec < 1 else None,
        )
        print(
            " MODE_EXACT",
            mode,
            "same_t=",
            samet,
            "up=",
            up,
            "same_g=",
            sameg,
            "same_u=",
            sameu,
            "same_tug=",
            sameroot,
            "same_record_label=",
            samerec,
        )
    print(
        "SCOPE forcing another t/label is renormalization; not additional unconditioned mass. Exact q and p are shared inside their real cells; same_230_record_label is equality of discrete labels, not equality of independent continuous points."
    )


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--archive", required=True)
args = parser.parse_args()
with open(args.archive, "rb") as f:
    assert hashlib.sha256(f.read()).hexdigest() == PIN
with zipfile.ZipFile(args.archive) as z:
    rebuilt = json.loads(z.read("comb814-rebuilt.json"))["stages"][0]
    ns = {"__name__": "archived_comb811"}
    exec(compile(z.read("comb811.py"), "comb811.py", "exec"), ns)
    name, n, h, middle, old = ns["FIXTURES"][-1]
    original = ns["fixture"](name, n, h, middle, old)
    for label, stage in (("original", original), ("rebuilt", rebuilt)):
        statistics(label, stage, False)
        statistics(label, stage, True)
print(
    "\nPASS exact reversible recouplings and preserved full original row marginal; n=4 high-J gate is empty"
)
