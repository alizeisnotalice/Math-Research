"""R814 true parent geometry under same-bin source/owner recoupling.

The separate W owner label is g: the owner's disjoint E_g and conditional
uniformity make its physical coordinate reveal g. At a fixed g its law does
not depend on t,u,z,q, so it cancels from their conditional distribution.
Source membership cells have constant densities relative to the same mu.
Owner-distance bounds use the complete owner rectangles, hence remain valid
for actual E_t subsets; no unsupported uniformity of E_t is assumed.
"""
import argparse
import hashlib
import json
import zipfile
from collections import defaultdict
from fractions import Fraction as F
from itertools import product

PIN = '891d8cbcbd35537e6abc18c938e53b1b4f300327357c24c8d14a51a46ad5e190'
THRESHOLDS = (F(1,256), F(1,128), F(1,64), F(3,128), F(1,32))


def above(distance, threshold, D):
    # n=4: distance > threshold*4*(2D)^(1/4), exact fourth powers.
    return distance > 0 and distance**4 > (4 * threshold)**4 * 2 * D


def run(name, stage, external):
    parents = {v['id']: v for v in stage['parents']}
    cells = {v['mask']: F(v['mass']) for v in stage['cells']}
    rows = []
    for root in stage['roots_cross']:
        t,u,g = (root[k] for k in ('t','u','g'))
        for z,q in product(root['z_masks'], root['q_masks']):
            rows.append((t,u,g,z,q,F(root['coefficient'])*cells[z]*cells[q]))
    total = sum((row[-1] for row in rows), F(0))
    assert len(stage['roots_cross']) == 34 and len(rows) == 230
    assert total == F(stage['benchmarks']['cross']['mother'])
    channels = {name: defaultdict(lambda: defaultdict(F)) for name in ('D','pqD','pqgD','pqugD')}
    for t,u,g,z,q,w in rows:
        D = F(parents[t]['volume_bin'])
        assert D <= F(parents[t]['m']) < 2*D
        assert q & parents[t]['bit'] and q & parents[g]['bit']
        pmasks = [(p,m) for p,m in cells.items() if p & parents[u]['bit'] and (not external or not p & parents[t]['bit'])]
        den = sum((m for p,m in pmasks), F(0))
        assert den > 0
        if not external:
            assert den == F(parents[u]['m'])
        for p,m in pmasks:
            v = w*m/(total*den)
            for mode,key in [('D',(D,)),('pqD',(p,q,D)),('pqgD',(p,q,g,D)),('pqugD',(p,q,u,g,D))]:
                channels[mode][key][t] += v
    print('FIXTURE',name,'source', 'Au_minus_At' if external else 'Au')
    print('CONTEXT fixed archived 4D fixture three_thin_axes; parent order is prescribed; no independent original O history identifier is archived')
    for mode,groups in channels.items():
        assert sum((sum(a.values(),F(0)) for a in groups.values()), F(0)) == 1
        exact = {h:F(0) for h in THRESHOLDS}
        lower = {h:F(0) for h in THRESHOLDS}
        upper = {h:F(0) for h in THRESHOLDS}
        same = F(0)
        repeat = {k: F(0) for k in (2,4,8)}
        diffpair = F(0)
        for key,dist in groups.items():
            D = key[-1]
            mass = sum(dist.values(),F(0))
            probs = [w/mass for w in dist.values()]
            for k in repeat:
                repeat[k] += mass*(1-sum((v**k for v in probs),F(0)))
            for t,wt in dist.items():
                for s,ws in dist.items():
                    weight = wt*ws/mass
                    same += weight*(t==s)
                    diffpair += weight*(t!=s)
                    a,b = parents[t],parents[s]
                    delta = sum((abs(F(x)-F(y)) for x,y in zip(a['center'],b['center'])),F(0))
                    error = sum((max(abs(F(x)-F(v[0])),abs(F(x)-F(v[1]))) for obj in (a,b) for x,v in zip(obj['center'],obj['owner'])),F(0))
                    for h in THRESHOLDS:
                        exact[h] += weight*above(delta,h,D)
                        lower[h] += weight*above(max(F(0),delta-error),h,D)
                        upper[h] += weight*above(delta+error,h,D)
        assert same+diffpair == 1 and repeat[2] == diffpair
        print('MODE',mode,'channels',len(groups),'same_parent',float(same),'different_parent',float(diffpair),'different_parent_exact',diffpair)
        print('  repeated_block_labels_prob_not_all_equal', {k:float(v) for k,v in repeat.items()})
        for h in THRESHOLDS:
            assert lower[h] <= exact[h] <= upper[h]
            print('  threshold',h,'center_exact',str(exact[h]),'center_float',float(exact[h]),'owner_lower_upper',float(lower[h]),float(upper[h]))
    print('  central parent geometry:')
    for t in sorted({row[0] for row in rows}):
        v=parents[t]
        print('   ',t,'D',v['volume_bin'],'center',v['center'],'owner',v['owner'])


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--archive',required=True)
    args=parser.parse_args()
    with open(args.archive,'rb') as f:
        assert hashlib.sha256(f.read()).hexdigest()==PIN
    with zipfile.ZipFile(args.archive) as z:
        rebuilt=json.loads(z.read('comb814-rebuilt.json'))['stages'][0]
        ns={'__name__':'archived_comb811'}
        exec(compile(z.read('comb811.py'),'comb811.py','exec'),ns)
        fixture,n,h,middle,old=ns['FIXTURES'][-1]
        original=ns['fixture'](fixture,n,h,middle,old)
    for name,stage in [('original',original),('rebuilt',rebuilt)]:
        for external in (False,True):
            run(name,stage,external)
    print('PASS exact fourth-power threshold, joint normalization, conditional repeat k=2 identity; 4D high-J gate empty')


if __name__=='__main__':
    main()
