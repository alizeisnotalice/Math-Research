"""Replay the round-830 checks and preserve their complete outputs."""

import argparse
from concurrent.futures import ThreadPoolExecutor
from hashlib import sha256
from importlib.metadata import version
import os
from pathlib import Path
import subprocess
import sys


ARCHIVE_SHA256 = "891d8cbcbd35537e6abc18c938e53b1b4f300327357c24c8d14a51a46ad5e190"
CHECKS = (
    ("recouple830.py", ("--archive",)),
    ("geometry830.py", ("--archive",)),
    ("reuse830.py", ("--exact",)),
    ("constants830.py", ()),
    ("cross830.py", ("--archive",)),
    ("overlap830.py", ()),
)


def file_digest(path):
    with path.open("rb") as source:
        return sha256(source.read()).hexdigest()


def run_check(directory, archive, check):
    script, args = check
    if args == ("--archive",):
        args = (*args, str(archive))
    env = {**os.environ, "PYTHONHASHSEED": "0", "PYTHONIOENCODING": "utf-8"}
    return subprocess.run(
        [sys.executable, "-B", script, *args],
        cwd=directory,
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=False,
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive", type=Path, required=True, help="Original round-814 research.zip")
    parser.add_argument("--jobs", type=int, choices=range(1, 5), default=4)
    parser.add_argument("--output", type=Path, help="Write the report to this file; default is stdout")
    args = parser.parse_args()

    directory = Path(__file__).resolve().parent
    archive = args.archive.resolve(strict=True)
    archive_hash = file_digest(archive)
    if archive_hash != ARCHIVE_SHA256:
        parser.error(f"unexpected round-814 archive SHA-256: {archive_hash}")
    script_hashes = {script: file_digest(directory / script) for script, _ in CHECKS}
    protected_paths = {directory / script for script in script_hashes}
    protected_paths.update((archive, Path(__file__).resolve()))
    if args.output and args.output.resolve() in protected_paths:
        parser.error("the output must be distinct from the archive and the scripts")

    flint_version = version("python-flint")
    with ThreadPoolExecutor(max_workers=args.jobs) as workers:
        pending = [workers.submit(run_check, directory, archive, check) for check in CHECKS]
        results = [job.result() for job in pending]

    if file_digest(archive) != archive_hash:
        parser.error("the input archive changed during replay")
    for script, digest in script_hashes.items():
        if file_digest(directory / script) != digest:
            parser.error(f"{script} changed during replay")

    report = [
        "Round 830 computational verification",
        f"Interpreter: {sys.executable}",
        f"Python: {sys.version}",
        f"Dependency: python-flint {flint_version}",
        "Standard library only: recouple830.py, geometry830.py",
        "PYTHONHASHSEED=0; PYTHONIOENCODING=utf-8; Python -B",
        f"Round 814 input: {archive}",
        f"Round 814 input SHA-256: {archive_hash}",
        f"Replay script SHA-256: {file_digest(Path(__file__).resolve())}",
    ]
    for (script, options), result in zip(CHECKS, results):
        command = " ".join([script, *options])
        if options == ("--archive",):
            command += " <round-814 archive above>"
        report.extend(
            [
                "",
                f"===== {command} =====",
                f"Script SHA-256: {script_hashes[script]}",
                f"Exit code: {result.returncode}",
                f"stdout SHA-256: {sha256(result.stdout).hexdigest()}",
                f"stderr SHA-256: {sha256(result.stderr).hexdigest()}",
                "----- stdout -----",
                result.stdout.decode("utf-8").removesuffix("\n"),
                "----- stderr -----",
                result.stderr.decode("utf-8").removesuffix("\n"),
            ]
        )
    all_passed = all(result.returncode == 0 for result in results)
    report.extend(("", f"Replay status: {'PASS' if all_passed else 'FAIL'}", ""))
    text = "\n".join(report)
    if args.output:
        args.output.write_text(text, encoding="utf-8")
    else:
        sys.stdout.write(text)
    return 0 if all_passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
