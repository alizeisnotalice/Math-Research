"""R830. Exact positive L1 sources, disjoint Lebesgue receiver cells, and last roots.

Use the pinned replay interpreter with --compact for selected decisions.
Default stdout includes the frozen pools, true conditional masses and all gates.
--exact prints full rational values rather than condensed large-number strings.
Geometric pair bounds alone use Arb; all original moment and payment sums are rational.
"""
import argparse
import json
import sys
from dataclasses import dataclass
from fractions import Fraction as Q
from itertools import product
from math import prod

import flint
from flint import arb, ctx


@dataclass
class Block:
    center: tuple
    mass: Q


@dataclass
class Cell:
    bounds: tuple
    side: Q
    ids: tuple


def volume(box):
    return prod((right-left for left,right in box), start=Q(1))


def certify(n, blocks, width, cells):
    source_total = sum(b.mass for b in blocks)
    assert width > 0 and all(b.mass > 0 and len(b.center) == n for b in blocks)
    for i,b in enumerate(blocks):
        for c in blocks[:i]:
            assert max(abs(x-y) for x,y in zip(b.center,c.center)) > 2*width
    for i,cell in enumerate(cells):
        t = cell.side
        assert len(cell.bounds) == n and 1 <= t <= 2 and all(v > u for u,v in cell.bounds)
        assert sum(blocks[j].mass for j in cell.ids) == t**n
        for j,b in enumerate(blocks):
            if j in cell.ids:
                d = max(max(abs(l-c),abs(r-c))+width for c,(l,r) in zip(b.center,cell.bounds))
                assert d <= t/2-width
            else:
                # An unrelated source cannot contribute until the total-source
                # bound is already at or below the threshold.
                d = max(max(l-c-width,c-width-r,0) for c,(l,r) in zip(b.center,cell.bounds))
                assert 2*d >= t and (2*d)**n >= source_total
        for prev in cells[:i]:
            assert any(b <= c or d <= a for (a,b),(c,d) in zip(cell.bounds,prev.bounds))
        assert (t-2*width)**n < t**n


def star(n, k, side_values, micro=100, first_axis_fraction=Q(1)):
    w = Q(1,micro*n)
    tags = list(product((-1,1),repeat=k))
    assert len(side_values) <= len(tags)
    sides = tuple(map(Q,side_values))
    m0 = min(sides)**n/2
    blocks = [Block((Q(0),)*n,m0)]
    cells = []
    for j,(sign,t) in enumerate(zip(tags,sides)):
        center = tuple(map(Q,sign)) + (Q(0),)*(n-k)
        blocks.append(Block(center,t**n-m0))
        limits = []
        for idx,z in enumerate(center):
            l = max(Q(0),z)-t/2+2*w
            r = min(Q(0),z)+t/2-2*w
            if idx == 0:
                mid = (l+r)/2
                l,r = mid-(r-l)*first_axis_fraction/2, mid+(r-l)*first_axis_fraction/2
            limits.append((l,r))
        cells.append(Cell(tuple(limits),t,(0,j+1)))
    return blocks,w,cells


def bridge(n, k, micro=100, bridge_fraction=Q(1)):
    assert k >= 2 and k % 2 == 0 and k <= n
    w, t = Q(1,micro*n), Q(3,2)
    s = t*(1+Q(1,3*n))
    m, b = s**n-t**n, 2*t**n-s**n
    zero = (Q(0),)*n
    c1 = tuple(Q(int(i < k//2)) for i in range(n))
    c2 = tuple(Q(int(k//2 <= i < k)) for i in range(n))
    blocks = [Block(zero,b), Block(c1,m), Block(c2,m)]
    cells = []
    for own,other,marker in ((1,2,k//2),(2,1,0)):
        limits = []
        for i in range(n):
            lower = blocks[own].center[i]-t/2+2*w
            upper = t/2-2*w
            if i == marker:
                assert blocks[other].center[i] == 1
                upper = min(upper,1-s/2-2*w)
            limits.append((lower,upper))
        cells.append(Cell(tuple(limits),t,(0,own)))
    limits = [(1-s/2+2*w,s/2-2*w) if i < k else (-s/2+2*w,s/2-2*w) for i in range(n)]
    a,d = limits[0]
    mid = (a+d)/2
    limits[0] = (mid-(d-a)*bridge_fraction/2,mid+(d-a)*bridge_fraction/2)
    cells.append(Cell(tuple(limits),s,(0,1,2)))
    return blocks,w,cells


def A(q):
    q = Q(q)
    return arb(q.numerator)/q.denominator


def nice(q):
    q = Q(q)
    bits = max(q.numerator.bit_length(),q.denominator.bit_length())
    if FULL_EXACT or bits <= 75:
        return str(q)
    return A(q).str(12)


def cmp(x):
    if x > 0:
        return 1
    if x < 0:
        return -1
    if x.is_zero():
        return 0
    raise ArithmeticError("The interval touches the decision boundary")


def kern(n,T,d):
    assert d > 0
    u = A(d/T)
    return (-u).exp()*(1+n/u)


def first_gate(n,T,L,delta):
    # Search half-integer radii. Every model center distance is an integer,
    # and 2*n*w < 1/2. Thus no true pair straddles these cutoffs.
    def allowed(j):
        return cmp(kern(n,T,Q(2*j+1,2))*A(2*L)-A(delta*delta)) <= 0
    lo,hi=-1,1
    while not allowed(hi):
        hi = 2*hi+1
    while hi-lo>1:
        mid=(lo+hi)//2
        if allowed(mid):
            hi=mid
        else:
            lo=mid
    return Q(2*hi+1,2)


def dyadic_volume_bin(v):
    j = v.numerator.bit_length()-v.denominator.bit_length()
    if v < Q(2)**j:
        j -= 1
    assert Q(2)**j <= v < Q(2)**(j+1)
    return j


def distance_matrix(blocks,w,n):
    d0 = [[sum(abs(x-y) for x,y in zip(b.center,c.center)) for c in blocks] for b in blocks]
    low = [[sum(max(abs(x-y)-2*w,0) for x,y in zip(b.center,c.center)) for c in blocks]
           for b in blocks]
    high = [[d+2*n*w for d in row] for row in d0]
    return d0,low,high


def analyze(n,k,edition,fixture):
    blocks,w,cells = fixture
    certify(n,blocks,w,cells)
    T = max(c.side for c in cells)
    value = [c.side**n for c in cells]
    area = [volume(c.bounds) for c in cells]
    xi = [a/v for a,v in zip(area,value)]
    L = sum(xi)
    V = sum(area)
    m = [b.mass for b in blocks]
    ids = range(len(blocks))
    h = [sum(xi[y] for y,c in enumerate(cells) if i in c.ids) for i in ids]
    pair = [[sum((xi[y] for y,c in enumerate(cells) if i in c.ids and j in c.ids),Q(0))
             for j in ids] for i in ids]
    assert sum(m[i]*h[i] for i in ids) == V
    d0,low,high = distance_matrix(blocks,w,n)
    kernel_worst = arb(0)
    kernel_offdiag = arb(0)
    by_distance = {}
    for i in ids:
        for j in range(i+1):
            ratio = A(pair[i][j])/kern(n,T,high[i][j])
            assert cmp(ratio-1) <= 0
            if ratio > kernel_worst:
                kernel_worst = ratio
            if i != j and ratio > kernel_offdiag:
                kernel_offdiag = ratio
            if i != j:
                key = str(d0[i][j])
                entry = by_distance.setdefault(key, {"pairs":0,"positive":0,"max_ratio":arb(0)})
                entry["pairs"] += 1
                if pair[i][j] > 0:
                    entry["positive"] += 1
                if ratio > entry["max_ratio"]:
                    entry["max_ratio"] = ratio
    for entry in by_distance.values():
        entry["max_ratio"] = entry["max_ratio"].str(9)
    by_gate = {}
    for label,delta in (("absolute_1_32",Q(1,32)),("relative_1_4",L/4),
                        ("relative_49_100",L*Q(49,100)),("relative_3_4",L*Q(3,4))):
        sel = [i for i in ids if h[i] >= delta]
        if not sel:
            by_gate[label] = {"delta":nice(delta),"blocks":[],"actual_q_fraction":"0"}
            continue
        mu = sum(m[i] for i in sel)
        at = [sum((m[i] for i in sel if i in c.ids),Q(0)) for c in cells]
        moment1 = sum(x*a for x,a in zip(xi,at))
        moment2 = sum(x*a*a for x,a in zip(xi,at))
        assert moment1 == sum(m[i]*h[i] for i in sel)
        assert moment2 == sum(m[i]*m[j]*pair[i][j] for i in sel for j in sel)
        assert moment1 >= delta*mu and moment1*moment1 <= moment2*L
        auto = first_gate(n,T,L,delta)
        cutoffs = sorted({Q(1,2),Q(2*(k//2)+1,2),Q(2*k+1,2),auto})
        radii = {}
        for cutoff in cutoffs:
            near = [[high[i][j] <= cutoff for j in ids] for i in ids]
            assert all(near[i][j] or low[i][j] > cutoff for i in ids for j in ids)
            source_near = sum((m[i]*m[j] for i in sel for j in sel if near[i][j]),Q(0))
            far_second = sum((m[i]*m[j]*pair[i][j] for i in sel for j in sel
                              if not near[i][j]),Q(0))
            prop_gate = kern(n,T,cutoff)*A(L/(delta*delta))
            assert cmp(A(far_second)-kern(n,T,cutoff)*A(mu*mu-source_near)) <= 0
            assert moment2-far_second <= L*source_near
            if cutoff == auto:
                assert cmp(prop_gate-A(Q(1,2))) <= 0
                assert source_near/mu**2 >= delta**2/(2*L**2)
            # Actual double-source mass, restricting q to the reused cluster.
            eligible_payment = sum((v/tv**2 * sum((m[p]*m[q] for p in c.ids for q in sel
                       if q in c.ids and near[p][q]),Q(0))
                       for c,v,tv in zip(cells,area,value)),Q(0))
            # A single fixed reference can be chosen before this q is sampled.
            # Since our radii are away from all center distances, a complete
            # source box is either in or out for that reference.
            blind = {i:sum((m[j]*h[j] for j in sel if near[i][j]),Q(0)) for i in sel}
            assert max(blind.values()) <= moment1 and eligible_payment <= moment1
            radii[str(cutoff)] = dict(
                far_kernel_times_L_over_delta2=prop_gate.str(11),
                source_pair_near_fraction=nice(source_near/(mu*mu)),
                far_second_fraction=nice(far_second/moment2),
                true_pair_paid_fraction_of_all=nice(eligible_payment/V),
                true_pair_unpaid_fraction_of_eligible=nice((moment1-eligible_payment)/moment1),
                best_fixed_reference_fraction_of_all=nice(max(blind.values())/V),
                reference_fractions_of_eligible={i:nice(v/moment1) for i,v in blind.items()})
        by_gate[label] = dict(delta=nice(delta),blocks=sel,actual_q_fraction=nice(moment1/V),
            cluster_mass=nice(mu),moment1=nice(moment1),moment2=nice(moment2),
            lower_from_gate=nice(delta**2*mu**2/L),
            lower_from_exact_mean=nice(moment1**2/L),
            mean_bound_over_actual_second=nice(moment1**2/(L*moment2)),
            guaranteed_near_pair_floor=nice(delta**2/(2*L**2)),
            first_passing_half_integer=str(auto),cutoffs=radii)
    return dict(n=n,k=k,edition=edition,source_halfwidth=str(w),T=str(T),
                source_masses=[nice(v) for v in m],root_sides=[str(z.side) for z in cells],
                log2_volume_bins=[dyadic_volume_bin(v) for v in value],
                total_real_receivers=nice(V),L=nice(L),xi=[nice(v) for v in xi],
                reuse_by_block_over_L=[nice(v/L) for v in h],pair_bound_checks=len(blocks)*(len(blocks)+1)//2,
                max_H_over_pair_bound=kernel_worst.str(12),max_off_diagonal_ratio=kernel_offdiag.str(12),
                by_center_distance=by_distance,gates=by_gate)


def leaf_restricted(n,k):
    """Same actual full-measure roots with the original endpoint cut on both leaves."""
    blocks,w,cells=bridge(n,k)
    certify(n,blocks,w,cells)
    T=max(c.side for c in cells)
    v=[c.side**n for c in cells]
    areas=[volume(c.bounds) for c in cells]
    xi=[a/t for a,t in zip(areas,v)]
    L=sum(xi)
    delta=Q(49,100)*L
    h=[sum(xi[j] for j,c in enumerate(cells) if i in c.ids) for i in range(3)]
    cut=(1,2)
    assert all(h[i]>=delta for i in cut)
    radius=first_gate(n,T,L,delta)
    _,low,high=distance_matrix(blocks,w,n)
    near=[[high[i][j]<=radius for j in range(3)] for i in range(3)]
    assert all(near[i][j] or low[i][j]>radius for i in range(3) for j in range(3))
    mass=[b.mass for b in blocks]
    local=[sum(mass[i] for i in cut if i in c.ids) for c in cells]
    original=sum(a*at*at/tv**2 for a,at,tv in zip(areas,local,v))
    paid_pair=sum(a/tv**2*sum((mass[i]*mass[j] for i in cut for j in cut
        if i in c.ids and j in c.ids and near[i][j]),Q(0)) for a,c,tv in zip(areas,cells,v))
    reference=[sum(a*at/tv**2*sum((mass[j] for j in cut if j in c.ids and near[i][j]),Q(0))
        for a,at,tv,c in zip(areas,local,v,cells)) for i in range(3)]
    moment1=sum(x*a for x,a in zip(xi,local))
    moment2=sum(x*a*a for x,a in zip(xi,local))
    far_second=sum(x*sum((mass[i]*mass[j] for i in cut for j in cut
        if i in c.ids and j in c.ids and not near[i][j]),Q(0)) for x,c in zip(xi,cells))
    source_total=sum(mass[i] for i in cut)
    source_near=sum((mass[i]*mass[j] for i in cut for j in cut if near[i][j]),Q(0))
    assert moment1**2<=L*moment2 and source_near/source_total**2>=delta**2/(2*L**2)
    assert reference[0]==original and reference[1]==reference[2]==original/2
    assert 0<original-paid_pair<original and 0<far_second<moment2
    return dict(n=n,k=k,cut_blocks=list(cut),absolute_1_32_q_mass_zero=all(h[i]<Q(1,32) for i in cut),
        L=nice(L),delta_over_L="49/100",auto_radius=str(radius),original_cut_J=nice(original),
        true_q_meeting_relative_gate="1",actual_pair_unpaid=(A((original-paid_pair)/original)).str(13),
        best_single_reference_from_this_cut="1/2",two_reference_menu="1",
        best_single_reference_from_full_source="1",source_pair_near=nice(source_near/source_total**2),
        far_second_fraction=nice(far_second/moment2),
        mean_square_over_second=nice(moment1**2/(L*moment2)))


def all_cases():
    s = (Q(6,5),Q(7,5),Q(3,2),Q(8,5))
    yield 2,1,"initial_flat",star(2,1,(Q(3,2),)*2)
    yield 8,2,"stress_cross",star(8,2,s)
    yield 8,2,"stress_micro_32",star(8,2,s,micro=3200)
    yield 8,2,"stress_half_cell",star(8,2,s,first_axis_fraction=Q(1,2))
    yield 8,4,"stress_bridge",bridge(8,4)
    yield 8,4,"stress_bridge_1_32",bridge(8,4,bridge_fraction=Q(1,32))
    for n,k in ((16,4),(32,16),(64,4),(64,32),(128,64),(256,4),(256,128),(256,256),(512,4),(512,256)):
        yield n,k,"larger_bridge",bridge(n,k)


def summarize(row):
    gate = row["gates"]["relative_49_100"]
    auto = gate["first_passing_half_integer"]
    data = gate["cutoffs"][auto]
    return {"edition":row["edition"],"n":row["n"],"k":row["k"],"T":row["T"],
            "bins":row["log2_volume_bins"],"L":row["L"],"q_over_L":row["reuse_by_block_over_L"],
            "absolute_q_paid":row["gates"]["absolute_1_32"]["actual_q_fraction"],
            "relative_q_paid":gate["actual_q_fraction"],"mean_square_over_second":gate["mean_bound_over_actual_second"],
            "first_radius":auto,"near_source_fraction":data["source_pair_near_fraction"],
            "far_second_fraction":data["far_second_fraction"],
            "true_unpaid_within_eligible":data["true_pair_unpaid_fraction_of_eligible"],
            "best_ref_paid":data["best_fixed_reference_fraction_of_all"],
            "max_pair_ratio":row["max_off_diagonal_ratio"]}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--compact",action="store_true")
    parser.add_argument("--exact",action="store_true",help="default report with unabridged rationals")
    args=parser.parse_args()
    global FULL_EXACT
    FULL_EXACT=args.exact
    if FULL_EXACT:
        sys.set_int_max_str_digits(0)
    ctx.prec=256
    records=[analyze(*p) for p in all_cases()]
    restricted=[leaf_restricted(n,k) for n,k in ((64,32),(512,256))]
    # Independent higher-precision checks of every analytic decision on the
    # strongest settings, in addition to exact rational source ledgers.
    ctx.prec=384
    for p in all_cases():
        if p[0] == 8 or p[0] >= 256:
            repeated=analyze(*p)
            first=next(x for x in records if (x["n"],x["k"],x["edition"]) == (p[0],p[1],p[2]))
            for key in first["gates"]:
                a,b=first["gates"][key],repeated["gates"][key]
                assert (a["blocks"],a.get("first_passing_half_integer")) == (b["blocks"],b.get("first_passing_half_integer"))
    restricted_again=[leaf_restricted(n,k) for n,k in ((64,32),(512,256))]
    assert all(a["auto_radius"] == b["auto_radius"] for a,b in zip(restricted,restricted_again))
    out={"leaf_only_cut":restricted_again,"precision_bits":[256,384],"flint":flint.__version__,"cases":len(records),
         "pair_bound_checks_at_256":sum(x["pair_bound_checks"] for x in records),
         "results":[summarize(r) for r in records] if args.compact else records}
    print(json.dumps(out,ensure_ascii=False,indent=2))


FULL_EXACT=False
if __name__ == "__main__":
    main()
