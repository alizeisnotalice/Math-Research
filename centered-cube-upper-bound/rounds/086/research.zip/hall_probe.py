#!/usr/bin/env python3
"""R86 public exact necessary-condition guards. No private pressure recipe.
Threshold/envelope algebra; a neutral contact-only positive L1 scalar example;
NONphysical finite common-column projection identities. No high-load physical
qualification, Hall estimate or general root-order theorem claimed.
"""
from fractions import Fraction as F
from functools import lru_cache
from pathlib import Path
import json, math
S=1<<60
SEED=860611
def ceildiv(a,b):return -(-a//b)
def floor_scaled(x):return x.numerator*S//x.denominator
def ceil_scaled(x):return ceildiv(x.numerator*S,x.denominator)

@lru_cache(32768)
def expneg(x):
    """e^-x in exact dyadic enclosure; positive Taylor then inversion/squaring."""
    x=F(x);assert x>=0
    if x==0:return F(1),F(1)
    k=0;v=x
    while v>F(1,2):v/=2;k+=1
    vl=floor_scaled(v);vu=ceil_scaled(v)
    tl=tu=S;sl=su=S
    for j in range(1,21):
        tl=tl*vl//(S*j);tu=ceildiv(tu*vu,S*j);sl+=tl;su+=tu
    nxt=ceildiv(tu*vu,S*21);su+=2*nxt
    lo=S*S//su;hi=ceildiv(S*S,sl)
    for _ in range(k):lo=lo*lo//S;hi=ceildiv(hi*hi,S)
    return F(lo,S),F(hi,S)


def clean(x):
    if isinstance(x,F):return str(x)
    if isinstance(x,dict):return {str(k):clean(v) for k,v in x.items()}
    if isinstance(x,(tuple,list)):return [clean(v) for v in x]
    return x

@lru_cache(None)
def log_interval(x):
    x=F(x);assert x>0;k=0
    while x>=2:x/=2;k+=1
    while x<1:x*=2;k-=1
    def unit(v):
        z=(v-1)/(v+1);q=z*z;term=z;total=F(0)
        for j in range(48):total+=2*term/(2*j+1);term*=q
        rem=2*term/(97*(1-q))
        return total,total+rem
    lo,hi=unit(x);l2,u2=unit(F(2))
    if k>=0:return lo+k*l2,hi+k*u2
    return lo+k*u2,hi+k*l2

def threshold_guard(n):
    l2,u2=log_interval(F(2));Hlo=1+n*l2;Hhi=1+n*u2
    # H >= 1. Cube comparison: T0>H iff H²<384 (H>0).
    r0_empty=Hhi*Hhi<384;r0_nonempty_possible=Hlo*Hlo>=384
    r1_empty=Hhi*Hhi<192*n or r0_empty
    r1_possible=Hlo*Hlo>=192*n and r0_nonempty_possible
    q0_empty=Hhi*Hhi<3072
    q1_empty=q0_empty or Hhi*Hhi<768*n
    assert r0_empty or r0_nonempty_possible
    assert r1_empty or r1_possible
    return dict(n=n,H_interval=[Hlo,Hhi],T0_cube=384,
      high_set_b_above_T_R0_necessarily_empty=r0_empty,
      high_set_b_above_T_R1_necessarily_empty=r1_empty,
      removal_set_q_above_2T_R0_necessarily_empty=q0_empty,
      removal_set_q_above_2T_R1_necessarily_empty=q1_empty,
      interpretation='Nonempty-possible only means the pointwise envelope does not force emptiness; no actual input existence.')

def coarse_phi_lower():
    # Genuine h*w_eta scalar lower at z=2/3 for all eta in [4/5,17/20].
    # True phi even/decreasing in z; all y/L in [2/5,2/3] use this bound.
    # t integrand lower uses eta endpoints separately, not false eta monotonicity.
    nt=256;acc=F(0)
    for j in range(1,nt):
        t=F(j,nt)
        a=expneg(F(1,6)/(F(4,5)*t))[0]
        b=expneg(F(7,6)/(F(17,20)*t))[1]
        acc+=t*max(F(0),a-b)
    return F(floor_scaled(acc/nt),S)

def contact_guard():
    # Public neutral scalar f=4 on [.6,.8], receiver x=0. CONTACT ONLY.
    a=F(3,5);b=F(4,5);rho=F(4);W=rho*(b-a);beta=F(2,5);l3,u3=log_interval(F(3))
    eta_lo,eta_hi=1/u3**2,1/l3**2
    assert F(4,5)<eta_lo<=eta_hi<F(17,20)
    alpha_hi=1/(10*l3);p=coarse_phi_lower();records=[];prev=F(8,5)
    for depth in range(16):
        lam=F(2,5)*beta**depth;L=2*a/(1-2*lam/rho)
        overlap=max(F(0),min(b,L/2)-a)
        avg=rho*overlap/L;anchor=F(0)
        oldavg=rho*max(F(0),min(b,prev/2)-a)/prev
        assert avg==lam and anchor<lam/2 and L<prev and oldavg>lam
        # Earlier physical scales: [1,2a] average0; after2a expression
        # rho/2-rho*a/L strictly increases until first full capture2b.
        assert 2*a<L<2*b
        # Full source at selected L. Integral lower >= rho*(b-a)/L*phi_bound.
        ptheta_lower=rho*(b-a)/L*p
        assert ptheta_lower>alpha_hi*lam
        records.append(dict(depth=depth,lambda_value=lam,first_contact_exact=L,
          previous_scale=prev,previous_scale_average=oldavg,anchor=anchor,source_mass=W,
          root_identity_residual=avg-lam,coarse_theta_interval=[eta_lo,eta_hi],
          selected_full_Ptheta_lower=ptheta_lower,alpha_lambda_upper=alpha_hi*lam,
          tunable_coarse_high_certified=True))
        prev=L
    return dict(scope='Actual positive L1 scalar contact test only; NOT original fully retained event. Every record is removed by NEW coarse-high deletion.',
      density=rho,source_interval=[a,b],receiver=F(0),source_mass=W,beta=beta,
      phi_uniform_lower=p,records=records,
      recursive_high_q_status='NOT TESTED; this fixed-input threshold sequence is not asserted to be a realised high-q recursion.',
      conclusion='Threshold-lowered contact radii strictly decrease with unchanged source mass. All are coarse-high; no pressure on the coarse-low residual.')

def projection_guard():
    # NONPHYSICAL: two receiver bands, common source capacity once.
    # All weights rational, logvalues bounded independently. No cube selector.
    l2,u2=log_interval(F(2));out=[]
    for stage,scale in [(1,8),(2,128),(3,4096)]:
        mass=F(1,scale*scale);W=F(1);bA=F(scale,2);bC=F(scale,2);bE=bA+bC
        D=mass*bE;T=F(scale,2);Ilo=mass*l2*l2/4;Ihi=mass*u2*u2/4
        assert bE>T and D==F(1,scale)
        # Exact distribution masses .5/.5 gives Var(log radial)=log(2)²/4.
        # Other sources have no occupation; tiny high-column mass matters.
        U=bE;band_product=mass*bA*bC
        energy_lower=l2*l2*band_product/(U*U)
        assert energy_lower==Ilo
        # Append C to A. Unnormalised second moment increases, conditional
        # variance on A is0 while wholeE ispositive. Conversely put .99 at
        # each firstband: no monotonicity of conditional variance itself.
        p=F(1,100);varA=F(1,4);varE=p*(1-p)
        assert varE<varA
        out.append(dict(stage=stage,model='NONphysical finite shared-source occupation matrix, not actual cube/L1 receiver geometry.',
          common_source_mass=mass,W=W,b_A=bA,b_C=bC,b_E=bE,D=D,T=T,
          high_source_mass_fraction=mass,unweighted_I_T_interval=[Ilo,Ihi],
          weighted_band_product=band_product,two_band_variance_lower=energy_lower,
          conditional_variance_log2_square_coefficients=[varA,varE],
          conditional_variance_A_interval=[varA*l2*l2,varA*u2*u2],
          conditional_variance_E_interval=[varE*l2*l2,varE*u2*u2],
          nested_variance_example='A has masses 1/2 at radial logs 0,log(2); E appends mass49 at0. Var(A)=log(2)^2/4,Var(E)=99log(2)^2/10000.',
          conclusion='A large pointwise common column does not by itself imply large source-mass weighted I_T; physical selector/gates absent.'))
    return out


def cutoff_certificates():
    lo,hi=log_interval(F(2));out=[]
    for label,c,N,linear in [('b>T R0',384,26,False),('b>T R1',192,396,True),('q>2T R0',3072,78,False),('q>2T R1',768,1595,True)]:
        def interval(n):
            shift=c*n if linear else c
            return (1+n*lo)**2-shift,(1+n*hi)**2-shift
        first=interval(1);last=interval(N);nextv=interval(N+1)
        assert first[1]<0 and last[1]<0 and nextv[0]>0
        deriv_lo=2*lo*(1+(N+1)*lo)-(c if linear else 0)
        assert deriv_lo>0
        out.append(dict(label=label,coefficient=c,last_empty_dimension=N,
          residual_at_one=first,residual_at_last_empty=last,residual_at_first_possible=nextv,
          derivative_lower_at_first_possible=deriv_lo,
          proof='Residual is convex quadratic, hence negative on [1,N] from endpoints. Positive at N+1 with positive increasing derivative, hence positive for all larger real n.'))
    return out

def main():
    ns=sorted(set(range(1,513))|set(range(1550,1621))|{1024,4096,16384,2**20});thresholds=[threshold_guard(n) for n in ns]
    max0=max(r['n'] for r in thresholds if r['high_set_b_above_T_R0_necessarily_empty'])
    max1=max(r['n'] for r in thresholds if r['high_set_b_above_T_R1_necessarily_empty'])
    maxq0=max(r['n'] for r in thresholds if r['removal_set_q_above_2T_R0_necessarily_empty'])
    maxq1=max(r['n'] for r in thresholds if r['removal_set_q_above_2T_R1_necessarily_empty'])
    assert (max0,max1,maxq0,maxq1)==(26,396,78,1595)
    obj=dict(schema='R86-public-exact-necessary-condition-guards-v1',publication='PUBLIC neutral exact guards; no private source/receiver recipe.',seed=SEED,
      scope='No qualified high-load residual and no new general inequality established. Private actual search excluded from archive.',
      cutoff_boundary_certificates=cutoff_certificates(),threshold_records=thresholds,threshold_empty_integer_ranges=dict(b_above_T_R0=[1,max0],b_above_T_R1=[1,max1],q_above_2T_R0=[1,maxq0],q_above_2T_R1=[1,maxq1]),
      contact_only_fixture=contact_guard(),nonphysical_projection_records=projection_guard(),
      counts=dict(threshold_dimensions=len(ns),actual_scalar_contact_records=16,nonphysical_projection_records=3))
    Path(__file__).with_name('hall_results.json').write_text(json.dumps(clean(obj),indent=2,sort_keys=True)+'\n')
    print('PASS',obj['counts'],'empty ranges',obj['threshold_empty_integer_ranges'])
if __name__=='__main__':main()
