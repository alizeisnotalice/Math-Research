# 中心立方体第86轮：一般来源块 Hall 预算与分散余集

2026-10-11。一般正 L1 输入的 $n^{1/2+o(1)}$ 一致弱型上界尚未证明，保留基准为 $O(n\log n)$。本轮校正特定删源递推中的立方体嵌套性，证明可支付的几何项，并继续攻击其余共同来源占用。条件充分性、局部约束反例和有限数值证据均不登记为一般上界。

八个既有 Agent 按用户要求复用：三位 Astra high 分别研究一般路线，一位 Astra high 与一位 Sol high 独立审核，两位 Sol high 负责数值与反例，一位 Sol high 核对原文及更新后的64项数学工具。审核员先独立检查命题，再阅读作者证明。下列正文保留所有已支付分支、真实勒贝格接收测度、输入重选与层数费用。

公开归档不包含未发表下界配方和新私有压力输入。实际已运行的公开程序、独立重放和 LaTeX 静态核验见 inventory.json。没有编译 PDF。


# 第86轮主账：一般小来源块分支与尚未支付的分散占用

一般目标 $C_n^\square\le\sqrt n\,n^{o(1)}$ 尚未证明，已保留的一般基准仍为 $O(n\log n)$。本轮沿用第82轮全部原事件与第85轮严格工具，不把条件返回或有限实验当作证明。

## 不变的原接口

$Q(x,L)=x+[-L/2,L/2]^n$，全边长 $L\in[1,2]$，$\mu=f\,dy$，$W=\|f\|_1$，接收需求为真实的 $\lambda\,dx$。原锚点 $A_1f<\lambda/2$，全窗口原平滑 $\sup P_{1,L}f\le\lambda/2$，窗口内严格硬见证，最早硬接触 $A_{L_*}f=\lambda$。原中间条件为 $e^{-s_n}/2<P_{1,L_*}f/\lambda\le1/2$。

$B_0=4+2\log2\sqrt{7n/3}$，$B_{\rm ext}=2(1+n\log2)/\sqrt{n+2}$。一般返回为

$$C_n^\square\le C_{\rm loc}\log(n+2)(B_0+B_{\rm ext}+D_{\rm mid}).$$

仅单个原 $\kappa=1+\log[\lambda/(2P_{1,L_*})]$ 层的费用须另乘 $J_n=O(\log(n+2))$。可选第83轮窄核极低背景并集另付一次 $B_{\rm ext}$，没有默认加入。本轮一般预算若对完整事件直接成立才避免层数费。每次实际限制来源后重新选择首次接触、重新判定所有分支。

## 新的通用来源块分支与所有 Hall 割

将同一个来源测度按固定半开网格分成可数小块，每块包含于全边长 $\varepsilon_{\rm pkt}\le1/(16n^2)$ 的立方体。令 $p_j(x)=\mu_j(Q_*)/(\lambda L_*^n)$，$\eta_a(x)=\sum_{p_j(x)\ge a}p_j(x)$。它们只描述实际捕获份额，没有来源坐标独立性假设。

本轮证明：对任意实际接触数据以及 $R=\{\eta_a\ge\rho\}$ 的每个可测子集 $A$，

$$\lambda|A|\le P_{n,a,\rho}\mu(N_A),\qquad
P_{n,a,\rho}=1+\frac2\rho[3+3\log(1/a)+4\log(4H_n/\rho)],$$

其中 $N_A=\{y:\int_A L_*^{-n}1_{Q_*}(y)dx>0\}$ 是本质捕获邻域。证明先用每个小块的边缘秩与精确接收体积控制标记列的指数尾，再以同一个小来源异常集支付所有相关行；可数块的质量只求和一次。所有割结论利用 Tonelli 保留接触和每块份额后重新应用接触恒等式版本，不声称平滑门在删源后自动继承，也不额外断言任意可测图上的运输存在。

固定 $p>0$，取 $a=n^{-p}$、$\rho=n^{-1/2}$，得到 $P_{n,p}=O_p(\sqrt n\log(n+2))$。此估计直接支付整个原背景层并集，不产生块数或背景层数因子。若每行最多捕获 $N$ 个小块，还得到所有割费用 $O(\log N+\log(n+2))$；这是局部数量受限时的推论，不是一般数量界。

在整个原粗平滑低分支 $F$ 上，新的真正剩余事件定义为

$$F_{\rm diff}=\{x\in F:\eta_{n^{-p}}(x)<n^{-1/2}\}.$$

这里多于 $1-n^{-1/2}$ 的捕获质量来自个别份额小于 $n^{-p}$ 的块。它是任意输入上的完整分支分解，尚未支付该分散余集。若 $D_{\rm diff}$ 是其一致费用，则原接口准确更新为

$$C_n^\square\le C_{\rm loc}\log(n+2)
[B_0+B_{\rm ext}+T_{\rm soft}/\alpha+P_{n,p}+D_{\rm diff}].$$

取 $\theta=\log^{-2}(n+2)$、$\alpha=1/[10\log(n+2)]$，已付粗平滑费用 $T_{\rm soft}/\alpha=O(\sqrt n\log^2(n+2))$；定义与常数见自适应正文。所有递推可以改用完整新 $F_{{\rm diff},i}$，每阶段 $A_n$ 增加 $P_{n,p}$。来源限制后重新计算原门、来源块质量和份额。此替换不推断 $I_T(F_{{\rm diff},i})\le I_T(F_i)$；径向假设必须在新完整余集上独立证明。

## 径向预算的条件桥及正确量词

令 $H_n=1+n\log2$，规范硬列 $b(y)=\int_B L_*^{-n}1_{Q_*}(y)dx$。点态 $b\le H_n$，而 $D=\lambda|B|\le H_nW$。令 $u=\log\max(1,2\|x-y\|_\infty)$，$I_T=\int_{b>T}\operatorname{Var}(u\mid y)d\mu$。第85轮已证明

$$\int(b-T)_+^2d\mu\le24n^2I_T+48D/T,\qquad T\ge2.$$

取输入无关 $R_n\ge0$ 与

$$T_n=\max\{2,\sqrt{192R_nn},(384H_n)^{1/3}\}.$$

若对每个当前输入与阈值的**完整原中间、粗平滑低分支** $F_i$ 均有 $I_{T_n}(F_i)\le R_nW_i/n$，则当前行 $B_i\subset F_i$ 的 $q_{B_i}\le q_{F_i}\le b_{F_i}$，集合 $S_i=\{q_{B_i}>2T_n\}$ 满足 $\mu_i(S_i)\le W_i/4$。径向预算只应用于完整 $F_i$，尾集通过点态列支配比较；实际删除与递推仍只使用当前行的列。条件方差 $I_T$ 不对接收子集单调，不能把只对完整事件的假设套给任意 $B_i$。

使用 $\alpha=\varepsilon=1/[10\log(n+2)]$、$c=1-\alpha-\varepsilon>0.85$、$\delta=1/2$、$\beta=c/2$ 与 $\rho=1/4$，该条件给出窗口费用 $O(\sqrt n\log^2(n+2)+\sqrt{nR_n})$，全尺度另付既有对数。**尚未证明上述统一径向假设。**小维数若 $T_n\ge H_n$，径向过滤集自动为空；实际删除集甚至在 $2T_n\ge H_n$ 时便已为空。这些只是无效检验区间，不是支持渐近径向预算的证据。

## 对第85轮递推几何警告的限定修正

一般任意来源限制后新立方体不保证属于原图；但第85轮的特定坏行递推有更强结构。坏行在旧边长 $L_i$ 已为子输入提供超过新阈值 $\lambda_{i+1}=\beta\lambda_i$ 的严格见证。若该接收点仍进入下一轮保留事件，新锚点低于新阈值，连续性与最早接触给出 $L_{i+1}<L_i$。因此沿同一持续保留接收点，立方体实际严格嵌套。本轮修正此前对此限定情形过宽的警告。

嵌套只控制几何支持；回到初始阈值还需支付 $\beta^{-i}$，重复异常分支、完整事件辅助列与当前残余行也不可混同。不能据此直接宣称原图容量或全局平方根费用已经成立。本轮还证明实际初始行后验下的几何密度放大均值至多 $H_n$，以及下有界几何势能的有限望远镜账。将来源条件径向方差纳入势能后，仍留下一个非负阈值放大误差 $U_i$；其带权总和未被控制。次临界来源存活矩有界，临界阈值补偿则恰好取消该存活尾，不能用前者替换后者。

## 共同来源行对及文献工具的边界

对同一来源下的两个实际捕获行，中心距离不超过边长差的固定比例时，较小立方体包含于较大行的真实较早同心立方体。首次接触支付这一近中心部分，得到

$$\int(b-T)_+^2d\mu\le12n^2\mathcal E_{T,a}
 +\frac{96D}{T(1-a)^2}.$$

空间分离的剩余行对能量 $\mathcal E_{T,a}$ 尚无统一上界。两条硬前缀约束的线性规划可以精确达到平凡交叠上限；该限制性反例仅涉及两个接收点，不具备完整平滑门、中间条件或正接收体积，不能当作弱型反例。

新核验的 Hardy 原文仅在实际径向后验无原子、密度及逆密度满足明确条件时给出方差的阻抗上界。实际截断径向变量可有原子与空环，尚无付费迁移。Carleson 原文所需整树检验、抵消和维数常数仍不能省略。

## 证据与公开边界

每条重要策略分初探、已知反例压力、扩大参数三阶段；精确有理证书、数值求积和一般证明分别标注。实际压力来源配方及用户未发表下界仅保留本地，不公开。64项技能入口完整性快照不代表所有来源定理已认证；本轮仅使用实际阅读并核验其假设的工具。LaTeX只静态核验，不编译PDF。


## 1. Exact setting and result

Let \(n\ge2\), \(d\mu=f\,dy\), \(0\le f\in L^1(\mathbb R^n)\), \(0<W=\mu(\mathbb R^n)<\infty\), and \(\lambda>0\). Let \(B\) be a measurable set with a measurable full-side selector \(L(x)\in[1,2]\) satisfying the actual contact identity
\[
 \mu(Q_x)=\lambda L(x)^n,\qquad Q_x=x+[-L(x)/2,L(x)/2]^n. \tag{1}
\]
All assertions are insensitive to null sets. No earlier-scale condition is required for the new packet estimate. In particular it applies to any measurable subset of the actual first-contact coarse-low residual, including that whole residual. Source marginals are absolutely continuous; coordinate independence is never assumed.

Partition the source into countably many disjoint measurable packets \(S_j\), each contained in a cube centered at \(c_j\) of full side \(\varepsilon\le1/(16n^2)\). Discard zero-mass packets. Put \(\mu_j=\mu|_{S_j}\), \(W_j=\mu(S_j)\). Such a partition exists by a fixed half-open grid. For \(0<a\le1\), define
\[
 p_j(x)=\frac{\mu_j(Q_x)}{\lambda L(x)^n},\qquad
 \eta_a(x)=\sum_{j:p_j(x)\ge a}p_j(x). \tag{2}
\]
Thus \(\sum_jp_j=1\). Measurability follows from Tonelli and countable summation. For \(y\in S_j\), define the column of traffic for which its own packet has share at least \(a\):
\[
 g(y)=\int_B L(x)^{-n}\mathbf1_{Q_x}(y)
                 \mathbf1_{\{p_j(x)\ge a\}}\,dx. \tag{3}
\]
Write \(H_n=1+n\log2\), \(C_a=3+3\log(1/a)\). Then
\[
 \mu\{g>K\}\le2e^{-(K-C_a)/4}W \quad(K\in\mathbb R). \tag{4}
\]
For every \(0<\rho\le1\), put
\[
 K_{a,\rho}=C_a+4\log(4H_n/\rho),\qquad
 P_{n,a,\rho}=1+\frac{2K_{a,\rho}}\rho.
\]
The actual Lebesgue receiver stratum obeys the unconditional estimate
\[
 \boxed{\quad\lambda|\{x\in B:\eta_a(x)\ge\rho\}|
          \le P_{n,a,\rho}W.\quad} \tag{5}
\]
There is no factor depending on the number of packets or on a layer count. This is an estimate on a concrete branch of arbitrary common-source contact data, not an assumption about the desired radial variance.

## 2. Marginal ranks and geometric column bound

Translate one packet center to zero. Let
\[
 G_{i,+}(s)=\mu_j\{z:z_i\ge s\},\qquad
 G_{i,-}(s)=\mu_j\{z:z_i\le s\},\qquad
 Z_j(y)=\frac1{2n}\sum_{i=1}^n\sum_{\pm}
                   \log\frac{W_j}{G_{i,\pm}(y_i)}.
\]
The exceptional zero tails have \(\mu_j\)-measure zero. Under \(\mu_j/W_j\), each normalized marginal rank \(G_{i,\pm}(Y_i)/W_j\) is uniform on \((0,1)\). Convexity of the exponential, with no independence, gives
\[
 \mathbb E_{\mu_j/W_j}e^{Z_j/2}
 \le\frac1{2n}\sum_{i,\pm}\mathbb E
       (W_j/G_{i,\pm}(Y_i))^{1/2}=2. \tag{6}
\]
We prove the pointwise estimate
\[
                         g(y)\le2Z_j(y)+C_a. \tag{7}
\]
All radii in this proof are relative to the PACKET CENTER: \(r=2\|x\|_\infty\).

First consider rows capturing the whole packet, in the measure sense \(\mu_j(Q_x)=W_j\). Contact and \(p_j\ge a\) imply
\(W_j\le\lambda L^n\le W_j/a\). The selected sides therefore lie in one interval of side ratio at most \(a^{-1/n}\). For any interval \([\ell,v]\), the source-centered kernel envelope has exact integral
\[
 \int_{\mathbb R^n}\sup_{s\in[\ell,v]}
 s^{-n}\mathbf1_{\{2\|x-y\|_\infty\le s\}}\,dx
 =1+n\log(v/\ell). \tag{8}
\]
Indeed the inner cube contributes one and the radial shell contributes \(n\int_\ell^v dr/r\). Clipping the interval to \([1,2]\) only helps. Hence the full-capture part costs at most \(1+\log(1/a)\).

For the remaining rows, capture of \(y\) implies \(L\ge r-\varepsilon\). Partial capture \(\mu_j(Q_x)<W_j\) implies \(L<r+\varepsilon\), because a side at least \(r+\varepsilon\) covers the entire packet's bounding cube. Thus
\[
                           |L-r|\le\varepsilon. \tag{9}
\]
The part \(r\le1+\varepsilon\) costs at most \((1+\varepsilon)^n\le C_\varepsilon\), where \(C_\varepsilon=e^{n\varepsilon}\), since \(L^{-n}\le1\).

For \(r>1+\varepsilon\), separate unique-face cones from near ties. In the cone with \(x_i=r/2\) and \(2|x_k|<r-2\varepsilon\) for every \(k\ne i\), all transverse coordinates of the bounding cube are captured: \(|x_k|+\varepsilon/2<(r-\varepsilon)/2\le L/2\). The longitudinal far face also covers the whole packet, and capture is exactly the half-space condition \(z_i\ge(r-L)/2\). Its mass is \(G_{i,+}((r-L)/2)\). Since \(y\) is captured, contact and dominance imply
\[
 G_{i,+}(y_i)\le\mu_j(Q_x)\le\lambda L^n\le W_j/a. \tag{10}
\]
The negative cone uses \(G_{i,-}\) and has the same bounds.

For the appropriate tail \(G=G_{i,\pm}(y_i)\), define
\(\ell=\max(1,(G/\lambda)^{1/n})\) and
\(v=\min(2,(W_j/(a\lambda))^{1/n})\). The cone is empty unless \(\ell\le v\). Otherwise selected rows lie in \(r\in[\ell-\varepsilon,v+\varepsilon]\), with \(r>1+\varepsilon\). This is interval containment, not a monotonicity or differentiability assertion about \(L\) as a function of \(r\).

At fixed positive or negative face the radial volume element is at most \(\tfrac12r^{n-1}dr\). Since \(L\ge r-\varepsilon\) and \(r>1+\varepsilon\),
\[
 r^{n-1}(r-\varepsilon)^{-n}\le C_\varepsilon/r.
\]
For \(\varepsilon\le1/4\),
\[
 \log\frac{v+\varepsilon}{\ell-\varepsilon}
 \le\log(v/\ell)+3\varepsilon
 \le\frac1n\log\frac{W_j}{aG}+3\varepsilon.
\]
Summing over \(2n\) cones bounds their contribution by
\[
 C_\varepsilon\bigl[Z_j(y)+\log(1/a)+3n\varepsilon\bigr]. \tag{11}
\]
For near ties, at a fixed maximal coordinate and sign the fraction of transverse coordinates having some \(2|x_k|\ge r-2\varepsilon\) is at most \(2(n-1)\varepsilon/r\). The full polar density is \(nr^{n-1}dr\), so the near-tie part is bounded by
\[
 2n(n-1)\varepsilon C_\varepsilon
       \int_{1+\varepsilon}^{2+\varepsilon}r^{-2}dr
 \le2n(n-1)\varepsilon C_\varepsilon. \tag{12}
\]
Ties themselves have zero receiver measure. Combining the four pieces gives
\[
 g(y)\le C_\varepsilon Z_j(y)
 +1+C_\varepsilon[1+(2n^2+n)\varepsilon]
 +(1+C_\varepsilon)\log(1/a).
\]
Here \(C_\varepsilon\le e^{1/32}\le32/31<2\),
\((2n^2+n)\varepsilon\le5/32\), and
\(1+(32/31)(37/32)=68/31<3\). This proves (7). Markov applied to (6) gives the packetwise version of (4); summing \(W_j\) proves (4) with no packet-count loss.

## 3. Paying the dominant branch with the actual common source

Set \(K=K_{a,\rho}\), \(S=\{g>K\}\). Equation (4) gives
\(\mu(S)\le\rho W/(2H_n)\). Let \(R=\{x\in B:\eta_a(x)\ge\rho\}\).
For rows in \(R\) whose TOTAL captured source mass in \(S\) is at most \((\rho/2)\lambda L^n\), the captured dominant-packet mass outside \(S\) is at least \((\rho/2)\lambda L^n\). Integrating this restricted mass with the actual hard kernel and applying Tonelli gives
\[
 (\rho/2)\lambda|R_{\rm good}|
 \le\int_{S^c}g\,d\mu\le KW.
\]
For every other row, \(A_{L(x)}(f\mathbf1_S)(x)>(\rho/2)\lambda\). The elementary whole-window kernel envelope (8) with \([1,2]\) gives
\[
 \lambda|R_{\rm bad}|
 \le(2H_n/\rho)\mu(S)\le W.
\]
Adding proves (5). The restricted input is used only in the full-window maximal estimate: no old contact, smooth gate or layer label is claimed to survive source restriction. This proof keeps all actual source mass and all actual receiver measure; it does not replace them by a finite graph.

### 3.1. Every measurable Hall cut of this branch

In fact, with the same constants, for EVERY measurable \(A\subset R=\{x\in B:\eta_a(x)\ge\rho\}\),
\[
 \lambda|A|\le P_{n,a,\rho}\,\mu(N_A),\qquad
 N_A=\{y:b_A(y)>0\},\quad
 b_A(y)=\int_A L(x)^{-n}\mathbf1_{Q_x}(y)dx. \tag{17}
\]
Here \(N_A\) is the measurable essential source neighborhood. The ordinary union of selected cubes, whenever measurable, contains this neighborhood and obeys the same upper bound with its (possibly larger) mass.

To prove (17), Tonelli gives
\(\int_A L^{-n}\mu(Q_x\setminus N_A)dx=0\).
Hence for almost every receiver in \(A\), restricting the source to \(N_A\) preserves the contact identity and, simultaneously for all countably many packets, every captured packet mass. Thus all \(p_j\) and \(\eta_a\) are unchanged there. The restricted input remains \(L^1\), and the packets \(S_j\cap N_A\) retain their containing cubes. Apply (5) to this new input and receiver set \(A\), using its new marginal ranks. If \(\mu(N_A)=0\), contact and Tonelli instead give \(|A|=0\) directly. No first-contact or smooth gate is needed by (5), so their possible failure after source restriction causes no gap. No maximizing cut or attained continuum transport is asserted.

As a useful quantitative subclass, suppose EVERY row in \(B\) captures positive mass from at most \(N\) packets, where the integer \(N\ge1\) is fixed. Taking \(a=1/(2N)\), \(\rho=1/2\), the total subthreshold share is at most \(1/2\). Hence \(R=B\) and every measurable cut has Hall fee
\[
 P_N=1+4[3+3\log(2N)+4\log(8H_n)]
                 =O(\log(N+1)+\log(n+2)). \tag{18}
\]
The condition is local packet count, not coordinate independence or a bound on the total number of packets. It is an explicit subclass statement, not a bound on packet count for arbitrary sources.

## 4. Precise remaining residual and fees

Fix \(p>0\), choose \(a=n^{-p}\) and \(\rho=n^{-1/2}\), and let \(F\) be the WHOLE actual coarse-low residual for the current input and threshold, with its current first-contact selector. Choose any source partition as above, once for this input. Decompose
\[
 F_{\rm dom}=\{x\in F:\eta_{n^{-p}}(x)\ge n^{-1/2}\},\qquad
 F_{\rm diff}=F\setminus F_{\rm dom}. \tag{13}
\]
The first branch costs
\[
 P_{n,p}=1+2\sqrt n\,[3+3p\log n+4\log(4H_n\sqrt n)]
             =O_p(\sqrt n\log(n+2)). \tag{14}
\]
On every row of the remaining branch, more than \(1-n^{-1/2}\) of the captured source mass comes from packets with individual share below \(n^{-p}\). In particular the number of packets meeting that diffuse mass is greater than \((1-n^{-1/2})n^p\) when finite. This assertion concerns the chosen physical source partition and is not invariant under arbitrary refinement. It does not by itself imply concentration or a radial variance gain.

A recursion may now run its stopped kernel on \(F_{\rm diff}\) afresh. Its canonical column and \(I_T\) must be recomputed using that receiver set; normalized conditional variance is not subset-monotone. At each reselected input the paid constant \(A_n\) increases by \(P_{n,p}\); the adaptive contraction statement is otherwise unchanged. The unresolved sufficient target can consequently be restricted to
\[
 I_T(F_{\rm diff})\le R_nW/n
\]
for EVERY current positive \(L^1\) input, threshold, whole selected diffuse residual and the specified permitted choice of its source partition. A theorem asserting existence of a useful partition must supply it; a fixed grid can instead be specified. No such bound has been proved here. The new result is the unconditional payment (5), not this displayed open target.

The estimate (5) applies directly to a whole union of original background layers, so it incurs no \(J_n\) factor. If used separately and summed over layers it incurs that factor. The established all-scale return has its additional logarithmic fee. Source packets are a spatial partition, not an asserted nested receiver tree; neither generic Bellman nor generic near-extremizer rigidity is used.

## 5. Correct subset-to-whole pressure transfer

For auditing future actual pressure tests, fix \(T>0\) and let \(E\) be one whole contact residual and \(B\subset E\) retain exactly the same selector. For each source \(y\), put
\(\beta_y(dx)=L(x)^{-n}\mathbf1_{Q_x}(y)dx\),
\(u=\log\max(1,2\|x-y\|_\infty)\), and let \(b_B,b_E\) be the restricted masses. The envelope gives \(b_E\le H_n\). Variance energy is monotone under addition of a positive measure because it is \(\inf_c\int(u-c)^2d\beta\). Therefore
\[
 I_T(E)\ge\int_{b_B>T}\frac{b_B}{b_E}\operatorname{Var}_B(u\mid y)d\mu
          \ge(T/H_n)I_T(B). \tag{15}
\]
Zero columns contribute zero. This is a dilution inequality, not monotonicity of normalized variance.

If actual receiver subsets \(A,C\subset E\) have disjoint log-side bands separated by \(h\), the pair formula for variance gives
\(\operatorname{Var}_E(t\mid y)\ge h^2b_A b_C/b_E^2\).
For a measurable source set \(S\subset\{b_A+b_C>T\}\) with \(b_E\le U\) there, the actual first-contact age estimate from R85 implies
\[
 I_T(E)\ge\frac{h^2}{2U^2}\int_S b_A b_C\,d\mu
                       -\frac{2D_E}{Tn^2}. \tag{16}
\]
Indeed \(\operatorname{Var}(u)\ge\operatorname{Var}(t)/2-\mathbb E(r^2\mid y)\), and \(\int b_E\mathbb E(r^2\mid y)d\mu\le2D_E/n^2\). If instead actual radial bands of \(u\) are separated by \(h_u\) uniformly on \(S\), the direct bound is \(h_u^2U^{-2}\int_Sb_Ab_Cd\mu\), with no age subtraction. These tests require the same physical source and the same selector; receiver-only scale histograms do not suffice.

## 6. Verification and limitation

The new packet theorem was sent as an exact statement to both independent auditors before this proof was written. Both subsequently read the full geometric and payment proof and returned PASS. The independent scalar guard passed three ranges: pilot dimensions 2, 3, 4; correlated-rank pressure dimensions 8, 32, 256; and enlarged dimension 4096. It includes 63 packet coefficient/tail/payment checks and 765 dependent marginal-rank Jensen checks, plus 21 variance-production and 21 common-source CDF checks. These are nonphysical algebraic models; the actual common-source theorem is justified by the proof, not by a numerical fit. Actual high-load searches are coordinated with the Hall and flux owners, without duplicate scans. Finite successful tests cannot establish the missing all-input diffuse-residual bound. In particular broad scale variance at bounded or root-sized canonical load need not survive the candidate high-load cutoff. No fully qualified counterexample to the filtered target is claimed.

## 1. Objects and a necessary correction to the radial bridge

The general centered-cube square-root-order bound remains **unproved**. Let Q(x,L)=x+[-L/2,L/2]^n, 1<=L<=2, mu=f dy, W=||f||1, and H_n=1+n log 2. The retained full-window hard envelope gives both b_B(y)<=H_n for every actual selected receiver subset B and lambda|{M_[1,2]f>lambda}|<=H_n W. All demands below use Lebesgue receivers and the actual threshold.

For each current input f_i and threshold lambda_i, let F_i be its **whole** original R82 middle event after the new coarse-high deletion. It includes the original anchor, whole-window original E2 gate, strict hard witness, original middle cutoff, and the selected coarse-low gate. Use

    theta=log^-2(n+2), alpha=epsilon=1/[10 log(n+2)],
    c=1-alpha-epsilon, delta=1/2, beta=c/2, n>=2.

Thus beta>0.425. Let L_i be the actual earliest hard contact on F_i. Define canonical b_i, radial u_i(x,y)=log max(1,2||x-y||infty), conditional variance and

    I_i(T)=integral_{b_i>T} Var(u_i|y) dmu_i

using **all F_i**, not merely the current surviving receiver subset. The radial variable itself does not depend on the selector; its captured fibre and conditional distribution do. At this stage the positive stopped kernel k_i satisfies 0<=k_i<=L_i^-n 1_Qi and c lambda_i<d_i=integral k_i dmu_i<=(1-epsilon)lambda_i. Write q_i^F(y)=integral_{F_i}k_i(x,y)dx<=b_i(y).

Let R_i be the current strict hard-witness receiver set and B_i=R_i intersect F_i. Use the actual current column q_i(y)=integral_{B_i}k_i(x,y)dx and the source set S_i={q_i>2T}. Since q_i<=q_i^F<=b_i, the whole-event radial estimate controls this smaller actual tail. The local split gives good-row cost

    G mu_i(S_i^c),  G=4T/c.

The bad rows R_(i+1) have a strict hard witness at their old selected side for f_(i+1)=f_i1_(S_i), at lambda_(i+1)=beta lambda_i. Recompute every original gate on this new input. The paid coefficient at every stage is

    A=Bbase+Bext+Tsoft/alpha,
    Bbase=4+2 log 2 sqrt(7n/3), Bext=2H_n/sqrt(n+2),
    Tsoft=1+log 2 min(2n,sqrt(n(theta^-1+4theta/3))).       (1)

If the separate R83 union is used, add its Bext fee at every stage where it is used. No hidden kappa sum is present: F_i is the whole middle residual. A layerwise variant must separately pay its layer count and overlaps.

This whole-F radial comparison is essential if the hypothesis is assumed only for whole coarse-low events. Conditional variance is not subset-monotone, so a bound for F_i cannot simply be applied to B_i. The construction uses only q_(B_i)<=q_(F_i), which is pointwise valid. Enlarging S_i to the whole-F source tail would also be legal but needlessly retains sources irrelevant to the current receivers; that alternate algorithm is not used here.

## 2. Independently checked pointwise radial bridge

The retained radial estimate, applied to the whole F_i, states for T>=2:

    integral (b_i-T)_+^2 dmu_i <=24n^2 I_i(T)+48D_i/T,
    D_i=lambda_i|F_i|<=H_n W_i.

Since q_i>2T implies b_i>2T, it follows that

    W_(i+1)<=a I_i(T)+h W_i,
    a=24n^2/T^2, h=48H_n/T^3.                           (2)

There is no assumption that q_i or I_i is preserved by input restriction. If, independently and at every reselected input, I_i(T)<=R W_i/n, then

    T=max(2,sqrt(192Rn),(384H_n)^(1/3))                  (3)

gives W_(i+1)<=W_i/4. The first contribution is at most W_i/8, including the zero-R case by direct interpretation; the second is at most W_i/8. The R85 finite ledger therefore yields

    lambda_0|R_0| <= [A+(3/4)G]/[1-1/(4beta)] W_0.       (4)

Consequently the conditional window fee is O(sqrt(n)log^2(n+2)+sqrt(nR)); the retained all-scale return adds C_loc log(n+2). This is a correct conditional interface, not a proof of its radial premise. When T>=H_n/2 the strict set S_i is empty by q_i<=H_n; low-dimensional examples in that range do not test a nontrivial tail mechanism.

## 3. New actual geometry: persistent earliest-contact cubes are nested

**Nested-contact lemma.** For any receiver x belonging to B_i and B_(i+1),

    L_(i+1)(x)<L_i(x),  Q_(i+1)(x) subset Q_i(x).        (5)

Indeed the old bad-row inequality is strict:

    A_(L_i(x))(f_(i+1))(x)>lambda_(i+1).

The next retained anchor gives A_1 f_(i+1)<lambda_(i+1)/2. The hard average is continuous in L for an L1 input. Hence it reaches lambda_(i+1) at some side strictly between 1 and L_i; its earliest contact is no later than that side. This proves (5). Also B_(i+1) subset B_i, because the next current receivers are old bad rows. No regularity of x -> L_i(x) beyond measurability is used.

This corrects an overly broad warning in R85: arbitrary input reselection need not preserve the old capture graph, but the exact bad-row recursion above does preserve it on persistent retained receivers. Thus a later **good-row** allocation is supported inside that receiver's original cube. This does not automatically produce a full original-graph Hall allocation: the repeated threshold weights and the paid exception receivers still require their own valid capacities/allocations.

Let Z_0 be the full source space and Z_i=intersection_(j<i)S_j, so f_i=f_0 1_(Z_i). For a receiver surviving stages 0,...,m define

    E_i(x)=Z_i intersect Q_i(x),  t_i=beta^-i.

These sets are nested and satisfy the exact physical source identity

    mu_0(E_i)=lambda_i L_i^n,
    mu_0(E_i)/mu_0(E_0)=beta^i(L_i/L_0)^n.              (6)

The selected hard averages, not an abstract branching model, establish (6).

If Y has the initial captured posterior mu_0|E_0 / mu_0(E_0), then for every finite m and every 0<=p<1,

    sum_(i=0)^m beta^(-pi) P(Y in E_i)
       <=1/[1-beta^(1-p)].                             (7)

At the critical exponent actually used by the receiver fee,

    sum_(i=0)^m beta^-i P(Y in E_i)
       =sum_(i=0)^m(L_i/L_0)^n >=(m+1)2^-n.            (8)

Thus rowwise survival has a genuine geometric tail, but its critical threshold compensation cancels that tail. The finite total side-length descent alone cannot bound (8) independently of persistent depth. This does not assert that arbitrarily long chains occur under the actual high-q rule and all new gates; proving a depth restriction would be additional geometry. It precisely identifies why a subcritical row-lifetime estimate cannot be substituted for the needed critical occupation estimate.

For a source y still captured at the last stage, geometric hard-density amplification telescopes to (L_0/L_m)^n<=exp(n r_0), where r_0=log L_0-u(x,y). Under the initial captured row posterior the retained first-contact tail gives P(r_0>h)<=e^(-nh). Therefore

    E[exp(n r_0)]
      =1+integral_0^(log L_0) n exp(nh)P(r_0>h)dh
      <=1+n log L_0<=H_n.                              (8a)

This replaces an exponential pointwise bound by a linear average under the initial posterior. It is not a uniform source-column bound, and conditioning on a late retained source set changes that posterior. No such conditioning is free.

## 4. A finite lower-bounded potential that really pays geometric inflation

For every transition between current retained sets define the unweighted-in-threshold kernel inflation

    J_i=integral_{B_(i+1)} integral 1_(Q_(i+1))(y)
          [L_(i+1)^(-n)-L_i^(-n)] dmu_(i+1)(y) dx.

By (5), J_i>=0. The next exact contact gives

    t_(i+1)J_i=lambda_0 integral_{B_(i+1)}
                   [1-(L_(i+1)/L_i)^n]dx.              (9)

There is an explicit finite nonnegative potential

    P_i=n lambda_0 integral_{B_i} log L_i(x) dx >=0.

Since 1-e^-z<=z, B_(i+1) subset B_i and log L_i>=0,

    t_(i+1)J_i <= P_i-P_(i+1),
    sum_(i<m)t_(i+1)J_i <=P_0-P_m
                          <=n log 2 lambda_0|B_0|.      (10)

This is an actual Bellman/finite telescoping estimate, with lower potential bound zero and error identically zero. It permits arbitrary nonuniform scale descent and arbitrary source-mass ratios. It is not inferred from naming a tree. Source restriction is already present in J_i through mu_(i+1), and receiver dropout only helps the potential inequality.

Its limitation is exact. Changing t_i to t_(i+1) also produces the separate positive threshold-amplification term

    U_i=(t_(i+1)-t_i) integral_{B_(i+1)}
                         L_i^-n mu_(i+1)(Q_(i+1)) dx
       =(1-beta)lambda_0 integral_{B_(i+1)}
                            (L_(i+1)/L_i)^n dx.        (11)

In particular U_i>=(1-beta)2^-n lambda_0|B_(i+1)|. The potential (10) does not pay (11). Moreover (10) costs O(n) times the still-unpaid original receiver demand, not O(sqrt(n)polylog(n)) times W_0. Finally, the whole F_i used in the radial tail can contain newly appearing receivers outside the nested B_i. No nesting theorem for B_i controls those extra fibres. Therefore (10) cannot be promoted to an amortized bound for sum t_i I_i without a new argument controlling threshold amplification, common-source sharing and the whole-event fibres.

### 4A. Actual radial variance production and its explicit error

The same geometry gives a finite radial potential with an exact remaining error. Use the common source measure mu_0 and define the threshold-weighted capture measure

    Gamma_i(dx,dy)=t_i 1_(Z_i)(y)L_i(x)^(-n)
                         1_(B_i)(x)1_(Q_i(x))(y) dx mu_0(dy).

For any such measure with density g(x,y) relative to dx mu_0(dy), let

    V(Gamma)=integral [inf_(a in [0,log2])
                        integral (u(x,y)-a)^2 g(x,y)dx] dmu_0(y).

The minimizing mean is measurable on nonzero fibres; set it to zero on zero fibres. This unnormalized conditional variance is monotone under addition of a positive measure. It is finite here, with V_i=V(Gamma_i)<=((log2)^2/4)lambda_0|B_i|.

Restrict Gamma_i to B_(i+1), Z_(i+1) and Q_(i+1) to obtain Gamma_i^ret. Then Gamma_i^ret<=Gamma_i and Gamma_(i+1)-Gamma_i^ret is positive. Define the actual variance loss

    ell_i=V_i-V(Gamma_i^ret)>=0.

The added measure has total mass exactly U_i+t_(i+1)J_i. Using the retained fibre mean, which lies in [0,log2], in the next variance minimization proves

    V_(i+1)<=V_i-ell_i+(log2)^2[U_i+t_(i+1)J_i].        (11a)

This argument also covers a zero retained fibre by the stated choice of center. No claimed martingale or independence is needed. Combining (11a) with (10), the nonnegative finite potential

    mathcal P_i=V_i+(log2)^2 P_i

satisfies the exact-sign descent inequality

    mathcal P_(i+1)<=mathcal P_i-ell_i+(log2)^2 U_i,
    mathcal P_m+sum_(i<m)ell_i
                  <=mathcal P_0+(log2)^2sum_(i<m)U_i.   (11b)

Its initial value is at most [(log2)^2/4+n(log2)^3]lambda_0|B_0|, and its lower bound is zero. Thus the N04 finite potential and error accounting can be implemented on the actual nested source/receiver sets. The remaining error is explicitly the threshold amplification (11); its sum has not been bounded.

The retained measure has at most beta times the old mass on each surviving receiver row, but this does not by itself imply ell_i>=(1-beta)V_i: the loss is a source-fibre variance quantity, not a row marginal mass. An energy-weighted deletion inequality would need an independent proof. No abstract failure of that inference is asserted to be an actual gated high-load counterexample.

For the current subset radial statistic, t_i I_T(B_i)<=V_i/T. This bounds a single statistic by a potential value, not by its decrement. Even bounded nonincreasing potential values do not imply their sum is finite. In addition, the required forcing I_i(T) uses the whole F_i, not B_i. Consequently (11b) does not prove a summed radial budget. It locates two exact missing steps: control of the threshold-error sum and a mechanism converting remaining high-load variance to paid potential loss, with the whole-event fibres covered.

## 5. A strictly more flexible radial occupation interface, with all terminal costs

A useful conditional alternative to uniform per-stage radial bounds is

    sum_(i<m) beta^-i I_i(T) <= J W_0/n
          for every finite m,                         (12)

on the actual whole-event sequence above. This asks for a geometric radial occupation budget, not for the desired receiver measure bound itself. It remains **unproved**. It permits individual stages with no source contraction, and does not require a uniform bound on I_i/W_i.

Here is its exact consequence. Suppose h<beta in (2), set v_i=beta^-i W_i and j_i=beta^-i I_i. Then

    beta v_(i+1)<=h v_i+a j_i,
    (beta-h)sum_(i<m)v_i+beta v_m
              <=beta W_0+a sum_(i<m)j_i.               (13)

Under (12), the nonnegative series Omega=sum_(i>=0)v_i converges and

    Omega<=[beta+aJ/n]/[beta-h] W_0,
    v_m -> 0.                                         (14)

Both statements follow from the finite identity (13), not an assumed stopping limit. The exact finite R85 ledger is

    lambda_0|R_0|<=sum_(i<m)[A v_i+G beta^-i(W_i-W_(i+1))]
                       +H_n v_m.

The terminal cost vanishes by (14), while summation by parts gives

    sum_(i>=0)beta^-i(W_i-W_(i+1))
                       =beta W_0+(1-beta)Omega.

Hence the full conditional bound is

    lambda_0|R_0| <= {G beta+
       [A+G(1-beta)] [beta+aJ/n]/[beta-h]} W_0.          (15)

For example, if (12) holds at

    T>=max(2,(96H_n/beta)^(1/3),sqrt(48nJ/beta)),

then h<=beta/2 and aJ/n<=beta/2, so Omega<=3W_0 and the fee is at most [3A+(3-2beta)G]W_0. Uniform per-stage contraction is unnecessary. The parameter choice still requires (12) at that same T; it cannot be selected after testing a different radial filter.

The logical gain is a precise alternative geometry budget, not a newly proved dimension estimate. The initial pointwise hypothesis plus its induced contraction implies a bound of form (12). Conversely a finite weighted radial budget places no uniform smallness requirement on a single stage: a finite amount may concentrate there, with later stages terminating. This is a strict flexibility gain at the scalar-budget level. A strict separation between the two premises on the class of fully qualified actual high-load inputs has not been proved; no geometric realization of an arbitrary scalar sequence is asserted.

## 6. Scope, evidence and the next required inequality

The new unconditional statements are (5)--(11b): actual nested capture sets, exact row survivor masses, all subcritical row occupation bounds, the critical identity, a zero-error geometric inflation potential, and an actual radial variance-production ledger with its explicit threshold error. Their hypotheses are the actual recursive gates and strict old-cube witness. They do not use a stochastic process representation, finite graph substitute or unverified source theorem.

The N04 and E03 skills were read with their cube-interface conditions. Both potentials above are explicitly finite and bounded below by zero. The geometric potential has zero error; the combined radial potential retains the nonnegative threshold error in (11b) without assuming its sum is bounded. No source Bellman theorem is invoked outside its original tree hypotheses. Conditional interfaces (3)--(4) and (12)--(15) retain all branch, source-repetition and terminal costs. Independent auditors receive each precise statement before reading its proof. Numerical pressure is separately owned and must use the new coarse-low residual; the old small-load fixture deleted by the stronger coarse branch is not a counterexample here. Private recipes are excluded from this extraction.

Both independent auditors passed the full mathematical and Markdown/TeX consistency reads through (11b) and (15). Author-side exact rational checks covered 32 finite variance-energy cases, including zero fibres, and three nonuniform forcing recurrences; the independent Sol guard checked 27 further nonuniform scalar recurrence models. These are algebra and bookkeeping checks, not certified actual high-load examples. Static source checks passed; no TeX compilation was performed. New actual residual pressure remains separately reported by the numeric owners.

The remaining task is to establish (12), another summable source-occupation budget, or an actual restriction on critical surviving depth using the common-source high-load geometry. The proven geometric potential alone cannot do this: it has the wrong payment measure and leaves (11) unpaid. The whole-event/subset distinction also prevents transferring a nested-current-row variance budget to the whole F_i by monotonicity. The general square-root-order goal remains unproved.

## 7. Addendum: the paid dominant-packet branch and the exact diffuse recursion

The general packet payment proved in the companion coverage text gives an additional unconditional reduction. Fix p>0 and a half-open source grid of full side epsilon_pkt<=1/(16n^2). Use this same geometric partition {C_j} at every stage, with current measures mu_(i,j)=mu_i restricted to C_j; discard their zero-mass members. Define

    a_pkt=n^-p, rho_pkt=n^-1/2,
    p_(i,j)(x)=mu_(i,j)(Q_i(x))/(lambda_i L_i(x)^n),
    eta_i(x)=sum_{j:p_(i,j)(x)>=a_pkt}p_(i,j)(x),
    K_pkt=3+3 log(1/a_pkt)+4 log(4H_n/rho_pkt),
    C_dom=1+2K_pkt/rho_pkt=O_p(sqrt(n)log(n+2)).          (16)

The packet theorem applies to arbitrary actual contact data, so it pays lambda_i|{x in F_i:eta_i(x)>=rho_pkt}|<=C_dom W_i without an additional gate or layer assumption. Its proof uses the same physical source partition: correlated marginal ranks give the packet column tail, good rows retain at least rho_pkt/2 dominant capture, and the complementary rows are paid by the full-window H_n estimate. The restricted source used inside that payment is not substituted into this recursion.

For the augmented algorithm, use the **whole new residual**

    F_i^diff={x in F_i:eta_i(x)<rho_pkt},
    B_i=R_i intersect F_i^diff,
    A^+=A+C_dom.                                       (17)

This is a receiver branch deletion on the current input. Its original earliest contact L_i(x), original hard cube and captured stopped kernel are unchanged at retained receivers. Define the new canonical column b_i^diff and radial conditional variance on all F_i^diff, and use

    I_i^diff(T)=integral_{b_i^diff>T} Var_(F_i^diff)(u|y)dmu_i,
    q_i=int_(B_i) k_i dx, S_i={q_i>2T},
    q_i<=q_(F_i^diff)<=b_i^diff.                        (18)

The radial tail estimate therefore applies with I_i^diff, while the source filter remains the actual current-subset filter. Equations (2)--(15) hold for this augmented sequence after replacing I_i by I_i^diff and A by A^+. In particular the uniform premise and the alternative cumulative premise are now, respectively,

    I_i^diff(T)<=R W_i/n at EVERY current stage,
    sum_(i<m)beta^-i I_i^diff(T)<=J W_0/n for EVERY m.    (19)

They are quantified for the specified fixed grid and every newly restricted positive L1 input and threshold. Neither follows from subset monotonicity or from a claimed inheritance of the old radial bound. The stopped constants c,beta,G and the finite terminal H_n v_m are unchanged; all repeated branch fees use A^+.

After the actual recursive restriction f_(i+1)=f_i1_(S_i), recompute the earliest contact, all original gates, coarse-low event, packet masses, marginal rank laws, packet shares and eta_(i+1). Keeping the geometric cells fixed does not keep their current masses or shares fixed. Persistent current receivers still have nested contact cubes by (5), since its strict old-cube witness and next anchor are unchanged. The packet theorem is applied to the whole current middle residual, so no kappa-layer count is introduced; the existing all-scale logarithmic return remains due.

This addendum changes the unresolved geometric target to the whole diffuse residual (19). It proves payment of the removed branch, not the diffuse radial budget. The conditional window order is unchanged because A^+=O_p(sqrt(n)log^2(n+2)). The packet parameters and source grid are part of this precise algorithm; no useful partition is assumed to exist without being specified.

The general root-order weak bound remains unproved. This component gives a new estimate for actual common-source pairs. Two receivers with substantially different selected sides can share a source while their centers are close relative to the side difference only by drawing that source from an earlier interior cube of the larger receiver. Original first contact pays this contribution exponentially in dimension. The resulting hinge estimate retains only spatially separated receiver pairs. No estimate for that remaining term is presently proved.

## Actual pair measure

Let the nonnegative integrable input, one source measure $\mu=fdy$, original threshold $\lambda$, retained receiver set $B$, and original selector $L(x)\in[1,2]$ be as in the contract. Put $D=\lambda|B|<\infty$, $H=\log2$, and
\[
k_x(y)=L(x)^{-n}1_{Q(x,L(x))}(y),\quad b(y)=\int_Bk_x(y)dx,\quad t(x)=\log L(x).
\]
The proof uses exact contact $\int k_xd\mu=\lambda$ and the original prefix inequality $\mu(Q(x,s))\le\lambda s^n$ for $1\le s<L(x)$. All original gates remain imposed in applications; they are not changed by this lemma. There is no source deletion, new selector, or separate source copy.

For $b(y)>0$ let $\beta_y(dx)=1_B(x)k_x(y)dx/b(y)$. For $T>0$ use the finite pair measure
\[
 d\Pi_T(y,x,x')=1_{\{b>T\}}\,d\mu(y)\,d\beta_y(x)\,d\beta_y(x').
\]
Conditional independence here defines two samples from this explicitly displayed receiver law. It asserts no independence among source coordinates or among physical receivers. Its total mass is $\mu\{b>T\}\le D/T$.

For $0\le a<1$ define the symmetric near-center event
\[
 C_a=\{2\|x-x'\|_\infty\le a|L(x)-L(x')|\},
 \qquad \psi_a(h)=-\log\bigl[a+(1-a)e^{-h}\bigr].
\]
All sets and kernels are measurable. Density representatives only change product-null sets.

## Near-center exponential overlap

For $0\le h\le H$,
\[
 \Pi_T\bigl(C_a\cap\{|t(x)-t(x')|>h\}\bigr)
 \le {2D\over T}e^{-n\psi_a(h)}.                 \tag{1}
\]
The right side can additionally be truncated at the total pair mass $D/T$; the untruncated form is convenient for integration.

To prove (1), orient a pair so $L=L(x)>e^hL(x')=e^hL'$. Capture by the smaller cube and the near-center inequality imply
\[
 2\|y-x\|_\infty\le a(L-L')+L'
 \le L\bigl[a+(1-a)e^{-h}\bigr]=:s_x.
\]
If an oriented pair is possible, $L>e^h$ since $L'\ge1$, so $s_x\ge Le^{-h}>1$; for $h>0$ it is strictly below $L$. First contact therefore bounds its source mass by $\lambda s_x^n$. At $h=0$ exact contact supplies the same bound. In the pair integral, integrate the smaller receiver over any eligible set and bound its integral of $k_{x'}$ by $b(y)$. The remaining factor $1_{b>T}/b$ is at most $1/T$. Thus the oriented contribution is at most
\[
 {1\over T}\int_{\{x:L(x)>e^h\}}L(x)^{-n}
                  \mu(Q(x,s_x))dx
 \le {D\over T}e^{-n\psi_a(h)}.
\]
Adding the reverse orientation proves (1). Importantly, the interior cube has physical side at least one. No prefix information below the prescribed window is used.

## A paid contribution to the hinge estimate

Define the remaining spatially separated pair energy
\[
 \mathcal E_{T,a}={1\over2}\int (t(x)-t(x'))^2
                         1_{C_a^c}\,d\Pi_T.
\]
The variance identity gives
\[
 \int_{b>T}\operatorname{Var}_{\beta_y}(t)d\mu
 =\mathcal E_{T,a}+{1\over2}\int(t-t')^2 1_{C_a}d\Pi_T.
\]
Since $\psi_a'(h)=(1-a)e^{-h}/[a+(1-a)e^{-h}]\ge(1-a)/2$ on $[0,H]$, the tail formula and (1) yield
\[
 {1\over2}\int(t-t')^2 1_{C_a}d\Pi_T
 \le {2D\over T}\int_0^H h e^{-n\psi_a(h)}dh
 \le {8D\over Tn^2(1-a)^2}.                         \tag{2}
\]
One can retain the finite integral in (2) for a smaller constant; the displayed bound is uniform in dimension and input.

For $T\ge2$, the retained first-contact cubic occupation inequality gives pointwise on $b>T$
\[
 (b-T)^2\le (b-1)^3/b\le12n^2\operatorname{Var}_{\beta_y}(t).
\]
Consequently the new estimate is
\[
 \boxed{\int(b-T)_+^2d\mu\le12n^2\mathcal E_{T,a}
                         +{96D\over T(1-a)^2}.}       \tag{3}
\]
This pays all near-center cross-scale pairs without assuming a small radial variance, a flat canonical column, or a finite principal representation. Arbitrary large canonical columns are allowed. The error is an explicit demand term, rather than an unpaid source duplication.

For comparison with the radial route, put $u=\log\max(1,2\|x-y\|_\infty)$ and $r=t-u$. The retained depth estimate gives $\int r^2d\Gamma\le2D/n^2$. Hence
\[
 I_T\le2\mathcal E_{T,a}
       +\left({16\over(1-a)^2}+4\right){D\over Tn^2}. \tag{4}
\]
The direct hinge (3) is stronger than first inserting (4) into the previous radial hinge; that insertion unnecessarily doubles a variance term.

## What is still needed

For a cut with $M=\mu(N(B))$, $K=D/M\ge4$, choosing $T=K/2$ in (3) and Jensen gives
\[
 K^2\le48n^2\mathcal E_{K/2,a}/M+{768\over(1-a)^2}.  \tag{5}
\]
No Hall supremum needs to be attained. This is a geometric localization of the outstanding high-load budget: a large cut requires scale dispersion among receivers which are spatially separated by a fixed fraction of their side difference. There is no proved uniform estimate $\mathcal E_{T,a}\lesssim W/n$ on the coarse-low residual, so (3)--(5) do not close the root-order target. At $a=0$ the near-center event is a diagonal of zero receiver product measure and the remainder is all scale variance; the result is useful only with an explicitly chosen positive $a<1$. Letting $a\uparrow1$ incurs the displayed divergent fee.

For any future bound $\mathcal E_{T,a}\le R_nW/n$ on every reselected whole coarse-low residual, (3) implies
\[
 \mu\{q>2T\}/W\le12R_nn/T^2+
        {96H_n\over T^3(1-a)^2},\qquad H_n=1+n\log2,
\]
since $q\le b$ and $D\le H_nW$. This is an explicit interface to the existing recursive ledger, not a newly proved hypothesis. Every reselected source still requires its own gates and fee payment. The estimate itself covers a whole retained event; applying it layer by layer would retain the usual layer count.

## Pressure boundary and relation to the earlier overlap route

The R84 older-union route required a separate estimate for the mass of the union of earlier cubes with other centers. It did not prove that the whole union lies in an earlier concentric cube. Here only its near-center, pair-weighted portion has such a containment, and (1) proves and prices that portion. No conclusion about the complementary union is inferred.

The retained synthetic shell diagnostic explains why this payment cannot be the entire argument. With a single reference point at the origin, receivers in the annulus of full radial sides between one and two, and the geometric selector $L(x)=2\|x\|_\infty$, reverse triangle gives $2\|x-x'\|_\infty\ge|L(x)-L(x')|$. Thus $C_a$ is empty off equal-scale null sets for every $a<1$, and the entire broad scale variance belongs to the separated remainder. Its scale occupation has density $n$ on $(0,\log2)$. This is a diagnostic with a point source and an arbitrary geometric selector, not an actual-level $L^1$ example: it lacks the common original contact equation and full gates. It does not disprove a bound for the remainder on actual inputs. It shows that proving (1) alone, without further common-input geometry on separated pairs, cannot be credited as closure.

## The far-pair prefix LP is sharp at the trivial terminal bound

There is also a precise limitation on a proposed pairwise Farkas argument. Fix two receiver points and their selected cubes. Relax the input to any nonnegative integrable density satisfying, at both points, every original concentric prefix upper bound and the two terminal contact equalities. The elementary dual certificate gives
\[
 \mu(Q_x\cap Q_{x'})\le
       \min\{\lambda L(x)^n,\lambda L(x')^n\}.          \tag{6}
\]
The dual certificate is simply the smaller terminal-cube constraint; no discretization is needed.

**Sharpness for separated pairs.** In every dimension at least two there are fixed distinct receivers and two selected sides strictly inside the physical window, separated by a fixed logarithmic gap, for which a genuine nonnegative $L^1$ density attains equality in (6). It satisfies both complete prefix families strictly before their contacts, both unit anchors with value zero, and strict later witnesses inside the window. The receiver separation exceeds the near-center threshold for every $a<1$.

An explicit positive-width primal certificate is supplied below the private boundary and has been independently checked. Its continuum prefix inequalities, exact contacts, and later witnesses are proved analytically; no scale-grid surrogate is used. Equality of this primal value with the elementary dual bound proves sharpness. Thus a uniform strict improvement of (6), or an exponential scale-gap factor, cannot follow from these two prefix chains, exact contact, anchor, and later-witness conditions alone. Combining or optimizing those same inequalities through an LP does not remove this obstruction.

This is explicitly a reduced two-receiver statement. The certificate does **not** establish the whole-window original smooth gate, the original middle gate, positive receiver Lebesgue volume, high canonical load, or a large optimized Hall cut. It is not a counterexample to a bound on $\mathcal E_{T,a}$ or $I_T$ for the actual coarse-low event. Its consequence for the next action is narrower and concrete: a successful far-pair estimate must use simultaneous common-input constraints from more rows, the additional retained gates, or source reallocation. Pairwise first-contact constraints by themselves already have the trivial overlap as their exact optimum.

## Verification and method boundaries

The exact statements were sent to both independent auditors before author proof, and both blind prechecks passed the stated constants and scope. The author executed a three-stage exact rational guard with 240 passing checks; its private replay code and precise limited scope are recorded below the publication boundary. These checks verify prefix values and algebraic constants, not the missing smooth/middle, receiver-volume, or high-load conditions. Both independent auditors passed the full Markdown and public TeX proofs, including the direct hinge constants, reduced LP certificate, and scope exclusions. The Sol auditor also independently passed rational exponent/coefficient checks over an enlarged dimension range. The author's exact private guard remains separately identified from those independent checks. The updated F05 Schur interface was read: the displayed $1/T$ estimate is a directly proved one-sided positive integral bound, not a two-sided operator norm claim or a cancellation theorem. The updated I02 interface was read: the conditional pair law is explicit, and no stopping-time or compensator theorem is invoked. The B01 weak-duality interface was also read for the reduced prefix LP: the upper certificate and matching explicit primal density prove its value directly, without an infinite-dimensional strong-duality or attainment theorem. The private lower-construction catalog was consulted only for pressure design; no gate or exponent is inherited from it. The R85 symmetric-envelope obstruction is respected throughout: no coordinate rectangle or unobserved receiver point is inserted.

## 1. Independent radial-bridge check and its exact scope

Write H=1+n log2. On the **whole** reselected coarse-low original middle event F, let h_x(y)=L_*(x)^(-n)1_{Q_*(x)}(y), b(y)=∫_F h_x(y)dx, D=λ|F|≤HW. Set u_x(y)=log max(1,2||x−y||∞). For b>0 its source posterior is the pushforward of h_x(y)dx/b(y). Use the retained UNWEIGHTED budget I_T=∫_{b>T}Var(u|y)dμ.

For any surviving receiver subset B⊂F and stopped column q_B≤b,

    μ{q_B>2T} ≤ T^(-2)∫(b−T)_+²dμ
                 ≤24n²I_T/T²+48HW/T³.                    (S1)

This follows because q_B>2T forces b−T>T; it never invokes subset monotonicity of conditional variance. With T=max(2,√(192R_n n),(384H)^(1/3)) and the separately assumed I_T≤R_nW/n, both terms are ≤W/8. For n≥2, c=1−1/[5log(n+2)]>0.85, β=c/2>0.425, so ρ=1/4<β. The adaptive author's finite ledger then gives the stated conditional window fee O(√n log²(n+2)+√(nR_n)); the all-scale localization fee remains. R_n and T must be input-independent and the premise must hold on every newly selected whole F_i. This checks a conditional implication, not its radial premise. If T≥H/2 the tested source tail is empty.

## 2. Exact common-source annular quantity to be bounded

Let F_y(s)=P(u≤s|y), H_0=log2. Tonelli gives, including atoms,

    Var(u|y)=2∫_0^{H_0}∫_s^{H_0}F_y(s)[1−F_y(t)]dt ds
      =1/(2b(y)²)∫_F∫_F [u_x(y)−u_z(y)]² h_x(y)h_z(y)dx dz.    (S2)

Proof: expand the variance as half the second moment of the difference of two independent draws from the SAME source posterior. Alternatively write u=∫1_{u>s}ds and expand its covariance; for s≤t the covariance is F_y(s)[1−F_y(t)]. All integrands are nonnegative and u∈[0,H_0]. Integrating (S2) only over {b>T}, with the original common μ and the factor b^(-2), recovers I_T exactly. Independent radial marginals or row-age moments cannot replace this three-variable interaction. The trivial bound is I_T≤H_0²W/4, lacking the required 1/n.

## 3. A newly read usable theorem: a conditional inverse-density test

Ruzhansky–Verma, arXiv:1806.03728v2, Theorem2.1, equations(2.1)–(2.2), assumes polar decomposition, 1<p≤q<∞, positive measurable weights U,V, integrable U and locally integrable V^(1−p'). Its Hardy norm is between D and D(p')^(1/p')p^(1/q), where D=sup_r(tail U)^(1/q)(inner V^(1−p'))^(1/p'). For p=q=2 the norm is ≤2D. The statement and §5 necessity/sufficiency proof were inspected; the other four equivalent criteria were not separately audited. [Original manuscript](https://arxiv.org/pdf/1806.03728).

Here is the precise qualified transfer, proved from that p=q=2 inequality. Suppose a posterior has **no atom**, has density p_y>0 a.e. on [0,H_0], and 1/p_y is locally integrable on each side of a median m_y. Define

    B_y^+=sup_{m_y<r<H_0} P(u≥r|y) ∫_{m_y}^r ds/p_y(s),
    B_y^−=sup_{0<r<m_y} P(u≤r|y) ∫_r^{m_y} ds/p_y(s),
    B_y=max(B_y^+,B_y^−).

If these are finite, apply the theorem on each half, reflecting the left half, with both weights p_y and f≡1. It gives

    ∫_{m_y}^{H_0}(s−m_y)²p_y(s)ds ≤4B_y^+ P(u>m_y|y),
    ∫_0^{m_y}(s−m_y)²p_y(s)ds ≤4B_y^− P(u<m_y|y).

Thus Var(u|y)≤E[(u−m_y)²|y]≤4B_y. An averaged high-load resistance estimate ∫_{b>T}B_y dμ≤R_nW/(4n) would imply the radial premise of (S1). This supplies an explicit density/tail criterion to test, not a claimed bound for it.

The actual clamping at radius1 can produce an atom at u=0. Actual receiver selection can leave annuli of zero posterior density; inverse density then need not be integrable. Neither positive f nor the original/full-window/coarse-low gates guarantees the above posterior assumptions or the averaged resistance estimate. Discarding atoms, filling annular gaps, or regularizing the posterior changes the quantity and needs a separate paid comparison. The primary theorem's lack of a doubling assumption does not remove these weight conditions. The 1972 Muckenhoupt publisher page was located, but its full original PDF was inaccessible here; no unverified theorem number is assigned to it.

## 4. Why the two relevant Carleson originals do not close this bridge

Garnett, arXiv:2204.10915v1, §1 Theorem1.1, uses dyadic Q⊂[0,1]^d, tents Q*=Q×(0,ℓQ], tiles TQ, positive measures m,v, finite A=sup m(Q*)/|Q| and B=sup v(TQ)/|Q|. For **every** disjoint dyadic stopping family, small m density on **every** remaining sub-tent (≤δ) must imply remaining v mass≤C|Q|. Its printed(1.5) omits the initial good tent: m=0 already falsifies that formula. For a valid stopping-generation construction satisfying(1.9)–(1.14), adding its root contribution gives the corrected accounting bound

    sup_Q v(Q*)/|Q| ≤ C+[B+2^d C/(2^d−1)]A/δ.

The full §1 stopping proof was read; §§2–3 are not certified here. [Original manuscript](https://arxiv.org/pdf/2204.10915).

This tool needs an actual common tree, all-subtree packing and every sawtooth implication. A whole-event I_T estimate is not that hypothesis. Source-centered annuli vary with y; simply assigning their masses to a dyadic receiver tree does not preserve the conditional posterior or prove the sawtooth tests. This audit rejects the printed constant; the corrected accounting is conditional on a valid stopping construction and does not certify the rest of the paper or claim a new cube estimate.

Ottazzi–Santagati, arXiv:2405.08358, §3 Definition3.2/Theorem3.3, assumes a doubling punctured-boundary measure ν of a tree, flow m(v)=ν(∂T_v), and at least two successors. For b∈BMO and kernel K, require ∫K(v,ω)dν=0, C_K=esssup_ωΣ_v|K(v,ω)|m(v)<∞, and |K(v,ω)|≤m(v)^a/m(v∧ω)^(a+1), a>0. Then |Kb|m is Carleson; the proof bounds its constant by ||b||_BMO(c_1 C_K+C_a), with parent/child flow ratio≤c_1 and C_a also depending on the growth ratio. Definition, theorem and the BMO-to-Carleson proof were read. [Original manuscript](https://arxiv.org/pdf/2405.08358).

The canonical positive capture kernel has no such cancellation. Centering u by its source-dependent posterior mean is not a fixed boundary function with a common flow. In the uniform dyadic n-cube tree c_1=2^n; the original proof therefore supplies no n-uniform constant even if this model were built. BMO norm, kernel summability and common-tree transfer are all missing. These are usable restricted tree tools, not general radial variance theorems.

## 5. Updated64 proof boundaries and weighted recursion

G01 requires all tent/subtree tests and legitimate geometry; it does not certify root-only packing. E03 requires node flow, an admissible Bellman domain, every subtree's budget and terminal sign. N04 only telescopes a bounded-below potential with an explicitly controlled error partial sum. Here the threshold return has weights β^(−i); an unweighted summable error does not suffice. The adaptive author's actual weighted-forcing interface is the valid weaker alternative to per-step contraction: W_{i+1}≤hW_i+aI_i, h<β, together with Σβ^(−i)I_i<∞, implies a finite weighted depth sum and a vanishing terminal term. This is conditional finite algebra; the cumulative radial forcing is still unproved.

The new nested-contact geometry and its potential/error are owned by the adaptive author. They concern persistent rows B_i; whole-event source posterior statistics use F_i. Substituting one for the other is invalid without a variance comparison. M03 offers no general stability theorem that turns nearly saturated envelope bounds into posterior concentration. K04 requires actual stochastic approximation, entropy and nondegeneracy inputs; deterministic source posterior columns are not automatically a Gaussian empirical process. All five skill entries were used to check hypotheses, not as independent theorem sources.

## 6. Likelihood-envelope next step, without a Gaussian-chain substitution

van Erven–Harremoës, arXiv:1206.2459v2, Theorem6 and its proof (p.7), identifies D_∞(P||Q)=log esssup_P(p/q); on a countable alphabet this is log sup_y p(y)/q(y), with positive/zero ratio infinity. Only this theorem was used. [Original manuscript](https://arxiv.org/pdf/1206.2459).

For any class of probabilities on a fixed finite alphabet, set M(y)=sup_P p(y), Z=ΣM(y). Directly,

    log Z=inf_Q sup_P D_∞(P||Q),  Q*(y)=M(y)/Z.         (S3)

Indeed a common ratio bound p≤e^rQ implies Z≤e^r, while Q* attains r=logZ. No finite-alphabet minimax exchange is needed. A representative cover with classes C_j, representative p_j and pointwise positive residual envelopes e_j(y)≥sup_{P∈C_j}(p(y)−p_j(y))_+ yields Z≤J+Σ_j||e_j||_1. This is a likelihood envelope test; Hellinger closeness alone does not bound these residual envelopes independently of state count.

Consequently replacing the previously overcharged Fisher length by entropy is a worthwhile restricted investigation, but requires control of rare-outcome likelihood envelopes at every refinement, not only metric diameter or log packing number. The abstract failure of such a metric-only transfer is independent of cube realization and is not a cube lower bound. For arbitrary physical mixtures, source-dependent selected scales and all retained gates still require their original transfer. No new uniform envelope estimate is claimed here.

## 7. Outcome and concrete next action

The verified new conditional resistance test and the common-source annular identity give explicit quantities for adversarial evaluation. None of the originals checked proves the required uniform high-load budget. The open inequality remains I_T(F_i)≲n^(−1)R_nW_i, or the weaker **threshold-weighted** cumulative version, for actual reselected coarse-low full events. The next geometric task is to control the joint same-source separated-annulus mass in (S2), or demonstrate a paid density/resistance comparison. Low-burden slices, deleted coarse-high rows and arbitrary probability experiments do not settle this question.

# R86 数值接口证书：高列资格与径向费用

一般平方根目标仍未证明。本轮**未定位并认证一个通过完整原门槛与新粗门、且规范源列超过实际过滤阈值的接收域**，也未得到整个粗门余集上的 \(I_T\) 上界。实际压力搜索与精确必要条件证书分开登记；没有把低维空集、稀有采样零命中或抽象共同列模型当成高负载预算的成功。

公开 `hall_probe.py` 自包含，仅依赖标准库；运行 `python3 hall_probe.py` 重建确定性的 `hall_results.json`。它是数值接口守卫，**没有新的 Hall 图、优化容量或合资格连续接收域证书**。私人新源配方与搜索数据没有写入公开程序或 JSON，也不进入归档。

## 精确门槛先排除无信息维数

对任意窗口选择 \(L(x)\in[1,2]\)，不必使用首触，逐源都有

\[
b(y)\le\int\max_{1\le L\le2}L^{-n}1_{Q(x,L)}(y)dx=H_n=1+n\log2.
\]

停止列还满足 \(q\le b\)。所以在测试源高负载之前，必须比较过滤阈值与这个点态上界。本轮以48项 `atanh` 正级数和显式几何余项包围 \(\log2\)，全部后续比较使用 Fraction。三阶段登记先验低维、临界维数以及扩大维数，共587个维数记录；另保存四个临界点证书。二次残差在空集区间的两个端点为负，凸性给整个区间为负；紧邻维数的残差及导数为正，给所有更大维数的相反符号。

| 阈值选择 | \(b>T\) 必为空的完整整数范围 | \(q>2T\) 必为空的完整整数范围 |
|---|---:|---:|
| \(R=0\)，\(T=\max(2,(384H_n)^{1/3})\) | \(1\le n\le26\) | \(1\le n\le78\) |
| \(R=1\)，再取 \(T\ge\sqrt{192n}\) | \(1\le n\le396\) | \(1\le n\le1595\) |

这里“范围以外不强制为空”仅表示上述包络不能排除，不代表存在实际高列。特别是，在这些范围内报告 \(I_T=0\) 不能为高维余集的缺失估计提供证据。两个分支的空集范围不同，不能将 \(b>T\) 与真正删除集 \(q>2T\) 混同。

## 一个公开的实际标量首触检查

中性的正 L1 输入 \(f=4\,1_{[3/5,4/5]}\)、接收点 \(x=0\) 只用于检查连续首触引理。它不是接收体积或完整保留事件的例子。取 \(\lambda_i=(2/5)(2/5)^i\)，每个真实首触都有精确公式

\[
L_i=\frac{6/5}{1-\lambda_i/2},\qquad A_{L_i}f=\lambda_i.
\]

\([1,6/5]\) 上硬平均为零，随后在全捕获以前严格增加，所以没有较早接触。16个记录逐一核对 \(A_1=0<\lambda_i/2\)、前一尺度上的严格见证以及 \(L_i<L_{i-1}\)。源质量始终为 \(4/5\)。这是固定输入、下降阈值的首触序列；没有验证实际 high-q 源限制或递归谓词，也不把它登记为真实递归链。

该输入不能用于新粗门余集的反例。真实 \(\theta=\log^{-2}3\) 严格在 \([4/5,17/20]\) 内。使用真正 \(h*w_\theta\) 的单调源距离界、256段 t 左 Riemann 和以及60位整数向外指数包围，得到对整段源坐标适用的核下界

\[
\phi_\theta(2/3)\ge160941663037279899/576460752303423488.
\]

这里把两个指数分别按 \(\theta\) 的端点包围，没有假定核关于软度单调。逐记录得到严格 \(P_{\theta,L_i}>\alpha\lambda_i\)，因此全部被新 coarse-high 删除。这说明“半径严格下降而源质量不变”的标量现象不能直接应用于新保留事件；原全窗口 E2/middle/high-q 递归资格均未由此建立。

## 共同列矩阵只核算质量权重

三阶段的有限正 occupation 矩阵明确标为 **NONphysical**，没有真实立方体捕获、L1 接收域、首触或软门。它们核对：大点态列值与小源质量可以同时出现，\(I_T\) 必须使用未乘 b 的源质量权重，不能用某个源点的大方差替代 \(I_T/W\)。另保存真正的嵌套矩阵：原两段各有质量1/2，加入质量49在第一段之后，条件方差下降；所用两段 log 值为0和 \(\log2\)。这只是条件归一化的精确检查，不是过滤后几何预算的反例。实际源、捕获与门槛的耦合仍必须另证。

## 实际压力探索的结果与限制

本轮私人实际探索分成源家族试点、非均匀几何压力、维数及采样分辨率扩大三阶段；没有重复旧轮的微小成功接收盒。输入是显式有限正 L1 产品，源复杂度由数学产品定义，未枚举并假称枚举指数多个组件。接收点使用具有已知密度的径向混合重要性采样，代表实际 dx 积分，而非孤立端点或无权网格。

有数值硬接触与原门诊断存活的点，但新粗门删除了大量点。对最有希望的区域，四个独立种子、各1600个接收采样并改变源盒内采样偏移；过滤后的列估计仍未越过实际 \(T\)。有效样本数低且不同种子差异大，有限观测的最大权重不是积分误差界。软核诊断使用周期延拓或局部核和的原函数/Fourier细化，尚未包围有限输入的延拓/尾部及截断误差。有限尺度窗口扫描、首触浮点搜索也不是向外整域认证，因而没有一个样本被升级为合资格接收盒。

另复查512个接收样本的全部可能接触物理断点窗口及每段内部临界点；与原搜索结果一致，但此复查仍使用浮点算术，不构成 Sturm/有理首触证书。固定源偏移上的列及方差估计不能代替全源质量积分；本轮**没有报告来源高列质量、\(I_T\)、真实 \(D/W\) 或共同 Hall 容量的认证值**。零高列观测不是不存在高列的证据。

公开守卫验证587个维数记录、4个范围边界、16个实际标量 contact-only 记录和3个非物理矩阵，重放约0.03秒。下一步缺口仍是整个重新选择、完整合资格 coarse-low 余集的高来源列径向预算，或能直接保证来源质量收缩的其他机制；本轮有限诊断尚不能决定它。

## R86 independent Astra audit

The general centered-cube estimate of order sqrt(n) n^{o(1)} remains unproved. The positive statements below have passed independent algebraic and geometric proof review; conditional interfaces are not credited as achieved dimension gains.

1. **High-load radial-to-source contraction — PASS, conditional.** With the unweighted actual source variance I_T, the retained hinge gives mu{q_B>2T}<=24n^2 I_T(F)/T^2+48H_n W/T^3 whenever B is the persistent subset of the whole new coarse-low event F. The comparison uses q_B<=q_F<=b_F, not monotonicity of I_T under receiver restriction. The stated threshold makes each term at most W/8 under the uniform premise I_T(F)<=R_n W/n. The source return ratio 1/4 is strictly below beta=c/2. Every source restriction requires new earliest contacts, original gates, and branch fees. The premise must hold at every stage with the same prescribed threshold; no proof of that premise is supplied.

2. **Weighted recursion and terminal limit — PASS.** The finite adaptive ledger, source-shell payment, and geometric contraction consequence retain every scale factor. The alternative summed-forcing hypothesis controls sum beta^{-i} I_i at the same threshold. With h<beta it yields a finite sum of beta^{-i} W_i and hence a vanishing terminal term. An unweighted error bound, one successful source cut, or one layer's estimate does not imply this hypothesis. Summing layers incurs their explicit multiplicity and changes the relevant tail threshold.

3. **Persistent-cube nesting and finite potentials — PASS.** In this exact bad-row recursion, the old-cube strict child witness together with the child's retained anchor forces its new earliest side to be strictly smaller. Thus persistent centered captures are nested. This corrects a broader warning from the previous round: arbitrary reselection need not preserve captures, but this particular persistent recursion does. Nesting preserves edge support; it does not remove the beta^{-i} source-capacity weights or pay exceptional receivers. The exact source lifetime identity, subcritical estimate, critical weighted sum, geometric inflation potential, and common-source radial energy production ledger all pass. The remaining threshold-inflation error is not summably bounded. Row mass loss is not proportional source variance loss, and a bound on potential values is not a bound on the sum of those values. Persistent-row potentials do not automatically control whole-event statistics.

4. **Near-center pair payment — PASS.** The earlier concentric side used in the proof remains inside the physical window. The two-orientation tail, its variance integral, the direct cubic hinge, and its Jensen consequence retain their stated constants. This genuinely pays the near-center contribution; the separated-pair energy remains an unproved interface. Neither a synthetic radial selector nor a two-row overlap relaxation qualifies as a full actual coarse-low event.

5. **Reduced two-row overlap limitation — PASS at its stated scope.** An actual integrable input attains the trivial overlap bound while satisfying both complete hard-prefix chains, exact contacts, zero anchors, and later strict witnesses. Consequently those two chains alone cannot yield a uniform strict overlap discount for separated scales. The certificate does not establish the original smooth or middle gates, positive receiver volume, a high filtered source budget, or a high optimized Hall cut. It does not refute the general target or the separated-pair interface. Its finite rational replay passed 240 checks; the continuum prefix claim is proved analytically.

6. **Source identities and qualified resistance transfer — PASS for the reviewed implications.** The common-source annular identity includes atoms. The two half-interval Hardy estimates imply the stated variance bound with no extra factor two, provided the positive absolutely continuous density and inverse-density hypotheses hold. Actual clamped posteriors need not satisfy them; no atom deletion or annulus filling is free. The finite-alphabet likelihood-envelope identity and positive residual cover estimate also pass. Primary-source theorem readings are separately attributed to the source author; this audit independently checked their displayed elementary transfers, not every external original.


7. **Dominant small-source-packet payment — PASS, unconditional.** For any countable disjoint source partition into packets contained in cubes of full side at most 1/(16n^2), the actual contact traffic carried by packets of row share at least a has source tail at most 2 exp[-(K-C_a)/4] W, C_a=3+3log(1/a). The geometric full/partial/tie decomposition and marginal-rank Jensen argument require no coordinate independence and incur no packet-count factor. Rows with total such share at least rho therefore cost at most [1+2K/rho]W at K=C_a+4log(4H_n/rho). The deleted-source branch is paid with the full-window estimate, not by inheriting old gates. For fixed p>0, a=n^{-p} and rho=n^{-1/2} give an unconditional O_p(sqrt(n)log(n+2)) branch payment on the entire current event. The remaining whole diffuse-packet event must have its source posterior recomputed. Its stagewise or threshold-weighted radial budget is still open. Source partitions, source masses, contacts, and all gates must be handled anew at each recursive input; the new fee is added each time through the existing weighted ledger. The strengthened theorem also proves EVERY measurable original-capture Hall cut of the dominant branch: restrict the source to its essential captured neighborhood, preserve all row contact and packet masses by Tonelli, and reapply the contact-only theorem. No maximizing cut or attained allocation is asserted. If each row captures at most N packets, every row and every subcut has the explicit O(log(N+1)+log(n+2)) fee. This is a local-count subclass, not a universal bound on that count or a pointwise canonical-column cap.

A canonical source posterior, an optimized allocation posterior, the total burden D/W, and the cut ratio D/mu(N) remain distinct quantities throughout. No maximizer or infinite principal decomposition is assumed. Exact finite checks support only the properties they certify; numerical absence of high-load samples is not a uniform inequality. Exact public interface guards remain separate from private correlated-source search diagnostics. Those search results are unqualified and do not certify a high-load event or its absence; any final isolated code/result replay is recorded separately by the parent integrator. This audit does not invent a completed numerical-worker receipt.

## 独立审计结论

本轮新增的主结果是一个对任意正 L1 输入、任意小包内相关性成立的「主导来源包」支付界，以及该分支的全部可测切割 Hall 不等式。全输入的平方根维数目标仍 **UNPROVED**：删去已付主导包分支后的 diffuse 事件尚无一般径向方差预算。递推桥、有限势账本和近中心配对支付均有严格适用范围，不能把它们的未证前提当作已证结论。

独立盲预检于 2026-10-11 14:55 UTC 留档，先于阅读本轮作者证明；随后阅读全文 coverage、adaptive、alternative、sources 的 Markdown 与 TeX 数学正文，并核对最终补充。TeX 仅静态核对，未编译。旧轮 PASS 未被计作本轮数值证据。私有压力检验与参数不进入此公开段或公开守卫。

### 一般证明审核

**主导来源包分支通过。** 对接触行 μ(Q(x,L))=λL^n、L∈[1,2]，将实际来源分成不交、各含于完整边长 ε≤1/(16n²) 小立方体的包。设 p_j 为捕获后验包份额，η_a=Σ_{p_j≥a}p_j。边际尾秩给出的 Z_j 满足 E exp(Z_j/2)≤2；这里使用 Jensen，不假设包内坐标独立。几何估计 g≤2Z_j+C_a，C_a=3+3 ln(1/a)，采用相对包中心的半径，分别结算完整捕获、内层、唯一面及并列面条带。ε 系数的向外上界足以给出所用常数。

取 H_n=1+n ln2、K=C_a+4 ln(4H_n/ρ)，来源尾集只按同一个实际 μ 收费一次。η_a≥ρ 的好行用剩余主导捕获质量构造原捕获图上的分配，费用 2KW/ρ；坏行有实际限制来源在阈值 ρλ/2 的严格硬核见证，由整窗口最大包络支付至多 W。于是该分支总费用为 (1+2K/ρ)W。取 a=n^{-p}、ρ=n^{-1/2} 得 O_p(√n log n)。这是一项一般支付定理；其 usefulness 仍依赖多少行有主导包，不宣称任意分包自动解决 diffuse 行。

**全部切割推论通过。** 对主导分支的任意可测 A，定义必要来源邻域 N_A={b_A>0}。Tonelli 给出几乎处处行在 N_A 外捕获质量为零。限制 μ 至 N_A 保留接触与每个 p_j，再应用仅需接触的定理，得到 λ|A|≤(1+2K/ρ)μ(N_A)。这不靠继承限制来源后的平滑门槛，也不宣称任意可测图的最优输运已取得。若每行至多捕获 N 个正份额包，a=1/(2N)、ρ=1/2 给出全部行的 O(log N+log n) Hall 费用。

**递推量词与重复收费通过核对。** 归一化条件方差 I_T 不随删行单调；单调的是未归一化方差能量。最终算法可用当前实际子事件的 S_i={q_{B_i}>2T}，以 q_{B_i}≤q_{F_i}≤b_{F_i} 控制，但方差假设必须作用于每次重新限制输入后的 WHOLE 当前 F_i。采用主导包删除时，该集合须改为 WHOLE F_diff,i；固定来源网格可以保留，包质量、尾秩、后验份额和全部门槛必须重新计算。不存在从旧输入或旧 F 自动继承 I 的步骤。

条件桥 T=max(2,√(192Rn),(384H_n)^{1/3}) 给出来源质量下降至多 1/4；它要求每一新输入 I_T≤RW/n。更灵活的桥要求每个有限深度都有 Σβ^{-i}I_i≤JW_0/n，且 48H_n/T³<β。有限账本保留终端费用，并按 W_i−W_{i+1} 支付好行来源壳，未将全部来源重复按一次费用简单相加。两种几何前提均尚未一般证明。

**实际嵌套与有限势通过。** 持续坏行在下一输入有旧尺度的严格见证，而下一锚点低于阈值的一半，因此连续性强制下一最早接触尺度更小；共同中心的立方体确实嵌套。其精确来源生存比例为 β^i(L_i/L_0)^n。亚临界折扣可求和，临界折扣只给 Σ(L_i/L_0)^n，不能得到与深度无关的费用。初始后验的临界指数矩 ≤H_n 也不能免费用于晚期条件化。

核膨胀 J 的有限总账 ≤n ln2 D_0，以初始 receiver demand D_0 而非来源 W_0 支付。组合方差势的新增误差 U≥0 尚未付清；势值有界不等于势损失可控制 WHOLE F_diff 的方差和。零保留纤维的方差中心选择、误差方向与有限终端均已核对。

**共同来源近配对通过。** 两个后验副本是同一来源条件分布的乘积定义，不是实际输入坐标独立性。对 2||x−x'||∞≤a|L−L'|、0≤a<1，最早接触的合法前缀给出近配对尾质量 ≤(2D/T)[a+(1−a)e^{-h}]^n。积分得到近配对能量 ≤8D/[Tn²(1−a)²]，以及直接 hinge 余项 96D/[T(1−a)²]。剩余 separated energy 未付；a 接近 1 时常数变差。所用 reduced pair sharpness 结论仅评价减少后的约束，不冒充全门槛、正 receiver 体积或主目标反例。

**来源工具契约通过有限核对。** 同一 μ 下的 CDF 方差双积分与后验配对公式保持来源共享。Hardy 方差准则要求无原子、正密度、局部可积的倒密度与有限测试常数；实际 clamped 径向后验可能有零点原子或缺口，不能直接套用。所引用 [Hardy 定理 2.1](https://arxiv.org/pdf/1806.03728) 的 p=q=2 常数，与 [Rényi D∞ 的本质上确界表述](https://arxiv.org/pdf/1206.2459) 已按实际使用部分核对。树/BMO/stopping 文献仍需要其原始假设及根账；本审计不认证整篇外部论文，也不把这些工具当作本问题的新预算。

### 本轮独立执行证据

| 检查 | 实际结果 | 可支持的范围 |
|---|---|---|
| 冻结公开主程序的临时副本重放 | exit 0，stderr 空，0.034770292 秒；JSON byte-identical | 当前确定性对象的复现 |
| 最终独立 audit_guard | PASS，3.6346 秒 | 冻结哈希、独立有理证书及下述明确范围 |
| 五成员形状隔离测试 | 3.571450125 秒，exit 0，stderr 空；从唯一 proof Python fence 提取的守卫与冻结字节一致 | 仅 proof pair、公开主程序/JSON、inventory 的依赖测试；这是形状测试，最终组装 archive 的实际重放由父任务另记 |

守卫不导入或调用作者主程序。主程序重放与独立 JSON 审计是两项分开的实际执行。守卫以有理数和整数根包围独立重建本轮对象，不依赖旧轮结果。

- 三阶段 27 个桥/有限递推模型，1539 条加权 forcing 检查、来源壳与终端恒等式、临界来源寿命、近配对常数；这些是 NONPHYSICAL 标量约束检验。
- 小包常数三阶段 n=2,3,4 / 8,32,256 / 4096：63 个系数/尾价检查，765 个相关尾秩 Jensen 代数检查，21 个含零纤维的能量增量检查、21 个共同来源 CDF 方差恒等式。它们验证代数，不代替真实几何证明。
- 当前公开 JSON 的 587 个维数记录、4 个全整数范围凸二次边界证书、16 个 actual CONTACT-ONLY 精确根记录、3 个 NONPHYSICAL 共同列/条件投影记录。真实标量接触对象具有正 L1 输入、锚点、前缀和后继严格见证；全部被新 coarse-high 门槛删除，不能用于残余 high-load 结论。平滑下界另用交错 Taylor 有理包围独立核验。

严格空集范围区分了 b>T 与实际删源 q>2T：R=0 时分别 n≤26、n≤78；R=1 时分别 n≤396、n≤1595。超过边界只说明简单的 H_n 包络不足以强制空集，不证明实际输入有该高负载事件。当前公开数据没有新的 fully gated high-load receiver 集、Hall 流图或 I_T 几何证书。NONPHYSICAL 模型不是真实立方体反例，有限接触记录也不是来源递推链。私有随机/网格压力仍属诊断；复现成功不将其门槛或未观察到的事件变为证明。

### 冻结与可移植范围

公开守卫只需标准库，以及同目录冻结的 hall_probe.py / hall_results.json；仅读取它们核对哈希和 JSON，不执行作者模块。没有私有文件、外部组件 Markdown、绝对工作目录、skills 或网络依赖。最终 proof.md 中唯一 Python fence 可提取为 audit_guard.py 后执行 `python3 -B audit_guard.py`；确定性主程序重建另行执行 `python3 -B hall_probe.py`。守卫不依赖 proof.tex.txt 或 inventory 的内容作数学判据。

| 冻结对象 | SHA-256 |
|---|---|
| hall_probe.py | c3626ecf2425277f192a3f9722973ebadacaaaf1984c1923e30e8e4500f11b38 |
| hall_results.json | 8faee5bb034bb828c8a1aca5444b1f2827919ed578658f0dc70137c56f3d9efc |
| hall_numeric.md | 8d48b7da176291c39df19e93c7ab9a188e551cc1a73c3a413a5f9bd4c89ca453 |
| audit_guard.py | 32dd0e31d53f2a58455b05b673be918be29068b585d59b0fa60325ef6e3e1319 |

本次审读组件快照如下；它们用于明确审读版本，守卫不依赖这些未单独归档的文件。父任务最终 inventory 另记录公开抽取与打包字节。

| 组件 | Markdown SHA-256 | TeX SHA-256 |
|---|---|---|
| coverage | ec3519bfc726d170ab9e5946554b7f82be29f33250c0b161466f5312627b0ebf | 34ce64f2f0d58db3784b78d8fab1bcb32cd7d313e3c3abd9c4a25981309faa5b |
| adaptive | 01b42853da3fefe6d5a79a6bae1c35b8cdfcba51e816aeb752a3c0440d3fa059 | a00573a0a967a5263a379c4012273591befb6b37c39552c19ffdf0093fe21b22 |
| alternative | d2db81cd368035286fd6fc8c154ea8f9e5bc2db23adf34b488eb54950b675470 | 83556f12fc9950fe4dcfded3368b185a10b31ed7b84b93e9027276c841ca92b9 |
| sources | 7c248ae03c29be6c936579b967ca9d7e0b4fb67f1dd0fc3cf8b83466ea7af5b7 | de97c350db5f80263daf10ce29bb7bcd68773e0e9152ada49a9d99240d2c7bd4 |

最终剩余问题是对 WHOLE diffuse 残余及每一次来源限制证明统一或阈值加权的高负载径向预算，或者支付 separated 配对能量/有限势中的 U 项。当前一般结果只在一个尺度窗口内给出相应费用；回到全部尺度与原弱型目标仍须原有定位和门槛账本。没有省略每层费用、来源共享或重新门槛检查来宣告主目标闭合。

## 独立公开证书审核程序

```python
#!/usr/bin/env python3
"""R86 independent PUBLIC audit. Scalar models are explicitly nonphysical.
Current frozen interface-certificate verification is a separate section below;
there is no newly certified high-load Hall graph in the public data.
No private inputs, author imports, external modules or external paths.
"""
from fractions import Fraction as F
from functools import lru_cache
from pathlib import Path
from itertools import product
from collections import deque
import hashlib,json,math,sys,time
ROOT=Path(__file__).resolve().parent
COUNTS={}
def check(v,label):
    if not v:raise AssertionError(label)
    key=label.split(':')[0];COUNTS[key]=COUNTS.get(key,0)+1
@lru_cache(None)
def expminus(x):
    x=F(x);check(x>=0,'exp:domain');j=0
    while x>F(1,2):x/=2;j+=1
    term=F(1);s=F(1)
    for k in range(1,26):
        term*=x/k;s+=(-1 if k%2 else 1)*term
        if k==24:hi=s
    lo=s
    for _ in range(j):lo*=lo;hi*=hi
    return lo,hi

def log2_bounds():
    z=F(1,3);lo=2*sum(z**(2*k+1)/(2*k+1) for k in range(48))
    hi=lo+2*z**97/(97*(1-z*z))
    return lo,hi

def root_upper(x,k):
    # Pure integer ceiling on a 2^-32 grid. No float root guides the enclosure.
    x=F(x);Q=1<<32;lo=0;hi=Q
    while F(hi,Q)**k<x:hi*=2
    while hi-lo>1:
        m=(lo+hi)//2
        if F(m,Q)**k<x:lo=m
        else:hi=m
    check(F(lo,Q)**k<=x<=F(hi,Q)**k,'root:outward integer bracket')
    return F(hi,Q)

def scalar_checks():
    L,U=log2_bounds();check(F(2,3)<L<U<F(7,10),'log:rational enclosure')
    stages=[(1,[2,8,16],8),(2,[32,64,256],32),(3,[1024,4096,65536],128)]
    models=0;domains=[]
    for stage,ns,depth in stages:
        for n in ns:
            H=1+n*U
            for R in [F(0),F(1),F(3)]:
                T=max(F(2),root_upper(192*R*n,2),root_upper(384*H,3))
                z=48*H/T**3;a=24*n*n/T**2
                check(a*R/n<=F(1,8) and z<=F(1,8),'bridge:two exact eighths')
                check(a*R/n+z<=F(1,4),'bridge:source contraction')
                c=F(7,8);beta=c/2;rho=F(1,4);G=4*T/c
                check(rho<beta and beta>F(17,40),'bridge:strict threshold contraction')
                A=F(1)+T;cost=(A+G*(1-rho))/(1-rho/beta)
                check(cost==(A+3*T/c)/(1-F(1,2)/c),'bridge:ledger exact constant')
                domains.append({'stage':stage,'n':n,'R':str(R),'T_ge_H':T>=H,'twoT_ge_H':2*T>=H})
                # Nonuniform but source-decreasing scalar recurrence. The
                # weighted radial budget is computed, NOT proved geometrically.
                W=[F(1)]
                for i in range(depth):W.append(W[-1]*(F(1,2) if i%3==0 else F(1,8)))
                I=[max(F(0),(W[i+1]-z*W[i])/a) for i in range(depth)]
                X=[beta**(-i)*W[i] for i in range(depth+1)]
                Q=sum(beta**(-i)*I[i] for i in range(depth))
                for i in range(depth):check(W[i+1]<=a*I[i]+z*W[i],'amortized:source recurrence')
                sx=sum(X[:-1]);C=(1+a*Q/beta)/(1-z/beta)
                check(sx<=C,'amortized:finite occupation bound retaining terminal')
                shell=sum(beta**(-i)*(W[i]-W[i+1]) for i in range(depth))
                check(shell==beta+(1-beta)*sx-beta*X[-1],'ledger:source-shell summation by parts')
                terminal=H*X[-1];actual=A*sx+G*shell+terminal
                check(actual==A*sx+G*(beta+(1-beta)*sx-beta*X[-1])+terminal,'ledger:finite terminal included')
                models+=1
            # Exact nested-cube/lifetime relaxation. No existence assertion
            # for physical retained chains of arbitrary depth is made.
            beta=F(7,16);m=min(depth,8);side=[F(2)-F(i,16) for i in range(m+1)]
            surv=[beta**i*(side[i]/side[0])**n for i in range(m+1)]
            critical=sum(beta**(-i)*surv[i] for i in range(m+1))
            check(critical>=F(m+1,2**n),'lifetime:critical occupation lower bound')
            check(critical==sum((q/2)**n for q in side),'lifetime:exact contact mass identity')
            check(all(surv[i+1]<surv[i] for i in range(m)),'lifetime:joint nested mass decrease')
            subcrit=sum(beta**(-F(i,1))*surv[i] for i in range(m+1))
            check(subcrit==critical,'lifetime:critical exponent cannot be renamed subcritical')
            # Choose p=0, an exact subcritical case, and p=1/2 with the
            # rational beta=1/4 surrogate so every discount is rational.
            check(sum(surv)<=1/(1-beta),'lifetime:subcritical zero exponent')
            b=F(1,2);half=sum(b**i*(q/2)**n for i,q in enumerate(side))
            check(half<=1/(1-b),'lifetime:subcritical exact half-exponent surrogate')
            for aa in [F(1,4),F(1,2),F(3,4)]:
                for h in [F(0),F(1,8),F(1,2)]:
                    elo,ehi=expminus(h);rlo=aa+(1-aa)*elo;rhi=aa+(1-aa)*ehi
                    # Algebraic derivative bound of psi on [0,log2].
                    check((1-aa)*elo/(aa+(1-aa)*elo)>=(1-aa)/2,'pair:uniform exponent derivative')
                    rate=n*(1-aa)/2
                    z0=min(rate*U,F(2));el,eu=expminus(z0)
                    momentlo=(1-(1+z0)*eu)/(rate*rate)
                    momenthi=(1-(1+z0)*el)/(rate*rate)
                    check(0<=momentlo<=momenthi<=1/(rate*rate),'pair:finite exponential tail integral')
                    check(2/(rate*rate)==F(8,n*n)/(1-aa)**2,'pair:close energy constant')
                    check(12*n*n*F(8,n*n)/(1-aa)**2==96/(1-aa)**2,'pair:direct hinge constant')
            # Critical exponential moment: exact truncated exponential law,
            # with H=1/2 solely as a scalar admissible cutoff.
            Hs=F(1,2);check(1+n*Hs>1,'pressure:critical exponential moment grows with dimension')
    # Conditional variance may grow when receiver rows are deleted, while
    # variance energy stays monotone. All masses exceed T=2 here.
    H=F(1,2);B=[(F(100),F(0)),(F(2),-H),(F(2),H)];A=B[1:]
    def ve(rows):
        m=sum(w for w,t in rows);mean=sum(w*t for w,t in rows)/m
        v=sum(w*(t-mean)**2 for w,t in rows)/m
        return m,v,m*v
    mb,vb,eb=ve(B);ma,va,ea=ve(A)
    check(ma>2 and va>vb,'pressure:unweighted variance subset nonmonotonicity')
    check(ea<=eb,'pressure:energy subset monotonicity')
    print('SCALAR THREE STAGES:',models,'bridge/recurrence models; NONPHYSICAL scalar laws only')
    print('DOMAIN CHECKS:',len(domains),'exact comparisons of T and 2T against H; no existence inference')

# The tail integral above is checked on a finite rational cutoff; extending
# its elementary exponential integral to infinity gives the stated constant.
# Public new numerical data: actual scalar contact only, plus nonphysical
# projection/cutoff algebra. No qualified high-load Hall claim is inferred.
def log_bounds(x):
    x=F(x);check(x>=1,'log:unit domain');z=(x-1)/(x+1)
    lo=2*sum(z**(2*j+1)/(2*j+1) for j in range(80))
    hi=lo+2*z**161/(161*(1-z*z))
    return lo,hi

def neutral_checks(data):
    check(data['schema']=='R86-public-exact-necessary-condition-guards-v1','schema:current R86 exact guards')
    lo,hi=log_bounds(2);ranges={0:[],1:[]};qrange={0:[],1:[]}
    rows=data['threshold_records']
    expected=sorted(set(range(1,513))|set(range(1550,1621))|{1024,4096,16384,2**20})
    check([r['n'] for r in rows]==expected,'cutoff:complete stated dimensions')
    for row in rows:
        n=row['n'];a,b=map(F,row['H_interval']);l,u=1+n*lo,1+n*hi
        check(a<=l<=u<=b,'cutoff:independent log enclosure')
        flags=[u*u<384, u*u<192*n or u*u<384]
        for R,flag in enumerate(flags):
            name='high_set_b_above_T_R'+str(R)+'_necessarily_empty'
            check(row[name]==flag,'cutoff:hinge T filter classification')
            if flag:ranges[R].append(n)
            # Actual source-pruning cutoff is 2T, not T.
            qempty=u*u<=3072 or (R==1 and u*u<=768*n)
            qpossible=l*l>3072 and (R==0 or l*l>768*n)
            check(qempty or qpossible,'cutoff:strict twoT filter enclosed')
            if qempty:qrange[R].append(n)
            if 'removal_set_q_above_2T_R'+str(R)+'_necessarily_empty' in row:
                check(row['removal_set_q_above_2T_R'+str(R)+'_necessarily_empty']==qempty,'cutoff:author twoT classification')
    for R in ranges:
        check(data['threshold_empty_integer_ranges']['b_above_T_R'+str(R)]==[1,max(ranges[R])],'cutoff:hinge integer range')
        check(data['threshold_empty_integer_ranges']['q_above_2T_R'+str(R)]==[1,max(qrange[R])],'cutoff:pruning integer range')
    certs=data['cutoff_boundary_certificates']
    check(len(certs)==4,'cutoff:four all-dimension convex boundaries')
    for r,(label,c,N,linear) in zip(certs,[('b>T R0',384,26,False),('b>T R1',192,396,True),('q>2T R0',3072,78,False),('q>2T R1',768,1595,True)]):
        check(r['label']==label and r['coefficient']==c and r['last_empty_dimension']==N,'cutoff:boundary metadata')
        for name,n in [('residual_at_one',1),('residual_at_last_empty',N),('residual_at_first_possible',N+1)]:
            a,b=map(F,r[name]);shift=c*n if linear else c
            l=(1+n*lo)**2-shift;u=(1+n*hi)**2-shift
            check(a<=l<=u<=b,'cutoff:independent convex boundary enclosure')
            check(u<0 if n<=N else l>0,'cutoff:strict boundary sign')
        derivative=2*lo*(1+(N+1)*lo)-(c if linear else 0)
        check(0<F(r['derivative_lower_at_first_possible'])<=derivative,'cutoff:all-larger positive derivative')

    # Genuine E2 at z=2/3 and eta in[4/5,17/20]. Outside-cube mixture
    # integrand t(exp(-1/(6eta t))-exp(-7/(6eta t))). Use independent
    # alternating-Taylor exponential brackets, not author's positive series.
    nt=256;own=F(0)
    for j in range(1,nt):
        t=F(j,nt);al=expminus(F(1,6)/(F(4,5)*t))[0]
        bu=expminus(F(7,6)/(F(17,20)*t))[1]
        own+=t*max(F(0),al-bu)/nt
    fixture=data['contact_only_fixture'];saved=F(fixture['phi_uniform_lower'])
    check(0<saved<=own,'E2:independent genuine uniform scalar lower')
    rho=F(fixture['density']);aa,bb=map(F,fixture['source_interval']);W=rho*(bb-aa)
    check(W==F(fixture['source_mass']) and F(fixture['receiver'])==0,'contact:actual positive L1 mass')
    l3,u3=log_bounds(3);etal,etau=1/u3**2,1/l3**2
    check(F(4,5)<etal<=etau<F(17,20),'contact:coarse width enclosed')
    prev=2*bb;beta=F(fixture['beta'])
    records=fixture['records'];check(len(records)==16,'contact:stated depths')
    for i,r in enumerate(records):
        lam=beta**(i+1);L=2*aa/(1-2*lam/rho)
        check(r['depth']==i and F(r['lambda_value'])==lam and F(r['first_contact_exact'])==L,'contact:independent exact first root')
        # Before2a no source is captured; on(2a,2b) hard average
        # rho/2-rho*a/L has strictly positive derivative rho*a/L².
        check(1<2*aa<L<2*bb<=2 and rho*aa/L**2>0,'contact:whole prefix first-root proof')
        avg=rho*(L/2-aa)/L;old=rho*max(F(0),min(bb,prev/2)-aa)/prev
        check(avg==lam and old>lam and L<prev,'contact:strict old witness and nesting')
        check(F(r['previous_scale'])==prev and F(r['previous_scale_average'])==old,'contact:recorded witness')
        check(F(r['anchor'])==0 and F(r['root_identity_residual'])==0,'contact:anchor and exact residual')
        el,eu=map(F,r['coarse_theta_interval']);check(el<=etal<=etau<=eu,'contact:author eta enclosure')
        # Every actual source y/L lies in[2/5,2/3]. Monotone true phi
        # gives the same scalar lower at every y; no empirical latent law.
        check(aa/L>=F(2,5) and bb/L<=F(2,3),'contact:source kernel argument range')
        lower=W/L*saved;alpha_hi=F(r['alpha_lambda_upper'])
        check(F(r['selected_full_Ptheta_lower'])==lower and alpha_hi>=lam/(10*l3),'contact:outward threshold values')
        check(lower>alpha_hi and r['tunable_coarse_high_certified'],'contact:coarse-high deletes fixture')
        prev=L
    p=data['nonphysical_projection_records'];check(len(p)==3,'projection:three public scalar stages')
    for r,scale in zip(p,[8,128,4096]):
        mass=F(1,scale*scale);bA=bC=F(scale,2);bE=F(scale)
        check(F(r['common_source_mass'])==mass and F(r['b_E'])==bE and F(r['D'])==mass*bE,'projection:independent source-normalized moments')
        vl,vh=map(F,r['unweighted_I_T_interval']);check(vl<=mass*lo**2/4<=mass*hi**2/4<=vh,'projection:independent variance enclosure')
        check(F(r['weighted_band_product'])==mass*bA*bC and F(r['two_band_variance_lower'])==vl,'projection:band normalization')
        va,ve=map(F,r['conditional_variance_log2_square_coefficients'])
        check(va==F(1,4) and ve==F(99,10000) and ve<va,'projection:subset variance may increase')
        for name,c in [('conditional_variance_A_interval',va),('conditional_variance_E_interval',ve)]:
            a,b=map(F,r[name]);check(a<=c*lo*lo<=c*hi*hi<=b,'projection:exact nested variance enclosure')
        check('NONphysical' in r['model'],'projection:qualification explicit')
    print('NEW NUMERICAL OBJECTS:',len(rows),'cutoff dimensions;',len(records),'actual CONTACT-ONLY roots;',len(p),'NONPHYSICAL projections')
    print('PRUNING twoT empty ranges sampled:',{str(R):max(v) for R,v in qrange.items()})

EXPECTED={'hall_probe.py':'c3626ecf2425277f192a3f9722973ebadacaaaf1984c1923e30e8e4500f11b38','hall_results.json':'8faee5bb034bb828c8a1aca5444b1f2827919ed578658f0dc70137c56f3d9efc'}
def actual_checks():
    if not EXPECTED:
        print('ACTUAL CERTIFICATES: pending author freeze; no PASS claimed')
        return
    for name,h in EXPECTED.items():check(hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==h,'bytes:frozen '+name)
    neutral_checks(json.loads((ROOT/'hall_results.json').read_text()))

def common_source_checks():
    # Fresh exact three-stage scalar stress of NEW conditional energy and
    # small-packet constants. These arrays have no physical cube realization.
    for stage,ns,M in [(1,[2,3,4],4),(2,[8,32,256],16),(3,[4096],64)]:
        for n in ns:
            eps=F(1,16*n*n);C=1/(1-n*eps)
            check(C<=F(32,31),'cluster:exponential upper by geometric series')
            check((2*n*n+n)*eps<=F(5,32),'cluster:inner tied-face and endpoint corrections')
            check(1+C*(1+(2*n*n+n)*eps)<3 and 1+C<3 and C<2,'cluster:rounded Z log and constant coefficients')
            # Marginal ranks upper-endpoint discretization, with arbitrary
            # permutations and also perfect correlation. All sources shared.
            factors=[root_upper(F(M,i+1),2) for i in range(M)]
            for offset in [0,1,3]:
                for row in range(M):
                    d=2*n if n<128 else M
                    check(d==2*n or 2*n%d==0,'rank:repeated coordinate blocks exact')
                    v=[factors[(row+offset*j)%M] for j in range(d)]
                    avg=sum(v)/d
                    check(math.prod(v)<=avg**d,'rank:dependent marginal Jensen AMGM')
                # Each coordinate's permutation has the same marginal sum.
                check(sum(factors)/M<2,'rank:uniform rank upper-endpoint integral bound')
            for rho in [F(1,2),F(1,4),F(1,16)]:
                H=1+n*log2_bounds()[1]
                tail=rho/(2*H)
                check(2*H*tail/rho==1,'cluster:single source tail pays all bad rows')
                K=F(3)+4*F(1)  # arbitrary symbolic log placeholders positive
                capacity=2*K/rho
                check(capacity*rho/2==K,'cluster:dominant outside-source normalized capacity')
            # Exact variance energy on a finite shared-source law including
            # zero retained fibres; arbitrary positive increments.
            H=F(1,2)
            for j in range(3):
                rows=[(F(i+j+1,M),H*F(i,M-1)) for i in range(M)]
                kept=rows[j::2] if j<2 else []
                inc=[(F(1,M),H),(F(j+1,M),F(0))]
                def energy(q):
                    mass=sum(w for w,u in q)
                    if not mass:return F(0),F(0)
                    mean=sum(w*u for w,u in q)/mass
                    return sum(w*(u-mean)**2 for w,u in q),mean
                e,mean=energy(rows);er,mr=energy(kept);en,mn=energy(kept+inc)
                loss=e-er;added=sum(w for w,u in inc)
                check(loss>=0 and en<=e-loss+H*H*added,'variance:finite production zero fibre exact signs')
                # CDF triangular identity, independent from pair formula.
                mass=sum(w for w,u in rows);points=sorted(set([F(0),H]+[u for w,u in rows]))
                triangular=F(0)
                for ia in range(len(points)-1):
                    l,r=points[ia:ia+2];Fa=sum(w for w,u in rows if u<=l)/mass
                    triangular+=Fa*(1-Fa)*(r-l)**2/2
                    for ib in range(ia+1,len(points)-1):
                        a,b=points[ib:ib+2];Fb=sum(w for w,u in rows if u<=a)/mass
                        triangular+=Fa*(1-Fb)*(r-l)*(b-a)
                check(2*triangular==e/mass,'annular:exact common-source CDF covariance identity')
    print('COMMON SOURCE THREE STAGES: packet constants n2,3,4/8,32,256/4096; dependent rank and finite energy arrays NONPHYSICAL')

def main():
    start=time.monotonic();scalar_checks();common_source_checks();actual_checks()
    print('PASS',json.dumps(COUNTS,sort_keys=True),'elapsed_seconds',round(time.monotonic()-start,6))
if __name__=='__main__':main()
```
