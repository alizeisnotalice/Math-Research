# R487：高类空配置支持、模父常数收缩与累计占用

本稿只使用同一 R486 自然参考与真实成功核 (J)。已证新的来源／配置波动块收缩；父均值块及累计停止费仍未获得根阶预算。没有将旧父刷新核 (K) 的行价转授新链。

## 1. 实际支持与高类强度

沿 R486 main「自然参考、最大父列与新分析链」，增广父为 (widehat B=(B,s_B))，
\[
 \mathsf M(d\widehat B,dx,dF)=\nu(dB)ds_B\,M_{\widehat B}(dx,dF),\qquad
 M_{\widehat B}=\pi_B(dx)\operatorname{PPP}(c_C(x)\Lambda_{\widehat B}(d\widehat C)),
\]
\[
 \Lambda_{\widehat B}(d\widehat C)
 =\frac{1_{\widehat C\prec\widehat B}}{T m_C}\nu(dC)ds_C,
 \quad \nu=t\sigma,\quad t\le S.
\]
前缀保原质量带，(F) 是最大父下方**全部 raw 点**。R479 main §3 的成功门是最大父对全部 raw 其余点的行和不超过 (1/2)，不是仅对删除后族的行和。对该前缀中每个点，(m_C\le m_B)，故
\[
 p_C:=\pi_B(Q_C)=\gamma_{BC}\sqrt{m_C/m_B}\le\gamma_{BC}.
\]
因此成功输出必有 (F_{\rm hi}=\varnothing)，其中确定分类为
\(\mathcal H_B=\{C:p_C>1/2\}\)。所有额外成功／原历史正限制保此支持。于是任意 (v\in L^2(\mathsf M)) 的 (h=J^*v) 都在该事件外为零；这不是由随机低 Gram 子族推断整个候选场低捕获。

R479 main §3（亦 R476 main (1)）已证：固定 (B,x\in Q_B)，
\[
 \int\gamma_{BC}\,t(C)c_C(x)\sigma(dC)/m_C\le4rS.
\]
删前缀只减小积分，且 (1_{p_C>1/2}\le2\gamma_{BC})，所以逐父、逐来源
\[
 \lambda_{\rm hi}(\widehat B,x)
 :=\int_{\mathcal H_B}c_C(x)d\Lambda_{\widehat B}
 \le\delta:=8rS/T. \tag{1}
\]
同质量原子由原 uniform mark 展开；此处并未把非严格质量关系改为严格质量下降。

## 2. 空高类支持的精确分解

固定增广父，缩写 (M=M_{\widehat B})、(pi=\pi_B)。令 (H) 为 R486 的补全潜在 PPP、重采来源、再观察捕获配置的核。其混沌公式是
\[
 h'_k(z;\mathbf C)=1_{z\in\cap C_i}\int_{\cap C_i}h_k(x;\mathbf C)\pi(dx).
\]
每元组纤维的非零特征值为 (pi(\cap C_i))。因此：含任一 (p_C\le1/2) 候选的 low-touch 部分谱帽为 (1/2)；纯 high、正阶部分谱帽至多 1；零阶来源函数被平均。原子重复候选保在 (Lambda^k) 中，特征值不是 (p_C^k)。R486 的指数向量／有限分割稠密性证明保证下列分解对一般有限强度、可测来源成立，不只对有限混沌多项式成立。

假设 (h=0) 于 (F_{\rm hi}\ne\varnothing)。给定 (x)，高／低配置独立。记
\[
 p_0(x)=e^{-\lambda_{\rm hi}(x)},\qquad
 a(x)=\mathbb E_{\rm low}[h(x,F_{\rm low},\varnothing)].
\]
则
\[
 \mathbb E[h\mid x,F_{\rm hi}]=a(x)1_{F_{\rm hi}=\varnothing},
 \qquad h_0(x):=\mathbb E[h\mid x]=p_0(x)a(x).
\]
纯 high 正阶范数精确为
\[
 V_{\rm hi}(h)=\int |a(x)|^2p_0(x)(1-p_0(x))\pi(dx).
\]
设 (eta=1-e^{-\delta}\le\delta)。由条件 Jensen，
\[
 V_{\rm hi}(h)\le\eta\int |a|^2p_0d\pi\le\eta\|h\|_M^2. \tag{2}
\]
这些结论含 (\lambda_{\rm hi}=0) 的纤维；空高类事件概率始终正。令 (m=\int h\,dM)，(V_0=\|h_0-m\|_\pi^2)，(V_{\rm lo}=\|h-\mathbb E[h\mid x,F_{\rm hi}]\|_M^2)。正交分解给
\[
 \|h\|^2=|m|^2+V_0+V_{\rm hi}+V_{\rm lo},
 \quad \|Hh\|^2\le |m|^2+V_{\rm hi}+\tfrac14V_{\rm lo}.
\]
所以，取 (q_*=1/4+3\eta/4<1)，
\[
 \boxed{\|Hh\|^2\le q_*\|h\|^2+\tfrac34|m|^2-\tfrac14V_0.} \tag{3}
\]
计划稿的 (q=1/4+3\delta/4) 在 (\delta<1) 时亦成立；(3)保留稍强的空事件概率。它不是对 (h-m) 的统一谱隙断言，因为 (h-m) 一般已不具有空高类支持。

## 3. 同一实际核的列尾缺陷与逐父积分

令 (Q) 为逐增广父的均值投影，全部范数以下在 (mathsf M) 上。自然 (H) 保每个父纤维，所以 (QH=HQ=Q)。将(3)对 (
u(dB)ds_B) 积分可得
\[
 \|Hh\|^2\le q_*\|h\|^2+\tfrac34\|Qh\|^2-\tfrac14 V_0^{\rm tot}(h). \tag{4}
\]
没有额外父数／质量带因子。

R486 geometry §2 (3)–(4) 还给 raw 最大父列的精确因子
\[
 c_0(\widehat B,x)=1-e^{-(U(x)-w_x(\widehat B))/T},
 \quad J^*1\le c_0\,1_{F_{\rm hi}=\varnothing}. \tag{5}
\]
它与下方配置无关，(U,w) 仍在原同一质量带。令 (j=J^*1)。伴随核的 Cauchy 不等式给
\( |J^*v|^2\le jJ^*(|v|^2)\)。(j=0) 处 (h=0)，并且 (J1\le1)，故
\[
 D_J(v):=\|v\|^2-\|J^*v\|^2
 \ge\int(1/j-1)|h|^2d\mathsf M
 \ge\int(1/c_0-1)|h|^2d\mathsf M=:D_{\rm tail}(h). \tag{6}
\]
零分母项按 (h=0) 取零；(6)同时证明该非负积分有限。未迁移任何旧 (K) 的一次停止价。

## 4. 累计占用与精确波动块消元

写 (mathcal P=JH)，(E=\mathcal P^*=HJ^*)。R486 双参考列界已证明真实新链的
\[
 V=\sum_{j\ge0}E^j1\in L^\infty(\mathsf M),\quad EV=V-1,
 \quad R=\mathsf M(1)=\int V e^\sharp d\mathsf M,
 \quad e^\sharp=1-J1.
\]
这是原初始质量在新分析链上的完整停止恒等式，不称新链与旧 (K) 轨迹同律。取 (h=J^*V)，精确能量左端为 (2\int Vd\mathsf M-R)。由上节得到
\[
\boxed{
 2\int Vd\mathsf M-R\ge D_{\rm tail}(h)
 +\tfrac34(\|h\|^2-\|Qh\|^2-V_{\rm hi}^{\rm tot}(h))
 +\tfrac14V_0^{\rm tot}(h).} \tag{7}
\]
其后两项合为 (\tfrac34V_{\rm lo}^{\rm tot}+V_0^{\rm tot}\ge0)。进一步可用
\[
 D_{\rm tail}(h)+\tfrac34\{(1-\eta)\|h\|^2-\|Qh\|^2\}
 +\tfrac14V_0^{\rm tot}(h) \tag{8}
\]
作右端下界，必须保负父常数项，不能由(8)宣称 (R) 已付。

还有比单条能量式更直接的统一连接。对任意 (v\in L^2(\mathsf M))，(h=J^*v) 具有上节支持，(J^*) 为收缩，故
\[
 \|(I-Q)Ev\|^2=\|Hh\|^2-\|Qh\|^2
 \le q_*\|h\|^2-\tfrac14\|Qh\|^2
 \le q_*\|v\|^2. \tag{9}
\]
在正交分解 (L^2=\operatorname{Ran}Q\oplus\ker Q) 上定义
\[
 A=QEQ,\quad B=QE(I-Q),\quad C=(I-Q)EQ,
 \quad D=(I-Q)E(I-Q).
\]
由(9)，(|D|\le\sqrt{q_*}<1)，且 (|C|\le\sqrt{q_*})。因此对实际 (a=QV,w=(I-Q)V)，
\[
 w=(I-D)^{-1}Ca,\qquad
 a=1+[A+B(I-D)^{-1}C]a,\qquad
 \|w\|\le\frac{\sqrt{q_*}}{1-\sqrt{q_*}}\|a\|. \tag{10}
\]
这是整个实际累计密度的精确块消元；常数 1 在父均值空间。有效父算子含有 (I-Q)，不自动正、次 Markov 或收缩。停止费仍为
\[
 R=\langle a,Qe^\sharp\rangle
   +\langle (I-D)^{-1}Ca,(I-Q)e^\sharp\rangle. \tag{11}
\]
第二项一般有符号，不能删除，也不能以一次费替代。新的实质是波动块有统一逆算子，而剩余具体任务是对(10)的实际父均值解及(11)给来源预算；当前仅有(7)的累计能量，未得到根阶付款。

## 5. 本机有限代数复核

下列脚本实际运行输出：`28 exact Fraction algebra assertions PASS; no native/history model claimed.` 它核正交能量／常数方向及两组块消元代数，不验证原生几何或原历史；一般证明如上。未重复另一个数值作者的 Charlier/PGF 实验。

```python
from fractions import Fraction as F
n=0
for eta in [F(0),F(1,8),F(1,2),F(3,4)]:
 for z in [F(0),F(1,3),F(2)]:
  m2, hi, low=F(2,5),F(1,7),F(3,8)
  total=m2+z+hi+low
  assert total-(m2+hi+low/4)==z+3*low/4;n+=1
  q=F(1,4)+3*eta/4
  assert q*total+3*m2/4-z/4-(m2+hi+low/4)==3*(eta*total-hi)/4;n+=1
for aa,bb,cc,dd in [(F(1,5),F(1,10),F(1,7),F(1,4)),(F(1,3),-F(1,8),F(1,6),F(1,5))]:
 a=1/(1-aa-bb*cc/(1-dd));w=cc*a/(1-dd)
 assert a==1+aa*a+bb*w;n+=1
 assert w==cc*a+dd*w;n+=1
print(f'{n} exact Fraction algebra assertions PASS; no native/history model claimed.')
```
