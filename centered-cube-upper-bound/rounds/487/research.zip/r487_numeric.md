# R487：高类empty支持与模父常数收缩的有限证书

指定数学Python实际执行4个有限source/candidate模型×3个支持函数，共12个valid例，另2个明确不满足empty支持的旧high-only障碍。203项检查通过；包含符号Poisson矩、支持、有限性与不等式，不是203个独立模型。计算不证明一般H界、原Schur预算或原J*输出资格。

## 最终追加：锐系数与centered-output形式

同一12个valid例增加锐系数η=1−exp(−δ)、q=1/4+3η/4，不新增模型或参数。所有例严格核

||Hh||²≤q||h||²+(3/4)|Eh|²，

以及其代数等价形式

||Hh||²−|Eh|²≤q||h||²−(1/4)|Eh|²。

两式的界差由SymPy一般恒等和各例独立Arb残差核相等；不是第二套独立样本。自然参考的H保均值，左端即centered-output能量。非零high投影的8例还严格核Vhi<η·E[a0² exp(−Λ_hi)]，另4个low输入投影精确0。η<δ均实际核验。

| δ | η近似 | q近似 |
|---|---:|---:|
| 1/16 | .060586937187 | .295440202890 |
| 1/4 | .221199216929 | .415899412696 |
| 3/4 | .527633447259 | .645725085444 |

原线性系数1/4+3δ/4留作较粗比较。12例的锐界余量全部严格正；empty-indicator的界差在四模型中约.03020773、.03020773、.10855649、.20199855。该追加仍只测试支持类h，不声称数值构造了实际J*V或验证原高门。

## 1. 实际source几何和冻结参数

完整f=1_{[−3,3]}，固定父B=[−1,1]，m_B=2，π_B均匀。真实子cube为

H0=[−3/4,3/4]，完整m=3/2，p0=3/4；
H1=[−7/20,23/20]，完整m=3/2，p1=27/40；
L=[1/10,11/10]，完整m=1，pL=9/20≤1/2。

所有完整cube在f支撑内，质量不以与B的交集代替。代码用实际π_B交集长度核p，并以有理平方核high类γ_BC²=I_BC²/(m_Bm_C)≥p_C²>1/4，因此这两个high cube若出现，确无法通过含B的1/2亲和行门。这只核该必要排除算术，不构造实际J*。

有限自然参考的high计数按capture独立Poisson。δ定义为实际sup_XΛ_hi(X)，而非未经验证地代入8rS/T。

| 阶段 | high candidates及其强度 | δ |
|---|---|---|
| 初探 | H0：1/16 | 1/16 |
| 重复原子压力 | 两个独立type均为H0：各1/32 | 1/16 |
| 扩大不同几何 | H0,H1：各1/8 | 1/4 |
| 扩大预算 | H0,H1：各3/8 | 3/4 |

每个模型另有low type L，强度1/2。重复high cube是不同Poisson type、同一实际source集合；不能将其source捕获当独立。四模型均以真实端点分割source signature，并核sup高强度恰为表中δ<1。有限candidate强度不是实际Lebesgue中心场，不声称满足原固定source Schur/CDF条件。

## 2. 三类支持函数与条件方差

所有valid输入为

h=1_{F_hi=empty}[a0(X)+1_L(X)(a1 C1(F_L)+a2 C2(F_L))]。

C1=N−λ、C2=N(N−1)−2λN+λ²，λ=1/2。SymPy以Poisson factorial moments精确核均值0、互相正交、方差λ和2λ²，不作count截断。

三个输入：

- empty indicator：a0=1，a1=a2=0；
- centered source：a0=1_H0−c，c=E[1_H0 exp(−Λ_hi)]/E[exp(−Λ_hi)]，其均值解析为0；
- repeated-low chaos：a0=0，a1=1，a2=1/2，含同一low原子的二阶Charlier项。

令q(X)=exp(−Λ_hi(X))。条件于X且对low平均后，high投影为a0(X)1_empty，故pure high-configuration variance准确为

Vhi=E[a0²(q−q²)]。

脚本独立计算norm与该方差，核Vhi≤δ E[a0²q]≤δ||h||²；第三输入投影和Vhi精确0。中心化常数含指数，但由有限signature的精确表达定义，Arb残差只作区间相容检查，不将contains0独立当作零均值证明。

## 3. 不镜像候选界的直接H范数计算

没有把候选谱系数作为H数值定义。给定输出(Z,G)，取两个独立输入source副本X、X′。自然保点耦合中，一个high type在这两个输入的empty因子乘积对G积分为

exp{−λ[z·max(a,b)+(1−z)(a+b)]}，

a=1_C(X),b=1_C(X′),z=1_C(Z)。

这是Poisson零点PGF及共享计数的直接结果；代码逐8种0/1组合用SymPy核。low部分则由C1/C2的正交矩计算。因此||Hh||²通过真实source signature上的有限三重和求得，所有high无限chaos已由指数PGF解析求和，没有无误差界的chaos截断。

初始线性比较亦实际核验：

||Hh||²≤(1/4+3δ/4)||h||²+(3/4)|Eh|²。

最终主报告使用上方更锐的q系数，两种界均保存在JSON。

| 模型 | empty indicator：||Hh||²/||h||² | centered source | low C1+C2 |
|---|---:|---:|---:|
| 单high，δ1/16 | .97971433 | .00892562 | .19817967 |
| 重复同high，各率减半 | .97971433 | .00892562 | .19817967 |
| 两不同high，δ1/4 | .91680281 | .01861805 | .19395916 |
| 两不同high，δ3/4 | .76971180 | .05629545 | .17794445 |

重复压力与单high的norm、mean及Hnorm之差均被独立核为0的区间相容值；解析上它们依赖相同总强度δ和同一source集合，因此完全一致。

第三输入含low阶，实际还严格核||Hh||²<||h||²/4。第一模型的empty indicator若丢掉父常数项，.97971433>19/64=.296875，会违反误用版本；因此本局部接口不能把“模父常数收缩”改成普通无常数收缩。

## 4. 支持限制的必要性压力

另取单high自然参考下的h=1_H0 C_k(F_H0)，k=1、2。这些函数均值0，却不支持F_hi=empty。其source rank-one系数p0=3/4，准确给

||Hh||²/||h||²=p0²=9/16>19/64。

二阶重复原子也仍为9/16，而不是把p0再平方一次得到其它阶数衰减。两个例子均违反把新界误用于无empty支持类的版本。它们只作为scope压力，不是新候选的反例。

## 5. 决策、边界与复现

本有限证据区分了三件事：empty支持使high-configuration variance可由实际δ价格控制；parent常数项不可丢；重复Poisson type不会自动让source谱按重复次数衰减。它没有证明原J*V必在该支持类，也没有验证原Schur给δ≤8rS/T的全部几何/原权假设。low类p≤1/2只是H谱标签，不保证其自身γ行门一定通过；本计算不声称构造完整成功族。

命令：

`/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python r487_numeric.py`

实际Python3.12.14、SymPy1.14.0、Arb256-bit。来源、质量和强度为Fraction精确，所有指数概率/三重积分和界差由严格Arb球包围；无MC、solver、source网格或Poisson尾截断。环境和实际用时记录于JSON compute_index。脚本自含并输出自身目录，stdout固定摘要。

归档仅r487_numeric.py、r487_numeric.json、r487_numeric.md。一般证明由作者审查，不从12例外推；计算已停止。
