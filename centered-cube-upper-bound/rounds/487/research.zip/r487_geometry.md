# R487：实际成功值域的配置波动收缩

## 1. 范围和原门

沿 R486 的自然状态 \((B,s_B,x,F)\)，\(F\) 是同一原质量带内、增广质量次序低于 \((B,s_B)\)、捕获 \(x\) 的**全部 raw Poisson 点**。自然参考为
\[
\mathsf M(dB,ds_B,dx,dF)=\nu(dB)ds_B\,M_{B,s_B}(dx,dF),
\quad M_{B,s_B}=\pi_B(dx)\operatorname{PPP}_{\Lambda_{B,s_B,x}}(dF).
\]
其中 \(\nu=t\sigma\)、\(0\le t\le S\)、\(\sigma=q_A\,dA\)、\(r=\lambda/q\)，\(\pi_B=c_B\mu/m_B\)，以及
\[
\Lambda_{B,s_B,x}(dC,ds_C)
=\frac1T1_{(C,s_C)\prec(B,s_B)}
 \frac{t(C)c_C(x)}{m_C}\sigma(dC)ds_C.
\]
\(J\) 是保全部原成功判据、输出最大父及其全部低秩 raw 点的次 Markov 算子；\(H\) 是 R486 的自然来源刷新，\(\mathcal P=JH\)。这是保自然参考的新分析链，不声称与原每步独立重抽配置的父链同律。已证 \(\mathsf M J\le\mathsf M\)、\(J1\le1\)，故 \(J^*\) 是 \(L^2(\mathsf M)\) 收缩。

固定父与标记，设
\[
p_B(C)=\pi_B(Q_C),\qquad
\mathcal E_{\rm hi}=\{(C,s_C):p_B(C)>1/2\}.
\tag{1}
\]
R479 的实际成功门要求**最大父的整条 raw 亲和行**不超过 \(1/2\)，不是仅在删行后对 \(F_0\) 作此要求。R482 及后续正限制没有撤销它。最大父满足 \(m_C\le m_B\)，所以
\[
p_B(C)=\frac{I_{BC}}{m_B}
\le\frac{I_{BC}}{\sqrt{m_Bm_C}}=\gamma_{BC}.
\]
因此每个实际成功输出均有 \(F_{\rm hi}=\varnothing\)。对任意实或复 \(v\in L^2(\mathsf M)\)，
\[
h=J^*v\quad\Longrightarrow\quad
h=0\quad\mathsf M\text{-a.e. on }\{F_{\rm hi}\ne\varnothing\}.
\tag{2}
\]
这是成功转移支撑推出的伴随值域性质，不用成功后的配置是 Poisson。

对每个 \(x\in Q_B\)，R479 的固定来源真实 Schur 界给
\[
\int\gamma_{BC}\frac{t(C)c_C(x)}{m_C}\sigma(dC)\le4rS.
\]
同带和标记限制只缩小积分，故自然参考下的高类强度满足
\[
\lambda_{m hi}(B,s_B,x)
\le\frac2T\int\gamma_{BC}\frac{t(C)c_C(x)}{m_C}\sigma(dC)
\le d:=\frac{8rS}{T}.
\tag{3}
\]
这对整个 \(\pi_B\) 来源域成立，没有将任意集中来源质量换成中心体积。质量原子由原均匀标记保留；高类的等号 \(p_B(C)=1/2\) 归入低类。

## 2. 高类空配置给实际值域收缩

本节固定 \((B,s_B)\)，记自然概率为 \(M_B\)。对任意满足 (2) 的 \(h\in L^2(M_B)\)，给定 \(x\) 时 high/low 两类 Poisson 独立。令
\[
a(x)=\mathbb E[h(x,F_{\rm lo},\varnothing)\mid x],
\qquad
P_{m hi}h=\mathbb E[h\mid x,F_{\rm hi}]
=a(x)1_{F_{\rm hi}=\varnothing}.
\]
在 \(\lambda=\lambda_{m hi}(x)\) 处，零阶来源函数是 \(a(x)e^{-\lambda}\)。因而正阶 pure-high 混沌的总范数精确为
\[
N_{m hi}
=\int |a(x)|^2(e^{-\lambda}-e^{-2\lambda})\pi_B(dx)
\le(1-e^{-d})\|P_{m hi}h\|^2
\le(1-e^{-d})\|h\|^2.
\tag{4}
\]
\(d<\infty\) 保证空配置概率正，条件表达在零来源质量处任意定义即可。

引用 R486 已证的条件 Poisson 混沌谱公式：含至少一个低类成员的 tuple，其 \(H\) 特征值至多 \(1/2\)；pure-high 部分至多1；零阶来源函数经 \(H\) 只留下其来源均值。此公式保留重复候选和原子，不将 \(\pi_B(C)^k\) 误作 tuple 交集概率。

记 \(N_0,N_{m hi},N_{m lo}\) 为三个正交部分的平方范数，\(m_h=\int h\,dM_B\)。则
\[
\|Hh\|^2\le |m_h|^2+N_{m hi}+\tfrac14N_{m lo}.
\]
用 \(N_0\ge|m_h|^2\) 和 (4)，得到
\[
\boxed{\|Hh\|^2
\le q_*\|h\|^2+\tfrac34|m_h|^2,
\qquad q_*:=1-\tfrac34e^{-d}<1.}
\tag{5}
\]
特别地，\(q_*\le1/4+3d/4\)，包含计划中的较松常数。没有假定整个 \(H\) 有谱隙；(5) 仅对高类空配置支撑成立，而 (2) 将实际 \(J^*\) 值域放进这个范围。

## 3. 真正统一的输出波动界与父常数桥

令 \(Q\) 是对给定父与标记的自然概率取均值的正交投影。\(QH=Q\)，所以在各父积分 (5) 并减去 \(\|Qh\|^2\)，得
\[
\boxed{\|(I-Q)\mathcal P^*v\|^2
\le q_*\|J^*v\|^2-\tfrac14\|QJ^*v\|^2
\le q_*\|v\|^2.}
\tag{6}
\]
因此实际波动块
\[
D=(I-Q)\mathcal P^*(I-Q),\qquad
\|D\|\le\sqrt{q_*}<1,
\qquad \|(I-D)^{-1}\|\le(1-\sqrt{q_*})^{-1}
\tag{7}
\]
有可求和 Neumann 级数。所有原成功、接受和历史条件仍在 \(J\) 中；这里只用原门控制值域，不将历史差作为零项丢掉。这是本轮新增的一般实际值域估计。

但 (6) 的父常数部分没有收缩结论。精确地，在父与标记测度 \(\widehat\nu=\nu(dA)ds_A\) 上定义一次平均核
\[
\widehat K g=QJg\quad(g\text{ 为父与标记函数}).
\]
它是原 \(J\) 对自然来源、配置的一次平均，不是断言新链每步独立刷新。对一般实际密度 \(v\)，父输出为
\[
\boxed{Q\mathcal P^*v=QJ^*v
=\widehat K^*Qv+QJ^*(I-Q)v.}\tag{8}
\]
后一项保留配置—来源相关，符号不定，不能删掉；用 (7) 消去波动后得到的有效父算子也不能未经证明就认作正 Markov 核。即使输入本来是父常数，\(\widehat K^*Qv\) 的无权停止来源价仍需几何结算。

例如初始 \(v=1\) 时 \(0\le QJ^*1\le1\)，现有直接估计仅为 \(\|QJ^*1\|^2\le R\le SX\)，不是根阶 \(W\) 价。质量加权 Green 亦不能去掉其质量配对。故本轮可合法求和的是**实际输出波动**，尚未证明父常数停止费用 \(\varepsilon X+C_\varepsilon\sqrt n\operatorname{polylog}(n)W\)。没有把旧核一次失败价迁移为新链累计价。

## 4. 本机有限核验

以下代码已由指定本机 Python 实际运行，输出：
`Arb finite conditional-Poisson cases: 24 PASS; spectral coefficient identity: 1 PASS`。
它用三来源、三种高候选及一种低候选的有限条件 Poisson 模型，检查同时含 high-empty 因子和一阶低类混沌的函数；192-bit Arb 核方向，唯一精确等号情形另有解析等号。它验证算子接口，不是原生 Lebesgue 中心/全部成功历史实例。

```python
from fractions import Fraction as F
from flint import arb, ctx
import sympy as s
ctx.prec=192
def A(q):
    q=F(q); return arb(q.numerator)/q.denominator
pi=[F(1,2),F(1,4),F(1,4)]
his=[(1,1,1),(1,1,0),(1,0,1)]
lo=(0,1,1); rateL=F(1,5)
profiles=[(F(0),)*3,(F(1,100),)*3,
          (F(1,10),F(1,5),F(1,20))]
avs=[(1,1,1),(-1,0,1),(1,2,-1),(0,1,3)]
bvs=[(0,0,0),(1,-2,3)]
n=0
for rates in profiles:
    lam=[sum((rate*sig[x] for rate,sig in zip(rates,his)),F(0))
         for x in range(3)]
    d=max(lam)
    for av in avs:
      for bv in bvs:
        N=sum((A(pi[x]*av[x]**2)*(-A(lam[x])).exp()
               *A(1+bv[x]**2*rateL*lo[x]) for x in range(3)),arb(0))
        mean=sum((A(pi[x]*av[x])*(-A(lam[x])).exp()
                  for x in range(3)),arb(0))
        H2=arb(0)
        for z in range(3):
          for x in range(3):
            for y in range(3):
              triple=sum((rate*sig[x]*sig[y]*sig[z]
                          for rate,sig in zip(rates,his)),F(0))
              H2+=A(pi[z]*pi[x]*pi[y]*av[x]*av[y])\
                  *(-A(lam[x]+lam[y]-triple)).exp()\
                  *A(1+bv[x]*bv[y]*rateL*lo[x]*lo[y]*lo[z])
        bound=(1-A(F(3,4))*(-A(d)).exp())*N+A(F(3,4))*mean**2
        if d==0 and av==(1,1,1) and bv==(0,0,0):
            assert (bound-H2).contains(0)  # exact h=1, Hh=1
        else:
            assert bound-H2>=0
        n+=1
N0,Nh,Nl,m2,D=s.symbols('N0 Nh Nl m2 D')
res=s.expand((1-s.Rational(3,4)*(1-D))*(N0+Nh+Nl)
             +s.Rational(3,4)*m2-(m2+Nh+s.Rational(1,4)*Nl))
assert s.expand(res-s.Rational(3,4)*(D*(N0+Nh+Nl)-Nh)
                -s.Rational(1,4)*(N0-m2))==0
print('Arb finite conditional-Poisson cases:',n,
      'PASS; spectral coefficient identity: 1 PASS')
```
