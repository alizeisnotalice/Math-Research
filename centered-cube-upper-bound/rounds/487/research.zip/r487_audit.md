# R487 FINAL PASS（仅限实际值域与波动块工具）

独立预审先于作者稿；终审核对全部八项冻结输入及最后显式常数更新。PASS认证原成功raw行门的值域限制、空高类谱比较、实际全输入波动收缩和精确消元；不认证父均值/完整停止的根阶来源预算。

已独立读取索引指定R479原文：最大父门针对整个raw行，故J*v确支持F_hi为空。质量非增及真实fixed-source Schur给λ_hi≤d_hi=8rS/T，不是来源密度帽。自然high/low独立给pure-high正阶平方范数≤(1−e^{-d_hi})||h||²；零阶与均值保留，得到q*=1−3e^{-d_hi}/4。该支持界不被扩大成全H统一谱隙。Q始终给定父与mark，未偷换成仅父或全局平均。

QH=Q与J*收缩正确给||(I−Q)P*v||²≤q*||v||²−||QJ*v||²/4，故D范数≤√q*。最后常数q*≤515/2048<(51/100)²、逆界100/49及对应尾界已用精确有理算术核清，不增加模型统计。真实V的终端与L²沿R486成立；块消元保原初始1、全部停止与有符号交叉。有效父算子不自动正/次Markov，父均值及母账费用仍未付。列尾Cauchy方向正确，零列h=0且截断极限无∞−∞；它作用于同一实际h，未拼接别的积分收益。

实际独立隔离复现：指定Python、新临时目录，运行geometry/proof内嵌代码及numeric.py，25、28、203项共256项通过，三段stdout与replay逐字一致。numeric JSON仅剔除compute_index.seconds后全字段相同，canonical SHA256：3022cdbaee844eaff314847c17d6039ac816ac0c29760068a23d67905c6a0531。数值仅12个支持类有限条件Poisson函数及2个明确范围外压力例；不认证Lebesgue接收场、原J*实现或全部history。严格方向须整Arb球满足，零残差含0仅作解析等式的相容检查。未编译PDF，一般目标未闭合。

冻结输入 SHA256：

- `r487_main.md`: `717dbedd7f5114320eb905d3fccc72fdf5cc668a0bd7721f5e290dc61c6109bf`
- `r487_geometry.md`: `bc9d900ad44eab48b18a4ee56496c5a91fff94d3333bcb1f7aa7bb6fe6481b76`
- `r487_proof.md`: `6e174034af759918a1220b7a460c05778a040ab09305fc11fc2931f69beecc9f`
- `r487_numeric.md`: `10e25b527049d9452873116023da38008a9b2394afb53ef66403faa6d7abe29d`
- `r487_numeric.py`: `95f6ed0a4c5e6582798d8c5821aaf965a75109594ac5e58e9a02fd961112c64d`
- `r487_numeric.json`: `fbb248680fe73916922b17dbe4198a3fbe5703344175f366954164f14c7c3d8b`
- `r487_maxrow_index.md`: `c67fd78c275dd40c69fd392e5f3834adec3d88e504318dfec0617084e4fe24c3`
- `r487_replay.json`: `86b429936a69a2a8535ba38b08be346bd29d19fdbfbf2c35063796cae91356b9`
