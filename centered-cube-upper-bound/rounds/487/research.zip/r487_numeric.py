from fractions import Fraction as F
from pathlib import Path
from math import factorial
import sys,platform,json,time
import sympy as sp
from sympy.functions.combinatorial.numbers import stirling
from flint import arb,ctx
ROOT=Path(__file__).resolve().parent;ctx.prec=256
start=time.perf_counter();checks=0

def ck(v):
 global checks
 assert v
 checks+=1

def ar(v):
 if isinstance(v,arb):return v
 v=F(v);return arb(v.numerator)/v.denominator
# Independent exact Poisson moments for the low first and repeated-atom
# second chaos; no count cutoff enters any source calculation below.
n,lam,q=sp.symbols('n lam q',positive=True)
C1=n-lam;C2=n*(n-1)-2*lam*n+lam**2

def EP(poly):
 return sp.expand(sum(coef*sum(stirling(power[0],j,kind=2)*lam**j for j in range(power[0]+1)) for power,coef in sp.Poly(sp.expand(poly),n).terms()))
for C,k in [(C1,1),(C2,2)]:ck(EP(C)==0);ck(EP(C*C)==factorial(k)*lam**k)
aa,bb,cc,qq=sp.symbols('aa bb cc qq',real=True)
ck(sp.expand((qq*aa+sp.Rational(3,4)*bb-cc)-(qq*aa-sp.Rational(1,4)*bb-(cc-bb)))==0)
ck(EP(C1*C2)==0);ck(sp.exp(lam*(q-1)).subs(q,0)==sp.exp(-lam))
for a in (0,1):
 for b in (0,1):
  for z in (0,1):
   lhs=(sp.exp(lam*(q-1)).subs(q,0) if a or b else 1) if z else sp.exp(-lam*a)*sp.exp(-lam*b)
   ck(sp.simplify(lhs-sp.exp(-lam*(z*max(a,b)+(1-z)*(a+b))))==0)

H0=(F(-3,4),F(3,4));H1=(F(-7,20),F(23,20));LOW=(F(1,10),F(11,10));mB=F(2)
def prob_intersection(cubes):
 lo=max([F(-1)]+[c[0] for c in cubes]);hi=min([F(1)]+[c[1] for c in cubes]);return max(F(0),hi-lo)/2
for C in (H0,H1,LOW):ck(-3<=C[0]<C[1]<=3)
for C in (H0,H1):
 p=prob_intersection([C]);mc=C[1]-C[0];g2=(2*p)**2/(mB*mc)
 ck(p>F(1,2));ck(g2>=p*p);ck(g2>F(1,4))
ck(prob_intersection([LOW])<=F(1,2))
settings=[('initial_single_high',[H0],[F(1,16)],F(1,16)),('duplicate_high_pressure',[H0,H0],[F(1,32),F(1,32)],F(1,16)),('expanded_distinct_high',[H0,H1],[F(1,8),F(1,8)],F(1,4)),('expanded_larger_budget',[H0,H1],[F(3,8),F(3,8)],F(3,4))]
rows=[];models=[];single_outputs={}
for name,highs,hrates,delta in settings:
 cubes=highs+[LOW];Lidx=len(highs);ll=F(1,2)
 ep=sorted(set([F(-1),F(1)]+[max(F(-1),min(F(1),v)) for C in cubes for v in C]))
 cells=[]
 for lo,hi in zip(ep,ep[1:]):
  x=(lo+hi)/2;sig=[int(C[0]<x<C[1]) for C in cubes];Lambda=sum(hrates[j]*sig[j] for j in range(Lidx))
  cells.append(dict(interval=[lo,hi],prob=(hi-lo)/2,sig=sig,Lambda=Lambda,empty=(-ar(Lambda)).exp()))
 ck(sum(c['prob'] for c in cells)==1);ck(max(c['Lambda'] for c in cells)==delta);ck(0<delta<1)
 M=len(cells)
 eta_sharp=1-(-ar(delta)).exp();q_sharp=ar(F(1,4))+ar(F(3,4))*eta_sharp
 ck(0<eta_sharp<ar(delta))
 # Direct conditional expectation of two input high-empty factors given
 # output (Z,G); Poisson PGF supplies the shared-zero coefficient.
 kernels=[]
 for z in cells:
  A=[]
  for x in cells:
   rr=[]
   for y in cells:
    exponent=sum(hrates[j]*(z['sig'][j]*max(x['sig'][j],y['sig'][j])+(1-z['sig'][j])*(x['sig'][j]+y['sig'][j])) for j in range(Lidx))
    rr.append((-ar(exponent)).exp())
   A.append(rr)
  kernels.append(A)
 denom=sum((ar(c['prob'])*c['empty'] for c in cells),arb(0))
 center=sum((ar(c['prob']*c['sig'][0])*c['empty'] for c in cells),arb(0))/denom
 ck(denom>0);ck(0<center<1)
 models.append(dict(name=name,high_intervals=[[str(v) for v in C] for C in highs],high_rates=list(map(str,hrates)),low_interval=list(map(str,LOW)),low_rate=str(ll),delta_max=str(delta),high_capture_probabilities=[str(prob_intersection([C])) for C in highs],low_capture_probability=str(prob_intersection([LOW])),source_cells=[dict(interval=list(map(str,c['interval'])),prob=str(c['prob']),signature=c['sig'],Lambda_high=str(c['Lambda'])) for c in cells]))
 for kind in ('empty_indicator','centered_source_empty','low_first_plus_second_empty'):
  if kind=='empty_indicator':a0=[arb(1)]*M;a1=[F(0)]*M;a2=[F(0)]*M
  elif kind=='centered_source_empty':a0=[ar(c['sig'][0])-center for c in cells];a1=[F(0)]*M;a2=[F(0)]*M
  else:a0=[arb(0)]*M;a1=[F(1)]*M;a2=[F(1,2)]*M
  norm=sum((ar(c['prob'])*c['empty']*(a0[i]*a0[i]+ar(c['sig'][Lidx])*(ar(ll*a1[i]*a1[i])+ar(2*ll*ll*a2[i]*a2[i]))) for i,c in enumerate(cells)),arb(0))
  mean=sum((ar(c['prob'])*c['empty']*a0[i] for i,c in enumerate(cells)),arb(0))
  highnorm=sum((ar(c['prob'])*c['empty']*a0[i]*a0[i] for i,c in enumerate(cells)),arb(0))
  highvar=sum((ar(c['prob'])*a0[i]*a0[i]*(c['empty']-c['empty']*c['empty']) for i,c in enumerate(cells)),arb(0))
  normH=arb(0)
  for zi,z in enumerate(cells):
   for xi,x in enumerate(cells):
    for yi,y in enumerate(cells):
     lowpart=ar(z['sig'][Lidx]*x['sig'][Lidx]*y['sig'][Lidx])*(ar(ll*a1[xi]*a1[yi])+ar(2*ll*ll*a2[xi]*a2[yi]))
     normH+=ar(z['prob']*x['prob']*y['prob'])*kernels[zi][xi][yi]*(a0[xi]*a0[yi]+lowpart)
  coefficient=F(1,4)+F(3,4)*delta;rhs=ar(coefficient)*norm+ar(F(3,4))*mean*mean
  sharp_rhs=q_sharp*norm+ar(F(3,4))*mean*mean
  centered_left=normH-mean*mean;centered_right=q_sharp*norm-ar(F(1,4))*mean*mean
  ck(normH<sharp_rhs);ck(centered_left<centered_right)
  ck(((sharp_rhs-normH)-(centered_right-centered_left)).is_finite() and ((sharp_rhs-normH)-(centered_right-centered_left)).contains(0))
  ck(all(v.is_finite() for v in (norm,mean,highnorm,highvar,normH,rhs)));ck(norm>0);ck(normH>0);ck(normH<rhs)
  if kind=='low_first_plus_second_empty':ck(highvar==0);ck(highnorm==0);ck(mean==0);ck(normH<norm/4)
  else:ck(highvar>0);ck(highvar<ar(delta)*highnorm);ck(highvar<eta_sharp*highnorm)
  ck((norm-highnorm)>0 or (norm-highnorm).contains(0))
  if kind=='centered_source_empty':ck(mean.contains(0))
  constant_needed=name=='initial_single_high' and kind=='empty_indicator'
  if constant_needed:ck(normH>ar(coefficient)*norm)
  if name=='initial_single_high':single_outputs[kind]=(norm,normH,mean)
  if name=='duplicate_high_pressure':
   for a,b in zip((norm,normH,mean),single_outputs[kind]):ck((a-b).is_finite() and (a-b).contains(0))
  rows.append(dict(eta_sharp=str(eta_sharp),q_sharp=str(q_sharp),sharp_bound_rhs=str(sharp_rhs),sharp_bound_margin=str(sharp_rhs-normH),centered_output_norm_squared=str(centered_left),centered_output_bound_rhs=str(centered_right),model=name,input_kind=kind,h='1_Fhigh_empty*(a0(X)+1_low(X)*(a1*C1+a2*C2))',norm_squared=str(norm),mean=str(mean),conditional_high_projection_norm=str(highnorm),pure_high_configuration_variance=str(highvar),variance_upper_delta_norm=str(ar(delta)*norm),Hh_norm_squared=str(normH),Hh_norm_ratio=str(normH/norm),delta=str(delta),coefficient_1_over_4_plus_3delta_over_4=str(coefficient),full_new_bound_rhs=str(rhs),positive_bound_margin=str(rhs-normH),parent_constant_credit_necessary_in_this_case=constant_needed,scope='Natural-reference finite candidate model; supported high-empty functions only'))
# Known high-only obstruction outside the new allowed support.
pH=prob_intersection([H0]);delta=F(1,16);A=F(1,4)+F(3,4)*delta
obstacles=[]
for order in (1,2):
 rate=F(1,16);chaos=F(factorial(order))*rate**order;norm=pH*chaos;out=pH**3*chaos
 ck(out/norm==pH*pH);ck(out>A*norm)
 obstacles.append(dict(order=order,input='1_H0(X)*Charlier_order(F_H0;lambda)',supported_on_high_empty=False,mean='0',norm_squared=str(norm),Hh_norm_squared=str(out),ratio=str(out/norm),new_coefficient_if_misapplied=str(A),violates_misapplied_bound=True))
result=dict(scope='Finite actual source/candidate intervals and natural-reference Poisson formulas; no original raw-row/Schur/highgate/history qualification.',compute_index=dict(executable=sys.executable,python=platform.python_version(),sympy=sp.__version__,arb_precision_bits=ctx.prec,command='"'+sys.executable+'" r487_numeric.py',seconds=time.perf_counter()-start),checks=checks,models=models,valid_cases=rows,unsupported_high_only_obstacles=obstacles,formula=dict(high_variance='int a(X)^2*(exp(-Lambda_hi)-exp(-2Lambda_hi)) dpi <= delta*||h||^2',new_bound='||Hh||^2 <= q||h||^2+(3/4)|mean h|^2, eta=1-exp(-delta),q=1/4+3eta/4',old_linear_bound='q<=1/4+3delta/4',centered_equivalent='||Hh||^2-|mean h|^2<=q||h||^2-(1/4)|mean h|^2',direct_Hnorm='Triple source integral using shared-high zero PGF and orthogonal low Charlier moments',delta='actual max_X sum high lambda_j*1_Cj(X), not claimed from original Schur theorem'),exactness='Source/cube probabilities, rates and Charlier moments exact Fraction/SymPy. High-empty and source triple integrals are finite analytic PGF expressions with256-bit Arb; no count truncation, Monte Carlo or solver.')
(ROOT/'r487_numeric.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS',checks,'checks;12 supported high-empty cases and2 explicitly unsupported high-only obstacles; finite natural reference only')
