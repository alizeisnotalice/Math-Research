"""R764 sharp price-translation candidates and closed-cube sign repair."""

from fractions import Fraction as Q
from itertools import product
from math import prod


def interval(center,radius):
    return center-radius,center+radius


def inside(I,x):
    return I[0]<=x<=I[1]


def distance(I,x):
    return max(I[0]-x,x-I[1],Q(0))


def candidate_audit():
    a,h = 32,Q(33,32)
    # Exact parent centers and half-sides of the original R764 1D fixture.
    parents = {
        "k":(Q(0),Q(3,8)), "u0":(Q(-1,5),Q(1,2)), "u1":(Q(1,5),Q(1,2)),
        "p":(Q(-3,4),Q(3,2)), "q":(Q(3,4),Q(7,4)), "r":(Q(-5,4),Q(2)),
        "s":(Q(5,4),Q(5,2)),
    }
    old_price,other_price = Q(-1,5),Q(1,5)
    A_t = interval(*parents["s"])
    assert all(inside(interval(*parents[j]),z) for j in parents for z in (old_price,other_price))
    Y1 = parents["u0"][0]+Q(1,128)
    Y1_other = parents["u1"][0]+Q(1,128)
    Y2 = parents["p"][0]-Q(3,128)
    V1 = (Y1-old_price)/h
    V2 = (Y2-old_price)/(2*h)
    assert V1==Q(1,132)==(Y1_other-other_price)/h
    assert V2==Q(-367,1320)
    for label,Y in (("u0",Y1),("p",Y2),("u1",Y1_other)):
        center,radius = parents[label]
        assert abs(Y-center)<radius/a

    def candidates(V,R):
        # The band volume is [R,2R) here; its upper radius is R.
        return {j:(center-h*R*V,radius/a) for j,(center,radius) in parents.items()
                if R<=2*radius<2*R}

    first,second = candidates(V1,Q(1)),candidates(V2,Q(2))
    assert set(first)=={"u0","u1"} and set(second)=={"p","q"}
    assert all(distance(A_t,X)<=e for X,e in first.values())
    assert abs(first["u0"][0]-old_price)<first["u0"][1]
    assert abs(first["u1"][0]-other_price)<first["u1"][1]
    assert abs(second["p"][0]-old_price)<second["p"][1]
    accepted = []
    comparisons = []
    for i,(X,e_i) in first.items():
        for j,(Z,e_j) in second.items():
            gap = abs(X-Z)
            if distance(A_t,X)<=e_i and gap<=e_i+e_j:
                accepted.append((i,j))
            comparisons.append(f"{i},{j}:{gap}<={e_i+e_j} is {gap<=e_i+e_j}")
    assert accepted==[("u0","p")]
    X,e_i = first["u0"]
    Z,e_j = second["p"]
    surviving_interval = (max(X-e_i,Z-e_j,A_t[0]),min(X+e_i,Z+e_j,A_t[1]))
    assert inside(surviving_interval,old_price) and not inside(surviving_interval,other_price)
    print(f"real 1D prices {old_price},{other_price}; actual owners Y1={Y1},Y2={Y2}; V1={V1},V2={V2}")
    print("X,e for the first and second observations",first,second)
    print("first candidate distances to A_t",{j:str(distance(A_t,X)) for j,(X,e) in first.items()})
    print("two-observation tests","; ".join(comparisons))
    print(f"accepted {accepted}, retained price interval {surviving_interval}")


def repair_audit(s,e,z,errors):
    A = interval(Q(0),s)
    assert 0<e<=s and all(inside(A,x) for x in z)
    assert all(abs(d)<=e for d in errors)
    prediction = [x+d for x,d in zip(z,errors)]
    n = len(z)
    axis_success = [sum(inside(A,x+sgn*e) for sgn in (-1,1)) for x in prediction]
    safe = [s-abs(x)>=2*e for x in z]
    assert all(count>=1 and (not roomy or count==2) for count,roomy in zip(axis_success,safe))
    hit = []
    for signs in product((-1,1),repeat=n):
        point = tuple(x+d*e for x,d in zip(prediction,signs))
        if all(inside(A,x) for x in point):
            hit.append(point)
    assert Q(len(hit),2**n)==prod(Q(c,2) for c in axis_success)>=Q(1,2**sum(not v for v in safe))
    if all(abs(x)==s for x in z):
        assert hit==[z]
        assert not any(all(-s<x<s for x in point) for point in hit)
    print(f"repair dim={n} near={sum(not v for v in safe)} closed hit={Q(len(hit),2**n)} safe axis hits={axis_success}")


def main():
    candidate_audit()
    s,e = Q(3,8),Q(3,64)
    repair_audit(s,e,(s,-s),(e,-e))
    repair_audit(s,e,(s,-s+e,s-2*e,Q(0)),(e,-e/2,e,-e))
    repair_audit(s,s,(Q(0),),(Q(0),))
    assert all(not inside(interval(Q(0),s),z) for z in (-2*s,2*s))
    print("The 1D fixture uses the original test L0=1/8. These checks cover geometry and same-price consistency. With e=2s both signs can miss.")


if __name__=="__main__":
    main()

