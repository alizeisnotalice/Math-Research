"""R764 marked band density, same-price pair weights and witness radius checks."""

import argparse
from collections import defaultdict
from fractions import Fraction as Q
from hashlib import sha256
from itertools import combinations, product
import json
from pathlib import Path
from platform import python_version


def interval(y,r):
    return y-r,y+r


def meet(*intervals):
    return max(a for a,b in intervals),min(b for a,b in intervals)


def length(I):
    return max(Q(0),I[1]-I[0])


def disjoint(I,J):
    return max(I[0],J[0])>=min(I[1],J[1])


def volume_band(d):
    k = d.numerator.bit_length()-d.denominator.bit_length()
    return k if Q(2)**k<=d else k-1


def vector_band_density(h,shrink,L,U,z,p,parents,owners):
    bands = defaultdict(list)
    centers_checked = []
    maximum_conditional = Q(0)
    rows = []
    for j in p:
        y,s = parents[j]
        bands[volume_band(2*s)].append(j)
    for b,labels in sorted(bands.items()):
        R = Q(2)**b
        # Right endpoint in volume is 2^(b+1); its radius is 2^b.
        assert all(R<=2*parents[j][1]<2*R for j in labels)
        D_box = {j:tuple((x-z)/(h*R) for x in owners[j]) for j in labels}
        assert all(-1<=I[0]<I[1]<=1 for I in D_box.values())
        assert all(disjoint(X,Y) for X,Y in combinations(D_box.values(),2))
        marked_mass = sum(p[j] for j in labels)
        density = {j:2*h*R*p[j]/length(owners[j]) for j in labels}
        assert all(value<=2*h/U<=2*h/L for value in density.values())
        cuts = sorted({x for I in D_box.values() for x in I}|{Q(-1),Q(1)})
        pieces = []
        for x,y in zip(cuts,cuts[1:]):
            center = (x+y)/2
            mass_per_box = sum(w for j,w in density.items() if D_box[j][0]<center<D_box[j][1])
            assert mass_per_box<=2*h/L
            if mass_per_box:
                pieces.append((x,y,mass_per_box))
        assert sum((y-x)*d/2 for x,y,d in pieces)==marked_mass
        maximum_conditional = max(maximum_conditional,max(density.values())/marked_mass)
        rows.append({
            "volume_band":b,"R_b":str(R),"marked_band_probability":str(marked_mass),
            "piecewise_D_relative_density":[[str(x),str(y),str(density)] for x,y,density in pieces],
            "conditional_density_peak_if_band_renormalized":str(max(density.values())/marked_mass),
        })
        for j in labels:
            y,s = parents[j]
            reference_center = (y-z)/(h*R)
            err = max(abs(x-reference_center) for x in D_box[j])
            assert reference_center==s/(h*R)*((y-z)/s)
            assert err==s/(shrink*h*R)<=Q(1,shrink)/h
            centers_checked.append([j,str((y-z)/s),str(reference_center),str(err)])
    assert sum(Q(row["marked_band_probability"]) for row in rows)==1
    return rows,centers_checked,maximum_conditional


def leakage(h,price_pockets,owners,tails,post,neighbor="p"):
    labels = ("u0","u1")
    # u0,u1 have common dyadic R=1.
    support = {(z,j):((owners[j][0]-P[1])/h,(owners[j][1]-P[0])/h)
               for z,P in enumerate(price_pockets) for j in labels}
    assert all(disjoint(support[0,j],support[1,j]) for j in labels)
    central = support[0,"u0"]
    assert central==support[1,"u1"] and length(central)>0
    assert length(owners["u0"])==length(owners["u1"])
    assert length(price_pockets[0])==length(price_pockets[1])
    # Matched pairs are translates of the same two independent uniform laws.
    assert owners["u0"][0]-price_pockets[0][0]==owners["u1"][0]-price_pockets[1][0]
    short = (Q(-1,32),Q(1,32))
    assert meet(central,short)==central
    assert disjoint(short,support[0,"u1"]) and disjoint(short,support[1,"u0"])
    weight_left = tails[0]*post[0][neighbor]*post[0]["u0"]
    weight_right = tails[1]*post[1][neighbor]*post[1]["u1"]
    combined = weight_left+weight_right
    assert 0<weight_left/combined<1
    return {
        "t_label":neighbor,"short_D_test_interval":list(map(str,short)),
        "D_support_price_patch_and_u": {
            f"{z},{j}":list(map(str,I)) for (z,j),I in support.items()
        },
        "matched_pairs_induce_identical_D_law":True,
        "P_left_given_short_D_only":str(weight_left/combined),
        "P_left_given_short_D_and_u0":"1","P_left_given_short_D_and_u1":"0",
        "short_event_original_high_tail_mass":str(combined),
    }


def original_model():
    shrink,h,K,G = 32,Q(33,32),Q(4),Q(65,32)
    L = Q(1,8)
    parents = {
        "k":(Q(0),Q(3,8)), "u0":(Q(-1,5),Q(1,2)), "u1":(Q(1,5),Q(1,2)),
        "p":(Q(-3,4),Q(3,2)), "q":(Q(3,4),Q(7,4)), "r":(Q(-5,4),Q(2)),
        "s":(Q(5,4),Q(5,2)),
    }
    A = {j:interval(y,r) for j,(y,r) in parents.items()}
    E = {j:interval(y,r/shrink) for j,(y,r) in parents.items()}
    assert all(disjoint(X,Y) for X,Y in combinations(E.values(),2))
    v = {j:length(I) for j,I in E.items()}
    d = {j:length(I) for j,I in A.items()}
    z = (Q(-1,5),Q(1,5))
    pockets = tuple(interval(y,Q(1,160)) for y in z)
    price = (((Q(-8),Q(8)),Q(1)),(pockets[0],Q(2)),(pockets[1],Q(1)))

    def mu(I):
        return sum(w*length(meet(I,B)) for B,w in price)

    m = {j:mu(I) for j,I in A.items()}
    assert all(m[j]==d[j]+Q(3,80)>d[j] for j in A)
    assert all(meet(A[j],P)==P for j,P in product(A,pockets))
    actual_receive = {j:v[j]/m[j] for j in A}
    kappa = {"k":Q(7,8),"u0":Q(1),"u1":Q(3,4),"p":Q(1),"q":Q(1),"r":Q(1),"s":Q(3,4)}
    source = {j:(K/G)*kappa[j]*actual_receive[j] for j in A}
    assert sum(source.values())<=1
    neighbors = tuple(j for j in A if j!="k")
    assert all(d[j]>d["k"] for j in neighbors)
    directions = (
        ("small_source",source["k"]*m["k"],{j:actual_receive[j] for j in neighbors},
         {"u0":(Q(1),Q(1,4)),"u1":(Q(1,4),Q(1)),"q":(Q(1),Q(3,4))}),
        ("small_receiver",K*v["k"]/G,{j:G*source[j]/K for j in neighbors},
         {"u0":(Q(1),Q(1,2)),"u1":(Q(1,2),Q(1)),"r":(Q(1),Q(1,2))}),
    )
    outcomes = []
    for direction,omega,weights,overrides in directions:
        gate = [{j:overrides.get(j,(Q(1),Q(1)))[r] for j in neighbors} for r in range(2)]
        values = [{j:weights[j]*B[j] for j in neighbors} for B in gate]
        U = [sum(row.values()) for row in values]
        assert min(U)>L and all(weights[j]<=v[j]/m[j] for j in neighbors)
        p = [{j:row[j]/U[r] for j in neighbors} for r,row in enumerate(values)]
        rho = [mu(P)/m["k"] for P in pockets]
        original = [omega*r*U0 for r,U0 in zip(rho,U)]
        tails = [omega*r*(U0-L) for r,U0 in zip(rho,U)]
        H = sum(tails)

        reconstructed, caps = {},{}
        for j in neighbors:
            I = mu(meet(A["k"],A[j]))
            cover_measured = sum(mu(P)*B[j] for P,B in zip(pockets,gate))
            assert cover_measured<=I
            coefficient = (source["k"]*actual_receive[j] if direction=="small_source"
                           else source[j]*actual_receive["k"])
            full_cap = K/G*actual_receive["k"]*actual_receive[j]*I
            actual = coefficient*cover_measured
            assert actual==sum(omega*r*row[j] for r,row in zip(rho,values))<=full_cap
            reconstructed[j] = actual
            caps[j] = full_cap
        assert sum(original)==sum(reconstructed.values())
        joint = {(t,u):sum(tail*row[t]*row[u] for tail,row in zip(tails,p))
                 for t,u in product(neighbors,repeat=2)}
        old_edge = {j:sum(omega*r*vals[j]*(1-L/U0) for r,vals,U0 in zip(rho,values,U))
                    for j in neighbors}
        assert sum(joint.values())==H
        assert all(sum(joint[t,u] for u in neighbors)==old_edge[t]
                   ==sum(joint[u,t] for u in neighbors) for t in neighbors)
        assert all(p_row[t]*p_row[u]/p_row[t]==p_row[u] for p_row in p
                   for t,u in product(neighbors,repeat=2))
        erased_same_price = old_edge["u0"]**2/H
        assert joint["u0","u0"]>erased_same_price
        rows = []
        for z0,B,U0,p_row in zip(z,pockets,U,p):
            detail,center_error,conditional = vector_band_density(h,shrink,L,U0,z0,p_row,parents,E)
            assert conditional>2*h/L
            for boundary in B:
                vector_band_density(h,shrink,L,U0,boundary,p_row,parents,E)
            rows.append({"price_center":str(z0),"U":str(U0),"bands":detail,
                         "u_center_direction_original_normalized_D_and_error":center_error})
        hits = {}
        for t,u in product(neighbors,repeat=2):
            w = mu(meet(A[t],A[u]))
            target = mu(meet(A["k"],A[t],A[u]))
            assert 0<target<=w
            hit = target/w
            r = parents["k"][1]/parents[t][1]+parents["k"][1]/parents[u][1]
            hits[t,u] = r,hit
        assert hits["p","u0"]==(Q(1),Q(57,83))
        assert hits["u0","u1"]==(Q(3,2),Q(1))
        paid_theta_one = sum(mass*hits[t,u][1] for (t,u),mass in joint.items() if hits[t,u][0]<=1)
        assert 0<paid_theta_one<H
        outcomes.append({
            "direction":direction,"omega_k":str(omega),
            "original_mass":str(sum(original)),"high_tail_mass":str(H),
            "pair_k_p_original_and_common_direction_cap":list(map(str,(reconstructed["p"],caps["p"]))),
            "normalized_same_price_diag_u0":str(joint["u0","u0"]/H),
            "normalized_erased_same_price_diag_u0":str(erased_same_price/H),
            "density_at_actual_price_centers":rows,"price_label_leakage":leakage(h,pockets,E,tails,p),
            "true_witness_r_hit_on_p_u0_u0_u1":[list(map(str,hits[key])) for key in (("p","u0"),("u0","u1"))],
            "theta_one_actual_weighted_hit_over_high_tail":str(paid_theta_one/H),
        })
    assert outcomes[0]["original_mass"]!=outcomes[1]["original_mass"]
    return {"L0":str(L),"h":str(h),"marked_density_upper_2h_over_L0":str(2*h/L),
            "K":str(K),"G_upper":str(G),
            "m_j":{k:str(w) for k,w in m.items()},"d_j":{k:str(w) for k,w in d.items()},
            "v_j":{k:str(w) for k,w in v.items()},
            "two_price_pocket_mu":list(map(str,map(mu,pockets))),"directions":outcomes}


def radius_cases():
    tests = [
        (1,Q(3,8),Q(3,2),Q(1,2),Q(1)),
        (2,Q(1,1000),Q(1),Q(1,2),Q(1)),
        (16,Q(1,64),Q(1,4),Q(1,8),Q(9,8)),
        (64,Q(1,2**20),Q(2**8),Q(1,2**5),Q(1)),
        (256,Q(1,2**40),Q(1,2**20),Q(1),Q(2)),
    ]
    result = []
    for n,k,t,u,over in tests:
        h = 1+Q(1,32*n)
        R = u*over
        r = k/t+k/u
        theta = 2*r if n==64 else r
        base = h*k/t+k/R
        assert k<t and k<u and u<=R and r<=theta<=1
        assert (k/t)**n*(h+t/R)**n==base**n<=h**n*theta**n
        result.append({"n":n,"s_k":str(k),"s_t":str(t),"s_u":str(u),"R":str(R),
                       "r":str(r),"theta":str(theta),"base_ratio_left_to_bound":str(base/(h*theta))})
    return result


def layer_integral():
    # Here alpha*n=1, so every step-function integral is rational.
    n,alpha = 2,Q(1,2)
    r = [Q(1,4),Q(1,2),Q(1)]
    mass = [Q(1,32),Q(3,64),Q(1,8)]
    F = [sum(mass[:i+1]) for i in range(len(r))]
    A = max(w/x**n for x,w in zip(r,F))
    direct = sum(w/x for x,w in zip(r,mass))
    layer = F[-1]+sum(w*(1/x-1/y) for w,x,y in zip(F,r,r[1:]))
    assert direct==layer<=A/(1-alpha)
    return {"n":n,"alpha":str(alpha),"r":list(map(str,r)),"mass":list(map(str,mass)),
            "exact_direct_and_layer":str(direct),"A_over_one_minus_alpha":str(A/(1-alpha))}


def report():
    return {
        "scope":(
            "Actual AC interval input with true m_j, disjoint positive full owners, and explicit preterminal gates. "
            "A volume band retains a marked subprobability. The layer test is an independent discrete scalar check."
        ),
        "python":python_version(),"source_sha256":sha256(Path(__file__).read_bytes()).hexdigest(),
        "commands":["python -B verify.py --out verify.json","python -B verify.py --check verify.json"],
        "original_model":original_model(),"radius_checks":radius_cases(),"discrete_layer_check":layer_integral(),
    }


def main():
    parser = argparse.ArgumentParser()
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--out",type=Path)
    group.add_argument("--check",type=Path)
    args = parser.parse_args()
    result = report()
    data = (json.dumps(result,indent=2,sort_keys=True)+"\n").encode()
    if args.out:
        args.out.write_bytes(data)
        print(f"wrote {args.out} ({len(data)} bytes)")
    else:
        assert args.check.read_bytes()==data,"certificate differs"
        print(f"identical rerun of {args.check} ({len(data)} bytes)")
    print("Two original directions, twelve marked center-density bands, five radius tests and three layer levels.")


if __name__=="__main__":
    main()

