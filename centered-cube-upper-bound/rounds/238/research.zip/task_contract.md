# R238 固定原来源的拥挤几何与真实接收占用

日期：2026-10-17；上轮已推送 3ac1b0c643ab64601854ab0e9eca10604a251e60。

## 目标与准确候选
保留 R237 原共同截断、原 ν≤β≤α≤f、真实 Ω 与所有尺度 hardband；对任意原 ν 的拥挤立方体 C（完整边长 d≤a，ν(C)>C0 q b^n），证明固定节点 R∈[a,b]、z∈C 的真实占用 O_R(z)=∫Ω h_R(x−z)dx≤1−(1−d/R)^n≤nd/a。再以原 ν 决定的可测拥挤半径 dH(z) 与 δ(z)=min(1,ndH(z)/a) 保留这一衰减进入所有 j/M/soft 菜单和原后验时钟求和。寻找可直接付款的来源分支，不以新余项名称代替付款。

并行辅助命题：实际软列 I0=∫Ω h_R P_{s(x),L}dx 满足 ∫D I0 dβ≤q O_R；半阶 QG 菜单价 B=e ceil(π√n) 与同底测度 Hölder 给 Jθ≤(B M^-n)^(2θ) I0^(1−2θ)，再核实真实后验与时钟积分。不得假设自适应 I0≤M^-n。

## 工具、限制、交付判据
允许 R237 已审核的原来源对门 D、actual FIRST、fixed-node hardband、full ν posterior、共同 heavy floor、固定 soft QG、公共软菜单及几何级数。所有条件须回查原来源账目。C0=16/3，Λ=128/119，ell=1+log n，不能混用。θ可在固定原硬来源 z 后选择，必须独立 x/y/v/u/辅助时间。原硬 z 不是 posterior 变量；β不能继承 ν hardcap；不得把变尺度核列归一，也不得重复选择 top-k 来源。

成功：独审通过的几何衰减及完整节点求和，至少给出精确可付款来源分支；若仅条件成立则标记条件，不声称一般根阶闭合。还须检查分支与原 top-k/light/history 资格的相容性。一般缺口必须写明。

## 分工与文件
peak（Astra high）：receiver_geometry.md，拥挤几何/原资格/根阶分支。
compare（Sol high）：overlap_weight.md，同底测度 overlap 插值和完整时钟求和。
audit（Sol high）：audit.md，先审命题，再读作者证明，核量词/常数/边界。
numeric（Sol medium）：numeric_checks.py/json、numeric_notes.md，初探—压力—扩大范围三个阶段。本机实际运行，不将有限算例认证一般结论。
主代理：本 contract、proof.tex.txt、report.md、reproduce.py 与精简归档/逐轮提交。各人仅写责任文件，完成停止，不提交他人文件。

## 数值与范围
精确有理 box 体积、拥挤有限密度来源的真实固定尺度 receiver 测度、δ log³ 预算参数；低维几何试验与原大维 hard residual 分开标记，固定尺度试验不得称一般闭合。数值代码与冻结 contract SHA 绑定；最终从仓库外复跑并比较完整 JSON。

## 附件状态
本轮用户说明建议可调整。微信原 txt 路径已失效；在 Desktop/T 与本项目专用 clone 文件名检索未找到同名副本。不能声称已读取这次附件；当前推进基于已核验 R237 原始账目与历史留存材料。
