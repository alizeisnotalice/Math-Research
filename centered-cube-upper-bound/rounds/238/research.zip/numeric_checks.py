#!/usr/bin/env python3
"""R238 finite fixed-R geometry and actual-density tools; not FULL."""
import argparse,hashlib,json
from pathlib import Path
from fractions import Fraction as F
from decimal import Decimal,localcontext
import mpmath as mp
ROOT=Path(__file__).resolve().parent

def box(n,d,R,z):
 # C=Q_d(0), z in C. Centers whose R cube contains C form Q_(R-d)(0).
 assert len(z)==n and all(abs(t)<=d/2 for t in z) and d<=R
 overlap=F(1)
 for t in z:overlap*=max(F(0),min(t+R/2,(R-d)/2)-max(t-R/2,-(R-d)/2))
 assert overlap==(R-d)**n
 outside=1-overlap/R**n;bound=1-(1-d/R)**n;linear=n*d/R
 assert outside==bound and bound<=linear
 return dict(n=n,d=str(d),R=str(R),z=[str(t) for t in z],excluded_receiver_volume=str(overlap),total_receiver_volume=str(R**n),outside_fraction=str(outside),binomial_bound=str(bound),linear_nd_over_R=str(linear))

def actual_interval(d,R,z,mass):
 # b1,C0=16/3,q3/16 => original b threshold1; a=R.
 a=R;density=mass/d;T=R;allowed_overlap=T/density;cut=(R+d)/2-allowed_overlap
 lo=z-R/2;hi=z+R/2;excluded=max(F(0),min(hi,cut)-max(lo,-cut));actual=1-excluded/R;bound=1-(1-d/R)
 assert mass>1 and actual<=bound and 0<=actual<=1
 critical=max(d/mass,2*(d/mass+abs(z)-d/2));empty=critical>=a;dH=min(a,critical);delta=min(F(1),dH/a)
 assert actual<=delta
 # Direct piecewise overlap at every receiver breakpoint, exact mass inequality.
 knots=sorted(set([lo,hi,-(R+d)/2,-(R-d)/2,(R-d)/2,(R+d)/2,-cut,cut]));segments=[];allowed_length=F(0)
 for u,v in zip(knots,knots[1:]):
  if v<=lo or u>=hi:continue
  u=max(u,lo);v=min(v,hi);x=(u+v)/2;overlap=max(F(0),min(x+R/2,d/2)-max(x-R/2,-d/2));allowed=density*overlap<=T
  if allowed:allowed_length+=v-u
  segments.append(dict(x_lo=str(u),x_hi=str(v),mass_at_midpoint=str(density*overlap),in_Omega_R=allowed))
 assert allowed_length/R==actual
 return dict(d=str(d),R=str(R),a=str(a),b='1',C0='16/3',q='3/16',nu_density=str(density),nu_mass=str(mass),C_mass_over_original_b_threshold=str(mass),z=str(z),Omega_R='outside [-cut,cut], endpoints immaterial',cut=str(cut),receiver_QR=[str(lo),str(hi)],receiver_segments=segments,true_O_R=str(actual),geometry_bound_d_over_R=str(bound),critical_threshold_inf=str(critical),dH=str(dH),dH_empty_set=empty,delta=str(delta),dH_geometry_margin=str(delta-actual),scope='Actual finite Lebesgue source, exact interval masses; Omega_R is a larger fixed-R tool set, not original all-B Omega/FULL.')

def huge(n,d):
 if n<=4096:
  bound=1-(1-d)**n;assert bound<=n*d
  def digest(k):return hashlib.sha256(k.to_bytes((k.bit_length()+7)//8 or 1,'big')).hexdigest()
  exact=dict(numerator_sha256=digest(bound.numerator),denominator_sha256=digest(bound.denominator),numerator_bits=bound.numerator.bit_length(),denominator_bits=bound.denominator.bit_length())
 else:exact=None
 vals=[]
 for precision in (50,80):
  with localcontext() as c:
   c.prec=precision;x=Decimal(d.numerator)/Decimal(d.denominator);v=1-(1-x)**n;vals.append(str(v))
 return dict(n=n,d_over_R=str(d),linear_exact=str(n*d),binomial_decimal50=vals[0],binomial_decimal80=vals[1],exact_fraction_summary=exact,scope='Exact Fraction binomial through4096 with Bernoulli verification; n1e6 Decimal refinement only, not interval proof.')
def price(R,delta,dps):
 with mp.workdps(dps):
  rr=mp.mpf(R.numerator)/R.denominator;dd=mp.mpf(delta.numerator)/delta.denominator;v=dd*(rr+mp.log(1/dd))**3;upper=4+108/mp.e**3;assert delta*R**3<=1 and v<=upper
  return dict(fee=mp.nstr(v,32),universal_upper=mp.nstr(upper,32),fee_over_upper=mp.nstr(v/upper,32))
def series(n,theta_text,dps):
 with mp.workdps(dps):
  theta=mp.mpf(theta_text);h=n*mp.log1p(mp.mpf(1)/n);r=mp.exp(-2*theta*h);jratio=mp.exp(-4*theta*h);cap_x=1/(2*theta);cap=cap_x*mp.exp(-2*theta*cap_x);ksum=h*r/(1-r)**2;jsum=1/(1-jratio);total=jsum*(ksum+cap)/4;bound=7/(64*theta**3)
  finite_j=sum(jratio**j for j in range(5));finite_k=sum(k*h*r**k for k in range(9));finite=finite_j*(finite_k+cap)/4;tail=total-finite
  # Independent positive tail decomposition, no unexplained numerical cutoff.
  tail_j=(jsum-finite_j)*(ksum+cap)/4;tail_k=finite_j*(ksum-finite_k)/4
  assert total<=bound and tail>=0 and abs(tail-tail_j-tail_k)<mp.mpf(10)**(-dps+10)
  assert F(n+1,n)**n>=2 and mp.log(2)<=h<=1
  return {k:mp.nstr(v,32) for k,v in dict(h0=h,regular_k_infinite=ksum,j_infinite=jsum,conservative_extra_cap_x=cap_x,extra_cap_value=cap,total=total,bound=bound,total_over_bound=total/bound,finite_j0_to4_k0_to8=finite,positive_omitted_tail=tail,tail_j=tail_j,tail_k=tail_k).items()}

def main(output,contract):
 boxes=[]
 for stage,ns in [('initial',(1,2)),('stress',(4,8))]:
  for n in ns:
   for d in (F(1),F(1,10),F(1,10**6)):
    for label in ('center','corner'):
     row=box(n,d,F(1),[F(0) if label=='center' else (-1 if i%2 else 1)*d/2 for i in range(n)]);row.update(stage=stage,position=label);boxes.append(row)
 actual=[]
 for d,R in [(F(1,10),F(1)),(F(1),F(1)),(F(1,10**6),F(1)),(F(1,4),F(1,2))]:
  for mass,z in [(F(101,100),d/2),(F(2),F(0))]:actual.append(actual_interval(d,R,z,mass))
 expanded=[huge(n,F(1,n**power)) for n in (512,4096,1000000) for power in (1,2)]
 fees=[]
 for R in map(F,(1,2,4,10,1000000)):
  for factor in (1,2,10,1000):
   delta=1/(R**3*factor);fees.append(dict(R=str(R),delta=str(delta),delta_Rcubed_exact=str(delta*R**3),mp40=price(R,delta,40),mp70=price(R,delta,70)))
 stationary=[]
 with mp.workdps(70):
  for R in (1,2,4,10,1000000):
   lower=max(mp.mpf(0),3*mp.log(R));t=max(lower,3-R);v=mp.exp(-t)*(R+t)**3;assert v<=4+108/mp.e**3;stationary.append(dict(R=R,t_lower=mp.nstr(lower,32),maximizing_t=mp.nstr(t,32),fee=mp.nstr(v,32)))
 sums=[dict(n=n,theta=t,mp40=series(n,t,40),mp70=series(n,t,70)) for n in (2,1000) for t in ('.5','.1','.01')]
 payload=dict(source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),scope='Finite fixed-R exact geometry/actual interval measures and numerical log-price tools; no adaptive-R normalization, beta hardcap, original residual/FULL certification.',box_rows=boxes,actual_density_rows=actual,expanded_rows=expanded,price_rows=fees,constrained_stationary_checks=stationary,geometric_series_checks=sums,geometric_series_scope="Perleg perorientation conservative infinitej/infinitek, plus one extra cap even if duplicate; full normalization retained. No actual FULL node claim.",counts=dict(exact_box_cases=len(boxes),actual_density_cases=len(actual),large_n_cases=len(expanded),price_cases=len(fees),stationary_cases=len(stationary),geometric_series_cases=len(sums)),price_reason='For t=log(1/delta), delta(R+t)^3; derivative sign3/(R+t)-1, t>=max(0,3logR). Universal analytic route (R+t)^3<=4(R^3+t^3), deltaR^3<=1, max exp(-t)t^3=27/e^3.')
 if contract and Path(contract).exists():payload['contract_sha256']=hashlib.sha256(Path(contract).read_bytes()).hexdigest()
 Path(output).write_text(json.dumps(payload,indent=2,sort_keys=True)+'\n');print(payload['counts'])
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--output',default=str(ROOT/'numeric_checks.json'));p.add_argument('--contract',default=str(ROOT/'task_contract.md'));a=p.parse_args();main(a.output,a.contract)
