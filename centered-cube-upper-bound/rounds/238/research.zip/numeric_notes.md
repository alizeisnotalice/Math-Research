# R238 bounded numerical design

Use exact Fraction box subtraction for real receiver-center sets, then actual finite n=1 density nu for Omega_R. The larger set Omega_R={nu(Q_R(x))<=C0qR} is permitted; no original residual/history qualifications are inferred. Three stages: small n1/2 geometry; n4/8 edge/corner and d tiny/d=a pressure, with real uniform-source interval calculations; enlarged n512/4096 exact-rational summaries and n1e6 finite Decimal refinement, plus delta logarithmic price evaluations. Large-dimensional samples remain fixed-R geometric tools. The full adaptive-R column is not normalized by this test. No beta hardcap is assumed.

## Actual completed geometry and density checks

Initial/stress geometry comprises24 exact Fraction cases: n=1,2,4,8; d=1,1/10,1/10^6; z at the center or an alternating-sign corner of C=Q_d(0); R=a=b=1. The receiver-center box whose Q_R contains C is Q_(R-d)(0). Its intersection with Q_R(z) is computed from coordinate endpoint maxima/minima, not inserted as a guessed volume. The exact product equals(R-d)^n, the subtraction gives1-(1-d/R)^n, and Bernoulli's linear bound is verified. d=R yields a zero-volume excluded box, as required.

Eight true n=1 finite Lebesgue densities nu=(M/d)1_[-d/2,d/2] are independently checked. b=1, C0=16/3, q=3/16, so C0qb=1. a=R is either1 or1/2 and every d<=a. Mass M is101/100 at edge z=d/2, or2 at z=0. For the larger fixed-scale receiver set Omega_R={nu(Q_R(x))<=C0qR}, direct overlap algebra gives its complement(-cut,cut), cut=(R+d)/2-Rd/M. The script partitions the actual receiver interval Q_R(z) at all overlap and threshold breakpoints, tests the mass at each segment midpoint, and sums the exact allowed lengths. Endpoint equality sets have Lebesgue measure zero. This computed O_R is compared with d/R and with delta from the same nu; no assumption on beta is made.

The centered crowding threshold infimum for that density is max(d/M,2(d/M+|z|-d/2)), capped at a with an explicit empty-set branch when no strict mass crossing exists by a. The strict inequality defining crowding is reflected by taking the infimum, not by replacing strict mass with equality as a feasible point. Examples: d=1,M=101/100,z=1/2,R=1 has O=100/101, empty crowding search up to a and delta=1. For d=1/10,M=101/100,z=1/20,R=1, O=10/101 and delta=20/101. The latter positive measure is a real receiver integral, not merely a containing-box upper bound. At center M=2, O=0 while dH=d/2 is positive.

Enlarged n=512,4096 and10^6 each use d/R=1/n or1/n^2. The first two use actual exact Fraction binomials and store numerator/denominator bit lengths and SHA256 rather than giant decimal integers. n=10^6 uses Decimal50/80 refinement only. Bernoulli's inequality is an analytic bound; the latter decimals are not interval certificates. At n=10^6 the two values are about.6321207427683549 and9.999995000006667e-7.

Twenty rational feasible pairs test delta[R+log(1/delta)]^3 with delta R^3<=1 at40/70dps. Five additional evaluations check the elementary constrained stationary point: with t=log(1/delta), derivative sign is3/(R+t)-1 and t>=max(0,3log R). The universal constant follows analytically from(R+t)^3<=4(R^3+t^3), delta R^3<=1 and max_t>=0 exp(-t)t^3=27/e^3, giving4+108/e^3. The largest fee in the20 rational pairs is about8.48617835693. These finite evaluations verify implementation and feasible ranges, not a numerical proof of the general inequality.

The R in `price_rows` is the separate logarithmic-price parameter R>=1, not the physical receiver scale R in the box/density rows. Their menus and meanings are recorded separately.

## Reproduction environment

Actual local executable is `/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3` (Python3.12.14), with mpmath1.3.0 supplied by the existing vendor. Only standard-library Fraction/Decimal/hashlib and mpmath are used; no package installed.

```sh
PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor \
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 \
/Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/238/work/numeric_checks.py \
--output /tmp/r238_numeric_replay.json \
--contract /Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/238/work/task_contract.md
```

The script and adjacent contract may be relocated; pass their resulting paths. Time and output-path strings are excluded from JSON.

## Additional confirmed all-node series diagnostic

Six further finite-parameter checks, n=2/1000 and theta=.5/.1/.01, evaluate the exact positive infinite-series majorant confirmed by compare:

    (1/4)/(1-exp(-4theta h0))
      * [h0 exp(-2theta h0)/(1-exp(-2theta h0))^2 + 1/(2e theta)]
    <= 7/(64theta^3),  h0=n log(1+1/n).

The regular M sum is an exponential first moment; the extra cap is placed at its maximizer xi=1/(2theta), even if it duplicates a regular slot. This deliberate overcount is conservative, not actual unique-cap enumeration. All j and regular M tails are evaluated in closed form. The JSON also records a partial sum j=0..4,k=0..8 and independently decomposes its positive omitted tail into j and k tails; no finite truncation is passed off as the full series. Gamma^n>=2 is checked with Fraction, while h0<=1 uses the elementary log(1+x)<=x bound and is numerically cross-checked. Computations are40/70dps and are scoped per leg and per orientation, after the stated normalization; they do not certify original FULL traffic. No additional geometric source configurations were searched.

## Frozen final replay

Complete separate-output JSON replay was byte-identical: 44036 bytes, actual wall.03s/user.02s/system.00s. Actual counts:24 exactbox cases,8 true-density receiver cases,6 large-n checks,20 feasible price pairs,5 stationary checks,6 confirmed geometric-series diagnostics. The six series total/bound ratios range.1469455 to.5467478. SHA256 source `e24bfed67bfa6246541582b1260a1359c79026db7670608b53189a846e1ea2bc`; JSON `13caa12b5d2ce84855ae91b09ef6570fdc43b08741ae061f20bcc158de689b84`; contract `e7a7cd790a9a5926838bf370430d5fae298ca7e279fa838dc85ac4c4ed3f04d9`. No time or output path enters JSON.
