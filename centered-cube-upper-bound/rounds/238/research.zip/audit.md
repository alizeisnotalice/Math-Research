# R238 independent audit — statement-first screening

Only this audit file is owned by the auditor. The requested contract was not yet on disk at the first read. This checkpoint uses the parent's precise proposition and the frozen R236/R237 original-source interfaces; no R238 author draft has been read.

## Interpolation and the actual bottom measure

Fix original outer data, hard source z, physical node L,R,A, soft r, target soft sigma and theta in (0,1/2]. Let C(x,y,v,z) in [0,1] be a certified static capture, independent of auxiliary time and the other posterior slot. Define on the same positive measure h_R(x-z) C(x,y,v,z)1_Omega(x) dx

    J0 = integral P_r,L(x-y),
    Jhalf = integral sqrt(P_r,L(x-y) Q_sigma,A(x-v))/sqrt(w_*(y,v)),
    Jtheta = integral P_r,L(x-y)^(1-theta) Q_sigma,A(x-v)^theta / w_*^theta.

Holder gives Jtheta<=J0^(1-2theta) Jhalf^(2theta). If the already certified QG gives Jhalf<=M^(-n), M=max(L,R), then

    Jtheta <= M^(-n) [M^n J0]^(1-2theta).

These inequalities are valid on true receiver Lebesgue measure. They require the same hard kernel, domain and capture in the two interpolated factors; dropping a capture needed for a premise is not a free operation. When J0=0 the original column vanishes. At theta=1/2 the conclusion is the original half-density bound, with that zero-column case handled before any 0^0 notation.

A larger usable overlap is J0bar=integral_Omega h_R(x-z)P_r,L(x-y)dx, with C removed only from this zeroth factor. For fixed r the normalized P_r,L and normalized fixed h_R yield J0bar<=min(L^(-n),R^(-n))=M^(-n), so its dimensionless overlap is in [0,1]. The pointwise density bound alone gives only L^(-n), not M^(-n) when R>L. In particular an actual receiver-adaptive s(x) cannot be assigned the fixed-r full-space normalization. The adaptive mother still needs its explicit common-soft menu before fixed-parameter overlap/QG is used.

## Legal posterior and source use

If C depends on auxiliary v, then the captured J0 also depends on v. It must remain inside the actual weighted posterior integral, or be replaced by a proved v-independent upper envelope such as J0bar. For the latter, each fixed-menu overlap is static in y,z,node and can multiply the ordinary same-law Gini bound n/4 without changing either full-nu posterior or e_t(y). A t/u-dependent capture cannot silently become this static column.

For the actual adaptive-soft column, the safe resulting tail is obtained by the already paid nearest-angle menu, schematically

    e M^(-n) sum_r [M^n J0bar_r(y,z)]^(1-2theta).

It is a sum of fixed-r overlaps, not a single unpriced adaptive overlap. After beta integration on the original D_V(z), a genuine retained quantity is the corresponding integral of these overlap powers against beta|D_V(z). It is <=e N beta(D_V(z)), but replacing it by that flat scalar bound loses the new spatial information. Any claimed improvement in the full j/M sum must retain and actually sum the appropriate overlap weights. Source FIRST supplies the separate actual-soft capacity price; it does not permit backward menu-FIRST or automatically multiply this capacity price by the fixed-soft overlap gain. Taking minima of two proved bounds for the same original column is legitimate; multiplying unrelated upper bounds is not.

The R237 actual y/hard-z gate may be retained throughout. Restricting the anchor beta to D_V(z) does not restrict the full nu in either posterior or heavy floor. Theta may depend on frozen original hard z, but remains fixed before receiver, anchor y, node and auxiliary time; all of its factors stay in nu(dz) until settled. Original static-capture and upper/lower-clamp qualifications are unchanged.

## True hard occupancy

For a fixed node, H_R(z)=integral_Omega h_R(x-z)dx lies in [0,1]. Keeping it in the actual-FIRST source/receiver calculation gives the R237 capacity clock price multiplied by H_R(z), provided the same true receiver Omega is retained. This is a legitimate occupation factor, not a declaration that every hard source is active. It depends on the physical node; no free sum or telescoping over nodes follows.

One may also use J0bar<=L^(-n)H_R(z), alongside the fixed-soft normalization bound above. The orientation factor M^n/L^n in converting this to a dimensionless overlap must be retained when R>L. In general J0bar/M^(-n) is not automatically <=H_R(z). Gates discarded from an enlarged receiver domain cannot subsequently be reused to infer a smaller occupancy for the original one.

## Tool evidence and current conclusion

A local mpmath 60-dps computation actually passed 144 same-positive-measure interpolation checks, including zero P, zero capture, theta=.001,.1,.25,.5 and nontrivial captured/uncaptured overlap comparisons. These are abstract finite-measure diagnostics, not FULL inputs, interval certificates or formal replay package experiments; the temporary check code is not archived. The analytic result is Holder plus the two fixed normalized kernels.

Statement-first conclusion: the proposed overlap interpolation is valid with these quantifiers and costs. It can improve a retained fixed-node column, but no automatic global source-moment/root payment follows. The same actual posterior, fixed-soft menu cost, original receiver domain, source gate and complete j/M expense must survive the new estimate. Awaiting the actual contract and author's exact inequality for final audit; no new counterexample search or author proof review has been performed.

## New proposition independently screened: crowded cells and an adaptive zeroth column

Before reading author proofs, the following additional proposition was checked. Let a fixed original axis-parallel source cube C have full side d<=a and nu(C)>C0 q b^n. On the preserved original full-scale hardband receiver Omega, every R in [a,b] satisfies nu(Q_R(x))<=C0 q R^n. Therefore Omega contains no center x with Q_R(x) containing C. The forbidden centers form an axis-parallel cube of side R-d. For every z in C that center cube is contained in Q_R(z). Subtracting its volume yields

    O_R(z)=integral_Omega h_R(x-z)dx
       <=1-(1-d/R)^n<=min(1,n d/a).

There is no padding for upward physical nodes: all those node scales are legal members of the original full-scale hardband. Strict crowded mass is essential to the stated exclusion. Boundary choices affect no receiver Lebesgue volume. For d=R the bound is simply one. Zero occupancy means the original positive column vanishes and is handled before powers/divisions. For an actual positive-L1 source a zero-side cube has zero nu mass and cannot meet the strict crowded hypothesis.

Original top-k/rank qualifications are not discarded. A crowded cell is a conditional portion of the actual fixed source; its existence is not implied by this geometric lemma. The retained rank gives, for a cell covered by N_C original birth pieces, nu(C)<=m_nu min(1,N_C gamma_V). Thus the crowded threshold also requires this upper bound to exceed C0 q b^n. No general FULL nonemptiness or availability of arbitrarily small crowded cells is certified without that compatibility. Disjoint crowded cells or a pre-frozen measurable source assignment may avoid hard-source duplication; arbitrary overlapping cells cannot each charge all their common mass.

The new adaptive-column tail is valid by a different order than the initial fixed-r interpolation. Use the larger uncaptured actual adaptive zeroth column I0(y,z)=integral_Omega h_R P_{s(x),L}(x-y)dx. The common-measure interpolation may first have C_z in both factors, but C_z must be removed from this zeroth factor before it is extracted from the auxiliary-v posterior integral; otherwise it need not be v-independent. It need not have the fixed-soft normalization M^-n, but the original source FIRST implies integral_D(z) I0(y,z)beta(dy)<=q O_R(z). First cover the actual half-density column by the nearest-angle soft menu, with its full B=e N charge, to obtain Jhalf_actual<=B M^-n. Interpolate Jtheta_actual between this actual half column and I0 on the same actual measure, and then use Holder in beta restricted to the authentic D(z). This proves the beta-integrated column bound

    q^-1 integral_D(z) Jtheta_actual beta(dy)
      <=(B rho_D(z))^(2theta) O_R(z)^(1-2theta)
          c^(4theta n) exp(-2theta X).

The same original-posterior Gini and node time length yield the stated clock price Z/4 times this expression. At theta=1/2 it reduces to the previous B rho_D tail; it is not a newly free menu bound. This is compatible with the independent capacity price multiplied by O_R(z), and the two may be minimized for the same actual column. The complete theta choice, j/M sum and constants of any delta-logarithmic conclusion remain to be audited from the actual author inequality; they are not granted by the node estimate alone.

An additional local tool run passed 72 bounded diagnostics: 48 exact Fraction checks of the occupation/Bernoulli bound and 24 finite-measure adaptive-column/source-Holder checks. These supplement the earlier 144 diagnostics and likewise are temporary unarchived algebra checks, not formal replay package experiments, interval/FULL examples or proof of the original crowded branch's nonemptiness.

## Final original-band and author-proof audit

The contract was read after it appeared. Both author files, the full parent proof (1)–(11), report and driver were then read completely. The initial fixed-r overlap remains a valid auxiliary fact; the final main route is stronger and uses the actual-soft zeroth column with source FIRST, then the half-menu bound and Gini. The uncaptured I0 is independent of auxiliary v before normalization is used; the certified capture remains in the half-column. This does not assume adaptive I0<=M^(-n), change either full-nu posterior, or extract the y-dependent normalizer from a source integral. No heavy-floor premise is needed for this new positive upper bound.

The essential all-scale hardband was checked directly, rather than inferred from a current winner: GENERAL_CURRENT_REDUCTION.md section 1 defines G_0=sup_(a<=L<=b) P_0,L f on the original 2lambda<G_0<=4lambda receiver band and retains q>=3lambda/4. Hence every legal B has nu(Q_B(x))<=C0qB^n on that same Omega. Frozen R221 source_locality.md SL1/SL3 confirms exactly this inherited usage and warns against granting it after expanding the receiver domain. This authenticates the crowding exclusion for every upward physical node without padding.

The centered d_H definition, empty-set default, measurability via rational radii, strict mass threshold and infimum limit were checked. Finite nu<=f dx is atomless, so the centered small-cube mass tends to zero at every fixed z and d_H>0. The default a gives delta=1 when no gain is certified. All sources are integrated once; no covering multiplicity is introduced. A hypothetical zero occupation is handled before exponent-zero notation. The final author text explicitly distinguishes a noncentered containing cube's direct occupation bound from the centered radius used in delta.

The exact regular-node series plus at most one additional cap give sum X exp(-2theta X)<=1/(2theta^2); the j series is <=7/(8theta). Combining the clock factor 1/4 yields 7/(64theta^3). With theta_z=1/(2H_D(z)), the exponent bound is <=e, so the per-leg/orientation coefficient is 7e/8. Restoring the original factors gives C*=(21/2)Lambda exp(5), equivalently 12 Lambda exp(4)(7e/8). The paid set G_A={delta R_D^3<=A} follows from delta(H_D)^3<=4A+108/exp(3) and the inherited unweighted source mass budget. A=1 and A=sqrt(n) are valid conditional subtraffic payments, not claims that such sources exhaust the original input.

Original birth/rank qualifications were kept separate. R107 integration.md R5 applies its stronger H_piece bound to a birth piece participating in an actual positive row; it is not a uniform cap on every source piece used to measure nu(Q_d(z)). The rank/light mass examples in receiver_geometry.md RG9 check only the explicitly listed numerical qualifications and do not verify R5, maxflow/cut history or a FULL nonempty traffic construction. The final revision states this limitation. Thus no unconditional nonemptiness or positive mass fraction is certified for G_A, nor is beta given nu's rank/density cap. The remaining complementary source set and other original branches stay unpaid.

## Independent numerical/reproduction audit

The full numeric source and notes were read. An independent complete run passed all 69 recorded configurations/diagnostics: 24 exact Fraction box-volume cases, eight exact finite-density fixed-R receiver cases, six large-n cases, 20 feasible log-price pairs, five stationary checks and six complete geometric-series checks. The entire 44036-byte JSON was byte-identical, SHA256 13caa12b5d2ce84855ae91b09ef6570fdc43b08741ae061f20bcc158de689b84. The true-density models directly partition receiver intervals at all overlap/threshold breakpoints and explicitly use the larger fixed-R Omega_R, not an asserted original all-scale/FULL receiver. Strict d_H threshold/empty-set cases and centered edge positions are handled correctly. Large-n Fraction summaries are exact through n=4096; n=10^6 Decimal refinement and the remaining high-precision values are not interval certificates. Positive infinite j/k tails are evaluated in closed form and independently decomposed, not silently truncated.

The overlap_weight.md embedded script was independently extracted and run verbatim: all nine true one-dimensional kernel interpolation checks passed, and the adaptive normalization stress returned 1.2560699822294480233>1, matching the recorded value. These are ordinary mpmath quadrature/kernel tools, not original FULL instances or error-certified integrals. The initial 144+72 temporary diagnostics are separate bounded runs without archived standalone scripts and are not added to the 69 formal configurations. The receiver author's other finite checks remain author-reported evidence.

The final driver statically passes the contract and source to a new external directory, compares the complete JSON, extracts/runs the archived overlap script, records its stdout, and verifies the frozen manifest before and after. Its final execution and receipt will be recorded by the parent after this audit freeze; this audit does not claim that later driver run.

**Final conclusion: pass within the stated original positive-far scope.** The new receiver exclusion, actual-soft overlap bound, complete node sum and explicit G_A payment are valid. No missing source/selector fee has been renamed as a paid general root budget. The set {delta R_D^3>sqrt(n)}, any required historical combination and all other original branches remain to be controlled. This conclusion supersedes provisional awaiting-author statuses above. The final hash table excludes this audit itself; after binding it the auditor stops writing.

| File | SHA256 |
| --- | --- |
| task_contract.md | `e7a7cd790a9a5926838bf370430d5fae298ca7e279fa838dc85ac4c4ed3f04d9` |
| proof.tex.txt | `2fabbc1263152b9cf01e4b0a591f0252912b6ec9d87fe029d9e97f49087f393b` |
| receiver_geometry.md | `744b735f5ee68e682deb0150fefe08eac104ac2ed0900725d0e9a5c49a1d4f16` |
| overlap_weight.md | `ff871ac1e2c1e7e298d4f9d4a8b186ce04816e2f7bf22498c48ccf721cf5ad70` |
| report.md | `9a1a73b4d4ebd152113b36f1bc0030ab54a4936ff03ada86b1647bcf52a0a270` |
| numeric_checks.py | `e24bfed67bfa6246541582b1260a1359c79026db7670608b53189a846e1ea2bc` |
| numeric_checks.json | `13caa12b5d2ce84855ae91b09ef6570fdc43b08741ae061f20bcc158de689b84` |
| numeric_notes.md | `0b98e88c1e4d4e63335d2e7978db284ed0b519f9c1c0f1bd41f50276462f1b29` |
| reproduce.py | `900ae310b9ef452e5a59d18ac80789dbba1045ebfd35c9bdb87c5bb622088fc5` |
