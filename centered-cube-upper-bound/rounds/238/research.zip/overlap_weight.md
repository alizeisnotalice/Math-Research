# R238: exact source overlap and an occupation-weighted summable tail

Only this file is edited by this task. Input is the audited R237
`local_geometry.md` and `source_ledger.md` at
`/Users/zhengzhihao/Desktop/T/output/centered_cube_round237_20261017_final_checkpoint/`.
This note proves the interpolation/source-weight component; the separate
author proves the original receiver geometry which supplies small
occupation. No posterior, source, negative credit or FIRST is rebuilt.

## OW1. Data, dimensions, and the exact fixed-soft overlap

Keep original finite data (omega,V), nu<=beta<=f dx, q>0,
0<a<=b<=2a, and the actual receiver set Omega. Let

    h=1[-1/2,1/2], phi=h*integral_0^1 exp(-|.|/r)dr,
    f_s=(1-s)h+s phi,
    P_{s,L}(x)=L^-n product_i f_s(x_i/L).

The original source-pair gate is

    D_V(z)=V intersect {y: ||y-z||_1<=17na}
                 intersect {y: ||y-z||_infty<=b(5log n+1/2)}.

It constrains the original soft y and hard z, not auxiliary v/u. The
gate is retained from the original mother expression before physical
cover; see R237 LG1 and SL5. Fix hard z before all x,y,v/u,j,M,t and
choose a single 0<theta<=1/2 for that anchor. All following inequalities
are uniform in theta. Original large-n and all source-history gates
remain; the elementary lemmas have a broader algebraic domain.

For fixed physical L,R in [a,b], M=max(L,R), and fixed soft r, define

    I0_r(y,z)=integral_Rn h_R(x-z)P_{r,L}(x-y)dx,
    A_r(y,z)=M^n I0_r(y,z).

The precise tensor formula is

    I0_r(y,z)=R^-n product_i [ (1-r) H_i+r V_i ],
    H_i=length([z_i-R/2,z_i+R/2] intersect
               [y_i-L/2,y_i+L/2])/L,
    V_i=integral_{(z_i-R/2-y_i)/L}^{(z_i+R/2-y_i)/L} phi(u)du. (OW1)

Thus A_r is nonnegative, measurable, and <=1. If R>=L, P_{r,L} is a
probability density and I0_r<=R^-n. If L>=R, f_r<=1 gives
I0_r<=L^-n. These two arguments prove the bound with correct units:
I0 has density units, while A_r is dimensionless. Formula OW1 is valid
for every independent source shift, all r in [0,1], and both orientations.

## OW2. Fixed-column fractional interpolation, retaining the source weight

Fix a legal target Q=P_{sigma,A}(x-v) belonging to an original leg:
(A,sigma)=(L,r),(min(b,gamma L),r), or (b,1), where gamma=1+1/n.
Use the exact-min physical node w_*(y,v)>0 and a certified static
capture C(x,y,z,v) in [0,1], with the support required by the proved QG
half-column. It is independent of auxiliary t,u. Define

    J_theta,r=integral h_R(x-z) C
                P_{r,L}(x-y)^{1-theta}Q(x,v)^theta w_*^-theta dx.

Holder with exponents 1/(1-2theta),1/(2theta), for 0<theta<1/2, gives

    J_theta,r <= I0_r(y,z)^{1-2theta} J_half,r^{2theta}
      <= M^-n A_r(y,z)^{1-2theta} E(y,v)^{2theta},      (OW2)

whenever the fixed QG bound is J_half,r<=M^-n E, E<=1. Indeed take
the two nonnegative factors h_R P and h_R C sqrt(PQ)/sqrt(w_*);
their powered product has C^{2theta}>=C. Alternatively use C in both
factors and then bound the zero-order integral by I0_r. At theta=1/2
use the half-column directly. At theta=0 the exact integral is
integral h_R C P<=I0_r. All zero factors are treated before taking
powers; a zero zero-order integral gives a zero fractional column.
There is no division by I0 or by a source mass.

Consequently an old shared-soft menu may retain the real source weight
sum_r A_r(y,z)^{1-2theta}, instead of replacing each of its N terms by
one. This fixed-r formula alone does not give source FIRST at backward
r. That would be an unauthorized change of the original receiver soft.

## OW3. Actual-soft overlap and the capacity-compatible interpolation

For a fixed physical node L*,R*,A*, keep the actual s=s(x) and set

    P_y(x)=P_{s(x),L*}(x-y),
    Q_x(v)=P_{s(x),A*}(x-v), or P_{1,b}(x-v),
    I0(y,z)=integral_Omega h_R*(x-z)P_y(x)dx,
    O_R*(z)=integral_Omega h_R*(x-z)dx in [0,1].

Here h_R* denotes the normalized hard kernel at fixed R*, not a
receiver-dependent hard scale. Original actual-soft FIRST gives

    integral_{D_V(z)} I0(y,z) beta(dy)
      =integral_Omega h_R*(x-z)
           integral_{D_V(z)}P_y(x)beta(dy)dx
      <=q O_R*(z).                                    (OW3)

This is real Lebesgue integration and Tonelli, with the same original
beta and nu. It does not invoke future FIRST at any menu soft value.

Let J_theta,act denote the actual-soft capture column, with the same
definition as OW2 but integrating over Omega. The audited shared
posterior-angle half-menu has N=ceil(pi sqrt n), price e, and applies
to the original three legs. Fixed-node half QG therefore gives

    J_half,act <= B M^-n,       B=eN.

Apply Holder to the actual soft kernel **before** using this menu:

    J_theta,act(y,z,v)
      <= I0(y,z)^{1-2theta} (B M^-n)^{2theta}.           (OW4)

The important menu price is now B^{2theta}, not B. Its target and source
dependences are never independently selected. OW3 and concavity/Holder
in the true source beta restricted to D_V(z) give

    integral_{D_V(z)} I0^{1-2theta} beta
      <=m_D(z)^{2theta}[q O_R*(z)]^{1-2theta},
    m_D(z)=beta(D_V(z)).                                (OW5)

At theta=1/2 this just uses the source mass; if O_R*=0 or m_D=0 the
actual column contribution is zero, handled first. Otherwise every
displayed power is well-defined. OW3–5 are the compatibility which
allows both true overlap and actual-soft FIRST on the same quantity.

Unlike OW1, actual adaptive softness need not give M^n I0<=1 in the
R*>L* orientation: P_{s(x),L*}(x-y), as a function of x, need not have
unit integral. No such normalization is used in OW3–5. In the other
orientation the elementary L*-infinity bound remains available.

## OW4. Original two-posterior clock: a new independent tail price

Keep the full original Pi_t=e_t^-1 1_Zt w_t nu, with its original
deletions and source anchor y. It is independent of receiver x and hard
z once the original (omega,V,j,y,t) is fixed. Invalid process rows and
e_t=0 rows are masked to zero; on active rows the posterior mass is one.
Do not integrate Pi against a newly restricted nu|D_V(z).

For a physical node put c=gamma^-j, M0=a/c^2,
xi=n log(M/M0), tau=a/c, and u=(xi-U)_+, U>=0. The original node clock
is contained in [tau,g* exp(-U/n)], length u/n in logarithmic time.
The full two iid scores 0<=k_t<=n satisfy

    integral integral (k_t(v)-k_t(u))_+ dPi_t(v)dPi_t(u)
       <=n/4.                                         (OW6)

Proof: express the difference by score-level layer cake; its integral
is integral_0^n p_r(1-p_r)dr<=n/4. No source envelope is used. After
receiver integration, OW4 has removed its v dependence, so OW6 applies
for each same y. Apply OW5 only then. The same original positive node
traffic, before the external 2Lambda e^4(K/3)^theta, is bounded by

    G_ov(j,M,z) <= (u/4) (B rho_D(z))^{2theta}
                  O_R*(z)^{1-2theta}
                  c^{4theta n} exp(-2theta xi),
    rho_D(z)=m_D(z)/(q a^n).                            (OW7)

All factors follow directly from (1/q) M^-2theta n,
m_D^{2theta}(q O)^{1-2theta}; M=M0 exp(xi/n).
The separate original prefactors and source nu(dz) have not vanished.
This estimate uses normalization, not a heavy-floor lower bound or a
derivative of e_t. On the actual heavy branch it is an additional
positive upper bound, compatible with the old growing-floor price and
the old linear-QG price by taking their pointwise minimum. It consumes
no signed, suffix or deletion negative credit.

## OW5. All physical nodes and j, including the cap node

Suppose the original receiver geometry supplies a measurable common
bound O_R*(z)<=delta(z)<=1 for every legal hard node, chosen before the
node sum. The bare universal choice is delta=1. Small choices require a
proved actual receiver fact; this note does not grant them for free.
For each j, the regular xi nodes are k h0, h0=n log(1+1/n), with at most
one additional nonduplicated cap point. Keep only legal nodes; positive
upper sums can be enlarged. Here 2/3<log2<=h0<=1.

For 0<theta<=1/2, the regular geometric series and the independent cap
point give

    sum_M xi exp(-2theta xi)
      <=h0 exp(-2theta h0)/(1-exp(-2theta h0))^2
           +1/(2e theta)
      <=3/(8theta^2)+1/(2e theta)<=1/(2theta^2).         (OW8)

Use 2sinh(theta h0)>=2theta h0 for the second step, then e>2 and
theta<=1/2 for the last. Independently,

    sum_j c^{4theta n}
       =1/(1-exp(-4theta h0))
       <=1+1/(4theta h0)<=7/(8theta).                  (OW9)

Since u<=xi, OW7–9 prove the **complete** sum, with no unlisted node
or j multiplicity,

    sum_{j,M}(K/3)^theta T_{jM,z}
      <= [7/(64theta^3)] delta(z)
             (K/3)^theta [B rho_D(z)/delta(z)]^{2theta}. (OW10)

Only the original actual-soft three legs and the two original physical
orientations are meant. Their fixed half-menu QG and physical cover
are those of R237 LG3,LG6; arbitrary free extra scales would require
their extra cover fee. If delta=0, the actual traffic is zero; no ratio
by delta is formed. If m_D=0, its source contribution is zero likewise.

For positive delta and m_D put

    R_delta(z)=1+log_+rho_D(z)+log_+K+log B+log(1/delta(z)),
    theta_z=1/[2 R_delta(z)].

This is an original hard-anchor choice, before all x,y,v/u,j,M,t. Then
(K/3)^theta [B rho_D/delta]^{2theta}<=e and OW10 gives

    sum_{j,M}(K/3)^theta_z T_{jM,z}
       <=(7e/8) delta(z) R_delta(z)^3.                 (OW11)

Restoring 2Lambda e^4, three legs and two orientations yields the
original far positive traffic estimate

    P_far(U) <= (21e/2) Lambda e^4
          E sum_V integral delta(z) R_delta(z)^3 nu_V(dz). (OW12)

Lambda=128/119 is the already restored original seed recovery, not
ell=1+log n. No further Lambda or C0=16/3 hard cap is added here.
The source integral has its original nu, including its original history
collection. On a source subset where delta R_delta^3<=H_n, this is an
actual payment <=(21e/2)Lambda e^4 H_n times that subset's original
hard-source mass. It is a root-order source price if H_n is of the
desired root order; the complementary integral is still explicit.

The separate receiver-author crowded-cube lemma is one way to supply
delta. Precisely, if original Omega retains the all-B hardband and a
cube C of full side d<=a has nu(C)>C0q b^n, then that author proves
O_R*(z)<=min(1,nd/a) for z in C and all legal R*. Applying OW12 with
that certified occupation pays that actual original source portion.
No such cube or small delta is assumed for all inputs. Thus OW12 is
not a general root-order weak bound.

## OW6. Real-kernel diagnostic and normalization stress

Actual local Python/mpmath execution at 30 digits used the following
one-dimensional tensor factors, all written as exact decimal strings:

| (L,R,A,s,sigma,y,v,z) | M I0 | M Jhalf | Jtheta/(I0^(1-2theta) Jhalf^(2theta)), theta=.1,.25,.5 |
|---|---:|---:|---|
| (1,1,1,.5,.5,0,.8,.2) | .639609861579 | .652372981738 | .972503556353, .955402341877, 1 |
| (.5,1,1,.1,1,0,1.3,.1) | .975124184646 | .554056126667 | .982085302641, .967271260854, 1 |
| (1,.5,1,.9,1,-.4,.6,0) | .466882110335 | .625498439221 | .995302427854, .992546737585, 1 |

Here b=1, c^2M=min(L,R), w_*=min(1,C(|y-v|)/(c^2M)),
C(d)=integral_core max(h,phi)(u-d)du. Real phi, hard intervals and the
original overlap C are used, not a Gaussian or diagonal substitute.
The factors tensorize to repeated-coordinate fixed-parameter kernels;
these are kernel checks, not FULL original histories or interval proofs.

An adaptive-soft normalization stress was also actually evaluated:
L=1,R=2,y=z=0, s(x)=0 on |x|<=1/2 and s(x)=1 on 1/2<|x|<=1. Then
M I0=1+2 integral_{1/2}^1 phi(u)du=1.2560699822294480233>1.
This confirms the range distinction in OW3; the proof never uses that
invalid adaptive normalization. It does not purport to be an eligible
original receiver selection satisfying FIRST.

Reproducible script (mpmath 1.3.0; no other files required):

```python
import mpmath as m
m.mp.dps=30
E=lambda k,x:m.mpf(1)/(k-1) if x==0 else m.expint(k,x)
def phi(x):
    d=abs(x)
    return 1-E(3,m.mpf('.5')-d)-E(3,m.mpf('.5')+d) if d<=m.mpf('.5') else E(3,d-m.mpf('.5'))-E(3,d+m.mpf('.5'))
def pint(l,u):
    if u<=l:return m.mpf(0)
    if u<=0:return pint(-u,-l)
    if l<0:return pint(0,-l)+pint(0,u)
    Fi=lambda x:x-E(4,m.mpf('.5')-x)+E(4,m.mpf('.5')+x)
    Fo=lambda x:-E(4,x-m.mpf('.5'))+E(4,x+m.mpf('.5'))
    if u<=m.mpf('.5'):return Fi(u)-Fi(l)
    if l>=m.mpf('.5'):return Fo(u)-Fo(l)
    return pint(l,m.mpf('.5'))+pint(m.mpf('.5'),u)
def C(d):
    d=abs(d);return max(1-d,0)+pint(max(m.mpf('.5'),d-m.mpf('.5')),d+m.mpf('.5'))
def f(s,L,x):return ((1-s)*(abs(x)<L/2)+s*phi(x/L))/L
cases=[('1','1','1','.5','.5','0','.8','.2'),('.5','1','1','.1','1','0','1.3','.1'),('1','.5','1','.9','1','-.4','.6','0')]
for case in cases:
    L,R,A,s,sg,y,v,z=map(m.mpf,case);M=max(L,R);dnode=min(L,R)
    w=min(1,C(abs(y-v))/dnode);lo=z-R/2;hi=z+R/2
    cut=sorted(set([lo,hi]+[p for p in [y-L/2,y+L/2,v-A/2,v+A/2] if lo<p<hi]))
    integ=lambda th:m.fsum(m.quad(lambda x:f(s,L,x-y)**(1-th)*f(sg,A,x-v)**th/w**th,[l,u]) for l,u in zip(cut[:-1],cut[1:]))/R
    I0=((1-s)*max(0,min(hi,y+L/2)-max(lo,y-L/2))/L+s*pint((lo-y)/L,(hi-y)/L))/R
    Jh=integ(m.mpf('.5'))
    for th in map(m.mpf,['.1','.25','.5']):
        jt=integ(th);bound=I0**(1-2*th)*Jh**(2*th)
        assert jt<=bound*(1+m.mpf('1e-23'))
        print(case,th,m.nstr(M*I0,12),m.nstr(M*Jh,12),m.nstr(jt/bound,12))
adapt=1+2*pint(m.mpf('.5'),m.mpf(1))
print('adaptive_R>L_normalized_I0',m.nstr(adapt,20));assert adapt>1
```

All nine interpolation comparisons passed. The first draft of the
diagnostic primitive mishandled the additive constants across u=1/2
and returned complex fractional powers; the final script uses separate
interior/exterior primitives and explicit splitting, then completed
successfully. The algebraic proof and final displayed results use only
this corrected script. No fitted dimension order or false certified
claim is inferred from these finite calculations.
