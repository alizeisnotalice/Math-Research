# R238：原拥挤来源迫出的接收薄层及已付款分支

本稿给出一个实际空间机制：原 hard 来源若在很小的立方体中超过全部合法尺度允许的接收质量，则任何原 receiver 的 hard cube 都不能包含该小立方体。因此同一个 hard 来源只能通过一个有明确体积的边界薄层被接收。该损失可保入全部节点与原 posterior 时钟预算，而不把 hard 来源当成 posterior 来源。

主结论 RG7 是一般原资料上的衰减估计；RG8 给出已经完整付款的来源分支。一般剩余高局部质量但不够集中的来源尚未支付，不声称一般根阶结论。

## RG1. 原全部尺度 hardband 的出处及保留方式

沿 R237 保固定原 `(ω,V)`、`ν≤β≤α≤f dx`、共同 `q,a,b`、`0<a≤b≤2a`、原 source-pair 集

\[
 D_V(z)=V\cap\{y:\|y-z\|_1\le17na\}
 \cap\{y:\|y-z\|_\infty\le b(5\log n+1/2)\}.
\]

这些来源和参数跨 `j` 不变。`m_D(z)=β(D_V(z))`、`ρ_D(z)=m_D(z)/(qa^n)` 沿 R237。无效行和空窗取零，原全部大维、soft margin、leaf/history 资格仍在。实际 softness `s(x)` 独立辅助时间和来源变量。

本轮使用的 hardband 是原 **所有 B** 资格，不能仅从 actual `R(x)` 的单个帽推断。作者已实际窄读
`/Users/zhengzhihao/Desktop/T/output/cube_general_20261003/GENERAL_CURRENT_REDUCTION.md`
第 7–13 行：原域为 `2λ<G0≤4λ`，`G_s=sup_(a≤L≤b)P_s,L*f`，且 `q∈[3λ/4,λ]`。因此在保留这个原 receiver 指示的 `Ω` 上，

\[
 \nu(Q_B(x))\le\int_{Q_B(x)}f
 \le4\lambda B^n\le C_0qB^n
 \quad(x\in\Omega,\ B\in[a,b]),\qquad C_0=16/3. \tag{RG1}
\]

R231 LD2 及后续原接口正保留这一共同 `Ω`。R222 `weight_contract.md` 第 94 行也强调：正放 RN 因子后仍必须显式保原 hardband 指示。本文绝不先扩大 receiver 到任意全空间，再追认 RG1。

`ν` 是原 top-k 等已付步骤后的同一 hard tail；没有再次选择、剥离或重新排序。`β` 只沿其原 FIRST 与 source-pair 支持使用，不继承 hard-source 的 rank 或密度帽。

## RG2. 拥挤立方体的精确接收排除

设 `C=∏[c_i−d/2,c_i+d/2]` 是预冻结立方体，完整边长 `0<d≤a`，且

\[
 \nu(C)>H_*:=C_0qb^n. \tag{RG2.1}
\]

对于任意合法节点尺度 `R∈[a,b]`，`Q_R(x)` 不可能包含 `C`：否则 RG1 给 `ν(C)≤C0qR^n≤H*`，矛盾。因此

\[
 \Omega\cap Q_{R-d}(c)=\varnothing. \tag{RG2.2}
\]

这里边长为零时仅表示零体积的极限；本稿后续真增益发生于 `d<a/n<R`。对于每个 `z∈C`，包含整个 `C` 的 receiver 中心集 `Q_{R-d}(c)` 包含于 `Q_R(z)`。故

\[
 \boxed{O_R(z):=\int_\Omega h_R(x-z)dx
 \le1-(1-d/R)^n\le\min(1,nd/a).} \tag{RG2.3}
\]

证明只计算两个轴对齐立方体的体积：`{x:z∈Q_R(x)}=Q_R(z)`，完整边长分别 `R` 和 `R−d`；最后用 Bernoulli 不等式。边界对 Lebesgue receiver 积分无影响。源测度绝对连续，亦不发生原核边界质量问题。

这对每一个 physical upward 节点成立，因为节点自身也在 `[a,b]`，RG1 对全部这些尺度成立。因此没有 `γ` padding 带来的额外占用损失，也没有从 actual `R` 向节点 `R*` 偷换 hardband。

## RG3. 无需复制来源的可测集中半径

以原完整 hard tail `ν` 定义

\[
 d_H(z)=\inf\{d\in(0,a]:\nu(Q_d(z))>H_*\},\qquad
 \inf\varnothing:=a,\qquad
 \delta(z)=\min\{1,nd_H(z)/a\}. \tag{RG3.1}
\]

球质量由同一原 `ν` 计算，不是 `β`，也不是某个 posterior。有限 `ν≤f dx` 保证 `ν(Q_d(z))` 关于正 `d` 连续，并且 `d↓0` 时趋零。可用有理半径表达其阈值集合，故 `d_H,δ` 可测，且原非零情形 `δ>0`。不需要为各 `z` 另选来源或 disjoint source cells。

若 `δ=1`，`O_R≤δ` 平凡。若 `δ<1`，由 inf 的定义可取满足 RG2.1 的半径 `d↓d_H(z)`，均有 `d<a`。用中心在 `z` 的这些立方体和 RG2.3，再取极限，得到全部节点的同一上界

\[
 \boxed{O_R(z)\le\delta(z)\quad\text{对所有 }R\in[a,b].} \tag{RG3.2}
\]

这里每个 hard 来源 `z` 最终只在原 `ν(dz)` 中积分一次。既没有对重叠来源球逐球复制 `ν`，也没有为测量集中程度额外收费。`d_H` 只是原来源的可计算函数。

## RG4. 将真实占用接入 actual-soft 重叠

固定原 hard `z`、一个节点 `(j,M)` 和 `0<θ≤1/2`，在 receiver/soft/auxiliary/time 之前冻结 `θ`。记 `γ=1+1/n`、`c=γ^−j`、`M0=a/c²`，节点及两朝向、三目标腿沿 R237。原外系数为 `2Λe^4(K/3)^θ`；这里没有改动它。

保同一原 receiver 与静态合法 capture `C_z(x,y,v)∈[0,1]`，定义

\[
 I_0(y,z)=\int_\Omega h_{R^*}(x-z)P_{s(x),L^*}(x-y)dx,
\]

\[
 J_\theta(y,z,v)=\int_\Omega h_{R^*}(x-z)C_z(x,y,v)
 \frac{P_{s(x),L^*}(x-y)^{1-\theta}Q(x,v)^\theta}
 {w_*(y,v)^\theta}dx.
\]

`Q` 是相应实际 soft 目标或固定 J 目标；所有变量、来源及 physical 节点合法性同 R237。原 full FIRST 在 `β|D_V(z)` 上给

\[
 \boxed{\int_{D_V(z)}I_0(y,z)\beta(dy)
 \le q\int_\Omega h_{R^*}(x-z)dx
 \le q\delta(z).} \tag{RG4.1}
\]

半阶列对 actual-soft 不直接调用 fixed-soft QG。令 `N=ceil(πsqrt n)`、`B=eN`，先用已经证明的同一个最近角 soft 菜单，再对其固定参数列调用 QG，保必需 capture 支持，得 `J_(1/2)≤B M^−n`。在同一正测度 `h_R C_z dx` 上 Hölder，并把其零阶列上放到 `I0`，得到

\[
 J_\theta\le I_0(y,z)^{1-2\theta}(BM^{-n})^{2\theta}. \tag{RG4.2}
\]

这一步既不要求也不授 adaptive `I0≤M^−n`。实际 `s(x)` 不被重新选择。零列按极限解释；最后所用指数严格小于 `1/2`，无 `0^0` 歧义。静态 capture 和原其它门只按已有正支配放松；原 `Ω` 在 `I0` 和 RG4.1 中始终保留。

上述共同底测度插值的独立完整证明由本轮 `overlap_weight.md` 给出。此处保其原对象，直接纳入新 RG3 几何损失。

## RG5. 原 full posterior 与新节点时钟价

令 `ξ=n log(M/M0)`，原 far 窗为 `[a/c,g*exp(−U/n)]` 的有效子集，`g*=cM`，`U≥0`。长度至多 `(ξ−U)_+/n`。固定 `(j,y,t)`，完整原 `Π_t` 与 `k_t` 不依 hard `z` 或 receiver。两个槽仍是同一 `Π_t`，因此

\[
 \iint(k_v-k_u)_+d\Pi_t^2\le n/4.
\]

把 RG4.2 用作同一原列的 `v` 一致上界后，先用此 Gini 界，再积原 soft 来源。Hölder 与 RG4.1 给

\[
 \int_{D_V(z)}I_0^{1-2\theta}\,d\beta
 \le m_D(z)^{2\theta}[q\delta(z)]^{1-2\theta}.
\]

保原外 `q^−1` 后，该节点已经积掉 soft 来源的交通满足

\[
 \boxed{\mathcal T_{jM,z}\le
 \frac{(\xi-U)_+}{4}
 (B\rho_D(z))^{2\theta}\delta(z)^{1-2\theta}
 c^{4\theta n}e^{-2\theta\xi}.} \tag{RG5}
\]

没有把 hard `z` 换成 `Π_t`，没有归一化局部 `ν`，没有将依 `y` 的 `e_t(y)` 提出来源积分。这个正估计甚至无需 heavy floor；将原有效门正放到上述节点窗仍是上界。原删除、capture、history 的其它条件不作为新负信用使用。

## RG6. 全尺度和及 z 预冻结优化

对每个 `j`，`ξ` 的正规点为 `kh0`，`h0=n log γ∈[log2,1]`，另至多一个不重复的 capped endpoint。对 `θ≤1/2`，

\[
 \sum_M\xi e^{-2\theta\xi}\le\frac1{2\theta^2},\qquad
 \sum_{j\ge0}c^{4\theta n}\le\frac7{8\theta}. \tag{RG6.1}
\]

第一式正规和 `h0 e^−2θh0/(1−e^−2θh0)^2≤1/(4θ²h0)≤3/(8θ²)`，单个 capped endpoint 至多 `1/(2eθ)≤1/(8θ²)`；最后用 `θ≤1/2`、`e>2`。第二式由 `1/(1−e^−u)≤1+1/u` 及 `h0≥2/3`，即 `θ+1/(4h0)≤7/8`。有限实际节点只会更小。

由 RG5 和 `(ξ−U)_+≤ξ`，每个腿/朝向的完整和满足

\[
 \sum_{j,M}(K/3)^\theta\mathcal T_{jM,z}
 \le\frac7{64\theta^3}\delta(z)(K/3)^\theta
 \left(\frac{B\rho_D(z)}{\delta(z)}\right)^{2\theta}. \tag{RG6.2}
\]

令

\[
 R_D(z)=1+\log_+\rho_D(z)+\log_+K+\log B,
 \quad H_D(z)=R_D(z)+\log(1/\delta(z)),
 \quad\theta_z=\frac1{2H_D(z)}.
\]

所有量由预冻结原来源及当前 hard `z` 决定，早于 `x,y,v,u,j,M,t`。原 good 不等式及以上估计统一于 `θ`，因此此选择合法。`m_D=0` 的原行直接为零。指数因子不超过 `e`，从 RG6.2 得

\[
 \sum_{j,M}(K/3)^{\theta_z}\mathcal T_{jM,z}
 \le\frac{7e}{8}\delta(z)H_D(z)^3. \tag{RG6.3}
\]

不用旧的大小节点 split；这里的 `B` 只进入对数，不是全式外乘菜单数。

## RG7. 带真实接收衰减的原交通定理

恢复三个腿、两个朝向及 `2Λe^4`，得到

\[
 \boxed{P_{\rm far}(U)\le
 \frac{21}{2}\Lambda e^5\,
 \mathbb E\sum_V\int_V
 \delta_V(z)\,[R_{D,V}(z)+\log(1/\delta_V(z))]^3\nu_V(dz).} \tag{RG7}
\]

这覆盖同一个原 far 分支的所有 actual softness、scale、deficit、有效 history 和 `U≥0`。`U=0` 指该分支的整个有效时钟，不包括此前另行分配的部分；`U≥n log(b/a)` 时节点窗全空。三来源仍是原 `β(dy)ν(dz)` 和完整 `ν` 的 auxiliary posterior；没有来源变更。

RG7 的衰减由 RG2 的实际接收体积证明，而不是给原余项重命名。对任意 source `z`，只要其同一 hard tail 在**以 z 为中心、完整边长 d<a/n 的 Q_d(z)** 中超过 `C0qb^n`，其价就有 `δ≤nd/a` 的量化损失。任意包含 z 的非居中拥挤 cube 仍有 RG2 的占用界，但不能据此直接把 centered `d_H(z)` 上界为它的边长。

## RG8. 已经付款的集中高质量来源分支

设 `A≥1`，取原预冻结 hard 来源子集

\[
 E_A=\{z:\delta(z)R_D(z)^3\le A\}.
\]

把原正母式的 `z` 积分限制到该集合只选择一个实际子交通，不改变其 posterior。对 `s=log(1/δ)≥0`，用 `(u+v)^3≤4(u³+v³)` 和 `sup_(s≥0)e^−s s³=27/e³`，得

\[
 \delta(R_D+\log(1/\delta))^3
 \le4A+108/e^3\quad(z\in E_A).
\]

因此该完整原 far 子交通已经支付

\[
 \boxed{P_{\rm far}^{E_A}(U)\le
 \frac{21}{2}\Lambda e^5(4A+108/e^3)
 \mathbb E\sum_V\nu_V(E_A).} \tag{RG8.1}
\]

尤其 `A=1` 是常数来源价，不带 `sqrt n` 或菜单因子，也不新增 `X` 费。取 `A=sqrt n·L_n`（`L_n≥1`）则为明确根阶 `O(sqrt n L_n)Wν` 付款。

一个直接可检查的充分条件是：对于该 `z` 存在 `0<d≤a`，

\[
 \nu(Q_d(z))>C_0qb^n,\qquad
 \min(1,nd/a)R_D(z)^3\le A. \tag{RG8.2}
\]

在真正小尺度支，写成 `d≤aA/(nR_D(z)^3)` 即可；特别 `A=1` 允许任意大的局部 `β(D)`，只要同一原 `ν` 的集中尺度按此缩小。没有把 `β` 的高质量当成 `ν` 的拥挤资格。

补集 `δR_D³>A` 仍有 RG7 的明确价；原 gate 目前没有被证明控制这部分局部高质量尾。因此一般输入根阶结论仍开放。

## RG9. 与原 top-k、light、rank 的相容性及非空范围

本轮没有重做这些步骤。R237 `source_ledger.md` SL1/SL4 的原量为：birth piece 完整边长 `a/n`，同一 hard residual 在 top-k 后满足

\[
 \nu(P_i)\le m_{\rm before}/(k+1),\quad
 M_*<m=\nu(V),\quad M_V<\sqrt n\,m,
 \quad M_*=\lambda a^n e^{\sqrt n},\quad |V|=(256na)^n.
\]

rank 是**整片质量**限制，没有片内密度帽。拥挤小球若只落在一个 birth piece 内，必要的质量空间是 `m_before/(k+1)>H*`；若达不到，则该片内的小球支确为空，本文不反向授其非空。一般半径 `d` 的 cube 可遇至多 `(ceil(nd/a)+1)^n` 个 pieces，其上界乘 `m_before/(k+1)` 若不超过 `H*`，同样排除该中心/半径。实际定义 RG3 自动处理这些零支。

同时上述已付步骤的质量和 rank 条件并不普遍迫使 RG8 为空。一个明确的**数值资格相容区间**如下。设原 leaf 容纳至少 `2k+2` 个 birth pieces，并存在

\[
 \max\{H_*,M_* /(k+2)\}<p<
 \frac{K_{256}\lambda|V|}{\sqrt n(2k+2)},
 \qquad K_{256}=4e^{1/128}. \tag{RG9}
\]

则给 `2k+2` 个原 pieces 各相同质量 `p` 的质量账，在删除 `k` 个最大 pieces 后尚有 `(k+2)p>M*`，留下每片质量 `p≤m_before/(k+1)=2p`，且前后质量比 `(2k+2)/(k+2)<2<sqrt n`。总质量也低于原 terminal `σ` low-mean 上限。因为没有片内密度帽，剩余 piece 的该质量可以在任意更小的绝对连续 cube 内承载，而不改变这些整片质量/rank 数值。

RG9 只说明这些已核 top-k/light/relative-mass **数值资格本身**与拥挤尺度分支相容，给出可检验的非空参数条件；不是重新构造 maxflow 残差，更不是宣称已经构造满足全部 FULL/cut/history 的实际输入。尤其本段没有验证 R107 R5 的实际出生行资格 `H_piece(x)<e² q R(x)^n e^(−sqrt n)/sqrt n`；不能据同一 piece 的 `p>H*` 质量账就宣称对应原正行非空。原 `k` 固定，不能为满足 RG9 免费改变它。若实际资料不满足拥挤条件，RG8 不收费该部分。其余原历史条件始终留在左侧，不由本段撤销。

## RG10. 本机核算和证据边界

作者本机实际运行了以下有限检查，不把它们替代严格证明或原历史资格：

- 60 个 exact `Fraction` 体积检查：`n∈{2,3,8,64}`、`d∈{1/1000,1/100,1/10,1/2,1}`、`R∈{1,3/2,2}`，逐一核验 `0≤1−(1−d/R)^n≤min(1,nd/R)`，全部通过。
- 70 位 mpmath 的 60 个预算检查：`R_D∈{1,4,16,512,10^6}`、`A∈{1,sqrt512,sqrt10^6}`、`t∈{1,.1,10^−10,10^−100}`，取 `δ=min(1,A/R_D³)t`，核 `δR_D³≤A` 及 `δ(R_D+log1/δ)³≤4A+108/e³`。全部通过，最大后一比值 `0.90499896498440129346`。

第一组是有理盒体积代数，第二组是有限参数检查。它们不检验 FULL 原来源构造、不拟合 n 阶。独立 numeric 的真实有限密度 receiver 实验及复跑范围由其责任文件记录。

本稿只写 `receiver_geometry.md`；本轮 `overlap_weight.md` 独立负责共同 actual 列插值，`audit.md` 负责原门与终审。没有改动原 source、FIRST、posterior 或他人文件。
