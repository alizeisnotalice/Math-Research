#!/usr/bin/env python3
"""Verify frozen evidence and replay local calculations outside the package."""
import argparse,hashlib,json,os,shutil,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def verify():
    hashes=json.loads((ROOT/'manifest.json').read_text())
    for name,h in hashes.items():assert digest(ROOT/name)==h,name
    return len(hashes)
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--verify-only',action='store_true');ap.add_argument('--output-dir',type=Path);args=ap.parse_args();count=verify()
    if args.verify_only:print('verified',count,'manifest hashes');return
    if args.output_dir is None:ap.error('--output-dir required')
    out=args.output_dir.resolve()
    if out==ROOT or ROOT in out.parents:ap.error('output must be outside package')
    out.mkdir(parents=True,exist_ok=False);runs=[];env=os.environ.copy()
    for name in ('task_contract.md','numeric_checks.py'):shutil.copyfile(ROOT/name,out/name)
    start=time.monotonic()
    subprocess.run([sys.executable,str(out/'numeric_checks.py'),'--output',str(out/'numeric_checks.json'),'--contract',str(out/'task_contract.md')],env=env,check=True)
    assert (out/'numeric_checks.json').read_bytes()==(ROOT/'numeric_checks.json').read_bytes(),'entire JSON differs'
    runs.append({'driver':'numeric_checks.py','checks':69,'entire_json_byte_identical':True,'sha256':digest(out/'numeric_checks.json'),'elapsed_seconds':time.monotonic()-start})
    code=(ROOT/'overlap_weight.md').read_text().split('```python\n',1)[1].split('```',1)[0]
    path=out/'overlap_checks.py';path.write_text(code)
    r=subprocess.run([sys.executable,str(path)],env=env,check=True,capture_output=True,text=True)
    (out/'overlap_stdout.txt').write_text(r.stdout)
    runs.append({'driver':'overlap_weight.md embedded script','interpolation_checks':9,'normalization_stress_checks':1,'stdout':r.stdout.strip(),'exit_code':r.returncode})
    assert verify()==count
    receipt={'complete_replay':True,'manifest_hashes_before_and_after':count,'runs':runs,'python':sys.executable,'scope':'Finite geometry, true fixed-R receivers, finite precision kernels and geometric series; not FULL original histories or general root-order closure.'}
    (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
if __name__=='__main__':main()
