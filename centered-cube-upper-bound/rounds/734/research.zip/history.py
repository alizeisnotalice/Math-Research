from fractions import Fraction as F
from flint import arb,ctx
from math import isqrt
import sys,json
ctx.prec=256
def check(n,j):
    a=32*n; k=n//2
    recovered=0
    for l in range(n):
        sg=(-1)**l; x=sg*F(3,50); h=-sg*F(63,64)
        for slot,R in enumerate((3,2)):
            bad=l<k if slot==0 else j<=l<k
            y=sg*(1 if bad else -1)*F(3*R,4)
            delta=abs(x+y/R-h)
            error=F(1,16*a)+F(2,a)+F(1,n)
            assert (delta-error>1 if bad else delta+error<1)
            if slot==1 and l<k and not bad:recovered+=1
    assert recovered==j
    lam=arb(2)**(arb(1)/n);T=(1+arb(1)/a)*lam
    rho=1-lam/a; dist=arb(3)/50+arb(63)/64+arb(1)/(16*a)
    g=(T+rho-dist)/(2*T)
    bounds=[j*arb(v).log()+k*(1-g*(1-arb(1)/v)).log() for v in (1,2,4,8,16)]
    K=4096*isqrt(n)*a**n; ell=arb(2).log()/K; vt=arb(1)/(8*a)**n;hi=vt*ell.expm1()/2
    lg=n*arb(32*n).log()+(K-5)*n*arb(4).log()+(-(-ell).expm1()).log()
    assert hi>0 and hi<vt/4 and lg>(4*arb(6)**n+1).log()
    return dict(n=n,missed=k,repaired=j,min_owner_success=str(g),log_bin_probability_bound=str(min(bounds)),
        high=str(hi),V_T=str(vt),logD_div_K_bounds=[str(lg/K),str((lg+arb(3).log())/K)],excess=0)
print(json.dumps(dict(python=sys.executable,bits=256,cases=[check(n,j) for n in (256,1024,4096) for j in (0,n//128,n//4)]),indent=2))
