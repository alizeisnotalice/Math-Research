"""Independent exact lower tails and near-extreme order statistics."""
from fractions import Fraction as F
from itertools import product
from math import prod
from pathlib import Path
import sys,json,platform,subprocess
def dp(p,k):
    a=[F(1)]+[F(0)]*k
    for q in p:a=[v*(1-q)+(a[i-1]*q if i else 0) for i,v in enumerate(a)]
    return sum(a)
def poly(p,k):
    # Elementary symmetric sums through Newton identities for the odds.
    odds=[q/(1-q) for q in p]; ps=[sum(x**j for x in odds) for j in range(1,k+1)]
    es=[F(1)]
    for j in range(1,k+1): es.append(sum((-1)**(v-1)*ps[v-1]*es[j-v] for v in range(1,j+1))/j)
    v=sum(es)
    for q in p:v*=1-q
    return v
def exact(remote=False):
    out=[]
    for n,d in ((8,1),(24,3),(96,8),(128,8)):
        # Calculated coordinates in the worst ordered subset; two-sided uniform envelope.
        ps=[F(2*i+1,2*n) for i in range(n)]
        for k in (n//4,n//2,n):
            cut=min(d,k-1); p=ps[:k]
            val=(poly if remote else dp)(p,cut)
            bd=min(F(2)**cut*prod(1-q/2 for q in p),1)
            assert val<=bd
            out.append([n,k,cut,str(val),str(bd)])
    return out
if '--remote' in sys.argv:
    print(json.dumps(exact(True)));sys.exit()
from flint import arb,ctx
ctx.prec=256
rows=exact()
cmd=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=8','macbook-math','/Users/zhengzhihao/.venv/bin/python -B - --remote']
proc=subprocess.run(cmd,input=Path(__file__).read_text(),text=True,capture_output=True,timeout=60)
assert proc.returncode==0 and json.loads(proc.stdout)==rows
ranges=[]
for e in (12,20,32,48,64):
    n=2**e;l=arb(n).log()
    # k=ceil(256 sqrt(n log n)) where there is a feasible slice.
    k=int(float(256*(arb(n)*l).sqrt()))+1
    if k<=n:
        ranges.append([e,k,str(arb(k)**2/(4096*n*l)),str((arb(n)*l*4/arb(n).sqrt()).log()-arb(k)**2/(4096*n))])
print(json.dumps(dict(python=sys.executable,version=platform.python_version(),exact=rows,remote_cmd=cmd,remote_exit=proc.returncode,match=True,expanded=ranges),indent=2))
