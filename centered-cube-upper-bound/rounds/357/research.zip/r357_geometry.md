# R357 — A priced multi-face union pays a new joint terminal branch

## Outcome

Start with the R356 direction-diffuse terminal measure F_disp, keeping its full original marks and unchanged R355 path process. Let σ be the R355 common shrink factor, t=1−σ, and L_n=log(n+2). A terminal tuple (z,w) has face count

    d(z,w)=#{i:|w_i−z_i|>σR_w/2}.

It already satisfies d≥1. Set

    m=1+ceil(8L_n).

This note pays a new combined terminal event: first all traffic over any source for which at least one quarter of the terminal traffic has d≥m; then, on the remaining sources, all individual tuples with d≥m. The joint source cost is

    C_multi,n W,   C_multi,n=4N C_m,
    C_m=P{Bin(n,t)≥m}
          +n log(b/a) P{Bin(n−1,t)≥m−1}.             (1)

The binomial quantities here are exact product-volume coefficients for receiver-center geometry. They are not assumptions about independent coordinates of f or of the original traffic.

On the nonempty original high-past branch,

    C_m≤A_n/(n+2)^4,
    C_multi,n≤4√n A_n/(n+2)^4≤4√n,                   (2)

where A_n=1+n log(b/a). There is no new X_q fee. The remaining measure F_low satisfies

    1≤d(z,w)<m for every remaining terminal tuple,
    L_i^new(z)/L_new(z)<4/[3log(n+2)]                 (3)

whenever its terminal source density is positive. The second inequality includes the normalization loss caused by the new deletion. Neither a root bound for all F_low nor coordinate independence is proved.

## 1. Frozen data and terminal joint domination

Use the original nonnegative f∈L¹, actual Lebesgue receivers, and full-f centered cubes

    Q_w=w+[-R_w/2,R_w/2]^n,
    m_w=∫f1_{Q_w}=q_wR_w^n,
    q_-=3λ/4≤q_w≤λ,  a≤R_w≤b≤2a.

Keep K=e^{√n}, s=1+√n, the genuine noncyclic rank subkernel, and

    N=max(1,ceil(log[(λ/q_-)(b/a)^n]/√n)),
    σ^n=min(1,s/(N A_n)).

Every original old source, small endpoint, full J, ηΩ, physical clock with its terminal atom, old high-past/outside/prefix and initial-witness crossing marks remain unchanged. Later current receivers are not substituted into those old gates.

The R355 process is unchanged: rich stop, true full-f source draw, inner-source stop, ancestor recapture stop, then rank termination or continuation. Its actual receiver arrival density at each of its at most N generations obeys κ_j≤q. All paths remaining in F_disp retain the R355 all-visited posterior shell qualification and actual shell/freshness conditions, as well as the R356 whole-source direction-diffuse gate.

In particular, its generation-j terminal (z,w) marginal has a measurable representation

    dT_j(z,w)=f(z)1_{Q_w}(z)k_j(z,w) dz dw/m_w,
    0≤k_j(z,w)≤κ_j(w)≤q_w.                           (4)

This comes from the actual source draw before conditioning on terminal success; the terminal, ancestor and old marked qualifications only multiply it by weights at most one. The R356 direction-diffuse restriction is also a positive source restriction. Thus (4) remains valid. A terminal receiver marginal alone would not justify it.

Let f(z)L(z)dz be the source marginal of F_disp and f(z)L_i(z)dz its restriction to face i. Define these from (4) by summing over all generations. Then

    F_disp=∫fL,
    0≤L_i≤L≤sum_i L_i,
    L_i(z)<L(z)/L_n whenever L(z)>0.                 (5)

The inequalities use overlapping face events, not a partition into independent directions. On {L=0}, all L_i are zero.

## 2. Candidate screening: a fixed k-face estimate alone is insufficient

For a fixed set I of k coordinate indices and 0<σ<1, actual-center integration gives

    ∫_E R_w^{-n}1_{z∈Q_w}
          product_{i∈I}1_{|w_i−z_i|>σR_w/2}dw
      ≤B_k,
    B_k=t^k+[k t^{k−1}+(n−k)t^k]log(b/a).            (6)

The proof is included through the more general count calculation below. A selected k-face event is contained in each of its single-face events. Therefore merely repeating the R356 source-heavy test for one such fixed intersection does not establish a new general payment of the direction-diffuse remainder.

Nor may I be selected separately for each receiver for free. For any 1≤k≤m≤n, the exact combinatorial identity

    sum_{|I|=k}1_{all faces in I occur}=binom(d,k)

implies only the properly priced union bound

    center-capacity{d≥m}
       ≤binom(n,k)B_k/binom(m,k).                     (7)

Both combinatorial factors must remain. The following direct count formula accounts for all of this selection entropy at once and is the candidate actually used.

## 3. Exact volume bookkeeping for many simultaneous faces

For any integer 1≤m≤n and each source z,

    ∫_E R_w^{-n}1_{z∈Q_w}1_{d(z,w)≥m}dw≤C_m,         (8)

where C_m is (1). If m>n, the event and C_m are both zero.

Translate z to zero and put r=2||w||∞. Contributing centers have r≤R_w and a≤R_w≤b.

For r<a, the density is at most a^{-n}. Each actual near-face coordinate obeys 2|w_i|>σR_w≥σa. Therefore the contributing centers are contained in the cube of side a with at least m coordinates in its two outer strips. Under its normalized Lebesgue volume, each absolute coordinate is uniform on [0,1]; the outer-strip proportion is t. The product-volume fraction is exactly

    P{Bin(n,t)≥m}.

Multiplication by a^n and then a^{-n} gives the first term of C_m. This is an exact computation with Lebesgue center volume, not a distributional assumption about f.

For r≥a, the density is at most r^{-n}. At least m coordinates must obey 2|w_i|>σr. Except on a Lebesgue-null set of center ties, precisely one coordinate achieves the maximum r/2. On each such face of the cube shell that maximum coordinate is automatically in its outer strip when σ<1; the other n−1 normalized absolute coordinates have product uniform surface measure. Consequently the fraction of the radial shell with at least m such coordinates is

    P{Bin(n−1,t)≥m−1}.

The cube shell volume is n r^{n−1}dr, so its total contribution is

    ∫_a^b r^{-n}n r^{n−1}dr P{Bin(n−1,t)≥m−1}
      =n log(b/a)P{Bin(n−1,t)≥m−1}.

This proves (8). The use of product volume is entirely within real receiver geometry; arbitrary source concentration and any dependence of path coordinates are allowed.

For the fixed set I in (6), the flat contribution is t^k. In the high radial shell, the maximum coordinate belongs to I on k/n of its faces, requiring the other k−1 selected coordinates to be outer; on the remaining faces all k selected coordinates must be outer. Its shell fraction is

    (k/n)t^{k−1}+((n−k)/n)t^k.

Integrating gives (6). Thus the fixed-face and full selection-count formulas agree, and (8) does not omit a factor binom(n,k).

### Endpoints

At σ=1, every strict face event is empty. The general formula (1) remains an upper bound by nonnegativity; for the chosen m>1 it is zero as well. More directly, the R355 process has no remaining flow at σ=1 because its rich test sees π_w(Q_w)=1. We do not apply the strict radial-face argument at this endpoint.

For n=1, the generic m=1 formula reduces to (1−σ)+log(b/a), consistent with R356. Our chosen m is greater than n, so its high-multiplicity event is empty. If b=a, the high radial term vanishes. Binomial tails are defined as zero when their threshold exceeds the number of trials, including Bin(0,t).

## 4. Accounting for the selection entropy gives a root source cap

On a nonempty original high-past entrance, the audited R352/R355 guards give

    N≤√n,   nt=n(1−σ)≤log n≤L_n.                    (9)

Let k=m−1=ceil(8L_n). If m>n, C_m=0 and there is nothing to estimate. Otherwise, monotonicity of binomial counts gives

    C_m≤A_n P{Bin(n,t)≥k}.                           (10)

The factorial-moment bound for an auxiliary binomial count X is

    P{X≥k}≤E binom(X,k)=binom(n,k)t^k
                      ≤(e nt/k)^k.                  (11)

The last inequality follows from k!≥(k/e)^k, which follows by integrating log on [1,k]. This combinatorial estimate is applied to the product-volume count just computed, never to a posterior or to a path process.

Since k≥8L_n, e<4, and nt≤L_n,

    (e nt/k)^k≤2^{-k}.

Also log2>1/2, so k≥8L_n implies

    2^{-k}≤exp(−4L_n)=(n+2)^{-4}.                    (12)

Equations (10)–(12) prove C_m≤A_n/(n+2)^4. If nt=0, the relevant tails are directly zero and no division by t is made. The estimate includes the full face-selection entropy; it is not the fixed-face probability with the number of possible face sets suppressed.

## 5. True common-source terminal density and a combined source/tuple split

Let H(z) be the terminal-source density factor of the event d(z,w)≥m within F_disp. From (4) and (8),

    0≤H(z)≤L(z),
    H(z)≤N C_m.                                     (13)

All N generations and all paths with that same actual source are included in H. In particular,

    ∫f(z)H(z)dz≤N C_m W.                            (14)

No cross-path disjointness is assumed.

Deleting only the high-multiplicity tuples would change the normalized source-direction bounds (5) without controlling the change. We therefore use the following exact two-part positive split of the existing terminal measure, without altering the process:

- If L(z)>0 and H(z)≥L(z)/4, pay the entire source block at z.
- On the complementary source set, pay its individual terminal tuples with d≥m.

For L=0 there is no traffic; take this source in the complement and H=0. The paid density factor is

    P(z)=L(z)1_{L>0,H≥L/4}+H(z)1_{H<L/4},            (15)

with P=0 when L=0. Its two terms are disjoint and

    P(z)≤4H(z).                                     (16)

Thus the total new fee is

    F_paid=∫fP≤4N C_mW=C_multi,n W.                 (17)

This is one combined charge. It does not add the full source-block bound to a second independent high-multiplicity bound.

Let F_low be the exact remaining terminal measure and L_new,L_i^new its source and coordinate-face density factors. On every source with remaining mass, H<L/4 and

    L_new=L−H>3L/4,
    L_i^new≤L_i<L/L_n<4L_new/(3L_n).                 (18)

Each remaining tuple has d<m, so (3) follows. The previous threshold 1/L_n is not falsely retained after this normalization. If H=0 and L>0, nothing is removed there and its original stricter threshold still holds.

The event d≥m can be spread over different coordinate subsets at different terminal tuples. Such spread need not create a dominant single coordinate at the same source, so it is not simply the R356 single-face-heavy source event again. The new payment accounts for all coordinate subsets through (8), and the source-block step in (15) also preserves a quantitatively controlled directional-spread statement on the complement.

## 6. Exact new fee, ledger, and remaining mechanism

By (9), (12), and A_n≤1+n,

    C_multi,n=4N C_m
       ≤4√n A_n/(n+2)^4
       ≤4√n.                                       (19)

Retain the exact coefficient 4N C_m if desired; the simpler 4√n is a valid root source fee. If the original high-past entrance is empty, the entire flow is zero and the fee may be taken zero.

At the R356 ledger's F_disp slot substitute the exact identity

    F_disp=F_paid+F_low.

The updated hard-slot estimate is

    B_H≤F_low
       +[(13/3)ε+γ_eff+β+α_rec+c_eff]X_q
       +[C_{ε,n}+8s+C_dir,n+C_multi,n]W
       +(D_top,n+C_hit,n+s)W_ex.                     (20)

All previous symbols retain their archived meanings. There is zero new X_q fee. The new source fee is full W, because the terminal source law is the true full-f posterior. Entrance factor two and exterior Λ multiply it, giving 2ΛC_multi,nW. None of the previous rich/inner, recapture, old-clock, or direction-concentrated fees is charged twice.

The low-multiplicity qualification concerns the terminal tuple only. It is not imposed retrospectively on earlier source draws. The R355 posterior and actual-source shell/freshness conditions still hold along the whole path, while the original old-clock crossing remains tied only to the initial w_0.

The remaining F_low has at most O(log n) terminal near-face coordinates per tuple while its source-conditional terminal direction load remains spread, in the exact sense (18). These facts are not independent-coordinate statements and do not by themselves provide its total budget. The general root goal and all other archived unpriced slots remain open.

## 7. Executed reproducible checks

The following Python code was actually executed. It passed 2,808 exact rational inclusion-exclusion identities linking fixed-face capacities to the full binomial count, including their combinatorial selection factors; it also passed 404 exact merged-source splits, including L=0, H=0, and H=L/4.

Five ordinary floating-point tail diagnostics used the actual R355 parameter choices in dimensions 128, 512, 1458, 4096 and 16384. They verified the displayed parameter inequalities and C_m≤A_n/(n+2)^4. They are numerical diagnostics, not proof certificates or realizations of the original high-past marked flow. The proof of the general bound is (9)–(12).

```python
from fractions import Fraction as F
from math import comb, log, log1p, lgamma, exp, expm1, ceil, sqrt

def tail(n,t,k):
 if k<=0: return F(1)
 if k>n: return F(0)
 return sum(F(comb(n,j))*t**j*(1-t)**(n-j) for j in range(k,n+1))
checks=0
for n in range(1,13):
 for den in range(2,10):
  for num in range(1,den):
   t=F(num,den)
   for m in range(1,n+1):
    low=high=F(0)
    for k in range(m,n+1):
     coeff=(-1)**(k-m)*comb(k-1,m-1)*comb(n,k)
     low+=coeff*t**k
     high+=coeff*(F(k,n)*t**(k-1)+F(n-k,n)*t**k)
    assert low==tail(n,t,m)
    assert high==tail(n-1,t,m-1)
    checks+=1
merge_checks=0
for L in [F(0),F(1),F(3,2),F(5)]:
 for j in range(101):
  H=L*F(j,100)
  whole=L>0 and H>=L/4
  paid=L if whole else H
  remain=F(0) if whole else L-H
  assert paid<=4*H and paid+remain==L
  if remain>0: assert remain>3*L/4
  merge_checks+=1

def float_tail(n,t,k):
 if k>n: return 0.0
 if k<=0: return 1.0
 p=exp(lgamma(n+1)-lgamma(k+1)-lgamma(n-k+1)
       +k*log(t)+(n-k)*log1p(-t))
 total=p
 for j in range(k,n):
  p*=((n-j)/(j+1))*t/(1-t)
  total+=p
  if p==0: break
 return total
out=[]
for n in [128,512,1458,4096,16384]:
 x=sqrt(n); s=1+x; A=1+n*log(2)
 N=max(1,ceil((log(4/3)+n*log(2))/x))
 sigma_log=min(0.0,log(s/(N*A))/n); t=-expm1(sigma_log)
 m=1+ceil(8*log(n+2)); k=m-1
 Cm=float_tail(n,t,m)+n*log(2)*float_tail(n-1,t,m-1)
 assert N<=x and n*t<=log(n)
 assert Cm<=A/(n+2)**4
 out.append((n,N,m,Cm))
print('PASS',checks,'exact binomial/cone inclusion-exclusion identities;',
      merge_checks,'exact merged source splits')
print('Ordinary-float tail diagnostics (n,N,m,Cm):',out)
```

The recorded floating values of C_m were approximately 9.40638e−26, 4.89463e−29, 5.47377e−33, 2.43010e−36 and 2.46196e−41 in the five listed dimensions. They are not substituted for the symbolic bound in the ledger.

Only /tmp/r357_geometry.md was authored. The new proved joint payment is (17)–(19); the terminal low-multiplicity, direction-diffuse remainder is not declared paid.
