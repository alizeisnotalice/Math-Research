# R357 final independent audit — PASS for the combined high-face terminal payment

Independent screens preceded reading the author proofs. This final file replaces its preliminary status. Read the frozen geometry, bridge, main/ledger/README, numeric code/result/notes and extracted proof script. Only this owned audit was modified; no author files or Git state were changed and the parent's full pipelines were not repeated. The historical global reduction remains inherited rather than exhaustively re-audited. General arbitrary-input root-order weak type is not certified complete.

## 1. Correct all-combination receiver capacity: PASS

For a fixed source z and the ACTUAL variable-radius field, the high-face count is d=#{i:|w_i-z_i|>sigma R_w/2}. In the low-radius cube, admissibility gives independent coordinate-strip product VOLUME with count Bin(n,t), t=1-sigma, and density at most a^(-n). On the outer cube shell at radial r=2||w-z||_infty, one coordinate is the unique absolute maximum away from a null set; for sigma<1 it is automatically a face, while the remaining n-1 surface coordinates have product-uniform reference volume. This gives 1+Bin(n-1,t). The actual density is at most r^(-n), so the shell integral contributes n log(b/a). Hence the full high-count capacity is bounded by
 C_m=P(Bin(n,t)>=m)+n log(b/a)P(Bin(n-1,t)>=m-1).
This is a true Lebesgue receiver-center envelope. Product-volume binomial notation does NOT impose independence on f, a posterior, coordinates of terminal traffic or path histories.

The fixed k-face bound and its binomial(n,k)/binomial(m,k) selection cost are correctly exhibited before the direct count formula. No coordinate-subset choice is free, and no choose factor disappears. The direct count formula incorporates the entire selection entropy. Variable R can only make the original event smaller than this common radial envelope; no full-f density cap or source boundary-volume estimate is used.

Strict sigma=1 is separately empty; a generic forced-one formula at m=1 can still be a nonsharp closed/left-limit upper bound and is not called the true strict capacity. For the chosen m>1 it is zero as well. m>n has empty original event and both tails zero. n=1 uses Bin(0,t), b=a removes the logarithmic term, and nt=0 is handled directly. No division by zero or endpoint atom substitution occurs.

## 2. Adopted tail exponent and threshold: PASS

Set L_n=log(n+2), k=ceil(8L_n), m=k+1. The nonempty ORIGINAL high-past guard supplies N<=sqrt(n) and nt<=log n<=L_n. If m>n use exact zero. Otherwise monotonicity gives C_m<=A_n P(Bin(n,t)>=k). The factorial-moment inequality P(X>=k)<=E binom(X,k)=binom(n,k)t^k<=(ent/k)^k, with k!>=(k/e)^k, is valid for the geometric count. e<4 and k>=8L_n give a bound by 2^(-k); log2>1/2 then gives (n+2)^(-4). Thus C_m<=A_n/(n+2)^4<=1 and C_multi=4NC_m<=4sqrt(n).

The preliminary stronger -8 estimate and numeric appendix are also valid in their stated ranges, but the ADOPTED main proof uses only -4. No stronger tail certificate is silently required or substituted for that proof. Fixed chosen rational thickness values in the numeric module are not claimed to be every actual R355 sigma; the universal statement is proved analytically from nt<=L_n. The ordinary-float checks include parameter choices in dimensions whose original high-past input is empty; they are not difficult-field realizations.

## 3. Actual terminal joint law and combined source/tuple payment: PASS

Start with the existing R356 F_disp, not a new source or process. Its generation-j normal-terminal source/receiver measure remains bounded by f(z)kappa_j(w)c_w(z)dz dw/m_w, kappa_j<=q, because the genuine full-f source draw precedes all current terminal filters and every ancestral/source restriction is positive. This JOINT domination, not merely an integrated terminal receiver marginal bound, gives H(z)<=NC_m for the high-count source subcolumn. The whole original terminal source column L satisfies 0<=H<=L.

The adopted split first pays the full source block where L>0 and H>=L/4, then only the high-count tuples at all other positive sources. Zero L gives zero H and no traffic. The combined paid column is L on the first class and H on the second, so it is <=4H pointwise. This gives ONE actual source price 4NC_m W, not a rich-source bound plus another independent tuple price. The source mass is full W, not W_ex.

This is a measurable POSTHOC positive classification of the already fixed terminal measure, and need not be predictable: it changes no transition, posterior, stopping event, original q/J/clock, or old label. A process restart with that selected source would require a different proof and is not done here. R356's paid dominant-coordinate sources are already absent, so the new class is applied to its actual complement, with no repeated charge. No uniformly positive paid fraction for every input is claimed.

## 4. Exact normalization loss and remainder: PASS

At a positive surviving source, H<L/4 and L_new=L-H>3L/4. Coordinate columns are positive restrictions, hence
 L_i,new<=L_i,old<L_old/log(n+2)<4L_new/[3log(n+2)].
The factor 4/3 is explicitly retained everywhere. The old numerical threshold is NOT claimed unchanged after removing high-count tuples. Zero remaining sources use no ratio. Remaining terminal tuples have 1<=d<m, by the inherited actual shell exclusion and new high-count removal.

Low terminal face count and source-conditional direction dispersion do not imply independent coordinates, isotropy, disjoint path source sets or a root estimate for the entire F_sparse. The qualification concerns the current TERMINAL tuple only, not all earlier source draws. Earlier all-visited posterior shell conditions, actual shell samples, ancestor freshness and complete original path labels remain. The old physical r/old y crossing belongs only to initial w_0 and is never moved to a later endpoint.

## 5. Updated complete ledger: PASS, no new receiver fee

The only new substitution is F_disp=F_multi+F_sparse at the R356 residual slot. The W coefficient becomes C_epsilon,n+8s+C_dir+C_multi; W_ex remains D_top+C_hit+s. The new source cost receives entrance factor two and exterior Lambda, namely 2Lambda C_multi W. All previous rich/inner, recapture, old-clock, peeling, source clipping and direction-source charges remain once each. No old negative square or defect credit is spent again.

The receiver coefficient and its explicitly conditional same-certified-X CZ accounting remain <889/2304, with >1415/2304 unallocated headroom. That headroom does not pay the remaining integrals. All general soft/crossing terms, hard-contract-exterior coupled tails, distance/low-pe/extreme-scale/threshold complements, chronological initial/deletion/future-deleted-source atoms, H/source/layer/physical-scale/outer-integral/truncation-limit costs and their multipliers are retained. Physical clock/rank endpoints do not replace historical time atoms. The historical base sections are kept for comparison and are not additional repeated charges.

## 6. Old-square bridge: correct limited diagnostic, no new fee

For the SAME original old pair m_u>K m_v, true overlap I_uv<=m_v gives 2I_uv<=2(m_u-m_v)/(K-1). Keeping identical positive old source/pair/path weights yields the reported small-credit ceiling; it does not create a second available negative-square budget. Fresh terminal source z avoids both old ancestors, so directly replacing the old overlap source variable by z gives zero on that pair. Other old-prefix receivers require the genuinely correlated Gamma(y,z,r)-weighted A_yz(r)^2/J, not the original product-source square. A_yz(r)>0 implies ||y-z||_infty<=r, but no needed quantitative visibility or measure comparison is proved. These observations do not rule out all bridges or affect the new positive face receipt. The bridge note is not an extra ledger residual or payment.

## 7. Code/result evidence and exact scope: PASS

Read the entire numeric implementation and frozen notes/result. Integer common-denominator binomial-complement recurrence checks its exact divisions; it does not subtract near-one floating probabilities. Log range reduction and positive atanh remainders certify the rational log floors and ceil(8L_n), and all tested N=sqrt(n) values are exact square dimensions. C_m upper endpoints are compared to lower endpoints of both -4 and optional -8 bounds. The numeric t is a certified rational below log(n)/n, and no native source/history path is asserted.

The finite terminal atoms have nonempty face sets, count complete mass once in L and overlaps correctly in L_i, and are explicitly split into N generation-tagged copies. Their per-generation high-count source mass is checked <=B<=a LOWER C_m endpoint, rather than assumed from a different receiver model. This is an imposed finite capacity interface, not physical realization. The selected coordinate-guard tests use rational L_n proxies (and non-strict test boundaries where stated), not a claimed original logarithmic source law. All three models pay 5/17 and retain 12/17; that large complement is not declared paid. The exact original-to-new 4/3 inequality is tested without transferring old normalization for free.

The parent reports fresh numeric PASS 618=73 small-geometry+449 capacity/recurrence+96 finite-terminal checks, and proof-script PASS 2808 exact inclusion-exclusion identities plus 404 merged-source cases. Five ordinary-float parameter diagnostics are explicitly NOT certificates or original difficult-field realizations. I checked all three numeric final hashes match the supplied freeze, result metadata and generation-capacity fields agree with the notes, and geometry_checks.py is byte-identical to the proof's unique embedded block. I did not repeat those full pipelines. The bridge's 180 checks are an author algebra report, not another parent rerun claimed here.

My preliminary local process executed 39 Fraction binomial/combined-source/normalization cases, separate from parent totals and from native-field certification. No new external theorem, solver output or unrun tool is used as proof evidence.

## Final conclusion

PASS for the all-combination actual high-face capacity, adopted -4 tail estimate, combined terminal-source/tuple root payment, corrected 4/3 remainder threshold, old-square bridge scope, code/results and unchanged-X complete ledger. The low-face direction-dispersed cross-path traffic and all other global/historical unpaid slots remain unbounded at the target scale. The arbitrary-input root-order weak-type theorem is not complete.

## Frozen SHA256 bindings

Adopted current files and necessary inherited interfaces; old bindings do not mean the full historical reduction was re-audited.

```
2fae9cf7838f8dd264404fdf01a9eed6a59cd00c23ef2aae9bec0fd9731821e0  /tmp/r357_main.md
2ed62fbf2d32e3d4293281f1d9ed4417aab78653f6e094b6e806a4a10f8c89aa  /tmp/r357_ledger.md
82a0484ca4d504686b4e651ea258fe118ade0918b762540ac7f764c780181c3c  /tmp/r357_readme.md
5d954e2b627ba7504e78df7bdc1ce69f94dd0c63c7fb2de5e52c2e303db3f66c  /tmp/r357_geometry.md
197eece89f06ebadf2fc85c1337dd98ad407d9f494358c9b30d3cf166d4dd592  /tmp/r357_bridge.md
46798eb08971b1e75e7a03deb9d04dcf0bf044cea029e08ddc351c0210ecbdca  /tmp/r357_numeric.py
3591869f9b05a0263344cbe032e4186beb52b113f5e497c584e5a1227d5002d8  /tmp/r357_numeric_result.json
2aafa30130f073f1ca944b05154aff15f1bade270801cd34535b89787a75adb2  /tmp/r357_numeric.md
2980a0b182bdd7dcf2a48aa401e5a8debc5c3222412bed099c63a092193d6280  /tmp/r357_geometry_checks.py
fdd9f88782dad7028ebe8004e3e75148f3e72770a502eb185dc216124bef3394  /tmp/r356_geometry.md
7fd942f032fc24995d15cc05e5f0d395326e5239e3f7c13c5704d8f9b1d845dd  /tmp/r356_ledger.md
b4ac9d68f9ea0d8665e374e497f94dae720325433303b98d5ec917abea8a97e4  /tmp/r356_audit.md
42febb6f3d8a479db4799f30a9be06cb3d87e2a8011a752321d8f2f7deb0ae64  /tmp/r355_geometry.md
3ffe96d2acab960535e236abf7fcf2a0ee0d351d7755d49501a3175dd69cfdcc  /tmp/r352_core.md
eef2a5ba2e20828387aab0ac8a8d3b58a55196229a44ae63f8870804b5b74b20  /tmp/r350_geometry.md
```
