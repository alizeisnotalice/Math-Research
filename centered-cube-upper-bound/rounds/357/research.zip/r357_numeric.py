#!/usr/bin/env python3
"""Exact high-face binomial capacities and separate joint terminal-atom accounting."""
from fractions import Fraction as F
from math import comb,isqrt
from itertools import product
from collections import Counter
from pathlib import Path
import json,hashlib
BASE=Path(__file__).resolve().parent;C=Counter();CAPS={}
def ck(k,v):
 C[k]+=1
 assert v,k
def logbounds(x,N=80):
 x=F(x);k=0
 while x>=2:x/=2;k+=1
 def local(z):
  w=(z-1)/(z+1);a=2*sum((w**(2*j+1)/F(2*j+1) for j in range(N)),F(0));return a,a+2*w**(2*N+1)/(F(2*N+1)*(1-w*w))
 l2,u2=local(F(2));lo,hi=local(x);return k*l2+lo,k*u2+hi
def brief(x):
 x=F(x);h=hashlib.sha256()
 for a in [x.numerator,x.denominator]:
  raw=a.to_bytes(max(1,(a.bit_length()+7)//8),'big');h.update(len(raw).to_bytes(8,'big'));h.update(raw)
 z=dict(display=float(x),fraction_sha256=h.hexdigest(),numerator_bits=x.numerator.bit_length(),denominator_bits=x.denominator.bit_length())
 if x.numerator.bit_length()+x.denominator.bit_length()<1000:z['exact']=str(x)
 return z
def tail(n,t,m):
 if m<=0:return F(1)
 if m>n:return F(0)
 if not t:return F(0)
 if t==1:return F(1)
 A=t.numerator;B=t.denominator;Q=B-A;term=Q**n;small=term
 for k in range(m-1):
  numerator=term*(n-k)*A;den=(k+1)*Q
  ck('exact_binomial_recurrence_division',numerator%den==0);term=numerator//den;small+=term
 return F(B**n-small,B**n)
def geometry_small():
 before=sum(C.values());rows=[]
 for n in [1,2,3]:
  for t in [F(0),F(1,4),F(1,2)]:
   for m in sorted(set([1,2,n,n+1])):
    low=tail(n,t,m);rad=tail(n-1,t,m-1)
    # Genuine cube coordinate strip volumes: each face indicator has length fraction t.
    direct=sum((t**sum(bits)*(1-t)**(n-sum(bits)) for bits in product([0,1],repeat=n) if sum(bits)>=m),F(0))
    ck('low_cube_all_coordinate_subsets_volume',direct==low)
    forced=sum((t**sum(bits)*(1-t)**(n-1-sum(bits)) for bits in product([0,1],repeat=n-1) if 1+sum(bits)>=m),F(0))
    ck('radial_forced_one_plus_all_other_faces',forced==rad)
    if t==0:ck('strict_sigma_one_face_empty',low==0)
    rows.append(dict(n=n,t=str(t),m=m,low=str(low),radial_closed_limit=str(rad),strict_sigma_one_radial='0' if not t else str(rad)))
 return dict(exact_checks=sum(C.values())-before,rows=rows,scope='Exact low-cube independent coordinate strip volumes and radial maximum-coordinate partition. At sigma=1 strict faces are empty; forced-one expression is only closed/left-limit upper bound.')
def capacity(stage,n):
 before=sum(C.values());lnlo,lnhi=logbounds(n);scale=10**6;floorlo=(lnlo*scale).numerator//(lnlo*scale).denominator;floorhi=(lnhi*scale).numerator//(lnhi*scale).denominator
 ck('log_n_floor_certified',floorlo==floorhi);t=F(floorlo,scale*n);ck('rational_thickness_below_log_n_over_n',t<=lnlo/n and 0<=t<1)
 l,u=logbounds(n+2);cl=(8*l).numerator//(8*l).denominator;cu=(8*u).numerator//(8*u).denominator;ck('ceil_8log_nplus2_certified',cl==cu and F(cl)<8*l<=8*u<F(cl+1));m=cl+2
 P=tail(n,t,m);Q=tail(n-1,t,m-1);l2,u2=logbounds(2);Clo=P+n*l2*Q;Chi=P+n*u2*Q;Anlo=1+n*l2
 ck('high_face_capacity_at_most_one',Chi<=1)
 ck('high_face_stronger_entropy_tail',Chi<=Anlo/F(n+2)**8)
 ck('high_face_main_power4_tail',Chi<=Anlo/F(n+2)**4)
 N=isqrt(n);ck('squared_dimension_N_bound',N*N==n)
 CAPS[n]=(Clo,m,N)
 return dict(stage=stage,n=n,t=str(t),sigma=str(1-t),m=m,N=N,low_binomial_tail=brief(P),radial_binomial_tail=brief(Q),C_m_lower=brief(Clo),C_m_upper=brief(Chi),N_C_m_upper=brief(N*Chi),An_over_nplus2_power8_lower=brief(Anlo/F(n+2)**8),exact_checks=sum(C.values())-before)
def atoms(stage,N,d,m,Clo):
 before=sum(C.values());theta=F(1,4);W=F(3);data=[];original=paid=Htotal=F(0)
 B=F(1);power=0
 while B>Clo:B/=2;power+=1
 ck('finite_per_generation_high_capacity_scale_certified',0<B<=Clo)
 scale=N*B
 # Source 0: rich equality; source1: below rich, high atoms removed; source2: no high atoms.
 specifications=[[(F(1),list(range(m)))]+[(F(3,d),[i]) for i in range(d)],[(F(1),list(range(m)))]+[(F(7,d),[i]) for i in range(d)],[(F(5,d),[i]) for i in range(d)]]
 for z,items in enumerate(specifications):
  ck('every_terminal_atom_has_a_face',all(mass>0 and len(faces)>0 and len(set(faces))==len(faces) for mass,faces in items))
  items=[(a*scale,f) for a,f in items]
  L=sum(a for a,f in items);H=sum(a for a,f in items if len(f)>=m);rich=H>=theta*L;stop=L if rich else H;new=[] if rich else [(a,f) for a,f in items if len(f)<m];Lnew=sum(a for a,f in new);original+=L;paid+=stop;Htotal+=H
  ck('merged_source_first_then_high_atom_stop',stop==(L if H>=theta*L else H))
  ck('combined_high_face_payment_four_H',stop<=4*H)
  generation_high=[sum((a/F(N) for a,f in items if len(f)>=m),F(0)) for j in range(N)]
  ck('explicit_generation_tagged_high_atom_capacity',sum(generation_high)==H and all(v<=B<=Clo for v in generation_high))
  ck('terminal_mass_paid_remainder_conserve',stop+Lnew==L)
  ck('remaining_each_atom_has_fewer_than_m_faces',all(len(f)<m for a,f in new))
  Li=[sum(a for a,f in items if i in f) for i in range(d)];Linew=[sum(a for a,f in new if i in f) for i in range(d)];Ln=F(2)
  ck('source_original_max_coordinate_guard',max(Li)<=L/Ln)
  ck('source_new_max_coordinate_guard_four_thirds',max(Linew)<=F(4,3)*Lnew/Ln)
  # Add a second covered family below with equality in the original guard.
  data.append(dict(source=z,L=str(L),H=str(H),rich=rich,paid=str(stop),remaining=str(Lnew),old_max_Li=str(max(Li)),new_max_Li=str(max(Linew)),Ln_proxy=str(Ln),high_mass_by_generation=list(map(str,generation_high)),new_max_budget=str(F(4,3)*Lnew/Ln)))
 ck('combined_integrated_four_H',paid<=4*Htotal)
 ck('per_generation_high_mass_under_Cm',Htotal/N<=W*B<=W*Clo)
 ck('combined_N_Cm_dependency_budget',paid<=4*N*Clo*W)
 # A covered low-face terminal family with original max Li <= L/Ln and removal fraction <=1/4.
 items=[(scale,list(range(m)))]+[(scale,[i]) for i in range(d)];L=sum(a for a,f in items);H=scale;Ln=F(d+1,2);new=[(a,f) for a,f in items if len(f)<m];Lnew=sum(a for a,f in new);Li=[sum(a for a,f in items if i in f) for i in range(d)];Linew=[sum(a for a,f in new if i in f) for i in range(d)]
 ck('original_max_coordinate_guard',max(Li)<=L/Ln)
 ck('nonrich_removes_less_than_quarter',H<theta*L)
 ck('remaining_mass_at_least_three_quarters',Lnew>F(3,4)*L)
 ck('new_max_coordinate_guard_four_thirds',max(Linew)<=F(4,3)*Lnew/Ln)
 return dict(stage=stage,N=N,d=d,m=m,per_generation_high_mass_scale=str(B),dyadic_exponent=power,budget_4N_CmW_lower_reference=brief(4*N*Clo*W),source_cases=data,original_cost=str(original),merged_paid=str(paid),remaining=str(original-paid),paid_fraction=str(paid/original),integrated_H=str(Htotal),budget_four_H=str(4*Htotal),low_face_guard=dict(L=str(L),H=str(H),Lnew=str(Lnew),Ln=str(Ln),old_max=str(max(Li)),new_max=str(max(Linew)),new_budget=str(F(4,3)*Lnew/Ln)),exact_checks=sum(C.values())-before,scope='Separate finite joint terminal atoms; full atoms are face-covered, rich-source stop precedes high-face atom stop. N/d are diagnostic, not native paths. No actual receiver marginal or C_m realization asserted.')
def main():
 small=geometry_small();rows=[capacity(st,n) for st,ns in [('initial',[1,4,16]),('stress',[64,256]),('expanded',[1024,4096])] for n in ns];joint=[atoms(st,CAPS[n][2],n,CAPS[n][1],CAPS[n][0]) for st,n in [('initial',64),('stress',256),('expanded',1024)]]
 out=dict(status='PASS',total_exact_checks=sum(C.values()),check_counts=dict(C),small_geometry=small,capacities=rows,joint_terminal_atoms=joint,scope='Exact finite geometric/binomial capacity calculations and separately finite joint terminal algebra. All choose factors retained. No native path/core model or general root proof.')
 (BASE/'r357_numeric_result.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(status='PASS',total_exact_checks=sum(C.values()),small_checks=small['exact_checks'],capacities=[dict(n=r['n'],m=r['m'],C_upper=r['C_m_upper']['display'],checks=r['exact_checks']) for r in rows],joint_checks=[r['exact_checks'] for r in joint]),sort_keys=True))
if __name__=='__main__':main()
