# R357 — Exact scope of an old-square / terminal-source bridge

**Outcome.** No new payment is claimed. This bounded attempt checks one route: couple the terminal source back to the original old-receiver overlap square. It proves a small-credit ceiling on the same old mass-separated pair, and identifies the exact four-point integral required if one instead uses other old-prefix receivers. Neither fact rules out a new geometric bridge. In particular, they do not apply to a new positive terminal-face-capacity estimate, which spends no old square credit.

## 1. The same old pair has only exponentially small overlap credit

Restore the original small receiver v before integrating it into Omega. The actual remaining paths retain

    c_u(y)c_v(y)=1,   m_u>K m_v,
    K=exp(sqrt(n)).

Let I_uv=integral f(x)c_u(x)c_v(x)dx. Then 0<=I_uv<=m_v and

    m_u+m_v-2I_uv=(m_u-m_v)+2(m_v-I_uv),
    2I_uv <= [2/(K-1)](m_u-m_v).                  (1)

This is a pointwise comparison of TRUE matched masses and source overlap; no boundary-volume argument is used.

For a precise integral version, let dLambda(y,u,v,r) contain the original nonnegative density

    g(y)c_u(y)c_v(y) / J_y(r)

against dy dmu(u)dmu(v) ell(dr), together with every original high-past, outside, H, eta, chi, strict-gap and other retained gate. Let K_path denote the actual subprobability kernel that appends w_0, all subsequent history, and a direction-diffuse normal terminal pair (z,w). It includes the fixed core and crossing restrictions. Thus, with p_disp=K_path(total),

    F_disp=integral (m_u-m_v)p_disp dLambda.

Even BEFORE asking whether an old credit has already been spent, the largest old-overlap expression with these same receiver/old-source/path weights obeys

    integral 2I_uv p_disp dLambda
       <= [2/(K-1)]F_disp.                        (2)

The original negative square has already entered the existing ledger, so (2) creates no available second credit. It also shows that a fixed positive fractional absorption of this far-mass traffic cannot be obtained merely by retaining more of the overlap credit on its SAME old pair. This statement is limited to that specified route and those weights.

## 2. Direct substitution of the terminal source gives zero

Every path in the actual fresh terminal block has

    z outside Q_u union Q_v,

because both old cubes remain in its ancestral exclusion set. Therefore the genuine four-point capture on that old pair is identically zero:

    c_u(y)c_v(y)c_u(z)c_v(z)=0.                   (3)

The source x integrated in I_uv is an independent integration variable under the original full-f source measure. It cannot be replaced by the terminal source z while retaining that overlap integral: z has a conditional path law and, by (3), is outside both old ancestors.

Direction dispersion is a property of the final source column. It supplies no change to (3), and it was not assigned to the old source y or to individual paths.

## 3. The exact joint four-point quantity needed for a different bridge

Let dT denote the COMPLETE actual direction-diffuse terminal measure on

    (y,u,v,r,w_0,history,z,w).

Let Gamma be its (y,z,r) marginal. The marginal uses the old physical r carried by the path; no later endpoint is assigned that clock. Define with the original prefix

    A_yz(r)=integral_{E_r}c_p(y)c_p(z)dmu(p),
    J_y(r)=integral_{E_r}c_p(y)dmu(p).

A bridge through OTHER old-prefix receivers p,q would have to control the genuinely joint four-point expression

    K_joint = integral Gamma(dy,dz,dr) [1/J_y(r)]
        integral_{E_r x E_r}
          c_p(y)c_q(y)c_p(z)c_q(z)dmu(p)dmu(q)
      = integral Gamma(dy,dz,dr) A_yz(r)^2/J_y(r). (4)

The original square, by contrast, uses the product source/clock measure:

    K_old = integral ell(dr) integral f(y)f(z)
          1_{J_y(r)>=H} A_yz(r)^2/J_y(r) dy dz.   (5)

These are different measures. The old rank sourcewise column controls the initial (y,w_0) law; each true-posterior generation bound controls a current receiver marginal. Neither supplies a proved comparison between Gamma in (4) and the product measure in (5), nor a lower bound on the mass of Gamma for which A_yz(r)>0.

There is also an exact support restriction: A_yz(r)>0 implies

    ||y-z||_infinity<=r.                          (6)

It follows because some ACTUAL receiver of side at most r captures both points. The current fresh/dispersion/crossing hypotheses do not establish (6) for terminal pairs. Thus (4) can only see old-time-visible terminal pairs, and a useful bridge would need both a quantitative control of their actual correlated law and a separate payment or comparison for the other pairs.

This note does not introduce K_joint as a new ledger residual or claim its size is a budget. It displays the exact integral that would have to be compared in this proposed route. Any use of (5) would additionally require a recomposed, nonduplicating ledger demonstrating which old square credit remains available; none is presumed here.

## 4. Executed check

Python fractions.Fraction actually verified 180 old-pair instances of (1), with terminal subprobability weights 0, 1/3 and 1. Output:

    PASS: 180 exact old-credit ceiling identities
          with terminal subprobability weights

This is an algebra diagnostic, not a full cube/path example. Equations (1)-(6) are the analytic statements for the actual frozen process.

Only /tmp/r357_bridge.md was authored. No new X_q or W fee is added. The general direction-diffuse terminal bound remains open by this route; other positive geometric estimates are unaffected.
