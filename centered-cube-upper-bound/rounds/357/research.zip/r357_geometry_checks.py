from fractions import Fraction as F
from math import comb, log, log1p, lgamma, exp, expm1, ceil, sqrt

def tail(n,t,k):
 if k<=0: return F(1)
 if k>n: return F(0)
 return sum(F(comb(n,j))*t**j*(1-t)**(n-j) for j in range(k,n+1))
checks=0
for n in range(1,13):
 for den in range(2,10):
  for num in range(1,den):
   t=F(num,den)
   for m in range(1,n+1):
    low=high=F(0)
    for k in range(m,n+1):
     coeff=(-1)**(k-m)*comb(k-1,m-1)*comb(n,k)
     low+=coeff*t**k
     high+=coeff*(F(k,n)*t**(k-1)+F(n-k,n)*t**k)
    assert low==tail(n,t,m)
    assert high==tail(n-1,t,m-1)
    checks+=1
merge_checks=0
for L in [F(0),F(1),F(3,2),F(5)]:
 for j in range(101):
  H=L*F(j,100)
  whole=L>0 and H>=L/4
  paid=L if whole else H
  remain=F(0) if whole else L-H
  assert paid<=4*H and paid+remain==L
  if remain>0: assert remain>3*L/4
  merge_checks+=1

def float_tail(n,t,k):
 if k>n: return 0.0
 if k<=0: return 1.0
 p=exp(lgamma(n+1)-lgamma(k+1)-lgamma(n-k+1)
       +k*log(t)+(n-k)*log1p(-t))
 total=p
 for j in range(k,n):
  p*=((n-j)/(j+1))*t/(1-t)
  total+=p
  if p==0: break
 return total
out=[]
for n in [128,512,1458,4096,16384]:
 x=sqrt(n); s=1+x; A=1+n*log(2)
 N=max(1,ceil((log(4/3)+n*log(2))/x))
 sigma_log=min(0.0,log(s/(N*A))/n); t=-expm1(sigma_log)
 m=1+ceil(8*log(n+2)); k=m-1
 Cm=float_tail(n,t,m)+n*log(2)*float_tail(n-1,t,m-1)
 assert N<=x and n*t<=log(n)
 assert Cm<=A/(n+2)**4
 out.append((n,N,m,Cm))
print('PASS',checks,'exact binomial/cone inclusion-exclusion identities;',
      merge_checks,'exact merged source splits')
print('Ordinary-float tail diagnostics (n,N,m,Cm):',out)
