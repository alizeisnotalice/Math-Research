R357 high-face capacity and combined stopping diagnostic

Frozen fresh standard-library local Python processes returned PASS 618 exact Fraction assertions: 73 small-dimensional geometric/subset checks; 449 large-parameter capacity/recurrence checks; 96 separately classified finite joint-terminal checks. Reproduce:

```
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 r357_numeric.py
```

The script is portable and self-contained. It writes r357_numeric_result.json beside itself. Large fractions are retained internally for exact comparisons; output records rational inputs, numerator/denominator bit counts and deterministic fraction SHA256, plus decimal displays. The result is about 26 KB, not a dump of the n=4096 denominators.

Geometry and all combinatorial factors. Let t=1-sigma. In the low-radius cube, independent absolute-coordinate face strips each have fraction t, so the count is Bin(n,t). In the radial maximum-coordinate partition, one maximum coordinate supplies a face and the other n-1 coordinates give Bin(n-1,t). Thus the evaluated expression is

C_m=Pr(Bin(n,t)>=m)+n log(b/a) Pr(Bin(n-1,t)>=m-1).

Small dimensions n=1,2,3 are independently integrated by enumerating ALL 2^n coordinate-strip subsets with their exact product volumes; this agrees with the binomial tail. The forced-one radial decomposition is independently enumerated too. No fixed k-face event is substituted for its union, and no choose(n,k) factor is omitted. Cases include m>n, m=1, and sigma=1. At sigma=1 the actual STRICT face is empty; the forced-one formula is only a closed/left-limit upper bound (potentially nonsharp at m=1), and the output distinguishes this. All main m values exceed n in the three small main cases, so both main tails are exactly zero there.

Certified main parameters. For n=1,4,16; 64,256; 1024,4096, set t=floor(10^6 log(n))/(10^6 n), using outward rational log intervals to certify the floor, hence t<=log(n)/n. Set m=ceil(8 log(n+2))+1, also certified by strict rational log brackets. N=sqrt(n) is an exact integer in these cases. The ratio b/a is 2. Log bounds use range reduction to [1,2] and 80 positive atanh terms plus an explicit geometric remainder. Every tail is computed as a common-denominator INTEGER complement of the first m binomial terms. Each recurrence division is checked exact; no floating-point subtraction of nearly equal probabilities is used.

| n | m | C_m upper display | N C_m upper display |
|---:|---:|---:|---:|
| 1 | 10 | 0 | 0 |
| 4 | 16 | 0 | 0 |
| 16 | 25 | 0 | 0 |
| 64 | 35 | 2.20404e-22 | 1.76323e-21 |
| 256 | 46 | 6.70552e-25 | 1.07288e-23 |
| 1024 | 57 | 3.95083e-29 | 1.26426e-27 |
| 4096 | 68 | 6.14459e-34 | 3.93254e-32 |

All finite cases certify C_m<=1 and the main bound C_m<=An/(n+2)^4 with An=1+n log 2. The already implemented stronger comparison An/(n+2)^8 also passes. Upper endpoints for C_m are compared to LOWER endpoints for the right-hand expressions, so outward log uncertainty cannot reverse the assertion. These are finite exact cases, not the proof of the universal tail estimate. The n=4096 upper fraction has about 127,115 denominator bits but is not serialized in full.

Separate joint-terminal model. Three finite source labels of mass 1 have terminal atoms with nonempty coordinate-face sets. At the first source H=L/4 exactly; whole-source rich stopping occurs first. At the second H=L/8, only its high-face atoms are removed. The third has no high-face atoms. A high atom has exactly m faces; all low atoms have one face. Each source's original and remaining coordinate columns are computed from these same atoms, with overlaps counted in the columns but terminal mass counted once.

The three models use (N,d,m)=(8,64,35),(16,256,46),(32,1024,57). Let B be a dyadic rational no larger than the certified LOWER C_m endpoint: respectively 2^-72,2^-81,2^-95. Terminal masses are scaled by N B. Each displayed atom is explicitly split into N equal-mass copies tagged by generation j=0,...,N-1; this preserves its face set and full terminal mass. Each source and generation has high-face mass at most B, checked from those tagged copies, and the source-integrated generation total is at most W B<=W C_m. This is an imposed and checked finite capacity interface, not a realization by native paths. The program verifies merged source-first/high-atom payment <=4H, then <=4N C_m W; there is no separate rich plus high-atom double charge. In every model the original terminal cost is 17NB, paid cost 5NB, retained cost 12NB: paid fraction 5/17, retained fraction 12/17. The retained part is not declared paid.

Every remaining atom has fewer than m faces. Each source also starts with the verified coordinate guard max_i Li<=L/Ln, using rational proxy Ln=2; the remaining columns obey max_i Li_new<=(4/3)L_new/Ln. A second covered atom family checks the same transition with equality in the original max-column guard and Ln=(d+1)/2. This is a conditional finite algebra check, not a proof of a native geometric Ln bound.

Scope. Genuine cube coordinate-volume/radial-partition calculations are separated from the finite joint terminal-atom models. The tests keep the full combinatorial entropy and N/C_m dependence, but do not implement original source/receiver marginals, historical high-past/core gates, native rank paths, or the general root theorem. No exponent is fitted from the table, and no finite matrix is passed off as actual receiver dx.
