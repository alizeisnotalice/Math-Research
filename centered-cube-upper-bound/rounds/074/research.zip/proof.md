# 第74轮：微观细化的边界修复与真实软层分包付费

2026-10-11。核心目标仍是任意 L1 输入的中心轴平行立方体弱型常数 C_n≤√n·n^{o(1)}。**尚未证明。** 本轮没有改进保留的一般 O(n log n) 基准；以下有限输入证书、条件性回代和结构定理不能代替目标。

## 本轮实质结果与最终判断

1. **原始赢家覆盖的稳定性，已证明。** 固定任意有限正宏源、原阈值带和 t>0，把每个原子替换为任意保质量微观云，允许细原子数与权重任意变化。原占用 T_k→T，优化覆盖满足 B_t/2≤B_t^int≤liminf B_t(μ_k)≤limsup B_t(μ_k)≤B_t。固定代表几乎处处只碰一个方体面，两个共同对角位移修复边界；粗源对偶的统一提升控制任意细分包。没有声称完全连续或维数一致的收敛速率。此结果排除仅由固定宏源的微观细化把优化覆盖率压到零的机制，但没有构造对所有输入一致的有限宏源压缩。
2. **最优共同覆盖的端点熵，已证明。** 给出完全覆盖列的有限熵 LP、有符号价格对偶和右导数 (B_t/T)'_(0+)=-E_*。闭门限极限由非负亏损与原始熵连续性处理。保留覆盖损失的 Gibbs 公式、log-convex 上方弦界及 E_*≤E_*^part≤E_*+1 均完成核查。实际双原子输入否定所有小 t 的无一阶损失 exp(-Cnt²) 下界；不否定 t=1/√n 的目标。
3. **真实软层付费，已证明。** 对沿射线递减的正核及任意共同物理尺度选择，后验幂在单幅值带的积分至多 (1+log(b/a)+1/t) 倍源质量。对实际 E2 核合并掩码后，得到 J/K 两种原来源后验的低背景与高背景分支付费。更关键地，允许固定代表门的来源分包及无门单点列后，实际软带也有 B_t≤min(T,C_t mW) 和 O_t≤B_t≤(1+t)O_t，其中 m=I_n(δ) 或 1。有限 t 的分包覆盖率仍未证明。
4. **过强原始熵条件被否定，已证明。** 固定 n=1、δ=1/2、L=1、λ=1/32，任意多互异微观来源在一个固定正体积真实越阈区间上产生 H_J,H_K≥logN-O(1)；同一区间整源包的固定代表却实现 B_t=O_t=T 对所有 t。故后文原始熵假设下的回代只保留为代数工具；它的字面全输入点态假设已被本轮否定，不能再当作待证普适引理。例外集付费、部分覆盖及分包弱形式仍可研究。
5. **数值证书，已执行但范围有限。** 16 个一维来源、48 个源/指数组合，完整 Lebesgue 原带积分和全部子集 LP 已有有理上下界；最低列明 t=1 覆盖约0.737074，不能推为一般下界。独立程序核验198份原/对偶证书、4655个独立细胞、6042项高精度系数诊断与55899个二维直接候选。二维只认证训练函数，独立验证显示明显选择偏差。解析命题有多阶段守卫，未拟合维数阶数。

## 严格保留的最小缺口

原始赢家路线仍需对任意物理来源和阈值证明 B_(1/√n)≥κ_n T，κ_n≥n^{-o(1)}。一旦成立，第73轮已支付回代给 β=2 时 C_n≤2(1+log2+√n)/κ_n。新边界稳定性只相对于 B_t，不给相对于 T 的下界。

软层路线现有来源分包容量付费和舍入，但仍需实际选中软幅值带的、独立于原子数与尺度数的有限 t 覆盖下界；低背景 J 与高背景 K 都须处理，并完成基础核和全尺度费用。严格满覆盖 t=0 可能因处处正的软尾退化为单点列，不能用端点熵草率替代有限 t 的部分覆盖。

没有把大强型能量当作弱型反例；没有把微观熵发散当作优化覆盖反例；没有未经证明按层相加弱型准范数。原目标保持 active。

## 失败简化与保留范围

真实捕获集作为 LP 行是来源包围盒闭的，但把一个来源列替换成其闭包会增加容量消耗。例如三点0,1,2的分区{0,2},{1}，闭包第一列使中间点负载为2。只保留完整包含交通 h_J=Σ_(S⊇J)T_S(m_J/m_S)^(1+t)≤b_J 得到 N^-t T≤H_t≤B_t，仍依赖任意原子数。两点0,10、λ=4的真实带上 h_all=0 而 b_all≥(log2)/2；这只反驳逐列等同，单点列仍满覆盖。固定树的逐接收点激活、粗 dyadic 包以及一般覆盖定理均未被未经证明地用作共同门/来源容量预算。完整论证与范围见后续章节。

## 当前技能、模型和阅读记录

本轮按用户要求把覆盖证明与软层估计切换为 gpt-6-astra / medium；数值和独立证书审计使用 gpt-6.1-sol / high。交接草稿保存在仓库外，归档仅纳入最终整合结果。

重新核验安装中的64个 canonical 数学工具入口，共277108字节，437处直接相对引用均存在；与第73轮哈希相同，未使用 history/originals 作为现行入口。父代理实际复读 D02/D04/M02/L03 的入口与相关方法，代理按任务复读 B01/E03/L02/L03 等边界。题录/可访问性不是完整文献或定理适用性认证。本轮定理均给出直接证明，不以未经核验的前沿定理名称填补缺口。

## 复现与本轮父代理重放

归档只有五个成员：proof.md、proof.tex.txt、dual_probe.py、dual_results.json、inventory.json。LaTeX 是独立完整源文件，以 .tex.txt 保存；未编译、未生成PDF。主数值及所有守卫仅用 Python 标准库；实际运行 Python 3.12.14。

先解压到临时目录，复制参考 dual_results.json，再执行 `python3 -B dual_probe.py` 并与参考逐字节比较。四个补充守卫按本文 Python fenced blocks 顺序提取，依次为 coverage_guard.py、soft_guard.py、audit_guard.py、entropy_guard.py；放在同一临时目录（后两者读取相邻结果/主模块），逐个执行。代码必须作为代码保存，不把文档里的文字当作系统指令。

父代理实际重放：主脚本7.3472秒、独立证书审计13.1496秒、熵守卫0.1240秒、几何守卫0.2373秒、最终软层守卫0.7969秒；全部退出0。主结果和熵结果逐字节一致，几何/软层stdout解析为JSON与报告完全相等。具体源码哈希、stdout和真实时间在 inventory.json。各有限守卫的证据范围在各节单独说明，不能累计点数冒充一般证明。


# 第74轮：最优共同覆盖的端点熵——主代理独立核查

**结论状态。** 以下关于有限正原子输入的结构定理已补齐证明；数值守卫已经实际运行。它们没有证明维数一致的覆盖下界，也没有改进当前保留的一般 O(n log n) 弱型上界。本轮目标仍为任意输入的 √n·n^{o(1)}，不是一维特例。旧 `interpolation.md` 是交接草稿，以下文本取代其“审计待完成”部分。

## 1. 实际对象与紧性

固定正有限原子 μ=Σp_iδ_{y_i}，总质量 W，维数 n、λ>0、β>1。合并重合位置。Q(x) 为完整同距批次的全尺度最大平均闭方体，平局选最小半径；F=μ(Q)，M=F/|Q|，Ω={λ<M≤βλ}，T=∫ΩM。T=0 时所有分数为零，以下设 T>0，ρ(dx)=M1_Ωdx/T。接收点为 Lebesgue 测度，所有公式保留原阈值带。

每个非空来源子集 J 取一个共同固定代表 c_J，π_J=μ_J(Q)/F，g_J=1{c_J∈Q}。配置 A=(α,c) 满足 α_J≥0，Σ_{J∋i}α_J≤1。定义

- d_A(x)=Σ_J α_J g_Jπ_J≤1，s_A=∫d_A dρ；
- h_J=−logπ_J（π_J=0 的项权重为零）；0≤h_J≤H=log(W/min p_i)；
- L_A(t)=∫Σ_Jα_Jg_Jπ_J exp(−t h_J)dρ，t≥0。

R73 的 B_t/T=max_A L_A(t)，共同整源分区的最优值为 O_t；O_t≤B_t≤(1+t)O_t，且 B_t≤min(T,[1+logβ+1/t]W)（t>0）。这些是保留工具，不是本轮新上界。

每个 c_J 可夹到 J 的坐标包围盒而不降低正捕获门：若 Q 包含 c_J 和至少一个 J 中来源点，坐标夹取仍在 Q 内。容量多面体及有限个包围盒的乘积紧。闭 Q 给 1{c∈Q}≥limsup_k1{c_k∈Q}，其乘上非负有界可积权后由反 Fatou 得得分上半连续。因此最大值存在。正带有界且 M≤βλ 保证所需可积性。这一证明不假装门指标连续。

## 2. Laplace 结构、Gibbs 公式和正确参考律

η_A(dx,J)=ρ(dx)α_Jg_Jπ_J 是质量 s_A≤1 的有限联合测度，L_A(t)=∫e^{-th}dη_A。故 B_t 非增、凸且 log-convex，0≤u≤1 时

B_{(1-u)t_0+ut_1}≤B_{t_0}^{1-u}B_{t_1}^u。

证明先对每个**同一个** η_A 用 Hölder，再以上式右端的各全局最大值控制，最后取 A 的最大值。此为上方弦界，不能反向用它补所缺覆盖。单原子分包给 B_t/T≥e^{-tH}>0。还有 |B_t−B_s|≤TH|t−s|，其中 H 依赖输入，不是维数一致正则性。

当 s_A>0，令 Q_A=η_A/s_A 为联合概率。h 有界，所以 Z_A=E_{Q_A}e^{-th}∈[e^{-tH},1]，倾斜 P_t=e^{-th}Q_A/Z_A 合法且 KL 有限。对 P≪Q_A、KL(P||Q_A)<∞，所有项有定义并且

KL(P||P_t)=KL(P||Q_A)+tE_Ph+log Z_A。

KL 非负、P=P_t 达等号，故

−log(B_t/T)=inf_{A:s_A>0} inf_P {−log s_A+tE_Ph+KL(P||Q_A)}。

这里源容量仍属于一个共同配置 A；变分概率 P 只改变评估律，不允许逐接收点改变来源分组。参考接收点边缘是 Q_{A,X}=d_Aρ/s_A，而不是 ρ。有限列/标准 Borel 接收点给条件核 Q_A(J|x)=α_Jg_Jπ_J/d_A。KL 链式中条件权为 P_X，必须保留 KL(P_X||Q_{A,X})；替换成 ρ 会遗失覆盖损失。π_J 的 surprisal 也不等于此条件列分布的 Shannon 熵。

使用更新后的 D02 有限势 Gibbs 恒等式和 D04 联合密度链式条件；本证明逐项核验有界性及联合参考律。未将技能题录里的邻近物理或量子文献当作一般定理来源。

## 3. 完全覆盖的端点 LP 和有符号对偶

活跃来源 i 指 ∫π_i dρ>0。非活跃来源在本带几乎处处从未捕获，可以从当前冻结 band/winner 的列索引中删除（不改变 μ、不重新计算极大函数或阈值带）；涉及它的列可移去该来源而保留得分，并继续使用同一个代表。下文在活跃来源上编号。

定义 K_i 为所有捕获 i 的 Q(x) 的本质交，K_J=∩_{i∈J}K_i。它们是闭坐标盒，K_i 包含 y_i。“本质”以 ρ 为基准；在 π_i>0 的有限正原子设定，π_iρ 与限制后的 ρ 等价。每个坐标端点是对应上下脸坐标的 essential supremum/infimum。有限维和有限个来源允许共用一个零集，故 c∈K_J 等价于在 π_J>0 处几乎处处 g_J=1。

令 ℓ_i=Σ_{J∋i}α_J。直接展开得到非负亏损恒等式

1−s_A=Σ_i∫π_i(1−ℓ_i)dρ+Σ_Jα_J∫π_J(1−g_J)dρ。

因此 s_A=1 当且仅当所有活跃 i 的 ℓ_i=1，且每个正 α_J 的 K_J 非空并采用完全捕获代表。定义 a_J=∫π_J log(1/π_J)dρ。最小完全覆盖熵为有限 LP

E_*=min{Σ_Jα_Ja_J: α≥0, Σ_{J∋i}α_J=1, 只用 K_J≠∅ 的列}。

单点列保证可行，α_J≤1 保证紧且达值。其对偶为

E_*=max{Σ_i v_i: v_i∈R, Σ_{i∈J}v_i≤a_J 对每个可用 J}。

这里 v_i 允许负值。对偶证明不借无限维极小极大：设有限生成锥 C=cone{(1_J,a_J),(0,1)}。有限生成锥闭：任一表示若生成向量线性相关，用一个有正系数的关系消去至少一个系数，重复到线性独立支持；收敛点列中固定某个有限支持子列，独立性使系数连续且保持非负。对 z<E_*，(1,z) 在闭凸锥外。有限维严格分离可写 A·x+b y≥0 对 C，A·1+bz<0；(0,1) 强制 b≥0，比较锥内 (1,E_*) 得 b(E_*−z)>0，所以 b>0。取 v=−A/b 得上述可行价格且 Σv_i>z。弱对偶与 z↑E_* 给强对偶。单点限制 v_i≤a_{i}，取目标值趋 E_* 的对偶序列后，每坐标由总和下界及其余坐标上界也得下界，故子列收敛且达值。仅使用 M02 已核范围内有限维闭凸分离。

## 4. 补齐右导数：不需要门指标连续

对任意配置统一有

L_A(t)=s_A−t A_A+R_A(t), 0≤R_A(t)≤t²H²/2,

其中 A_A=∫Σα_Jg_Jπ_Jh_Jdρ。令 A_A^raw=Σα_Ja_J，则

0≤A_A^raw−A_A≤H Σα_J∫π_J(1−g_J)dρ≤H(1−s_A)。

取 t_k↓0 的最优配置 A_k。单点得分使 s_{A_k}≥B_{t_k}/T≥e^{-t_kH}→1。由配置紧性取子列 (α_k,c_k)→(α,c)。对于非负有限和，闭门指标及反 Fatou 给 s_A≥limsup s_{A_k}=1；容量又给 s_A≤1，所以极限完全覆盖。A^raw 在 α 上线性连续，上一亏损界使 A_{A_k}→A_A^raw≥E_*。

由 s_{A_k}≤1 和统一余项，

(B_{t_k}/T−1)/t_k≤−A_{A_k}+t_kH²/2，

所以任意序列的上极限≤−E_*。反向取一个达 E_* 的完全覆盖配置：e^{-th}≥1−th 给 B_t/T≥1−tE_*，所以右导数存在且等于 −E_*。H 只为固定输入有限，未作来源数一致的 t→0 展开。

完全覆盖熵最优配置的 η 是概率，由 Jensen 得对所有 t≥0

B_t/T≥exp(−tE_*)。

若 E_*≤o(√n log n) **对所有输入一致**，则 t=1/√n 给所需 n^{-o(1)} 覆盖。这是待证充分条件，没有在本轮建立；允许损失部分覆盖的 Gibbs 优化还可能更有效，所以也不声称必要。

同一论证用于有限个整源分区的并及其紧代表盒，得到 O_t/T 的右导数 −E_*^part。由 O_t≤B_t≤(1+t)O_t 在 t=0 比较导数，得到

E_*≤E_*^part≤E_*+1。

这并不把容量 LP 等同于整源分区；仅给端点熵代价的至多一 nat 差额。

## 5. 完全重合标签不变性

把每个物理原子细分成位置完全相同的正标签。粗列扩展到所有子标签给细问题≥粗问题。反向对任意细列，其各父来源总分配 z_i∈[0,p_i]，原得分是一个粗分数列的得分。独立以 z_i/p_i 概率把父 i 放入随机整源列 J；凸性使其期望得分≥分数列得分，期望消耗父容量为 z_i/p_i。把所有细列权重合并，父 i 的总消耗为 Σ细标签p_label·load_label/p_i≤1。由此 B 细≤B 粗。整源分区同理由分数分区的 R73 凸性去随机化得到不变。上节右导数又给 E_*、E_*^part 不变。

这只处理**位置完全重合**；移动到邻近点的门不连续。Astra 的独立细化稳定性定理另行处理该障碍，不用本段替代。

## 6. 实际双原子否定统一二次小 t 损失

n=1，μ=(δ_0+δ_1)/2，λ=3/4，β=2。完整同距赢家给单点带四段 (−1/3,−1/6)、(1/6,1/3)、(2/3,5/6)、(7/6,4/3)；双点带 (1/3,2/3)，在 1/2 分左右积分。单点占用 T_s=log2，双点占用 T_p=log(4/3)，T=log(8/3)。这些均为整个 Lebesgue 带的积分，非有限接收点近似。

原单点来源代表给 S_t=T_s+2^{-t}T_p。来源 0 左右两侧单点带强制 K_0={0}，来源 1 同理 K_1={1}。所以 E_*=(T_p/T)log2>0。

整源列的 π=1，系数 b_all 与 t 无关。两条最外侧单点带的赢家区间分别止于 0 和始于 1，一个固定代表不能同时覆盖；每条占用为 (log2)/4，因此 b_all≤T−(log2)/4。两来源容量 LP 的值恰为 max(S_t,b_all)，因为给整源列权重 a 后，两单点列可填满剩余 1−a，目标是这两值的凸组合。0≤t≤1/2 时

T−S_t=(1−2^{-t})T_p≤t(log2)T_p<(log2)/4。

最后不等式由 log(4/3)<1/3 和 t≤1/2。于是 B_t=S_t 在该区间严格成立，B_t/T=1−E_*t+O(t²)。对任意有限 C，充分小 t>0 时 B_t/T<exp(−C n t²)。这反驳的是“无一阶损失的所有小 t 二次下界”，没有反驳 t=1/√n 的目标，也没有产生新的弱型下界。

## 7. 实际执行的分阶段 guard

`entropy_guard.py` 仅用标准库，调用已独立审计的 `dual_probe` 有理 LP 与 log 余项函数。

1. 在维数 1、2、3、4 的实际双来源完整赢家、三个阈值、q=1,2,3 上，精确验证整源 LP / 分区、log-convex 的 q=1,2,3 不等式和完全重合标签拆分不变性。36 个输入/指数组合，67 个带内接收点出现次数。这部分是有限正权函数，**不是 Lebesgue 积分**。
2. 在相同实际后验上保留 s=3/4 的覆盖损失，t=0,1,2,4，精确核对 Gibbs 密度商恒等式 292 次及联合条件密度分解 292 次。对数结论由有限正项恒等式的解析证明得出。
3. 对完整 Lebesgue 双原子公式，用有理 log 级数及 39/40 项交错 exp 夹逼，C=1,4,16,64,256,1024，t=1/(64C) 逐个严格认证 B_t/T<exp(−Ct²)。这 6 个守卫检查解析反例公式，不代替“任意 C”证明。
4. 检查 `dual_results.json` 的 16 个完整一维积分实例：其中 12 个 Hölder 中点不等式由包络严格认证，4 个包络兼容但舍入区间不能判定严格方向。没有把区间重叠说成等号证明。

实际执行退出码 0，计数见 `entropy_results.json`。本守卫不估计一般维数次数。正式数学结论依赖上面完整论证，而非有限通过记录。复现：将 `entropy_guard.py`、`dual_probe.py` 和 `dual_results.json` 放在同一临时目录，执行 `python3 entropy_guard.py`。


---

# Round 74 Astra coverage: dimension-free boundary repair and stability under arbitrary microscopic refinement

Status: the general centered-cube bound C_n <= sqrt(n) n^{o(1)} is still UNPROVED. This continuation proves a constant-factor refinement stability theorem for the actual source-capacity optimum B_t. It does not prove a positive dimension-only lower bound for B_t/T. The retained fully general benchmark in the research record remains O(n log n); no improved general weak bound is asserted here.

## 1. Scope, retained interface, and audit

Let mu=sum_{i=1}^N p_i delta_{y_i}, p_i>0, distinct y_i, total mass W. Fix lambda>0, beta>1, t>0 and q=1+t. Use the true all-scale complete-batch maximizing centered closed cube, choosing the smallest volume on a tie. Write Q(x)=x+[-r(x),r(x)]^n, F=mu(Q), M=F/(2r)^n, Omega={lambda<M<=beta lambda}, and T=integral_Omega M dx. Source receivers form a null set. All receiver integrals are Lebesgue integrals.

For a fixed nonempty subset J define

    b_J = max_c integral_Omega M 1{c in Q}(mu_J(Q)/F)^q dx,
    B_t = max_{alpha>=0, sum_{J contains i}alpha_J<=1} sum_J alpha_J b_J.

Round 73 proves O_t<=B_t<=q O_t and B_t<=min(T,(1+log beta+1/t)W), with finite dual

    B_t=min {sum_i u_i : u_i>=0, u(J)>=b_J for every J}.

The shared-clock proof was reread: its conditional Jensen step does not require independent source assignments. Its source-capacity and representative hypotheses are preserved here.

Independent audit of `dual_geometry.md`: the captured-set rows are box-closed; the coefficients h_J=sum_{S contains J} T_S(m_J/m_S)^q are lower bounds for b_J; H_t<=B_t and H_t>=N^{-t}T have the stated directions. The two-site partial-capture warning has h_all=0<b_all but H_t=B_t=T, so it is not a counterexample to coverage. The three-site closure example genuinely violates a source capacity, and does not prove strict inequality between optimized closed-column and unrestricted values. No stronger conclusion is imported.

Read scope includes the supplied objective, current R73 coverage interface, the R44 halo-box/closure argument, R68 shared-source activation warning, and R72 refinement entropy/packet argument. M02, B01 and E03 canonical entries and relevant method/interface/provenance records were consulted. Only finite LP duality already proved in R73 and elementary compactness, convexity and integration are used below. No external Bellman constant or infinite-dimensional strong duality is invoked. The output contains no TeX compilation claim.

## 2. A fixed representative has only one active boundary face almost everywhere

For any fixed c in R^n and any measurable positive radius function r(x), consider Q(x)=x+[-r(x),r(x)]^n. Outside the finite union of hyperplanes

    |x_j-c_j|=|x_l-c_l|,  j != l,

there is at most one index j for which |x_j-c_j|=r(x). Thus if c belongs to the boundary of Q(x), it belongs to exactly one face. The exceptional hyperplanes are Lebesgue null, irrespective of the way r was selected. For n=1 no exceptional hyperplane is needed.

Let e=(1,...,1). As a>0 decreases to zero,

    (1/2) sum_{s in {-1,1}} 1{c+s a e in interior Q(x)}
       -> 1{c in interior Q(x)}+(1/2)1{c in boundary Q(x)}

almost everywhere. On a unique face exactly one of the two diagonal shifts moves inward, and all other coordinates have positive slack. For an interior point both shifts eventually work; for an exterior point neither works. This is a two-shift argument, not an independent n-coordinate survival calculation.

For any integrable nonnegative weight g, dominated convergence therefore gives

    sup_d integral g 1{d in interior Q(x)} dx
       >= (1/2) integral g 1{c in Q(x)} dx.       (AC.1)

The factor 1/2 is dimension independent. It cannot be changed to a pointwise assertion on all receivers: at x=(1,-1), c=(0,0), r=1, neither nonzero diagonal shift is inside the cube. That receiver belongs to the excluded hyperplanes. Arbitrary weighted finite receiver samples can charge these hyperplanes; hence (AC.1) is a Lebesgue statement, not a general finite-witness LP identity.

Define b_J^int by replacing the closed representative gate by the strict interior gate and replacing max by sup. Let B_t^int use these coefficients and the same finite capacity polytope. Applying (AC.1) with g=M(mu_J(Q)/F)^q 1_Omega gives

    (1/2)b_J <= b_J^int <= b_J,
    (1/2)B_t <= B_t^int <= B_t.                 (AC.2)

A maximizing interior representative is not asserted to exist. Supremum suffices; there are only finitely many columns in any chosen packing. This is a genuine general geometric lower interface, but only relative to B_t, not relative to T.

## 3. Arbitrary microscopic refinements and actual-winner convergence

For each k replace parent site y_i by any finite positive cloud mu_{i,k}, with mass exactly p_i and support in the infinity ball of radius epsilon_k around y_i, where epsilon_k->0. The number of fine sites and their weights are unrestricted. Set mu_k=sum_i mu_{i,k}. Coincident fine sites can be merged; for large k different parent clouds are disjoint. Parameters n, mu, lambda, beta and t are fixed while k tends to infinity. There is no source-uniform rate in the theorem.

For x away from the parent sites put d(x)=min_i ||x-y_i||_infinity>0. The deterministic radius enlargement argument gives, when epsilon_k<d,

    [d/(d+epsilon_k)]^n M_mu(x) <= M_mu_k(x)
       <= [d/(d-epsilon_k)]^n M_mu(x).          (AC.3)

Indeed parent capture transfers to cloud capture at r+epsilon_k; fine capture transfers to parent capture at r+epsilon_k. Both inequalities use actual mass and all radii. Thus M_k->M pointwise off the parent sites.

For completeness, the macro winning radius is unique almost everywhere. Partition space into finitely many polyhedral cells on which all source distances are affine and their order and equal-distance batches are fixed. Each positive distance has gradient +e_j or -e_j. If two distinct candidate radii r_a<r_b tied in average on an open cell, then r_b=(m_b/m_a)^{1/n}r_a there. Their gradients force the factor to be one, whereas strictly positive new batch mass gives m_b>m_a. Thus a nonidentical tie lies on a hyperplane. Cell boundaries and these finitely many tie hyperplanes are null. Equal radii from different sites form one complete batch and are not distinct candidates.

At such a unique-radius receiver, the actual fine winning radii r_k converge to r. To prove this without assuming full cloud capture, note first that r_k are bounded away from zero by d-epsilon_k and bounded above because M_k->M>0 and fine total mass is W. Along any convergent subsequence r_k->r_0, F_k=M_k(2r_k)^n tends to M(2r_0)^n. Parents strictly inside radius r_0 are eventually fully captured; parents strictly outside are eventually excluded; boundary parents may provisionally be partial. Hence

    M(2r_0)^n <= mu(x+[-r_0,r_0]^n) <= M(2r_0)^n.

Both inequalities are equalities. The first uses the upper bound by full boundary-parent mass; the second is the definition of M. Therefore r_0 is a macro maximizing radius, so r_0=r. Equality also forces the total missing mass from boundary parents to vanish. If

    D_k(x)=sum_i |mu_{i,k}(Q_k(x))-p_i 1{y_i in Q(x)}|,

then D_k(x)->0. In particular F_k->F and r_k->r almost everywhere, although microscopic labels and the exact fine winning batch may change with k.

For any arbitrary fine packet z_k<=mu_k, let z_{i,k} be its full mass in parent cloud i. Its captured mass obeys the useful uniform-in-packet inequality

    |z_k(Q_k)-sum_{i:y_i in Q}z_{i,k}| <= D_k(x).  (AC.4)

For a macro-captured parent the possible deficit is bounded by that parent's missing cloud mass; for an excluded parent any packet contribution is bounded by its extra captured cloud mass. This proves (AC.4), including partial microscopic packets.

Positive macro level sets {M=a}, a>0, are null: the maximizing captured mass is one of finitely many subset sums and its radius one of finitely many source distances, so equality places x on a finite union of source-centered cube boundaries. Consequently band indicators converge almost everywhere. All bands lie in one fixed bounded receiver set, and their integrands are bounded by beta lambda. Dominated convergence proves

    T(mu_k,lambda,beta)->T(mu,lambda,beta).      (AC.5)

## 4. Lower stability: fixed robust representatives survive refinement

For a coarse column J use the fine column consisting of every descendant of the parents in J. Its source incidence is the same at parent level, so the original alpha coefficients remain feasible for every fine site. Fix any representative c. On the coarse interior gate, r_k->r ensures c in Q_k eventually; (AC.4) gives convergence of its captured packet fraction, and the band indicators converge. Fatou yields

    liminf_k score_k(descendants(J),c)
      >= integral_Omega M 1{c in interior Q}(mu_J(Q)/F)^q dx.

Choose finitely many representatives within an arbitrary error of the interior column suprema, multiply by any feasible coarse alpha, and sum. Taking the coarse optimum and then letting the error vanish gives

    liminf_k B_t(mu_k) >= B_t^int(mu) >= (1/2)B_t(mu).   (AC.6)

This is the boundary repair omitted by a naive fixed-representative dominated-convergence proof. Example: a unit parent at zero shifted entirely to +epsilon has, at x>epsilon in dimension one, winner [epsilon,2x-epsilon]; the old representative zero is outside for every epsilon>0. The proof first moves representatives into a strict gate and only then takes the refinement limit. It never chooses representatives separately for different receivers.

## 5. Upper stability by uniformly lifting a coarse dual

Let u be an optimal coarse finite dual and set pi_i=u_i/p_i. A coarse fractional packet z=sum_i z_i delta_yi with 0<=z_i<=p_i and any representative c has

    score_mu(z,c) <= sum_i pi_i z_i.             (AC.7)

To verify this, include parent i independently in a random whole-site subset J with probability z_i/p_i. The expected captured mass equals z(Q); convexity of a^q gives score_mu(z,c)<=E score_mu(mu_J,c)<=E b_J<=E u(J)=sum_i pi_i z_i. Empty subsets contribute zero. No median requirement is imposed.

Fix a bounded receiver set D containing all sufficiently fine bands. Remove U_delta=union_i {||x-y_i||_infinity<delta}; write E_delta=D\U_delta. If epsilon_k<delta/2 and x is in the fine band in E_delta, then r_k>=delta/2 and

    F_k>lambda delta^n.

A fine packet of total mass w has normalized integrand score-density/w bounded by

    beta lambda w^t/(lambda delta^n)^q.         (AC.8)

Representatives may be clamped to the global fine-source bounding box without losing positive score, as in R73. These boxes lie in a fixed compact box K. Associate to each nonzero fine packet its parameters (w,s,c), where s_i=z_i/w, s lies in the N-simplex, 0<w<=W, ws_i<=p_i, and c in K. The closed parameter set allowing w=0 is compact.

Claim: for every eta>0, all sufficiently large k and every fine packet and representative,

    score_{mu_k,E_delta}(z_k,c)/w
          <= sum_i pi_i s_i + eta.             (AC.9)

If this uniform claim failed, take an offending sequence and a convergent parameter subsequence (w_k,s_k,c_k)->(w,s,c). If w=0, (AC.8), integrated on bounded E_delta, makes the left side tend to zero; the proposed right-side limit is nonnegative. If w>0, (AC.4) gives convergence of normalized captured masses to the coarse fractional packet z_i=ws_i. Closedness of the limiting cube and r_k->r give limsup 1{c_k in Q_k}<=1{c in Q}. Reverse Fatou, with the uniform integrable bound (AC.8), gives

    limsup score_{mu_k,E_delta}(z_k,c_k)/w_k
       <= score_{mu,E_delta}(z,c)/w
       <= sum_i pi_i s_i,

where the last step follows from (AC.7) and nonnegative truncation. This contradicts failure by a fixed eta and proves (AC.9). Thus no measure-valued infinite LP or unverified minimax theorem is needed.

Apply (AC.9) to any optimal fine packing. Source capacities give sum_J alpha_J z_{i,J}<=p_i and sum_J alpha_J w_J<=W. Summing proves that its score on E_delta is at most B_t(mu)+eta W. On U_delta its entire packed score is at most its fine band occupation, by the pointwise source-capacity inequality from R73, hence at most beta lambda |U_delta|. Therefore

    limsup_k B_t(mu_k) <= B_t(mu)+eta W+beta lambda |U_delta|.

First eta->0 and then delta->0 give

    limsup_k B_t(mu_k) <= B_t(mu).              (AC.10)

The t>0 hypothesis is used in the w->0 case of (AC.8). At t=0 the already-known identity B_0=T and (AC.5) give continuity separately.

## 6. Result, implications, and exact remaining gap

For every fixed finite positive macro source, every arbitrary mass-preserving microscopic refinement as above, and fixed t>0, lambda>0 and beta>1,

    (1/2)B_t(mu) <= B_t^int(mu)
        <= liminf B_t(mu_k) <= limsup B_t(mu_k) <= B_t(mu),
    T(mu_k)->T(mu).                             (AC.11)

If T(mu)>0, division gives the corresponding bounds for B_t/T, with at most factor two deterioration under arbitrary fine splitting. Constants in (AC.11) are independent of n, the number of fine sites, their weights, and refinement depth. Convergence rates and the threshold at which the asymptotic statements apply can depend on the macro input, n, lambda, beta, t, delta and eta; no uniform rate is claimed.

This theorem addresses the R72 entropy warning: arbitrarily large entropy generated merely by microscopic label refinement cannot force the optimized coverage ratio to zero for a fixed macro source with positive B_t/T. It does not assert exact continuity B_t(mu_k)->B_t(mu); moving boundary gates remain a genuine issue. It also does not supply a bounded-size macro approximation valid uniformly over all sources, and therefore does not turn N^{-t} coverage into a dimension-only result.

The minimal missing interface is still

    B_{1/sqrt(n)}(mu,lambda,beta) >= kappa_n T(mu,lambda,beta),
    kappa_n >= n^{-o(1)},

uniformly over all original physical sources and thresholds. If it held, R73 payment and beta-band summation would give at beta=2 the weak bound 2(1+log 2+sqrt(n))/kappa_n. No such lower bound, no all-input macro compression, and no counterexample to this lower bound are proved in this file. The new lower stability theorem is a repair of a general geometric interface, not a substitute for the target theorem.

## 7. Three-stage reproducible guard

The embedded Python uses only the standard library and Fraction. It computes actual complete-distance-batch winners, never a radius grid. It checks the pointwise refinement maximal inequalities, packet capture-defect inequality for whole-parent, arbitrary fine-subset and fractional fine packets, single-face two-shift gate, captured-set box closure and fully captured packet gates. It also explicitly verifies the old-representative translation failure, a multiple-face exceptional receiver, the three-source capacity warning and the two-source partial-capture warning.

Pilot dimensions are 1 and 2; stress dimensions 2,3,4 with nested, correlated, unequal-weight and spike sources and refinement counts 2,4,8; expanded dimensions 8,16,32. Refinement displacement scales vary with K as 2^{-(8+3K)}, capped by receiver distance/100. Deterministic pseudorandom receiver seed is 740211; independent fine-packet seed is 740212. Parent sources have one or four sites; no all-input numerical inference is made. The exact continuum proofs above, rather than these finitely many witnesses, establish the almost-everywhere and limiting claims. No zero-mean source claim is made because this positive-source packet interface applies to |f|, not signed cancellation.

Run the Python block below, or extract it to any temporary file and execute python3. It prints deterministic JSON. No numerical cubature, confidence interval, floating LP certificate or convergence rate is claimed.

```python
from fractions import Fraction as F
from itertools import product
from random import Random
import json
rng=Random(740211)
packet_rng=Random(740212)
counts=dict(winners=0,stability=0,parent_capture=0,single_face_gates=0,containment=0,closure=0,convex_packets=0,arbitrary_fine_packets=0)
def win(points,weights,x):
 ds=[max(abs(a-b) for a,b in zip(x,y)) for y in points]
 assert min(ds)>0
 rows=[]
 for r in sorted(set(ds)):
  S=[i for i,d in enumerate(ds) if d<=r]
  m=sum((weights[i] for i in S),F(0));rows.append((m/(2*r)**len(x),r,S,m))
 best=max(z[0] for z in rows)
 ans=next(z for z in rows if z[0]==best);counts['winners']+=1
 return ans
stages=[]
for stage,ns,Ks in [('pilot',[1,2],[2,4]),('stress',[2,3,4],[2,4,8]),('expanded',[8,16,32],[2,4])]:
 start=dict(counts)
 for n in ns:
  for pattern in ['spike','nested','correlated','weights']:
   N=1 if pattern=='spike' else 4
   pts=[tuple(F(i*(j+1) if pattern=='correlated' else (2**i if pattern=='nested' else ((i+2)*(j+3)%7)),8) for j in range(n)) for i in range(N)]
   # Preserve distinct physical sites; repeated coordinates are intentional.
   if len(set(pts))<N: continue
   ws=[F((i+1)**2 if pattern=='weights' else 1) for i in range(N)]
   for trial in range(6):
    x=tuple(F(rng.randrange(-80,81),13)+F(j,1009) for j in range(n))
    M,r,S,m=win(pts,ws,x);d=min(max(abs(a-b) for a,b in zip(x,y)) for y in pts)
    # Fixed arbitrary representatives include active boundary source sites.
    for c in [pts[S[0]],tuple(sum(y[j] for y in pts)/N for j in range(n))]:
     gaps=[r-abs(x[j]-c[j]) for j in range(n)]
     if min(gaps)<0 or gaps.count(0)>1: continue
     positive=[a for a in gaps if a>0]
     delta=min([r]+positive)/4
     inside=lambda z:all(abs(x[j]-z[j])<r for j in range(n))
     got=sum(inside(tuple(c[j]+sgn*delta for j in range(n))) for sgn in [-1,1])
     assert got==(1 if 0 in gaps else 2)
     counts['single_face_gates']+=1
    for K in Ks:
     eps=min(F(1,2**(8+3*K)),d/100)
     pp=[];ww=[];parent=[]
     for i,y in enumerate(pts):
      for k in range(K):
       offset=F(2*k-K+1,K)*eps
       pp.append(tuple(y[j]+offset*(1 if (i+j)%2 else -1) for j in range(n)))
       ww.append(ws[i]/K);parent.append(i)
     Mk,rk,Sk,mk=win(pp,ww,x)
     assert (d/(d+eps))**n*M<=Mk<=(d/(d-eps))**n*M
     counts['stability']+=1
     # Parent deficit is computed from the actual fine winner, not its macro surrogate.
     cap=[sum((ww[k] for k in Sk if parent[k]==i),F(0)) for i in range(N)]
     defect=sum(abs(cap[i]-(ws[i] if i in S else 0)) for i in range(N))
     for trial_packet in range(12):
      den=1 if trial_packet<6 else 7
      zz=[a*F(packet_rng.randrange(den+1),den) for a in ww]
      actual=sum((zz[k] for k in Sk),F(0))
      ideal=sum((zz[k] for k in range(len(pp)) if parent[k] in S),F(0))
      assert abs(actual-ideal)<=defect
      counts['arbitrary_fine_packets']+=1
     for mask in range(1,1<<N):
      actual=sum(cap[i] for i in range(N) if mask>>i&1)
      ideal=sum(ws[i] for i in S if mask>>i&1)
      assert abs(actual-ideal)<=defect
      counts['parent_capture']+=1
    # Exact Bernoulli whole-site convexification on actual capture rows.
    probs=[F(i+1,N+2) for i in range(N)]
    mean=sum(ws[i]*probs[i] for i in S)
    for q in [2,3]:
     moment=F(0)
     for mask in range(1<<N):
      prob=F(1)
      for i in range(N): prob*=probs[i] if mask>>i&1 else 1-probs[i]
      captured=sum((ws[i] for i in S if mask>>i&1),F(0))
      moment+=prob*captured**q
     assert mean**q<=moment
     counts['convex_packets']+=1
    # DG containment and exact box closure on actual captured-set rows.
    bbox=[(min(pts[i][j] for i in S),max(pts[i][j] for i in S)) for j in range(n)]
    closed=[i for i,y in enumerate(pts) if all(a<=y[j]<=b for j,(a,b) in enumerate(bbox))]
    assert closed==S;counts['closure']+=1
    for mask in range(1,1<<N):
     J=[i for i in range(N) if mask>>i&1]
     if set(J)<=set(S):
      c=tuple((min(pts[i][j] for i in J)+max(pts[i][j] for i in J))/2 for j in range(n))
      assert max(abs(c[j]-x[j]) for j in range(n))<=r
      counts['containment']+=1
 stages.append(dict(stage=stage,dimensions=ns,K=Ks,counts={k:counts[k]-start[k] for k in counts}))
# A fixed old representative really fails under a whole-atom translation.
M,r,S,m=win([(F(1,100),)],[F(1)],(F(1),))
assert abs(F(1)-0)>r and abs(F(1)-F(1,100))<=r
# Multiple-face exceptional point: neither diagonal perturb lies inside.
x=(F(1),F(-1));c=(F(0),F(0));r=F(1)
assert all(not all(abs(x[j]-(c[j]+s*F(1,100)))<r for j in range(2)) for s in [-1,1])
# DG capacity closure warning and full-source winner.
pts=[(F(i),) for i in range(3)];ws=[F(1)]*3
M,r,S,m=win(pts,ws,(F(95),))
assert S==[0,1,2] and F(1,100)<M<=F(1,50)
assert [1,2,1]!=[1,1,1]
# Partial-capture column positive although full-containment coefficient vanishes.
M,r,S,m=win([(F(0),),(F(10),)],[F(1,2)]*2,(F(3,64),))
assert F(4)<M<=F(8) and S==[0] and abs(F(3,64))<=r
print(json.dumps(dict(status='PASS',seed=740211,scope='exact finite actual-winner and algebra guards; no cubature or asymptotic certification',counts=counts,stages=stages),indent=2))
```

Actual stdout:

```json
{
  "status": "PASS",
  "seed": 740211,
  "scope": "exact finite actual-winner and algebra guards; no cubature or asymptotic certification",
  "counts": {
    "winners": 651,
    "stability": 456,
    "parent_capture": 5244,
    "single_face_gates": 345,
    "containment": 1446,
    "closure": 192,
    "convex_packets": 384,
    "arbitrary_fine_packets": 5472
  },
  "stages": [
    {
      "stage": "pilot",
      "dimensions": [
        1,
        2
      ],
      "K": [
        2,
        4
      ],
      "counts": {
        "winners": 144,
        "stability": 96,
        "parent_capture": 1104,
        "single_face_gates": 95,
        "containment": 466,
        "closure": 48,
        "convex_packets": 96,
        "arbitrary_fine_packets": 1152
      }
    },
    {
      "stage": "stress",
      "dimensions": [
        2,
        3,
        4
      ],
      "K": [
        2,
        4,
        8
      ],
      "counts": {
        "winners": 288,
        "stability": 216,
        "parent_capture": 2484,
        "single_face_gates": 142,
        "containment": 722,
        "closure": 72,
        "convex_packets": 144,
        "arbitrary_fine_packets": 2592
      }
    },
    {
      "stage": "expanded",
      "dimensions": [
        8,
        16,
        32
      ],
      "K": [
        2,
        4
      ],
      "counts": {
        "winners": 216,
        "stability": 144,
        "parent_capture": 1656,
        "single_face_gates": 108,
        "containment": 258,
        "closure": 72,
        "convex_packets": 144,
        "arbitrary_fine_packets": 1728
      }
    }
  ]
}
```

Guard SHA-256 (exact code block including final newline): `b6f7eadb5009c58b7219f8ad5231f4ecb4e08f53e982992e877128ed89bfb473`.
Stdout SHA-256: `5b90d52ce74193f9f567bab63ca3f2d885d186ed0bc639aadfbadcce9a03c50e`.


---

# Round 74: true soft-layer band payment through source posterior powers

**Proof status.** The ray-envelope lemma, arbitrary-selector band payment, merged-mask posterior reduction, conditional weak estimate, and finite-N corollary below have complete elementary proofs. The dimension-uniform source-entropy coverage needed for the requested general cube bound is NOT proved. The R73 global-cap strong-energy counterexample is retained; no strong-energy or optional-stopping claim replaces it. These results concern the actual E2 kernel. No external theorem or skill is used in these elementary proofs; no Git operation, TeX compilation, or PDF creation occurred.

## 1. Actual kernels and a dimension-free directional envelope

Let h=1_{[-1/2,1/2]}, w(x)=integral_0^1 exp(-|x|/t)dt, phi=h*w. Both w and phi have mass one. The function w is even and decreasing on [0,infinity); phi is likewise even and decreasing, since its derivative where defined is w(x+1/2)-w(x-1/2)<=0 for x>0. Equivalently the interval integral of an even decreasing function decreases as its center moves away from zero. Thus every mask kernel k_m=product_i(h if m_i=0, phi if m_i=1) decreases along every ray from zero. Nonnegative sums of these kernels retain this property.

**Ray-envelope lemma [proved].** Let k>=0 be Borel, integrable, of mass m, and satisfy k(r theta) nonincreasing in r>0 along each ray. For theta on the Euclidean unit sphere, set

    a(theta)=sup_{r>0} r^n k(r theta).

Then a is measurable (the supremum may be taken over positive rational r, approaching each r from below), and

    integral_S a(theta) d sigma(theta)/n <= m.                 (1)

Indeed, for each r, r^n k(r theta)/n <= integral_0^r s^(n-1)k(s theta)ds. Take the supremum and integrate. Directions on which the right side is infinite form a null set. For every L>0 and x=r theta,

    k_L(x)<=a(theta)/r^n.                                    (2)

This is an envelope for every positive physical scale, not only [1,2]. It does not assert integrability of the envelope; its radial integral diverges logarithmically. That divergence is precisely why a threshold/power cutoff is needed.

## 2. Arbitrary-selector band theorem

Fix finitely many columns u_i(x)=p_i (k_i)_{L(x)}(x-y_i), with p_i>0, k_i ray-decreasing of mass m_i, and any measurable common scale selector L(x)>0. Put G=sum_i u_i. On an arbitrary measurable subset A of {a<G<=b}, where 0<a<b<infinity, define pi_i=u_i/G. For every t>0,

    integral_A G sum_i pi_i^(1+t) dx
       <= [1+log(b/a)+1/t] sum_i p_i m_i.                    (3)

No source independence, filtration, martingale, differentiability of L, or finite-scale assumption is required. A may depend on the full source, L and the threshold. The assertion also holds with a common nonnegative multiplier attached to each column, multiplying its paid mass.

**Proof.** For each column and x in A,

    G pi_i^(1+t) <= min(b, u_i, u_i^(1+t)/a^t).

Use (2), centered at y_i. Along each direction write A_i=p_i a_i(theta) and v=r^n, so r^(n-1)dr=dv/n. When A_i>0, the radial integral of the envelope is

    (1/n) integral_0^infinity min(b,A_i/v,A_i^(1+t)/(a^t v^(1+t)))dv
       =(A_i/n)[1+log(b/a)+1/t].

The three pieces meet at v=A_i/b and v=A_i/a. If A_i=0 the integral is zero. Integrate theta, apply (1), sum columns, and use Tonelli. The right side is finite, justifying all subsequent integrals. This is a Lebesgue-space theorem, not a statement under a source-sampled observation law.

## 3. Merge all artificial mask labels before measuring source entropy

Let nu=sum_{i=1}^N p_i epsilon_i delta_{y_i}, |epsilon_i|=1, with distinct physical sites (merge coincident sites first), W=sum_i p_i. The same proof allows real or complex epsilon_i. Use the R73 endpoint mask laws alpha=Bernoulli(delta/2)^n, beta=Bernoulli(delta)^n, q=(alpha+beta)/2 and zeta=(alpha-beta)/q, omitting zero q. Define

    K=sum_m q_m k_m,       J=sum_m q_m zeta_m^2 k_m,
    I=integral J=sum_m q_m zeta_m^2<=min(4,2n delta).

Both K and J decrease along rays; their masses are 1 and I; J<=4K pointwise. For the chosen scale let

    F=sum_i p_i K_L(x-y_i),  C=sum_i p_i J_L(x-y_i),
    T=nu*[(psi_(delta/2)^tensor n)_L-(psi_delta^tensor n)_L].

R73's same-joint-measure Cauchy gives |T|^2<=FC, while C<=4F and |T|<=2F. If I=0, J=0 a.e. and for these actual kernels delta=0, so T=0; that case is trivial. Assume I>0 below. The kernels are bounded, so for finite atomic sources the finite-scale quantities are finite everywhere; in general the usual a.e. conventions suffice.

Define TWO posteriors on the same original source sites, after masks have already been summed:

    tau_i^J=p_i J_L(x-y_i)/C,       tau_i^K=p_i K_L(x-y_i)/F,
    H_J=-sum_i tau_i^J log tau_i^J, H_K=-sum_i tau_i^K log tau_i^K.

Terms 0 log 0 vanish. On the contrast event |T|>lambda, both denominators are positive. The entropy here contains no artificial mask-label complexity. Exact duplicated labels are merged before computing it. Spatially distinct refinement still can change these entropies; no dimension-only entropy stability is claimed.

## 4. True low-background crossing event: a paid power cutoff

Take any measurable selector and E={|T|>lambda}, lambda>0. For B>=1 put E_low=E intersect {F<=B lambda}. On E_low,

    lambda/B<C<=4B lambda.

Apply (3) to k_i=J and the SAME physical selector and original source. For every t>0,

    integral_E_low C sum_i (tau_i^J)^(1+t)
       <=[1+log(4B^2)+1/t] I W.                            (4)

This is an unconditional arbitrary-source, arbitrary-selector result. It replaces the unpowered selected C fee by a source-posterior power. It is not an assertion that integral_E_low C itself has the same bound.

Jensen under the posterior tau^J gives

    sum_i (tau_i^J)^(1+t)>=exp(-t H_J).

Consequently, for E_low,h=E_low intersect {H_J<=h},

    lambda |E_low,h|
       <=B exp(th)[1+log(4B^2)+1/t] I W.                   (5)

If a subset with H_J<=h retains a fraction kappa of E_low, divide this right side by kappa. If instead the entropy-bad volume has a known weak budget D W/lambda, add D W. Neither kind of paid coverage is proved here uniformly in source count. Section 7B disproves a universal pointwise raw-source entropy bound and explains why source-packet optimization is essential.

## 5. Pay the high-background branch on its own amplitude bands

For k=0,1,... put A_k=E intersect {2^k B lambda<F<=2^(k+1)B lambda}. These sets partition E_high={F>B lambda}; equality endpoints can be allocated to the preceding band. The same selector is used on all bands. Apply (3) with kernel K, and Jensen with tau^K. Then

    lambda |A_k intersect {H_K<=h}|
       <=exp(th)[1+log 2+1/t] W/(2^k B).

Summing nonnegative volumes yields the paid high-branch formula

    lambda |E_high intersect {H_K<=h}|
       <=(2/B) exp(th)[1+log 2+1/t] W.                     (6)

No weak-quasinorm triangle inequality is used. This branch needs its own source-entropy coverage, as does the low branch. A bound on H_J alone does not pay H_K, and the converse is also unavailable.

Combining (5)--(6), if H_J<=h on E_low and H_K<=h on E_high, gives

    lambda |E|/W <=exp(th){ B I[1+log(4B^2)+1/t]
                                +(2/B)[1+log 2+1/t] }.    (7)

This is a sufficient conditional interface on the actual selected event. If bounds hold only after deleting a set D_lambda, add lambda|D_lambda|/W; that deletion is not free.

## 6. Explicit constants, finite-source corollary, and layer accounting

Choose t=1/(1+h). For 0<I<=1 take B=I^(-1/2), obtaining

    a(I,h)=e sqrt(I)[3h+6+log 16+log(1/I)].                (8)

For 1<I<=4 take B=1, obtaining the convenient upper bound

    a(I,h)=6e(h+4).                                      (9)

The log(1/I) in (8) comes from the true low-background band width and must not be dropped. Equations (8)--(9) are upper bounds; no optimality is asserted.

**Unconditional finite-source corollary [proved].** Since H_J,H_K<=log N, (7)--(9) hold with h=log N for every finite atomic nu and every finite physical scale family, with L(x) the first member whose contrast exceeds lambda. The constants have no dependence on the number or spacing of physical scales, but they DO depend on N. The generic theorem also applies to any measurable all-scale selector. The finite-source result cannot be sent through empirical atomization with N tending to infinity to obtain a general L1 bound.

**Conditional layer return (accounting only; universal pointwise raw-source entropy is refuted in Section 7B).** Suppose suitable paid two-source-entropy coverage bounds were available with one dimension-only h_n on the relevant selected events for all delta=2^(-s), with entropy exceptions separately paid at a summable cost. Since I_s<=min(4,2n2^(-s)), the first O(log(2+n)) layers have fee O(1+h_n). The remaining tail, indexed by j after s about log_2(2n), has fee O((1+h_n+j)2^(-j/2)). To see this without assuming monotonicity of (8), note sqrt(I)log(1/I)<=sqrt(a)[log(1/a)+2/e] whenever 0<I<=a<=1. Thus the square-root threshold allocation yields

    (sum_s sqrt(a_s))^2=O((1+h_n)log^2(2+n)).              (10)

No claim of a completed full-scale cube theorem follows. One still needs the genuine uniform entropy/coverage theorem, the remaining base-kernel estimate and the approved full-scale localization. The tail logarithm in (8) is summable and does not add another log n to (10). This displays the fee that a suitable paid entropy/coverage scheme would need. A pointwise input-uniform raw-source h_n is in fact impossible, by Section 7B. The viable open interface is optimized finite-t packet coverage or a separately paid entropy exception scheme, not that refuted pointwise bound.

## 7. Relationship to source-capacity entropy and the R73 counterexample

The exponent pi^(1+t) in (3) has the same payment mechanism as the original-winner source-capacity score: a bounded amplitude band, a radial mass envelope, and a positive posterior-power cutoff. Here it applies to true soft kernels and arbitrary selected scales. There is no representative gate, because each individual source-centered kernel supplies its own directional envelope. Aggregating spatially distinct source sites into a packet generally destroys radial monotonicity about a common center. Therefore one cannot import R74's optimized common-packet entropy E_* as a bound for H_J or H_K without proving a packet envelope/gate comparison. The following additional construction supplies payment for new physical-scale packet gates. It does not identify those gates with the original-winner gates in R74 interpolation, or transfer the original-winner endpoint entropy.

The R73 box-source construction has selected unpowered energy at least n/1944 on a wide original global cap. That cap spans exponentially many amplitudes. The theorem here restricts a single soft amplitude band and inserts tau_i^t. It does not bound the unpowered cap integral and hence does not contradict or erase the counterexample. The finite-atomic entropy bound also cannot be transferred to that genuine L1 source with constant entropy by merely calling the whole cube one atom: its convolution column is not a source-centered probability kernel of the required form under every scale.

Minimal unpaid interface after this reduction: construct, on actual contrast crossings, source aggregation or source-entropy major subsets that retain/pay all weak volume at dimension-only h_n, simultaneously for J on the low branch and K on the high branch. The construction below pays common-source packet capacities, but their lower coverage remains unproved. The original target remains unproved.

## 7A. A paid soft packet-capacity interface, with the correct physical gate

The actual kernels satisfy the additional height bounds K<=1 and J<=I, since 0<=k_m<=1. Work with either k=K of mass m=1 or k=J of mass m=I, G=mu*k_L, and one of its actual bands A={a<G<=b} intersected with the chosen contrast event. For any fixed source subset P, mass w_P, representative c_P, and common physical cube Q(x,L(x)), put

    u_P=mu_P*k_L, pi_P=u_P/G,
    g_P=1{c_P in Q(x,L(x))}.

On that gate,

    u_P <= m w_P/L^n <= m w_P/(2||x-c_P||_infinity)^n.

The cube radial-volume identity v=(2||x-c_P||_infinity)^n, dx=dv after angular integration, and the same three-piece minimum therefore prove

    integral_A G g_P pi_P^(1+t) dx
       <=[1+log(b/a)+1/t] m w_P.                          (11)

This does not require that the packet's source sites be inside Q, or that c_P be a median. It uses the ACTUAL physical selector cube, not the original cube-maximizing winner used by the earlier source-capacity problem.

Add a special ungated singleton column for each original source i, paid by the ray theorem. Gated singleton columns are dominated by these, so they need not be listed separately. For all other subsets allow fixed representatives and the gate above. A common family alpha_P>=0 with source capacities sum_{P contains i} alpha_P<=1 has score

    B_t(A)=sup integral_A G sum_P alpha_P g_P pi_P^(1+t) dx,

where the singleton special columns have g_i=1. Every feasible score is <=T_A=integral_A G, and (11) gives

    B_t(A)<=[1+log(b/a)+1/t] m W;    B_0(A)=T_A.           (12)

The supremum notation avoids any need for a new compact-representative attainment theorem. This is now a genuine common-source-capacity payment for the soft event. Its needed dimension-only lower coverage B_t(A)>=kappa T_A is NOT proved.

For completeness, the R73 common-clock rounding proof also transfers to this modified column system without changing constants. For a finite feasible family, sample Exp(alpha_P) clocks and assign each original source to its earliest incident column. Retain its column representative; if the resulting packet is a singleton its ungated score only improves. Conditional on the clock of P being s, every site in P survives with probability at least exp(-(1-alpha_P)s). The captured SOFT source contribution u_P, being linear and nonnegative in source weights, therefore has conditional mean at least exp(-(1-alpha_P)s)u_P. Jensen at exponent 1+t and integration in s give expected traffic at least alpha_P/[1+t-t alpha_P] times original traffic, hence at least alpha_P/(1+t). This proves O_t<=B_t<=(1+t)O_t for the supremum O_t over actual common partitions with these physical gates and ungated singletons. Independence between different site assignments is not asserted or needed. Leftover source capacity is placed into ungated singleton packets. No lower coverage follows from the rounding comparison.

**Soft full-coverage endpoint warning.** For delta>0, the all-soft mask has strictly positive coefficient in both K and J, and phi>0 everywhere. Therefore every nonempty source packet has u_P(x)>0 at every finite x. In a full-coverage configuration on A, the nonnegative capacity/gate deficit forces every positive gated column to have its fixed representative inside Q(x,L(x)) for almost every x in ALL of A. Thus if the essential intersection of these selected physical cubes is empty, no non-singleton gated column can appear in a full-coverage endpoint configuration; only ungated singletons remain. Tiny but positive soft tails impose this endpoint obligation. A finite-t partial-coverage or Gibbs formulation can discard appropriately paid tail traffic; the exact t=0 endpoint cannot silently do so. This is a structural warning, not a proved large-entropy counterexample or a disproof of the desired finite-t coverage.

## 7B. Fixed-dimension counterexample to uniform raw-source entropy; the packet repairs it

**Analytic counterexample [proved].** Fix n=1, delta=1/2, L=1, lambda=1/32, B=32, and any N>=2 distinct sites y_i in [-1/32,1/32], all of weight 1/N. Let R=[1/8,1/4]. For every x in R, x-y_i belongs to [3/32,9/32], so h(x-y_i)=1. The actual kernel obeys phi<=3/4: its maximum is phi(0), and the w-mass outside [-1/2,1/2] is at least 2 exp(-1) integral_{1/2}^1 t dt=3/(4e)>1/4, using e<3.

The exact endpoint algebra is

    T=(1/4) mu*(h-phi),
    K=(5/8)h+(3/8)phi,  J=(1/10)h+(1/6)phi,  I=4/15.

Thus throughout R, T>=1/16>lambda and F<=1=B lambda. This is a positive-volume actual low-background contrast event at a single physical scale. Also 1/10<=J(x-y_i)<=9/40<=4/15 and 5/8<=K(x-y_i)<=1. Consequently

    tau_i^J<=8/(3N),   H_J>=log N-log(8/3),
    tau_i^K<=8/(5N),   H_K>=log N-log(8/5).                (13)

The entropy lower bounds follow termwise from -log tau_i>=log N-log c and sum tau_i=1. Since the sites are distinct, merging coincident labels does not change this example. Both raw-source entropies diverge uniformly on R as N grows, with n, delta, L, lambda and B fixed. Therefore no finite dimension-only pointwise bound H_J,H_K<=h_n can hold on all actual contrast events. A raw-entropy-bounded subset cannot retain any fixed positive fraction of this particular R once N is sufficiently large.

This does NOT disprove the weak target, a scheme that pays exceptional volume, or optimized packet coverage. Indeed lambda|R|=1/256 is bounded independently of N. More decisively, the single whole-source packet with representative c=0 is gated on all R: |x|<=1/4<L/2. Its posterior pi_all is exactly 1, so for every t>=0 its score is the entire occupation T_R=integral_R C dx. The pointwise upper bound already proved for capacity scores shows

    B_t(R)=O_t(R)=T_R  for every t>=0.                    (14)

The actual C-values on R lie strictly in the fixed band (1/20,1/4), since C>=1/10 and C<=9/40. Thus (14) uses precisely the paid soft-packet band interface, without a change of source, selector, or background. It sharply separates exploding raw atomic entropy from perfect common-packet coverage. The source-packet interface remains a viable open problem; the naive universal raw-source entropy hypothesis does not.

The added guard uses three source-count stages (N=2,8; 32,128; 512,2048), with exactly distinct equally spaced rational sites and three receivers in R. Eighteen exact rational geometry/constant checks and eighteen actual-E2 numerical entropy/packet checks pass. The analytic statements (13)--(14) hold for every N and every x in R; finite numerical checks are only regression evidence.

## 8. Executed staged guard and limits

The guard below is standard-library-only, seed 74011. Stage 1 checks exact rational binomial fees. Three actual-E2 stages use complete finite-grid contrast maximizers and complete equal-distance batches for original cube winners: initial low dimensions; spike, zero-mean, nested and correlated stress cases; then increased dimensions, source depth and physical scale density. It checks same-measure Cauchy, latent and merged-source Jensen, the source entropy bound, actual gated packet height/envelope inequalities, and actual E2 full-capture traces of the R73 mechanism. The actual E2 integral is Simpson-approximated at 128 and 256 subintervals. The observed refinement difference is a diagnostic, not an outward-rounded error bound. These numerical checks do not claim continuous-space cubature, certify the ray integral numerically, or prove a dimension-uniform entropy estimate. Universal claims are established by the analytic proofs above.

Guard source SHA-256: `f22d117b46ed607cd06a87892524332d032e67013a1facf96dbdb1846def4b1a`.

```python
import math, random, itertools, json
from fractions import Fraction as Q
from functools import lru_cache
rng=random.Random(74011)
counts=dict(exact_fees=0, actual_points=0, finite_selectors=0, entropy_checks=0, hard_ties=0, cap_stress=0, soft_packet_gates=0, raw_entropy_exact_rows=0, raw_entropy_actual_rows=0)
max_refinement_error=0.0
@lru_cache(None)
def phi(x,M):
    x=abs(x)
    def f(t):
        if t==0: return 0.0
        if x>=.5: return t*(math.exp(-(x-.5)/t)-math.exp(-(x+.5)/t))
        return t*(2-math.exp(-(.5-x)/t)-math.exp(-(.5+x)/t))
    return (f(0)+f(1)+sum((4 if j%2 else 2)*f(j/M) for j in range(1,M)))/(3*M)
def fee(n,d):
    out=Q(0)
    for k in range(n+1):
        a=Q(math.comb(n,k))*(d/2)**k*(1-d/2)**(n-k)
        b=Q(math.comb(n,k))*d**k*(1-d)**(n-k)
        if a+b: out+=2*(a-b)**2/(a+b)
    return out
for n in range(1,33):
    for d in {Q(1),Q(1,2),Q(1,n),Q(1,4*n)}:
        I=fee(n,d)
        assert 0<=I<=4*(1-(1-d/2)**n)<=min(Q(4),2*n*d)
        counts['exact_fees']+=1

def vals(points,p,signs,x,L,d,M):
    n=len(x); rows=[]
    for y,weight,sgn in zip(points,p,signs):
        z=[abs((a-b)/L) for a,b in zip(x,y)]
        hard=[float(a<=.5) for a in z]; soft=[phi(a,M) for a in z]
        for mask in itertools.product((0,1),repeat=n):
            k=sum(mask); a=(d/2)**k*(1-d/2)**(n-k); b=d**k*(1-d)**(n-k)
            q=(a+b)/2
            if not q: continue
            score=(a-b)/q
            kernel=math.prod(soft[i] if mask[i] else hard[i] for i in range(n))/L**n
            rows.append((weight*q*kernel,score,sgn))
    F=sum(u for u,z,s in rows); T=sum(u*z*s for u,z,s in rows)
    C=sum(u*z*z for u,z,s in rows)
    assert T*T<=F*C+1e-11 and abs(T)<=2*F+1e-12
    return F,T,C,rows

def winner(points,p,x):
    # Full equal-distance batches, including closed-cube boundary ties.
    ds=sorted(set(max(abs(a-b) for a,b in zip(x,y)) for y in points))
    if ds and ds[0]==0:
        return (math.inf,0.,sum(w for y,w in zip(points,p) if y==x))
    values=[]
    for r in ds:
        if r==0: continue
        mass=sum(w for y,w in zip(points,p) if max(abs(a-b) for a,b in zip(x,y))<=r)
        values.append((mass/(2*r)**len(x),r,mass))
    return max(values,key=lambda z:(z[0],-z[1]))

results=[]
# Three stages: initial, cap/zero-mean/nested pressure, enlarged dimensions/depth.
for stage,dims,N in [(1,(1,2),3),(2,(1,2,3),5),(3,(3,5),8)]:
    for n in dims:
        for family in ('spike','zero_mean','nested','correlated','random'):
            if family=='spike': points=[(0.,)*n]; p=[1.]; signs=[1.]
            elif family=='zero_mean': points=[(-.25,)*n,(.25,)*n];p=[.5,.5];signs=[1.,-1.]
            else:
                if family=='nested': points=[(2.**(-j-1),)*n for j in range(N)]
                elif family=='correlated': points=[tuple((j-(N-1)/2)/N*(-1)**i for i in range(n)) for j in range(N)]
                else: points=[tuple(rng.uniform(-.6,.6) for i in range(n)) for j in range(N)]
                p0=[rng.random()+.1 for j in points];p=[v/sum(p0) for v in p0]; signs=[(-1.)**j for j in range(len(p))]
            xs=[tuple(rng.uniform(-1.2,1.2) for i in range(n)) for z in range(8)]
            xs += [(r,)+(0.,)*(n-1) for r in (.5,.625,.875)]
            Ls=(1.,1.125,1.5,2.) if stage<3 else tuple(1+j/8 for j in range(9))
            d=1/n
            records=[]
            for x in xs:
                original=winner(points,p,x)
                assert original[0]>=0
                values=[vals(points,p,signs,x,L,d,128) for L in Ls]
                idx=max(range(len(Ls)),key=lambda j:abs(values[j][1]))
                F,T,C,rows=values[idx]
                refined=vals(points,p,signs,x,Ls[idx],d,256)
                max_refinement_error=max(max_refinement_error,max(abs(a-b) for a,b in zip((F,T,C),refined[:3])))
                counts['actual_points']+=len(Ls); counts['finite_selectors']+=1
                if F and C:
                    pi=[u/F for u,z,s in rows]; v=C/F
                    H=sum((u*z*z/C)*math.log(F/u) for u,z,s in rows if u*z*z>0)
                    D=sum(u>0 for u,z,s in rows)
                    assert H<=math.log(D)+math.log(4/v)+1e-10
                    for t in (.125,.5,1.,2.):
                        A=F*sum(z*z*(u/F)**(1+t) for u,z,s in rows if u)
                        assert A+1e-12>=C*math.exp(-t*H)
                        # Holder check independent from Jensen's tilted-fee proof.
                        R=sum(v0**(1-t) for v0 in pi if v0) if t<=1 else None
                        if R is not None: assert T*T/F <= A*R+1e-11
                        counts['entropy_checks']+=1
                # Merge every latent mask back into its original physical source.
                Dmask=2**n
                U=[sum(u for u,z,s in rows[j*Dmask:(j+1)*Dmask]) for j in range(len(p))]
                V=[sum(u*z*z for u,z,s in rows[j*Dmask:(j+1)*Dmask]) for j in range(len(p))]
                assert abs(sum(U)-F)<1e-10 and abs(sum(V)-C)<1e-10
                # Actual common packet gates: kernel height <= its total mass.
                Iscalar=float(fee(n,Q(1,n)))
                for ids in [list(range(len(p))),list(range(max(1,len(p)//2)))]:
                    c=tuple(sum(points[j][i] for j in ids)/len(ids) for i in range(n))
                    r=max(abs(a-b) for a,b in zip(x,c))
                    if r<=Ls[idx]/2:
                        mass=sum(p[j] for j in ids)
                        for parts,kmass in ((U,1.),(V,Iscalar)):
                            u=sum(parts[j] for j in ids)
                            assert u<=kmass*mass/Ls[idx]**n+1e-11
                            if r: assert u<=kmass*mass/(2*r)**n+1e-11
                            counts['soft_packet_gates']+=1
                for total,parts in ((F,U),(C,V)):
                    if total:
                        shares=[u/total for u in parts if u]
                        Hsource=-sum(a*math.log(a) for a in shares)
                        assert Hsource<=math.log(len(p))+1e-10
                        for t in (.125,.5,1.,2.):
                            assert sum(a**(1+t) for a in shares)+1e-12>=math.exp(-t*Hsource)
                            counts['entropy_checks']+=1
                records.append((F,abs(T),C))
            lam=sorted(t for f,t,c in records)[len(records)//2]
            low=sum(t>lam and f<=4*lam for f,t,c in records)
            high=sum(t>lam and f>4*lam for f,t,c in records)
            results.append(dict(stage=stage,n=n,family=family,low=low,high=high))
# Closed hard ties are handled as complete batches.
for n in (1,2,3):
    points=[(-1.,)*n,(1.,)*n]; out=winner(points,[.5,.5],(0.,)*n)
    assert out==(1/2**n,1.,1.); counts['hard_ties']+=1
# Actual E2 atomic full-capture stress; this is a numeric trace of the R73 mechanism,
# not a replacement for its genuine-L1 analytic counterexample.
for n in (2,4,8,16,32):
    d=1/n
    for r in (.5,.625,.75,.875):
        L=2*r; x=[r]+[0.]*(n-1)
        ph=[phi(abs(a/L),256) for a in x]
        P=math.prod(1-d/2+d/2*v for v in ph)/L**n
        Q0=math.prod(1-d+d*v for v in ph)/L**n
        F=(P+Q0)/2; T=P-Q0
        assert T*T/F>=L**(-n)/162-1e-13
        counts['cap_stress']+=1
# New three-stage distinct-source refinement pressure at fixed n=1, delta=1/2.
for stage,Ns in ((1,(2,8)),(2,(32,128)),(3,(512,2048))):
    for N in Ns:
        ys=[-Q(1,32)+Q(j,16*(N-1)) for j in range(N)]
        assert len(set(ys))==N
        for x in (Q(1,8),Q(3,16),Q(1,4)):
            assert all(Q(3,32)<=x-y<=Q(9,32) for y in ys)
            assert abs(x)<=Q(1,2)
            assert Q(1,10)+Q(1,6)*Q(3,4)==Q(9,40)<Q(1,4)
            assert Q(1,20)<Q(1,10) and Q(1,4)*(1-Q(3,4))==Q(1,16)>Q(1,32)
            assert Q(4,15)/Q(1,10)==Q(8,3) and 1/Q(5,8)==Q(8,5)
            counts['raw_entropy_exact_rows']+=1
            ph=[phi(float(x-y),256) for y in ys]
            js=[.1+v/6 for v in ph]; ks=[.625+.375*v for v in ph]
            C=sum(js)/N; F=sum(ks)/N; T=.25*(1-sum(ph)/N)
            assert T>1/32 and F<=1 and 1/20<C<1/4
            for values,constant in ((js,8/3),(ks,8/5)):
                total=sum(values); posterior=[v/total for v in values]
                H=-sum(v*math.log(v) for v in posterior)
                assert max(posterior)<=constant/N+1e-12
                assert H>=math.log(N)-math.log(constant)-1e-10
            # Full packet's physical representative 0 is gated and posterior=1.
            for t in (.125,.5,1.,2.):
                assert C*1.**(1+t)==C
            counts['raw_entropy_actual_rows']+=1
print(json.dumps(dict(status='PASS',seed=74011,counts=counts,
    max_simpson_128_256_value_change=max_refinement_error,
    scope='exact fee identities; floating actual-E2 finite-selector and entropy checks, not spatial integration or an asymptotic proof',
    low_events=sum(r['low'] for r in results),high_events=sum(r['high'] for r in results)),indent=2))
```

Actual stdout:

```json
{
  "status": "PASS",
  "seed": 74011,
  "counts": {
    "exact_fees": 126,
    "actual_points": 2090,
    "finite_selectors": 385,
    "entropy_checks": 4620,
    "hard_ties": 3,
    "cap_stress": 20,
    "soft_packet_gates": 656,
    "raw_entropy_exact_rows": 18,
    "raw_entropy_actual_rows": 18
  },
  "max_simpson_128_256_value_change": 6.292550874809066e-07,
  "scope": "exact fee identities; floating actual-E2 finite-selector and entropy checks, not spatial integration or an asymptotic proof",
  "low_events": 40,
  "high_events": 135
}
```


---

# Round 74: certified actual-band source-capacity coverage in one dimension

This experiment computes rigorous bounds for the full Round 73 source-capacity LP on 16 registered one-dimensional finite rational sources. It integrates the entire original winner band, optimizes every nonempty subset over unrestricted fixed representatives, and certifies both sides of each LP by exact rational primal and dual feasibility. The lowest tested `t=1` coverage is approximately `.737074`, while singleton or one-median strategies can be much smaller. No arbitrary-source coverage fraction, dimension growth law, or target `C_n≤√n n^{o(1)}` is proved.

A secondary two-dimensional stage optimizes the full finite empirical LP, then validates its selected common representatives and source allocations on independent full-space receivers. Its certified finite-witness upper bound is not an upper bound for the spatial LP. The two evidence types are kept separate below.

## Original source, winner, occupation and LP

Every source has positive rational masses normalized to `W=1`, with coincident sites merged. In one dimension its sites and weights are exact rational input data. For a receiver x outside the finite source set, every centered interval arrival radius is tested; all equal-distance sites enter as one batch. The selected winner is the smallest-radius complete batch maximizing `M=F/(2r)`. This retains the original all-scale maximal function and the original band `Ω={λ<M≤2λ}`.

For each nonempty whole-site subset J and fixed representative c, define

`b_J(c)=∫_Ω M(x) 1{c∈Q*(x)} [μ_J(Q*(x))/F(x)]^q dx`, `q=1+t`,

`b_J=max_c b_J(c)`, `T=∫_Ω M(x)dx`.

The complete source-capacity LP is

`B_t=max Σ_J α_J b_J`, subject to `α_J≥0` and `Σ_{J∋i}α_J≤1` for every site i.

Its dual uses nonnegative site prices u_i with `Σ_{i∈J}u_i≥b_J` for every nonempty J. The common whole-site partition optimum is `O_t=max_P Σ_{J∈P}b_J`. The probe includes all `2^N−1` columns for each source with `N≤8`; it does not substitute a tree frontier or a sampled subset library for this LP. Dynamic programming also computes bounds for the unrestricted common-partition optimum.

The analytic inequalities `O_t≤B_t≤T` and `B_t≤(1+t)O_t` remain conceptually distinct from the numerical input-specific values. The fee `1+log 2+1/t` is an upper source payment bound for `t>0`; a large tested `B_t/T` is not a proved uniform coverage lower bound. The endpoint `q=1` is included as a check: singleton representatives at the original sites give `B_0=O_0=T` exactly, since all captured source mass is contained. No finite fee is assigned to `t=0`.

## Full-band rational winner cells

The Round 44 `levelset_guard.py` and its piecewise structure/oracle discussion were inspected first. That program certifies weak-level set volumes via subset-box unions. It does not compute winner occupation or unrestricted representative optima. This probe uses the same exact finite atomic object and adds a separate one-dimensional winner-cell decomposition.

Source sites and all pairwise site midpoints divide the receiver axis into intervals of constant distance ordering. On each such interval, every prefix capture mass F is fixed and every candidate denominator is `2s(x−a)`, with anchor site a and sign s fixed. Equality between two candidate averages is a linear rational equation. All its roots inside that ordering interval are added. Thus winner comparisons are fixed on each resulting open cell. The program separately guards the selected capture at two rational interior points; the finite decomposition is justified by the complete ordering and pairwise equality cuts, rather than by those point guards alone.

The weak set lies inside `[min y−1/(2λ),max y+1/(2λ)]`. For a fixed winning anchor a and mass F, the band condition is `F/(4λ)≤|x−a|<F/(2λ)`. Intersecting with these rational endpoints gives the entire band up to finitely many null boundary points. Adjacent cells with identical anchor and captured source set are merged. Distances stay positive on every retained band cell. Strict/closed endpoint conventions are immaterial to these Lebesgue integrals, while the exact point winner and representative gates retain complete tied batches and closed cubes.

On each final cell `(u,v)`, write `A_J=μ_J(Q*)`, fixed throughout the cell. Without a representative gate, its contribution is

`(F/2)(A_J/F)^q log(r_max/r_min)`.

All its logarithm ratios lie in `[1,2]` because the cell lies inside the original band. There is no receiver mesh, stochastic quadrature, scale truncation or omitted spatial tail in the one-dimensional calculation.

## Finite representative reduction for the actual integral

If a cell lies to the right of its anchor, its winner is `[a,2x−a]`. For fixed c the gate requires `c≥a` and `x≥(c+a)/2`. Its contribution is zero when the gate is impossible; otherwise it is

`(F/2)(A_J/F)^q log((v−a)/max(u−a,(c−a)/2))`,

when the denominator is below the numerator. On a left-of-anchor cell the corresponding expression is

`(F/2)(A_J/F)^q log((a−u)/max(a−v,(a−c)/2))`,

with `c≤a`. A partial contribution has the form `constant−positive_coefficient·log|c−a|`; its second derivative is nonnegative. Each term is therefore convex on every representative interval cut by `a,2u−a,2v−a`, while constant and zero pieces are also convex. Their sum is convex between the combined cuts. At c=a, the closed gate includes the entire anchor-side cell; that endpoint value dominates the lost opposite-side limit.

A representative may first be clamped to J's source bounding interval without losing any positive captured gate. Consequently each subset's full-band maximum is attained among the rational cuts `a,2u−a,2v−a` inside that interval, together with its two bounding endpoints. This is a reduction of the full one-dimensional spatial integral, not the finite-receiver arrangement reduction from Round 73. Source coordinates or medians alone need not exhaust these candidates. The saved representative for each subset maximizes the lower enclosure; its actual coefficient is at least that enclosure, even if two nearly tied true candidates cannot be ordered by the retained precision.

## Outward arithmetic and exact LP certificates

For rational `1≤r≤2`, put `z=(r−1)/(r+1)`. The code uses the first 45 terms of

`log r=2Σ_{k≥0}z^(2k+1)/(2k+1)`.

The positive omitted tail is at most `2z^(91)/(91(1−z²))`. Exact Fraction arithmetic computes the lower sum and upper sum plus this remainder, then rounds them downward/upward to denominator `2^90`. The exponents are `q=1,3/2,2`. Integer powers are rational; the half-integer power is bounded by 100 exact dyadic square-root bisections applied to `π^3`, with the squared endpoint inequalities checked before outward rounding. All sums and final coefficient endpoints are rational. A narrow decimal display does not determine the bound direction; the exact endpoints are stored as strings in the JSON.

Each subset coefficient is bounded by the maximum of its candidate lower endpoints and the maximum of its candidate upper endpoints. Solving the capacity LP with all lower coefficients gives a lower bound for the true spatial LP. Solving with all upper coefficients gives an upper bound. The latter's dual prices cover every actual subset coefficient, so it is a valid upper certificate for this listed full-band one-dimensional input.

The solver is a small exact-rational primal simplex with Bland's rule. It starts from the slack basis and checks nonnegative primal weights, each site capacity, nonnegative dual prices, every subset dual constraint, and equality of primal/dual objectives for both rational enclosure LPs. No floating LP tolerance determines certificate acceptance. A separate exact subset dynamic program bounds `O_t` and reconstructs an actual common partition with one fixed representative per block.

The program also solves the LP with only bounding-box-closed source subsets. In one dimension these are contiguous intervals in sorted source order. Noncontiguous columns have zero objective in this comparison and can be deleted; retained columns use their unchanged actual packet coefficients. This is a diagnostic restriction, not an assumed reduction of the original LP.

## Registered one-dimensional pressure results

The archive includes 16 sources, 48 source/exponent cases, 112 band cells and 2,568 exact interior capture guards. It evaluates 6,042 subset coefficients and 61,071 representative candidates across the three exponents, and solves 192 certified enclosure LPs including the closed-subset comparisons. Thresholds and all coordinates/weights are saved. The equal grids use N=4,6,8; other fixtures include unequal weights, widely separated groups, microscopic pairs and deep geometric gaps. These sources were constructed for mechanism pressure; they do not parameterize every positive source.

The following entries are approximate displays of certified intervals, not sample means. Their full rational endpoints are saved. At `q=2` the widest B interval is about `7.28×10^−27`; widths are far below the displayed digits.

| Source | N | λ | actual T | full B/T, t=1/2 | full B/T, t=1 | common O/T, t=1 | singleton traffic, t=1 | whole lower-median traffic, t=1 |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| single_atom | 1 | 1/4 | 0.69314718 | 1.00000000 | 1.00000000 | 1.00000000 | 0.69314718 | 0.69314718 |
| equal_two_low | 2 | 1/4 | 0.34657359 | 1.00000000 | 1.00000000 | 1.00000000 | 0.34657359 | 0.17328680 |
| equal_two_peak | 2 | 3/4 | 0.98082925 | 0.91409297 | 0.85334753 | 0.85334753 | 0.83698822 | 0.63425566 |
| unequal_two | 2 | 1/4 | 0.59140550 | 0.98588834 | 0.98588834 | 0.98588834 | 0.53019752 | 0.58305979 |
| grid4 | 4 | 1/4 | 0.47738563 | 0.92467251 | 0.92467251 | 0.92467251 | 0.17328680 | 0.40546511 |
| unequal4 | 4 | 1/4 | 0.92975586 | 0.87365733 | 0.79397813 | 0.79397813 | 0.68413376 | 0.58484315 |
| grid6 | 6 | 1/4 | 0.54121255 | 0.97192699 | 0.97192699 | 0.97192699 | 0.11552453 | 0.51082562 |
| grid8 | 8 | 1/4 | 0.57630721 | 0.98551864 | 0.98551864 | 0.98551864 | 0.08664340 | 0.55961579 |
| three_groups2_gap4 | 6 | 1/12 | 0.80901230 | 0.86113087 | 0.76293556 | 0.76293556 | 0.30861213 | 0.48076967 |
| three_groups2_gap20 | 6 | 1/12 | 0.69314718 | 1.00000000 | 1.00000000 | 1.00000000 | 0.34657359 | 0.23104906 |
| four_micro_pairs | 8 | 1/16 | 0.82061723 | 0.84598155 | 0.73707406 | 0.73707406 | 0.30242784 | 0.35961785 |
| heterogeneous_micro_pairs | 8 | 1/16 | 0.49177965 | 0.92602733 | 0.87886808 | 0.87886808 | 0.21610472 | 0.21344795 |
| deep_hierarchy8 | 8 | 1/4 | 0.34657359 | 1.00000000 | 1.00000000 | 1.00000000 | 0.08664340 | 0.17328680 |
| unequal_deep_hierarchy8 | 8 | 1/4 | 0.43976474 | 0.91390471 | 0.85462830 | 0.85462830 | 0.23052604 | 0.37218722 |
| one_heavy_seven_light | 8 | 1/8 | 0.69065113 | 0.98369625 | 0.97905829 | 0.97905829 | 0.66463449 | 0.66668042 |
| alternating_weights8 | 8 | 1/4 | 0.59037308 | 0.97258408 | 0.97258408 | 0.97258408 | 0.16406438 | 0.55749603 |

For four microscopic pairs, the full LP and common-partition coverage are approximately `.737074`, compared with singleton traffic `.302428` and whole lower-median traffic `.359618` against actual occupation `.820617`. For three pairs separated by 20, the full LP and partition coverage enclose 1, although a whole lower median pays one-third of the actual occupation and singletons at t=1 pay one-half. These are rigorous finite-input failures of those particular fixed strategies to cover all the occupation; they do not refute the unrestricted coverage route.

No strict gap was certified between B and O on these inputs: their enclosures overlap at the retained precision. Likewise no strict gap was found between the full LP and the contiguous-subset restricted LP. This finite record does not prove either equality for arbitrary one-dimensional sources. The smallest tested full B/T is a bound for that input, not a lower bound on the infimum over all sources, and the range of 16 values is not an asymptotic estimate.

The exact weak-level-set representation from Round 44 provides independent calibrations. One atom gives `T=log 2`. For equal atoms at 0,1 and λ=1/4, the exact weak statistic is `3/4` and `T=(log 2)/2`; for λ=3/4 the weak statistic is `5/4` and `T=log(8/3)`. The script checks compatible rational logarithm enclosures for these three identities. These oracles test integration normalization and band limits; they are not general optimal-source results.

## Two-dimensional finite LP and independent validation

The secondary stage contains the equal four vertices, the six-site heterogeneous two-scale source retained from Round 73, and eight sites in four microscopic pairs. It uses `q=2`, a 64-receiver training witness per source and two independent 1,024-receiver validation batches. Seeds are `741000+source_id` for training, and `742000+10·source_id`, `742001+10·source_id` for validation. There are 192 training draws, 6,144 validation draws and 333 training subset columns, with 55,899 finite arrangement candidates. These counts describe distinct draws; reusing each receiver across all subsets does not create additional independent observations.

The sampler uses the same full-space three-component volume proposal as Round 73. With `V=1/λ`, `a_i=p_i` and `τ_i=(2‖x−y_i‖∞)^2/V`, its full normalized density is

`qcore=Σ_i min(1,τ_i^−2)/(4N)+Σ_i a_i min(1,τ_i^−2)/8+Σ_i min(1,(a_i/τ_i)^2)/8`.

Every sampled receiver is interpreted as its exact binary rational coordinate. The code computes its complete tied-distance winner, original band, rational posterior mass, closed representative gates and full rational proposal density. Its occupation importance score is `1_Ω(M/λ)/qcore`, bounded by `8N`. Candidate representatives for every subset are the exact product arrangement of winner-cube faces, packet-box endpoints and open-cell midpoints. Integer difference arrays accumulate downward/upward rounded positive score contributions at denominator `2^90`, producing certified bounds on that finite empirical coefficient maximum. The saved lower-best candidate is independently evaluated directly with rational gates.

Both finite enclosure LPs have exact primal/dual certificates. The trained lower-LP packing, its representatives and the trained common partition are then frozen. Each held-out receiver checks that the packing score and partition score lie in `[0,1]`. Its source-capacity feasibility makes the corresponding true spatial packing a legitimate lower route to B_t. The held-out sample estimates its integral; it does not certify that integral, the full continuum optimum, or a continuum LP upper bound. Sampling uses ordinary floating construction and `random.Random`; exact evaluation of its realized points does not certify that finite machine draws have the ideal continuous law.

The table combines the equal-size validation batches. `±` denotes one combined sample standard error `sqrt(SE_1²+SE_2²)/2`, without a ratio confidence interval. The packing and partition estimates happen to agree for the trained choices on these inputs. Their dependence on the same receivers is retained.

| Two-dimensional source | finite training LP B | finite training occupation | held-out frozen packing | held-out occupation |
|---|---:|---:|---:|---:|
| vertices4 | 0.488827 | 0.585959 | 0.288596 ± 0.018922 | 0.445608 ± 0.024873 |
| heterogeneous6 | 0.381537 | 0.428216 | 0.242358 ± 0.019218 | 0.516898 ± 0.026619 |
| micro_pairs8 | 0.844003 | 0.844003 | 0.688732 ± 0.037782 | 0.688732 ± 0.037782 |

The four-vertex training LP is approximately `.488827`, but its frozen packing estimates only `.288596 ± .018922` on held-out receivers. The heterogeneous source gives training `.381537` versus held-out `.242358 ± .019219`. Optimization of the entire finite LP does not remove training selection bias. In the microscopic-pair source the frozen choice has full power at every sampled band receiver, giving matching packing and occupation means; that sample identity is not an all-receiver gate proof.

Per 1,024-draw validation row, the formal ideal-proposal two-sided 95% Hoeffding radius is `8N sqrt(log(40)/(2·1024))`: about 1.3581, 2.0372 and 2.7162 for N=4,6,8. These are much wider than the sample SEs. They assume the exact ideal continuous proposal and are not simultaneous guarantees across all rows. Reporting selection, finite-machine randomness and decimal statistics are not covered by the rational finite-witness certificates.

## Verification, replay and evidence boundary

After the main run, a separate standard-library verification rechecked the 102 unrestricted lower/upper LP certificates from saved JSON, covering all 12,750 subset dual inequalities. It also tested 1,600 independently seeded rational receiver points against the full one-dimensional band-cell decomposition, including capture identity wherever in the band. These additional tests support the implementation; they are not counted as new source cases or a substitute for the cell/reduction proof. The maximum saved one-dimensional coefficient width was `3/618970019642690137449562112`, approximately `4.85×10^−27`.

The current L02/L03 skill boundaries are observed: the input family and every constraint are explicit; finite pressure search is distinguished from universal optimization; rational enclosure directions and feasibility are checked; no generic verified floating interval library is claimed. Round 44's exact geometry and Round 73's unrestricted representative/LP definitions are retained. The numerical target remains arbitrary input, not a restriction to these special families.

The final main run exited 0 in 7.539634084 seconds. An independent temporary-directory replay of the saved script exited 0 in 7.596856000 seconds with empty stderr and produced byte-identical JSON. Runtime is printed and excluded from deterministic JSON. The script uses only the Python standard library; the recorded execution used bundled Python 3.12.14. No SciPy or NumPy installation is needed. A pilot serialization attempt initially failed because a sample diagnostic ratio was retained as an enormous exact Fraction; it was changed to an explicitly floating sample ratio before the successful final run. No failed output is counted as final evidence.

The program writes `dual_results.json` beside itself. Preserve the FINAL archive by replaying a temporary copy, and use `--pilot` only there:

```sh
TASK_DUAL_REPLAY_DIR=$(mktemp -d)
cp /Users/zhengzhihao/Desktop/T/output/centered_cube_round074_20261011/dual_probe.py "$TASK_DUAL_REPLAY_DIR/dual_probe.py"
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 "$TASK_DUAL_REPLAY_DIR/dual_probe.py"
shasum -a 256 "$TASK_DUAL_REPLAY_DIR/dual_results.json"
```

The complete certified one-dimensional results reduce finite-point uncertainty for these inputs. The remaining general problem is a uniform lower bound for B_t/T over arbitrary positive sources in growing dimensions; none follows from the completed experiment.

Frozen dual_probe.py SHA256: `7f5a6a44ceeb4a2c866cdb4a17dadcded1486d793e260f2f1a98928c90cafc2d`.

Frozen dual_results.json SHA256: `f8e872567835e2d2ea597c12b10e0ab3d216a5104eb0c2d82642f1a17fff54cd`.


---

# 第 74 轮独立数值证书审计

**结论：冻结存档通过本次独立审计，未发现影响其已声明结论的实质错误。** 一维部分认证的是 16 个列明的正有理原子源、48 个源/指数实例的完整 Lebesgue 原带积分及源容量 LP；二维部分认证的是 3 个实际 64 点训练函数的有限 LP。二者都不构成任意源、任意维数或 `C_n≤√n n^{o(1)}` 的证明。主目标仍未证明，本轮只完成校准和有限输入证书。

审计未修改主数值代码/JSON/作者报告，未操作 Git。独立脚本 `audit_guard.py` 不 import `dual_probe.py`，只读取最终 JSON 并另行实现几何、见证核验、闭式校准和训练系数直接求和。

## 冻结对象与实际执行

审计终点的 SHA256 与数值作者冻结通知一致：

- `dual_probe.py`: `7f5a6a44ceeb4a2c866cdb4a17dadcded1486d793e260f2f1a98928c90cafc2d`
- `dual_results.json`: `f8e872567835e2d2ea597c12b10e0ab3d216a5104eb0c2d82642f1a17fff54cd`
- `dual_numeric.md`: `9e5aa852e44d63758cc9bc8e9c7cf0505acf915b9088a3a47eb57407047bf9fc`

独立运行命令：

```sh
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 /Users/zhengzhihao/Desktop/T/output/centered_cube_round074_20261011/audit_guard.py
```

最终运行退出码为 0，输出 `PASS`，用时约 13.4801 秒。实际检查量：

|核验|实际数量|性质|
|---|---:|---|
|保存的有理 LP 原/对偶见证|198|精确 Fraction；192 一维完整/连续子集 LP，6 二维有限 LP|
|独立连续原子块几何细胞|4,655|精确 Fraction 重建；合并后的 112 原带细胞与 JSON 完全一致|
|一维全部子集系数|6,042|100 位 Decimal 候选最大值与保存代表交叉诊断；不冒充区间证书|
|三个手算小例的系数闭式|21|独立 80 项有理 log 余项包络及 150 步平方根二分|
|二维直接 Cartesian 候选|55,899|逐点整数求和，不使用差分数组；333 训练系数的上下界全部相等|
|全部一维/二维分区最优值|51 对上下界|独立枚举所有集合分区，分别核对保存 O 的上下端点|

最大保存一维系数宽度为 `3/618970019642690137449562112`，约 `4.85×10^−27`。该宽度不承担证明方向；证明方向见下述精确算术与弱对偶。

## 赢家几何、阈值与系数归一化

列明源均有总质量 1、正质量、互异合并后的有理位置、`λ>0`。原尺度归一化已由作者报告明确：`raw_mass` 是原权重和的记录，计算中的源本身是概率质量。不能把存档阈值直接当作未归一化原质量的同一阈值。

在 source sites 和所有 pairwise midpoints 之间，距离次序恒定，每个完整到达前缀给出 `F/[2s(x−a)]`。两候选相等的根为

`x=(F·t·b−G·s·a)/(F·t−G·s)`，

与主程序加入的切点一致。分母为零时，候选恒相等或始终不相等，无漏掉的孤立根。源点、距离次序变化点、候选相等点都是有限零测集；点上 complete tied arrival 与最小半径 tie convention 不影响本轮积分。主 `winner` 确实按相同半径整批加入原子，然后比较平均密度，未把一个 tied batch 拆开。

独立重建没有使用主程序的前缀事件。它利用恒等式

`M(x)=max_{i≤j} [Σ_{k=i}^j p_k]/[2 max(|x−y_i|,|x−y_j|)]`。

每个连续块候选均不大于真实 M，因为其半径捕获至少该块；反过来真实赢家捕获的原子是连续块，故等号成立。独立脚本给所有块作完整交点切分并检查最大块在选定半径下已捕获完整质量，随后截取原带。4,655 个精确细胞合并后与存档 112 细胞逐项一致。

所有带内 receiver 位于 `[min y−1/(2λ),max y+1/(2λ)]`；带条件恰为 `F/(4λ)≤|x−a|<F/(2λ)`，所以界外没有被截掉的尾积分。每个带内距离比在 `[1,2]`。任一固定捕获集的积分是

`(F/2)(μ_J(Q*)/F)^q log(r_max/r_min)`。

这里 `F/2` 来自一维中心区间体积 `2r`，不是 `F` 或 `F/(2λ)`；主代码归一化正确。

## 无限制代表最大值的有限化

对于右 anchor cell `x∈(u,v), x>a`，`Q*=[a,2x−a]`，闭 gate 是 `c≥a` 且 `x≥(c+a)/2`。贡献是

`K log((v−a)/max(u−a,(c−a)/2))`，`K=(F/2)(μ_J(Q*)/F)^q≥0`，

当 gate 不可能或分母不小于分子时为 0。左侧相应贡献是 `K log((a−u)/max(a−v,(a−c)/2))`，须 `c≤a`。

在 `a,2u−a,2v−a` 之间，每项是常数、零或 `constant−K log|c−a|`，后者二阶导为 `K/(c−a)^2≥0`；因此整和在共同切点之间凸，最大值由两端控制。非 anchor 切点处项连续。anchor 处闭 gate 包含该侧全部 receiver；即使同一 anchor 汇集左右细胞，切点本身包含两侧贡献，其值分别不小于左右极限。因而跳跃不会在临界候选外产生漏掉的上确界。

将 c 投影到 J 的源 bbox 不会减少正贡献：若某项 `μ_J(Q*)>0` 且旧 c 在 Q* 中，则 Q* 也包含 J 的至少一个源点；闭区间的凸性保证 bbox projection 仍在 Q*。故候选是 bbox 两端及其内部全部上述切点，存档确实优化了无限制 c，而非只选源坐标或中位数。保存代表最大化下包络，足以给出可实现下界，无须证明浮点意义上的唯一最佳代表。

## 外向包络与 LP 证书

主代码没有 Decimal/浮点区间库依赖。Fraction 给出全部有理几何和中间运算；仅 JSON 展示/抽样统计使用 float。

`log r` 用 `z=(r−1)/(r+1)∈[0,1/3]` 的 45 项正级数下和，尾项不超过

`2 z^91/[91(1−z²)]`。

这是把所有余项分母以 91 从下界替换后的几何级数上界。`down`/`up` 分别用整数 floor/ceiling 到 `2^90` 网格，对正数方向正确。半整数幂满足 `(π^q)^2=π^3`；100 步精确二分保持 `lo²≤π^3≤hi²`，随后外向取整保持包含性。非负幂、log、质量的乘法和累加保持上下界方向。候选下界的最大值是可实现系数下界，候选上界的最大值是全部候选、从而全部空间代表的上界。

独立脚本直接从 JSON 逐一检查：原变量非负、每个原子容量不超过 1、对偶非负、**每个保存子集**的对偶不等式、目标相等、保存 loads 和最小 slack。包括闭包受限 LP 的零化非连续列。每个有理 LP 都有相等目标的可行原/对偶见证，所以接受性不依赖 simplex 枢轴实现或浮点 solver 状态。对于真实积分 LP，lower coefficients 的原见证给下界，upper coefficients 的对偶见证给上界。独立全分区枚举另核验 O；没有靠主动态规划的同代码断言。

100 位 Decimal 重评所有临界候选，最大值及保存代表均落入存档有理区间。这只是高精度诊断。严谨包络由上面的有理余项/平方比较和精确见证给出，未声称 Decimal 自身是经过认证的向外舍入库。

三个独立闭式校准进一步检查质量系数和 band：

1. 单原子、`λ=1/4`：带为 `(-2,-1)∪(1,2)`，所有 q 的 `b=B=O=T=log2`。
2. 等质量原子 0,1、`λ=1/4`：带为 `(-1,-1/2)∪(3/2,2)`，每侧只捕获一个原子；`T=B=O=(log2)/2`，三个非空子集各自 `b_J=(log2)/4`，对三个 q 均成立。
3. 同源、`λ=3/4`：`T=log2+log(4/3)=log(8/3)`；两个 singleton 系数各为 `(log2)/2+2^(−q)log(4/3)`，全源系数为 `(log2)/2+log(4/3)`，`B=O=log2+2^(1−q)log(4/3)`。从六个手算带区间得到这些式子。独立更窄有理 oracle 区间完全包含在存档相应区间中。

还可直接证明本任务的保守界 `O≤B≤T`：对每个 receiver，令 `π_J=μ_J(Q*)/F`；`q≥1` 给 `π_J^q≤π_J`，容量约束给 `Σ_J α_Jπ_J≤1`，gate 只会降低该和。积分即得 B≤T。q=1 时 singleton 代表选原位、权重全取 1，点态和恰为 1，因此 `B=O=T`。这些界不提供 q>1 的任意源统一正覆盖率。

## 二维：有限训练证书与理想采样的边界

独立脚本从保存 seed 重建实际浮点训练坐标，再将它们转为 exact binary Fractions；自行比较所有到达半径、整批加入同距离原子，独立计算 proposal density 和 score。对每个子集，枚举 winner cube faces、bbox 端点与相邻 cut 中点的 Cartesian product。随后**逐 receiver 直接累计**向下/向上整数权重，不使用主程序的差分数组或 prefix sums；全部 55,899 候选所得上下最大值与主程序完全相等。保存 lower-best gate 还用未取整的有理 score 直接求和，落在保存区间中。

闭矩形 arrangement 的端点与开区间中点已穷尽每维 gate 模式；端点可能同时包含相邻矩形，因此端点不能省略。所有 receiver 权重非负，差分数组的负 corner 更新只是线性记账，prefix 后得到正权重矩形求和；上下界方向由逐项取整和完整求和确定。本轮的独立直接枚举也核验了该方向。

理想连续 proposal 的体积变量 v 密度为 `[1/(2b)]min(1,(b/v)^2)`，来自等概率的 `bU,b/U`。均匀选 L∞ faces 及面内坐标给出正确 shell 体积均匀化。三个混合权重 `.5,.25,.25`、首分量均匀源点、后二分量按质量选源点，合成的物理空间密度恰为 `λ qcore`，与保存公式一致。第三项中的外部质量系数被质量尺度 `b=p_i/λ` 抵消，所以其项确实是 `min(1,(p_i/τ_i)^2)/8`。

取赢家边界的一个源点 i，则 `τ_i=4λr²=F/(M/λ)<1` 于 band 内，uniform-site 分量给 `qcore≥1/(4N)`；又 `M/λ≤2`，故 occupation score≤8N。源容量和 `π_J²≤π_J` 保证冻结 packing score∈[0,1]，训练分区同理。保存 train/validation seed 分离，训练代表和 allocations 固定后才用于验证，避免把训练优化目标当成无选择偏差估计。

但是 floating `sqrt`/坐标构造和 `random.Random` 的有限机器 law 不等于被数学认证的理想连续 law。Fraction 对已实现点的精确评价只能认证**有限训练函数**。报告正确把独立 held-out means/SE 称为估计，并把 Hoeffding radius 限为理想 iid proposal 下单行形式界；它不是机器抽样认证、不是跨行同时置信界、不是 ratio 的置信区间，也不是 continuum LP 上证书。本审计没有把未保存的 held-out 点或统计量升级为精确积分证书。

## 技能边界与残留问题

已读取当前 `math-l03-rational-and-interval-certificates/SKILL.md` 及 provenance/method/cube-interface。按其范围，只使用有理平方比较、有限 LP 弱对偶和明确的算术包含推导；没有声称已验证通用浮点区间 API。

没有发现需修改冻结数值文件的实质错误。主 helper 的一般输入防御不是此存档认证范围（列明 fixtures 都满足非空、正质量、匹配数组、正阈值）。有限来源、whole-site subset 列和所选 q 是本实验参数范围，不能被文字扩展为任意原子源或更细可分裂 source allocation 的完备数值证书。作者报告已经明确列明输入范围及 whole-site 对象。

剩余核心缺口是：在任意正源和增长维数中证明与 source payment 相匹配的统一 `B_t/T` 下界，并把它接回目标维数上界。本次审计通过不填补该缺口。


## Executable guard: audit_guard.py

```python
#!/usr/bin/env python3
"""Independent Round 74 certificate audit; never imports the production code.
Checks saved exact primal/dual witnesses and partitions, reconstructs 1D band
geometry from every contiguous source block, and evaluates coefficients with
100-digit Decimal as a diagnostic (not as interval arithmetic).
"""
from fractions import Fraction as F
from decimal import Decimal, localcontext
from pathlib import Path
import json, hashlib, itertools, time, random, math
ROOT=Path(__file__).parent

def dec(x):
    x=F(x); return Decimal(x.numerator)/Decimal(x.denominator)

def cert(lp,coeff,n):
    p={int(k):F(v) for k,v in lp['primal'].items()}; y=list(map(F,lp['dual']))
    assert all(v>=0 for v in p.values()) and all(v>=0 for v in y)
    loads=[sum(v for m,v in p.items() if m>>i&1) for i in range(n)]
    assert all(v<=1 for v in loads) and loads==list(map(F,lp['loads']))
    assert all(sum(y[i] for i in range(n) if m>>i&1)>=v for m,v in coeff.items())
    obj=sum(coeff[m]*v for m,v in p.items()); assert obj==sum(y)==F(lp['value'])
    slack=min(sum(y[i] for i in range(n) if m>>i&1)-v for m,v in coeff.items())
    assert slack==F(lp['min_dual_slack'])

def partitions(mask):
    if not mask:
        yield (); return
    first=mask&-mask
    rest=[i for i in range(mask.bit_length()) if mask>>i&1 and (1<<i)!=first]
    for selection in range(1<<len(rest)):
        block=first|sum(1<<v for j,v in enumerate(rest) if selection>>j&1)
        for tail in partitions(mask^block):yield (block,)+tail

def geometry(src):
    ys=list(map(F,src['y'])); ps=list(map(F,src['p'])); lam=F(src['lam']); n=len(ys)
    L=ys[0]-1/(2*lam); R=ys[-1]+1/(2*lam)
    base=sorted({L,R,*ys,*[(a+b)/2 for a in ys for b in ys]})
    out=[]; tests=0
    for l,h in zip(base,base[1:]):
        mid=(l+h)/2
        # Independent identity: M(x) equals the maximum over all contiguous
        # atom blocks of block mass / (2 max(|x-left|,|x-right|)).
        cand=[]
        for i in range(n):
            for j in range(i,n):
                a=ys[i] if abs(mid-ys[i])>=abs(mid-ys[j]) else ys[j]
                s=1 if mid>a else -1
                cand.append((sum(ps[i:j+1]),a,s))
        cuts={l,h}
        for (mass,a,s),(mass2,a2,s2) in itertools.combinations(cand,2):
            den=mass*s2-mass2*s
            if den:
                z=(mass*s2*a2-mass2*s*a)/den
                if l<z<h:cuts.add(z)
        cuts=sorted(cuts)
        for u,v in zip(cuts,cuts[1:]):
            x=(u+v)/2
            mass,a,s=max(cand,key=lambda z:z[0]/(2*z[2]*(x-z[1])))
            r=abs(x-a); ids=tuple(k for k,y in enumerate(ys) if abs(x-y)<=r)
            fullmass=sum(ps[k] for k in ids)
            # A maximizing block necessarily fills its radius completely.
            assert mass==fullmass
            tests+=1
            if s==1:u=max(u,a+mass/(4*lam)); v=min(v,a+mass/(2*lam))
            else:u=max(u,a-mass/(2*lam)); v=min(v,a-mass/(4*lam))
            if u<v:
                cell=(u,v,a,mass,ids)
                if out and out[-1][1]==u and out[-1][2:]==cell[2:]:out[-1]=(out[-1][0],v,*cell[2:])
                else:out.append(cell)
    return out,tests

def numeric_coeff(cells,ps,mask,q,c=None):
    total=Decimal(0)
    for u,v,a,mass,ids in cells:
        cap=sum(ps[i] for i in ids if mask>>i&1)
        if not cap:continue
        if c is None:lo,hi=sorted((abs(u-a),abs(v-a)))
        elif u>a:
            if c<a:continue
            lo=max(u-a,(c-a)/2); hi=v-a
        else:
            if c>a:continue
            lo=max(a-v,(a-c)/2); hi=a-u
        if hi<=lo:continue
        power=dec(cap/mass)**q.numerator
        if q.denominator==2:power=power.sqrt()
        total+=dec(mass)/2*power*dec(hi/lo).ln()
    return total

def draw2(src,S,seed):
    """Recreate the registered floating proposal; independently evaluate it.
    This certifies realized training functionals, never its continuum law.
    """
    ys=[tuple(map(F,y)) for y in src['y']];ps=list(map(F,src['p']));lam=F(src['lam']);n=len(ps);rng=random.Random(seed);cum=[];acc=0.
    for p in ps:acc+=float(p);cum.append(acc)
    out=[]
    for _ in range(S):
        z=rng.random();component=0 if z<.5 else 1 if z<.75 else 2
        if component==0:i=rng.randrange(n)
        else:
            z=rng.random();i=next((j for j,p in enumerate(cum) if z<p),n-1)
        base=float(1/lam)*(float(ps[i]) if component==2 else 1.)
        U=max(rng.random(),math.nextafter(0.,1.));v=base*U if rng.randrange(2)==0 else base/U
        theta=[rng.uniform(-1,1),rng.uniform(-1,1)];theta[rng.randrange(2)]=rng.choice([-1,1]);radius=.5*math.sqrt(v)
        x=tuple(F(float(ys[i][k])+radius*theta[k]) for k in range(2))
        distances=[max(abs(x[k]-y[k]) for k in range(2)) for y in ys]
        candidates=[]
        for r in sorted(set(distances)):
            ids=tuple(j for j,z in enumerate(distances) if z<=r);mass=sum(ps[j] for j in ids)
            candidates.append((mass/(4*r*r),r,ids,mass))
        M,r,ids,mass=max(candidates,key=lambda z:z[0])
        density=F(0)
        for p,z in zip(ps,distances):
            tau=4*z*z*lam
            shape=F(1) if tau<=1 else 1/(tau*tau)
            shape_p=F(1) if tau<=p else p*p/(tau*tau)
            density+=F(1,4*n)*shape+p*shape/8+shape_p/8
        score=M/lam/density if lam<M<=2*lam else F(0)
        assert 0<=score<=8*n
        out.append((x,r,ids,mass,score))
    return out

def finite_coeff_check(row):
    src=row['source']; n=len(src['p']);ps=list(map(F,src['p']));ys=[tuple(map(F,y)) for y in src['y']];S=row['training_samples'];ds=draw2(src,S,row['training_seed']);band=[z for z in ds if z[4]];Q=1<<90;evals=0
    for m,z in row['coefficients'].items():
        m=int(m); sites=[ys[i] for i in range(n) if m>>i&1];axes=[]
        for k in range(2):
            a=min(y[k] for y in sites);b=max(y[k] for y in sites)
            edges=sorted({a,b}|{c for x,r,ids,mass,score in band for c in (x[k]-r,x[k]+r) if a<=c<=b})
            axes.append(sorted(set(edges)|{(a+b)/2 for a,b in zip(edges,edges[1:])}))
        weights=[]
        for x,r,ids,mass,score in band:
            cap=sum(ps[i] for i in ids if m>>i&1);weight=score*(cap/mass)**2/S
            L=weight.numerator*Q//weight.denominator;U=-(-weight.numerator*Q//weight.denominator)
            weights.append((x,r,L,U))
        maxL=maxU=0
        # Direct Cartesian summation, no difference array or prefix sum.
        for c in itertools.product(*axes):
            low=upp=0
            for x,r,L,U in weights:
                if all(abs(x[k]-c[k])<=r for k in range(2)):low+=L;upp+=U
            maxL=max(maxL,low);maxU=max(maxU,upp);evals+=1
        assert F(maxL,Q)==F(z['lower']) and F(maxU,Q)==F(z['upper'])
        rep=tuple(map(F,row['selected_representatives'][str(m)]))
        direct=sum(score*(sum(ps[i] for i in ids if m>>i&1)/mass)**2/S for x,r,ids,mass,score in band if all(abs(x[k]-rep[k])<=r for k in range(2)))
        assert F(z['lower'])<=direct<=F(z['upper'])
    return evals

def oracle_log(r):
    # No production cache, dyadic rounding or production term count.
    z=(F(r)-1)/(F(r)+1);K=80
    lower=sum((2*z**(2*j+1)/F(2*j+1) for j in range(K-1,-1,-1)),F(0))
    upper=lower+2*z**(2*K+1)/((2*K+1)*(1-z*z))
    return lower,upper

def oracle_smallcases(rows):
    L2,U2=oracle_log(2);L4,U4=oracle_log(F(4,3));checked=0
    for row in rows[:3]:
        label=row['source']['label']
        for ex in row['exponents']:
            q=F(ex['q'])
            if label=='single_atom':T=(L2,U2);co={1:T};B=T
            elif label=='equal_two_low':
                T=(L2/2,U2/2);co={m:(L2/4,U2/4) for m in (1,2,3)};B=T
            else:
                T=(L2+L4,U2+U4)
                power=F(1,2)**q.numerator
                if q.denominator==2:
                    a,b=F(0),F(1)
                    for _ in range(150):
                        z=(a+b)/2
                        if z*z<=power:a=z
                        else:b=z
                else:a=b=power
                singleton=(L2/2+a*L4,U2/2+b*U4)
                co={1:singleton,2:singleton,3:(L2/2+L4,U2/2+U4)}
                B=tuple(2*z for z in singleton)
            assert F(ex['T']['lower'])<=T[0]<=T[1]<=F(ex['T']['upper'])
            for m,(a,b) in co.items():
                archived=ex['coefficients'][str(m)]
                assert F(archived['lower'])<=a<=b<=F(archived['upper'])
                checked+=1
            for target in ('B','O'):
                assert F(ex[target]['lower'])<=B[0]<=B[1]<=F(ex[target]['upper'])
    return checked

def main():
    start=time.monotonic();d=json.loads((ROOT/'dual_results.json').read_text()); count=0; tests=0; widths=[];finite_evals=0;oracles=oracle_smallcases(d['cases'])
    with localcontext() as ctx:
        ctx.prec=100
        for row in d['cases']:
            src=row['source']; n=len(src['p']);ps=list(map(F,src['p']))
            cells,checks=geometry(src);tests+=checks
            stored=[(F(u),F(v),F(a),F(m),tuple(ids)) for u,v,a,m,ids in row['band_cells']]
            assert cells==stored,(src['label'],cells,stored)
            full=(1<<n)-1; T=numeric_coeff(cells,ps,full,F(1))
            for ex in row['exponents']:
                q=F(ex['q']);coeff=ex['coefficients'];lo={int(m):F(z['lower']) for m,z in coeff.items()};hi={int(m):F(z['upper']) for m,z in coeff.items()}
                cert(ex['lower_LP'],lo,n);cert(ex['upper_LP'],hi,n);count+=2
                closed=lambda m: ((m//(m&-m))&(1+m//(m&-m)))==0
                cert(ex['closed_subset_lower_LP'],{m:v if closed(m) else F(0) for m,v in lo.items()},n)
                cert(ex['closed_subset_upper_LP'],{m:v if closed(m) else F(0) for m,v in hi.items()},n);count+=2
                assert dec(ex['T']['lower'])<=T<=dec(ex['T']['upper'])
                cuts={a for u,v,a,f,ids in cells}|{2*z-a for u,v,a,f,ids in cells for z in (u,v)}
                ys=list(map(F,src['y']))
                for m,z in coeff.items():
                    m=int(m);sites=[ys[i] for i in range(n) if m>>i&1];a,b=min(sites),max(sites)
                    candidates={a,b}|{c for c in cuts if a<=c<=b}
                    ref=max(numeric_coeff(cells,ps,m,q,c) for c in candidates)
                    assert dec(lo[m])<=ref<=dec(hi[m]),(src['label'],q,m)
                    chosen=numeric_coeff(cells,ps,m,q,F(z['representative']))
                    assert dec(lo[m])<=chosen<=dec(hi[m])
                    widths.append(hi[m]-lo[m])
                plist=list(partitions(full))
                OL=max(sum(lo[m] for m in p) for p in plist); OU=max(sum(hi[m] for m in p) for p in plist)
                assert OL==F(ex['O']['lower']) and OU==F(ex['O']['upper'])
                for label,loexpect,hiexpect in [('B',F(ex['lower_LP']['value']),F(ex['upper_LP']['value']))]:
                    assert F(ex[label]['lower'])==loexpect and F(ex[label]['upper'])==hiexpect
        for row in d['finite_2d']:
            finite_evals+=finite_coeff_check(row)
            n=len(row['source']['p']);lo={int(m):F(z['lower']) for m,z in row['coefficients'].items()};hi={int(m):F(z['upper']) for m,z in row['coefficients'].items()}
            cert(row['lower_LP'],lo,n);cert(row['upper_LP'],hi,n);count+=2
            pp=list(partitions((1<<n)-1))
            assert max(sum(lo[m] for m in p) for p in pp)==F(row['finite_training_O']['lower'])
            assert max(sum(hi[m] for m in p) for p in pp)==F(row['finite_training_O']['upper'])
    print(json.dumps({'status':'PASS','exact_LP_witnesses':count,'independent_contiguous_block_cells_checked':tests,'coefficient_diagnostic_count':len(widths),'finite2d_direct_candidate_evaluations':finite_evals,'independent_closed_form_coefficient_checks':oracles,'maximum_enclosure_width':str(max(widths)),'seconds':time.monotonic()-start,'hashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [ROOT/'dual_probe.py',ROOT/'dual_results.json']}},indent=2))
if __name__=='__main__':main()
```


## Executable guard: entropy_guard.py

```python
#!/usr/bin/env python3
"""R74 parent guard: finite actual winners, exact Gibbs ratios, full-band checks.
Analytic general results are proved in parent_entropy.md, not by this guard.
"""
from fractions import Fraction as F
from functools import lru_cache
from itertools import product
from pathlib import Path
import json, math
import dual_probe as d

@lru_cache(None)
def logiv(x):
    assert x>0
    if x<1:
        lo,hi=logiv(1/x);return -hi,-lo
    k=0
    while x>2:x/=2;k+=1
    lo,hi=d.log_interval(x);a,b=d.log_interval(F(2));return lo+k*a,hi+k*b

def expminus(a):
    assert 0<=a<=1
    term=F(1);s=F(1)
    # alternating partial sums of e^-a: odd lower, even upper
    lo=None
    for k in range(1,41):
        term*= -a/k;s+=term
        if k==39:lo=s
    assert lo<=s
    return lo,s

def expminusiv(a):
    return expminus(a[1])[0],expminus(a[0])[1]

def actual_rows(points,masses,receivers,lam):
    rows=[];n=len(points[0])
    for x in receivers:
        events={}
        for i,y in enumerate(points):
            r=max(abs(a-b) for a,b in zip(x,y));assert r
            events.setdefault(r,[]).append(i)
        f=F(0);ids=[];best=F(0);saved=None
        for r,block in sorted(events.items()):
            ids+=block;f+=sum(masses[i] for i in block);v=(2*r)**n
            if f/v>best:best=f/v;saved=(r,tuple(ids),f)
        if lam<best<=2*lam:rows.append((x,*saved,best))
    return rows

def coeff(rows,points,masses,q):
    n=len(points[0]);N=len(points);out={}
    for mask in range(1,1<<N):
        selected=[i for i in range(N) if mask>>i&1]
        lo=[min(points[i][k] for i in selected) for k in range(n)]
        hi=[max(points[i][k] for i in selected) for k in range(n)]
        # A maximum positive weighted closed-box depth is attained at
        # lower endpoints of the intersection of its positive boxes.
        axes=[sorted({lo[k]}|{x[k]-r for x,r,ids,f,M in rows if lo[k]<=x[k]-r<=hi[k]}) for k in range(n)]
        best=F(0)
        for c in product(*axes):
            score=F(0)
            for x,r,ids,f,M in rows:
                if all(abs(x[k]-c[k])<=r for k in range(n)):
                    a=sum((masses[i] for i in ids if mask>>i&1),F(0));score+=M*(a/f)**q
            best=max(best,score)
        out[mask]=best
    return out

def main():
    out={'scope':'Exact finite actual-receiver guards plus certified full 1D band regressions; no universal bound.','counts':{}}
    count=0;rows_total=0;invariance=[];gibbs=0;chain=0
    for n in [1,2,3,4]:
        points=[tuple([F(0)]*n),tuple([F(1)]*n)]
        masses=[F(1,2),F(1,2)]
        receivers=[tuple(F(j,12)+F(k,120) for k in range(n)) for j in range(-12,25) if j not in [0,12]]
        for lam in [F(1,4),F(3,4),F(3,2)]:
            rows=actual_rows(points,masses,receivers,lam);rows_total+=len(rows)
            if not rows:continue
            T=sum(z[-1] for z in rows);B=[];O=[]
            for q in [1,2,3]:
                c=coeff(rows,points,masses,q);b=d.simplex(c,2)['value'];o=d.partition_opt(c,2)[0];B.append(b);O.append(o)
                finepoints=[points[0],points[0],points[1],points[1]];finemass=[F(1,8),F(3,8),F(1,6),F(1,3)]
                finerows=actual_rows(finepoints,finemass,receivers,lam)
                cc=coeff(finerows,finepoints,finemass,q);bb=d.simplex(cc,4)['value'];oo=d.partition_opt(cc,4)[0]
                assert b==bb and o==oo and o<=b<=q*o and b<=T
                invariance.append({'n':n,'lambda':str(lam),'q':q,'B':str(b),'O':str(o)})
                count+=1
            assert B[0]==O[0]==T and B[0]>=B[1]>=B[2] and B[1]**2<=B[0]*B[2]
            # Actual singleton joint posterior, deliberately subprobability
            # capacity 3/4: coverage loss must remain in Gibbs normalization.
            eta={};pi={}
            for j,(x,r,ids,f,M) in enumerate(rows):
                for i in ids:
                    pi[j,i]=masses[i]/f;eta[j,i]=F(3,4)*(M/T)*pi[j,i]
            s=sum(eta.values());assert s==F(3,4)
            Q={k:v/s for k,v in eta.items()}
            for t in [0,1,2,4]:
                Z=sum(Q[k]*pi[k]**t for k in Q);tilt={k:Q[k]*pi[k]**t/Z for k in Q}
                assert sum(tilt.values())==1
                P={k:Q[k]*F(2*k[0]+k[1]+1) for k in Q};norm=sum(P.values());P={k:v/norm for k,v in P.items()}
                PX={};QX={}
                for (j,i),v in P.items():PX[j]=PX.get(j,F(0))+v
                for (j,i),v in Q.items():QX[j]=QX.get(j,F(0))+v
                for k in Q:
                    assert (P[k]/tilt[k])/(P[k]/Q[k])==Z/pi[k]**t;gibbs+=1
                    j,i=k
                    assert P[k]/Q[k]==(PX[j]/QX[j])*((P[k]/PX[j])/(Q[k]/QX[j]));chain+=1
    # Full Lebesgue two-atom formula, with directed rational log/exp bounds.
    l2=logiv(F(2));lp=logiv(F(4,3));TT=(l2[0]+lp[0],l2[1]+lp[1]);E=(l2[0]*lp[0]/TT[1],l2[1]*lp[1]/TT[0])
    counter=[]
    for C in [1,4,16,64,256,1024]:
        t=F(1,64*C);power=expminusiv((t*l2[0],t*l2[1]))
        score=(l2[0]+power[0]*lp[0],l2[1]+power[1]*lp[1]);ratio=(score[0]/TT[1],score[1]/TT[0])
        gaussian=expminus(C*t*t)
        assert ratio[1]<gaussian[0]
        derivative=((1-ratio[1])/t,(1-ratio[0])/t)
        counter.append({'C':C,'t':str(t),'B_over_T':[str(z) for z in ratio],'exp_minus_Ct2':[str(z) for z in gaussian],'loss_slope':[float(z) for z in derivative]})
    data=json.loads(Path(__file__).with_name('dual_results.json').read_text());strict_holder=0;compatible_holder=0;checks=0
    for case in data['cases']:
        rows=case['exponents'];b=[(F(r['B']['lower']),F(r['B']['upper'])) for r in rows]
        assert b[0][1]>=b[1][0] and b[1][1]>=b[2][0]
        if b[1][1]**2<=b[0][0]*b[2][0]:strict_holder+=1
        else:
            assert b[1][0]**2<=b[0][1]*b[2][1];compatible_holder+=1
        checks+=1
    out['counts']={'finite_label_invariance_LP_and_partition_cases':count,'actual_band_receiver_occurrences':rows_total,'exact_Gibbs_density_ratios':gibbs,'exact_joint_chain_density_ratios':chain,'quadratic_loss_strict_fullband_counter_guards':len(counter),'fullband_interpolation_cases':checks,'certified_Holder_inequalities':strict_holder,'enclosure_compatible_Holder_cases_not_strictly_decided':compatible_holder}
    out['finite_cases']=invariance;out['two_atom_entropy_interval']=[str(z) for z in E];out['quadratic_counters']=counter
    Path(__file__).with_name('entropy_results.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n')
    print(json.dumps(out['counts'],sort_keys=True))
if __name__=='__main__':main()
```
