#!/usr/bin/env python3
"""Round 74: actual 1D winner-band packet coefficients and source-capacity LP.
Exact rational geometry; certified rational log/power enclosures; rational LP.
Every numerical certificate is for its listed finite source and threshold.
"""
from fractions import Fraction as F
from functools import lru_cache
from pathlib import Path
import argparse,json,math,time,hashlib

Q=1<<90

def down(x): return F(x.numerator*Q//x.denominator,Q)
def up(x): return F(-(-x.numerator*Q//x.denominator),Q)

def pack(label,positions,weights,lam):
    merged={}
    for x,w in zip(positions,weights):
        x=F(x);w=F(w);assert w>0;merged[x]=merged.get(x,F(0))+w
    ys=sorted(merged);W=sum(merged.values());ps=[merged[y]/W for y in ys]
    return dict(label=label,y=ys,p=ps,lam=F(lam),raw_mass=W)

def winner(src,x):
    events={}
    for i,y in enumerate(src['y']):
        r=abs(x-y)
        if r==0: raise ValueError('null-set source receiver')
        events.setdefault(r,[]).append(i)
    mass=F(0);capture=[];best=F(0);ans=None
    for r,ids in sorted(events.items()):
        mass+=sum(src['p'][i] for i in ids);capture+=ids
        M=mass/(2*r)
        if M>best:
            best=M;ans=(r,tuple(sorted(capture)),mass)
    r,ids,mass=ans
    # The anchor is a site at the selected cube boundary; tied boundaries may
    # have two anchors only on the excluded finite distance-order boundaries.
    anchors=[src['y'][i] for i in ids if abs(x-src['y'][i])==r]
    return best,r,ids,mass,anchors[0]

def band_cells(src):
    ys=src['y'];ps=src['p'];lam=src['lam'];N=len(ys)
    left=min(ys)-1/(2*lam);right=max(ys)+1/(2*lam)
    cuts={left,right,*ys}
    cuts.update((a+b)/2 for a in ys for b in ys if left<(a+b)/2<right)
    cuts=sorted(cuts);allcells=[];comparison_count=0
    for lo,hi in zip(cuts,cuts[1:]):
        x=(lo+hi)/2;order=sorted(range(N),key=lambda i:abs(x-ys[i]));events=[];mass=F(0)
        for i in order:
            mass+=ps[i];sign=1 if x>ys[i] else -1
            events.append((mass,ys[i],sign))
        local={lo,hi}
        for j,(a,b,s) in enumerate(events):
            for c,d,t in events[:j]:
                den=a*t-c*s
                if den:
                    cross=(a*t*d-c*s*b)/den
                    if lo<cross<hi:local.add(cross)
        local=sorted(local)
        for u,v in zip(local,local[1:]):
            m,r,ids,mass,anchor=winner(src,(u+v)/2)
            # Pair comparisons are linear on this cell. Explicit guard at
            # two rational interior points verifies the retained capture.
            for z in [(2*u+v)/3,(u+2*v)/3]:
                mm,rr,jj,ff,aa=winner(src,z);assert jj==ids and ff==mass and aa==anchor
                comparison_count+=1
            side=1 if (u+v)/2>anchor else -1
            if side>0:bu=max(u,anchor+mass/(4*lam));bv=min(v,anchor+mass/(2*lam))
            else:bu=max(u,anchor-mass/(2*lam));bv=min(v,anchor-mass/(4*lam))
            if bu<bv:
                cell=(bu,bv,anchor,mass,ids)
                if allcells and allcells[-1][1]==bu and allcells[-1][2:]==cell[2:]:
                    allcells[-1]=(allcells[-1][0],bv,*cell[2:])
                else:allcells.append(cell)
    assert all(u<v and (u-a)*(v-a)>0 for u,v,a,f,ids in allcells)
    return allcells,comparison_count

@lru_cache(None)
def log_interval(r):
    assert 1<=r<=2
    if r==1:return F(0),F(0)
    z=(r-1)/(r+1);z2=z*z;term=z;total=F(0);terms=45
    for k in range(terms):total+=2*term/(2*k+1);term*=z2
    residual=2*term/((2*terms+1)*(1-z2))
    return down(total),up(total+residual)

@lru_cache(None)
def power_interval(pi,q):
    assert 0<=pi<=1
    if q.denominator==1:return pi**q.numerator,pi**q.numerator
    assert q.denominator==2
    target=pi**q.numerator;lo=F(0);hi=F(1)
    for _ in range(100):
        mid=(lo+hi)/2
        if mid*mid<=target:lo=mid
        else:hi=mid
    assert lo*lo<=target<=hi*hi
    return down(lo),up(hi)

def cell_log(cell,c=None):
    u,v,a,mass,ids=cell
    if c is None:lo,hi=sorted([abs(u-a),abs(v-a)])
    elif u>a:
        if c<a:return F(0),F(0)
        lo=max(u-a,(c-a)/2);hi=v-a
    else:
        if c>a:return F(0),F(0)
        lo=max(a-v,(a-c)/2);hi=a-u
    if hi<=lo:return F(0),F(0)
    assert 0<lo<=hi and hi/lo<=2
    return log_interval(hi/lo)

def coefficient(cells,src,mask,q,c=None):
    lower=F(0);upper=F(0)
    for cell in cells:
        u,v,a,mass,ids=cell
        captured=sum((src['p'][i] for i in ids if mask>>i&1),F(0))
        if not captured:continue
        pl,pu=power_interval(captured/mass,q);ll,lu=cell_log(cell,c)
        lower+=mass*pl*ll/2;upper+=mass*pu*lu/2
    return down(lower),up(upper)

def all_coefficients(cells,src,q):
    N=len(src['y']);cuts={a for u,v,a,f,ids in cells}
    cuts.update(2*z-a for u,v,a,f,ids in cells for z in [u,v])
    lower={};upper={};reps={};evaluations=0
    for mask in range(1,1<<N):
        sites=[src['y'][i] for i in range(N) if mask>>i&1];lo=min(sites);hi=max(sites)
        candidates=sorted({lo,hi}|{c for c in cuts if lo<=c<=hi});bestlo=F(-1);besthi=F(0);rep=None
        for c in candidates:
            ll,uu=coefficient(cells,src,mask,q,c);evaluations+=1
            if ll>bestlo:bestlo=ll;rep=c
            besthi=max(besthi,uu)
        lower[mask]=bestlo;upper[mask]=besthi;reps[mask]=rep
    return lower,upper,reps,evaluations

def simplex(coeff,N):
    """Bland-rule exact primal simplex; objective and all entries Fraction."""
    masks=list(range(1,1<<N));K=len(masks);total=K+N
    rows=[[F(bool(mask>>i&1)) for mask in masks]+[F(j==i) for j in range(N)]+[F(1)] for i in range(N)]
    reduced=[coeff[m] for m in masks]+[F(0)]*N;basis=list(range(K,total));value=F(0);pivots=0
    while True:
        entering=next((j for j,z in enumerate(reduced) if z>0),None)
        if entering is None:break
        eligible=[i for i,row in enumerate(rows) if row[entering]>0]
        assert eligible,'bounded capacity LP cannot be unbounded'
        leaving=min(eligible,key=lambda i:(rows[i][-1]/rows[i][entering],basis[i]));row=rows[leaving];pivot=row[entering];row=[z/pivot for z in row];rows[leaving]=row
        for i in range(N):
            if i!=leaving and rows[i][entering]:
                factor=rows[i][entering];rows[i]=[a-factor*b for a,b in zip(rows[i],row)]
        factor=reduced[entering];value+=factor*row[-1];reduced=[a-factor*b for a,b in zip(reduced,row[:-1])];basis[leaving]=entering;pivots+=1
        assert pivots<10000
    primal={m:F(0) for m in masks}
    for i,b in enumerate(basis):
        if b<K:primal[masks[b]]=rows[i][-1]
    dual=[-reduced[K+i] for i in range(N)]
    assert all(z>=0 for z in primal.values()) and all(z>=0 for z in dual)
    loads=[sum(primal[m] for m in masks if m>>i&1) for i in range(N)]
    assert all(z<=1 for z in loads)
    margins={m:sum(dual[i] for i in range(N) if m>>i&1)-coeff[m] for m in masks}
    assert all(z>=0 for z in margins.values())
    assert sum(coeff[m]*primal[m] for m in masks)==value==sum(dual)
    return dict(value=value,primal={m:z for m,z in primal.items() if z},dual=dual,loads=loads,min_dual_slack=min(margins.values()),pivots=pivots)

def partition_opt(coeff,N):
    dp={0:(F(0),[])}
    for mask in range(1,1<<N):
        first=mask&-mask;sub=mask;best=(F(-1),[])
        while sub:
            if sub&first:
                value=coeff[sub]+dp[mask^sub][0]
                if value>best[0]:best=(value,dp[mask^sub][1]+[sub])
            sub=(sub-1)&mask
        dp[mask]=best
    return dp[(1<<N)-1]

def interval_record(pair):return dict(lower=str(pair[0]),upper=str(pair[1]),lower_decimal=float(pair[0]),upper_decimal=float(pair[1]),width_decimal=float(pair[1]-pair[0]))
def clean(obj):
    if isinstance(obj,F):return str(obj)
    if isinstance(obj,dict):return {str(k):clean(v) for k,v in obj.items()}
    if isinstance(obj,(list,tuple)):return [clean(v) for v in obj]
    return obj

def fixtures(pilot=False):
    ans=[]
    def add(label,y,w,lam):ans.append(pack(label,y,w,lam))
    add('single_atom',[0],[1],F(1,4))
    add('equal_two_low',[0,1],[1,1],F(1,4))
    add('equal_two_peak',[0,1],[1,1],F(3,4))
    add('unequal_two',[0,1],[1,7],F(1,4))
    add('grid4',[F(j,3) for j in range(4)],[1]*4,F(1,4))
    add('unequal4',[0,F(1,8),1,3],[1,3,2,7],F(1,4))
    if pilot:return ans
    for N in [6,8]:add('grid'+str(N),[F(j,N-1) for j in range(N)],[1]*N,F(1,4))
    for gap in [4,20]:add('three_groups2_gap'+str(gap),[g*gap+F(j,64) for g in range(3) for j in range(2)],[1]*6,F(1,12))
    add('four_micro_pairs',[g*4+F(j,4096) for g in range(4) for j in range(2)],[1]*8,F(1,16))
    add('heterogeneous_micro_pairs',[g*4+F(j,4096) for g in range(4) for j in range(2)],[1,1,2,2,4,4,8,8],F(1,16))
    add('deep_hierarchy8',[sum(F(1,8**k) for k in range(3) if j>>k&1) for j in range(8)],[1]*8,F(1,4))
    add('unequal_deep_hierarchy8',[sum(F(1,8**k) for k in range(3) if j>>k&1) for j in range(8)],[1,2,4,8,16,32,64,128],F(1,4))
    add('one_heavy_seven_light',list(range(8)),[1]*7+[127],F(1,8))
    add('alternating_weights8',[F(j,7) for j in range(8)],[1,32]*4,F(1,4))
    return ans


def finite_winner_2d(src,x):
    distances=[max(abs(x[k]-y[k]) for k in range(2)) for y in src['y']]
    assert all(distances)
    groups={}
    for i,r in enumerate(distances):groups.setdefault(r,[]).append(i)
    best=F(0);mass=F(0);ids=[];answer=None
    for r,block in sorted(groups.items()):
        mass+=sum(src['p'][i] for i in block);ids+=block;M=mass/(4*r*r)
        if M>best:best=M;answer=(r,tuple(ids),mass)
    r,ids,mass=answer;V=1/src['lam'];volumes=[4*r*r/V for r in distances];N=len(src['p'])
    density=sum((min(F(1),1/v**2)/(4*N)+a*min(F(1),1/v**2)/8+min(F(1),(a/v)**2)/8 for a,v in zip(src['p'],volumes)),F(0))
    band=src['lam']<best<=2*src['lam'];score=best/src['lam']/density if band else F(0)
    assert score<=8*N
    return dict(x=x,radius=r,ids=ids,mass=mass,M=best,band=band,score=score)

def finite_draws_2d(src,S,seed):
    import random
    rng=random.Random(seed);N=len(src['p']);out=[];cum=[];total=0.
    for a in src['p']:total+=float(a);cum.append(total)
    for _ in range(S):
        z=rng.random();component=0 if z<.5 else 1 if z<.75 else 2
        if component==0:center=rng.randrange(N)
        else:
            z=rng.random();center=next((i for i,c in enumerate(cum) if z<c),N-1)
        b=float(1/src['lam'])*(float(src['p'][center]) if component==2 else 1.)
        U=max(rng.random(),math.nextafter(0.,1.));volume=b*U if rng.randrange(2)==0 else b/U
        theta=[rng.uniform(-1,1),rng.uniform(-1,1)];theta[rng.randrange(2)]=rng.choice([-1,1]);radius=.5*math.sqrt(volume)
        x=tuple(F(float(src['y'][center][k])+radius*theta[k]) for k in range(2))
        out.append(finite_winner_2d(src,x))
    return out

def finite_arrangement_coefficients(src,draws):
    import bisect
    N=len(src['p']);S=len(draws);band=[d for d in draws if d['band']];lower={};upper={};reps={};evaluations=0
    for mask in range(1,1<<N):
        sites=[src['y'][i] for i in range(N) if mask>>i&1];axes=[]
        for k in range(2):
            lo=min(y[k] for y in sites);hi=max(y[k] for y in sites);cuts={lo,hi}
            for d in band:cuts.update(z for z in [d['x'][k]-d['radius'],d['x'][k]+d['radius']] if lo<=z<=hi)
            edges=sorted(cuts);axes.append(sorted(set(edges+[(a+b)/2 for a,b in zip(edges,edges[1:])])))
        nx,ny=map(len,axes);L=[[0]*(ny+1) for _ in range(nx+1)];U=[[0]*(ny+1) for _ in range(nx+1)]
        for d in band:
            captured=sum((src['p'][i] for i in d['ids'] if mask>>i&1),F(0));weight=d['score']*(captured/d['mass'])**2/S
            wl=down(weight);wu=up(weight);li=wl.numerator*(Q//wl.denominator);ui=wu.numerator*(Q//wu.denominator)
            l=[bisect.bisect_left(axes[k],d['x'][k]-d['radius']) for k in range(2)];h=[bisect.bisect_right(axes[k],d['x'][k]+d['radius']) for k in range(2)]
            for A,w in [(L,li),(U,ui)]:
                A[l[0]][l[1]]+=w;A[h[0]][l[1]]-=w;A[l[0]][h[1]]-=w;A[h[0]][h[1]]+=w
        bestlo=-1;besthi=0;rep=None
        for i in range(nx):
            for j in range(ny):
                for A in [L,U]:
                    if i:A[i][j]+=A[i-1][j]
                    if j:A[i][j]+=A[i][j-1]
                    if i and j:A[i][j]-=A[i-1][j-1]
                if L[i][j]>bestlo:bestlo=L[i][j];rep=(axes[0][i],axes[1][j])
                besthi=max(besthi,U[i][j])
        lower[mask]=F(bestlo,Q);upper[mask]=F(besthi,Q);reps[mask]=rep;evaluations+=nx*ny
        # Verify lower-optimal arrangement gate directly with rational geometry.
        direct=sum((d['score']*(sum((src['p'][i] for i in d['ids'] if mask>>i&1),F(0))/d['mass'])**2/S for d in draws if max(abs(d['x'][k]-rep[k]) for k in range(2))<=d['radius']),F(0))
        assert lower[mask]<=direct<=upper[mask]
    return lower,upper,reps,evaluations

def finite_stats(values,bound):
    n=len(values);floats=[float(z) for z in values];mean=sum(floats)/n
    se=math.sqrt(sum((z-mean)**2 for z in floats)/(n-1)/n)
    return dict(mean=mean,sample_SE=se,maximum=max(floats),ideal_bound=bound,ideal_Hoeffding95_radius=bound*math.sqrt(math.log(40)/(2*n)))

def finite_validation(src,draws,alpha,reps,blocks):
    packed=[];partition=[];traffic=[]
    for d in draws:
        score=F(0);part=F(0)
        for mask,w in alpha.items():
            c=reps[mask]
            if max(abs(d['x'][k]-c[k]) for k in range(2))<=d['radius']:
                captured=sum((src['p'][i] for i in d['ids'] if mask>>i&1),F(0));score+=w*(captured/d['mass'])**2
        for mask in blocks:
            c=reps[mask]
            if max(abs(d['x'][k]-c[k]) for k in range(2))<=d['radius']:
                captured=sum((src['p'][i] for i in d['ids'] if mask>>i&1),F(0));part+=(captured/d['mass'])**2
        assert 0<=score<=1 and 0<=part<=1
        packed.append(d['score']*score);partition.append(d['score']*part);traffic.append(d['score'])
    bound=8*len(src['p'])
    return dict(packing=finite_stats(packed,bound),partition=finite_stats(partition,bound),band=finite_stats(traffic,bound),sample_B_lower_route_over_T=sum(float(z) for z in packed)/sum(float(z) for z in traffic) if any(traffic) else None)

def finite_2d_stage(pilot=False):
    fixtures=[('vertices4',[(-1,-1),(-1,1),(1,-1),(1,1)],[1]*4,F(1,32)),('heterogeneous6',[(-2,-1),(-2,1),(0,F(-1,2)),(0,F(1,2)),(2,-1),(2,1)],[1,1,2,2,4,4],F(1,32)),('micro_pairs8',[(g*4+F(j,4096),F(g%2)) for g in range(4) for j in range(2)],[1]*8,F(1,32))]
    if pilot:fixtures=fixtures[:1]
    rows=[]
    for sid,(label,ys,ps,lam) in enumerate(fixtures):
        mass=sum(ps);src=dict(label=label,y=[tuple(map(F,y)) for y in ys],p=[F(p,mass) for p in ps],lam=lam)
        trainseed=741000+sid;training=finite_draws_2d(src,64,trainseed);bl,bu,reps,evals=finite_arrangement_coefficients(src,training);lpL=simplex(bl,len(ps));lpU=simplex(bu,len(ps));O,blocks=partition_opt(bl,len(ps));OU,_=partition_opt(bu,len(ps));validation=[]
        for seed in [742000+10*sid,742001+10*sid]:
            validation.append(dict(seed=seed,samples=1024,**finite_validation(src,finite_draws_2d(src,1024,seed),lpL['primal'],reps,blocks)))
        rows.append(dict(source=src,training_seed=trainseed,training_samples=64,training_band=finite_stats([d['score'] for d in training],8*len(ps)),q='2',candidate_evaluations=evals,finite_training_B=interval_record((lpL['value'],lpU['value'])),finite_training_O=interval_record((O,OU)),lower_LP=lpL,upper_LP=lpU,selected_representatives=reps,selected_partition=blocks,coefficients={m:dict(lower=bl[m],upper=bu[m]) for m in bl},validation=validation,scope='Exact bounds for the finite empirical importance functional; trained feasible columns held fixed on independent full-space draws. No continuum LP upper certificate.'))
        print('finite2d',label,'N',len(ps),'arrangement candidates',evals,flush=True)
    return rows

def main():
    start=time.monotonic();ap=argparse.ArgumentParser();ap.add_argument('--pilot',action='store_true');args=ap.parse_args();records=[]
    for src in fixtures(args.pilot):
        cells,checks=band_cells(src);N=len(src['y']);full=(1<<N)-1
        T=coefficient(cells,src,full,F(1));assert T[0]>0
        weak_length=F(0)
        # Exact weak volume from the R44 subset interval representation.
        boxes=[]
        for mask in range(1,1<<N):
            sites=[src['y'][i] for i in range(N) if mask>>i&1];mass=sum(src['p'][i] for i in range(N) if mask>>i&1)
            lo=max(sites)-mass/(2*src['lam']);hi=min(sites)+mass/(2*src['lam'])
            if lo<hi:boxes.append((lo,hi))
        cuts=sorted({z for b in boxes for z in b})
        for lo,hi in zip(cuts,cuts[1:]):
            if any(a<(lo+hi)/2<b for a,b in boxes):weak_length+=hi-lo
        if src['label']=='single_atom':
            assert max(T[0],log_interval(F(2))[0])<=min(T[1],log_interval(F(2))[1])
        if src['label']=='equal_two_low':
            assert src['lam']*weak_length==F(3,4)
            ll,uu=log_interval(F(2));assert max(T[0],ll/2)<=min(T[1],uu/2)
        if src['label']=='equal_two_peak':
            assert src['lam']*weak_length==F(5,4)
            l1,u1=log_interval(F(4,3));l2,u2=log_interval(F(3,2));assert max(T[0],2*l1+l2)<=min(T[1],2*u1+u2)
        exponents=[]
        for q in [F(1),F(3,2),F(2)]:
            bl,bu,reps,evals=all_coefficients(cells,src,q);lpL=simplex(bl,N);lpU=simplex(bu,N);partL,blocks=partition_opt(bl,N);partU,_=partition_opt(bu,N)
            # Reconstructed selected common partition has fixed representatives.
            actualparts=[dict(mask=m,indices=[i for i in range(N) if m>>i&1],representative=reps[m]) for m in blocks]
            actualL=sum(coefficient(cells,src,m,q,reps[m])[0] for m in blocks);assert actualL==partL
            B=(lpL['value'],lpU['value']);O=(partL,partU)
            closed={m:((m>>((m&-m).bit_length()-1))&(1+(m>>((m&-m).bit_length()-1))))==0 for m in bl}
            clL=simplex({m:bl[m] if closed[m] else F(0) for m in bl},N);clU=simplex({m:bu[m] if closed[m] else F(0) for m in bu},N)
            C=(clL['value'],clU['value'])
            assert B[0]<=B[1] and O[0]<=O[1] and O[0]<=B[1]
            if q==1:assert max(B[0],T[0])<=min(B[1],T[1])
            singleton=(sum(bl[1<<i] for i in range(N)),sum(bu[1<<i] for i in range(N)))
            median=src['y'][next(i for i in range(N) if sum(src['p'][:i+1])*2>=1)];wholemedian=coefficient(cells,src,full,q,median)
            exponents.append(dict(q=str(q),t=str(q-1),B=interval_record(B),O=interval_record(O),T=interval_record(T),B_over_T=interval_record((B[0]/T[1],B[1]/T[0])),O_over_T=interval_record((O[0]/T[1],O[1]/T[0])),B_over_O=interval_record((B[0]/O[1],B[1]/O[0])),singleton=interval_record(singleton),whole_source_lower_median=interval_record(wholemedian),coefficient_count=len(bl),candidate_evaluations=evals,coefficients={m:dict(lower=bl[m],upper=bu[m],representative=reps[m]) for m in bl},lower_LP=lpL,upper_LP=lpU,closed_subset_B=interval_record(C),closed_subset_B_over_T=interval_record((C[0]/T[1],C[1]/T[0])),closed_subset_lower_LP=clL,closed_subset_upper_LP=clU,selected_common_partition=actualparts,certificate='Exact rational primal capacities and nonnegative dual subset margins; objectives equal for each rational coefficient enclosure LP.'))
        records.append(dict(source=src,band_cells=cells,band_cell_count=len(cells),exact_interior_capture_checks=checks,weak_ratio=str(src['lam']*weak_length),exponents=exponents))
        print(src['label'],'N',N,'cells',len(cells),'seconds',round(time.monotonic()-start,3),flush=True)
    finite2d=finite_2d_stage(args.pilot)
    out=dict(finite_2d=finite2d,round=74,status='PILOT' if args.pilot else 'FINAL',scope='Certified full-Lebesgue original-band 1D coefficients and source-capacity LP for each registered finite rational input. No arbitrary-source or dimension-asymptotic theorem.',arithmetic='Fraction rational geometry, 45-term atanh log enclosures rounded outward to 2^90; half-integer powers by exact 100-step dyadic square-root bisection; exact rational Bland simplex.',counts=dict(sources=len(records),source_exponents=sum(len(r['exponents']) for r in records),band_cells=sum(r['band_cell_count'] for r in records),interior_capture_checks=sum(r['exact_interior_capture_checks'] for r in records),finite_2d_sources=len(finite2d),finite_2d_training_draws=64*len(finite2d),finite_2d_validation_draws=2048*len(finite2d),finite_2d_training_subset_columns=sum(len(r['coefficients']) for r in finite2d)),cases=records)
    Path(__file__).with_name('dual_results.json').write_text(json.dumps(clean(out),indent=2,sort_keys=True)+'\n')
    print('DONE',out['counts'],'seconds',time.monotonic()-start,flush=True)

if __name__=='__main__':main()
