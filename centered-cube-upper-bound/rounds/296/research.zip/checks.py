#!/usr/bin/env python3
"""R296 merged-band finite algebra and hard-envelope scalar diagnostics."""
import json,random,hashlib
from fractions import Fraction as Q
from decimal import Decimal as D,localcontext,ROUND_CEILING
from pathlib import Path
R=random.Random(29620261018)
def dd(x):return D(x.numerator)/D(x.denominator) if isinstance(x,Q) else D(str(x))
def band(n,L,Rr):
 gamma=Q(n+1,n);ratio=min(L,Rr)/max(L,Rr);j=0;c=Q(1)
 while ratio<(c/gamma)**2:j+=1;c/=gamma
 assert (c/gamma)**2<=ratio<=c*c
 return j,c

def matrix(ns,count,spread):
 rowchecks=0;zero=0;maxratio=Q(0);js=set()
 for trial in range(count):
  n=ns[trial%len(ns)];assert n%2==0
  beta=[Q(R.randint(0,20),R.randint(1,20)) for _ in range(5)];nu=[Q(R.randint(0,20),R.randint(1,20)) for _ in range(4)]
  omega=[[Q(R.randint(0,10),10) for _ in nu] for _ in beta]
  if trial%4==0:
   for w in omega:w[0]=Q(0)
  bcols=[sum(beta[y]*omega[y][z] for y in range(len(beta))) for z in range(len(nu))]
  lam=Q(R.randint(1,10),R.randint(1,10));qm=3*lam/4;K=Q(R.randint(1,10),R.randint(1,10));M=Q(10)**R.randint(-spread,spread);ell=Q(3,2);alpha0=2*K/(ell*M)
  traffic=Q(0);majorant=Q(0)
  for row in range(8):
   Rr=[Q(1),Q(4,3),Q(3,2)][row%3];L=Q(2);j,c=band(n,L,Rr);js.add(j);alphaj=alpha0*c**(3*n//2)
   q=lam*[Q(3,4),Q(7,8),Q(1)][row%3];assert qm<=q<=lam
   raw=[Q(R.randint(0,20),R.randint(1,20)) for _ in beta];norm=sum(x*w for x,w in zip(raw,beta));p=[x*q/(1+norm) for x in raw]
   masks=[bool(R.randrange(2)) for _ in beta]
   for y in range(len(beta)):
    if masks[y]:p[y]=min(p[y],alphaj/Rr**n)*Q(3,4)
   assert sum(beta[y]*p[y] for y in range(len(beta)))<=q
   dx=Q(R.randint(1,20),R.randint(1,20))
   for z in range(len(nu)):
    value=sum(beta[y]*omega[y][z]*p[y]/q for y in range(len(beta)) if masks[y])
    # Exactly one receiver band is retained before replacing alpha_j by alpha_0.
    merged=sum(value if k==j else Q(0) for k in range(max(js)+1));assert merged==value
    bound=min(Q(1),alpha0*bcols[z]/(qm*Rr**n));assert value<=bound
    h=Q(R.randrange(2),1)/Rr**n;traffic+=dx*nu[z]*h*value;majorant+=dx*nu[z]*h*bound
    rowchecks+=1
    if not bcols[z]:assert value==0;zero+=1
  assert traffic<=majorant
  if majorant:maxratio=max(maxratio,traffic/majorant)
 return {'finite_matrix_cases':count,'per_receiver_column_min_checks':rowchecks,'zero_frozen_column_checks':zero,'selected_unique_band_indices':sorted(js),'max_traffic_to_merged_min_bound_ratio':str(maxratio),'max_exact_violation':'0','scope':'Abstract finite receiver matrices with exact FIRST and actual selected-height inequalities; arbitrary dx weights. No F_A integration bound is inferred from these arbitrary matrices. ell is a positive formal scalar; no full kernel/history construction.'}

def Ftheta(A,u,theta):
 if not u:return D(0)
 if A==1:return min(D(1),u)
 inv=(-theta*A.ln()).exp();cross=(theta*A.ln()).exp()
 if u<=1:return u*(1+(1-inv)/theta)
 if u>=cross:return 1+A.ln()
 return 1+u.ln()/theta+(1-u*inv)/theta

def pieceF(A,u,theta):
 if not u:return D(0)
 ell=A.ln();cut=max(D(0),min(ell,u.ln()/theta))
 first=min(D(1),u)
 tail=u*((-theta*cut).exp()-(-theta*ell).exp())/theta if cut<ell else D(0)
 return first+cut+tail

def Psi(A,u,n):
 if not u:return D(0)
 d=D(3)*D(n)/2*(1+D(1)/n).ln();r=(-d).exp();den=1-r;loga=A.ln();logu=u.ln()
 above=max(0,int(((logu-loga)/d).to_integral_value(rounding=ROUND_CEILING)))
 positive=max(0,int((logu/d).to_integral_value(rounding=ROUND_CEILING)))
 middle=max(0,positive-above);start=u*(-d*above).exp()
 total=D(above)*(1+loga)
 if middle:
  total+=D(middle)*(2+logu-d*above)-d*D(middle)*(middle-1)/2-(start/A)*(1-(-d*middle).exp())/den
 tail=u*(-d*positive).exp();total+=tail*(2-1/A)/den
 return total

def Psi_direct(A,u,n):
 if not u:return D(0)
 d=D(3)*D(n)/2*(1+D(1)/n).ln();r=(-d).exp();arg=u;total=D(0);loga=A.ln()
 while arg>1:
  total+=(1+loga) if arg>=A else 2+arg.ln()-arg/A
  arg*=r
 return total+arg*(2-1/A)/(1-r)

def scalar(ns):
 cases=[]
 for n in ns:
  for scale in [1,2]:
   cases.extend((n,scale,label) for label in ['zero','one','A','root','tiny','huge','Msmall','Mlarge','thetaedge'])
 maxdiff=D(0);maxroot1=D(0);maxroot3=D(0);maxsave=D(0);maxformula=D(0);psichecks=0;psierror=D(0);rows=[]
 for n,scale,label in cases:
  vals=[]
  for dp in [40,60]:
   with localcontext() as ctx:
    ctx.prec=dp;A=D(scale)**n;root=D(n).sqrt();capacity=root.exp()
    u={'zero':D(0),'one':D(1),'A':A,'root':capacity,'tiny':D('1e-100'),'huge':D('1e100'),'Msmall':D('1e10000'),'Mlarge':D('1e-10000'),'thetaedge':(D(3)/4*A.ln()).exp()}[label]
    f=Ftheta(A,u,D(1));f3=Ftheta(A,u,D(3)/4);ps=Psi(A,u,n)
    if label in ['zero','one','root','tiny','huge','thetaedge']:
     direct=Psi_direct(A,u,n);de=abs(ps-direct)/max(D(1),abs(direct));assert de<D('1e-28');psierror=max(psierror,de);psichecks+=1
    for th,v in [(D(1),f),(D(3)/4,f3)]:
     piece=pieceF(A,u,th);err=abs(v-piece)/max(D(1),abs(v));assert err<D('1e-28');maxformula=max(maxformula,err)
    assert f>=0 and f3>=0 and ps>=f-D('1e-25')*max(D(1),f)
    if u<=capacity:
     assert f<=3*root+D('1e-28') and f3<=4*root+D('1e-28');maxroot1=max(maxroot1,f/(3*root));maxroot3=max(maxroot3,f3/(4*root))
    if f:maxsave=max(maxsave,ps/f)
    vals.append((+f,+f3,+ps))
    if dp==60 and scale==2 and label=='root':rows.append({'n':n,'A':'2^n','u':'exp(sqrt(n))','F_A':str(f),'F_3_over_4':str(f3),'old_Psi':str(ps),'old_Psi_over_F_A':str(ps/f)})
  with localcontext() as ctx:
   ctx.prec=90;err=max(abs(a-b)/max(D(1),abs(b)) for a,b in zip(*vals));assert err<D('1e-25');maxdiff=max(maxdiff,err)
 return {'cases':len(cases),'precision_runs':2*len(cases),'decimal_precisions':[40,60],'max_normalized_40_vs_60_error':str(maxdiff),'max_piecewise_formula_error':str(maxformula),'old_Psi_direct_sum_precision_checks':psichecks,'max_old_Psi_closed_vs_direct_error':str(psierror),'max_F_A_to_3sqrt_n_ratio':str(maxroot1),'max_F_3over4_to_4sqrt_n_ratio':str(maxroot3),'max_old_Psi_over_F_A':str(maxsave),'root_capacity_examples':rows,'max_violation':'0'}

def finite_envelope(ns,count,spread):
 maxratio=D(0);maxratio3=D(0);checks=0
 for j in range(count):
  n=ns[j%len(ns)];u=Q(0) if j%10==0 else Q(10)**R.randint(-spread,spread)
  menu=[Q(1),Q(5,4),Q(3,2),Q(7,4),Q(2)]
  def integral(rs):
   total=min(Q(1),u);prev=Q(1)
   for r in rs[1:]:v=r**n;total+=(1-prev/v)*min(Q(1),u/v);prev=v
   return total
  coarse=integral([Q(1),Q(2)]);fine=integral(menu);assert coarse<=fine
  with localcontext() as ctx:
   ctx.prec=60;A=D(2)**n;bound=Ftheta(A,dd(u),D(1));assert dd(fine)<=bound+D('1e-40')*max(D(1),bound)
   if bound:maxratio=max(maxratio,dd(fine)/bound)
  # Fraction theta=3/4 model at fourth-power volume breakpoints.
  n4=4*((n+3)//4);roots=[Q(1),Q(2),Q(2)**(n4//4)];roots=sorted(set(roots));prev=Q(1);value=min(Q(1),u)
  for r in roots[1:]:vol=r**4;value+=(1-prev/vol)*min(Q(1),u/r**3);prev=vol
  with localcontext() as ctx:
   ctx.prec=60;bound=Ftheta(D(2)**n4,dd(u),D(3)/4);assert dd(value)<=bound+D('1e-40')*max(D(1),bound)
   if bound:maxratio3=max(maxratio3,dd(value)/bound)
  checks+=1
 return {'cases_each_theta':checks,'exact_fraction_menu_refinement_checks':checks,'max_finite_menu_to_F_A_ratio':str(maxratio),'max_fourth_power_menu_to_F_3over4_ratio':str(maxratio3),'max_violation':'0','scope':'Independent genuine cube-volume radial finite-menu envelope integrals; not arbitrary-matrix receiver integration.'}

def all_orientation(ns):
 count=0;eq=0
 for n in ns:
  gamma=Q(n+1,n)
  for l4,r4 in [(Q(1),Q(1)),(Q(1),Q(2)),(Q(2),Q(1)),(Q(3,2),Q(7,4)),(Q(7,4),Q(3,2))]:
   Lv=l4**4;Rv=r4**4;ratio=min(Lv,Rv)/max(Lv,Rv);j=0;c=Q(1)
   while ratio<(c/gamma)**(2*n):j+=1;c/=gamma
   assert (c/gamma)**(2*n)<=ratio<=c**(2*n)
   old=c**(n//2)/(l4*r4)**2;new=gamma**(n//2)/r4**3 # a^n=1, kappa=1.
   assert old<=new
   if old==new:eq+=1
   count+=1
 return {'exact_fraction_fourth_power_volume_cases':count,'dimensions':ns,'old_height':'kappa*c_j^(n/2)*g^-n','new_height':'kappa*gamma^(n/2)*a^(-n/4)*R^(-3n/4)','max_exact_height_violation':'0','scope':'Coefficient comparison at selected scales in both orientations; additional theorem quantifiers remain external.'}
settings=[('initial',[2,4,16],8,2,[1,2,4],[1,2,4],[4,16]),('boundary_extreme_columns',[4,16,64],16,15,[8,64,100],[8,32,64],[4,16,64]),('expanded',[16,64,128],24,50,[1000,10000],[128,256,1000],[16,64,128])]
stages=[]
for name,mns,count,spread,sns,ens,ans in settings:
 stages.append({'name':name,'merged_band_matrix':matrix(mns,count,spread),'finite_hard_envelope':finite_envelope(ens,count,spread),'all_orientation_height':all_orientation(ans),'scalar_F_and_root_capacity':scalar(sns)})
out={'status':'PASS','seed':29620261018,'scope':'Exact Fraction selected-receiver FIRST/height/unique-band algebra, separately calibrated finite hard-scale radial envelopes, exact fourth-power all-orientation height comparison, and Decimal40/60 scalar F/root/Psi data. Abstract finite matrices are not claimed to be genuine high-dimensional kernels. No FULL/source closure or independent quantifier audit.','F_A':'min(1,u)+integral_1^A min(1,u/v)dv/v','F_theta':'min(1,u)+integral_1^A min(1,u/v^theta)dv/v, theta=3/4','old_Psi':'sum_j>=0 F_A(u exp(-(3n/2)log(1+1/n)*j)); exact closed finite head plus geometric tail','stages':stages}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps(out,sort_keys=True,indent=2))
