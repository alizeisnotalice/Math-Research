#!/usr/bin/env python3
"""Finite diagnostics for the mixed-source inequalities, not their proof."""
import sys, random
from fractions import Fraction
try:
 import mpmath as mp
except ImportError:
 sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
 import mpmath as mp
mp.mp.dps=45

def F(A,theta,u):
 S=A**theta
 if u<=1: return u*(1+(1-1/S)/theta)
 if u<=S: return 1+(mp.log(u)+1-u/S)/theta
 return 1+mp.log(A)

def optimal(A,theta,a):
 if not a: return mp.mpf(0),mp.mpf(1)
 S=A**theta
 if A==1 or a*(1-1/S)<=theta:
  return a*F(A,theta,1)/(1+a),mp.mpf(1)
 w=mp.lambertw(a*mp.exp(theta+a/S))
 return (w-a/S)/theta,a/w

def limit(theta,a):
 if a<=theta: return (1+1/theta)*a/(1+a)
 return mp.lambertw(a*mp.exp(theta))/theta

scalar=0
for theta in map(mp.mpf,['.25','.75','1']):
 for A in map(mp.mpf,['1','1.01','2','1024','1e100']):
  for a in map(mp.mpf,['.000001','.1','.75','1','3','100','1e6']):
   c,u=optimal(A,theta,a)
   assert 1-mp.mpf('1e-35')<=u<=A**theta+mp.mpf('1e-35')
   assert abs(c-a*F(A,theta,u)/(a+u))<=mp.mpf('1e-32')*max(1,c)
   assert c<=limit(theta,a)+mp.mpf('1e-32')
   assert c<=1+max(0,mp.log(a/theta))/theta+mp.mpf('1e-32')
   for j in range(-40,41):
    v=mp.exp(mp.mpf(j)/4)
    assert a*F(A,theta,v)/(a+v)<=c+mp.mpf('1e-30')
   scalar+=1

rng=random.Random(296)
tables=0
for case in range(100):
 theta=mp.mpf('.75') if case%2 else mp.mpf(1)
 A=mp.mpf(2)**(case%9)
 bm=[Fraction(rng.randint(1,9),3) for _ in range(3)]
 nm=[Fraction(rng.randint(1,9),4) for _ in range(4)]
 om=[[Fraction(rng.randint(0,10),10) for _ in nm] for _ in bm]
 B=sum(bm); N=sum(nm)
 rows=[sum(o*v for o,v in zip(row,nm)) for row in om]
 cols=[sum(bm[i]*om[i][j] for i in range(3)) for j in range(4)]
 E=sum(bm[i]*rows[i] for i in range(3))
 assert E==sum(nm[j]*cols[j] for j in range(4))
 R=max(rows)
 Q=Fraction(2,3); C=R/Q
 cv=lambda x:mp.mpf(x.numerator)/x.denominator
 kappa=mp.mpf(10)**((case%7)-3)
 value=sum(cv(nm[j])*F(A,theta,kappa*cv(cols[j])/cv(Q)) for j in range(4))
 jensen=cv(N)*F(A,theta,kappa*cv(E)/(cv(Q)*cv(N)))
 row_bound=cv(N)*F(A,theta,kappa*cv(B)*min(1,cv(R/N))/cv(Q))
 linear=limit(theta,kappa*cv(C))*cv(B+N)
 assert value<=jensen+mp.mpf('1e-35')
 assert jensen<=row_bound+mp.mpf('1e-35')
 assert row_bound<=linear+mp.mpf('1e-35')
 # Constant fractional allocation attains the row-only Jensen optimum.
 t=min(Fraction(1),R/N)
 assert sum(v*t for v in nm)<=R
 const=cv(N)*F(A,theta,kappa*cv(B*t)/cv(Q))
 assert abs(const-row_bound)<=mp.mpf('1e-35')
 tables+=1
print('PASS finite-A optimal coefficients and uniform Lambert-W limits:',scalar)
print('PASS exact rational row/column ledgers, Jensen, sharp mass bounds:',tables)
print('theta=.75, a=1 optimum uniform coefficient=',mp.nstr(limit(mp.mpf('.75'),mp.mpf(1)),25))
