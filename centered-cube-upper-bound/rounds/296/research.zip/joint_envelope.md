# R296 — merge bands before receiver integration; a common envelope for both orientations

## Precise objects and scope

Use exactly the finite positive sources beta,nu and original receiver traffic of R295 reverse geometry, with actual Lebesgue dx, common selected s(x), L(x), R(x) in [a,b], 0<a<=b, q(x) in [q_-,lambda], q_-=3lambda/4. Keep all source/history/forbidden masks as factors in [0,1]. Original FIRST is integral p_y beta(dy)<=q(x). The original low and high qualifications are p_y e_g(y)<2K q(x) and e_g(y)>ell M q(x)c_j^(-n/2)g^n, g=sqrt(LR), ell=1+log n, M>0. The actual original band satisfies c_j/gamma<=min(L,R)/g<=c_j, c_j=gamma^(-j), gamma=1+1/n. No local replacement of e_g is made. Write kappa=2K/(ell M).

Let omega(y,z) in [0,1] be measurable and frozen independently of receiver selectors. Define b_omega(z)=integral omega(y,z)beta(dy), W_beta=beta(R^n), W_nu=nu(R^n). All estimates concern the ORIGINAL raw low, m>M traffic times omega; the outside Lambda is applied once. Fixed outer source/seed data remain fixed. Sums over those outer data are not paid by this proof.

## 1. Uniform height before any band sum

Combining the two original gates on each retained edge gives

    p_y < kappa c_j^(n/2)(LR)^(-n/2).                  (1)

For L>R, R/g<=c_j gives

    p_y <= kappa c_j^(3n/2) R^(-n) <= kappa R^(-n).    (2)

There is no need to sum a separate receiver envelope for each j. Inequality (2) is valid on the UNION of all original band branches before beta integration. This remains valid if a positive source mask further separates edges: the uniform upper bound is independent of that separation. It would not license summing multiple independent receiver selectors as though FIRST held for their sum.

For L<=R, c_j<=gamma sqrt(L/R) gives

    p_y <= kappa gamma^(n/2)L^(-n/4)R^(-3n/4)
        <= kappa gamma^(n/2)a^(-n/4)R^(-3n/4).         (3)

For L>R, (2) is at most the last expression in (3), because R>=a and gamma^(n/2)>=1. Thus (3) holds for BOTH orientations, including equality, with no softness restriction. This does not use the common-soft moment, source density assumptions, source displacement restrictions, or new caps.

## 2. Exact fractional-height hard envelope

For theta>0, A=(b/a)^n>=1 and u>=0 define

    F_(A,theta)(u)=min(1,u)+integral_1^A min(1,u v^(-theta))dv/v.

The exact geometric identity is

    integral dx sup_(a<=R<=b) R^(-n)1_(Q_R(z))(x)
              min(1,u (a/R)^(n theta)) =F_(A,theta)(u). (4)

The coefficient decreases in R. On Q_a(z) the maximum is at a; on Q_b(z) minus Q_a(z), it is at R=2||x-z||_infinity. Integrate with d|Q_R|=nR^(n-1)dR and substitute v=(R/a)^n. Outside Q_b it is zero. This proves (4) with measurable supremum and without discarding selector-dependent hard faces. A=1 and u=0 are included.

The exact scalar formula, with consistent endpoints, is

    u[1+(1-A^(-theta))/theta],                     0<=u<=1;
    1+(log u)/theta+(1-u A^(-theta))/theta,        1<=u<=A^theta;
    1+log A,                                     u>=A^theta.       (5)

For A=1 the function is simply min(1,u). In particular

    F_(A,theta)(u)<= (1+1/theta)u                    (u<=1),
    F_(A,theta)(u)<= 1+1/theta+(log u)/theta         (u>=1). (6)

Unlike the previous Psi price there is only ONE logarithm.

## 3. Actual traffic inequalities

For each original accepted receiver x and source z, integrate beta BEFORE removing the low/high masks. FIRST and (2) give on L>R

    integral omega (p_y/q)1_branch beta(dy)
       <= min(1, kappa b_omega(z)/(q_- R^n)).

Multiply by the actual h_R(x-z), dominate only its selected scale by (4), then use positive Tonelli. Therefore

    T_(low,m>M,L>R;omega)
       <= integral F_(A,1)(kappa b_omega(z)/(q_-a^n))nu(dz). (7)

There is NO band count and NO additional source reuse. This replaces R295's Psi sum; the improvement comes from respecting the original union before making an upper envelope.

Using (3) instead gives for ALL orientations

    T_(low,m>M;omega)
       <= integral F_(A,3/4)(gamma^(n/2) kappa b_omega(z)
                                      /(q_-a^n))nu(dz). (8)

All actual common softness values are allowed. The original hard cap remains an admissibility condition but is not used to turn nu into a bounded-density source. Original full e_g and all historical labels remain unchanged. No new favourable high-m condition is inferred after masks are dropped.

## 4. Root-price capacity and exact remaining issue

For n>=1, if kappa b_omega/(q_-a^n)<=exp(sqrt n) nu-a.e., then (6)-(7) imply T_reverse<=3sqrt(n) W_nu. If

    gamma^(n/2) kappa b_omega(z)/(q_-a^n)<=exp(sqrt n)   (9)

nu-a.e., then (6)-(8) imply T_all<=4sqrt(n) W_nu: for u>=1, 7/3+(4/3)sqrt(n)<= (11/3)sqrt(n)<4sqrt(n); for u<=1, F<=7/3. This is all original high mass, both scale orientations and all softness, under an explicit frozen source capacity. It is not a special input family restriction, but it is a genuine condition which must be paid for a full proof.

For omega=1, (8) gives the unconditional but concentration-dependent estimate

    T_(low,m>M) <= W_nu F_(A,3/4)
                    (gamma^(n/2) kappa W_beta/(q_-a^n)). (10)

The dimensionless global concentration ratio on the right can be arbitrarily large. Formula (5) saturates at 1+n log(b/a), so this estimate alone does not give the desired uniform root-order bound. Splitting beta into many allocations cannot repeat W_nu for free. The remaining objective is a geometrically legitimate source allocation or direct joint estimate controlling the SINGLE logarithmic integral in (8) with the actual source ledger. This round has removed a nonessential band logarithm and the soft-moment fee from this source-budget route; it has not proved that the remaining concentration charge is always payable.

## 5. Evidence and dependencies

The reverse union proposition was independently screened before this text. The both-orientation extension is also submitted for independent quantifier/constant review. Separate finite diagnostics verify band heights, scalar envelopes and endpoint budgets; finite receiver matrices are not asserted to realize actual spatial soft kernels. The proof of the general geometric statement is (1)-(8), not a numerical extrapolation. A02 is used to track positive dominance before suprema and source integrals. No external optimal-transport theorem is invoked without its hypotheses.
