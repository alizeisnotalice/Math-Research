"""Reproduce the finite diagnostics reported in r296_spatial_geometry.md.

These checks supplement the analytic proof; the Simpson differences are not
certified quadrature error bounds. Uses only the Python standard library.
"""
from fractions import Fraction as F
from decimal import Decimal, localcontext
from pathlib import Path
import math
import json


def tail(r, subdivisions):
    def integrand(t):
        if t == 0:
            return 0.0
        return 2 * t * t * math.exp(-(r - .5) / t) * (-math.expm1(-1 / t))

    step = 1 / subdivisions
    return step / 3 * (
        integrand(0) + integrand(1)
        + sum((4 if k % 2 else 2) * integrand(k * step)
              for k in range(1, subdivisions))
    )


radii = [.500001, .6, 1., 2., 5., 20.]
errors, tails = [], []
for r in radii:
    t2 = tail(r, 2000)
    t4 = tail(r, 4000)
    assert 0 <= t4 <= (2 / 3) * math.exp(-(r - .5)) * (1 + 1e-12)
    errors.append(abs(t2 - t4))
    tails.append(t4)

coefficient_cases = 0
for n in [1, 2, 3, 8, 16, 100, 10000]:
    coefficients = []
    for k in range(n + 1):
        m = min(k, n - k)
        if m == 0:
            coefficients.append(1.)
        else:
            coefficients.append(math.exp(
                math.lgamma(n + 1) - math.lgamma(m + 1)
                - math.lgamma(n - m + 1)
                + m * math.log(m / n)
                + (n - m) * math.log1p(-m / n)
            ))
    csoft = math.fsum(coefficients)
    weighted_sum = math.fsum(k * coefficients[k] for k in range(n + 1))
    assert abs(weighted_sum - .5 * n * csoft) <= 1e-12 * n * csoft
    for t in tails:
        product_tail_sum = math.fsum(
            coefficients[k] * (-math.expm1(k * math.log1p(-t)))
            for k in range(1, n + 1)
        )
        assert product_tail_sum <= .5 * n * csoft * t * (1 + 1e-12)
        coefficient_cases += 1

rectangle_cases = 0
with localcontext() as ctx:
    ctx.prec = 60

    def dec(q):
        return Decimal(q.numerator) / Decimal(q.denominator)

    for n in [1, 2, 3, 8, 16, 64]:
        widths = [F([1, 2, 3, 5][i % 4], 2) for i in range(n)]
        volume = math.prod(widths)
        for r in [F(1, 2), F(3, 4), F(1), F(2)]:
            cutoff_side = 4 * r

            def outside_volume(scale):
                return scale ** n * volume - math.prod(
                    min(scale * width, cutoff_side) for width in widths
                )

            previous = F(0)
            for mesh in [2, 4, 8, 16]:
                scales = [1 + F(k, mesh) for k in range(mesh + 1)]
                value = outside_volume(F(1)) / volume
                for lower, upper in zip(scales, scales[1:]):
                    value += (outside_volume(upper) - outside_volume(lower)) / (
                        upper ** n * volume
                    )
                assert value >= previous
                terminal_tail = 1 - math.prod(
                    min(width, 2 * r) / width for width in widths
                )
                bound = (1 + Decimal(n) * Decimal(2).ln()) * dec(terminal_tail)
                assert dec(value) <= bound + Decimal('1e-50')
                previous = value
                rectangle_cases += 1

result = {
    'status': 'PASS',
    'actual_phi_tail_radii': radii,
    'Simpson_2000_4000_max_difference': max(errors),
    'shared_soft_tail_cases': coefficient_cases,
    'coefficient_dimensions': [1, 2, 3, 8, 16, 100, 10000],
    'exact_Fraction_tail_envelope_cases': rectangle_cases,
    'rectangle_dimensions': [1, 2, 3, 8, 16, 64],
}
output = json.dumps(result, indent=2) + '\n'
Path('/tmp/r296_spatial_checks.json').write_text(output)
print(output, end='')
