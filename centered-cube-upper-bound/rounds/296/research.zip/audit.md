# R296 independent preauthor screen

## Verdict and exact scope

PASS. Written before reading any new R296 author proof. Read the original object and definitions in /tmp/r295_reverse_geometry.md. The candidate merged-band bound is valid for the ENTIRE SAME original low-pe,m>M,L>R traffic (all original unique bands together), with arbitrary original L1 sources, original actual beta FIRST, and a frozen measurable pair allocation omega in[0,1]. No new density hypothesis, source ordering, full-soft moment, q freeze or additive mass loss is required. The source column mass condition below remains a genuine condition, not automatic coverage.

Fix each original outer/terminal datum n,a,b,lambda,K,M before receiver integration, with q_-=3lambda/4, ell=1+log n, M>0. Original p=P_(s(x),L(x))(x-y), h_R=R(x)^-n 1_QR(x-z), q=q(x), and FIRST integral p beta<=q are retained at their actual common receiver selectors. Original full e_g,m,low/accepted/history/source masks and unique band remain on the left. The hard cap may remain an original qualification, but this proof does not need to consume it. The original outside Lambda multiplies the raw result once.

## Independent merged-band proof

On EVERY retained original pair row, actual low and actual m>M give
 p_y<2K c_j^(n/2)/(ell M g^n).
For L>R, the original band has R/g<=c_j, hence g>=R/c_j. Therefore
 p_y<alpha_j R^-n, alpha_j=2K c_j^(3n/2)/(ell M)
 <=alpha_0 R^-n, alpha_0=2K/(ell M),
since j>=0 and0<c_j<=1. This last height holds uniformly over ALL actual bands. There is no need to sum per-band bounds.

Let a(x,y,z) in[0,1] denote all current original masks including low,m>M,L>R, and let omega(y,z) in[0,1] be frozen independently of receiver/actual selectors. Define b_omega(z)=integral omega(y,z)beta(dy). At each original receiver x and source z,
 J(x,z)=integral omega(y,z)(p_y/q(x))a(x,y,z)beta(dy)
 <=1 by the original beta FIRST,
 J(x,z)<=alpha_0 b_omega(z)/(q_-R(x)^n) by the uniform original branch height.
Thus J<=min(1,B(z)/R(x)^n), B(z)=alpha_0 b_omega(z)/q_-.

After these two actual-receiver bounds, drop only positive restrictions and majorize the actual hard scale by its physical supremum. Positive Tonelli gives
 T_omega<=integral nu(dz) integral dx sup_(a<=R<=b)
       R^-n1_QR(z)(x) min(1,B(z)/R^n).
The exact hard scale-envelope integral is F_A(B/a^n), A=(b/a)^n,
 F_A(u)=min(1,u)+integral_1^A min(1,u/v)dv/v.
Consequently
 T_(original-low,m>M,L>R;omega)
 <=integral nu(dz) F_A(X_omega(z)),
 X_omega(z)=2K b_omega(z)/(ell M q_-a^n).
This improves the R295 Psi band sum to ONE hard-scale envelope. The same actual p,q,R are used throughout; no FIRST property is assigned to a scale supremum or a different source.

## Band, selector and source quantifiers

The original selected band j is unique and is not reselected after source integration. If extra positive masks sort traffic by y or z, the height alpha_j<=alpha0 still holds for every retained row, so dropping that sorting does not invalidate the common height. Even a row-dependent band label would not obstruct this uniform pointwise inequality, PROVIDED p,q,R in the FIRST/hard kernel remain the same actual common receiver quantities. Allowing soft or hard selectors to vary separately with the source without the corresponding original response cap would change the theorem and is not authorized.

The pair allocation must be frozen, or else supplied with a separately proved uniform column-mass envelope before applying this proof. A different omega chosen favorably at each receiver cannot simply be assigned the fixed b_omega. Several allocations repeat their nu costs unless an explicit source responsibility prevents duplication. The original masks/e/m are never recomputed on source subpieces. Outer-dependent parameters and source weights remain inside their original seed/leaf sums until a valid common estimate is proved.

## Exact scalar bound and root consequence

F_A(u)=u(2-1/A) for0<=u<=1; F_A(u)=2+log u-u/A for1<=u<=A; F_A(u)=1+log A foru>=A. For A=1 use min(1,u). Thus F_A<=2u foru<=1 and F_A<=2+log u foru>=1, and also F_A<=1+log A. Zero b_omega contributes zero.

If X_omega(z)<=exp(sqrt(n)) for nu-almost every z, then F_A(X)<=2+sqrt(n)<=3sqrt(n) for n>=1 (and the small-X branch is also below this). Hence
 T_omega<=3sqrt(n)W_nu,
with raw outside Lambda once. The corresponding exact column capacity is
 b_omega(z)<=ell M q_-a^n exp(sqrt(n))/(2K).
For omega=1 this is a condition on the total ORIGINAL beta mass; it is not proved automatically by original FIRST, hard cap or source finiteness. Without it the merged all-band theorem still gives the explicit single-log source functional integral F_A(X_omega)dnu, improving the previous log-squared functional but not proving its desired global root budget.

The initial task success criterion is met: merged-band general original traffic is rigorously covered by this one-envelope inequality. Remaining issue: source-conserving coverage or a uniform nu-weighted bound on its actual normalized beta column-mass logarithm, plus the other original branches/outer ledgers. No global centered-cube weak-type closure is asserted.

## Executed bounded scalar diagnostic

mpmath at40 digits checked 28 new capacity endpoints X=exp(sqrt(n)), n in {1,2,3,8,64,512,10000}, and b/a in {1,1.01,1.5,2} against the exact piecewise F_A and3sqrt(n). All passed; maximum observed ratio was 0.582261903075. This supplements the elementary general proof and does not test original FULL/history coverage. No new R296 author proof was read.

Initial independent verdict PASS; screen frozen pending any separately requested author/integration review.

## Additional independent all-orientation theorem screen

PASS before any new R296 author proof. This broadens the preceding merged-band statement to ALL original low,m>M orientations and all actual softness, while retaining an explicit source-mass cost. Put kappa=2K/(ell M). From the original band lower endpoint c_j/gamma<=min(L,R)/g one has c_j<=gamma sqrt(min/max). On L<=R,
 p_y<=kappa c_j^(n/2)g^-n
 <=kappa gamma^(n/2)L^-n/4 R^-3n/4
 <=kappa gamma^(n/2)a^-n/4 R^-3n/4.
On L>R, the previous p_y<=kappa R^-n is also bounded by that final expression because R>=a and gamma>=1. Hence a single common point height holds over every original band AND orientation. No soft profile or R_delta is used.

For frozen omega, actual beta FIRST and the common height therefore give, at every original receiver and source z,
 J(x,z)<=min(1,X_omega(z)(R(x)/a)^(-3n/4)),
 X_omega=gamma^(n/2)kappa b_omega/(q_-a^n).
The exact hard-scale envelope is
 T_(original-low,m>M;omega)<=integral nu(dz) F_(A,theta)(X_omega(z)),
 A=(b/a)^n, theta=3/4,
 F_(A,theta)(u)=min(1,u)+integral_1^A min(1,u v^-theta)dv/v.
The calculation is the same fixed-source cube radial integration as above, performed AFTER the actual FIRST and branch-height bounds. It does not assign a cap to any artificial scale.

For general theta>0 this scalar function has branches
 u[1+(1-A^-theta)/theta], 0<=u<=1;
 1+[1+log u-u A^-theta]/theta, 1<=u<=A^theta;
 1+log A, u>=A^theta.
At A=1 it is min(1,u). Its infinite-window upper bound is (1+1/theta)u foru<=1 and1+1/theta+(log u)/theta foru>=1. Thus for theta=3/4 and X<=exp(sqrt(n)),
 F_(A,3/4)(X)<=7/3+(4/3)sqrt(n)<=11sqrt(n)/3<4sqrt(n),
with the small-X branch also below this. Consequently the ENTIRE original low,m>M allocation omega has price <=4sqrt(n)W_nu under the explicit column capacity
 b_omega(z)<=ell M q_-a^n exp(sqrt(n))/(2K gamma^(n/2))
for nu-almost every z. The raw outside Lambda is multiplied once.

All actual selectors must remain common receiver quantities for the original FIRST. Original full e,m,accepted/history and unique-band identities stay intact; no source posterior, q freeze, density premise, source ordering or softness qualification is introduced. A varying outer datum keeps its X and source weights inside the original ledger. This is a general actual-traffic SOURCE-CONDITIONAL budget; it is not a proof that the capacity or its nu-weighted single-log budget is automatic.

Executed40-digit mpmath: 28 all-orientation capacity endpoints over the same seven dimensions and four physical window ratios passed the exact piecewise F_(A,3/4)<=4sqrt(n) bound. The elementary algebra supplies the all-parameter proof. No new R296 author file was read.

Updated initial verdict PASS, with both original candidate and the stronger all-orientation bound explicitly scoped.

## Main merged-envelope file review

PASS for /tmp/r296_joint_envelope.md SHA256 93ec5151b714646c0202b3e98362b648a23496658b1a0008a8d6ad4e1a8f51ca. Equations1--10 match both independent screens above. The all-orientation height uses the LOWER original band endpoint with the correct gamma^(n/2) normalization; the actual single FIRST is consumed before any hard scale supremum, and all bands are united before source integration. The exact F_(A,theta) formula includes zero mass, singleton scales and hard faces. The3sqrt(n) reverse and4sqrt(n) all-orientation capacities have the correct constants and preserve every concentration factor. No softness moment, source density cap or new response cap is used. The unconditional formula10 retains the single-log source mass ratio and finite-window saturation. No correction requested.

## Independent row-budget/Jensen screen

Before reading the proposed mixed-source author proof, the row mechanism is valid. Put Q=q_-a^n and kappa=2K gamma^(n/2)/(ell M). If a fixed omega in[0,1] satisfies integral omega(y,z)nu(dz)<=C Q for beta-almost every y, then positive Tonelli gives integral b_omega(z)nu(dz)<=C Q W_beta. Since F_(A,theta) is nondecreasing and concave, Jensen against nu/W_nu gives
 T_omega<=W_nu F_(A,theta)(kappa C W_beta/W_nu),
with zero-source corners treated directly. The same statement holds with the infinite-window majorant.

For a=kappa C, the SHARP coefficient for F_infinity is sup_(x>=0) a F_infinity(x)/(a+x). On x<=1 the ratio increases to x=1. On x>=1 its derivative has sign a/x-theta-log x. Thus
 c(a)=(1+1/theta)a/(1+a), a<=theta;
 c(a)=W_0(a exp(theta))/theta, a>=theta.
Both give1 at a=theta; a=0 gives0. The second optimizer is x=a/W_0(a exp(theta)). This is a sharp two-SOURCE-mass inequality for the relaxed F_infinity receipt, not an assertion that original cube traffic attains it.

A legitimate sufficient row cover is a fixed measurable cover of omega's source support at each y by cubes Q_(r_k)(x_k) whose centers/radii actually possess the original hard-source cap nu(Q_(r_k)(x_k))<=4lambda r_k^n. Then row mass<=4lambda sum r_k^n, giving C=(16/3)sum(r_k/a)^n. Radius legality and the accepted receiver cap must hold for EACH witness cube. A uniform finite C is a premise; if C_y varies, its beta-weighted row cost stays explicit. There is no theorem that a low-cost cover exists for all sources, and covers/allocations may not be selected separately at each current receiver for free.

Executed40-digit mpmath: 20 theta/a combinations checked the exact Lambert-W or boundary optimizer against the coefficient and five nearby/remote comparison points. All passed. This supplements the analytic derivative proof.

## Independent actual far-tail screen

For D>=1, freeze omega_D(y,z)=1{|y-z|_infinity<=Db}. Its exact beta column mass is beta(Q_(2Db)(z)), so the main merged all-orientation bound gives the corresponding one-F_(A,3/4) nu source price. The complementary source-far original traffic has |x-y|_infinity>(D-1/2)b by actual hard capture. The common-soft positive binomial envelope sum a_k Q_k is ray-decreasing, and its fixed physical scale envelope outside this radius costs at most A_n times the unscaled tail beyond D-1/2, A_n=1+n log(b/a).

Each Q_k tail is at most k times the one-dimensional phi tail. For r>=1/2, exact positive integration gives integral_{|u|>r}phi(u)du=2 integral_0^1 t² exp(-(r-1/2)/t)(1-exp(-1/t))dt <=(2/3)exp(-(r-1/2)). Since a_k=a_(n-k), sum k a_k=n Csoft_n/2. Thus the full actual far raw traffic is at most (16/9)A_n n Csoft_n exp(1-D)W_beta after consuming original hardcap/q<=16/3 BEFORE receiver extension. This argument does not need original low/high gates or a softness restriction. For0<epsilon<=1, D=1+log[(16/9)A_n n Csoft_n/epsilon]>=1 pays far<=epsilon W_beta. For arbitrary epsilon>0 use the maximum with1. Local beta-mass concentration in the remaining near receipt remains explicit and unproved.

## Mixed-source frozen author audit

PASS for /tmp/r296_mixed_source.md SHA256 a73702a812cf6e45d83ae496607acd578e0d0060933649a5f38a832733512178. Equations1--20 are valid with their explicit row capacity and frozen allocation premises. The sharper Jensen form retains E_omega<=B min(CQ,N), so N F((kappa B/Q)min(1,CQ/N)) is correct. The constant fractional allocation attains these source-functional bounds, with no claim that actual cube traffic attains the relaxation. The variable C(y) statement uses the correct capped beta row integral.

Concavity includes the downward derivative jump at u=1. The author correctly avoids a false global bound uF'(u)<=1/theta on u<1. The asymmetric supergradient fee and its intercept1+log(u0)/theta are correct, with right derivative at u0=1 and zero at S. The finite-width optimal coefficient has threshold a0(1-1/S)<=theta; otherwise the stationary equation is a0/u=theta+a0/S+log u, giving [W(a0 exp(theta+a0/S))-a0/S]/theta. Both reduce to the independently screened infinite-width formulas. The elementary bound c_theta(a0)<=1+theta^-1 log_+(a0/theta) has the correct sign and constants.

Aggregate allocations must sum to at most1 and obey the AGGREGATE row budget before applying Jensen once. Disjoint beta partitions satisfy this when each row has the common budget; arbitrary pair disjointness alone does not. Every uncovered old traffic factor1-omega remains. All source integrals precede the new source fee; no source density or ordering assumption enters.

Each witness cube must carry the original accepted hard-source cap at the SAME legal radius, with frozen measurable source-row maps. Formula19 C=(16/3)sum(r_k/a)^n and formula20 expanded128sqrt(e)/9 retain every normalization. A common budget exp(O(sqrt(n))) would indeed give a root joint-source price for covered traffic, while existence/coverage of such a budget is explicitly unproved. Choosing a new witness at every current receiver cannot count as one row. No correction requested.

## Spatial-localization frozen author audit

PASS for /tmp/r296_spatial_geometry.md SHA256 5b1ada31ae0ff67ce17e24deef3783cc994e8b2bc1de779f6ac68a55d175e6cc. S1--S12 agree with the independent far-tail derivation. The common original FIRST/height bound is merged across all bands and orientations before the near hard-scale integral. The fixed closed source-near mask has exactly beta(Q_(2Db)(z)) column mass and an exact strict source-far complement. No source decomposition changes original e,m or history.

The true one-dimensional phi tail in S7 has correct2/3 coefficient. Product-Q_k tail is exactly1-(1-tail_phi)^k for radius>1/2, and coefficient symmetry gives sum k a_k=n Csoft/2. The full-profile ray envelope S9 is applied BEFORE restricting the receiver region, avoiding any false ray monotonicity of a tail-truncated profile. Its normalization and physical scale mass A_n remain explicit. After actual hard capture, source-far implies the fixed soft receiver cutoff, and original hardcap/q16/3 is consumed before receiver extension. This proves the exact16/9 coefficient and exp(1-D).

The local source fee plus the far epsilon W_beta fee is therefore unconditional for the same original low,m>M traffic, all softness, both orientations, arbitrary original L1 sources. The far fee itself holds without low/high. D_epsilon>1 for0<epsilon<=1; the original b<=2a window justifies the stated O(b log(n/epsilon)) localization radius. Lambda multiplies the raw low receipt once. Local mass concentration is not inferred from FIRST, hard caps at source centers, or Lebesgue weak bounds. No grid multiplicity or duplicated source fee is used. No correction requested.

## Final README integration and numerical receipt

PASS for the current README and all three frozen mathematical proofs. Constants and parameter names match: main kappa=2K/(ell M), all-orientation kappa_star=gamma^(n/2)kappa, Q=q_-a^n, A=(b/a)^n, theta=3/4. The reverse single-envelope and all-orientation capacities are genuine conditions; the latter gives4sqrt(n)W_nu only with the displayed normalized source column budget. The spatial reduction pays the complete far tail at epsilon W_beta and leaves the actual local beta-mass single-log integral. The row-capacity theorem supplies a joint beta-plus-nu price only when the frozen aggregate row budget or its genuine accepted-receiver witness cover is proved. No source density, source ordering, extra FIRST or low-cost cover is inferred.

The README preserves all these conditions, original low/m>M/source/history masks, unique actual selectors, source reuse responsibilities, original b<=2a physical range for logarithmic localization, and Lambda once. It does not turn the all-softness/all-orientation SOURCE FUNCTIONAL into an unconditional root source budget, or claim that the continuous high-score and initial/jump/deletion/global ledgers are closed. Its finite numerical evidence is properly distinguished from general proof and interval certification. No correction remains.

Parent reports actual exit0 reruns of all three scripts. The final main and spatial JSON hashes/statuses were inspected, as was the mixed-source rerun log confirming105 finite-width coefficient cases and100 exact ledgers PASS. Main JSON SHA25669db61ab53f29fe8beb77d83be024b7c4e4b79cd9f8a512e03cbef838a8babd7; spatial JSON SHA25664f9a4c45dd49817102d57304f9582e22f578d783b25309298f6ca99b6a11020. Independent local calculations in this audit additionally checked28 reverse capacity endpoints,28 theta=3/4 endpoints and20 Lambert coefficient optimizers; no new rerun was launched at final integration.

Final proof/report hash bindings:
- /tmp/r296_joint_envelope.md: SHA256 93ec5151b714646c0202b3e98362b648a23496658b1a0008a8d6ad4e1a8f51ca
- /tmp/r296_mixed_source.md: SHA256 a73702a812cf6e45d83ae496607acd578e0d0060933649a5f38a832733512178
- /tmp/r296_spatial_geometry.md: SHA256 5b1ada31ae0ff67ce17e24deef3783cc994e8b2bc1de779f6ac68a55d175e6cc
- /tmp/r296_README.md: SHA256 0b12cdb85aba6c8394636b942adc8f2b1d604d049123922dadc366d03e59b240

Final unresolved bridge: prove a root-compatible budget for the nu-weighted LOCAL normalized beta-mass logarithm, or construct a frozen aggregate pair allocation covering the intended original traffic with a proved affordable row/witness capacity. Any uncovered1-omega traffic and all other original global ledgers remain. The new results are general original-traffic inequalities with explicit source costs, not full weak-type closure.

Final verdict PASS; audit frozen. Only this owned temporary audit file was edited. No repository, Git, PDF or upstream author file was changed.
