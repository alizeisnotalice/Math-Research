# R296: unconditional spatial localization of the merged all-orientation column price

## 1. Exact general estimate

Retain the ORIGINAL traffic

    dT=q(x)^(-1)P_(s(x),L(x))(x-y)h_(R(x))(x-z)
            a_omega(x,y,z) dx beta(dy)nu(dz),

where a<=L,R<=b<=2a, q_-=3lambda/4<=q(x)<=lambda, 0<=a_omega<=1, and all original accepted/FIRST, forbidden-source, terminal and history masks remain. The actual FIRST condition is integral P_(s,L)(x-y)beta(dy)<=q(x), and the original maximal hard cap gives h_R*nu(x)<=4lambda at actual receivers. The original complete e_g, low p_y e_g<2Kq, and m=e_g/(ell q c_j^(-n/2)g^n), ell=1+log n, are unchanged.

Fix M>0. Let T_* denote ALL original low,m>M traffic, with both orientations and all original ratio bands. Set

    gamma=1+1/n, kappa=2K/(ell M), theta=3/4,
    A=(b/a)^n, A_n=1+n log(b/a),
    Csoft_n=sum_(k=0)^n a_(n,k),
    a_(n,k)=max_(0<=s<=1) binom(n,k)s^k(1-s)^(n-k).

For D>1 freeze the pair allocation

    omega_D(y,z)=1{|y-z|_infinity<=Db},
    b_D(z)=beta(Q_(2Db)(z)),
    X_D(z)=kappa gamma^(n/2)b_D(z)/(q_-a^n).

The allocation is independent of actual receiver, scales, softness, and clock. Its near cube is CLOSED; the complementary far relation is STRICT >Db. Define

    F_(A,theta)(u)=min(1,u)+integral_1^A min(1,u/v^theta)dv/v.

Then the following unconditional source-weighted estimate holds:

    T_* <= integral nu(dz) F_(A,3/4)(X_D(z))
              +(16/9) A_n n Csoft_n exp(1-D) W_beta.     (S1)

No local-density hypothesis is required. Each original hard-source point is charged once through the displayed nu integral. The far beta fee is also paid once. There is no spatial-grid multiplicity, source-per-pair copy, or factor such as 3^n.

Consequently, for any epsilon>0 with

    D_epsilon=1+log[(16/9)A_n n Csoft_n/epsilon]>1,

we have

    T_* <=epsilon W_beta
       +integral nu(dz)F_(A,3/4)(
          kappa gamma^(n/2)beta(Q_(2D_epsilon b)(z))/(q_-a^n)). (S2)

For an arbitrary epsilon one may instead take any D>1 making the coefficient in (S1) at most epsilon. The particularly useful range 0<epsilon<=1 automatically gives D_epsilon>1, since Csoft_n>=2 and A_n>=1. The outside original low-raw factor Lambda multiplies (S1)-(S2) once. No posterior or continuous-score multiplier is inserted.

This is an unconditional improvement from the global beta column mass to a genuinely local mass at radius O(b log(n/epsilon)). It does not assert a universal root bound for the remaining nu-weighted local concentration integral.

## 2. Merging all bands before FIRST, including both orientations

For clarity, the merged-column theorem independently established and audited by the parent is recorded here with its normalization. The original low,m>M inequalities imply

    p_y<kappa c_j^(n/2)g^(-n).

If L>R, c_j<=1 and g>=R give p_y<=kappa R^(-n). If L<=R, the original band gives c_j<=gamma sqrt(L/R), hence

    p_y<=kappa gamma^(n/2)L^(-n/4)R^(-3n/4).

Since L>=a, both orientations satisfy the common ACTUAL height inequality

    p_y<=kappa gamma^(n/2)a^(-n/4)R^(-3n/4).             (S3)

For L>R the comparison uses R>=a. Thus the low/high gate has been used before any positive enlargement. The original e is not replaced by beta mass; it cancels only between its actual two defining inequalities.

For any fixed pair mask 0<=omega(y,z)<=1, let b_omega(z)=integral omega(y,z)beta(dy). At an original receiver, integrate beta first. Original FIRST gives the beta-integrated factor at most one, while (S3) and q>=q_- give at most

    X_omega(z)(a/R)^(3n/4),
    X_omega=kappa gamma^(n/2)b_omega/(q_-a^n).

These two estimates concern the SAME actual response and source, and combine into their minimum. All original bands and both orientations have already been included here: no sum over j remains. The hard physical-scale envelope is exactly

    integral_x sup_(a<=R<=b) R^(-n)1_(Q_R(z))(x)
                       min{1,X_omega(a/R)^(n theta)}
       =F_(A,theta)(X_omega).                            (S4)

Indeed the scalar coefficient decreases with R. On Q_a the maximum is at a; on the infinity-radius shell 2|x-z|_infinity=R it is at R. Integrating the shell volume d(R^n) and substituting v=(R/a)^n proves (S4). This includes singleton scale windows and all endpoint equalities.

For theta>0 the exact function is

    F_(A,theta)(u)=u[1+(1-A^(-theta))/theta],  0<=u<=1;
    F_(A,theta)(u)=1+(log u)/theta
                       +(1-u A^(-theta))/theta, 1<=u<=A^theta;
    F_(A,theta)(u)=1+log A,                         u>=A^theta.

The branches agree at endpoints. In particular

    F_(A,3/4)(u)<=min{1+log A, 7/3+(4/3)log_+u}.        (S5)

The min bound is also valid at u=0 by interpreting the exact value there as zero; the displayed majorant need not be sharp. Applying (S4) with omega=omega_D proves the near term in (S1). The hard cap is not used for this near-column step.

## 3. The true common-soft tail and its exact positive expansion

Use the actual one-dimensional profiles

    h=1_[-1/2,1/2], w(t)=integral_0^1 exp(-|t|/r)dr,
    phi=h*w, f_s=(1-s)h+s phi.

Both h and phi are probability densities, even and nonincreasing away from zero. The full common-soft profile is

    H(v)=sup_(0<=s<=1) product_i f_s(v_i).

Its positive expansion is

    H(v)<=sum_(k=0)^n a_(n,k)Q_k(v),

where Q_k is the average of the product probability densities with exactly k phi coordinates and n-k hard coordinates. Every Q_k is nonincreasing along rays from zero. This is one common softness parameter, not an independent maximization of each coordinate. The exact coefficients satisfy

    a_(n,k)=a_(n,n-k),
    sum_k k a_(n,k)=(n/2)Csoft_n,
    Csoft_n<=1+(pi/2)sqrt(n).                            (S6)

The coefficient symmetry supplies the n/2 rather than n in the tail bound below.

For r>1/2, the ACTUAL one-dimensional soft tail is

    t_phi(r)=integral_(|v|>r)phi(v)dv
       =2 integral_0^1 u^2 exp(-(r-1/2)/u)(1-exp(-1/u))du
       <=(2/3) exp(-(r-1/2)).                           (S7)

To derive the equality, integrate the convolution h*w first in its hard coordinate, then its positive half-line v>r, and use symmetry. All integrands are nonnegative. The upper bound uses exp(-(r-1/2)/u)<=exp(-(r-1/2)) for 0<u<=1, 1-exp(-1/u)<=1, and integral_0^1 u^2 du=1/3.

For Q_k and r>1/2, every hard coordinate lies in [-r,r], so the exact product tail is

    integral_(|v|_infinity>r)Q_k(v)dv=1-[1-t_phi(r)]^k.

Therefore

    integral_(|v|_infinity>r)H(v)dv
       <=sum_k a_(n,k){1-[1-t_phi(r)]^k}
       <=(n/2)Csoft_n t_phi(r)
       <=(n/3)Csoft_n exp(-(r-1/2)).                    (S8)

The first expression is a sharper finite coefficient formula and may be retained. The last bound is the simple explicit receipt used in (S1). No coordinatewise-max product with exponential mass has been substituted for H.

## 4. Tail supremum over the physical soft scales

For any nonnegative integrable ray-decreasing profile G, the usual positive layer-cake scale envelope gives the pointwise majorant

    sup_(a<=L<=b)L^(-n)G(x/L)
       <=b^(-n)G(x/b)+n integral_a^b L^(-n)G(x/L)dL/L.  (S9)

For a star-shaped indicator superlevel set the identity is exact; positive layer cake gives the indicated inequality for a general profile. This is a fixed positive majorant of the full scale supremum, not a fixed-scale integral with a selector substituted afterward. It may be applied to H itself, which is ray-decreasing, or componentwise to the Q_k expansion.

Restrict the receiver integral to |x-y|_infinity>rb, where r>1/2. At each L<=b, the normalized cutoff is rb/L>=r. Positive Tonelli and (S9) therefore give

    integral_(|x-y|_infinity>rb)
             sup_(a<=L<=b,s) P_(s,L)(x-y)dx
       <=A_n integral_(|v|_infinity>r)H(v)dv
       <=A_n(n/3)Csoft_n exp(-(r-1/2)).                 (S10)

All normalization factors and the physical scale factor A_n are retained. The tail estimate is valid for arbitrary receiver-dependent common s and L. It uses no hypothetical future FIRST and grants no cap to H or its enlarged scale envelope.

## 5. Paying the far traffic in the original integration order

On an actual positive hard edge, h_R(x-z)>0 implies |x-z|_infinity<=R/2<=b/2. If the frozen far relation |y-z|_infinity>Db holds, the triangle inequality gives

    |x-y|_infinity>(D-1/2)b.

Consequently the original far traffic is positively bounded by the traffic carrying this last soft receiver cutoff. Now integrate the ORIGINAL hard source at the SAME actual receiver, applying h_R*nu(x)<=4lambda before extending the receiver set. Since q(x)>=q_-, its ratio is at most 16/3. Thus

    T_far <=(16/3) integral beta(dy)
          integral_(|x-y|_infinity>(D-1/2)b)
                   sup_(a<=L<=b,s)P_(s,L)(x-y)dx.

Use (S10) at r=D-1/2>1/2. This yields

    T_far <=(16/9) A_n n Csoft_n exp(1-D) W_beta.        (S11)

This actually pays that far part of any original positive traffic with the stated actual hard cap; it does not require low, high m, or either scale orientation. For (S1), apply it to the original T_* subtraffic. The original near and far pair allocations add to one exactly, including their stated boundary conventions. Combining (S11) with section 2 proves (S1).

There is no hidden repeat charge: the far integral collapses to one integral of beta because the whole original nu response was capped once at its actual receiver. For the near part, each z has exactly one frozen local beta mass b_D(z), and its price is integrated against original nu once. The proof never expands b_D into a grid sum or grants a fresh source budget per spatial box.

## 6. What remains and what is now paid

Formula (S2) is a full-source, all-softness, all-orientation, all-band inequality. It replaces the R295 total beta mass inside the column fee by beta(Q_(2Db)(z)) and pays the discarded spatial tail explicitly. Hence a large number of separated source components does not by itself enlarge every column through the total mass W_beta.

The remaining quantity is the concrete source interaction

    integral nu(dz)F_(A,3/4)(
           kappa gamma^(n/2)beta(Q_(2Db)(z))/(q_-a^n)).   (S12)

A root conclusion still requires a source-conserving bound on (S12), or a sharper estimate retaining the actual receiver restrictions instead of the column supremum. The original hard cap is available at actual receivers; it is not a density cap on nu at source centers z. FIRST controls the actual soft response, not the mass beta(Q_(2Db)(z)). Neither can be replaced by those stronger assertions.

In particular, the elementary Lebesgue weak estimate for z↦beta(Q_(2Db)(z)) does not control its integral against arbitrary concentrated nu. Reusing beta in many local columns is visible in (S12); it has not been charged for free to beta. The point of the present theorem is the unconditional localization and the explicitly paid far term, not a claim that locality alone removes the concentration fee.

No further source extraction is asserted here. The separate column-capacity/transport task can use (S12), but its allocation costs must be proved. The main global root problem and any other original unpaid ledger entries remain open.

## 7. Actual finite checks and frozen scope

Local Python was actually run in three parameter stages. The true one-dimensional tail formula (S7) was evaluated at r=0.500001,0.6,1,2,5,20 by composite Simpson integration with 2000 and 4000 subintervals. Every value obeyed the stated exponential bound; the largest difference between the two resolutions was 4.718447854656915e-16. This is a numerical diagnostic, not a certified quadrature error bound.

The coefficient symmetry and exact product-tail/union comparison in (S8) passed 42 cases at n=1,2,3,8,16,100,10000. Separately, 96 exact Fraction calculations checked the scale-tail envelope on nested finite scale menus for anisotropic rectangular probability profiles, at n=1,2,3,8,16,64. Menus had 2,4,8,16 subdivisions of [1,2], coordinate widths cycled through 1/2,1,3/2,5/2, and normalized infinity cutoffs were 1/2,3/4,1,2. Their exact outside-volume formula is

    V_out(L)=L^n product_i w_i - product_i min(L w_i,2rb),

and the finite-menu envelope integral is

    V_out(a)/(a^n product_i w_i)
       +sum_i [V_out(L_i)-V_out(L_(i-1))]/(L_i^n product_i w_i).

Every menu refinement increased this exact integral and remained below A_n times the normalized b-scale tail volume. These tests include threshold equalities, empty tails, and non-cubic star-shaped profiles. They check the full-profile-majorant tail argument; the tail-truncated profile itself was never asserted ray-decreasing.

The independent audit screened the merged all-orientation column mechanism and the spatial coefficient 16/9 before freeze. The present deliverable is only /tmp/r296_spatial_geometry.md. No other author file, repository, or Git state was changed. Final file-level audit should bind the complete artifact hash.
