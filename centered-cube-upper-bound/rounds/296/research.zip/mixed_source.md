# R296 — a sharp mixed-source budget from a frozen row capacity

## 1. Screen and theorem

A genuine fixed-source row capacity is enough to remove every column supremum. Jensen applies to the TOTAL pair allocation before charging either source. The resulting sharp mass-ratio bound has only a logarithmic dependence on the normalized row capacity when converted into a joint beta-plus-nu budget. The row capacity remains a hypothesis unless a real original-cap witness cover supplies it. Arbitrary concentration of individual columns is permitted.

Let beta,nu be finite positive L1 sources on R^n, of masses B,N. Put Q=q_-a^n>0. Let omega(y,z) be measurable, 0<=omega<=1, frozen independently of the receiver, physical selector and auxiliary clock. Define

    b_omega(z)=integral omega(y,z)beta(dy),
    r_omega(y)=integral omega(y,z)nu(dz),
    E_omega=integral b_omega(z)nu(dz)
           =integral r_omega(y)beta(dy).

For A>=1 and 0<theta<=1 define

    F_(A,theta)(u)
       =min(1,u)+integral_1^A min(1,u v^(-theta))dv/v.

Suppose an original positive traffic satisfies the actual receiver bound leading to

    T_omega<=integral F_(A,theta)(kappa b_omega(z)/Q)nu(dz). (1)

Section 2 proves this from the actual original FIRST and the appropriate actual pointwise height; it also verifies the new all-orientation choice theta=3/4. No new FIRST or density condition is postulated in (1).

If the frozen row capacity is

    r_omega(y)<=C Q for beta-almost every y,              (2)

then the sharp bound from these source hypotheses and the functional in (1) is

    T_omega<=N F_(A,theta)(kappa E_omega/(Q N))
       <=N F_(A,theta)((kappa B/Q)min(1,CQ/N)).           (3)

Here and below zero source mass means zero traffic, without division. A convenient slightly weaker form is

    T_omega<=N F_(A,theta)(kappa C B/N).                 (4)

The original source masses, their ratio, Q, C and kappa are all retained. The stronger bound (3) also records omega<=1, through r_omega<=N.

More generally, if r_omega(y)<=Q C(y), then replace the last argument of (3) by

    [kappa/(Q N)] integral min(Q C(y),N)beta(dy).        (5)

These estimates are optimal for the stated source constraints and functional (1): the fractional allocation omega(y,z)=min(1,CQ/N), constant in y,z, attains (3)'s Jensen and capacity bounds. For (5), use omega(y,z)=min(1,Q C(y)/N). This claims sharpness of the source transfer, not that the original cube traffic necessarily attains its relaxation.

## 2. The actual all-orientation height supplies the functional

Retain the original traffic and masks from /tmp/r295_reverse_geometry.md, q_-<=q(x)<=lambda, and the ORIGINAL FIRST integral p_y beta(dy)<=q(x). The original low and high gates imply

    p_y<kappa0 c_j^(n/2)g^(-n),
    kappa0=2K/(ell M), g=sqrt(LR),
    a<=L,R<=b, c_j/gamma<=min(L,R)/g<=c_j,
    gamma=1+1/n.

This uses the original FULL e_g in BOTH gates; no local substitute for e or m is made. If L<=R, c_j<=gamma L/g, hence

    p_y<=kappa0 gamma^(n/2)L^(-n/4)R^(-3n/4)
        <=kappa a^(-n/4)R^(-3n/4),
    kappa=kappa0 gamma^(n/2)<=sqrt(e) kappa0.             (6)

If L>R, the simpler original estimate p_y<=kappa0 R^(-n) is stronger than (6), since R>=a. Thus (6) holds on BOTH orientations, all original bands and all actual softness values. More generally assume the point height

    p_y<=kappa a^(-n(1-theta))R^(-n theta).              (7)

For each original receiver x and fixed z, integrate beta first, keeping all actual masks until applying (7). Original FIRST and omega<=1 give an upper bound one for that beta integral divided by q. Height (7) gives the simultaneous upper bound

    [kappa b_omega(z)/Q](a/R(x))^(n theta).

There is no band sum: (7) is uniform over the actual unique j before the beta integral is enlarged. Multiply the minimum of these two bounds by the actual h_R(x-z). The exact hard physical-scale envelope is

    integral_x sup_(a<=R<=b) h_R(x-z)
        min(1,u(a/R)^(n theta))dx=F_(A,theta)(u),
    A=(b/a)^n.                                         (8)

Indeed on Q_a the envelope is a^(-n)min(1,u); outside Q_a it is evaluated at R=2|x-z|_infinity. The substitution v=(R/a)^n gives (8). The selected coefficient is decreasing in R, so no unproved selector interchange is needed. Apply (8), positive Tonelli over nu, and retain the original q_- in Q to prove (1).

This proof uses FIRST only at the actual original receivers before extending their integration positively. It does not need a FIRST assertion for nu or beta at other points, and does not use the hard cap to manufacture source density. The hard cap is available for the separate witness capacities in Section 6. All original low-pe, high-m, forbidden, accepted and history qualifications stay in the left side. Original outside factors multiply the final raw receipts once.

## 3. Concavity, the exact mass ledger, and its proof

Put S=A^theta. The scalar function is explicitly

    F_(A,theta)(u)=u[1+(1-S^(-1))/theta],    0<=u<=1;
    F_(A,theta)(u)=1+[log u+1-u/S]/theta,   1<=u<=S;
    F_(A,theta)(u)=1+log A,                u>=S.          (9)

At A=1 it is min(1,u). The branches agree at their endpoints, and the derivative drops by one at u=1. Therefore F is increasing and concave, including both kinks. A small derivative qualification matters: uF'(u)<=1/theta holds for u>1, but is not a global assertion; below one its maximum is 1+(1-S^(-1))/theta. None of the proof discards this first min(1,u) term.

Apply Jensen with the probability nu/N to (1). The source ledger is exact by positive Tonelli, with

    E_omega<=B min(CQ,N).

Monotonicity then proves (3); E_omega<=CQ B proves (4). The same argument with E_omega<=integral min(Q C(y),N)beta proves (5). There is no endpoint weak Young argument or use of Lebesgue level volumes against beta. The integrals are finite on infinite domains: b_omega<=B, and F is bounded when A<infinity. Its A=infinity majorant below is also bounded at this fixed argument kappa B/Q.

For an explicit asymmetric pair of source fees, any nonnegative supergradient t of F at u0 gives

    T_omega<=kappa C t B+[F(u0)-u0 t]N.                 (10)

For 1<=u0<=S choose t=(1/u0-1/S)/theta, giving

    T_omega<=[kappa C/theta](1/u0-1/S)B
                                +[1+log(u0)/theta]N.   (11)

At u0=1 choose that RIGHT supergradient; at u0=S it is zero. The purely linear bound T<=kappa C[1+(1-S^(-1))/theta]B is also valid. These are alternatives for the SAME traffic, not independently spendable negative credits. Formula (5) permits replacing C B in (10)-(11) by integral C(y)beta(dy) when finite, or the sharper capped row integral divided by Q.

## 4. Optimal two-source coefficient, including finite physical width

Write a0=kappa C (this scalar is unrelated to the lower physical length a). Define

    c_(theta,A)(a0)=sup_(t>=0) F_(A,theta)(a0 t)/(1+t).

Then (4) gives the joint-source receipt

    T_omega<=c_(theta,A)(a0)(B+N).                      (12)

This is the best uniform coefficient relative to B+N derivable from (4). It is also optimal under the full row hypotheses across arbitrary masses: take N>=CQ so that the row bound is active, set B/N to the maximizing t, and use the constant fractional allocation from Section 1.

At a0=0 put c=0. At A=1,

    c_(theta,1)(a0)=a0/(1+a0).

For A>1 set S=A^theta and f1=1+(1-1/S)/theta. Then

    c_(theta,A)(a0)=a0 f1/(1+a0),
                  if a0(1-1/S)<=theta;                 (13)

otherwise

    c_(theta,A)(a0)
       =[W(a0 exp(theta+a0/S))-a0/S]/theta.             (14)

Here W is the nonnegative real solution of w exp(w)=x, defining it without an external special-function estimate. To prove these formulas, put u=a0 t. The quotient a0 F(u)/(a0+u) increases for u<1 and decreases after S. Its right derivative at one has the sign a0(1-1/S)-theta. If this sign is positive, the unique stationary point in (1,S) solves

    a0/u=theta+a0/S+log u,
    u=a0/W(a0 exp(theta+a0/S)).

At that point the quotient equals a0 F'(u), which is (14). If the sign is nonpositive, the maximum is at the kink u=1. This proves both branches and their equality case.

The exact optimal coefficient UNIFORM over the physical width A is

    c_theta(a0):=sup_(A>=1)c_(theta,A)(a0)
       =(1+1/theta)a0/(1+a0),              0<=a0<=theta;
       =W(a0 exp(theta))/theta,            a0>=theta.   (15)

Indeed F increases with A and tends to the function (1+1/theta)u below one and 1+(1+log u)/theta above one. The same derivative argument proves (15). At a0=theta both values equal one. A useful elementary consequence is

    c_theta(a0)<=1+(1/theta)log_+(a0/theta).             (16)

For a0>=theta, the defining equation w+log w=log a0+theta and w>=theta imply w<=theta+log(a0/theta). For a0<=theta, the first branch is at most one. Thus the fee is logarithmic in kappa C, rather than its square root or a column supremum.

For the actual all-orientation height theta=3/4, (12) and (16) give

    T_omega<=[1+(4/3)log_+((4/3)kappa C)](B+N),
    kappa=2K gamma^(n/2)/(ell M).                       (17)

The exact F mass-ratio formula (3) can be substantially sharper than (17). Both retain arbitrary positive L1 sources, and neither requires nu<=beta.

## 5. How to combine many frozen allocations without repeatedly charging nu

Suppose omega_k>=0 are measurable frozen pair allocations and their sum omega=sum_k omega_k is <=1. If the AGGREGATE row satisfies

    integral sum_k omega_k(y,z)nu(dz)<=CQ,

apply the theorem ONCE to omega. Positive Tonelli gives T_omega=sum_k T_(omega_k) and the single fee in (12) or (17). Column masses add before Jensen. They may be arbitrarily concentrated, but no column supremum is taken.

For instance, partition the beta source into disjoint measurable sets Y_k, and let omega_k=1_(Y_k)(y)eta_k(y,z) with each row integral of eta_k at most CQ. Then the aggregate row bound holds independently of the number of pieces, and omega<=1. The theorem charges total B and total N once. This is more efficient than separately applying a nu fee to each Y_k.

Pairwise disjointness alone does not guarantee the row capacity: one y may then collect many different nu blocks. If a construction has row capacities C_k Q, their sum must be paid unless an aggregate argument improves it. Applying a bounded-column theorem to every beta piece against the full nu, or selecting a fresh favorable allocation for each receiver, is not source conservation. In all cases any part of the original traffic outside omega retains its exact old mask times (1-omega).

## 6. Actual receiver hard caps supply a genuine witness-row capacity

Here is a precise source-geometric sufficient condition that uses the REAL original hard cap. For beta-almost every y choose a finite or countable family of measurable witness maps

    x_k(y), r_k(y), with a<=r_k(y)<=b,

where EACH witness carries an original accepted-receiver cap at that SAME radius:

    nu(Q_(r_k(y))(x_k(y)))<=4lambda r_k(y)^n.             (18)

If the original maximal hard cap is known at x_k(y), it supplies (18) at every legal chosen radius. Otherwise (18) must be verified at the chosen radius; a cap at some different selected radius is insufficient. The maps and all blocks are frozen before the receiver integral. No existence or measurability of such a cover is presumed.

Let

    Z_wit(y)=union_k Q_(r_k(y))(x_k(y)),
    omega(y,z)<=1_(Z_wit(y))(z), 0<=omega<=1.

A union bound and (18) give the genuine row capacity

    r_omega(y)<=4lambda sum_k r_k(y)^n
       =(16/3)Q sum_k (r_k(y)/a)^n.                    (19)

This is a measure of actual source blocks, not a pointwise bound on nu's density. Overlap only reduces their union mass. Thus if

    sum_k (r_k(y)/a)^n<=J exp(H)

uniformly on the rows used, take C=(16/3)J exp(H). Combined with (17) and gamma^(n/2)<=sqrt(e), the covered original traffic has the explicit payment

    T_omega<={1+(4/3)log_+[(128sqrt(e)/9)
                         (K/(ell M))J exp(H)]}(B+N).    (20)

The expanded constant is (4/3)*2*(16/3)*sqrt(e); the factor two in kappa0=2K/(ell M) is retained.

Consequently, if the per-row sum in (19) is at most exp(O(sqrt(n))) and log_+(K/(ell M)) is O(sqrt(n)) (or the corresponding root-polylog quantities), the theorem gives a root (respectively root-polylog) linear price for ALL original traffic actually covered by omega. It permits arbitrarily many witness blocks when their total normalized volume has that budget. Different rows may use different witnesses and arbitrary original sources.

A particularly simple valid row uses a legal side-a cube at one original accepted receiver x(y): its capacity is C=16/3. Finite or countable beta partitions with different such witnesses can be combined as in Section 5. This is a real capacity statement, but it says nothing by itself about how much original traffic has its z in the chosen row cube. A larger witness r close to b can have normalized volume (b/a)^n; its logarithm can be order n, so the physical interval alone does not make (20) root-priced.

For the WHOLE original traffic to satisfy (20), the frozen row unions must cover every contributing hard source z for beta-almost every y and receiver-almost everywhere in the actual old traffic. Existence of such a cover with the stated sum is an additional geometric premise. The original hard cap does not itself produce that cover. In particular, one cannot choose a new witness x for each actual receiver and then call the resulting union one capacity-CQ row.

## 7. Bounded outcome, remaining premise, and finite evidence

The new proved source inequality is (3), with its exact optimal source-mass ratio, the asymmetric fee family (10)-(11), and the sharp Lambert-W joint coefficient (13)-(17). Equations (18)-(19) identify an actual receiver-local hard-cap capacity that can feed it; Sections 5-6 give the exact aggregate ledger and its coverage condition. No concentration bound on columns, source density hypothesis, source ordering or endpoint convolution estimate has been used.

For an arbitrary frozen omega without a proved row budget, the identity E_omega<=BN alone just returns the global mass functional N F(kappa B/Q). Taking C=N/Q is valid but leaves the original mass scale inside the logarithm. It is not a free general root bound. The specific missing bridge is a source-conserving witness-row cover of the intended remaining original traffic with controlled sum_k(r_k/a)^n, or another proof of its aggregate row capacity. The spatial-decay route being developed independently may supply different information; it is not assumed here.

The companion /tmp/r296_mixed_source_checks.py was actually run at 45 digits. It passed 105 finite-A coefficient cases over theta=1/4,3/4,1, A from 1 through 10^100, and normalized capacity from 10^(-6) to 10^6, checking the optimum against 81 logarithmically spaced test arguments per case and its uniform Lambert-W bound. It also passed 100 exact-Fraction row/column mass ledgers, Jensen comparisons, the sharp source-mass bound, and constant-fraction equality cases. The computed uniform coefficient at theta=3/4,a0=1 was 1.171981525825248770524642. These finite diagnostics supplement the complete proofs above and do not certify existence of a global geometric cover.

Only this temporary author note and its companion script were written. No other author files or Git state were changed.
