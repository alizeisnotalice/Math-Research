"""R862: one true-source decision emits an ordered pair of physical positions."""
from argparse import ArgumentParser
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
from itertools import combinations, product
from pathlib import Path
from zipfile import ZipFile
import json
import sys

PIN860="2b530fd04c0f05f81e7c52cf4c644b07ce25103d96967927820f011c27c9ae39"
PIN_PUBLIC="5592e50a9c03b822ab3e36d592a1556f7d14cf34658f4fac7c516b4251a16839"
TAU=F(246354331389380694725739337173509533728950922705473059,
      18748125373815017986228277802731820946303221760)
GAMMA=F(1)


def helpers(rounds):
    archive=rounds/"860"/"research.zip"
    assert sha256(archive.read_bytes()).hexdigest()==PIN860
    with ZipFile(archive) as z:
        name="public860.py"
        code=z.read(name)
        manifest=json.loads(z.read("MANIFEST.json"))
        assert sha256(code).hexdigest()==manifest["sha256"][name]==PIN_PUBLIC
        public_stdout=z.read("public860.txt")
        assert sha256(public_stdout).hexdigest()==manifest["sha256"]["public860.txt"]
        saved=public_stdout.decode().split("gamma 1 critical shared density")[1]
        saved=saved.split("tau / certified upper critical 1/4")[1].split("tau / certified upper critical 3/4")[0]
        assert "shared all, linear all, independent all, fixed min/max: [2.79058998E-1," in saved
        assert "shared hard, linear hard, independent hard, all plan on hard: [2.66797132E-1," in saved
    scope={"__name__":"split862_public","__file__":name}
    exec(compile(code,name,"exec"),scope)
    return scope


def physical_cells(parents):
    ps=tuple(parents.values())
    all_bits=sum(p["bit"] for p in ps)
    cells={all_bits:F(1)}
    witness={all_bits:()}
    for bounds in zip(*(p["box"] for p in ps)):
        faces=sorted({x for pair in bounds for x in pair})
        row=defaultdict(F)
        local={}
        for a,b in zip(faces,faces[1:]):
            pt=(a+b)/2
            mask=sum(p["bit"] for p,(lo,hi) in zip(ps,bounds) if lo<pt<hi)
            row[mask]+=b-a
            local.setdefault(mask,(a,b))
        nxt=defaultdict(F)
        reps={}
        for (mask,vol),(q,span) in product(cells.items(),row.items()):
            nxt[mask&q]+=vol*span
            reps.setdefault(mask&q,witness[mask]+(local[q],))
        cells,witness=nxt,reps
    cells.pop(0,None)
    witness.pop(0,None)
    cells=dict(sorted(cells.items()))
    assert cells and min(cells.values())>0
    for r in range(1,len(ps)+1):
        for family in combinations(ps,r):
            bit=sum(p["bit"] for p in family)
            exact=F(1)
            for axis in zip(*(p["box"] for p in family)):
                exact*=max(F(0),min(b for a,b in axis)-max(a for a,b in axis))
            assert sum(v for c,v in cells.items() if c&bit==bit)==exact
    return cells,witness


def row_specs(parents,src,raw):
    roots,arms=defaultdict(set),defaultdict(set)
    for t,left,right in raw:
        for i,y,h in (left,right):
            roots[y].add(t)
            arms[y].add(i)
            physical=parents[t]["bit"]|parents[i]["bit"]
            assert physical&y==physical
    assert roots.keys()==arms.keys() and set(roots)<=src.keys()
    return {y:(sum(parents[t]["bit"] for t in roots[y]),
               sum(parents[i]["bit"] for i in arms[y])) for y in sorted(roots)}


def plan(parents,src,raw,cells,full_signature=False):
    specs=row_specs(parents,src,raw)
    middle=sum(p["bit"] for p in parents.values() if p["role"]=="middle")
    old=sum(p["bit"] for p in parents.values() if p["role"]=="old")
    first,second={},{}
    first_density=defaultdict(F)
    second_density=defaultdict(F)
    volumes={}
    for y,(a,b) in specs.items():
        assert a&middle==a and b&old==b
        if full_signature:
            a,b=y&middle,y&old
        L=tuple(c for c in cells if c&a==a and not c&old)
        R=tuple(c for c in cells if c&b==b and not c&middle)
        vl,vr=(sum(cells[c] for c in group) for group in (L,R))
        assert 0<vl and 0<vr
        volumes[y]=vl,vr
        first[y]={c:cells[c]/vl for c in L}
        second[y]={c:cells[c]/vr for c in R}
        assert sum(first[y].values())==sum(second[y].values())==1
        for c in L:
            first_density[c]+=src[y]/(2*vl)
        for c in R:
            second_density[c]+=src[y]/(2*vr)
    assert set(first_density).isdisjoint(second_density)
    total_src=sum(src[y] for y in specs)
    assert all(sum(cells[c]*d for c,d in out.items())==total_src/2
               for out in (first_density,second_density))
    # The same half-probability sends both locations. Multiplying the
    # two normalized conditional laws is done only after this send decision.
    def h(y,a,b):
        return sum(aa*bb/2 for x,aa in first[y].items() for xp,bb in second[y].items()
                   if x&a==a and xp&b==b)
    return h,first_density,second_density,volumes


def certify_mark(records,parents,h):
    score=F(0)
    reception=[defaultdict(F),defaultdict(F)]
    for (t,l,r),weight in records.items():
        b=parents[t]["bit"]
        ends=[h(y,b,parents[i]["bit"]) for i,y,k in (l,r)]
        assert ends==[F(1,2),F(1,2)]
        x=min(F(1),sum(ends)/GAMMA)
        assert x==1
        score+=weight*x
        for role,(i,y,k) in enumerate((l,r)):
            reception[role][i,k]+=weight*x
    assert score==sum(records.values())==sum(reception[0].values())==sum(reception[1].values())
    assert all(v<=parents[i]["owner_volume"]/2 for table in reception for (i,k),v in table.items())
    return score,tuple(max(2*v/parents[i]["owner_volume"] for (i,k),v in table.items())
                       for table in reception)


def diagonal_upper(obs,cells,src,tau,mass):
    coeff=defaultdict(F)
    for (z,a,q,b),weight in obs.items():
        for y,gate in ((z,a),(q,b)):
            for c in cells:
                if c&gate==gate:
                    coeff[y,c]+=weight/(GAMMA*src[y])
    return tau*sum(volume*max(coeff[y,c] for y in src) for c,volume in cells.items())/mass


def replay(rounds):
    public=helpers(rounds)
    parents,src,raw,hard,fmt,pin,cut=public["load"](rounds)
    cells,reps=physical_cells(parents)
    gates,_=public["physical_cells"](parents,raw)
    assert all(cells[c]==v for c,v in gates.items())
    F0=sum(raw.values())
    h,L,R,vols=plan(parents,src,raw,cells)
    whole,um=certify_mark(raw,parents,h)
    difficult,hm=certify_mark(hard,parents,h)
    assert whole==F0 and difficult==cut[2]
    slots=L,R
    peak=[max(table.values()) for table in slots]
    peak_at=[tuple(c for c,x in sorted(table.items()) if x==p)
             for table,p in zip(slots,peak)]
    assert all(p<TAU/2 for p in peak)
    strict=F(1,2**20)
    while strict<=max(peak):
        strict*=2
    one_count=sum(c.bit_count()==1 for c in cells)
    one_volume=sum(v for c,v in cells.items() if c.bit_count()==1)
    print("Python",sys.version.split()[0],"; Fraction transport and physical target proof, no optimizer.")
    print("Pinned R860",PIN860,"; pinned public860.py",PIN_PUBLIC,"; R814",pin)
    print("Physical positive parent-membership cells",len(cells),"; volume",sum(cells.values()),
          "; singly parented",one_count,"of volume",one_volume)
    print("Every nonempty parent intersection recovers its unique exact physical volume.")
    print("Full/hard original rows",len(raw),len(hard),"; active physical source cells",len(vols),
          "; all original source cells",len(src))
    print("Input uses one half-probability common send decision. Inactive physical sources send zero.")
    print("Conditioned on send, first position uniform on all required middle boxes with all old boxes excluded;",
          "second position uniform on all required old boxes with all middle boxes excluded.")
    print("Actual ordered pair regions are disjoint by role. Both marginals are judged globally against a separate tau dx.")
    print("Minimum true admissible output volumes L,R:",
          min(v[0] for v in vols.values()),min(v[1] for v in vols.values()))
    print("Active true source mass, total output mass in each slot:",sum(src[y] for y in vols),
          sum(src[y] for y in vols)/2)
    print("Exact peaks per slot",*peak)
    print("Peak intervals L,R",*(fmt(x) for x in peak),"; cells attaining",peak_at)
    print("Strict common density budget per slot adequate for full marking",strict,
          "; demonstrated actual peak of aggregate density",fmt(max(peak)))
    print("Aggregate peaks equal slot max because the distinct actual output regions are disjoint.")
    print("All original and hard-cut branches are individually fully marked, each arm hit =1/2, gamma=1.")
    print("Original F, full/hard marked over F:",fmt(F0),fmt(whole/F0),fmt(difficult/F0))
    print("Original U/W max actual full and hard weight per half Lebesgue:",
          tuple(fmt(v) for v in um),tuple(fmt(v) for v in hm))
    print("Two-slot split and record-by-record split both attain all eligible mass.")
    hp,Lp,Rp,_=plan(parents,src,raw,cells,full_signature=True)
    assert certify_mark(raw,parents,hp)[0]==whole and certify_mark(hard,parents,hp)[0]==difficult
    alt=max(max(Lp.values()),max(Rp.values()))
    assert alt<TAU/2
    print("Complete-signature role selection, independent of the observed branch catalog, also marks every record;",
          "actual aggregate peak",fmt(alt),"; peak < 1/1024:",alt<F(1,1024))
    print("Saved R860 quarter-critical tau",fmt(TAU),"; tau/2 on both slots also fits original total density.")
    all_old,hard_old=public["group"](raw,parents),public["group"](hard,parents)
    print("One-position bounds at the same scales, normalized by full F; old lower scaled by concavity.")
    for theta in (F(1),F(1,2)):
        tau=theta*TAU
        print(" tau factor",theta,"; each two-slot cap",fmt(tau))
        for name,obs,weight,base in (
            ("all",all_old,whole,F("0.279058998")),
            ("hard",hard_old,difficult,F("0.266797132")),
        ):
            upper=diagonal_upper(obs,gates,src,tau,F0)
            lower=theta*base
            independent=sum(public["separate_records"](obs,src,gates,tau,GAMMA,F0))
            assert lower <= upper < independent < weight/F0
            print("  ",name,"one-position shared",fmt(lower,upper),"; one-position independent",fmt(independent),
                  "; two-position shared and independent",fmt(weight/F0))
    print("Physical per-slot witness boxes at one maximizing target of each role:",
          tuple(reps[q[0]] for q in peak_at))
    print("Finite geometric marking certificate. No old contract payment inference.")


if __name__=="__main__":
    parser=ArgumentParser()
    parser.add_argument("--rounds",type=Path,required=True)
    replay(parser.parse_args().rounds)

