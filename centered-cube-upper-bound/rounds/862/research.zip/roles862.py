"""Physical role-signature obstruction with shared true source stock."""

from fractions import Fraction as F
from itertools import product
from math import comb, prod
from sys import version

S = F(1, 4)
TAU = F(1)
LAMBDA = F(1)
T = F(3, 4)
I = F(1, 2)


def volume(box):
    return prod(hi-lo for lo,hi in box)


def overlap(a, b):
    return prod(max(F(0),min(q,s)-max(p,r)) for (p,q),(r,s) in zip(a,b))


def binary_floor(value):
    estimate = value.numerator.bit_length()-value.denominator.bit_length()
    return estimate-(value < F(2)**estimate)


def role_box(side, signs, n, epsilon, core=None):
    center = tuple(sign*(side-epsilon) for sign in signs)+(F(0),)*(n-len(signs))
    radius = side if core is None else core
    return tuple((c-radius,c+radius) for c in center)


def cap_measure(n, d, epsilon, side):
    """Lebesgue capacity of all cells with j wildcard coordinates."""
    return [TAU*comb(d,j)*2**(d-j)*(2*epsilon)**j
            *(2*side-2*epsilon)**(d-j)*(2*side)**(n-d)
            for j in range(d+1)]


def top_stock(capacity):
    remaining = S
    used = [F(0)]*len(capacity)
    for j in reversed(range(len(capacity))):
        used[j] = min(remaining,capacity[j])
        remaining -= used[j]
    assert remaining == 0
    assert used[1:] == capacity[1:]
    return used


def extras(capacity):
    return sum((2**j-1)*amount for j,amount in enumerate(capacity))


def cartesian_optimum(large, small, k):
    """Exact monotone primal and layer-cake upper bound for the full Cartesian family."""
    # Volumes are dyadic. One integer unit makes the whole transport exact
    # without long rational additions for every joint tail.
    unit = max(value.denominator for value in (*large,*small))
    assert unit % S.denominator == 0
    total = S.numerator * (unit // S.denominator)

    def units(values):
        assert all(unit % value.denominator == 0 for value in values)
        return [value.numerator*(unit//value.denominator) for value in values]

    cap_left,cap_right = units(large),units(small)
    left,right = units(top_stock(large)),units(top_stock(small))
    lrem,rrem = left[:],right[:]
    joint = {}
    for i in reversed(range(len(large))):
        for j in reversed(range(len(small))):
            amount = min(lrem[i],rrem[j])
            if amount:
                joint[i,j] = amount
                lrem[i] -= amount
                rrem[j] -= amount
    assert not any(lrem) and not any(rrem)
    assert sum(joint.values()) == total
    for i in range(len(large)):
        assert sum(x for (a,_),x in joint.items() if a==i) == left[i] <= cap_left[i]
        assert sum(x for (_,b),x in joint.items() if b==i) == right[i] <= cap_right[i]
    primal = sum(2**(i+j)*x for (i,j),x in joint.items())
    # Kernel multiplicity 2^j=sum_{i<=j} jumps[i]. For every threshold pair,
    # the joint tail is capped by the two true marginal capacities and S.
    jumps = [1]+[2**(i-1) for i in range(1,len(large))]
    tails_left = [sum(cap_left[i:]) for i in range(len(large))]
    tails_right = [sum(cap_right[i:]) for i in range(len(small))]
    tails = [[0]*(1+len(small)) for _ in range(1+len(large))]
    upper = 0
    for i in reversed(range(len(large))):
        for j in reversed(range(len(small))):
            ceiling = min(total,tails_left[i],tails_right[j])
            actual = (joint.get((i,j),0)+tails[i+1][j]+tails[i][j+1]-tails[i+1][j+1])
            assert actual == ceiling
            tails[i][j] = actual
            upper += jumps[i]*jumps[j]*ceiling
    assert primal == upper
    # Given levels, choose each side's sign pattern uniformly and independently.
    # Its label inclusion fraction is 2^i/k, so all k^2 scores agree.
    return F(primal,total*k*k)


def independently_audit_small_geometry(n,d,epsilon,side,packets,capacity):
    signs = tuple(product((-1,1),repeat=d))
    parents = [role_box(side,s,n,epsilon) for s in signs]
    cores = [role_box(side,s,n,epsilon,F(1,64)) for s in signs]
    assert all(overlap(a,b) == 0 for i,a in enumerate(cores) for b in cores[i+1:])
    assert all(overlap(packet,parent)==volume(packet)
               for packet in packets for parent in parents)
    edge = 2*side-epsilon
    axis = ((-edge,-epsilon),(-epsilon,epsilon),(epsilon,edge))
    profile = [F(0)]*(d+1)
    for pattern in product(range(3),repeat=d):
        cell = tuple(axis[i] for i in pattern)+((-side,side),)*(n-d)
        true = sum(overlap(cell,parent)==volume(cell) for parent in parents)
        assert true==2**pattern.count(1)
        profile[pattern.count(1)] += TAU*volume(cell)
    assert profile==capacity


def factored_score(name, score, denominator, n):
    excess = score*denominator-1
    assert excess > 0
    power = binary_floor(excess)
    print(f"  {name}=(1+e)/{denominator}, with 2^{power} <= e < 2^{power+1}")
    if n <= 2:
        print(f"    exact score={score}")


def exercise(label,n,d):
    k = 2**d
    epsilon = F(1,2**(5*n+8))
    source_cores = []
    for shift in (-1,1):
        active = ((shift*epsilon/4-epsilon/16,shift*epsilon/4+epsilon/16),)
        active += ((-epsilon/16,epsilon/16),)*(d-1)
        source_cores.append(active+((F(-1,8),F(1,8)),)*(n-d))
    assert overlap(*source_cores)==0
    common = ((-epsilon,epsilon),)*d+((-I,I),)*(n-d)
    assert all(overlap(p,common)==volume(p)>0 for p in source_cores)
    true_stock = (S/4,3*S/4)
    assert sum(true_stock)==S
    b_vol = sum(map(volume,source_cores))
    assert all(mu/volume(packet)>TAU and mu/volume(packet)>F(3,2)
               for mu,packet in zip(true_stock,source_cores))
    # Ambient f=3/2 outside B in [-2,2]^n and equals true source density on B.
    # All sign-ray actual receiver cores are deep enough for every side in [1,2].
    core_half = F(1,64)
    assert T-epsilon+core_half+1<2
    assert LAMBDA<F(3,2) and F(3,2)+S<2*LAMBDA
    core_vol = (2*core_half)**n
    mt = F(3,2)*(2*T)**n+S-F(3,2)*b_vol
    mi = F(3,2)*(2*I)**n+S-F(3,2)*b_vol
    arm_factor = core_vol**2/(mt*mi)
    original = S*arm_factor

    large = cap_measure(n,d,epsilon,T)
    small = cap_measure(n,d,epsilon,I)
    if d<=4:
        independently_audit_small_geometry(n,d,epsilon,T,source_cores,large)
        independently_audit_small_geometry(n,d,epsilon,I,source_cores,small)
    for capacity,side in ((large,T),(small,I)):
        assert sum(capacity)==TAU*(4*side-2*epsilon)**d*(2*side)**(n-d)
        assert extras(capacity)==TAU*k*(2*side)**n-sum(capacity)
        assert 0<sum(capacity[1:])<S<capacity[0]
    assert all(a>=b for a,b in zip(large,small))

    # One shared law per actual source. Each packet has all k labels, with
    # alignment on one packet and antipodal pairing on the other.
    # Per wildcard pattern, match the two real cells (or their antipodes);
    # the small role is the capacity bottleneck. Conditional supports keep the
    # same uniform pattern masses on both packets, so the true stocks pool.
    selected_small = top_stock(small)
    assert all(x<=min(a,b) for x,a,b in zip(selected_small,large,small))
    aligned_mass = sum(2**i*x for i,x in enumerate(selected_small))
    assert aligned_mass==S+extras(small)
    # The total number of aligned hits at any two positions is at most the
    # small-role multiplicity. The total extra multiplicity is at most its
    # true capacity integral. Uniform sign-patterns attain equal scores.
    p_aligned = aligned_mass/(S*k)

    # The corresponding marginal-only tests have their own physical caps.
    single = []
    for capacity in (large,small):
        primal = sum(2**i*x for i,x in enumerate(top_stock(capacity)))
        assert primal==S+extras(capacity)
        single.append(primal/(S*k))
        assert primal/(S*k)<1

    p_cartesian = cartesian_optimum(large,small,k)

    # Independently conditioned positions, even with a separate law for each z.
    # If m is its total conditional mass and every label hits at least g,
    # g<=m<=1 and e_T(z)+e_I(z)>=2(k*sqrt(g*m)-m) by AM-GM and Cauchy.
    # The minimum over m is at g or 1. Its first endpoint exceeds the global
    # available excess for all g>=1/k^2, yielding the rational upper bound.
    pooled_excess = (extras(large)+extras(small))/S
    lower_independent = F(1,k*k)
    assert pooled_excess<2*F(k-1,k*k)
    upper_independent = (1+pooled_excess/2)**2/(k*k)
    assert lower_independent<=p_cartesian<p_aligned<1

    # If the current labels are supplied to the sender, choose the respective
    # exclusive sign cell at each end. The stock at any exclusive cell is S/k,
    # even though each physical source participates in all the histories.
    assert S/k<=min(large[0],small[0])/k
    load_seen = S/min(large[0],small[0])
    assert load_seen<1

    def passes(score):
        return n * score**4 >= 1

    def passing_share_power(score):
        # The fourth power of (score / gamma) is rational, with gamma=n^(-1/4).
        return binary_floor(n*score**4)//4 + 1

    print(f"{label} n={n}, active coordinates={d}, labels per role={k}, epsilon=2^-{5*n+8}, delta=0")
    print(f"  true source masses={true_stock[0]},{true_stock[1]}, shared total={S}, actual original record mass=S*(1/32)^(2n)/(m_t m_i)")
    assert original>0
    if n==2:
        print(f"    exact original mass={original}")
    print(f"  cap-integral excess / S for middle and small has floor log2 "
          f"{binary_floor(extras(large)/S)}, {binary_floor(extras(small)/S)}")
    factored_score("middle-only shared maximin",single[0],k,n)
    factored_score("small-only and correlated joint maximin",p_aligned,k,n)
    factored_score("Cartesian hidden-label joint maximin",p_cartesian,k*k,n)
    print(f"  conditionally independent robust hit >=1/{k*k}, with excess factor "
          f"<= 2^{binary_floor(upper_independent*k*k-1)+1} above this lower endpoint")
    print(f"  seeing the actual record labels gives hit 1, peak marginal/cap < "
          f"2^{binary_floor(load_seen)+1}")
    print(f"  threshold n^(-1/4), tested by fourth powers: correlated-all={'yes' if passes(p_aligned) else 'no'}, "
          f"Cartesian-all={'yes' if passes(p_cartesian) else 'no'}, "
          f"independent-all={'no' if not passes(upper_independent) else 'yes' if passes(lower_independent) else 'undecided'}")
    if not passes(p_aligned):
        print(f"    correlated-family passing share at most 2^{passing_share_power(p_aligned)}")
    if not passes(p_cartesian):
        print(f"    Cartesian-family passing share at most 2^{passing_share_power(p_cartesian)}")


if __name__ == "__main__":
    print(f"Python {version.split()[0]}, exact Fraction with true physical cube cells.")
    print("Actual middle and small sides are 3/2 and 1. All real source packets are interior to all parents.")
    print("Ambient max is in (1,2) on the whole physical side window for all genuine receiver cores.")
    print("Each true source point has every role signature in its family with equal original weight.")
    print("The correlated family pairs identical labels on one source and antipodal labels on the other.")
    print("The Cartesian family hides both role labels. Slots have a common source-dependent law with total mass <=1.")
    print("Each pooled output marginal is bounded by tau=1 times Lebesgue measure. There is no output support restriction.")
    print("For each family the original subflow uses true disjoint receiver cores with dU dV/(m_t m_i) and splits by its number of signatures.")
    print("Large cases use exact multiplicity-level counts and transport, with scope limited to this finite physical family.")
    exercise("INITIAL",2,2)
    exercise("PRESSURE",256,2)
    exercise("EXPANDED",256,32)
