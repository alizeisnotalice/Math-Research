"""R862: finite Hall thresholds and coupled physical-capacity deficits.

For a cut, put in P the price input nodes on the sink side, and in Q the
price output nodes on the source side. Infinite arcs then force the middle
union for P and the small-parent union for Q into their charged cut sides.
If a price belongs to both P and Q, move its output node to the sink side:
this adds no source bridge to the cut and can only remove restrictions.
With P,Q disjoint, precisely the remaining price bridges cross, so the cut
is total demand minus the disjoint-pair deficit displayed by this script.
"""
from argparse import ArgumentParser
from collections import defaultdict, deque
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import runpy
import sys

PIN_SPLIT="d46734b95ca9d04644aa12a4255f626e08b00b28da6e12be27ba3a8bfe11d5bd"


def split_helpers():
    path=Path(__file__).with_name("split862.py")
    assert sha256(path.read_bytes()).hexdigest()==PIN_SPLIT
    return runpy.run_path(str(path))


def input_data(rounds):
    split=split_helpers()
    public=split["helpers"](rounds)
    parents,src,records,hard,fmt,pin,cut=public["load"](rounds)
    cells,_=split["physical_cells"](parents)
    middle=sum(x["bit"] for x in parents.values() if x["role"]=="middle")
    old=sum(x["bit"] for x in parents.values() if x["role"]=="old")
    specs=split["row_specs"](parents,src,records)
    eligible=tuple(tuple(tuple(c for c in cells if c&a==a and not c&other)
                         for a,other in zip(ab,(old,middle)))
                   for y,ab in specs.items())
    order=tuple(specs)
    assert len(records)==920 and len(hard)==848 and len(order)==10
    assert all(L and R and not set(L)&set(R) for L,R in eligible)
    assert sum(hard.values())==cut[2]
    return parents,src,records,hard,fmt,cells,order,eligible


def subset_tables(cells,req,eligible):
    count=1<<len(req)
    mask_mass=[F(0)]*count
    unions=[(0,0)]*count
    volumes=([F(0)]*count,[F(0)]*count)
    keys=tuple(cells)
    at={c:1<<i for i,c in enumerate(keys)}
    options=tuple(tuple(sum(at[c] for c in side) for side in both)
                  for both in eligible)
    memo={0:F(0)}
    def measure(bits):
        if bits not in memo:
            memo[bits]=sum(cells[c] for c in keys if bits&at[c])
        return memo[bits]
    for p in range(1,count):
        low=p&-p
        i=low.bit_length()-1
        previous=p^low
        mask_mass[p]=mask_mass[previous]+req[i]
        both=tuple(a|b for a,b in zip(unions[previous],options[i]))
        unions[p]=both
        for k in (0,1):
            volumes[k][p]=measure(both[k])
    return mask_mass,*volumes


def critical(tables):
    masses,left,right=tables
    def side(vol):
        assert min(vol[1:])>0
        value,p=max((masses[p]/vol[p],p) for p in range(1,len(masses)))
        return value,p
    return side(left),side(right)


def subsets(disjoint):
    s=disjoint
    while True:
        yield s
        if s==0:
            return
        s=(s-1)&disjoint


def deficits(tables,tau):
    masses,L,R=tables
    cuts=(tuple(m-tau*v for m,v in zip(masses,L)),
          tuple(m-tau*v for m,v in zip(masses,R)))
    I=len(masses)-1
    pair=max((cuts[0][p]+cuts[1][q],p,q) for p in range(I+1)
             for q in subsets(I^p))
    independent=tuple(max((v,p) for p,v in enumerate(side)) for side in cuts)
    assert max(v for v,p in independent)<=pair[0]<=sum(v for v,p in independent)
    return pair,independent


class Network:
    def __init__(self):
        self.adj=defaultdict(list)

    def add(self,a,b,cap):
        f=[b,len(self.adj[b]),cap,cap]
        r=[a,len(self.adj[a]),F(0),F(0)]
        self.adj[a].append(f)
        self.adj[b].append(r)
        return f

    def solve(self,source,sink,start_cap):
        value=F(0)
        while True:
            levels={source:0}
            q=deque([source])
            while q:
                a=q.popleft()
                for b,j,cap,stock in self.adj[a]:
                    if cap and b not in levels:
                        levels[b]=levels[a]+1
                        q.append(b)
            if sink not in levels:
                return value,levels
            cursor=defaultdict(int)
            def path(a,cap):
                if a==sink:
                    return cap
                row=self.adj[a]
                while cursor[a]<len(row):
                    f=row[cursor[a]]
                    b,j,r,_=f
                    if r and levels.get(b,-1)==levels[a]+1:
                        more=path(b,min(cap,r))
                        if more:
                            f[2]-=more
                            self.adj[b][j][2]+=more
                            return more
                    cursor[a]+=1
                return F(0)
            while more:=path(source,start_cap):
                value+=more


def flow(cells,order,demand,eligible,tau):
    S,T=("S",0),("sink",0)
    grand=sum(demand)
    infinite=grand+1
    net=Network()
    one={c:net.add(S,("T",c),tau*v) for c,v in cells.items()}
    two={c:net.add(("I",c),T,tau*v) for c,v in cells.items()}
    store={}
    left,right={},{}
    for y,m,(L,R) in zip(order,demand,eligible):
        a,b=("in",y),("out",y)
        store[y]=net.add(a,b,m)
        left[y]={c:net.add(("T",c),a,infinite) for c in L}
        right[y]={c:net.add(b,("I",c),infinite) for c in R}
    value,cut=net.solve(S,T,infinite)
    assert all(e[3]<infinite or e[0] in cut for x in cut for e in net.adj[x])
    assert value==sum(e[3] for x in cut for e in net.adj[x] if e[0] not in cut)
    def sent(e):
        return e[3]-e[2]
    by_price={y:sent(e) for y,e in store.items()}
    first={c:sum(sent(v[c]) for v in left.values() if c in v) for c in cells}
    second={c:sum(sent(v[c]) for v in right.values() if c in v) for c in cells}
    for y,m in zip(order,demand):
        z=by_price[y]
        assert 0<=z<=m and z==sum(map(sent,left[y].values()))==sum(map(sent,right[y].values()))
        # If z>0, the product of these two conditional location measures,
        # multiplied by z, implements this distribution on actual cell pairs.
        if z:
            assert sum(sent(l)*sent(r)/z for l in left[y].values() for r in right[y].values())==z
    for c in cells:
        assert first[c]==sent(one[c]) and second[c]==sent(two[c])
        assert 0<=max(first[c],second[c])<=tau*cells[c]
    assert value==sum(by_price.values())==sum(first.values())==sum(second.values())
    peak=tuple(max(v[c]/cells[c] for c in cells) for v in (first,second))
    return value,by_price,peak


def mark(records,src,by_price,parents):
    weighted=F(0)
    rec=[defaultdict(F),defaultdict(F)]
    for (t,l,r),w in records.items():
        fraction=sum(by_price[arm[1]]/src[arm[1]] for arm in (l,r))
        assert 0<=fraction<=1
        weighted+=w*fraction
        for j,(i,y,h) in enumerate((l,r)):
            rec[j][i,h]+=w*fraction
    assert all(sum(v.values())==weighted for v in rec)
    assert all(x<=parents[i]["owner_volume"]/2 for v in rec for (i,h),x in v.items())
    return weighted,tuple(max(2*x/parents[i]["owner_volume"] for (i,h),x in v.items()) for v in rec)


def replay(rounds):
    parents,src,records,hard,outward,cells,order,eligible=input_data(rounds)
    def fmt(x):
        return outward(x) if x else "0"
    req=tuple(src[y]/2 for y in order)
    grand=sum(req)
    mass=sum(records.values())
    tables=subset_tables(cells,req,eligible)
    crit=critical(tables)
    tau_star=max(a for a,p in crit)
    def labels(p):
        return tuple(y for j,y in enumerate(order) if p>>j&1)

    print("Python",sys.version.split()[0],"; independent exact max-flow and 3^10 Hall cuts.")
    print("Pinned split862.py",PIN_SPLIT)
    print("920/848 original records. Source demand per active price is true mu_y/2.")
    print("Eligibility: all observed middles with every old box excluded; all observed olds with every middle excluded.")
    print("Total real output demand",grand,"; 24 physical membership cells, including disjoint by-role supports.")
    for role,(tau,p),vols in zip(("middle","old"),crit,tables[1:]):
        print(" ",role,"exact critical density",tau,fmt(tau),"critical source set",labels(p),
              "; m(P)",tables[0][p],"; true target union volume",vols[p])
    print("Exact common critical capacity",tau_star,fmt(tau_star))
    # Test a single additional separated-bottleneck level: the midpoint
    # between the two single-role critical capacities, when they differ.
    small=min(x[0] for x in crit)
    extra=(small+tau_star)/2 if small<tau_star else tau_star*F(3,4)
    for key,tau in (("zero",F(0)),("quarter",tau_star/4),("half",tau_star/2),
                    ("single-role diagnostic",extra),("critical",tau_star)):
        pair,sides=deficits(tables,tau)
        Delta,P,Q=pair
        value,by_price,peak=flow(cells,order,req,eligible,tau)
        assert value+Delta==grand and P&Q==0
        all_,um=mark(records,src,by_price,parents)
        hard_,hm=mark(hard,src,by_price,parents)
        print(" ",key,"tau/tau*",fmt(tau/tau_star),"; single-role and simultaneous deficits/demand",
              *(fmt(d/grand) for d,p in sides),fmt(Delta/grand))
        print("    original demand fraction sent, original marked all/F and hard/F:",
              fmt(value/grand),fmt(all_/mass),fmt(hard_/mass))
        print("    maximizer P,Q:",labels(P),labels(Q),"; standalone maximizing sets",
              tuple(labels(p) for d,p in sides))
        print("    true target union volume T,I and observed output peaks T,I:",
              tables[1][P],tables[2][Q],tuple(fmt(x) for x in peak))
        print("    real U/W peaks using the whole/hard original record weights:",
              tuple(fmt(x) for x in um),tuple(fmt(x) for x in hm))
        if key=="critical":
            assert Delta==0 and all_==mass and hard_==sum(hard.values())
        if key=="zero":
            assert Delta==grand and all_==hard_==0
    print("The original marking weights each record by the two actual source emission fractions of this explicit pair flow.")
    print("All finite certificates verified. No claim about old contract payment or general CZ history.")


if __name__=="__main__":
    parser=ArgumentParser()
    parser.add_argument("--rounds",type=Path,required=True)
    replay(parser.parse_args().rounds)

