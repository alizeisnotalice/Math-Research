# 第646轮审计与证据边界

一般n^(1/2+o(1))一致弱型上界仍未证明。新增的是同源非负剥离、完整条件分支付款，以及实际重数的来源收费；不是整个困难族已覆盖。

REPORT.tex SHA256：9beddde36bf1ce2cc512f9f103a6b875c04bbb407fa65eada0a24221e8dc55e3。

- SOURCE_FINAL_AUDIT.md：§1–3全部行来源、密度剥离、实际α与fallback和完整条件分支；原命题先独立检查再读作者稿。
- MULTIPLICITY_FINAL_AUDIT.md：§4真实maximum-radius ownership、all-capturer收费、逐点只保一份、低增长付款及完整S不双花。
- ACTION_FINAL_AUDIT.md：§5半动作的全输入共同运输选择、half参数、交换不等式、存在/可测与未证whole-score方向。

主代理完整整合LaTeX，保留两种实际ownership不可混用、全部原标签片、actualα适应性、低/高增长端点与所有超支。
“可逆Markov”在此表示详细平衡(reversible)，不表示矩阵非奇异；可能存在Tr=0零模。

## 真实运行

repro/slack 为实际单进程SymPy/Fraction记录：21个预先限定标量点、105个fallback检查。连续域结论依据分段非负恒等式和单调性，不依赖网格外推。
repro/diagnostic 保留一次失败的有限实现诊断及其独审：ε=1500偏离大H合同，n2/N3非困难输入，且浮点KKT与cell过滤不提供严格可行性。原results.json对应sanity_original.py；sanity.py仅修复过滤并做语法检查，没有重跑。未用这组数字排除主路线，也不登记其为根阶改进。
原诊断中三个案例均未触发非零逃逸、fallback及删零；全部分支合法性来自一般证明与独审。

本轮没有新MATLAB或Arb运行，没有PDF编译，没有重复第645轮批次。两个数值任务均为短时单进程，不能称CPU持续满载。原始实际命令、版本、结果、运行范围与已知误差见各repro说明。

verify_archive.py只检查文件哈希、语法/结构、明确的符号残差及有限有理fallback恒等式，不认证几何命题或一般弱型上界。L03的证书边界与B04的极小极大资格限制均保留；没有借来源题录宣称新外部定理。

## 未付对象

对同一个动作律，仍需证明完整score E[2O+R(B−M)+]≤E_grow+(Λκ−1/2)V，或以高增长priced multiplicity与剩余S/fill建立完整正预算。交叉不eligible的anchor质量不能省掉1/λ价格，交换coercivity也不能逐pair免费求和。
密度剥离与捕获都是同一个S的下界，不能叠加双领。条件性分支、局部符号核验与有限实现诊断均不替代一般闭合。

## 归档最终补记

历史去重仅检索R632–645报告，没有发现相同密度剥离公式或低增长12倍付款；来源一次收费的原则已有R633/R641先例，本轮新内容是当前actual价格、真实重数和低增长费用的完整配对，不声称首次提出来源一次收费。
文件审计指出原诊断脚本固定写旧/tmp路径。新增repro/diagnostic/reproduce.py只在内存中改输出路径，原脚本字节和原结果不变：`python reproduce.py`可重新跑原实现，`python reproduce.py --corrected`可跑修正版，分别写reproduced_original.json/reproduced_corrected.json，均不覆盖已归档results.json。包装器只检查语法，未执行优化器。原run.log未收录，结构化结果及收据足以记录实际运行；无报告依赖其作为输入。
父代理实际运行verify_archive.py，Python3.12.14/SymPy1.14.0：8项符号残差和54组有理剥离反馈恒等式通过，原几何批次未重跑。最终文件清单以MANIFEST.json为准，FILE_AUDIT.md是新增包装器/清单之前的盘点快照。
