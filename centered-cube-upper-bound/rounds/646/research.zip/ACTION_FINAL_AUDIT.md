# R646 final action-law / whole-score transplant audit

PASS for REPORT §5 and its §6 unresolved-status statements. No mathematical correction is required in this limited scope.

Bound versions:

- REPORT.tex SHA256: `9beddde36bf1ce2cc512f9f103a6b875c04bbb407fa65eada0a24221e8dc55e3`
- /tmp/ccu_r646/action_selection.md SHA256: `6be264ee21adf8e8ec38122a7df949d658d40bcefb71d6246b6a3d02b7b52083`

The previously unavailable author draft has now been read and compared with the independent action audit. That earlier audit used the parent's initial full-move parameters. The **frozen author/report law is the half-move version** below; this final audit completes the author-comparison status and does not import the old full-piece formula. No numerical run, LP, scan, historical batch or PDF compilation was performed.

## 1. Half parameters and actual whole action: PASS

The final author uses beta=(tau-1)/2 and sigma=1+beta; the report calls the same quantity b=(t-1)/2. With z=(y-X)/(2s), the actual canonical center is c=sigma y-beta X, while the radius remains rho=tau s. Its actual scaled receiver piece is

E=c+tau(I-y)=tau I-beta(y+X).

All half factors are correct in both files. The initial full formula tau I-(tau-1)X is not used in the frozen proof. For eligible anchors, ||z||_infinity<=1/2, so the action has a fixed half-box buffer inside the canonical displacement box and satisfies the half-action capture hypothesis. All old labels, growth factors, scales and source masses remain in the one construction.

Gamma is only an allocation for choosing anchors; it is not substituted for the old mu, old incidence/Gram matrix, or the original lambda weights of the all-old source construction. No anchor draw creates extra usable copies of M.

## 2. Existence and simultaneous exchange inequality: PASS

The source allocation constraints are unchanged from the independently audited proposition. The trial lambda_j 1_(Aj)mu is feasible, its label masses sum to M, and they are strictly positive. Densities in [0,1] with fixed sum/support/mass form a weak-* compact feasible set over the fixed finite mu. The source lies in a bounded finite old-cube union, so the continuous quadratic costs are bounded there. Thus the final existence argument is valid, including open/closed cube conventions modulo AC-null faces.

A fixed optimal allocation followed by one product draw supplies a measurable joint anchor law for the fixed input. No parameterwise measurable optimizer-selection theorem, deterministic purification, source coordinate independence or per-pair optimization is asserted or needed.

For each cross-eligible pair, equal-mass submeasure exchange gives the stated cost inequality product-a.e. Fractional submeasure exchange suffices; nonatomicity is not needed for that exchange. The actual AC source removes face ambiguities. Finite pairs and the one product law make all applicable inequalities simultaneous almost surely.

With A_jk=sigma_j y_j-sigma_k y_k-(b_j-b_k)(X_j+X_k)/2 and bar b=(b_j+b_k)/2, the swap inequality gives A_jk·Delta X<=0, and c_j-c_k=A_jk-bar b Delta X. Consequently

|A_jk|^2+bar b^2|Delta X|^2<=|c_j-c_k|^2.

The sign, factor and subsequent receiver-intersection upper bound n(rho_j+rho_k)^2/a^2 are correct. The final text retains cross eligibility; it does not impose the inequality on unsupported pairs or treat it as a bound on total lost copies.

## 3. Actual ownership, measurability and finite expectations: PASS

Equal sharing of each new receiver membership cell gives an actual positive mass vector, with w_j>=|B'_j|/J_old>0. Such masses can be realized by real measurable cell pieces. The mass vector is measurable (indeed continuous under the fixed finite box translations). The actual optimizer is unique and continuous on each fixed packing-graph region; there are finitely many Borel graph regions, so Q' is measurable. This is sufficient for the fixed-input expectation and deterministic extraction; no arbitrary favorable ownership is selected outside the expectation.

Every anchor marginal is AC because gamma_j<=mu, and b_j>0. Each center is an invertible scalar affine image of its anchor. The chosen product law therefore gives jointly AC centers, so finitely many contact hyperplanes have probability zero. This supports the report's genericity statement, but is not used to ignore actual graph-dependent Q'.

O<=sum ell_j and B<=2M give the fixed finite bound

0<=K(Z)=2O+R(B-M)_+<=2sum ell_j+RM.

Likewise W and Q' are bounded for the finite input, so D is integrable. Actual original pieces may be arbitrary measurable sets; choosing Borel representatives and translating them gives measurable union/source integrals without changing volumes. No density cap is needed.

## 4. Whole-score direction and exact conditional implication: PASS

This transplant uses the already audited all-old source/actual-slack estimate in REPORT (whole), within its R>1 critical-input range. It does not reprove that estimate here. The final source is explicitly constructed over **all old rows**, which is essential for the self-density peeling step; it is not silently replaced by the earlier retained-only source variant.

Since B_*<=M and R/(R-1)>=1, the positive-part term in (whole) is at least [Lambda_kappa V-O-M-R(B-M)_+]_+. Applying [x]_+>=x and dropping only the same-action nonnegative F_fill and R(M-B)_+ gives exactly

D>=E_grow+Lambda_kappa V-M-K(Z),
K(Z)=2O(Z)+R(B(Z)-M)_+.

Thus the **unproved sufficient condition**

E K(Z)<=E_grow+(Lambda_kappa-1/2)V

would give E D>=V/2-M. Integrability and the full-measure legality/exchange event yield at least one single legal complete action and its actual new ownership/optimizer with D>=V/2-M. This is the stated paid target, and is sufficient for c=1/2,C=1 in the original form when L_n>=1. It is not an assertion that the expectation condition holds.

All quantities in this implication come from the same realized action. The whole score permits overlap and source overrun to trade inside one expectation; it does not combine two separately favorable actions, sources or ownerships. If the separate maximum-radius ownership estimate is invoked, the final report correctly requires alpha to be recomputed on that same ownership rather than adding credit from equal-share alpha.

## 5. Final author comparison and unresolved scope: PASS

The author and report both identify the two missing costs: cross-ineligible anchor probabilities retain the 1/(lambda_k m_k) normalization, and even eligible near-center constraints do not give an N-free total multiplicity bill. They do not claim gamma_k<=C lambda_k mu, factor adaptive alpha expectations, or replace actual overlap by a Gram row sum.

REPORT §5 explicitly labels its whole-score expectation bound unproved. §6 preserves the full large-overlap/large-return branch, lack of a complete uniform contraction/terminal argument, and failure of the off-contract geometric diagnostics to certify a general claim. It does not turn action existence, swap coercivity or a conditional paid estimate into the general root/polylog weak bound.

No correction is required to the bound versions in this scope. Author-proof comparison complete; bounded audit complete; stop.
