# Modified enumeration: retain every positive-width floating interval. Original run is bound to sanity_original.py; no new results have been produced.
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[k]='1'
import itertools,math,time,resource,json,sys,platform
import numpy as np,scipy,cvxpy as cp,clarabel

def cube(c,r):return ((c[0]-r,c[1]-r),(c[0]+r,c[1]+r))
def vol(b):return math.prod(max(0,y-x) for x,y in zip(*b))
def contains(b,x):return all(l<z<h for l,z,h in zip(b[0],x,b[1]))
def cells(boxes):
 e=[sorted(set(v for b in boxes for v in (b[0][k],b[1][k]))) for k in range(2)]
 for parts in itertools.product(*[list(zip(z,z[1:])) for z in e]):
  if any(y <= x for x,y in parts):continue
  x=tuple((a+b)/2 for a,b in parts);area=math.prod(b-a for a,b in parts);mask=sum(1<<j for j,b in enumerate(boxes) if all(b[0][k] <= parts[k][0] and parts[k][1] <= b[1][k] for k in range(2)))
  if mask:yield x,area,mask,((parts[0][0],parts[1][0]),(parts[0][1],parts[1][1]))
def own(boxes):
 pieces=[[] for _ in boxes];v=np.zeros(len(boxes))
 for _,area,mask,cell in cells(boxes):
  i=(mask&-mask).bit_length()-1;pieces[i].append(cell);v[i]+=area
 return pieces,v

def matrix(boxes):
 pats=sorted({mask for _,_,mask,_ in cells(boxes)}); A=np.array([[(mask>>j)&1 for j in range(len(boxes))] for mask in pats],dtype=float);return pats,A

def solve(boxes,d,v,eps):
 patterns,A=matrix(boxes);scale=float(max(d));lam=cp.Variable(len(d),pos=True);con=A@lam<=1;prob=cp.Problem(cp.Maximize((d@lam+eps*cp.sum(cp.multiply(v,cp.log(lam))))/scale),[con]);prob.solve(solver='CLARABEL',max_iter=500,tol_gap_abs=1e-10,tol_gap_rel=1e-10,tol_feas=1e-10);l=np.array(lam.value);z=scale*np.maximum(np.asarray(con.dual_value),0);m=A.T@z;station=m-d-eps*v/l
 return {'status':prob.status,'pats':patterns,'A':A,'lambda':l,'z':z,'m':m,'station_resid':max(abs(station)),'capacity_resid':max(0.,max(A@l-1)),'comp_resid':max(abs(z*(1-A@l))),'lambdaK_mass_err':float(abs(np.dot(z,A@l)-sum(z))),'objective':prob.value}

def run(label,centers,radii):
 clock=time.monotonic();cpu=time.process_time();N=len(radii);a=64.;eps=1500.;U=np.array([1/3,-1/4]);y=np.array(centers);r=np.array(radii);orig=[cube(c,a*rad) for c,rad in zip(y,r)];small=[cube(c,rad) for c,rad in zip(y,r)];oldpieces,v=own(small);d=np.array([vol(x) for x in orig]);V=float(sum(v));old=solve(orig,d,v,eps);m=old['m'];la=old['lambda'];z=old['z'];M=float(sum(z));Q=float(d@la);R=V/Q;g=m/d;t=np.sqrt(g);s=a*r;rho=s*t;delta=rho-s;c=y+delta[:,None]*U
 new=[cube(cj,rr) for cj,rr in zip(c,rho)];smallnew=[cube(cj,rr/a) for cj,rr in zip(c,rho)];_,w=own(smallnew);J=np.flatnonzero(w>1e-10);assert len(J)==N
 actual=solve(new,m,w,eps);alpha=actual['lambda'];Qp=float(m@alpha);E=[];Eowner=[]
 for j,pp in enumerate(oldpieces):
  for lo,hi in pp:
   box=(tuple(c[j]+t[j]*(np.array(lo)-y[j])),tuple(c[j]+t[j]*(np.array(hi)-y[j])));E.append(box);Eowner.append(j)
 ell=g*v;growth=float(sum(ell)-R*M);massK={mask:float(z[i]) for i,mask in enumerate(old['pats']) if z[i]>0};Cin=0.;inrow=np.zeros(N);qescape={mask:np.zeros(N) for mask in massK};UE=0.
 # All E and C faces: integrate exact per-piece float rectangle arrangement.
 for x,area,mask,_ in cells(E+new):
  ejs={Eowner[i] for i in range(len(E)) if mask>>i&1}; cjs={j for j in range(N) if mask>>(len(E)+j)&1}
  if not ejs:continue
  UE+=area;D=np.zeros(N)
  for K,zk in massK.items():
   dens=zk*sum(la[j]/ell[j] for j in ejs if K>>j&1)
   for k in range(N):
    if K>>k&1:
     D[k]+=dens
     if k not in cjs:qescape[K][k]+=area*dens
  if cjs:
   density=max(D[k] for k in cjs);Cin+=area*density
   for k in cjs:inrow[k]+=area*density
 # For each old membership K and each retained k in K, r_K is max integrated escape.
 rk={K:max((vec[k] for k in range(N) if K>>k&1),default=0.) for K,vec in qescape.items()};esc=sum(rk.values());B=Cin+esc;Bstar=min(B,M)
 rows=inrow+np.array([sum(zr for K,zr in rk.items() if K>>k&1) for k in range(N)])
 selected=rows if B<=M else m
 Dint=old['A'].T@(z*(old['A']@la))
 W=float(sum(w));overlap=float(sum(ell)-UE);fill=W-UE;T=M-Bstar;slack=Bstar-Qp;D=W-R*Qp;rhs=growth-overlap+fill+R*T+R*slack
 return {'label':label,'n':2,'a':a,'epsilon':eps,'U':U.tolist(),'centers':y.tolist(),'radii':r.tolist(),'old_v':v.tolist(),'new_w':w.tolist(),'old_lambda':la.tolist(),'old_m':m.tolist(),'old_source_z':[[int(K),zk] for K,zk in massK.items()],'old_Q':Q,'old_M':M,'R':R,'g':g.tolist(),'delta':delta.tolist(),'ell':ell.tolist(),'actual_alpha':alpha.tolist(),'actual_Qprime':Qp,'W':W,'UE':UE,'O_raw':overlap,'F_fill':fill,'E_grow':growth,'C_in':Cin,'R_escape':esc,'B':B,'Bstar':Bstar,'transport_credit':T,'actual_slack':slack,'overlap_minus_fill':overlap-fill,'transported_demand_integral':Dint.tolist(),'demand_integral_residual':(Dint-m).tolist(),'transport_row_supply':rows.tolist(),'selected_row_supply':selected.tolist(),'row_margins':(selected-m).tolist(),'Qprime_le_Bstar_residual':max(0.,Qp-Bstar),'ledger_residual':D-rhs,'qK_mass_residual':old['lambdaK_mass_err'],'old_status':old['status'],'old_station_abs':old['station_resid'],'old_cap_violation':old['capacity_resid'],'old_complementarity':old['comp_resid'],'new_status':actual['status'],'new_station_abs':actual['station_resid'],'new_cap_violation':actual['capacity_resid'],'new_complementarity':actual['comp_resid'],'old_patterns':len(old['pats']),'new_patterns':len(actual['pats']),'elapsed_seconds':time.monotonic()-clock,'cpu_seconds':time.process_time()-cpu,'rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
if __name__=='__main__':
 cases=[('overlap',[[-1,0],[0,0],[1,0]],[1,1,1]),('scale_separation',[[0,0],[2.1,0],[3.2,0]],[1,.5,.25]),('equal_delta_platform',[[0,0],[3,0],[6,0]],[1,1,1])];out=[run(*case) for case in cases];doc={'python':sys.version,'platform':platform.platform(),'numpy':np.__version__,'scipy':scipy.__version__,'cvxpy':cp.__version__,'clarabel':clarabel.__version__,'cases':out};open('/tmp/ccu_r646/numeric_design/results.json','w').write(json.dumps(doc,indent=2));print(json.dumps(out,indent=2))
