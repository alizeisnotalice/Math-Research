"""Optional diagnostic rerun; only redirects the historical output path.

The archived results belong to sanity_original.py, not to this wrapper or
the corrected script. Neither variant is a hard-contract input certificate.
Usage: python reproduce.py [--corrected]
"""
from pathlib import Path
import argparse

parser = argparse.ArgumentParser()
parser.add_argument('--corrected', action='store_true')
args = parser.parse_args()
root = Path(__file__).resolve().parent
name = 'sanity.py' if args.corrected else 'sanity_original.py'
output = root / ('reproduced_corrected.json' if args.corrected
                 else 'reproduced_original.json')
script = root / name
text = script.read_text()
old = repr('/tmp/ccu_r646/numeric_design/results.json')
assert text.count(old) == 1
text = text.replace(old, repr(str(output)))
exec(compile(text, str(script), 'exec'),
     {'__name__': '__main__', '__file__': str(script)})
