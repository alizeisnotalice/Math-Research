#!/usr/bin/env python3
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import json,sys,time,resource
import sympy as S
start=time.perf_counter();cpu=time.process_time();u,k=S.symbols('u k',positive=True)
base=k-(k-1)**2/(4*u)
r1=S.factor(1+u-base);r2=S.factor(k*(1+u)/u-base)
assert S.simplify(r1-(2*u-(k-1))**2/(4*u))==0
assert S.simplify(r2-(k+1)**2/(4*u))==0
endpoint=F(7,2)-(F(7,2)-1)**2/(4*F(7,2));assert endpoint-F(3)==F(3,56)
derivative=S.factor(S.diff(k-(k-1)**2/(4*k),k));assert S.simplify(derivative-(S.Rational(3,4)+1/(4*k*k)))==0
phases=[('initial',[(k0,u0) for k0 in (F(7,2),F(4)) for u0 in (k0/2,k0,2*k0)]),('boundary',[(k0,u0) for k0 in (F(7,2),F(4)) for u0 in (k0-F(1,100),k0,k0+F(1,100))]),('wide',[(k0,u0) for k0 in (F(7,2),F(15,4),F(4)) for u0 in (F(1,10**6),F(1),F(10**6))])]
out=[]
for name,pts in phases:
 rows=[]
 for kk,uu in pts:
  omega=min(F(1),kk/uu);lhs=omega*(1+uu);rhs=kk-(kk-1)**2/(4*uu);res=lhs-rhs;assert res>=0
  secondary=kk-(kk-1)**2/(4*kk)-3;assert secondary>=F(3,56)
  falls=[]
  for B in (F(0),F(1,2),F(1),F(3,2),F(2)):
   M=F(1);Q=min(B,M)/2;R=F(3,2);W=F(2);Bstar=min(B,M);pos=lambda x:max(x,F(0));T=M-Bstar;A=Bstar-Q
   assert Bstar==M-pos(M-B)==B-pos(B-M) and T==pos(M-B) and T>=0 and A>=0
   assert W-R*Bstar==max(W-R*B,W-R*M)==W-R*M+R*pos(M-B)
   assert W-R*Q==(W-R*Bstar)+R*A
   falls.append({'B':str(B),'M':str(M),'Q':str(Q),'Bstar':str(Bstar),'T':str(T),'A':str(A),'guarantee':str(W-R*Bstar),'actual':str(W-R*Q)})
  rows.append({'kappa':str(kk),'u':str(uu),'omega':str(omega),'residual':str(res),'secondary_minus_3':str(secondary),'fallback':falls})
 out.append({'stage':name,'cases':len(rows),'fallback_checks':len(rows)*5,'rows':rows})
print(json.dumps({'symbolic':{'u_le_kappa_residual':str(r1),'u_ge_kappa_residual':str(r2),'secondary_derivative':str(derivative),'secondary_endpoint_minus_3':str(endpoint-3)},'stages':out,'run':{'python':sys.version,'sympy':S.__version__,'cpu_s':time.process_time()-cpu,'wall_s':time.perf_counter()-start,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest()}},indent=2))
