# 实际 slack 的标量证书

对任意 u>0、κ∈[7/2,4]，令 ω=min(1,κ/u)。分段的精确残差是

- 0<u≤κ：ω(1+u)−κ+(κ−1)²/(4u)=[2u−(κ−1)]²/(4u)≥0；
- u≥κ：同一残差=(κ+1)²/(4u)>0。

因此整个连续域满足 ω(1+u)≥κ−(κ−1)²/(4u)。另一项不是只由网格判断：

f(κ)=κ−(κ−1)²/(4κ)，　f'(κ)=(3κ²+1)/(4κ²)>0，
f(κ)≥f(7/2)=171/56=3+3/56>3。

这比所需下界3略强。两个分段残差和导数由 SymPy 精确化简；上述符号论证给所有实数参数，不依赖计算样本。

## Fallback 与正部

对于 B,M≥0、R≥0，B*=min(B,M) 精确等于

B*=M−(M−B)_+=B−(B−M)_+，　M−B*=(M−B)_+≥0。

故

W−RB*=max(W−RB,W−RM)=W−RM+R(M−B)_+。

若另外已知实际 Q′≤B*，记 A=B*−Q′≥0，则实际目标的准确分解为

W−RQ′=(W−RB*)+RA。

这里 A 保留 actual α 的真实 slack；不能因该特定 fallback 的保证较弱就删除 RA，也不能用代数恒等式声称空间覆盖或根阶付款。

## 实际运行与范围

预注册于 PLAN.md：端点初步6个 (κ,u)、u=κ 附近边界6个、宽范围9个；每点对 B/M=0,1/2,1,3/2,2 核 fallback 和 positive-part，共21个标量点、105个 fallback 检查，全部 Fraction 精确通过。完整输入、残差和各 fallback 结果保存在 results.json；样本仅验证代码，连续域结论来自上述恒等式与单调性。

命令：`OPENBLAS_NUM_THREADS=1 /Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r646/slack_numeric/check.py > /tmp/ccu_r646/slack_numeric/results.json`。实际 Python 3.12.14、SymPy 1.14.0，单进程 CPU 0.0478 s、wall 0.0536 s、峰 RSS 72,515,584 bytes。源码和输出 SHA256 见 SHA256SUMS。没有调用 Arb、重跑历史批次或声称数值证明空间积分/一般 F。
