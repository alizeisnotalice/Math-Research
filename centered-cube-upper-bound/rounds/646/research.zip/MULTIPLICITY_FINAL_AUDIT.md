# R646 final multiplicity transplant audit

**Verdict: PASS for the finalized author increment, formal REPORT §4, and the stated non-double-spending constraints. The high-growth residual and the general complete target remain unproved.**

Report: `/tmp/ccu_r646_final/REPORT.tex`

Verified SHA-256: `9beddde36bf1ce2cc512f9f103a6b875c04bbb407fa65eada0a24221e8dc55e3`

Compared the now-completed `/tmp/ccu_r646/multiplicity_bridge.md` with the independent `/tmp/ccu_r646/MULTIPLICITY_AUDIT.md`, then read formal §4, its required symbol definitions, and the final cross-mechanism constraints. This is an incremental proof check, not a repeated computation or review of unrelated sections. No author/report file was changed.

## 1. Full capturer increment is valid

The author's final `J_k={j∈J:A_k⊂C_j}` enlarges the earlier pointwise eligible-parent collection. Every member contains the same positive-volume old cube A_k, so this is an actual new clique. Thus

`0≤A_k*=Σ_{j∈J_k}α_j(1−P_kj)≤Σ_{j∈J_k}α_j≤1`.

The P normalization is exactly the required row-k normalization, `P_kj=μ(A_k∩A_j)/m_k`. The half-jitter geometry and actual largest-radius new owner ensure a retained capturer for almost every active high-growth copy. No uniform positive α or Gram complement is inferred. The proof continues to include every old child k, even when its actual new owner was deleted.

The formal report's containment estimate, strict constant, retained-label rule, row normalization and use of the actual newly recomputed α agree with the audited definitions. The full original new union is covered a.e. by the retained owner pieces.

## 2. The q-maximum keeper is legal and noncircular

Define β_k=κA_k*/u_k for high labels and β_k=0 for low labels, then q_k=1−β_k. These coefficients are fixed after the same new geometry, largest-radius true ownership, and actual α have been chosen. Only the decomposition of E-copy multiplicity is subsequently optimized.

Choosing one maximum-q copy at each point gives exactly m_E−1 lost copies and

`Σ_k∫_{L_k}q_k=∫_{U_E}[Σ_{k:x∈E_k}q_k−max_{k:x∈E_k}q_k]dx`.

This choice does not need to be the largest-radius E copy: geometric capture comes from the already fixed largest-radius **full-receiver owner**, independently of the bookkeeping keeper. Hence no ownership/α circularity is introduced. Negative q contributions remain favorable terms and are not clipped or absolutized.

## 3. Full source price and explicit residual

With h_k=|L_k|/ell_k, the completed proof defines

`H_j=Σ_{high k:j∈J_k}λ_kh_k 1_{A_k\A_j}`.

The same old packing and the actual containments imply `0≤H_j≤1_{C_j\A_j}` μ-a.e. The identity `λ_km_k/ell_k=ε/u_k` gives exactly

`C_cap=Σ_jα_j∫H_jdμ=Σ_high k(ε/u_k)A_k*|L_k|≤S`.

This remains a same-source, all-row calculation without an N factor. The report preserves the stronger equality

`S=C_cap+S_rem`,

where `S_rem=∫(1−L_α^C)dμ+Σ_jα_j∫(1_{C_j\A_j}−H_j)dμ≥0`.

The displayed parent sums may use all original labels because α is extended by zero. Child sums continue to use all old labels. S_rem is actual remaining credit, not a separately feasible source covering all row demands.

## 4. Low payment and final complete inequality

The low/high partition uses low g<3/2 and high g≥3/2, with no endpoint duplication. The exact harmonic identity is `Σv/u=V/κ`, and the raw variance is `E_grow=Σv(u−κ)²/u`. The polynomial certificate at u≤1/2, κ≥7/2 is correct and pays `O_low≤E_grow/12`.

Consequently the formal inequality

`D≥11E_grow/12+F_fill−Σ_high k∫_{L_k}[1−κA_k*/u_k]dx+R S_rem`

matches the finalized author equation (15). It retains negative high brackets, all actual slack, true fill and the remaining raw energy. It does not reuse the paid twelfth of the growth energy. The report explicitly leaves the high-growth priced multiplicity unpaid.

## 5. Source-slack combination and scope

The source peeling bound and this capture certificate concern the same actual S. The report correctly forbids adding them as independent credits. If a same-action, same-input peeling argument gives S≥S_peel, the only additional residual lower bound used is

`S_rem≥[S_peel−C_cap]_+`.

The final paragraph also correctly forbids importing an α computed under an equal-share new ownership into this largest-radius ownership calculation. If the mechanisms are combined, actual α and all dependent quantities must be recomputed on the one common new partition.

The final author discussion correctly retains the raw-flat platform: there β_k=A_k*≤1, so capture alone cannot create an extra positive baseline; fill and actual S_rem are still possible and not discarded. Neither that branch nor all high residuals are declared solved. No strict good-action or general F_own conclusion is asserted from the bookkeeping identity alone.

The finalized author increment is therefore audited, rather than left at the earlier pending state. No substantive correction was required. No numerical/historical batch was rerun, and no Git operation or other-file edit was performed. Audit complete; stop.
