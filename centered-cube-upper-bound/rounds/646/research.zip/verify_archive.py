from pathlib import Path
from fractions import Fraction as F
import ast, hashlib, json, re, sys
import sympy as s

root = Path(__file__).resolve().parent
manifest = json.loads((root / 'MANIFEST.json').read_text())
for name, digest in manifest['sha256'].items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == digest, name
for path in root.rglob('*.py'):
    ast.parse(path.read_text())
tex = (root / 'REPORT.tex').read_text()
assert not any(ord(c) < 32 and c not in '\n\t' for c in tex)
stack = []
for sign, env in re.findall(r'\\(begin|end)\{([^}]+)\}', tex):
    if sign == 'begin':
        stack.append(env)
    else:
        assert stack.pop() == env
assert not stack

u, k, V = s.symbols('u k V', positive=True)
identities = [
    1 + u - k + (k - 1)**2 / (4*u) - (2*u-k+1)**2/(4*u),
    k*(1+u)/u-k+(k-1)**2/(4*u)-(k+1)**2/(4*u),
    (k-u)**2-12*u*(1+u)
    -(k-s.Rational(7,2))*(k+s.Rational(7,2)-2*u)
    -(s.Rational(1,2)-u)*(11*u+s.Rational(49,2)),
    k*k*(V/k)-k*V,
]
bj, bk, yj, yk, x, y = s.symbols('bj bk yj yk x y')
fj = lambda z: bj*z*z/2-(1+bj)*yj*z
fk = lambda z: bk*z*z/2-(1+bk)*yk*z
A = (1+bj)*yj-(1+bk)*yk-(bj-bk)*(x+y)/2
dx = x-y
c = (1+bj)*yj-bj*x-((1+bk)*yk-bk*y)
identities.extend([fj(x)+fk(y)-fj(y)-fk(x)+A*dx,
                   c-(A-(bj+bk)*dx/2)])
for expr in identities:
    assert s.simplify(expr) == 0
lam = k-(k-1)**2/(4*k)
assert lam.subs(k, s.Rational(7,2)) == s.Rational(171,56)
assert s.simplify(s.diff(lam,k)-(3*k*k+1)/(4*k*k)) == 0

# Only scalar piecewise identity checks; these tuples are not geometric families.
count = 0
for R in map(F, [2,10,100]):
    for M in map(F, [1,3]):
        for ratio in [F(1,2),F(1),F(3,2)]:
            B = M*ratio
            for H in [F(0), R*B/2, R*B]:
                star = min(B,M)
                hat = (R*B-H)/(R-1)
                dagger = min(B,M,hat)
                expected = max(H-star-R*max(B-M,0),0)/(R-1)
                assert star-dagger == expected
                count += 1
print(json.dumps({'status':'PASS', 'manifest_files':len(manifest['sha256']),
                  'symbolic_residuals':len(identities)+2,
                  'rational_peeling_identities':count,
                  'python':sys.version.split()[0], 'sympy':s.__version__,
                  'geometry_batches_rerun':False, 'pdf_compiled':False}))
