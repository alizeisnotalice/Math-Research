# R646 文件归档审查

范围：仅盘点 `REPORT.tex`、三份 `*_FINAL_AUDIT.md`、`AUDIT.md`、`verify_archive.py` 与 `repro/`。未运行优化器、批次或归档验证脚本；未认证数学结论。父任务后续添加的 `MANIFEST.json` 等文件不在本次清单范围内，本文件也不计入自身清单。

## 核心状态

- 当前清点文件：**16**，合计 **104,888 bytes**。
- `REPORT.tex` SHA-256：`9beddde36bf1ce2cc512f9f103a6b875c04bbb407fa65eada0a24221e8dc55e3`。`ACTION_FINAL_AUDIT.md`、`MULTIPLICITY_FINAL_AUDIT.md`、`SOURCE_FINAL_AUDIT.md` 均绑定此 SHA。
- `verify_archive.py` 会读取本目录的 `MANIFEST.json`。盘点时该文件尚不存在，故验证器目前不能直接运行；按任务约定由父任务随后添加，不计为本次归档缺项。
- 没有 PDF、cache、临时文件或 `.log` 文件。`repro/diagnostic/RESULT.md` 提及原运行的 `run.log`，但它未随包收录；其保存结果在 `results.json`。如要求保留原控制台日志，则目前缺失；就已列出的结构化数值结果而言，未发现重复的大型日志或数据文件。

## 诊断结果和修正版范围

`repro/diagnostic/results.json` SHA-256 为 `7f053a03bb900bfe5ff452bed882c38f042eedd8c547a32fed976b7c72d22f31`；它对应原运行脚本 `sanity_original.py`，SHA-256 为 `c5474fc2768bd7f006165f8c5f2e95aa908413aabebb199dbe3efe82a845b913`。`RESULT.md` 和 `AUDIT.md` 明确说明本次数值是 ε=1500 的改变参数诊断，非冻结合同实例；它不是精确源证书。

修正版 `sanity.py` SHA-256 为 `fb5c82f64bd1ebc39f3e132ef53b749f880419c2447af41c8d503e3db215c29c`。归档说明它只修复正宽度 cell 过滤并做语法检查，**没有重跑**；因此现存 `results.json` 仍应归于 `sanity_original.py`，不能写成修正版的运行输出。

两版诊断脚本都将运行结果硬编码写到 `/tmp/ccu_r646/numeric_design/results.json`。输入几何参数直接写在脚本中，没有外部输入文件依赖；但若从归档目录执行，结果不会写在包内，且目标路径不存在时可能失败，因而输出位置不是可移植的相对路径。诊断说明的“原命令输出 run.log”也指向历史执行记录，当前包没有该日志。

## 精确标量包与其他路径

`repro/slack/SHA256SUMS` 的四个条目（`PLAN.md`、`check.py`、`results.json`、`REPORT.md`）均通过静态摘要核对。`results.json` 内所记 `script_sha256` 与当前 `check.py` 摘要一致；这是精确标量检查包，不是几何优化批次。`check.py` 无外部数据输入，输出 JSON 到 stdout；报告中引用旧工作目录的命令是运行记录，不是脚本输入依赖。

`verify_archive.py` 的逐文件读取均基于其所在目录的 `root / name`，语法检查遍历包内 Python 文件，TeX 检查读取本地 `REPORT.tex`；唯一外部前置文件是待父任务创建的 `MANIFEST.json`。此审查未执行该脚本。

## 最小必要文件白名单

保留 `REPORT.tex`、三份 final audit、`AUDIT.md`、`verify_archive.py` 及 `repro/` 中所有当前文件。诊断包中的原脚本、修正版、旧结果和范围说明不能互相替代；标量包中的脚本、结果、校验摘要与运行说明共同对应其已完成检查。无需增加重复的大型输出；若需完整控制台日志，则另行补充 `run.log` 或删除对此文件已随包保留的依赖性表述。

## 独立 SHA-256 清单

路径相对于 `/tmp/ccu_r646_final`；大小为精确字节数。

| 文件 | 字节 | SHA-256 |
|---|---:|---|
| `ACTION_FINAL_AUDIT.md` | 7,235 | `f1636c4488c34ab718bcb33c07692ee02a4ee22fecc00b5c092975fdf3a6af23` |
| `AUDIT.md` | 2,632 | `d926ea6e924075cbd9d52632a31b4ab3068b4b994d2f0ee9d660b7bc1dc16c43` |
| `MULTIPLICITY_FINAL_AUDIT.md` | 5,164 | `07f505b48fc95c7e7eb3daebd649ff694e3812c3da8f25235b46535c1de1cd98` |
| `REPORT.tex` | 14,237 | `9beddde36bf1ce2cc512f9f103a6b875c04bbb407fa65eada0a24221e8dc55e3` |
| `SOURCE_FINAL_AUDIT.md` | 4,017 | `7e25fb4778ceaf24602f66c4a1dfde83598f7a8af042d85760d9d744f00a2543` |
| `verify_archive.py` | 2,330 | `ff1e03a5c1200f0576e8976a6f4776067947c85105652150dd501615b0949a18` |
| `repro/diagnostic/INDEPENDENT_CHECK.md` | 6,050 | `3727a2113f4d5f5b65c4e69200737c5873882abbdb400c0f32040a23cfa34da3` |
| `repro/diagnostic/RESULT.md` | 5,071 | `3799788f311e3e7e4145194a7564e62c6f89f65ba1821cfe904d1a717be37e7e` |
| `repro/diagnostic/results.json` | 10,392 | `7f053a03bb900bfe5ff452bed882c38f042eedd8c547a32fed976b7c72d22f31` |
| `repro/diagnostic/sanity.py` | 6,088 | `fb5c82f64bd1ebc39f3e132ef53b749f880419c2447af41c8d503e3db215c29c` |
| `repro/diagnostic/sanity_original.py` | 5,881 | `c5474fc2768bd7f006165f8c5f2e95aa908413aabebb199dbe3efe82a845b913` |
| `repro/slack/PLAN.md` | 561 | `eae87d4d4d26e6d3a3f32698be2f2faaaa7286d1843100688cdd88cfb9026973` |
| `repro/slack/REPORT.md` | 1,856 | `e63aa705f85f359f4656e4c031b3ab4b1ca346fc79df7f7b7f9f75f7611242eb` |
| `repro/slack/SHA256SUMS` | 304 | `61de1d424fef8dcaea292e304d8e764c165b013038f2cba505d577bb0baef134` |
| `repro/slack/check.py` | 2,176 | `9af5900d179ba45788ad83b8acaf789e4da4e72de985165ffe3d99511f88fe2b` |
| `repro/slack/results.json` | 30,894 | `e905748f50d089a25794ce1a3e1f8a19f79b118682113b30a8ba3cbf330ed7fd` |
