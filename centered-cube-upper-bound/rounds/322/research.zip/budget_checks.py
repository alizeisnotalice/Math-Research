#!/usr/bin/env python3
"""R322 exact old-layer and source-root budgets on positive-volume boxes."""
from fractions import Fraction as F
from math import isqrt
from collections import Counter
from pathlib import Path
import json
counts=Counter();diag=Counter()
def ck(key,b):
 counts[key]+=1
 assert b,key

def old_tail(n,R,kappa,b=F(2)):
 q=kappa*R
 return q**(-n) if q<=b else F(0)
def run(n,kind):
 k=isqrt(n);eps=F(1,100*n);volume=eps**n
 centers=[F(-3,10),F(3,10),F(-1,10),F(1,10)];R=[F(1),F(1),F(3,2),F(2)]
 src=[F(-3,5),F(3,5)];m=[F(1,k),F(1,k)]
 if kind=='half_gate':m=[x/2 for x in m]
 if kind=='zero_source':m=[F(0),F(0)]
 # beta is uniform unit mass on an auxiliary positive-volume box;
 # Actual s=0,L=2,q=lambda1 kernel is 2^-n on all beta/receiver products.
 U=F(1,2**n)
 ck('actual_soft_hard_endpoint_kernel',max(abs(x) for x in centers)+eps<1)
 ck('FIRST_exact',U<=1)
 capture=[]
 for i,x in enumerate(centers):
  row=[]
  for z in src:
   maxdist=abs(x-z)+eps # source and receiver have sideeps
   mindist=max(F(0),abs(x-z)-eps)
   if maxdist<R[i]/2:row.append(1)
   elif mindist>R[i]/2:row.append(0)
   else:raise AssertionError('partial receiver/source incidence')
   ck('transverse_complete_or_firstaxis_outside',row[-1]==0 or eps<R[i]/2)
  capture.append(row)
  ck('same_radius_cap_all_receiver_points',sum(m[z]*row[z] for z in range(2))<=4*R[i]**n)
 ck('receiver_boxes_disjoint',all(abs(centers[i]-centers[j])>eps for i in range(4) for j in range(i)))
 rootboxes=[]
 for z in src:
  index=(z+F(1,2*n))*n//1;lo=-F(1,2*n)+F(index,n);hi=lo+F(1,n)
  ck('source_boxes_inside_roots',lo<z-eps/2 and z+eps/2<hi)
  rootboxes.append((lo,hi))
 ck('transverse_source_inside_root',eps<F(1,n))
 hs=[volume*U]*4;totalE=4*volume;W=sum(m)
 def prefix(r):return [i for i in range(4) if R[i]<=r]
 results=[]
 for H in [volume*U,2*volume*U,4*volume*U,5*volume*U]:
  for kappa in [F(1),F(4,3),F(2),F(3)]:
   levels=sorted({F(1),F(3,2),F(2)}|{kappa*r for r in R if 1<=kappa*r<=2})
   old=F(0);rootbase=F(0)
   for j,r in enumerate(levels):
    ell=r**(-n)-(levels[j+1]**(-n) if j+1<len(levels) else 0);ids=prefix(r);J=sum(hs[i] for i in ids)
    if J<H:continue
    for i in ids:
     for w in ids:
      mismatch=sum(m[z]*capture[i][z]*(1-capture[w][z]) for z in range(2))
      if r>=kappa*R[i]:old+=ell*hs[i]*hs[w]*mismatch/J
    # Root positive baseline with unchanged second endpoint summing to J.
    rootbase+=ell*sum((hs[i]*m[z]*capture[i][z] for i in ids for z in range(2) if k*m[z]>=R[i]**n),F(0))
   ck('old_layer_budget',old<=4*kappa**(-n)*totalE)
   ck('root_baseline_budget',rootbase<=4*k*(1+F(1,n))**n*W)
   ck('root_baseline_positive',rootbase>=0)
   results.append(dict(H=H,kappa=kappa,old_layer=old,old_upper=4*kappa**(-n)*totalE,rootbaseline=rootbase,root_upper=4*k*(1+F(1,n))**n*W))
 # Exact layer tail checks include the terminal atom at equality.
 for radius in sorted(set(R)):
  for kap in [F(1),F(4,3),F(2),F(3)]:
   start=kap*radius;points=sorted({F(1),F(3,2),F(2)}|({start} if 1<=start<=2 else set()))
   direct=sum((r**(-n)-(points[j+1]**(-n) if j+1<len(points) else 0) for j,r in enumerate(points) if r>=start),F(0))
   ck('old_interval_tail_with_terminal_atom',direct==old_tail(n,radius,kap))
   if start==2:ck('old_at_b_includes_atom',direct==F(2)**(-n));diag['old_gate_at_b']+=1
   if start>2:ck('old_after_b_zero',direct==0);diag['old_gate_after_b']+=1
 # Capturing endpoint matters: a larger miss radius does not imply its old gate.
 ck('reverse_scale_not_old',capture[2][0]==1 and capture[1][0]==0 and R[2]>=F(4,3)*R[1] and not (R[2]>=F(4,3)*R[2]))
 gate=[]
 for z,i in [(0,0),(1,1)]:
  accepted=k*m[z]>=R[i]**n
  ck('root_gate_equality_guard',accepted==(kind=='equality'))
  gate.append(dict(root_mass=m[z],capturing_R=R[i],active=accepted))
 return dict(n=n,kind=kind,actual_U=U,beta_mass=F(1),beta_box_center=F(0),beta_box_side=eps,L=F(2),softness=F(0),q=F(1),receiver_side=eps,receiver_volume_each=volume,receiver_centers_firstaxis=centers,receiver_radii=R,source_root_firstaxis_intervals=rootboxes,source_centers_firstaxis=src,source_side=eps,source_masses=m,capture=capture,root_side=F(1,n),root_gates=gate,budgets=results)
def anisotropic(n):
 k=isqrt(n);eps=F(1,100*n);mass=F(1,k);widths=[F(1,4)]+[F(1,n*n)]*(n-1)
 source_center=F(3,5);source_interval=(source_center-widths[0]/2,source_center+widths[0]/2)
 U=F(1,2**n);h=eps**n*U;J=2*h;H=J/2
 ck('strip_beta_receiver_actual_kernel',F(3,10)+eps<1 and U<=1)
 ck('strip_all_u_capture',F(3,10)+eps/2-source_interval[0]<F(1,2) and source_interval[1]-(F(3,10)-eps/2)<F(1,2))
 ck('strip_all_w_miss',source_interval[0]-(-F(3,10)+eps/2)>F(1,2))
 ck('strip_transverse_capture',F(1,n*n)/2+eps/2<F(1,2))
 ck('strip_same_radius_cap',mass<=4)
 old_mass_upper=mass*F(4,n)
 ck('strip_all_isotropic_cells_fail',old_mass_upper<F(1,k))
 ck('strip_rectangular_gate_equality',k*mass==1)
 gamma=F(1)
 for width in widths:gamma*=1+width
 ck('strip_rectangular_inflation',gamma<=2)
 ck('strip_middle_distance_lower',F(3,5)-eps>F(1,2))
 ck('strip_middle_distance_upper',F(3,5)+eps<2)
 # Direct full-prefix integral: one captured receiver and one missing receiver.
 direct=(h*h/J)*mass
 potential=mass*(h-h*h/J)
 ell=(F(1)-F(2)**(-n))+F(2)**(-n)
 ck('strip_positive_true_BH',direct*ell==potential==J*mass/4>0)
 ck('strip_H_actual',H==h and J>=H)
 ck('strip_root_baseline_budget',h*mass<=4*k*gamma*mass)
 return dict(n=n,k=k,source_firstaxis_interval=source_interval,source_other_width=F(1,n*n),source_mass=mass,receiver_side=eps,actual_U=U,J=J,H=H,BH=potential,isotropic_root_mass_upper=old_mass_upper,rectangle_gate=True,rectangle_Gamma=gamma,rectangle_price=4*k*gamma*mass,scope='Actual endpoint kernel and positive-volume strip/receiver boxes; new rectangular success while every isotropic1/n cell fails. Original lowpe/full-history and full-f/q selector eligibility are not certified.')
def serial(x):
 if isinstance(x,F):return str(x)
 if isinstance(x,dict):return {k:serial(v) for k,v in x.items()}
 if isinstance(x,(list,tuple)):return [serial(v) for v in x]
 return x

def main():
 reports=[];stages=[]
 for stage,ns in [('initial',[1,4]),('boundary',[16]),('expanded',[64])]:
  before=sum(counts.values())
  for n in ns:
   for kind in ['equality','half_gate','zero_source']:reports.append(run(n,kind))
  stages.append(dict(stage=stage,n=ns,models=3*len(ns),checks=sum(counts.values())-before))
 before=sum(counts.values());strips=[anisotropic(n) for n in [16,36,64]]
 stages.append(dict(stage='anisotropic_addition',n=[16,36,64],models=3,checks=sum(counts.values())-before))
 result=dict(anisotropic=strips,status='PASS',arithmetic='Fraction',check_counts=dict(counts),total_checks=sum(counts.values()),diagnostics=dict(diag),stages=stages,scope='Actual endpoint soft kernel s0,L2,q1 on positive-volume beta/receiver/source boxes. FIRST and same-radius caps hold on whole boxes. No full lowpe/history or natural root-H realization/closure is claimed.',models=reports)
 print(json.dumps(serial(result),sort_keys=True))
if __name__=='__main__':main()
