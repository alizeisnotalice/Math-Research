# R322 — recomposable original ledger around the R302/R320 boundary fee

**Decision:** the R302 entrance and R320 distance decomposition give a precise auxiliary middle fee, with its ENTIRE capture square retained. They do not replace the complete old ledger. In particular wide-source low-pe/extreme-aspect traffic, initial atoms, real deletion jumps, future-deleted continuous traffic and the terminal-surviving suffix remain separate. The old coupled low-pe source can be matched explicitly to `nu<=beta^c<=f`; the R279 gate `ns<=D` has a different, near high-continuous lineage and is not automatically a qualification of that raw low-pe target or its B_H.

Only this file was written. No Git operations or changes to other files. This is a decision ledger with exact certified and conditional interfaces, not a claim of global closure or a complete audit of all historical coefficient bounds.

Archive notation `302::r302_geometry.md:20–56` means member/lines inside `/Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/302/research.zip`. The same convention is used for other round numbers.

## 1. The original entrances are distinct

**H — historical matched history route.** Its old finite retained receiver measure is `X_old=lambda|E_0|`. The inspected authentic assembled inequality is for R_out, not for X_old itself:

`R_out <= A_pre+E_pre X_old+Lambda T_small`, `Lambda=128/119`. (H1)

Exact sources: `112::proof.md:819–839`, coupled replacement `113::proof.md:350–360`, root consolidation `114::proof.md:307–340`, and parent deletion `115::proof.md:174–185`. With the original parameter choices already made in R112,

`E_pre=19/768+Lambda(epsilon_tree+delta_tail+k0 kappa_n+epsilon_LP)`,

`A_pre=P104+B105 W_mu+(16/3)A_far W_hi`

` +Lambda{A_tree W_stop+K_(eta*,r)W_eta*+A_tail(delta_tail)W_light`

` +(C_mix K_s sqrt(n)+C_GP+n^(-1)+C_n ell_b+Kcal_alpha)W_hi}`. (H2)

Here `ell_b=1+log n`, `kappa_n=e^2 exp(-sqrt(n))/sqrt(n)`, `B105=2+3sqrt(n)+log(16/beta104^2)`, `beta104=1/6144`. The hard source partition is `W_stop+W_eta*+W_top+W_light+W_heavy=W_tree<=W_mu`; soft extraction uses a DIFFERENT complementary source identity and cannot be put into that hard partition (`237::source_ledger.md:101–121`). Kcal_alpha has its stated root/log-cubed order at `113::proof.md:306–315`; this bounded ledger preserves the other named coefficients rather than inventing their order.

For clarity the complete uniform R104 source price, on its own actual cap/residual source split, is

`P104=768 C2^2 sqrt(n)W_cap`

` +{2sqrt(n)[1+log(24576sqrt(n))]+1+log(150994944)+sqrt(n)}W_res`.

It is `104::proof.md:833–840`; the source split here belongs to that earlier input, not automatically the later beta or nu.

**Missing H-entry:** a verified complete original-band-to-AUTHENTIC-HISTORY inequality with its exact coefficient has not been established in the inspected chain. Its required form is

`X_band <= A_ent W+alpha_ent X_band+C_ent R_out^*+R_ent^+`, (H0?)

where R_out^* must actually be generated from that complete input, retained event, joint source kernel and histories, and every positive eligibility complement R_ent^+ must be priced. This displayed interface is a MISSING mathematical statement, not an asserted bound. Neither R_out=X_band nor C_ent=1 follows from(H1). A newly chosen initial hard maximizer is permitted by the uniform R104 input, but it does not generate old FULL/history eligibility for free.

**N — complete native hard-band entrance.** There is a separate certified route using the complete original hard maximizer from the outset. R321's final archived `combined.md:13–19` records

`X_band <=(768/761){P104+S318+8C2^2 sqrt(n)W_lo+G_root+H_rootleft}`. (N)

It has raw loss7/768; G_root replaces G320. H_rootleft is its actual unpriced remainder. This is not B_H, R_out or the old history traffic. No inspected map permits inserting old low-pe/I/J/D/suffix receipts into(N), or inserting the new hard-band source fees into(H1). Conversely one must not append old I/J/D to the native route without an identity creating them. R321 explicitly preserves both entrances separately.

**Native R312 alternative.** `312::native_entry.md:136–154` has `X_band<=A_paid+(64/63)R_HP` and its separate degree-tail absorption (at m=7, coefficient2/63). R_HP/R_corr is a one-receiver high-potential/corridor object; no identity with B_H or R_out is certified. This is another alternative entrance, not a source fee to add to(N)/(H1).

## 2. Exact common measure and matched source contract

For the old route, the original finite truncation I has

`dT_I=1_I1_{j(x)=j} q(x)^(-1)p_y(x)h_(R(x))(x-z)`

`                         a_omega(x,y,z)dx beta_V(dy)nu_V(dz)`,

`p_y=P_(s(x),L(x))(x-y)`. (M1)

The outer measure is the original probability expectation and sum over terminal leaves V and the UNIQUE actual band j(x). There is no independent free j copy. This is `128::proof.md:604–611`. Original continuous high terms additionally integrate dt/t and full posterior pairs; raw low-pe does not.

The coupled source order is genuinely proved, not just a total-mass comparison:

`nu_V<=zeta_sigma*<=beta_V^c=alpha_V-eta_alpha^c<=alpha_V=mu_hi|V<=f dz`. (M2)

Sources: `237::source_ledger.md:23–33` (especially25 and28–33); `114::proof.md:335–340` retains the same nu<=beta; and MOST DIRECTLY the actual old low traffic at `117::proof.md:264–276` states dT with these beta_V,nu_V and at272 explicitly `nu<=beta<=f`. Lines294–305 give its actual FIRST/cap. R299's target at `299::r299_geometry.md:5–10` is precisely the same-form complete low-pe,m>M dT with every original mask, e_g and unique band retained.

Thus one may EXPLICITLY instantiate the universal R302 theorem on that actual slot by setting its beta=beta_V^c and nu=nu_V, with the same raw target and admissible row mask. This constructs a matched B_H. It does not identify an arbitrarily selected beta in another abstract instance with beta^c merely by notation. In particular the moving suffix source rho=beta-sigma_infty is not automatically a hard-source dominator: nu<=beta does not imply nu<=rho.

For each full seed, terminal V are disjoint. The source and receiver budgets are

`W_nu=E sum_V||nu_V||<=W_beta=E sum_V||beta_V^c||<=W_hi<=W`,

`E sum_V integral_(E_(omega,V))rho_(omega,V)(x)dx<=|E_0|`,

`rho(x)=integral alpha(x,y)p_y(x)beta_V^c(dy)/q(x)<=1_E(x)`. (M3)

The leaf recovery Lambda=128/119 is paid ONCE (`237::source_ledger.md:81–99`). Its leaf-total restrictions are `m_V<=beta_V(V)<=M_V<sqrt(n)m_V`, with low mean belonging to stopping measure sigma, not beta (`237::source_ledger.md:39–61`). There is no pointwise beta density cap, and no `beta+nu<=f` assertion. A fixed hard rank restriction for nu remains available at `237::source_ledger.md:127–135`; soft beta is not granted that rank. These are old n>=512 source/history qualifications; small dimensions require their actual separate fallback if this old route is used.

## 3. Fully specified low-pe decomposition before B_H

Let `A_hi={p_y e_g>=2Kq}` with the ORIGINAL weighted nu mass e_g on original Z_g. The complete raw low slot is

`T_low=E sum_(V,j)integral 1_(A_hi^c)dT`.

The old support only implies `|y-z|_1<=17na` from `|x-y|_1<=16na` and hard capture (`115::proof.md:126`). Define `r0=a/(16sqrt(n))` and fixed M>=1. A genuine disjoint split is

`T_low=T_near+T_wide,m<=M+T_extreme+T_*`, (L1)

where T_near has `|y-z|_1<=r0`; the next term has `|y-z|_1>r0,m<=M`; and the remaining two have `|y-z|_1>r0,m>M`, partitioned by

`v=min(1,(L/R)^(n/2))<v0` (T_extreme) or `v>=v0` (T_*).

Here `m=e_g/[ell_b q c_j^(-n/2)g^n]`, g=sqrt(LR), and all original masks remain. For a common fixed M,v0,K these same parameters can be used in all leaves. The actual paid source bounds are

`S_near=2kappa_near[(16/3)W_beta+(1+log B_n)W_nu]`,

`kappa_near=2+sqrt(n)/8`, `S_near<=64sqrt(n)log(n+2)(W_beta+W_nu)`,

`S_mod=M C_n ell_b S_n W_beta`, `C_n=4+pi sqrt(n)`, `S_n<4`. (L2)

Exact receipts/constants: `289::low_pe.md:43–74,98–110`; m and the old root estimate are also `117::proof.md:314–325`. B_n is the explicit menu polynomial at `289::low_pe.md:49–66`, not the boundary fee B_H. Both are SOURCE prices. They carry Lambda once in the old ledger, no high factor2 and no dt/t.

T_extreme is still unpaid. Although L/R is in[1/2,2], v can be as small as2^(-n/2); choosing v0 that small in a root-price formula can introduce an exponential inverse-aspect cost. Treating both orientations does not delete this complement.

## 4. R302 fixed-instance entrance with every coefficient

At one matched leaf/seed (or a genuinely authenticated general outer instance), choose a z-INDEPENDENT original row mask alpha(x,y) in[0,1] dominating its T_* mask. Pair/source-dependent restrictions stay in the original target; alpha=1 is always a legal positive enlargement. Define

`U_y(x)=1_E(x)alpha(x,y)p_y(x)/q(x)`,

`J_y(r)=integral_(R(x)<=r)U_y(x)dx`,

`A_yz(r)=integral_(R(x)<=r)U_y(x)1_{z in Q_R(x)}dx`,

`mathscr L_n(dr)=b^(-n)delta_b+n r^(-n-1)1_(a,b)dr`,

`A_n=1+nlog(b/a)`, `q_-=3lambda/4`,

`kappa0=2K/(ell_b M)`, `psi_inf=3-2/(3gamma^n)`, `gamma=1+1/n`,

`d=kappa0 psi_inf/(q_-v0)`.

Then

`T_*<=2 O_d`, `O_d=integral beta nu mathscr L_n min(d,A_yz(r))`,

`O_d<=4lambda H W_beta+(d/H)A_n W_nu+B_H`,

`Q_y(r)=J_y(r)M_y(r)-integral A_yz(r)^2nu(dz)`,

`M_y(r)=integral A_yz(r)nu(dz)`,

`B_H=integral beta(dy)mathscr L_n(dr)1_{J_y(r)>=H}Q_y(r)/J_y(r)`. (B1)

No division on zero rows. At `H=sqrt(d A_n/(4lambda))`,

`T_*<=4sqrt(lambda d A_n)(W_beta+W_nu)+2B_H`. (B2)

This is `302::r302_geometry.md:5–56,73–88`. Its exact dependence is

`lambda d=(4/3)kappa0 psi_inf/v0`, `q_-H=(3/8)sqrt(lambda d A_n)`.

The source term is root order for controlled kappa0,v0; it is not uniform as v0 tends to0. The source-balanced alternative H* at302:58–67 is legitimate only with its retained B_(H*); it cannot be optimized while leaving another H's boundary fee.

B_H is an AUXILIARY upper-bound fee, not a literal remaining raw positive traffic allocation. Positive enlargement may include source pairs already paid in(L2); this is legal for the upper bound, but it is not an exact original residual partition. Original raw source-wide and auxiliary receiver-distance-long are different events.

## 5. R320 distance split, keeping the ENTIRE capture square

Use endpoint-independent weight v_pair=1 for the physical B_H. More general frozen v_pair(y,z,r) is permitted by the theorem, but it cannot hide an endpoint-dependent mask. Put

`F1=integral beta nu mathscr L_n A_yz(r)<=A_n W_nu`.

For a symmetric receiver-pair region D define N_D by the actual U_y(u)U_y(w)c_u(z)/J baseline, E_D by replacing c_u with c_uc_w, and L_D=N_D-E_D>=0, all with beta,nu,layer,J>=H and any v_pair retained. The WHOLE square is

`E_full=integral beta nu mathscr L_n1_{J>=H}A_yz(r)^2/J_y(r)`.

Choose source-price parameters e_beta,e_nu>0 and define

`Csoft_n=sum_k max_s binom(n,k)s^k(1-s)^(n-k)<=1+(pi/2)sqrt(n)`,

`M_n=A_n n Csoft_n/2`,

`h=(a/2)min{1,[e_nu q_-H/(2A_n)]^(1/n)}`,

`T0=min{e_beta q_-/(4lambda),e_nu q_-H/(2A_n)}`,

`t=b[1/2+log_+(M_n/T0)]`.

Let D_near={|u-w|_infinity<=h}, D_mid={h<|u-w|_infinity<=2t}, D_long={|u-w|_infinity>2t}. R320 proves

`N_near+N_long<=e_beta W_beta+e_nu W_nu`,

`B_H=N_near+N_long+Pi_mid`,

`Pi_mid=N_mid-E_full`. (B3)

References: `320::pair_geometry.md:15–40,44–69,107–132`. Both N_mid and E_full are finite, at most F1. Thus the signed subtraction is legitimate. It keeps ALL selected radius ratios and the full original prefix J. It is not `L_mid` and not `N_mid-E_mid`: in fact `Pi_mid=L_mid-E_near-E_long`.

The alternative positive interface is `B_H<=e_beta W_beta+e_nu W_nu+L_mid`. Use one interface consistently. An oriented history/collar mask is not automatically symmetric, and cannot acquire an isolated whole-square subtraction. R303's different receiver-near domain likewise needs its actual restricted overlap; one cannot assert its numerator is the unrestricted A^2 just because its denominator is full J.

The exact target insertion from(B2),(B3) is

`T_* <=[4sqrt(lambda d A_n)+2e_beta]W_beta`

`       +[4sqrt(lambda d A_n)+2e_nu]W_nu+2Pi_mid`. (B4)

After old outer recovery this becomes Lambda times BOTH source prices and `2Lambda Pi_mid`. e_beta,e_nu are SOURCE coefficients, not X losses. t need not be O(log n) if q_-H is extremely small; its displayed dependence must stay fixed when forming the annulus.

## 6. What the recent high-soft receipt really removes

`321::highsoft.md:5–26` pays the actual CAPTURING-u baseline on `s(u)>=s_*=1-1/(2sqrt(n))` by

`N_(mid,+)<=(4lambda/q_-)Z_n W_beta`, `Z_n<13sqrt(n)`.

Put `C_+= (4lambda/q_-)Z_n <(208/3)sqrt(n)`. Split N_mid exactly by that original capturing-endpoint softness. Then the square-preserving refinement of(B4) is

`Pi_mid<=C_+ W_beta+Phi_mid,-`,

`Phi_mid,-=N_mid,- - E_full`. (B5)

It retains the ENTIRE E_full. Alternatively the positive physical loss can be split into its oriented capturing-u high/low pieces and only the high piece paid by its baseline; that leaves positive L_mid,-. Do not identify an oriented piece with a symmetric-difference formula without proving its symmetry.

This receipt costs source, so adds zero X loss. At the old outer coefficient its high-soft source cost is at most `(53248/357)sqrt(n)W_beta`. It only restricts the capturing endpoint u in N_mid,-; the other endpoint w and the whole square still use the full U,J. One cannot silently make BOTH endpoints low-soft from this allocation.

On an ALREADY MATCHED R279/R281 near-moving remainder, this high-soft region is absent asymptotically or already paid by R288 (section9 below). Therefore (B5) is not claimed as new paid mass on that special lineage. On the explicitly constructed old raw low-pe B_H its applicability is analytic, but no constant coverage or general middle payment is asserted.

## 7. Recomputable old remainder ledger with the new auxiliary fee

The latest inspected COMPLETE old-slot assembly is `123::proof.md:1098–1109`:

`Lambda T_small <=E5 X_old+C_G sqrt(n)W_beta+Lambda T_low`

` +2Lambda(I_rem+J_rem+D_rem+P_suffix-N_Zc-N_del)`,

`E5=epsilon_near+epsilon_FA+epsilon_IJ+epsilon_D+epsilon_G`. (G)

C_G already includes its stated high/recovery factors (`123::proof.md:1093`); do not multiply it by2Lambda again. The epsilon_G receipt REPLACES the alternative older capture/source receipts, rather than adding all historical variants.

For a concrete conservative choice, adopt only(L2) and the R302/R320 low-pe insertion, and leave the FULL original current suffix in(G) unpriced. Let L_out[F]=E_omega sum_V F with each leaf's original low target/selector (its unique j remains inside U/target). If d,H,e_beta,e_nu are common, the recomposable inequality is

`R_out <=A_pre+C_G sqrt(n)W_beta+Lambda(S_near+S_mod)`

` +E_original X_old+Lambda T_extreme`

` +Lambda L_out{[4sqrt(lambda d A_n)+2e_beta]||beta_V||`

`             +[4sqrt(lambda d A_n)+2e_nu]||nu_V||+2Pi_mid,V}`

` +2Lambda(I_rem+J_rem+D_rem+P_suffix-N_Zc-N_del)`, (G302320)

where

`E_original=19/768+Lambda(epsilon_tree+delta_tail+k0 kappa_n+epsilon_LP)`

`             +epsilon_near+epsilon_FA+epsilon_IJ+epsilon_D+epsilon_G`. (E)

To adopt(B5), add `2Lambda L_out(C_+||beta_V||)` and REPLACE Pi_mid by Phi_mid,-; do not add both remainders. For common coefficients (M3) pays the source norms once, with `W_nu<=W_beta<=W`; positive source coefficients add, not a complementary-source maximum. If parameters vary with authentic outer data, retain their exact weighted source sums.

A more general outer clock/xi instance has its original positive weight c(xi): every line of(B4)/(B5), including all source prices, H and the remaining square, is multiplied by that c(xi) inside its existing outer integral. A fixed-instance theorem supplies no free integrated W bridge. Original raw low-pe has no new dt/t or independent j sum. Its coefficient is Lambda; the factor2 in front of B_H is from T_target<=2O_d, not from the old high branch.

This base ledger does not charge optional R126–R301 alternative positive allocations. If later suffix receipts are adopted instead, their ACTUAL positive responsibility weights must be deleted from P_suffix and their precise source/error prices inserted. An unspecified 'all later receipts paid' or an unspecified E_post cannot certify absorption or coverage. R288's local receipt does not alone provide that adoption map.

## 8. The remaining original integral slots and their measures

All following terms retain the original outer expectation/leaf/unique-band sum and dT of(M1). Put terminal bad `B=D_g`, terminal good `G=Z_g\\D_g`, future-deleted `E_t=Z_t\\Z_g`, and

`delta_t(c,b)=[k_t(c)-k_t(b)]_+`, `ell_t(c)=Q_x^*(c)/(p_y w_t(c))`.

- **Wide low-pe/extreme aspect:** T_extreme in(L1), raw dx traffic with `|y-z|_1>r0,m>M,v<v0`; coefficient Lambda. The auxiliary B_H middle is the other aspect-qualified low-pe fee, not this complement.
- **Initial low test:** `I_rem=E sum integral1_(A_hi)dT e_tau^(-1) integral_B1_{ell_tau<B_IJ theta0}w_tau dnu`, `theta0=e_g/e_tau`.
- **Genuine deletion jumps:** `J_rem=E sum integral1_(A_hi)dT sum_(tau<u<=g,true jumps)[Pi_u(B)/e_(u-)] integral_(Z_(u-)\\Z_u)1_{ell_u<B_IJ theta_u}w_u dnu`, `theta_u=Pi_u(B)e_g/e_(u-)`. These are TIME ATOMS, not score dt/t; auxiliary deleted points do not inherit the original hard z capture. Exact definitions `121::proof.md:1516–1532`.
- **Future-deleted CONTINUOUS positive term:** `D_rem=E sum integral1_(A_hi)dT1_{Diss>d_D} integral_(J_far)dt/t integral_(b in B,c in E_t)1_{ell_t(c)<B_FA delta_t(c,b)}delta_t(c,b)dPi_t(c)dPi_t(b)`. Diss is `e_g^(-1)integral_(Z_tau\\Z_g)[w_tau-w_h]dnu`; source domain E_t is not terminal good. `120::proof.md:436–459,621–638`. Its moderate-Diss part already funded its own epsilon_D slot.
- **Terminal-surviving continuous suffix:** `P_suffix=E sum integral1_(A_hi)dT integral_(J_far)dt/t integral_(c in G,b in B)Psi chi_FA rho_rem delta_t(c,b)dPi_t(c)dPi_t(b)`. Keep its ACTUAL rho_rem in[0,1], not just its support. This includes its wide-source portion `r0<|y-z|_1<=17na` and every near portion not certified under a selected later receipt. `128::proof.md:604–650`, `223::negative_contract.md:18–58`.
- **Unused negatives once:** N_Zc uses the same G×B suffix-complement domain Psi and reverse score `[k_t(b)-k_t(c)]_+`, WITHOUT positive FA/rho gates. N_del uses E_t×B and the full reverse score, WITHOUT added Psi/terminal-good/FA/large-Diss gates. The surviving old signed slot is exactly `2Lambda(P_suffix-N_Zc-N_del)`. N_Z on the already-deleted good suffix is consumed and cannot reappear. `223::negative_contract.md:60–75`.

I,J,D each carry2Lambda, as does the suffix signed slot. There is no demonstrated whole later price for these independent prefix slots. A terminal-good moving theorem does not pay future-deleted c or true jump atoms. The intrinsic auxiliary `-E_full` in(B3) is not an additional use of these posterior negative credits. All old signed manipulations use common finite truncations before limits; the finite B_H square identity is a different legitimate subtraction.

## 9. Which extra restrictions are legitimate for the low-soft middle?

| Restriction or information | Legal scope and minimum evidence |
|---|---|
| `nu<=beta^c<=f` | YES for the explicit matched low-pe instantiation(M2), including positive hard-source restrictions. Direct `117::proof.md:264–276`, `237::source_ledger.md:25,28–33`. Not a property of every abstract R302 source choice or moving rho slot. |
| SAME-E all-radius hard cap | YES for matched nu,beta restrictions from f on original E: `244::receiver_ledger.md:9–29`, also checked at `321::source_contract.md:17–19`. It gives upper source masses at actual receiver centers, not a density cap or a lower intersection mass. |
| Both witness endpoints in original leaf/support | YES if U is formed on the original eligible E_(omega,V); unique-leaf cube containment is `237::source_ledger.md:19`, original `107::proof.md:998–1016`. Receiver/source extension beyond E loses this cap/eligibility. |
| Original low-pe, m>M, aspect and broad `|x-y|_1<=16na` | May be retained in z-independent alpha if they actually dominate the same raw target and use ORIGINAL e_g,m. Then BOTH U endpoints have these retained row gates, and capturing u implies broad `|y-z|_1<=17na`. `299::r299_geometry.md:5–13,48–62`; `301::r301_geometry.md:5–13,108–116`. Source-wide and forbidden z-dependent gates cannot be moved into alpha. |
| Original kernel heights | On the actual low/m row gates, `p_y<=kappa0(LR)^(-n/2)` and `p_y<=kappa0 gamma^(n/2)L^(-n/4)R^(-3n/4)` (`299::r299_geometry.md:48–62`). These are kernel bounds, not a soft-source density or a normalized posterior capacity. |
| Capturing endpoint low-soft `s(u)<1-1/(2sqrt(n))` | YES after paying the actual high-soft baseline as in(B5); full J and square remain. The other endpoint w is not thereby low-soft. |
| `ns<=D` from R279 | NOT automatic for raw old low-pe/B_H. It is proved only for the qualified near moving high-continuous lineage after its paid certification tails; see below. |
| Hard maximizer identity | NOT certified for the frozen historical selector. Full-source initial R* is lawful in a fresh construction, but its old history/source eligibility must be built. All-radius upper cap does not give a winner identity. |
| Pointwise beta/nu density, beta+nu<=f, small source-near r0 for all pairs | NOT supplied by the inspected contracts. Coupled measure order and original broad near support do not imply them. |

The exact R279 gate is

`ns+R2(y,v)<D`,

`D=1+36exp(4c)/c^2+(2/c)log_+[(64Lambda/3)e^(5/2)sqrt(K)n^3(n+1)/epsilon]`,

`c=(25/2^68)/432`.

Primary references are `279::proof.tex.txt:17–26,195–204`, its proof audit `279::final_audit.md:31–33`, and the actual inherited remainder `281::integration.md:3,21–23`. It controls the original near good moving slot, not bad auxiliary u, arbitrary source pairs or all original low-pe. It is O(log(n+2)) only for controlled K and fixed epsilon/outer constants. `288::linear_gap.md:173–205` pays that precise current moving near route, including its physical exceptions. `288::README.md:29–32` explicitly leaves its upstream ancestor-domination/global-entry bridge open.

**Constructive lawful use:** if a SPECIFIC raw target is already proved supported on `ns(x)<=D`, choose its original row mask alpha to include that restriction BEFORE forming U,J,A. The universal R301/R302 proof can then be instantiated with those actual rows; both witness endpoints inherit the row gate. Merely editing an existing B_H after its J has been frozen is not this construction. For an unmatched raw low-pe target one may split it exactly into `T_{ns<=D}+T_{ns>D}`, apply the restricted construction only to the first and keep the second as a new positive unpaid complement. No inspected theorem pays that complement on raw low-pe solely by invoking R279.

Thus there are two different low-soft decisions: a matched near-moving suffix can legitimately have ns<=D, but still needs its exact entry into any B_H estimate; the matched old raw low-pe source can legitimately have nu<=beta^c, but does not thereby have ns<=D. Their shared notation is not a map between their measures.

## 10. Actual absorption accounting, scale limits and next decision

The verified assembled old receiver losses are exactly(E). R302(B2), R320's e_beta/e_nu fees, and R321's high-soft fee are SOURCE prices and add ZERO X coefficient. R300's proposed4C/N receiver term is conditional on an unproved cost bound; it is not an adopted small error. R319/native's1/128 belongs to the separate native(N), not to(E).

If one additionally adopts the historical R314 contact interface, its OLD-slot charge is `2Lambda epsilon X_old+2Lambda D_eff,total`, with a separate source top fee. At epsilon=119/32768 the receiver charge is X_old/128, but the old winner defect remains unpriced and can only be bounded coarsely by a nonabsorbable `(1024/119)X_old`. This contact option is not used in(G302320). Even a valid old small loss must be multiplied by the UNKNOWN original-entry coefficient C_ent when an authentic(H0) is supplied. No complete numeric alpha<1 for the general weak event has been certified.

At every general outer instance, weighted source prices, q_-H, K,M,v0 and geometry cutoffs stay inside their original positive outer integration until a uniform bound/source bridge is proved. Do not assume per-clock copies sum once because leaf masses do. R320's distance partition retains every selected scale ratio in[a,b]; it does not pay the raw extreme-aspect complement of(L1).

The all-physical-scales step is conditional on an estimate for EVERY complete nonnegative L1 input and the WHOLE octave weak event. `289::scale_bridge.md:17–37,49–62` gives, from an octave weak coefficient A_oct, the bound `C_NT[5+alpha_n max(1,ceil(log_2 n))A_oct]`, `alpha_n=1+log(log5)/(1+log n)`. It does not localize the unbounded-tail soft family directly and is not a free infinite octave sum. Whole-threshold-band bookkeeping, small-dimensional treatment for the old n>=512 route, and common finite-truncation limits remain part of any final general conclusion.

**Next decision:** attack the exact low-soft middle fee Phi_mid,- (or its explicitly chosen positive counterpart) on a declared matched source/row contract, retaining its full square. At the same time choose which COMPLETE entrance is being pursued. A root price for that fee alone still leaves T_extreme, I/J/D, wide/otherwise-unmatched suffix and the authentic old entry bridge; a native(N) proof must instead price its own H_rootleft. No list here is advertised as a closed proof.

Local Python/Fraction execution checked Lambda=128/119, 2Lambda=256/119, 4Lambda=512/119, the fixed old loss19/768, the contact calibration1/128, high-soft outer coefficient53248/357, q_-H prefactor3/8, and native raw7/768/entrance768/761. These computations verify arithmetic only; the source and measure matches above are established by the cited original clauses.

## 11. R322 direct insertion: delayed layers and source rectangles, with the whole square

This appendix updates the auxiliary fee in(G302320). It leaves the original source/history entrance, old classifications and all independent I/J/D/suffix slots unchanged. Its new receipts are proved in `/tmp/r322_joint_potential.md`, `/tmp/r322_mass_geometry.md` sections1–4, and independently checked in `/tmp/r322_audit.md` sections2–4,7–9. These files are the current R322 proof sources, not older archive claims. The two alternative old-layer budgets below are NOT charged simultaneously.

**Original low-threshold qualification.** The authentic R117 low slot inspected at `117::proof.md:272–276` uses `K_orig=1`. The direct matched reading of sections2–7 of this ledger therefore takes that original threshold and its old high/low/history fields as fixed. A generic low threshold K>=1 may positively ENLARGE this old low slot for a R302 upper bound; that is not an exact new old high/low partition. A threshold K<1 omits the old-low strip `2Kq<=p_y e_g<2q`, which must be retained and paid, or the entire high/low assembly must be rederived. No generic K in the fixed-instance theorem authorizes optimizing an unauthenticated old assembled error coefficient. The NEW delayed-layer parameter K_rad below is independent of K_orig and of the box/rank indices.

### 11.1 Exact baseline priority and unchanged overlap

Keep the full physical B_H from(B1), its same full U,J,A, layer measure, sources and square E_full. Let `kappa_rad>=1` be a frozen outer parameter and write `K_rad=n log kappa_rad`. Freeze a finite or countable COMMON hard-source decomposition

`nu=sum_iota nu_iota`, `nu_iota>=0`,

with each nu_iota supported in an axis box of widths `delta_(iota,1),...,delta_(iota,n)`. Set

`m_iota=||nu_iota||`, `r_iota^n=m_iota sqrt(n)/lambda`,

`Gamma_iota=product_i(1+delta_(iota,i)/a)`. (R1)

This source-label decomposition is frozen for the entire outer instance, common to ALL soft rows y, layer r and receivers. Its source masses sum to W_nu; boxes may overlap without duplicating the allocated measures. A y-dependent family is not licensed by the FIRST factorization. The box index iota is not the original unique ratio band j(x). Zero-mass labels carry no traffic.

Partition the ENTIRE capturing baseline N in this positive priority:

1. N_near on `|u-w|_infinity<=h`.
2. N_long on `|u-w|_infinity>2t`.
3. N_old on the remaining middle annulus and `r>=kappa_rad R(u)`.
4. N_box on the middle annulus, `r<kappa_rad R(u)`, and `R(u)<=r_iota` for its actual frozen hard-source label.
5. N_core on the middle annulus, `r<kappa_rad R(u)`, and `m_iota<lambda R(u)^n/sqrt(n)`.

These branches are disjoint and exhaustive, with equality assigned to old/covered as written. All original prefix conditions `R(u),R(w)<=r`, high-J gate and endpoint-independent original weights remain. In particular `r<kappa_rad R(u)` does not force any lower bound for the missed receiver radius R(w); the reverse large-capturing/small-missed direction remains in the core if its other gates fail.

Linearity in the allocated hard source preserves the SAME full overlap. Therefore the exact signed identity is

`B_H=N_near+N_long+N_old+N_box+Phi_core`,

`Phi_core=N_core-E_full`. (R2)

Every baseline and E_full is finite, bounded by the original F1<=A_n W_nu. Phi_core is a signed compensation for the whole fee; it is not the positive isolated core loss. The alternative positive allocation has `R_core=L_core=N_core-E_core>=0` and yields the corresponding bound with R_core, but does not retain an additional subtraction of E_full. Choose one version.

### 11.2 Sharp delayed-layer receipt and its source-only choice

Integrate the original noncapturing endpoint to the SAME J and drop only positive restrictions. For a fixed capturing u the inclusive layer tail satisfies

`integral mathscr L_n(dr)1_{r>=kappa_rad R(u)}`

` <=kappa_rad^(-n)R(u)^(-n)`.

It is exactly that value when `kappa_rad R(u)<=b`, including equality at b and its actual b atom; it is zero above b. Apply the hard-source cap only at u and its ACTUAL R(u), never at the enlarged layer. This gives the sharper fixed-instance bound

`N_old<=4lambda e^(-K_rad) integral_E rho(x)dx`

`       =4lambda e^(-K_rad) integral I_y beta(dy)`,

`I_y=integral U_y(x)dx`. (R3)

The genuine complete-soft row envelope from `302::r302_geometry.md:13` is `I_y<=A_n Csoft_n/q_-`. Hence the SOURCE receipt is

`N_old<=(16/3)e^(-K_rad)A_n Csoft_n W_beta`. (R4)

Choose `kappa_rad^n=e^(K_rad)>=A_n`, for example `K_rad=log A_n` and `kappa_rad=A_n^(1/n)`. Then

`N_old<=(16/3)Csoft_n W_beta`. (R5)

This adds ZERO X loss. At a=b, A_n=1 and kappa_rad=1: all admissible layers are old and the recent core is empty; the inclusive tail proof still applies. A convenient rational sufficient choice under b/a<=2 is `kappa_rad=(1+1/n)^k`, `k=ceil(log_2(n+1))`, since `(1+1/n)^n>=2` and thus `kappa_rad^n>=2^k>=n+1>=A_n`. Its actual recent-layer restriction, rather than another parameter's, must be retained.

The OPTIONAL receiver version instead aggregates(R3) sharply. For the authentic old low slot, M3 gives

`E sum_V integral rho_V(x)dx<=|E_0|`.

This is supported directly by original full-source FIRST and the original disjoint leaf/source/receiver convention: `117::proof.md:264–305`, `237::source_ledger.md:81–99`, and unique eligible receiver leaf `107::proof.md:1005–1016`. The common original p,q are retained. The original j is unique inside the row; it is not a separate source copy. If rows are written by j, their ORIGINAL receiver indicators must first be summed, rather than charging a whole-source envelope to every j. Consequently

`E sum_V N_old,V<=4e^(-K_rad)X_old`. (R6)

After the R302 target factor2 and old recovery Lambda its receiver charge is `8Lambda e^(-K_rad)X_old`. It may be added to E_original only when THIS receiver option is adopted; then(R5)'s old-layer source fee is omitted. An arbitrary new clock collection has no such M3 bridge until it is proved. Even this correct old X charge does not furnish the missing H0 original-band entrance or a final global absorption.

### 11.3 Source-conserving rectangular receipt

For label iota, integrate the noncapturing endpoint and inclusive layer tail exactly as above. Positive domination leaves the actual capturing mixed row

`rho(u)1_{R(u)<=r_iota}R(u)^(-n)nu_iota(Q_(R(u))(u))`.

Since rho<=1 and nu_iota<=nu, the row is at most4lambda on its actual receiver support. That support lies in the containing source box plus Q_(min(b,r_iota)). On active labels r_iota>=a, its volume is at most `r_iota^n Gamma_iota`. Thus

`N_box<=4sqrt(n)sum_{iota:r_iota>=a}Gamma_iota m_iota`. (R7)

The further middle/recent priority restrictions only reduce the actual branch; they are not removed from its definition. Receiver supports may overlap. Source-once summation uses `sum_iota m_iota=W_nu`, not a bound on the number of boxes. For example `sum_i delta_(iota,i)<=aL` implies Gamma_iota<=e^L, with that exact inflation paid. No arbitrary collection of alternative source partitions supplies a free union of their success events.

For old terminal leaves define the integrated weighted source budget

`B_rect=E sum_V sum_{iota:r_(V,iota)>=a}Gamma_(V,iota)m_(V,iota)`. (R8)

With uniformly bounded Gamma it is at most Gamma_* W_nu. If geometry/parameters vary over genuine outer fields, keep the actual weighted sum and all original outer factors. The optional dominating-source version spends its specified dominating measure's mass, not automatically W_nu or W_beta. The present principal receipt uses the actual hard nu labels.

### 11.4 Direct replacement in G302320

Adopt the SOURCE-only delayed-layer choice(R5). Combining(R2),(R5),(R7) with the already chosen R320 near/long receipt gives the fixed-instance bound

`B_H<=e_beta W_beta+e_nu W_nu+(16/3)Csoft_n W_beta`

`       +4sqrt(n)sum_{iota:r_iota>=a}Gamma_iota m_iota+Phi_core`. (R9)

In(G302320), REPLACE its entire `2Lambda L_out[Pi_mid]` by

`(32Lambda/3)Csoft_n W_beta+8Lambda sqrt(n)B_rect`

`                         +2Lambda L_out[Phi_core]`. (R10)

The other near/long source terms in(G302320) remain once. The explicit recomposed ledger is therefore

`R_out<=A_pre+C_G sqrt(n)W_beta+Lambda(S_near+S_mod)`

` +E_original X_old+Lambda T_extreme`

` +Lambda L_out{[4sqrt(lambda d A_n)+2e_beta]||beta_V||`

`             +[4sqrt(lambda d A_n)+2e_nu]||nu_V||}`

` +(32Lambda/3)Csoft_n W_beta+8Lambda sqrt(n)B_rect`

` +2Lambda L_out[Phi_core]`

` +2Lambda(I_rem+J_rem+D_rem+P_suffix-N_Zc-N_del)`. (G322)

All coefficients in(R10)/(G322) include the target2 and the old Lambda ONCE. No old Pi_mid is also retained. This source-only version adds no X coefficient: E_original stays exactly(E). If the optional receiver version(R6) is used instead, replace `(32Lambda/3)Csoft_n W_beta` by `8Lambda e^(-K_rad)X_old`; E_original then becomes `E_original+8Lambda e^(-K_rad)`. The rectangle price remains unchanged. These old-layer source and receiver bills are alternatives.

If the R321 high-soft baseline receipt(B5) has ALSO been explicitly adopted, retain its one source fee and apply the old/box priority only inside the remaining capturing-low-soft baseline. Its core is then `N_core,-−E_full`; the SAME whole square remains, and its source upper receipts are still valid by positive domination. Do not add either the old Pi_mid or Phi_mid,- again. The independent old posterior negatives N_Zc/N_del remain exactly as in(G322); the auxiliary whole square is not their reuse.

Thus the new precise middle obligation is Phi_core (signed interface) or the separately chosen positive R_core. It retains recent layer `r<kappa_rad R(u)`, actual source-capacity failure, all remaining receiver middle geometry, full source/masks and original J. No source order, small-softness condition or source-box coverage fraction has been added for free. H0, raw extreme aspect, initial/jump/future-deleted traffic, wide/unmatched suffix and all-scale passage remain separate unresolved bridges/slots.

Local Fraction arithmetic verified `2Lambda*(16/3)=32Lambda/3=4096/357`, `2Lambda*4=8Lambda=1024/119`, and that the source-only option changes E_original by exactly0. The inclusive-tail, rectangle and authentic M3 checks were independently audited in `/tmp/r322_audit.md`; the finite geometric fixture certifies the stated endpoint-kernel/FIRST/cap scope, not an unproved full historical low-pe realization.
