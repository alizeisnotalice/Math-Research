# R322 — one-sided radius-history payment; the joint potential remains unclosed

## Scope and actual result

This note uses the original R302 field and its exact Q=JM-integral A^2 nu. It preserves the actual alpha, E, q, s,L,R, source/history masks, aspect branch and full inclusive J. It does not strengthen arbitrary beta,nu to matched sources, use a source density bound, or revisit the R321 high-softness branch.

The general root bound for B_H is NOT proved. A concrete positive part can nevertheless be charged directly to an arbitrarily small receiver budget. Fix an OUTER constant K>0 and put

    kappa=exp(K/n), X=lambda |E|.

Then the entire actual capturing-u baseline restricted to r>=kappa R(u) obeys

    N_old <= 4 exp(-K) X.                               (1)

This includes any actual middle-distance restriction and either the physical v=1 or the original endpoint-independent tent weight 0<=v<=1. Thus it also pays the original oriented positive loss on this restriction. No receiver or source is charged once per scale, and the full J is never replaced by a recent-radius J.

Consequently, after the R320 original near/far receipts, one can retain only the exact middle loss with

    R(u)>exp(-K/n) r,                                   (2)

at a further cost 4exp(-K)X. In particular any pair with R(w)>=kappa R(u) is paid in its OLD-capturing-u orientation. Its reverse, where a larger-radius u captures and a smaller-radius w misses, is not paid by (1).

This is a one-sided positive allocation, not a symmetric restriction of the source symmetric difference. It is not a root source receipt for the remaining middle kernel. The parent's history check identifies (1) as a direct corollary of the R320 layer-tail method. It is recorded as reuse with an explicit epsilon ledger, not as a new root-order breakthrough.

## 1. Definitions and proof, including the radius atom

For any endpoint-independent 0<=v(y,z,r)<=1 define

    N_old = integral beta(dy)nu(dz)ell_n(dr) 1_(J_y(r)>=H) v/J_y(r)
       * integral_(R(u),R(w)<=r) U_y(u)U_y(w)c_u(z)
                                         1_(r>=kappa R(u)) du dw.

Any additional positive endpoint or actual middle-distance restriction can be inserted and only decreases this quantity. Integrating w to the SAME original full J, then dropping the original gate and v positively, gives

    N_old <= integral beta(dy) integral U_y(u)nu(Q_(R(u))(u))
                              ell_n([kappa R(u),b]) du.

If kappa R(u)>b the layer tail is zero. Otherwise its exact value is

    ell_n([kappa R(u),b])=(kappa R(u))^(-n).

At kappa R(u)=b this is the TOP ATOM b^(-n), not zero. The closed high-layer condition in (1) deliberately assigns this equality to the paid piece. Applying only the actual receiver's selected-radius cap yields

    nu(Q_(R(u))(u))ell_n([kappa R(u),b])
      <=4lambda R(u)^n (kappa R(u))^(-n)
      =4lambda exp(-K).

Finally original FIRST rho(u)=integral U_y(u)beta(dy)<=1_E(u) gives (1).

No beta/nu source comparison, nu<=f, all-radius cap, or property of the softness is used. No virtual receiver is introduced. The source cap remains at u,R(u), while the layer tail is simply the unchanged auxiliary ell_n identity. In particular (1) is valid on the genuinely low-softness portion as well.

For finite X this is a meaningful epsilon budget. For X=infinity it is only an extended-real inequality and supplies no absorption argument; no finiteness-preserving truncation or original entry is invented.

## 2. Complete allocation and external fees

Use the original R320 h,t and its disjoint near, middle and far pair regions. Let L_(mid,recent)^v be the actual oriented loss obtained by inserting

    1_(h<||u-w||_infinity<=2t) 1_(r<kappa R(u))

into the unaltered original c_u(z)(1-c_w(z)) formula. Then exactly positive splitting, followed by (1) and R320, gives

    B_H^v <= epsilon_beta W_beta+epsilon_nu W_nu
                          +4exp(-K)X+L_(mid,recent)^v.   (3)

For a preexisting residual after the high-softness branch is paid, the same statement holds after retaining its actual low-softness mask at u; its existing high-softness receipt must be carried separately. This note makes no upstream slot match from R321 and does not count that payment again.

Take K=log(4/epsilon_X) when 0<epsilon_X<4 to make the receiver term epsilon_X X. In R302's target entry T_target<=root_source+2B_H, this part instead costs 8exp(-K)X; choosing K=log(8/epsilon_X) makes its FINAL contribution epsilon_X X. Every additional original positive outer factor Lambda multiplies the source fees, this receiver fee and the retained remainder together. The original dependence through lambda d=(4/3)kappa0 psi_inf/v0 is untouched.

For any actual pair in the retained piece,

    R(w)<=r<kappa R(u),

so w cannot have radius at least kappa times the capturing endpoint's radius. It may have a much smaller radius. In particular this is not a two-sided thin-radius reduction, and replacing it by |log R(w)-log R(u)|<K/n would delete unpaid pairs.

The same positive baseline argument pays the original tent C_long restricted to r>=kappa R(u) in its actual capturing-endpoint representation. The original tent v, full A, full J, A<H and J>=2H gates remain unchanged. Thus a potential argument for C_long can also focus on its recent-capturing-endpoint component, but (1) does not itself bound that component.

## 3. Joint cumulative mass and capture square: screening, not a new theorem

The grouped-atom ANOVA and gated summation-by-parts identities already occur in R313/R317, according to the parent's lineage check. They must not be relabelled as new R322 progress. They are recorded here only to specify the exact remaining step.

Let a cumulative row have J>0, A(z), and V=M-integral A^2/J nu. Add an entire same-radius block of mass k>0 and capture B(z). With p=A/J and b=B/k,

    Delta V = integral [B-B^2/k]nu
                 +Jk/(J+k) integral (p-b)^2 nu >=0.     (4)

The first term is the block's internal capture variance. The second is disagreement between the old and new capture means. All equal-radius atoms are grouped; replacing them by independent singleton updates without the internal variance term is invalid. The J=0 initial block has precisely its own internal variance.

Formula (1) pays the old-capturing part of a cross-block baseline when the radius gap is at least K/n on the logarithmic scale. It does not pay the new-capturing part. At a new radius r, the old cap applies to nu of old cubes at their own radii, but the new capture term contains nu(Q_r(u)) with the r^n cap. Its ell tail contributes r^(-n), so those factors cancel with NO exp(-K) gain. Replacing this new-source mass by the old-source cap is the specific invalid step in a symmetric cross-block discount.

The square term in (4) has no deterministic negative sign available to repair this: on source points where p(z)=0 and b(z)>0, its integrand is b(z)^2 and represents genuinely new capture. Same-radius hard caps alone give an upper bound on the mass of each cube; they do not lower-bound old capture p on these newly captured source points. FIRST controls the beta mixture at receivers and likewise does not supply that lower bound. This observation identifies the missing inference; it is not presented as a counterexample to the full spatial theorem.

The remaining physical geometry could still force a source-linear upper bound on the aggregate of these new captures. To establish it one must use the actual shared-source kernel relation between u,w,y and the newly captured z (and, on a certified matched slot only, nu<=beta^c<=f and q=P*f). This task has not proved such an upper bound. No density or source symmetry is supplied by those inequalities alone, and alpha cannot be freely interchanged under y-z exchange.

## 4. What has and has not changed

The concrete estimate is (1), with the full decomposition (3). It removes a specified actual portion of the low-softness middle fee at arbitrarily small epsilon X cost and exposes a directed remaining history term. The retained layer horizon in (2) is a consequence of a proved positive payment, not an assumed localization.

The remaining recent-capturing middle term still has the full old prefix in J and in the w endpoint. Neither its source-root price nor the original general B_H source-root price has been proved. The grouped-atom joint potential does not close this gap by itself, and its exact identities are not counted as progress. This file therefore supplies a narrower paid portion and an explicit missing spatial estimate, not completion of R302.

Only `/tmp/r322_joint_potential.md` is authored. Other agents' files and Git are unchanged. No duplicate R313/R317 finite ANOVA tests were run; the parent has already assigned and then stopped that duplicate check after identifying the existing results.
