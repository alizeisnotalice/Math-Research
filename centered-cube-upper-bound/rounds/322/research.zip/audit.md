# R322 independent preauthor screen — two positive B_H receipts

Ownership: only /tmp/r322_audit.md; no Git or other-author file edits. This screen was written before reading any R322 author proof. Its target is an actual positive allocation of the original B_H auxiliary measure, not equality of that measure with original traffic or a completed global entry.

## 1. Frozen original contract and orientation

Keep U_y(x)=1_E(x)alpha(x,y)P_s,L(x-y)/q, original FIRST rho(x)=integral U_y(x)beta(dy)<=1, selected R in[a,b], same-actual-R nu(Q_R(x))<=4lambda R^n, original finite positive sources, and ell_n([t,b])=t^-n for legal t in[a,b] (zero tail above b). Keep the FULL original J_y(r)=integral_{R<=r}U_y. The endpoint-independent weight v(y,z,r) lies in[0,1] and contains the original high-J and any tent qualifications; zero-J rows contribute zero. Capturing u/missed w is the orientation in

 B_H^v=integral beta nu ell_n v/J integral_prefix U_y(u)U_y(w)c_u(z)(1-c_w(z))du dw.

Dropping a positive restriction or replacing the missed endpoint by its complete prefix only gives an upper bound. It does not recompute A,J,v, source masses or any original e/m/history gate. A new capturing-u/source restriction need not be symmetric; the oriented formula already has coefficient1. No extra1/2 or factor2 can be inserted from the symmetric full-loss identity once the restriction breaks that symmetry.

## 2. A: delayed layer relative to the actual capturing scale — PASS

Restrict the actual positive B_H integrand to r>=kappa R(u), kappa>1. Drop v and the missed-source factor positively, then integrate the ORIGINAL w prefix to J and cancel J. For each actual captured u the remaining inclusive layer tail is

 integral ell_n(dr)1{r>=kappa R(u)}
 <=kappa^-n R(u)^-n,

with exact equality if kappa R(u)<=b, including kappa R(u)=b; otherwise the contribution is zero. No cap at kappa R(u) is used. Apply the nu cap at the ORIGINAL u and R(u) only, then FIRST:

 B_delay <=4lambda kappa^-n integral_E du integral beta U_y(u)
          <=4kappa^-n X_E, X_E=lambda|E|.

All retained source/pair gates can remain in the actual allocation, since they were removed only in its positive majorant. The reverse event where the capturing receiver is new/large and the missed receiver old/small is not included. This is an actual positive B_H payment, not an assumed traffic identity or an estimate of all of B_H. Taking kappa=(4/epsilon)^(1/n) gives epsilon X_E, but its original entry/outer coefficients must multiply this charge before any absorption. The native X_band, historical X_old and this X_E cannot be silently identified.

If |E| is finite the displayed output budget is directly meaningful. Without finite X_E, it is formally true but may be useless; one may first restrict the capturing endpoint u to E intersect a bounded receiver box, keeping original w,J,v and sources unchanged, and then exhaust. No new FIRST on a replaced E or recomputed high-J event is needed. In a separately certified full hardband, finite X_E follows its original envelope, but it is not inferred from the abstract same-R cap alone.

## 3. B: fixed hard-source roots — PASS

Freeze a countable source grid of full cell side delta=a/n, BEFORE evaluating receivers. For D let m_D=nu(D), r_D^n=m_D sqrt(n)/lambda. Zero-mass roots have no traffic. Restrict the actual B_H positive integrand to captured z in D and R(u)<=r_D. Integrate w/J positively as in §2, then the inclusive ell tail, leaving at most the actual one-receiver mixed row

 rho(u) h_R*(nu|D)(u),

on the stated source/scale branch. Since rho<=1 and nu|D<=nu, that row is <=4lambda1_E(u). No beta/nu measure order, full f, hard winner, density cap, component FIRST or all-radius cap is required.

An active root has r_D>=a, with t_D=min(b,r_D). Captured z in D and R(u)<=t_D imply u belongs to D+Q_tD, of volume(t_D+delta)^n. Thus

 B_root,D <=4lambda(t_D+delta)^n
 <=4sqrt(n)(1+1/n)^n m_D.

Sum over the DISJOINT source roots, not over receiver sets: receiver supports may overlap and need not have bounded multiplicity. This gives

 B_root <=4sqrt(n)(1+1/n)^n W_nu <=4e sqrt(n)W_nu.

Only frozen preactive roots m_D>=lambda a^n/sqrt(n) can contribute, so their exact mass sum may be kept as a sharper budget. It is finite and source-once, with no cell-count fee. The mass is the actual hard nu mass; a full-f or soft beta mass is not silently substituted. Equality in R<=r_D is paid. Original full J and v continue to use the full original sources even after the source allocation to D. Further positive restrictions, including the complement of A, can be imposed on this paid branch without changing its upper bound.

This is a source-linear payment of concentrated hard-source B_H capture, not a universal captured fraction. The exact root-small-mass remainder is retained with all original qualifications. Its relation to previously paid native grid branches requires a true slot/measure identity; matching formula shape alone is not that identity.

## 4. Exact simultaneous use and global accounting guard

A and B can be combined through an explicit priority, for example first pay the nu-root event, then pay the delayed-layer event only on its complement; the residual is the original B_H integrand times BOTH event complements. All allocations are nonnegative and exhaust the original integrand pointwise. Alternatively a union majorant by the sum is valid but must not be described as a disjoint decomposition. No original source, prefix, posterior or high-J event is reconstructed. The root price and the epsilon X_E price both acquire every original positive entry/clock coefficient.

Neither receipt proves the remaining source geometry root bound. In particular the non-delayed retained layer r<kappa R(u) still contains missed receivers at ANY smaller legal R(w), and the hard-source root-failure event can retain all traffic for some inputs. A quantitative bound for that exact joint complement remains necessary. Complete physical-scale/time-atom/global epsilon accounting is outside these local statements.

## 5. Local mathematical tool evidence actually executed

Local Python standard-library exact Fractions:72 inclusive-layer-tail and top-atom checks;48 hard-source root-volume comparisons in square dimensions;18 prefix cancellation checks. Total138 assertions PASS. They verify bounded algebra/volume examples, not native/history realizability, universal coverage or global closure. The general receipts above are analytic proofs. No old-round test was repeated and no broad input/counterexample scan was performed.

## 6. Pending final author comparison

Both precise proposed positive receipts pass this independent screen. Await author proofs and final integration for bounded comparison and hash binding. No original B_H root closure, target identity, total output absorption or remaining-input claim is certified at this stage.

## 7. Independent stronger anisotropic-box screen — PASS

The proposed generalization is valid for a frozen COMMON source decomposition nu=sum_j nu_j into positive measures, with each nu_j supported in an axis box D_j of widths delta_(j,i) and m_j=||nu_j||. This decomposition and its mass/box fields must be common across ALL soft rows y, receivers x and layer r for the frozen outer instance. The boxes may overlap but source mass may not be duplicated: each nu_j<=nu and sum_j m_j=Wnu. A source label can equivalently be lifted by its frozen RN allocation weights. A y-dependent decomposition would obstruct the fixed-hard-source FIRST factorization and is not granted by this proof.

For the positive captured packet event m_j>=lambda R(u)^n/sqrt(n), the original same-R cap passes to nu_j; each packet's actual mixed row is <=4lambda. The receiver support is D_j+Q_min(b,rj), rj^n=m_j sqrt(n)/lambda, active rj>=a. Thus

 B_packet <=4sqrt(n)sum_j m_j product_i(1+delta_(j,i)/a).

The preactive source indices m_j>=lambda a^n/sqrt(n) may be retained. If sum_i delta_(j,i)<=aL for every charged j, the root price is <=4exp(L)sqrt(n)Wnu. No receiver overlap or source-box multiplicity fee is needed beyond the actual mass-conserving allocation and displayed inflation. Different source partitions cannot supply a free union of their success events; use one common choice, normalized probability mixture, or prove the requisite joint allocation.

The proposed long-thin prescribed-kernel fixture has full packet first width1/4 and other widths1/n² at n16/36/64, total hard mass1/sqrt(n). Its packet passes the R=1 gate at equality. Every isotropic1/n cell captures at most4/n of its mass and hence fails that threshold. This does demonstrate strict coverage of the anisotropic mass-gate family beyond the isotropic one. A source around0.6 e1 and receivers near+/-0.3 e1 can give actual positive hard capture/miss under the s=0,L=2 prescribed kernel with legal FIRST/same-R caps after normalization. Such a diagnostic does not certify original low-pe/m/history/higher-softness qualifications or novelty against every earlier paid branch; those stronger claims require their exact original contract. No new calculation was needed to repeat the already established volume algebra.

## 8. Bounded author and authentic-ledger comparisons

Read /tmp/r322_joint_potential.md and /tmp/r322_capacity_history.md. The delayed-layer proof agrees with §2, includes the top atom at equality, and correctly leaves the reverse new-capturing/old-missed direction. It is identified as a direct R320 tail-method corollary rather than a new root-order principle. Whole-batch ANOVA is explicitly reused and leaves its intrinsic/new-capture terms; no duplicate novelty or closed potential is claimed.

Read the complete /tmp/r322_mass_geometry.md. Its direct capturing baseline bound, exact positive capacity-failure loss, optional whole-overlap retained interface, zero-mass/threshold conventions, source-once coarsening and all-scope source budgets pass. Its written partition version extends to the primary proof's positive common nu_j decomposition by the same displayed argument or by a frozen source-label lift; no source mass is copied. All j fields must remain common across y, receivers and layer, as explicitly stated by the primary TeX. The optional dominating measure tau>=nu spends tau mass, not automatically beta mass; choosing tau=beta^c/f requires the actual matched source order and its source budget. No hidden enlarged cap or winner is used. Requested one wording guard: ell_n has an explicit b atom only; endpoint cases R=a,b should not be described as two ell atoms. No estimate or code change is needed.

The strict thin-strip fixture is actual positive-volume s=0,L=2 kernel geometry/FIRST/same-R-cap algebra, with positive capture/miss in the declared centre-distance annulus. It demonstrates stricter anisotropic gate coverage than ANY isotropic side1/n grid phase; it does not certify historical low-pe/m/FULL/selector eligibility or new coverage against all old paid branches. This scope is explicitly stated. The shared root statement does not depend on fixture realization of those stronger masks.

Read /tmp/r322_ledger.md and spot-checked the decisive original source/receiver clauses rather than re-auditing all history: R117 proof.md:264–305 explicitly has original nu<=beta<=f and normalized full-source FIRST; R237 source_ledger.md:81–99 has disjoint retained source masses, probability seed and Lambda paid once; R107 proof.md:1005–1016 gives unique eligible leaf at each actual x. Therefore on the authenticated raw low-pe slot, fixed full seed and common ORIGINAL p,q across leaves, sum_V beta_V^c<=mu_hi<=f implies sum_V rho_V(x)<=P_s,L*f/q<=1_E0. Original unique j has no independent source copy. This proves the sharp delayed-layer aggregate4exp(-K)lambda E sum_V integral rho_V<=4exp(-K)X_old and, after the target factor2 and old recoveryLambda,8Lambda exp(-K)X_old. It does not apply to arbitrary new clock fields or an unproved original-band entry. The history H0 connector and globalepsilon sum remain unresolved.

Notified a further old-ledger threshold guard: authentic R117 CL1 inspected here sets K=1. That is a valid direct match; a larger low threshold K>=1 can positively enlarge that original low slot, but K<1 requires pricing the omitted old-low strip or rederiving the high/low assembly. The generic fixed-instance R302 theorem is unaffected; no free optimization of an unauthenticated original high/low parameter is certified.

## 9. Source-tail option and exact whole-square interface

The sharp oldscale proof can instead use the existing genuine full-soft row envelope, without any finite-X or leaf receiver recovery assumption:

 N_old<=4lambda kappa^-n integral rho
 <=(16/3)kappa^-n An Csoft Wbeta.

Thus the primary's choice kappa^n>=An pays (16/3)Csoft Wbeta with ZERO new X loss. Exact kappa=An^(1/n) has kappa=1 when a=b; then all original layers are covered and the recent complement is empty. The positive rational alternative kappa=(1+1/n)^k, k=ceil(log2(n+1)), satisfies kappa^n>=2^k>=n+1>=An (b/a<=2), and logkappa<=k/n. These are safe sufficient choices, not a numerical maximization or a component FIRST. The omitted reverse capturing-large direction still remains in the recent core.

For the full-square version, partition the ENTIRE original capturing first moment baseline into near, long, middle-old, middle-recent-source-covered and core, in a declared positive priority. Pay each baseline once with the relevant source/output bound and THEN retain the original full E_full negative term once. The resulting Phi_core=N_core-E_full is a finite SIGNED compensation for the whole B_H. It need not equal or dominate the isolated actual positive failure loss, which instead uses its own restricted overlap. The source-tail option and receiver-budget option are alternatives; the primary source-only continuation adds no8Lambda exp(-K) output term unless explicitly adopting that separate receiver version. All entry factors still multiply the chosen source fees and the signed or positive remainder consistently.


## 10. Final author corrections and ledger appendix — PASS

The source-geometry author's endpoint wording is corrected: actual endpoint cases R=a,b are covered by the inclusive tail, while ell_n has only an explicit b atom. Final source_geometry.md agrees with /tmp/r322_mass_geometry.md, SHA256 f5ab8006e4110b4bc8406fdff2f28bb955a99976a6bf6f7e357f7ff9c99b8cfd. Its original finite-row qualification is explicitly supplied by the existing envelope, not by an invalid monotonicity claim for normalized quotients under receiver truncation. No proof/test changes require a rerun.

Read the final complete ledger §11 (SHA2565afd04957c06ab4c2c08fc920cc4d503ffb488e5f585ebd6b282fe4fe1e4a2d5). The original K_orig=1 qualification and the distinct K_rad are explicit. The exact baseline priority is exhaustive; all original J/source/pair fields stay. Whole E_full is retained only once in the signed Phi_core; its positive-loss counterpart uses E_core instead. G322 legitimately REPLACES the old Pi_mid slot, does not add it again, and leaves the independent posterior negatives unchanged. Target factor2 and recoveryLambda appear once, giving (32Lambda/3)Csoft Wbeta and8Lambda sqrt(n)B_rect in the SOURCE version. Its E_original stays unchanged. The optional receiver version instead spends8Lambda exp(-K_rad)X_old and omits the old-layer source fee. Correct original M3 applies to the authenticated raw slot and original probability/leaf/unique-j structure, not arbitrary new outer clock fields. Optional high-soft baseline adoption likewise retains its single fee and full square, without adding old remainders again.

This ledger is a recomposable, precisely sourced conditional interface. This review independently checked the decisive source match, original common FIRST/disjoint-leaf recovery and the new appendix arithmetic/allocations. It does NOT certify a fresh full re-audit of every named historical coefficient or a missing original-band-to-authentic-history construction. Ledger H0 remains a missing mathematical interface; the native route is a distinct alternative. Initial/time-jump/future-deleted/suffix/wide/extreme-aspect and all-scale obligations remain explicit.

## 11. Final primary integration and actual evidence

Read final combined.md and research.tex, including explicit0<=alpha<=1 with z-independence, M_y(r)=integral A_yz nu, the source-only/rational-kappa alternatives, matched dominating tau version and the analytic strip inflation bound. The common positive source-component theorem is valid by its direct proof / frozen source-label lift; a y-dependent source family is explicitly excluded. The tau variant spends its own source mass and updates both success/failure gates. A per-leaf global f bill is not granted for free; matched tau=beta_V^c retains its own original source-once budget. The full-square Phi_core is correctly called a signed certificate, not actual positive residual flow.

The main default source-tail version adds zero new X error. The optional receiver charge is displayed as an alternative with exact outer factors, not a second fee. a=b and exact kappa=1 are handled; rational kappa retains its own recent-layer condition. Gamma<2 for the strip is analytically bounded by exp(1/4+(n-1)/n²)<=exp(1/2)<2, independent of floating evidence. No asserted coverage fraction, unproved original low-pe/full-history fixture, global absorption or root residual estimate is introduced.

Read primary fresh evidence/logs: budget_checks.py1119 exact Fraction assertions, stages540/270/270 plus39 anisotropic additions; source_tail_checks.py32 exact scalar assertions. Primary total1151, all exact arithmetic, not distinct original inputs. The kernel fixtures use actual s=0,L=2,q1 and positive-volume beta/receiver/hard-source boxes, with full product capture/miss and same-R cap/FIRST checks. Their H values are prescribed diagnostics, not claimed natural root H or full-f/q/history realizations. The strict strip addition is physical B_H (not an actual active-low-A tent fixture). No finite sample proves the uniform theorem. This reviewer's own138 exact checks in §5 are separate and are NOT added to primary1151. Duplicate old ANOVA/author reruns are not added either.

Verified checkpoint copies of all final current proof/history/ledger files, numeric script and scope note byte-identical to their /tmp sources. The stored raw numeric stdout JSON SHA agrees with the announced75e7258154f637b78772bb18f6311cc10c71b849472bb4615ff43a46b9bf97e6; logs carry the actual execution counts. The references manifest locates frozen bytes without asserting every historical theorem was reread. No new test rerun, PDF compilation, Git/repository mutation or broad search was performed.

## 12. Frozen bounded verdict and exact remaining gap

PASS for the direct original B_H positive source-shape payment, its whole-overlap signed alternative, one-sided delayed-layer/source-tail corollary, final static integration and bounded conditional ledger insertion. No correction remains pending. The core still retains actual middle distance, recent capturing layer, all chosen source-component capacity failures, full historical J and original qualifications. Neither its positive R_core nor signed Phi_core has a general root budget here; source coarsening/order supplies no universal coverage. Reverse large-capturing/small-missed configurations remain. The genuine historical H0 entry, extreme aspect, I/J/D/future/suffix slots, finite global epsilon sum and full physical-scale assembly are not discharged. Native H_rootleft remains a different unpaid object. General n^(1/2+o(1)) weak closure is NOT certified.

Final SHA256 bindings follow; only the listed current bytes are covered:

- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round322_20261018_final_checkpoint/budget_checks.json`: `75e7258154f637b78772bb18f6311cc10c71b849472bb4615ff43a46b9bf97e6`
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round322_20261018_final_checkpoint/budget_checks.log`: `7aa8e5add83f6939ff162b470347050b35915369daa459cc2893e5cc45005cf6`
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round322_20261018_final_checkpoint/budget_checks.py`: `38d692bdbadaa4e9b5d45be7af2372c777b41a34c4ad7668ddd29ab39a293e4d`
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round322_20261018_final_checkpoint/combined.md`: `7382500b7b422d7aea0c9b9440ee16997ac0efd77d9dbaf6ef1b8a2c02f61be4`
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round322_20261018_final_checkpoint/history_scope.md`: `de307a2ddc1a5c0d20b9ab4392a905db8e779d131956c7a8616eb827d49af539`
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round322_20261018_final_checkpoint/layer_budget.md`: `637dd27df4f56e25cdf8fa594b1489f79f2c9aff4810d1120202ddf95dbcaf64`
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round322_20261018_final_checkpoint/ledger.md`: `5afd04957c06ab4c2c08fc920cc4d503ffb488e5f585ebd6b282fe4fe1e4a2d5`
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round322_20261018_final_checkpoint/numeric_notes.md`: `be98ebfa0e15dfd225a2d95e847522d6e5e2b3f36c1d1b4482230de1e85c59ea`
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round322_20261018_final_checkpoint/research.tex`: `01316353791881d59fcdb8ebc9624a32a6a77cf6e86e681a1a3a8fc6ed7f52bc`
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round322_20261018_final_checkpoint/source_geometry.md`: `f5ab8006e4110b4bc8406fdff2f28bb955a99976a6bf6f7e357f7ff9c99b8cfd`
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round322_20261018_final_checkpoint/source_references.json`: `7a9686bdbfc652cba2655a879ddeafac53b164d8b27ef5ce5331c572dc0ba35c`
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round322_20261018_final_checkpoint/source_tail_checks.log`: `c9b86ccb4ae166174c8fdd0b14cda5cf31e8ebbffbaa7e720d3ea886d90f55c0`
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round322_20261018_final_checkpoint/source_tail_checks.py`: `ed261bd80ce9139a8d4780f312308cfd83de6fb11cf638e9583de25ac2677be7`

Ownership respected: only /tmp/r322_audit.md written by this reviewer. Final bounded audit frozen.
