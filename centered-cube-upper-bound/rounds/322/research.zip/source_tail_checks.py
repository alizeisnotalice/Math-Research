"""Exact scalar certificate for a rational narrow-layer cutoff; no asymptotic claim from samples."""
from fractions import Fraction as F
import json
counts={'rational_tail_discount':0,'normalized_source_price':0}
rows=[]
for n in (1,2,4,16,36,64,256,1024):
    k=n.bit_length()  # ceil(log_2(n+1)) for positive integer n
    kappa=(1+F(1,n))**k
    assert kappa**n >= 2**k >= n+1
    counts['rational_tail_discount']+=1
    # An<=n+1 on b/a<=2; Csoft cancels from this coefficient check.
    for lam in (F(1,4),F(1),F(4)):
        q=3*lam/4
        assert (4*lam/q)*(n+1)/kappa**n <= F(16,3)
        counts['normalized_source_price']+=1
    rows.append({'n':n,'k':k})
print(json.dumps({'status':'PASS','checks':counts,'total':sum(counts.values()),'dimensions':rows,'scope':'Exact scalar checks. Uniform proof uses binomial (1+1/n)^n>=2 and An<=n+1; actual kernel geometry is in budget_checks.py.'},sort_keys=True))
