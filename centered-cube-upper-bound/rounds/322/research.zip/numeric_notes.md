# R322 new old-layer / source-root budgets

This replaces the stopped duplicate potential experiment. The standalone script passes 1,119 exact Fraction checks on 15 real positive-volume configurations: initial n1,4 (540); boundary n16 (270); expanded n64 (270), plus39 anisotropic additions at n16,36,64. Each dimension has equality-root-mass, half-mass and zero-source cases. It prints deterministic JSON to stdout; no result JSON file is created.

Actual kernel fixture: a=lambda=q=1,b=2,s=0,L=2. Beta has mass1 uniformly on a small cube of side epsilon=1/(100n) centered0. Four disjoint receiver cubes of the same side have first-coordinate centers -.3,+.3,-.1,+.1 and remaining coordinates0, with original R=1,1,3/2,2. For every beta/receiver pair, all coordinate distances are <1, so the actual endpoint kernel is P_(0,2)=2^-n. Thus U=2^-n on E and rho=2^-n<=1 exactly. Receiver occupation mass is epsilon^n2^-n per cube.

Nu is uniform on two cubes of side epsilon centered at first coordinates -.6,+.6. Equality masses are1/sqrt(n) each, half cases halve them. Exact extreme-distance inequalities show capture patterns (left,right) of (1,0),(0,1),(1,1),(1,1) on the ENTIRE receiver/source products. There are no partial incidences. All receiver hard responses are bounded by4, and every cap is verified from its actual captured masses. Source roots have side1/n in the COMMON grid with phase-1/(2n); integer cell locations and strict containment of both source cubes are checked. Their nu masses are therefore exactly the specified masses.

A: capturing-end old layers

For kappa=1,4/3,2,3 and H equal to1,2,4,5 times one actual occupation mass, the script integrates the original positive capture/miss expression with full prefix J, gate J>=H and capturing-end layer condition r>=kappa R(u). Breakpoints include every original R and legal kappa R(u). Exact ell weights retain terminal2^-n. All192 instances satisfy old fee<=4 kappa^-n |E|. Separate144 interval-tail checks verify ell([kappa R,b])=(kappa R)^-n if kappa R<=b, and0 otherwise. These include36 equal-to-b tests with the positive terminal atom, and72 beyond-b tests. A concrete actual pair with capturing R=3/2 and missing R=1 checks that reversing a scale comparison cannot supply the old-layer gate at r=3/2,kappa=4/3.

B: source-root baseline

The independent positive baseline retains the original second endpoint and full J, then cancels sum_w U/J=1 only in that baseline. Its capturing endpoint uses the inclusive capacity gate sqrt(n)m_D>=R(u)^n. Both roots pass exactly at the R1 equality case, fail at half mass, and higher original radii are independently evaluated. All192 high-J baseline budgets satisfy

    baseline <=4 sqrt(n)(1+1/n)^n W_nu.

No receiver/source scale is changed. The four actual H choices are finite diagnostic thresholds; they are not asserted to be a natural root H from original low-pe/full-history selectors. This experiment verifies the candidate gates and costs on a true endpoint-soft-kernel subclass with positive-volume sources and receivers. It does not certify full historical eligibility or any all-input root theorem. The analytic proofs, rather than the finite parameter list, establish the general bounds.

Check counts: actual kernel12; FIRST12; same-radius cap48; full capture/outside geometry96; receiver disjointness12; source-root first-axis containment24 and transverse containment12; old interval tail144, b equality36, beyond b72; old budget192; root budget192 and nonnegativity192; root equality guards24; reverse-scale exclusion12.

Strict newly covered rectangular branch

An additional actual-kernel fixture at n16,36,64 puts nu mass1/sqrt(n) uniformly on a strip centered .6e1, of first-axis length1/4 and other widths1/n^2. Two receiver cubes of side1/(100n), centered at +.3e1 and -.3e1, have R1. Beta remains the positive-box unit source at0, with s0,L2,q1, so U=2^-n and FIRST holds on all products. Exact extreme distances show every positive receiver/source pair captures, every negative pair misses, and all caps hold. With h=receiver-volume2^-n, J=2h,H=J/2, the true finite-layer fee is positive and exactly B_H=J nu(strip)/4, since the ell tail from1 through b2, including the terminal atom, is1.

Every isotropic side1/n grid cell has at most the strip mass times4/n, strictly below1/sqrt(n); this applies to every grid phase. The entire rectangular source block has mass exactly1/sqrt(n), so it succeeds at the inclusive capacity threshold. Its actual inflation Gamma=(5/4)(1+1/n^2)^(n-1) is rationally <=2. Receiver pair distance is >1/2 and <2 on the entire boxes, so for h_outer<=1/2,t>=1 it lies in the specified middle spatial regime. These39 exact checks show a positive geometrical intersection newly covered by the rectangle branch; they do not certify original low-pe/history or the full-f/q selector conditions.

Reproduce:

```
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 /tmp/r322_budget_checks.py
```

No external packages, random matrices, old temporary-script imports or floating-point decisions are used. The old R313/R317 identities remain historical checks and are not counted as new R322 results.
