# R322 — rectangular source capacity pays an original positive loss branch

This note gives a direct payment in the original R302 high-row capture loss. It keeps the actual receiver measure and both actual endpoints. The new covered branch can strictly exceed the isotropic source-root branch. It does not bound the remaining middle-distance, capacity-failure loss for arbitrary inputs. The underlying FIRST/support-volume argument is familiar from earlier source-packet entrances; the contribution here is its direct oriented `B_H` interface, the preserved overlap credit, and source-conserving anisotropic coarsening. No measure-order identification of the abstract row source is used.

## 1. Contract and exact positive decomposition

Let `n≥1`, `0<a≤b<∞`, `λ>0`, and let `β(dy),ν(dz)` be finite positive L¹ sources. Write `Q_R(x)=x+[-R/2,R/2]^n`. On the original receiver set `E`, keep the actual selected `s(x),L(x),R(x),q(x)` and the original admissible row mask `α(x,y)`. In particular `a≤L,R≤b`, `3λ/4≤q≤λ`, and

\[
 U_y(x)=1_E(x)\alpha(x,y)P_{s(x),L(x)}(x-y)/q(x),\qquad
 \rho(x)=\int U_y(x)\,\beta(dy)\le1_E(x).                 \tag{1}
\]

The row mask is independent of hard source `z`; its original selection and every original gate are unchanged. Assume only the **same actual receiver, same actual radius** cap

\[
 \nu(Q_{R(x)}(x))\le4\lambda R(x)^n.                       \tag{2}
\]

No maximizing-radius assertion, enlarged-radius cap, source-density bound, or `ν≤β` is needed. Put

\[
 \ell_n=b^{-n}\delta_b+n r^{-n-1}1_{[a,b]}(r)\,dr,
 \quad \ell_n([R,b])=R^{-n},\quad A_n=1+n\log(b/a),        \tag{3}
\]
\[
 J_y(r)=\int_{R(x)\le r}U_y(x)\,dx,\qquad
 A_{yz}(r)=\int_{R(x)\le r}U_y(x)c_x(z)\,dx,
 \quad c_x(z)=1_{Q_{R(x)}(x)}(z).                          \tag{4}
\]

Use the original finite rows: `J_y(b)<∞` for `β`-almost every `y`, as supplied by the original finite-band kernel envelope. Fix `H>0`, a measurable weight `0≤v(y,z,r)≤1` independent of the two receiver endpoints, and any original pair qualification `0≤M(y,z,r,u,w)≤1`. Thus `v=1,M=1` gives the original `B_H`; the original tent weight and a retained middle-distance mask are also allowed. All receiver pairs below satisfy `R(u),R(w)≤r`. With

\[
 d\Xi=\beta(dy)\nu(dz)\ell_n(dr)
 1_{\{J_y(r)\ge H\}}\frac{v(y,z,r)}{J_y(r)}
 U_y(u)U_y(w)\,du\,dw,
\]

define

\[
 N^M=\int c_u(z)M\,d\Xi,\qquad
 E^M=\int c_u(z)c_w(z)M\,d\Xi,\qquad
 B^M=\int c_u(z)(1-c_w(z))M\,d\Xi=N^M-E^M.              \tag{5}
\]

These quantities are finite: drop `v,M` and the high-row gate, integrate `w`, and apply FIRST at each scale to get

\[
 N^M\le\int\ell_n(dr)\int\nu(dz)
       \int_{R(u)\le r}1_{Q_{R(u)}(u)}(z)\rho(u)\,du
 \le A_nW_\nu.                                         \tag{6}
\]

The last receiver set is contained in `Q_r(z)`. Consequently all signed formulas below subtract finite nonnegative quantities. When `M=1`,

\[
 E^1=\int\beta(dy)\nu(dz)\ell_n(dr)
       1_{J_y(r)\ge H}\,v(y,z,r)\frac{A_{yz}(r)^2}{J_y(r)}.
                                                               \tag{7}
\]

## 2. Source-once rectangular capacity theorem

Freeze one finite or countable measurable source partition `{S_j}` covering `ν`-almost all sources. Each `S_j` is contained in an axis-parallel box `D_j` with finite side widths `δ_{j1},…,δ_{jn}`. The containing boxes may overlap; the source assignments are disjoint. Set

\[
 m_j=\nu(S_j),\quad
 r_j^n=\frac{m_j\sqrt n}{\lambda},\quad
 K_j=\prod_{i=1}^n(1+\delta_{ji}/a),                       \tag{8}
\]

with `r_j=0` if `m_j=0`. The partition and its boxes are fixed as source data, not chosen separately for each receiver. On the **capturing endpoint** define

\[
 G(u,z)=\sum_j1_{S_j}(z)1_{\{R(u)\le r_j\}}
       =\sum_j1_{S_j}(z)
          1_{\{m_j\ge\lambda R(u)^n/\sqrt n\}}.          \tag{9}
\]

Insert `G` or `1−G` in (5), giving `N_cov,E_cov,B_cov` and their uncovered counterparts. These are positive disjoint allocations of the original traffic, with all original `U,J,v,M` retained. Then

\[
 \boxed{\quad N_{\rm cov}^M\le
 P:=4\sqrt n\sum_{j:r_j\ge a}K_jm_j.\quad}              \tag{10}
\]

In particular,

\[
 B_{\rm cov}^M\le P-E_{\rm cov}^M\le P,
 \qquad
 \boxed{\ B^M\le P+N_{\rm uncov}^M-E^M.\ }             \tag{11}
\]

The alternative positive-loss receipt is `B^M≤P+B_uncov^M`. Its complement is exactly the original loss with

\[
 z\in S_j,\qquad m_j<\lambda R(u)^n/\sqrt n.             \tag{12}
\]

The strict failure in (12) is intentional: equality belongs to the paid branch. Formula (11) retains the *whole* original capture-square credit for `M=1`. The source gate is oriented at `u`; it cannot be moved to `w` or symmetrized for free. With a general `M`, the retained overlap is exactly `E^M`, not an invented square.

**Proof.** For one `j`, first bound the noncapturing endpoint integral by `J_y(r)`. Drop only positive factors `v,M,1_{J≥H}`. Tonelli and the exact tail identity (3) give

\[
 N_{{\rm cov},j}^M
 \le\int_E\rho(u)1_{R(u)\le r_j}R(u)^{-n}
                \nu(S_j\cap Q_{R(u)}(u))\,du.            \tag{13}
\]

Apply the actual FIRST bound `ρ≤1` and (2) at the unchanged `R(u)`: the integrand is at most `4λ`. If it is nonzero, `u∈D_j+Q_{s_j}`, where `s_j=min(b,r_j)`. An active branch has `r_j≥a`, hence `s_j≥a`. Therefore

\[
 |D_j+Q_{s_j}|=\prod_i(\delta_{ji}+s_j)
 \le s_j^n K_j\le r_j^nK_j,
 \quad N_{{\rm cov},j}^M\le4\lambda r_j^nK_j
                         =4\sqrt nK_jm_j.               \tag{14}
\]

Sum the positive estimates. Disjointness is needed for source allocation and the source-mass sum; receiver supports need not be disjoint. Equations (5) then give (11). This argument never replaces the actual receiver convolution by a frozen convolution. ∎

Zero-mass pieces carry no `ν` traffic. If `r_j<a`, their gate is empty. `r_j=a` retains all original `R=a` atoms; `r_j>b` simply covers every actual scale. Both endpoint cases `R=a,b` are included by the inclusive tail identity (3); `ell_n` has only the explicit `b` atom. For countably many pieces, (10) is valid with an infinite right side, and is useful when the displayed weighted mass sum is finite.

If every box satisfies `Σ_iδ_ji≤aL`, then `K_j≤e^L` and

\[
 P\le4e^L\sqrt n\,\nu\Big(\bigcup_{j:r_j\ge a}S_j\Big)
 \le4e^L\sqrt nW_\nu.                                  \tag{15}
\]

In particular, columns in pieces with `m_j≥λb^n/√n` are paid at **all** original scales, not only a fixed scale.

## 3. Coarsening supplies strictly more actual coverage without source copies

Suppose an old partition consists of disjoint source pieces `S_i`. Group its indices into fixed disjoint groups `I_j`, and let `S'_j=⋃_{i∈I_j}S_i`, contained in a specified finite box `D'_j`. Then

\[
 m'_j=\sum_{i\in I_j}m_i,\qquad r'_j\ge r_i\ (i\in I_j).
                                                               \tag{16}
\]

Thus every old covered capturing endpoint remains covered by the new partition. The new gate may also cover endpoints that failed every old fine-piece gate. Apply (10) **once to the new partition** with its computed `K'_j`; do not add its cost to the old costs or claim a free supremum over independently chosen partitions. Large coarsened boxes have their full explicit inflation cost.

A concrete all-source construction starts with a fixed side-`a` macro grid and its side-`a/n` subdivisions. In each macrocell choose a fixed set of `k` coordinate directions and merge the fine cells along those directions. The resulting rectangular partition has side `a` in `k` axes and side `a/n` in the others. It merges `n^k` old cells and satisfies

\[
 K_j=2^k(1+1/n)^{n-k}\le e\,2^k,
 \qquad P\le4e\,2^k\sqrt nW_\nu.                        \tag{17}
\]

For `k=1` this is at most `8e√nWν`; `k=O(log log(n+2))` gives a root budget times fixed powers of logarithms. The chosen axes may depend on the source data in each macrocell, provided that this produces one frozen partition. For example choose among the finitely many axis sets to maximize source mass in packets satisfying `m_j≥λb^n/√n`, with a fixed tie rule. This is an actual all-scale coverage selection, while every unselected/failing packet remains in (12). It gives no assertion that an arbitrary source has substantial covered mass.

More general anisotropic source assignments need not be grid rectangles themselves: any measurable `S_j⊂D_j` with `Σδ_ji/a≤L` has (15). This permits long directions along the actual source geometry while keeping source mass counted once.

## 4. Relation to the other paid spatial branches and source contracts

The theorem is valid with a retained R320 middle-distance qualification `M`, so it pays a genuine part of the original middle loss. Equivalently, allocate the **baseline** first to the covered branch, then apply the established near/long baseline estimates only to the uncovered part, and retain the uncovered middle baseline. Since these are disjoint positive baseline allocations, one may keep the original full `E^M` subtraction in the resulting signed ledger. A positive-loss version instead retains only the corresponding unallocated loss. One must not combine the full negative square with separately overlapping positive payments as if they were disjoint.

The main theorem uses `m_j=ν(S_j)`. An optional dominating-source version is also valid: if a *specified finite source measure* `τ≥ν` is available, set `m_j=τ(S_j)` in (8)–(12). Proof (13) still uses the original `ν` cap, while (14) charges `τ(S_j)` once, giving `4√nΣK_jτ(S_j)`. Its extra coverage is paid from `Wτ`, not automatically from the abstract row `Wβ`.

On the matched coupled lineage, R321 `source_contract.md` verifies `ν≤β^c≤f` and the appropriate original-source cap inheritance. This licenses `τ=β^c` or `τ=f` only on that specified lineage and with its own source budget. It does **not** identify the abstract row source `β` with `β^c`, give `β+ν≤f`, or certify a hard maximizing selector. None of these facts is needed for (10).

## 5. Reproducible scope check and remaining task

The independent script `/tmp/r322_budget_checks.py` was run again for this note and returned `PASS`, **1,119 exact Fraction checks**. Its relevant coverage diagnostics include 192 source-root baseline budget checks and 39 strict anisotropic additions. The other checks concern the separately owned old-layer receipt and actual fixture eligibility; they are not additional new theorems here. Full details are in `/tmp/r322_budget_checks.md`.

The strict addition uses `n=16,36,64`, `a=λ=q=R=1`, `b=L=2`, and actual shared softness `s=0`. The unit row source is uniform on a small positive-volume cube about zero. Receivers are positive-volume cubes about `±.3e₁`, with side `1/(100n)`. The actual endpoint kernel is `U=2^{-n}`, so FIRST holds. The hard source is uniform on the strip centered at `.6e₁`, of width `1/4` in its first coordinate, `1/n²` in the others, and mass `m=1/√n`. Every positive receiver captures the entire strip; every negative receiver misses it; the actual hard caps hold. With `H=J/2`, the original loss is exactly `B_H=Jm/4>0`.

Every isotropic side-`1/n` cell, for every grid phase, has mass at most `(4/n)m<m`, so fails the `R=1` capacity gate. The single rectangular strip succeeds at equality, and has `K=(5/4)(1+1/n²)^{n-1}≤2`. The receiver pair distances lie strictly between `1/2` and `2` on the whole boxes, hence this is a newly covered positive portion of the specified middle regime. This is a true positive-volume endpoint-kernel/FIRST/hardcap fixture. The diagnostic does **not** certify original low-`pe`, full-history, or full-`f`/`q` selector eligibility.

Reproduce without external packages:

```sh
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 /tmp/r322_budget_checks.py
```

Script SHA256: `38d692bdbadaa4e9b5d45be7af2372c777b41a34c4ad7668ddd29ab39a293e4d`.
Diagnostic note SHA256: `be98ebfa0e15dfd225a2d95e847522d6e5e2b3f36c1d1b4482230de1e85c59ea`.

The outstanding geometric task is to control the exact original capacity-failure loss (12), in particular its remaining middle-distance part, or to prove enough coverage by one source-conserving partition with a bounded inflation sum. A source may spread across too many low-mass boxes; neither coarsening nor source order by itself proves that this remainder is small. The payment (10) and the strict enlargement of coverage are established; no general root theorem or original global entrance is claimed.
