# 第100轮：实际障碍分解、截断占用量与共同包络的边界

日期：2026-10-12。一般中心轴平行立方体极大算子的 $C_n^\square\le\sqrt n\,n^{o(1)}$ 一致弱型上界仍未证明。本轮新增一般定理和明确的失败接口；保留 $O(n\log n)$ 全输入基准。上一轮已独立提交并推送 `508ba64b57a9df1244748d8b6724f97713128c9c`。

本轮对非负 $L^1\cap L^2$ 输入建立零阻尼晶体障碍，并以两条独立变分论证证明实际通量、有界残差及质量守恒的相容分解。每条论证中的通量同时满足其全部恒等式；不声称两种构造选择了相同或唯一的通量。接触集上另用带符号能量测试证明原密度不超过障碍高度。由此得到保留真实接收阈值的占用量删帽接口。该接口尚缺一般的删帽费用与剩余能量联合预算，不能把存在性中的源 $L^2$ 范数当作统一费用。

原联合门路线保留同源、同阈值、原最早尺度及全部老费用。新增一般共同剖面定理说明其质量、振幅与无约束尺度包络之间的准确关系；私有合资格压力测试表明，不能反向把昂贵包络解释为原共同来源容量的必要费用。目标仍须通过真实接收几何或来源共同重分配解决。

下文依次给出统一主账、四个详细理论模块、实际检验与两份独立审核。来源配方、数值程序和未发表量化压力保留本地；公开归档只含报告、详细 LaTeX 文本与必要复现守卫，不编译 PDF。各模块的公式编号在模块内解释。


## 统一假设与最终回代账

固定 $Q(x,L)=x+[-L/2,L/2]^n$，$A_Lf=L^{-n}\int_Q f$，原来源 $d\mu=f\,dy$，$W=\int f$。空间接收测度始终是实际 Lebesgue $dx$。零输入的正阈值事件为空；一维由既有界覆盖，渐近账取 $n\ge2$。

第一条路线保留同一个原输入、阈值 $\lambda$、原可测最早接触尺度 $L_*(x)\in[1,2]$，以及单位锚点、全窗口 $P_1$、原中间下限、所选尺度粗门、包门和物理门。上一轮已经支付的内核分支不重复付费，本轮没有新增无条件删除分支。精确主账仍为

\[
\lambda|E_{\rm initial}|\le
[A_{\rm old}+C_{\rm ext}+\sqrt n+2\lceil\sqrt n\rceil]W+\lambda|F_2|.
\]

$A_{\rm old}$ 的所有组成及两个不同的 $C_{\rm ext}$ 用途详见 adaptive 模块。$F_2$ 的统一根阶共同来源容量仍未知。保留 $O(\log(n+2))$ 全尺度返回；若另作原强度分层，保留 $J_n=O(\log n)$ 和实际重叠。未来若限制或改变来源，必须重新核验每个门，重新计入原阈值比、源质量、分类费用与真实终端；本轮没有证明递归费用可和。更新后的 N04 技能仅在势能有统一下界、非负下降项和有界误差部分和时允许望远镜回代，这些条件不能由层数少推出。

第二条路线已是全尺度。对 $f\ge0\in L^1\cap L^2$、能量阈值 $\kappa>0$，以障碍高度 $\kappa/2$ 得到实际帽 $\Omega$，$|\Omega|\le2W/\kappa$，实际分解 $f=g-\operatorname{div}Z$，$0\le g\le\kappa/2$，$\int g=W$。接触测试另外给 $f\le g$ 于 $\Omega^c$。帽不必为开集；面通量用几乎所有接收点及尺度的分布/Fubini 论证。

覆盖模块定义同源阈值占用场 $N_0,N_1,H$。对任意 $T>0$，令

\[
P(T)=\int_{\Omega^c\cap\{H\le T\}}\int_0^\infty N_0(x,L)\,{dL\over L}\,dx,
\quad U_T=\Omega\cup\{x\in\Omega^c:H(x)>T\}.
\]

则 $|U_T|\le2W/\kappa+|\{x\in\Omega^c:H>T\}|$，且
$E_\kappa(f;U_T)\le c_{n,\beta}T P(T)$，其中 $\beta=1+1/(2n)$、$c_{n,\beta}=n/(1-\beta^{-n})\le4n$。这是一条已证接口；一般子幂支付尚未证明。以全占用矩 $P,Q$ 代替截断 $P(T)$ 会丢失真正被删去的接收点，不能假定其积自动小。

一般帽返回保留第98轮的准确形式：若对每个 $\kappa$ 可取 $|U|\le AW/\kappa$、$E_\kappa(f;U)\le B\kappa W$，则

\[
C_n^\square\le4A+8\sqrt{nAB/\log2}.
\]

目前可把第99轮 OT 与高度帽 $V$ 同实际障碍帽取并集，明确付费 $A=5$，$B=c_n\log(4n)\log(8n)$，$c_n=n/(1-2^{-n})$；这仍只有 $O(n\log n)$。若另选已证的第99轮帽而不强行并入障碍帽，原较小费用也继续有效。本轮没有把不同帽认作同一个帽。达到目标的一个充分条件是 $A,B=n^{o(1)}$，所有依赖必须统一于输入与阈值。

零阻尼势目前只为 $L^1\cap L^2$ 输入建立。若将来获得与幅度无关的一致弱界，可对 $f_m=\min(f,m)1_{[-m,m]^n}\uparrow f$ 使用原算子 $M_\square f_m\uparrow M_\square f$ 回代；这不等于任意 $L^1$ 输入先有有限能量势。

实际非线性 resolvent 的全输入弱界1及 $N$ 次迭代上界 $N$ 继续保留。一般真实流最大弱界未由此推出；本轮私有严格压力排除了其中一种统一逐点桥梁，未排除直接弱型比较、一般覆盖或有偿删帽。四个模块均不能单独充当一般根阶闭合。


## General actual obstacle and bounded density

Let \(n\ge1\), \(H(p)=\|p\|_1\), \(F(p)=H(p)^2/2\), and
\[
 E(v)=\int_{\mathbb R^n}F(\nabla v),\quad D(E)=H^1(\mathbb R^n),
 \qquad E=+\infty\text{ outside }H^1.
 \tag{O1}
\]
For \(f\ge0\) in \(L^1\cap L^2\), \(\lambda>0\), and \(W=\|f\|_1>0\), write
\[
 V=W/\lambda,\qquad \ell=(4V)^{1/n}.
\]
All sets below are measurable sets modulo Lebesgue null sets; no openness of a positivity set is assumed.

**Theorem O.** There is a nonnegative minimizer \(w\in H^1\cap L^1\) of
\[
 \Phi_0(v)=E(v)+\lambda\|v\|_1-\langle f,v\rangle,\qquad v\ge0,
 \tag{O2}
\]
selected as the increasing zero-damping limit of the unique damped minimizers. Put \(\Omega=\{w>0\}\). Then
\[
 |\Omega|\le V,\qquad
 \|H(\nabla w)\|_2\le\ell\|f\|_2,\qquad
 \|w\|_2\le\ell^2\|f\|_2,\qquad
 \|w\|_1\le \sqrt V\,\ell^2\|f\|_2.
 \tag{O3}
\]
There are actual measurable functions \(g,Z\) such that
\[
 \begin{gathered}
  0\le g\le\lambda,\quad g\in L^1\cap L^2,\quad
  \int g=W,\quad g=\lambda\ \text{a.e. on }\Omega,\\
  Z(x)\in\partial F(\nabla w(x))\ \text{a.e.},\quad
  Z=0\ \text{a.e. on }\Omega^c,\quad
  f=g-\operatorname{div}Z,\quad f-g\in\partial_{L^2}E(w).
 \end{gathered}
 \tag{O4}
\]
The divergence in (O4) is the \(L^2\) function \(g-f\), in the full distributional sense; there is no omitted singular boundary measure. The explicit flux bounds are
\[
 \begin{gathered}
 \|\|Z\|_\infty\|_2=\|H(\nabla w)\|_2\le\ell\|f\|_2,\qquad
 \|Z\|_{L^2(\ell^2)}\le\sqrt n\,\ell\|f\|_2,\\
 \|\|Z\|_\infty\|_1\le\sqrt V\,\ell\|f\|_2,\qquad
 \|Z\|_{L^1(\ell^2)}\le\sqrt{nV}\,\ell\|f\|_2,\qquad
 \|g\|_2^2\le\lambda W.
 \end{gathered}
 \tag{O5}
\]
Moreover,
\[
 \int H(\nabla w)^2=\int(f-\lambda)w,
 \qquad f\le g\le\lambda\quad\text{a.e. on }\{w=0\}.
 \tag{O6}
\]
We do not assert uniqueness of an arbitrary zero-damping minimizer. The constants in (O3)–(O5) retain \(\|f\|_2\); these are existence and integrability bounds, not an amplitude-free exterior-energy estimate. Zero input is handled by \(w=g=Z=0\).

### Support Poincare bound with its full constant

For \(v\in H^1\) supported on a measurable set of volume at most \(V\), let \(A_\ell v\) be its convolution with the probability density of the cube \([-\ell/2,\ell/2]^n\). Cauchy–Schwarz gives \(\|v\|_1\le\sqrt V\|v\|_2\), and Young's inequality gives
\[
 \|A_\ell v\|_2\le\ell^{-n/2}\|v\|_1\le\tfrac12\|v\|_2.
\]
For \(h\) in this cube, the translation formula and
\(|h\cdot\nabla v|\le\|h\|_\infty H(\nabla v)\) imply
\[
 \|v(\cdot-h)-v\|_2\le\|h\|_\infty\|H(\nabla v)\|_2.
\]
Approximation by smooth functions justifies the formula for \(H^1\) data. Averaging and using \(\|h\|_\infty\le\ell/2\) proves
\[
 \|v\|_2\le\ell\|H(\nabla v)\|_2.
 \tag{O7}
\]
Thus this existence bound does not need a hidden Euclidean-gradient comparison factor.

### Damped minimizers and the zero-damping limit

For \(\delta>0\), let \(w_\delta\) minimize
\[
 \Phi_\delta(v)=E(v)+\frac{\delta}{2}\|v\|_2^2+
                   \lambda\|v\|_1-\langle f,v\rangle,\qquad v\ge0.
\]
The R99 direct-method proof gives existence and uniqueness. Its truncation argument is short: comparing with \((w_\delta-h)_+\), the energy and quadratic norm decrease, so
\(\lambda\int\min(w_\delta,h)\le\int f\min(w_\delta,h)\).
Divide by \(h\), then let \(h\downarrow0\), to obtain
\(\lambda|\{w_\delta>0\}|\le W\).

Scalar variations \(c w_\delta\), \(c>0\), give the exact identity
\[
 \|H(\nabla w_\delta)\|_2^2+
 \delta\|w_\delta\|_2^2+\lambda\|w_\delta\|_1
 =\langle f,w_\delta\rangle.
 \tag{O8}
\]
Using (O7) on its support, (O8) implies all three bounds on \(w_\delta\) in (O3), uniformly in \(\delta\).

If \(\delta_1>\delta_2\), set \(u=w_{\delta_1}\), \(v=w_{\delta_2}\). Use \(u\wedge v\) and \(u\vee v\) in their respective minimization problems. The local gradient energy sum is unchanged, as are the sum of the linear and L1 terms. The quadratic difference is
\[
 -\frac{\delta_1-\delta_2}{2}
   \int_{\{u>v\}}(u^2-v^2)\le0.
\]
Minimality forces this to vanish; hence \(w_{\delta_1}\le w_{\delta_2}\). Along any decreasing sequence \(\delta_j\downarrow0\), the nonnegative functions increase to \(w\). Uniform L1/L2 bounds and monotone convergence give \(w\in L^1\cap L^2\) and strong convergence in both spaces. Their supports are nested, so \(|\{w>0\}|\le V\). The uniform gradient bound gives weak \(H^1\) convergence and the bounds in (O3).

For any admissible \(v\),
\[
 \Phi_0(w_{\delta_j})\le\Phi_{\delta_j}(w_{\delta_j})
 \le\Phi_0(v)+\frac{\delta_j}{2}\|v\|_2^2.
\]
Lower semicontinuity of the energy and strong L1/L2 convergence prove that \(w\) minimizes \(\Phi_0\). The limit is the same for every cofinal decreasing damping sequence, by the order just proved. Scaling this minimizer gives the first identity in (O6).

### Bounded density before taking a flux limit

This step supplies the simultaneous bounded density and actual L2 subgradient, rather than assuming them from a formal variational inequality. Define the Huber approximation
\[
 j_\varepsilon(r)=
 \begin{cases}
 r^2/(2\varepsilon),& |r|\le\varepsilon\lambda,\\
 \lambda|r|-\varepsilon\lambda^2/2,& |r|>\varepsilon\lambda,
 \end{cases}
 \qquad
 \beta_\varepsilon(r)=j_\varepsilon'(r)
 =\operatorname{clip}_{[-\lambda,\lambda]}(r/\varepsilon).
 \tag{O9}
\]
The integral \(P_\varepsilon(u)=\int j_\varepsilon(u)\) is finite and continuously Frechet differentiable on L2, with gradient \(\beta_\varepsilon(u)\). Indeed \(0\le j_\varepsilon(r)\le r^2/(2\varepsilon)\), and the pointwise Lipschitz bound on \(\beta_\varepsilon\) gives
\[
 |P_\varepsilon(u+h)-P_\varepsilon(u)
      -\langle\beta_\varepsilon(u),h\rangle|
 \le\|h\|_2^2/(2\varepsilon).
\]
For fixed \(\delta,\varepsilon>0\), the unconstrained functional
\[
 E(u)+\frac{\delta}{2}\|u\|_2^2+P_\varepsilon(u)-\langle f,u\rangle
\]
has a unique minimizer \(u=u_{\delta,\varepsilon}\). Absolute value preserves its energy, quadratic term and penalty, and decreases its last term because \(f\ge0\); uniqueness implies \(u\ge0\). Minimality along segments, convexity of \(E\), and differentiability of the other terms prove directly that
\[
 \xi_{\delta,\varepsilon}
 =f-\delta u-\beta_\varepsilon(u)\in\partial_{L^2}E(u).
 \tag{O10}
\]
Thus no unproved subdifferential sum rule on L1 is being used.

To obtain a whole-space budget, let \(T_h(u)=\min(u/h,1)\). This lies in \(H^1\cap L^2\). For \(0<\eta<h\), the variation \(u-\eta T_h(u)\) decreases the energy. The subgradient inequality therefore gives
\(\langle\xi_{\delta,\varepsilon},T_h(u)\rangle\ge0\).
Inserting (O10) and letting \(h\downarrow0\) yields
\[
 \int\bigl(\delta u+\beta_\varepsilon(u)\bigr)\le W,
 \qquad \|\beta_\varepsilon(u)\|_2^2\le\lambda W.
 \tag{O11}
\]
The first limit uses monotone convergence on the nonnegative terms and domination against \(f\). In particular \(u\in L^1\) is proved here, not presumed.

A constant penalty error times the volume of the whole space would be invalid. The correct integrable error is
\[
 0\le\lambda\|u\|_1-P_\varepsilon(u)
 \le\varepsilon\lambda\int\beta_\varepsilon(u)
 \le\varepsilon\lambda W.
 \tag{O12}
\]
For \(u\le\varepsilon\lambda\), write \(u=\varepsilon\beta_\varepsilon(u)\); for larger \(u\), the gap is \(\varepsilon\lambda^2/2\). This verifies (O12) pointwise before integration.

Compare the penalized minimizer with \(w_\delta\). By (O12),
\[
 0\le\Phi_\delta(u)-\Phi_\delta(w_\delta)
 \le\varepsilon\lambda W.
\]
The \(\delta\)-strong convexity of \(\Phi_\delta\) on its positive domain then gives the explicit convergence estimate
\[
 \|u_{\delta,\varepsilon}-w_\delta\|_2^2
 \le 2\varepsilon\lambda W/\delta.
 \tag{O13}
\]
Choose a sequence along which \(\beta_\varepsilon(u_{\delta,\varepsilon})\)
converges weakly in L2 to \(g_\delta\). The closed convex order interval yields
\(0\le g_\delta\le\lambda\); compact nonnegative cutoff tests in (O11) yield
\(\int g_\delta\le W\), and \(\|g_\delta\|_2^2\le\lambda W\).

The L2 subgradient graph is closed under strong convergence of its argument and weak convergence of its values. In this case it follows directly by passing to the subgradient inequality using lower semicontinuity of \(E\). Apply it to (O10) and (O13):
\[
 f-\delta w_\delta-g_\delta\in\partial_{L^2}E(w_\delta).
 \tag{O14}
\]
Complementarity also has a whole-space justification:
\[
 0\le\int u_{\delta,\varepsilon}
              [\lambda-\beta_\varepsilon(u_{\delta,\varepsilon})]
 \le\varepsilon\lambda W.
\]
The weak/strong L2 pairing converges to \(\langle g_\delta,w_\delta\rangle\).
Fatou for the nonnegative L1 norms gives
\(\lambda\|w_\delta\|_1\le\langle g_\delta,w_\delta\rangle\);
the reverse inequality follows from \(g_\delta\le\lambda\).
Consequently \(g_\delta=\lambda\) almost everywhere on \(\{w_\delta>0\}\).
No unproved strong L1 convergence at this epsilon step was used.

Now let \(\delta_j\downarrow0\). The already proved strong L1/L2 convergence of \(w_{\delta_j}\), its uniform L2 bound, and the uniform L2 bound on \(g_{\delta_j}\) give, after a subsequence,
\[
 g_{\delta_j}\rightharpoonup g,\qquad
 \xi=f-g\in\partial_{L^2}E(w),\qquad
 0\le g\le\lambda,\quad \int g\le W,\quad\|g\|_2^2\le\lambda W.
 \tag{O15}
\]
Here \(\delta_jw_{\delta_j}\to0\) in L2. Passing the complementarity pairing using both strong limits gives \(g=\lambda\) almost everywhere on \(\Omega\).

### Actual flux, absence of boundary measures, and total mass

We use the static version of the genuine flux lemma proved in R98, whose short argument is included to state its exact scope. For \(\xi\in\partial_{L^2}E(w)\), let
\(\mathfrak F(p)=\int F(p)\) on \(L^2(\mathbb R^n;\mathbb R^n)\).
On the range of the H1 gradient map define
\(\mathcal L(\nabla h)=\langle\xi,h\rangle\).
This is well-defined: an H1 function on the whole space with zero gradient is an L2 constant and hence zero. The subgradient inequality implies
\(\mathcal L(q)\le D\mathfrak F(\nabla w;q)\).
The right side is a continuous sublinear function, bounded in magnitude by
\(n\|\nabla w\|_2\|q\|_2\). Dominated Hahn–Banach and Riesz give a vector field \(Z\in L^2\) with the same values on gradient fields and
\[
 \langle Z,q\rangle\le D\mathfrak F(\nabla w;q)
 \le\mathfrak F(\nabla w+q)-\mathfrak F(\nabla w).
\]
Localization to finite-measure sets and a countable dense family of vector perturbations gives \(Z(x)\in\partial F(\nabla w(x))\) almost everywhere. Equality on the original gradient range gives \(-\operatorname{div}Z=\xi=f-g\) against every compact smooth test. This is the complete distributional divergence, already known to be in L2 by (O15).

Finite-dimensional duality, \(F^*(z)=\|z\|_\infty^2/2\), gives
\[
 \|Z(x)\|_\infty=H(\nabla w(x)),\qquad
 Z(x)\cdot\nabla w(x)=H(\nabla w(x))^2,\qquad
 |Z(x)|_2\le\sqrt n\,H(\nabla w(x)).
 \tag{O16}
\]
In particular \(\partial F(0)=\{0\}\). The Sobolev zero-level-set property gives
\(\nabla w=0\) almost everywhere on \(\{w=0\}\), so \(Z=0\) there. Its support in the measurable sense has volume at most \(V\); Cauchy–Schwarz proves all flux bounds in (O5).

For mass, choose \(0\le\chi_R\le1\), equal to one on \(\{\|x\|_\infty\le R\}\), zero outside the doubled cube, increasing to one, with \(\|\nabla\chi_R(x)\|_1\le1/R\) almost everywhere. These compact Lipschitz functions are admissible in the L2 distributional identity, by H1 approximation. Then
\[
 \left|\int(g-f)\chi_R\right|
 =\left|\int Z\cdot\nabla\chi_R\right|
 \le \frac{\|\|Z\|_\infty\|_1}{R}\longrightarrow0.
\]
Since both \(g\) and \(f\) are integrable, this proves \(\int g=W\). No constant test function was inserted into an L2 equation.

### Contact density without an H(div) locality assumption

The needed contact conclusion is a sign statement, not the assertion that a divergence vanishes on every measurable zero set of its vector field. Let \(\varphi\ge0\) be smooth and compactly supported, and set
\(\psi_\varepsilon=\varphi(1-w/\varepsilon)_+\).
This is an admissible compact H1 test. By (O16),
\[
 \begin{aligned}
 \int(f-g)\psi_\varepsilon
 &=\int(1-w/\varepsilon)_+Z\cdot\nabla\varphi
   -\frac1\varepsilon\int_{\{0<w<\varepsilon\}}
                      \varphi H(\nabla w)^2\\
 &\le\int(1-w/\varepsilon)_+Z\cdot\nabla\varphi.
 \end{aligned}
 \tag{O17}
\]
The last term tends to zero by local integrability, dominated convergence, and \(Z=0\) on \(\{w=0\}\). The left side tends to
\(\int_{\{w=0\}}(f-g)\varphi\), since \(f-g\) is locally integrable. Thus \(f\le g\le\lambda\) almost everywhere on the contact set. We do not assert \(f=g\) there or infer arbitrary measurable-set locality of the divergence.

## Exact exterior-energy interface and its remaining fee

Let \(Q_L(x)\) be the centered cube of full side length \(L\), and
\(A_L f(x)=|Q_L|^{-1}\int_{Q_L(x)}f\).
For an energy threshold \(\kappa>0\), construct the obstacle at
\(\lambda=\kappa/2\), retaining the resulting cap fee
\[
 |\Omega|\le 2W/\kappa.
 \tag{O18}
\]
Define the genuine cube flux balance by the density integral
\[
 B_Q=-\int_Q\operatorname{div}Z=\int_Q(f-g).
\]
It is defined for every cube and does not assume classical pointwise normal traces on its faces. Since \(g\le\kappa/2\),
\[
 (A_Lf(x)-\kappa)_+
 \le\left(\frac{B_{Q_L(x)}}{|Q_L|}-\frac\kappa2\right)_+.
 \tag{O19}
\]
In particular, for the actual measurable receiver cap,
\[
 \begin{aligned}
 \mathcal E_\kappa(f;\Omega)
 &:=\int_{\Omega^c}\int_0^\infty
                (A_Lf(x)-\kappa)_+^2\,\frac{dL}{L}\,dx\\
 &\le\int_{\Omega^c}\int_0^\infty
       \left(\frac{B_{Q_L(x)}}{|Q_L|}-\frac\kappa2\right)_+^2
              \frac{dL}{L}\,dx .
 \end{aligned}
 \tag{O20}
\]
Both sides may be infinite. Every receiver indicator and the threshold margin remain present. The contact lemma additionally gives \(f\le\kappa/2\) almost everywhere outside the same cap, with no additional union-cap cost.

The missing quantitative assertion is a subpower bound for an appropriate full exterior positive-excess energy, possibly after a paid enlargement of this actual cap. The \(\|f\|_2\)-dependent flux bounds in (O5) do not supply it. A pure L1 input need not possess the finite-energy obstacle constructed here. To return a genuinely amplitude-free maximal theorem to all L1 inputs, one must first prove it uniformly for \(f_m=\min(f,m)1_{[-m,m]^n}\), then use \(M_\square f_m\uparrow M_\square f\). The present construction alone is not that maximal theorem and does not close the \(\sqrt n\,n^{o(1)}\) target.

状态：新增一般接口已给出自包含证明。目标仍是任意正 L1 输入的中心立方体弱常数 sqrt(n)n^{o(1)}，**未证明**。本稿不改 R99，也不调用已待证的极大算子界。所有积分在 R^n 上对真实 Lebesgue 测度进行。

## 1. 一手来源阅读与可迁移条件

|来源|本次实际阅读位置|条件与使用范围|
|---|---|---|
|[Gigli–Mosconi, The abstract Lewy–Stampacchia inequality and applications](https://cvgmt.sns.it/media/doc/paper/2344/LewyStampacchia-final.pdf)，作者原稿20页|PDF 第5页 Theorems 2.3–2.4，第6页完整证明，第7页 classical application；已逐页读取提取文本；截图调用仅返回引用，未提供可读像素，不登记截图复核|Theorem 2.4 要求拓扑向量格、凸且 submodular 能量、区间上的实际 minimizer，以及能量在可行点连续或相应 interior 条件。其结论对非光滑能量给**分别选取**的两个 subgradient 的一侧界，不能直接断言同一个选择同时满足上下界。|
|[Carlen–Lieb, A dual form of the sharp Nash inequality and its weighted generalization, arXiv:1703.09325v2](https://arxiv.org/pdf/1703.09325)|PDF 第2页 equations (1.2)–(1.3)，第5页 equation (2.1)；均已逐页读取提取文本；截图调用未提供可读像素，不登记截图复核|文中使用全空间 Nash 不等式，p=1,q=2, theta=n/(n+2)，包括 n=1,2。这里仅核验 Nash 的函数空间与指数；本稿下文另外给出含显式常数的 Fourier 证明，不依赖其 sharp-constant theorem。|

上述来源允许把问题放进格上的凸变分框架，但不提供任意 L1 的有限能量势、不提供子幂立方体费用，也不认证某个形式 Euler 通量。Nash 1958 原文链接本次获取超时，Carlen–Loss 1993 sharp-constant 页仅取得题录，因此二者没有登记为已阅读/已认证的定理来源。

## 2. 准确新命题

设 n>=1，f>=0 属于 L1(R^n)∩L2(R^n)，lambda>0，W=∫f，

F(p)=1/2 ||p||_1^2， E(u)=∫F(∇u)， X=H1(R^n)∩L1(R^n)，

X 取 Banach 范数 ||u||H1+||u||1。设 w∈X、w>=0 是

J(u)=E(u)+lambda∫u−∫fu

在 X_+ 上的实际 minimizer。那么存在一个 Z∈L2(R^n;R^n) 与 rho∈L∞(R^n)，满足

- Z(x)∈∂F(∇w(x)) a.e.；
- 0<=rho<=(lambda−f)_+、rho w=0 a.e.；
- −div Z+lambda−f=rho，在**全空间 distributions** 中成立；
- g:=lambda−rho=f+div Z 满足 min(f,lambda)<=g<=lambda a.e.；
- S={w>0} 满足 lambda |S|<=W，Z=0 a.e. 于 S^c，Z∈L1；
- g∈L1∩L2，∫g=W，g=lambda a.e. 于 S，f=g−div Z；
- C={w=0} 上 f<=g<=lambda a.e.，因此 {f>lambda}⊂S（模零集）。

这给同一个真实通量的两侧残差界；不需要 F 可微、严格凸、均匀 Hessian 椭圆性、光滑自由边界或紧支撑 f。**不声明零 delta minimizer 唯一，也不声明 div Z 自动在任意可测零集上消失。** g 的全局可积性和质量通过 cutoff 另证。

## 3. 非光滑能量的精确罚项

令 h=lambda−f，b=h_+，h_−=(f−lambda)_+。b∈L∞且0<=b<=lambda；h 定义 X 上连续线性泛函

ell_h(u)=lambda∫u−∫fu。

Sobolev 正负部分属于 X，并有梯度局部性：∇u^+=1_{u>0}∇u，∇u^−=−1_{u<0}∇u，∇u=0 a.e. 于 {u=0}。F 是偶函数且 F(0)=0，因此 E(u)=E(u^+)+E(u^−)。定义全 X 上连续凸泛函

K(u)=E(u)+ell_h(u)+P(u)， P(u)=∫b u^−。

对任意有符号 u∈X，直接分解得

K(u)=J(u^+)+E(u^−)+∫h_−u^− >= J(w)=K(w)。

所以 w 是 **无障碍** K 的 minimizer。这里只使用 w 对非负竞争函数的最小性，没有把空内点的 L2 正锥套进不合资格的 normal-cone sum rule。

## 4. 所需 continuous convex chain rule 的自包含证明

取 Y=L2(R^n;R^n)×L1(R^n)，T:X→Y，Tu=(∇u,u)。令

A(p,v)=Q(p)+P(v)，Q(p)=∫F(p)。

T 连续线性且单射。Q 有限连续凸；例如 |F(p)−F(q)|<=n/2 (|p|2+|q|2)|p−q|2 后用 Cauchy–Schwarz。P 有限凸且 L1-Lipschitz，常数<=lambda。因此 A 在整个 Y 上连续凸，局部 Lipschitz。

在 a=Tw，连续凸泛函的单侧方向导数 d(y)=A'(a;y) 是有限连续 sublinear 泛函。K 最小性给

−ell_h(u)<=d(Tu)，u∈X。

在 Ran T 上定义线性泛函 L(Tu)=−ell_h(u)。单射保证良定义；由 Hahn–Banach 的 sublinear domination 形式，将 L 延拓至 Y 上线性泛函 Ltilde，且 Ltilde(y)<=d(y)。对 y 和 −y 的 domination 及 d 的连续性保证 Ltilde 连续。由于 d(y)<=A(a+y)−A(a)，Ltilde∈∂A(a)。Y* 的标准 Lp 对偶表示给

Ltilde(p,v)=∫Z·p+∫p0 v，Z∈L2，p0∈L∞。

分别固定两个变量，得到 Z∈∂Q(∇w)，p0∈∂P(w)，并对每个 u∈X 有

∫Z·∇u+∫p0 u+lambda∫u−∫fu=0。 (S4)

这里 Hahn–Banach 本身是基础分离定理；整个复合 subgradient 步骤已经展开，无需另外把某本书中未核验的链式法则当证据。

## 5. 点态 subgradient、同一 rho 与无奇异残差

积分 subgradient 的点态化也可直接证明：在任意有界可测集合上作有界、常向量增量，若 F(q)−F(∇w)−Z·(q−∇w) 在正测度集合为负，则构造只在该集合变化的 L2 竞争向量，与 ∂Q 不等式矛盾。对 q∈Q^n 逐个使用，再以 F 连续性扩至所有 q，得到 Z∈∂F(∇w) a.e.。

同理 L1 局部竞争函数给 p0(x)∈∂[b(x)(·)^−](w(x))。由于 w>=0，

p0=0 于 {w>0}； −b<=p0<=0 于 {w=0}。

取 rho=−p0。把 compactly supported smooth test 代入 (S4) 得

−div Z+lambda−f=rho， 0<=rho<=b，rho w=0。

因此 g=lambda−rho 满足 min(f,lambda)<=g<=lambda，而 g=lambda 于 S。此恒等式是全空间 distributions 等式，其右侧是函数；不存在被丢掉的界面 Dirac 或其他 singular residual measure。虽然 rho 本身通常不属于全空间 L2（远离源的 rho 可能等于 lambda），但 div Z=g−f 后续会属于 L2。不要在得到 g 可积之前误称 rho 是 L2 乘子。

若 s=||p||1，则晶体 subgradient 具体为 z_i=s sign(p_i)（p_i非零）或 z_i∈[−s,s]（p_i=0）。特别地 ∂F(0)={0}，z·p=s²，||z||∞=s（p非零），|z|2<=sqrt(n)s<=n|p|2。因此 Z=0 a.e. 于 {∇w=0}，尤其于 S^c。这是 a.e. 支持声明，不需要 S 光滑或开。

## 6. 有限帽、L1 通量和全质量

对 epsilon>0，phi_epsilon=min(w/epsilon,1) 属于 X；其 L1 性由 phi<=w/epsilon，其 L2 与 H1 性由截断链式法则。代入 (S4)，rho phi=0，得到

lambda∫phi_epsilon=∫f phi_epsilon−(1/epsilon)∫_{0<w<epsilon}||∇w||1²<=W。

epsilon↓0，单调收敛给 lambda|S|<=W。故

||Z||1<=|S|^(1/2)||Z||2<=sqrt(n)|S|^(1/2)|| ||∇w||1 ||2。

选 smooth radial cutoff chi_R(x)=chi(x/R)，0<=chi<=1，chi=1 于 B1、0 于 B2，径向非增。chi_R↑1，||∇chi_R||∞<=C/R。distribution 等式给

∫g chi_R=∫f chi_R−∫Z·∇chi_R。

g>=0，右侧<=W+C||Z||1/R；monotone convergence 先得 g∈L1，再取极限得 ∫g=W。因0<=g<=lambda，||g||2²<=lambda W。因此 div Z=g−f∈L2。整个步骤不依赖“div 在可测零集为零”。

## 7. 零 delta 存在性的显式 support-Poincare 与极限

R99 已有 delta>0 的 J_delta=J+delta/2||u||2² minimizer w_delta>=0，以及 |{w_delta>0}|<=V=W/lambda。这里只说明其零 delta 紧性；W=0 时可直接取 w=0，Z=0，g=0。

任意 u∈H1∩L1，其 a.e. 非零集合的体积<=V，令 v_n 为 Euclidean 单位球体积，采用 Fourier 约定 uhat(xi)=∫exp(−i x·xi)u(x)dx。Plancherel 与 ||uhat||∞<=||u||1 给，对任意 R>0，

||u||2² <= (2pi)^(-n)v_n R^n ||u||1²+R^(-2)||∇u||2²。

又 ||u||1²<=V||u||2²。取 R^n=[2(2pi)^(-n)v_n V]^(-1)，得到

||u||2 <= C_n V^(1/n)||∇u||2，
C_n=sqrt(2)[2v_n/(2pi)^n]^(1/n)。 (S7)

这是所有 n>=1 的 finite-support Poincare，不需要 bounded/open support，不调用 Faber–Krahn 的 Dirichlet domain 正则性。上述 Fourier splitting 是独立证明；不是将某个只对 n>=3 的 Sobolev inequality 默默用于 n=1,2。

令 A=C_n V^(1/n)。J_delta(w_delta)<=0 及 F>=1/2|p|2² 给

1/2||∇w_delta||2²+lambda||w_delta||1+(delta/2)||w_delta||2²<=||f||2||w_delta||2<=A||f||2||∇w_delta||2。

所以 ||∇w_delta||2<=2A||f||2，||w_delta||2<=2A²||f||2，lambda||w_delta||1<=2A²||f||2²。这些为固定 n,f,lambda 的一致界，**不是**要免费带入后续子幂预算的常数。

取 delta_j↓0，H1 弱紧性和局部 Rellich 逐球对角子列给 w_delta_j ⇀ w 于 H1，且 a.e. 收敛。w>=0，Fatou 给 w∈L1，|{w>0}|<=V。凸梯度能量弱下半连续，f∈L2 给 ∫f w_delta_j→∫fw，非负 L1 项用 Fatou。对任意 v∈X_+，

J(w)<=liminf J_delta_j(w_delta_j)<=limsup J_delta_j(w_delta_j)<=lim J_delta_j(v)=J(v)。

因此 w 是零 delta 实际 minimizer，前述同一 Z/rho/g 分解可用。这里不以任意 L1 的 L2 近似强行定义有限能量 w；一般正 L1 的最终极大弱界仍应在证明出一致弱界后，通过原算子的单调输入截断回代。

## 8. 接触集密度：依赖真实能量符号的新增界

准确新增命题：在上文实际通量分解的同一假设下，C={w=0} 上有 f<=g<=lambda a.e.，因此 {f>lambda} 包含于 S（模零集）。**不升级成 C 上 g=f，也不引用任意 H(div) 向量场的可测零集局部性。**

取任意非负 phi∈C_c^infty，令 a_epsilon=(1−w/epsilon)_+，psi_epsilon=phi a_epsilon。虽然 a_epsilon 本身在全空间可能不属于 L1/L2，psi_epsilon 有紧支撑且属于 X，所以可合法代入 (S4)。rho/g 恒等式与 Sobolev 截断给

∫(f−g)phi a_epsilon
=∫a_epsilon Z·∇phi−(1/epsilon)∫_{0<w<epsilon}phi Z·∇w
=∫a_epsilon Z·∇phi−(1/epsilon)∫_{0<w<epsilon}phi ||∇w||1²
<=∫a_epsilon Z·∇phi。

a_epsilon→1_C a.e.，0<=a_epsilon<=1。右侧由 Z∈L2 和 compact support 的 dominated convergence 趋于 ∫_C Z·∇phi=0。左侧由 f−g∈L2 和 compact support 的 dominated convergence 趋于 ∫_C(f−g)phi。因此 ∫_C(f−g)phi<=0 对所有非负 smooth compact phi 成立，得 f<=g a.e. 于 C，而已有 g<=lambda。这正是帽外背景密度所需界，不证明 divergence 在 C 上为零。

## 9. 维数费用及真正剩余缺口

本稿给出的实际接口：f=g−div Z，0<=g<=lambda，∫g=W，Z∈L1∩L2 且支持于真实变分帽 S，lambda|S|<=W。对晶体通量还能记录 ||Z||∞,pointwise=||∇w||1、Z·∇w=||∇w||1²；Euclidean L2 bound 带 sqrt(n)。

这不是全尺度帽外立方体正超额预算。尤其 L2(f) 控制与存在性常数 C_n V^(1/n) 不产生对全部正 L1 输入统一的子幂能量，不许可删 threshold margin、尺度门或重复费用，也不把 g 的帽称 R99 的 OT 压力帽。将 divergence 写成每个立方体的边界通量还需合法 trace/对几乎所有边长的 Fubini 论证；帽外通量能量的维数预算是继续研究的新缺口。

## 1. Scope and the actual obstacle dependency

The general sqrt(n)n^{o(1)} weak bound remains OPEN. This round proves exterior-energy interfaces for the actual crystalline-energy obstacle, distinguishes its cap from an optimal-transport cap, and identifies a paid receiver cap that repairs the new pressure family. The untrimmed occupation product does not provide a general improvement. The private proofs establish the precise limitations and do not lower-bound the maximal weak constant or rule out arbitrary cap selections.

Fix n≥2, κ>0, and nonnegative f∈L1∩L2(R^n), with W=∫f>0. Use the full-side convention

$$
Q(x,L)=x+[-L/2,L/2]^n,\quad A_Lf(x)=L^{-n}\int_{Q(x,L)}f,\qquad
E_\kappa(f;U)=\int_{U^c}\int_0^\infty(A_Lf(x)-\kappa)_+^2\,\frac{dL}{L}\,dx. \tag{1}
$$

The nonlinear role owns the zero-regularization obstacle theorem for the local energy F(ξ)=||ξ||1²/2. We use its following exact conclusion at height λ=κ/2:

$$
w\ge0,\quad w\in H^1\cap L^1,\quad \Omega=\{w>0\},\quad |\Omega|\le W/\lambda,
\qquad Z\in\partial F(\nabla w),\quad f=g-\operatorname{div}Z,
\quad 0\le g\le\lambda,\quad\int g=W. \tag{2}
$$

Here Z∈L2, div Z∈L2, Z=0 almost everywhere on {w=0}, and Z·∇w=||∇w||1² almost everywhere. The set Ω is measurable; no open representative or classical face trace is assumed. The same-round nonlinear module proves this theorem by its zero-damping construction, bounded Huber penalty, actual L2 subgradient graph, and whole-space mass settlement. This author has read that complete proof, including the contact sign test; its review receipts are recorded below. The explicit private examples also independently verify their own actual obstacle identities. We never infer (2) from the R99 OT pressure, and never define a finite-energy obstacle for arbitrary L1 data without the stated hypotheses.

## 2. The contact-density lemma and actual cube flux

An additional argument, not generic divergence locality, establishes the needed bounded background. For φ≥0 smooth with compact support and ε>0, take ψε=φ(1−w/ε)+. It is a compactly supported H1 test. Testing the actual distributional identity f−g=−div Z gives

$$
\int(f-g)\phi(1-w/\varepsilon)_+
=\int(1-w/\varepsilon)_+Z\cdot\nabla\phi
-\varepsilon^{-1}\int_{\{0<w<\varepsilon\}}\phi\|\nabla w\|_1^2
\le\int(1-w/\varepsilon)_+Z\cdot\nabla\phi. \tag{3}
$$

The last integral tends to zero by dominated convergence and Z=0 on contact. The left tends to ∫_{w=0}(f−g)φ. Hence f≤g≤λ almost everywhere on Ωc. No equality f=g on this possibly nonopen set, nor locality of div Z for arbitrary measurable zero sets, has been assumed.

Put F_L(x)=∫_{Q(x,L)}(f−g). Then

$$
(A_Lf-\kappa)_+\le\left(L^{-n}F_L-\kappa/2\right)_+. \tag{4}
$$

For almost every (x,L), the distributional cube flux is the signed sum of translated face integrals:

$$
F_L(x)=-\sum_{j=1}^n\left[\int_{[-L/2,L/2]^{n-1}}Z_j(x+\tfrac L2e_j+t)\,dt
-\int_{[-L/2,L/2]^{n-1}}Z_j(x-\tfrac L2e_j+t)\,dt\right]. \tag{5}
$$

In each face integral t has zero j-th coordinate. A rigorous justification uses mollification: the identity is classical for smooth Z; convolution of div Z converges locally in L2, and the translated surface integrals converge in local L2(dx dL) on scale windows bounded away from zero by Fubini and Cauchy–Schwarz. A subsequence on countably many compact receiver/scale windows passes the identity almost everywhere. Thus no unproved classical normal trace of the original field is invoked.

Let h(y)=dist∞(y,Ωc). Face Cauchy–Schwarz yields |L^−n F_L|²≤2nL^−n−1 times the sum of the integrals of |Z_j|² on the 2n faces. If a face point y and receiver x∉Ω occur, then h(y)≤L/2. For fixed y,L and a fixed face sign, the allowed other coordinates of x have volume at most L^{n−1}. Tonelli and ∫_{2h}^∞L^−3dL=1/(8h²) give the general estimate

$$
E_\kappa(f;\Omega)\le\frac n2\int_\Omega\frac{|Z(y)|_2^2}{h(y)^2}\,dy. \tag{6}
$$

This is an extended-value statement. At h=0 the quotient is infinite if Z≠0, and is assigned zero if Z=0. The right side need not be finite, much less bounded by a favorable multiple of κW. The private fixed-dimension test shows why this discarded-sign and discarded-threshold budget cannot be used as an L1 payment.

## 3. A general receiver cap retaining the actual threshold

The contact lemma permits a different interface. Set μ=f1Ω and b=f1Ωc; then b≤κ/2. Let β=1+1/(2n), so β^−n≥e^−1/2>1/2, and define fields with the actual SAME-f receiver tests

$$
N_0(x,L)=A_L\mu(x)\,\mathbf1_{\{A_Lf(x)>\kappa\}},\qquad
N_1(x,L)=A_L\mu(x)\,\mathbf1_{\{A_Lf(x)>\kappa\beta^{-n}\}},
\qquad H(x)=\int_0^\infty N_1(x,L)\,\frac{dL}{L}. \tag{7}
$$

The relaxed threshold still exceeds the bounded contact background. In particular the background has not been introduced into an untruncated all-scale occupation. Define exact exterior first moments, allowing infinity,

$$
P=\int_{\Omega^c}\int_0^\infty N_0(x,L)\,\frac{dL}{L}\,dx,\qquad
Q=\int_{\Omega^c}H(x)\,dx. \tag{8}
$$

They have units of source mass. These definitions are not assertions of a small or finite general budget. On an active receiver, (A_Lf−κ)+≤A_Lμ, by the bounded background, and on an inactive receiver the excess vanishes. If u∈[L,βL], nested cubes give A_uf≥(L/u)^n A_Lf and A_uμ≥(L/u)^n A_Lμ. The relaxed test therefore persists, giving

$$
(A_Lf-\kappa)_+^2\le N_0(x,L)^2,\qquad
N_0(x,L)\le c_{n,\beta}H(x),\quad
c_{n,\beta}=\frac n{1-\beta^{-n}}\le4n. \tag{9}
$$

The last constant follows from n log β≥2/5 and 1−e^−2/5>1/4. When 0<Q<∞, the ONE additional receiver cap

$$
U=\Omega\cup\{x\in\Omega^c:H(x)>\kappa Q/W\}
\quad\text{satisfies}\quad |U|\le3W/\kappa,
\qquad E_\kappa(f;U)\le c_{n,\beta}\kappa\frac{PQ}{W}. \tag{10}
$$

Chebyshev charges W/κ once, and (9) pays the energy. If P=0, the energy outside Ω is already zero, even if Q is infinite; Q=0 implies P=0. Infinite Q provides no finite cap certificate by this formula. There is no dimension-free bound for c_{n,β}.

For reference, a source-depth upper proxy follows from the true mass cutoff, without a transport displacement window. Put Rm=(W/κ)^{1/n}. An active N0 scale is less than Rm, and an active N1 scale less than βRm. A source at y captured from an exterior center must have L≥2h(y). Exterior receiver volume is at most L^n. Hence

$$
P\le\int_\Omega f(y)\log_+\frac{R_m}{2h(y)}\,dy,\qquad
Q\le\int_\Omega f(y)\log_+\frac{\beta R_m}{2h(y)}\,dy. \tag{11}
$$

These are only upper proxies; they can be infinite. They preserve the one fixed cap and the actual source density, not a reference source. They do not assert that globally aggregating many separated sources is efficient.

## 4. The precise retained-distribution budget

The useful bound before replacing everything by P is sharper. For a height T>0, define

$$
P(T)=\int_{\{x\in\Omega^c:H(x)\le T\}}\int_0^\infty N_0(x,L)\,\frac{dL}{L}\,dx,
\qquad U_T=\Omega\cup\{x\in\Omega^c:H(x)>T\}. \tag{12}
$$

The same proof, with nonnegative integrals, gives

$$
|U_T|\le2W/\kappa+|\{x\in\Omega^c:H(x)>T\}|,
\qquad E_\kappa(f;U_T)\le c_{n,\beta}T P(T). \tag{13}
$$

This retains the very receivers that remain after deletion. The missing GENERAL payment is a choice of T for the SAME input and threshold satisfying a subpower bound for κ|{H>T}|/W and for c_{n,β}T P(T)/(κW), or another directly proved energy bound with those actual receiver indicators. Formula (13) is a sufficient interface, not a proof of this tradeoff. The private broad-source argument shows that replacing P(T) by the untrimmed P can retain a full order-n coefficient. It does not prove that the actual retained energy has that size.

## 5. Paid fallback and all-input scope

A finite unconditional fallback is available without identifying unrelated caps. For this regular f, let V be the R99 OT-plus-height cap: |V|≤3W/κ and Eκ(f;V)≤c_nκW log(4n)log(8n), where c_n=n/(1−2^−n). Its construction applies to all positive L1 inputs. Adjoin the current obstacle cap and pay the union:

$$
|\Omega\cup V|\le5W/\kappa,\qquad
E_\kappa(f;\Omega\cup V)\le c_n\kappa W\log(4n)\log(8n). \tag{14}
$$

These caps need not coincide. This is a fallback with its exact fee, not new dimensional progress. The retained R98 return C_n≤4A+8sqrt(nAB/log2) supplies

$$
C_n\le20+8\sqrt{\frac{5n c_n\log(4n)\log(8n)}{\log2}}=O(n\log n). \tag{15}
$$

To transfer any genuinely improved uniform weak estimate proved on regular inputs, use f_m=min(f,m)1_{[-m,m]^n} increasing to f. The original centered maximal functions increase pointwise, and their superlevel sets increase; monotone convergence passes the SAME weak constant. This does not construct a finite-energy obstacle for the untruncated input. Formula (15) is already known in order and is not the desired root estimate.

## 6. Evidence and review receipts

Both auditors received the actual contact test, face estimate, receiver-cap propositions, and private pressure statements before manuscript proof. The numerical role owns the three actual stages on genuine positive-L1 inputs and actual continuous receiver volumes. The three numerical stages are complete. Actual zero-energy certificates, nonzero lower certificates, and theorem-dependent paid-cap upper proxies are recorded separately in the private ledger. Both independent auditors have completed full dual-format review of the nonlinear dependency, including the actual flux and contact lemma: PASS. Astra and the independent Sol successor have completed full coverage Markdown and matching-TeX proof review, including equations (1)–(32) and the private proofs: PASS. This author has not executed the numerical program or claimed an independent numerical reconstruction. All quantitative pressure recipes and method-specific lower conclusions are retained in local private material and excluded from the public archive.

## 1. Outcome and exact residual

This round identifies a limitation of a broad common-profile envelope method on the actual R99 residual. It does not prove a lower bound for original selected columns, optimal Hall capacity or the cube maximal norm. A new positive-density physical family is qualified privately on whole positive-volume receiver cubes with the original first contact and all specified gates within the stated packet-parameter domain. On that family, the actual captured posterior is nearly uniform, while the complete local contact event has a cheap original-capture allocation. Thus the loss belongs to the unrestricted envelope relaxation, and actual receiver volume cannot be discarded.

Let `mu=f dy>=0`, `W=||f||1`, `lambda>0`, `Q(x,L)=x+[-L/2,L/2]^n`. The current event is EXACTLY the original `F2` from R99: the same input, threshold and measurable earliest `L_x in [1,2]`,
\[
 L_x^{-n}\mu(Q(x,L_x))=\lambda,                                    \tag{1}
\]
with the original anchor, all-window P1, middle, selected-coarse, packet and physical gates, followed by the already-paid unit and mesh deletions. At `T=sqrt(n)`, `N=ceil(sqrt(n))`, `r_j=2^(j/N)`, it retains
\[
 A_1f<\lambda/T,\qquad A_{r_j}f<\lambda/2\quad(r_j\le L_x),          \tag{2}
\]
where the old strict unit anchor handles `j=0`. With `r_-(x)` the strict predecessor, more than half of the hard captured law
\[
 d\pi_x(y)=\frac{1_{Q(x,L_x)}(y)d\mu(y)}{\lambda L_x^n}               \tag{3}
\]
is in `Q(x,L_x)\Q(x,r_-(x))`. The relative shell width is at most `log(2)/N`. None of those facts alone pays a root column; the unrestricted moving-shell envelope has mass `n log(2)`.

At the same selected radius put `F=Phi_1((x-y)/L_x)`, `G=Phi_theta((x-y)/L_x)`, with `theta=log^-2(n+2)`, `alpha=[10log(n+2)]^-1`. The retained captured-middle and coarse conditions are
\[
 E_{\pi_x}F>b_n,\qquad E_{\pi_x}G<\alpha.                            \tag{4}
\]
Their R99 score deficit may be nonpositive. No whole-window coarse gate, changed source or different root is substituted here.

## 2. A general radial bookkeeping theorem

This theorem concerns a COMMON spatial profile, not a receiver-dependent allocation. Let `Q1=[-1/2,1/2]^n`, let `k:Q1->[0,A]` be Borel measurable with finite `A>0`, extend it by zero, and set
\[
 c=\int_{Q1}k(z)dz,\qquad
 B_k=\int_{\mathbb R^n}\mathop{\rm ess\,sup}_{1\le L\le2}
                      L^{-n}k(v/L)\,dv.                            \tag{5}
\]
The essential supremum is over Lebesgue scale measure. It is a measurable relaxation: it does not encode any source, first contact or joint gate.

Let `omega` have the normalized cubical cone measure on `boundary Q1`; equivalently radial integration is
`dz=n r^(n-1)dr d sigma(omega)`, `0<r<1`. For almost every direction define
\[
 m(\omega)=\mathop{\rm ess\,sup}_{0<r<1}r^n k(r\omega),\qquad
 \bar m=\int m\,d\sigma,\qquad
 \psi_A(s)=s[1+\log(A/s)],\quad\psi_A(0)=0.                          \tag{6}
\]
Then
\[
 c\le\int\psi_A(m)d\sigma\le\psi_A(\bar m),\qquad
 B_k\ge n\log2\,\bar m.                                           \tag{7}
\]
If `c>0`, an explicit consequence is
\[
 \bar m\ge\frac{c}{2[1+\log(A/c)]},\qquad
 B_k\ge\frac{n\log2\,c}{2[1+\log(A/c)]}.                           \tag{8}
\]
These are exact relations between the retained profile mass, amplitude and its universal dilation envelope. They do not give the reverse comparison from an envelope to actual selected-column necessity.

Proof. By the definition of the radial essential supremum,
`k(r omega)<=min(A,m(omega)/r^n)` for almost every radial point. Integrating and splitting at `(m/A)^(1/n)` gives exactly `psi_A(m)`. The function `psi_A` is increasing and concave on `[0,A]`, with second derivative `-1/s`, so Jensen gives the first part of (7).

For the envelope bound, fix almost every direction and a positive epsilon below `m`. The set of radii where `r^n k(r omega)>m-epsilon` has positive measure. Choose a density point `r0` of that set. For every `t` strictly between `r0` and `2r0`, its intersection with `(t/2,t)` has positive measure; under `L=t/r` this gives positive-measure admissible scales. Thus the scale essential supremum at `t omega` is at least `(m-epsilon)t^-n`. Cubical radial integration over `(r0,2r0)` yields `n log(2)(m-epsilon)`. Let epsilon decrease to zero, then integrate directions by Tonelli. This argument uses positive-measure near-maximizers rather than a value on one exceptional radius. Directions with `m=0` contribute zero.

Finally put `u=1+log(A/c)>=1`. Since `log(2u)<=u`,
`psi_A(c/(2u))=c[u+log(2u)]/(2u)<=c`. Monotonicity of `psi_A` and (7) give (8). The bounded profile also gives `B_k<=A H_n` by the full hard window envelope, so these quantities are finite.

## 3. What the theorem does and does not test

For a common extraction profile `k`, a row-mass guarantee `E_pi k>=delta>0` permits the original-capture allocation
\[
 a_x(y)=\frac{L_x^{-n}1_{Q(x,L_x)}(y)k((x-y)/L_x)}{E_{\pi_x}k}.       \tag{9}
\]
Its row integral against the SAME `mu` is `lambda`, and its support is the original graph. If a pointwise scale supremum, or an otherwise justified majorant on the actual selected scales, has integral `C_k`, then every source column is at most `C_k/delta`, simultaneously for every measurable receiver cut. The essential-supremum expression (5) agrees with that pointwise envelope almost everywhere in the receiver variable for continuous profiles, but for an arbitrary measurable profile it is NOT automatically a majorant at an exceptional selected scale. We use (5) as a lower diagnostic for any pointwise envelope, which is at least as large. This distinction prevents a measurable exceptional-scale shortcut.

The new private qualification shows why the current joint gates do not force every useful common profile to have a small universal envelope at modest amplitude and normalization cost. The quantified method-pressure conclusion is private. Crucially, this does not refute (9) at the actual receivers: its true column integrates the actual receiver set, not all of space with freely selected scales. Receiver-dependent/source-adapted redistribution is also outside the common-profile theorem. No posterior independence is used.

A02 was reread for the direction of this relaxation. The original selected graph maps into a larger scale envelope, giving an upper certificate when a valid pointwise majorant is used. A large value of that relaxed certificate is not a lower bound for the original selected columns. D01's model is a static positive plan; no vector transport, stochastic path law or strong-duality existence theorem is invoked.

## 4. Full retained payments, cuts and terminal

For a measurable receiver cut `B`, use the essential neighborhood
`N_B={y:integral_B 1_Q(x,L_x)(y)dx>0}`. Every explicit feasible plan above has row mass `lambda` and stays inside this neighborhood. A verified common column bound `C` would imply `lambda|B|<=C mu(N_B)` by Tonelli. No such new uniform root `C` on all `F2` is claimed.

Retain the frozen constants
\[
\begin{gathered}
H_n=1+n\log2,\quad C_{\rm ext}=2H_n/\sqrt{n+2},\\
B_{\rm base}=4+2(\log2)\sqrt{7n/3},\quad
T_{\rm soft}=1+(\log2)\min\{2n,\sqrt{n(\theta^{-1}+4\theta/3)}\},\\
a_0=n^{-p_0},\quad\rho_0=n^{-1/2},\quad
P_{\rm dom}=(5+3\log(1/a_0))/\rho_0,\\
h_*=(16n^{3/2})^{-1},\quad E_*=e^{nh_*},\quad
B_*=1+E_*[1+(2n^2+n)h_*],\\
P_{\rm phys}=2[E_*+B_*+2(1+E_*)\sqrt n],\\
A_{\rm old}=B_{\rm base}+C_{\rm ext}+T_{\rm soft}/\alpha
                      +P_{\rm dom}+P_{\rm phys}.
\end{gathered}
\]
The physical union is charged once. The separately paid captured-low branch adds another `C_ext`. The unit and mesh common cores add `T+2N`. Thus
\[
 \lambda|E_{\rm initial}|
 \le(A_{\rm old}+C_{\rm ext}+T+2N)W+\lambda|F_2|.                    \tag{10}
\]
The canonical `H_n W` terminal fallback and the R99 outer `2n log(2)W` fallback are both retained; their minimum may be used. The present theorem does not replace that term with a root estimate. Optional full-window coarse and near-anchor-scale deletions, if used, still add `T_soft/alpha` and `1+n log(1+1/sqrt(n))`; no such new deletion is used here.

There is no recursive input change in this round. If a future proof reuses any branch on `mu_i`, threshold `lambda_i`, its original-threshold price includes `t_i=lambda_0/lambda_i` and the actual source mass `W_i`. In particular, repeated R99 payments remain `sum_i t_i(T_i+2N_i)W_i`, plus fresh classification costs and an unfinished terminal demand, bounded if needed by `t_m H_n W_m`. No summability or gate inheritance is proved. An empty receiver terminal is zero even when source mass remains. The original all-scale return retains its `O(log(n+2))` multiplier and any separate strength layering retains `J_n=O(log n)` with actual overlaps.

The general original joint-gated common-column problem remains OPEN. The new conclusion is a sharply scoped, physically qualified failure of a common-envelope inference, together with an actual common-column payment of the test source. It is not another nongated transfer example and not a general weak lower bound.

本轮检验对象是实际晶体变分障碍及其帽，直接核验真实次梯度场、全空间变分不等式、源质量与边界通量。它与上轮最优运输帽不同；未把旧帽或有限网格优化器移作实际障碍。

同一来源的外部立方体平均与超额能量以真实 Lebesgue 体积和有理尺度窗口作证书。另行列出收费非径向修复的解析上界代理；这些代理不是已计算的占用量、帽形状或实际能量积分。原帽的压力不能被解读成所有收费帽的失败。

具体输入配方、程序、量化压力和反例数据目前全部为 PRIVATE，仅本地保留。未认证原联合 Fnew 门、未执行 PDE 数值求解、未拟合一般维度指数，也未给一般弱型上界或下界。总体目标仍 OPEN。

A new nonradial fixture verifies an actual continuous crystalline flux, its bounded source decomposition, and the zero-regularization obstacle inequality. The certificate includes every interface trace and exact continuum source integral. A contrasting facet choice creates a singular interface contribution: its off-interface Euler formula cannot be used as a bounded-density decomposition.

This is a finite family of valid obstacle inputs and a precise constraint failure for the contrasting choice, not a proof of a general maximal or energy theorem. The original jointly gated receiver experiment belongs to the adaptive module and was not duplicated here. No prior fixed-source payment or selected-high classification is counted as new evidence.

The four theoretical Markdown modules and their detailed matching TeX were independently read in full after statement-first checks. The numerical reports and complete producer programs were separately reviewed. The audit distinguishes general proofs, conditional energy interfaces, qualified physical tests, and finite arithmetic certificates.

The zero-regularization obstacle and bounded-density flux decomposition are proved for nonnegative inputs in L1 intersect L2. Both the approximation proof and the exact-penalty proof retain their functional-analytic domains. The flux is an actual measurable field with the required global distributional equation; interface measures are not discarded. The contact-density conclusion is obtained by an admissible truncation test, not by assuming divergence locality on a measurable zero set. Existence estimates retain their L2 dependence and do not supply the desired mass-only exterior-energy budget for arbitrary L1 input.

The exterior-energy argument retains the obstacle-height margin, a single cap for all scales, true receiver measure, and the charge for an added receiver cap. The finite-moment interface and its trimmed version are valid with their stated hypotheses; a uniformly sufficient general moment or trimmed-energy estimate remains unproved. Bounds for distinct caps are kept separate. A vanishing finite-window lower certificate is not classified as zero energy unless an independent all-scale upper argument proves it.

The original joint-gated common-column route retains the same source, threshold, earliest selector, all original gates, and the previously paid deletions. The common-profile theorem concerns an unrestricted scale envelope. Its essential-supremum qualification is explicit, and its limitations are not turned into lower bounds for actual selected columns or optimal Hall capacity. Actual receiver volume and the corresponding same-source allocation remain part of the accounting.

Three separately owned producers were reproduced from isolated temporary copies. The standalone energy producer matched its saved JSON byte for byte; the flux producer matched all mathematical and descriptive JSON fields after removing only its declared timing fields; the embedded profile producer completed its exact assertions. These are independent executions of author programs, not new source experiments, an independent reconstruction of those algorithms, or a numerical proof of the general theorems. The energy-repair proxy quantities are not reported as measured occupations, reconstructed caps, or computed PDE solutions. Primary-paper readings belong to the source author; this audit does not claim to have independently reread them.

The all-input, all-scale target remains OPEN. General proofs and evidence scopes pass this module-level review; final assembled extraction, privacy, inventory, and archive consistency require a separate integration receipt. Specific private constructions, quantified method-pressure outcomes, and local execution details are excluded from this public audit.

R100's independent Sol audit is complete with PASS for the stated mathematical and certificate scopes. The general zero-damping obstacle and simultaneous actual bounded-density/flux decompositions apply to nonnegative L1 intersect L2 inputs; source amplitude remains in existence bounds. The contact conclusion is the proved inequality f<=g, and the full distributional flux excludes omitted interface measures. Coverage retains its threshold margin and actual receiver deletion; adaptive retains its original joint gates, common-source cuts, packet domain, receiver volume and return fees. The general energy and common-column budgets remain unpaid.

Standalone certificate replays passed, and one distinct continuum guard checks an actual nonradial obstacle with all interface traces and exact whole-space integrals. These finite checks do not prove an all-input endpoint estimate. The audit's chronological private ledger distinguishes predecessor proof/source reads, successor reviews and actual executions; inherited or other-auditor receipts are not counted as successor work. The arbitrary-positive-L1, all-scale centered-cube root-order target remains OPEN.

## 实际检验、复现与证据范围

本轮有三条互不重复的私有证据链。能量程序使用15个真实有界紧支撑正 L1 输入，逐一核验实际障碍、同源收费帽、真实接收积分和有理尺度窗口；45个帽、352个子区间不是新增来源。非径向通量程序使用3个不同真实输入，在全部连续分片和界面上做精确多项式积分及通量检查。原联合门程序使用另外3个输入，以81项有理/对数充分条件支持解析的整盒资格证明，未用有限接收采样代替整盒证明。各自均有初探、已知压力、扩大范围三个阶段。

主代理实际读取数学论证与程序后，隔离复制并执行了三项复现：能量程序外部耗时2.619647875秒；非径向通量程序0.084222833秒；原联合门嵌入程序3.827153834秒。前两项全部数学及描述字段与保存输出完全相等，仅通量输出忽略其计时字段；能量输出不含运行计时，其数值内容精确重现。第三项在相同3个来源上通过27/27/27项检查，共81项。所有执行exit0、stderr为空；这些复现不是新来源、新随机样本或另一独立能量算法。

非径向删帽的上界代理依赖已证明的一般覆盖接口；它们不是已计算的真实 P/Q、帽形状或完整能量。有限窗口的零下界不等于实际能量零。原联合门程序核验的是解析整盒证明所用的充分不等式，不是对极大算子的数值积分。私人配方、程序、输出及未发表量化压力不进入 GitHub 归档。

另有独立公开守卫，内嵌在报告末尾，可提取为 guard.py 后用 Python3 标准库运行。它重建一个新的不对称实际零阻尼障碍与真实密度，核验连续通量、全部界面及十个全空间连续积分。它的来源数为1；不是通用障碍存在性或一般极大弱界的数值证明。主代理实际阅读全文后，隔离复制执行通过，外部耗时0.027501041秒，exit0、stderr为空。源代码 SHA-256 为 c2520f252e0cff5f37c40d4880e8b13cc7ea2b5b96afd6f8258e0baf895d47f4。九个连续矩形全部积分，质量256、散度积分0、晶体梯度平方积分7932/875、源与势的配对97532/875；其余六个积分完整列于程序输出。再次提取归档执行只计为复现，不增加来源数。

更新后的64项数学技能按当前安装文件核对，清单和哈希仅用于定位版本。实际阅读与使用的相关工具及一手定理条件在各模块中逐项说明；未把“64项存在”或材料哈希当作64项数学验收。主代理本轮另外核对 N04 的误差部分和条件，以限制尚未证明的递归回代。原始论文阅读范围与未获取文献均由来源模块如实登记。

详细 LaTeX 只做静态检查，不编译 PDF。一般 sqrt(n)n^{o(1)} 上界仍未证明。公开归档中逻辑模块名指合并报告的章节，不是要求额外下载同名文件。


## 独立公开审核程序

```python
"""One independent actual nonradial continuum obstacle certificate.

Standard-library Fraction arithmetic integrates all nine polynomial rectangles.
No producer imports, saved outputs, discretized receivers, or prior-round tests.
The cubic source is a positive reconstruction, not a private lower-bound recipe.
"""
from fractions import Fraction as Q
import json


def add(*ps):
    out = {}
    for p in ps:
        for k, v in p.items():
            out[k] = out.get(k, Q(0)) + v
    return {k: v for k, v in out.items() if v}


def scale(p, c):
    return {k: v*c for k, v in p.items() if v*c}


def mul(p, q):
    out = {}
    for (i, j), a in p.items():
        for (k, l), b in q.items():
            out[i+k, j+l] = out.get((i+k, j+l), Q(0)) + a*b
    return {k: v for k, v in out.items() if v}


def deriv(p, axis):
    out = {}
    for ij, a in p.items():
        ij = list(ij)
        n = ij[axis]
        if n:
            ij[axis] -= 1
            out[tuple(ij)] = n*a
    return out


def face(p, axis, t):
    out = {}
    for ij, a in p.items():
        k = ij[1-axis]
        out[k] = out.get(k, Q(0)) + a*t**ij[axis]
    return {k: v for k, v in out.items() if v}


def integral(p, box):
    (a, b), (c, d) = box
    return sum((v*(b**(i+1)-a**(i+1))/(i+1)
                *(d**(j+1)-c**(j+1))/(j+1)
                for (i, j), v in p.items()), Q(0))


ONE = {(0, 0): Q(1)}


def coordinate(e, side, axis):
    t = {(1, 0) if axis == 0 else (0, 1): Q(1)}
    if side == 0:
        return ONE, scale(t, -1/e), Q(0)
    s = scale(add(scale(t, side), scale(ONE, -e)), 1/(1-e))
    # u=(1-s)^2(1+2s), so 0<=u<=1 on the entire wing.
    u = add(ONE, scale(mul(s, s), -3), scale(mul(mul(s, s), s), 2))
    return u, scale(ONE, -side), Q(-side)


def run():
    e = [Q(1, 3), Q(1, 5)]
    edges = [[Q(-1), -t, t, Q(1)] for t in e]
    cells = {}
    totals = {k: Q(0) for k in ('w', 'w_square', 'hard_gradient_square',
                               'gradient_square', 'flux_square', 'divergence',
                               'divergence_square', 'f', 'f_square', 'fw')}
    for ix, sx in enumerate((-1, 0, 1)):
        for iy, sy in enumerate((-1, 0, 1)):
            ux, vx, signx = coordinate(e[0], sx, 0)
            uy, vy, signy = coordinate(e[1], sy, 1)
            dx, dy = deriv(ux, 0), deriv(uy, 1)
            ax, ay = scale(dx, signx), scale(dy, signy)
            w = mul(ux, uy)
            gx, gy = mul(dx, uy), mul(dy, ux)
            H = add(mul(ax, uy), mul(ay, ux))
            zx = add(gx, mul(mul(vx, ux), ay))
            zy = add(gy, mul(mul(vy, uy), ax))
            if sx:
                assert zx == scale(H, signx)
            else:
                assert zx == mul(vx, H)  # |vx|<=1 on the whole plateau.
            if sy:
                assert zy == scale(H, signy)
            else:
                assert zy == mul(vy, H)
            # Supporting relation and dual bound establish the actual subgradient.
            assert add(mul(zx, gx), mul(zy, gy)) == mul(H, H)
            divergence = add(deriv(zx, 0), deriv(zy, 1))
            explicit = add(mul(deriv(dx, 0), uy), mul(deriv(dy, 1), ux),
                           mul(mul(deriv(vx, 0), ux), ay),
                           mul(mul(deriv(vy, 1), uy), ax), scale(mul(ax, ay), 2))
            assert divergence == explicit
            f = add(scale(ONE, 64), scale(divergence, -1))
            box = ((edges[0][ix], edges[0][ix+1]),
                   (edges[1][iy], edges[1][iy+1]))
            for key, p in [('w', w), ('w_square', mul(w, w)),
                           ('hard_gradient_square', mul(H, H)),
                           ('gradient_square', add(mul(gx, gx), mul(gy, gy))),
                           ('flux_square', add(mul(zx, zx), mul(zy, zy))),
                           ('divergence', divergence),
                           ('divergence_square', mul(divergence, divergence)),
                           ('f', f), ('f_square', mul(f, f)), ('fw', mul(f, w))]:
                totals[key] += integral(p, box)
            cells[ix, iy] = (w, zx, zy)
    # All normal traces, not samples of them: no hidden interface distribution.
    for ix in range(3):
        for iy in range(3):
            w, zx, zy = cells[ix, iy]
            for axis, index, other in ((0, ix, iy), (1, iy, ix)):
                z = (zx, zy)[axis]
                if index < 2:
                    neighbor = cells[(index+1, other) if axis == 0 else (other, index+1)]
                    t = edges[axis][index+1]
                    assert face(z, axis, t) == face(neighbor[axis+1], axis, t)
                    assert face(w, axis, t) == face(neighbor[0], axis, t)
                if index == 0:
                    assert face(z, axis, Q(-1)) == {}
                    assert face(w, axis, Q(-1)) == {}
                if index == 2:
                    assert face(z, axis, Q(1)) == {}
                    assert face(w, axis, Q(1)) == {}
    # Entire-cell inequalities: u''<=6/d^2, |u'|<=3/(2d), v'<=0.
    d1, d2 = 1-e[0], 1-e[1]
    div_upper = 6/d1**2 + 6/d2**2 + Q(9, 2)/(d1*d2)
    assert div_upper == Q(501, 16)
    assert 64-div_upper == Q(523, 16) > 0
    assert totals['divergence'] == 0
    assert totals['f'] == 256
    assert totals['fw'] == 64*totals['w'] + totals['hard_gradient_square']
    assert totals['f_square'] == 64**2*4 + totals['divergence_square']
    assert all(totals[k] > 0 for k in ('w', 'w_square', 'hard_gradient_square',
               'gradient_square', 'flux_square', 'divergence_square', 'f_square'))
    assert totals['gradient_square'] <= totals['hard_gradient_square']
    assert totals['flux_square'] <= 2*totals['hard_gradient_square']
    # Outside the cap, Z=w=f=0, g=0, and the variational residual is +64.
    # Convexity therefore proves a true zero-damping obstacle minimizer.
    return {'scope': 'one actual asymmetric nonradial positive L1/L2 source; full continuum',
            'polynomial_rectangles': 9, 'cap_volume': '4', 'threshold': '64',
            'g': '64*indicator_(-1,1)^2', 'g_mass': '256',
            'actual_zero_delta_variational_remainder': '64*integral_outside_square competitor >=0',
            'all_internal_normal_traces': 'matched as full polynomial identities',
            'all_outer_normal_traces': 'zero as full polynomial identities',
            'whole_space_integral_count': len(totals),
            'source_lower_bound': str(64-div_upper),
            'integrals': {k: str(v) for k, v in totals.items()},
            'status': 'PASS', 'exterior_energy_or_general_weak_bound': 'not reconstructed'}


if __name__ == '__main__':
    print(json.dumps(run(), sort_keys=True))
```
