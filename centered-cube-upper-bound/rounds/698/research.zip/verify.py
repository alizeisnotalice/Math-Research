from fractions import Fraction as F
from pathlib import Path
from flint import arb,ctx
import json
ctx.prec=256
def data(h,k):
    return json.loads(Path(h+k+'.json').read_text())
cases={}
dims=set()
for h,workers in [('mini',12),('laptop',15)]:
    counts=[]
    for kind in ('','-check','-shell'):
        d=data(h,kind); rr=d['rows']
        assert len({r['pid'] for r in rr})==d['workers']==workers
        counts.append(len(rr))
        print(h,kind,len(rr),round(d['elapsed'],3),round(sum(r['cpu'] for r in rr),3))
        if kind=='':
            seeds=[r['seed'] for r in rr];assert len(set(seeds))==len(seeds)
            assert not set(seeds).intersection(cases)
            for r in rr:
                assert 0<F(r['whole'])<=F(r['ratio'])
                assert set(r['tight']) and len(r['tight'])<=r['bad']
                cases[r['seed']]=r
        elif kind=='-check':
            assert seeds==[r['seed'] for r in rr] and all(r['verified'] for r in rr)
        else:
            for r in rr:
                n=r['n'];assert n not in dims;dims.add(n)
                a=32*n*n;t=arb(n).sqrt();u=(1-arb(2)/a)**n
                L=int((t*arb(2).log()/(1-u)).ceil().unique_fmpz())
                assert L==r['L']
                w=(-(1-u)/t).exp()
                lower=(1-w)*(1-(u*w)**(L-1))/((1-u*w)*u**L)+(w**(L-1)-arb(1)/2)/u
                assert (arb(r['log_rate'])-lower.log()/t).abs_upper()<arb('1e-55')
assert sorted(cases)==list(range(2160)) and dims==set(range(1,513))
assert sum(F(r['whole'])<F(r['ratio']) for r in cases.values())==2075
print('exact ratio range',float(min(F(r['ratio']) for r in cases.values())),float(max(F(r['ratio']) for r in cases.values())))
