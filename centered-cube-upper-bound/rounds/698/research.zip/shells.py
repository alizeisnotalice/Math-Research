from flint import arb,ctx
from fractions import Fraction as Q
import json
from math import ceil
ctx.prec=256
two=arb(2); log2=two.log()
rows=[]
for n in (1,2,3,4,8,16,32,64,128,256,1024,4096,16384,65536,262144):
    a=32*n*n;t=arb(n).sqrt();rho=1-two/a;u=rho**n
    L=int((t*log2/(1-u)).ceil().unique_fmpz())
    assert (L-1)*(1-u)<t*log2 and L*(1-u)>t*log2
    b=arb(a)**(-n); kap=(1+arb(1)/a)**n
    w=(-(1-u)/t).exp()
    # Exact bracket for residual at the first integer update reaching q.
    lo=u**(-L)*(1-w)*(1-(u*w)**(L-1))/(1-u*w)+(w**(L-1)-1/two)/u
    hi=lo+(1-(-b/t).exp())/(two*u)
    x=t*log2/kap
    H=x if x<1 else (x-1).exp()
    lower=(1/two-b/t)*kap*H/(2*t)
    assert lower<lo and hi<=(1/two+b/t)*u**(-L)
    rows.append(dict(n=n,L=L,lower_log_rate=str(lower.log()/t),
                     shell_lower_log_rate=str(lo.log()/t),shell_upper_log_rate=str(hi.log()/t)))
# Materialize the first two-dimensional shell and confirm exact tiling counts.
for n in (1,2):
    from itertools import product
    a=32*n*n
    cells=[j for j in product(range(a),repeat=n) if 0 in j or a-1 in j]
    assert len(cells)==a**n-(a-2)**n
    for cell in cells:
        assert max(abs(Q(2*k+1-a,a)) for k in cell)<1
print(json.dumps(rows))
