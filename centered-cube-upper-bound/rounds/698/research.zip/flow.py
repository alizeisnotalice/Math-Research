from collections import deque
import sys, os, time, socket, json, random
from multiprocessing import get_context
from fractions import Fraction

def case(seed):
    start=time.process_time()
    rng=random.Random(seed)
    n=72+seed%41
    # Units 1/32; equal parents radius 32, disjoint owners radius 1.
    y=[0]
    for _ in range(n-1):
        y.append(y[-1]+rng.choices([2,3,4],[19,2,1])[0])
    ends=sorted({v+d for v in y for d in (-32,32)})
    cells=list(zip(ends,ends[1:]))
    rows=[[h for h,(lo,hi) in enumerate(cells) if lo>=v-32 and hi<=v+32] for v in y]
    inc=list(map(set,rows))
    denom=32**n
    q=denom//2
    load=[0]*len(cells)
    order=list(range(n))
    rng.shuffle(order)
    active=order[:]
    sel=[]
    theta={}
    pools={}
    while active:
        i=max(active,key=lambda j:denom-max(load[k] for k in rows[j]))
        w=(denom-max(load[k] for k in rows[i]))//32
        theta[i]=w
        active.remove(i)
        sel.append(i)
        for k in rows[i]:load[k]+=w
        for j in active:
            if j in pools:continue
            h=max(rows[j],key=load.__getitem__)
            if load[h]>=q:pools[j]=[k for k in sel if h in inc[k]]

    targets=list(pools)
    # Units for optimization: each target has demand 1; each supplier i
    # has integer capacity theta[i]. Multiply resulting ratio by denom/32,
    # since actual demand is 1/16 and source budget is 2 theta[i]/denom.
    def oracle(lam):
        a,b=lam.numerator,lam.denominator
        end=1+len(targets)+n
        graph=[[] for _ in range(end+1)]
        def edge(x,y,k):
            g=[y,k,None];r=[x,0,g];g[2]=r
            graph[x].append(g);graph[y].append(r)
        for k,j in enumerate(targets,1):
            edge(0,k,b)
            for i in pools[j]:edge(k,1+len(targets)+i,b*len(targets)+1)
        for i in sel:edge(1+len(targets)+i,end,a*theta[i])
        while True:
            levels=[-1]*len(graph);levels[0]=0
            queue=deque([0])
            while queue:
                x=queue.popleft()
                for y,w,_ in graph[x]:
                    if w and levels[y]<0:levels[y]=levels[x]+1;queue.append(y)
            if levels[end]<0:break
            cursor=[0]*len(graph)
            def send(x,flow):
                if x==end:return flow
                while cursor[x]<len(graph[x]):
                    arc=graph[x][cursor[x]];y,w,rev=arc
                    if w and levels[y]==levels[x]+1:
                        d=send(y,min(w,flow))
                        if d:arc[1]-=d;rev[1]+=d;return d
                    cursor[x]+=1
                return 0
            while send(0,len(targets)*b):pass
        return [j for k,j in enumerate(targets,1) if levels[k]>=0]
    def ratio(group):
        return Fraction(len(group),sum(theta[i] for i in {i for j in group for i in pools[j]}))
    lam=ratio(targets)
    full=lam
    cut=targets
    iterations=0
    while True:
        nxt=oracle(lam);iterations+=1
        if not nxt:break
        r=ratio(nxt)
        if r==lam:break
        assert r>lam
        lam=r;cut=nxt
    assert ratio(cut)==lam
    # Independent explicit subset exhaustion for small examples.
    if len(targets)<=12:
        check=max(ratio([j for k,j in enumerate(targets) if mask>>k&1]) for mask in range(1,1<<len(targets)))
        assert check==lam
    return dict(seed=seed,count=n,bad=len(targets),tight=cut,ratio=str(lam*denom/32),whole=str(full*denom/32),calls=iterations,exhausted=len(targets)<=12,cpu=time.process_time()-start,pid=os.getpid())
if __name__=='__main__':
    lo,hi,workers=map(int,sys.argv[1:])
    start=time.monotonic()
    with get_context('fork').Pool(workers) as p: rows=p.map(case,range(lo,hi),1)
    print(json.dumps(dict(host=socket.gethostname(),python=sys.version,workers=workers,elapsed=time.monotonic()-start,rows=rows)))
