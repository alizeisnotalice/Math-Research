import json,sys
from pathlib import Path
z=json.load(open('laptop.json'))
src=Path('checkflow.py').read_text().replace('json.load(open(sys.argv[1]))["rows"]',repr([{k:r[k] for k in ('seed','tight','ratio')} for r in z['rows']]))
sys.stdout.write(src)
