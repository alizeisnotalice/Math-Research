from flint import arb,ctx
import json
ctx.prec=192
two=arb(2)
ln2=two.log()
base=(-arb(1)).exp()
rows=[]
for K in (2,3,4,8,16,32,64,128,256,512,1024):
    def inv(j):
        y=j*ln2
        return y if j==1 else (y-1).exp()
    v=sum((inv(j)/two**(j+1) for j in range(1,K)),arb(0))+inv(K)/two**K
    closed=ln2/4+K*base/2
    assert v.overlaps(closed) and (v-closed).contains(0) and (v-closed).abs_upper()<arb('1e-48')
    rows.append(dict(K=K,interval=str(v),ratio=str(v/base)))
print(json.dumps(rows))
