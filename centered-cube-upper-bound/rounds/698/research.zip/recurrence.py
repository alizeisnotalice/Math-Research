from decimal import Decimal as D, getcontext, ROUND_CEILING
from multiprocessing import get_context
import json,os,socket,sys,time

def calc(n):
    start=time.process_time()
    getcontext().prec=72
    a=32*n*n
    t=D(n).sqrt()
    u=(1-D(2)/a)**n
    w=(-(1-u)/t).exp()
    L=int((t*D(2).ln()/(1-u)).to_integral_value(rounding=ROUND_CEILING))
    # Sum source spending up to level 1/2. A fractional last update gives
    # the analytic lower endpoint of the true discrete first-hit bracket.
    geom=u**(-L)
    reward=geom*(1-w)
    block=u*w
    total=D(0)
    for k in range(L-1):
        total+=reward
        reward*=block
    total+=(w**(L-1)-D('0.5'))/u
    return dict(n=n,L=L,log_rate=str(total.ln()/t),cpu=time.process_time()-start,pid=os.getpid())
if __name__=='__main__':
    lo,hi,workers=map(int,sys.argv[1:])
    start=time.monotonic()
    with get_context('fork').Pool(workers) as pool:rows=pool.map(calc,range(lo,hi),1)
    print(json.dumps(dict(host=socket.gethostname(),python=sys.version,workers=workers,elapsed=time.monotonic()-start,rows=rows)))
