from collections import deque
import sys, os, time, socket, json, random
from multiprocessing import get_context
from fractions import Fraction

def case(seed):
    start=time.process_time()
    rng=random.Random(seed)
    n=72+seed%41
    # Units 1/32; equal parents radius 32, disjoint owners radius 1.
    y=[0]
    for _ in range(n-1):
        y.append(y[-1]+rng.choices([2,3,4],[19,2,1])[0])
    ends=sorted({v+d for v in y for d in (-32,32)})
    cells=list(zip(ends,ends[1:]))
    rows=[[h for h,(lo,hi) in enumerate(cells) if lo>=v-32 and hi<=v+32] for v in y]
    inc=list(map(set,rows))
    denom=32**n
    q=denom//2
    load=[0]*len(cells)
    order=list(range(n))
    rng.shuffle(order)
    active=order[:]
    sel=[]
    theta={}
    pools={}
    while active:
        i=max(active,key=lambda j:denom-max(load[k] for k in rows[j]))
        w=(denom-max(load[k] for k in rows[i]))//32
        theta[i]=w
        active.remove(i)
        sel.append(i)
        for k in rows[i]:load[k]+=w
        for j in active:
            if j in pools:continue
            h=max(rows[j],key=load.__getitem__)
            if load[h]>=q:pools[j]=[k for k in sel if h in inc[k]]

    targets=list(pools)
    # Units for optimization: each target has demand 1; each supplier i
    # has integer capacity theta[i]. Multiply resulting ratio by denom/32,
    # since actual demand is 1/16 and source budget is 2 theta[i]/denom.
    def ratio(group):
        return Fraction(len(group),sum(theta[i] for i in {i for j in group for i in pools[j]}))
    # Independent upper certificate via Edmonds--Karp at reported cost.
    # Lower certificate: validate the reported maximizing receiver cut.
    reported=table[seed]
    cut=reported["tight"];assert len(set(cut))==len(cut) and set(cut)<=set(targets)
    lam=ratio(cut)
    assert lam*denom/32==Fraction(reported["ratio"])
    a,b=lam.numerator,lam.denominator
    sink=n+len(targets)+1
    residual=[{} for _ in range(sink+1)]
    def edge(i,j,v):
        residual[i][j]=v
        residual[j][i]=0
    for k,j in enumerate(targets,1):
        edge(0,k,b)
        for i in pools[j]:edge(k,1+len(targets)+i,b)
    for i in sel:edge(1+len(targets)+i,sink,a*theta[i])
    delivered=0
    while delivered<len(targets)*b:
        via={0:-1};queue=deque([0])
        while queue and sink not in via:
            x=queue.popleft()
            for y,v in residual[x].items():
                if y not in via and v:
                    via[y]=x;queue.append(y)
        assert sink in via
        y=sink;delta=b
        while y:
            x=via[y];delta=min(delta,residual[x][y]);y=x
        y=sink
        while y:
            x=via[y];residual[x][y]-=delta;residual[y][x]+=delta;y=x
        delivered+=delta
    for k,j in enumerate(targets,1):
        flow=sum(residual[1+len(targets)+i][k] for i in pools[j])
        assert flow==b
    for i in sel:
        v=residual[sink][1+len(targets)+i]
        assert v==sum(residual[1+len(targets)+i].get(k,0) for k in range(1,len(targets)+1))
        assert v<=a*theta[i]
    return dict(seed=seed,verified=True,cpu=time.process_time()-start,pid=os.getpid())
if __name__=='__main__':
    table={x["seed"]:x for x in json.load(open(sys.argv[1]))["rows"]};workers=int(sys.argv[2])
    start=time.monotonic()
    with get_context('fork').Pool(workers) as p: rows=p.map(case,list(table),1)
    print(json.dumps(dict(host=socket.gethostname(),python=sys.version,workers=workers,elapsed=time.monotonic()-start,rows=rows)))
