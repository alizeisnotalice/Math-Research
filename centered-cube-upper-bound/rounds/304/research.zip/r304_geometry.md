# R304 — retain complete source/history qualification in a common marked witness process

## 1. Exact candidate and why the route changes

Keep the full original field, sources, kernel and gates. Let nu_* be the frozen heavy-source restriction nu_h from R303, or any fixed positive restriction nu_*<=nu. Every original e_g,m, low/high qualification and selected field is still computed from the FULL original nu,beta. Restricting the integration source does not recompute those qualifications.

Write the exact target, including its original aspect v(L,R)=min(1,(L/R)^(n/2))>=v0>0, as

    T=integral I0(x,y,z)p_y(x)h_(R(x))(x-z)/q(x)
                                          dx beta(dy)nu_*(dz). (1)

I0 in [0,1] includes all desired source, history, forbidden, terminal and near-pair masks. No such pair mask is removed in the construction below. Keep a<=L,R<=b<=2a, q_-=3lambda/4<=q<=lambda, original FIRST and actual accepted SAME-radius hard caps. Let alpha(x,y) in [0,1] be a measurable z-independent row gate with I0<=alpha on the accepted set E. Put

    U_y(x)=alpha(x,y)1_E(x)p_y(x)/q(x), I_y=integral U_y dx,
    b_y(x,z)=I0(x,y,z)/alpha(x,y) when alpha>0,
    b_y(x,z)=0 when alpha=0.

Then 0<=b<=1 and the exact target density is U_y(x)b_y(x,z)h_R(x-z). Original I0 already vanishes off E and where alpha=0. Define

    A^*_yz(r)=integral_{R(x)<=r}U_y(x)b_y(x,z)
                                      1{z in Q_(R(x))(x)}dx,
    ell_n(dr)=b^(-n)delta_b(dr)+n r^(-n-1)1_(a,b)(r)dr,
    d=kappa0 psi_inf/(q_-v0),
    kappa0=2K/(ell M), psi_inf=3-2/(3gamma^n), gamma=1+1/n,
    O_d^*=integral beta(dy)nu_*(dz)ell_n(dr)min(d,A^*_yz(r)).
                                                               (2)

The symbol b in the physical endpoint and b_y in the mask are distinguished by the subscript/arguments. The new common marked-witness theorem is

    T<=2O_d^*, and O_d^*<=T.                                (3)

The first inequality is realized by ONE common Poisson rate 1/d, not a separate selector for each source pair. Moreover O_d^* is no larger than the prior row-only clipped capacity, since A^* retains all actual pair masks before the clipping. No new target complement is introduced. This is a monotone whole-target improvement of the auxiliary source price, rather than an estimate for another far or very-close subcase.

There is also an exact quadratic construction on receiver-plus-mark space. With its boundary/mark fee B_H^* defined in section 4,

    (1-2d/H)T<=8lambda H W_beta+2B_H^*, H>0,              (4)
    T<=64lambda d W_beta+4B_(4d)^*.                       (5)

Equation (5) is valid finite-traffic algebra inside this fixed target. It does not require a separate entry inequality for lambda|E|, and does not establish a global root bound: the marked incidence fee is still unpaid. It may not be substituted for the original unmarked B_H without its own proof. All aspect and original outer costs remain.

## 2. One common marked Poisson stream and frozen qualified source pieces

For each row y use a Poisson process on actual receiver-mark pairs (u,v), v in [0,1], with intensity

    t U_y(u)du dv, t>0.

Its total intensity is tI_y<infinity by the established full-soft envelope. At a sampled point (u,v) define the ORIGINAL source-qualified set

    S_y(u,v)={z:z in Q_(R(u))(u), v<=b_y(u,z)}.           (6)

All hard sources see the SAME sampled receiver and SAME uniform mark. A different favorable receiver process has not been selected independently for each z. The entire set in (6) is frozen once y,u,v and the original field are fixed. It is contained in the witness's own hard cube, so

    nu_*(S_y(u,v))<=nu(Q_(R(u))(u))<=4lambda R(u)^n.      (7)

For every finite configuration partition its qualified sets S_i by smallest containing radius, with ties by index. Let D_i be the disjoint resulting source pieces. They are fixed during the target receiver x integral. Apply the R299 own-scale penalty

    chi_r(L,R)=min{1,(L/r)^(n/2)min[1,(R/r)^(3n/2)]}

to D_i, and let H_config^* be the maximum chi-weighted qualified capture. The same rowwise own-scale estimate gives

    T_(E H_config^*)<=(kappa0 psi_inf/q_-) C_t^*,
    C_t^*=integral beta(dy) E integral r_min^(-n)1_union nu_*(dz).
                                                               (8)

Here r_min is over the qualified sets S_i, not all their unqualified cubes. The sharper Psi_G((b/r_i)^n) coefficient may be retained. The fee includes original source overlap through these actual pieces; (7) only supplies a positive upper bound when needed.

Crucially the own-scale lemma accepts ANY frozen measurable source subset of a witness cube. It does not require transferring the witness's history or source qualification to the target receiver. The original I0(x,y,z) is still present in the target integral when its low/high point heights are used. At a witness u the separately evaluated I0(u,y,z) merely defines a source subset; it does not assert that I0(x,y,z)=I0(u,y,z). Thus no free witness/target history compatibility is assumed.

The construction is measurable through the usual nonnegative Poisson series: sum over finite m, factor exp(-tI_y)/m!, and product intensity (tU_y du dv)^m. Every sampled configuration is finite almost surely. Each D_i is measurable by finitely many comparisons of radii and membership in (6). No global measurable choice of one random witness function y -> configuration is required. If I_y=0 the process is empty and the target row is zero.

## 3. Exact marked capture, rank, and the actual first moment

For a fixed source z the Poisson intensity of qualified witnesses with radius <=r is tA^*_yz(r). Hence the minimum-radius distribution has CDF 1-exp(-tA^*_yz(r)), and

    C_t^*=integral beta(dy)nu_*(dz)ell_n(dr)
                                          [1-exp(-tA^*_yz(r))]. (9)

Whenever a qualified witness has radius at most the actual hard R, its chi is at least v(L,R). Thus on the target aspect branch

    1<=(E H_config^*)/v0+exp(-t A^*_yz(R)).              (10)

The rank measure for the second term is EXACTLY the pushforward of
U_y(u)b_y(u,z)1_capture du by R(u), namely dA^*_yz. At a radius atom with increment delta A and endpoints A-,A, the deficit

    [exp(-tA-)-exp(-tA)]/t-exp(-tA)delta A>=0

follows by integrating the decreasing exponential over the atom interval. The nonatomic part follows by the same quantile identity. Therefore the target miss term is at most C_t^*/t, and (8),(10) prove

    T<=(d+1/t)C_t^*.                                    (11)

The one common choice t=1/d and 1-exp(-u)<=min(1,u) give T<=2O_d^*.

On the other hand, ell_n([s,b])=s^(-n) and Tonelli yield the EXACT first-moment identity

    integral beta(dy)nu_*(dz)ell_n(dr) A^*_yz(r)
      =integral U_y(x)b_y(x,z)h_(R(x))(x-z)
                                             dx beta(dy)nu_*(dz)
      =T.                                                (12)

Since min(d,A)<=A, (12) proves O_d^*<=T. Thus (3) is an actual equivalence within factor two. The earlier row-only capacity could price traffic disallowed by source/history masks; the new capacity retains those qualifications exactly.

Finiteness needed for later algebra is already available: at every actual receiver, integral I0 p_y beta/q<=1 by original FIRST, so T<=A_n W_(nu_*), A_n=1+n log(b/a), through the positive hard-scale envelope. No finite receiver-volume assumption is required for this finiteness statement.

## 4. Marked quadratic identity and the changed first-moment ledger

The cumulative row mass is still ORIGINAL

    J_y(r)=integral_{R(u)<=r}U_y(u)du,

because integration over v in [0,1] has mass one. Let M_y^*(r)=integral A^*_yz(r)nu_*(dz). On receiver-plus-mark space define

    Q_y^*(r)=(1/2)integral_{R(u),R(w)<=r}U_y(u)U_y(w)
           integral_[0,1]^2 nu_*(S_y(u,v) Delta S_y(w,v'))dv dv' du dw.

Then the EXACT indicator expansion gives

    Q_y^*(r)=J_y(r)M_y^*(r)-integral [A^*_yz(r)]^2 nu_*(dz). (13)

Define

    B_H^*=integral beta(dy)ell_n(dr)1{J_y(r)>=H}Q_y^*(r)/J_y(r).
                                                               (14)

On J>0, the same verified scalar inequality for 0<=A<=J gives

    integral min(d,A^*)nu_*
           <=(d/J)M_y^*+Q_y^*/J,

and it is also at most M_y^*. The small cumulative layers J<H cost at most 4lambda H per beta row: (7) supplies M_y^*(r)<=4lambda integral_[a,r]s^n mu_y(ds), and the inclusive-CDF argument with ell_n([s,b])=s^(-n) excludes the entire atom crossing H. No continuity assumption at the threshold is used.

Consequently

    O_d^*<=4lambda H W_beta+(d/H)T+B_H^*.               (15)

The middle term is now the EXACT original T from (12), not the enlarged first moment A_n W_nu or lambda|E|. Combine (15) with T<=2O_d^* to obtain (4). Because T is finite, taking H=4d and moving T/2 to the left is legitimate, proving (5). This is internal self-absorption of an explicitly known fraction of the same finite target; it is not a claim of an unproved epsilon estimate for B_H^*, or of the full global ledger.

The general remaining criterion is therefore a source-conserving bound for the ACTUAL marked normalized incidence (14), with H tied to d if (5) is used. A bound at the old R302 threshold cannot be substituted silently. The source coefficient is 64lambda d=(256/3)kappa0 psi_inf/v0, so small v0 remains costly and its original complementary aspect problem has not disappeared.

## 5. Geometric boundary versus source/history-mark disagreement

It is essential to record what Q^* measures. Fix y,u,w,z and write

    c_u=1{z in Q_(R(u))(u)}, c_w=1{z in Q_(R(w))(w)},
    b_u=b_y(u,z), b_w=b_y(w,z).

Averaging the qualified-capture symmetric difference over the TWO independent uniform marks gives exactly

    c_u(1-c_w)b_u+c_w(1-c_u)b_w
                   +c_uc_w[b_u+b_w-2b_u b_w].          (16)

The first two terms are physical cube boundary incidence weighted by original qualifications. They are at most the old unmarked cube symmetric difference. The last term is qualification/mark disagreement INSIDE the common cube. It is nonnegative and is not a geometric boundary term. It can be present when both cubes are identical. For binary original masks it records source/history qualification changes; for genuinely fractional masks it also includes their Bernoulli-mark variance.

If b is the SAME frozen binary source-pair mask at both receiver locations, the final term vanishes. In general it must be paid. It is therefore false to infer B_H^*<=B_H solely from A^*<=A. The correct monotonicity is the clipped-cost inequality O_d^*<=O_d^row. Both exact qualifications and common receiver geometry are present in (13)-(16).

This changes the next mathematical question. A pure estimate for unqualified cube boundary mass may be unnecessarily strong for the original traffic, while replacing it by marked boundary without charging the common-cube term would be invalid. The faithful incidence problem must control both terms in (16), integrated against the actual U_y(u)U_y(w)/J_y(r), original beta and nu_h, with the prefix and original full e_g/history kept. FIRST is available jointly across beta rows, but alone only gives the old positive first-moment bounds; no density cap on nu_h or free selector for b has been inferred.

The proved gain is a common source-conserving witness mechanism which retains ALL original pair masks and makes the quadratic first moment exactly T, permitting (5). No integrated root payment of B_H^*, or of the old local-heavy B_H, has been proved. No epsilon lambda|E| absorption is claimed. In the global argument all still-unpaid aspect, source and outer pieces remain. Conditional on outer data xi, the existing positive Lambda(xi) multiplies (3)-(5); internal exact identities do not grant a free outer budget or certify a complete original entry ledger.

## 6. Actual finite marked-geometry diagnostics

A local exact-Fraction run passed three mark regimes: all qualifications retained, genuinely fractional and receiver-varying qualifications, and all qualifications removed. Across n=1,2,4 it passed 108 common-mark iid union identities, 504 exact physical-boundary/mark-disagreement decompositions, 27 quadratic identities, 9 exact original first moments, and 54 clipped cumulative budgets. Shared marks were represented by their exact intervals between qualification thresholds, so one mark simultaneously defined the source set for every source. These tests verify finite witness algebra, not full original low/e_g/history realizability or an unknown root incidence estimate. Exact code follows and writes no files.

```python
from fractions import Fraction as F
from itertools import product
ct={'marked_union':0,'pair_decomposition':0,'quadratic':0,'first_moment':0,'clip_budget':0}
for n in [1,2,4]:
 centers=[(F(0),)*n,(F(1,2),)*n,(F(2),)*n];rs=[F(1),F(3,2),F(2)]
 zs=centers+[(F(1),)*n];nu=[F(1,4)]*4;U=[F(1,4),F(1,2),F(1,4)]
 caps=[[int(all(abs(z[k]-x[k])<=r/2 for k in range(n))) for z in zs] for x,r in zip(centers,rs)]
 for marks in [[[F(1)]*4]*3,[[F(0),F(1,2),F(1),F(1,3)],[F(1,2),F(1),F(1,3),F(0)],[F(1),F(0),F(1,2),F(1)]],[[F(0)]*4]*3]:
  atoms=[]
  for i in range(3):
   cuts=sorted(set([F(0),F(1)]+marks[i]))
   for lo,hi in zip(cuts,cuts[1:]):
    v=(lo+hi)/2
    atoms.append((i,U[i]*(hi-lo),[caps[i][z]*int(v<=marks[i][z]) for z in range(4)]))
  for N in [1,2,3]:
   hit=[F(0)]*4
   for inds in product(range(len(atoms)),repeat=N):
    prob=F(1)
    for j in inds:prob*=atoms[j][1]
    for z in range(4):hit[z]+=prob*int(any(atoms[j][2][z] for j in inds))
   for z in range(4):
    A=sum(U[i]*caps[i][z]*marks[i][z] for i in range(3))
    assert hit[z]==1-(1-A)**N;ct['marked_union']+=1
  layers=[]
  for k,r in enumerate(rs):
   active=[a for a in atoms if rs[a[0]]<=r]
   J=sum(a[1] for a in active)
   Az=[sum(a[1]*a[2][z] for a in active) for z in range(4)]
   M=sum(m*A for m,A in zip(nu,Az));Q=J*M-sum(m*A*A for m,A in zip(nu,Az))
   pair=sum(a[1]*b[1]*sum(nu[z]*abs(a[2][z]-b[2][z]) for z in range(4)) for a in active for b in active)/2
   assert Q==pair;ct['quadratic']+=1
   for i,j,z in product(range(k+1),range(k+1),range(4)):
    c,e=caps[i][z],caps[j][z];p,q=marks[i][z],marks[j][z]
    direct=c*p+e*q-2*c*e*p*q
    decomposed=c*(1-e)*p+e*(1-c)*q+c*e*(p+q-2*p*q)
    assert direct==decomposed;ct['pair_decomposition']+=1
   weight=r**(-n)-(rs[k+1]**(-n) if k<2 else F(0))
   layers.append((weight,J,Az,M,Q))
  T=sum(w*M for w,J,Az,M,Q in layers)
  actual=sum(U[i]*rs[i]**(-n)*sum(nu[z]*caps[i][z]*marks[i][z] for z in range(4)) for i in range(3))
  assert T==actual;ct['first_moment']+=1
  for d,H in product([F(1,10),F(1)],[F(1,4),F(1),F(3)]):
   O=sum(w*sum(m*min(d,A) for m,A in zip(nu,Az)) for w,J,Az,M,Q in layers)
   B=sum((w*Q/J for w,J,Az,M,Q in layers if J>=H),F(0))
   assert O<=4*H+d*T/H+B;ct['clip_budget']+=1
print('PASS',ct)
```

Only /tmp/r304_geometry.md was written. Other authors, previous frozen proofs and Git state were preserved.
