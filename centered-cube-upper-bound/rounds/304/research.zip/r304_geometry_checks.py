from fractions import Fraction as F
from itertools import product
ct={'marked_union':0,'pair_decomposition':0,'quadratic':0,'first_moment':0,'clip_budget':0}
for n in [1,2,4]:
 centers=[(F(0),)*n,(F(1,2),)*n,(F(2),)*n];rs=[F(1),F(3,2),F(2)]
 zs=centers+[(F(1),)*n];nu=[F(1,4)]*4;U=[F(1,4),F(1,2),F(1,4)]
 caps=[[int(all(abs(z[k]-x[k])<=r/2 for k in range(n))) for z in zs] for x,r in zip(centers,rs)]
 for marks in [[[F(1)]*4]*3,[[F(0),F(1,2),F(1),F(1,3)],[F(1,2),F(1),F(1,3),F(0)],[F(1),F(0),F(1,2),F(1)]],[[F(0)]*4]*3]:
  atoms=[]
  for i in range(3):
   cuts=sorted(set([F(0),F(1)]+marks[i]))
   for lo,hi in zip(cuts,cuts[1:]):
    v=(lo+hi)/2
    atoms.append((i,U[i]*(hi-lo),[caps[i][z]*int(v<=marks[i][z]) for z in range(4)]))
  for N in [1,2,3]:
   hit=[F(0)]*4
   for inds in product(range(len(atoms)),repeat=N):
    prob=F(1)
    for j in inds:prob*=atoms[j][1]
    for z in range(4):hit[z]+=prob*int(any(atoms[j][2][z] for j in inds))
   for z in range(4):
    A=sum(U[i]*caps[i][z]*marks[i][z] for i in range(3))
    assert hit[z]==1-(1-A)**N;ct['marked_union']+=1
  layers=[]
  for k,r in enumerate(rs):
   active=[a for a in atoms if rs[a[0]]<=r]
   J=sum(a[1] for a in active)
   Az=[sum(a[1]*a[2][z] for a in active) for z in range(4)]
   M=sum(m*A for m,A in zip(nu,Az));Q=J*M-sum(m*A*A for m,A in zip(nu,Az))
   pair=sum(a[1]*b[1]*sum(nu[z]*abs(a[2][z]-b[2][z]) for z in range(4)) for a in active for b in active)/2
   assert Q==pair;ct['quadratic']+=1
   for i,j,z in product(range(k+1),range(k+1),range(4)):
    c,e=caps[i][z],caps[j][z];p,q=marks[i][z],marks[j][z]
    direct=c*p+e*q-2*c*e*p*q
    decomposed=c*(1-e)*p+e*(1-c)*q+c*e*(p+q-2*p*q)
    assert direct==decomposed;ct['pair_decomposition']+=1
   weight=r**(-n)-(rs[k+1]**(-n) if k<2 else F(0))
   layers.append((weight,J,Az,M,Q))
  T=sum(w*M for w,J,Az,M,Q in layers)
  actual=sum(U[i]*rs[i]**(-n)*sum(nu[z]*caps[i][z]*marks[i][z] for z in range(4)) for i in range(3))
  assert T==actual;ct['first_moment']+=1
  for d,H in product([F(1,10),F(1)],[F(1,4),F(1),F(3)]):
   O=sum(w*sum(m*min(d,A) for m,A in zip(nu,Az)) for w,J,Az,M,Q in layers)
   B=sum((w*Q/J for w,J,Az,M,Q in layers if J>=H),F(0))
   assert O<=4*H+d*T/H+B;ct['clip_budget']+=1
print('PASS',ct)
