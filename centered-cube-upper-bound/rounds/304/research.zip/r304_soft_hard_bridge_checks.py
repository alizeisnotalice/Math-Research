from fractions import Fraction as F
from math import comb, factorial
rho=F(19,20)
E2=sum((F(2)**k/F(factorial(k)) for k in range(7)),F(0))
E2+=F(2)**7/F(factorial(7))*F(4,3)
assert E2<F(15,2)
coeff_cases=cutoff_cases=0
for n in (1,2,8,32,128):
 c=[F(1) if k in (0,n) else
    comb(n,k)*F(k,n)**k*F(n-k,n)**(n-k)
    for k in range(n+1)]
 assert all(0<t<=1 for t in c)
 tails=[sum((c[k]*rho**k for k in range(j+1,n+1)),F(0))
        for j in range(n+1)]
 for j in range(n+1):
  assert tails[j]<=rho**(j+1)/(1-rho)
  coeff_cases+=1
 for d in (F(0),F(1,100),F(1),F(10)**6):
  for eps in (F(1),F(1,10),F(1,1000)):
   for scale in (F(1),F(3,2),F(2)):
    D=2-scale**(-n)
    j=next(j for j in range(n+1) if D*d*tails[j]<=eps)
    assert 0<=j<=n and D*d*tails[j]<=eps
    if j: assert D*d*tails[j-1]>eps
    cutoff_cases+=1
print(coeff_cases,cutoff_cases)  # actual output: 176 180
