# R304 — exact common-soft traffic ledger and a paid adaptive high-degree tail

## 1. Statement and scope

Fix the ORIGINAL measurable receiver fields s(x) in [0,1], a<=L(x),R(x)<=b<=2a, q(x)>=q_-=3lambda/4>0 and accepted receiver set E. Let beta,nu be arbitrary finite positive L1 sources. Keep all original low-pe, high-m, aspect, forbidden and history masks in I0(x,y,z) in [0,1]. The actual kernel is

    p_y(x)=P_(s(x),L(x))(x-y),
    P_s(u)=product_(i=1)^n[(1-s)h(u_i)+s phi(u_i)],
    h=1_[-1/2,1/2], phi=h*w,
    w(t)=integral_0^1 exp(-|t|/u)du.

For a subset S of coordinates let q_S use phi on S and h elsewhere. Let q_k be the AVERAGE of q_S over |S|=k, and write q_(k,L)(u)=L^(-n)q_k(u/L). Set

    b_k(s)=binom(n,k)s^k(1-s)^(n-k),
    c_(n,k)=max_(0<=s<=1)b_k(s).

For k=0,n, c_(n,k)=1; for 0<k<n its exact value is b_k(k/n). These are common-softness coefficients. No coordinate-wise optimization of s is allowed.

Let omega(y,z) in [0,1] be any FROZEN measurable source-pair allocation. In particular it may be the old near-heavy allocation. Define

    b_omega(z)=integral omega(y,z)beta(dy),
    d_omega(z)=b_omega(z)/(q_-a^n),
    D_scale=2-(a/b)^n in [1,2).

Choose ANY measurable integer cutoff j(z) in {0,...,n}. Split the original traffic by the exact kernel identity into low k<=j(z) and high k>j(z), with their actual weights b_k(s(x)). Then

    T_omega=T_low,j+T_high,j,                          (1)
    T_high,j <=D_scale integral d_omega(z)
                         S_(n,j(z))(rho)nu(dz),       (2)

where

    S_(n,j)(rho)=sum_(k=j+1)^n c_(n,k)rho^k,
    rho=1-2 integral_0^1 u exp(-3/(2u))du<1.

The same statement holds with any certified rho_bar>=rho, rho_bar<1, in place of rho. In particular rho_bar=19/20 is rigorously available below. For j=n the sum is empty and zero. For j=0 only the hard k=0 component remains in the low part. Formula (2) has NO A_n^2 point-amplitude fee, where A_n=1+n log(b/a).

For EVERY epsilon>0 and arbitrary original sources, the measurable cutoff

    j_epsilon(z)=min{j in {0,...,n}:
                D_scale d_omega(z)S_(n,j)(rho_bar)<=epsilon} (3)

exists, and gives the genuinely source-linear high-degree payment

    T_high,j_epsilon <=epsilon W_nu.                 (4)

If d_omega=0 choose j=0. Otherwise a simple sufficient explicit cutoff is

    j=min(n,ceil(log_+(D_scale rho_bar d_omega/
                               ((1-rho_bar)epsilon))
                                             /log(1/rho_bar))). (5)

Here log_+(t)=max(0,log t), for t>0. Formula (5) follows from the geometric tail bound and may exceed the exact minimal cutoff (3). The cutoff is fixed by original source masses; e,m,q and the receiver selectors are unchanged on both pieces. This is an all-source tail payment, not a total-mass or light-column assumption.

The low-degree cutoff, however, may equal n on heavy columns. No dimension-uniform bound on j_epsilon is proved. The result is an exact mass/cutoff receipt and a paid high-degree tail, not a reduction of all original traffic to uniformly bounded k and not a new general root estimate.

## 2. Weighted FIRST is an exact shared budget

The pointwise common-softness identity is

    p_y(x)=sum_(k=0)^n b_k(s(x))q_(k,L(x))(x-y).        (6)

All terms are nonnegative. When p_y>0 define the actual latent fraction

    theta_k(x,y)=b_k(s(x))q_(k,L(x))(x-y)/p_y(x).

Set every theta_k=0 where p_y=0. On that set all positive terms in (6) are zero. Elsewhere sum_k theta_k=1. Multiplying original traffic by theta_k gives an exact positive decomposition (1), without changing its denominator or source measures. Variable j(z) merely groups these existing terms into two parts.

At original accepted receivers, FIRST supplies ONLY

    sum_k b_k(s(x))F_k(x)=F_actual(x)<=q(x),
    F_k(x)=integral q_(k,L(x))(x-y)beta(dy).            (7)

Thus the actual component response shares

    f_k(x)=b_k(s(x))F_k(x)/q(x)

are nonnegative and sum to at most one. This is the exact joint coefficient accounting. In particular the sum of all weighted component FIRST charges is one original FIRST charge, not n+1 independently spendable charges. Any retained subset of these terms is at most the full actual response.

For b_k(s(x))>0, (7) individually implies the comparison

    F_k(x)<=q(x)/b_k(s(x)).                            (8)

It does NOT imply F_k<=q. Where b_k=0 the component makes no actual contribution and no unweighted FIRST comparison is supplied. Formula (8) has no finite uniform constant on s in [0,1] for an interior k; near the endpoints b_k tends to zero. This is an exact algebraic obstruction to declaring component FIRST for free, rather than an original-cube counterexample.

All original masks can depend on x,y,z. For each fixed z, the sum of the retained nonnegative weighted components is still bounded by actual p_y. FIRST may therefore be used once before the hard receiver envelope to obtain

    T_low,j<=A_n W_nu, T_high,j<=A_n W_nu,
    T_low,j+T_high,j=T_omega<=A_n W_nu.                (9)

The two separate inequalities in (9) are alternatives; they do not provide two independent source credits. Paying the high part by (4) does not itself improve the low part's A_n baseline.

## 3. Proof of the high-degree source receipt with actual selectors

Use the strict soft-coordinate overlap contraction proved in /tmp/r303_soft_gap.md. At every L,R in [a,b], translation delta, and coordinate subset S of size k,

    (q_(S,L)*h_R)(delta)<=rho^k max(L,R)^(-n).          (10)

This is the actual phi, in both scale orientations. Averaging over |S|=k proves the same bound for q_k. The argument does not assume an actual selected s is small.

Let mu=delta_b+n1_(a,b)(t)dt/t, and set

    K_k(u)=integral q_(k,L)(u)mu(dL),
    H(u)=integral h_R(u)mu(dR), P_k=K_k*H.

Each q_k is ray-decreasing. The positive scale-envelope inequality from R302 implies q_(k,L(x))(x-y)<=K_k(x-y) at the actual selected L. Similarly h_(R(x))(x-z)<=H(x-z). First keep the original mask and actual b_k(s(x)); then bound b_k<=c_(n,k), q>=q_-, and extend the receiver integral positively. It follows that

    T_high,j <=(1/q_-) integral omega(y,z)beta(dy)nu(dz)
                       sum_(k>j(z))c_(n,k)P_k(z-y).   (11)

The exact two-scale normalization from R302 is

    integral integral max(L,R)^(-n)mu(dL)mu(dR)
                                      =2a^(-n)-b^(-n).

Using (10) INSIDE this scale integral gives

    P_k(delta)<=rho^k(2a^(-n)-b^(-n)).                (12)

Integrating the original beta allocation omega in (11) proves (2). No fixed convolution was substituted for an actual selector: the two positive scale envelopes dominate the actual kernels first. No FIRST statement is granted outside E. Nonnegative Tonelli justifies all integrals and the finite sum.

Because c_(n,k)<=1,

    S_(n,j)(rho_bar)<=rho_bar^(j+1)/(1-rho_bar).        (13)

This proves (5); (3) exists because S_(n,n)=0. Measurability follows from a finite first-satisfying-index rule applied to the measurable d_omega. Equation (4) then follows pointwise in the original hard source before integration. Different cutoff strata partition that hard source; summing their epsilon fees costs epsilon W_nu ONCE, rather than once per k or stratum.

For reference the integrable envelopes have

    integral P_k=A_n^2,
    integral sum_(k>j)c_(n,k)P_k
                            =A_n^2 sum_(k>j)c_(n,k).  (14)

The rho^k loss is a POINT overlap contraction, not an L1 mass loss. Equation (14) explains why it cannot be silently turned into an L1 contraction and convolved against an arbitrary source for free.

## 4. What source conservation does and does not permit

At a fixed L and fixed k there is a genuine probability smoothing law eta_(k,L): average over subsets S of size k, using w_L in coordinates S and a delta mass at zero in the others. Then

    q_(k,L)*beta=h_L*(eta_(k,L)*beta),
    totalmass(eta_(k,L)*beta)=W_beta.                  (15)

This is a true source-conserving convolution identity for that fixed pair (k,L). It does not provide a SINGLE replacement source for the original field when L=L(x) and b_k=b_k(s(x)) vary with the receiver. Nor may one charge W_beta independently for every (k,L) in (15) and call the total one source mass. The exact shared budget available without an additional operator argument is (7), and the exact source-tail budget is (2).

For the near-heavy allocation, omega may include 1{|y-z|_infinity<=Db} and its original heavy-column indicator. Then b_omega is the actual restricted original beta column mass, not a posterior substitute. Formula (3) pays its high-degree tail even if those columns are arbitrarily heavy. To conclude that the remaining degree is at most a prescribed J<n using THIS certificate, one needs on the relevant columns

    D_scale d_omega(z)S_(n,J)(rho_bar)<=epsilon.        (16)

This is a precise sufficient source-mass condition for the certificate; it is not asserted necessary for actual traffic, and is not proved from original FIRST. The latter is an actual-receiver cap (7), whereas d_omega is a source-column mass. There is no verified implication from (7) to (16) on heavy columns.

Thus a uniformly small effective k still requires an additional source-conserving geometry/response estimate that controls the large-d_omega columns without repeating their nu fee, or an operator estimate for the variable-cutoff low part that avoids the unweighted comparison loss (8). The local-heavy border mechanism has not been closed. The new receipt deliberately exposes that exact remaining bridge instead of granting component FIRST or assuming all columns light. All costs here are raw; original outer/source allocation factors multiply them once.

## 5. Rational constant and actual reproducible finite checks

The convenient rational rho_bar=19/20 is rigorous. On u in [3/4,1], u>=3/4 and exp(-3/(2u))>=exp(-2), so

    1-rho=2 integral_0^1 u exp(-3/(2u))du
                       >=(3/8)exp(-2)>1/20.

For the strict last inequality, the Taylor terms for exp(2) through order 6 plus a geometric upper tail starting at order 7 give

    exp(2)<=sum_(k=0)^6 2^k/k!+(2^7/7!)/(1-1/4)<15/2.

The term ratio after order 7 is at most 1/4. All comparisons in the last display are exact rational ones. This bound uses the true phi contraction; it is not a replacement profile.

The following standard-library code was actually run successfully. It checked 176 exact coefficient/tail cases and 180 exact minimal-cutoff cases, as well as the rational exponential certificate. Its finite n range checks implementation and zero/n endpoint conventions; the theorem is proved analytically above.

```python
from fractions import Fraction as F
from math import comb, factorial
rho=F(19,20)
E2=sum((F(2)**k/F(factorial(k)) for k in range(7)),F(0))
E2+=F(2)**7/F(factorial(7))*F(4,3)
assert E2<F(15,2)
coeff_cases=cutoff_cases=0
for n in (1,2,8,32,128):
 c=[F(1) if k in (0,n) else
    comb(n,k)*F(k,n)**k*F(n-k,n)**(n-k)
    for k in range(n+1)]
 assert all(0<t<=1 for t in c)
 tails=[sum((c[k]*rho**k for k in range(j+1,n+1)),F(0))
        for j in range(n+1)]
 for j in range(n+1):
  assert tails[j]<=rho**(j+1)/(1-rho)
  coeff_cases+=1
 for d in (F(0),F(1,100),F(1),F(10)**6):
  for eps in (F(1),F(1,10),F(1,1000)):
   for scale in (F(1),F(3,2),F(2)):
    D=2-scale**(-n)
    j=next(j for j in range(n+1) if D*d*tails[j]<=eps)
    assert 0<=j<=n and D*d*tails[j]<=eps
    if j: assert D*d*tails[j-1]>eps
    cutoff_cases+=1
print(coeff_cases,cutoff_cases)  # actual output: 176 180
```

Only this assigned file was created. The underlying two-selector and contraction theorems come from R302/R303; the contribution is the exact actual-weight FIRST ledger and adaptive original-source tail receipt, with its remaining uniform-degree premise explicit.
