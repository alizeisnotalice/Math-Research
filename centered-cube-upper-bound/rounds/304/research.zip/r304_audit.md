# R304 independent preauthor screen

Own only /tmp/r304_audit.md, no Git or other file edits. This screen was saved BEFORE reading any R304 author proof. The target is the complete original positive low-pe,m>M, accepted, history/source and ASPECT-qualified traffic. Its exact mask I0(x,y,z) in [0,1] must include the aspect v(L,R)>=v0. Original full e_g,m,q,common s,L,R and original sources stay fixed. Original FIRST and same-accepted-receiver/same-selected-radius hardcaps hold. Write q_-=3lambda/4, kappa0=2K/(ell M), psi_inf=3-2/(3gamma^n), d=kappa0 psi_inf/(q_-v0)>0. Actual receiver measure remains Lebesgue dx; original outer/global ledgers are not inferred.

## 1. Common marked witnesses preserve the complete original pair mask

Choose a z-independent measurable alpha(x,y) in [0,1] dominating I0. Set U_y=alpha1_E p_y/q and b(x,y,z)=I0/alpha when alpha>0, zero otherwise. Then 0<=b<=1, and U_y b=I0 p_y/q on the original accepted target. Alpha=0 forces I0=0 and adds no traffic. The row law is finite by the existing full-soft envelope.

Use ONE Poisson process on receiver-mark space (u,v) with intensity t U_y(u)du dv, v in [0,1]. Its witness source set is S_(u,v)={z:z in Q_R(u)(u), v<=b(u,y,z)}. It is a measurable ORIGINAL source subset of the actual cube, so its cap <=4lambda R(u)^n is inherited. The null mark endpoint v=0 at b=0 can be defined either way without changing any integral. Fractional masks are handled by the shared mark; no different favorable receiver process is selected for each z.

For each finite configuration, partition these qualified source sets by smallest capturing R, tie by finite index. The pieces are frozen before current x integration. The R299 chi single-witness theorem applies to their ORIGINAL nu masses, because the original CURRENT target heights are still valid wherever I0>0. Its common-max fee is at most (kappa0 psi_inf/q_-) times the expected inverse-volume source maximum. Mark qualification changes the source subset, not the witness radius or the original point-height proof. Finite positive Poisson series ensure joint measurability, without choosing a global random row map.

## 2. Exact actual cumulative intensity and rank bridge

The qualified capture CDF is

    Aact_yz(r)=integral_{R(u)<=r}U_y(u)b(u,y,z)
                                  1_QR(u)(u)(z)du
              =integral_{R(u)<=r}I0(u,y,z)p_y(u)/q(u)
                                  1_QR(u)(u)(z)du.

It is exactly the actual captured target measure, not the enlarged original row probability. Its hit probability is 1-exp(-t Aact_yz(r)). Let Cact_t denote the original-beta integral of expected marked minimum inverse-volume cost. The inclusive-CDF atom argument gives the ACTUAL rank integral against dAact <=Cact_t/t after beta integration. There is no missing I_y normalization.

For a current target edge, an eligible marked witness radius<=R contributes chi>=v(L,R)>=v0. Thus the same pointwise positive majorant as R301 gives

    T_target <=(d+1/t) Cact_t.

Define Omega=beta(dy)nu(dz)[b^-n delta_b(dr)+n r^-n-1 dr] and Oact_d=integral min(d,Aact)dOmega. The common implementable rate t=1/d gives T_target<=2Oact_d. Since Aact<=Arow pointwise, Oact<=Orow and Cact<=Crow. This is cost monotonicity only: qualified-set disagreement does NOT have to decrease under masks.

## 3. Exact first moment and legal internal T absorption

The layer identity ell([R,b])=R^-n gives EXACTLY

    integral Aact dOmega=T_target.

This equality requires I0 to be the exact stated target INCLUDING aspect; it would instead return a larger target if that qualification were omitted from Aact. Therefore Oact<=T_target, while the bridge gives T_target/2<=Oact. This comparability is not a dimension estimate or an authorized global X-entry.

On the extended receiver-mark space, prefix mass J_y(r)=integral_{R<=r}U_y du is UNCHANGED because the full mark interval has unit measure. The qualified source indicator sets have exact overlap identity

    Qact_y(r)=J_y(r)Mact_y(r)-integral Aact_yz(r)^2nu(dz).

Their same-radius source caps inherit the original hardcap. R302's strict low-J-layer proof, with inclusive atoms and terminal ell mass retained, gives <=4lambda H W_beta. On the high layer the first-moment term is now (d/H)T_target. Hence

    Oact<=4lambda H W_beta+(d/H)T_target+Bact_H.

Original target traffic is finite: it is <=4lambda integral I_y beta, finite by the old full-soft row bound, and also <=A_n W_nu by original FIRST. Thus for H>2d the local internal algebra is legitimate:

    (1-2d/H)T_target<=8lambda H W_beta+2Bact_H,
    H=4d gives T_target<=64lambda d W_beta+4Bact_(4d).

This is absorption of the SAME finite T into itself, not an epsilon lambda|E| global entry, and it does not prove any authorized X-entry or pay original outer branches. Its new boundary fee remains to be controlled.

## 4. Qualified-set disagreement is not pure cube boundary

After integrating independent marks at receivers u,w, let c_u,c_w be their cube indicators and b_u,b_w their original source qualifications. The disagreement integrand is

    c_u(1-c_w)b_u+c_w(1-c_u)b_w
                   +c_uc_w(b_u+b_w-2b_ub_w).

The first two are qualified cube-difference parts. The third is a WITHIN-COMMON-CUBE history/mark difference, which cannot be called pure spatial boundary or deleted as overlap. It can be nonzero even for b_u=b_w equal to a fractional constant because the witness marks are independent. Thus Qact and Bact need not be monotone when masks shrink, despite Aact/Oact being monotone. Any R302/R303 geometric-boundary transfer must retain this additional term and all source/clock costs.

## 5. Actual bounded diagnostics and independent verdict

An actual local Python run checked 27 exact Fraction marked prefix-overlap identities, nine exact target first-moment identities, and 27 Poisson atomic rank comparisons at 50-digit precision. The finite cases included fractional, zero and unit qualification masks. All PASS. They verify the mark algebra/normalization, not full original low/m/history or a general endpoint result.

Independent-screen verdict: PASS for the common marked-Poisson bridge, exact original first moment and the stated finite-T internal absorption, including alpha=0, fractional masks, atoms and shared-source quantifiers. Remaining Bact includes history/mark disagreement; no arbitrary original source density, nu<=beta comparison, authorized global X-entry or root closure has been supplied. Await author files and final ledger/evidence comparison; no other files changed.

## 6. Independent cumulative capture-potential screen

For two disjoint receiver-mark blocks of masses J,h>0 and capture profiles A,a with 0<=A<=J,0<=a<=h, write p=A/J,q=a/h and V(J,A)=integral(A-A^2/J)dnu. Direct expansion gives EXACTLY

    V(J+h,A+a)=V(J,A)+V(h,a)
                    +(Jh/(J+h))integral(p-q)^2dnu.

Zero-mass blocks have zero capture and are treated by continuity. Thus the actual cumulative V(r)=Qact(r)/J(r), zero at J=0, is nonnegative and nondecreasing in r. Finite original row mass and source mass, plus 0<=A<=J, give right continuity by dominated convergence; at J tending to zero use V<=J W_nu.

For H>0 the cutoff W_H(r)=1{J(r)>=H}V(r) is nondecreasing and RIGHT-continuous: below H, right continuity of J leaves a positive gap locally; at or above H its indicator remains one. Define W_H(a-)=0. It determines a finite positive Stieltjes measure even if J crosses H continuously. A cutoff crossing may add an auxiliary W jump equal to its full V at that threshold; this is not an original receiver/time jump.

Positive Fubini gives the GENERAL exact identity directly, without a finite-menu limiting argument:

    Bact_H=integral_[a,b]ell(dr)W_H(r)
           =integral_[a,b]s^-n dW_H(s),

because W_H(r)=integral_[a,r]dW_H and ell([s,b])=s^-n. The initial a atom and terminal b atom are included. If J first attains H only at b, W has the corresponding b atom and the identity still gives b^-n V(b). If J(b)<H it is zero. For a finite radius menu with first high index k, this becomes r_k^-n V_k+sum_(i>k)r_i^-n(V_i-V_(i-1)); if there is no high index it is zero.

This is a true monotone cumulative capture-square potential and preserves its cross-negative term by an exact between-block variance identity. It gives no root bound or automatic cancellation of history/mark disagreement, nor any identification with original global time atoms.

Actual local diagnostics before author-potential reading: 54 exact Fraction block decompositions/monotonicity comparisons and six fifty-digit continuous/terminal-cutoff Stieltjes identities passed (the latter include continuous J crossing H and first attainment at b). These are finite algebra diagnostics, distinct from the general proof above.

## 7. Independent high-soft cutoff screen before its author file

The actual common-soft expansion gives p_y(x)=sum_k b_(n,k)(s(x))Q_(k,L(x))(x-y). With F_k(x)=integral Q_(k,L(x))(x-y)beta(dy), original FIRST yields exactly sum_k b_k(s(x))F_k(x)/q(x)<=1. It does NOT give any component FIRST, especially at zero binomial weights. Full-p low/m point heights also cannot be assigned to an individual Q_k merely by relabeling it.

For a frozen source-pair allocation omega and a source-dependent cutoff j(z), the high-k actual positive traffic may instead use b_k<=c_nk and the already paid TWO positive selector envelopes. Soft-coordinate contraction gives the safe source charge

    T_high <=(Dscale/q_-)integral nu(dz) B_omega(z)
                         sum_(k>j(z))c_nk rho_bar^k,
    Dscale=2a^-n-b^-n, B_omega(z)=integral omega(y,z)beta(dy),

for any certified rho_bar>=rho, rho_bar<1. Choosing the smallest j(z) in the finite menu so that each displayed column price is <=epsilon pays epsilon W_nu ONCE. If needed j=n makes the tail zero, so this is existence of a cutoff, not a uniform bound on its size. Measurability is finite threshold testing. The remaining low-k response retains its original binomial weights and one shared FIRST ledger; source-dependent cutoffs must not be summed as repeated full-source copies. This statement screen was saved before reading the secondary author proof.

## 8. Marked-geometry author-file comparison — PASS

Read final /tmp/r304_geometry.md after the independent screens. It explicitly retains exact I0 including aspect, frozen nu_* restriction with qualifications still computed from FULL original sources, alpha=0 and zero rows. The same marked source set is shared for all hard sources. Its source-subset own-scale use does not transfer witness history to the current receiver. The actual rank is dA*, the exact first moment is T, and original FIRST gives T<=A_n W_nu_* for finite-traffic algebra. At H=4d the source coefficient 64lambda d and boundary coefficient four are correct. It does not confuse this internal absorption with a global receiver/X entry. The within-common-cube mark/history term is explicit, includes fractional mark variance and is not declared a monotone physical boundary. No correction is needed.

## 9. Shared-soft tail author-file comparison — PASS

Read /tmp/r304_soft_hard_bridge.md after the independent cutoff screen. Its dimensionless D_scale and d_omega include q_- a^n exactly once. The exact theta decomposition, weighted FIRST and zero-p/zero-binomial-weight cases are correct; no low/m height or FIRST is transferred to an individual component. Both selector envelopes precede convolution and give the point rho^k loss, while the L1 mass remains A_n^2. The finite minimal cutoff and explicit sufficient ceiling formula are valid, including zero column and j=n. The rational rho_bar=19/20 certificate follows from the stated exact Taylor/geometric-tail bound for exp(2). Source cutoff strata charge epsilon W_nu once; the potentially full degree of the low remainder is explicit. No correction is needed.

Provisional author bindings:
- /tmp/r304_geometry.md: 104f4cd774104816e74c3836a9453fe736e9c9c138b8b5067d0a57291cf82d70
- /tmp/r304_soft_hard_bridge.md: c1c250250f1b26f5ef16b1412bc33249baccba3af5c1f1572f3790314346f654

## 10. Joint-potential author-file comparison — PASS

Read /tmp/r304_joint_potential.md after its independent screen. P1 is the exact homogeneous variance decomposition; all zero blocks are handled and the between-block square is an additional nonnegative expense. Right continuity at J=0 follows from V<=J W_nu. W_H is a legitimate monotone right-continuous cutoff potential, and positive Tonelli directly proves the general Stieltjes P2 with initial and terminal atoms. The finite-menu P3 groups tied radii and retains the full crossing value. These are auxiliary radius/cutoff atoms, explicitly not the original initial/deletion random-time expenses. No root estimate, fake negative credit or tree embedding is inferred. No correction is needed.

## 11. Bounded original-ledger and aspect-index verification

Read /tmp/r304_global_ledger.md and /tmp/r304_aspect_atoms_index.md, then directly extracted the key ORIGINAL ZIP member lines listed below. This is a transcription/measure/scope audit, not recertification of historical lemmas or every adopted receipt. Verified: original receiver event and q/FIRST/hard scale context; original dT with outer expectation/leaf/unique-band sum; single Lambda on raw low-pe; separate 2Lambda I/J/D and continuous suffix; genuine deletion jump measure versus continuous future-deleted source measure; exact reverse-sign and once-only negative-credit contract; seed-averaged disjoint terminal source budget; and the orientation-dependent inverse coefficients. The original reduction file's hard-band definition also confirms all-octave hard caps at its SAME original accepted receivers, rather than inferring them from one selected radius.

R123's original assembled display has Lambda T_low, but I_rem,J_rem,D_rem and P_suffix each carry 2Lambda. R128/223 define suffix on the HIGH pe terminal-good x terminal-bad continuous dt/t slot. Thus the R303 and new R304 low-pe,m>M own-scale receipts cannot be placed there without an exact additional bridge. Original jump J_rem is an actual time atom, D_rem is a distinct future-deleted continuous-source term, and the potential's radius atoms do not pay either. R303's 3epsilon W_beta is a source fee, not an epsilon X absorption. R237's probabilities and hard/soft source copies are retained once; stronger nu<=beta is cited only for its exact original coupled construction and is not assumed by the new arbitrary-source theorems.

The whole-event alternative displayed in GENERAL_CURRENT_REDUCTION.md still has its own unpaid R_HP; the inspected excerpts do not identify it with R_out, R_heavy or the later local target. The ledger correctly leaves the original-X connector and full post-receipt adoption/error sum UNCERTIFIED. This is an explicit missing certification, not a proof that no connector can exist elsewhere, and this audit does not claim to have eliminated all historical alternatives. The 19/768 arithmetic matches the old 1/768+1/64+1/128; all older named source coefficients remain dependencies rather than newly proved constants.

One index terminology correction was requested: original R294:223-228 defines TERMINAL-STRIP NORMALIZED SOFT-DENSITY cutoffs tau_large,j and tau_small,j, not a hard-scale theta0 normalization. Its displayed coefficients and orientation labels were otherwise correct. This matters because R295's genuinely different hard-R normalization produces the decreasing c_j^(3n/2) on L>R. Final binding will verify the corrected phrase.

Original source member SHA256 and checked ranges:
- /Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/112/research.zip::proof.md: 8ed304854b418f68b0aefc243328f42699b1cb69317b12b4e968cb6e00dbaaec; checked lines 401-410,819-839
- /Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/123/research.zip::proof.md: c0d7912d8cfe11450c9777d86c7715ef5b00745bac42345a38d3e72786c68e2c; checked lines 1098-1110
- /Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/128/research.zip::proof.md: 14e2d1021fed0379308ad9a8d75a756b3e706742d6343e3c53ba4ccc3275fb12; checked lines 604-634
- /Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/121/research.zip::proof.md: 4e150d90b01257ee576bf76f7bce4b68eb81f9bef32925b998364d75c551427e; checked lines 1516-1532
- /Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/120/research.zip::proof.md: 7519540ea8b69ab8079dbe492e1b96015f837968d9e6a45e46abab75e6f89c89; checked lines 185-213,436-459,621-638
- /Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/223/research.zip::negative_contract.md: 01675c28b8ff31f02fb23a5620fbda84b7a47f5885392d35b91f5dd20b6b3095; checked lines 18-75
- /Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/237/research.zip::source_ledger.md: 2d9479dba286ffff9fa253b3b6008ba1f8f18813de55bd315d493f3b914b6a21; checked lines 1-121
- /Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/244/research.zip::receiver_ledger.md: d9c586f84fcd518784b21f620a09591c8d0c6f91aed9525e932f89e7425c34a3; checked lines 9-27
- /Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/294/research.zip::joint_geometry.md: b79b5962a9ee116fa3cad08ceec714a7a25df88f8a8270bb0652fef6711b0f9c; checked lines 187-207,219-230,250-264
- /Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/295/research.zip::reverse_geometry.md: a46f0b5f0c3d378b2bf3e3867eb77a88cd4bbaab802e0d2ea1602146b1723ccf; checked lines 10-24,54-63
- /Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/296/research.zip::joint_envelope.md: 93ec5151b714646c0202b3e98362b648a23496658b1a0008a8d6ad4e1a8f51ca; checked lines 5-26,56-89
- /Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/115/research.zip::proof.md: 57b0848f4deb48b895de28a82b1459785b89b163d46d21f9acb67e1b64719685; checked lines 120-128
- /Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/289/research.zip::low_pe.md: d1540f1f24482b8e8479e5cbb7f8c32aa4d8fca5babe3cc7e7ebb24088829c9e; checked lines 43-74,98-110
- /Users/zhengzhihao/Desktop/T/output/cube_general_20261003/GENERAL_CURRENT_REDUCTION.md: 606be26dd6b8d0ac662501bdea6768449c3d72f700923e0951ce5ef9c64cc82e; checked original event lines 1-20 and full-event entry lines 155-174

## 12. Final README/LaTeX/ledger/evidence integration — PASS and frozen

Read final /tmp/r304_README.md and r304_research.tex in the requested checkpoint without compiling. Their conclusions, formulas and scope match the three mathematical proofs and the bounded ledger/index. Two necessary textual fixes were applied before this receipt: the LaTeX now explicitly requires 0<=alpha<=1 and I0<=alpha; the index calls R294's quoted terminal-strip tau cutoffs normalized SOFT-density cutoffs, rather than hard-scale theta0 coefficients. Both corrected final bytes were verified. No other mathematical correction is required.

The summary places R304 within original LOW-pe, high-m, aspect-qualified traffic; its marked mask fidelity does not grant the low/m point-height theorem to the high-pe suffix or I/J/D slots. It preserves original low-slot single Lambda, initial/jump/future-deleted measures separately, both once-only negative credits, original named prices and uncertified entrance/adoption list. The historical I3 excerpt itself is stated for n>=512; this audit confirms its transcription and arithmetic, not a new all-dimension version or historical proof of every dependency. A complete original-X connector or global absorption has NOT been certified. Internal exact-T absorption remains exactly that, with finite T guaranteed by original FIRST and source mass.

The Stieltjes potential includes initial, terminal and full crossing cutoff values; its auxiliary radius atoms do not pay original time atoms. The high-soft cutoff preserves one weighted FIRST and one epsilon W_nu source fee, allows j=n and leaves the variable low-degree problem. The actual marked disagreement retains its common-cube qualification/mark component and is not declared monotone or purely spatial. All aspect, source and outer/clock complements remain.

Evidence inspected: geometry rerun log reports 108+504+27+9+54=702 Fraction checks PASS; soft bridge log reports 176 coefficient/tail and 180 cutoff checks. The final frozen marked JSON is PASS with no failures and check-count sum 7793, including 396 marked prefixes and 186 direct-versus-increment Stieltjes identities. Its finite positive-volume s=0 source/receiver models explicitly do not realize the full original low/e/m/history. Source masks and shared-versus-independent mark distinctions are documented; no final exponent is inferred. The added P3 code was inspected: it starts with the WHOLE first high-prefix potential and then sums subsequent weighted increments, matching the analytic threshold-atom identity. Numeric author reports this final run completed; the parent reports completed independent reruns of the two embedded checkers and, at this receipt, an independent staging rerun of the final marked script is in progress. This receipt binds the FINAL completed author JSON and exact script and does not predeclare that ongoing second run's result. Auditor's independent 27 marked overlap/nine first-moment/27 Poisson-rank and 54 potential/six cutoff diagnostics are documented above and were actually executed separately.

Final SHA256 bindings (superseding provisional hashes above):
- /tmp/r304_README.md: 7b6a3e67f3e9bbabd412951f9f21d2aaf7b48ffa58c72d9dd3ad57e1bcde07da
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round304_20261017_final_checkpoint/r304_research.tex: 1686d1328e332c475c3459193f0f84add2026d2419220ad09e173ccd54b17799
- /tmp/r304_geometry.md: 104f4cd774104816e74c3836a9453fe736e9c9c138b8b5067d0a57291cf82d70
- /tmp/r304_joint_potential.md: 603a71fb26872750d4672e437e9c189708ef32c314cda34a2358299d10ace3e7
- /tmp/r304_soft_hard_bridge.md: c1c250250f1b26f5ef16b1412bc33249baccba3af5c1f1572f3790314346f654
- /tmp/r304_global_ledger.md: 0aa633178dc0f018ac9df888623681207076faf2738c85d213b40f366a0518f6
- /tmp/r304_aspect_atoms_index.md: 546f4f56e331a5c933b26550900febd0e67dca2d78d242246d51cd33c582d66e
- /tmp/r304_geometry_checks.py: bb233ef2abecc0c7076c90d8a9a67e2677bf6d967bc918ce7f5d1f563c23e04b
- /tmp/r304_geometry_checks.log: 009c77e801be5358cd5c237ce8d4754aeea8210f48dac94ed910ae9f81d96124
- /tmp/r304_soft_hard_bridge_checks.py: 853d301982f416f894fe12af7b9bdd760f957a020ee3fbf245148feb30b2bfd2
- /tmp/r304_soft_hard_bridge_checks.log: 7df2f56be15c114febc1b3fd36d17122a64c82e10368448300472e4394df835f
- /tmp/r304_marked_checks.py: f1c9adb7ed2e4cec6bc69cc1a8a334b98fbcefb5bf9c4e05d7527faf8b9c09a2
- /tmp/r304_marked_checks.json: 7690936d130b1441fc9a1ebe0f69a7fe14d0dfd86488e2968820b64d59c9f583
- /tmp/r304_marked_checks.md: 2cc0a8e2f338fcc15d02267c7af99623b053ae798a1e2f24b2a23082d5bc540e

Final bounded verdict: PASS after the two stated textual corrections. The original full entry/adoption/coverage ledger, integrated source-linear root cost for marked or unmarked local-heavy incidence, within-common-cube qualification differences, extreme aspects and initial/jump/future-deleted/wide-continuous/global outer slots remain unproved or unpriced as explicitly indexed. No independent-X entry, source-density premise, free component FIRST, time-atom replacement or general weak-type closure was introduced. Audit frozen; no repository/Git/PDF or other author file changed.
