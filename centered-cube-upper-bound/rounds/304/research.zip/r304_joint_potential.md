# R304 — exact cumulative mass/capture-square potential

This is a structural identity for the actual qualified capture in r304_geometry.md, not a root-order estimate. All source restrictions are frozen from the original input; beta, nu, original receiver Lebesgue measure, masks, scales, and outside multipliers remain unchanged.

Fix y and finite nu. For receiver blocks of masses J,h and capture functions 0<=A(z)<=J, 0<=a(z)<=h define

    V(J,A)=integral [A-A^2/J]dnu (J>0), V(0,0)=0.

For J,h>0, with p=A/J and q=a/h, direct expansion proves

    V(J+h,A+a)=V(J,A)+V(h,a)
                       +Jh/(J+h) integral(p-q)^2dnu.       (P1)

Indeed, subtracting the first two terms from the left gives pointwise
A^2/J+a^2/h-(A+a)^2/(J+h)=(hA-Ja)^2/[Jh(J+h)]. A block of zero mass has zero capture, and contributes zero; no division by zero is performed. All terms are nonnegative. This retains the capture-square overlap exactly, rather than bounding two whole source masses separately. The between-block difference is an additional nonnegative expense, not an automatically available saving.

For actual cumulative receiver mass J_y(r) and marked capture A*_yz(r), V_y(r)=Q*_y(r)/J_y(r) when J>0, zero otherwise. Equation (P1) on every two nested prefixes proves V_y is nondecreasing. Finite row/source measures and 0<=A*<=J imply right continuity by dominated convergence. At J=0 use V<=J||nu||. No finite radius menu is assumed.

For H>0 define W_H(r)=1{J_y(r)>=H}V_y(r), with W_H(a-)=0. This is a nonnegative, finite, nondecreasing, right-continuous function. Below threshold, right continuity of J leaves a positive gap for a sufficiently small right interval; at or above threshold, the indicator stays one. Hence W_H defines a positive Stieltjes measure on [a,b], including its initial atom at a.

With ell_n=b^(-n)delta_b+n r^(-n-1)1_(a,b)dr, Tonelli and ell_n([s,b])=s^(-n) give the exact general identity

    B*_H(y)=integral_[a,b] W_H(r)ell_n(dr)
           =integral_[a,b] s^(-n)dW_H(s).                (P2)

Integrating beta(dy) recovers the full qualified incidence fee. This is nonnegative Tonelli, not an exchange of signed divergent terms. If J(b)<H the fee is zero. If first attainment is at b, the b atom contributes b^(-n)V_y(b). If a continuous J crosses H, the cutoff can create an atom of W_H even when the receiver radius measure has no atom.

For a finite radius menu r_1<...<r_m, group all tied radii before defining prefixes. If k is the first index with J_k>=H, then

    B*_H(y)=r_k^(-n)V_k
             +sum_(i>k)r_i^(-n)(V_i-V_(i-1)).         (P3)

Each increment is precisely the within-block term plus between-block square in (P1). The whole threshold-crossing value V_k is retained; it is not replaced by only the fraction of its block beyond H. Empty/zero blocks do not change the potential.

The atoms here are AUXILIARY radius/cutoff atoms. They are not the original stochastic initial term, deletion jumps, or future-deleted-source dissipation. Neither (P2) nor (P3) pays those original integrals. The complete original ledger in r304_global_ledger.md remains binding.

Status: general identities (P1)-(P2) are proved; independent review separately verified their quantifiers and endpoint cases before reading this file. No bound of the form epsilon X+C_epsilon sqrt(n) log^A(n+2)||f||_1 for this potential has been proved. The next substantive problem is to bound its actual source-weighted increments, including the within-common-cube qualification disagreement, using original capacities and overlap jointly. Finite exact cell/shell prefix tests diagnose these identities, not their unknown dimension budget.

Skill use: math-e03-tree-bellman-cross-layer-budget provides mass, zero-block and endpoint accounting discipline only. No external tree Bellman embedding is invoked, because a budget-paying admissible tree has not been established here.
