#!/usr/bin/env python3
"""R304 exact common-mark splitting on true FIRST-coupled positive-cell models."""
import json,random,hashlib,sys
if hasattr(sys,"set_int_max_str_digits"):sys.set_int_max_str_digits(0)
from fractions import Fraction as F
from pathlib import Path
from math import lcm
from decimal import Decimal,localcontext
R=random.Random(30120261018);COUNTS={};FAIL=[]
def ck(ok,label,data):
 COUNTS[label]=COUNTS.get(label,0)+1
 if not ok:FAIL.append({'test':label,'data':data})
def cellvol(h,n):return F(2*h,32)**n
def make(name,n,kind):
 if kind=='disjoint':
  X=[(0,0),(128,0),(256,0)];eh=[1,2,1];ls=[32]*3;rs=[32]*3
  Y=[(v,4) for v in [4,132,260,452]];Z=list(Y)
 elif kind=='chain':
  X=[(-16,0),(0,0),(16,0)];eh=[1,2,1];ls=[32,48,64];rs=[32,32,48]
  Y=[(v,4) for v in [-28,-12,4,20,36,100]];Z=list(Y)
 else:
  X=[(0,0),(16,0),(0,16),(16,16)];eh=[1,2,2,1] if n>=8 else [1,2,1,2]
  ls=[32,48,64,32];rs=[48,32,64,48]
  if kind=='tied':ls=rs=[32]*4
  Y=[(x,y) for x in [-12,4,20,36] for y in [-12,4,20,36]]
  Z=[(-12,-12),(4,4),(20,4),(4,20),(20,20),(36,20),(100,100)]
 if n==1:X=[[x] for x,y in X];Y=[[x] for x,y in Y];Z=[[x] for x,y in Z]
 else:X=[list(v)+[0]*(n-2) for v in X];Y=[list(v)+[4]*(n-2) for v in Y];Z=[list(v)+[4]*(n-2) for v in Z]
 def incidence(points,sides,label):
  A=[]
  for i,(x,s,h) in enumerate(zip(X,sides,eh)):
   row=[]
   for j,z in enumerate(points):
    inside=all(2*(abs(a-b)+h+1)<=s for a,b in zip(x,z));outside=any(2*(abs(a-b)-h-1)>s for a,b in zip(x,z))
    ck(inside or outside,label,{'case':name,'receiver':i,'source_cell':j});row.append(int(inside))
   A.append(row)
  return A
 soft=incidence(Y,ls,'exact_soft_pair_whole_inside_or_outside');hard=incidence(Z,rs,'exact_hard_pair_whole_inside_or_outside')
 for tag,points,hs in [('E',X,eh),('Y',Y,[1]*len(Y)),('Z',Z,[1]*len(Z))]:
  ck(all(any(abs(z[k]-w[k])>=hs[j]+hs[l] for k in range(n)) for j,z in enumerate(points) for l,w in enumerate(points[:j])),'positive_cells_disjoint_'+tag,{'case':name})
 vol=[cellvol(h,n) for h in eh];L=[F(s,32) for s in ls];rr=[F(s,32) for s in rs]
 br=[F(R.randint(1,10),R.randint(1,10)) for _ in Y];vr=[F(R.randint(1,10),R.randint(1,10)) for _ in Z]
 bresp=[sum(v*a for v,a in zip(br,row))/l**n for row,l in zip(soft,L)];bscale=1/max(bresp);beta=[bscale*v for v in br]
 vresp=[sum(v*a for v,a in zip(vr,row))/r**n for row,r in zip(hard,rr)];vscale=4/max(vresp);nu=[vscale*v for v in vr]
 first=[sum(v*a for v,a in zip(beta,row))/l**n for row,l in zip(soft,L)];hardresp=[sum(v*a for v,a in zip(nu,row))/r**n for row,r in zip(hard,rr)]
 for i,(f,h) in enumerate(zip(first,hardresp)):
  ck(f<=1,'actual_FIRST_q1',{'case':name,'receiver':i,'response':str(f)})
  ck(h<=4,'actual_same_radius_hardcap_lambda1',{'case':name,'receiver':i,'response':str(h)})
 I=[sum(vol[i]*soft[i][j]/L[i]**n for i in range(len(X))) for j in range(len(Y))]
 pi=[[vol[i]*soft[i][j]/L[i]**n/ij if ij else F(0) for i in range(len(X))] for j,ij in enumerate(I)]
 ck(sum(b*ij for b,ij in zip(beta,I))==sum(v*f for v,f in zip(vol,first))<=sum(vol),'FIRST_integrated_rowI_identity',{'case':name})
 return {'name':name,'n':n,'X':X,'Ehalf':eh,'Y':Y,'Z':Z,'L':L,'R':rr,'soft':soft,'hard':hard,'vol':vol,'beta':beta,'nu':nu,'first':first,'hardresp':hardresp,'I':I,'pi':pi}

def shell(n):
 delta=F(1,100*n);m=4*n;rr=[1+F(i,m) for i in range(m+1)];vol=[];prev=F(0)
 for r in rr:
  v=(r-2*delta)**n;vol.append(v-prev);prev=v
 ck(all((r-2*delta)/2+delta==r/2 for r in rr),'shell_actual_full_source_inclusion',{'n':n})
 return {'name':'concentric_shell_n'+str(n),'n':n,'vol':vol,'L':rr,'R':rr,'soft':[[1] for r in rr],'hard':[[1] for r in rr],'beta':[F(1)],'nu':[F(4)],'first':[r**(-n) for r in rr],'hardresp':[4*r**(-n) for r in rr],'geometry':{'type':'centered_disjoint_shells','delta':delta,'m':m,'source_side':2*delta,'source_center':0,'receiver_shell_sides':'E0=Q_(1-2delta); Ei=Q_(Li-2delta) minus Q_(L_(i-1)-2delta); Li=Ri=1+i/m'}}
POOL=[F(0),F(1,4),F(1,2),F(1)]
def mark(i,j,z):return POOL[(i+2*j+3*z)%4]
def verify(c):
 n=c['n'];name=c['name'];radii=sorted(set(c['R']+[F(2)]));weights=[r**(-n)-(radii[k+1]**(-n) if k+1<len(radii) else 0) for k,r in enumerate(radii)];layers=[];Wbeta=sum(c['beta']);Wnu=sum(c['nu']);Cmenu=sum(w*r**n for w,r in zip(weights,radii));joint_difference=0;diagonal_positive=0;maxexcess=F(0)
 for i,(first,hard) in enumerate(zip(c['first'],c['hardresp'])):ck(first<=1 and hard<=4,'actual_FIRST_sameR_caps',{'case':name,'i':i})
 for j,beta in enumerate(c['beta']):
  u=[v*c['soft'][i][j]/c['L'][i]**n for i,v in enumerate(c['vol'])]
  common_den=lcm(*(x.denominator for x in u));uint=[x.numerator*(common_den//x.denominator) for x in u]
  for i in range(len(u)):
   # Same witness: exactly integrate its one common mark over all gate breakpoints.
   for z,z2 in [(0,min(1,len(c['nu'])-1)),(0,0)]:
    bz=mark(i,j,z);bz2=mark(i,j,z2);cz=c['hard'][i][z];cz2=c['hard'][i][z2];direct=F(0)
    for left,right in zip(POOL,POOL[1:]):
     mid=(left+right)/2;direct+=(right-left)*cz*cz2*(mid<=bz)*(mid<=bz2)
    common=cz*cz2*min(bz,bz2);independent=cz*cz2*bz*bz2
    ck(direct==common,'same_witness_common_mark_min_gate',{'case':name,'i':i,'j':j,'z':z,'z2':z2})
    joint_difference+=int(common!=independent)
  for r,w in zip(radii,weights):
   ids=[i for i,rr in enumerate(c['R']) if rr<=r];J=sum((u[i] for i in ids),F(0));A=[];Arow=[];Qdirect=F(0);diag=F(0)
   for z,nu in enumerate(c['nu']):
    grouped={e:0 for e in POOL};a=ar=F(0);diag_num=0
    for i in ids:
     e=c['hard'][i][z]*mark(i,j,z);grouped[e]+=uint[i];a+=u[i]*e;ar+=u[i]*c['hard'][i][z];en=int(4*e);diag_num+=uint[i]**2*en*(4-en)
    A.append(a);Arow.append(ar)
    # This is 1/2 integral over independent receiver indices AND independent
    # marks, including i=k. Grouping identical e only accelerates the exact sum.
    Qdirect+=nu*F(sum(ue*uf*(4*int(4*e)+4*int(4*f)-2*int(4*e)*int(4*f)) for e,ue in grouped.items() for f,uf in grouped.items()),32*common_den**2)
    diag+=nu*F(diag_num,16*common_den**2)
   M=sum(v*a for v,a in zip(c['nu'],A));Mrow=sum(v*a for v,a in zip(c['nu'],Arow));Q=J*M-sum(v*a*a for v,a in zip(c['nu'],A));Qrow=J*Mrow-sum(v*a*a for v,a in zip(c['nu'],Arow))
   ck(Q==Qdirect,'direct_independent_mark_pair_Q_including_diagonal',{'case':name,'j':j,'r':str(r)})
   ck(0<=diag<=Q and Qdirect-diag==Q-diag,'positive_diagonal_is_retained',{'case':name,'j':j,'r':str(r)})
   diagonal_positive+=int(diag>0);maxexcess=max(maxexcess,Q-Qrow)
   ck(0<=Q and all(0<=a<=ar<=J for a,ar in zip(A,Arow)),'marked_overlap_ranges_and_row_domination',{'case':name,'j':j})
   layers.append({'j':j,'r':r,'w':w,'beta':beta,'J':J,'A':A,'Arow':Arow,'M':M,'Mrow':Mrow,'Q':Q,'Qrow':Qrow,'diag':diag})
 # Successive prefix blocks, with all equal-radius receivers grouped.
 pooling_count=zero_mass_pooling=0
 def potential(J,A):return sum(v*(a-a*a/J) for v,a in zip(c['nu'],A)) if J else F(0)
 for j in range(len(c['beta'])):
  leftJ=F(0);leftA=[F(0)]*len(c['nu'])
  for layer in [l for l in layers if l['j']==j]:
   J=layer['J'];A=layer['A'];h=J-leftJ;avec=[a-p for a,p in zip(A,leftA)]
   vp=potential(leftJ,leftA);vb=potential(h,avec);vnew=potential(J,A);layer['V']=vnew
   gap=leftJ*h/J*sum(v*(p/leftJ-a/h)**2 for v,p,a in zip(c['nu'],leftA,avec)) if leftJ and h else F(0)
   ck(vnew==vp+vb+gap and min(vnew,vp,vb,gap)>=0,'exact_successive_prefix_pooling_identity',{'case':name,'row':j,'r':str(layer['r'])})
   ck(vnew==(layer['Q']/J if J else 0),'pooling_potential_equals_Q_over_J',{'case':name,'row':j})
   pooling_count+=1;zero_mass_pooling+=int(not leftJ or not h);leftJ=J;leftA=A
  ck(potential(leftJ,leftA)==potential(leftJ,leftA)+potential(F(0),[F(0)]*len(c['nu'])),'explicit_zero_appended_block_pooling',{'case':name,'row':j})
 for r,w in zip(radii,weights):
  for z in range(len(c['nu'])):
   coupled=sum(l['beta']*l['A'][z] for l in layers if l['r']==r)
   ck(coupled<=r**n,'shared_FIRST_marked_column_volume_bound',{'case':name,'r':str(r),'z':z})
 Mtotal=sum(l['beta']*l['w']*l['M'] for l in layers);ck(Mtotal<=Cmenu*Wnu,'shared_FIRST_global_linear_bound',{'case':name})
 js=sorted(set(l['J'] for l in layers if l['J']));mid=js[len(js)//2];Hs=sorted(set([F(1,16),F(1),F(16),js[0],mid,js[-1],mid*F(99,100),mid*F(101,100)]));records=[]
 for d in [F(1,16),F(1),F(16)]:
  for l in layers:
   l['clip']=sum(v*min(d,a) for v,a in zip(c['nu'],l['A']));l['rowclip']=sum(v*min(d,a) for v,a in zip(c['nu'],l['Arow']))
   bound=min(l['M'],(d*l['M']+l['Q'])/l['J']) if l['J'] else 0
   ck(l['clip']<=l['rowclip'] and l['clip']<=bound,'marked_clipped_layer_and_row_domination',{'case':name,'d':str(d),'j':l['j']})
  O=sum(l['beta']*l['w']*l['clip'] for l in layers);Orow=sum(l['beta']*l['w']*l['rowclip'] for l in layers)
  ck(O<=Orow,'exact_Oact_le_Orow',{'case':name,'d':str(d)})
  for H in Hs:
   small=sum(l['beta']*l['w']*l['clip'] for l in layers if l['J']<H);large=O-small;BH=sum(l['beta']*l['w']*l['V'] for l in layers if l['J']>=H);largeM=sum(l['beta']*l['w']*l['M'] for l in layers if l['J']>=H)
   for j in range(len(c['beta'])):
    rowSmall=sum(l['w']*l['M'] for l in layers if l['j']==j and l['J']<H)
    ck(rowSmall<=4*H,'actual_marked_low_prefix_row_budget',{'case':name,'j':j,'H':str(H)})
   ck(small<=4*H*Wbeta,'actual_marked_low_prefix_global_budget',{'case':name,'H':str(H)})
   ck(large<=d/H*largeM+BH,'marked_high_split',{'case':name,'H':str(H)})
   increment=F(0);crossings=0
   for j,beta in enumerate(c['beta']):
    row=[l for l in layers if l['j']==j];selected=[l for l in row if l['J']>=H]
    if not selected:continue
    first=selected[0];increment+=beta*first['r']**(-n)*first['V']
    crossings+=int(any(l['J']<H and l['r']<first['r'] for l in row))
    for left,right in zip(selected,selected[1:]):increment+=beta*right['r']**(-n)*(right['V']-left['V'])
   ck(BH==increment,'exact_marked_Stieltjes_direct_vs_increment_including_threshold_atom',{'case':name,'d':str(d),'H':str(H),'crossing_rows':crossings})
   rhs=4*H*Wbeta+d/H*Cmenu*Wnu+BH;ck(O<=rhs,'marked_full_global_split',{'case':name,'H':str(H)})
   records.append({'d':d,'H':H,'H_equals_J_atom':H in js,'Oact':O,'Orow':Orow,'low_fee':small,'high_fee':large,'BH_act':BH,'Stieltjes_increment_fee':increment,'threshold_crossing_rows':crossings,'RHS':rhs})
 if name.startswith('concentric_shell'):ck(maxexcess>0,'explicit_real_shell_Qact_greater_than_Qrow',{'case':name})
 geometry=c['geometry'] if 'geometry' in c else {'coordinate_denominator':32,'receiver_centers_num':c['X'],'receiver_halfwidth_num':c['Ehalf'],'beta_centers_num':c['Y'],'nu_centers_num':c['Z'],'source_halfwidth_num':1}
 return {'name':name,'n':n,'receiver_count':len(c['vol']),'beta_rows':len(c['beta']),'nu_cells':len(c['nu']),'layer_count':len(layers),'pooling_prefix_tests':pooling_count,'pooling_zero_mass_cases':zero_mass_pooling,'positive_mark_diagonal_layers':diagonal_positive,'same_witness_min_differs_from_product_tests':joint_difference,'layers_where_Qact_gt_Qrow':sum(l['Q']>l['Qrow'] for l in layers),'maximum_Qact_minus_Qrow':maxexcess,'explicit_Q_excess_example':next(({'j':l['j'],'r':l['r'],'J':l['J'],'Qact':l['Q'],'Qrow':l['Qrow'],'pair_diagonal':l['diag']} for l in layers if l['Q']>l['Qrow']),None),'Cmenu':Cmenu,'geometry':geometry,'L':c['L'],'R':c['R'],'receiver_volumes':c['vol'],'beta_masses':c['beta'],'nu_masses':c['nu'],'soft_incidence':c['soft'],'hard_incidence':c['hard'],'records':records}
def encode(x):
 if isinstance(x,F):
  if x.numerator.bit_length()+x.denominator.bit_length()<=1250:return str(x)
  num=abs(x.numerator).to_bytes(max(1,(abs(x.numerator).bit_length()+7)//8),'big')
  den=x.denominator.to_bytes(max(1,(x.denominator.bit_length()+7)//8),'big')
  canonical=bytes([x.numerator<0])+len(num).to_bytes(8,'big')+num+den
  with localcontext() as ctx:
   ctx.prec=60;display=str(Decimal(x.numerator)/Decimal(x.denominator))
  return {'decimal60':display,'exact_rational_binary_sha256':hashlib.sha256(canonical).hexdigest(),'numerator_bits':x.numerator.bit_length(),'denominator_bits':x.denominator.bit_length()}
 raise TypeError(type(x).__name__)

settings=[('initial',[('disjoint_n1',1,'disjoint'),('overlap_chain_n1',1,'chain')]),('atomic_boundary',[('cross_n4',4,'cross'),('tied_n4',4,'tied')]),('expanded',[('cross_n8',8,'cross'),('cross_n16',16,'cross')])]
stages=[{'name':stage,'cases':[verify(make(name,n,kind)) for name,n,kind in specs]} for stage,specs in settings];stages[-1]['cases'] += [verify(shell(n)) for n in [16,32]]
out={'status':'PASS' if not FAIL else 'FAIL','scope':'Genuine finite positive-volume source/receiver cell and shell kernels with actual s=0 FIRST and same-radius hard caps. Frozen b masks are geometry-index diagnostics, not a realization of the original full source-qualified low-m/e_g history. No FULL certificate or general dimension order claim.','serialization':'Fractions with combined numerator/denominator bit length<=1250 are stored exactly. Larger values use60digit decimal display and exact canonical binary rational SHA256: sign byte,8byte bigendian numerator-byte-length,absolute numerator bytes,positive denominator bytes. All checks use full exact arithmetic; rerunning reconstructs every value.', 'mask':'b_ijz=[0,1/4,1/2,1][(i+2j+3z) mod4]. A witness i uses one COMMON uniform mark v for all z; capture eta_i(z,v)=c_iz 1{v<=b_ijz}. Masks are constant on each real L1 source cell.','pooling':'V(J,A)=sum nu(A-A^2/J), V(0,0)=0. Successive equal-radius grouped prefixes satisfy V(J+h,A+a)=V(J,A)+V(h,a)+Jh/(J+h) sum nu(A/J-a/h)^2; zero-mass branches separately handled. This is a joint potential identity, not root payment.', 'pair_mark_distinction':'Qact uses two independent marks for the two receiver copies, including equal receiver indices. E|eta_i(z,v)-eta_k(z,w)|=e_i+e_k-2e_i e_k. Same witness joint-z capture instead uses c_iz c_izprime min(b_ijz,b_ijzprime), not their product.','Stieltjes':'ell_k=r_k^-n,ell_(last+1)=0,V_k=Q_k/J_k. From first k0 with J>=H: sum_(k>=k0)(ell_k-ell_(k+1))V_k=ell_k0 V_k0+sum_(k>k0)ell_k(V_k-V_(k-1)). Includes threshold-crossing initial atom.','split':'Oact<=Orow and Oact<=4H Wbeta+(d/H)Cmenu Wnu+BH_act. Original unmarked J is unchanged; BH_act=sum_(J>=H) beta w Qact/J; Cmenu=sum w r^n.','check_counts':COUNTS,'failures':FAIL,'stages':stages}
base=Path(__file__);base.with_suffix('.json').write_text(json.dumps(out,default=encode,sort_keys=True,indent=2)+'\n');lines=['# R304 common-mark exact diagnostics','',out['scope'],'',out['mask'],'',out['pair_mark_distinction'],'',out['split'],'',out['pooling'],'',out['Stieltjes'],'','|model|layers|positive diagonal|Qact>Qrow layers|common min differs from product|','|---|---:|---:|---:|---:|']
for st in stages:
 for c in st['cases']:lines.append(f"|{c['name']}|{c['layer_count']}|{c['positive_mark_diagonal_layers']}|{c['layers_where_Qact_gt_Qrow']}|{c['same_witness_min_differs_from_product_tests']}|")
lines+=['','All comparisons use Fraction. Very long fractions in JSON use60digit display plus a canonical binary rational hash to keep the file bounded; the script reconstructs all exact values. With explicit original geometry and frozen mask construction in the script/JSON. Common-mark joint capture is checked by partitioning the unit mark interval exactly. Receiver-pair integration groups equal Bernoulli probabilities to retain all diagonal terms efficiently. Real concentric shells supply explicit Qact>Qrow diagnostics, so Qact<=Qrow is not assumed. Original frozen scripts are neither imported nor changed.']
base.with_suffix('.md').write_text('\n'.join(lines)+'\n');print(json.dumps({'status':out['status'],'counts':COUNTS,'failures':FAIL,'cases':[{'name':c['name'],'positive_diagonal':c['positive_mark_diagonal_layers'],'Qact_gt_Qrow':c['layers_where_Qact_gt_Qrow'],'joint_min_not_product':c['same_witness_min_differs_from_product_tests']} for st in stages for c in st['cases']]},indent=2));assert not FAIL,FAIL
