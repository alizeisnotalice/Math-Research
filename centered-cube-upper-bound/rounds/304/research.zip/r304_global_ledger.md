# R304 — complete original ledger restoration before further local claims

**Decision:** The verified later work does not supply a completed original weak-type ledger. Keep the full low-pe, initial, genuine deletion-jump, future-deleted-source, and continuous-suffix slots separate. Tiny source-near is an added restriction, not an inherited support theorem. R303 reduces an actual **low-pe, m>M, aspect-qualified** raw target; it cannot be inserted into RT3's high continuous suffix slot without a new exact reentry identity. The remaining task is to connect and price these original slots, not to relabel one local ancestor as the complete remainder.

Only this file was written; no repository/Git changes, new proof campaign, or counterexample search. The source receipts below are used only in their explicit scopes. Earlier audits are context, not substitutes for original formulas.

## A. Locator convention and original input/entry

Let `R=/Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds`. A locator `123::proof.md:1098` means the line in member `proof.md` of `R/123/research.zip`. These archive members and line numbers were read directly in this audit. Old rounds 112/115/120/121/123 contain only the assembled `proof.md`, so loose source-file line numbers must not be advertised as archive-member locators.

The complete original input is `f>=0`, `W=integral f<infinity`, original Lebesgue receiver measure. Full sides are `a<=L,R<=b<=2a`, common level `3lambda/4<=q<=lambda`. The original hard octave event is `2lambda<G0<=4lambda`, `G0=sup_(a<=R<=b)h_R*f`; it yields the all-scale-in-octave hard cap at original receivers. `X=lambda|E_0|` is the ORIGINAL finite retained receiver event used in the later traffic ledger, not the area of a newly selected local subset. Actual FIRST remains `P_(s(x),L(x))f(x)=q` with its original future upper bounds. See `112::proof.md:401–410`, `128::proof.md:604–611`; the full hard-band ancestry is checked in `244::receiver_ledger.md:9–27`.

A directly displayed full-event entry available outside the late archives is `/Users/zhengzhihao/Desktop/T/output/cube_general_20261003/GENERAL_CURRENT_REDUCTION.md:160–171`:

`lambda|E_band| <= (2C_base+8)sqrt(n)W +(32/3)kappa_n W`

` +(256/3)K_*^2 sqrt(n)W_lo +(64/63)(epsilon+Q_mix)W_hi +(64/63)R_HP`.

Here `K_*` is absolute, `Q_mix=O(sqrt(n)log^2(n+2))`, and `R_HP` is its original high-potential spatial remainder. This is a complete alternative full-event reduction; it is not an identity with `R_out`, `T_small`, or a later local fee. **Missing:** a verified exact original-input connector from this full event, or another fully checked entry, to the later `R_out` ledger with every constant and complementary branch.

The older supplied entrance `X<=2B_paid+(4096/49)R_heavy` appears in `/Users/zhengzhihao/Desktop/T/Math-Research/centered-cube-upper-bound/current_joint_budget_20261007.md:74–89`; the accompanying `阶段研究与数值检验笔记.tex.txt:17–25` explicitly treats its three upstream documents as not yet located/independently certified. This audit does not promote that imported conditional interface to a proved original entry. Nor does it assert `R_HP=R_out=R_heavy` by name.

The all-scale step itself has a precise CONDITIONAL transfer: `289::scale_bridge.md:17–37,49–60` states whole-input octave coefficient `A_n` implies all-scale `C_NT[5+alpha_n ceil(log_2 n) A_n]` with its n=1 convention. Its premise is the completed **whole-input** octave estimate. This does not complete the missing event-to-traffic connector or pay any slot below.

## B. Common original measure and once-only source budget

For each legal original finite common truncation define

`dT =1_{j(x)=j} q^-1 p_y(x) h_R(x-z) a_omega(x,y,z)`

`       dx beta_V(dy)nu_V(dz)`, `p_y=P_(s(x),L(x))(x-y)`, `0<=a_omega<=1`.

Always include `E_omega sum_(V,j)` outside this expression. `a_omega` keeps the actual FULL/FIRST, accepted hard source, original forest/LCA, CP/GP/deep, cut/rank and history gates. The original hard source z never becomes an auxiliary posterior point. `T_small<=4X`. The fixed-before-receiver source posterior is

`Pi_(j,V,y,t)(dv)=1_(Z_t(y))(v)w_t(y,v)nu_V(dv)/e_t(y)`,

`w_t=product_i min(1,[b C(|y_i-v_i|/b)/c_j]/t)`, `e_t=integral_(Z_t)w_t dnu`,

`c_j=(1+1/n)^(-j)`, `g=sqrt(LR)`, `tau=a/c_j`, `J_far=I_(j,V,y) intersect[tau,g exp(-u/n)]`.

Empty/invalid rows are zero before division. At fixed `(omega,V,j,y,t)`, Pi is independent of x and hard z. `Pi_g`, terminal-good/bad sets, actual selectors, source gates and history do not have that independence. References: `128::proof.md:604–650`; `223::negative_contract.md:7–42`.

**Actual source budget:** retained terminal V are disjoint for each whole probability seed, `alpha_V=mu_hi,omega|V`, original hard `nu_V<=sigma_V<=alpha_V`, and coupled soft residual `beta_V<=alpha_V`. Hence `W_beta=E sum_V||beta_V||<=W_hi<=W` and `W_nu<=W`, with the stronger original coupled `nu<=beta` where that exact construction is used. No later theorem needs to invent this stronger ordering. `237::source_ledger.md:81–121` supplies the exact once-only budget, probability-seed averaging, hard five-part partition, and recovery factor. Do not copy W to every j/ancestor/scale. Soft extraction fees cannot be absorbed into the five-part hard-source partition. Additional outer fields or clocks require a verified integrated mass bridge; a fixed-instance receipt does not supply one.

## C. Strongest assembled original remainder ledger

`112::proof.md:819–839` (I3–I4), the coupled replacement in `113::proof.md:350–360` (B36), `114::proof.md:307–340` (S11–S14), and `115::proof.md:174–185` (AR17) give

`R_out <= A_pre + E_pre X + Lambda T_small`, `Lambda=128/119`,

`E_pre=19/768+Lambda(epsilon_tree+delta_tail+k0 kappa_n+epsilon_LP)`,

`A_pre=P104+B105 W_mu+C_h A_far W_hi`

` +Lambda[A_tree W_stop+K_(eta*,r)W_eta*+A_tail(delta_tail)W_light`

` +(C_mix K_s sqrt(n)+C_GP+n^-1+C_n ell_n+Kcal_alpha)W_hi]`.

This retains every earlier named fee, rather than silently deleting it. `19/768=1/768+1/64+1/128`; `epsilon_LP` is the distinct R115 large-parent error. `P104` is explicit in `104::proof.md:825–842`, including its actual source-cap/source-residual partition; `B105=2+3sqrt(n)+log(16/beta^2)`, `beta=1/6144`. `Kcal_alpha` is the complete soft-network coefficient in `113::proof.md:306–315`, with its `O(sqrt(n)log^3 n)` order. The old named GP/tree/hard coefficients remain dependencies; this audit does not independently recertify all historical lemmas behind them.

The FULL assembled decomposition of the next original remainder is `123::proof.md:1098–1109` (G123-current; duplicate A1 at1163–1169):

`Lambda T_small <= E5 X+C_G(epsilon_G)sqrt(n)W_beta+Lambda T_low`

` +2Lambda I_rem+2Lambda J_rem+2Lambda D_rem`

` +2Lambda P_suffix -2Lambda N_Zc-2Lambda N_del`,                 (L)

`E5=epsilon_neartime+epsilon_FA+epsilon_IJ+epsilon_D+epsilon_G`.

The suffix capture version changes in later AC/RC/SP/MA proofs, but the other original slots are not thereby removed. The once-only negative contract and continued independent prefix slots are explicit at `223::negative_contract.md:60–75`; the later K/dependency audit `227::signed_budget.md:103–123` does not certify their full later payment.

**All verified assembled absorption coefficients through this stage add to**

`E_original =19/768+Lambda(epsilon_tree+delta_tail+k0 kappa_n+epsilon_LP)`

`             +epsilon_neartime+epsilon_FA+epsilon_IJ+epsilon_D+epsilon_G`.

These are distinct error slots; `epsilon_G` replaces its older SG/RS/RR-U/UP-E capture receipts rather than adding all historical alternatives. Later actually adopted disjoint receipts would add `E_post=sum_(adopted receipt r)e_r`; **missing:** an authoritative complete adoption/coverage list and exact sum through R303. Do not use an unspecified E_post to claim absorption. R273's alternative Young error, for example, is not automatically added when a direct different source proof is chosen.

R303's `3epsilon W_beta` is a SOURCE PRICE, so contributes **zero** to the `X` coefficient. R300's proposed `4C/N X` absorption is CONDITIONAL on an unproved geometric bound, not an authorized new absorption (`300::r300_geometry.md:34–41,157–180`). Even `E_original<1`, if established from all parameter choices, does not erase positive unpaid integrals or determine the missing original-X entrance multiplier. No complete global alpha<1 is certified here.

## D. ALL original unpaid integral slots, including their different measures

Set `A={p_y e_g>=2Kq}`, `B=D_g={v in Z_g:p_y w_g(v)>KQ_x*(v)}`, `G=Z_g\B`, `E_t=Z_t\Z_g`, `ell_t(v)=Q_x*(v)/(p_y w_t(v))`, `delta_t(v,b)=[k_t(v)-k_t(b)]_+`. Original K is a freely fixed positive threshold; see `289::K_index.md:5–29`. All terms below include the original outer expectation/leaf/unique-band sum and dT.

1. **Low pe, all original source distances:**

`T_low=E sum_(V,j) integral 1_(A^c)dT`.

Its complete original support only gives `||y-z||_1<=17na`, not `r=a/(16sqrt(n))`: `115::proof.md:126`. `289::low_pe.md:43–74` pays the added tiny-near restriction with actual beta FIRST, and its lines98–110 retain the disjoint moderate-m receipt `M C_n ell_n S_n W_beta`, `S_n<4`, on the far portion. The exact remaining original low slot after those two receipts is

`T_low,wide,m>M=integral 1_(A^c)1_{||y-z||_1>r}1_{m>M}dT`,

`m=e_g/[ell_n q c_j^(-n/2)g^n]`.

This is a RAW dx traffic integral: no high factor2, no auxiliary score, no added dt/t. Its original outer multiplier is Lambda once. Later R303 only refines the aspect-qualified portion of this target; see E.

2. **Initial low-test term:**

`I_rem=E sum_(V,j) integral 1_A dT e_tau^-1`

`             integral_(B)1_{ell_tau<B_IJ theta0}w_tau dnu`, `theta0=e_g/e_tau`.

3. **Genuine deletion-jump LOW-test term:**

`J_rem=E sum_(V,j) integral 1_A dT sum_(tau<u<=g, true jumps)`

`        [Pi_u(B)/e_(u-)] integral_(Z_(u-)\Z_u)`

`                      1_{ell_u<B_IJ theta_u}w_u dnu`,

`theta_u=Pi_u(B)e_g/e_(u-)`.

These are exact definitions at `121::proof.md:1516–1532` and `120::proof.md:185–213`. The jump uses an actual time atom; it is not an integral of continuous score dt/t. These auxiliary deleted points acquire no hard-capture gate. Small-source-near domination of some prefix is not an all-distance payment. A complete later settlement of I/J has not been verified here.

4. **Future-deleted-source CONTINUOUS positive term with large dissipation:**

`D_rem=E sum_(V,j) integral 1_A dT 1_{Diss>d_D}`

`       integral_(J_far)dt/t integral_(b in B) integral_(v in E_t)`

`       1_{ell_t(v)<B_FA delta_t(v,b)}delta_t(v,b)dPi_t(v)dPi_t(b)`,

`Diss=e_g^-1 integral_(Z_tau\Z_g)[w_tau(v)-w_h(v)]dnu(v)`.

MG3–MG5 are `120::proof.md:436–459`; decomposition MG22–MG23 at621–638. Here v is **not terminal good**. The moderate dissipation portion is paid to its separate epsilon_D X slot; its large complement is not priceable by a terminal-good certification theorem merely because it has the same score notation. N_del below is a different signed continuous term, not these deletion atoms or a refund for D_rem.

5. **Terminal-surviving, continuous SUFFIX positive term:**

`P_suffix=E sum_(V,j) integral 1_A dT integral_(J_far)dt/t`

`   integral_(v in G,b in B) Psi(v,b) chi_FA(t,v,b) rho_rem(t,v,b)`

`                       delta_t(v,b)dPi_t(v)dPi_t(b)`.

`Psi=1_(Zcal^c)` is the original suffix-failure domain, `chi_FA` the insufficient-test gate, `rho_rem in[0,1]` the exact unspent positive allocation (not merely its support). RT1–RT3 are `128::proof.md:604–633`; current form and score direction are `223::negative_contract.md:18–58`. Negative

`N_Zc=E sum integral 1_A dT integral_(J_far)dt/t`

`        integral_(v in G,b in B)Psi[k_t(b)-k_t(v)]_+ dPi_t(v)dPi_t(b)`

and `N_del` has `v in E_t,b in B` and full `[k_t(b)-k_t(v)]_+`, with NO positive FA/capture/suffix gates wrongly added. The full signed slot is `2Lambda(P_suffix-N_Zc-N_del)`. N_Z was already consumed in the zero-cost suffix deletion and never returns; N_Zc and N_del remain ONCE. All manipulations use common finite truncations before limits, not infinity-minus-infinity.

**Wide-distance/high-continuous complement:** split this last P by `1_{||y-z||_1<=r}` and its complement. The R288 near-source payment only acts on its exact qualified near restriction. It leaves

`P_suffix,wide =P_suffix with 1_{r<||y-z||_1<=17na}`.

R279's small-deficit tail receipt also used the near receiver window and must not be transferred to arbitrary wide y,z (`290::partition.md:69–83`). R256/R257 explicitly introduced a positive near subpart; they did not prove all pairs near (`256::cluster_payment.md:185–205`, `257::actual_bridge.md:195–205`, `257::mixed_geometry.md:223`). Wide low-pe and wide high-continuous are different slots. Split I/J/D by the same source-pair indicator only when useful, retaining both halves until each is actually priced.

## E. Exact R303 insertion — qualified low-pe slot, not RT3 suffix

The primary archived statement is unambiguous: `303::r303_combined_budget.md:3` fixes **low-pe,m>M, aspect v>=v0**, and `302::r302_geometry.md:5–18` supplies those same assumptions. Put `v=min(1,(L/R)^(n/2))`, `kappa0=2K/(ell_n M)`, `psi_inf=3-2/(3gamma^n)`, `d=kappa0 psi_inf/(q_-v0)`, `A_n=1+n log(b/a)`, `H=sqrt(d A_n/(4lambda))`. Keep every original low/m/forbidden/history gate evaluated using full original sources. Let T_303 be the raw low-pe target with all these qualifications; retain `T_low,wide,m>M,v<v0` separately. If T_303 is a positive enlargement of the qualified wide target, its upper estimate is valid by positivity, without falsely making it an exact partition.

R303's proven replacement, lines14–29, is

`T_303 <=2 C_rho L0 W_(nu_l)`

`       +4sqrt(lambda d A_n)(W_beta+W_(nu_h))`

`       +3epsilon303 W_beta+2 B_H^near(D1;nu_h)`.

`rho=1-2 integral_0^1 u exp(-3/(2u))du`, `C_rho=1/(1-rho)`; nu_l/nu_h are frozen original-source restrictions at the stated local beta-mass threshold. Their masses sum to W_nu. Use the EXACT source/receiver tail cutoffs D0,D1 in `303::r303_combined_budget.md:5–11`, not the older tiny-near r. The remaining fee is

`B_H^near=integral beta(dy) ell_n(dr) 1_{J_y(r)>=H}`

`    [1/(2 J_y(r))] integral_(R(u),R(w)<=r; |u-y|inf,|w-y|inf<=D1b)`

`        U_y(u)U_y(w) nu_h(Q_(R(u))(u) Delta Q_(R(w))(w))du dw`,

`U_y(u)=alpha(u,y)1_E(u)p_y(u)/q(u)`, `J_y(r)=integral_(R(u)<=r)U_y(u)du`,

`ell_n(dr)=b^-n delta_b(dr)+n r^(-n-1)1_(a,b)(r)dr`.

The denominator is the **full original J_y**, not the near-only mass. alpha is an actual z-independent dominating original row gate; no auxiliary-node FIRST or cap at source centers is supplied. This is an auxiliary fee in a valid upper bound, not itself an exact remaining raw traffic allocation. It is still unpriced at the target order. `303::r303_geometry.md:7–31,140–164` (section4) and `302::r302_geometry.md:20–69` give the exact bridge and limitations.

At the original low-pe ledger position, multiply this raw bound by the single original Lambda. If applying at more general outer xi instances, retain the stated original positive multiplier inside that outer integral until a verified integrated source-W bridge is supplied. Do not assert a free clock integral; original low-pe itself had no auxiliary clock. **No verified identity was found placing R303 into high RT3 continuous suffix.** It must therefore be inserted into the low-pe qualified target only, unless that additional identity is furnished.

For fixed controlled v0,kappa0, L0=sqrt(A_n) makes the explicit source terms root order; letting v0 become tiny changes d and its price. Therefore the extreme-aspect complement cannot be erased by saying “both orientations are allowed.”

## F. Compact complete status and next decision

After ONLY the verified R289 low-near/moderate-m receipts and the R303 qualified replacement, the original remainder ledger necessarily still displays:

- `Lambda T_low,wide,m>M,v<v0`, plus the R303 `2Lambda B_H^near(D1;nu_h)` fee and its exact integrated source prices;
- `2Lambda I_rem`, `2Lambda J_rem` (actual jump atoms), `2Lambda D_rem` (future-deleted continuous sources), each with any verified later positive subreceipts explicitly subtracted;
- `2Lambda P_suffix,wide`, and any near suffix complement not included in the exact R288 qualified cover;
- `-2Lambda N_Zc-2Lambda N_del` once on the original common measure; already used N_Z never returns;
- the original-X entrance connector, exact old named source prices, and the adopted post-receipt/error sum where not yet verified.

These terms can overlap in source budgets; sum their proved coefficients, never take a maximum without an actual complementary source identity. R303's new source price changes one low-pe branch, not all prefix branches. No all-ancestor/local/global closure follows. The immediate next decision is to establish an explicit complete entry/coverage/adoption ledger and select one of these concrete unpriced integral slots; a further local geometric claim should state which one it pays and what survives.
