# R304 common-mark exact diagnostics

Genuine finite positive-volume source/receiver cell and shell kernels with actual s=0 FIRST and same-radius hard caps. Frozen b masks are geometry-index diagnostics, not a realization of the original full source-qualified low-m/e_g history. No FULL certificate or general dimension order claim.

b_ijz=[0,1/4,1/2,1][(i+2j+3z) mod4]. A witness i uses one COMMON uniform mark v for all z; capture eta_i(z,v)=c_iz 1{v<=b_ijz}. Masks are constant on each real L1 source cell.

Qact uses two independent marks for the two receiver copies, including equal receiver indices. E|eta_i(z,v)-eta_k(z,w)|=e_i+e_k-2e_i e_k. Same witness joint-z capture instead uses c_iz c_izprime min(b_ijz,b_ijzprime), not their product.

Oact<=Orow and Oact<=4H Wbeta+(d/H)Cmenu Wnu+BH_act. Original unmarked J is unchanged; BH_act=sum_(J>=H) beta w Qact/J; Cmenu=sum w r^n.

V(J,A)=sum nu(A-A^2/J), V(0,0)=0. Successive equal-radius grouped prefixes satisfy V(J+h,A+a)=V(J,A)+V(h,a)+Jh/(J+h) sum nu(A/J-a/h)^2; zero-mass branches separately handled. This is a joint potential identity, not root payment.

ell_k=r_k^-n,ell_(last+1)=0,V_k=Q_k/J_k. From first k0 with J>=H: sum_(k>=k0)(ell_k-ell_(k+1))V_k=ell_k0 V_k0+sum_(k>k0)ell_k(V_k-V_(k-1)). Includes threshold-crossing initial atom.

|model|layers|positive diagonal|Qact>Qrow layers|common min differs from product|
|---|---:|---:|---:|---:|
|disjoint_n1|8|2|2|2|
|overlap_chain_n1|18|10|7|6|
|cross_n4|48|24|17|32|
|tied_n4|32|12|14|16|
|cross_n8|48|24|16|32|
|cross_n16|48|24|23|32|
|concentric_shell_n16|65|64|64|64|
|concentric_shell_n32|129|128|128|128|

All comparisons use Fraction. Very long fractions in JSON use60digit display plus a canonical binary rational hash to keep the file bounded; the script reconstructs all exact values. With explicit original geometry and frozen mask construction in the script/JSON. Common-mark joint capture is checked by partitioning the unit mark interval exactly. Receiver-pair integration groups equal Bernoulli probabilities to retain all diagonal terms efficiently. Real concentric shells supply explicit Qact>Qrow diagnostics, so Qact<=Qrow is not assumed. Original frozen scripts are neither imported nor changed.
