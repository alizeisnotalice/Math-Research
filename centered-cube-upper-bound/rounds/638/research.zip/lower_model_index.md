# R638 lower-model source index (bounded history lookup)

Read-only targeted search only; no simulations, proof certification, or repository edits. The three strongest reusable leads are below. They are distinct model families and should not be combined without checking their contracts.

## 1) Direct six-dimensional lattice witness with explicit finite-L1 boundary transfer

**Files:**
- `/Users/zhengzhihao/Desktop/T/Math-Research-cube6-green-audit076/cube-dim-6-bounds/lower/round001_rectangular_certificate.py` — SHA-256 `9072275d47bd66c3ba9ec7de0c435efdba0785c39a02b122ea1ebb960403ec82`.
- `/Users/zhengzhihao/Desktop/T/Math-Research-cube6-green-audit076/cube-dim-6-bounds/lower/round001_transfer_proof.md` — SHA-256 `801a4cc6ffb28c3937b4ef7ccb3862036f261e6bcf885c31f21e75cefb4eebd1`.

**Reusable code:** `main()` enumerates the full product of six count coordinates in `{1,2,3,4}` (`itertools.product`, 4^6 candidate count vectors), constructs same-radius witness boxes and deduplicates/contains them; `box_union()` computes their actual geometric union recursively by coordinate slicing. `root()` and the cached field operations certify algebraic endpoints. This is a lattice witness code, not an orbit/binomial DP: it fully enumerates the fixed six-dimensional count product.

**Model/measure:** The source is a periodic atomic measure on the genuine rectangular product lattice (a_1\mathbb Z\times\cdots\times a_6\mathbb Z), with six unequal algebraic spacings. For each retained count vector, a common radius (r=(\prod_j\ell_j)^{1/6}/2) cube contains the selected block's ∏\ell_j atoms, so its volume equals that selected mass. The certificate reports 127 nonempty candidate boxes, 96 noncontained boxes, and computes the reflected union (rather than summing box volumes); its receiver is a genuine Lebesgue region.

`round001_transfer_proof.md` §§“Passage to a finite Lebesgue L1 input” supplies the especially relevant realization: first shrink the finite set of witness boxes to compact inner boxes with a positive common margin; replace each lattice atom by a compactly supported smooth unit-mass bump smaller than that margin; then truncate receiver fundamental cells to labels `[-K,K]^6` and source atoms to `[-K-2,K+2]^6`. The source mass is `(2K+5)^6`; selected receiver volume is `(2K+1)^6(R-o_delta(1))`. It explicitly protects boundary witness mass, then takes K→∞, delta→0, and lambda↑1. This is an existing complete finite-AC/boundary-truncation template at **n=6**, although the periodic configuration and parameter are fixed to that construction.

## 2) Exact ternary product lattice / corner-block model (large n closed form, tiny n exhaustive)

**Source member:** `rounds/575/research.zip`, SHA-256 `214f4b956d0dee7eee3f2bf88d61c3869badf898c1f6b3a260c3217707e7c06c`; member `repro/ccu_r575_grid_certificate.py`, extracted for inspection to `/tmp/ccu_r638/r575/repro/ccu_r575_grid_certificate.py`, member SHA-256 `bc94575c8f9f1e61a8a5a6672f58eec1e17f10e87698205495c2259d0f280b9a`.

**Reusable code:** top-level exact `Fraction` checks use a closed product formula for each (n\in\{2,3,4,8,16,32,64,128\}); only the (n=2) branch enumerates all 511 nonempty subsets of the nine source atoms and checks actual box intersections. No binomial DP/permutation-orbit implementation is in this file; it compresses the higher-dimensional family analytically and only fully enumerates the small case.

**Model/measure:** the finite source is exactly the (3^n)-point product lattice ({-a,0,a}^n), (a=2-1/(n2^n)), each atom unit weight, (W=3^n). It gives (2^n) actual corner receiver blocks, with exact residual volume (2^{n-n^2}/n^n); central-star and forest costs have exact powers/ratios. The source is an actual finite atomic cube example, with actual geometric receiver cells in the n=2 enumeration and dimension-independent analytic formulas beyond it. This package does **not** supply a finite AC smoothing/boundary-truncation transfer for this ternary model; do not infer one from its atom formulas.

## 3) Explicit finite AC source/capacity plus true receiver-union geometry (small nonhard control)

**Archive:** `/Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/637/research.zip`, SHA-256 `d79a2d287a43ae47d8ad29515beb667098da7011e09b7e434a81c91f1e952cd7`; relevant members `numeric/geometry.py` (inspected extraction SHA-256 `93e3609686e695d48f3c01f98522b8d83d0999691d560cf78acec455655007f2`), `REPORT.tex`, and `audits/geometry_certificate_audit.md`.

**Reusable code:** `geometry.py` functions `box`, `intersect`, `area`, `union`, `mass_at`, and `run(K)` calculate actual rectangles and their unions from exact rational coordinates. `union(bs)` slices the plane into coordinate cells and measures the true union; `mass_at(q,sources)` integrates uniform AC box sources against a query box by intersection-area/source-area. The archive report/audit documents rebuilding membership, positive-area intersections, source rows and receiver union from the actual boxes.

**Model/measure:** this is (n=2,a=64,H=32), five actual macro-centers with K=1,2,4 horizontal clones (5/10/20 old labels). The common old KKT source is a sum of five uniform positive-area boxes; a separate capacity function is a sum of two uniform positive-area boxes. New receivers are real scaled cubes and (V_{new}) is the actual union (not the sum of individual cube volumes). The run records positive updates for selected mixed-scale families and fully AC source/capacity measures.

**Hard-branch boundary:** this is explicitly nonhard: for K=1 the report gives (R=1/2048) and (6PH=12675/64); it does not meet (R>6PH). The audits state the cross-clique fractional hard-family payment remains unresolved. It is useful as a real finite AC geometry/receiver-union harness, not as an R638 hard example.

## What I did not find

No single existing artifact combines (i) exact permutation/orbit/binomial DP over a high-dimensional actual cube lattice, (ii) the R638 complete containment-shift action under the hard condition (R>6PH, a\ge32n), (iii) the true receiver-union measure, and (iv) finite AC/boundary transfer. The closest direct lower construction is the R001 rectangular periodic lattice plus its explicit smoothing/truncation proof; the closest high-n product-symmetric finite source is R575's ternary lattice, but it is atomic and has no bundled AC transfer. R637 supplies AC box-source/receiver mechanics only in a small nonhard geometry. Any abstract binomial/orbit guards found elsewhere in the repo are not by themselves actual cube witness families or actual receiver measures.

These are file-location and scope notes only. Root/Sol should inspect the cited original proofs and receipts before using any model as a mathematical premise.
