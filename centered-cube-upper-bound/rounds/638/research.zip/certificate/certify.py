#!/usr/bin/env python3
import json,sys,time,resource,hashlib,math,itertools,platform
from fractions import Fraction as F
from pathlib import Path
P=Path(__file__).resolve().parent
inp=P/'instance.json';raw=inp.read_bytes();entry=json.loads(raw);assert entry['n']==2 and entry['variant']==4
start=time.monotonic();sys.set_int_max_str_digits(0)
def iv(x):return (x,x) if not isinstance(x,tuple) else x
def add(a,b):a,b=iv(a),iv(b);return a[0]+b[0],a[1]+b[1]
def neg(a):a=iv(a);return -a[1],-a[0]
def sub(a,b):return add(a,neg(b))
def mul(a,b):
 a,b=iv(a),iv(b);z=[x*y for x in a for y in b];return min(z),max(z)
def div(a,b):
 a,b=iv(a),iv(b);assert not b[0]<=0<=b[1]
 return mul(a,(1/b[1],1/b[0]))
def scale(q,a):return mul(F(q),a)
def sqrt_iv(a):
 lo,hi=iv(a);assert lo>0
 def sqfloor(z):return math.isqrt(z.numerator*10**60//z.denominator)
 return F(sqfloor(lo),10**30),F(sqfloor(hi)+1,10**30)
def midpoint(a):return (a[0]+a[1])/2

def box(c,r):return (c[0]-r,c[0]+r,c[1]-r,c[1]+r)
def uni(bs):
 xs=sorted({x for b in bs for x in b[:2]});total=F(0)
 for a,b in zip(xs,xs[1:]):
  seg=sorted((q[2],q[3]) for q in bs if q[0]<b and q[1]>a);acc=F(0);lo=hi=None
  for l,h in seg:
   if lo is None:lo,hi=l,h
   elif l>hi:acc+=hi-lo;lo,hi=l,h
   else:hi=max(hi,h)
  if lo is not None:acc+=hi-lo
  total+=(b-a)*acc
 return total

def maxcliques(boxes):
 patterns=[]
 for mask in range(1,1<<len(boxes)):
  members=[boxes[i] for i in range(len(boxes)) if mask>>i&1]
  gap=[]
  for k in range(2):
   ls=[b[2*k] for b in members];rs=[b[2*k+1] for b in members]
   maxL=(max(t[0] for t in ls),max(t[1] for t in ls));minR=(min(t[0] for t in rs),min(t[1] for t in rs));gap.append(sub(minR,maxL))
  positive=all(g[0]>0 for g in gap);negative=any(g[1]<=0 for g in gap)
  assert positive or negative,('ambiguous intersection',mask,gap)
  if positive:patterns.append(mask)
 return sorted(x for x in patterns if not any(x!=y and x&y==x for y in patterns)),len(patterns)
C=[tuple(map(F,x)) for x in entry['centers']];r=list(map(F,entry['radii']));v=list(map(F,entry['v_exact']));d=[4*t*t for t in r];eps=F(1,64)*F(64,65)**2
old=[box(C[i],r[i]) for i in range(6)];small=[box(C[i],r[i]/64) for i in range(6)];assert all(uni(small[:i+1])-uni(small[:i])==v[i] for i in range(6));V=sum(v)
old_cliques,_=maxcliques([tuple(iv(x) for x in b) for b in old]);assert old_cliques==[3,5,28,48]
# λ=(x,1-x,1-x,x-y,y,1-y).  Two stationarity compatibility equations.
mid=[F(entry['old_diag']['lambda'][0]),F(entry['old_diag']['lambda'][4])];w=F(1,10**24);B=[(u-w,u+w) for u in mid]
def lam(x,y):return [x,sub(1,x),sub(1,x),sub(x,y),y,sub(1,y)]
def mm(l):return [add(d[i],div(eps*v[i],l[i])) for i in range(6)]
def fun(x,y):
 m=mm(lam(x,y));return [add(sub(sub(m[0],m[1]),m[2]),m[3]),sub(sub(m[4],m[3]),m[5])]
def deriv(x,y):
 one_minus_x=sub(1,x);one_minus_y=sub(1,y);delta=sub(x,y)
 a=div(eps*v[0],mul(x,x));b=div(eps*(v[1]+v[2]),mul(one_minus_x,one_minus_x));c=div(eps*v[3],mul(delta,delta));e=div(eps*v[4],mul(y,y));f=div(eps*v[5],mul(one_minus_y,one_minus_y))
 return [[neg(add(add(a,b),c)),c],[c,neg(add(add(e,c),f))]]
J=deriv(*mid);a,b,c,e=J[0][0][0],J[0][1][0],J[1][0][0],J[1][1][0];det=a*e-b*c;assert det!=0
Y=[[e/det,-b/det],[-c/det,a/det]];Jbox=deriv(*B);Fmid=fun(*mid);t=[sub(mid[i],add(mul(Y[i][0],Fmid[0]),mul(Y[i][1],Fmid[1]))) for i in range(2)]
E=[[sub(1 if i==j else 0,add(mul(Y[i][0],Jbox[0][j]),mul(Y[i][1],Jbox[1][j]))) for j in range(2)] for i in range(2)]
norm=max(sum(max(abs(x[0]),abs(x[1])) for x in row) for row in E);assert norm<F(1,10**18)
KB=[]
for i in range(2):
 corr=add(mul(E[i][0],(-w,w)),mul(E[i][1],(-w,w))); z=add(t[i],corr);assert B[i][0]<z[0]<=z[1]<B[i][1];KB.append(z)
l=lam(*B);assert all(z[0]>0 for z in l);m=mm(l);duals=[m[1],sub(m[0],m[1]),m[3],m[5]];assert all(q[0]>0 for q in duals)
# Dual masses distribute uniformly on explicit positive-area old clique rectangles.
source=[]
for mask in old_cliques:
 rows=[old[i] for i in range(6) if mask>>i&1];L=max(q[0] for q in rows);R=min(q[1] for q in rows);B0=max(q[2] for q in rows);T=min(q[3] for q in rows);assert L<R and B0<T
 q=((3*L+R)/4,(L+3*R)/4,(3*B0+T)/4,(B0+3*T)/4);assert all((q[1]<=p[0] or p[1]<=q[0] or q[3]<=p[2] or p[3]<=q[2]) for i,p in enumerate(old) if not(mask>>i&1));source.append(q)
rho=[scale(F(1,2),sqrt_iv(q)) for q in m];delta=[sub(rho[i],r[i]) for i in range(6)];assert all(x[0]>0 for x in delta)
z=entry['best']['z'];assert all(x in (-1.0,1.0) for row in z for x in row)
def rects(shifted):
 stars=[];inn=[];out=[]
 for i in range(6):
  coords=[add(C[i][k],scale(int(z[i][k]),delta[i])) if shifted else iv(C[i][k]) for k in range(2)];rad=rho[i]
  edges=[]
  for k in range(2):edges.extend([sub(coords[k],rad),add(coords[k],rad)])
  stars.append(tuple(edges));radS=scale(F(1,64),rad);e=[]
  for k in range(2):e.extend([sub(coords[k],radS),add(coords[k],radS)])
  inside=(e[0][1],e[1][0],e[2][1],e[3][0]);outside=(e[0][0],e[1][1],e[2][0],e[3][1]);assert inside[0]<inside[1] and inside[2]<inside[3];inn.append(inside);out.append(outside)
 return stars,(uni(inn),uni(out))
raw_stars,rawV=rects(False);shift_stars,shiftV=rects(True)
rawC,nraw=maxcliques(raw_stars);shiftC,nshift=maxcliques(shift_stars);assert rawC==old_cliques and shiftC==old_cliques
Q=(F(0),F(0))
for i in range(6):Q=add(Q,scale(d[i],l[i]))
M=add(Q,eps*V);R=div(V,Q);assert R[1]<1 # Since 6PH > 192, this control is not hard.
diff=sub(shiftV,rawV);assert F(1328743,10**9)<diff[0]<=diff[1]<F(1328744,10**9) and diff[1]-diff[0]<F(1,10**20)
# Same four maximal cliques: λ is primal feasible, clique masses dual feasible,
# and λ·m = Q+eps V = Σ dual masses, giving Qraw=Qshift=M.
assert [sum(1 for i in range(6) if mask>>i&1) for mask in old_cliques]==[2,2,3,2]
def fmt(x):return [str(x[0]),str(x[1])]
result={'status':'PASS','n':2,'variant':4,'root_method':'rational interval contraction; exact preconditioner, strict self-map and infinity norm <1','contraction_norm_upper':str(norm),'root_box':[fmt(x) for x in B],'krawczyk_image':[fmt(x) for x in KB],'positive_old_dual_mass':list(map(fmt,duals)),'source_rectangles':[[str(t) for t in b] for b in source],'old_raw_shift_maximal_cliques':old_cliques,'raw_positive_subsets':nraw,'shift_positive_subsets':nshift,'receiver_union_raw':fmt(rawV),'receiver_union_shift':fmt(shiftV),'difference':fmt(diff),'capacity':'Q_C(raw)=Q_C(shift)=M=Q+eps V exactly, by matching feasible λ and clique source masses','V':str(V),'Q':fmt(Q),'M':fmt(M),'R':fmt(R),'python':sys.version,'platform':platform.platform(),'input_sha256':hashlib.sha256(raw).hexdigest(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'wall_s':time.monotonic()-start,'cpu_s':time.process_time(),'rss_platform_units':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
(P/'result.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS strict improvement lower',float(diff[0]),'upper',float(diff[1]),'norm',float(norm))
