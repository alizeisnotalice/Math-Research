# 真正包含旧星的平移：有限多尺度数值控制

15 个冻结几何（n=2,3,4，各 5 个，N=6）均给出可完成数值解的旧正则化 KKT 系统，且最佳测试平移的 D 高于 raw z=0。以旧 V 归一，数值差约 0.256–0.599；差额在当前机器精度下全部来自真实 receiver union 的增长，而新完整线性 packing 值 Q_C 的最大绝对变化约 7.2e−15。共同平移本身在全部 15 例中给出正数值变化；部分逐标签角点或坐标翻转进一步改善。结果与各个 raw/common/independent/best 的完整向量与分解在 results.json。**这些是非 hard 有限案例的浮点线索，尚非严格正收益证书，也不是维数阶结论。**

旧 family 为三个相邻 group、各两标签，原大星半边长 (11/10,9/10,23/20,19/20,6/5,1)，group 间距依次取 39/20、2、41/20、21/10、43/20；同组中心相距量级 1/(2a)，所以旧小 receiver 有真实部分重叠。每个维数 a=32n、H=32。15 个 family 在实际几何上不同，但 variant 0 和 1 在此测试中具有相同旧 clique、相同数值增益，不能计成两项独立机制证据。每个旧 Aj 的最大 positive-volume clique 通过所有 63 个非空子集以 Fraction 严格枚举；真实有序增量 vj 由包含排除的有理坐标计算，并完整保留。最小权对应的高精度 KKT 系统可重构为同一 μ：在每个带正对偶权的旧最大 clique 的正体积公共交中放相应质量。

对完整旧 clique 系统，用线性规划识别活动集、必要时枚举替代活动集；随后用 80 位 mpmath 求解旧正则化 KKT。三个初步活动集遗漏了真实活跃约束，已拒绝并在显式检查全部 clique 后以其他活动集重算；不把第一次误解作为结果。原有理几何/ε 直接转为高精度，最终 stationarity 数值残差最大 3.65e−53、原约束正向残差为 0（数值意义），但雅可比条件数最大约 1.65e13、最小 λ 可接近 1e−11；所以这些数值残差不能替代有理/区间 KKT 证书。λ 转为双精度后用于后续非线性半径、union 与 LP，也须独立复核。每个 mj=dj+εvj/λj 后构造 ρj=mj^(1/n)/2、δj=ρj−sj，Cj=Q(yj+δj zj,ρj)，||zj||∞≤1，按几何关系始终包含旧 Aj，故同一旧 μ 的合法性不是逐行更换来源。

每个输入比较 raw；3 个共同角点/交错角点；4 个确定逐标签方向；然后对当前最优方向的每个标签/坐标各试一次符号翻转。每个动作都重新计算 Vnew=|∪Cj/a|，使用全子集包含排除，不把各体积之和冒充 union；重新枚举所有新 positive-volume cliques 并对完整线性 packing 用 HiGHS LP 求 Q_C，不把 ν dual 单独当作 τ 上界证书。新半径为浮点，正交和 clique 接触判断为浮点：n=2 variant=0 的最佳动作存在一对 gap 小于 1e−11，标记 near_tangent_pairs=1，需高精度/区间确定；其他最佳动作未触及此阈值。所有 Q_C、union 和 D 仍为浮点，因此即使 near-tangent 标记为0，也只作候选，不可当严格证明。

运行：`OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 /Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python experiment.py > results.json`。Python 3.12.14、SciPy 1.18.1、mpmath 1.3.0；15 个单线程 worker，总 wall 0.798 秒，单进程最大 CPU 0.422 秒，peak RSS 最大 79,740,928 bytes。JSON 保留输入几何、有理 v、各 KKT 对偶、条件数、所有比较动作的代表及变化分解，脚本和结果哈希见 SHA256SUMS。若需将某例作为严格机制证据，应选择远离接触的案例，并独立认证旧 KKT、代数半径所致的所有 clique、完整容量 primal/dual 和 union 的方向性误差；不能只精确化正的浮点差。
