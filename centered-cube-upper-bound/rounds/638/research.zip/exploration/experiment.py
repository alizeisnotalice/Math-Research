#!/usr/bin/env python3
import os,sys,time,json,hashlib,resource,itertools,math
from fractions import Fraction as F
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
import numpy as np
from scipy.optimize import linprog
import mpmath as mp
from scipy import __version__ as SCIPY
mp.mp.dps=80

def union(c,r,n):
 ans=0.0;N=len(r)
 for mask in range(1,1<<N):
  ix=[i for i in range(N) if mask>>i&1];vol=1.0
  for j in range(n):vol*=max(0.,min(c[i][j]+r[i] for i in ix)-max(c[i][j]-r[i] for i in ix))
  ans+=vol if len(ix)%2 else -vol
 return ans
def intersection_rational(c,r,ids,n):
 z=F(1)
 for j in range(n):
  d=min(c[i][j]+r[i] for i in ids)-max(c[i][j]-r[i] for i in ids)
  if d<=0:return F(0)
  z*=d
 return z
def old_v(c,r,n,a):
 v=[]
 for j in range(len(r)):
  vol=F(0)
  for mask in range(1<<j):
   ids=[i for i in range(j) if mask>>i&1]+[j];term=intersection_rational(c,[x/a for x in r],ids,n);vol += (-1 if mask.bit_count()%2 else 1)*term
  v.append(vol)
 return v
def cliques(c,r,n):
 N=len(r);masks=[]
 for mask in range(1,1<<N):
  ix=[i for i in range(N) if mask>>i&1]
  if all(max(float(c[i][j])-float(r[i]) for i in ix)<min(float(c[i][j])+float(r[i]) for i in ix) for j in range(n)):masks.append(mask)
 return [m for m in masks if not any(m!=k and (m&k)==m for k in masks)]
def cliques_exact(c,r,n):
 masks=[mask for mask in range(1,1<<len(r)) if intersection_rational(c,r,[i for i in range(len(r)) if mask>>i&1],n)>0]
 return [m for m in masks if not any(m!=k and m&k==m for k in masks)]
def oldkkt(d,v,eps,A):
 N=len(d);K=A.shape[0];lp=linprog(-np.array(list(map(float,d))),A_ub=A,b_ub=np.ones(K),bounds=(0,None),method='highs');assert lp.success
 lam0=lp.x;dual0=-lp.ineqlin.marginals; initial=tuple(i for i in range(K) if dual0[i]>1e-8)
 def M(q):return mp.mpf(q.numerator)/q.denominator
 cv=[M(eps)*M(z) for z in v];dm=[M(z) for z in d]
 active_sets=[initial]+[x for k in range(1,K+1) for x in itertools.combinations(range(K),k) if x!=initial]
 for active in active_sets:
  if not active:continue
  guess=[]
  for j in range(N):
   slack=sum(mp.mpf(str(dual0[k]))*int(A[k,j]) for k in active)-dm[j]
   guess.append(mp.mpf(str(lam0[j])) if lam0[j]>1e-6 else cv[j]/max(slack,mp.mpf('0.00000001')))
  guess += [max(mp.mpf(str(dual0[k])),mp.mpf('0.00001'))*(1+mp.mpf('1e-7')) for k in active]
  def eq(*x):
   l=x[:N];u=x[N:];return tuple([l[j]*(sum(u[t]*int(A[k,j]) for t,k in enumerate(active))-dm[j])-cv[j] for j in range(N)]+[sum(l[j]*int(A[k,j]) for j in range(N))-1 for k in active])
  try:
   sol=mp.findroot(eq,tuple(guess),tol=mp.mpf('1e-60'),maxsteps=100,solver='mdnewton');lm=list(sol[:N]);mu=list(sol[N:]);
   if min(lm)<=0 or min(mu)<=0:continue
   load=[sum(lm[j]*int(A[k,j]) for j in range(N)) for k in range(K)]
   if max(load)>1+mp.mpf('1e-35'):continue
   station=[dm[j]+cv[j]/lm[j]-sum(mu[t]*int(A[k,j]) for t,k in enumerate(active)) for j in range(N)]
   J=mp.matrix(mp.calculus.optimization.jacobian(mp.mp,eq,tuple(sol)));cond=mp.cond(J)
   return [float(q) for q in lm],{'active_cliques':active,'dual':[str(x) for x in mu],'lambda':[str(x) for x in lm],'stationarity_max':str(max(map(abs,station))),'constraint_max':str(max([max(q-1,mp.mpf(0)) for q in load])),'min_lambda':str(min(lm)),'jacobian_condition':str(cond),'mpmath_dps':mp.mp.dps}
  except (ValueError,ZeroDivisionError,OverflowError):continue
 raise ValueError('no valid high-precision active set')

def case(spec):
 start=time.perf_counter();cpu=time.process_time();n,variant=spec;a=32*n;epsF=F(1,64)/F(a+1,a)**n;eps=float(epsF);N=6;spacing=F(195+5*variant,100);shift=F(1,2*a)
 radii=[F(11,10),F(9,10),F(23,20),F(19,20),F(6,5),F(1)]
 centers=[]
 for g in range(3):
  for h in range(2):centers.append(tuple([g*spacing+h*shift]+[F(h,4*a) if j==1 else F(0) for j in range(1,n)]))
 vf=old_v(centers,radii,n,a)
 if min(vf)<=0:raise ValueError('zero receiver increment')
 v=list(map(float,vf));df=[(2*r)**n for r in radii];d=list(map(float,df));oldcl=cliques_exact(centers,radii,n)
 if len(oldcl)<2:raise ValueError('one old clique only')
 A=np.array([[int(mask>>j&1) for j in range(N)] for mask in oldcl],float)
 lam,diag=oldkkt(df,vf,epsF,A);Q=sum(x*y for x,y in zip(lam,d));V=sum(v);R=V/Q;mr=[d[i]+eps*v[i]/lam[i] for i in range(N)];rho=[x**(1/n)/2 for x in mr];delta=[rho[i]-float(radii[i]) for i in range(N)]
 if min(delta)<-1e-10:raise ValueError('negative expansion')
 def evaluate(z):
  C=[[float(centers[i][j])+delta[i]*z[i][j] for j in range(n)] for i in range(N)]; rr=[r/a for r in rho];Vnew=union(C,rr,n);cl=cliques(C,rho,n);mat=np.array([[int(mask>>j&1) for j in range(N)] for mask in cl],float);dnew=np.array([(2*x)**n for x in rho]);lp=linprog(-dnew,A_ub=mat,b_ub=np.ones(len(cl)),bounds=(0,None),method='highs');assert lp.success;Qc=-lp.fun;near=sum(1 for i in range(N) for j in range(i) if abs(min(min(C[i][t]+rho[i],C[j][t]+rho[j])-max(C[i][t]-rho[i],C[j][t]-rho[j]) for t in range(n)))<1e-11);return {'D':Vnew-R*Qc,'Vnew':Vnew,'Qc':Qc,'cliques':cl,'near_tangent_pairs':near,'z':z}
 zero=[[0.]*n for _ in range(N)];raw=evaluate(zero); candidates=[('raw',raw)]
 for vec in [tuple([1.]*n),tuple([-1.]*n),tuple(1. if j%2==0 else -1. for j in range(n))]:candidates.append(('common',evaluate([list(vec) for _ in range(N)])))
 for q in range(4):
  z=[[1. if ((i*7+j*11+q*3)%5)<2 else -1. for j in range(n)] for i in range(N)];candidates.append(('independent',evaluate(z)))
 best_common=max((x for x in candidates if x[0]=='common'),key=lambda x:x[1]['D']);best_independent=max((x for x in candidates if x[0]=='independent'),key=lambda x:x[1]['D']);best=max(candidates,key=lambda x:x[1]['D']);z=[row[:] for row in best[1]['z']];moves=0
 for i in range(N):
  for j in range(n):
   zt=[row[:] for row in z];zt[i][j]=-zt[i][j] if zt[i][j] else 1.;trial=evaluate(zt);moves+=1
   if trial['D']>best[1]['D']+1e-14*max(V,1e-20):best=('coordinate',trial);z=zt
 out={'n':n,'variant':variant,'N':N,'centers':[[str(x) for x in c] for c in centers],'radii':list(map(str,radii)),'v_exact':list(map(str,vf)),'old_cliques':oldcl,'old_diag':diag,'Q':Q,'V':V,'R':R,'m':mr,'rho':rho,'raw':raw,'best_common':best_common[1],'best_independent':best_independent[1],'best_label':best[0],'best':best[1],'D_improvement':best[1]['D']-raw['D'],'receiver_change':best[1]['Vnew']-raw['Vnew'],'capacity_change':best[1]['Qc']-raw['Qc'],'actions_evaluated':8+moves,'eps':eps,'cpu_s':time.process_time()-cpu,'wall_s':time.perf_counter()-start,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
 return out
def safe(s):
 try:return case(s)
 except Exception as e:return {'n':s[0],'variant':s[1],'error':repr(e)}
if __name__=='__main__':
 start=time.perf_counter();spec=[(n,v) for n in (2,3,4) for v in range(5)];
 if len(sys.argv)>1:spec=spec[:int(sys.argv[1])]
 workers=min(15,len(spec));
 with ProcessPoolExecutor(max_workers=workers) as p:res=list(p.map(safe,spec))
 out={'results':res,'workers':workers,'wall_s':time.perf_counter()-start,'python':sys.version,'scipy':SCIPY,'mpmath':mp.__version__,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()};print(json.dumps(out,indent=2))
