# R638 平移控制：计算方案

目标有限实验而非 hard/维数证明：n=2,3,4，各5个有区别的多尺度 family；N≤8，中心以三个相邻 group 串联，组间距约2.0–2.5、大星半径约0.9–1.2，同组有小尺度间隔约1/a 的 receiver 重叠，半径不全相同。完整 box Helly 正体积共同交从所有非空子集准确枚举，每行真实顺序 receiver 增量由有限并集包含排除计算；若预设族退化为单一共同 clique、零增量或 KKT 残差不合格，记录并停止该例，不以其代替多 clique 竞争。

旧 λ 从完整 maximal-clique 约束解 regularized packing；记录原始可行误差、stationarity、dual complementarity、条件数及 εv/λ 的实际量级。常规浮点在 n=4 的对数小权可能不足，必要时由活动约束高精度 mpmath 重算；不能将数值近似称严格 KKT 证书。用同一个旧 λ 和 mj=dj+εvj/λj 定义 ρj=mj^(1/n)/2、δj=ρj−sj。所有 candidate 平移满足 ||zj||∞≤1，故 Aj⊂Cj、同一旧 μ 自动可达。保留所有标签与尺度。

三阶段、每例先固定旧 family/μ 后分别比较：z=0；共同角点 ±和若干确定低差异方向；逐标签确定独立角点、以及限定轮次的有界坐标优化。每个 z 全量重算真实 Vnew=|∪Cj/a| 和完整线性 packing QC（包含所有新 positive-volume cliques）；D=Vnew−(V/Q)QC，同时记录 Vnew−Vraw 与 QC−Qraw，判断收益来自 receiver 还是 capacity。所有单动作算完整 union 与全部 clique，不把体积和当 union。15个输入并行最多15个单线程进程，BLAS每进程1线程；预估每个 N≤8 需几十至数百次 255 子集测试和 LP，合理预估 1–20 秒/例、总峰 RAM 随实测记录；若精度或规模不可控、仅剩平凡族则停止并记录。数值收益仅作为决策线索，后续需独立证书；不预设收益必正。

执行完成：15/15 候选数值活动集可解；三个最初活动集不满足 inactive clique 的候选被拒后，以完整活动集检验恢复。旧 cliques/receiver increments 用有理正体积枚举，80位 KKT 仅数值，新的 union/packing 为浮点。总 wall 0.798s，worker CPU 最大0.422s，RSS 最大79,740,928 bytes；具体结果/误差/一处近接触标记和复现命令见 REPORT.md 与 results.json。脚本未将有限结果外推到 hard 或根阶。
