#!/usr/bin/env python3
"""Reproduce the exact finite certificate; do not rerun or certify floating exploration."""
from pathlib import Path
import hashlib,json,os,platform,shutil,subprocess,sys,tempfile,time
P=Path(__file__).resolve().parent
receipt=P/'RUN_SUMMARY.json'
receipt.unlink(missing_ok=True)
start=time.perf_counter()
saved=json.loads((P/'certificate/result.json').read_text())
assert saved['input_sha256']==hashlib.sha256((P/'certificate/instance.json').read_bytes()).hexdigest()
assert saved['script_sha256']==hashlib.sha256((P/'certificate/certify.py').read_bytes()).hexdigest()
with tempfile.TemporaryDirectory(prefix='ccu638-verify-') as d:
 q=Path(d)
 for f in ['certify.py','instance.json']:shutil.copy2(P/'certificate'/f,q/f)
 run=subprocess.run([sys.executable,str(q/'certify.py')],cwd=q,text=True,capture_output=True,check=True)
 fresh=json.loads((q/'result.json').read_text())
volatile={'python','platform','wall_s','cpu_s','rss_platform_units'}
keys=sorted(set(saved)-volatile)
assert {k:saved[k] for k in keys}=={k:fresh[k] for k in keys}
assert fresh['status']=='PASS'
ex=json.loads((P/'exploration/results.json').read_text())
assert len(ex['results'])==15 and all('error' not in r for r in ex['results'])
assert ex['script_sha256']==hashlib.sha256((P/'exploration/experiment.py').read_bytes()).hexdigest()
files=['REPORT.tex','certificate/certify.py','certificate/instance.json','certificate/result.json','exploration/experiment.py','exploration/results.json']
report={'status':'PASS','scope':'exact selected n=2 variant4 certificate only; exploration checked for file binding and 15 completed records, NOT re-solved or certified; general bound unproved','interpreter':sys.executable,'python':sys.version,'platform':platform.platform(),'cpu_count':os.cpu_count(),'exact_workers':1,'historical_exploration_workers':ex['workers'],'historical_exploration_wall_s':ex['wall_s'],'exact_math_fields_compared':len(keys),'command':f'{sys.executable} verify.py','stdout':run.stdout.strip(),'wall_s':time.perf_counter()-start,'fresh_certificate_wall_s':fresh['wall_s'],'fresh_certificate_rss_platform_units':fresh['rss_platform_units'],'hashes':{f:hashlib.sha256((P/f).read_bytes()).hexdigest() for f in files}}
receipt.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print('PASS exact certificate; matched',len(keys),'stored fields. Floating sweep not rerun.')
