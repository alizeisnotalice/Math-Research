# R638 整族 LP dual 的量词、稳定性与准确未付桥（Sol high）

**核心结论：** full finite LP 的确避免逐 packet 保每行的过窄限制；但未从旧饱和/新 dual 近饱和推出完整正预算。可严格得到的定量桥是

    T:=S+γ=M−ν·d,
    Kν=Σ_l ν_l[d_l/μ(C_l)]1_{C_l},
    ∫(1−Kν)dμ=T,
    F:=ε^{-1}∫F_old Kνdμ≥V−T/ε.                    (B)

这里 S=M−Q_C，γ=Q_C−ν·d≥0；F_old=Σ_jλ_je_j1_{A_j}≤1，e_j=εv_j/(λ_jm_j)。F 是保留全部旧标签与真实 I_j 的匹配 receiver 质量，不是新小 receiver union。完整 source/geometry 价格见下文。上述是准确稳定性合同，**不计完整预算进展**。

## 1. 精确 dual 身份与量词

先全局选定同一真实 AC 旧 KKT μ，再选一个非空、标签数≤N且对它可行的新 cubes 族 C_l，d_l=|C_l|>0，m_l^C=μ(C_l)≥d_l，s_l=m_l^C−d_l≥0。令 Q_C 为该完整新族的线性 packing 最优值。

有限全部 positive-volume incidence cells 上的 LP 给

    Q_C=max{ν·d:ν≥0,Lν≤1} = min{||τ||1:τ≥0 AC,τ(C_l)≥d_l}.

两边最优均可在有限模型中达到：ν polytope compact；容量质量可摊在实际正体积代表胞腔上。这里无需某个旧 KKT μ 优化 D，也未使用无限维强对偶或原子极限。最优容量 τ 与给新见证的旧 KKT μ 是不同职责的对象。

对每个可行 ν，逐项精确有

    ∫(1−Lν)dμ+Σ_lν_ls_l=M−ν·d.

因此

    S=M−Q_C
      =min_{ν≥0,Lν≤1}[∫(1−Lν)dμ+Σν_ls_l]≥0.       (1)

min 方向正确。full dual允许全部行信用与真实 slack 的共同循环；没有要求每个 source packet 重组后逐行无损。另一方面，(1)本身不构造 μ、新几何或容量节省下界，不能把它称为完整付款。

若使用近最优 ν，令 γ=Q_C−ν·d。两项非负 gap 的和为 T=S+γ。ν达到 dual 最优仅保证 γ=0，**不保证 S 小**，也不自动使 Lν在 μ 上接近1。

## 2. 实际可得的定量 rigidity

旧 Lλ=1 μ-a.e.，新 0≤Lν≤1 μ-a.e.，故

    ||Lλ−Lν||_{L1(μ)}=∫(1−Lν)dμ≤T,
    ||Lλ−Lν||_{L2(μ)}²≤T.

对 θ>0，μ{1−Lν≥θ}≤T/θ。若某些行有相对 slack s_l≥θ m_l^C，则

    Σ_{这些行}ν_lm_l^C≤T/θ.

这些控制只在 μ 的质量和 ν 加权行上成立。没有 μ 的 Lebesgue 密度帽，不能把 μ-小异常集当作 receiver 体积小；ν_l=0 或极小的新行也没有得到未加权 slack 控制，不能从完整 V_new 中删除它们。

精确 S=0 时，任意最优 ν 都满足 Lν=1 μ-a.e. 且每个 ν_l>0 的行 s_l=0。这是共同饱和的有限结构条件，不提供中心距离、半径、receiver overlap 或全族容量根阶控制。S仅小而非零时还必须保留上述定量误差，不能替成逐点精确饱和。

## 3. 把两种 gap 合成一次真实 source 损失

由于 d_l/m_l^C∈(0,1]，定义

    Kν(X)=Σ_lν_l(d_l/m_l^C)1_{C_l}(X).

有 0≤Kν≤Lν≤1，且

    ∫Kνdμ=Σ_lν_ld_l=Q_C−γ,
    ∫(1−Kν)dμ=S+γ=T.                              (2)

这没有把新行 slack 丢掉，而是将它与未覆盖 source 合入一次整体损失。对应真实有限 subtransport 为

    dTν(X,Y,l)=ν_l 1_{C_l}(X)dμ(X)/m_l^C
                      ·1_{C_l}(Y)dY.

其 source 边缘为 Kνμ，target 边缘为 Lν(Y)dY≤dY，总质量 Q_C−γ。给定 l 的 source 是真实 μ|C_l/m_l^C，target 是 C_l 中 Lebesgue uniform，不能将 source 坐标产品化。

**Tν的 target 不是容量证书 τ。** 密度 Lν≤1 的这个 target 一般不满足 τ(C_l)≥d_l；其作用是全局匹配/分析，不是用 dual 下界冒充 primal 上界。

## 4. 全部旧真实 receiver 的匹配：保留 ε 价格

旧完整 source-once potential 为 F_old=Σλ_je_j1_{A_j}≤Lλ≤1，且 ∫F_old dμ=εV。由 (2)，

    F=ε^{-1}∫F_old Kνdμ,
    0≤V−F=ε^{-1}∫F_old(1−Kν)dμ≤T/ε.              (3)

可显式同时保留旧 j、真实 Z∈I_j、新 l、同一 X 和 target Y：

    dJ=ν_l/(m_j m_l^C)·1_{A_j∩C_l}(X)dμ(X)
                      ·1_{I_j}(Z)dZ·1_{C_l}(Y)dY.

它的总质量是 F，旧 receiver 边缘≤1_U(Z)dZ；因此没有逐行重复领取 M。每个 j 的缺失比例为

    ω_j=m_j^{-1}∫_{A_j}(1−Kν)dμ,
    Σ_jv_jω_j=V−F≤T/ε.

所以 Σ_{ω_j≥θ}v_j≤T/(εθ)。如果 T≪εV，绝大多数**真实增量体积**在这种条件来源意义下被匹配；这是比只控制 source 异常集更接近 receiver 的定量结论。

但 J 的 Y 边缘只能直接给

    J_Y≤ε^{-1}Lν(Y)dY≤ε^{-1}dY.

这保留了接回旧 receiver 时的 e_j/ε价格。Y仍位于新**大星**，不是新小 receiver C_l/a；逐标签缩向各中心还会产生真实 a^n Jacobian 及重叠，不能把这个 target 当作 V_new 上的单位容量。旧、新标签、X、全部尺度与 source correlation 都仍在 dJ 中，未得到可删除这些参数的定理。

这一步的形式与既有 source-once 交通相容；它只说明 full dual/slack 如何无 packetwise 限制地进入该交通，不是新几何付款。

## 5. 一个精确定价的充分缺口

先取最优 ν（有限 LP 合法，γ=0），S=M−Q_C，F如(3)，W_miss=V−F≤S/ε。完整目标是

    D=V_new−RQ_C=V_new−RM+RS.

可把需要证明的几何部分准确定位为：对同一旧 family、一次共同选择的 μ及≤N个新见证，是否有统一0<c≤1、C，使

    V_new−RM+(R−c/ε)S ≥ cF−C L_nM.                (G)

若(G)成立，则

    D−cV=[V_new−RM+(R−c/ε)S−cF]
             +cS/ε−cW_miss ≥−C L_nM.

所以(G)确实支付完整 target；它不是要求每 packet 都保每行。hard εR>3保证 R−c/ε>2R/3，故 RS 已有足够价格吸收(3)中的未匹配旧 receiver 体积；**剩余未付的是匹配部分的真实新 receiver 几何与共同容量比较**。

目前旧饱和、dual gap小、packing target≤Lebesgue、source/receiver匹配式，都没有给(G)中 V_new−RM 的下界，也没有消除新小 receiver overlap、重复列或逆质量/尺度价格。不能把(3)或target的单位密度重新命名为(G)。本审没有证明(G)，没有取得完整预算新估计。

若使用近最优 ν，则 W_miss≤(S+γ)/ε，(G)右端还须增加 cγ/ε，或以明确另一项预算支付这笔误差。若最后只给出实际容量 B=||τ||1≥Q_C，真实正向目标还会再少 R(B−Q_C)。这两种 gap 分别有 ε^{-1}、R 的价格，不能因为有限 LP 浮点误差小就无价删除。

## 6. 与 genuine near-extremal receiver geometry 的关系

R635 的纯几何近极值权限适用于该完整新族。若旧 R>S_N−δ，则

    V_new<(R+δ)Q_C,
    D<δQ_C≤δM,
    S<M−V_new/(R+δ).

这些是对全族/全来源共同成立的反向有限约束，没有使任意 μ成为驻点，也不保证S小到可免费应用rigidity。它们与(1)–(3)相容，并不自行给相反的下界。

若(G)能在这种真正 near-extreme 旧族中对**存在的一份**真实 μ及一个完整新族成立（统一c,C），即可按已审余量选δ形成矛盾；不必对每个旧KKT来源成立。μ须先按整个family共同选定，再生成全套新见证/ν/τ与上述交通，不能事后按 X 或 l 各选一个来源。

full LP 去掉了 packetwise 保行的过强充分条件，但没有去掉共同可达性和完整 receiver 几何。也不能从某个新族的 S=0/很小推一般 hard 构造不可能；主目标允许另选 μ和整族新动作。只有找到或排除一个具有(G)所需定量价格的共同选择，才改变完整预算。

## 7. 验证与最终范围

另对 outer 作者发来的 containment-demand 全局 row-credit 身份作了定点量词核验：当新需求确为旧 m_j、同一 μ 由 containment 证明可达，真实 positive clique 容量的“旧 λ 超载减未利用 row 信用”式来自 M=Σλm 的精确展开；其 oversupply/unused 项必须负扣。该实际容量 τ 与本文 dual-associated transport target 不同。此核验没有假定 packetwise 重新保每行，也没有为(G)提供下界，未计作进展。

只用本机 math venv / SymPy 1.14.0，对 matched-row source 质量和第5节完整 deficit 分拆作轻量精确代数检查，残差均0；约0.03秒。没有重复任何历史数值、finite pool、MIP或例子。

最终交付：接受整族 finite dual身份与上述含 slack/gap 的真实 source-once rigidity；明确其适用量词及 ε^{-1}、R、大小 receiver 的价格。**没有得到能支付完整 target 的新定量几何桥；准确未证式是(G)或一个保留相同全部费用的更弱充分联合估计。** 仅写本文件，完成停止。
