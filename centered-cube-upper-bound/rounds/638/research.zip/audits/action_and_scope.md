# R638 独立量词与联合饱和条件卡

已读 CONTRACT 与 PREVIOUS 指定第 1、3、末节。尚未读本轮作者新证明，未做反例扫描、LP 或昂贵实验。当前只核完整目标及 near-S_N 许可范围，等待实际候选。

## 必查短清单

1. **完整量词：** 每个完整 hard old family，只需存在一份共同真实 AC KKT 来源 μ，再由它许可至多 N 个完整新见证与一份实际 AC 容量 τ；所有 c,C,B 统一于 N、尺度、来源和步骤。不能逐 row/packet/source 点另选 μ。
2. **共同可达：** μ 保持全部旧 moments，支撑于旧 Lλ=1；新 demands 必须由同一 μ 同时满足。正体积 cells 的共同分配可以实现 AC，逐行分别可达不能拼接。
3. **两份来源职责：** μ 证明新见证合法；τ 给 capacity 上界 B。新 packing ν 给 capacity 下界/最优值，不能把 ν 的目标当作实际 τ 上证书。τ 可用旧 tight cells 外的新核，不代表 μ 也可搬过去。
4. **完整几何：** 用实际 `Vnew=|∪C_l/a|`；一行允许跨多个 clique 分数付款。不得整行指派、忽略共享行需求、丢掉正体积/slack 或把 gross volume 当 union。
5. **near 许可：** near-S_N 只有完整目标的一侧上帽；“ν 近新 LP 最优”与“μ 近新 capacity dual 最优”是不同命题。任何联合饱和必须给出实际 gap 的定量来源。
6. **有限更新/尺度：** 新族用自己的实际 increments 重算 regularizer，删零行不增标签。非严格见证只能按已有 finite strict recovery 保持已证净 margin；没有净 margin 时不能靠极限创造正增益。不从 KKT 自动补新中心/全外尺度帽或 μ 密度上界。

## 1. 冻结目标与 near 上帽的准确方向

对选定同一 μ 合法的新族，令

\[
d_l'=|C_l|,\quad Q_C=\max_{L_\nu\le1}\sum_l\nu_ld_l',
\quad B=\|\tau\|_1\ge Q_C.
\]

μ 本身也是这份新 capacity 问题的可行来源，故 Q_C≤M。需要构造的是

\[
\boxed{V_{\rm new}-RB\ge cV-C L_nM.}
\]

对 `R>S_N−δ` 的旧完整近极值族，既有权限给

\[
V_{\rm new}-RQ_C<\delta Q_C\le\delta M,
\]

因此也给 `Vnew−RB<δM`。它对每一份合法 μ、每个合法有限更新成立；没有最大值达到、μ 紧性、驻点或微分许可。

该式是一侧上界，B 取很大时更容易成立。它本身不使 τ 最优，也不迫使 Q_C 接近 M。

## 2. 同 μ 的精确 old/new source gap

对任何完整新可行 ν，利用新 witnesses 与旧 Lλ=1 μ-a.e.，有

\[
\boxed{M-\nu\cdot d'
=\int(1-L_\nu)d\mu
 +\sum_l\nu_l[\mu(C_l)-d_l']\ge0.}\tag{G}
\]

第一项也可写成 `∫(Lλ−Lν)dμ`，但只在 μ 的意义下如此；没有全空间 pointwise old/new load 顺序。旧 Lebesgue 价格 `∫Lλdx=Q` 与新 `∫Lνdx=ν·d'`，不能替代 (G) 的 μ 积分，因为 μ 没有密度帽。

(G) 是已有 feasibility 的完整 gap 恒等式，不计新推进。若 ν 正好最优，则 gap 为 M−Q_C；若仅近最优，

\[
M-\nu\cdot d'=(M-Q_C)+(Q_C-\nu\cdot d').
\]

优化精度只控制第二项。即便 ν 完全最优，也不自动使 μ 在新 ν 下近饱和，或使 ν 加权的全部 source row surplus 很小。

对于实际 τ，另外的完整 gap 是

\[
B-\nu\cdot d'
=\int(1-L_\nu)d\tau
 +\sum_l\nu_l[\tau(C_l)-d_l'].
\]

若这份 gap 很小，只能先推出 τ 的新饱和；它不等于 μ 的 gap。将两者混同会把容量搬运误当成旧来源共同可达。

## 3. near-family 真能许可的条件性定量饱和

near 上帽可重排成

\[
M-Q_C\le M-V_{\rm new}/R+\delta M/R.\tag{N}
\]

所以，如果**另有独立证明**的真实 receiver 增长

\[
V_{\rm new}\ge(1-\eta)RM,
\]

并且 `Q_C−ν·d'≤γM`，才可由 (N) 得到

\[
M-\nu\cdot d'\le(\eta+\delta/R+\gamma)M.
\]

这时 (G) 的两个非负项各自受同一 gap 控制，特别对任何 s>0，

\[
\mu\{L_\nu\le1-s\}
\le\frac{\eta+\delta/R+\gamma}{s}M,
\quad
\sum_l\nu_l[\mu(C_l)-d_l']
\le(\eta+\delta/R+\gamma)M.
\]

这是一条合法的**条件桥**，但所需 actual receiver 下界尚未由 near 性给出。若只知 Vnew≥V，(N) 只回到

\[
M-Q_C\le M-Q+\delta M/R=\epsilon V+\delta M/R;
\]

hard 分支 εV/M>3/4，因而不是小 gap。raw gross 增长≥RM 不能代替真实 Vnew，缺额就是完整 overlap/fill/capacity 的预算。

小 gap 也不是最终目标必须采取的机制：显著 capacity 节省本身使 M−Q_C 变大。不能为了得到饱和而未经证明排除这种合法分数循环。必须比较节省和真实 receiver 缺额，而不是预设二者中的某一个小。

## 4. 本轮真正需要的新含量

记实际容量节省 `Sτ=M−B`（一般可为负）。完整目标等价于实际可达构造满足

\[
\boxed{S_\tau\ge M-V_{\rm new}/R+
[cV-CL_nM]/R.}
\]

最优新容量节省 S*=M−Q_C 只满足 near 的相反上帽

\[
S_*\le M-V_{\rm new}/R+\delta M/R.
\]

这两式不是新估计，而是准确定位矛盾需要打破的**共同节省/receiver 几何比较**。现有 old tight support、near-S_N、ν 的近最优性、有限 Farkas 表示或 Helly 可达点，均未证明可实现的 fractional circulation 能越过该缺额并留下统一正 cV。

若作者提议从“old Lλ=1 + new ν near max”直接得 receiver 排斥/小 overlap，必须先给 (G) 的小 gap 来源，或给不依赖小 gap 的同一完整 tradeoff 估计；否则决定性缺口就在这里。ν_l=0 的 rows、跨 clique 共享需求、μ 与 τ 的不同可达区域和所有尺度都需保留。

## 5. 当前核验范围与停止点

本机 math venv 的 SymPy 1.14.0 轻量核验三胞腔、两行形式下的完整 source-gap 恒等式，以及 `Vnew−R(M−S)=Vnew−RM+RS`，残差均为 0。没有具体几何扫描或新 LP，恒等式不登记预算进展。

**当前没有实际候选可判证明通过/失败。所能确认的是条件式 (N) 与 (G)；缺失的是其 receiver-growth 前提或另一份完整 fractional saving 几何估计。条件卡完成，停止等待 root/作者新候选。**

## 6. 新 candidate：保留旧星的全族独立平移动作

已收到主代理新动作定义，但尚无收益证明。以下只审合法性、全族界和原目标回代，不声称存在有利平移。

旧 A_j=Q(y_j,s_j)，令

\[
\rho_j=m_j^{1/n}/2\ge s_j,\quad\delta_j=\rho_j-s_j,\quad
h_j=\delta_jz_j,\quad z_j\in[-1,1]^n,
\]

\[
C_j(z_j)=Q(y_j+h_j,\rho_j),\quad |C_j|=m_j.
\]

对每个旧星点 x，逐坐标有

\[
|x_i-y_{j,i}-h_{j,i}|<s_j+|h_{j,i}|\le s_j+\delta_j=\rho_j.
\]

因此 **包括 z_j 在边界时** 也有 A_j⊂C_j。对任意一次整族向量 `(z_1,…,z_N)`，同一份旧 KKT μ 同时满足

\[
\boxed{\mu(C_j(z_j))\ge\mu(A_j)=m_j=|C_j(z_j)|\quad\forall j.}
\]

这里“独立 z_j”只表示允许 Cartesian-product 动作空间，不是来源坐标或需求的概率独立。必须在抽样/收费之前固定同一整族动作；不能对每个收费来源另选 tuple。

m_j 在旧 KKT 来源类内固定，所以 ρ_j、δ_j、动作空间及其纯几何目标均不随该类内 μ 的选择改变。这个受限 candidate 的共同可达性对每一份合法旧 μ 自动成立；source 选择不能单独提高其几何目标。

动作只提供非严格 witness 质量下界。它不自动提供新中心属于 {Mμ>1}、canonical 最后坏半径或全未来帽；若收益证明使用这些额外性质，须另证。冻结目标本身允许 ≥，故该限制不影响其当前合法性。

## 7. 实际 receiver 位置与可保留的全族界

真实新 receiver 是

\[
\boxed{C_j/a=Q(y_j+\delta_jz_j,\rho_j/a).}
\]

其中心位移是 δ_j z_j，**不能除以 a**。δ_j>0 时，旧 B_j=Q(y_j,s_j/a) 包含于该新 receiver 的充要条件是

\[
\delta_j\|z_j\|_\infty+s_j/a\le\rho_j/a
\iff\|z_j\|_\infty\le1/a.
\]

所以一般动作不提供旧 receiver 的逐行包含，也不能默认 Vnew≥V。所有比较必须使用这个真实新中心算 union。R636 的“中心固定、共同半径放大、packing 平台”负号结论不能直接移到当前各中心独立平移的动作。

对每个整族 tuple，始终保留以下安全界。记 `m_max=max_jm_j`：

\[
\frac{m_{\max}}{a^n}\le V_{\rm new}(z)
\le\frac1{a^n}\sum_jm_j.
\]

还可保留有实际位置的共同外包：

\[
\bigcup_j C_j/a
\subset\bigcup_jQ(y_j,\delta_j+\rho_j/a).
\]

因 C_j⊃A_j，新 packing polytope P_C⊂P_old。对所有 ν∈P_old，旧同 μ 给 `ν·m≤M`，且旧 λ 达到 `λ·m=M`，所以

\[
\max_{\nu\in P_{\rm old}}\nu\cdot m=M,
\qquad
\boxed{m_{\max}\le Q_{\rm lin}(C(z))\le M.}
\]

下界由只取最大一行权 1 得到。旧 λ 不必在 P_C 中可行；不能把 λ·m=M 当作新 capacity 的下界。也不能比较 Qlin(C) 与旧 Q 的一般大小。

因此对完整净目标 `Φ(z)=Vnew(z)−R Qlin(C(z))`，全族可确认的粗界为

\[
\frac{m_{\max}}{a^n}-RM
\le\Phi(z)
\le\frac{\sum_jm_j}{a^n}-Rm_{\max}.
\]

这些界没有固定正号，不证明也不否定存在有利整族 tuple。

## 8. 新目标确实回代原全族目标，计数与容量没有替换

候选是：对每个完整 hard 旧族，存在一份全族 tuple z，使

\[
\boxed{\Phi(z)\ge cV-CL_nM.}
\]

若真的证明，它是原同族目标的合法充分形式：新族每旧标签一个 cube，故≤N；同 μ 所有 witnesses 同时合法；完整 receiver 用第 7 节实际 union。

新 linear capacity 可在这个有限族的全部 faces 正体积 cells 上精确表示为有限 LP。μ 提供可行质量≤M；对偶就是完整 packing Qlin(C)。该已冻结有限 LP 的最优 AC 容量可以把各正体积 cell 的最优质量均匀摊开实现，因此存在实际 τ 满足 `||τ||=Qlin(C)`。这只使用有限正体积模型，不把 ν 的单份下界当上证书，也不调用无限维强对偶。若只给一个近优 τ，须把 `R(||τ||−Qlin(C))` 实际扣回净 margin。

计算新 ratio/调用 S_N 时，用**新真实中心、新 cubes 的实际顺序 increments**；删零增量后≤N、union 至零测不变。reduced capacity 不超过完整 capacity，所以删除零行不损失上述 Φ 下界。

对 near family `R>S_N−δ`，同样对每一个完整 tuple 有

\[
\Phi(z)<\delta Q_{\rm lin}(C(z))\le\delta M.
\]

证明入口是新 regularized linear part≤新 reduced linear optimum≤完整 Qlin(C)，而不是把旧 λ、旧 increments 或名义中心代进新问题。没有达到性或驻点许可。

若作者给出统一正净 margin，便可选择 δ 更小而回代矛盾；目前尚无这样的收益证明。动作的共同合法性没有独立推出 fractional capacity saving 或真实 receiver 增长。

## 9. 新动作最终审核状态

本机 SymPy 轻量检查包含 margin 为 `δ_j(1−||z_j||∞)`，receiver 包含 margin 为 `δ_j(1/a−||z_j||∞)`，以及同族 saving 账的代数残差 0。未与 Terra 重复任何几何或 LP 计算。

**通过：** 全族动作对同一 μ 同时合法、真实中心与≤N计数、一般全族上下界、有限实际 AC 容量回代、near-S_N 一侧上帽。

**未证明：** 存在整族 z 获得所需正 Φ。仍需一个对真实 receiver union 和完整 fractional 新容量同时有效的统一收益估计；不能由包含旧大星或独立动作自由度直接推断。

已完成指定 candidate 的独立接口审查，停止等待收益证明。

## 10. 动作专属严格端点恢复：独立审核通过

本节只按主代理新命题独立推理，未读作者新稿。记 η=0 为第 6 节的平移端点。对 0<η<1 定义

\[
C_j^\eta=Q\bigl(y_j+(1-\eta)\delta_jz_j,\ s_j+(1-\eta)\delta_j\bigr).
\]

**该恢复成立，适用于所有 z_j∈[-1,1]^n（包括边界）。** 它是同步回收中心位移与半径增量，不是固定新中心的 generic 缩半径。

### 10.1 同一来源的逐行严格合法性

当前合同 v_j>0、ε>0、λ_j>0、d_j>0，因此 m_j>d_j，ρ_j>s_j，确有 δ_j>0；不存在 δ_j=0 的当前 row。若将来另保留 v_j=0 行，该行不能靠本招获得 strict，须先按合同删零行或另证。

令 u=1−η。中心位移各坐标≤uδ_j，而半径是 s_j+uδ_j，所以旧 A_j 仍包含于 C_j^η，包括 z 的极端边界。另一方面

\[
|C_j^\eta|=[2(s_j+(1-\eta)\delta_j)]^n
<[2(s_j+\delta_j)]^n=m_j.
\]

因此同一份固定真实 μ 同时严格满足

\[
\boxed{\mu(C_j^\eta)\ge\mu(A_j)=m_j>|C_j^\eta|\quad\forall j.}
\]

不改变旧 source 或其任何 moment，不需要 μ 产品性、密度帽或来源极限。

### 10.2 大星一侧嵌套，正体积 clique 最终完全稳定

第 i 坐标端点写作

\[
\ell_{ji}(u)=y_{j,i}-s_j+u\delta_j(z_{j,i}-1),
\quad r_{ji}(u)=y_{j,i}+s_j+u\delta_j(z_{j,i}+1).
\]

z_i∈[−1,1] 给 lower 随 u 非增、upper 随 u 非减。因此 η↓0 时，大星嵌套增加到 C_j^0；端点 z_i=±1 仅让相应一个面固定，不破坏包含或极限。

若端点某个 finite clique 的开方体共同交有正体积，则可取交内点及严格坐标余量，η 足够小时仍在全部 C_j^η 内。端点无正体积的 clique 不可能在子集 C_j^η 中突然出现。有限标签只有有限个 cliques，所以存在 η0>0，使全部 0<η<η0 的正体积 clique 约束与端点完全相同。仅闭边界接触、零体积核不加入；不需 generic position 或横截假设。

对 axis-parallel open cubes，也可用有限 pair 图加 Helly 得同样结论。因而 packing polytope 最终严格相同，而不只是某一份最优 ν 可行。

### 10.3 容量目标与真实 receiver union 的极限

记 d_j^η=|C_j^η|，Qlinη 为完整新族 linear 最优值。稳定区间内 polytope=P0⊂[0,1]^N，d_j^η↑m_j，故

\[
0\le Q_{\rm lin,0}-Q_{\rm lin,\eta}
\le\sum_j(m_j-d_j^\eta)\longrightarrow0.
\]

小 receiver `C_j^η/a` 的中心仍为 `y_j+(1−η)δ_jz_j`，半径为 `[s_j+(1−η)δ_j]/a`，所以它们一般**不嵌套**。但有限盒端点连续，每盒 symmetric difference 的 Lebesgue 体积趋零，遂

\[
|V_\eta-V_0|
\le\sum_j|(C_j^\eta/a)\triangle(C_j^0/a)|\longrightarrow0.
\]

因此完整物理目标确有

\[
\boxed{D_\eta:=V_\eta-RQ_{\rm lin,\eta}\longrightarrow
D_0:=V_0-RQ_{\rm lin,0}.}
\]

这里没有将 receiver 按名义旧中心重放，也没有用 gross volume 代真实 union。

### 10.4 正净 margin 可保留；不需要来源/容量的原子闭包

若端点已证明 D0≥g>0，则可取有限而实际的 η>0 使 Dη≥g/2。更一般，已证统一 target `D0≥cV−CLnM` 时可把允许误差取为 cV/2，得到 `Dη≥(c/2)V−CLnM`；在已知 hard 参数使右端严格正的情形，正增益保留。η 可依赖这份 finite family，不造成新的维数/尺度常数。

这不在 D0=0 或尚未证明净 margin 时创造正值。

新容量须按收缩后的真实 finite cells 重建；不声称端点那份 τ 直接限制后仍满足新全部 demands。有限正体积 cell 模型可实现实际 AC 最优/任意近优容量，且 Qlinη→Qlin0，故没有必要令 τ 的密度或来源 μ 收敛到原子。若端点首先给的是某实际 τ0 的正目标，Qlin0≤||τ0|| 已保证 linear 端点目标至少同样正，再取 η 后的实际最优/近优 AC τ 即可。

### 10.5 原 λ、标签数与有限终端不被偷换

旧 λ 始终只是旧 KKT 来源的固定参数。新 strict family 用自己的真实中心、半径和顺序 increments 重算新 regularized 权；不要求新 λ 随 η 收敛，不把旧 λ 当成新 packing。

每个 η 仍至多 N 个标签。按该 η 的真实 receiver 顺序删零增量，union 测度不变、标签不增加，reduced linear capacity 不超过完整 Qlinη，新 regularized linear part≤reduced capacity。故正 Dη 能按已有 near-S_N/固定 N 终端接口回代。此处没有额外的标签、尺度或 log 损失。

**最终判定：该动作专属端点 strict 恢复完全通过；任何已证严格正完整更新可保留（必要时统一常数减半）。全局有利平移/容量节省预算仍未证明。**

本机 SymPy 轻量核验了两坐标端点差的因式分解及端点半径差 ηδ；嵌套符号、finite clique 稳定与 union/capacity 连续性以上述解析证明完成。没有读取作者新稿、没有重复 Terra 计算。完成追加，停止待命。
