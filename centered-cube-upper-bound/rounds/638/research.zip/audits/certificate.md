# R638 variant 4 有限证书数学整合独审（Sol high）

对象：`certificate/certify.py`、`instance.json`、`REPORT.md`、`result.json`。本审核数学推论，不把程序 PASS 当作证明。没有改作者文件、仓库或 Git，没有启动扫描/代理。

**结论：在冻结的 n=2、a=64、H=32、ε=64/4225 参数下，证书成立；未发现实质逻辑错误。** 它认证一份真实旧 AC KKT 来源、raw 与 shifted 的完整新线性容量均恰为 M，以及严格正的 shifted-minus-raw receiver/deficit 差。该实例非 hard；不认证一般目标、canonical radii 或整个动作池最优。

## 1. 真实旧几何与降维 KKT

代码从确切 rational centers/radii 构造旧大星，且用精确 x-sweep 检查所有六个真实顺序增量 v_j，未用逐 cube 体积代替重叠后的 increments。全部63个非空子集按每坐标严格交长分类，旧 maximal positive-volume cliques 为

    3={0,1}, 5={0,2}, 28={2,3,4}, 48={4,5}.

四个 tight 约束确等价于

    λ=(x,1−x,1−x,x−y,y,1−y).

所有其余 cliques 是这些 maximal cliques 的子集；只要 λ>0，上述 tight 等式便给全部 packing 可行性。

设 g_j=d_j+εv_j/λ_j。四个 clique-source masses 取

    a=g1, b=g0−g1, c=g3, e=g5.

其 incidence 分别要求

    g0=a+b, g1=a, g2=b+c, g3=c, g4=c+e, g5=e.

所以唯一额外 compatibility equations 正是代码的

    F1=g0−g1−g2+g3=0,
    F2=g4−g3−g5=0.

没有漏掉其他 stationarity row。令

    A=εv0/x²,
    B=ε(v1+v2)/(1−x)²,
    C=εv3/(x−y)²,
    E=εv4/y²,
    F=εv5/(1−y)²,

则 Jacobian 恰为

    DF=[−A−B−C, C; C, −E−C−F].

代码各符号和分母正确；这不是拿浮点最优 λ 直接当作精确 KKT。

## 2. rational interval contraction 真正证明了什么

B 是关于输入数值中心 (x0,y0) 的 rational 闭 box，半径10^-24。输入小数只用作该 box 的中心；F、DF、preconditioner Y 都用 Fraction 精确计算。Y 是 midpoint Jacobian 的确切逆，det≠0 已验证。

代码分析的是映射

    T(z)=z−YF(z).

`E=I−Y DF(B)` 是其导数的包含区间，计算的 infinity row-sum bound 严格小于10^-18。又用 mean-value 包含

    T(B)⊂z0−YF(z0)+(I−Y DF(B))(B−z0)

得到严格自映射。所有 λ 分量在整个 B 有正下界，因此 F 在 B 上光滑、分母不跨0。闭 box 完备，故 Banach contraction 给 B 内一个且仅一个 fixed point；Y 可逆使其等价于 F=0。

这是存在唯一性证书，而非“小 residual”或单纯区间 Newton 排除。唯一性首先是该 box 内的 compatibility root 唯一；下面的正 KKT 与严格凹性再给全域正则最优 λ 唯一，未宣称所有无约束 compatibility roots 全局唯一。

所有六个 λ 和四个 clique masses 都有严格正 interval 下界。由旧 packing 可行、tight 支持和 stationarity，F的唯一 root 给完整非负 KKT；目标 Hessian 为 −εdiag(v/λ²) 严格负定，所以这是整个 packing polytope 上的唯一正正则最优解，边界 λ_j=0 因 v_j>0 使 barrier 趋−∞。

## 3. 一份真实 AC μ，而非独立 interval 端点拼接

每个旧 maximal clique 都有代码明确构造的 rational 正面积小矩形，位于该 clique 全交内部，且与每个未入 clique 的旧星内部不交。四个正 mass a,b,c,e 均匀摊在对应矩形上，得到一份实际非负 L1 来源 μ。

这里 masses 是同一个已证明存在的 exact root 的函数；不能任意挑各 interval 的端点当成独立的“可行 mass”。使用同一个 root 时，上述 compatibility 保证全部六行 μ(A_j)=g_j 同时成立，且源支撑处 Lλ=1。于是

    μ(R²)=a+b+c+e=Σλ_jg_j=Q+εV=M.

没有使用原子极限，没有逐行/逐 clique 另领一份 M，也没有假定最优旧来源存在。该 source 是显式正矩形上的 AC 实现。

## 4. raw 与 shift 可达性、cliques 与真实容量

实际新半径为 ρ_j=√g_j/2，故新面积4ρ_j²=g_j。旧 g_j>d_j=4r_j² 给 ρ_j>r_j。raw 中心不变；shift 中心为

    y'_j=y_j+z_j(ρ_j−r_j),  z_ji∈{−1,1}.

因此 ||y'_j−y_j||∞=ρ_j−r_j，旧 open star 满足 A_j⊂C_j。即使 z_i在允许的端点，开 cube 仍由 |x−y_j|<r_j 严格推出 |x−y'_j|<ρ_j。所以同一 μ 同时给

    μ(C_j)≥μ(A_j)=g_j=|C_j|.

这只是非严格见证；证书正确没有宣称这些半径是 canonical 或可一般缩半径恢复 strict。

对 raw 与 shift，代码对全部63个子集用 outward intervals 判定：每个坐标交长下界>0 则真 positive clique；某个坐标交长上界≤0 则无正体积交。无法决定时会报错而非猜测。两族的 maximal cliques 均仍为3,5,28,48，因此真实新 packing polytope 与旧相同。

**Qraw=Qshift=M 并非单凭 clique 名称相同。** 还须同时使用新需求 d'_j=g_j 和同一 μ 的 containment 可达性：

- 旧 λ 在每个新 polytope 可行，目标 Σλ_jd'_j=Σλ_jg_j=M，故 Qnew≥M。
- 同一实际 AC μ 是每个新族的容量上证书，总质量 M，故 Qnew≤M。

两边配合才给 Qraw=Qshift=M。也可将同四个 clique masses 放在对应真实新公共核内证明上界。代码/报告具备这些条件，未拿 packing 下界单独当容量上界。

各族仍只有原六个 labels；后续若有新零 receiver increment，可删去而保 union 至零测并按已有规则比较完整线性容量。本证书当前直接保留完整六行，未借删行降低所称完整 Qnew。

## 5. sqrt、receiver enclosure 与差额方向

`sqrt_iv` 对正 rational m 使用 exact integer floor 给 sqrt(m) 的上下界；上界再加10^-30，向外性正确。对任一实际 center/radius：

- inner rectangle 的 left 用 actual-left interval 上端、right 用 actual-right interval 下端；
- outer rectangle 反用 left 下端、right 上端。

因此每个 inner⊂真实 receiver⊂outer；centers 与 radii 的相关性虽然被区间放宽，但只会使包含更保守。代码实际 receiver 半径是 ρ_j/64，中心仍是对应新 star 中心，没有错误地把中心也除以64。

对 inner/outer 分别 exact sweep，得到 Vraw^-≤Vraw≤Vraw^+、Vshift^-≤Vshift≤Vshift^+。所以差区间方向必须且确实是

    [Vshift^-−Vraw^+, Vshift^+−Vraw^-].

容量均为同一个 exact M，旧 R 也相同，因此

    Dshift−Draw=Vshift−Vraw

严格成立，容量项没有数值误差相减或独立 LP 区间拼接。证书给

    0.001328743 < Dshift−Draw < 0.001328744,

并有区间宽度<10^-20。浮点显示约0.001328743411053135仅为读数，不是严格依据。

本审另以已存 rational R、M 和 receiver intervals 作方向检查，二者各自的绝对 D 下界也均为正（约 Draw=0.0003574320786144、Dshift=0.0016861754896675）；这不改变证书主要认证的严格相对改进范围，也不说明动作池全局最优。

## 6. 实际独立重放与完整范围

本审只执行该 tiny exact script 一次，并在内存中截掉唯一写 `result.json` 的语句，未改脚本/输入/结果。重新计算全部 assertions 后，22个保存的数学字段与现有 result.json **逐字段精确相同**；运行无扫描、无15任务或其他数值重复。

绑定文件：

- instance SHA-256 `4acd5a7d388d9ea6c9af554f483ca4c0f3a7251e88a8e3ad4cd034c69c62a38e`；
- script SHA-256 `04c54ae3c904a3a7bbbddae63a1979739c77ad046926f407b5a88c918ea89989`；
- saved result SHA-256 `cabcd46e9a711fdf5df55e1a74beb45e981dc4351445937a8637db8bd9fed847`。

重放得到 contraction bound 约1.74594×10^-19，raw/shift 各13个 positive subsets、四个 maximal cliques相同，R upper约0.000347605<1。脚本参数隐含为a=64、H=32，归档主文宜显式列出；它们不能事后换值而沿用此证书。

**最终判定：接受这份 exact finite certificate 的数学含义，无实质修正要求。** 原80-digit数值 optimizer 的 stationarity、dual、D字段未被当成证明；唯一 center 用途已由严格 interval contraction覆盖。old/raw/shift 来源、完整容量及 receiver intervals 的逻辑链齐全。此例远不满足 R>6PH，既非 canonical 更新证明，也非一般 root-order 结论或全候选最优性声明。唯一写入文件为本审报告；完成停止。
