# R184：原 K0/current 核比值、硬面穿越与互反来源的共同位移预算

本稿给出原 mixed product 核的精确尺度穿越式，以及一条把 reciprocal 来源位移控制到“阈值内基准 + 维数无关超额”的几何界。两者结合，得到 R183 已付 F1 门的显式距离/硬面充分条件；收缩时另有对同一行全部 reciprocal u 统一成立的接收点/外源几何条件。所有公式适用于原自适应尺度，保留硬跳、尺度裁剪与共同 x,y,u,v。它们没有证明剩余 low-F 交通小，也没有一般根阶闭合。

## KG1. 原资格与需要控制的比值

固定原 (omega,V,a,b,q,x,j(x))。R128 proof.md RT4–RT6 给

    a≤L,R≤b≤2a,  gamma=1+1/n,  c_j=gamma^(−j),  g=√(LR),
    c_j g/gamma≤min(L,R)≤c_j g,
    ell=1+log n,       m(s)=1−s+s phi(1/2),
    H0=g c_j^(−1/2)m(s)ell^(1/(2n)),
    H=Hhat=max(a,min(b,H0)),
    T=c_j^(n/2)/(g^n√ell),
    p_z=P_(s,L)(x−z),  K0_z=P_(s,H)(x−z),  J_v=P_(1,b)(x−v).

D≥1 是原继承常数，不重选。a_v=T Delta_y(v)，Delta=w_tau−w_hstop，tau=a/c_j，hstop 为原 far 终点；原非空 far 中 0≤Delta≤1。空 far 行、a_v=0 或 rho_v=0 的原正交通先取零。alpha、capture/bad、Q_v、QJ=∫Jnu、q 与原来源/历史完全固定。本文仅对实际非零 positive target 定义含 a_v 的分式。

原 h=1_[−1/2,1/2]，w(r)=∫_0^1 exp(−|r|/t)dt，phi=h*w。设

    f_s(r)=(1−s)1_{r≤1/2}+s phi(r),  r≥0,
    lambda=H/L,      r_i=|x_i−u_i|/L.

于是原比值精确为

    K0_u/p_u=lambda^(−n)∏_i f_s(r_i/lambda)/f_s(r_i).       (KG1)

实际严格软范围 s>0 保证分母正。KG2–KG11 允许全部 0<s≤1；s=0 单独在 KG12 处理，绝不将无穷硬跳与零计数相乘。

## KG2. H/L 的全部方向，不能假定总是收缩

a≤L≤b 给 lambda∈[a/L,b/L]⊂[1/2,2]。令 r=R/L、delta=min(L,R)/g、theta_j=c_j/delta∈[1,gamma]，直接计算未裁剪比例

    H0/L=m(s)ell^(1/(2n))theta_j^(−1/2)
          × r^(3/4)  if r≥1,
          × r^(1/4)  if r≤1.                             (KG2)

再将此数裁剪到 [a/L,b/L]，才得到实际 lambda。特别 lambda>1 当且仅当 H0>L 且 L<b；lambda<1 当且仅当 H0<L 且 L>a。端点 L=a 可把向下的 H0 截到 lambda=1，L=b 可把向上的 H0 截到1。没有某个统一的 s 方向替代这些条件。

若记 KG2 中除 m 外的因子为 zeta>0，则 H0/L=zeta[1−s(1−phi(1/2))]。因此扩张/收缩的 soft 分界是这一显式线性式与1的比较；zeta≤1 时不能产生严格扩张。zeta>1 时可用 s 与 (1−1/zeta)/(1−phi(1/2)) 比较，仍必须保留 [0,1] 与裁剪端点。代数上可出现两种尺度方向，本稿不据此声称相应参数已满足全部原 FIRST/history。

## KG3. 可自证的一维光滑速率界

phi 偶且递减，phi(r)≤1。由卷积求导

    phi'(r)=w(r+1/2)−w(r−1/2),    |phi'|≤1.

并且

    phi(1/2)=∫_0^1 t(1−exp(−1/t))dt
             ≥(1−exp(−1))/2,          phi(1/2)<1/2.

设 Lphi=2/(1−exp(−1))。在 0≤r≤1/2，phi(r)≥phi(1/2)，故 |phi'/phi|≤Lphi。对 r>1/2，

    phi(r)=∫_0^1 t(1−exp(−1/t)) exp(−(r−1/2)/t)dt.

其负对数导数是 t^(−1) 的正加权平均，因而≥1；它随 r 非增。后者无需引用 logconcavity：在边界权测度下，t^(−1) 与 exp(−d/t) 的协方差非正，展开为两个来源变量的差乘积即可；边界一阶矩有限。故该平均不超过边界的 |phi'(1/2)|/phi(1/2)≤Lphi。于是全 r 的 log phi 为 Lphi-Lipschitz，而在外硬核其下降速率至少1。

对 r≠1/2 定义

    beta_s(r)=−s phi'(r)/f_s(r).

它满足 0≤beta_s≤Lphi；r>1/2 时 beta_s=−phi'/phi≥1。r=1/2 的单点取值不影响积分。仅此分段速率和一个真实硬跳参与下文；没有假设 mixed 核 logconcave。

## KG4. 完整 log 比值与闭硬面约定

记真实跳幅

    j_s=log[m(s)/(s phi(1/2))]≥0.

对任意 r≥0，逐段积分给

    log f_s(r)=log f_s(0)−∫_0^r beta_s(t)dt−j_s1_{r>1/2}.

因此定义

    Jplus=#{i:1/2<r_i≤lambda/2}       when lambda≥1,
    Jminus=#{i:lambda/2<r_i≤1/2}      when lambda≤1,

另一方向的计数取0，有精确恒等式

    log(K0_u/p_u)=−nlog lambda
       −Σ_i∫_(r_i)^(r_i/lambda) beta_s(t)dt
       +j_s(Jplus−Jminus).                               (KG3)

lambda=1 时两种计数与有向积分均为零，比值恰为1。r_i=1/2 属原 current 闭硬核；r_i=lambda/2 属 K0 闭硬核。尤其收缩只有 lambda/2<r_i 才丢硬核，扩张的终点等号已获得硬核。该恒等式对原子来源也逐点成立，不丢硬面零测集。

## KG5. 两方向的显式密度预算

扩张 lambda≥1 时置

    Eplus=Σ_i[r_i−max(1/2,r_i/lambda)]_+,
    Bplus=Σ_i∫_(r_i/lambda)^(r_i) beta_s(t)dt.

则 Eplus≤Bplus≤Lphi(1−1/lambda)Σr_i，故

    −nloglambda+Eplus+j_sJplus
       ≤log(K0_u/p_u)
       ≤−nloglambda+Lphi(1−1/lambda)Σr_i+j_sJplus.         (KG4)

这保留了体积损失、外硬核路径的正密度回收与内向硬跳三项。只用单调性时仍有 K0_u/p_u≥lambda^(−n)，但该指数维数损失不能免费删掉。

收缩 lambda≤1 时置

    Eminus=Σ_i[r_i/lambda−max(1/2,r_i)]_+,
    Bminus=Σ_i∫_(r_i)^(r_i/lambda) beta_s(t)dt.

Eminus≤Bminus≤Lphi(1/lambda−1)Σr_i，从而

    −nloglambda−Lphi(1/lambda−1)Σr_i−j_sJminus
       ≤log(K0_u/p_u)
       ≤−nloglambda−Eminus−j_sJminus.                    (KG5)

因此低比值 K0_u/p_u<epsilon 有准确必要条件：扩张时

    Eplus+j_sJplus<nloglambda+log epsilon;

收缩时

    Lphi(1/H−1/L)||x−u||_1+j_sJminus
          >nlog(L/H)+log(1/epsilon).                     (KG6)

若右侧不正，条件可能没有排除力，不能省略这一情形。收缩的 bulk 与硬跨面损失均可很大；反过来这两项小于阈值就给真正的比值下界。

## KG6. 原 reciprocal 重叠给位移超额，而非免费小位移

沿用原基本 bad 的互反限制，K=1，或仅为追踪常数写 kappa=K(1+gamma^(−n))/3<1。固定同一 x,y,u 的原 reciprocal 边给

    w_g(y,u)>kappa,
    kappa/w_g(y,u)<p_y/p_u<w_g(y,u)/kappa,
    Σ_i log_+[xi_g/C(|y_i−u_i|/b)]<log(1/kappa),
    xi_g=c_jg/b∈[1/2,1].                                (KG7)

这些属于 y−u 的 bad 边，不能替代 y−v 的 good 重叠。下文保留它们与 x−u 的共同几何。

给 actual C 一个显式下降速率。令 cC=1−phi(1/2)>1/2。F=max(h,phi) 在闭硬核内为1、外为phi，C=h*F。0<d<1 时

    C(d)=1−d+∫_(1/2)^(1/2+d)phi(t)dt,
    −(log C)'(d)=[1−phi(1/2+d)]/C(d)≥cC.

d>1 时 C=h*phi(d) 完全落在 phi 的正指数混合区，所以 −(log C)'≥1≥cC。C 在0、1连续，局部绝对连续且正；故可跨这些点积分得到

    log[C(d1)/C(d2)]≥cC(d2−d1),   0≤d1≤d2.             (KG8)

C 并未被概率化。它从 C(0)=1 严格递减到0，故 rxi=C^(−1)(xi_g) 唯一存在，xi_g=1 时 rxi=0。令 e_i=|y_i−u_i|，KG8 与 KG7 给

    Σ_i(e_i/b−rxi)_+<log(1/kappa)/cC,
    ||y−u||_1≤b[n rxi+log(1/kappa)/cC],
    rxi≤log(1/xi_g)/cC.                                 (KG9)

因此也有完全显式的粗界 ||y−u||_1≤2b[nlog(1/xi_g)+log(1/kappa)]。其中 n rxi 是不可由 reciprocal 单独消掉的阈值内基准；只有 nlog(1/xi_g)=O(1) 时此界本身才给 O(b) 位移。对任意 eta>0，超出 b(rxi+eta) 的坐标数小于 log(1/kappa)/(cC eta)。这是同一 product 真实重叠的确定性推论，不是坐标独立或来源质量帽。

## KG7. shared x,y 的收缩硬面计数

现在 H<L。记

    delta0=b rxi,    Erecip=b log(1/kappa)/cC,
    d_i=|x_i−y_i|.

选择任意物理长度 hface>0，定义接收点/外源的膨胀硬环计数

    N_h=#{i:dist(d_i,[H/2,L/2])≤delta0+hface}.

若 i 是 Jminus 所计的原 crossing，则 ||x_i−u_i|−d_i|≤e_i。若它同时不在 N_h 内，必有 e_i>delta0+hface。KG9 因而给

    Jminus≤min(n,N_h+Erecip/hface),
    ||x−u||_1≤||x−y||_1+n delta0+Erecip.                 (KG10)

硬环的两端均采用闭的充分包络，原 crossing 仍由 KG4 的半开约定给出；这里没有改变原面。代入 KG5 后，对**同一原行的每个 reciprocal u** 统一成立

    log(K0_u/p_u)≥B_h(x,y),
    B_h=nlog(L/H)
       −Lphi(1/H−1/L)(||x−y||_1+n delta0+Erecip)
       −j_s min(n,N_h+Erecip/hface).                     (KG11)

hface 可取预定值，或取不依当前 u 的原共同数据的任意可测正函数；这是逐点确定性界，不产生选择菜单积分费。所有 hface^(−1)、N_h、n delta0 和原软度跳幅费用都显式保留。环内坐标可以有 n 个，不能假装该几何界自动为 O(1)。

## KG8. 回代 R183 的真实已付门

在原非零 good/capture target 上，R183 的 r=1 归一物理权为

    F1(v,u)=(27/4) w_g(y,v)^2
             [D K0_u/p_u][J_v/a_v][q/QJ].

写 Gamma_v=(27/4)D w_g(y,v)^2 J_v q/(a_v QJ)。对一般方向，用 KG4 或 KG5 的显式 lower B(u) 即得 F1≥Gamma_v exp(B(u))。收缩时 KG11 进一步给对整行 reciprocal source 统一的下界

    F1(v,u)≥Gamma_v exp(B_h(x,y)).                        (KG12)

扩张时无需额外源限制的统一版本为 F1≥Gamma_v lambda^(−n)；更强的逐 source 门保留 Eplus 与 Jplus。

故固定 theta>0，定义原正交通的几何子支：一般版本 Gamma_v exp(B(u))≥theta，或收缩的 target-only 充分版本 Gamma_v exp(B_h)≥theta。它们都包含于原已付 F1≥theta，保持原 receiver/high、good target、capture、互反 bad、score、Z_t 与历史门。由已审 R183 JG14，

    Raw_rec^+[该几何子支]
       ≤(32Lambda/3)√[n log2/(72K kappa theta)] WA
       ≤(32Lambda/3)√[n log2/(72K kappa theta)]||f||1.     (KG13)

这是直接可使用的原模型付款，不附未知 posterior 假设。它并不意味着该子支一般非空或严格扩大某个旧已付集合；未证明这些覆盖主张。若此前已付集合为 O，应只在 O^c 上应用新几何门，剩余 O^c∩{该门失败} 原位保留。也可继续在剩余中使用真正 F1≥theta；充分门失败不意味着 F1 必低。

KG13 已继承 R183 的全部费用：同原 high/current 容量、单向 E_J≤nWnu/(2K)、common xi∈[1/2,1] 后的唯一 j、一个 hard16/3 与外2Lambda、固定 b 的 J 源积分。本文不另对 adaptive L,s 使用固定参数卷积上界，因此无免费 sup；source beta 与 nu 仍只受共同父支配。跨独立窗口重复价格必须相加，不能免费复用 WA。没有再用任何已消费负信用。

## KG9. T、裁剪与 target 密度的精确成本

原定义给无误差的恒等式

    T H0^n=m(s)^n,
    (L/H)^n J_v/T
      =(L/b)^n(H0/H)^n m(s)^(−n)
          ∏_i phi((x_i−v_i)/b).                         (KG14)

因此若 KG3 写为 K0_u/p_u=(L/H)^n exp(S_u)，则 a_v=TDelta_v 代回 KG8 给

    F1=(27D/4)w_g(y,v)^2(q/QJ)/Delta_v
          ×(L/b)^n(H0/H)^n m(s)^(−n)
          ×∏phi((x−v)/b) ×exp(S_u).                    (KG15)

未裁剪时 H=H0，裁剪因子恰为1。下裁剪 H0<a 时该因子小于1；上裁剪 H0>b 时大于1，均不能无条件删掉。Delta、target J 与 good overlap 仍属同一个 v；不能以 bad-u 的 large overlap 代替它。KG14 消去的是真实尺度代数，不是额外来源归一化，q/QJ 也仍在。

## KG10. 与实际低比值补集的接口及障碍

低 K0_u/p_u 的几何在 KG6 中有明确分类：扩张的体积损失未被外路径回收/内向硬跳抵消；或收缩的外位移/出硬面损失超过 nlog(L/H)。在原 reciprocal 区域，可用 KG9–KG11 将收缩的未知 source 位移归入共同 x−y 距离、阈值内基准 n rxi、receiver 硬环 N_h 及定量超额 Erecip；无需逐例外坐标枚举或 binomial 菜单。

但是 KG7 只惩罚 C(e_i/b)<xi_g 的超额；任意多个坐标可停在 C≥xi_g 的阈值内。shared x−y 硬环也可含全部坐标。原 source/current 容量并不在这里给 N_h 或 beta 的环质量一个可吸收帽，sigma/nu 的出生树也不能自动给 beta 每窗 lambda b^n 帽。故不能从这些确定性式子推出一般 small-source 费或 epsilon receiving 费。即使 K0_u/p_u 有常数下界，target 的 w_g(y,v)^2 J_v/a_v 和 q/QJ 仍是 F1 的真实乘子；不能将它们独立取好值。

原 bad 反向响应 p_u≈p_y/w_g 的双侧范围仍为 KG7，不授权把 x−u 与 x−y 独立化。一般低 F 的实际三点加权积分仍未付；Astra/父稿的极值 deficit 若能控制上述硬环、基准或 target 乘子，需在同一原积分中另证明其收费。本稿没有重命名这些项为已付能量。

## KG11. 可复核的解析检查与范围

初步检查：lambda=1 时 KG3 精确给1，cross 与 bulk 全零；0<s≤1 的每个坐标分 inside→inside、outside→outside 和唯一 crossing，KG3 分别是普通积分、普通积分加完整跳幅，因而没有漏面。

边界压力：s=1 时 j_s=0，保留纯 phi 尺度比；r_i=1/2 或 lambda/2 的等号由 KG4 的闭面公式处理；H0=a,b 时 KG14 连续且裁剪因子1；xi_g=1 时 rxi=0，KG9 留 O(b) 总位移而非人为 0。kappa≥1 时 reciprocal 为空，以上收费无需使用。a_v=0、rho=0、QJ=0 的原零行先消去，不在 KG8/15 造0/0。

扩大参数检查：KG2 同时保留 L≥R 与 L≤R 的不同幂次、全部 s∈(0,1] 及三个裁剪区；KG4–5 对任意坐标组合张量相加，不需独立性；KG9–11 对所有 n、全部实际 xi_g∈[1/2,1] 成立，显式 n 项未拟合或忽略。本文无新数值扫描，解析恒等式并不认证任何有限原子为 FULL/L1/history 实例。

## KG12. s=0 的单独硬核支与停止点

s=0 且 p_u>0 时，u 位于原 current 闭立方体。若 H≥L，则 K0_u/p_u=(L/H)^n。若 H<L，只有所有 |x_i−u_i|≤H/2 时该比值为 (L/H)^n，否则为0。p_u=0 的槽不写比值。这个边界不能靠 j_s→∞ 后写0×∞来替代；当前实际严格软来源应用用 KG1–11 即可。

交付是一个全软度/全原尺度的精确核比值几何工具、一个保留基准成本的 reciprocal source 超额预算、及其原 root-paid 子支回代。尚缺一般低 F 三点流量的实际 receiver/source 付款与整体覆盖；本文在该有限检查点停止。
