# R184 父级独立重放

父级实际将冻结脚本、task_contract.md、kernel_ratio_geometry.md复制到新的隔离目录 /var/folders/lq/2c4qbz2n0354_tnttkv_qsz00000gn/T/r184_parent_d3u2c_re，通过现有 PYTHONPATH mpmath 依赖运行，退出码0；输出完整JSON与保留结果逐字段一致。未安装新依赖。

33个有理精确案例与30个高精度诊断均通过。高精度诊断不是区间误差证书，不证明一般维数阶数。核验未加入物理FIRST/history或完整接收积分的数值认证。

父级另外实际运行最终 reproduce.py --output-dir /tmp/r184_reproduce_parent_final_20261016：13项当时清单哈希通过，完整JSON重放一致，退出码0。最终独审冻结后会重建inventory并再次只验证哈希；不改变数学/数值输入。proof.tex.txt花括号平衡检查通过，未编译PDF。
