#!/usr/bin/env python3
"""R184 bounded exact low-core and canonical-tail certificates."""
from fractions import Fraction as F
from pathlib import Path
import argparse,hashlib,json
HERE=Path(__file__).resolve().parent
ZERO=F(0)
def sm(xs):return sum(xs,ZERO)
def fs(xs):return list(map(F,xs))
def enc(x):
 if isinstance(x,F):return str(x)
 if isinstance(x,dict):return {k:enc(v) for k,v in x.items()}
 if isinstance(x,(list,tuple)):return [enc(v) for v in x]
 return x

def bridge(name,stage,e,delta,nodes,slopes):
 e,delta=F(e),F(delta);nodes,slopes=fs(nodes),fs(slopes)
 assert e>0 and 0<delta<1 and nodes[0]==0 and len(slopes)==len(nodes)-1 and all(x<y for x,y in zip(nodes,nodes[1:])) and all(0<=m<=1 for m in slopes)
 L=H=integral=parts=ZERO;cells=[];endpoint_dom=True
 for lo,hi,m in zip(nodes,nodes[1:],slopes):
  intercept=L-m*lo;cuts=[lo,hi]
  if m!=delta:
   root=-intercept/(m-delta)
   if lo<root<hi:cuts.append(root)
  cuts.sort()
  for a,b in zip(cuts,cuts[1:]):
   selected=m*((a+b)/2)+intercept<=delta*(a+b)/2
   h_slope=m if selected else ZERO;h_intercept=H-h_slope*a
   direct=h_slope*(1/(e+a)-1/(e+b));integral+=direct
   def primitive(z):return -2*h_slope/(e+z)-(h_intercept-h_slope*e)/(e+z)**2
   ip=primitive(b)-primitive(a);parts+=ip
   h_end=H+h_slope*(b-a)
   endpoint_dom=endpoint_dom and H<=delta*a and h_end<=delta*b
   cells.append(dict(lo=a,hi=b,L_slope=m,L_intercept=intercept,selected_closed_gate=selected,H_start=H,H_end=h_end,integral=direct,parts_integral=ip))
   H=h_end
  L+=m*(hi-lo)
 D=nodes[-1];rhs=delta*(1/e-1/(e+D));parts+=H/(e+D)**2
 checks=dict(direct_equals_integration_by_parts=integral==parts,selected_cumulative_domination=endpoint_dom,bridge_inequality=integral<=rhs,nonnegative=integral>=0,zero_D=D!=0 or integral==rhs==0)
 assert all(checks.values()),(name,checks)
 return dict(name=name,stage=stage,e=e,delta=delta,nodes=nodes,slopes=slopes,D=D,L_terminal=L,selected_cumulative_H=H,cells=cells,integral=integral,integration_by_parts=parts,bound=rhs,gap=rhs-integral,equality=integral==rhs,checks=checks)

def tails(name,stage,e,d,M,D):
 e,d,M,D=map(F,(e,d,M,D));assert e>0 and d>=0 and M>=0 and D>=0
 low_end=min(D,d*e);low=1/e-1/(e+low_end);lowbound=d/(e*(1+d));high_start=M*e;high=1/(e+high_start)-1/(e+D) if high_start<D else ZERO;infinite=1/(e*(1+M));total=1/e-1/(e+D)
 checks=dict(low_truncation=0<=low<=lowbound,high_truncation=0<=high<=infinite,canonical_low_identity=1/e-1/(e+d*e)==lowbound,canonical_infinite_tail_identity=1/(e+M*e)==infinite,total_nonnegative=total>=0,empty_window=D!=0 or low==high==total==0)
 assert all(checks.values())
 return dict(name=name,stage=stage,e=e,d=d,M=M,D=D,low_interval=[ZERO,low_end],low_integral=low,low_bound=lowbound,high_interval=[high_start,D] if high_start<D else [],high_integral=high,infinite_high_tail=infinite,whole_truncated_integral=total,checks=checks)

def envelope_checks():
 out=[]
 for stage,R in [('initial',F(0)),('initial',F(1,9)),('initial',F(1,3)),('stress',F(1,2**40)),('stress',F(1,3)-F(1,2**30)),('stress',F(1,3)+F(1,2**30)),('expanded',F(1)),('expanded',F(2**30)),('expanded',F(7,20))]:
  rstar=2*R/(1-R) if R<F(1,3) else F(1)
  E=1/(1-R)**2 if R<=F(1,3) else F(27,4)*R
  upper=1+F(27,4)*R
  derivative_relation=R*(rstar+2)==rstar if 0<R<F(1,3) else (3*R>=1 if R>=F(1,3) else True)
  assert E<=upper and 0<=rstar<=1 and derivative_relation
  if R==F(1,3):assert E==F(27,4)*R
  out.append(dict(stage=stage,R=R,maximizer_r=rstar,envelope=E,linear_upper=upper,gap=upper-E,stationarity_algebra=derivative_relation,checks_pass=True))
 return out

def physical_checks():
 from functools import lru_cache
 import mpmath as mp
 def evaluate(dps):
  mp.mp.dps=dps
  def mm(x):
   if isinstance(x,F):return mp.mpf(x.numerator)/x.denominator
   return mp.mpf(x)
  @lru_cache(None)
  def phi(r):
   r=abs(r)
   return 1-mp.expint(3,mp.mpf('.5')+r)-mp.expint(3,mp.mpf('.5')-r) if r<=mp.mpf('.5') else mp.expint(3,r-mp.mpf('.5'))-mp.expint(3,r+mp.mpf('.5'))
  def C(d):
   d=abs(d)
   if d<=1:return 1-d+mp.mpf(1)/3-mp.expint(4,d)-mp.expint(4,1)+mp.expint(4,1+d)
   return mp.expint(4,d-1)-2*mp.expint(4,d)+mp.expint(4,d+1)
  def fs(r,s,inside):return (1-s if inside else 0)+s*phi(r)
  ell=1+mp.log(4);Lphi=2/(1-mp.exp(-1));ratios=[]
  configs=[(4,F(L),F(R),F(s)) for L,R in [(F(1,2),F(1,2)),(F(1,2),1),(1,F(1,2)),(1,1)] for s in [F(4,25),F(3,4)]]
  configs += [(16,F(1),F(1,2),F(4,25)),(16,F(1,2),F(1),F(3,4))]
  for ci,(n,Lq,Rq,sq) in enumerate(configs):
   L,R,s=map(mm,(Lq,Rq,sq));gamma=F(n+1,n);delta2=min(Lq,Rq)**2/(Lq*Rq);j=0
   while gamma**(-2*(j+1))>=delta2:j+=1
   cj=mm(gamma**(-j));g=mp.sqrt(L*R);ell=1+mp.log(n);m=1-s+s*phi(mp.mpf('.5'));H0=g*cj**(-mp.mpf('.5'))*m*ell**(mp.mpf(1)/(2*n));H=max(mp.mpf('.5'),min(mp.mpf(1),H0));lam=H/L;T=cj**(mp.mpf(n)/2)/(g**n*mp.sqrt(ell));jump=mp.log(m/(s*phi(mp.mpf('.5'))))
   patterns=['zero','faces_tail','mixed_tail'] if n==4 else ['faces_tail']
   for pattern in patterns:
    if pattern=='zero':ds=[mp.mpf(0)]*n;labels=['zero']*n
    elif pattern=='faces_tail':ds=[L/2,H/2,(L+H)/4,mp.mpf(4)]*(n//4);labels=['current_face','hat_face','midface','tail4']*(n//4)
    else:ds=[mp.mpf(0),mp.mpf('.25'),mp.mpf(1),mp.mpf(8)];labels=['zero','quarter','one','tail8']
    current_inside=[True if lab=='current_face' else (H<=L if lab=='hat_face' else d<=L/2) for d,lab in zip(ds,labels)]
    hat_inside=[True if lab=='hat_face' else (L<=H if lab=='current_face' else d<=H/2) for d,lab in zip(ds,labels)]
    logratio=-n*mp.log(lam)+sum(mp.log(fs(d/H,s,ih))-mp.log(fs(d/L,s,ic)) for d,ic,ih in zip(ds,current_inside,hat_inside))
    jp=sum(not ic and ih for ic,ih in zip(current_inside,hat_inside));jm=sum(ic and not ih for ic,ih in zip(current_inside,hat_inside));rs=[d/L for d in ds]
    if lam>=1:
     extra=sum(max(r-max(mp.mpf('.5'),r/lam),0) for r in rs);lower=-n*mp.log(lam)+extra+jump*jp;upper=-n*mp.log(lam)+Lphi*(1-1/lam)*sum(rs)+jump*jp
    else:
     extra=sum(max(r/lam-max(mp.mpf('.5'),r),0) for r in rs);lower=-n*mp.log(lam)-Lphi*(1/lam-1)*sum(rs)-jump*jm;upper=-n*mp.log(lam)-extra-jump*jm
    # Smooth antiderivative subtracts the entire true hard jump; no jump is quadrature-smoothed.
    smooth=sum(mp.log(fs(d/L,s,ic))-mp.log(fs(d/H,s,ih))-jump*(int(ic)-int(ih)) for d,ic,ih in zip(ds,current_inside,hat_inside))
    identity=-n*mp.log(lam)-smooth+jump*(jp-jm)
    tol=mp.mpf('1e-30');assert lower-tol<=logratio<=upper+tol and abs(identity-logratio)<tol and s>1-mp.power(2,-mp.mpf(1)/n),(ci,pattern,lam,lower,logratio,upper,identity-logratio,current_inside,hat_inside)
    assert abs(T*H0**n-m**n)<tol and cj/mp.sqrt(mm(delta2))>=1-tol and cj/mp.sqrt(mm(delta2))<=mm(gamma)+tol
    ratios.append(dict(n=n,L=str(Lq),R=str(Rq),s=str(sq),j=j,pattern=pattern,stage='initial' if len(ratios)<4 else ('stress' if len(ratios)<12 else 'expanded'),H0=H0,Hhat=H,clamp='lower' if H0<mp.mpf('.5') else ('upper' if H0>1 else 'none'),lambda_scale=lam,positions=ds,position_labels=labels,current_inside=current_inside,hat_inside=hat_inside,current_face_margin=[d-L/2 for d in ds],hat_face_margin=[d-H/2 for d in ds],Jplus=jp,Jminus=jm,logratio=logratio,lower=lower,upper=upper,log_identity_residual=identity-logratio,scale_identity_residual=T*H0**n-m**n,strictsoft_margin=s-(1-mp.power(2,-mp.mpf(1)/n)),checks_pass=True))
  cC=1-phi(mp.mpf('.5'));geom=[]
  for n,xiq in [(4,F(1)),(4,F(3,4)),(16,F(1)),(16,F(3,4))]:
   xi=mm(xiq);lo=mp.mpf(0);hi=mp.mpf(4)
   if xi==1:rxi=mp.mpf(0)
   else:
    for _ in range(180):
     mid=(lo+hi)/2
     if C(mid)>xi:lo=mid
     else:hi=mid
    rxi=(lo+hi)/2
   kappa=mm((1+F(n,n+1)**n)/3);e=rxi+mp.log(1/kappa)/(100*n);wg=min(1,C(e)/xi)**n;excess=n*(e-rxi);bound=mp.log(1/kappa)/cC
   assert wg>kappa and excess<=bound and rxi<=mp.log(1/xi)/cC+mp.mpf('1e-30')
   geom.append(dict(n=n,xi=str(xiq),rxi=rxi,inverse_residual=C(rxi)-xi,source_displacements=[e]*n,actual_product_wg=wg,kappa=kappa,excess=excess,excess_bound=bound,retained_baseline=n*rxi,checks_pass=True))
  # Independent integration of actual phi and C: empirical mpmath quadrature, not intervals.
  quads=[]
  for r in [mp.mpf('.25'),mp.mpf(2)]:
   phiq=mp.quad(lambda z:mp.expint(2,abs(z)),[r-mp.mpf('.5'),0,r+mp.mpf('.5')]) if r<mp.mpf('.5') else mp.quad(lambda z:mp.expint(2,z),[r-mp.mpf('.5'),r+mp.mpf('.5')])
   cq=mp.quad(lambda z: 1 if abs(z)<=mp.mpf('.5') else phi(abs(z)),[r-mp.mpf('.5'),mp.mpf('.5'),r+mp.mpf('.5')]) if r<1 else mp.quad(lambda z:phi(z),[r-mp.mpf('.5'),r+mp.mpf('.5')])
   quads.append(dict(r=r,phi_residual=phiq-phi(r),C_residual=cq-C(r)))
   assert abs(phiq-phi(r))<mp.mpf('1e-30') and abs(cq-C(r))<mp.mpf('1e-30')
  beta_quads=[]
  for row in [next(x for x in ratios if x['lambda_scale']>1 and x['pattern']=='faces_tail'),next(x for x in ratios if x['lambda_scale']<1 and x['pattern']=='faces_tail')]:
   ss=mm(F(row['s']));LL=mm(F(row['L']));HH=row['Hhat'];dd=row['positions'][0];r0=dd/LL;r1=dd/HH;aa,bb=min(r0,r1),max(r0,r1);cuts=[aa]+([mp.mpf('.5')] if aa<mp.mpf('.5')<bb else [])+[bb]
   def beta(t):return ss*(mp.expint(2,abs(t-mp.mpf('.5')))-mp.expint(2,t+mp.mpf('.5')))/fs(t,ss,t<=mp.mpf('.5'))
   integ=sum(mp.quad(beta,[a,b]) for a,b in zip(cuts,cuts[1:]))*(1 if r1>=r0 else -1)
   ic,ih=row['current_inside'][0],row['hat_inside'][0];jump0=mp.log((1-ss+ss*phi(mp.mpf('.5')))/(ss*phi(mp.mpf('.5'))));endpoint=mp.log(fs(r0,ss,ic))-mp.log(fs(r1,ss,ih))-jump0*(int(ic)-int(ih))
   assert abs(integ-endpoint)<mp.mpf('1e-30')
   beta_quads.append(dict(L=row['L'],R=row['R'],s=row['s'],lambda_scale=row['lambda_scale'],r_current=r0,r_hat=r1,beta_integral=integ,endpoint_smooth_integral=endpoint,residual=integ-endpoint))
  def stringify(x):
   if isinstance(x,mp.mpf):return mp.nstr(x,35)
   if isinstance(x,dict):return {k:stringify(v) for k,v in x.items()}
   if isinstance(x,list):return [stringify(v) for v in x]
   return x
  return stringify(dict(ratio_cases=ratios,C_geometry_cases=geom,quadrature_crosschecks=quads,beta_quadrature_crosschecks=beta_quads))
 low=evaluate(40);high=evaluate(60)
 differences=[str(abs(mp.mpf(a['logratio'])-mp.mpf(b['logratio']))) for a,b in zip(low['ratio_cases'],high['ratio_cases'])]
 assert all(mp.mpf(x)<mp.mpf('1e-28') for x in differences)
 return dict(**high,precision_dps=[40,60],logratio_precision_differences=differences,dependency=dict(mpmath_version=mp.__version__,entry_sha256=hashlib.sha256(Path(mp.__file__).read_bytes()).hexdigest()),status='High-precision numerical consistency only, not directed interval certification',limitations=['No common source masses, alpha/good/high/FIRST/history qualification is asserted','The smooth antiderivative decomposition reuses endpoint kernels; independent phi/C quadrature is separately reported','1e-30 residual and 40/60 differences are numerical controls, not rigorous error bounds','All n-dependent volume, hard jump, clipping, and baseline costs are retained'])

def run():
 B=bridge
 rows=[B('constant_low','initial',1,F(1,2),[0,1],[F(1,4)]),B('constant_high','initial',1,F(1,2),[0,1],[F(3,4)]),B('whole_tie','initial',2,F(1,2),[0,1,3],[F(1,2)]*2),B('zero_D','initial',1,F(1,2),[0],[]),B('zero_slope','initial',1,F(1,4),[0,3],[0]),B('delta_near_one','initial',1,F(99,100),[0,1,2],[F(1,2),1]),B('alternating_crossings','stress',1,F(2,5),[0,1,2,3,4],[0,1,0,1]),B('alternating_reverse','stress',1,F(3,5),[0,1,2,3,4],[1,0,1,0]),B('endpoint_ties','stress',1,F(1,2),[0,1,2,3,4],[0,1,0,1]),B('tie_then_leave','stress',1,F(1,2),[0,1,2,3],[F(1,2),1,0]),B('flat_tie_endpoint','stress',F(1,7),F(1,3),[0,1,3,4],[1,0,1]),B('many_crossings','stress',F(3,2),F(1,2),list(range(9)),[0,1]*4),B('tiny_e','expanded',F(1,2**40),F(1,3),[0,F(1,2),1,2],[0,1,0]),B('huge_e','expanded',2**40,F(2,3),[0,1,2,4],[1,0,1]),B('tiny_D','expanded',1,F(1,2),[0,F(1,2**40),F(1,2**39)],[0,1]),B('huge_D','expanded',1,F(1,2),[0,2**30,2**31],[0,1]),B('tiny_delta','expanded',F(1,8),F(1,2**30),[0,1,2],[0,1]),B('irregular_segments','expanded',F(7,11),F(5,13),[0,F(1,7),F(2,3),F(11,5),9],[F(1,9),F(8,9),F(1,17),F(15,16)])]
 T=tails;tailrows=[T('baseline','initial',1,F(1,2),2,10),T('zero_D','initial',1,1,1,0),T('truncation_before_cuts','stress',2,3,4,1),T('exact_cutpoints','stress',1,2,2,2),T('extreme_e','expanded',F(1,2**40),F(1,2**20),2**20,1),T('zero_d_M','expanded',2**20,0,0,2**30)]
 assert rows[2]['equality'] and rows[3]['equality'] and len([c for c in rows[6]['cells'] if c['selected_closed_gate']])>=2
 return dict(envelope_cases=envelope_checks(),physical=physical_checks(),schema='r184_numerical_v1',arithmetic='Fraction exact for all bridge/tail results',inputs={'task_contract.md':hashlib.sha256((HERE/'task_contract.md').read_bytes()).hexdigest(),'kernel_ratio_geometry.md':hashlib.sha256((HERE/'kernel_ratio_geometry.md').read_bytes()).hexdigest()},bridge_cases=rows,canonical_tail_cases=tailrows,summary=dict(bridge_cases=len(rows),tail_cases=len(tailrows),envelope_cases=9,physical_ratio_cases=26,physical_C_cases=4,physical_numeric_consistency_pass=True,all_exact_pass=True,unexpected_failures=[]),scope=['Bridge and tails are finite piecewise-linear algebra certificates, not physical FIRST/history examples','At isolated equality crossings dL has no atom; an entire equality interval is included by the closed gate','Independent integration by parts uses selected cumulative H(z)<=delta z, checked at every affine cell endpoint','Physical kernel probes are numerical consistency checks only and have no full FIRST/history qualification'])
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=HERE/'numerical_checks.json');args=p.parse_args();r=run();args.output.write_text(json.dumps(enc(r),indent=2,sort_keys=True)+'\n');print(json.dumps(r['summary'],sort_keys=True))
