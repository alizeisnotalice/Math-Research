# R184 finite exact and physical-kernel checks

All retained checks pass. Categories are 18 exact low-core bridge cases, 6 exact canonical-tail cases, 9 exact envelope cases, 26 physical product-kernel ratio cases, and 4 physical C-geometry vectors. The bridge, tail, envelope, and ratio categories record initial/stress/expanded checks. The four C vectors follow the fixed order n=4, ξ=1 baseline; n=4, ξ=3/4 pressure; then the two n=16 expanded comparisons, without per-row stage fields. No source-history search, receiver integration, fitted dimension order, or physical FULL/FIRST example is claimed.

## Exact bridge and tails

For increasing piecewise-linear L with L(0)=0 and slopes in [0,1], the checker cuts every segment at the rational root of L(z)=δz. It includes an entire equality segment, and isolated crossings have no dL atom. The integral on a selected cell [a,b] is exactly slope·[(e+a)^-1−(e+b)^-1]. This is compared with δ[1/e−1/(e+D)].

An independent integration-by-parts computation uses H(z)=∫_[0,z]1_{L≤δt}dL(t), with affine-cell endpoint checks H(z)≤δz. On each refined cell H=mz+b, the primitive of 2H/(e+z)^3 is −2m/(e+z)−(b−me)/(e+z)^2. The computed integral equals H(D)/(e+D)^2 plus this integral exactly. Thus the second calculation retains all skipped L increments and the entire denominator evolution.

Stages cover constant low/high slopes, full ties (exact equality), zero D, zero slope, δ near one; alternating and endpoint crossings; and e or D as small/large as 2^-40/2^40, tiny δ, and irregular rational segments. No failures remain. Six canonical-tail cases independently check the exact finite truncations of ∫(e+z)^-2dz against d/[e(1+d)] and 1/[e(1+M)], including empty windows and cutpoints.

## Exact adaptive envelope algebra

Nine rational R values test E(R)=(1−R)^-2 for 0≤R≤1/3, and E(R)=27R/4 above 1/3, including R=0, the junction, both sides of the junction, 2^-40 and 2^30. Every value satisfies E≤1+27R/4. The stationary candidate r*=2R/(1−R) is checked by R(r*+2)=r* in the interior; the r=1 endpoint sign is checked by 3R≥1. This is finite rational verification of the authored envelope formula and its algebra, not evaluation of irrational powers or an independent general optimization proof. The analytic logarithmic derivative log R+log((r+2)/r) is decreasing, which explains the two branches. No new pairwise-menu or root closure is inferred numerically.

## Physical kernels and closed hard faces

The physical section follows frozen `kernel_ratio_geometry.md` KG1–KG9. It uses actual h=1_[−1/2,1/2], w=E2(|r|), φ=h*w, and C=h*max(h,φ). Stable analytic formulas are

- φ(r)=1−E3(1/2+r)−E3(1/2−r) inside the hard interval, and E3(r−1/2)−E3(r+1/2) outside;
- C(d)=1−d+1/3−E4(d)−E4(1)+E4(1+d) for d≤1, and E4(d−1)−2E4(d)+E4(d+1) for d≥1.

The primary menu is n=4, a=1/2,b=1, all four (L,R) endpoint pairs, s=4/25 or 3/4, and three true displacement patterns: all zero; (L/2,H/2,(L+H)/4,4); (0,1/4,1,8). Two n=16 comparisons repeat the face pattern. Every case recomputes the original ratio-band j, c_j, H0, clamped Hhat, T, and strict-soft margin. Cases cover 13 unclipped, 10 lower-clipped, and 3 upper-clipped outcomes. Ratios use the same s and original H/L. All volume factors and hard jumps are retained.

The exact constructed faces d=L/2 and d=H/2 use symbolic scale ordering for membership, never a subtraction rounded to one side of a face. The final diagnostics include all hard-face margins and membership flags. During development a face-order inversion was caught by the KG4/5 assertion and corrected before the retained outputs. The complete smooth-antiderivative plus hard-jump identity is checked against the product log ratio. Expansion and contraction bounds KG4/5 both hold in all retained cases. In addition, one expansion and one contraction smooth integral are independently checked by quadrature of β_s, splitting the hard face; the jump is never smoothed by quadrature. Independent φ/C quadrature at r=1/4 and 2 checks the E3/E4 formulas.

Four C vectors use n=4 or 16, ξ=1 or 3/4, actual inverse rξ, and an explicit small positive excess per coordinate. They satisfy the strict actual reciprocal-product inequality wg>κ and the KG9 excess bound. At ξ=3/4, n rξ is approximately 1.40085639 for n=4 and 5.60342557 for n=16: the baseline is retained and visibly changes with n. This does not certify any original reciprocal source/capture/history input.

## Precision, reproducibility, and scope

Exact categories use standard-library Fraction only. Physical results use existing local mpmath at 40 and 60 decimal digits; output records the version and entry-file SHA256, and author/contract hashes. Product log-ratio differences must be below 10^-28; numerical identity/quadrature checks use 10^-30 residual thresholds. These are empirical precision/resolution controls, **not rigorous quadrature error bounds or directed interval certificates**. A finite scan cannot certify the general KG inequalities or a general dimension estimate.

Run:

```sh
PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor python3 numerical_checks.py
```

The script writes adjacent `numerical_checks.json`, or accepts `--output /tmp/result.json`. It requires the two adjacent recorded source documents and mpmath 1.3.0 available through standard import (the local command above supplies PYTHONPATH); no installation is performed. Local dependency keys are filenames to support relocation. Runtime is deterministic apart from no timing field; all assertion failures, including physical numerical failures, exit nonzero. Isolated replay copies only the script and two source documents outside the repository and compares the entire JSON.

The remaining mathematical gap is unchanged: none of these finite tests pays the general low-F three-point source/receiver traffic, supplies original FIRST/history qualification, or removes the source/receiver/dimension costs retained in the authored geometry.
