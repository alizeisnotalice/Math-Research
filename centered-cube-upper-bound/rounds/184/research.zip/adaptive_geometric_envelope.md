# R184: a paid pair-adaptive envelope and its actual source-likelihood frontier

Parent proof, sent as an exact proposition for independent screening before this manuscript. The result pays the previously unpriced pair-dependent choice of r, with an explicit factor2; it does not prove a positive lower bound on the envelope or pay its low-value complement.

## AE1 Original quantities and zero branches

Use R183 JG's same original x,y,v,u, alpha, k=DK0, a_v=TDelta_y(v), p_u, QJ=Jnu and q. Distinguish static k from auxiliary score k_t. On an active target and effective reciprocal bad pair set

Rbase=(k_u/p_u)(J_v/a_v)(q/QJ),
F_r=wg(y,v)^2 Rbase^r/c_r,
c_r=4r^r/(r+2)^(r+2), 0<r<=1, c_0=1.

F_0=wg(y,v)^2 is defined directly. Original strictsoft gives positive p,J,K0 on finite positions; noncapture, a=0, rho=0, QJ=0 or alpha=0 branches are handled exactly as R183 before forming products. In particular alpha0 implies zero effective bad traffic. One need not define infinite weights multiplied by zero. The following algebra extends to Rbase=0 by assigning F_0 as above and F_r=0 for r>0.

R183 proved C_rec[F_r]<=C0 Wnu for each target-only choice of r, including the two endpoints, with C0=log(2)/(36 kappa_n). It did NOT pay a pairwise supremum for free. We now prove a positive domination by the two already paid endpoint weights.

## AE2 Exact scalar envelope

For R>=0,

E(R)=sup_{0<=r<=1} R^r/c_r
 = (1-R)^(-2),                 0<=R<=1/3,
 = (27/4)R,                   R>=1/3.                    (AE1)

For R>0, differentiate log(R^r/c_r) with respect to r:

 d/dr = log[R(r+2)/r].

This derivative decreases strictly in r. If 0<R<1/3, it changes sign at r*=2R/(1-R) in (0,1). At this point R=r*/(r*+2), and c_r=R^r(1-R)^2, proving the first branch. If R>=1/3 the function is increasing up to r=1, giving the second. R=0 follows directly from the separately defined r0 endpoint; the branches agree at R=1/3.

On [0,1/3],

E(R)-1=R(2-R)/(1-R)^2 <= (15/4)R <= (27/4)R,

where the first rational factor increases to15/4. On R>=1/3 the linear expression is exact. Therefore

F_sup:=wg(y,v)^2 E(Rbase) <= F_0+F_1.                    (AE2)

All quantities are explicit measurable functions of the actual pair. No measurable-supremum existence theorem or stochastic independence is needed. A maximizing r is given by the explicit piecewise expression above. It is allowed to depend on u HERE because AE2 supplies a new valid payment, not because the old Holder proof tolerated u-dependent r.

## AE3 Actual companion and root price, including the factor2

Positivity and the two R183 endpoint estimates give

C_rec[F_sup] <= C_rec[F_0]+C_rec[F_1]
             <= log(2)/(18 kappa_n) Wnu.                (AE3)

The same original receiver dx, unique j, original high/good/bad and capture, source parent and fixed-J time integration are those of R183. The two terms are positive budgets for the same weighted integral, not two pieces of signed credit. The factor2 is fully paid. No continuum menu size is charged, and no count is silently discarded.

For one prescribed theta>0, restrict the still-unpaid positive original reciprocal traffic to F_sup>=theta. Then C_branch<=C_rec[F_sup]/theta. With the actual fixed-J energy nWnu/(2K), and hard cap/outer factor32Lambda0/3 each used once,

Raw_rec^+[F_sup>=theta]
 <=(32Lambda0/3) sqrt[n log(2)/(36 K kappa_n theta)] Wnu
 <=same coefficient W_A.                                (AE4)

For fixed theta this is root order. All older paid branches must first be removed. This does not prove strict enlargement over their physical union, nor prove all original traffic satisfies this threshold. Independent windows still pay their true source reuse; no new automatic window summation is inferred.

Among pointwise bounds of the form E(R)<=b0+b1*(27/4)R valid for all R>=0 with nonnegative fixed coefficients, b0>=1 by R0 and b1>=1 by R tending infinity. Thus total endpoint price b0+b1 cannot be less than2 in this restricted domination scheme. This is algebraic optimality of the chosen two-weight comparison, not a lower bound on the physical maximal-operator constant.

## AE4 Exact low-envelope event

Let w=wg(y,v)>0 and a=w^2/theta. If a>=1, the envelope is at least theta for every effective u. If 0<a<1, monotonicity and AE1 give

F_sup>=theta iff Rbase>=T(a),
T(a)=4/(27a) for 0<a<=4/9,
T(a)=1-sqrt(a) for 4/9<a<1.                              (AE5)

At the joining point both values are1/3. This displays the whole family of r thresholds without an unpriced union. The complementary event Rbase<T(a) is retained exactly, not renamed as an already bounded moment.

## AE5 Actual common-source likelihood, with normalization retained

On an original high row with t<=g, suppose alpha>0 and use the original reciprocal bad domain BcapR. The two measures on this SAME domain are subprobabilities

P(du)=1_BcapR p_u nu(du)/q,
S(du)=1_BcapR k_u nu(du)/(alpha QJ).

The first uses original current capacity; the second uses same-alpha reserve capacity. On their nonzero support let

ell_u=dS/dP=q k_u/(alpha QJ p_u),
z_v=alpha J_v/a_v.

Then the exact factorization is Rbase=z_v ell_u. Neither P nor S is replaced by a probability without its mass. The actual posterior restricted to BcapR satisfies

Pi_y,t(du) <= P(du)/(2K kappa_n),                         (AE6)

because q wt/(e_t p_u)<=wt wg/(2K kappa_n)<=1/(2K kappa_n). Thus Markov in the current source measure, with int ell dP=||S||<=1, gives when0<a<1

Pi_y,t(BcapR intersect {F_sup>=theta})
 <= min{1, ||P||/(2K kappa_n), z_v/(2K kappa_n T(a))}.    (AE7)

This is an actual posterior statement, not a substitution Pi=P. If z_v=0 in the original alpha0 branch, the traffic is first zero; no normalization by alpha is formed. One may retain actual ||S|| in the numerator for a sharper bound.

If the actual good weight A(v)=rho_v J_v/(3Q_v)>1-eta, with0<eta<1, then rho_v>1-eta and z_v<eta. Also (p_v+pplus_v)/J_v<eta/(1-eta), and (k_v+alpha J_v)/a_v<eta. Therefore AE7 is at most eta/[2K kappa_n T(a)]. For example when w^2<= (1-sigma)^2 theta,0<sigma<1, one has 1/T(a)<=1/sigma and the simpler bound eta/(2K kappa_n sigma).

The inequality 1/T(a)<=1/(1-sqrt(a)) on the small-a branch follows from (27/4)a(1-sqrt(a))<=1 for sqrt(a)<=2/3; the function increases to1. This is not a claim that the entire low-envelope complement is small: the inequality bounds the PAID high-envelope fraction, and can make it small in the high-A/low-good-overlap corner. Its role is to identify the correct remaining extremal geometry while retaining both actual source densities.

## AE6 Information-accounting qualification and remaining task

D02 Gibbs/entropy skill was used to check the source reference and finite-domain qualifications. P,S above are subprobabilities; converting them to probability measures introduces their masses and changes the likelihood. No finite KL or uniform exponential-moment bound on the physical receiver-selected source law has been proved here, so no entropy cost is silently credited to the target estimate. The proof uses exact density comparison and the first reserve moment only.

The new source payment is AE3–4, obtained by a real positive domination that resolves the pair-adaptive menu issue at factor2. AE5–7 describes its complement and shows why small capture ratio z_v may coexist with large original positive traffic. R184's instantaneous extremal localization must therefore be combined with original K0/current hard-face and overlap geometry in that corner; this note supplies no general root price for it. All finite checks of AE1–5 are algebra, not original physical FIRST/history constructions.
