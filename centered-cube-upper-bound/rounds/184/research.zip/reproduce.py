#!/usr/bin/env python3
"""Verify archived bytes; optionally replay finite checks in a new directory."""
import argparse, hashlib, json, pathlib, shutil, subprocess, sys
p=argparse.ArgumentParser()
p.add_argument('--verify-only',action='store_true')
p.add_argument('--output-dir',type=pathlib.Path)
a=p.parse_args()
base=pathlib.Path(__file__).resolve().parent
manifest=json.loads((base/'inventory.json').read_text())
for name, digest in manifest['sha256'].items():
    path=base/name
    if hashlib.sha256(path.read_bytes()).hexdigest()!=digest:
        raise SystemExit('HASH MISMATCH: '+name)
print('ARCHIVE_HASHES_PASS',len(manifest['sha256']))
if a.verify_only:
    sys.exit(0)
if a.output_dir is None:
    p.error('supply --verify-only or --output-dir NEW_DIRECTORY')
a.output_dir.mkdir(parents=True,exist_ok=False)
for name in ['numerical_checks.py','task_contract.md','kernel_ratio_geometry.md']:
    shutil.copy2(base/name,a.output_dir/name)
out=a.output_dir/'numerical_checks.json'
subprocess.run([sys.executable,str(a.output_dir/'numerical_checks.py'),'--output',str(out)],check=True)
if json.loads(out.read_text())!=json.loads((base/'numerical_checks.json').read_text()):
    raise SystemExit('FULL_JSON_MISMATCH (check dependency version and entry-file hash)')
print('FULL_JSON_REPLAY_MATCH')
