from fractions import Fraction as F
from math import isqrt

def sqrt_bounds(x):
 S=10**45; k=isqrt(x.numerator*x.denominator*S*S)
 return F(k,x.denominator*S),F(k+1,x.denominator*S)
def sq_bounds(a,b):
 if a<=0<=b:return F(0),max(a*a,b*b)
 return min(a*a,b*b),max(a*a,b*b)
counts={}; positives=0
for phase,N in [('initial',4),('ties',6),('expanded',9)]:
 count=0
 for seed in range(1,5):
  # Finite full-source matched incidence, not a native receiver field.
  f=[F(1+(i*seed)%5,7) for i in range(N)]
  C=[[int(i<=j or ((i+j+seed)%5==0)) for j in range(N)] for i in range(N)]
  m=[sum(f[i]*C[i][a] for i in range(N)) for a in range(N)]
  du=[F(1+(a+seed)%4,3) for a in range(N)]
  mu=[du[a]/m[a] for a in range(N)]
  q=[F(3+(a%2),4) for a in range(N)];qmin=min(q)
  J=[sum(mu[a]*C[i][a] for a in range(N)) for i in range(N)]
  inv=[sqrt_bounds(1/j) for j in J]
  elo=ehi=F(0)
  for a in range(N):
   for i in range(N):
    for j in range(N):
     w=q[a]*du[a]*f[i]*f[j]*C[i][a]*C[j][a]/m[a]**2
     if not w:continue
     for k in range(N):
      l=C[i][k]*inv[i][0]-C[j][k]*inv[j][1]
      h=C[i][k]*inv[i][1]-C[j][k]*inv[j][0]
      sl,sh=sq_bounds(l,h);elo+=w*mu[k]*sl;ehi+=w*mu[k]*sh
  assert ehi-elo<F(1,10**35)
  for rho in [F(5,4),F(3,2),F(2),F(4)]:
   correction=far=F(0)
   for i in range(N):
    near=sum(mu[a]*mu[b]*C[i][a]*C[i][b] for a in range(N) for b in range(N) if m[a]<=rho*m[b] and m[b]<=rho*m[a])
    ordered=sum(mu[a]*mu[b]*C[i][a]*C[i][b] for a in range(N) for b in range(N) if m[a]>rho*m[b])
    assert 2*ordered+near==J[i]**2
    correction+=f[i]*near/J[i];far+=f[i]*ordered/J[i]
   # Algebraic lower bound uses ACTUAL near moment. No native volume bound imported.
   lower=qmin*(1-1/rho)*(sum(du)-correction)
   assert lower==2*qmin*(1-1/rho)*far
   assert elo>=lower
   positives+=lower>0;count+=1
 counts[phase]=count
print('PASS rigorous rational sqrt enclosures and far/closed-near identities',counts)
print('strictly_positive_algebraic_lower_bounds',positives)
print('Finite matching algebra only; native mass-window volume theorem is analytic, not tested by receiver atoms.')
