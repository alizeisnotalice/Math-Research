# R407 independent audit — FINAL PASS (structural scope; general budget unresolved)

FINAL PASS for the full-scale normalized-energy structural theorem, its mass-window and comparable positive-component estimates, and the precisely priced original-marked bridge. The formal paid ledger remains R406; the full-energy root bound and current marked far budget are unresolved. Only this audit file was edited. Independent screens below preceded the R407 author proofs; later post-review and final byte bindings complete this bounded audit. No author/repository edits or counterexample search were performed.

## 1. Entering contract that must survive a chain argument

The current R406 optional linear version fixes the SAME complete f, m_u=f(Q_u)=q_uR_u^n, q_-<=q_u<=lambda, a<=R<=b<=2a, actual mu(du)=du/m_u, sigma(du)=q_u du, pi_u=f c_u/m_u, K=e^sqrt(n), and h=(1+sqrt(n))/(epsilon0 q_-). The actual source-labeled Gamma0 has its original clock average, loss, source/target/geometry/history marks, strict mass gate m_u>K m_v and the original middle-rank strip. On the retained old source y, T_v(y)>4h+kappa Ztot(y). This is an actual old-source restriction; it is not a full-posterior condition for every new sampled source of v.

The linear R406 lower-rank receipt and its full mother fees are already charged once. A subsequent auxiliary path must retain its original root labels and original positive cost; it may add random labels as a positive disintegration, but may not requalify descendants as old-history inputs or reuse old source fees without a bound for their actual incoming measure. Recomputing f, m, J, ranks, clocks, switching b_i or cold gates is a different field/proof.

## 2. What strict mass descent proves exactly

Let m_-=q_-a^n, m_+=lambda b^n. Every continuation with m_next<m_current/K decreases log mass by more than log K. The number of successful jumps is bounded conservatively by

    N=ceil(log(m_+/m_-)/log K),

with terminal generation counted separately if necessary. On the octave N=O(sqrt(n)) with its explicit q-band dependence. Atoms do not enlarge this bound because the mass inequality is strict. This is a geometric termination fact, not a source-capacity statement.

For an actual finite substochastic path with injection I, continuation P and total arrival occupancy O=I+OP, let b=1-P1 denote its complete stopping hazard. Then the positive conservation identities are

    O=sum_{j>=0} IP^j,  terminal=O b,  terminal(total)=I(total).

All original marks may be retained in an augmented history state. Alternatively a positive actual occupation disintegration can define an effective kernel, but its reference domination still has to be proved. Conditioning the process on a selected future terminal event before deriving row/column bounds is not such a proof.

For any bounded potential V, the exact finite-path identity is

    integral O(du)P(u,dv)[V(u)-V(v)]
       =integral V dI-integral V d(terminal).

Taking V=log(m/m_-) proves only a jump-count budget bounded by log(m_+/m_-)/logK times I(total). It does not turn the input mass (typically Xq or an original edge cost) into W. Moreover the current Gamma already includes its fractional mass loss; a mass-difference telescoping law for a different transport measure cannot simply substitute Gamma without its real change-of-density factors.

## 3. Concrete common conditions sufficient for a root source fee

A terminal source draw at state u must be its actual subprobability joint kernel, e.g. theta(history,u,y)pi_u(dy), 0<=theta<=1 when it is dominated by the complete posterior. The exact reference-source projection of sigma is

    sigma(du)pi_u(dy)=f(y)c_u(y)du/R_u^n dy.

It is not f(y)mu(du)dy, nor a probability measure over all receivers. If reference rho=r(u)sigma(du) is used instead, the factor r must remain in the source projection. Changing sigma to du or mdu requires the corresponding q or m density and bounds, not an implicit reversibility claim.

Two usable sufficient contracts are:

(A) A per-generation contract: the SAME actual path has each incoming measure bounded by C rho, and its actual selected terminal kernel has reference source price <=B0 W with B0 dimension-free up to declared logarithms. At most N+1 terminal generations then cost <=C(N+1)B0 W. This is root-order only if the actual B0 has no additional sqrt(n) factor. A native terminal estimate already costing Delta=O(sqrt(n)) per generation gives O(n)W through this argument, not root order.

(B) An occupation/defect contract: one common substochastic P and one nonnegative reference rho satisfy rhoP<=rho, the ACTUAL injection satisfies

    I<=C d,  d=rho-rhoP,

and the actual terminal source kernel has reference price <=B W. Then positive telescoping proves

    sum_{j=0}^{N}IP^j
      <=C sum_{j=0}^{N}(rho-rhoP)P^j
      =C(rho-rhoP^(N+1))<=C rho.

The total terminal source fee is then <=CBW, with no N multiplier. This is useful if B itself is root-order. Crucially I<=C rho alone does NOT give this conclusion; it gives at best a generation-count multiple absent some additional decay. The incoming deficit is a common measure, not a separately assigned slack for each stage or path.

A more general source potential can replace (B), but it must exhibit a real one-step terminal/drift inequality for the SAME actual path and an initial/source integral bounded by epsilon Xq plus the claimed W price. The positive exit and injection terms must be displayed. Merely naming a finite mass potential or giving positive variance does not provide that source integral.

For example, if a single canonical P has both a genuine row survival contraction and a proved reference-terminal source capacity, a finite head plus a small surviving-tail Xq price can also be valid. Those two facts must refer to the SAME kernel: one cannot borrow the original Gamma row beta while borrowing the native missing-rank terminal cost of a different rank-Q process. That changes which stops exist and their actual masses.

## 4. What the present actual Gamma supplies, and does not

The current sourcewise outgoing bound beta and incoming sigma-density bound Ccol are real, but only imply

    sigma K_actual<=Ccol sigma.

There is no established sigma-subinvariance when Ccol>1, nor a common incoming-defect domination for the actual injection. Repeated frozen transitions may have columns controlled only by Ccol^j. The row beta<1 controls total survival mass/L-infinity, not concentration relative to sigma or the source projection. It does not itself supply a terminal W price.

A formal auxiliary path can be attached to an original edge as additional randomness and preserve its original root cost. Since all its terminal outcomes sum to the original cost, a complete source bound for that terminal law would pay the original bill. But an auxiliary endpoint's new full posterior is not the old transported source. After sampling y' from pi_v, the earlier T_v(y)>4h+kappa Ztot(y) says nothing about y' without a new estimate. Keeping y fixed avoids that particular swap but still does not give a terminal capacity or conserved source potential. Likewise the first/current core, cold, geometry and temporal tests do not automatically hold for descendants merely because they satisfy strict mass descent.

Dropping a terminal type because it was paid at the original entry is invalid unless its new labeled incoming measure is dominated by the original paid measure with an explicitly priced constant. One must state all stopping types and their precedence, include the terminal probability left by row normalization, and count each root edge exactly once. Shared full f does not allow private per-chain copies of W.

Thus the existing Gamma facts do not yet instantiate (A), (B), or a source-integrated drift certificate. This is a precise missing contract, not a claim that no such construction can exist. The next useful author statement should specify its actual continuation, actual injection, selected/other terminal types, common reference or source potential, and the quantitative source projection it proves.

## 5. Actual bounded local check

Executed a local standard-library Python Fraction check: 54 identities across nine finite directed-chain cases (2,4,8 states and survival 0,1/2,1). It verified O=I+OP, I<=rho-rhoP implies O<=rho, complete terminal mass conservation, terminal reference domination, the finite potential telescoping identity, and the weaker N-times mass bound when only I=rho is supplied. These are algebra checks of the sufficient contracts, not a native matched cube path, original history realization, or evidence of a new W bound. No separate script was saved and this reviewer execution is not pooled with future author counts.

The initial independent terminal/source prefilter ended here; it certified no new chain/source budget. The subsequent actual author candidates are reviewed below. All original R406 prices and unproved global slots remain.

Context SHA-256:
- `/tmp/r406_aux.md`: `db741a843da268a794d1dd653bfa04b977d66dbda10ca605131f7d3ba77c3f5e`
- `/tmp/r406_main.md`: `433f82a68430e2de4459c16214364bfacbd699c88652049713aeda5a8dce70f4`


## Independent screen of the normalized shared-source energy (before auxiliary proof)

For each source y define J(y)=Ztot(y)=integral c_w(y)dw/m_w. On J>0 define the probability law p_y(dw)=c_w(y)dw/[m_w J(y)] and its square-root feature e_y(w)=c_w(y)/sqrt(m_w J(y)) in L2(dw). Equivalently use e_y=c_w(y)/sqrt(J(y)) in L2(mu); the Hellinger distance is invariant under this common change of dominating measure. On J=0 set e_y=0. This does not introduce a false probability normalization: Tonelli gives integral fJ=|E|, and sigma(du)pi_u(dy) assigns zero mass to source points with J=0. All source draws in the proposed energy therefore have ||e_y||=1 almost everywhere. A standalone source law f(y)dy is NOT the source marginal of du pi_u; that marginal is f(y)J(y)dy.

The affinity and the proposed energy are exactly

    <e_y,e_z>=C_all(y,z)/sqrt(J(y)J(z)),
    E_q=integral sigma(dA)pi_A(dy)pi_A(dz)||e_y-e_z||^2
       =2Xq-2 integral sigma(dA)||integral pi_A(dy)e_y||^2.

The identities are well-defined finite Hilbert/Tonelli integrals; Jensen bounds the latter integral by Xq, so there is no infinity subtraction. The measure in the outer integral is q_A dA, not m_A dA. Under f->cf, both E_q and W scale by c whereas the probability features are invariant; constants in an E_q/W bound should depend on q-band ratio, not an artificial density normalization. Coordinate/source independence is not assumed: the two source draws are the actual product of the complete posterior pi_A, not a product source density imposed on f.

A universal E_q<=C sqrt(n)polylog(n)W would be a genuine new joint-geometric theorem. The normalization, finite J bound, posterior contraction and integral fJ=|E| alone do not prove it. This is a more geometry-sensitive quantity than the unnormalized P2: it measures variation of the full receiver capture law across two sources of one actual parent. The exact identity is not itself a newly paid negative-square credit and is not the old BH square available for a second subtraction.

### Exact bridge to the marked two-end bill

At an actual endpoint A use the SAME far prefix for y,z and let C_A(y,z) be its common capture. Suppose on a selected source pair

    [Z_A(y)-C_A(y,z)]/J(y)>=kappa,
    [Z_A(z)-C_A(y,z)]/J(z)>=kappa.

The two receiver sets capturing only y and only z within that prefix are disjoint; on each, the other probability law has zero density. Consequently the Hellinger squared norm is at least the sum of those two probabilities, hence >=2kappa. There is no cancellation or triangle-inequality loss in this lower bound. Merely assuming Z_A/J>=kappa and C_A<h, without a spare additive margin, would NOT give this same kappa. The original linear old gate T_v(y)>4h+kappa J(y), the far inclusion Z_u(y)>=T_v(y), the native T_v-Z_v<=epsilon0 h and C_A<h do provide sufficient old-source margin at both u and v.

A concrete new-source cleanup is: retain only Z_A(z)>4h+kappa J(z) on each endpoint bill. Its low part implies T_A(z)<=(4+epsilon0)h+kappa J(z). Summing the same-z stage marks first and then using the actual old-source outgoing/incoming capacities beta,Ccol gives a once-only new-source price

    S lambda[(4+epsilon0)hW+kappa|E|]
       <=(4+epsilon0)S lambda hW+S(lambda/q_-)kappa Xq.

This price is additional to the old-linear source cleanup, not free reuse of it. An alternative precise threshold can give another valid complete fee, but no such omitted price may be presumed. On the retained pair, both normalized exclusives are >=kappa. Inserting the true squared Hellinger factor into the original external and small-end positive costs, keeping their original y and same z stage labels, yields

    2kappa R_both <= E_Theta <=(beta+Ccol) E_q.

The upper inequality uses pointwise old-source capacities and drops only positive extra restrictions; it does not assert independence of the original v or replace the external E_uv/Z_u reweighting by one. The original physical clock was already retained in Gamma0 before its capacities were applied. New sources/receiver witnesses receive no historical qualification.

Thus IF the stated global E_q theorem holds, it could pay this whole selected residual after both explicitly priced source cleanups, with the unavoidable factor S/(2kappa). This is conditional sufficiency for the current marked cost, not proof of that theorem or general closure. For kappa>=1 the strict gates are empty; a nontrivial version uses 0<kappa<1. Source/field parameters and absorption must be chosen simultaneously in the mother ledger.

### Actual low-dimensional true-field sanity computation

Executed a Python ordinary-double check on one fully specified native 1D field: f=1_[−4,4], W=8; actual receiver interval E1=[−1,−1/2] with R=1, E2=[1/4,3/4] with R=2. These intervals are disjoint, so the selector is single-valued; all cubes lie in the source support, m_A=R_A, q_A=1, a=1,b=2, Xq=1 and the 4/3 q-band holds. This is not an original high-rank/history/core fixture or a near extremizer.

For y,z, the exact receiver capture length in Ei is

    ell_i(y,z)=[min(Ei_upper,min(y,z)+Ri/2)
                       -max(Ei_lower,max(y,z)-Ri/2)]_+.

Accordingly J(y)=sum_i ell_i(y,y)/Ri, C_all=sum_i ell_i(y,z)/Ri, and the actual parent-integrated source-pair kernel is B_q(y,z)=sum_i ell_i(y,z)/Ri^2. Receiver integration is analytic. Source y,z integration was ordinary midpoint quadrature on [−1.5,1.75] with mesh 1/(4N), N=16,32,64. Results for E_q were respectively 0.403122274261357, 0.403110707522401, 0.403107473535544. Squared Hellinger values were nonnegative on these grids; the positive formula and 2Xq minus the affinity formula agreed, and the computed integral B_q−Xq was zero to displayed double precision. These checks make the normalization and q weighting concretely testable. They do NOT certify the square-root-source integration error, a convergence rate, a dimension exponent or a global bound. No separate script was saved and these three reviewer grids are not pooled with later author checks.

The Hellinger screen passed for definitions and the explicitly conditional marked bridge. The universal root-order energy estimate was not proved; the reverse comparison and final author review below sharpen the scope.


## Independent reverse-energy estimate: arbitrary comparison ratio, not the original flow K

Before reading the author's proof, independently derived the proposed reverse inequality and its stronger rho=2 specialization. Fix ANY auxiliary comparison ratio rho>1 solely inside the full, unmarked E_q integral. This does not redefine the original far-mass gate K, h, f or any current flow. For each parent A and receiver w with m_A>rho m_w, full matching gives pi_A(c_w)<=m_w/m_A<1/rho. Cauchy on the support of c_w gives

    Var_{pi_A}[c_w/sqrt(m_w J)]
      >=(1-pi_A(c_w)) pi_A[c_w/(m_w J)]
      >=(1-1/rho) pi_A[c_w/J]/m_w.

All variances are positive componentwise; retaining only these w is legitimate even though this auxiliary comparison mask is NOT the original Gamma support. The full Hilbert variance identity therefore gives

    E_q>=2q_-(1-1/rho) integral_{J>0} f(y)/J(y)
              [integral c_A(y)mu(dA) Z_A^rho(y)]dy,
    Z_A^rho(y)=integral c_w(y)1_{m_w<m_A/rho}mu(dw).

For fixed y, the two strict far directions partition the complement of the CLOSED mass-ratio window. Atoms at equality belong to that near window, not to either strict far part. Thus exactly

    2 integral rho_y(dA)Z_A^rho(y)=J(y)^2-N_rho(y),
    N_rho=integral rho_y(dA)rho_y(dw)
                       1_{m_A/rho<=m_w<=rho m_A}.

The actual matched-center closed-window bound, not a fixed-radius shell heuristic, gives

    N_rho(y)<=[1+2log(rho)] J(y)/q_-.

After dividing by J, the source integral is bounded below by the integral of J minus the fixed window constant. Source points with J=0 are excluded from the positive integral; extending the negative constant term to all f only weakens the lower bound. Since integral fJ=|E|>=Xq/lambda,

    E_q >= (q_-/lambda)(1-1/rho) Xq
                -(1-1/rho)[1+2log(rho)]W.                 (*).

Every q/measure factor is accounted for: the parent variance is integrated against q_A dA, then q_A>=q_- is used; only after the ordered mu-pair identity is the source normalization f/J canceled. No source-density cap, nonatomic mass CDF, false reversibility or independent radius is assumed.

Taking rho equal to the original K=e^sqrt(n) reproduces the initially proposed root-error version. More strongly rho=2 is freely allowed in this energy-only proof and yields

    E_q >= q_- Xq/(2lambda)-(1+2log2)W/2,
    Xq <=(2lambda/q_-)E_q
                         +(lambda/q_-)(1+2log2)W.

Together with E_q<=2Xq, this shows E_q+W and Xq+W are equivalent up to constants depending only on the q-band ratio, with NO dimension-dependent error. In particular a universal full-energy root-order W bound is quantitatively equivalent to the corresponding local Xq root-order bound. It is not demonstrated as a simpler independent geometric tool by its normalized formulation. This does not refute the energy conjecture or forbid an energy proof; it prevents reporting a mere reduction to that full-energy conjecture as progress toward paying the general marked core.

Nor may (*) be used as a lower bound on R_both: E_q includes source pairs and receiver components outside the original Gamma, while the actual bridge was an upper domination 2kappa R_both<=S E_q. The direction cannot be reversed or used to certify that the marked remainder is hard. A more restricted dynamically marked energy could have a different difficulty; no such theorem is asserted here.

Reverse-energy screen PASS with the displayed constants and atom conventions. The earlier energy normalization/bridge screen remains correct, but this coercivity calculation sharpens its scope: the proposed full unmarked E_q bound is essentially the original local weak-type budget. No new general root payment is obtained by this route.


## Independent all-scale extension of the structural reverse estimate

The closed-window capacity used above does NOT require the octave hypothesis. Let the receiver field have arbitrary measurable positive finite side lengths R_A, finite |E|, and actual masses m_A=f(Q_A) with q_-<=m_A/R_A^n<=lambda. For a fixed source and mass window [M/rho,rho M], capture implies z=(2||A-y||infinity)^n<=rho M/q_-, while the actual center density satisfies

    1/m_A<=1/max(M/rho,q_-z).

Its exact radial-envelope integral is

    integral_0^(rho M/q_-) dz/max(M/rho,q_-z)
      =[1+2log(rho)]/q_-.

The flat inner contribution is 1/q_- and the remaining shell is 2log(rho)/q_-. There is no hidden radius-lower cutoff, radius-menu assumption or independent selector integration.

Matching still gives integral fJ=|E|, and Xq<=lambda|E|. Thus J is finite fdy-almost everywhere even without a global pointwise center bound, and the J=0/infinite exceptional sources have zero mass under receiver-posterior sampling. One need not assume integral fJ^2 finite: the ordered pair identity is pointwise where J finite; after dividing by J its nonnegative integrand is <=fJ, which is integrable. All required feature/variance expressions therefore remain finite and Tonelli-safe.

Consequently the arbitrary-rho and rho=2 coercivity estimates above hold on this all-scale finite-measure field as structural comparisons. This strengthens only the range of that comparison. It supplies no upper estimate for Xq, no general weak theorem and no extension of the original marked Gamma contract beyond its octave; those claims must remain separate.

## Initial frozen auxiliary post-review

Read the complete r407_aux.md and delivered check script after completing the independent screens above. Its new-source gate uses the slightly sharper small-end T_v(z)>4h+kappa J(z), rather than the uniformly Z-based option in this prefilter. The small endpoint then retains Z_v(z)>kappa J(z)+(4-epsilon0)h, enough for the same separation. The actual new-source price is therefore

    lambda h[beta(4+epsilon0)+4Ccol]W+S(lambda/q_-)kappa Xq,

and adding the old-linear receipt yields its exact displayed conditional bridge

    R404<= (lambda/q_-)kappa(beta+3Ccol)Xq
       +lambda h[(4+epsilon0)beta+12Ccol]W
       +S E_q/(2kappa).

The author correctly combines stage marks on the same (y,u,v,z) space before capacities, retains the two original endpoints and all current marks, and does not confer old history on new witness receivers. Its full mother factor64Lambda applies to every new term while old R404 prices remain once. This bridge and its lack of energy upper payment are correct.

Actually reran r407_aux_check.py: 182 Fraction assertions, comprising36 inclusive proportional-CDF cuts,144 square-rank separation inequalities,2 finite Bayes marginal models. These finite incidence models are not a native selector, octave or original-history realization; the author states that limit. The script does not prove the new global energy upper bound, which remains unproved and by the reverse comparison is not a weaker budget target.

Two limited corrections were requested and subsequently verified in the frozen auxiliary: distinguish the q-weighted joint's conditional p_y^q=q_A c_A(y)mu(dA)/D(y) and refresh kernel P_q from original p_y/P (only the former is reversible under fD), and write the mass-drift inequality non-strict in the zero-cost case, with strictness only when R_both>0. The actual energy feature remains based on original p_y. Both corrections are complete, with unchanged fees and code.


## Final frozen proofs, report and actual evidence

Read the complete frozen r407_geometry.md. PASS: the theorem assumes a genuine measurable positive finite side at each actual center, finite |E|, same full f and matching q-band, and correctly does NOT require an octave for the structural energy comparison. The actual-center radial bound uses the radius forced by a mass window and includes both mass endpoints; it does not integrate an independent selector radius or discard mass atoms. The variance first term has total Xq, so its subtraction is finite. The arbitrary-rho ordered-pair split is symmetric in mu, with q_A>=q_- applied before the split and |E|>=Xq/lambda only at the end. This reproduces the independently derived rho=2, dimension-free coercivity exactly. J=0/infinite and potential integrability issues are handled via the true posterior sampling measure and integral fJ=|E|, without assuming integral fJ^2 finite.

Its comparable-mass positive energy component has the correct price

    E_q,cmp(rho)<=2(lambda/q_-)(1+2log rho)W.

The factor2 comes from the two nonnegative square terms; there is no extra factor2, and the comparison mask is inside the component integration rather than imposed after a whole-energy average. The complement still consists of both far-mass directions. These are auxiliary (A,w) mass comparisons, not the original ordered (u,v) far gate.

The author's optional actual marked soft allocation is also valid: on the already selected R_both where e(y,z)>=2kappa, multiply its original cost at endpoint A by e_cmp,A(y,z)/e(y,z), with zero convention if needed. The ratio is in [0,1], leaves an exact positive complement, and yields the stated S/(2kappa) times E_q,cmp price. It retains the same original b_i, old source, clocks and history. It does not price the complete marked remainder. Main/report do not insert this option into the formal R406 paid ledger or add it twice with another receipt.

Re-read the revised frozen auxiliary. The weighted Bayes correction now explicitly defines nu_q, p_y^q and P_q; original P remains reversible only under fJ, weighted P_q under fD, and e_y still comes from original unweighted p_y. The zero-flow mass drift is now <= with strictness only for R_both>0. The source-refresh covariance is retained with its true sign and source marginal; exit or descendant/history costs are not assumed zero. All proof fees, code and positive bridge constants are unchanged by these corrections.

Read final r407_main.md and r407_readme.md completely. PASS: all-scale structural assumptions are distinguished from the original octave Gamma; free rho does not reset K or h; E_q+W comparability is not called a weak-type upper bound. The exact alternative bridge has X coefficient r kappa(beta+3Ccol), W coefficient lambda h[(4+epsilon0)beta+12Ccol], and energy coefficient S/(2kappa), with original entrance multipliers64Lambda. It replaces the R406 square-root option if invoked; the formal adopted paid total instead remains R406, with old chi_n/Delta404/P_L and unproved slots once. The new-source gate price is explicitly charged and not obtained by reassigning old history. Main correctly does not reverse the E_marked<=S E_q inequality or infer a marked lower bound from the full-energy coercivity. The complete normalized-energy conjecture is quantitatively as strong as the local Xq problem, not a demonstrated simpler route.

Actual reviewer Python executions: r407_parent_check.py PASS48 rigorous rational square-root-enclosure and strict-far/closed-near cases (16 per stage,42 positive algebraic lower bounds); r407_aux_check.py PASS182 Fraction assertions; r407_geometry_check.py PASS348 Fraction assertions. Thus the delivered total is578 rigorous rational/certificate assertions, not native geometric/history samples. Parent48 uses the finite model's actual near moment, and geometry348 uses its finite actual window capacity; neither imports the native volume theorem into arbitrary receiver atoms. The original native all-scale mass-window result is proved analytically above. Reviewer reruns and parent reruns are the same delivered cases, not new independent experiments. The earlier54 finite-chain identities and three independent ordinary 1D source grids in this audit remain separate reviewer executions.

Read the entire MATLAB r407_energy_check.m and its recorded56-case output; did not rerun MATLAB as reviewer. The deterministic single-valued selector is defined by actual q tests and a specified priority among side lengths .5,.75,1. Full piecewise-constant source masses are analytically partitioned at source/capture faces. Source matching and normalized feature evaluation are consistent with the receiver-grid field, with reported balance error3.1883327886671152e-16 and feature-norm excess4.4408920985006262e-16. Receiver integration is ordinary midpoint quadrature; q-boundary selection and field discontinuities are not interval-certified. Empty receiver grids are skipped, accounting for56 rather than60 potential cases. n=1,2 and fluctuating grid results do not certify a dimension exponent, high-rank/history core, near extremizer, convergence rate or general energy estimate. These ordinary diagnostics are not pooled with578 rational checks.

The main's PDF/literature/skill reading statements are parent provenance and background, not additional theorems independently verified by this reviewer. No such citation is used as a prerequisite for the structural proof or its ledger claims. This audit does not re-review every historical reduction.

FINAL PASS in this bounded scope: the normalized-energy structural theorem and its exact marked bridge are correct with stated domains, source measures, constants, atoms and remaining fees. The comparable energy/soft component is a limited positive statement, not complete far payment. The adopted formal source/absorption ledger remains R406 and all general root-bound gaps remain explicit. No author/script/result/repository bytes were changed by this reviewer. Audit is frozen below.

## Final SHA-256 bindings
- `/tmp/r407_main.md`: `0e80fdd82f62c9d05dcb0c2483a0a38555bf1f021a9919b81a35a168819e358e`
- `/tmp/r407_readme.md`: `1fcd6a1919cbfa08d4ee677d951d45563af0ff952f7bd9584934af16d387973b`
- `/tmp/r407_aux.md`: `58b41f947f5e49552885635cdee6e85685ddfe91b74b7733c3b70e34effe816b`
- `/tmp/r407_geometry.md`: `b7d221cd722b1c4c94408c715af50f7cee4b20f15b8e2126c906ed05c0882266`
- `/tmp/r407_parent_check.py`: `55f7276acbb8abda506e4ba8a4f514ed1665f921af186e43e9ee3ec27d2658e6`
- `/tmp/r407_parent.result.txt`: `78c078a191cfea3347dd484546ca41dadc6a462754ff4cbe692b4d472fe5d6a2`
- `/tmp/r407_aux_check.py`: `edd957e602a901a9518c39bad70ab1742b553b618e7d15a2e6b6f79f855b93a6`
- `/tmp/r407_aux.result.txt`: `bbd616ab403a12abe9961799a79a62dc3fc0be9c4d307e8053976054eeed2f4e`
- `/tmp/r407_geometry_check.py`: `b6ffe156ee4aecd60d058f6d003ac08a126e39c06a32d00d6a683317c0dc84c9`
- `/tmp/r407_geometry.result.txt`: `2880b1f5994560c03f0c7bb40e98f043bf45353ace0465fbbc60c6c807777445`
- `/tmp/r407_energy_check.m`: `ab0377794f80cfa156d33805d8c71e72e28701fe6999b1c6c4ef43f7b4989c4e`
- `/tmp/r407_energy.result.txt`: `cab6a7c6074c3ce42acc33a2aee28d4a36119b59b7971143611b59be97a2f4db`
- `/tmp/r406_main.md`: `433f82a68430e2de4459c16214364bfacbd699c88652049713aeda5a8dce70f4`
- `/tmp/r406_aux.md`: `db741a843da268a794d1dd653bfa04b977d66dbda10ca605131f7d3ba77c3f5e`
