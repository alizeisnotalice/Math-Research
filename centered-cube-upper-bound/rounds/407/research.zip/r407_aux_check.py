from fractions import Fraction as F
from itertools import product
counts={'inclusive_ratio_cut':0,'normalized_separation':0,'shared_source_balance':0}
for atoms,h,kappa,eps in product(((F(1,4),F(1,3),F(2,5)),(F(3),F(1,4),F(1,2)),(F(1,10),F(4),F(1,10))), (F(1,100),F(1,10),F(1)),(F(1,20),F(1,4)),(F(1,4),F(1,2))):
    J=sum(atoms); T=F(0); target=4*h+kappa*J
    included=F(0)
    for atom in atoms:
        T+=atom
        if T<=target: included+=atom
    assert included<=target
    enlarged=target+eps*h
    assert sum(atom for j,atom in enumerate(atoms) if sum(atoms[:j+1])<=enlarged)<=enlarged
    counts['inclusive_ratio_cut']+=1
for ay,az,h,kappa,eps,C in product((F(1),F(2),F(3)),(F(1),F(2),F(3)),(F(1,100),F(1,20)),(F(1,20),F(1,5)),(F(1,4),F(1,2)),(F(0),F(1,200))):
    Jy,Jz=ay*ay,az*az
    Zy=kappa*Jy+(4-eps)*h; Zz=kappa*Jz+(4-eps)*h
    if not(C<h and C<=min(Zy,Zz) and Zy<=Jy and Zz<=Jz): continue
    prefix_energy=Zy/Jy+Zz/Jz-2*C/(ay*az)
    assert prefix_energy>=2*kappa
    counts['normalized_separation']+=1
# A finite shared-source incidence model. It checks invariant marginals only;
# it is not an actual selector or a realization of original history gates.
source=[F(1,3),F(2,3),F(3,2)]
incidence=[[1,1,0],[0,1,1],[1,1,1]]
mu=[F(1,4),F(1,3),F(1,2)]
for q in ((F(1),F(1),F(1)),(F(3,4),F(1),F(4,5))):
    mass=[sum(w*c for w,c in zip(source,row)) for row in incidence]
    sigma=[q[a]*mass[a]*mu[a] for a in range(3)]
    D=[sum(q[a]*mu[a]*incidence[a][y] for a in range(3)) for y in range(3)]
    conduct=[[sum(sigma[a]*(source[y]*incidence[a][y]/mass[a])*(source[z]*incidence[a][z]/mass[a]) for a in range(3)) for z in range(3)] for y in range(3)]
    for y in range(3):
        assert sum(conduct[y])==source[y]*D[y]
        for z in range(3): assert conduct[y][z]==conduct[z][y]
    assert sum(source[y]*D[y] for y in range(3))==sum(sigma)
    counts['shared_source_balance']+=1
print('PASS',counts,'total',sum(counts.values()))
