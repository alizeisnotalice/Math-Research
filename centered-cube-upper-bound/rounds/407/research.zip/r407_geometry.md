# R407：完整后验 Hellinger 能量的反向强制性与可比质量正分量

2026-10-19。**结论范围：**完整无标记能量不是比原接收总量更弱的待证目标；下述双向比较的误差仅为维数无关的 W 项。可比质量部分确有独立 W 价格，但不支付远质量补集。本稿不改变原 K、原时钟或任何历史门，不声称闭合当前带标记余项。

## 1. 一般实际场与定理

设 f≥0 属于 L1(R^n)，W=∫f。E 是有限 Lebesgue 测度的可测实际接收集，A↦R_A∈(0,∞) 可测，Q_A 是以 A 为中心、边长 R_A 的轴平行立方体。要求完整匹配

\[
m_A=\int_{Q_A}f=q_A R_A^n,\qquad 0<q_-\le q_A\le\lambda<\infty.
\]

本定理不需要 R_A 处在 octave。当前应用仍是冻结的原 octave 场。记

\[
c_A(y)=1_{Q_A}(y),\quad \mu(dA)=dA/m_A,\quad
\sigma(dA)=q_A dA,\quad \pi_A(dy)=f(y)c_A(y)dy/m_A,
\quad X_q=\int_Eq_A dA.
\]

令 Z(y)=∫c_A(y)μ(dA)。Tonelli 与完整匹配给

\[
\int f(y)Z(y)dy=|E|. \tag{1}
\]

因此 Z<∞ 对 f(y)dy 几乎处处成立。在 0<Z(y)<∞ 上定义概率密度

\[
p_y(w)=\frac{c_w(y)}{m_w Z(y)}\quad\text{相对于真实 }dw.
\]

在其余来源点任意置零；这些点在 σ(dA)π_A(dy) 下为零测集。所有函数均联合可测，后续正积分使用 Tonelli。定义

\[
e(y,z)=\int_E(\sqrt{p_y(w)}-\sqrt{p_z(w)})^2dw,
\qquad
\mathcal E_q=\int_E\sigma(dA)\int\pi_A(dy)\pi_A(dz)e(y,z).
\tag{2}
\]

对任意辅助数 ρ>1（与原流固定的 K 无关），有

\[
\boxed{\quad
\frac{q_-}{\lambda}(1-\rho^{-1})X_q
 -(1-\rho^{-1})(1+2\log\rho)W
 \le\mathcal E_q\le2X_q.\quad} \tag{3}
\]

尤其 ρ=2 给

\[
\boxed{\quad X_q\le\frac{2\lambda}{q_-}\mathcal E_q
 +\frac{\lambda}{q_-}(1+2\log2)W.\quad} \tag{4}
\]

定义正分量（限制必须放在平方差积分内部）

\[
\mathcal E_{q,\mathrm{cmp}(\rho)}
=\int\sigma(dA)\pi_A(dy)\pi_A(dz)
 \int 1_{m_A/\rho\le m_w\le\rho m_A}
 (\sqrt{p_y(w)}-\sqrt{p_z(w)})^2dw.
\]

则

\[
\boxed{\mathcal E_{q,\mathrm{cmp}(\rho)}
 \le \frac{2\lambda}{q_-}(1+2\log\rho)W.} \tag{5}
\]

ρ=2 的价格维数无关；ρ=K=e^{√n} 的价格为 2(λ/q_-)(1+2√n)W。其正补集是 m_A>ρm_w 与 m_w>ρm_A 两部分。式(5)不估计这两部分。

## 2. 唯一原生几何输入：闭质量窗容量

对任意来源 y 及固定 0<L≤U<∞，

\[
\int_E\frac{c_A(y)}{m_A}1_{L\le m_A\le U}dA
 \le\frac{1+\log(U/L)}{q_-}. \tag{6}
\]

证明不把选择器半径当独立积分变量。令 r=2||A−y||∞。若 c_A(y)=1 且 m_A≤U，则 r≤R_A≤(U/q_-)^{1/n}；同时 m_A≥max(L,q_-r^n)。直接按实际中心 A 积分并外放松到整个中心立方体，得到

\[
\begin{aligned}
\int_E\frac{c_A(y)}{m_A}1_{L\le m_A\le U}dA
&\le \int_0^{(U/q_-)^{1/n}}
 \frac{nr^{n-1}}{\max(L,q_-r^n)}dr\\
&=\frac1{q_-}+\frac{\log(U/L)}{q_-}.
\end{aligned}
\]

这里半径 r 的中心立方体体积是 r^n。闭窗端点均保留，中心积分中相应几何边界无体积。此证明适用于任意实际可测半径场，不要求固定 R，也不使用来源密度帽。

## 3. 反向式的证明：先保证无 ∞−∞

记 π_A(g)=∫g dπ_A。对几乎所有实际 (A,w)，独立的 y,z∼π_A 给精确方差式

\[
\int\pi_A(dy)\pi_A(dz)
 (\sqrt{p_y(w)}-\sqrt{p_z(w)})^2
=\frac2{m_w}\left[\pi_A(c_w/Z)
 -(\pi_A(c_w/\sqrt Z))^2\right]. \tag{7}
\]

它的非负第一项可积，事实上

\[
\int q_A dA\int\frac{dw}{m_w}\pi_A(c_w/Z)
=\int q_A dA\,\pi_A(1)=X_q. \tag{8}
\]

式(8)用 Z 的定义及上述零测集约定。故 (7) 的减法有限；Cauchy–Schwarz 又保证第二项不大于第一项。积分给 0≤E_q≤2X_q，不涉及两个无穷量相减。

现在仅保留 m_A>ρm_w 的非负能量部分。由完整匹配

\[
p:=\pi_A(Q_w)=\frac{f(Q_A\cap Q_w)}{m_A}
 \le\frac{m_w}{m_A}<\rho^{-1}.
\]

带 c_w 的 Cauchy–Schwarz 给

\[
(\pi_A(c_w/\sqrt Z))^2
\le p\,\pi_A(c_w/Z),
\]

所以 (7) 在该部分至少为 2(1−ρ^{-1})π_A(c_w/Z)/m_w。这一步使用全部 f 的匹配质量，而非来源点密度或新历史。

固定 y，记 ρ_y(dA)=c_A(y)dA/m_A，其总量为 Z(y)；定义

\[
F_y=\iint1_{m_A>\rho m_w}\rho_y(dA)\rho_y(dw),
\quad N_y=\iint1_{m_w/\rho\le m_A\le\rho m_w}
 \rho_y(dA)\rho_y(dw).
\]

这里符号 ρ_y 是测度，ρ>1 是独立辅助常数。两个严格远质量区互为转置，等号全部归入闭窗，故包括任意质量原子时仍精确有

\[
2F_y=Z(y)^2-N_y. \tag{9}
\]

对每个 w 应用 (6) 的 L=m_w/ρ、U=ρm_w，得到

\[
N_y\le C_\rho Z(y),\qquad C_\rho=(1+2\log\rho)/q_-.
\tag{10}
\]

因此由 q_A≥q_-、Tonelli、(1)，

\[
\begin{aligned}
\mathcal E_q
&\ge2q_-(1-\rho^{-1})\int\frac{f(y)}{Z(y)}F_y\,dy\\
&\ge q_-(1-\rho^{-1})(|E|-C_\rho W)\\
&\ge\frac{q_-}{\lambda}(1-\rho^{-1})X_q
 -(1-\rho^{-1})(1+2\log\rho)W.
\end{aligned}
\]

所有 Z 分母只在 0<Z<∞ 使用；Z=0 的来源不收费。若 |E|−C_ρW<0，最后下界仍正确，未将其强制正化。

## 4. 可比质量分量的证明与准确作用

对 a,b≥0，(√a−√b)^2≤a+b。交换 y,z 后两项相等。因此

\[
\begin{aligned}
\mathcal E_{q,\mathrm{cmp}(\rho)}
&\le2\int\frac{f(y)}{Z(y)}dy
 \int\frac{c_w(y)}{m_w}dw
 \int\frac{q_A c_A(y)}{m_A}
 1_{m_w/\rho\le m_A\le\rho m_w}dA\\
&\le2\lambda C_\rho\int\frac{f(y)}{Z(y)}Z(y)dy
\le2\lambda C_\rho W.
\end{aligned}
\]

因平方根非负，首步没有额外因子 2；最终常数是式(5)的 2 而非 4。完整能量仍等于该正分量加两个严格质量远区，不能只以式(5)替代整个能量。

在 λ/q_- 一致有界的类上，由 (3)–(4)，任何全尺度或 octave 的统一根阶多对数 W 上界 E_q≤C√n log^A(n+2)W 都会直接给同阶 X_q 上界；反向由 E_q≤2X_q 自动成立。因此完整无标记能量的目标与原接收总量目标等价到维数无关 W 误差。**它不是新的几何捷径，也没有在本轮获得完整根阶付款。**

## 5. 原标记仍须保留；不创造新历史或新目标

为明确损失发生在哪里，令 dR_u^i、dR_v^i 分别为当前强分支的实际两端正费用测度，即原 Γ_i 加原 π_u/π_v、新来源 b_i(z)、原 far/common/rank/时钟/历史及全部保存乘子。将辅助见证 w 引入后，唯一自然的实际能量加权量是

\[
\mathcal E_{\rm marked}
=\sum_i\int e(y,z)\,dR_u^i
 +\sum_i\int e(y,z)\,dR_v^i. \tag{11}
\]

该写法仅记录必须保留的权重，不提出或声称一个新的已付目标。若已审强分支满足 e(y,z)≥2κ，则 2κR_strong≤E_marked。另一方面，由原逐来源 β、C_col、Γ_i 的嵌套限制和同一 z 上 Σ_i b_i(z)≤1，可正放松得 E_marked≤(β+C_col)E_q。正是这一步删去了动态 D_i/f 截断等 b_i 信息，转成与 X_q 同样困难的完整能量。

式(5)只允许支付其对应的正分量。更精确地，在强分支上可按端点 A=u 或 v 的比例 e_cmp,A(y,z)/e(y,z) 分拆实际费用，e_cmp,A 是式(5)的内部 w 积分。该比例处于 [0,1]，则所得正分量满足

\[
R_{\rm cmp(\rho)}
\le\frac{\beta+C_{\rm col}}{2\kappa}\mathcal E_{q,\rm cmp(\rho)}
\le\frac{(\beta+C_{\rm col})\lambda}{\kappa q_-}
 (1+2\log\rho)W. \tag{12}
\]

这是以已审强分支分离假设为前提的实际软分量价格，不是整个 R_strong 的价格。完整余项保留原测度乘 1−e_cmp,A/e；原 b_i、χ、时钟和 rank 均不变。式(12)不与同一分量的其他付款重复相加。本稿没有证明该余项占比小，也不提出未经证明的全标记能量预算。

## 6. 实际本机核验与状态

已实际运行 `/tmp/r407_geometry_check.py`（Python 标准库 Fraction），输出：

```
PASS stages: 192 108 48 total: 348
```

三阶段分别验证：192 个精确条件 Cauchy/方差下界；108 个带质量原子和等号的严格远区/闭窗分割；48 个完整匹配有限 incidence 场中的能量、反向式及可比正分量上界。第三阶段取全部非空来源子集为 receiver，选权令 Z(y)=1，从而全部能量用 Fraction 精确计算；窗常数使用该有限模型自身的精确容量。**这些是代数诊断，不是实际立方体 Lebesgue 场或原历史门样本；原生容量 (6) 由上述解析证明负责。**

本轮完成一般 ρ、全尺度、原子安全的反向证明与正分量付款。完整 marked 余项的联合几何预算未证。按父代理要求停止无标记能量方向，不开展更多链或后验门探索。
