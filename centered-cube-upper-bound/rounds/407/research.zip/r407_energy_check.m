function r407_energy_check
% Continuous piecewise-constant source; exact source partition at all cube faces.
% Receiver midpoint quadrature of a deterministic, single-radius selector.
rows=[]; maxbalance=0; maxneg=0;
for n=1:2
 if n==1, grids=[16 32 64 128 256]; else, grids=[6 10 14 20 28]; end
 for fixture=1:3
  if fixture==1
   boxes=[-ones(1,n),ones(1,n),1]; lam=.9;
  elseif fixture==2
   boxes=[-.9*ones(1,n),-.5*ones(1,n),3; .35*ones(1,n),.8*ones(1,n),2];lam=.7;
  else
   boxes=[-ones(1,n),ones(1,n),.2; -.2*ones(1,n),.2*ones(1,n),5];lam=.8;
  end
  W=sum(boxes(:,end).*prod(boxes(:,n+1:2*n)-boxes(:,1:n),2));
  for N=grids
   axis=-1.5+((1:N)-.5)*3/N; centers=gridpoints(repmat({axis},1,n));
   radii=[.5 .75 1]; q=zeros(size(centers,1),3);
   for k=1:3
    for j=1:size(boxes,1)
     ol=max(0,min(centers+radii(k)/2,boxes(j,n+1:2*n))-max(centers-radii(k)/2,boxes(j,1:n)));
     q(:,k)=q(:,k)+boxes(j,end)*prod(ol,2)/radii(k)^n;
    end
   end
   for mode=1:2
    good=q>=.75*lam & q<=lam;
    chosen=zeros(size(centers,1),1);
    if mode==1, order=3:-1:1;else,order=1:3;end
    for k=order, chosen(good(:,k))=k;end
    keep=chosen>0; x=centers(keep,:);idx=chosen(keep);R=radii(idx)';
    if isempty(R),continue;end
    if size(R,1)==1,R=R';end
    qa=q(sub2ind(size(q),find(keep),idx)); m=qa.*R.^n;dw=(3/N)^n;
    breaks=cell(1,n);srcaxes=cell(1,n);lens=cell(1,n);
    for d=1:n
     breaks{d}=unique([boxes(:,d);boxes(:,n+d);x(:,d)-R/2;x(:,d)+R/2]);
     srcaxes{d}=(breaks{d}(1:end-1)+breaks{d}(2:end))/2;
     lens{d}=diff(breaks{d});
    end
    ys=gridpoints(srcaxes);vl=gridpoints(lens);vol=prod(vl,2);f=zeros(size(ys,1),1);
    for j=1:size(boxes,1)
     f=f+boxes(j,end)*all(ys>boxes(j,1:n)&ys<boxes(j,n+1:2*n),2);
    end
    fw=f.*vol; use=fw>0;ys=ys(use,:);fw=fw(use);
    C=true(size(ys,1),size(x,1));
    for d=1:n,C=C & abs(ys(:,d)-x(:,d)')<R'/2;end
    C=double(C);mass=C'*fw;
    balance=max(abs(mass-m)./max(m,1e-30));maxbalance=max(maxbalance,balance);assert(balance<1e-10);
    mu=dw./m;J=C*mu;sel=J>0;C=C(sel,:);fw=fw(sel);J=J(sel);
    % M_Aw = E_piA sqrt(p_y(w)); p_y receiver quadrature law.
    A=(C'*(C.*(fw./sqrt(J))))./m;
    A=A.*sqrt(mu)'; capture=sum(A.^2,2);
    X=sum(qa)*dw;energy=2*sum(qa.*(1-capture))*dw;
    maxneg=max(maxneg,max(capture-1));assert(min(capture)>-1e-10&&max(capture)<1+1e-10);
    assert(abs(sum(fw.*J)-numel(m)*dw)<1e-9);
    rows(end+1,:)=[n fixture N mode numel(m) W X energy energy/W energy/(sqrt(n)*W) balance]; %#ok<AGROW>
   end
  end
 end
end
fprintf('n fixture grid mode receivers W X E E/W E/(sqrt(n)W) balance\n');
fprintf('%d %d %d %d %d %.12g %.12g %.12g %.12g %.12g %.3g\n',rows');
fprintf('cases=%d max_capture_balance=%.17g max_capture_excess=%.17g max_E_over_rootW=%.17g\n',size(rows,1),maxbalance,maxneg,max(rows(:,10)));
fprintf('Exact source partition; receiver midpoint quadrature not interval-certified. n=1,2 only; no dimension exponent inferred.\n');
end
function a=gridpoints(v)
g=cell(size(v));[g{:}]=ndgrid(v{:});a=zeros(numel(g{1}),numel(v));for k=1:numel(v),a(:,k)=g{k}(:);end
end
