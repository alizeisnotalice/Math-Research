# R407：原标记来源刷新、质量势与未付终端

2026-10-19。结论：本轮没有证明原远域的一般根阶预算。以下核准了可付的新来源比例门以及它所强迫的实际中心分布分离，但把该分离接入原联合流后，现有总能量仍为 X_q 级。质量下降与来源刷新尚不能共同结算成 W 级终端。这是本轮的失败判据，不将下面的能量恒等式算成新的总付款。

## 1. 冻结合同与确切对象

沿用 R406 的同一 f、实际中心 du、m_A=f(Q_A)=q_AR_A^n、μ=dA/m_A、σ=q_AdA、π_A=f c_A/m_A，q_-≤q_A≤λ，a≤R_A≤b≤2a。所有原 Γ_0 的物理时钟平均、J/H、质量亏损、空间/历史标记和阶段 Γ_i=1_{A_i²}Γ_0 保留。其逐旧来源外出容量为 β，入列容量为 C_col；S=β+C_col。T_A 为闭质量CDF，Z_A 为严格 m_w<m_A/K 的秩，K=e^(√n)，h=(1+√n)/(ε_0q_-)，ε_0≤1/2。

本文从 R406 的线性旧源门
\[
T_v(y)>4h+\kappa J(y),\qquad J(y)=Z_{\rm tot}(y)=\int c_w(y)\mu(dw),\quad0<\kappa<1
\tag{1}
\]
出发。取得(1)的原价格是 8C_col λhW+2C_col(λ/q_-)κX_q；若使用该选择，应替换 R406 的平方根阈值版本，不能两份都收。以下 R 表示 R404 两端远域在(1)上的正限制。

原新来源 z 的标记为 b_i(z)，Σ_i b_i(z)≤1。外端父为 A=u，还保留 z∉Q_v、Z_u(z)>Lh；小端父为 A=v，保留 T_v(z)>Lh。两端均有共同捕获软因子 (1−C_A(y,z)/h)_+ 与完整双范数远域。新增 w 只是占用见证，不继承原 u、v 的资格。

## 2. 新来源比例门：实际费用与局限

对外端删除 Z_u(z)≤4h+κJ(z)，对小端删除 T_v(z)≤4h+κJ(z)，按两端原正积分分别分拆。原闭窗容量给 T_A−Z_A≤ε_0h；闭CDF子水平质量≤阈值，故全部阶段一次累计得到
\[
R\le R_{\rm both}+P_\kappa,
\qquad
P_\kappa\le\lambda h[\beta(4+\varepsilon_0)+4C_{\rm col}]W
+S\lambda\kappa|E|
\le\lambda h[\beta(4+\varepsilon_0)+4C_{\rm col}]W
+S(\lambda/q_-)\kappa X_q. \tag{2}
\]
证明中先用每个新 z 上 Σ_i b_i(z)≤1 与 Γ_i≤Γ_0，再用原逐来源外/入容量，最后用 R406 的源依赖闭CDF阈值；没有按阶段收费。原新来源高秩门还在，删除支只支付其交集。式(2)属于允许的来源比例门工具，不是本轮预定的一般目标。

该门的实质是：R_both 中同一父 A 的两个实际源都满足
\[
Z_A(y)>\kappa J(y)+(4-\varepsilon_0)h,
\qquad Z_A(z)>\kappa J(z)+(4-\varepsilon_0)h,
\qquad C_A(y,z)<h. \tag{3}
\]
外端旧源还可保更强的4h；统一使用(3)。原 R398 的固定 Lh 门也不删除。

## 3. 实际捕获分布的分离及完整能量

在 J(y)>0 上定义中心概率及其平方根特征
\[
p_y(dw)=c_w(y)\mu(dw)/J(y),\qquad
 e_y(w)=c_w(y)/\sqrt{J(y)}\in L^2(\mu),\quad\|e_y\|=1.
\]
由实际捕获指标，无须来源独立或密度上界。仅在父 A 的严格远质量前缀上积分即得
\[
\begin{split}
\|e_y-e_z\|^2
&\ge Z_A(y)/J(y)+Z_A(z)/J(z)-2C_A(y,z)/\sqrt{J(y)J(z)}\\
&\ge2\kappa+h\left[(4-\varepsilon_0)(J(y)^{-1}+J(z)^{-1})
 -2/\sqrt{J(y)J(z)}\right]\ge2\kappa .
\end{split} \tag{4}
\]
最后只用平方非负。令 Θ 为 R_both 的完整原标记联合测度（包括 i,y,u,v,z、端点类型以及原时钟标签），则
\[
2\kappa R_{\rm both}\le\mathcal E_\Theta:=\int\|e_y-e_z\|^2\,d\Theta. \tag{5}
\]
此处不能删去 Θ 的原权之后，仍声称保有它的全部资格。

用于比较的精确 Bayes 耦合为
\[
\nu(dy,dA)=f(y)c_A(y)dy\,dA/m_A.
\]
其接收边缘为 dA，来源边缘为 f(y)J(y)dy；两个条件law正是 π_A 和 p_y。故来源刷新核
\[
P(y,dz)=\int p_y(dA)\pi_A(dz)
\]
关于 fJdy 可逆，而不是关于 fdy 可逆。其总来源质量为 ∫fJ=|E|。

设 \bar e_A=∫π_A(dy)e_y，则全部共享来源能量严格为
\[
\mathcal E_0=\int dA\,\pi_A(dy)\pi_A(dz)\|e_y-e_z\|^2
=2|E|-2\int\|\bar e_A\|^2dA. \tag{6}
\]
加 q_A 后，同样
\[
\mathcal E_q=2X_q-2\int\|\bar e_A\|^2\sigma(dA). \tag{7}
\]
这里加权耦合为 ν_q(dy,dA)=q_Aν(dy,dA)，接收边缘为 σ，来源边缘为 f(y)D(y)dy，D(y)=∫q_Ac_A(y)μ(dA)，总量 X_q。接收条件仍为 π_A；来源条件必须改为 p_y^q(dA)=q_Ac_A(y)μ(dA)/D(y)，于是 P_q(y,dz)=∫p_y^q(dA)π_A(dz) 才关于 fDdy 可逆。原 P=∫p_yπ_A 仍仅关于 fJdy 可逆，未声称它关于 fDdy 可逆。式(7)的特征 e_y 仍是原 p_y 的平方根，未随加权改变。Tonelli 保证公式；J=0 或 D=0 的条件law可任意置零，这部分在相应耦合下零测。

累计时先在共同的 (y,u,v,z) 空间使用
\[
\sum_i1_{A_i}(u)1_{A_i}(v)b_i(z)\le1.
\]
能量 ||e_y−e_z||² 非负，且不依赖阶段 i 或端点类型。对外端，先合并这份阶段权并丢掉其他≤1标记，再积分 v，严格得到
\[
\mathcal E_{\Theta,\rm ext}\le\int\Gamma_0(dy,du,dv)\pi_u(dz)\|e_y-e_z\|^2
\le\beta\int\sigma(du)\pi_u(dy)\pi_u(dz)\|e_y-e_z\|^2=\beta\mathcal E_q.
\]
对小端同样先合并阶段权，再积分 u，得
\[
\mathcal E_{\Theta,\rm small}\le\int\Gamma_0(dy,du,dv)\pi_v(dz)\|e_y-e_z\|^2
\le C_{\rm col}\mathcal E_q.
\]
两式用的是同一个完整 E_q；只在最后正上界中遗失原资格。没有对每个阶段分别使用容量后求和。于是
\[
\mathcal E_\Theta\le S\mathcal E_q\le2SX_q. \tag{8}
\]
它仅给 R_both≤SX_q/κ，不能吸收。原 BH 的负平方没有在(6)或(7)再次扣款；这些是新的比较量的精确展开，不是已获额外信用。

## 4. 质量势为什么尚不能支付这份能量

取 ℓ(A)=log[m_A/(q_-a^n)]，则 0≤ℓ≤M_n:=log(λ/q_-)+n log(b/a)。把 Θ 投影到实际 u→v，记其两个端点边缘为 O、I。严格质量下降给
\[
\sqrt n\,R_{\rm both}\le\int[\ell(u)-\ell(v)]d\Theta
=\int\ell(A)[dO(A)-dI(A)]. \tag{9}
\]
这是原一次流的真实有向漂移；R_both>0 时首个不等式严格，零流量时两侧为0。只有 O(E)=I(E)；不能推出两个测度局部相等。有限链长至多 O(M_n/√n) 不能支付右侧的注入与终端质量。

更具体地，尝试来源势 V(y)=∫p_y(dA)ℓ(A)，有0≤V≤M_n。将 Θ 写成原标签基底 dΛ(l)π_{A(l)}(dz)t_l(z)，其中 l 保留 i,y,u,v、端点类型和原时钟，t_l 为全部新来源正标记，a_l=π_A t_l。确切换源漂移是
\[
\int[V(y)-V(z)]d\Theta
=\int d\Lambda(l)\left\{a_l[V(y)-\pi_A V]
-\operatorname{Cov}_{\pi_A}(t_l,V)\right\}. \tag{10}
\]
其中 t_l 包含 b_i、远域、共同捕获、原新秩与新增比例门。协方差没有已证符号。即使替成无标记 Bayes 刷新而使其消失，来源边缘仍是 fJ（或 q 加权的 fD），不是 f；同时刷新后的接收者不自动满足质量下降、原时钟或原核心资格。若再次强制这些门，退出原允许集合的终端项必须独立支付。

所以本候选的具体缺口是：需要对原 Θ 建立有符号的(9)–(10)联合控制，连同退出费用，达到 δX_q+C√n polylog(n)W。现有匹配、容量与(3)只证明了分离(4)和 X_q 级(8)，没有给出这种终端界。既不能从 ∫fJ=|E| 改成 W，也不能把协方差或退出项当零。本轮停止于这个明确障碍，不继续包装链长或一般熵递减作付款。

## 5. 完整条件性桥、入口与核验

合并线性旧来源门的一次费用、(2)与(5)–(8)，得到本稿可直接审查的条件性桥：r=λ/q_- 时，
\[
\boxed{R404\le r\kappa(\beta+3C_{\rm col})X_q
+\lambda h[(4+\varepsilon_0)\beta+12C_{\rm col}]W
+\frac{S}{2\kappa}\mathcal E_q.} \tag{11}
\]
这是真实原 marked flow 的上界；E_q 未付。它替代 R406 的平方根旧阈值方案，而非叠加其 D_η。原入口中 R404 的系数为64Λ，故本次替换精确贡献
\[
64\Lambda r\kappa(\beta+3C_{\rm col})X_q
+64\Lambda\lambda h[(4+\varepsilon_0)\beta+12C_{\rm col}]W
+\frac{32\Lambda S}{\kappa}\mathcal E_q. \tag{12}
\]
其余 R404 母账的 χ_n、Δ404、P_L、E387、S390、H与全部外部费用各保留一次。未改变原 L，亦不扣重复的旧近域或共同捕获价格。

若另外证明所有原场都满足 E_q≤C_*s log^A(n+2)W，那么给定本槽吸收目标δ>0，取
\[
\kappa=\min\{1/2,\delta/[r(\beta+3C_{\rm col})]\}
\]
即可由(11)得到 δX_q 加显示的根阶多对数 W 价格；原入口吸收贡献为64Λδ。这个几何能量假设尚未证明，不能把(11)称为一般结论。若只保现有 E_q≤2X_q，最后项不可吸收。本轮独立辅助止于(11)及其精确来源，不同时研究能量几何。

本机标准库 Fraction 脚本 `/tmp/r407_aux_check.py` 实际输出：

```
PASS {'inclusive_ratio_cut': 36, 'normalized_separation': 144, 'shared_source_balance': 2} total 182
```

36项核闭CDF比例阈值及原子；144项核平方秩的归一分离代数；2个有限共享来源 incidence 模型核实际质量归一的可逆边缘。最后两例不代表原单值半径场、octave或完整原历史实现。检查仅辅助以上严格证明，未认证未付联合势或一般渐近界。
