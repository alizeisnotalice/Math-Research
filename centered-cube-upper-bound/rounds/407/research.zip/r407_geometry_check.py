from fractions import Fraction as F
from itertools import combinations, product
from math import comb

counts = [0, 0, 0]
# Stage 1: the exact conditional Cauchy step, including zero capture.
for p in [F(0), F(1,5), F(1,2), F(1)]:
    for r1, r2 in product([F(0), F(1,3), F(1), F(3)], repeat=2):
        for t in [F(0), F(1,4), F(1)]:
            a = p*(t*r1*r1+(1-t)*r2*r2)
            b = p*(t*r1+(1-t)*r2)
            assert b*b <= p*a
            assert a-b*b >= (1-p)*a
            counts[0] += 1
# Stage 2: closed near window versus strict far, with mass atoms/equalities.
for weights in product([F(1,3), F(1), F(2)], repeat=3):
    masses = [F(1), F(2), F(4)]
    Z = sum(weights)
    for rho in [F(5,4), F(3,2), F(2), F(4)]:
        far = sum(weights[i]*weights[j] for i in range(3) for j in range(3)
                  if masses[i] > rho*masses[j])
        near = sum(weights[i]*weights[j] for i in range(3) for j in range(3)
                   if masses[j]/rho <= masses[i] <= rho*masses[j])
        C = max(sum(weights[i] for i in range(3)
                    if masses[j]/rho <= masses[i] <= rho*masses[j]) for j in range(3))
        assert 2*far + near == Z*Z
        assert near <= C*Z
        counts[1] += 1
# Stage 3: full-mass matching finite incidence models, Z(y)=1.
# These are algebra diagnostics, NOT native cube/Lebesgue or history fixtures.
for N in range(1,7):
    Q = [frozenset(c) for k in range(1,N+1) for c in combinations(range(N),k)]
    m = [F(len(a)) for a in Q]
    du = [m[i]/(N*comb(N-1,len(a)-1)) for i,a in enumerate(Q)]
    Z = [sum(du[i]/m[i] for i,a in enumerate(Q) if y in a) for y in range(N)]
    assert all(z == 1 for z in Z)
    Emeasure, W = sum(du), F(N)
    for pattern in range(2):
        q = [F(1) if (i+pattern)%2 else F(3,4) for i in range(len(Q))]
        qmin, lam = F(3,4), F(1)
        X = sum(q[i]*du[i] for i in range(len(Q)))
        energy = sum(2*q[i]*du[i]*du[j]/m[j]*
                     (F(len(a&b),len(a))-F(len(a&b),len(a))**2)
                     for i,a in enumerate(Q) for j,b in enumerate(Q))
        assert 0 <= energy <= 2*X
        for rho in [F(5,4), F(3,2), F(2), F(4)]:
            C = max(sum(du[i]/m[i] for i,a in enumerate(Q)
                        if y in a and m[j]/rho <= m[i] <= rho*m[j])
                    for y in range(N) for j in range(len(Q)))
            far_by_y = [sum(du[i]/m[i]*du[j]/m[j]
                            for i,a in enumerate(Q) for j,b in enumerate(Q)
                            if y in a and y in b and m[i] > rho*m[j])
                        for y in range(N)]
            cmpenergy = sum(2*q[i]*du[i]*du[j]/m[j]*
                            (F(len(a&b),len(a))-F(len(a&b),len(a))**2)
                            for i,a in enumerate(Q) for j,b in enumerate(Q)
                            if m[i]/rho <= m[j] <= rho*m[i])
            assert energy >= 2*qmin*(1-1/rho)*sum(far_by_y)
            assert energy >= qmin*(1-1/rho)*(Emeasure-C*W)
            assert energy >= qmin/lam*(1-1/rho)*X-qmin*(1-1/rho)*C*W
            assert 0 <= cmpenergy <= 2*lam*C*W
            counts[2] += 1
print('PASS stages:', *counts, 'total:', sum(counts))
