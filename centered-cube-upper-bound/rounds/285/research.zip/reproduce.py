from pathlib import Path
import argparse,hashlib,json,subprocess,sys,tempfile
p=Path(__file__).resolve().parent
arg=argparse.ArgumentParser();arg.add_argument('--check-only',action='store_true');a=arg.parse_args()
manifest=json.loads((p/'manifest.json').read_text())
for name,expected in manifest.items():assert hashlib.sha256((p/name).read_bytes()).hexdigest()==expected,name
print('PASS manifest',len(manifest),'files',flush=True)
if not a.check_only:
 for script in ['r285_soft_checks.py','r285_joint_checks.py','r285_symmetric_checks.py']:
  subprocess.run([sys.executable,str(p/script)],check=True)
 with tempfile.TemporaryDirectory() as t:
  dest=Path(t)/'r285_numeric.json'
  subprocess.run([sys.executable,str(p/'r285_numeric.py'),'--output',str(dest)],check=True)
  assert dest.read_bytes()==(p/'r285_numeric.json').read_bytes()
  print('PASS byte-identical r285_numeric.json',flush=True)
  out=Path(t)/'r285_allocation.json'
  subprocess.run([sys.executable,str(p/'r285_allocation_checks.py'),'--input',str(dest),'--output',str(out)],check=True)
  assert out.read_bytes()==(p/'r285_allocation.json').read_bytes()
  print('PASS byte-identical r285_allocation.json',flush=True)
 print('ALL PASS; the both-high original remainder is not certified',flush=True)
