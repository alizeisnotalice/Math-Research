# R285 final audit: reciprocal-neighborhood allocations

**PASS for the two stated paid branches, under the stated original score/clock qualifications and the separately audited packet theorem. No correction to either author file is requested. This is not a payment of the both-high remainder.**

Only this audit file is owned/written. No repository, Git, PDF, or author file was changed. The independent analytic checks below distinguish the new allocation argument from its previously audited soft-packet input; the soft-packet proof was not re-run as a new audit.

## 1. Frozen inputs and quantifiers

The following files were read, and their SHA256 values were actually checked:

- `/tmp/r285_joint.md`: `4f7a145fc3741e20cfaefa448d1c3cec2338e8b65206f39394eba3cecf613049`.
- `/tmp/r285_symmetric.md`: `a632df6cfd3ca30c8e89fc27032835be998a56baee7909973310df1671746811`.
- `/tmp/r285_soft_audit.md`: `fc6597d764eabfebd4602c20617f8a5311cb6dc6d31b0d9c7f35b2fc46f0a1a1`.
- `/tmp/r285_soft_packet.md`: `74332cdc1e1b11ff6f66437e10b0ab9ae661ad9b534254a4f2f18d455953d24c`.

The preauthor `/tmp/r285_allocation_screen.md` was also read as supporting history. This receipt's verdict follows the checks recorded here; it does not assert a new preauthor chronology.

The accepted statement uses integer n>=1, D>=0, lambda>0, a>0, and arbitrary finite nonnegative L1 source densities rho,nu. No comparison between the sources is required. Receiver selectors and q are measurable and keep their ORIGINAL qualifications: q in [3lambda/4,lambda], actual full-soft response of rho at most q, actual hard maximal response of nu over [a,b] at most 4lambda, a<=L,R<=b<=2a, and actual clock qualification L,R>=a_xi=max(a,b xi/gamma). The original near radius is r=a/(16sqrt(n)); neither source packet changes that original near condition.

Write kappa_xi=6+4sqrt(2nr/a_xi). The accepted packet input is the uniform all-L>=a_xi, all-common-soft ns<=D weak bound kappa_xi B times packet mass, with B exactly as in the frozen soft-packet file. B>=1 is uniform in the anchor and physical clock. That input was independently audited in the frozen soft audit. All source sums below are against the original sources, and any outer-data-dependent D, B_D and B remain inside the original weighted source sum until an actual common bound is available.

## 2. Source identities, finiteness, and zero fibers

For N(y)=nu(B_1(y,r)), define sigma_z(dy)=1_near 1_{N(y)>0}rho(dy)/N(y). Nonnegative Tonelli gives exactly

    integral nu(dz)sigma_z(dy)=1_{N(y)>0}rho(dy),
    integral ||sigma_z||nu(dz)<=W_rho.

Thus sigma_z is finite for nu-almost every z, remains L1 because rho is L1, and is supported in B_1(z,r). The exceptional anchor set is fixed before the clock and has zero original nu measure, so it can be removed simultaneously for every clock. The near product measure on N=0 is zero, since its total equals integral 1_{N=0}N(y)rho(dy)=0. This deals with zero sources and zero packets as well as strictly positive masses.

For M(z)=rho(B_1(z,r)), the reverse definition tau_y(dz)=1_near 1_{M(z)>0}nu(dz)/M(z) gives, by the same direct Tonelli calculation,

    integral rho(dy)tau_y(dz)=1_{M(z)>0}nu(dz),
    integral ||tau_y||rho(dy)<=W_nu.

These tau packets are finite L1 and supported in B_1(y,r) for rho-almost every y, with a clock-independent exceptional null set. The original near product on M=0 is zero. Both constructions are measurable kernels of measures. They are auxiliary analysis disintegrations, not replacements of the original source or posterior.

## 3. Low-N receiver price

At fixed xi use N0=(3lambda/4)a_xi^n/kappa_xi. The ACTUAL restricted response F_z^low satisfies F_z^low/q<=1 by original full-soft FIRST, while positive reconstruction gives F_z^low<=N0 P_actual*sigma_z. On the actual receiver set E_xi its quotient therefore has weak constant at most B a_xi^n||sigma_z||. The maximal packet envelope gets only that weak estimate; no FIRST cap is granted to it or to sigma_z.

The actual hard point column has height at most a_xi^-n and weak constant at most one, directly from the centered-cube envelope over R>=a_xi. Normalize it by a_xi^n. For two functions of height at most one with weak constants A,C, the rearrangement/layer-cake bound is

    integral fg<=I(A,C),
    I(A,C)=min(A,C)[2+log(max(A,C)/min(A,C))],

with I=0 if either argument is zero. The powers of a_xi cancel, giving the original receiver integral at each anchor at most I(B||sigma_z||,1). The elementary amplification inequality

    I(Bu,v)<=u+(1+log B)v,  B>=1,

is valid for every u,v>=0. It follows from I(u,v)<=u+v and differentiating in log B (the derivative is at most v). Integrating the exact sigma marginal yields

    T_lowN(xi)<=W_rho+(1+log B)W_nu.

No hard-source cap or source comparison was needed for this direction; no factor from a same-cell grid is present.

## 4. Low-M receiver price and direct soft point bound

For a fixed normalized positive rectangle shape R, the point envelope sup_{L>=a_xi}H_{R,L}(x-y) has weak constant at most one. Indeed its contributing rectangles are nested as L increases, and at level t their limiting volume is at most 1/t. This is a direct geometric point-kernel statement and does not invoke a Dirac input in an L1 theorem.

The same fixed common-soft menu and upward shape-rounding law from the frozen soft packet file applies pointwise, with total domination e^2. Its labelled shape entropy is at most H_*. Applying the proved countable positive weak-sum lemma, without inverse-side marks, gives

    B_point=e^2 M_nodes[3+2log2+2log M_nodes+2H_*]<=B.

The inequality to B follows directly from its additional factor D+3>=3 and E_*>H_*. All shape tails remain present. The ACTUAL point soft kernel also has height at most a_xi^-n because h, phi, and their convex mixture are bounded by one. Height and weak-envelope statements remain distinct.

Use M0=4lambda a_xi^n/kappa_xi. The actual low-M hard response H_y^low<=4lambda follows from the original hard maximal cap at the ACTUAL R in [a,b]. Positive reconstruction gives H_y^low<=M0 h_actual*tau_y. The R284 all-scales hard packet bound consequently gives weak constant a_xi^n||tau_y|| for H_y^low/(4lambda), and this actual quotient has height at most one. No hard cap is assigned to tau_y.

Pairing with the normalized actual soft point column gives I(B_point,||tau_y||)<=1+(1+log B)||tau_y||. The variable q is handled by its original lower bound only: 4lambda/q<=16/3. Integration in original rho therefore gives exactly

    T_lowM(xi)<=(16/3)[W_rho+(1+log B)W_nu].

## 5. Original score, clock, disjointness, and constants

The two paid branches are the exact sequential partition L_N and (1-L_N)L_M, where L_N=1_{N<=N0} and L_M=1_{M<=M0}. Their sum and the remainder (1-L_N)(1-L_M) equal one pointwise. Both new gates depend on original sources, near points, and physical clock but not auxiliary slots u,v. Any prior positive current masks, including an R284 heavy allocation, stay on the left; dropping them only in the positive majorant is valid.

The original full-posterior score bound retains the explicit mask 1_{R2(y,v)<=D} and its ns<=D qualification. It is used pointwise BEFORE source integration and BEFORE xi=c_jt/b substitution. The unique actual j(x) restriction is retained until its sum is at most one. The actual receiver set E_xi is retained until it supplies both lower-scale bounds. Thus there is no posterior-independence assumption after clock substitution, no new scale menu, and no copying the same source price per j or per physical clock.

With the already stated score integral B_D<=min(nlog2,4sqrt(nD)), the one outside coefficient 2Lambda yields

    P_first<=2Lambda B_D C,
    P_second<=(32Lambda/3)B_D C,
    P_first+P_second<=(38Lambda/3)B_D C
                       <=(152Lambda/3)sqrt(nD) C,
    C=W_rho+(1+log B)W_nu.

The arithmetic is 2+32/3=38/3. There is no additional grid or Lambda factor. At D=0 the original masked score has zero price; any endpoint convention for its scalar majorant is understood via that zero-score statement. For D=O(log(n+2)), the frozen B is polynomial in log(n+2), so the stated root-polylog payment of these branches follows. No original signed negative credit is used.

## 6. Actually run bounded diagnostic and its limit

`python3 /tmp/r285_joint_checks.py` was actually run once during this final audit, with output:

    PASS exact_marginal_checks= 5 exact_low_gate_checks= 60 floating_I_amplification_checks= 125
    neighbor_masses= ['1/5', '1/5', '7/15', '14/15', '0'] allocated_rho_mass= 17/28 original_rho_mass= 1
    Finite algebra diagnostics only; not an original L1-history model or interval certificate.

The 5 and 60 tests are exact Fraction incidence/threshold checks, while the 125 scalar I tests are ordinary floating-point diagnostics. They are not a universal proof, a directed interval certificate, or a continuous original-history example. The universal allocation conclusions above follow analytically from Tonelli, the packet and point weak bounds, the capped product estimate, and the stated original score/clock qualifications.

## 7. Exact remaining gap

The unpaid remainder is precisely the SAME current original positive near integrand multiplied by BOTH

    1{nu(B_1(y,r))>(3lambda/4)a_xi^n/kappa_xi}
    1{rho(B_1(z,r))>4lambda a_xi^n/kappa_xi}.

It retains every original source, actual selector, source cut, near mask, current positive mask, full posterior, physical clock, explicit upper-slot qualification, and unique j restriction. These are source-mass lower bounds only. They do not imply a lower bound for captured response at the receiver. The jointly dense branch may carry all remaining traffic; no positive coverage fraction or price for it has been proved. A further joint source-capacity/geometric argument is still required to close the general root-polylog goal.

**Final receipt: PASS for the two allocations at the four frozen hashes above; the both-high branch remains exactly unpaid.**
