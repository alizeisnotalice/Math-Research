# R285 finite geometric near coupling and actual hard responses

Completed6 exact Fraction models in three stages (two each),85 near edges,54 marginal inequalities,225 same-receiver L/R rows, and25 all-continuous-R hardcap certificates. There are66 jointly qualified rows and every model has positive qualified traffic. No floating arithmetic or numerical quadrature is used. This is a finite atomic/receiver-grid diagnostic, not positive-volume L1/FULL, posterior or historical traffic certification.

## Coupling and exact recovery

For a fixed actual l1 near graph, m_z=sum_near rho_y,n_y=sum_near nu_z and

pi_yz=1_near rho_y nu_z/max(m_z,n_y).

No edge divides by zero because its two positive endpoint masses force both near sums positive; isolated vertices have zero coupling. Exact assertions verify sum_z pi_yz<=rho_y and sum_y pi_yz<=nu_z. Analytically the first follows from max>=n_y and the second from max>=m_z. For every edge,

pi_yz max(m_z,n_y)=rho_y nu_z.

Consequently both the total weighted coupling cost and all225 receiver-scale responses recover the original edge products exactly. The recovered weight is not silently dropped.

The two measures have distinct, nonuniform weights: rho_i proportional to2^i, total1; nu_j proportional to((7j+3)mod13)+1,total3/2. They need not be source-independent laws. Coordinates and full exact masses are saved. The near graph is geometric, not an arbitrary adjacency matrix.

## Physical point geometry and fixed qualification

All receivers are actual rational grid points, and h_L(x-y)=L^(-n)1_{all coordinates |x_i-y_i|<=L/2}. a1,b2; L,R menus1,3/2,2. Source sets are finite positive atomic laws. Every response uses the same x,L,R for all sources; no per-edge or per-source scale maximization is performed.

Each model first fixes lambda=max_{declared x,L} sum_y rho_y h_L(x-y). It is not changed at each receiver. At every receiver/scale pair the actual q=sum rho h_L must satisfy3lambda/4<=q<=lambda. Independently, the nu hardcap is checked for all continuous R in[1,2] at that receiver, not merely the selected grid. All thresholds R=2||x-z||infinity lying in[1,2], plus both endpoints, are enumerated. Between them the response is a fixed nonnegative mass times R^(-n), hence decreasing; its supremum is attained among these exact knots with the declared closed-cube convention. This is a certificate for each finite receiver, not an all-Lebesgue-receiver cap.

Only rows meeting both qualifications are eligible for the T/q maximum, where T=sum_near rho_y nu_z h_L(x-y)h_R(x-z). Qualification flags are saved for every row, including failures and equality cases; the cap is not imposed by wishful selection. The near anchor response sum_z nu_z h_R(x-z)m_z is also retained separately.

|stage/model|n|fixed lambda|qualified rows|best T/q|
|---|---:|---:|---:|---:|
|initial oneD cluster|1|1|9|3/2|
|initial twoD cluster|2|1|9|3/2|
|stress unequal disconnected|1|16/31|9|33/40|
|stress twoD disconnected|2|4/5|3|33/40|
|expanded twoD lattice|2|1|27|684/511|
|expanded threeD cube|3|1|9|3681/5015|

The unequal disconnected best q is12/31=3lambda/4, explicitly an equality boundary, not a strict original qualification. The source/receiver locations, graph edges and best actual L/R are fully recorded. The denser twoD case uses nine rho sources and four nu sources; the threeD case uses eight of each. Near radii are1/2 except the threeD cube, which uses3/4. Disconnected/isolated sources remain in the original masses and response cap; they are not removed to improve normalization.

## What the finite decision does and does not show

In the first two clustered models, pi has total mass1, but the original near product mass is3/2. All recovery weights are3/2; at the best receiver the unweighted coupling response is1 while the original and weighted recovered responses are3/2. A marginal-normalized subcoupling therefore exists, but it does not remove the recovery weight or pay the original cost automatically.

In other models some recovery weights can be below1, so unweighted and weighted costs need not have a universal direction. For example the unequal disconnected best unweighted response is12/31 while the original is99/310; the code retains both. The correct conclusion is exact weighted recovery, not a claim that normalization is always beneficial or always a loss. No general order is inferred from low dimensions or six families. There is no original Pi, history, FIRST/high gate, positive-volume receiver measure, dense-complement payment or FULL claim.

## Reproduction

Self-contained Python3.12.14, standard library only (Fraction is the local mathematical tool):

```sh
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 \
r285_numeric.py --output r285_numeric.json
```

The JSON is deterministic, binds the source SHA256 and contains no runtime/time/output path. The complete final run actually completed successfully. No old numerical suite, repository file, Git or PDF was touched. Exactness refers to the declared finite point law and exact cube tests only, not a continuous/general theorem certificate.
