# Verification ledger

Final author hashes: r285_joint.md 4f7a145fc3741e20cfaefa448d1c3cec2338e8b65206f39394eba3cecf613049; r285_symmetric.md a632df6cfd3ca30c8e89fc27032835be998a56baee7909973310df1671746811; r285_soft_packet.md 74332cdc1e1b11ff6f66437e10b0ab9ae661ad9b534254a4f2f18d455953d24c.

Independent receipts: soft fc6597d764eabfebd4602c20617f8a5311cb6dc6d31b0d9c7f35b2fc46f0a1a1; joint efa3cd57205b344fbb6760c08d9b82c735a8a9a7755c7e40037be7660a0d5612. Parent read all authors and both final receipts; parent ran all packaged scripts. Main finite-geometry JSON was independently recomputed byte-identically before packaging.

Local runtime: /Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3. PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor supplies mpmath1.3.0. Standard-library Fraction is used for exact finite data. Ordinary 40/60 digit calculations are not directed interval certificates. The finite receiver grids are not original FULL/L1 histories. The high-high original traffic remains unpriced.

Default full reproduction actually completed with exit 0: ALL PASS; both numerical JSON files recomputed byte-identically.
