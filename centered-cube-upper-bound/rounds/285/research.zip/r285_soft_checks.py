import sys,math
sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
import mpmath as mp
answers=[];checks=0
for prec in (40,60):
    mp.mp.dps=prec
    def w(x):
        x=abs(x)
        return mp.mpf(1) if x==0 else mp.exp(-x)-x*mp.e1(x)
    def dens(r):
        return r/2*(w(abs(r/2-mp.mpf('.5')))-w(r/2+mp.mpf('.5')))
    intervals=[0,1,2,4,8,16,mp.inf]
    half=mp.quad(lambda r:dens(r)/mp.sqrt(r) if r else mp.mpf(0),intervals)
    loghalf=mp.quad(lambda r:dens(r)*abs(mp.log(r))/mp.sqrt(r) if r else mp.mpf(0),intervals)
    assert mp.mpf(13)**(-mp.mpf(1)/4)<=half<=1;checks+=1
    assert 0<=loghalf<14;checks+=1
    answers.append((half,loghalf))
assert max(abs(answers[0][j]-answers[1][j]) for j in (0,1))<mp.mpf('1e-30');checks+=1
for n in (1,2,8,64,512):
    for D in (0.,.5,2.,math.log(n+2),float(n)):
        M=min(n,math.floor(D)+1);zeta=1+1/(D+1);gamma=1+1/n
        for frac in (0.,.25,.5,.75,1.):
            s=frac*min(1.,D/n);k=min(n,math.floor(n*s)+1);sigma=k/(n+1)
            assert k<=M and s<=gamma*sigma+1e-14 and 1-s<=gamma*(1-sigma)+1e-14;checks+=1
            tilted=zeta*sigma/(1+(zeta-1)*sigma)
            assert n*math.log1p((zeta-1)*sigma)<=1+1e-13 and n*tilted<=D+2+1e-13;checks+=1
print('PASS',checks)
print('E[r^-1/2]=',mp.nstr(answers[1][0],25))
print('E[r^-1/2 |log r|]=',mp.nstr(answers[1][1],25))
