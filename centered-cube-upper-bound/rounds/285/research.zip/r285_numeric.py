#!/usr/bin/env python3
"""R285 exact finite near-graph marginal coupling and actual hard responses."""
import argparse,hashlib,json,itertools
from pathlib import Path
from fractions import Fraction as F

def ss(x):return str(x)
def point(*xs):return tuple(F(x) for x in xs)
def cube(x,y,R):return all(abs(a-b)<=R/2 for a,b in zip(x,y))
def h(x,y,R):return F(int(cube(x,y,R)),1)/R**len(x)
def near(y,z,r):return sum(abs(a-b) for a,b in zip(y,z))<=r
def weights(N,style,total=F(1)):
 raw=[F(2**i) if style=='geometric' else F((7*i+3)%13+1) for i in range(N)]
 return [total*x/sum(raw) for x in raw]
def model_menu():
 return [
 ('initial','oneD_cluster',1,[point('-1/4'),point('0'),point('1/4')],[point('-1/8'),point('1/8')],[point('-1/4'),point('0'),point('1/4')],F(1,2)),
 ('initial','twoD_cluster',2,[point('0','0'),point('1/4','0'),point('0','1/4')],[point('1/8','1/8'),point('-1/8','0')],[point('0','0'),point('1/4','1/4'),point('-1/4','0')],F(1,2)),
 ('stress','unequal_disconnected',1,[point('-2'),point('-7/4'),point('0'),point('1/4'),point('3')],[point('-15/8'),point('1/8'),point('13/4')],[point('-2'),point('0'),point('1/4'),point('3')],F(1,2)),
 ('stress','twoD_disconnected',2,[point('-1','0'),point('-3/4','0'),point('1','0'),point('1','1/4')],[point('-7/8','0'),point('9/8','0'),point('3','3')],[point('-1','0'),point('1','0'),point('0','0')],F(1,2)),
 ('expanded','twoD_lattice',2,[tuple(F(x,4) for x in ij) for ij in itertools.product([-1,0,1],repeat=2)],[tuple(F(x,8) for x in ij) for ij in itertools.product([-1,1],repeat=2)],[tuple(F(x,4) for x in ij) for ij in itertools.product([-1,0,1],repeat=2)],F(1,2)),
 ('expanded','threeD_cube',3,[tuple(F(x,4) for x in ij) for ij in itertools.product([-1,1],repeat=3)],[tuple(F(x,8) for x in ij) for ij in itertools.product([-1,1],repeat=3)],[point('0','0','0'),point('1/4','0','0'),point('-1/4','1/4','0')],F(3,4))]
def run_model(stage,name,n,Y,Z,X,r):
 rho=weights(len(Y),'geometric');nu=weights(len(Z),'modular',F(3,2));Lmenu=[F(1),F(3,2),F(2)];Rmenu=Lmenu
 edges=[(i,j) for i,y in enumerate(Y) for j,z in enumerate(Z) if near(y,z,r)]
 mz=[sum((rho[i] for i,y in enumerate(Y) if (i,j) in edges),F(0)) for j in range(len(Z))]
 ny=[sum((nu[j] for j,z in enumerate(Z) if (i,j) in edges),F(0)) for i in range(len(Y))]
 pi={};edge_rows=[]
 for i,j in edges:
  factor=max(mz[j],ny[i]);assert factor>0;pi[i,j]=rho[i]*nu[j]/factor;assert pi[i,j]*factor==rho[i]*nu[j]
  edge_rows.append({'y':i,'z':j,'pi_exact':ss(pi[i,j]),'recovery_factor_max_mz_ny_exact':ss(factor),'original_edge_product_exact':ss(rho[i]*nu[j])})
 rowm=[sum((v for (ii,j),v in pi.items() if ii==i),F(0)) for i in range(len(Y))]
 colm=[sum((v for (i,jj),v in pi.items() if jj==j),F(0)) for j in range(len(Z))]
 assert all(v<=r for v,r in zip(rowm,rho)) and all(v<=r for v,r in zip(colm,nu))
 lam=max(sum((rho[i]*h(x,y,L) for i,y in enumerate(Y)),F(0)) for x in X for L in Lmenu);assert lam>0
 caprows=[];receivers=[];best=None
 for xi,x in enumerate(X):
  knots=sorted(set([F(1),F(2)]+[2*max(abs(a-b) for a,b in zip(x,z)) for z in Z if 1<=2*max(abs(a-b) for a,b in zip(x,z))<=2]))
  cap=max(sum((nu[j]*h(x,z,R) for j,z in enumerate(Z)),F(0)) for R in knots);hardok=cap<=4*lam
  caprows.append({'receiver':xi,'threshold_R_exact':[ss(t) for t in knots],'allR_hard_sup_exact':ss(cap),'hardcap_4lambda_exact':ss(4*lam),'qualified_hardcap':hardok})
  for L,R in itertools.product(Lmenu,Rmenu):
   q=sum((rho[i]*h(x,y,L) for i,y in enumerate(Y)),F(0));qok=F(3,4)*lam<=q<=lam
   orig=sum((rho[i]*nu[j]*h(x,Y[i],L)*h(x,Z[j],R) for i,j in edges),F(0))
   unweighted=sum((v*h(x,Y[i],L)*h(x,Z[j],R) for (i,j),v in pi.items()),F(0))
   restored=sum((v*max(mz[j],ny[i])*h(x,Y[i],L)*h(x,Z[j],R) for (i,j),v in pi.items()),F(0));assert restored==orig
   anchor=sum((nu[j]*h(x,z,R)*mz[j] for j,z in enumerate(Z)),F(0))
   qualified=hardok and qok
   row={'receiver':xi,'L_exact':ss(L),'R_exact':ss(R),'q_exact':ss(q),'q_lower_exact':ss(F(3,4)*lam),'qualified_q':qok,'qualified_hardcap':hardok,'qualified':qualified,'original_T_exact':ss(orig),'unweighted_coupling_response_exact':ss(unweighted),'weighted_recovered_T_exact':ss(restored),'near_anchor_mass_response_exact':ss(anchor),'T_over_q_exact':ss(orig/q) if q else None}
   receivers.append(row)
   if qualified and (best is None or orig/q>best[0]):best=(orig/q,row)
 totalnear=sum((rho[i]*nu[j] for i,j in edges),F(0));couplingmass=sum(pi.values(),F(0));recoverycost=sum((v*max(mz[j],ny[i]) for (i,j),v in pi.items()),F(0));assert recoverycost==totalnear
 return {'phase':stage,'name':name,'n':n,'near_l1_radius_exact':ss(r),'Y_exact':[[ss(x) for x in p] for p in Y],'Z_exact':[[ss(x) for x in p] for p in Z],'receiver_points_exact':[[ss(x) for x in p] for p in X],'rho_exact':list(map(ss,rho)),'nu_exact':list(map(ss,nu)),'rho_mass_exact':ss(sum(rho)),'nu_mass_exact':ss(sum(nu)),'lambda_exact':ss(lam),'m_z_exact':list(map(ss,mz)),'n_y_exact':list(map(ss,ny)),'coupling_row_marginals_exact':list(map(ss,rowm)),'coupling_column_marginals_exact':list(map(ss,colm)),'edges':edge_rows,'near_product_mass_exact':ss(totalnear),'coupling_mass_exact':ss(couplingmass),'weighted_recovery_cost_exact':ss(recoverycost),'allR_hardcap_certificates':caprows,'receiver_scale_rows':receivers,'qualified_rows':sum(row['qualified'] for row in receivers),'best_qualified':None if best is None else best[1]}
def main():
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));a=p.parse_args();models=[run_model(*x) for x in model_menu()];positive=sum(x['best_qualified'] is not None and F(x['best_qualified']['original_T_exact'])>0 for x in models);assert positive>=1
 out={'schema':'R285-exact-geometric-near-coupling-v1','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'counts':{'models':6,'stage_models':{'initial':2,'stress':2,'expanded':2},'exact_near_edges':sum(len(x['edges']) for x in models),'marginal_inequalities':sum(len(x['Y_exact'])+len(x['Z_exact']) for x in models),'receiver_scale_rows':sum(len(x['receiver_scale_rows']) for x in models),'allR_hardcap_receivers':sum(len(x['allR_hardcap_certificates']) for x in models),'qualified_rows':sum(x['qualified_rows'] for x in models),'models_with_positive_qualified_traffic':positive},'models':models,'decision':'Marginal normalization creates a subcoupling, but exact recovery retains max(m_z,n_y) as a weight. It does not remove the original weighted cost; sparse/disconnected graphs are preserved.','scope':['Exact Fraction positive finite atomic laws and actual cube indicators at receiver grid points, not continuous receiver cells or L1 source/FULL instances. No posterior/Pi/history/high qualification certified.','lambda is fixed per model from the maximum actual rho response over the declared receiver/L grid, not reset per receiver. q-band and independent nu hardcap are explicitly checked and may fail; only jointly qualified rows are optimized.','For each receiver the nu hardcap is exact over every continuous R in[1,2]: the response decreases as R^-n between activation thresholds, and all activation thresholds plus endpoints are enumerated. Closed-cube endpoint convention retained.','The chosen scale response uses the same receiver and L,R for all sources; no per-source maximization. No general source theorem or dimension-order fit. No repository/Git/PDF changes.']}
 a.output.write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps({'counts':out['counts'],'best':[(x['name'],None if x['best_qualified'] is None else x['best_qualified']['T_over_q_exact']) for x in models]}))
if __name__=='__main__':main()
