import argparse,json
from fractions import Fraction as F
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--input',type=Path,default=Path(__file__).with_name('r285_numeric.json'));a=p.parse_args()
data=json.loads(a.input.read_text());marginals=edges_n=checks=rows_n=0
for model in data['models']:
 rho=list(map(F,model['rho_exact']));nu=list(map(F,model['nu_exact']));edges={(e['y'],e['z']) for e in model['edges']}
 Y=[tuple(map(F,q)) for q in model['Y_exact']];Z=[tuple(map(F,q)) for q in model['Z_exact']];X=[tuple(map(F,q)) for q in model['receiver_points_exact']]
 M=[sum((rho[i] for i in range(len(rho)) if (i,j) in edges),F(0)) for j in range(len(nu))]
 tau={(i,j):nu[j]/M[j] for i,j in edges if M[j]>0}
 for j in range(len(nu)):
  assert sum((rho[i]*tau.get((i,j),F(0)) for i in range(len(rho))),F(0))==nu[j]*int(M[j]>0);marginals+=1
 for i,j in edges:
  assert rho[i]*tau[i,j]*M[j]==rho[i]*nu[j];edges_n+=1
 thresholds=sorted({mm*f for mm in M if mm>0 for f in (F(1,2),F(1),F(2))})
 for row in model['receiver_scale_rows']:
  if not row['qualified']:continue
  rows_n+=1;x=X[row['receiver']];R=F(row['R_exact'])
  h=[F(int(all(abs(t-u)<=R/2 for t,u in zip(x,z))))/R**len(x) for z in Z]
  for threshold in thresholds:
   for clock in (F(1,2),F(1),F(2)):
    cutoff=clock*threshold
    for i in range(len(rho)):
     actual=sum((nu[j]*h[j] for j in range(len(nu)) if (i,j) in edges and M[j]<=cutoff),F(0))
     majorant=cutoff*sum((tau.get((i,j),F(0))*h[j] for j in range(len(nu))),F(0))
     assert actual<=majorant;checks+=1
print('PASS',{'dual_marginals':marginals,'edge_recovery':edges_n,'qualified_rows':rows_n,'actual_low_M_comparisons':checks})
print('Exact finite point/receiver diagnostics only; not continuous L1/FULL certification.')
