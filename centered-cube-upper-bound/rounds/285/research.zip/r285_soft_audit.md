# R285 independent audit: full-soft local packet weak envelope

## SA1. Independent statement screen before author proof

**Independent screen: PASS for n>=1 integer, D>=0, a>0, finite positive L1 mu supported in B1(z,r), r>=0.** This section was derived and sent to the parent before reading `/tmp/r285_soft_packet.md`. It does not audit the separate original-traffic allocation.

Let kappa_r=6+4sqrt(2nr/a), M=min(n,floor D+1),

`H_*=(D+2)[log(en)+log(2D+3)+15]`.

The screened full-soft weak factor is

`B=e^2 M(D+3){3+2log2+2log M`

`                +2[log(n+1)+H_*+log(2D+3)+60]}`.

All logarithms here are natural except where a base is explicitly shown.

### Fixed-shape geometry and Jacobian

For any finite positive diagonal shape R, put T_R x=(x_i/R_i). Its rectangular kernel satisfies

`(H_(R,L)*mu)(x)=(det R)^-1(h_L*(T_R#mu))(T_R x)`.

The pushforward remains L1, has unchanged mass, and is supported in the l1 ball of radius r/min R_i. Threshold and receiver-volume Jacobians cancel exactly in weak L1. The already audited R284 all-scales packet theorem therefore supplies

`weaknorm(sup_(L>=a) H_(R,L)*mu)`

` <=[6+4sqrt(2nr/a) max_i R_i^(-1/2)]||mu||`.

Hard-labeled coordinates have R_i=1, so this is at most kappa_r U_R||mu|| with U_R=1+sum_(soft i)R_i^(-1/2). There is no aspect determinant left in the constant, no finite upper-scale requirement, and no source-coordinate independence.

### Soft mesh and rounding

For k=max(1,ceil(ns))<=M, sigma_k=k/(n+1), the affine factors obey f_s<=(1+1/n)f_sigma_k coefficientwise on the corresponding interval. Their common n-fold product costs at most e, including s=0 and the endpoint s=1 when permitted. Let zeta=1+1/(D+1). Upward-round every positive soft side t to R_j=zeta^j, so t<=R_j<=zeta t. A product rectangle costs zeta^(number soft coordinates). Absorb this into a tilted product label law: its normalizing mass is at most exp(n sigma_k/(D+1))<=e, and its new soft-label probability satisfies n t_k<=D+2. This proves a common-soft e^2 menu with M nodes, without an independent coordinate-soft choice or an L grid.

### Rounded shape moments and entropy constants

The interval-mixture measure for phi has density `-(t/2)phi'(t/2)`, probability mass one, inverse moment phi(0)<=1, second moment 13, and density at most t/2 near zero. Upward rounding gives

`Z_(1/2)=E R_j^(-1/2)<=E t^(-1/2)<=sqrt(E t^-1)<=1`.

By Jensen and the second moment,

`Z_(1/2)>=2^-1/2 E t^-1/2>=2^-1/2 13^-1/4>1/4`.

With eta=log zeta, the two-sided geometric reference proportional to exp(-eta|j|) has normalization 2D+3. The rounded unweighted entropy satisfies

`H(p)<=log(2D+3)+14`,

because E|log t|<=1/8+13 and eta<=log2. For the inverse-half tilted law, its reference moment is at most

`eta E_tilt|j|<=4[E(t^-1/2|log t|)+log2 E t^-1/2]`

`                 <=4[2/9+13+log2]<60`.

Here the small-side term is `(1/2)integral_0^1 t^(1/2)(-log t)dt=2/9`; the large-side part is bounded by E t^2=13. Thus its entropy is at most log(2D+3)+60, exactly the proposed constant. Countable-reference cross entropy is finite, so these claims do not assume finite entropy in advance.

For x=n t_k<=D+2, n h2(t_k)<=x log(en/x)<=x log(en)+1/e. Consequently the rounded product label entropy is bounded by H_*, since the harmless 1/e remainder is absorbed by the spare unit in 15.

### Marks and countable weak summation

Mark 0 has weight 1; mark i has weight `1_soft(i) R_i^-1/2`. Their total is U_R, and E U_R<=D+3. Conditional mark 0 leaves the original product law; conditional mark i forces its coordinate soft with the inverse-half tilted law and leaves other kernel labels unchanged. The normalized marked entropy is therefore at most

`E_*=log(n+1)+H_*+log(2D+3)+60`.

Across M nodes the total assigned weak mass is at most e^2 kappa_r||mu|| M(D+3), and its normalized entropy is at most log M+E_*.

For clarity, the applicable countable positive weak-sum lemma has coefficient `3+2log2+2H`. If functions have weak bounds a_i, total A=sum a_i and finite weight entropy H, split the event sum f_i>u into the union {some f_i>u}, of price A/u, and middle pieces above u a_i/(2A) but at most u. Low pieces sum to at most u/2. Their middle strong integrals are at most a_i[1+log(2A/a_i)], so Markov costs at most twice that sum divided by u. This yields the stated coefficient. Countable labels follow by nonnegative limits and finite entropy. Assigning marks as exact fractions of each positive function avoids source/function duplication.

These independent steps give the proposed kappa_r B bound for the full supremum over 0<=s<=1, ns<=D and L>=a. They retain all soft tails. The claim remains a packet maximal estimate and uses no FIRST at any step.

## SA2. Author proof and final version binding

**Final verdict: PASS. No mathematical or scope correction requested.**

Author file actually read in full and SHA verified:

`/tmp/r285_soft_packet.md`

SHA256 `74332cdc1e1b11ff6f66437e10b0ab9ae661ad9b534254a4f2f18d455953d24c`.

The independent screen in SA1 was recorded before reading this file. The author proof matches its complete accounting. The following details were checked explicitly:

1. The original source is finite positive L1; an invertible diagonal pushforward remains L1. The determinant identity in (5) has the correct direction and cancels in the weak-level measure. Thus R284's all-scales theorem applies for every positive finite shape, even when the transformed support radius is much larger than a. No finite-octave fallback or missing aspect determinant is needed.
2. The geometric factor is controlled by the full U_R, including when all coordinates are soft or all their sides exceed one. This is a half-inverse factor, not an inverse factor or a supremum of all small sides taken outside the mixture.
3. The interval-mixture density, inverse moment and second moment 13 are correct for the original phi. The two explicit small-side logarithmic integrals are 1/8 and 2/9. The rounded inverse-half lower bound follows from Jensen and loses only sqrt(2); the safe 1/4 and resulting entropy constant 60 are valid.
4. The final author uses k=min(n,floor(ns)+1), rather than the endpoint variant in SA1. This choice is also correct: ns in [k-1,k) gives both affine coefficient bounds, while the s=1 endpoint is handled by k=n. It satisfies k<=min(n,floor D+1), including D=0 and integer D. Its common-soft menu is used once, not independently in each coordinate.
5. The two distinct coefficient losses are retained: gamma^n<=e for common-soft discretization and Z_k<=e for shape rounding. Tilting the rounded product label law is exact; nt_k<=D+2. Taking sup_L through the positive mixture is only an upper bound, as explicitly stated in (15).
6. The author's H(p)<=log(2D+3)+15 is sufficient for (16). For nt_k<=1, n h2(t_k)<=log(en); for nt_k>1, it is at most (D+2)log(en). Therefore H_* has no missing small-nt entropy term. The independent screen's slightly sharper raw-shape constant 14 is not needed for the author proof.
7. Marking is an exact function decomposition. Mark i forces only its own kernel label soft and changes its side law to the inverse-half tilt; the other kernel labels retain their product law. The normalized mark entropy, conditional shape entropy and unequal node masses yield exactly E_* and log M. These are facts about positive kernel coefficients, not independence assertions about the input source.
8. The assigned weak constants are multiplied by the actual unnormalized marked probabilities, with total at most e^2 kappa_r m M(D+3). The countable weak-sum inequality (18) has the correct coefficient 3+2log2+2H. The proof's high union, deterministic low sum and truncated middle integrals account for all pieces. Finite weight entropy allows monotone limits of the entire countable shape family; no soft-tail cutoff or unpaid label count remains.
9. Suprema are measurable in the stated L1 setting: for fixed x the convolution is continuous in (s,L) with L>0 by dominated convergence, since hard coordinate boundaries have zero source mass. Each rectangular maximal function similarly has a countable-scale version. The upper envelopes and countable label sums are measurable. This justifies the stated full parameter family, not only a finite sample of selectors.
10. For D<=C log(n+2), M=O_C(log(n+2)) and H_*=O_C(log^2(n+2)), so the displayed B is O_C(log^4(n+2)). At the original radius kappa_r=6+sqrt(2)n^(1/4). The claimed full-soft single-packet order follows with all constants present.

## SA3. Actual independent diagnostic replay

The author's embedded Python block was extracted and actually executed unchanged. Exact output:

```text
AUTHOR_SHA256 74332cdc1e1b11ff6f66437e10b0ab9ae661ad9b534254a4f2f18d455953d24c
PASS 255
E[r^-1/2]= 0.7018321856253943535683159
E[r^-1/2 |log r|]= 0.5103843128782831114226181
```

The count is four moment inequalities at two precisions plus one agreement check, and 250 menu/rounding inequalities (five n values, five D values, five soft fractions, two assertions each). The moment calculations use ordinary 40/60-digit mpmath quadrature; the finite parameter checks use ordinary floating point. They are not directed interval certificates and do not certify FULL original histories. The analytic proof, independently screened above, supplies the universal conclusions.

Reproduce the exact extraction without changing the author file:

```python
from pathlib import Path
import hashlib
p=Path('/tmp/r285_soft_packet.md')
s=p.read_text()
print('AUTHOR_SHA256',hashlib.sha256(s.encode()).hexdigest())
blocks=[chunk.split('\n```')[0] for chunk in s.split('```python\n')[1:]]
assert len(blocks)==1
exec(compile(blocks[0],str(p)+' diagnostic','exec'),{})
```

## SA4. Scope of acceptance

This audit certifies the unconditional weak bound for the full common-soft family of one arbitrary positive L1 packet in the specified l1 ball. It covers all allowed s, every L>=a, all off-core soft response and the complete shape tail. It grants no FIRST to any latent component and uses no FIRST in its proof. Actual selector-dependent responses are pointwise dominated by that family, without a normalized-channel substitution.

The packet theorem does not by itself aggregate different packets, make an anchor-indexed pair mass linear, or pay original auxiliary posterior and score-clock weights. Those original-traffic uses are a separate task/audit. No nu-to-beta comparison, source-coordinate independence, or consumed negative credit is imported here.

**Final status: PASS, frozen at the author hash in SA2. Only this owned audit file was written. No author/repository/Git/PDF state was changed.**
