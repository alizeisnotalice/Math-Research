# R285 — exact two-source allocation and a paid low-neighbor-mass branch

## Proposition and explicit scope

Freeze one original outer source pair rho,nu, both finite nonnegative L1 measures, and retain all actual selectors, source cuts, current positive masks, and the original full pair posterior. Write W_rho=||rho||, W_nu=||nu|| and q_-=3lambda/4. Assume the ORIGINAL conditions

    q_- <= q(x) <= lambda,
    integral P_{s(x),L(x)}(x-y)rho(dy) <= q(x),
    a <= L(x),R(x) <= b <= 2a.

The original hard maximal cap <=4lambda remains in force; this proof does not need to spend it. No comparison between rho and nu is assumed. Set r=a/(16sqrt(n)) and define the actual original-hard-source neighbor mass

    N(y)=nu(B_1(y,r)).                                      (1)

At physical clock xi=c_j t/b set

    a_xi=max(a,b xi/gamma), gamma=1+1/n,
    kappa_xi=6+4sqrt(2nr/a_xi),
    N0_xi=q_- a_xi^n/kappa_xi.                              (2)

Every contributing original row has L,R>=a_xi. Retain the original upper-slot restriction R2(y,v)<=D and its qualification ns<=D. Let B>=1 be any valid uniform full-soft packet factor: for every finite positive L1 measure sigma supported in an l1 ball of radius r,

    || sup_{L>=a_xi, 0<=s<=min(1,D/n)} P_{s,L}*sigma ||_(1,infty)
       <=kappa_xi B ||sigma||.                              (H_B)

For hard input s=0, B=1 is unconditional by `/tmp/r284_mass_extension.md`. For the original full soft family, `/tmp/r285_soft_packet.md`, SHA256 `74332cdc1e1b11ff6f66437e10b0ab9ae661ad9b534254a4f2f18d455953d24c`, proves (H_B) with

    M=min(n,floor(D)+1),
    H_*=(D+2)[log(en)+log(2D+3)+15],
    E_*=log(n+1)+H_*+log(2D+3)+60,
    B=e^2 M(D+3)[3+2log2+2log M+2E_*].                      (3)

The two-source argument below depends only on (H_B), so its validity is separated from the independent audit of that soft packet lemma. It does not reprove or assume an unmarked shape-mixture estimate.

Let P_cur be any current unspent original positive near traffic, in particular the R284 heavyweight remainder. Multiply its original integrand by

    1{N(y)<=N0_xi}.

Then its resulting low-neighbor-mass part satisfies

    P_cur,lowN <=2Lambda B_D [W_rho+(1+log B)W_nu]
                <=8Lambda sqrt(nD)[W_rho+(1+log B)W_nu],     (P)

where B_D<=min(nlog2,4sqrt(nD)) is the existing original middle-clock score integral. The outside 2Lambda occurs exactly once. There is no coarse-grid factor in (P).

For D<=C log(n+2), (3) is polynomial in log(n+2), and (P) is therefore a genuine sqrt(n) times polylog source payment of this branch. It does not prove a positive coverage fraction or pay the complementary branch. The exact remaining traffic is the SAME current original integrand multiplied by 1{N(y)>N0_xi}.

## 1. A genuine source-mass disintegration across hard anchors

For each original hard anchor z define the auxiliary packet

    sigma_z(dy)=1{|y-z|_1<=r}1{N(y)>0}rho(dy)/N(y).          (4)

This packet is defined before xi, x, or any response threshold is chosen. It uses the entire original nu in (1), and is never a replacement for an original posterior or original source. The Borel measurability follows directly from measurability of the closed-ball incidence kernel and Tonelli. Its exact marginal identity is

    integral nu(dz)sigma_z(dy)=1{N(y)>0}rho(dy),
    integral ||sigma_z||nu(dz)=rho{N>0}<=W_rho.              (5)

Indeed integration of the incidence indicator in z is exactly N(y). Also

    integral 1{N(y)=0}1{|y-z|_1<=r}rho(dy)nu(dz)=0.          (6)

Thus sigma_z is a finite positive L1 measure supported in B_1(z,r) for nu-almost every z, and the exceptional anchors have zero nu mass. Neither absolute continuity nor finite mass requires rho<=nu. No source density is silently replicated at each anchor: (5) is the complete marginal calculation.

## 2. The actual low response keeps FIRST; its envelope gets only a weak bound

Fix xi and let E_xi denote the set of receivers allowed by the original physical clock and ns<=D. It may include the unique j(x) qualification; these restrictions will only be dropped positively. Put

    F_z^low(x,xi)=integral 1{|y-z|_1<=r}1{N(y)<=N0_xi}
                              P_{s(x),L(x)}(x-y)rho(dy).

By (6) the zero-N fibers can be removed. Positivity and the ORIGINAL full FIRST give

    0<=F_z^low(x,xi)/q(x)<=1.                               (7)

By (4), on E_xi,

    F_z^low(x,xi)
      <=N0_xi (P_{s(x),L(x)}*sigma_z)(x).                    (8)

In particular the function

    f_z(x)=1_{E_xi}(x)F_z^low(x,xi)/q(x)

is bounded by one and has weak-L1 constant at most

    kappa_xi B (N0_xi/q_-)||sigma_z||
       =B a_xi^n ||sigma_z||.                              (9)

Only the ACTUAL numerator in (7) has the FIRST cap. The maximal envelope in (H_B) and the packet sigma_z receive no FIRST assumption. The low-neighbor indicator remains inside the actual response; it is not put into sigma_z, so the mass allocation (5) is independent of clock.

## 3. Capped weak-product estimate, with both constants retained

If nonnegative functions f,g are bounded by one and have valid weak-L1 constants A,C, then

    integral f g <=I(A,C),
    I(A,C)=min(A,C)[2+log(max(A,C)/min(A,C))],                (10)

with I=0 when either argument is zero. One proof uses their decreasing rearrangements: f*(u)<=min(1,A/u), g*(u)<=min(1,C/u), and the integral of their product is exactly the displayed I. The rearrangement product inequality also follows directly by layer cake: the intersection of two superlevel sets has measure at most the smaller of their measures. Thus (10) applies on all of the real receiver space, not just to a probability-normalized selected channel.

For the actual hard point kernel, set

    g_z(x)=1_{E_xi}(x)a_xi^n h_{R(x)}(x-z).

This has height at most one and weak-L1 constant at most a_xi^n. To see the latter, the point envelope over ALL R>=a_xi is

    min(a_xi^(-n),(2||x-z||_infty)^(-n)),

whose superlevel volume is at most 1/u at level u. The finite upper window and actual selector can only decrease that envelope. This uses the original point kernel, with no expanded-scale hard cap.

Equations (9)-(10) and homogeneity of I therefore give, for nu-almost every z,

    integral_{E_xi} [F_z^low(x,xi)/q(x)] h_{R(x)}(x-z) dx
       <=a_xi^(-n) I(B a_xi^n||sigma_z||,a_xi^n)
       =I(B||sigma_z||,1).                                 (11)

For all x,y>=0 and B>=1,

    I(Bx,y)<=x+(1+log B)y.                                 (12)

For completeness, I(x,y)<=x+y follows from log u<=u-1. At positive arguments the derivative of I(e^t x,y) in t is y if e^t x>=y, and otherwise is e^t x[1+log(y/(e^t x))]<=y. Integrate from 0 to log B and use continuity at zero. This proves (12) without losing a factor B in the final hard-source price.

Integrating (11) in the ORIGINAL nu and applying (5) and (12) yields the source-paid receiver estimate

    T_low(xi):=integral_{E_xi} dx integral nu(dz)
                      [F_z^low(x,xi)/q(x)]h_{R(x)}(x-z)
       <=W_rho+(1+log B)W_nu.                              (13)

All displayed receiver integrals here are restricted to E_xi. No normalized selected column is used; no atomwise sum of weak norms is treated as an L1 norm. The product estimate is applied once per actual hard anchor, and its two linear source terms are then integrated by the exact marginal identity.

## 4. Return to the full original score and clock

At fixed actual x,y,j,t, keep the original full Pi_t x Pi_t and its upper-slot mask. The audited score bound is

    E_{Pi_t x Pi_t}[(k_t(v)-k_t(u))_+
                   1_good(v)1{R2(y,v)<=D}]
       <=f_D(xi)=min(n,D/(1-xi)^2).

The new gate 1{N(y)<=N0_xi} is independent of v,u. Apply this probability bound before source integration. Existing unspent masks, including any hard-source cut 1_{Z_g(y)}, stay in the actual branch and can be discarded only positively in its majorant. If P_cur is the R284 heavyweight allocation, its factor A_heavy is in [0,1], so it too is discarded positively; no conditional-grid denominator remains in (13).

Change dt/t to dxi/xi on each ACTUAL row; retain the unique j(x) indicator until its sum is at most one. On each resulting E_xi, equations (2) and (13) apply. Thus

    P_cur,lowN
      <=2Lambda integral_middle f_D(xi) T_low(xi) dxi/xi
      <=2Lambda B_D[W_rho+(1+log B)W_nu].

This is (P). The source packet sigma_z is the same at every xi; the variable N0_xi is merely an actual-integrand gate. Its uniform source price is integrated against the one existing score integral, rather than being copied per physical scale. No deletion jump, old negative credit, new j menu, or second Lambda is used.

For the original outer seed/terminal average, apply the proof to every original source pair and sum the linear masses with their original weights. When D varies with that outer datum, keep B_D and B_{n,D} inside the same outer sum until an actual common bound is available.

## 5. Exact unresolved branch and what the allocation changes

After the R284 light payment and the new payment (P), the residual is exactly

    original current positive near integrand
      * A_heavy(x,y,z,xi)
      * 1{nu(B_1(y,r))>q_-a_xi^n/kappa_xi},                  (14)

where “current” before the displayed A_heavy means the remainder to which the R284 split was applied. Equivalently, if current already includes A_heavy, multiply it only by the last indicator. Every original source, physical selector, source cut, near condition, full pair posterior, and remaining positive mask is retained in (14).

The new branch condition is a genuine lower bound on ORIGINAL hard-source mass near each contributing soft point, measured in source-mass units: lambda times length^n. It does not imply a positive lower bound on the selected hard response at x. The existing hard cap <=4lambda and the heavy-cell response constraint A_xi F_C>q therefore still need a joint geometric argument on (14).

The concrete progress is that local packet weak estimates can now be used over continuously many hard anchors without repeating soft mass. The price is the explicit low-neighbor-mass gate, whose threshold absorbs kappa_xi. This does not establish any guaranteed coverage fraction, does not estimate (14), and does not close the general root-polylog goal.

## 6. Actual local algebra diagnostic

The exact finite incidence diagnostic below was actually run. It returned

    PASS exact_marginal_checks=5 exact_low_gate_checks=60
         floating_I_amplification_checks=125
    neighbor_masses=['1/5','1/5','7/15','14/15','0']
    allocated_rho_mass=17/28 original_rho_mass=1.

The rational checks verify (5) and (8), including a zero-N source and nontrivial low/high thresholds. The floating checks verify instances of (12). They are finite algebra diagnostics, not an original L1-history construction or interval certificate; the analytic argument is above. Reproducible code:

```python
from fractions import Fraction as Q
import math
Y=[Q(0),Q(1,8),Q(1,4),Q(1,2),Q(2)]
Z=[Q(0),Q(1,4),Q(1,2),Q(3,4)]
r=Q(1,4)
rho=[Q(k,28) for k in (2,3,5,7,11)]
nu=[Q(k,15) for k in (1,2,4,8)]
edge=[[abs(y-z)<=r for y in Y] for z in Z]
N=[sum((nu[j] for j in range(len(Z)) if edge[j][i]),Q(0))
   for i in range(len(Y))]
sigma=[[rho[i]/N[i] if edge[j][i] and N[i]>0 else Q(0)
        for i in range(len(Y))] for j in range(len(Z))]
marginal_checks=0
for i in range(len(Y)):
    assert sum((nu[j]*sigma[j][i] for j in range(len(Z))),Q(0)) == \
           (rho[i] if N[i]>0 else 0)
    marginal_checks+=1
allocated=sum((nu[j]*sum(sigma[j],Q(0)) for j in range(len(Z))),Q(0))
assert allocated<=sum(rho,Q(0))
comparison_checks=0
for threshold in (Q(0),Q(1,15),Q(1,5),Q(1,3),Q(1)):
    for kernel in ([Q(1)]*5,[Q(k,7) for k in (0,1,2,3,4)],
                   [Q(k,11) for k in (13,0,5,1,7)]):
        for j in range(len(Z)):
            F=sum((rho[i]*kernel[i] for i in range(len(Y))
                   if edge[j][i] and N[i]<=threshold),Q(0))
            bound=threshold*sum((sigma[j][i]*kernel[i]
                                 for i in range(len(Y))),Q(0))
            assert F<=bound
            comparison_checks+=1
def I(x,y):
    if min(x,y)==0:return 0.
    return min(x,y)*(2.+math.log(max(x,y)/min(x,y)))
amplification_checks=0
for x in (0.,1e-5,.1,1.,17.):
    for y in (0.,1e-5,.1,1.,17.):
        for B in (1.,1.1,2.,100.,1e8):
            lhs=I(B*x,y);rhs=x+(1.+math.log(B))*y
            assert lhs<=rhs+1e-12*max(1.,lhs,rhs)
            amplification_checks+=1
print('PASS exact_marginal_checks=',marginal_checks,
      'exact_low_gate_checks=',comparison_checks,
      'floating_I_amplification_checks=',amplification_checks)
print('neighbor_masses=',list(map(str,N)),
      'allocated_rho_mass=',str(allocated),
      'original_rho_mass=',str(sum(rho,Q(0))))
print('Finite algebra diagnostics only; not an original L1-history model or interval certificate.')
```
