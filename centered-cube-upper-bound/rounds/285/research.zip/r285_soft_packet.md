# R285: full-soft local packet maximal estimate

Only this temporary file is written. This extends the R284 near-packet weak theorem to the entire original common-soft family, including its off-core part and all physical scales L>=a. No FIRST cap is assigned to a latent component. The packet source is arbitrary positive L1; independence used below belongs only to the positive kernel mixture.

## 1. Statement and explicit price

Let n>=1, a>0, D>=0, and let mu be a nonnegative finite L1 measure of mass m supported in B_1(z,r), r>=0. Define
\[
h=1_{[-1/2,1/2]},\quad
w(x)=\int_0^1e^{-|x|/u}du,\quad \phi=h*w,
\]
\[
P_{s,L}(x)=L^{-n}\prod_{i=1}^n[(1-s)h(x_i/L)+s\phi(x_i/L)],
\]
and the full common-soft maximal function
\[
\mathcal M_{a,D}^{\rm soft}\mu(x)
=\sup_{\substack{L\ge a\\0\le s\le\min(1,D/n)}}(P_{s,L}*\mu)(x).
\]
Put
\[
\begin{split}
\kappa_r&=6+4\sqrt{2nr/a},\qquad
M=\min\{n,\lfloor D\rfloor+1\},\qquad \zeta=1+\frac1{D+1},\\
H_*&=(D+2)\{\log(en)+\log(2D+3)+15\},\\
E_*&=\log(n+1)+H_*+\log(2D+3)+60,\\
\mathfrak B_{n,D}
&=e^2M(D+3)\{3+2\log2+2\log M+2E_*\}.
\end{split}                                                     \tag{1}
\]
Then for every lambda>0,
\[
\boxed{\lambda|\{\mathcal M_{a,D}^{\rm soft}\mu>\lambda\}|
\le\kappa_r\mathfrak B_{n,D}\,m.}                              \tag{2}
\]
At r=a/(16 sqrt(n)), the geometric factor is
\(\kappa_r=6+\sqrt2\,n^{1/4}\). For D<=C log(n+2), (2) is
\[
O_C\bigl(n^{1/4}\log^4(n+2)\bigr)m.                           \tag{3}
\]
This is an all-s, all-L weak bound, not a fixed-parameter estimate. It applies to the actual full soft response of a positive restriction mu of an original source. It alone does not sum weak bounds of different packets, change original posteriors, or establish a full traffic budget.

The geometric ingredient is the proved R284 theorem
\[
\|\mathcal M_{[a,\infty)}\sigma\|_{1,\infty}
\le [6+4\sqrt{2nR/a}]\|\sigma\|
\quad\text{if }\operatorname{supp}\sigma\subset B_1(z,R).     \tag{4}
\]
Its proof and measurable scale-crossing selection are in `/tmp/r284_mass_extension.md`, SHA256 `4acab79c70051cc2d9164b9a395011bb5d728750bc40280efa15e7a0898a4fa3`. The R284 source file is not modified here.

## 2. Fixed rectangle shape: determinant cancellation and half-inverse cost

For a positive shape vector R=(R_i), set
\[
H_{R,L}(x)=\frac{1_{\{|x_i|\le LR_i/2\ \forall i\}}}
 {L^n\prod_iR_i},\qquad
\mathcal K_R\mu=\sup_{L\ge a}H_{R,L}*\mu.
\]
Under x_i=R_i x_i', the pushforward source mu^R has the same mass and is supported in an l1 ball of radius r/min_i R_i. Furthermore
\[
(H_{R,L}*\mu)(\operatorname{diag}(R)x')
=(\prod_iR_i)^{-1}(h_L*\mu^R)(x').
\]
The spatial determinant exactly cancels the density factor in a weak-L1 level estimate. Thus (4) gives
\[
\|\mathcal K_R\mu\|_{1,\infty}
\le\left[6+4\sqrt{\frac{2nr}{a\min_iR_i}}\right]m.            \tag{5}
\]
Label each coordinate as hard (side 1) or soft. Define
\[
U_R=1+\sum_{i\text{ soft}}R_i^{-1/2}.
\]
Since U_R>=1 and U_R>=(min_i R_i)^(-1/2), including when all coordinates are soft,
\[
\|\mathcal K_R\mu\|_{1,\infty}\le\kappa_r U_R m.             \tag{6}
\]
No source-coordinate independence is used. Large aspect ratios and arbitrarily small positive sides are allowed. In particular no global infimum of the random sides is taken outside the mixture.

## 3. Positive shape law and its explicit entropy moments

The original phi is even, decreasing on the positive half-line, and absolutely continuous, with
\(\phi'(x)=w(x+1/2)-w(x-1/2)\). Its positive interval-mixture measure is
\[
\mu_\phi(dt)=-\frac t2\phi'(t/2)dt,\qquad
\phi(x)=\int_0^\infty t^{-1}1_{\{|x|\le t/2\}}\mu_\phi(dt).
                                                                    \tag{7}
\]
It is a probability. Each kernel coordinate independently chooses side 1 with probability 1-s, or a side from mu_phi with probability s. The resulting labelled product law pi_s satisfies
\(P_{s,L}=\int H_{R,L}\,d\pi_s(R)\).

The following moment facts are elementary consequences of (7):
\[
\int t^{-1}\mu_\phi(dt)=\phi(0)\le1,\qquad
\int t^2\mu_\phi(dt)=13,\qquad
\mu_\phi'(t)\le t/2\quad(0<t<1).                              \tag{8}
\]
For the second equality, w has variance 1, h has variance 1/12, and a uniform interval of full side t has variance t^2/12. Therefore
\[
\int|\log t|d\mu_\phi\le\tfrac18+13,
\qquad
\int t^{-1/2}|\log t|d\mu_\phi\le\tfrac29+13<14.              \tag{9}
\]
The small-t contributions are direct integrals against t/2. On t>=1, both |log t| and t^-1/2 log t are at most t^2.

Round each soft side t upward to R_j=zeta^j when zeta^(j-1)<t<=zeta^j, j in Z, and let p_j be the mu_phi mass of this bin. Let eta=log zeta. Then
\[
R_j/t\le\zeta\le2,\quad
\eta|j|\le|\log t|+\eta.
\]
The reference law proportional to exp(-eta|j|) has normalizer 2D+3. Relative entropy against this law gives
\[
H(p)\le\log(2D+3)+15.                                      \tag{10}
\]
The same conclusion can first be proved on finite bin truncations and passed to the limit using (9).

The half-inverse moment z_(1/2)=sum_j p_j R_j^(-1/2) obeys
\[
\frac14\le z_{1/2}\le1.                                   \tag{11}
\]
For the upper bound use upward rounding and Cauchy with the first identity in (8). For the lower bound, Jensen applied to (t^2)^(-1/4) gives integral t^-1/2>=13^-1/4, and rounding loses at most sqrt(2); 13^-1/4/sqrt(2)>1/4.
The tilted shape probability p_j^(1/2)=p_j R_j^(-1/2)/z_(1/2) satisfies
\[
\eta\sum_j|j|p_j^{(1/2)}
\le\frac{14+\log2}{z_{1/2}}<60,
\qquad H(p^{(1/2)})\le\log(2D+3)+60.                        \tag{12}
\]
These estimates pay the actual small-side shape law, including its entropy. They are not assumptions on the input mu.

## 4. One common-soft menu, with all probability inflation retained

Let gamma=(n+1)/n. Given s in [0,min(1,D/n)], choose
\[
k=\min\{n,\lfloor ns\rfloor+1\},\qquad \sigma_k=k/(n+1).
\]
Then 1<=k<=M,
\[
s\le\gamma\sigma_k,\quad 1-s\le\gamma(1-\sigma_k),\quad
n\sigma_k\le D+1.                                         \tag{13}
\]
Every nonnegative latent-kernel coefficient at s is at most gamma^n<=e times its coefficient at this single sigma_k. This covers both endpoints s=0 and s=1 whenever they are in the allowed range.

Upward rounding of k_soft sides costs zeta^(k_soft). At sigma_k the total mass after that weighting is
\[
Z_k=[1+(\zeta-1)\sigma_k]^n\le e,
\]
and the normalized rounded law pi_k^disc is still a product labelled law, with soft probability
\[
t_k=\frac{\zeta\sigma_k}{1+(\zeta-1)\sigma_k},\qquad nt_k\le D+2.
                                                                    \tag{14}
\]
Consequently, by positivity, for every x, all allowed s, and every L>=a,
\[
(P_{s,L}*\mu)(x)
\le e^2\sum_{k=1}^M\int(H_{R,L}*\mu)(x)\,d\pi_k^{\rm disc}(R).
\]
Taking a supremum only increases the right side to the fixed nonnegative envelope
\[
\mathcal M_{a,D}^{\rm soft}\mu
\le e^2\sum_{k=1}^M\int \mathcal K_R\mu\,d\pi_k^{\rm disc}(R).
                                                                    \tag{15}
\]
Thus no supremum is passed through the mixture as an equality, and both coefficient losses e are present. The laws in (15) do not depend on the receiver or the input measure.

For these product kernel labels,
\[
H(\pi_k^{\rm disc})
=n h_2(t_k)+nt_k H(p)\le H_* .                              \tag{16}
\]
To include nt_k<1 correctly, note that x log(en/x) is increasing on (0,n]. If nt_k<=1, it is at most log(en); if it exceeds 1, it is at most (D+2)log(en). Together with (10) this proves (16) in every case.

## 5. Exact marking pays the half-inverse factor and the weak sum

For each node k and shape R, introduce mark 0 of weight 1, and mark i of weight 1_(i soft)R_i^-1/2. Their sum is U_R. Split the function K_R mu into these same fractions divided by U_R. This is an exact nonnegative decomposition; it neither discards nor duplicates a source contribution.

By (6), each marked piece in (15) has weak constant bounded by e^2 kappa_r m times its unnormalized marked probability. The marked mass for a node is
\[
Z_k'=\mathbb E_{\pi_k^{\rm disc}}U_R
=1+nt_k z_{1/2}\le D+3.                                   \tag{17}
\]
Conditionally on mark 0, the original rounded shape law remains. Conditionally on mark i>0, coordinate i is forced soft with law p^(1/2); the remaining coordinates have the original independent kernel-label laws. Its entropy is at most H_*+H(p^(1/2)). The entropy of the mark index is at most log(n+1). Therefore the normalized marked law at every node has entropy at most E_* from (1).

Across all M nodes the total unnormalized marked mass is at most M(D+3). Its normalized entropy is at most log M+E_*, even though the actual masses Z_k' need not agree.

Here is the needed weak-sum inequality, including its proof. For a finite or countable family of nonnegative functions with valid weak constants a_i and A=sum a_i,
\[
\Big\|\sum_i f_i\Big\|_{1,\infty}
\le A(3+2\log2)+2\sum_i a_i\log(A/a_i).                     \tag{18}
\]
For a level u, remove the union {f_i>u}, with measure at most A/u. Terms below u a_i/(2A) have total at most u/2. Each remaining piece has integral at most a_i[1+log(2A/a_i)], by integrating its weak tail from u a_i/(2A) to u. Markov at u/2 proves (18). Finite truncations and monotone convergence prove the countable statement when the indicated entropy is finite. Terms with a_i=0 vanish almost everywhere and can be removed.

Apply (18) to the marked decomposition, with
\[
A\le e^2\kappa_r mM(D+3),\qquad
H(a_i/A)\le\log M+E_*.
\]
This proves (2) exactly with the constant (1).

## 6. Scope of the new source payment

The new geometric improvement over the prior rectangular cluster argument is the replacement of an inverse-side multiplier by a half-inverse-side multiplier, together with the R284 l1-ball constant kappa_r. At the actual near radius it changes the single-packet full-soft weak scale from order sqrt(n) times polylog to order n^(1/4) times polylog. The proof covers all source shapes within that l1 ball and the full soft off-core response.

For an actual restricted source mu<=f, the same envelope bounds its response for every actual s(x),L(x) in the stated range. It does not bound the envelope's height by an actual FIRST cap; actual caps apply only to the actual response. No latent component receives FIRST, no assumption nu<=beta is used, and no original source is renormalized. If packets are indexed by hard anchors or source cells, their sum still requires the established weak-sum or another joint allocation mechanism; (2) cannot be added as if weak-L1 were an L1 norm. Likewise no original score/clock fee is absorbed here. The bounded deliverable is the unconditional full-soft packet estimate (2), not a full global root theorem.

## 7. Actual bounded local diagnostics

The following Python block was run locally. It returned PASS 255. The two inverse-half moments were computed at 40 and 60 decimal digits and agreed within 1e-30. Numerical outputs were

```
E[r^-1/2] = 0.7018321856253943535683159
E[r^-1/2 |log r|] = 0.5103843128782831114226181
```

These are diagnostics, not interval certificates. The moment, entropy, and maximal-function inequalities above have independent analytic proofs. The code tests no original FULL input or posterior budget.

```python
import sys,math
sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
import mpmath as mp
answers=[];checks=0
for prec in (40,60):
    mp.mp.dps=prec
    def w(x):
        x=abs(x)
        return mp.mpf(1) if x==0 else mp.exp(-x)-x*mp.e1(x)
    def dens(r):
        return r/2*(w(abs(r/2-mp.mpf('.5')))-w(r/2+mp.mpf('.5')))
    intervals=[0,1,2,4,8,16,mp.inf]
    half=mp.quad(lambda r:dens(r)/mp.sqrt(r) if r else mp.mpf(0),intervals)
    loghalf=mp.quad(lambda r:dens(r)*abs(mp.log(r))/mp.sqrt(r) if r else mp.mpf(0),intervals)
    assert mp.mpf(13)**(-mp.mpf(1)/4)<=half<=1;checks+=1
    assert 0<=loghalf<14;checks+=1
    answers.append((half,loghalf))
assert max(abs(answers[0][j]-answers[1][j]) for j in (0,1))<mp.mpf('1e-30');checks+=1
for n in (1,2,8,64,512):
    for D in (0.,.5,2.,math.log(n+2),float(n)):
        M=min(n,math.floor(D)+1);zeta=1+1/(D+1);gamma=1+1/n
        for frac in (0.,.25,.5,.75,1.):
            s=frac*min(1.,D/n);k=min(n,math.floor(n*s)+1);sigma=k/(n+1)
            assert k<=M and s<=gamma*sigma+1e-14 and 1-s<=gamma*(1-sigma)+1e-14;checks+=1
            tilted=zeta*sigma/(1+(zeta-1)*sigma)
            assert n*math.log1p((zeta-1)*sigma)<=1+1e-13 and n*tilted<=D+2+1e-13;checks+=1
print('PASS',checks)
print('E[r^-1/2]=',mp.nstr(answers[1][0],25))
print('E[r^-1/2 |log r|]=',mp.nstr(answers[1][1],25))
```
