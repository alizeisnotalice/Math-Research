#!/usr/bin/env python3
"""R285 supplemental one-sided allocation and scalar layer integral; no FULL."""
import argparse,hashlib,json
from pathlib import Path
from fractions import Fraction as F
import mpmath as m

def enc(x):return m.nstr(x,90)
def h(x,y,L):return F(int(all(abs(a-b)<=L/2 for a,b in zip(x,y))),1)/L**len(x)
def allocation(data):
 models=[];recon=0;edgechecks=0;lowchecks=0;trafficchecks=0
 for model in data['models']:
  rho=list(map(F,model['rho_exact']));nu=list(map(F,model['nu_exact']));Y=[tuple(map(F,p)) for p in model['Y_exact']];Z=[tuple(map(F,p)) for p in model['Z_exact']];X=[tuple(map(F,p)) for p in model['receiver_points_exact']];edges={(e['y'],e['z']) for e in model['edges']};N=[sum((nu[j] for j in range(len(Z)) if (i,j) in edges),F(0)) for i in range(len(Y))]
  sigma={(i,j):rho[i]/N[i] for i,j in edges if N[i]>0}
  for i in range(len(Y)):
   assert sum((nu[j]*sigma.get((i,j),F(0)) for j in range(len(Z))),F(0))==rho[i]*int(N[i]>0);recon+=1
  for i,j in edges:assert sigma[i,j]*nu[j]*N[i]==rho[i]*nu[j];edgechecks+=1
  positive=sorted(set(x for x in N if x>0));thresholds=sorted(set(x*f for x in positive for f in [F(1,2),F(1),F(2)]));rows=0;minimum=None;strict=0
  for row in model['receiver_scale_rows']:
   if not row['qualified']:continue
   x=X[row['receiver']];L=F(row['L_exact']);R=F(row['R_exact']);p=[h(x,y,L) for y in Y]
   recovered=sum((sigma[i,j]*nu[j]*N[i]*p[i]*h(x,Z[j],R) for i,j in edges),F(0));assert recovered==F(row['original_T_exact']);trafficchecks+=1
   for base in thresholds:
    for clock in [F(1,2),F(1),F(2)]:
     cutoff=base*clock
     for j in range(len(Z)):
      lhs=sum((p[i]*rho[i] for i in range(len(Y)) if (i,j) in edges and N[i]<=cutoff),F(0))
      rhs=cutoff*sum((p[i]*sigma.get((i,j),F(0)) for i in range(len(Y))),F(0))
      assert lhs<=rhs;lowchecks+=1;rows+=1;gap=rhs-lhs;minimum=gap if minimum is None else min(minimum,gap);strict+=int(gap>0)
  models.append({'name':model['name'],'phase':model['phase'],'N_y_exact':list(map(str,N)),'zero_N_source_count':sum(x==0 for x in N),'sigma_positive_edges':len(sigma),'base_thresholds_exact':list(map(str,thresholds)),'clock_multipliers_exact':['1/2','1','2'],'low_N_receiver_checks':rows,'strict_low_N_checks':strict,'minimum_margin_exact':str(minimum)})
 return {'models':models,'counts':{'source_mass_reconstructions':recon,'original_edge_product_reconstructions':edgechecks,'qualified_original_traffic_reconstructions':trafficchecks,'low_N_kernel_inequalities':lowchecks},'identity':'sum_z nu_z sigma_z(y)=rho_y 1_{N_y>0}; sigma_z(y)nu_z N_y=1near rho_y nu_z','low_N':'sum_y p_y rho_y1near1_{N_y<=N0} <=N0 sum_y p_y sigma_z(y); threshold may vary with the declared rational clock multiplier, sigma remains static'}

def scalar(dps):
 with m.workdps(dps):
  menu=[(phase,m.mpf(ms),B) for phase,ms in [('initial','1e-12'),('initial','1e-6'),('stress','.01'),('stress','1'),('expanded','1e6'),('expanded','1e12')] for B in [m.mpf(1),m.mpf(2),m.mpf(100),m.log(1026)]]+ [('boundary',1/B,B) for B in [m.mpf(2),m.mpf(100)]]
  rows=[];tol=m.mpf(10)**(-dps+10)
  for phase,mass,B in menu:
   x=B*mass;y=m.mpf(1);lo=min(x,y);hi=max(x,y);closed=lo*(2+m.log(hi/lo));fn=lambda t:min(1,x/t)*min(1,y/t)
   first=m.quad(lambda z:lo*fn(lo*z),[0,1]);middle=m.mpf(0) if lo==hi else m.quad(lambda v:fn(lo*m.exp(v))*lo*m.exp(v),[0,m.log(hi/lo)])
   last=m.quad(lambda v:x*y/hi if v==0 else fn(hi/v)*hi/(v*v),[0,1]);quad=first+middle+last;bound=mass+1+m.log(B)
   assert abs(closed-quad)/max(1,closed)<tol and closed<=bound+tol*max(1,bound)
   rows.append({'phase':phase,'m':enc(mass),'B':enc(B),'Bm':enc(x),'I_closed':enc(closed),'I_quad':enc(quad),'bound_m_plus1_pluslogB':enc(bound),'margin':enc(bound-closed),'Bm_is_one':x==1})
  # zero branch is defined rather than log0 evaluated.
  return {'cases':rows,'zero_argument_I':'0'}
def main():
 p=argparse.ArgumentParser();p.add_argument('--input',type=Path,default=Path(__file__).with_name('r285_numeric.json'));p.add_argument('--output',type=Path);a=p.parse_args();raw=a.input.read_bytes();data=json.loads(raw);exact=allocation(data);lo=scalar(40);hi=scalar(60)
 with m.workdps(110):
  diff={}
  for i,(x,y) in enumerate(zip(lo['cases'],hi['cases'])):
   for k in ['m','B','Bm','I_closed','I_quad','bound_m_plus1_pluslogB','margin']:diff[str(i)+'/'+k]=abs(m.mpf(x[k])-m.mpf(y[k]))/max(1,abs(m.mpf(y[k])))
  worst=max(diff,key=diff.get);maximum=enc(diff[worst]);assert diff[worst]<m.mpf('1e-28')
 out={'schema':'R285-supplement-one-sided-allocation-v1','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'input_sha256':hashlib.sha256(raw).hexdigest(),'counts':{**exact['counts'],'geometry_models':6,'scalar_cases_per_precision':26,'precision_fields':len(diff)},'allocation':exact,'mp40':lo,'mp60':hi,'precision_max_scaled_difference':maximum,'precision_worst_field':worst,'scope':['Reads adjacent frozen r285_numeric.json by default; input SHA bound. Exact finite atomic geometry and qualified receiver rows reused, not new L1/FULL instances.','One-sided allocation conserves input mass only on N_y>0; all low-N inequalities checked with actual hard p_y and static sigma. No claim that high-N remainder or total original source cost has been paid.','I(x,y)=int_0^infinity min(1,x/t)min(1,y/t)dt=min(x,y)(2+log(max/min)), zero if either argument0. Independent transformed split quadrature includes the infinite tail. Ordinary40/60, not intervals.','For B>=1, I(Bm,1)-m<=1+logB: in Bm>=1 maximize2+log(Bm)-m at m1; below Bm1 function increasing and endpoint bound uses logB>=1-1/B. Finite tests corroborate, not prove general geometry.','Only this supplemental script is written; frozen r285_numeric files and repository/Git/PDF are untouched.']}
 text=json.dumps(out,sort_keys=True,indent=2)+'\n'
 if a.output:a.output.write_text(text)
 else:print(text,end='')
if __name__=='__main__':main()
