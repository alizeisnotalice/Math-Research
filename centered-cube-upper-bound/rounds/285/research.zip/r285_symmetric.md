# R285 parent extension: pay the low soft-neighbor mass after low hard-neighbor mass

This is a new positive allocation of the current original remainder, not an assertion that either allocated branch has positive coverage. Retain the exact qualifications of r285_joint.md, including q>=q_-=3lambda/4, original hard maximal cap <=4lambda on [a,b], full soft kernel with ns<=D, actual L,R>=a_xi, original near radius r and full auxiliary posterior. Let kappa_xi=6+4sqrt(2nr/a_xi). Let B>=1 be the explicit constant in r285_soft_packet.md, whose kernel-menu estimates are separately audited.

## 1. A soft POINT envelope, without using a delta in an L1 theorem

For each fixed shape R, the normalized rectangle kernel has the exact scaling envelope sup_{L>=a_xi}H_{R,L}(x-y). Its weak-L1 constant is at most 1: at level t>0, any contributing L satisfies L^n prod_i R_i<1/t; the union of these nested rectangles has volume at most 1/t. This is a direct point-kernel statement, requiring no source regularity or approximation of a delta.

The same source-independent common-soft menu and upward shape rounding as in r285_soft_packet.md give

sup_{ns<=D,L>=a_xi}P_{s,L}(x-y)
 <=e^2 sum_{k=1}^M sum_R pi_k^disc(R) sup_{L>=a_xi}H_{R,L}(x-y).

The labelled shape laws have entropy at most H_* and total mass one. Applying the proved countable weak-sum inequality, without any inverse-side marks, gives the point weak constant

B_point=e^2 M[3+2log2+2log M+2H_*] <=B.

The actual point kernel has height at most a_xi^(-n), since h,phi and (1-s)h+sphi are bounded by one. This height bound applies to the actual response, whereas the maximal point envelope is used only for its weak constant. The positive labelled mixture and all infinite shape tails remain present.

## 2. Source-conserving disintegration in the other direction

Define the ORIGINAL soft-source neighbor mass M(z)=rho(B_1(z,r)). Set

tau_y(dz)=1{|y-z|_1<=r}1{M(z)>0}nu(dz)/M(z).

Tonelli gives the exact identity

integral rho(dy) tau_y(dz)=1{M(z)>0}nu(dz),
integral ||tau_y|| rho(dy)<=W_nu.

Original near-pair product mass on M(z)=0 is zero. Hence for rho-almost every y, tau_y is a finite positive L1 measure supported in B_1(y,r). This is an auxiliary analysis packet, not a replacement of the actual source or the original posterior. It is fixed before the receiver or clock is chosen.

At each physical xi choose

M0_xi=4lambda a_xi^n/kappa_xi.

Define the actual low-M hard response

H_y^low(x,xi)=integral 1{|y-z|_1<=r}1{M(z)<=M0_xi}h_{R(x)}(x-z)nu(dz).

On the actual qualified receiver set E_xi,

0<=H_y^low<=4lambda,
H_y^low<=M0_xi(h_{R(x)}*tau_y)(x).

The first inequality uses the ORIGINAL hard cap at the actual R; it does not grant a hard cap to tau_y. The second is positive comparison. By the R284 hard near-packet theorem, f_y=1_E_xi H_y^low/(4lambda) has height at most 1 and weak constant at most a_xi^n||tau_y||. The actual g_y=1_E_xi a_xi^n P_{s(x),L(x)}(x-y) has height at most 1 and weak constant at most a_xi^n B_point.

## 3. Exact capped product and source price

With I(u,v)=min(u,v)[2+log(max(u,v)/min(u,v))] and the zero convention, the capped weak-product inequality gives

integral_E_xi P_{s(x),L(x)}(x-y) H_y^low/(4lambda) dx
 <=a_xi^(-n)I(a_xi^n B_point,a_xi^n||tau_y||)
 =I(B_point,||tau_y||)
 <=1+(1+log B_point)||tau_y||.

The last inequality is the already proved amplification I(Bu,v)<=u+(1+log B)v with u=1. Since 4lambda/q<=16/3, integration in the ORIGINAL rho yields

T_lowM(xi):=integral_E_xi dx integral rho(dy)
                 P_{s(x),L(x)}(x-y) H_y^low(x,xi)/q(x)
 <=(16/3)[W_rho+(1+log B)W_nu].

There is no near-anchor overlap fee: the tau marginal was calculated exactly. Neither rho<=nu nor nu<=rho is used. Zero-mass packets cause no problem.

## 4. Disjoint original branch accounting

Let P_cur already contain every previously unpaid mask, including the R284 heavy allocation if applicable. Define

L_N=1{N(y)<=q_-a_xi^n/kappa_xi},
L_M=1{M(z)<=4lambda a_xi^n/kappa_xi}.

Split the ACTUAL current positive integrand by the exact identity

1=L_N+(1-L_N)L_M+(1-L_N)(1-L_M).

The first part is paid by r285_joint.md. For the second keep (1-L_N)L_M and every original mask on the left. Drop (1-L_N) and other positive masks only in its upper estimate. Apply the full posterior score bound with explicit 1{R2(y,v)<=D} BEFORE changing xi=c_jt/b. The new gates depend on original y,z,clock but not auxiliary slots v,u. The physical lower-scale gate E_xi and unique j remain until justified; no posterior independence after substitution is assumed.

Thus the SECOND part has price

P_second <=(32Lambda/3) B_D [W_rho+(1+log B)W_nu].

Together the two new, disjoint branches cost at most

P_first+P_second <=(38Lambda/3)B_D[W_rho+(1+log B)W_nu]
 <=(152Lambda/3)sqrt(nD)[W_rho+(1+log B)W_nu].

Sum the actual original disjoint terminal source ledgers once. If D depends on outer data, keep both B_D and B inside that original weighted sum unless a common bound is proved. This is sqrt(n) times polylog for the existing common D=O(log n), with no grid factor.

The remaining original current integrand is EXACTLY restricted by BOTH

nu(B_1(y,r))>q_-a_xi^n/kappa_xi,
rho(B_1(z,r))>4lambda a_xi^n/kappa_xi.

These are source-mass lower bounds, not lower bounds on the captured responses at the receiver. Both dense branches may carry the whole remaining traffic. No payment of that jointly dense branch is proved here. Source capacity or geometric covering for it remains necessary; the present allocations do not turn local weak-L1 bounds into a free sum theorem.

## 5. Evidence boundary

The argument is analytic. The reciprocal-degree identity in this direction can be tested by transposing the finite geometric graph in r285_numeric.json. Such finite exact tests and scalar I checks are not a continuous/FULL proof. No PDF, repository edit, replacement posterior or signed credit is involved.
