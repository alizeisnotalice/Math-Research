from fractions import Fraction as Q
import math
Y=[Q(0),Q(1,8),Q(1,4),Q(1,2),Q(2)]
Z=[Q(0),Q(1,4),Q(1,2),Q(3,4)]
r=Q(1,4)
rho=[Q(k,28) for k in (2,3,5,7,11)]
nu=[Q(k,15) for k in (1,2,4,8)]
edge=[[abs(y-z)<=r for y in Y] for z in Z]
N=[sum((nu[j] for j in range(len(Z)) if edge[j][i]),Q(0))
   for i in range(len(Y))]
sigma=[[rho[i]/N[i] if edge[j][i] and N[i]>0 else Q(0)
        for i in range(len(Y))] for j in range(len(Z))]
marginal_checks=0
for i in range(len(Y)):
    assert sum((nu[j]*sigma[j][i] for j in range(len(Z))),Q(0)) == \
           (rho[i] if N[i]>0 else 0)
    marginal_checks+=1
allocated=sum((nu[j]*sum(sigma[j],Q(0)) for j in range(len(Z))),Q(0))
assert allocated<=sum(rho,Q(0))
comparison_checks=0
for threshold in (Q(0),Q(1,15),Q(1,5),Q(1,3),Q(1)):
    for kernel in ([Q(1)]*5,[Q(k,7) for k in (0,1,2,3,4)],
                   [Q(k,11) for k in (13,0,5,1,7)]):
        for j in range(len(Z)):
            F=sum((rho[i]*kernel[i] for i in range(len(Y))
                   if edge[j][i] and N[i]<=threshold),Q(0))
            bound=threshold*sum((sigma[j][i]*kernel[i]
                                 for i in range(len(Y))),Q(0))
            assert F<=bound
            comparison_checks+=1
def I(x,y):
    if min(x,y)==0:return 0.
    return min(x,y)*(2.+math.log(max(x,y)/min(x,y)))
amplification_checks=0
for x in (0.,1e-5,.1,1.,17.):
    for y in (0.,1e-5,.1,1.,17.):
        for B in (1.,1.1,2.,100.,1e8):
            lhs=I(B*x,y);rhs=x+(1.+math.log(B))*y
            assert lhs<=rhs+1e-12*max(1.,lhs,rhs)
            amplification_checks+=1
print('PASS exact_marginal_checks=',marginal_checks,
      'exact_low_gate_checks=',comparison_checks,
      'floating_I_amplification_checks=',amplification_checks)
print('neighbor_masses=',list(map(str,N)),
      'allocated_rho_mass=',str(allocated),
      'original_rho_mass=',str(sum(rho,Q(0))))
print('Finite algebra diagnostics only; not an original L1-history model or interval certificate.')
