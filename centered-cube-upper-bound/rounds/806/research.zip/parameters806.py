"""Exact algebra and outward-rounded scalar diagnostics for the two price covers."""
import argparse
from fractions import Fraction as Q
from itertools import product
import json
from pathlib import Path
import platform

import flint
import sympy as sp
from flint import arb


def algebra():
    h, x = sp.symbols("h x", positive=True)
    # Uniform coordinate with x >= h+1, including the clipping correction.
    mean_piece = ((h - 1 + x)**2 - (x - h - 1)**2) / (4*h)
    assert sp.simplify(mean_piece - (x - 1)) == 0
    chord_loss = arb(1)/6 - ((arb(5)/3).exp()-1)/(5*128) - arb(1)/8
    assert chord_loss > 0
    return dict(tail_mean_identity=str(sp.simplify(mean_piece)),
                mgf_margin_lower=str(chord_loss.lower()))


def square(groups):
    volume = edge = rectangle = Q(0)
    for outer, left, right, table in groups:
        lw, rw = sum(left), sum(right)
        volume += outer * lw * rw
        edge += outer * sum(w*v*table[i][j] for i,w in enumerate(left)
                            for j,v in enumerate(right))
        # Normalize both conditional measures at each price, then restore its true weight.
        g = sum(w*w1*v*v1*table[i][j]*table[k][j]*table[k][l]*table[i][l]
                for i,w in enumerate(left) for k,w1 in enumerate(left)
                for j,v in enumerate(right) for l,v1 in enumerate(right))
        rectangle += outer * g / (lw*rw)
    assert volume**3 * rectangle >= edge**4
    return dict(W=str(volume), edge=str(edge), rectangle=str(rectangle),
                normalized_Jensen_gap=str(volume**3*rectangle-edge**4))


def finite():
    groups = [(Q(7,10), [Q(1,27),Q(2,9)], [Q(1,50),Q(3,8)],
               [[Q(1),Q(0)],[Q(0),Q(4,7)]]),
              (Q(11,13), [Q(1,8),Q(1,2)], [Q(3,20),Q(1,16),Q(8,9)],
               [[Q(2,5),Q(3,4),Q(1,5)],[Q(1,13),Q(1),Q(0)]])]
    out = [square(groups[:1]), square(groups), square(groups*3)]
    # An exact audit of the coordinate quantizer and its support-count exponent.
    widths = []
    for dimension, mesh_units, budget in [(2,2,4),(3,3,5),(4,2,6)]:
        sites = set()
        inputs = 0
        for v in product(range(-budget,budget+1), repeat=dimension):
            if sum(map(abs,v)) > budget:
                continue
            q = tuple((1 if a>=0 else -1)*(abs(a)//mesh_units) for a in v)
            assert max(abs(a-b*mesh_units) for a,b in zip(v,q)) < mesh_units
            assert sum(map(abs,q)) <= budget//mesh_units
            sites.add(q)
            inputs += 1
        bound=(2*dimension+1)**(budget//mesh_units)
        assert len(sites) <= bound
        widths.append([dimension,mesh_units,budget,inputs,len(sites),bound])
    return dict(normalization=out, quantization=widths)


def scalar(log_n_2):
    n = arb(2)**log_n_2
    ell = (n+2).log()
    r0 = n.sqrt()*ell**2
    r1 = r0+1
    omega_min = r0**2/(8192**2*n)
    xi_min = ((r0/(16384*ell)-1)*omega_min).sqrt()
    xi_max = ((r1/(16384*ell))*(r1**2/(8192**2*n))).sqrt()
    J = n.sqrt()*ell**8
    smin, smax=J-arb(2).log(), (n+1)*arb(2).log()
    if not smin < smax:
        assert smin > smax
        return dict(n_power=log_n_2, feasible=False)
    logarithm2=arb(2).log()
    def audit(y):
        return dict(sign="negative" if y < 0 else "positive" if y > 0 else "undecided",
                    interval=y.str(12))
    # All log diagnostics include the displayed N^8 allowance when present.
    # It is a finite scalar stress test, not an estimate for unspecified constants.
    c=arb(1)/16384
    outputs=dict(n_power=log_n_2,feasible=True)
    outputs["two_sided"]={
        "early_deletion_log":audit(8*ell -omega_min/8),
        "near_dictionary_log":audit(8*ell+r1/32768+2*c*xi_max-r0/8192),
        "far_gram_log_margin":audit(8*ell+2*c*xi_max-xi_min/768),
        "projection_vs_common_codegree_log":audit(2*ell**2+2*logarithm2-c*xi_min),
    }
    outputs["mass_ratio"]=[]
    for s in (smin,(smin*smax).sqrt(),smax):
        delta=s/(128*n)
        radius=s*s/(2**18*n*ell)
        net=radius/delta*(2*n+1).log()
        metrics=dict(s=s.str(12),radius=radius.str(12),
                     cover_log=audit(8*ell+net+4*n*delta+s/8+2*c*radius-s),
                     far_gram_log=audit(8*ell+2*c*radius-radius/3),
                     projection_log=audit(2*ell**2+2*logarithm2-c*radius))
        outputs["mass_ratio"].append(metrics)
    return outputs


def render():
    flint.ctx.prec=512
    data=dict(python=platform.python_version(),flint=flint.__version__,
              sympy=sp.__version__,architecture=platform.machine(),
              precision=flint.ctx.prec,algebra=algebra(),finite=finite(),
              scalar=[scalar(q) for q in [32,128,512,2048,8192,32768]])
    return json.dumps(data,ensure_ascii=False,sort_keys=True,indent=2)+"\n"


if __name__ == "__main__":
    p=argparse.ArgumentParser()
    p.add_argument("--check",type=Path)
    args=p.parse_args()
    actual=render()
    if args.check:
        assert args.check.read_text()==actual
        print("exact replay and Arb intervals match")
    else:
        print(actual,end="")
