#!/usr/bin/env python3
"""Exact exterior-source reversal and one-scale owner packing in real boxes."""
import argparse
from collections import defaultdict
from fractions import Fraction as F
from itertools import product
import json
from math import ceil, floor, prod
from pathlib import Path
import platform


SUPPORT = F(8)
HALO = F(65, 64)
PERIOD = F(1, 2)
HALF_PERIOD = PERIOD / 2


def total(values):
    return sum(values, F(0))


def cube(c, radius):
    return tuple((x - radius, x + radius) for x in c)


def center(box):
    return tuple((a + b) / 2 for a, b in box)


def clip(A, B):
    return tuple((max(a, c), min(b, d)) for (a, b), (c, d) in zip(A, B))


def volume(box):
    return prod(max(F(0), b - a) for a, b in box)


def inside(A, B):
    return all(c <= a < b <= d for (a, b), (c, d) in zip(A, B))


def phase_primitive(x):
    phase = x % PERIOD
    return min(phase, PERIOD - phase)


def source_mass(box, amplitude, decompose=False):
    bounded = clip(box, ((-SUPPORT, SUPPORT),) * len(box))
    if not volume(bounded):
        return F(0)
    a, b = bounded[0]
    if decompose:
        mass = total((1 + amplitude * (-1)**(j % 2)) *
                     max(F(0), min(b, (j + 1)*HALF_PERIOD) - max(a, j*HALF_PERIOD))
                     for j in range(floor(a/HALF_PERIOD), ceil(b/HALF_PERIOD)))
    else:
        mass = b - a + amplitude * (phase_primitive(b) - phase_primitive(a))
    return mass * volume(bounded[1:])


def two_halves(box):
    a, b = box[0]
    mid = (a + b) / 2
    return (((a, mid),) + box[1:], ((mid, b),) + box[1:])


def exterior(pocket, halo):
    assert all(c <= a < b <= d for (a, b), (c, d) in zip(pocket[1:], halo[1:]))
    a, b = pocket[0]
    c, d = halo[0]
    return [((x, y),) + pocket[1:]
            for x, y in ((a, min(b, c)), (max(a, d), b)) if x < y]


def retain(stage, t, left, right):
    u, z, U, _ = left
    g, q, V, _ = right
    if stage == 'initial':
        return True
    if stage == 'pressure':
        return U == V
    return z != q or (U == V and (u+g+t) % 3 != 1)


def true_arm_flux(stage, middles, smalls, mu):
    small_half_owners = [two_halves(u['owner']) for u in smalls]
    rows = []
    degrees = []
    for t, T in enumerate(middles):
        m_t, j_t = T['m'], T['j']
        old = []
        types = []
        for u, U in enumerate(smalls):
            m_u, j_u = U['m'], U['j']
            overlap = clip(T['A'], U['A'])
            x = mu(overlap)
            q = x / m_u
            pocket = exterior(U['G'], T['hat'])
            a = total(mu(C) for C in pocket)
            K = q / m_t
            base_flux = (j_t / m_t) * q * j_u
            assert 0 <= q <= 1 and x == mu(overlap, decompose=True)
            if x:
                assert a > 0 and U['s'] < T['s']
                for z, Z in enumerate(two_halves(overlap)):
                    for r, R in enumerate(small_half_owners[u]):
                        w = j_u * K * mu(Z)/x * volume(R)/U['v']
                        assert w == j_u/U['v'] * mu(Z) * volume(R)/(m_t*m_u)
                        old.append((u, z, r, w))
            types.append(dict(t=t, u=u, q_true=q, q_lebesgue=volume(overlap)/m_u,
                              true_mu_intersection=x, external=pocket, true_mu_external=a,
                              external_fraction=a/m_u, base_flux=base_flux,
                              fraction_in_forbidden_halo=mu(clip(U['A'], T['hat']))/m_u,
                              full_d_minus_factor=None, retained_true_flux=F(0)))
        d_minus = total(U['j'] * row['q_true'] / m_t for U, row in zip(smalls, types))
        extra = {str(v): T1['j'] * mu(clip(T['A'], T1['A'])) / (m_t*T1['m'])
                 for v, T1 in enumerate(middles) if v != t}
        d = d_minus + total(extra.values())
        assert total(leg[3] for leg in old) == d_minus and d > 0
        full, kept = [F(0)]*len(smalls), [F(0)]*len(smalls)
        count = 0
        for left, right in product(old, repeat=2):
            u = left[0]
            w = j_t * left[3] * right[3] / d
            full[u] += w
            if retain(stage, t, left, right):
                kept[u] += w
                count += 1
        for u, row in enumerate(types):
            q, a = row['q_true'], row['true_mu_external']
            assert full[u] == d_minus/d * row['base_flux']
            assert 0 <= kept[u] <= full[u] <= row['base_flux']
            assert (kept[u] > 0) == (q > 0)
            row.update(full_d_minus_factor=d_minus/d, ungated_true_flux=full[u],
                       retained_true_flux=kept[u], true_external_density=(kept[u]/a if a else F(0)),
                       ungated_external_density=(full[u]/a if a else F(0)),
                       removed_leg_upper_density=(row['base_flux']/a if a else F(0)))
        assert sum(full) == j_t * d_minus**2 / d
        rows.extend(types)
        degrees.append(dict(t=t, d_minus=d_minus, d_original=d,
                            nonold_degree_by_actual_center=extra, retained_full_path_cells=count))
    return rows, degrees


def source_membership_atoms(rows, n, mu):
    pieces = [(i, B) for i, row in enumerate(rows) if row['retained_true_flux'] for B in row['external']]
    by_axis = []
    for d in range(n):
        cuts = sorted({-SUPPORT, SUPPORT, *(x for _, B in pieces for x in B[d])})
        by_axis.append([(a, b, sum(1<<k for k, (_, B) in enumerate(pieces) if B[d][0] <= a < b <= B[d][1]))
                        for a, b in zip(cuts, cuts[1:])])
    masses = defaultdict(F)
    representative = {}
    members_by_piece_mask = {}
    for coordinates in product(*by_axis):
        mask = (1<<len(pieces))-1
        for _, _, axis_mask in coordinates:
            mask &= axis_mask
        if mask not in members_by_piece_mask:
            members_by_piece_mask[mask] = tuple(sorted({i for k, (i, _) in enumerate(pieces) if (mask>>k)&1}))
        members = members_by_piece_mask[mask]
        B = tuple((a, b) for a, b, _ in coordinates)
        weights = mu(B)
        masses[members] += weights
        representative.setdefault(members, B)
    assert total(masses.values()) == (2*SUPPORT)**n
    for i, row in enumerate(rows):
        if row['retained_true_flux']:
            assert total(w for indices, w in masses.items() if i in indices) == row['true_mu_external']
    return sorted(masses.items()), representative


def reversible_bipartite(rows, centres, atoms, representatives):
    def normalized(line, mass):
        return [x/mass if mass else F(0) for x in line]

    Y = len(atoms)
    joint = [[F(0)]*centres for _ in range(Y)]
    for a, (indices, w) in enumerate(atoms):
        for i in indices:
            row = rows[i]
            joint[a][row['t']] += w*row['true_external_density']
    source = [total(row) for row in joint]
    mids = [total(row[t] for row in joint) for t in range(centres)]
    M = total(mids)
    assert 0 < M == total(source) == total(row['retained_true_flux'] for row in rows)
    assert all(mids[t] == total(row['retained_true_flux'] for row in rows if row['t'] == t)
               for t in range(centres))
    reverse = [normalized([row[t] for row in joint], mids[t]) for t in range(centres)]
    forward = [normalized(row, source[a]) for a, row in enumerate(joint)]
    assert all(total(p) == int(mass>0) for p, mass in zip(forward, source))
    assert all(total(p) == int(mass>0) for p, mass in zip(reverse, mids))
    for a, t in product(range(Y), range(centres)):
        assert source[a]*forward[a][t] == mids[t]*reverse[t][a] == joint[a][t]

    def two_step(first, second, mass, opposite, raw):
        n0, n1 = len(mass), len(opposite)
        result = [[total(first[i][k]*second[k][j] for k in range(n1))
                   for j in range(n0)] for i in range(n0)]
        for i, j in product(range(n0), repeat=2):
            direct = total(raw[i][k]*raw[j][k]/opposite[k] for k in range(n1) if opposite[k])
            assert mass[i]*result[i][j] == direct == mass[j]*result[j][i]
        for i in range(n0):
            assert total(result[i]) == int(mass[i]>0)
            assert total(mass[j]*result[j][i] for j in range(n0)) == mass[i]
        return result

    by_mid = two_step(reverse, forward, mids, source, list(map(list, zip(*joint))))
    two_step(forward, reverse, source, mids, joint)
    shared_switch = total(mids[t]*by_mid[t][v] for t, v in product(range(centres), repeat=2) if t!=v)/M
    independent_switch = 1 - total((m/M)**2 for m in mids)
    assert 0 < shared_switch < independent_switch
    a = max(range(Y), key=lambda a: (sum(x>0 for x in joint[a]), source[a]))
    assert sum(x>0 for x in joint[a]) >= 2
    return dict(source_atoms=[dict(active_types=I, actual_mu=mass, representative_cell=representatives[I])
                              for I, mass in atoms], actual_mu_joint=joint, source_marginal=source,
                central_marginal=mids, source_then_center=forward, center_then_source=reverse,
                central_two_steps=by_mid, true_center_switch_probability=shared_switch,
                wrong_unconditional_independent_center_switch=independent_switch,
                witness_source_atom_index=a, witnessed_central_posterior=forward[a],
                zero_entries_in_joint=sum(x==0 for row in joint for x in row),
                zero_center_rows=sum(m==0 for m in mids), total_retained=M)


def fine_rows(rows, middles, smalls, n, D, step, shift, amp, mu):
    bounding = [tuple(C[d] for row in rows if row['retained_true_flux'] for C in row['external']) for d in range(n)]
    axes = []
    for coords in bounding:
        lo = floor((min(a for a, _ in coords)-shift)/step)
        hi = ceil((max(b for _, b in coords)-shift)/step)
        axes.append([(shift+i*step, shift+(i+1)*step) for i in range(lo, hi)])
    minimum_fraction = min(r['external_fraction'] for r in rows if r['retained_true_flux'])
    h = 1 + F(1, 32*n)
    actual_R = max(U['s'] for U in smalls)
    dyadic_upper = (F(2), F(3, 2), F(4, 3))[n-1]
    assert (2*actual_R)**n <= 2*D <= (2*dyadic_upper)**n and (2*n*step)**n <= 2*D
    outer = h*actual_R + step/2
    dyadic_outer = h*dyadic_upper + step/2
    actual = [F(0)]*len(rows)
    upper = actual.copy()
    covered_source, active_count = F(0), 0
    min_cell_density, max_cell_density, max_outer_density = None, F(0), F(0)
    max_owner_fraction, witness = F(0), None
    for C in product(*axes):
        by_t = defaultdict(list)
        for i, row in enumerate(rows):
            if not row['retained_true_flux']:
                continue
            mass = total(mu(clip(C, B)) for B in row['external'])
            if mass:
                by_t[row['t']].append((i, mass))
        if not by_t:
            continue
        w = mu(C)
        rho = w / volume(C)
        outer_box = cube(center(C), outer)
        outer_density = mu(outer_box) / volume(outer_box)
        assert 0 < rho <= 1 + amp and 0 < outer_density <= 1 + amp
        assert outer_box == clip(outer_box, cube(center(C), dyadic_outer))
        covered_source += w
        active_count += 1
        min_cell_density = min(min_cell_density, rho) if min_cell_density is not None else rho
        max_cell_density = max(max_cell_density, rho)
        max_outer_density = max(max_outer_density, outer_density)
        for t, entries in by_t.items():
            U_list = [smalls[rows[i]['u']] for i, _ in entries]
            assert all(inside(U['owner'], outer_box) for U in U_list)
            delivered = total(U['v'] for U in U_list)
            owner_weight = total(U['j'] for U in U_list)
            assert owner_weight <= delivered <= volume(outer_box)
            if owner_weight/volume(outer_box) > max_owner_fraction:
                max_owner_fraction = owner_weight/volume(outer_box)
                witness = dict(t=t, C=C, contained_owners=[rows[i]['u'] for i, _ in entries],
                               true_owner_weight=owner_weight, owner_union_lebesgue=delivered,
                               outer_lebesgue=volume(outer_box), true_outer_mu=mu(outer_box))
            cap = middles[t]['j']/middles[t]['m'] * volume(outer_box)*w/(minimum_fraction*D)
            assert total(rows[i]['removed_leg_upper_density']*m for i, m in entries) <= cap
            for i, m in entries:
                actual[i] += rows[i]['true_external_density']*m
                upper[i] += rows[i]['removed_leg_upper_density']*m
    assert actual == [row['retained_true_flux'] for row in rows]
    assert upper == [row['base_flux'] for row in rows]
    assert min_cell_density and witness
    return dict(fine_edge=step, grid_shift=shift, owner_size_bin_D=D, true_active_grid_boxes=active_count,
                listed_max_s=actual_R, rational_upper_for_dyadic_top=dyadic_upper, h=h,
                exact_outer_radius=outer, conservative_dyadic_outer_radius=dyadic_outer,
                external_fraction_minimum=minimum_fraction, maximum_density_globally=1+amp,
                grid_cell_masses_covered=covered_source, actual_grid_density_range=[min_cell_density,max_cell_density],
                maximum_measured_outer_density=max_outer_density, maximal_owner_over_outer_fraction=max_owner_fraction,
                true_grid_flux=total(actual), pre_gate_grid_flux_upper_bound=total(upper),
                coactive_owner_packing_witness=witness)


def diagnostic(stage,n,T_specs,U_specs,amp,step,shift):
    def make(spec):
        x, s, share, pocket_scale = map(F, spec)
        c = (x,) + (F(0),)*(n-1)
        A, E = cube(c,s), cube(c,s/(32*n))
        return dict(c=c, s=s, A=A, m=volume(A), owner=E, v=volume(E), j=share*volume(E),
                    G=cube(c,pocket_scale*s), hat=cube(c,HALO*s))

    mu = lambda box, **kw:source_mass(box,amp,**kw)
    middles = list(map(make, T_specs))
    smalls = list(map(make, U_specs))
    parents = middles + smalls
    D = 2**n
    assert all(U['m'] == mu(U['A']) == mu(U['A'],decompose=True) and 0<U['j']<=U['v'] for U in parents)
    assert all(inside(U['G'],U['A']) and F(1)<=U['s']<2 for U in parents)
    assert all(volume(clip(T['owner'],U['owner']))==0 for i,T in enumerate(parents) for U in parents[i+1:])
    assert all(D <= U['m'] < 2*D for U in smalls)
    rows,degrees = true_arm_flux(stage,middles,smalls,mu)
    atoms,reps = source_membership_atoms(rows,n,mu)
    chain = reversible_bipartite(rows,len(middles),atoms,reps)
    observed = chain['total_retained']
    base_flux = total(row['base_flux'] for row in rows)
    no_gate = total(row['ungated_true_flux'] for row in rows)
    if stage=='initial':
        assert observed == no_gate == base_flux
    else:
        assert 0 < observed < no_gate < base_flux
    assert any(r['q_true'] != r['q_lebesgue'] for r in rows)
    wrong_ext = total(r['retained_true_flux']*r['external_fraction'] for r in rows)
    assert 0<wrong_ext<observed
    grid = fine_rows(rows,middles,smalls,n,D,step,shift,amp,mu)
    assert grid['true_grid_flux']==observed and grid['pre_gate_grid_flux_upper_bound']==base_flux
    union = total(mass for mask,mass in atoms if mask)
    repeated = total(row['true_mu_external'] for row in rows if row['retained_true_flux'])
    assert union < repeated and union <= grid['grid_cell_masses_covered']
    return dict(stage=stage, n=n, true_source_amplitude=amp, middle_cubes=middles, small_cubes=smalls,
                true_physical_degrees=degrees, by_t_u=rows, total_supported_original_mass=observed,
                ungated_true_total=no_gate, base_b_t_q_b_u_total=base_flux,
                total_if_wrong_source_denominator_is_m_u=wrong_ext, physical_exterior_union_mu=union,
                sum_of_physical_exterior_mu_by_pair=repeated, fine_source_cover=grid,
                diagnostic_max_halo_overlap_fraction=max(r['fraction_in_forbidden_halo'] for r in rows if r['q_true']),
                diagnostic_min_G_over_m=min(mu(U['G'])/U['m'] for U in smalls), alternation=chain)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    action = parser.add_mutually_exclusive_group()
    action.add_argument('--output',type=Path)
    action.add_argument('--check',type=Path)
    args = parser.parse_args()
    middles = [('7/4','13/8',1,1),(-2,'13/8','3/4',1),('9/4','13/8','1/2',1),
               ('-5/2','13/8','7/8',1),('3/2','11/8','5/8',1),('19/4','11/8','3/4',1)]
    smalls = [('-1/4',1,1,'31/32'),('1/4','9/8','7/8','31/32'),
              ('-3/4',1,'3/4','29/32'),(1,'9/8','1/2','31/32'),(0,1,'5/8','15/16')]
    stages = [diagnostic('initial',1,middles[:2],smalls[:2],F(1,4),F(1),F(0)),
              diagnostic('pressure',2,middles[:3],smalls[:4],F(63,64),F(1,4),F(1,64)),
              diagnostic('expanded',3,middles,smalls,F(3,4),F(1,3),F(-1,12))]
    data = dict(runtime=dict(python=platform.python_version(),architecture=platform.machine(),arithmetic='Fraction exact'),
                reproduction='python -B reverse805.py --check reverse805.json',
                scope=dict(source='Density 1 plus or minus the stage amplitude on alternate quarter intervals of the first axis, uniform on other axes, and zero outside [-8,8]^n.',
                    physical='Real axis-parallel cubes in one physical octave, true mu(A_i)=m_i=Leb(A_i), pairwise disjoint actual owners in the 1/(32n) cores, j_i<=Leb(E_i), and one genuine small dyadic volume bin.',
                    original='One physical middle history per label. Degree includes all old limbs and all positive central-to-central intersections. Original two arms retain their own true price cells and uniform Lebesgue owner halves.',
                    atom='Finite diagnostic acceptance: all paths in initial, equal owner halves in pressure, and different actual price halves or selected equal owner halves in expanded.',
                    exterior='Exact permitted G_u minus the (65/64) homologous enlarged A_t, elementary finite replacement of the asymptotic halo. Real true-outer-mass denominator for every positive original type.',
                    formula='b_t=j_t/m_t, b_u=j_u, q=mu(A_t intersect A_u)/m_u. Ungated two-arm exterior density on its support is (d_minus/d_v)b_t q b_u/mu(exterior). Full-path mask only decreases it.',
                    cap='Fine source cubes of side at most 1/n, true owner packing in a checked cube of radius h*s_max+step/2. Absolute source density 1+amplitude provides the outer-radius cube average bound.',
                    limits='A finite real model with stated diagnostic gates and source halo. Full hard high-dimensional cut, the large volume jump, first passage global maximal selection and asymptotic exterior small-loss hypotheses are not assumed.'),
                stages=stages)
    text = json.dumps(data,sort_keys=True,indent=2,default=str)+'\n'
    if args.output:
        args.output.write_text(text)
    if args.check:
        assert args.check.read_text()==text
    if args.output or args.check:
        for s in stages:
            p=s['alternation']
            print(s['stage'], 'actual / ungated / bqb',s['total_supported_original_mass'],
                  s['ungated_true_total'],s['base_b_t_q_b_u_total'],
                  'fine grid cells',s['fine_source_cover']['true_active_grid_boxes'],
                  'same-source switch (display decimal)',format(float(p['true_center_switch_probability']),'.8f'),
                  'zero central rows',p['zero_center_rows'])
        if args.check:
            print('byte-identical')
    else:
        print(text,end='')


if __name__=='__main__':
    main()
