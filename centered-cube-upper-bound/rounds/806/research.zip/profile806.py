#!/usr/bin/env python3
"""True z profiles, their Hellinger Gram matrices and common projections."""
import argparse
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
from itertools import combinations
import json
from pathlib import Path
import platform
import subprocess
import sys

import flint
from flint import arb, ctx

import rectangle806 as rect


DEPENDENCIES = dict(rect.DEPENDENCIES,
    **{'rectangle806.py': '04714603e8dfbc8b7fe6f1f9e431c4fd8cf9c3b671e567e34bd5315244c576be'})
total = rect.total


def truth_box_point(box):
    coordinates = [(a+b)/2 for a,b in box]
    a,b = box[0]
    # Avoid the quarter-step boundaries of the actual price density.
    if (4*coordinates[0]).denominator==1:
        coordinates[0] = next(a+(b-a)/k for k in range(3,65) if (4*(a+(b-a)/k)).denominator!=1)
    assert all(a<x<b for x,(a,b) in zip(coordinates,box))
    return coordinates


def original_row_profiles(stage, model, old):
    fibres,marks,_ = old.reconstruct(stage)
    amplitude = F(stage['true_source_amplitude'])
    mu = lambda B:model.source_mass(B,amplitude)
    T,U = stage['middle_cubes'],stage['small_cubes']
    small_D = rect.dyadic_lower(F(U[0]['m']))
    middle_D = [rect.dyadic_lower(F(t['m'])) for t in T]
    assert all(rect.dyadic_lower(F(u['m']))==small_D for u in U)
    by_tu = {(r['t'],r['u']): r for r in stage['by_t_u']}
    y_sources = defaultdict(F)
    y_reps = {}
    for Y in stage['alternation']['source_atoms']:
        allowed = defaultdict(list)
        for i in Y['active_types']:
            r = stage['by_t_u'][i]
            allowed[r['u']].append(r['t'])
        for u,ts in allowed.items():
            key = u,tuple(sorted(ts))
            y_sources[key] += F(Y['actual_mu'])
            y_reps.setdefault(key,old.box(Y['representative_cell']))

    z_boxes = {}
    forward = defaultdict(F)
    reverse = defaultdict(lambda:defaultdict(dict))
    left_reference = {}
    for t,frame in enumerate(fibres):
        j_t,m_t = F(T[t]['j']),F(T[t]['m'])
        d_t = F(stage['true_physical_degrees'][t]['d_original'])
        for b,edges in frame.items():
            g,q,W = b
            B = marks[t][b]
            lam = mu(B['price'])*model.volume(B['owner'])
            x = (0,t,g,q,W)
            left_reference[x] = lam
            for (u,z,r),w in edges.items():
                A = marks[t][u,z,r]
                z_mass = mu(A['price'])
                z_key = t,u,z
                z_boxes[z_key] = A['price']
                a_mass = F(by_tu[t,u]['true_mu_external'])
                owner_mass = model.volume(A['owner'])
                h = (j_t/d_t)*F(U[u]['j'])/F(U[u]['v'])/(m_t*F(U[u]['m']))
                h *= (F(U[g]['j'])/F(U[g]['v']))/(m_t*F(U[g]['m']))/a_mass
                assert 0 < h <= 1 and w == h*z_mass*lam*owner_mass*a_mass
                forward[t,u,z,r] += 2*lam*h
                yy = total(v for (u1,ts),v in y_sources.items() if u1==u and t in ts)
                assert yy == a_mass
                reverse[x][z_key][r] = yy*owner_mass*h
    z_keys = sorted(z_boxes)
    z_inputs = [dict(retained_true_flux=1,external=[z_boxes[k]],true_mu_external=mu(z_boxes[k])) for k in z_keys]
    atoms,reps = model.source_membership_atoms(z_inputs,stage['n'],mu)
    z_profiles = []
    for label,(indices,w) in enumerate(atoms):
        keys = [z_keys[i] for i in indices]
        if not keys:
            continue
        assert len(keys)==len({(t,u) for t,u,z in keys})
        z_profiles.append((label,keys,w,reps[indices]))

    def profile(weighted):
        result=[]
        for name,w,box,value in weighted:
            row_mass = total(value.values())
            if row_mass:
                local=mu(box)
                assert 0<local<=w
                result.append(dict(z_id=name,z_pattern_true_mu=w,z_actual_box=box,
                                   z_actual_representative_box_mu=local,
                                   true_z_density=row_mass,unscaled_weight=w*row_mass,
                                   posterior={k:v/row_mass for k,v in sorted(value.items()) if v}))
        mass = total(r['unscaled_weight'] for r in result)
        for r in result:
            r['true_z_probability'] = r['unscaled_weight']/mass
            r['true_representative_box_probability'] = r['z_actual_representative_box_mu']*r['true_z_density']/mass
        return result,mass

    forward_profiles, reverse_profiles = [],[]
    forward_mass,reverse_mass = F(0),F(0)
    for (u,ts),y_weight in sorted(y_sources.items()):
        for M in sorted({middle_D[t] for t in ts}):
            selected = [t for t in ts if middle_D[t]==M]
            for r,owner in enumerate(model.two_halves(old.box(U[u]['owner']))):
                weighted = ((name,w,box,{t:forward[t,u,z,r] for t,u1,z in keys if u1==u and t in selected})
                            for name,keys,w,box in z_profiles)
                rows,mass = profile(weighted)
                if mass:
                    y = y_reps[u,ts]
                    for t in selected:
                        assert model.volume(model.clip(y,old.box(T[t]['hat'])))==0
                    assert model.inside(y,old.box(U[u]['G']))
                    ref = y_weight*model.volume(owner)
                    forward_mass += ref*mass
                    forward_profiles.append(dict(anchor=dict(u=u,actual_U_point=model.center(owner),
                        U_subbox=owner,actual_y_point=truth_box_point(y),y_subbox=y,full_y_middle_mask=ts,central_bin=M,
                        right_reference_mass=ref,unscaled_true_price_mass=mass), rows=rows))
    for x,Z in sorted(reverse.items()):
        _,t,g,q,W = x
        B = marks[t][g,q,W]
        weighted = ((name,w,box,{u:total(Z.get((t,u,z),{}).values()) for v,u,z in keys if v==t})
                    for name,keys,w,box in z_profiles)
        rows,mass = profile(weighted)
        if mass:
            reverse_mass += mass*left_reference[x]
            reverse_profiles.append(dict(anchor=dict(x=x,physical_q_subbox=B['price'],actual_q_point=truth_box_point(B['price']),
                physical_W_subbox=B['owner'],actual_W_point=model.center(B['owner']),small_bin=small_D,
                left_reference_mass=left_reference[x],unscaled_true_price_mass=mass), rows=rows))
    observed = F(stage['total_supported_original_mass'])
    assert forward_mass == 2*reverse_mass == 2*observed
    return forward_profiles, reverse_profiles, dict(number_of_actual_disjoint_z_profiles=len(z_profiles),
        fixed_right_integrates_to_two_original_orientations=forward_mass,
        fixed_left_integrates_to_one_original_orientation=reverse_mass)


def classify(rows):
    changed_support,disjoint,partial,nonconstant = None,None,None,None
    for i,j in combinations(range(len(rows)),2):
        p,q = rows[i]['posterior'],rows[j]['posterior']
        if p!=q and nonconstant is None:
            nonconstant = (i,j)
        if p.keys()!=q.keys() and changed_support is None:
            changed_support = (i,j)
        if not p.keys() & q.keys() and disjoint is None:
            disjoint = (i,j)
        if p.keys() & q.keys() and p!=q and partial is None:
            partial = (i,j)
    return dict(nonconstant=nonconstant,changed_support=changed_support,disjoint=disjoint,partial=partial)


def to_arb(x):
    return arb(x.numerator)/x.denominator


def arb_sum(xs):
    return sum(xs,arb(0))


def dot(x,y):
    return arb_sum(a*b for a,b in zip(x,y))


def ball(x):
    return x.str(34)


def hellinger_of_pair(rows, i, j):
    p,q = rows[i]['posterior'],rows[j]['posterior']
    common = p.keys() & q.keys()
    h = arb_sum(to_arb(p[k]*q[k]).sqrt() for k in sorted(common))
    if not common:
        assert h==0
    elif p==q:
        assert (h-1).contains(0)
    else:
        assert 0<h<1
    return h


def gram(rows):
    labels = sorted({u for r in rows for u in r['posterior']})
    weights = [r['true_z_probability'] for r in rows]
    assert total(weights)==1 and all(total(r['posterior'].values())==1 for r in rows)
    # Aggregate equal square-root rows after their actual, disjoint prices are paid.
    grouped = defaultdict(F)
    for w,r in zip(weights,rows):
        grouped[tuple(r['posterior'].get(t,F(0)) for t in labels)] += w
    p,w = list(grouped),list(grouped.values())
    N,m = len(w),len(labels)
    X = [[to_arb(w[i]*p[i][j]).sqrt() for j in range(m)] for i in range(N)]
    XT = list(map(tuple,zip(*X)))
    G = [[dot(x,y) for y in X] for x in X]
    C = [[dot(x,y) for y in XT] for x in XT]
    traceG = arb_sum(G[i][i] for i in range(N))
    traceC = arb_sum(C[j][j] for j in range(m))
    QG = arb_sum(x*x for g in G for x in g)
    QC = arb_sum(x*x for c in C for x in c)
    full_X = [[to_arb(wi*r['posterior'].get(t,F(0))).sqrt() for t in labels]
              for wi,r in zip(weights,rows)]
    full_Gram = [[dot(x,y) for y in full_X] for x in full_X]
    Q_full = arb_sum(v*v for g in full_Gram for v in g)
    assert (Q_full-QG).contains(0)
    assert (traceG-1).contains(0) and (traceC-1).contains(0) and (QG-QC).contains(0)
    mixture = [total(wi*pi[j] for wi,pi in zip(w,p)) for j in range(m)]
    u = [to_arb(q).sqrt() for q in mixture]
    P_rows = arb_sum(dot(x,u)**2 for x in X)
    P_cols = dot(u,[dot(v,u) for v in C])
    assert (P_rows-P_cols).contains(0)
    if N>1:
        assert 0<P_rows<1 and 0<QG<1
    else:
        assert (P_rows-1).contains(0) and (QG-1).contains(0)
    exact_pure = None
    if all(sum(x>0 for x in pi)==1 for pi in p):
        exact_pure = total(v*v for v in mixture)
        assert (QG-to_arb(exact_pure)).contains(0) and (P_rows-to_arb(exact_pure)).contains(0)
    common_support = set.intersection(*(set(r['posterior']) for r in rows))
    return dict(actual_label_order=labels,groups=[dict(posterior=v,weight=wi) for v,wi in zip(p,w)],
                mixture_posterior=mixture,common_support=sorted(common_support),
                common_support_coordinate_projection_squared=total(mixture[j] for j,t in enumerate(labels) if t in common_support),
                full_true_price_Gram_dimensions=[len(full_X),len(full_X)],
                Frobenius_squared_by_full_ungrouped_price_Gram_arb=ball(Q_full),
                trace_exact=1,trace_rows_arb=ball(traceG),trace_columns_arb=ball(traceC),
                weighted_row_Hellinger_Gram_arb=[[ball(x) for x in g] for g in G],
                label_Gram_arb=[[ball(x) for x in c] for c in C],
                Frobenius_squared_by_row_arb=ball(QG),Frobenius_squared_by_label_arb=ball(QC),
                mixture_root_projection_squared_by_row_arb=ball(P_rows),
                mixture_root_projection_squared_by_label_arb=ball(P_cols),
                exact_pure_disjoint_labels_frobenius_and_projection=exact_pure)


def profile_witness(p, which):
    rows = p['rows']
    i,j = p['flags'][which]
    return dict(anchor=p['anchor'],real_price_rows=[rows[i],rows[j]],
                Hellinger_affinity_arb=ball(hellinger_of_pair(rows,i,j)))


def report_direction(all_profiles):
    for p in all_profiles:
        p['flags'] = classify(p['rows'])
    flags = ('nonconstant','changed_support','disjoint','partial')
    counts = {k:sum(p['flags'][k] is not None for p in all_profiles) for k in flags}
    # Prefer a real profile with disjoint and partially overlapping sectors.
    def score(p):
        f = p['flags']
        return (f['disjoint'] is not None, f['partial'] is not None,
                f['changed_support'] is not None, len(p['rows']), p['anchor']['unscaled_true_price_mass'])
    selected = max(all_profiles,key=score)
    witnesses = {}
    for k in flags:
        relevant = [p for p in all_profiles if p['flags'][k] is not None]
        if relevant:
            witnesses[k] = profile_witness(max(relevant,key=score),k)
    return dict(positive_anchor_count=len(all_profiles),exact_profile_variation_counts=counts,
                selected_anchor=selected['anchor'],actual_price_rows=selected['rows'],
                genuine_pair_witnesses=witnesses,public_projection_and_Gram=gram(selected['rows']))


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--deps-dir',type=Path,default=Path(__file__).resolve().parent)
    args_group = p.add_mutually_exclusive_group()
    args_group.add_argument('--output',type=Path)
    args_group.add_argument('--check',type=Path)
    args=p.parse_args()
    own = Path(__file__).resolve().parent
    deps = args.deps_dir.resolve()
    for name,sha in DEPENDENCIES.items():
        path = (own if name=='rectangle806.py' else deps)/name
        assert sha256(path.read_bytes()).hexdigest()==sha
    sys.path.insert(0,str(deps))
    import reverse805 as model
    import shared805 as old
    ctx.prec=256
    frozen=json.loads(subprocess.check_output([sys.executable,'-B',str(deps/'reverse805.py')],text=True))
    stages=[]
    for s in frozen['stages']:
        fwd,rev,normalization=original_row_profiles(s,model,old)
        fwd_summary,rev_summary=report_direction(fwd),report_direction(rev)
        stages.append(dict(stage=s['stage'],dimension=s['n'],normalization=normalization,
                           right_fixed_middle_posterior=fwd_summary,left_fixed_small_posterior=rev_summary))
    assert any(s['right_fixed_middle_posterior']['exact_profile_variation_counts']['disjoint'] for s in stages)
    assert any(s['left_fixed_small_posterior']['exact_profile_variation_counts']['partial'] for s in stages)
    out=dict(runtime=dict(python=platform.python_version(),architecture=platform.machine(),flint=flint.__version__,Arb_bits=ctx.prec),
             command='python -B profile806.py --check profile806.json',dependencies=DEPENDENCIES,stages=stages,
             scope=dict(physical='Same unrestricted real-price atoms, legal y exteriors, original full degree and frozen finite diagnostic gates as rectangle806.',
                        forward='Fix one true price-preceding right pair (U,y), its small label, and a true middle dyadic volume bin. Both original orientations enter t posterior.',
                        reverse='Fix one exact (q,W), the other arm small label, its original middle, direction 0 and the true specified-small volume bin. Integrate actual exterior y and receiving U in the right margin.',
                        measure='Active z atoms form a disjoint partition, up to null boundaries. Each representative is a true box in the state with its own true mu and own conditional price mass. The price weight is original regional mu times the fixed-anchor row density, then normalized. Ratios at physical rational anchor points use the constant density version on the interior.',
                        roots='Arb 256-bit uses directed balls for square roots and Gram calculations. Exact Fraction geometry, probabilities, trace and pure-state values. Fubini gives equality of squared Frobenius norms; independent Arb evaluations enclosing the common scalar check it numerically.'))
    text=json.dumps(out,sort_keys=True,indent=2,default=str)+'\n'
    if args.output:
        args.output.write_text(text)
    if args.check:
        assert args.check.read_text()==text
    if args.output or args.check:
        for s in stages:
            print(s['stage'])
            for tag in ('right_fixed_middle_posterior','left_fixed_small_posterior'):
                d=s[tag]
                g=d['public_projection_and_Gram']
                print(tag,d['positive_anchor_count'],d['exact_profile_variation_counts'],
                      'Frob^2',g['Frobenius_squared_by_row_arb'],'projection^2',g['mixture_root_projection_squared_by_row_arb'])
        if args.check:
            print('byte-identical')
    else:
        print(text,end='')


if __name__=='__main__':
    main()
