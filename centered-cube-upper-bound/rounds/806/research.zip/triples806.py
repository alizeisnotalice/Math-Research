#!/usr/bin/env python3
"""Exact three-label correction from true same-price rectangle completion."""
import argparse
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
from itertools import combinations, product
import json
from pathlib import Path
import platform
import subprocess
import sys

import rectangle806 as rect


DEPENDENCIES = dict(rect.DEPENDENCIES, **{
    'rectangle806.py': '04714603e8dfbc8b7fe6f1f9e431c4fd8cf9c3b671e567e34bd5315244c576be',
    'profile806.json': '176f897ca3fc7fd4ffd00770d39100437c4394fdd51044a108563bc76a0ff0f1',
    'reverse805.json': '955de184b852e78a2913ca9e1865404afa746c0425a920c3aa80bf9896dad886',
})
total = rect.total


def chosen_price_boxes(rows):
    def quality(pair):
        i,j = pair
        p,q = rows[i]['posterior'],rows[j]['posterior']
        if p==q:
            return 0
        return 2 if p.keys() & q.keys() else 1
    selected = max(combinations(range(len(rows)),2),key=quality)
    assert quality(selected)>0
    return [rows[i] for i in selected]


def genuine_config(stage, model, old):
    fibres,marks,_ = old.reconstruct(stage)
    T,U = stage['middle_cubes'],stage['small_cubes']
    mu = lambda Z:model.source_mass(Z,F(stage['true_source_amplitude']))
    middle_bin = [rect.dyadic_lower(F(t['m'])) for t in T]
    small_bin = [rect.dyadic_lower(F(u['m'])) for u in U]
    masks = defaultdict(F)
    for Y in stage['alternation']['source_atoms']:
        by_u = defaultdict(list)
        for index in Y['active_types']:
            r = stage['by_t_u'][index]
            by_u[r['u']].append(r['t'])
        for u,ts in by_u.items():
            masks[u,tuple(sorted(ts))] += F(Y['actual_mu'])
    ref_right = {}
    owners = [model.two_halves(old.box(u['owner'])) for u in U]
    for (u,ts),mass in masks.items():
        for r,owner in enumerate(owners[u]):
            ref_right[u,r,ts] = model.volume(owner)*mass
    by_tu = {(r['t'],r['u']):r for r in stage['by_t_u']}
    for (t,u),r in by_tu.items():
        if F(r['retained_true_flux']):
            assert total(w for (u0,ts),w in masks.items() if u==u0 and t in ts)==F(r['true_mu_external'])
    return fibres,marks,T,U,mu,middle_bin,small_bin,ref_right,owners,by_tu


def same_z_edges(stage, config, M, D, Z, model, old):
    fibres,marks,T,U,mu,middle_bin,small_bin,ref_right,_,by_tu = config
    H,ref_left = {},{}
    w_Z = mu(Z)
    assert w_Z>0
    for t,frame in enumerate(fibres):
        if middle_bin[t]!=M:
            continue
        j_t,m_t = F(T[t]['j']),F(T[t]['m'])
        d_t = F(stage['true_physical_degrees'][t]['d_original'])
        for b,row in frame.items():
            B = marks[t][b]
            g = b[0]
            left_ref = mu(B['price'])*model.volume(B['owner'])
            current = {}
            for (u,z,r),w in row.items():
                if small_bin[u]!=D:
                    continue
                A = marks[t][u,z,r]
                local = mu(model.clip(Z,A['price']))
                assert local in (F(0),w_Z)
                if not local:
                    continue
                exact_B = (j_t/d_t)*F(U[u]['j'])/F(U[u]['v'])/(m_t*F(U[u]['m']))
                exact_B *= (F(U[g]['j'])/F(U[g]['v']))/(m_t*F(U[g]['m']))
                ext = F(by_tu[t,u]['true_mu_external'])
                h = exact_B/ext
                assert model.retain(stage['stage'],t,(u,z,r,A['raw']),(*b,B['raw']))
                assert model.retain(stage['stage'],t,(*b,B['raw']),(u,z,r,A['raw']))
                assert 0<h<=1 and w==h*mu(A['price'])*left_ref*model.volume(A['owner'])*ext
                for a in ref_right:
                    if a[:2]==(u,r) and t in a[2]:
                        assert a not in current
                        current[a] = h
            for direction in (0,1):
                x = direction,t,*b
                if current:
                    H[x] = current
                    ref_left[x] = left_ref
    return H,rect.transpose(H),ref_left,ref_right


def genuine_completion(direction, anchor, H, Ht, lx, ra):
    if direction=='right':
        row_roots = {(x,anchor):lx[x]*h for x,h in Ht[anchor].items()}
    else:
        row_roots = {(anchor,a):ra[a]*h for a,h in H[anchor].items()}
    root_mass = total(row_roots.values())
    assert root_mass>0
    true_result, missing_c, original = defaultdict(F),defaultdict(F),defaultdict(F)
    zero, no_changed_marks = F(0),F(0)
    closures = []
    for (x,a),raw_root in row_roots.items():
        root = raw_root/root_mass
        original[x[1] if direction=='right' else a[0]] += root
        triangle = defaultdict(F)
        changed_marks = F(0)
        for xx,h_xx_a in Ht[a].items():
            shared = H[x].keys() & H[xx].keys()
            for aa in sorted(shared):
                three = lx[xx]*ra[aa]*H[x][aa]*H[xx][aa]*h_xx_a
                assert three>0 and H[x][a]>0
                I = (x[1],xx[1],aa[0]) if direction=='right' else (a[0],aa[0],xx[1])
                triangle[I] += three
                if xx!=x and aa!=a:
                    changed_marks += three
        c = total(triangle.values())
        alternate = total(ra[aa]*h_x_aa*total(lx[xx]*Ht[aa][xx]*Ht[a][xx]
                    for xx in sorted(Ht[aa].keys() & Ht[a].keys())) for aa,h_x_aa in H[x].items())
        assert c==alternate
        if not c:
            zero += root
            continue
        if not changed_marks:
            no_changed_marks += root
        closures.append(c)
        for I,value in triangle.items():
            true_result[I] += root*value/c
            missing_c[I] += root*value
    assert total(true_result.values())+zero==1 and total(original.values())==1
    return original,root_mass,true_result,missing_c,zero,no_changed_marks,closures


def square_budget(p, direction, T, U):
    def b(item):
        i,j,k = item
        parents = (T[i],T[j],U[k]) if direction=='right' else (U[i],U[j],T[k])
        out = F(1)
        for v in parents:
            out *= F(v['j'])/F(v['m'])
        return out
    return {I:b(I) for I in p}


def pair_label_energy(p,b):
    return total(w*w/b[I] for I,w in p.items())


def apply_anchor(stage, profile, direction, config, model, old):
    _,_,T,U,mu,middle_bin,small_bin,ref_right,owners,_ = config
    frozen = profile['selected_anchor']
    if direction=='right':
        u,ts = frozen['u'],tuple(frozen['full_y_middle_mask'])
        r = owners[u].index(old.box(frozen['U_subbox']))
        anchor = u,r,ts
        assert ref_right[anchor]==F(frozen['right_reference_mass'])
        M,D = F(frozen['central_bin']),small_bin[u]
    else:
        anchor = tuple(frozen['x'])
        M,D = middle_bin[anchor[1]],F(frozen['small_bin'])
    selected = chosen_price_boxes(profile['actual_price_rows'])
    raw_rows = []
    for row in selected:
        Z = old.box(row['z_actual_box'])
        H,Ht,lx,ra = same_z_edges(stage,config,M,D,Z,model,old)
        if direction=='left':
            assert lx[anchor]==F(frozen['left_reference_mass'])
        base,original_density,p,q,zero,no_changed,closures = genuine_completion(direction,anchor,H,Ht,lx,ra)
        assert original_density==F(row['true_z_density'])
        assert base=={int(i):F(x) for i,x in row['posterior'].items()}
        true_mu = mu(Z)
        physical_mass = original_density*true_mu
        assert physical_mass/F(frozen['unscaled_true_price_mass'])==F(row['true_representative_box_probability'])
        raw_rows.append(dict(z_box=Z,true_mu=true_mu,original_density=original_density,
                       original_parent_posterior=base,true_original_price_mass=physical_mass,
                       original_fraction_without_true_closure=zero,
                       original_fraction_without_second_distinct_encoded_marks=no_changed,
                       minimum_positive_c=min(closures) if closures else None,
                       maximum_positive_c=max(closures) if closures else None, triples=p, missing_c=q))
    total_mass = total(row['true_original_price_mass'] for row in raw_rows)
    true,raw = defaultdict(F),defaultdict(F)
    selected_weights = [r['true_original_price_mass']/total_mass for r in raw_rows]
    assert total(selected_weights)==1
    zero_mass = total(w*r['original_fraction_without_true_closure'] for w,r in zip(selected_weights,raw_rows))
    keep = 1-zero_mass
    assert keep>0
    for w,row in zip(selected_weights,raw_rows):
        for I,p in row['triples'].items():
            true[I] += w*p/keep
        for I,q in row['missing_c'].items():
            raw[I] += w*q
    b = square_budget(true,direction,T,U)
    exactly = pair_label_energy(true,b)
    rows = [r['triples'] for r in raw_rows]
    inner = [[total(p[I]*q[I]/b[I] for I in sorted(p.keys() & q.keys())) for q in rows] for p in rows]
    other_order = total(selected_weights[i]*selected_weights[j]*inner[i][j]/keep**2
                        for i,j in product(range(len(rows)),repeat=2))
    assert exactly==other_order>0 and total(true.values())==1
    raw_total = total(raw.values())
    normalized_wrong = {I:w/raw_total for I,w in raw.items()}
    assert raw_total>0 and total(normalized_wrong.values())==1
    tv = total(abs(true[I]-normalized_wrong[I]) for I in true)/2
    for w,row in zip(selected_weights,raw_rows):
        row.update(selected_true_price_probability=w,triples=[dict(labels=I,p=v) for I,v in sorted(row['triples'].items())],
                   missing_c=[dict(labels=I,w=v) for I,v in sorted(row['missing_c'].items())])
    return dict(direction=direction,fixed_anchor=frozen,central_bin_M=M,small_bin_D=D,
                selected_two_boxes_fraction_of_whole_anchor=total_mass/F(frozen['unscaled_true_price_mass']),
                two_actual_price_boxes=raw_rows,uncompletable_original_root_probability=zero_mass,
                normalized_triples=[dict(I=I,b_I=b[I],p_bar=p,no_c_globally_normalized=normalized_wrong[I])
                                    for I,p in sorted(true.items())],
                sum_p_bar=total(true.values()),sum_p_bar_sq_over_b_I=exactly,
                by_two_prices_same_I=other_order,common_I_count=len(rows[0].keys() & rows[1].keys()),
                common_I_weighted_inner_product=inner[0][1],
                raw_no_c_total_mass=raw_total,raw_no_c_square_sum=pair_label_energy(raw,b),
                after_global_renormalization_no_c_square_sum=pair_label_energy(normalized_wrong,b),
                wrong_renormalized_total_variation=tv)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    here=Path(__file__).resolve().parent
    p.add_argument('--deps-dir',type=Path,default=here)
    p.add_argument('--rebuild-fixture',action='store_true',
                   help='Read the base fixture from frozen reverse805.py stdout even if its JSON is available.')
    files=p.add_mutually_exclusive_group()
    files.add_argument('--output',type=Path)
    files.add_argument('--check',type=Path)
    args=p.parse_args()
    deps=args.deps_dir.resolve()
    for name,digest in DEPENDENCIES.items():
        if name=='reverse805.json':
            continue
        path=(here if name in ('rectangle806.py','profile806.json') else deps)/name
        assert sha256(path.read_bytes()).hexdigest()==digest
    sys.path.insert(0,str(deps))
    import reverse805 as model
    import shared805 as old
    fixture_path=deps/'reverse805.json'
    if fixture_path.is_file() and not args.rebuild_fixture:
        fixture=fixture_path.read_bytes()
    else:
        fixture=subprocess.check_output([sys.executable,'-B',str(deps/'reverse805.py')])
    assert sha256(fixture).hexdigest()==DEPENDENCIES['reverse805.json']
    raw=json.loads(fixture)
    profile=json.loads((here/'profile806.json').read_text())
    cases=[]
    for s,frozen in zip(raw['stages'],profile['stages'],strict=True):
        assert s['stage']==frozen['stage']
        config=genuine_config(s,model,old)
        applications=[apply_anchor(s,frozen[key],mode,config,model,old) for key,mode in
                      (('right_fixed_middle_posterior','right'),('left_fixed_small_posterior','left'))]
        cases.append(dict(stage=s['stage'],dimension=s['n'],applications=applications))
    assert len(cases)==3 and all(len(s['applications'])==2 for s in cases)
    assert any(a['common_I_count']>0 for s in cases for a in s['applications'])
    assert any(a['wrong_renormalized_total_variation']>0 for s in cases for a in s['applications'])
    out=dict(runtime=dict(python=platform.python_version(),architecture=platform.machine(),arithmetic='Fraction exact'),
             reproduction='python -B triples806.py --check triples806.json', dependencies=DEPENDENCIES,stages=cases,
             optional_fixture='If reverse805.json is absent, its frozen Python script recreates the fixture via stdout with the same SHA256. No anchor scan is repeated.',
             scopes=dict(witnesses='Exactly the six fixed actual anchors already selected in profile806. Exactly two disjoint physical representative price boxes per anchor, preferring a positive nonidentical overlap of first-label posteriors. Original price mass of the selected boxes is explicit.',
                 kernels='Each of four edges uses the same continuous z and its own original old-arm marks, original degree, owner factors, physical volume bin, and genuine external denominator. The three-edge completion has its own c_h for each fixed root. Closure is independently recomputed in the reversed order.',
                 copies='Both new states are drawn using non-atomic real price and receiver references. Matching encoded tags can occur while their continuous marks differ almost surely. No identity edge or weight is added. The stronger requirement of two different encoded full marks is only separately diagnosed.',
                 labels='The ordered physical triple is (t,t_prime,u_prime) for fixed right pre-price or (u,u_prime,t_prime) for fixed left pre-price. b_I is the product of j_i/m_i at all three slots, including repeated physical labels.',
                 zero='An actual uncompletable root is omitted from completion and its natural probability is recorded. In the selected model the binned exact probability is re-normalised on completable mass if necessary.',
                 check='Two price boxes use their true fixed-anchor probabilities conditioned on belonging to the selected boxes. Squaring the true averaged triple vector and integrating the two-price common-label inner product agree exactly. Omitted c_h is checked both before and after a global normalisation.',
                 limit='Frozen 1/2/3-dimensional finite witnesses with their real geometric price/owner measures and existing diagnostic masks. This does not test the full high-dimensional terminal screen.'))
    text=json.dumps(out,sort_keys=True,indent=2,default=str)+'\n'
    if args.output:
        args.output.write_text(text)
    if args.check:
        assert args.check.read_text()==text
    if args.output or args.check:
        for s in cases:
            for a in s['applications']:
                print(s['stage'],a['direction'],'common I',a['common_I_count'], 'uncompletable',a['uncompletable_original_root_probability'],
                      'energy display',format(float(a['sum_p_bar_sq_over_b_I']),'.9g'),
                      'wrong normalized TV display',format(float(a['wrong_renormalized_total_variation']),'.9g'))
        if args.check:
            print('byte-identical')
    else:
        print(text,end='')


if __name__=='__main__':
    main()
