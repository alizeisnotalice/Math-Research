#!/usr/bin/env python3
"""Repeat actual arms conditional on a shared, fully marked opposite arm."""
import argparse
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
from itertools import product
import json
from math import prod
from pathlib import Path
import platform
import subprocess
import sys

import reverse805 as model


REVERSE_SHA = 'c9a810c2807fa592e0fc76c514738522d8414d2e01c548579856e64d8b7fb17e'
total = model.total


def box(data):
    return tuple(tuple(map(F, axis)) for axis in data)


def agreement_mass(grouped, order):
    mass = total(grouped.values())
    if not mass:
        return F(0)
    return total(w**order for w in grouped.values())/mass**(order-1)

def event_measure(edges, signature, order):
    by_signature = defaultdict(F)
    for a, weight in edges.items():
        by_signature[signature(a)] += weight
    result = agreement_mass(by_signature, order)
    assert result == total(w*(by_signature[signature(a)]/total(edges.values()))**(order-1)
                           for a,w in edges.items())
    return result


def reconstruct(stage):
    old_cubes = stage['small_cubes']
    actual_reference = {(r['t'],r['u']):r for r in stage['by_t_u']}
    mu = lambda B: model.source_mass(B, F(stage['true_source_amplitude']))
    old_arms = []
    fibres = []
    subcell_checks = 0
    for t, T in enumerate(stage['middle_cubes']):
        m_t, j_t = F(T['m']), F(T['j'])
        d = F(stage['true_physical_degrees'][t]['d_original'])
        arms = {}
        for u, U in enumerate(old_cubes):
            overlap = model.clip(box(T['A']), box(U['A']))
            mu_I = mu(overlap)
            if not mu_I:
                assert F(actual_reference[t,u]['retained_true_flux']) == 0
                continue
            m_u, j_u, vol_u = map(F,(U['m'],U['j'],U['v']))
            assert mu_I == F(actual_reference[t,u]['true_mu_intersection'])
            for (zi,Z),(ri,R) in product(enumerate(model.two_halves(overlap)),
                                           enumerate(model.two_halves(box(U['owner'])))):
                rho = j_u * mu_I / (m_u*m_t)
                raw = rho * mu(Z)/mu_I * model.volume(R)/vol_u
                marks = []
                for Z0,R0 in product(model.two_halves(Z),model.two_halves(R)):
                    p = mu(Z0)/mu(Z) * model.volume(R0)/model.volume(R)
                    direct = j_u/vol_u * mu(Z0)*model.volume(R0)/(m_t*m_u)
                    assert 0 < direct == p*raw
                    marks.append((Z0,R0,p,direct))
                assert total(v[2] for v in marks) == 1 and total(v[3] for v in marks) == raw
                arms[u,zi,ri] = dict(price=Z,owner=R,raw=raw,refinements=marks)
        assert total(a['raw'] for a in arms.values()) == F(stage['true_physical_degrees'][t]['d_minus'])
        by_opposite = defaultdict(dict)
        counts = defaultdict(F)
        for (a,am),(b,bm) in product(arms.items(),repeat=2):
            if not model.retain(stage['stage'],t,(*a,am['raw']),(*b,bm['raw'])):
                continue
            weight = j_t*am['raw']*bm['raw']/d
            by_opposite[b][a] = weight
            counts[a[0]] += weight
            for _,_,p,direct in bm['refinements']:
                assert j_t*am['raw']*direct/d == weight*p
                subcell_checks += 1
        assert all(counts[u] == F(actual_reference[t,u]['retained_true_flux']) for u in range(len(old_cubes)))
        assert sum(map(len,by_opposite.values())) == stage['true_physical_degrees'][t]['retained_full_path_cells']
        fibres.append(dict(sorted(by_opposite.items())))
        old_arms.append(arms)
    return fibres,old_arms,subcell_checks


def analyse(stage):
    fibres,marks,refinements = reconstruct(stage)
    observed = F(stage['total_supported_original_mass'])
    centre_m = [total(w for edges in frame.values() for w in edges.values()) for frame in fibres]
    assert total(centre_m) == observed
    assert centre_m == [F(v) for v in stage['alternation']['central_marginal']]
    entries = [(v,b,weights,total(weights.values())) for v,frame in enumerate(fibres) for b,weights in frame.items()]
    candidates = [(v,b,weights,w,ref) for v,b,weights,w in entries for ref in marks[v][b]['refinements']]
    unequal_price_candidates = [q for q in candidates if q[-1][2] != F(1,4)]
    v_w,b_w,_,row_w,(price_w,owner_w,fraction_w,_) = max(unequal_price_candidates or candidates,key=lambda q:q[3])
    assert 0 < fraction_w < 1
    results = []
    for p in (2,3):
        correct, impostor = F(0), F(0)
        true_label, wrong_label, true_owners, wrong_owners = (F(0),)*4
        same_signature_by_middle = F(0)
        different_signature_by_middle = F(0)
        min_marginal_fraction, max_marginal_fraction = F(1),F(0)
        for v,frame in enumerate(fibres):
            w_v = centre_m[v]
            if not frame:
                assert w_v == 0
                continue
            combined = defaultdict(F)
            row_mass = {}
            for b, edges in frame.items():
                w_x = total(edges.values())
                row_mass[b] = w_x
                wrong_factor = (w_x/w_v)**(p-1)
                min_marginal_fraction = min(min_marginal_fraction,wrong_factor)
                max_marginal_fraction = max(max_marginal_fraction,wrong_factor)
                assert total(w/w_x for w in edges.values()) == 1
                for a, w in edges.items():
                    other_slots = [w_x]*p
                    for slot in range(p):
                        all_other_weights = prod(c for i,c in enumerate(other_slots) if i != slot)
                        assert w * all_other_weights/w_x**(p-1) == w
                        assert w * all_other_weights/w_v**(p-1) == w*wrong_factor
                    combined[a] += w
                correct += w_x
                impostor += w_x * wrong_factor
                true_label += event_measure(edges,lambda a:a[0],p)
                true_owners += event_measure(edges,lambda a:a[2],p)
            same_signature = agreement_mass(row_mass,p)
            same_signature_by_middle += same_signature
            same_exact_signature_independent = total(w*(w/w_v)**(p-1) for w in row_mass.values())
            assert same_signature == same_exact_signature_independent
            different_signature_by_middle += total(w*(1-(w/w_v)**(p-1)) for w in row_mass.values())
            wrong_label += event_measure(combined,lambda a:a[0],p)
            wrong_owners += event_measure(combined,lambda a:a[2],p)
        assert correct == observed and impostor == same_signature_by_middle
        assert observed - impostor == different_signature_by_middle > 0
        assert true_label >= wrong_label and true_owners >= wrong_owners
        shared_subcell = row_w*fraction_w
        independent_subcell = row_w*fraction_w**p
        assert 0 < independent_subcell < shared_subcell
        twice = dict(order=p, all_specified_full_arm_marginals_checked=True,
                     shared_full_mark_total=correct, same_opposite_signature_mass_if_only_center=same_signature_by_middle,
                     differing_opposite_signature_mass_if_only_center=different_signature_by_middle,
                     differing_opposite_signature_probability_if_only_center=different_signature_by_middle/observed,
                     wrong_denominator_remaining_mass=impostor,
                     wrong_denominator_missing_mass=observed-impostor,
                     wrong_denominator_retained_fraction=impostor/observed,
                     per_edge_wrong_marginal_multiplier_range=[min_marginal_fraction,max_marginal_fraction],
                     all_specified_small_labels_same=dict(shared_mass=true_label,center_only_mass=wrong_label,
                       shared_probability=true_label/observed,center_only_probability=wrong_label/observed,
                       difference=(true_label-wrong_label)/observed),
                     all_specified_receive_halves_same=dict(shared_probability=true_owners/observed,
                        center_only_probability=wrong_owners/observed,difference=(true_owners-wrong_owners)/observed),
                     witness_one_true_opposite_price_owner_joint_subcell=dict(shared_mass=shared_subcell,
                        independently_redrawn_within_same_opposite_cell_mass=independent_subcell))
        results.append(twice)
    if stage['stage']=='pressure':
        assert all(p['all_specified_receive_halves_same']['shared_probability']==1 and
                   p['all_specified_receive_halves_same']['difference']>0 for p in results)
    if stage['stage']=='expanded':
        assert all(p['all_specified_small_labels_same']['difference']>0 for p in results)
    return dict(stage=stage['stage'],dimension=stage['n'],actual_original_mass=observed,
                actual_central_totals=centre_m,positive_opposite_fibres=len(entries),
                true_original_oriented_cells=sum(len(e) for _,_,e,_ in entries),
                exact_original_price_receiver_refinement_checks=refinements,
                original_opposite_row_masses=[dict(v=v,opposite_mark=b,w_x=w,positive_specified_arms=len(e))
                                              for v,b,e,w in entries],
                localized_same_opposite_witness=dict(v=v_w,b=b_w,w_x=row_w,full_true_price=marks[v_w][b_w]['price'],
                    full_true_owner=marks[v_w][b_w]['owner'], selected_actual_price_subcell=price_w,
                    selected_actual_owner_subcell=owner_w,conditional_mu_times_Leb=fraction_w), moments=results)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    files = p.add_mutually_exclusive_group()
    files.add_argument('--output',type=Path)
    files.add_argument('--check',type=Path)
    args = p.parse_args()
    dependency = Path(__file__).resolve().with_name('reverse805.py')
    assert Path(model.__file__).resolve() == dependency
    assert sha256(dependency.read_bytes()).hexdigest() == REVERSE_SHA
    frozen = json.loads(subprocess.check_output([sys.executable,'-B',str(dependency)],text=True))
    stages = [analyse(s) for s in frozen['stages']]
    data = dict(runtime=dict(python=platform.python_version(),architecture=platform.machine(),arithmetic='Fraction exact'),
                reproduction='python -B shared805.py --check shared805.json',
                source_dependency={'reverse805.py':REVERSE_SHA},
                scope=dict(physical='Same three physical cube fixtures, true old price, real owner, and original degrees as reverse805.',
                  arm='For each v fix the complete second arm: physical small label, true price half and true receiving half. At this finite resolution the stage gate is constant. Refine both actual halves geometrically and check the same real conditional density for every specified arm.',
                  continuous='One actual pair (opposite price, opposite receiving point) is drawn once with the true within-cell product conditional law and shared by all p copies. The certificate integrates subcells exactly. It samples no floating-point locations. Independently drawn actual continuous positions are almost surely distinct even in a matching cell signature.',
                  weights='At fixed v and b let w_x=sum_a m(v,b,a). The shared p-arm weight is product_a(m)/w_x^(p-1), so each full original oriented edge is restored as a marginal. Only-v redraw allows p independent opposite signatures, which are explicitly counted.',
                  baseline='Wrong w_v denominator with b artificially fixed keeps only the finite same-signature event for the true only-v sampler. Receiving-half comparisons refer to the lower/upper first coordinate half within each actual small receiver.',
                  range='Finite diagnostic gates from reverse805. No extra asymptotic or high-dimensional screens are imposed.'),stages=stages)
    text = json.dumps(data,sort_keys=True,indent=2,default=str)+'\n'
    if args.output:
        args.output.write_text(text)
    if args.check:
        assert args.check.read_text() == text
    if args.check or args.output:
        for s in stages:
            print(s['stage'], s['positive_opposite_fibres'], 'actual fibres')
            for m in s['moments']:
                print(' p',m['order'],'different b / lost denominator fraction',
                      format(float(m['differing_opposite_signature_probability_if_only_center']),'.8f'),
                      'same specified-small probability gain',format(float(m['all_specified_small_labels_same']['difference']),'.8f'),
                      'same receiving-half probability gain',format(float(m['all_specified_receive_halves_same']['difference']),'.8f'))
        if args.check:
            print('byte-identical')
    else:
        print(text,end='')


if __name__=='__main__':
    main()
