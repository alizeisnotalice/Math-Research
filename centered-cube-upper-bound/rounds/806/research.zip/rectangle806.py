#!/usr/bin/env python3
"""Same true price, physical old-arm bipartite graph, and admissible rectangles."""
import argparse
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
from itertools import combinations_with_replacement, product
import json
from pathlib import Path
import platform
import subprocess
import sys


DEPENDENCIES = {
    'reverse805.py': 'c9a810c2807fa592e0fc76c514738522d8414d2e01c548579856e64d8b7fb17e',
    'shared805.py': 'd35faf62af4a6498cfaff0bd8ce1b59ebdd870143847660c67f02aa0aa10ceab',
}


def total(values):
    return sum(values, F(0))


def dyadic_lower(volume):
    D = F(1)
    while D > volume:
        D /= 2
    while 2*D <= volume:
        D *= 2
    return D


def transpose(rows):
    result = defaultdict(dict)
    for x, row in rows.items():
        for a, h in row.items():
            result[a][x] = h
    return dict(result)


def codegree_square(rows, left, right):
    # Compress exact duplicate coefficient vectors only. Their real weights add.
    representative_weight = defaultdict(F)
    for x, row in rows.items():
        representative_weight[tuple(sorted(row.items()))] += left[x]
    codegrees = defaultdict(F)
    for row, weight in representative_weight.items():
        for (a,ha), (b,hb) in combinations_with_replacement(row,2):
            codegrees[a,b] += weight*ha*hb
    return total((1 if a==b else 2)*right[a]*right[b]*v**2 for (a,b),v in codegrees.items())


def brute_rectangle(rows, left, right, complete=False):
    xs = list(rows) if complete else list(rows)[:5]
    rights = sorted(set().union(*(rows[x] for x in xs)))
    rights = rights if complete else rights[:6]
    small = {x:{a:rows[x][a] for a in rights if a in rows[x]} for x in xs}
    value = F(0)
    for x,y in product(xs,repeat=2):
        for a,b in product(rights,repeat=2):
            weights = [small[x].get(a),small[x].get(b),small[y].get(a),small[y].get(b)]
            if all(weights):
                first,second,third,fourth = weights
                value += left[x]*left[y]*right[a]*right[b]*first*second*third*fourth
    assert value == codegree_square(small,left,right) == codegree_square(transpose(small),right,left)
    return value


def exchange_test(rows, left, right):
    # Take two actual diagonal edges at the same z. Three tests restrict
    # the pair by price alone, by matching middle, or by matching all parents.
    compressed = defaultdict(F)
    candidates = {}
    for x, row in rows.items():
        _, t, g, _, _ = x
        key = t,g,tuple(sorted(row.items()))
        compressed[key] += left[x]
        candidates.setdefault(key,x)
    data = []
    for key, j in compressed.items():
        t,g,coefficients = key
        edges = {a:right[a]*h for a,h in coefficients}
        by_u = defaultdict(F)
        for a,m in edges.items():
            by_u[a[0]] += m
        data.append((t,g,candidates[key],j,edges,total(edges.values()),by_u))
    masses = dict(all_pairs=F(0), genuine_cross_support=F(0), same_middle_pairs=F(0),
                  same_middle_genuine_cross_support=F(0), same_physical_parent_triples=F(0),
                  same_physical_triple_genuine_cross_support=F(0))
    witnesses = {}
    for i,j in combinations_with_replacement(range(len(data)),2):
        t,g,x,jx,L,sL,by_uL = data[i]
        v,f,y,jy,R,sR,by_uR = data[j]
        w = jx*jy*(1 if i==j else 2)
        common = L.keys() & R.keys()
        remain = total(L[a] for a in common)*total(R[a] for a in common)
        raw = sL*sR
        masses['all_pairs'] += w*raw
        masses['genuine_cross_support'] += w*remain
        if t==v:
            masses['same_middle_pairs'] += w*raw
            masses['same_middle_genuine_cross_support'] += w*remain
        if (t,g)==(v,f):
            same_u = by_uL.keys() & by_uR.keys()
            sharedL, sharedR = defaultdict(F), defaultdict(F)
            for a in common:
                sharedL[a[0]] += L[a]
                sharedR[a[0]] += R[a]
            masses['same_physical_parent_triples'] += w*total(by_uL[u]*by_uR[u] for u in same_u)
            masses['same_physical_triple_genuine_cross_support'] += w*total(sharedL[u]*sharedR[u] for u in same_u)
        if remain==raw:
            continue
        for xa,ya,lhs,rhs in ((x,y,L,R),(y,x,R,L)):
            for a in sorted(lhs.keys()-rhs.keys()):
                external = ya[1] not in a[2]
                label = 'new_middle_forbids_external_y' if external else 'original_full_path_gate'
                if label not in witnesses:
                    witnesses[label] = xa,ya,a,min(rhs)
                if ('same_physical_triple' not in witnesses and xa[1:3]==ya[1:3]
                        and any(b[0]==a[0] for b in rhs)):
                    witnesses['same_physical_triple'] = xa,ya,a,min(b for b in rhs if b[0]==a[0])
                if all(k in witnesses for k in ('new_middle_forbids_external_y','original_full_path_gate','same_physical_triple')):
                    break
    assert 0 <= masses['genuine_cross_support'] <= masses['all_pairs']
    assert 0 <= masses['same_middle_genuine_cross_support'] <= masses['same_middle_pairs']
    assert 0 <= masses['same_physical_triple_genuine_cross_support'] <= masses['same_physical_parent_triples']
    return masses,witnesses


def small_common_pool(cols,left):
    best = None
    for a,b in combinations_with_replacement(sorted(cols),2):
        N1,N2 = cols[a].keys(),cols[b].keys()
        common = N1 & N2
        if not common or min(len(N1),len(N2))<4 or len(common)==min(len(N1),len(N2)):
            continue
        M1,M2,C = (total(left[x] for x in N) for N in (N1,N2,common))
        ratio = C/min(M1,M2)
        if best is None or ratio<best['common_fraction_of_smaller_pool']:
            best = dict(a=a,b=b,positive_left_mark_counts=[len(N1),len(N2),len(common)],
                        actual_left_reference_masses=[M1,M2,C],common_fraction_of_smaller_pool=ratio)
    return best


def stage_graph(stage, model, previous):
    fibres,marks,_ = previous.reconstruct(stage)
    n = stage['n']
    mu = lambda B:model.source_mass(B,F(stage['true_source_amplitude']))
    middles,smalls = stage['middle_cubes'],stage['small_cubes']
    small_bin = dyadic_lower(F(smalls[0]['m']))
    assert all(dyadic_lower(F(u['m']))==small_bin for u in smalls)
    middle_bins = [dyadic_lower(F(t['m'])) for t in middles]
    Z = {}
    y_table = stage['alternation']['source_atoms']
    ext_by_index = [(r['t'],r['u']) for r in stage['by_t_u']]
    exterior_mu = {(r['t'],r['u']):F(r['true_mu_external']) for r in stage['by_t_u']}
    y_by_u, y_reps = defaultdict(F), {}
    for Y in y_table:
        allowance = defaultdict(list)
        for k in Y['active_types']:
            t,u = ext_by_index[k]
            allowance[u].append(t)
        for u,ts in allowance.items():
            key = u,tuple(sorted(ts))
            y_by_u[key] += F(Y['actual_mu'])
            y_reps.setdefault(key,previous.box(Y['representative_cell']))
    for (t,u),r in zip(ext_by_index,stage['by_t_u']):
        if F(r['retained_true_flux']):
            assert total(m for (v,ts),m in y_by_u.items() if u==v and t in ts)==exterior_mu[t,u]
    right, owners = {}, {}
    for u,U in enumerate(smalls):
        owners[u] = model.two_halves(previous.box(U['owner']))
    for (u,ts),ymass in y_by_u.items():
        for r,R in enumerate(owners[u]):
            right[u,r,ts] = model.volume(R)*ymass
    left = {}
    expected, z_edges, right_bins = {},defaultdict(list),set()
    for t,frame in enumerate(fibres):
        T = middles[t]
        j_t,m_t = F(T['j']),F(T['m'])
        d_t = F(stage['true_physical_degrees'][t]['d_original'])
        for b,edge_row in frame.items():
            B = marks[t][b]
            g = b[0]
            G = smalls[g]
            for direction in (0,1):
                x = direction,t,*b
                left[x] = mu(B['price'])*model.volume(B['owner'])
                for a0,actual in edge_row.items():
                    u,z_half,receive_half = a0
                    U = smalls[u]
                    z_key = t,u,z_half
                    A = marks[t][a0]
                    Z[z_key] = A['price']
                    assert model.retain(stage['stage'],t,(*a0,A['raw']),(*b,B['raw']))
                    assert model.retain(stage['stage'],t,(*b,B['raw']),(*a0,A['raw']))
                    ext = exterior_mu[t,u]
                    dens_a = F(U['j'])/F(U['v'])/(m_t*F(U['m']))
                    dens_b = F(G['j'])/F(G['v'])/(m_t*F(G['m']))
                    h = (j_t/d_t)*dens_a*dens_b/ext
                    assert 0<h<=1
                    assert actual==h*left[x]*mu(A['price'])*model.volume(A['owner'])*ext
                    expected[x,a0] = actual
                    for a in sorted(right):
                        if a[:2]==(u,receive_half) and t in a[2]:
                            z_edges[z_key].append((x,a,a0,h))
                            right_bins.add((small_bin,middle_bins[t]))
    z_keys = sorted(Z)
    atom_input = [dict(retained_true_flux=1,external=[Z[k]],true_mu_external=mu(Z[k])) for k in z_keys]
    z_atoms,z_reps = model.source_membership_atoms(atom_input,n,mu)
    edge_counts = defaultdict(F)
    integrated_left, integrated_right = defaultdict(F), defaultdict(F)
    summaries = defaultdict(lambda:defaultdict(F))
    witnesses, subchecks = {}, {}
    support_sizes = defaultdict(int)
    pooled = None
    max_h = F(0)
    for z_indices,z_mass in z_atoms:
        z_records = defaultdict(lambda:defaultdict(dict))
        for index in z_indices:
            for x,a,a0,h in z_edges[z_keys[index]]:
                D = middle_bins[x[1]]
                assert a not in z_records[D][x]
                z_records[D][x][a] = h
                w = z_mass*left[x]*right[a]*h
                edge_counts[x,a0] += w
                integrated_left[x] += w
                integrated_right[D,a] += w
                max_h = max(max_h,h)
        for D,rows in sorted(z_records.items()):
            cols = transpose(rows)
            row_marg = {x:left[x]*total(right[a]*h for a,h in rr.items()) for x,rr in rows.items()}
            col_marg = {a:right[a]*total(left[x]*h for x,h in cc.items()) for a,cc in cols.items()}
            M = total(row_marg.values())
            assert M==total(col_marg.values())>0
            Tx = codegree_square(rows,left,right)
            Ta = codegree_square(cols,right,left)
            assert Tx==Ta>0
            support_sizes[D] += 1
            if stage['stage']=='initial':
                direct = brute_rectangle(rows,left,right,complete=True)
                assert direct==Tx
            if D not in subchecks:
                subchecks[D] = brute_rectangle(rows,left,right)
                assert subchecks[D]>0
            data,missing = exchange_test(rows,left,right)
            assert data['all_pairs']==M**2
            s = summaries[D]
            s['actual_edge_mass'] += z_mass*M
            s['enumerated_square_by_left_codegree'] += z_mass*Ta
            s['enumerated_square_by_right_codegree'] += z_mass*Tx
            if stage['stage']=='initial':
                s['direct_exhaustive_four_vertex_integral'] += z_mass*direct
            for k,value in data.items():
                s[k] += z_mass*value
            s['posterior_two_diagonals_with_false_cross'] += z_mass*(M**2-data['genuine_cross_support'])/M
            for k,(x,y,a,b) in missing.items():
                if k in witnesses:
                    continue
                r,s0 = rows[x],rows[y]
                assert r[a]>0 and s0[b]>0 and a not in s0
                z_box = z_reps[z_indices]
                ya, yb = y_reps[a[0],a[2]], y_reps[b[0],b[2]]

                def valid_at_same_true_z(x0,a1,Y0):
                    _, t0, *opposite = x0
                    u0,r0,_ = a1
                    assert model.inside(Y0,previous.box(smalls[u0]['G']))
                    outside = model.volume(model.clip(Y0,previous.box(middles[t0]['hat'])))==0
                    assert (t0 in a1[2])==outside
                    spec = [(u0,z_half,r0) for z_half in (0,1)
                            if (u0,z_half,r0) in marks[t0] and model.inside(z_box,marks[t0][u0,z_half,r0]['price'])]
                    assert len(spec)==1
                    spec = spec[0]
                    opposite = tuple(opposite)
                    gate = model.retain(stage['stage'],t0,(*spec,marks[t0][spec]['raw']),
                                        (*opposite,marks[t0][opposite]['raw']))
                    return outside,gate

                details = [valid_at_same_true_z(xx,aa,Y) for xx,aa,Y in ((x,a,ya),(x,b,yb),(y,a,ya),(y,b,yb))]
                assert [all(v) for v in details]==[a in r,b in r,a in s0,b in s0]
                assert details[2]==((False,True) if k=='new_middle_forbids_external_y' else (True,False))
                all_price_and_sources = z_mass*right[a]*right[b]
                representative_boxes = mu(z_box)*mu(ya)*mu(yb)*model.volume(owners[a[0]][a[1]])*model.volume(owners[b[0]][b[1]])
                local = representative_boxes*left[x]*left[y]*r[a]*s0[b]
                whole = all_price_and_sources*left[x]*left[y]*r[a]*s0[b]
                assert 0<local<=whole
                witnesses[k] = dict(central_bin_D=D,actual_z_cell=z_box,exact_z_pattern_mu=z_mass,
                    x=x,xx=y,a=a,aa=b,full_four_true_densities=[r[a],r.get(b,F(0)),s0.get(a,F(0)),s0[b]],
                    four_validation_pairs_outside_halo_and_full_path_gate=details,
                    true_diagonal_pair_mass=whole,diagonal_pair_mass_on_representative_boxes=local,
                    x_true_q=marks[x[1]][x[2:]]['price'],xx_true_q=marks[y[1]][y[2:]]['price'],
                    x_true_W=marks[x[1]][x[2:]]['owner'],xx_true_W=marks[y[1]][y[2:]]['owner'],
                    a_true_U=owners[a[0]][a[1]],aa_true_U=owners[b[0]][b[1]],
                    a_true_y_cell=ya,aa_true_y_cell=yb)
            pool = small_common_pool(cols,left)
            if pool is not None and (pooled is None or pool['common_fraction_of_smaller_pool']<pooled['common_fraction_of_smaller_pool']):
                pooled = dict(pool,real_z_cell=z_reps[z_indices],middle_bin=D)
    assert edge_counts == expected
    M2 = 2*F(stage['total_supported_original_mass'])
    assert total(edge_counts.values())==total(integrated_left.values())==total(integrated_right.values())==M2
    col_groups = defaultdict(F)
    for (D,a),v in integrated_right.items():
        col_groups[a[0]] += v
    for u,v in col_groups.items():
        assert v == 2*total(F(d['retained_true_flux']) for d in stage['by_t_u'] if d['u']==u)
    for x,v in integrated_left.items():
        assert v==total(fibres[x[1]][x[2:]].values())
    assert total(s['actual_edge_mass'] for s in summaries.values())==M2
    totals = {k:total(s[k] for s in summaries.values()) for k in next(iter(summaries.values()))}
    false = 1-totals['genuine_cross_support']/totals['all_pairs']
    same_triple_false = 1-totals['same_physical_triple_genuine_cross_support']/totals['same_physical_parent_triples']
    same_middle_false = 1-totals['same_middle_genuine_cross_support']/totals['same_middle_pairs']
    if stage['stage']=='initial':
        assert false==same_triple_false==same_middle_false==0 and not witnesses
    else:
        assert min(false,same_triple_false,same_middle_false)>0
        assert {'new_middle_forbids_external_y','original_full_path_gate','same_physical_triple'}<=witnesses.keys()
    return dict(stage=stage['stage'],dimension=n,small_bin_D=small_bin,
            occupied_small_middle_bins=sorted(right_bins),true_integrated_edge_mass_two_directions=M2,
            original_full_mark_marginal_checks=len(expected),
            exact_integrated_left_marginal_count=len(integrated_left),exact_integrated_right_marginal_count=len(integrated_right),
            maximum_true_density_h=max_h,
            by_middle_bin=[dict(middle_bin=D,active_z_patterns=support_sizes[D],direct_four_vertex_submatrix_check=subchecks[D],
                               exact_integrals=dict(s)) for D,s in sorted(summaries.items())],
            exact_totals=totals,same_z_false_cross_fraction_of_two_actual_diagonals=false,
            same_z_and_middle_false_cross_fraction=same_middle_false,
            same_z_and_all_three_physical_parent_labels_false_cross_fraction=same_triple_false,
            shared_z_original_posterior_false_fraction=totals['posterior_two_diagonals_with_false_cross']/M2,
            actual_unsupported_cross_witnesses=witnesses,proper_common_opposite_pool_witness=pooled)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--deps-dir',type=Path,default=Path(__file__).resolve().parent)
    files = parser.add_mutually_exclusive_group()
    files.add_argument('--output',type=Path)
    files.add_argument('--check',type=Path)
    args = parser.parse_args()
    deps = args.deps_dir.resolve()
    for file,digest in DEPENDENCIES.items():
        assert sha256((deps/file).read_bytes()).hexdigest()==digest
    sys.path.insert(0,str(deps))
    import reverse805 as model
    import shared805 as previous
    frozen = json.loads(subprocess.check_output([sys.executable,'-B',str(deps/'reverse805.py')],text=True))
    stages = [stage_graph(s,model,previous) for s in frozen['stages']]
    data = dict(runtime=dict(python=platform.python_version(),architecture=platform.machine(),arithmetic='exact Fraction'),
                reproduction='python -B rectangle806.py --check rectangle806.json',dependencies=DEPENDENCIES,
                scopes=dict(z='The same continuously distributed z is shared by all edges. A z atom is the union of actual geometric boxes with constant membership in every actual designated-price half. Source mass is Lebesgue-integrated against the original piecewise positive density.',
                    x='An actual direction, physical middle t, and full other leg with physical small g, actual q-price half and actual W receiving half. The reference weights each tag by mu(q-half)*Leb(W-half).',
                    a='Actual specified small label u, physical owner half U, and actual y belonging to the union of cells with the same exact set of allowable middle t. Its reference is mu(y-atom)*Leb(U-half).',
                    h='Density relative to the actual three reference measures. Keeps j_t/d_t and both true owner shares, 1/(m_t*m_u) and 1/(m_t*m_g), multiplies by 1/mu(G_u minus halo of t), and uses the full original gate and original price support. Reversal checks every marked edge separately for each direction.',
                    exchange='At a fixed true z, first draw two genuine diagonal edges. A supported pair has both swapped edges positive under their own full original rules and actual exterior. The raw quadratic probability integrates M_z^2 against mu(dz). The posterior version instead weights M_z against mu(dz). The physical triple locks t, g and u, with original source and owner marks still varying.',
                    four='T4 is the full weighted real four-edge product in one actual (D_small,D_middle) bin. Two nonnegative codegree orders are checked, plus direct four-variable enumeration on the entire initial model and a finite submatrix of each pressure or expanded bin.',
                    limits='Finite real cube models with the exact frozen diagnostic gates and original full degree. The high-dimensional asymptotic screens and global first-passage selection are outside the experiment.'),stages=stages)
    text = json.dumps(data,sort_keys=True,indent=2,default=str)+'\n'
    if args.output:
        args.output.write_text(text)
    if args.check:
        assert args.check.read_text()==text
    if args.output or args.check:
        for s in stages:
            X=s['proper_common_opposite_pool_witness']
            print(s['stage'],'edges',s['original_full_mark_marginal_checks'],
                  'false same-z / same physical triples',format(float(s['same_z_false_cross_fraction_of_two_actual_diagonals']),'.8f'),
                  format(float(s['same_z_and_all_three_physical_parent_labels_false_cross_fraction']),'.8f'),
                  'common pool fraction',X['common_fraction_of_smaller_pool'] if X else None)
        if args.check:
            print('byte-identical')
    else:
        print(text,end='')


if __name__=='__main__':
    main()
