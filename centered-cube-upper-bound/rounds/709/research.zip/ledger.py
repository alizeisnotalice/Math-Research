"""Exact-history geometry, floating receiver samples and completed-layer donor approximation."""
import json,math,os,random,socket,sys
from multiprocessing import get_context

def params(n,lam):
    a=32*n;g=math.log1p(-2/a);W=-math.expm1(n*g);t=math.sqrt(n)/math.log(2)
    K=8;J=math.floor(math.sqrt(n)/W);C=math.ceil((K-1)*math.sqrt(n)/W)
    rem=math.sqrt(n)-J*W
    assert 1e-10*W<rem<(1-1e-10)*W
    rs=math.exp(-C*g); rb=lam*math.sqrt(n/math.log(n))*rs*math.exp(-J*g)
    z=n*g-W/t
    def val(j):return -math.expm1(-W/t)*math.expm1(j*z)/math.expm1(z)
    big=val(J)+math.exp(J*z)*(-math.expm1(-rem/t))
    logD=n*math.log(rb/rs)+math.log(big)
    # remaining receiver value and late-shell value in units of actual V_T
    other=.5*(val(C)+math.exp(-C*W/t-n*math.log(rs))*(-math.expm1(-1/t)))
    logD+=math.log1p(math.exp(-logD)*other)
    return a,g,W,t,J,C,rs,rb,logD

def trial(job):
    n,lam,seed=job
    a,g,W,t,J,C,rs,rb,logD=params(n,lam);h=1+1/a;L=math.log(n)
    rng=random.Random(752709+n*10000+lam*100+seed)
    ell=int(-t*math.log1p(rng.random()*math.expm1(-J*W/t))/W)
    si=rb*math.exp(ell*g)
    first=min(n-1,int(math.log1p(-W*rng.random())/g));edge=(a-1)*rng.randrange(2)
    r=rs*math.exp(math.log1p(-rng.random())/n);imax=rng.randrange(n)
    s=1 if r<=1 else rs*math.exp(min(C-1,max(0,math.floor(math.log(r/rs)/g)))*g)
    ss=(s,1,1);marks=[[],[],[]];half=(1+6/n)*si
    for k in range(n):
        d=rng.randrange(1,a-1) if k<first else edge if k==first else rng.randrange(a)
        y=si*((2*d+1)/a-1)
        if abs(y)+rs+h*rs<=half: continue
        X=(r*(1 if rng.randrange(2) else -1) if k==imax else r*rng.uniform(-1,1),
           rng.uniform(-1,1),(1-2*rng.random()/a)*(1 if k%2 else -1))
        for x,sj,obs in zip(X,ss,marks):
            lo=(y-half-x)/(h*sj);hi=(y+half-x)/(h*sj)
            if lo>-1:obs.append((lo,0))
            if hi<1:obs.append((hi,1))
    res=[]
    for sj,obs in zip(ss,marks):
        blocks=[]
        for _,v in sorted(obs):
            blocks.append((v,1))
            while len(blocks)>1:
                p,m=blocks[-2];q,l=blocks[-1]
                if p*l<=q*m:break
                blocks[-2:]=[(p+q,m+l)]
        loss=-sum(k*math.log(k/m) for p,m in blocks for k in (p,m-p) if k)
        high=(si<=2*h*n*sj/L and loss>.375*L)
        res.append([int(high),int(high and si>=64*math.sqrt(n/L)*sj),loss/L])
    return [n,lam,seed,res,logD,W/t,os.getpid()]

if __name__=='__main__':
    parity,w,reps=map(int,sys.argv[1:4]);dims=list(map(int,sys.argv[4:]))
    jobs=[(n,l,k) for n in dims for l in (32,64,80) for k in range(parity,reps,2)]
    with get_context('fork').Pool(w) as pool: rows=pool.map(trial,jobs,1)
    print(json.dumps(dict(host=socket.gethostname(),python=sys.version,args=sys.argv[1:],
        workers=len(set(r[-1] for r in rows)),rows=[r[:-1] for r in rows])))
