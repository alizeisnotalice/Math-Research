"""R709 bounded continuous multiplier and exact rational finite-torus checks.

Run with /Users/zzh/.venvs/main/bin/python. Only album.json is written.
Continuous convention: sinc(t)=sin(t)/t, and s^k d_J A_s has squared
multiplier prod_J sin(t_i)^2 prod_notJ sinc(t_i)^2.
"""
from fractions import Fraction as F
from itertools import combinations, product
from pathlib import Path
import hashlib
import json
import math
import platform
import random
import sys
import mpmath as mp
import numpy as np


def stable_coordinate(t):
    if t == 0:
        return 1.0, 0.0, 0.0
    q = math.sin(t) ** 2
    if abs(t) < 0.25:
        z = t * t
        delta = z * (1/6 + z * (-1/120 + z * (1/5040 + z * (-1/362880 + z / 39916800))))
        deficit = delta * (2 - delta)
    else:
        deficit = 1 - (math.sin(t) / t) ** 2
    return (math.sin(t) / t) ** 2, q, deficit


def polynomial(coordinates, bernoulli=False):
    out = np.array([1.0], dtype=np.longdouble)
    for p, q, deficit in coordinates:
        out = np.convolve(out, np.array([p, deficit if bernoulli else q], dtype=np.longdouble))
    return out


def continuous_checks():
    mp.mp.dps = 90
    samples = []
    values = [mp.mpf(0)] + [mp.mpf(10) ** k for k in range(-300, 5, 3)]
    values += [mp.mpf(j) / 400 for j in range(1, 8001)]
    values += [mp.pi * j + mp.mpf('1e-40') for j in range(1, 21)]
    maximum = mp.mpf(0)
    for t in values:
        if not t:
            continue
        if abs(t) < mp.mpf('.25'):
            delta = mp.fsum((-1) ** (k+1) * t ** (2*k) / mp.factorial(2*k+1) for k in range(1, 31))
            deficit = delta * (2-delta)
        else:
            deficit = 1-(mp.sin(t)/t)**2
        ratio = mp.sin(t)**2 / deficit
        assert ratio <= 4
        maximum = max(maximum, ratio)
        if t in [mp.mpf('1e-300'), mp.mpf('1e-150'), mp.mpf('1e-30')]:
            samples.append({'t': str(t), 'ratio': mp.nstr(ratio, 35)})
    # Elementary global certificate, involving only exact rational constants.
    coefficient = F(38, 120)-F(361, 14400)
    assert coefficient == F(4199, 14400) and coefficient > F(1,4)
    assert F(101,120)**2 < F(3,4)
    rng = random.Random(70920261118)
    tests = []
    for stage, count, dims in [('pilot', 20, [1,2,4]), ('stress', 100, [8,16,32]), ('wider', 100, [64,128])]:
        worst = 0.0
        max_mass_error = 0.0
        for rep in range(count):
            n = dims[rep % len(dims)]
            coords = []
            for j in range(n):
                mode = (j+rep) % 7
                if mode == 0:
                    coords.append((1.0,0.0,0.0))  # exact frequency zero
                elif mode == 1 and rep % 5 == 0:
                    coords.append((0.0,0.0,1.0))  # exact nonzero integer-pi zero
                else:
                    t = (10**rng.uniform(-140,3)) if mode <= 3 else rng.uniform(-30,30)
                    coords.append(stable_coordinate(t))
            energies = polynomial(coords)
            probabilities = polynomial(coords, True)
            max_mass_error=max(max_mass_error,abs(float(sum(probabilities))-1))
            for k, (energy, probability) in enumerate(zip(energies, probabilities)):
                bound = np.longdouble(4)**k * probability
                assert energy >= 0 and energy <= bound*(1+1e-12)+np.nextafter(np.longdouble(0),np.longdouble(1))
                assert energy <= np.longdouble(4)**k*(1+1e-12)
                if k and bound:
                    worst=max(worst,float(energy/bound))
        tests.append({'stage':stage, 'cases':count, 'dimensions':dims,
                      'max_Ek_over_4k_Bernoulli':worst, 'max_Bernoulli_mass_error':max_mass_error})
    return {'global_C':4, 'rigorous_certificate':[
        '|t|<=1: sinc(t)<=1-(19/120)t^2 by the alternating Taylor bound; therefore 1-sinc^2(t)>=4199/14400*t^2>=t^2/4.',
        '1<=|t|<=2: sinc(t) is positive decreasing; sinc^2(t)<=sinc^2(1)<=(101/120)^2<3/4.',
        '|t|>=2: sinc^2(t)<=1/t^2<=1/4; sin^2(t)<=1.',
        'Thus sin^2(t)<=4(1-sinc^2(t)) globally, including t=0 by equality.',
        'Expanding prod_i[p_i+(1-p_i)z] gives nonnegative coefficients summing exactly to one. At order k, Ek<=4^k times that coefficient<=4^k.'
    ], 'mpmath_dps':90, 'one_coordinate_points':len(values)-1,
        'max_sampled_ratio':mp.nstr(maximum,35), 'tiny_samples':samples, 'mixed_tests':tests,
        'anchored_bound':'sum_{k=0}^n (4R/s)^k sqrt(binomial(n,k)) since sqrt(C)=2; numerical checks do not prove the localization step'}


def matmul(A,B):
    return [[sum((a*b for a,b in zip(row,col)), F(0)) for col in zip(*B)] for row in A]


def transpose(A):
    return list(map(list,zip(*A)))


def psd_pivots(A):
    A=[row[:] for row in A]
    pivots=[]
    for k in range(len(A)):
        pivot=A[k][k]
        assert pivot>=0
        pivots.append(str(pivot))
        if not pivot:
            assert all(A[i][k]==0 for i in range(k+1,len(A)))
            continue
        for i in range(k+1,len(A)):
            for j in range(i,len(A)):
                A[i][j]-=A[i][k]*A[k][j]/pivot
                A[j][i]=A[i][j]
    return pivots


def discrete_checks():
    rows=[]
    matrix_certificates=[]
    for L,m in [(3,2),(5,2),(5,3),(7,4)]:
        # M averages m consecutive cyclic translates; Q=m(T-I)M.
        M=[[F(sum((x+r)%L==y for r in range(m)),m) for y in range(L)] for x in range(L)]
        Q=[[m*(M[(x+1)%L][y]-M[x][y]) for y in range(L)] for x in range(L)]
        MM=matmul(transpose(M),M);QQ=matmul(transpose(Q),Q)
        A=[[16*(F(i==j)-MM[i][j])-QQ[i][j] for j in range(L)] for i in range(L)]
        pivots=psd_pivots(A)
        matrix_certificates.append({'L':L,'m':m,'C':16,'exact_PSD_pivots':pivots})
    for L,m,n in [(3,2,1),(3,2,2),(3,2,3),(5,3,2),(5,2,3)]:
        points=list(product(range(L),repeat=n))
        f={x:F((sum((j+2)*v for j,v in enumerate(x))+math.prod(v+1 for v in x))%11-5,3) for x in points}
        def shift(x,axis,d=1):
            y=list(x);y[axis]=(y[axis]+d)%L;return tuple(y)
        g=f.copy()
        for axis in range(n):
            g={x:sum((g[shift(x,axis,r)] for r in range(m)),F(0))/m for x in points}
        normf=sum((v*v for v in f.values()),F(0))/len(points)
        energies=[]
        for k in range(n+1):
            energy=F(0)
            for J in combinations(range(n),k):
                derivative=g.copy()
                for axis in J:
                    derivative={x:m*(derivative[shift(x,axis)]-derivative[x]) for x in points}
                energy+=sum((v*v for v in derivative.values()),F(0))/len(points)
            assert energy <= 16**k * normf
            energies.append(energy)
        # One fixed voxel: all shifts in {0,1}^n, with actual pointwise max.
        envelope={x:max(abs(g[tuple((xj+dj)%L for xj,dj in zip(x,delta))]) for delta in product([0,1],repeat=n)) for x in points}
        envelope_squared=sum((v*v for v in envelope.values()),F(0))/len(points)
        measured_bound=sum(math.sqrt(math.comb(n,k)*float(energies[k]))/m**k for k in range(n+1))
        analytic_bound=math.sqrt(float(normf))*sum((4/m)**k*math.sqrt(math.comb(n,k)) for k in range(n+1))
        assert math.sqrt(float(envelope_squared)) <= measured_bound+1e-12 <= analytic_bound+1e-12
        rows.append({'L':L,'m':m,'n':n,'norm_f_squared_exact':str(normf),
                     'order_energy_exact':[str(e) for e in energies],
                     'actual_voxel_sup_L2_squared_exact':str(envelope_squared),
                     'actual_voxel_sup_L2':math.sqrt(float(envelope_squared)),
                     'anchored_mixed_difference_bound':measured_bound,'analytic_bound_C16':analytic_bound})
    return {'convention':'M_m f(x)=m^-1 sum_{r=0}^{m-1}f(x+r); mixed derivative analog is m^k Delta_J M_m^{tensor n}; normalized counting L2.',
            'finite_matrix_certificates':matrix_certificates, 'actual_L2_tests':rows,
            'scope':'Exact finite rational PSD/energy/sup values only for listed L,m,n. Discrete C16 and voxel {0,1}^n are separate from continuous C4 and a continuous supremum.'}


def main():
    result={'python':sys.executable,'python_version':platform.python_version(),'numpy_version':np.__version__,
            'numpy_longdouble_bits':int(np.finfo(np.longdouble).bits),
            'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'continuous':continuous_checks(),'discrete':discrete_checks(),
            'scope':['One-coordinate C4 and Bernoulli coefficient bounds have elementary analytic proofs recorded above.',
                     'Floating mixed-frequency stress is numerical evidence, not an independent continuum proof.',
                     'Finite voxel matrices do not prove an infinite-dimensional maximal theorem.']}
    output=Path(__file__).with_name('album.json')
    output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'output':str(output),'one_coordinate_points':result['continuous']['one_coordinate_points'],
                      'max_sampled_ratio':result['continuous']['max_sampled_ratio'],
                      'mixed_cases':sum(t['cases'] for t in result['continuous']['mixed_tests']),
                      'finite_matrices':len(result['discrete']['finite_matrix_certificates']),
                      'finite_voxel_cases':len(result['discrete']['actual_L2_tests'])},indent=2))


if __name__=='__main__':
    main()
