"""Arb 256-bit interval checks for the shell ledger and the 1D positive operator."""
from fractions import Fraction as Q
import json,math,random
from flint import arb,ctx
ctx.prec=256
def F(q):
    q=Q(q);return arb(q.numerator)/q.denominator
def power(q):
    return F(q)**(arb(3)/2)
def affine(a,b,u,v):
    y=a+b*u;z=a+b*v
    if y==z:return F(v-u)*power(y)
    return F(Q(2,5)/b)*(power(z)*F(z)-power(y)*F(y))
def test(f,s,R):
    k=len(f);g=[sum((Q(f[j%k]) for j in range(i-s,i+s)),Q(0))/(2*s) for i in range(k)]
    integ=arb(0)
    for i in range(k):
        aff=[]
        for j in [i-R,i+R]:
            y=g[j%k];aff.append((y,g[(j+1)%k]-y))
        aff.append((max(g[j%k] for j in range(i-R+1,i+R+1)),Q(0)))
        cuts={Q(0),Q(1)}
        for a,b in aff:
            for c,d in aff:
                if b!=d:
                    z=(c-a)/(b-d)
                    if 0<z<1:cuts.add(z)
        cuts=sorted(cuts)
        for u,v in zip(cuts,cuts[1:]):
            a,b=max(aff,key=lambda w:w[0]+w[1]*(u+v)/2)
            integ+=affine(a,b,u,v)
    normp=sum((power(q) for q in f),arb(0))
    ratio=integ/normp
    assert ratio<(1+F(Q(256*R*R,s*s)))**(arb(3)/4)
    return float(ratio**(arb(2)/3))
rng=random.Random(70931);tests=[]
for n,s,R in [(32,2,1),(64,4,1),(96,8,1),(256,20,1),(256,20,3)]:
    for f in ([1]*n,[1+int(i<n//2) for i in range(n)],[1+int(i==0)*20 for i in range(n)],
              [100+min(i,n-i) for i in range(n)],[rng.randrange(21) for _ in range(n)]):
        tests.append(test(f,s,R))
samples={}
for r in json.load(open('mini.json'))['rows']:samples[tuple(r[:2])]=r[4]
cases=[]
for (n,lam),floating in samples.items():
    a=32*n;t=arb(n).sqrt()/arb(2).log()
    rho=arb(a-2)/a;W=1-rho**n;root=arb(n).sqrt()
    J=int((root/W).floor().unique_fmpz()); C=int((7*root/W).ceil().unique_fmpz());e=root-J*W
    rs=rho**(-C);rb=lam*(n/arb(n).log()).sqrt()*rs*rho**(-J)
    P=rho**n*(-W/t).exp()
    def bill(m):return (-(-W/t).expm1())*(1-P**m)/(1-P)
    DVT=(rb/rs)**n*(bill(J)+P**J*(-(-e/t).expm1()))+bill(C)/2+(-C*W/t).exp()*(-(-1/t).expm1())/(2*rs**n)
    assert abs(DVT.log()-floating)<arb('1e-7')
    cases.append(dict(n=n,scale=lam,full_early_layers=J,late_layers=C,
                      log10_D_over_VT=str(DVT.log()/arb(10).log()),
                      log10_excess_upper=str((1/(4*root*DVT)).log()/arb(10).log())))
print(json.dumps(dict(precision=ctx.prec,one_dimensional_tests=len(tests),
                      max_observed_norm_ratio=max(tests),ledgers=cases),indent=2))
