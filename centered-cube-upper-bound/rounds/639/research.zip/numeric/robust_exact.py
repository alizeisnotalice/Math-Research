from fractions import Fraction as F
from pathlib import Path
import json,sys,time,resource,hashlib
w=time.perf_counter();cpu=time.process_time();src=Path(__file__).with_name('old_geometry.json');x=json.loads(src.read_text());N=x['N'];n=x['n'];c=[[F(v) for v in row] for row in x['centers']];r=list(map(F,x['radii']));masks=[]
for mask in range(1,1<<N):
 ix=[i for i in range(N) if mask>>i&1]
 if all(max(c[i][j]-r[i] for i in ix)<min(c[i][j]+r[i] for i in ix) for j in range(n)):masks.append(mask)
maximal=[m for m in masks if not any(m!=z and m&z==m for z in masks)]
assert maximal==x['old_cliques'] and all(m&4 for m in maximal)
out={'input_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'n':n,'variant':x['variant'],'maximal_cliques':maximal,'common_label_index':2,'proof':'all maximal cliques contain label 2; all old lambda strictly positive; hence all load=1 cells contain label 2; any KKT mu is supported in A2; m2=M; C2(Z) contains A2, thus e2 is feasible and Q_Z=M for all admissible Z', 'python':sys.version,'cpu_s':time.process_time()-cpu,'wall_s':time.perf_counter()-w,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
print(json.dumps(out,indent=2))
