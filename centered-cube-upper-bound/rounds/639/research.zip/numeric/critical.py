#!/usr/bin/env python3
from fractions import Fraction as F
from itertools import combinations
from concurrent.futures import ProcessPoolExecutor
from hashlib import sha256
from pathlib import Path
import json,sys,os,time,resource
sys.set_int_max_str_digits(0)
def dig(x):return sha256(str(x).encode()).hexdigest()
def work(n):
 w=time.perf_counter();cpu=time.process_time();a=32*n;P=F(a+1,a)**n;eps=F(1,64)/P;u=2*eps/a**n;t=u/n;eta=3*t;d=2**n;v=F(d,a**n);m=d*(1+u);lo=F(7,8)*t;hi=t
 # Proof: (1+7t/8)^n <= 1/(1-7u/8)<1+u, while Bernoulli gives δ<t.
 assert 0<u<F(1,7) and 1/(1-F(7,8)*u)<1+u and 0<eta<F(1,100) and 0<hi<F(1,100)
 coords=[(F(0),F(0)),(F(9,5),F(0)),(F(2)+eta,F(9,5)),(F(3,5),F(14,5)),(F(-1),F(7,5))];N=5;expected={(0,1),(1,2),(2,3),(3,4),(0,4)}
 def positive_old(ix):return all(max(coords[i][j]-1 for i in ix)<min(coords[i][j]+1 for i in ix) for j in range(2))
 oldedges={p for p in combinations(range(5),2) if positive_old(p)};assert oldedges==expected
 assert all(not positive_old(p) for p in combinations(range(5),3))
 # Choose a rational positive-volume box inside each old edge intersection.
 for i,j in expected:
  lr=[(max(coords[i][q]-1,coords[j][q]-1),min(coords[i][q]+1,coords[j][q]+1)) for q in range(2)]
  mid=[(x+y)/2 for x,y in lr];h=min([F(1,4)]+[(y-x)/4 for x,y in lr]);assert h>0
  for q in range(2):assert lr[q][0]<mid[q]-h<mid[q]+h<lr[q][1]
 # For raw and shifted, isolate all 1D gaps rigorously using δ∈(7t/8,t).
 def edge_possible(i,j,shift):
  coeff=[(1 if k==0 else (-1 if k==2 else 0)) if shift else 0 for k in (i,j)]
  bounds=[]
  for q in range(2):
   base=coords[i][q]-coords[j][q];coef=(coeff[0]-coeff[1]) if q==0 else 0;z1=base+coef*lo;z2=base+coef*hi;mn=F(0) if z1*z2<=0 else min(abs(z1),abs(z2));mx=max(abs(z1),abs(z2));bounds.append((2*(1+lo)-mx,2*(1+hi)-mn))
  if all(l>0 for l,h in bounds):return True
  if any(h<0 for l,h in bounds):return False
  raise ValueError('unresolved positive-volume contact')
 raw={p for p in combinations(range(5),2) if edge_possible(*p,False)};new={p for p in combinations(range(5),2) if edge_possible(*p,True)}
 assert raw==expected and new==expected|{(0,2)}
 # All receiver cubes stay pairwise disjoint for raw and shifted actions.
 assert F(7,5)-2*hi>2*(1+hi)/a
 # Real τ supports: triple 012 in rational x-neighborhood of 1+3t/2, y near .9;
 # edge34 around (-.2,2.1). The x-coordinate margins exceed t/16 by δ bounds.
 assert F(3,2)*t-F(1,16)*t>eta-2*lo
 assert F(3,2)*t+F(1,16)*t<2*lo
 # Remaining coordinates of the two rational τ boxes lie strictly inside their covering stars.
 assert F(9,10)+F(1,20)<1 and F(9,5)-(F(9,10)-F(1,20))<1
 assert abs(F(-1,5)-F(3,5))+F(1,20)<1 and abs(F(-1,5)+1)+F(1,20)<1
 assert abs(F(21,10)-F(14,5))+F(1,20)<1 and abs(F(21,10)-F(7,5))+F(1,20)<1
 # Original KKT and exact old/new objective identities.
 Q=F(5,2)*d;V=5*v;R=F(2,a**n);M=F(5,2)*m;assert M==Q+eps*V and (m-d)/2==eps*v
 Var=5*v*v/F(d,2)-V*V/Q;assert Var==0
 Qraw=F(5,2)*m;Qshift=2*m;Vnew=F(5)*m/a**n;Draw=Vnew-R*Qraw;Dshift=Vnew-R*Qshift;assert Draw==0 and Dshift==m/a**n
 exact={'P':P,'eps':eps,'u':u,'t':t,'eta':eta,'v':v,'m':m,'lo':lo,'hi':hi,'Q':Q,'V':V,'R':R,'M':M,'Var':Var,'Qraw':Qraw,'Qshift':Qshift,'Vnew':Vnew,'Draw':Draw,'Dshift':Dshift}
 assert all(isinstance(x,F) for x in exact.values())
 return {'n':n,'a':a,'u_sha256':dig(u),'t_sha256':dig(t),'t_numerator_bits':t.numerator.bit_length(),'t_denominator_bits':t.denominator.bit_length(),'log2_t_bounds':[t.numerator.bit_length()-t.denominator.bit_length()-1,t.numerator.bit_length()-t.denominator.bit_length()+1],'raw_gap_lower':'t','shifted_edge_overlap_lower':'t/2','old_nonedge_gap':'3t','delta_bounds':['7t/8','t'],'old_graph':[list(x) for x in sorted(oldedges)],'shift_graph':[list(x) for x in sorted(new)],'old_KKT':True,'all_algebra_is_Fraction':True,'source_all_edges_m_over_2':True,'raw_Q_over_m':'5/2','shift_Q_over_m':'2','D_shift_over_V':'m/(5d)','tau_support_triple':'x=1+3t/2 width=t/16; y=9/10 width=1/20; rest width=1/20','tau_support_edge':'x=-1/5,y=21/10,width=1/20; rest width=1/20','cpu_s':time.process_time()-cpu,'wall_s':time.perf_counter()-w,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
if __name__=='__main__':
 t=time.perf_counter();ns=[2,3,4,8,16,32,64,128,256,512,1024];workers=min(os.cpu_count() or 1,15,len(ns))
 with ProcessPoolExecutor(max_workers=workers) as p:res=list(p.map(work,ns))
 print(json.dumps({'cases':res,'workers':workers,'wall_s':time.perf_counter()-t,'python':sys.version,'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest()},indent=2))
