# 直接 own-Qε 的五个冻结动作

C5 临界族的 raw 与指定 shift 均有 **Qε=Qlin**：raw 正则最优权为 (1/2)^5，Qε=5m/2、Dε=0；shift 最优权为 (1/3,1/3,1/3,1/2,1/2)，Qε=2m、Dε=m/a^n。新 receiver 在两动作中都不交，真实有序增量 w_j=m/a^n。shift 的约束 012 与 34 紧，23 与 04 均有正 slack；对应 KKT 乘子分别为 m+3εw 和 m+2εw，其他乘子为0，严格凹性给唯一正则最优。raw 的五条边均紧，每条乘子为 (m+2εw)/2。`check.py` 直接以 Fraction 检验全部乘子、可行性和互补。该严格证书说明 C5 的已有正收益来自真实线性容量下降，正则化在这个对称控制中没有额外信用；不把 Qε 解释成真实 τ 的质量。

R638 n=2 variant0 的原几何有严格结构论证：同一旧来源的线性容量在所有允许 Z 都为 M。但其旧半径和 actions 存档为双精度。以下将所存十进制值当成精确有理数构造**替代几何**，重算整个有序新族；这不是对旧精确代数半径的严格重建。

| 冻结动作 | 删零行 | Qlin（替代几何） | Qε（80位数值） | G=Qlin−Qε（数值） | Dε/Vold（数值） |
|---|---|---:|---:|---:|---:|
| raw | 原 label 3 | 10.850007212694793 | 10.850002751353845 | 4.46134e−6 | 0.28398468 |
| best_common | 无 | 10.850007212694793 | 10.849972672337785 | 3.45404e−5 | 0.73990313 |
| best | 无 | 10.850007212694793 | 10.850007212694793 | 2.76444e−16 | 0.73990790 |

每个动作的 w_i 都由实际前缀 receiver unions 以有理包含排除重算；raw 的 label 3 在 label 2 的旧先序小 cube 内，替代几何中严格包含余量约 0.00308，因此其 w3=0 并在求解新正则问题前删除。Qlin 是这个**同一删零新族**所有有理顶点的精确线性最优；不会把删除前的 linear gap 掺入 barrier gap。新的 λ 以这些真实正 w 的完整 clique 约束做 80 位 mpmath 正则 KKT 求解，结果的 stationarity 数值残差分别约 1.7e−80、8.4e−81、8.6e−65，雅可比条件数约 5.4e4、1.5e6、1.1e5；并非经过向外舍入的 Qε 数值误差证书。

对于三个**有理替代几何**，枚举的线性最优多面体顶点中存在所有最优点均强制为0的坐标。由于全部保留 w_i>0，barrier 最优 λ_i>0，故严格 Qε<Qlin；这条符号结论不用数值求根。另有理定量界如下：对每个强制零坐标 j，记所有 λ_j>0 的线性顶点到 Qlin 的最小目标缺口为 Δj>0。因每个坐标≤1、每个可行点是顶点凸组合，Qlin−d·λ≥Δj λj。新 KKT 给 λj≥εw_j/(Qlin+εVnew)，故

εw_j Δj/(Qlin+εVnew) ≤ G ≤ εVnew。

脚本取所有强制零坐标中最大的下界；raw、best_common、best 的可认证下界约 4.09e−7、4.92e−6、2.02e−21。上下界的完整精确 Fraction 字符串在 results.json。它们认证替代几何的正 barrier gap，但不认证 80 位点估计的误差范围。

尤其 best 的新 stars 中有一对在原存档标记的接触距离小于 1e−11，点估计 gap 仅约 2.8e−16；真实未圆整代数几何的 gap、其 clique 状态及正则收益都无法从这一替代计算断言。best_common 没有标记的近接触，但旧 λ 与代数半径也没有被提供可认证向外区间，故其数值仍不能上升为真实几何上的严格证书。需要对旧 KKT、rho 以及所有新几何间隙提供联合区间证明才能转移；不凭数值“成功”假设误差已足够小。

因此有限控制回答的是：C5 中线性下降已解释全部收益；在冻存的 R638 有理替代中，即便线性最优面固定到 Qlin，也可以有严格正 barrier gap，而其在实际代数几何中的定量大小尚未认证。对于一般 hard near-extremal family，统一正的 Dε 付款仍未证明。

复现：在本目录运行 `OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 /Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python check.py > results.json`。脚本只依赖相对路径 frozen_input.json 和 baseline.py；最低冻结输入注明原 R638 results 的完整 SHA256 和 index 0。Python 3.12.14、SciPy 1.18.1、SymPy 1.14.0、mpmath 1.3.0；实际 CPU 0.282 s、wall 0.248 s、峰 RSS 118,030,336 bytes。完整精确值、残差、clique 和 hash 在 results.json/SHA256SUMS。没有重复扫描旧族或调用旧 linear-capacity 搜索。
