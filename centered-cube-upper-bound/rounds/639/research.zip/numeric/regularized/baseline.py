from fractions import Fraction as F
import itertools
import numpy as np
import mpmath as mp
from scipy.optimize import linprog
mp.mp.dps=80
def intersection_rational(c,r,ids,n):
 z=F(1)
 for j in range(n):
  d=min(c[i][j]+r[i] for i in ids)-max(c[i][j]-r[i] for i in ids)
  if d<=0:return F(0)
  z*=d
 return z

def old_v(c,r,n,a):
 v=[]
 for j in range(len(r)):
  vol=F(0)
  for mask in range(1<<j):
   ids=[i for i in range(j) if mask>>i&1]+[j];term=intersection_rational(c,[x/a for x in r],ids,n);vol += (-1 if mask.bit_count()%2 else 1)*term
  v.append(vol)
 return v

def cliques_exact(c,r,n):
 masks=[mask for mask in range(1,1<<len(r)) if intersection_rational(c,r,[i for i in range(len(r)) if mask>>i&1],n)>0]
 return [m for m in masks if not any(m!=k and m&k==m for k in masks)]

def oldkkt(d,v,eps,A):
 N=len(d);K=A.shape[0];lp=linprog(-np.array(list(map(float,d))),A_ub=A,b_ub=np.ones(K),bounds=(0,None),method='highs');assert lp.success
 lam0=lp.x;dual0=-lp.ineqlin.marginals; initial=tuple(i for i in range(K) if dual0[i]>1e-8)
 def M(q):return mp.mpf(q.numerator)/q.denominator
 cv=[M(eps)*M(z) for z in v];dm=[M(z) for z in d]
 active_sets=[initial]+[x for k in range(1,K+1) for x in itertools.combinations(range(K),k) if x!=initial]
 for active in active_sets:
  if not active:continue
  guess=[]
  for j in range(N):
   slack=sum(mp.mpf(str(dual0[k]))*int(A[k,j]) for k in active)-dm[j]
   guess.append(mp.mpf(str(lam0[j])) if lam0[j]>1e-6 else cv[j]/max(slack,mp.mpf('0.00000001')))
  guess += [max(mp.mpf(str(dual0[k])),mp.mpf('0.00001'))*(1+mp.mpf('1e-7')) for k in active]
  def eq(*x):
   l=x[:N];u=x[N:];return tuple([l[j]*(sum(u[t]*int(A[k,j]) for t,k in enumerate(active))-dm[j])-cv[j] for j in range(N)]+[sum(l[j]*int(A[k,j]) for j in range(N))-1 for k in active])
  try:
   sol=mp.findroot(eq,tuple(guess),tol=mp.mpf('1e-60'),maxsteps=100,solver='mdnewton');lm=list(sol[:N]);mu=list(sol[N:]);
   if min(lm)<=0 or min(mu)<=0:continue
   load=[sum(lm[j]*int(A[k,j]) for j in range(N)) for k in range(K)]
   if max(load)>1+mp.mpf('1e-35'):continue
   station=[dm[j]+cv[j]/lm[j]-sum(mu[t]*int(A[k,j]) for t,k in enumerate(active)) for j in range(N)]
   J=mp.matrix(mp.calculus.optimization.jacobian(mp.mp,eq,tuple(sol)));cond=mp.cond(J)
   return [float(q) for q in lm],{'active_cliques':active,'dual':[str(x) for x in mu],'lambda':[str(x) for x in lm],'stationarity_max':str(max(map(abs,station))),'constraint_max':str(max([max(q-1,mp.mpf(0)) for q in load])),'min_lambda':str(min(lm)),'jacobian_condition':str(cond),'mpmath_dps':mp.mp.dps}
  except (ValueError,ZeroDivisionError,OverflowError):continue
 raise ValueError('no valid high-precision active set')

