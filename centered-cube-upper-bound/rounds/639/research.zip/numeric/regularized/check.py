#!/usr/bin/env python3
import sys,time,json,resource,hashlib,importlib.util
from fractions import Fraction as F
from pathlib import Path
import numpy as np
import itertools
import sympy as S
from scipy.optimize import linprog
from scipy import __version__ as scipy_version
import mpmath as mp
T=time.perf_counter();cpu=time.process_time();sys.set_int_max_str_digits(0)
sp=importlib.util.spec_from_file_location('baseline',Path(__file__).with_name('baseline.py'));base=importlib.util.module_from_spec(sp);sp.loader.exec_module(base)
oldpath=Path(__file__).with_name('frozen_input.json');old=json.loads(oldpath.read_text());n=old['n'];a=32*n;eps=F(1,64)/F(a+1,a)**n
assert n==2 and old['variant']==0
# C5 exact numeric instance and exact KKT gradients, plus algebraic formula generalizes n.
d=F(2**n);v=d/a**n;m=d+2*eps*v;w=m/a**n;R=F(2,a**n);Vnew=5*w
rawlam=[F(1,2)]*5;shiftlam=[F(1,3)]*3+[F(1,2)]*2
Araw=[[1 if j in e else 0 for j in range(5)] for e in [(0,1),(1,2),(2,3),(3,4),(0,4)]]
Ash=[[1 if j in e else 0 for j in range(5)] for e in [(0,1,2),(2,3),(3,4),(0,4)]]
for A,lam,dual in [(Araw,rawlam,[(m+2*eps*w)/2]*5),(Ash,shiftlam,[m+3*eps*w,F(0),m+2*eps*w,F(0)])]:
 assert all(sum(F(x)*l for x,l in zip(row,lam))<=1 for row in A)
 for j in range(5):assert m+eps*w/lam[j]==sum(dual[i]*A[i][j] for i in range(len(A)))
 assert all(z>=0 and (z==0 or sum(F(x)*l for x,l in zip(row,lam))==1) for z,row in zip(dual,A))
Qraw=sum(m*l for l in rawlam);Qshift=sum(m*l for l in shiftlam)
assert Qraw==F(5,2)*m and Qshift==2*m and Vnew-R*Qraw==0 and Vnew-R*Qshift==m/a**n
def exact_linear(dvals,A):
 N=len(dvals); rows=[[int(z) for z in row] for row in A]+[[int(i==j) for j in range(N)] for i in range(N)]; rhs=[1]*len(A)+[0]*N;best=None;solutions=[];vertices=[]
 for ix in itertools.combinations(range(len(rows)),N):
  B=S.Matrix([rows[i] for i in ix]);
  if B.det()==0:continue
  sol=B.inv()*S.Matrix([rhs[i] for i in ix]);
  if any(x<0 for x in sol) or any(sum(S.Rational(int(row[j]))*sol[j] for j in range(N))>1 for row in A):continue
  val=sum(S.Rational(q.numerator,q.denominator)*sol[j] for j,q in enumerate(dvals))
  vertices.append((val,sol))
  if best is None or val>best:best=val;solutions=[sol]
  elif val==best:solutions.append(sol)
 assert best is not None
 forcedzero=[j for j in range(N) if all(v[j]==0 for v in solutions)]
 separations={j:min(best-val for val,sol in vertices if sol[j]>0) for j in forcedzero}
 return F(int(best.p),int(best.q)),forcedzero,len(solutions),{j:F(int(z.p),int(z.q)) for j,z in separations.items()}
out={'critical_C5':{'m':str(m),'w':str(w),'R':str(R),'Vnew':str(Vnew),'raw':{'lambda':list(map(str,rawlam)),'Qlin':str(Qraw),'Qeps':str(Qraw),'Dlin':'0','Deps':'0'},'shift':{'lambda':list(map(str,shiftlam)),'Qlin':str(Qshift),'Qeps':str(Qshift),'Dlin':str(m/a**n),'Deps':str(m/a**n)},'proof':'exact strictly concave KKT with rational positive weights and matching dual'},'r638_actions':[]}
rho=[F(str(x)) for x in old['rho']];c0=[[F(q) for q in row] for row in old['centers']];s=list(map(F,old['radii']));delta=[rho[i]-s[i] for i in range(6)];oldv=sum(map(F,old['v_exact'])); oldd=[(2*x)**n for x in s]; oldl=list(map(mp.mpf,old['old_diag']['lambda'])); Vold=mp.mpf(oldv.numerator)/oldv.denominator; Qold=sum(oldl[i]*mp.mpf(oldd[i].numerator)/oldd[i].denominator for i in range(6));Rold=Vold/Qold
for name in ['raw','best_common','best']:
 try:
  z=old[name]['z'];C=[[c0[i][j]+delta[i]*F(str(z[i][j])) for j in range(n)] for i in range(6)];vf=base.old_v(C,rho,n,a)
  keep=[j for j,x in enumerate(vf) if x>0];assert keep
  Cred=[C[j] for j in keep];rred=[rho[j] for j in keep];vred=[vf[j] for j in keep];N=len(keep)
  masks=base.cliques_exact(Cred,rred,n);A=np.array([[int(q>>j&1) for j in range(N)] for q in masks],float);df=[(2*r)**n for r in rred]
  qlin_exact,forcedzero,optcount,separations=exact_linear(df,A)
  lower=max((eps*vred[j]*separations[j]/(qlin_exact+eps*sum(vred)) for j in forcedzero),default=F(0));upper=eps*sum(vred)
  lam,diag=base.oldkkt(df,vred,eps,A);lmp=list(map(mp.mpf,diag['lambda']));dm=[mp.mpf(q.numerator)/q.denominator for q in df];Qeps=sum(x*y for x,y in zip(lmp,dm));V=mp.mpf(sum(vred).numerator)/sum(vred).denominator;Qlin=mp.mpf(qlin_exact.numerator)/qlin_exact.denominator;Dlin=V-Rold*Qlin;Deps=V-Rold*Qeps;gap=Qlin-Qeps
  out['r638_actions'].append({'action':name,'retained':keep,'w_all':list(map(str,vf)),'deleted_zero':[j for j in range(6) if j not in keep],'positive_cliques':masks,'Qlin_rational':str(qlin_exact),'optimal_face_forced_zero_local_indices':forcedzero,'linear_optimal_vertex_count_with_duplicates':optcount,'positive_barrier_gap_proved_for_rational_surrogate':bool(forcedzero),'rational_surrogate_gap_lower':str(lower),'rational_surrogate_gap_upper':str(upper),'Qeps_mp':str(Qeps),'Vnew_rational':str(sum(vf)),'Dlin':str(Dlin),'Deps':str(Deps),'Deps_over_Vold':str(Deps/Vold),'gap':str(gap),'identity_residual':str(Deps-Dlin-Rold*gap),'old_input_near_tangent_pairs':old[name]['near_tangent_pairs'],'rho_input_note':'R638 stored double precision numbers interpreted as exact rational perturbation, not certified exact canonical geometry','KKT':diag})
 except Exception as e:out['r638_actions'].append({'action':name,'error':repr(e)})
out['run']={'python':sys.version,'scipy':scipy_version,'sympy':S.__version__,'mpmath':mp.__version__,'cpu_s':time.process_time()-cpu,'wall_s':time.perf_counter()-T,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'frozen_input_sha256':hashlib.sha256(oldpath.read_bytes()).hexdigest(),'original_source_sha256':old['original_sha256'],'original_index':old['original_index'],'helper_sha256':hashlib.sha256(Path(__file__).with_name('baseline.py').read_bytes()).hexdigest(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
print(json.dumps(out,indent=2))
