# R639 独立 screen：切掉旧最优面能付多少真实容量

只读 CONTRACT 与主代理初始命题；未读作者新证明，未扫描反例、求解 LP 或改仓库。以下是一个有限 LP 条件筛查，不是一般预算结论。

## 1. 固定同一动作与完整量词

对同一次全族位移 Z，令

\[
P_0=P_{\rm old}\subset[0,1]^N,\quad
P_Z=P(Z)\subset P_0,\quad
M=\max_{\nu\in P_0}m\cdot\nu,
\]

\[
F_0=\{\nu\in P_0:m\cdot\nu=M\},\quad
S(Z)=M-\max_{\nu\in P_Z}m\cdot\nu.
\]

P0、PZ 都是完整实际正体积 cube-clique packing polytopes，非空且紧；所有 C_j(Z) 包含旧 A_j，使 PZ⊂P0。边界零体积交不加约束。m、M 固定于整个旧 KKT 类，不随 μ 的 cell 内重排或 Z 改变。

完整目标是一个共同 Z（或合法分布）使

\[
V_Z-RM+RS(Z)\ge cV-CL_nM.
\]

所有 face/cut/receiver 项必须来自同一 Z；不能先按不同旧最优点或 clique 各选有利但互相矛盾的位移。

## 2. 精确切面只保证有限严格 gap

由紧性和实际最优达到，

\[
\boxed{S(Z)>0\iff F_0\cap P_Z=\varnothing.}
\]

这是固定有限问题的严格正数，不包含维数统一、标签数统一或尺度统一的下界。它也不意味着 D>0：完整 receiver 缺额 RM−VZ 仍需 R·S 一同支付。

设实际新 cuts 为 `a_K·ν=Σ_{j∈K}ν_j≤1`，定义 whole-face violation

\[
\chi_Z=\min_{\nu\in F_0}\max_K(a_K\cdot\nu-1).
\]

在 F0∩PZ 为空时，χZ>0。finite minimax 给一份**共同**新 cut 概率向量 q_K≥0、Σq_K=1，使

\[
\min_{\nu\in F_0}\phi_q(\nu)=\chi_Z,
\qquad \phi_q(\nu)=\sum_Kq_K(a_K\cdot\nu-1).
\]

因为 ν≥0，始终有 φq≥−1。这里 q 不是逐旧最优点重选的一份不同对象。

## 3. 可用的精确定量桥：必须保留旧 normal 的 conditioning 价格

定义 normalized nonface-vertex objective gap

\[
\Delta_0=\min_{v\in\operatorname{vert}(P_0)\setminus F_0}
\frac{M-m\cdot v}{M}>0.
\]

该集合非空（0∈P0 且 M>0）；有限顶点保证 Δ0 对固定问题严格正。合同没有给它对 N、尺度、λ 或步骤统一的下界。

若 χZ>0，则有下面不带额外 N-Lipschitz 因子的有限定量式：

\[
\boxed{S(Z)\ge M\Delta_0\frac{\chi_Z}{1+\chi_Z}.}\tag{Q}
\]

证明：把任意 ν∈PZ 分解为旧顶点的凸组合，设非 F0 顶点的总权为 α。face 部分的 φq 至少 χZ，非face部分至少 −1，而 φq(ν)≤0。因此

\[
0\ge\phi_q(\nu)\ge(1-\alpha)\chi_Z-\alpha,
\quad\alpha\ge\frac{\chi_Z}{1+\chi_Z}.
\]

另一方面 `(M−m·ν)/M≥αΔ0`，取 ν∈PZ 的最优即得 (Q)。

所以 whole-face cutting 可转为容量 gap，**但 Δ0 这个 off-face 价格不能删除**。若作者只证明 χZ 与真实 overlap/receiver 有统一比较，而不控制 Δ0 或用另一份 full-polytope 价格替代它，尚不够得到统一净目标。

(Q) 是一个可供实际候选使用的条件桥，不证明本轮存在相应 Z，也不提供 Δ0 的一般 cube/KKT 下界。

## 4. 为什么直接把 full infimum 限到旧 face 方向不对

令 `g(ν)=M−m·ν`。有限 LP 的正确 Lagrange 下界是

\[
S(Z)=\sup_{p_K\ge0}\min_{\nu\in P_0}
\left[g(\nu)+\sum_Kp_K(a_K\cdot\nu-1)\right].
\]

即使不使用等号，任何固定 p 的 **full P0 minimum** 都给合法下界。直接改成

\[
\min_{\nu\in F_0}\sum_Kp_K(a_K\cdot\nu-1)
\]

会缩小 minimization 域、抬高数值，不能继续当作 S 的下界。真正新最优点可稍离旧 face，以少量 objective loss 避开旧 face 上显著的新 overload。

在第 3 节的 paid criterion 中，可合法作 face reduction，但须缩放 multiplier：取

\[
p_K=M\theta q_K,\quad \theta=\Delta_0/(1+\chi_Z).
\]

face 顶点的 `g+Mθφq≥MθχZ`；非face顶点的 `g+Mθφq≥MΔ0−Mθ=MθχZ`。线性函数在整个 P0 的 minimum 因而恰等于 face minimum `MθχZ`，得到 (Q)。这明确说明为什么 multiplier/normal 的 off-face conditioning 不能无价跳过。

也可另证 Hoffman/weak-sharp 型常数或直接 full-P0 separation；但必须展示其常数怎样进入全族 receiver 账，而非只引用有限问题“存在某常数”。

## 5. 回代完整目标与 near-S_N：尚缺哪一条

由 (Q) 得到一个真正足够、但尚未证可实现的筛查条件：同一个 Z 满足

\[
V_Z-RM+RM\Delta_0\frac{\chi_Z}{1+\chi_Z}
\ge cV-CL_nM.
\]

或者证明更好的 full-polytope 容量下界以替代其中的 Δ0 χZ/(1+χZ)。这必须覆盖所有 N、全部真实尺度及 receiver overlap，而不只证明 χZ>0。

near-S_N 只给每个合法 Z 的

\[
V_Z-RM+RS(Z)\le\delta M.
\]

它不提供 Δ0、χZ 或其乘积的统一下界，不把旧 source 饱和转成对所有 near-face 点的稳定性，也不允许 μ 驻点/normal compactness 假设。固定有限族的严格容量 gap 可以随近极值族/δ 一同退化；而且可能被 RM−VZ 完整吸收。因此“切掉所有旧最优点”本身不与 near 上帽矛盾。

## 6. 需要作者下一候选明确给出的有限条件

- 同一完整 Z 的全部新正体积 cuts，与实际 receiver VZ；不按 face 点分别优化几何。
- 是仅 F0∩PZ 为空，还是给出了 χZ 的明确量化。
- off-face 价格：Δ0 的合法统一下界，或另一份保留 full P0 的 priced separation。不得只把 infimum 域缩到 F0。
- R·capacity gap 与实际 receiver 缺额的净比较；不能将 S>0、clique 数增长或旧 face 空交命名为完整预算。
- 常数独立于 N、最小尺度/质量、旧 λ_min 和步骤，或把任何依赖全部显式回代并证明可接受。

本机 SymPy 1.14.0 轻量核验 θ 的 outside-vertex 等价、face/nonface 混合系数及完整 saving 账，三个符号残差为 0。未做新例或数值扫描。

**当前 screen 结论：精确 face-empty 给有限严格 gap；(Q) 给有 off-face 价格的定量桥。缺少统一 conditioning 或直接 full-polytope 预算时，不能仅凭旧 face reduction 认证所需全局收益。停止等待实际候选。**

## 7. 重要 route-scope 追加：直接新 Qε 目标合法，线性容量目标并非必要

本节核对实际权威接口：`/tmp/ccu_r634/terminal_audit.md` §1–4、`/tmp/ccu_r635/source_choice_audit.md` §1、§5、`/tmp/ccu_r635_final/REPORT.tex` 的 near-S_N 节，以及 `/tmp/ccu_r637/BASE.md`。这些定义中的 S_N 分母确实是 **本族自己的 regularized 最优权的 linear part**，不是 linear packing optimum，也不是带 log 的总目标。

**范围判定：YES。** 原最终弱型目标可以采用下面更弱的完整更新合同；不必额外证明一份 AC 容量 τ 的质量等于 Qε,new。它放宽了 R638 的特定 τ/linear-capacity 充分接口，并不伪称构造了那份通常不存在的 τ。

### 7.1 精确弱化后的充分目标

对每个完整 hard old family，存在一份共同旧真实 KKT μ 和一个同 μ 合法的新有序有限族 F′，使删零增量后标签数≤旧上限 N，并满足

\[
\boxed{D_\epsilon:=V'-R Q_{\epsilon}(F')
\ge cV-CL_nM.}\tag{E}
\]

这里固定相同 a、H、ε；V′ 是实际新 receiver union。新实际顺序 increments 记 w_l>0，且

\[
\lambda'=\arg\max_{L_\alpha^{F'}\le1,\alpha_l>0}
\left[d'\cdot\alpha+\epsilon\sum_lw_l\log\alpha_l\right],
\qquad Q_\epsilon(F')=d'\cdot\lambda'.
\]

不能用旧 increments、旧 λ、任意人为小权或带 log 的目标值冒充这个 denominator。新顺序可以是一次共同合法选择，但必须据它重算全部真实 w_l，不能按被收费来源分别重排。

同 μ 的 witness 关系给出直接、无需 τ 的比较：

\[
Q_\epsilon(F')=\sum_l\lambda_l'd_l'
\le\sum_l\lambda_l'\mu(C_l)
=\int L_{\lambda'}^{F'}d\mu\le M.
\]

这只是 λ′ 的 packing 可行性，不把 Qε 叫作实际来源/容量上界。

### 7.2 原 near-S_N 与有限 N 终端直接适用

新比率精确为 `R′=V′/Qε(F′)`。对 R>S_N−δ 的旧族，因 F′ 属于同一≤N、同一 ε 的有序纯几何类，

\[
\boxed{D_\epsilon=Q_\epsilon(F')(R'-R)
<\delta Q_\epsilon(F')\le\delta M.}
\]

若 (E) 对全部 hard families 有统一常数，预先取 H 足够大，使 hard 中 `Dε≥cV/2`，则

\[
R'-R\ge\frac{cV}{2M}
>\frac{3c}{8\epsilon},
\]

因为 `V/M=β/ε` 且 β>3/4。它给真正的统一正增幅，R′ 保持 hard。每一步可在新族自己的 λ′ 上重新构造真实 KKT 来源；不沿用旧 μ 冒充新 KKT。所有步骤不增标签、a/ε 不变，R634 的固定 N 终端遂给原反证。或者直接与上述 near 上帽矛盾。

因此没有实际 τ 质量 Qε 并不妨碍这条路线。初始任意 f 的恢复仍用其真实 witnesses 与可行 λ 给 `Qε≤∫fLλ≤||f||1`，不是把 Qε 当作 source mass。

### 7.3 与 linear 目标的准确关系和剩余熵价格

在同一个**已删零、同序的新族**上，令

\[
G_\epsilon=Q_{\rm lin}(F')-Q_\epsilon(F')\ge0.
\]

则

\[
\boxed{D_\epsilon=D_{\rm lin}+RG_\epsilon.}
\]

所以原 linear/实际容量目标足够但更强；必须切掉旧 linear 最优面的 criterion 也不再是直接 (E) 的必要条件。

现有一阶最优性只给，对任一新 linear 最优 αlin，

\[
0\le G_\epsilon
\le\epsilon\sum_lw_l\left(1-\frac{\alpha_{{\rm lin},l}}{\lambda_l'}\right)
\le\epsilon V'.
\]

这是上界，不能把 εV′ 或 RGε 的最大许可值当作已获得的正信用。必须使用实际新 barrier/geometry 来证明下界或直接证明 (E)。若与删零前完整 linear capacity 比较，另有 nonnegative deletion gap；它要单列，不能把该 gap 一并冒称≤εV′ 的 barrier gap。

所有 overlap、真实中心位移、实际 V′ 与新 w_l、row 删除/选择、同 ε 的 log 权、步骤后的 `M′=Qε′+εV′` 均须保留。将 ν 的 linear 最优性改成 λ′ 的 regularized 最优性时，合法支持梯度是 `d_l′+εw_l/λ_l′`，不是 d_l′；不能无价套用旧 linear exchange 式。

### 7.4 正 barrier 权能消除哪种零权问题，不能消除什么

所有保留的 w_l>0，使 λ_l′>0，因此直接正则化机制无需让某个 old linear-face vertex 成为新实际最优权；零坐标顶点的 log 目标为 −∞，不可能是 barrier argmax。这可避免“新 linear owner 恰有 ν_l=0”作为某些付款机制的硬零。

但它没有删除 packing polytope 的零顶点，也没有统一下界 `λ_l′≥c`。新 KKT 只给如 `λ_l′≥εw_l/M′` 的 row-dependent 下界；w_l 可很小。全正不代表 quantitative source credit、gap 或正 Dε。真实零增量行先删；不能声称对已删除行仍有正 barrier 权，不能删除正增量后继续沿用原 V′。

旧 whole-row τ 规则的 no-go 仍正确，但它约束实际 B=||τ||。没有 B 与 Qε 的额外比较时，不能直接把该 no-go 套成 (E) 的 no-go。

### 7.5 本动作 strict endpoint 的新正则化处理

当前 ratio/near 类本来是所有有序纯几何有限族，且 `Qε′≤M` 只需非严格 witnesses。因此在纯几何反证中，不需要额外假设新 μ 中心本身严格坏。

若沿既有接口要求 strict 更新，不能仅引用 Qlin 的 endpoint 连续性来替代 Qε。合法处理为：

1. 在端点新族按实际顺序**先删零增量**，固定剩余有限顺序，所有端点 w_l^0>0。
2. 仅对这些 retained rows 使用 R638 已审同步 inward-shift/radius 收缩。它保留同 μ 并使每行 strict；完整 positive-clique polytope 最终稳定。
3. 新 receiver 的各个 prefix union 测度连续，故 w_l^η→w_l^0>0，足够小 η 时所有 retained w_l^η 仍正。
4. 在固定 polytope 上 d^η、w^η 连续。正 barrier 最优不可能趋近 λ_l=0：该 log 项系数有固定正下界、其它 log≤0、linear 部分有界，而一个共同严格正可行点给统一有限 baseline。故最优权在这个固定 family 邻域内远离零，唯一最优性给 λ^η→λ^0，进而 Qε^η→Qε^0。

因此已证正 Dε margin 可保留，标签数不增，不要求任何跨 family 的 λ_min 常数。不能不删 endpoint 零行就默认 barrier continuity；极小正 w 的行与实际删除行属于不同 entropy 问题。

## 8. S∞/新增标签的权限：现有证明尚不提供

实际已证终端只有

\[
S_N\le G(N,a,\epsilon)
=\frac{N}{2a^n}\left[1+\sqrt{1+\frac{4a^n}{\epsilon N}}\right]<\infty.
\]

它依赖 N，随 N 增长无统一有限上界。因此当前可定义 `S∞=sup_N S_N` 为扩展实数，但所核 R634/635/638 文献没有证明它有限。不能据此让每步增加标签，或以旧 near-S_N 的上帽比较一个>N 的新族。仅“每一步仍有限”不提供终端。

经典 weak bound B_n 给 `V≤P B_n Qlin`，配现有 barrier gap只能推出

\[
R\le P B_n(1+\epsilon R).
\]

只有另有 `εPB_n<1` 时，才得到 N-independent 的

\[
S_\infty\le\frac{PB_n}{1-\epsilon PB_n}.
\]

当前 ε=(2PH)^{-1} 下该条件是 B_n<2H，不能从已知 nlogn 界对 intended root H 自动推出。没有权威证明时，不能把经典 Qlin 弱型界直接移成 fixed-ε 的 uniform regularized bound；也不据此反断 S∞ 实际无穷。

若以后要允许 added labels，需另证统一 S∞ 终端、统一 label 上限、或包含 N_k 增长的真实累计终端。当前两条安全逻辑仍是同一≤N的 near argument 和不增标签迭代。

**scope 最终决定：直接 own-Qε 更新是合法且严格更宽的充分路线；无需不可能的 τ=Qε 质量解释。它必须保留真实 receiver/entropy/label 全账，且尚无一般净收益。当前没有 S∞ 或任意加标签权限。完成量词审查，停止待后续机制。**

本次追加实际调用本机 SymPy：核验 `Dε−Dlin−R(Qlin−Qε)=0`、hard additive 系数 3/8，以及既有终端的 `lim_{N→∞}G(N)/N=a^(−n)`。最后一项仅说明**这个已有上界**不统一于 N，不是证明实际 S_N 或 S∞ 发散。

## 9. scope 最终核验：原任意输入恢复不额外乘 P

这里是**条件恢复引理**，不是已证明一般根阶上界。假定将来确实证明，对同一 a、ε 的所有有序有限几何族，有统一、与标签数无关的

\[
V/Q_\epsilon\le K_n.
\]

取任意非负 f∈L1、阈值 α>0、紧 `F⊂{M_nf>α}`。对每个 x∈F 选一个原算子见证半径 R_x，使

\[
\int_{Q(x,R_x)}f>\alpha(2R_x)^n.
\]

令小 receiver `B_x=Q(x,R_x/a)`、大星 `A_x=aB_x=Q(x,R_x)`。所有 B_x 是 F 的开覆盖，取有限子覆盖，按固定顺序形成实际 increments、删零行，并求本族自己的 regularized 最优 λ。令 V 是该实际 union 的测度。则

\[
\alpha|F|\le\alpha V
\le K_n\alpha Q_\epsilon
=K_n\alpha\sum_j\lambda_j|A_j|
\le K_n\int fL_\lambda
\le K_n\|f\|_1.
\]

原超水平集开，内正则性恢复整个集合；对一般 signed 输入取 |f|。所有 R_x 任意正，不需尺度截断或新 threshold，也不要求原 f 是辅助 KKT μ。

**因此这个恢复入口没有额外 receiver-halo P。** 小 receivers 虽缩成原见证的 1/a，仍因每个原超水平点都给一只中心在该点的小 cube 而覆盖 F；不需声称这些小 cubes 全部处于原 Eα。

若未来 hard 排除给 `K_n=6PH`，最终是条件式

\[
C_n\le6PH\le6e^{1/32}H\qquad(a\ge32n),
\]

而不是再乘一个 P。这里已有 P 来自冻结参数/阈值，不是恢复中新产生的费用。

与此不同，R634 为从**已知 weak bound**反向控制一个任意 μ-可行 family 所用的 `V≤PB_nQlin`，确实需要把 receiver 放入 `{Mμ>1/P}` 的 halo 因子 P。两条推导方向和输入不同，不能互换或重复计费。

最终归档/README 必须保留以下范围：

- 固定 N 的 G(N,a,ε) 只证明每个 S_N 有限；N 可随原输入/紧覆盖变化，故它本身不提供上述统一 K_n，也不提供新的弱型上界。
- 只有尚未证明的完整 own-Qε 正更新（或其它统一机制）先排除所有 hard finite families，才可把这一恢复引理用于原任意 f、全尺度目标。
- R637/638 的有限 nonhard 正控制、Qlin/Qε 数值比较和本轮 scope 弱化都不等于该排除已完成。

**原输入恢复的 P/receiver 尺度核验通过；目前全局净更新未证。完成最终量词审查，停止待命。**
