# R639 own-Qε 五动作证书独审（Sol high）

只读核对 `numeric/regularized/REPORT.md`、`check.py`、`baseline.py`，并检查现存结果完整性与后加的交付验证器；没有重跑整批、没有改代码或其他文件。

**判定：所声称的两份 C5 解析 KKT、三份有理替代几何的 exact linear face/正 barrier-gap 下界，数学上通过。** 一个复现风险必须明确：`check.py` 自身的 exit0 不等于全部动作成功，交付验收必须运行最终 `verify.py`。原真实未圆整几何的 gap、80位点估计的误差和一般根阶目标均不获本审核认证。

## 1. 两个 C5 动作的解析证书正确

这里使用已核的 critical C5 实际 old/raw/shift 几何：新 receiver 两动作中均不交，每个真实增量 w=m/a^n>0，需求均为 m。

raw 五条 edge 约束下 λ=(1/2)^5，梯度各为 m+2εw；每条 edge 的乘子取(m+2εw)/2，恰覆盖每行梯度且全为正。五条 edge 全tight，所以 KKT和互补成立。

shift 的 maximal constraints 为012、23、34、04。λ=(1/3,1/3,1/3,1/2,1/2)的012与34载荷1，另两条为5/6；乘子分别m+3εw、0、m+2εw、0，恰给所有行梯度。全部λ>0、w>0使 barrier目标严格凹，因此两点均为各自全局唯一正则最优。

线性最优也准确：raw五edge相加给Σλ≤5/2；shift用012与34两个约束给Σλ≤2。所列权达到对应上界，因此 Qε=Qlin=5m/2和2m。以实际 Vnew=5m/a^n、旧R=2/a^n回代，raw Dε=0、shift Dε=m/a^n，均为精确Fraction式。这不把一般Qε当作可行τ质量；此对称控制中只是已另证Qε恰等于Qlin。

## 2. 有理替代几何、删零与完整顶点枚举

程序将 frozen rho和shift的十进制浮点表示经`Fraction(str(...))`定义为确切rationals，旧centers/radii是rational字符串。这定义的是三份新的有理替代几何，**不是**原未圆整代数几何的有误差认证重建。REPORT已经明确此边界。

`baseline.old_v`对每个前缀使用确切rational包含排除，计算真实 receiver增量；`cliques_exact`按各坐标严格正交长枚举全部子集，再保留maximal cliques，点/面接触不构成positive clique。np矩阵只存精确可表示的0/1，exact linear部分转回int/SymPy rational，无浮点几何判断。

raw的原label3增量为0，求新barrier前删去；其余动作保留全部6行。删除零增量只改union零测，后续保留行的增量体积不变，故vred仍是同一删后顺序的真实正增量。程序用**同一删后族**重建stars、cliques、df、linear optimum和barrier目标，未混入删除前Qlin。保留zero-row的另一优化问题可能有不同值，不能把本结果移回那个问题。

`exact_linear`枚举clique上界和所有坐标zero hyperplanes中N个线性独立活动等式，解后精确检查非负与全部clique约束。该packing polytope有界且full-dimensional，每个vertex均含N个独立活动约束，所以枚举覆盖全部vertices。把active下界的等式写成+e_j·λ=0而不是−e_j·λ=0不改变解。重复vertex/不同basis只影响count，不影响最优值与face判断，结果字段也注明with-duplicates。

线性最优face是全部最优vertices的凸包。因此“所有最优vertices在坐标j为0”精确推出“所有最优点该坐标为0”。现存结果三动作均有这样的坐标，且所有保留w>0，所以其barrier最优全正，不可能在线性最优face中；Qε<Qlin的符号结论不依赖数值findroot。

## 3. Δ_jλ_j 与显式正下界：方向、分母均合法

对一个forced-zero坐标j，令Δ_j为所有vertex中该坐标>0者的最小linear objective gap。集合非空（e_j可行），最小gap严格为正。每个packing坐标≤1；对任意可行λ作vertex凸组合，

    Qlin−d·λ
      ≥Δ_j Σ_{vertex p:p_j>0}weight(p)
      ≥Δ_j λ_j.

所以该下界方向正确，不是按某个数值λ猜出的gap。

对同一正增量新族的真barrier最优λ，沿可行方向e_j−λ的一阶最优性给

    d_j+εw_j/λ_j≤Qε+εVnew≤Qlin+εVnew.

可行线段在端点前保持全正，因此比较e_j不需要把barrier定义到zero边界。这也可由finite-cell KKT来源的单行质量≤总质量得到。于是确有

    λ_j≥εw_j/(Qlin+εVnew),
    Qlin−Qε≥εw_jΔ_j/(Qlin+εVnew)>0.

对多个forced-zero坐标取各合法下界的**最大值**正确，不能无证相加。上界Qlin−Qε≤εVnew同样由正则一阶最优性比较线性最优点得到，针对的也是同一删后族。结果中的三个精确rational下界均正、且≤所列精确上界；读数约4.09e−7、4.92e−6、2.02e−21只作阅读辅助。

这些量认证的是有理替代几何的真Qε gap区间；不认证80位Qε点估计的误差范围，更不认证原真实代数几何的gap。

## 4. 数值 KKT、异常捕获与交付验收

`baseline.oldkkt`用SciPy初值与80位mpmath尝试活动集，允许数值载荷误差并报告stationarity/条件数；这不是向外区间证书。旧R用于Dε/Vold读数也来自未认证的数值λ。REPORT把这些点值、D值及其原真实几何转移明确列为数值证据，此范围正确；尤其best动作的极小gap不能靠“80位求根成功”上升为原几何结论。

**复现缺陷：** `check.py`的外层`except Exception`会将某动作失败写成`{'action':..., 'error':...}`后继续，最后正常打印JSON并exit0。它可能同时吞掉exact枚举/边界断言或数值KKT失败。因此仅凭shell exit0、JSON可解析或文件存在，可能静默误报“全部成功”。这不使现存三条记录失效，但必须有完整性guard。

主代理已补最终 `/tmp/ccu_r639_final/verify.py`。本审只读对照：它在临时目录重放，要求三动作齐全、逐行无error，exact字段与冻结值相同，retained w正/deleted w零，positive rational bounds和相应hash一致；另检查数值残差及identity门槛，并明确这些不是interval误差认证。当前冻结results的三动作确为raw、best_common、best，均无error；script/helper/input hashes也与当前文件匹配。

**交付必须以verify.py为验收入口，不能只运行check.py并读取exit0。** 这保留原脚本字节/hash，同时堵住静默动作失败的流程风险。主代理的实际RUN_SUMMARY记录verify通过、wall约0.728秒；本审没有再次运行验证器或整批。

## 最终范围

数学证书通过，复现异常风险已有外部验收器修复。两份C5解析动作与三份rational-surrogate严格gap可保留；原真实未圆整几何、80位误差范围、finite动作全局最优或一般困难分支的uniform正Dε均不在已证范围内。唯一写入本文件，完成停止。
