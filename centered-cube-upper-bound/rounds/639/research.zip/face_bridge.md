# R639 整个旧最优面的容量损失与真实几何价格（Sol high）

**核心判据：** 令 P0 为完整旧 packing polytope、F0=argmax_{P0}m·ν，最优值为 M。对一次真实完整 Z，B_Z 的行是实际新增 positive-volume clique 约束。则

    S(Z)>0  ⇔ F0∩{B_Zν≤1}=∅.                       (F)

旧 λ 单点被新 clique 超载不够；必须切去整个 F0。若 w≥0、b=B_Zᵀw、b*=min_{F0}b·ν、Δ=b*−Σw>0，定义确切首次可离开旧最优面 F0 的价格

    t*=min_{p∈vertices(P0)\F0, b·p<b*}
                (M−m·p)/(b*−b·p),

则

    S(Z)≥t*Δ.                                      (T)

这是一个定量、全旧面、自适应新容量下界；但当前没有证明其同次 receiver 净价能在 hard near-extreme 族中统一付款。t* 的价格不能省掉，也不是所有 full-LP 方法都必须受该 first-face 估计限制。本审未得完整 target。

## 1. 固定需求 m，旧最优面而非 λ 单点

旧 KKT 给 m=d+εv/λ，并且对每个 ν∈P0，

    m·ν=∫Lν^old dμ≤M,  m·λ=M.

因此 F0 非空，包含 λ；它可能比 λ 所在最小活动面大，不能假定 F0={λ} 或 λ 是 F0 的相对内部点。

每个 C_j(Z) 包含 A_j，所以所有旧 positive cliques 在新族中保留，P(Z)⊂P0。令 B_Z 只列需要额外施加的新 clique rows，全部来自**同一个 Z**。非空紧 polytope 上最大值达到，故 Q_Z=M 当且仅当新 feasible set 与 F0 相交，得到(F)。这是 capacity saving 的充要条件，不是 D>0 的必要条件；receiver 本身也可能给净增益。

m、ρ_j及固定 Z 的 V_Z、Q_Z由旧几何/λ决定，在旧 KKT 类内换 μ 密度不会改变它们。来源选择可以用于证明或选择 Z，但不能宣称它改变固定 Z 的 face loss。

## 2. 全支持函数与旧面线性外推的确切价格

记 h0(c)=max_{ν∈P0}c·ν。有限 LP 的精确全局式是

    S(Z)=max_{β≥0}{M−h0(m−B_Zᵀβ)−Σβ}.              (1)

这里只使用有限 polytope/新增约束的 Lagrange alternative；对每个 β，右端都是合法 saving 下界。该式允许所有旧面与自适应 ν 重新优化，不把一个固定 ν 的超载代替真实容量下降。

为得到真正可核查的旧面价格，固定 w，令 b、b*、Δ如首节。P0 的 vertices 有限，F0 外 vertex p 的旧目标 gap g(p)=M−m·p>0。对0≤t≤t*，

    g(p)≥t(b*−b·p) 对全部外部 vertices,

而 F0 内 b 的最小值为 b*。逐 vertex 比较便给

    h0(m−tb)=M−tb*.

代入(1)的 β=tw，得 S≥tΔ，特别得到(T)。Δ>0 时 b*>Σw≥0，origin 是一个有正 relief 的外部 vertex，所以 t*有限且严格正。

t*是**沿这个 tilt、support maximizer 首次可离开旧 F0 的精确阈值**；F0 内的 reoptimization 已由 b*=min_F0 b·ν 支付，t>0时可以立即转向 F0 的 b-minimizing subface，未冻结旧 λ。越过它后必须重新算 h0，不能继续写 M−tb*。t*可能含近旧最优面的目标-gap conditioning；当前合同没有给它维数一致下界。它小只否定无价的冻结面外推，不能据此否定 full LP 或整条路线，因为(1)仍允许穿越面后重新优化。

若归一 Σw=1，则 Δ是全旧面的加权超载。整个 F0 被切去时，有限凸分离给某个这样的 w 使Δ>0；反之一个Δ>0就排除整个F0。需要最小化整个面上的 load，不能用 w·(B_Zλ−1) 代替。

## 3. 一个明确的 metric 版本及其 conditioning

定义

    η_Z=min_{ν∈F0}max_K(ν(K)−1)_+.

η_Z>0恰是(F)的 face exclusion。新 clique 的0/1 rows 对ℓ1距离是1-Lipschitz。再定义旧面 sharpness

    κ0=sup_{ν∈P0\F0}dist_1(ν,F0)/(M−m·ν).

κ0有限：将一个点分解为旧 vertices，把所有外部 vertices 替为某个固定 F0 点即可，得到由有限 vertex gap/距离比给出的上界。故

    S(Z)≥η_Z/κ0.                                   (2)

但κ0不能不付费地当作常数。粗上界会含 N/最小非零旧 vertex-gap；即使所有 λ_j>0，也未得到其 uniform 控制。这里没有提供 actual cube family 使κ0退化的反例，也不声称此 conditioning 是所有 global capacity 构造的必要损失；它明确指出这种 metric 推理中不能删除的价格。

这排除了两个未经证明的步骤：λ有新超载就自动有S>0；或旧面确实被切去就自动有 S≥cM。后者还需定量价格，或直接用(1)给更好的全支持函数证书。

## 4. 实际 cube contacts 与同次 receiver 净价

B_Z 的每个 clique K 必须满足全部坐标的严格正交长

    max_{j∈K}(y_ji+δ_j z_ji−ρ_j)
       <min_{j∈K}(y_ji+δ_j z_ji+ρ_j)  对每个i.

不能把不同 Z 各自有利的 clique rows 合并，也不能把零面积接触当作可放 AC 容量的公共核。所选 w 可依赖整次 Z，但一切必须联合结算，不能交换 E max 与 max E。

对完整 receiver 账，(T)确实给

    D(Z)≥εVar−O_Z+F_Z+R t*Δ.                        (3)

因此一个真正足够的 joint criterion 是：在同一实际 Z 下证出可用 w、t≤t*，并付清

    O_Z−F_Z ≤εVar+R tΔ−cV+C L_nM.                  (J)

若能以统一常数实现(J)，目标就完成；这里没有最小λ/对数N的隐藏费用，因为所有 capacity price 都明写在 tΔ。但本审没有从真正 hard near-extreme receiver 几何推出(J)，也没有 uniform tΔ 与 O_Z−F_Z 的联合控制。

仅有每个实例 t*Δ>0，不会自动压过其 receiver loss 或 near-extreme δM 帽。允许 t*随 family 退化时，不能在选择 δ-near family 后再假定 δ小于一个未控制且同步退化的正增量。反过来，不必单独证明 t*≥cM：如果 receiver 项本身好，或全支持函数(1)给更强saving，仍可支付(J)。

## 5. Geometry 作者的 simultaneous-capture 条件：通过但只是充分分支

收到并独核以下候选。固定同一真实 AC μ，对每行定义

    a_j*=max_{z∈[-1,1]^n} μ(C_j(z)\A_j).

平移 L1 连续性和 compact 参数域保证最大值达到。每行只依自己的 z_j，因此可用一个完整 Zcap 同时实现全部 a_j*，也同时最大化 Σν_ja_j 对**每个**ν≥0；这里没有 Emax 交换。

对0≤γ<1，令 Fγ={ν∈P0:m·ν≥(1−γ)M}，

    Gγ=min_{ν∈Fγ}Σν_ja_j*.

任意 ν∈P(Zcap) 满足 M−m·ν≥Σν_ja_j*。故若 Gγ>γM，整个 Fγ 被排除，Q_Zcap<(1−γ)M、S(Zcap)>γM。方向与 strict inequality 正确。

它避免显式写 t*，但把 near-face conditioning 保留在**整个 Fγ 的最小化**里，不能改为 λ 单点。当前没有 cube 估计强制该门槛成立，也未控制同一 capture-maximizing Zcap 的 V_Z/receiverloss。该条件是 sufficient，不是 capacity loss 的 necessary condition；失败不能推出无saving，因为完整 dual residue 还包括 μ 未被新 potential 覆盖的部分。

已只读最终 `/tmp/ccu_r639/geometry.md`：在各行 argmax 的紧乘积集上再最大化真实 receiver union 的 tie-break 合法，既不损a*也未假定来源极值或canonical连续。取γ=Q/(4M)时，若Gγ>Q/4且同Z有V_Z≥RM−V/8−CL_nM，则RS>RQ/4=V/4，确给D>V/8−CL_nM。该文件明确两前提未证。其逐坐标包含式中的 +δ_kz_k 符号正确，inner-half 的5/48余量也在其明确附加条件下成立，未被用来覆盖full-box最大捕获动作；没有越界的主目标声明。

## 6. Capacity 作者的 QP：定点核验通过，仍无能量下界

只读对照 `/tmp/ccu_r639/capacity.md`，没有复制其构造或重新求解。对新 positive cells 的实际 x_D=μ(D)，本轮所有旧行均 containment，故Σx=M；ω=x+Mπ>0、Σω=2M。有限严格凸 QP 的 KKT 与 h=y−x 配对，确给

    t(M−B)=Σh_D²/ω_D+q·(Ax−m)+k·x≥0,
    y=[x+ω(Aᵀq−t)]_+.

t>0、共同y、真实AC τ、q/k非负及补余松弛方向均正确。这里Σx=M不能外推到不 containment 的任意新族。

对任何可行容量bar y，目标比较给 B≤bar B+bar E/(2t)。uniform π=1/T 且bar B≤M时，bar E≤(T+1)M 的粗界也正确；没有理由删掉 T 或 tiny-cell/ω价格。存在严格更便宜容量时，该QP沿可行线段确会严格节省，但严格性本身没有 uniform 幅度。

这个构造与(1)兼容，确实允许 full-cell 行信用循环；它尚未给出其 saving 对同次 O_Z−F_Z 的下界。不能将非负能量命名成已支付(J)。

## 7. actual critical C5 的 face 价格：有限数学控制

已只读 Terra 的 `numeric/critical.py`、`REPORT.md`，未重跑11个维数。其解析构造 n≥2，d=2^n、v=d/a^n、m=d(1+2ε/a^n)，旧 C5 λ_j=1/2 给 M=5m/2、R=2/a^n、Var=0。

设 u=2ε/a^n、t=u/n、η=3t、ρ=(1+u)^{1/n}、δ=ρ−1。Bernoulli在n≥2给δ<t；(1+7t/8)^n≤1/(1−7u/8)<1+u（u<1/7）给δ>7t/8。故 raw 02 gap>t，row0向+δe1、row2向−δe1 后 02 overlap>t/2；其余坐标/边有正余量。两个报告所列 rational τ boxes 确分别位于真实 triangle012 和 edge34 内，所有源盒可扩成其余坐标中心0的正体积 n维盒；同一旧 μ 的 edge masses m/2 保证 KKT及新可达性。

这个例子的 F0 恰为唯一点(1/2,…,1/2)：旧C5 edge约束求和给Σν≤5/2，达到等号强制五条edge全tight，奇环解唯一。新增triangle012给Δ=1/2。

其 tilt price 可独立精确求出，无需数值顶点枚举。按 edges(01,12,23,34,40)，triangle row c=1_{012} 的旧normal系数为

    (1/2,1/2,1/2,−1/2,1/2).

所以 m1−s c 在0≤s≤m的旧非负normal质量为：edge34是(m+s)/2，其余四条是(m−s)/2。得到

    h0(m1−s c)=5m/2−3s/2,  0≤s≤m.

s>m时旧vertex e3 的值m立即超过该直线，因此 t*=m，(T)给 S≥m/2。实际 τ成本2m，packing e0+e3 给下界2m，故 S=m/2精确达到。

所有 old/raw/shift 小receivers都不交，Ij=Bj，故Var=O=F=0，完整 D=RS=m/a^n。这个实际 cube contact 控制说明 face-cut/tilt价格可以正确支付一次动作，而非只算固定λ超载；但旧R=2/a^n远非hard，不能据此推广(J)。

**数值exactness修复绑定：** 主代理发现初版 `critical.py` 的 `d/2` 是 int-to-float 表达式；初版 Var 数值assert不构成 exact 证据，本审不采用该行。解析 Var=0 如上，不受此bug影响。现已只读核修复为 `F(d,2)`，并对P、ε、u、t、m、Q、V、R、M、Var和完整D等核心变量逐项加 `isinstance(...,Fraction)` guard。作者重跑相同11案的receipt全部通过，本审未独立重跑。

绑定修复文件：`critical.py` SHA-256 `c944d6dd2f95c8e8220ee879ff74007a480e33e323c2c14b07e91749e9651bf1`；`critical_results.json` SHA-256 `6f76eb9e17b4ae482fa876abd0c88c1427ac05a45d0ab557afb71132ff02634c`。结果内script hash相同，11例的Fraction flags均为true。旧版数值运行不被重新描述为exact；几何/容量数学验收依据上述解析证明及修复后绑定。

## 8. 交付状态

本机 math venv / SymPy 1.14.0 只做一次5×5旧C5 normal线性代数核验：triangle normal系数如上，normal重构五个残差全0、support和为5m/2−3s/2，约0.07秒。没有数值扫描、旧案重放或新代理。

当前有用的新审查权限是整个旧最优面排除、显式有限tilt价格、以及全支持函数跨面比较；它们准确阻止把旧λ超载或无价face刚性直接当capacitydrop。**没有得到hard near-extreme族的uniform(J)或完整target付款。** 本报告仅写本文件；修复数字receipt已完成只读绑定，独审完成停止。
