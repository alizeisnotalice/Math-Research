#!/usr/bin/env python3
"""Re-run exact controls in temporary directories; never replace audited saved outputs."""
from pathlib import Path
from fractions import Fraction
import hashlib,json,os,shutil,subprocess,sys,tempfile,time
root=Path(__file__).resolve().parent
start=time.perf_counter()
env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
def run(script):
 r=subprocess.run([sys.executable,str(script)],cwd=script.parent,env=env,text=True,capture_output=True,check=True)
 return json.loads(r.stdout)
def mathpart(row):
 return {k:v for k,v in row.items() if k not in {'cpu_s','wall_s','peak_rss_bytes'}}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
manifest=root/'MANIFEST.json'
if manifest.exists():
 for name,h in json.loads(manifest.read_text()).items():
  assert sha(root/name)==h, ('manifest mismatch',name)
with tempfile.TemporaryDirectory(prefix='ccu-r639-verify-') as td:
 t=Path(td);shutil.copytree(root/'numeric',t/'numeric')
 critical=run(t/'numeric'/'critical.py')
 saved=json.loads((root/'numeric'/'critical_results.json').read_text())
 assert critical['script_sha256']==saved['script_sha256']==sha(root/'numeric'/'critical.py')
 assert [mathpart(x) for x in critical['cases']]==[mathpart(x) for x in saved['cases']]
 assert len(critical['cases'])==11 and all(x['all_algebra_is_Fraction'] for x in critical['cases'])
 robust=run(t/'numeric'/'robust_exact.py')
 assert robust['maximal_cliques']==[7,13,28,52] and robust['common_label_index']==2
 reg=run(t/'numeric'/'regularized'/'check.py')
 old=json.loads((root/'numeric'/'regularized'/'results.json').read_text())
 assert reg['critical_C5']==old['critical_C5']
 assert len(reg['r638_actions'])==3
 fields=['action','retained','w_all','deleted_zero','positive_cliques','Qlin_rational','optimal_face_forced_zero_local_indices','linear_optimal_vertex_count_with_duplicates','positive_barrier_gap_proved_for_rational_surrogate','rational_surrogate_gap_lower','rational_surrogate_gap_upper','Vnew_rational']
 import mpmath as mp
 mp.mp.dps=90
 for row,previous in zip(reg['r638_actions'],old['r638_actions']):
  assert 'error' not in row, row
  assert {k:row[k] for k in fields}=={k:previous[k] for k in fields}
  assert Fraction(row['rational_surrogate_gap_upper'])>=Fraction(row['rational_surrogate_gap_lower'])>0
  assert all(Fraction(row['w_all'][j])>0 for j in row['retained'])
  assert all(Fraction(row['w_all'][j])==0 for j in row['deleted_zero'])
  assert mp.mpf(row['KKT']['stationarity_max'])<mp.mpf('1e-45')
  assert mp.mpf(row['KKT']['constraint_max'])<=mp.mpf('1e-35')
  assert abs(mp.mpf(row['identity_residual']))<mp.mpf('1e-60')
  assert abs(mp.mpf(row['Qeps_mp'])-mp.mpf(previous['Qeps_mp']))<mp.mpf('1e-45')
  gap=mp.mpf(row['gap']);low=Fraction(row['rational_surrogate_gap_lower']);up=Fraction(row['rational_surrogate_gap_upper'])
  assert mp.mpf(low.numerator)/low.denominator<=gap<=mp.mpf(up.numerator)/up.denominator
 # Numerical residual assertions above only compare floating calculations; no interval error certification.
 for key,file in [('helper_sha256','baseline.py'),('script_sha256','check.py'),('frozen_input_sha256','frozen_input.json')]:
  assert reg['run'][key]==old['run'][key]==sha(root/'numeric'/'regularized'/file)
summary={'status':'passed','interpreter':sys.executable,'python':sys.version,'wall_s':time.perf_counter()-start,
 'critical_exact_cases':11,'critical_workers':critical['workers'],'critical_replay_wall_s':critical['wall_s'],
 'old_geometry_exact_maximal_cliques':robust['maximal_cliques'],'C5_exact_regularized_actions':2,
 'rational_surrogate_exact_actions':3,'surrogate_replay_wall_s':reg['run']['wall_s'],
 'limits':'C5 is nonhard; surrogate exact gap does not transfer to original algebraic geometry. mpmath values/residuals are floating evidence, not interval certificates. No MATLAB, Arb, or PDF compilation.'}
(root/'RUN_SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
