# R194 sparse affinity checks

Nine finite scalar cases passed at 25 and 40 decimal digits. Each stage fixes one gap eta (1/2, 1/4, 1/8) and s=1-eta, then tests (lambda,d)=(1/2,0), (3/4,eta^4/(36*51200)), and (1,1/2). This is a selected menu, not a Cartesian scan or a uniform certificate.

The E3 formula for phi and E4 formula for C are copied from the frozen R191 scalar probe, whose SHA is recorded in JSON; no old module or JSON is imported. Each whole-line affinity integral is split at both source hard faces, zero, and all target phi seams. Hard-face membership is explicit. At the positive source face, the code compares the two one-sided discrepancies from the continuous target phi(x-d). It integrates the absolute discrepancy on the larger side for length J/20, where J=eta/lambda. This compact contribution to the actual L1 distance passes J^2/80 and hence eta^2/80. It is not a full-axis L1 quadrature or an independent proof of the analytic Lipschitz bound.

All nine unnormalized affinities pass 1-eta^4/51200. All six near points pass the normalized exp(-3 eta^4/(4*51200)) bound. The exact rational near condition is classified before conversion to mpmath, including threshold equality. Near normalized F ranges from about 0.857558 to 0.981526. At d=1/2 the normalized F values are approximately 1.129996, 1.177829 and 1.192945: the small-displacement bound is deliberately not applied there. Their unnormalized affinities are below one, as required by the different claim.

The maximum observed 25/40 difference among affinity, normalized F and compact L1 witness is below 1.7e-26 (the script requires less than 1e-18). These are empirical precision comparisons, not directed interval error bounds. No uniform gap theorem, optimal constant, dimension-order fit, original selector, FIRST/history or FULL construction is certified by this finite menu.

Reproduce with standard-library Python plus the existing mpmath 1.3.0 vendor (no installation):

```sh
PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor python3 sparse_affinity_checks.py --output sparse_affinity_checks.json
```

The script requires its local task_contract.md, whose hash is included using a portable filename key. mpmath version and entry-file SHA are recorded. Runtime was about 3.8 seconds locally; timing is printed and omitted from deterministic JSON. A fresh temporary-directory copy of script and contract was independently executed and its complete JSON compared byte-for-byte with the work output; equality passed. Only the three assigned R194 numerical files were written.
