#!/usr/bin/env python3
"""Finite exact arithmetic checks; no geometric or asymptotic claim.

Only Python standard-library arithmetic is used. All input bounds are rational:
log(2) < 7/10, exp(1/16) < 16/15, and Ngrid <= ceil(56*n/5)+1.
"""
import argparse
from fractions import Fraction
from hashlib import sha256
import json
from math import comb
from pathlib import Path


def rational(value):
    value = Fraction(value)
    return {"numerator": str(value.numerator), "denominator": str(value.denominator)}


def check_case(n):
    N = n
    p = Fraction(n + 2, 8 * n)
    a, d = p.numerator, p.denominator
    denominator = d ** N
    weights = [comb(N, k) * a ** k * (d - a) ** (N - k)
               for k in range(N + 1)]
    assert sum(weights) == denominator
    # tail_numerators[m] / denominator = P(Binomial(N,p) >= m).
    tails = [0] * (N + 2)
    for k in range(N, -1, -1):
        tails[k] = tails[k + 1] + weights[k]
    assert tails[0] == denominator and tails[N + 1] == 0
    monotone = all(tails[k] > tails[k + 1] for k in range(N + 1))
    assert monotone
    grid = (56 * n + 4) // 5 + 1
    B = (Fraction(n, 4) * (Fraction(7, 10) + Fraction(49 * (n + 1), 400))
         * Fraction(16, 15) * grid * (n + 1))
    rhs = n * B.denominator ** 2 * denominator ** 2

    def passes(m):
        return B.numerator ** 2 * tails[m] ** 2 <= rhs

    mstar = next(m for m in range(1, N + 2) if passes(m))
    previous_fail = None if mstar == 1 else not passes(mstar - 1)
    assert passes(mstar) and (previous_fail is None or previous_fail)
    half = (N + 1) // 2
    half_check = tails[half] ** 2 * 4 ** N <= 3 ** N * denominator ** 2
    assert half_check
    return {
        "n": n, "N": N, "p0": rational(p),
        "Ngridbar": grid, "Bbar": rational(B),
        "tail_normalization_exact": sum(weights) == denominator,
        "tails_strictly_decreasing_through_empty_event": monotone,
        "mstar": mstar, "branch_nonempty": mstar <= N,
        "chosen_event": "nonempty_binomial_tail" if mstar <= N else "empty_event_m_equals_N_plus_1",
        "chosen_tail": rational(Fraction(tails[mstar], denominator)),
        "chosen_Bbar_squared_tail_squared_le_n": passes(mstar),
        "previous_m": None if mstar == 1 else mstar - 1,
        "previous_tail": None if mstar == 1 else rational(Fraction(tails[mstar - 1], denominator)),
        "previous_Bbar_squared_tail_squared_gt_n": previous_fail,
        "half_count_m": half,
        "half_count_tail": rational(Fraction(tails[half], denominator)),
        "half_count_tail_squared_le_three_quarters_power_N": half_check,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path("face_budget_checks.json"))
    args = parser.parse_args()
    stages = [[2, 4, 8], [16, 32, 64], [128, 256, 512]]
    result = {
        "schema_version": 1,
        "scope": "Finite rational arithmetic certificates only. These checks do not prove actual geometric face inclusion, FULL coverage, or an asymptotic theorem. An empty event is explicitly classified and does not imply general coverage.",
        "bounds": {
            "log2_upper": rational(Fraction(7, 10)),
            "exp_one_sixteenth_upper": rational(Fraction(16, 15)),
            "Ngridbar_formula": "ceil(56*n/5)+1",
            "Bbar_formula": "(n/4)*(7/10+49*(n+1)/400)*(16/15)*Ngridbar*(n+1)",
            "selection": "min m in {1,...,N+1} with Bbar^2*Tail(N,m)^2 <= n",
            "tail_formula": "sum_{k=m}^N binomial(N,k)*p0^k*(1-p0)^(N-k)",
            "p0_formula": "1/8+1/(4*n)",
            "N_choice": "N=n",
        },
        "stages": [{"stage": index, "cases": [check_case(n) for n in ns]}
                   for index, ns in enumerate(stages, 1)],
        "all_assertions_passed": True,
    }
    payload = (json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2) + "\n").encode("utf-8")
    args.output.write_bytes(payload)
    print(json.dumps({"output": str(args.output), "sha256": sha256(payload).hexdigest(),
                      "bytes": len(payload), "cases": 9}, sort_keys=True))


if __name__ == "__main__":
    main()
