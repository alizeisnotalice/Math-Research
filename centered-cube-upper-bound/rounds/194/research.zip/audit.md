# R194 独立审计

本文件独占维护；先读共同 task_contract.md，未读本轮作者证明。以下为准确候选的独立量词检查点，不登记一般全局交通付款。

## 1. 排序倒置的实际几何

固定一条原 row、bad u 与原 P_u，令 β_i=b_i^P<T=log(g/ell)，m=n−i+1。若 b_(i)(v)>β_i，则至少 m 个**原实际坐标**满足 C(|y_l−v_l|/b)>a_i，a_i=ξ_ell exp(β_i)。当 0<a_i<1 时，C 连续、偶、从 C(0)=1 严格径向下降，因此等价于这些坐标 |y_l−v_l|<b C^{-1}(a_i)。半开 parent cube 的 face 最大距离用 supremum；倒置域本身是严格不等号。β_i=T 时不可能；a_i≥1 时域为空，不能将逆函数在范围外继续延拓。β_i=0 时 clipped threshold 的 strict inversion 仍推出相同 strict 物理阈值。

这个命题只给 source pair y−v 的坐标接近性，既不是 receiver x−y 的 overflow 计数，也不是坐标随机独立或某个概率的 m 次方。i、P_u、ell/g 和半径可随原 row/θ/x 变；因此其事件在真实 dx/来源积分中须保持原依赖，不能从固定半径的积分直接替换。

## 2. 可合法交换和必须收费的边界

原固定 (ω,V,j,y,t) 的 ν、Z_t、w_t、e_t、Π_t、score 及 canonical 正 flux reference Γ^+ 独立 receiver x。正积分可 Tonelli；终端 g、A、同 α、capture、w_g 及倒置门仍依 x。原目标几何支的精确正 traffic 仍为

(32Λ/3) EΣ_{V,j}∫_E dx p_y β(dy)∫dt/t ∬ A(v)H(x,y,u,v,t)(k_t(v)−k_t(u))_+ Π_t(dv)Π_t(du)，

其中 H 保留倒置、low-tree、late、tiny、原唯一 j 与其他真实门。可以正删门作支配，不能改 source、重算 α、将原 bad 换成无资格的全源后沿用 bad reserve，也不能借用原 signed 负信用。

对固定来源 y,v 及固定合法 s,L,b，kernel 的 product 结构确实给

∫_{R^n}√(P_{s,L}(x−y)J_b(x−v))dx=∏_l∫_R√(p_{s,L}(r−y_l)φ_b(r−v_l))dr。

这只是 x 核的张量恒等式，对任意相关来源后续 Tonelli 仍合法；它不使 β/ν 的坐标独立。若 receiver 域为一般 E 或门耦合各坐标，只能保门或正扩大到 R^n；若 s,L 随 x 选，须用已有带完整参数选择费的正包络，不能在固定参数乘积右边免费取 sup。与原 A 连接的 good 比较为 p_y A≤√(K/3)ρ_v√(p_yJ_v/w_g(y,v))；tiny w_g 的倒数仍在，未经证明不能丢掉或由 coordinate count 自动抵消。

固定 row、固定半径的多坐标 source 限制可写为 union_{|I|=m}∩_{l∈I}{|y_l−v_l|<R}。以 union bound/子集枚举估计须保 binomial 成本；若能直接保 count 函数可避免人为枚举，却不自动产生小量。坐标接近通常不会单独产生 affinity 小因子；所需是实际 source/capture 或 receiver 权重的联合估计。

## 3. 来源、随机格与预算量词

β_V、ν_V 仅各受共同父 μ_hi|V 支配，不能互相排序。共同 seed/window 内不交 V 可合并其正质量到 μ_hi；独立窗口、菜单或真实 j 重用仍按原账收费。R188 λ≤(pβ/q)⊗(pν/q) 只校准 outer y/u 两槽，并未同时控制本轮 target v 的 τ_d 或 ν_v。不能把二源 product 支配当成三源免费独立性，也不能把依 x 的 λ 固定后套源核张量。

随机 θ padding 只有在先将 θ 依赖来源/attenuation 正支配到 pre-θ 的共同输入 product，并对每个 fixed pair 取 θ 平均时才合法。依 P_u 或实现后 heavy/capture 得到的半径/事件一般不是 pre-θ；不能把这种自适应半径直接塞入固定 pair 的 split 概率。R192 已付的 pre-θ pair 选层仍可沿原限制复用，不能据此免去新 target v 的联合费用。

R193 可继续逐 u、时间固定 target 分片：失败部分的正确代价是 D_d,u=∫(1−e^(−Ω))dτ_d,u；有序 matching/robust cut 只提供共同 c 的证书，未提供一般失败 cut 根价。任何新估计须在上述真实 β、target ν、λ/Γ^+、dx、全部窗口下控制该量，或直接控制同一原正 traffic；单个条件门、裸 coordinate multiplicity 或 parent 无权质量尚不足。

## 4. 阶段结论

准确 inversion→strict coordinate radius 的几何成立，允许 fixed-source/fixed-parameter x 核张量及正 Tonelli。尚未给其在原 adaptive receiver/source/capture 下的全局价格。等待两作者准确候选后再全文独审；不沿作者路线重复攻坚，不作无关反例搜索。


## 5. 三个准确候选的独立筛查

以下先核准确命题消息，再读相应证明。主 jump-gap：f_{s,λ}−φ(·−d)在 λ/2 跳 J=(1−s)/λ≥η，开单侧 smoothpart Lipschitz≤5。J≤2，长度 J/20 不碰另一硬面，给 L1≥J²/80，继而 affinity≤1−η⁴/51200。除 √C 后以 logC-Lip18、d≤η⁴/(36·51200) 得 exp(−3η⁴/(4·51200))；其余坐标用已审 R191 F0/F1。保 sparse-count 与 carrier 的 fixed-source 指示、两个完整参数选择费和 Γ+ 总质量才可回原 source 价。

Astra current-face：源固定 S={i:|u_i−v_i|≤a/16}，向上 scale 网格 logstep=1/(16n)。原 adaptive closed cross 逐点被网格两条扩带覆盖，总长≤2|u_i−v_i|+2ΔL；各 normalized h/φ 密度≤1/L'，最新安全 p0=1/8+1/(4n)，n≥2 时≤1/4。固定 s 的 Bernstein conditional product 平均给 Bin(N,p0) 上尾，sup_s≤Σ_{k=0}^n G_k 的 n+1 费、scale网格 N_L 与 e^(1/16) 均须保。Γ+ 后的原 raw 系数通过。固定 source 的 m 或 m=ceil(N/2) 可用；不得把未付 x-adaptive m 填进固定尾式。HG严格必要式与 signed current count≤M_S+n−N 联合，确可使明确 large-gap 门包含于已付多面事件；不覆盖未达门补集。

Sol capture bridge：A>0⇒χdensity=1，所以 A_m=min(A,(1−A)/c) 的 global diagonal coupling 合法，parent-limited neutral 时 matched target 必须同限。真实 Δ 的近点下界由 wτ(z)≥e^(−dC)wτ(v)、wh(z)≤e^dC wh(v)直接相减并取正部，β=e^(−dC)[1−(e^(2dC)−1)/(e^L−1)]_+。L≥(Ω−u0)_+；A(v)≥a0⇒a_v/k_v≥1/(1−a0)，配 signed K0 ratio Γ 给 E 内实际 χdensity(z)≥min(1,βe^(−Γ)/(1−a0))。可得(c_cap−A)_+ν neutral，但不能丢 E/真实ν或换成 μ。尺度、硬跳与物理门费用仍保，未登记一般 root。

## 6. 主稿全文后审（尚待其他作者全文）

已实读 sparse_displacement_geometry.md 全文。SD1–10 常数、count 阈值、真实 good 与 Γ+ 回代通过；双参数 Stieltjes 的单调量分别为 (1−s)^(−n/2)G_s、L^(n/2)G_L，closed adaptive faces 以 Stieltjes 跳保留。η_n=1/log(n+2) 的负指数 n/log⁴(n+2) 吸收已显示多项式成本是合法解析结论。已建议明确 Γ+ 质量是≤L_nW_A，fixed-source carrier d_i≤Rn 保留至 envelope 应用，并沿用原窗口 sup/来源总账。该小坐标位移支不是全部 middle 覆盖；未从有限核数值证明一般阶数。


## 7. 有限核数值静态审

已读 sparse_affinity_checks.py 与 numerical_review.md。9 例实际 E3/E4 kernel 归一、source hardface 与 target seam 分段、单侧较大 trace 的 compact L1 witness、精确 Fraction near-threshold 分类与 25/40 dps 对照一致。d=1/2 三例只检 unnormalized gap，不能套 near normalized bound；notes 正确保留 normalized F 可大于1。全部为有限非区间诊断，不认证 analytic uniform gap、Γ+、FIRST/history 或 FULL。本独审不重跑。

补充范围提醒：diagonal matching 给低 A≤a0 的 2a0 C_rec 价成立，但被旧 RF 正上界直接乘 A≤a0 得 a0 C_rec 压过；该推论不作新进展。其余物理 capture bridge 只在真实 E 与 ν 上给实际下界，未付成本尚在。


## 8. 两作者全文后审

已实读 geometry_cost.md 全文。GC6/7–10 保留 adaptive closed-face 的逐点扩带和固定 kernel 端点处理；p0、Bernstein 全 softness n+1 费、N_grid、e^(1/16) 均正确。GC12 保真实 fixed-source tail 平均；GC13 的 m*(N) 在每 source tuple 先于 x 固定，空 m=N+1 不作覆盖。GC14 的 (32Λ/3)√nW_A 回代正确，T*=sup窗、Wβ≤W_A 及原窗口成本均明确。GC17 的严格原 HG 与 signed-count 上界确使 GC18 门进入已付面层，s=1 与空门分支合法；GC19/20 的长位移/少面余项保持未付，不混成 R193 clock inversion。

已实读 source_capture_bridge.md 全文。SC6/7 global diagonal matching 与 parent-limited 版本区分正确；SC10 同 α 的正部缺口、SC13/14 prefix/suffix 的正确方向、SC16 Δ 的邻点模量、SC18/19 实际 clamped Hhat 的有向硬跳均通过。SC20–23 在真实 E/ν 内给 χ 下界，SC24 保 nS/H 与 j_s m+，SC25/26 精确来源/eligibility/未饱和缺失及低 k/w 倒数没有免费省略。它是 constructive capture 接口，未登记高 A 余域的新全局付款。

主 SD4 两处窄修已实际读取：Γ+ 总质量≤L_nW_A；fixed-source carrier 1{all d_i≤Rn} 必须保留到 SD9 应用，之后才放掉其他门。不会将 receiver-dependent terminal 支持先删后套超范围 envelope。

## 9. 精确 face 数值脚本静态审

已读 face_budget_checks.py。9 例固定 N=n，p0=(n+2)/(8n)；Bbar 用 log2<7/10、exp(1/16)<16/15、ceil(56n/5)+1 与 T* 上界安全放大 GC11。尾概率用精确整数规范，平方判定与前一 m 失败检查正确；半数尾的平方 Chernoff 关系只在所测 n≥2 使用。脚本只认证这些有限有理公式，未认证 face 包含、原 FULL、一般阶数或支非空覆盖；本独审不重跑。


## 10. 最终整合审核与冻结

已全文实读最终 proof.tex.txt、report.md、reproduce.py 及最终数值说明。LaTeX 的 jump-gap/normalized-coordinate 收缩、两参数 Stieltjes 费用、真实 Γ+ 回代 SP、多 current 面 FP 及实际 capture 接口与详细稿一致。报告的两 root 来源支按先 SP 后其补集 FP 结算，不声称其并集覆盖剩余全体；SC 的邻块界未冒称第三 root 价。9 核诊断、9 exact face 算术的精度/范围及报告列出的阈值与 JSON 静态一致。父级已报告分别实际重跑两脚本且完整 JSON bytes 一致；本独审未重跑。总 driver 等 manifest 后父级执行，当前不提前认证。driver 静态保持原环境、相同 Python、双脚本 fresh output 及全 JSON 比较，没有隐含新实验。未编译 PDF。

**严格通过范围：** fixed-source 稀疏 y−v 位移分支与 fixed-source 短 u−v 多 current 硬面分支的实际 Lebesgue receiver/source 预算，以及同 α HG 迫入后者的明确条件门；实际 Δ/K0/χ 邻块桥及全部来源缺失公式仅按已证接口通过。来源坐标从未独立化，原 α/Π/删除/唯一 j/全部窗口费用不变。

**一般未付范围：** 稀疏位移失败且多面事件不足的真实 high-A/late/tiny/low-tree/cut 余域；实际 E 内 ν 占用、低 K0/w 缺失和排序 cut 的空间费用仍缺全局价。不认证 FULL 严格覆盖扩大或一般弱型闭合。

以下 SHA256 由最终文件字节实算。排除 audit.md 自身与未来 manifest，避免循环绑定。现冻结停止。

| 文件 | SHA256 |
|---|---|
| task_contract.md | `3a6423ddb15ecb818e2a773169753ed0cc278433ce5c358bd29d5b16caa059f3` |
| sparse_displacement_geometry.md | `41920c5f0392e860658a72ceb11a430706c28ff62ca96b275b7a7ec2e0d6bfa5` |
| geometry_cost.md | `02f4fcbc6469206b1af335c4e4759e7442f0fdf047b94cad7e9e57d0d2b69441` |
| source_capture_bridge.md | `e15c577dfc1f45079073035c2534a6a07a82a0ea3c8ba8bf40c862ed49c94fda` |
| proof.tex.txt | `cf88c0bf2c6abdef5a128e25434fbe1705b1aff68d07184729c634622534d3f8` |
| report.md | `aad62c7460c5186f7078acea37a2fbf68ffc96fced1fd63a16a3e7e6a6c2a333` |
| sparse_affinity_checks.py | `c4ee1121c11bfa15d2bcf8dda2bf9ab96e21d977ea51f932c79037e1fa1910da` |
| sparse_affinity_checks.json | `919c0e05294408d59987653e5d3339fbd5419e766da4f53445f409a3e575ba11` |
| face_budget_checks.py | `da12806d2a0303c8a720fdc1aa6063da9b3742df467ec163c0bfa614641552e6` |
| face_budget_checks.json | `057895d6a8a188da1ef94e59d8b453c8667dfdda5db28a4358786f3791ad9f6e` |
| numerical_review.md | `5509e8b9a5d27daefba1dd0f365e9f4d856660a96b44fa2ce4d4e06f579d563d` |
| reproduce.py | `daa5ce90487efff756e740bf298c50de0fc06148992cb992af2e2f73741f3237` |
