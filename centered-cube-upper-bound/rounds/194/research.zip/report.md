# 第194轮：原接收测度上的稀疏位移与多硬面费用

2026-10-16。起点main ad0dffacaa0389dccdb9cf3fa38898384ad990d6；本轮进入时工作区干净、远端正确。第193轮属于已证明接口、实测证据与已推送产出的实质进展。本轮保持一般n^(1/2+o(1))一致弱型上界目标，未将两个分支当作一般闭合。

## 经过独审的实际估计

1. **稀疏非微小位移来源对。** 原mixed核的硬跳给L1≥η²/80、未归一化affinity≤1−η⁴/51200。结合原C的log-Lipschitz及R191远坐标包络，给多数坐标位移小于明确半径的source pair指数衰减。完整soft与scale Stieltjes费用均保留；回原Γ+后得到实际来源价。η=1/log(n+2)时解析推出根阶，未拟合阶数。详细见sparse_displacement_geometry.md SD1–10。
2. **短位移、多硬面交叉。** 固定source tuple的接收product核使多个短u-v坐标同时穿过current硬面的事件有二项尾价格。尺度向上扩带保adaptive closed faces，全部soft由n+1个Bernstein系数组成的包络支付。参考j/time质量完整计入。实际原分支取得(32Λ/3)√n W_A来源价；同α强间隔可强制进入该门。详细见geometry_cost.md GC6–18。
3. **捕获率桥梁。** 实际Δ与K0的邻点比较保留future contrast、signed硬面、nS尺度和原E/ν占用。它给可计算下界而未付一般全局价。简单小A同点匹配被旧RF更强界覆盖，不登记新成果或新增覆盖。详见source_capture_bridge.md。

合法组合为先稀疏位移分支、再其补集上的多面分支，两个来源预算相加。稀疏位移使用y-v，面层使用u-v，两者不能互相替代，未证明联合覆盖剩余全体。来源坐标从未假设独立；只在固定source之后对receiver概率核做product积分。原q、唯一j与参考j/time代价、同alpha、所有窗口和真实dx保留。

## 数值证据与实际运行

- sparse_affinity_checks.py：9例三阶段，η=1/2、1/4、1/8，各含λ=.5/d0、λ=.75/精确小半径、λ1/d.5；25/40位，硬面和target接缝分段。L1检验是真实单侧紧区间贡献，非未经根定位的全轴绝对值数值。6近点满足归一化界，3远点仅检查未归一化gap，不能把远点F>1套进近点结论。最大精度差<1.7e-26，非区间认证。
- face_budget_checks.py：9个Fraction/整数二项尾例，n=N=2,4,8,16,32,64,128,256,512。用log2<7/10、exp(1/16)<16/15构造严格保守有理Bbar；平方比较消除sqrt。阈值依次3（空事件）、4、6、9、15、24、39、66、114；逐例检查选中阈值通过、前阈值失败和半数Chernoff平方界。仅是算术证书，不认证实际几何实例或FULL。

父实际分别执行两脚本输出到/tmp/r194_parent_affinity.json及/tmp/r194_parent_face.json，并cmp冻结JSON，退出码均0、完整bytes一致。完整driver在manifest冻结后再运行，其结果记录于外层README，不提前宣称。

复现：已有mpmath1.3.0；本机PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor。精确tail脚本仅stdlib。reproduce.py --verify-only核哈希，完整模式用--output-dir新的目录，继承此PYTHONPATH。只保存实际运行输出。

## 工具边界、审计与剩余问题

使用64项工具的F01核/归一化/分支审核要求，阅读其SKILL.md和cube-interface；没有调用未定义GP-BRANCH私有定理。D01/B01方法延续前轮但未重做抽象输运归约。N03经阅读发现其振荡条件与本轮正核估计不符，未套用。所有本轮主不等式有直接证明；引用的Γ+、C模量和F1界来自已独审冻结研究工具。有限数值不替代证明。

audit.md记录先独筛命题再读全文，以及实际审查范围。详细LaTeX在proof.tex.txt，不编译PDF。复用1 Astra high、2 Sol high、1 Sol medium，另开1 Sol medium执行独立精确面层算术；实际模型扣额数据不可得，不推测成本比例。

一般缺口是：稀疏位移条件失败、但短u-v硬面交叉数低于m*的真实high-A/late/tiny/lowFtree域。需要同时控制实际E内ν占用、低K0/w来源缺失和排序cut空间质量。SC邻块界仍有完整nS和hardjump损失；单个父块h大不能付这些扣项。下一轮应针对这一真实联合区域，而不是再用linear粗包络或把条件界称一般闭合。
