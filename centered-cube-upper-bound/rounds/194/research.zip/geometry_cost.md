# R194：实际多硬面 receiver 层的来源付款

本稿证明一个真正带 dx 的几何估计。固定原 source tuple 后，对 u-v 位移很短的坐标，原 current cube 若在足够多坐标将 u、v 分置硬面两侧，其 current 核的接收积分具有二项上尾衰减。证明包含所有 adaptive softness/scale 成本、原 fixed-time 正流量参考的 j/time 质量，并保留 adaptive closed face。回代后该实际子支得到 sqrt(n) 来源价。原同 alpha 的 HG 间隔还能强制进入这一已付支；但 R193 的时钟倒置不自动等于多 current 硬面交叉，余域不声称闭合。

## GC1. 原积分和固定时间参考

保持原 (omega,V,a,b,q)，a≤b≤2a，q 为本窗口共同阈值，原接收域 E_rec、current s(x),L(x)、唯一 j(x)、high、same alpha、K0、capture、rho、good/bad、history 与全部删除不变。beta、nu 只分别受共同父来源支配，不假设 nu≤beta。

原 current product 核为

    P_(s,L)(x-y)=L^(-n)∏_i f_s((x_i-y_i)/L),
    f_s=(1-s)h+s phi, h=1_[-1/2,1/2].

h、phi 均为概率密度，0≤h,phi≤1，偶且径向非增。phi=h*w。下文接收核估计允许全部 0≤s≤1；原交通仍保留原严格软资格，不以扩展参数制造新交通。

使用已核 R186 FL1–FL6 的原 fixed-time 正流量参考

    Gamma_V^+(dj,dt,dy,dv,du)
       =Σ_j 1_[a/c_j,b c_j](t)dt/t beta_V(dy)
          [score_j,y,t(v)-score_j,y,t(u)]_+
                       Pi_j,y,t(dv)Pi_j,y,t(du).       (GC1)

固定 (omega,V,j,y,t) 时 nu、Z、e_t、Pi_t 和 score 真正先于 receiver x 构造；原定位 R128 RT4 约648–650行，已在 FL1 窄核。终端 A、g、alpha 等仍依 x，绝不并入参考。e_t=0 时原零核先取0。

令 gamma=1+1/n，c_j=gamma^(-j)，hwin=log(b/a)，Jwin=floor[hwin/(2log gamma)]。真实时钟总长

    T_n(a,b)=Σ_j log_+(b c_j²/a)
      =(Jwin+1)hwin-log(gamma)Jwin(Jwin+1)
      ≤log2+(n+1)log²2/4.                             (GC2)

原两个 posterior score 槽均在[0,n]，其 product 正差积分≤n/4。因此

    ||Gamma_V^+||≤(n/4)T_n(a_V,b_V)||beta_V||,
    Tstar=sup_(omega,V)T_n(a_V,b_V),
    Lstar=(n/4)Tstar,
    EΣ_V||Gamma_V^+||≤Lstar Wbeta≤Lstar W_A.           (GC3)

Tstar=0 时本类原交通全零，后文不除它。原不交来源族与窗口费用按原总账；独立重跑窗口不免费重用 W_A。

只用一次原 hard/source 帽16/3及外系数2Lambda，原正 J-share 对任何实际正切片 E_geom 有

    Raw_original^+[E_geom]
       ≤(32Lambda/3)EΣ_V∫Gamma_V^+
          ∫_Erec P_(s(x),L(x))(x-y)
                       A_x(y,v)H_x 1_Egeom dx.        (GC4)

0≤A,H≤1。H 包含唯一 j(x)、actual far、高低门、history 等。以下先保留这些实际门，再以正上界丢去 A,H。没有重选 Pi、alpha 或森林。采用 fixed reference 后 j 的参考不同，不能再免费用唯一 j 消去 GC2；该费用已明确列入 GC3。

## GC2. 短 source 位移与原 current 硬面事件

对 fixed (omega,V,j,t,y,v,u)，定义不依 x 的坐标集合

    S(u,v)={i:|u_i-v_i|≤a/16},  N=|S|.

原 current closed membership 为

    H_i^L(z;x)=1_{|x_i-z_i|≤L/2},
    M_S(x,L)=Σ_(i∈S)1_{H_i^L(u;x)≠H_i^L(v;x)}.        (GC5)

取整数 m∈{1,...,N+1}。m 可以依 fixed source tuple、原窗口和 N，但必须先于 x 固定。本节证明

    ∫_(R^n) sup_(0≤s≤1,a≤L≤b)
        [P_(s,L)(x-y)1_{M_S(x,L)≥m}]dx
       ≤e^(1/16) N_grid (n+1) B_(N,p0)(m),            (GC6)

其中

    N_grid=ceil(16n log(b/a))+1,
    p0=1/8+1/(4n),
    B_(N,p0)(m)=Σ_(k=m)^N binom(N,k)p0^k(1-p0)^(N-k).

m=N+1 时尾和为0，事件空；N=0 也按此处理。n≥2 时 p0≤1/4；n=1 时 GC6 的精确 p0=3/8 版本仍成立。显示式使用上确界作正支配；无需对实际 current selector 施加新可测选择。

## GC3. Adaptive L 的逐点扩带，不删闭面

取向上尺度网格，log 间距至多 delta=1/(16n)，含端点 a,b；节点数不超过 N_grid。对每个 L 选 L'≥L，L'/L≤exp(delta)。由 h、phi 的径向单调，逐点

    P_(s,L)(x-y)≤exp(1/16)P_(s,L')(x-y).               (GC7)

同时

    DeltaL=L'-L≤b(1-exp(-delta))≤b/(16n)≤a/(8n).

固定 i∈S，记 d_i=|u_i-v_i|≤a/16≤L。原两个一维 closed intervals 的 symmetric difference 位于两个同侧面之间：一对左面和一对右面。把 L 的面换成 L' 的面，每一对整体移动距离≤DeltaL/2。故原 cross 逐点包含于以下固定 L' 的 closed 带 E_i(L')：分别连接 u_i-L'/2 与 v_i-L'/2、连接 u_i+L'/2 与 v_i+L'/2，并各向两端扩大 DeltaL/2。

可统一用最坏 DeltaL_bound=b/(16n) 定义带，仍有

    |E_i(L')|≤2d_i+2DeltaL_bound
              ≤a/8+a/(4n).                           (GC8)

该扩带先于任何 dx 积分，保留原 adaptive L 的闭面原子资格。不能把随 x 选择的 L 所命中的硬面说成零测度；本证明没有这样做。后续固定网格区间的有限端点才对 Lebesgue 积分无影响。

对任意固定 L' 的单坐标 h 或 phi 密度，sup≤1/L'，故

    Prob{x_i∈E_i(L')}≤|E_i(L')|/L'≤p0.               (GC9)

原 M_S≥m 于是迫至少 m 个这些固定坐标带事件成立。

## GC4. 全 softness 与二项尾

对固定 L'，精确 Bernstein 展开为

    P_(s,L')=Σ_(k=0)^n binom(n,k)s^k(1-s)^(n-k)G_(k,L'),

G_k 是所有恰有 k 个 phi 坐标、其余 h 坐标的 product 概率核的平均。每个 Bernstein 权≤1，因此

    sup_s P_(s,L')≤Σ_(k=0)^n G_(k,L').                (GC10)

在任意一个这样的 product 接收密度下，固定坐标带事件是 product 坐标事件，且每个概率≤p0。于是其计数由 Bin(N,p0) 的上尾控制。这个 product 只来自已固定 source tuple 后的接收核；绝没有假定原来源坐标独立或把 beta/nu 变成自由 product。

积分 GC10，每个 G_k 的相应事件概率≤B_(N,p0)(m)，所以共付 n+1。再对 N_grid 个向上尺度求正和并用 GC7，得到 GC6。没有未计费的 scale 或 softness supremum，也没有把固定尺度结果直接授给原 adaptive selector。

## GC5. 原来源回代与显式 root 分支

GC6 在每个 fixed source tuple 上成立。令 Nstar_grid=ceil(16n log2)+1，并置

    B_n=Lstar exp(1/16) Nstar_grid(n+1).               (GC11)

由 GC4、A,H≤1、GC6 和 GC3，原实际面层支满足

    Raw_original^+[M_S≥m]
      ≤(32Lambda/3)exp(1/16) Nstar_grid(n+1)
          EΣ_V∫ B_(N(u,v),p0)(m(u,v))dGamma_V^+.
                                                               (GC12)

如果保留 source 相关的 N,m，就保留这一真实平均，不能先为每个 source 层重领整份 W_A。一个统一可检验的选择是

    m_*(N)=min{m∈{1,...,N+1}:
                    B_n B_(N,p0)(m)≤sqrt(n)}.         (GC13)

尾和 m=N+1 为0，故定义总存在。m_* 只依原固定 source 的 N 和已付窗口上界，不依 receiver x。若 m_*=N+1，示例事件为空，不宣称有覆盖。对其余实际点，GC12 给

    Raw_original^+[M_S≥m_*(N)]
           ≤(32Lambda/3)sqrt(n)W_A.                  (GC14)

这是本稿新增的来源付款。无须 w_g(y,v) 下界；可与本轮实际 small-LCA/late/tiny/lowFtree 余域及任何原门相交，因此不只是无门模型的估计。代价使用 Wbeta≤W_A，没有偷换 nu 外槽。

为给出简单数量级，n≥2 时 p0≤1/4。在 m≥ceil(N/2) 上，用指数参数 log3 的初等 Markov 估计，

    B_(N,p0)(m)≤3^(-N/2)(3/4+3/4)^N
                   =(sqrt(3)/2)^N.                 (GC15)

因此若

    N≥ceil(log_+(B_n/sqrt(n))/log(2/sqrt(3))),
    M_S≥ceil(N/2),                                    (GC16)

则享受 GC14 的 root 价格。B_n=O(n^4)，所以该充分条件所需 N=O(log(n+2))，其隐含常数可由 GC2/11 原样计算；不把有限维数公式改成拟合。若 GC16 要求 N>n，它不产生该示例覆盖。一般结论仍是精确 GC12–14。

## GC6. 同 alpha / 原 K0 间隔迫入已付面层

本节只在已审 R186 HG 的实际资格上应用：取0<eta<kappa²、原 A_y(v)>1-eta，互反 bad-u，真实 a_v=TDelta_y(v)>0。令

    c_v=(DK0_v+alpha_y J_v)/a_v=1-rho_v,
    eta_eff=eta-c_v>0,
    w_u=w_g(y,u)>kappa,
    G_vu=log{ kappa²(1-eta)/[eta_eff(w_u²-kappa²)] }>0,
    j_s=log[(1-s+s phi(1/2))/(s phi(1/2))],
    Lphi=2/(1-exp(-1)).

原同点 J/current 间隔及 signed hard-face 恒等式给

    G_vu<Lphi||u-v||_1/L
             +j_s[N_L(u)-N_L(v)],
    N_L(z)=Σ_i1_{|x_i-z_i|≤L/2}.                      (GC17)

这里 G 保留原实际 Hhat 的 K0、同 alpha 和实际 capture Delta；没有分别取逆核上确界。对固定 S 的短位移坐标及其余 n-N 个坐标，总有

    N_L(u)-N_L(v)≤M_S+(n-N).

所以 j_s>0 时，原可直接检查的门

    G_vu≥Lphi||u-v||_1/L
                  +j_s[(n-N)+m_*(N)-1]               (GC18)

强制 M_S≥m_*(N)，并由 GC14 支付。GC17 是严格不等式，所以 GC18 的等号也合法。门可依 x,s,L、alpha 和全部原数据；证明只利用它包含于已经支付的固定 m_*(N) 面层，不把这些参数当成独立随机量。

s=1 时 j_s=0，GC17 的连续部分排除 GC18，不能除以零或将此门当另一个已付 soft 结论。m_*=N+1 时相应 GC18 在原 HG 下同样不可能成立，因为 M_S≤N。

若原 high-A/互反点未进入 GC14，则 M_S≤m_*(N)-1，并保留明确的必要上界

    G_vu<Lphi||u-v||_1/L
               +j_s[(n-N)+m_*(N)-1].                (GC19)

这说明一部分强 capture/互反极端间隔已可真实支付；余下间隔可由长位移、非短坐标数量或不足以达到 binomial tail 的少量 current 硬面承担。本稿没有证明这些余量具有小全局价格。

## GC7. 与原 upper-cut、其他已付支及未付积分的接缝

R193 TD18 的 sorted clock inversion 使用 y-v 位移和原 LCA 最坏时钟；GC5 使用 u-v 位移与 receiver 的 current 硬面。两者不同。不能从 closed upper-cut 失败或 tiny good 直接推断 GC16/18，也不能把主稿其他 y-v 几何分支的补集等同于本稿短 u-v many-face 事件。

合法结算是：先支付此前与本轮其他正几何支，再在其补集上取 GC14。每项独立的 root 来源价格按总账相加，例如两项同系数 root 价至多付两倍；不声称联合覆盖。没有消耗原负信用或重新构造森林。

在 GC14 之外，仍须控制原实际积分

    (32Lambda/3)EΣ_V∫Gamma_V^+
       ∫_Erec p_y A_x(y,v)H_core(x,j,t,y,v,u)
                      1_{M_S<m_*(N)}dx,              (GC20)

其中 H_core 继续保留 small-LCA、late、tiny、lowFtree、原 cut 失败及其余全部资格。GC19 是其 high-A 部分已经证明的同 alpha 物理约束。此处若直接丢掉 A/history 而只用全 current 包络，通常只能拿到 B_n=O(n^4) 的粗来源费，不能当成 root 付款；若为每个坐标/尺度分别使用该粗界还会重复来源。

因此本稿实际完成的是 GC6/12 的全 adaptive receiver 多面层估计、GC14 的 root 来源子支和 GC18 的原 capture 间隔回代。对于剩余少面或长位移的真实 cut 质量，尚无一般根阶或 epsilon 接收价。未认证 FULL 严格覆盖扩大，不把必要式 GC19 当作已付结论。本轮在此有界检查点停止。
