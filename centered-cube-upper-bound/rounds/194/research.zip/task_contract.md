# R194: actual geometric cost of ordered-capture failures

Start ad0dffacaa0389dccdb9cf3fa38898384ad990d6, clean main, correct origin. Previous round is verified progress, not closure. Goal remains arbitrary positive L1 centered-cube n^(1/2+o(1)) weak bound with true receivers and all windows.

Frozen R193 checkpoint: /Users/zhengzhihao/Desktop/T/output/centered_cube_round193_20261016_final_checkpoint. Read only the needed files. Frozen R192 analog contains original LS/CG/IF.

Current precise unpaid object: original positive reciprocal raw on LS-small ancestor P_u, late mass, tiny target and low-tree branch. R193 TD7 bounds it by C_rec integral q dx integral min(psi_A, 2/(1+c_u)+psi_d,u) d lambda; this is conditional, not paid. TD14/18 locate capacity failure in low neutral parent capacity or actual sorted inversion. Need a source or receiving-measure estimate of these actual configurations with sqrt(n) times logarithmic costs, not a renamed norm. Original lambda depends on receiver and FULL theta. Keep q fixed in each original window and the unique j indicator, same alpha/capture/K0, no nu<=beta.

Primary work: obtain an actual integrable geometric estimate for target/source relative position and coordinate multiplicity; no unproved independence. Allow known R188 lambda product domination, R191 single-direction source energy, R192 source-pair random-grid bound, R193 protected capacity and future-loss formulas, with original hypotheses. A conclusion may fail; record exact remaining weighted integral and do not call it a root budget.

Ownership: parent task_contract/main integration; Astra geometry_cost.md on actual failure geometry; Sol auxiliary source_capture_bridge.md on physical kernel versus protected neutral; independent Sol audit.md; Sol numerical plan/code only after accurate candidate available. No child Git, spawning, or edits to others. Only this round's work files may be created. Stop after assigned deliverable. Skill D01/B01 retained; apply geometric and error-budget skills as relevant. No PDF compilation.
