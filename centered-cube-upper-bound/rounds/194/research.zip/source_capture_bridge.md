# R194：实际捕获率、受保护 neutral 与 target 未来损失

本稿固定原 row 和 actual source，证明三件具体事实：有效 target 的同点 neutral 可做一个明确的部分匹配；该匹配缺口有保留同 α 的实际 Δ 公式；相邻来源点的捕获率可由快 target 的真实 overlap 时间差定量下界。最后一个结论保留全部尺度、硬面、capture eligibility 和 ν/μ 缺失费用。小 A 价格只作一致性校验，已被旧无权 RF 的直接价格压过；本稿没有取得一般高 A、tiny、late 余域的根阶来源预算。

## SC1. 原对象与零支

固定原 `(ω,V,x,j,y)`、初始 ell、终端 g、原 far 截止 h，保持 q 固定、全部 current/FIRST、history、原 Pi、删除和唯一 j(x)。沿用 R192 CG/IF 与 R193 TD/OC 的记号

\[
 \tau_0=a/c_j\le\ell\le h=g e^{-u_0/n}<g,
 \quad w_t(z)=\prod_i\min(1,C((y_i-z_i)/b)/\xi_t),\quad \xi_t=c_jt/b,
\]
\[
 \Delta_z=w_{\tau_0}(z)-w_h(z),\quad
 t_z=T\Delta_z,\quad k_z=DK_{0,z},\quad K_0=P_{s,\widehat H},
 \quad T={c_j^{n/2}\over g^n\sqrt{1+\log n}},
\]
\[
 \widehat H=\max\{a,\min[b,gc_j^{-1/2}m(s)(1+\log n)^{1/(2n)}]\},
 \quad m(s)=1-s+s\phi(1/2).
 \tag{SC1}
\]

这里 τ0 是物理时间，下面 target 测度记为 τ_tar，避免混淆。非空 far 行使用 ell<h；零时间行先取零。原 strictsoft 范围 s>0 使 p、J、K0 正；s=1 允许，硬跳此时为零。本文不通过 s↓0 的未证极限处理纯硬核。

令 μ=μ_hi、ν=ν_V，原 capture 集为 E，

\[
 \chi=1_E\min(1,t_z/k_z)\nu,\quad
 \rho_z=[1-(k_z+\alpha J_z)/t_z]_+,\quad
 A_z=1_{\rm good}\rho_z{J_z\over p_z+p_z^++J_z},
 \quad \Theta=A\nu.
 \tag{SC2}
\]

非 capture、t_z=0 等无效槽取 A=0。使用已审原资格

\[
 0\le\Theta\le\chi\le\nu\le\mu,\quad
 \operatorname{supp}\chi\subset Z_g(y),\quad
 R_\alpha=\alpha QJ=Dq-\int k\,d\chi,
 \quad \int k\,d(\mu-\chi)\le R_\alpha.
 \tag{SC3}
\]

没有 ν≤β、均匀来源密度或新树。原 e=e_g(y)>0，G_A(t)=∫A w_t dν，并保留

\[
 {G_A(g)\over e}\le{1\over6},\qquad
 e_t\ge e+G_A(t)-G_A(g).
 \tag{SC4}
\]

这是上界，不能反向用作正 target 质量。

## SC2. 实际 target 上捕获饱和及同点匹配

若 A_v>0，则 v 在原 capture 集且 t_v>k_v+αJ_v≥k_v，所以 χ 在该处的 ν 密度恰为 1。因此

\[
 (\chi-\Theta)|_{\{A>0\}}=(1-A)\nu|_{\{A>0\}}.
 \tag{SC5}
\]

对固定、沿辅助时间不变的 c>0，定义

\[
 A_{m,c}=\min\{A,(1-A)/c\},\qquad
 A_{d,c}=A-A_{m,c}={[(c+1)A-1]_+\over c}.
 \tag{SC6}
\]

在 A=0 处两者均为零。实际 neutral 中取 N_c=c A_m,c ν，则 N_c≤χ−Θ；其全局同点 coupling 将 w(v)N_c(dv) 与 c w(v)A_m,c(v)ν(dv) 在 z=v 处配对。原 sorted thresholds 完全相等，故对所有原 t 有

\[
 G_{N_c}(t)=cG_{m,c}(t),\qquad
 A_{m,c}\nu+N_c\le\chi\le\nu.
 \tag{SC7}
\]

这个 N 不需要位于 P_u∩B_born：原分母 e_t 可使用全局 terminal-surviving neutral。若坚持 R193 的局部供给 σ_u|P_u∩B_born，则同点 matched target 必须同限于该区域；区域外 target 仍是 defect，不能凭同点公式穿过 P_u 的限制。本文没有改变原实际 Pi 或把 coupling 变成交通。

R193 TD7 的逐 u 原 FTC 可直接用于 SC6–7：令

\[
 D_{d,c}=\int(w_\ell-w_g)A_{d,c}\,d\nu,
 \quad \psi_{d,c}={D_{d,c}\over e+D_{d,c}},\quad
 C_{\rm rec}={16\Lambda\over3K\kappa}.
\]

得到原正交通的接收形式

\[
 \mathrm{Raw}^+
 \le C_{\rm rec}\,\mathbb E\sum_V\int_{E_{\rm rec}}q\,dx
 \int\min\{\psi_A,2/(1+c)+\psi_{d,c}\}\,d\lambda_{x,V}.
 \tag{SC8}
\]

λ 是原实际 HB 校准测度，保留唯一 j、原 row/window、reciprocal 和全部原 mask；其共同 receiver 总质量界仍按原顺序使用。c 或 masked target 如依 u，必须先逐 u 固定并沿 t 不变、可测，不能逐运行 target/时刻更换同一分母的拆分。

特别对原片 A≤a0、0<a0<1，取 c=(1−a0)/a0，可用 c A 1_{A≤a0}ν≤(χ−Θ) 作完整匹配。该片实际价格为

\[
 \mathrm{Raw}^+[A(v)\le a_0]
 \le 2a_0 C_{\rm rec}\,\mathbb E\int_{E_{\rm rec}}q\,dx.
 \tag{SC9}
\]

故预分配 ε 后取 a0≤ε/(2C_rec) 可支付此片；独立窗口仍须分配各自 ε。直接用 e_t≥G_low(t)/a0 也得到同式。更重要的是，既有原无权 RF 界直接乘 A≤a0 已给 a0 C_rec 的更强价格。因此 SC9 仅校验本 partialmatching 接口的一致性，不登记新付款或覆盖改善。它不依赖局部父块质量，也不是一般高 A 余域的闭合。

## SC3. 高 A 与实际未来损失的正部公式

在 J_v>0 处写 r_v=(p_v+p_v^+)/J_v≥0。由 SC2、SC6，在 Δ_v>0 的原 capture 槽精确有

\[
 A_{d,c}(v)
 ={[(c-r_v)-(c+1)(k_v+\alpha J_v)/(T\Delta_v)]_+
       \over c(1+r_v)},
\]
\[
 \boxed{\Delta_v A_{d,c}(v)
 ={[(c-r_v)\Delta_v-(c+1)(k_v+\alpha J_v)/T]_+
       \over c(1+r_v)}.}
 \tag{SC10}
\]

域外 A_d=0。式子同时保留正部、k 和同 αJ，未将各项独立取最大。特别 A_v≥a0>0 必须满足

\[
 \rho_v\ge a_0(1+r_v),\quad
 r_v\le{1-a_0\over a_0},\quad
 {k_v+\alpha J_v\over T\Delta_v}\le1-a_0(1+r_v)\le1-a_0.
 \tag{SC11}
\]

因此高 A 既是 current 相对 J 小的区域，也是 capture 余量大的区域。若使用原共同合法 J 的 FIRST，则其真实 source 核质量还满足

\[
 \int_{\{A\ge a_0\}}(p+p^+)\,d\nu
 \le{1-a_0\over a_0}\int_{\{A\ge a_0\}}J\,d\nu
 \le{1-a_0\over a_0}q.
 \tag{SC12}
\]

SC12 不含原 raw 的后验分母或 p_y，因此不是单独的全局付款。

记 Ω(v)=log(w_ell(v)/w_g(v))，L(v)=log(w_τ0(v)/w_h(v))。真实曲线给

\[
 D_{d,c}=\int[1-e^{-\Omega(v)}]w_\ell(v)A_{d,c}(v)\,d\nu,
 \qquad L(v)\ge[\Omega(v)-u_0]_+.
 \tag{SC13}
\]

第二式由 w_τ0≥w_ell 与 log(w_h/w_g)≤u0 得到，而不是从两个 lower 相减。还可保守地用 w_ell−w_g≤Δ+(e^{u0}−1)w_g，将 SC10 代入得

\[
 {D_{d,c}\over e}
 \le {1\over e}\int
 {[(c-r_v)\Delta_v-(c+1)(k_v+\alpha J_v)/T]_+
        \over c(1+r_v)}\,d\nu
       +{e^{u_0}-1\over6}.
 \tag{SC14}
\]

SC14 没有 1/α，但保留了真实 prefix 的空间/来源积分和 suffix 的 e^{u0} 费用。若 u0 大，不能将最后一项当作小接收费；SC13 的准确曲线形式通常更强。SC10–14 是将 protected defect 接回真实 capture/loss 的接口，并未证明其接收平均小。

## SC4. 邻点的实际 Δ 模量：须保时间对比度

沿用 R192 IF 的原 C 与 log-weight 界：对任意原 t，

\[
 |\log w_t(z)-\log w_t(v)|\le d_C,
 \qquad d_C={18\|z-v\|_1\over b}.
 \tag{SC15}
\]

这是实际 C=h*max(h,φ) 的确定性界，不是假设来源坐标独立。直接对两个正项分别比较，得到

\[
 \Delta_z\ge e^{-d_C}w_{\tau_0}(v)-e^{d_C}w_h(v).
\]

对 Δ_v>0，故

\[
 \boxed{\Delta_z\ge\beta(d_C,L(v))\Delta_v,\quad
 \beta(d,L)=e^{-d}\left[1-{e^{2d}-1\over e^L-1}\right]_+.}
 \tag{SC16}
\]

取正部合法，因为原 τ0≤h 保证 Δ_z≥0。L=0 时 Δ_v=0，不使用分母，定义该退化下界为零即可。d=0、L>0 时 β=1。若 L≤2d，该方法只能给零下界；不能把两个 w 的乘性可比误写成 Δ 的免费乘性可比。

当 Ω(v)≥u0+η、η>0 时，L(v)≥η；于是统一半径 d≤D 给 β(d,L)≥β(D,η)。若 D>0 且

\[
 \eta\ge\log(2e^{2D}-1),
 \quad\text{则}\quad\beta(D,\eta)\ge\tfrac12e^{-D}.
 \tag{SC17}
\]

这是一个真实 future-loss/捕获率联系。已支付 low-Ω 片不自动使剩余满足所需 η：必须检查原 u0、η 和实际快 target 范围。

## SC5. 原 mixed K0 的有向硬面费用

令 f_s(r)=(1−s)1_{|r|≤1/2}+sφ(r)，

\[
 j_s=\log{1-s+s\phi(1/2)\over s\phi(1/2)},\quad
 N_H(z)=\#\{i:|x_i-z_i|\le H/2\},\quad
 L_\phi={2\over1-e^{-1}}.
\]

原去跳函数 f_s(r)exp(−j_s1_{|r|≤1/2}) 连续、偶且递减，log-Lipschitz 常数≤Lφ；这是 R192 IF 使用的 mixed-kernel 硬面分解，换 r/H 后常数变 Lφ/H。体积因子在同 H 的两来源比较中精确抵消。因此闭硬面计数给

\[
 -{L_\phi\|z-v\|_1\over\widehat H}
    +j_s[N_{\widehat H}(z)-N_{\widehat H}(v)]
 \le\log{K_{0,z}\over K_{0,v}}
 \le {L_\phi\|z-v\|_1\over\widehat H}
    +j_s[N_{\widehat H}(z)-N_{\widehat H}(v)].
 \tag{SC18}
\]

等号硬面属于 inside；signed 计数差不能无费改零。s=1 时 j_s=0；不设 Hhat=L，也不删除 Hhat 的原 clamp。

与 SC15 合并，实际 k/w 比较为

\[
 e^{-L_\phi d_1/\widehat H-d_C+j_s\Delta N}
 \le {k_z/w_\ell(z)\over k_v/w_\ell(v)}
 \le e^{L_\phi d_1/\widehat H+d_C+j_s\Delta N},
 \quad d_1=\|z-v\|_1,\quad\Delta N=N_{\widehat H}(z)-N_{\widehat H}(v).
 \tag{SC19}
\]

这是相邻空间块上可用的核/初始权可比性，所有坐标费用在指数内保留。

## SC6. 从高 A、快 target 转移到真实邻块捕获率

固定一个非空实际 target 片 V0，满足 A_v≥a0∈(0,1)、Ω(v)≥u0+η。取来源集 C0，使对每个相关 z∈C0、v∈V0 有 d1≤d0 且 ΔN≤m_+，其中 m_+≥0 是已核的统一上界。置

\[
 D_0=18d_0/b,\quad
 \Gamma_+={L_\phi d_0\over\widehat H}+j_s m_+,
 \quad c_{\rm cap}=\min\left(1,
 {\beta(D_0,\eta)e^{-\Gamma_+}\over1-a_0}\right).
 \tag{SC20}
\]

由 SC11 的 t_v/k_v≥1/(1−a0)、SC16 的 Δ_z 下界和 SC18 的 k_z 上界，对原 E 内的 z 得

\[
 {d\chi\over d\nu}(z)\ge c_{\rm cap}
 \quad(z\in C_0\cap E),\qquad
 {d(\chi-\Theta)\over d\nu}(z)
       \ge(c_{\rm cap}-A_z)_+.
 \tag{SC21}
\]

最后一步还用 N≥0。该结论使用同一原 χ；没有对每个 target 重选来源。统一条件可由整个固定片求出，须可测且沿辅助时间不变。若 V0 空，不生成任何捕获保证。

于是对任意实际物理 cut C⊂C0∩P_u∩B_born∩b^{-1}(U)，可直接积分

\[
 \sigma_u(U)\ge\int_{C\cap E}w_\ell(z)
                      (c_{\rm cap}-A_z)_+\,d\nu(z).
 \tag{SC22}
\]

它是 R193 protected-neutral cut 的实际核下界，且不需要再使用泛型弱对偶；但其右侧仍是实际 ν 的合格质量，不是 h(P) 或 μ 的无权质量。若 c_cap=1，则 C∩E 全部原 ν 都被实际捕获；这仍不保证 C∩E 内有足够 ν。

全捕获的充分门为 (1−a0)e^{Γ+}≤β(D0,η)。若 SC17 适用，一个便于核查但较强的门是

\[
 -\log(1-a_0)\ge\Gamma_++D_0+\log2.
 \tag{SC23}
\]

## SC7. 相邻块的维度费用与同 α 来源缺失

若两个轴平行、边长 S 的相邻 cube 的坐标区间并集长度均≤2S，则 d0≤2nS；特别 face 相邻也满足此保守界。因此

\[
 D_0\le36nS/b,\qquad
 \Gamma_+\le2L_\phi nS/\widehat H+j_s m_+,
 \quad m_+\le n.
 \tag{SC24}
\]

没有避开硬面时，j_s m_+ 必须保留；若整个两个块都在每个 Hhat 硬面的同一侧，才能令对应计数差为零。S 与 b 或 Hhat 同阶时，SC23 要求 1−a0 指数小；一般高 A>a_ε 并不足以触发全捕获。SC17 也要求 Ω 超过 u0 加一个 O(nS/b) 的真实对比度。tiny w_g 本身不保证该 future Ω：初始 w_ell 也可能很小。

原严格 soft 下，对每个物理 C 有精确缺失分解

\[
 \begin{aligned}
 \int_C w_\ell\,d(\chi-\Theta)
 ={}&\int_Cw_\ell\,d\mu-\int_Cw_\ell\,d\Theta
      -\int_Cw_\ell\,d(\mu-\nu)\\
 &-\int_{C\setminus E}w_\ell\,d\nu
      -\int_{C\cap E}w_\ell(1-t_z/k_z)_+\,d\nu.
 \end{aligned}
 \tag{SC25}
\]

SC21 将最后一项在合格邻块上控制为≤(1−c_cap)∫C∩E w_ell dν；域外 capture eligibility 的损失不可删。由于 μ−ν≤μ−χ，同 α 只给

\[
 \int k\,d(\mu-\nu)\le R_\alpha.
\]

若实际 C 上另外认证 k/w_ell≥m_C>0，则

\[
 \int_Cw_\ell\,d(\mu-\nu)\le R_\alpha/m_C.
 \tag{SC26}
\]

m_C 可由 SC19 连同一个实际 reference k_v/w_ell(v) 下界得到，但该 reference 本身不得归一为 1。高 A 给 k_v/(TΔ_v) 的**上界**，不提供 m_C 的正统一下界。因此 SC26 的 1/m_C 可能很大；同一 reserve 不能按每个块、cut、ancestor 独立重复领。此处没有 1/α 的人为分离，也没有把 ν 当成 μ，但低 K0/w 的物理代价仍真实存在。

## SC8. 实际付款范围与首个未付项

SC9 只作已付小 A 片的一致性校验；SC6、SC10–14 把原 defect 写为同 α 的正部未来损失；SC16–24 则使邻块未捕获损失有实际快 target 与跨硬面的可核查上界。它们适用于任意原正 L1 输入和真实 dx，不要求有限 source 或坐标独立。

尚未支付的是 SC8 在高 A 余域的实际接收平均，或 SC22/25 在原 small-LCA、late、tiny、low-tree 域中产生足够共同匹配比例的成本。具体缺口是实际 μ−ν 的低 k/w 加权缺失、E 外来源、排序 cut 的空间质量，以及 SC24 的维度/硬面损失。没有原来源密度或窗口质量帽可将这些项免费转成 h(P)；SC12 的单核 source 容量也未消除 raw 中的后验分母。

所有 λ、原唯一 j 和窗口在 SC8 前保持，独立窗口不得重复使用 ε 或同 α reserve。本文没有取得一般高 A 分支的 rootpolylog 来源价，不宣称一般 middle 层闭合，也不以条件邻块门登记严格扩大全部历史覆盖。到此停止。
