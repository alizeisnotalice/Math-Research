#!/usr/bin/env python3
"""Finite physical scalar affinity diagnostics, not interval certificates."""
import argparse
from fractions import Fraction as F
from functools import lru_cache
import hashlib
import json
from pathlib import Path
import time
import mpmath as mp
HERE=Path(__file__).resolve().parent

def runtime(dps):
    mp.mp.dps=dps
    half=mp.mpf(1)/2
    def val(q): return mp.mpf(q.numerator)/q.denominator
    @lru_cache(maxsize=65536)
    def phi(x):
        r=abs(x)
        if r<=half: return 1-mp.expint(3,half-r)-mp.expint(3,half+r)
        return mp.expint(3,r-half)-mp.expint(3,r+half)
    def C(r):
        r=abs(r)
        if r<=1: return 1-r+mp.mpf(1)/3-mp.expint(4,1)-mp.expint(4,r)+mp.expint(4,r+1)
        return mp.expint(4,r-1)-2*mp.expint(4,r)+mp.expint(4,r+1)
    def evaluate(etaq,lamq,dq):
        eta,lam,d=map(val,(etaq,lamq,dq));s=1-eta;face=lam/2
        def source(x): return (eta*(abs(x)<=face)+s*phi(x/lam))/lam
        cuts=[-mp.inf]+sorted(set([-face,mp.mpf(0),face,d-half,d,d+half]))+[mp.inf]
        affinity=mp.quad(lambda x:mp.sqrt(source(x)*phi(x-d)),cuts)
        norm=affinity/mp.sqrt(C(d))
        # One-sided trace at the positive hard face. The larger trace difference
        # gives a compact L1 witness; the discontinuity is never averaged away.
        J=eta/lam;length=J/20
        left=(eta+s*phi(half))/lam-phi(face-d)
        right=s*phi(half)/lam-phi(face-d)
        side='left' if abs(left)>=abs(right) else 'right'
        trace=left if side=='left' else right
        lo,hi=(face-length,face) if side=='left' else (face,face+length)
        witness_cuts=sorted(set([lo,hi]+[x for x in cuts if lo<x<hi]))
        # Fixed side formula at the single endpoint is irrelevant to its integral.
        def discrepancy(x):
            hard=1 if side=='left' else 0
            return (eta*hard+s*phi(x/lam))/lam-phi(x-d)
        witness=mp.quad(lambda x:abs(discrepancy(x)),witness_cuts)
        gap=eta**4/51200;near_threshold=eta**4/(36*51200)
        near=dq<=etaq**4/F(36*51200)
        normalized_upper=mp.exp(-3*gap/4)
        checks={'jump_trace_at_least_half_jump':abs(trace)>=J/2,
                'compact_L1_witness_at_least_jump_squared_over_80':witness>=J**2/80,
                'compact_L1_witness_at_least_eta_squared_over_80':witness>=eta**2/80,
                'unnormalized_gap':affinity<=1-gap}
        if near: checks['near_normalized_gap']=norm<=normalized_upper
        assert all(checks.values())
        def out(x):return mp.nstr(x,dps+5)
        return {'dps':dps,'affinity':out(affinity),'C':out(C(d)),
          'normalized_F':out(norm),'unnormalized_upper':out(1-gap),
          'normalized_upper':out(normalized_upper) if near else None,
          'near_displacement_bound_applicable':near,'J':out(J),
          'jump_trace_left':out(left),'jump_trace_right':out(right),'witness_side':side,
          'witness_length':out(length),'compact_L1_witness':out(witness),
          'jump_L1_lower':out(J**2/80),'eta_L1_lower':out(eta**2/80),
          'finite_integration_seams':[out(x) for x in cuts if not mp.isinf(x)],
          'checks':checks}
    return evaluate

def run():
    specs=[]
    for stage,eta in [('initial',F(1,2)),('stress',F(1,4)),('expanded',F(1,8))]:
        specs.extend([(stage,eta,F(1,2),F(0)),
                      (stage,eta,F(3,4),eta**4/F(36*51200)),
                      (stage,eta,F(1),F(1,2))])
    rows=[]
    # Run each precision in one block, then compare the retained decimal strings.
    for stage,eta,lam,d in specs:
        rows.append({'stage':stage,'eta':str(eta),'s':str(1-eta),'lambda':str(lam),'d':str(d),'runs':[]})
    for dps in (25,40):
        evaluate=runtime(dps)
        for row,(_,eta,lam,d) in zip(rows,specs): row['runs'].append(evaluate(eta,lam,d))
    for row in rows:
        low,high=row['runs']
        diffs={k:abs(mp.mpf(low[k])-mp.mpf(high[k])) for k in ('affinity','normalized_F','compact_L1_witness')}
        assert all(v<mp.mpf('1e-18') for v in diffs.values())
        row['absolute_precision_differences']={k:mp.nstr(v,12) for k,v in diffs.items()}
        row['precision_consistent_1e_minus_18']=True
    return {'schema':'r194_sparse_affinity_v1','dependencies':{'mpmath_version':mp.__version__,
       'mpmath_entry_sha256':hashlib.sha256(Path(mp.__file__).read_bytes()).hexdigest()},
       'inputs':{'task_contract.md':hashlib.sha256((HERE/'task_contract.md').read_bytes()).hexdigest()},
       'kernel_provenance':{'source_file':'R191 normalized_overlap_probe.py', 'source_sha256':'dfc3e6538990c6fe95e3d36a6c764321592017c27ca2228c38806e32a4ab7157', 'runtime_import_required':False},
       'formulas':{'source':'[(1-s)h(x/lambda)+s phi(x/lambda)]/lambda',
        'target':'phi(x-d)','denominator':'sqrt(C(d)); C=h*max(h,phi)',
        'jump':'J=eta/lambda; choose larger absolute one-sided discrepancy at +lambda/2',
        'L1_witness':'one chosen side of length J/20, contained in a smooth source region',
        'unnormalized_bound':'1-eta^4/51200',
        'near_threshold':'eta^4/(36*51200)',
        'near_normalized_bound':'exp(-3 eta^4/(4*51200))'},
       'case_count':9,'stage_counts':{'initial':3,'stress':3,'expanded':3},'precision_dps':[25,40],
       'cases':rows,'status':'PASS','limitations':[
        'Finite scalar physical kernels only; no original selector/FIRST/history or full source construction.',
        'Infinite mpmath quadrature and two-precision differences are numerical diagnostics, not directed intervals or certified error limits.',
        'The compact witness is a lower contribution to L1, not a claim to have integrated the full absolute difference.',
        'Near normalized bound is tested only at zero and its exact rational threshold; d=1/2 tests only the unnormalized bound.',
        'No uniform theorem, dimension-order fit, or optimality of the analytic constants is inferred.']}

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=HERE/'sparse_affinity_checks.json');args=ap.parse_args()
    start=time.monotonic();result=run();args.output.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print('PASS: 9 cases at 25/40 dps; elapsed_seconds='+str(round(time.monotonic()-start,3)))
