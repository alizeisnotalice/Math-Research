# R194: jump gap and sparse source displacement — actual source budget

Status: submitted for independent audit. This is a geometric subbranch for arbitrary original inputs, not a full general upper bound. The source geometry is fixed before receiver integration; it does not assume independence of source coordinates.

## SD1. Original normalized kernels and the exact jump

Let h=1_[-1/2,1/2], w(r)=integral_0^1 exp(-|r|/t)dt, phi=h*w. These are probability densities. phi is globally 1-Lipschitz: almost everywhere phi'(x)=w(x+1/2)-w(x-1/2), with w in [0,1]. Set f_s=(1-s)h+s phi and f_{s,lambda}(x)=lambda^{-1}f_s(x/lambda), lambda in [1/2,1]. Fix 0<eta<1 and 0<=s<=1-eta.

For any displacement d, D(x)=f_{s,lambda}(x)-phi(x-d) has at x0=lambda/2 a downward jump J=(1-s)/lambda>=eta. On either adjacent side, its smooth part has Lipschitz constant at most s/lambda^2+1<=5. One of its one-sided boundary values has absolute value at least J/2. On that same side, throughout an interval of length J/20 its absolute value is at least J/4. This interval encounters no other hard face: J<=2 and J/20<=1/10<lambda. Thus

    ||f_{s,lambda}-phi(.−d)||_1 >= J^2/80 >= eta^2/80.       (SD1)

The elementary Cauchy inequality for probability densities gives ||f-g||_1^2<=8(1-integral sqrt(fg)). Therefore, uniformly over all d and lambda,

    Aff(s,lambda,d):=integral sqrt(f_{s,lambda}(x)phi(x-d))dx
       <=1-eta^4/51200.                                    (SD2)

No numerical gap or order is inserted here. The one-sided values and Lipschitz estimates concern open intervals; face values do not affect this fixed-scale density integral.

## SD2. Normalized near-coordinate gap and far-coordinate envelope

Retain the original overlap C=h*max(h,phi), C(0)=1, with its proved log-Lipschitz constant18. Hence C(d)>=exp(-18d) for d>=0. Define

    delta_eta=eta^4/(36*51200), a0=3/(4*51200).

For 0<=d<=delta_eta, SD2 gives

    F(s,lambda,d):=Aff(s,lambda,d)/sqrt(C(d))
       <=exp(-a0 eta^4).                                  (SD3)

For arbitrary d<=R_n=5log n+1/2 use the R191 already-proved hard/phi and phi/phi normalized affinity estimates, F0<=1 and F1<=C_*sqrt(1+d), with absolute C_* independent of n,lambda,d. From sqrt((1-s)h+s phi)<=sqrt(1-s)sqrt(h)+sqrt(s)sqrt(phi),

    F(s,lambda,d)<=B_n:=1+C_*sqrt(1+R_n).                  (SD4)

C_* is the analytic constant from the frozen R191 proof, not a fitted value. All constants and the cutoff below are allowed to depend on that fixed constant.

For a fixed actual source pair (y,v) define d_i=|y_i-v_i|/b and m_eta=number{i:d_i>delta_eta}. The actual terminal support guarantees d_i<=R_n. By product integration for fixed s,L (lambda=L/b),

    integral sqrt(P_{s,L}(x-y)J_b(x-v)/product_i C(d_i))dx
       <=exp(-a0 eta^4(n-m_eta)) B_n^{m_eta}.              (SD5)

This is Tonelli for the receiver variable x at fixed source pair, not a probabilistic assertion about arbitrary beta or nu coordinates. If

    m_eta <= a0 eta^4 n/[2(log B_n+a0 eta^4)],             (SD6)

the right side is at most exp(-a0 eta^4 n/2).

## SD3. Entire adaptive soft and scale costs

Write the SD5 integrand as G_{s,L}(x). For each fixed L,x, (1-s)^(-n/2)G_{s,L}(x) is nondecreasing and continuous for 0<=s<=1-eta: each kernel factor f_s/(1-s)=h+s phi/(1-s) is nondecreasing. Weighted Stieltjes variation and integration by parts therefore give

    sup_{s<=1-eta}G_{s,L}
      <=G_{1-eta,L}+(n/2)integral_0^{1-eta}G_{s,L}/(1-s)ds.

Integrate x and use SD5 uniformly in s. The cost of the common adaptive soft parameter is exactly bounded by

    1+(n/2)log(1/eta).                                   (SD7)

It is not selected separately in each coordinate. For the scale, every f_s is even and nonincreasing in absolute radius. Thus L^(n/2)G_{s,L} is pointwise nondecreasing and right-continuous; so is its supremum over the compact soft interval. The same Stieltjes argument on [a,b], b/a<=2, gives an additional cost

    1+(n/2)log2.                                         (SD8)

Adaptive hard faces are included as Stieltjes atoms. No adaptive-face null-set argument is used. Combining these arguments,

    integral sup_{a<=L<=b,0<=s<=1-eta}G_{s,L}(x)dx
       <=[1+(n/2)log(1/eta)][1+(n/2)log2]
          exp(-a0 eta^4 n/2)                             (SD9)

for each fixed source pair satisfying SD6 and the original carrier.

## SD4. Return to original traffic

The original good relation and A=rho J/(3Q) imply

    p_y A(v)<=sqrt(K/3)*sqrt(p_y J_v/w_g(y,v)).

The terminal overlap satisfies w_g(y,v)>=product_i C(d_i). Use the already proved R186 fixed positive score/source measure Gamma_+, exactly as in R191 normalized_overlap_geometry.md §4, whose total mass is at most L_n W_A with L_n=O(n^2), carrying original j/time and independent of receiver. Keep the fixed-source carrier indicator 1{all d_i<=R_n}, obtained from the terminal support, until SD9 has been applied; it is not dropped before that step. Keep the geometric indicator SD6, which depends only on the fixed source pair and the window b,n, before receiver integration. Apply the positive receiver envelope SD9. With one hard cap16/3 and one outer factor2Lambda, the actual original positive subtraffic satisfies

    Raw[s<=1-eta; SD6]
      <=(32Lambda/3)sqrt(K/3)L_n
         [1+(n/2)log(1/eta)][1+(n/2)log2]
         exp(-a0 eta^4 n/2) W_A.                         (SD10)

Other original receiver indicators may be retained or positively dropped after the needed source carrier has been kept. No normalized posterior is replaced by a fixed source measure; only the previously established Gamma_+ domination is invoked. Original repeated windows and their parent source costs remain in W_A and the original ledger; this estimate creates no free window reuse. q is unchanged.

For eta_n=1/log(n+2), the prefactor is polynomial times log log(n+2), while the exponent is -a0 n/[2 log^4(n+2)]. Since n/log^4(n+2) divided by log n tends to infinity, the displayed expression is <=C Lambda sqrt(n) W_A for all n, with an absolute finite constant absorbing small dimensions and the fixed prior constants. This is an analytic asymptotic deduction, not a finite-dimensional fit. It supplies a genuine source-priced geometric branch throughout this soft range, including tiny terminal overlap where applicable.

## SD5. Exact remaining region and limitations

This result does not show that an original failed matching cut lies in SD6. On the complementary middle-soft region the original pair has more than the SD6 count of coordinates with |y_i-v_i|>b delta_eta. These moderate or large displacements must still be charged jointly with actual capture, hard-face crossing, current capacities and true receivers. The branch may overlap old paid gates; no strict enlargement of historical FULL coverage is asserted without an actual realization audit.

The small positive jump produces an eta^4 gap, not a claimed optimal eta^2 gap. The very small explicit coordinate radius and conservative constant are kept as proved. No estimate on arbitrary source-coordinate distribution is inferred from receiver tensorization. Numerical checks only inspect finite one-dimensional kernel instances at stated precision and cannot certify Gamma_+, FULL, or general dimension asymptotics.
