"""Outward upper rectangles for a continuous exponential occupation envelope."""
from flint import arb,ctx
import json
ctx.prec=256
rows=[]
for n in [1024,65536,1048576]:
    factor=(2*(1+arb(1)/(32*n))**n)/arb(n).sqrt()
    slope=arb(35)/1000*n
    for ratio in [2,16,256]:
        weight=factor/ratio
        crossing=arb(ratio).log()/slope
        exact=(crossing+1/slope)*weight-factor*(-slope).exp()/slope
        assert 0<crossing and crossing<1
        # Integrate after the substitution s=slope*lambda-log(ratio):
        # the constant plateau is exact, the decaying tail is bracketed by
        # lower/upper rectangles on [0,16] plus its analytic remainder.
        steps=1024
        dx=arb(16)/steps
        left=(1-(-16*arb(1)).exp())/(-(-dx).expm1())*dx
        tail=(-arb(16)).exp()-(-slope+arb(ratio).log()).exp()
        assert slope-arb(ratio).log()>16
        low=weight*(crossing+(left*(-dx).exp()+tail)/slope)
        high=weight*(crossing+(left+tail)/slope)
        assert 0<low and low<exact and exact<high
        deficit=factor*(-slope).exp()/slope
        assert deficit>0 and (exact+deficit).overlaps(weight*(1+arb(ratio).log())/slope)
        rows.append(dict(n=n,ratio=ratio,integral_per_unit_weight=str(exact/weight),
                         bracket_width_per_unit_weight=str((high-low)/weight)))
print(json.dumps(rows,indent=2))
