#!/usr/bin/env python3
"""Exact finite geometric pooled-label audit; no greedy-history assertion."""
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import hashlib,json,platform,socket,subprocess,sys
BASE=Path(__file__).resolve().parent
ALPHA=F(1,512)
SPECS=[('initial',3,3,1,False),('pressure_skew',8,4,1,True),
       ('expanded_all_neighbors',64,32,1,False),('expanded_four_clusters',64,32,4,False)]

def fs(x): return str(x)
def fixture(spec):
    name,H,m,G,skew=spec;n=H+1
    centers=[];points=[];radii=[]
    for i in range(H):
        g=i//(H//G);c=[F(0)]*n;c[i]=ALPHA/2;c[-1]=2*ALPHA*g
        x=[F(0)]*n;x[i]=F(1,2)+ALPHA/4;x[-1]=c[-1]
        centers.append(c);points.append(x);radii.append(ALPHA/F(64*(2**i if skew else 1)))
    volumes=[(2*r)**n for r in radii];V=sum(volumes,F(0));mu=[v/V for v in volumes]
    theta=[F(i+1,H*(H+1)) for i in range(H)]
    assert sum(theta)==F(1,2)
    incidence=[]
    for x,eta in zip(points,radii):
        row=[]
        for c in centers:
            inside=all(abs(a-b)+eta<F(1,2) for a,b in zip(x,c))
            outside=any(abs(a-b)-eta>F(1,2) for a,b in zip(x,c))
            assert inside or outside # whole receiver core has constant exact incidence
            row.append(inside)
        incidence.append(row)
    assert all([h for h,v in enumerate(row) if v]==[i] for i,row in enumerate(incidence))
    assert all(any(abs(x-y)>radii[i]+radii[j] for x,y in zip(points[i],points[j]))
               for i in range(H) for j in range(i))
    neighbors=[[h2 for h2,c2 in enumerate(centers)
                if max(abs(a-b) for a,b in zip(c,c2))<=ALPHA] for c in centers]
    p=[sum((mu[j] for j in range(H) if incidence[j][h]),F(0)) for h in range(H)]
    pp=[sum((mu[j] for j in range(H) if any(incidence[j][h2] for h2 in neighbors[h])),F(0)) for h in range(H)]
    first=[sum((theta[h] for h in range(H) if row[h]),F(0)) for row in incidence]
    assert max(first)<=sum(theta)==F(1,2)
    correct=sum((theta[h]*p[h]*pp[h]**(m-1) for h in range(H)),F(0))
    fixed=sum((theta[h]*p[h]**m for h in range(H)),F(0))
    unmarked=sum((theta[h]*pp[h]**(m-1) for h in range(H)),F(0))
    pooled_first=sum((theta[h]*pp[h]**m for h in range(H)),F(0))
    assert fixed<=correct<=max(first)
    # Finite-state exact integration retaining the source-identity mask.
    states={}
    for j in range(H):
        mask=sum(1<<h for h in range(H) if incidence[j][h]);states[mask]=states.get(mask,F(0))+mu[j]
    allowed=[sum(1<<h for h in range(H) if any(incidence[j][h2] for h2 in neighbors[h])) for j in range(H)]
    state_counts=[len(states)]
    for step in range(m-1):
        nxt={}
        for mask,mass in states.items():
            for j in range(H):
                key=mask&allowed[j];nxt[key]=nxt.get(key,F(0))+mass*mu[j]
        states=nxt;state_counts.append(len(states))
    dp=sum((mass*sum((theta[h] for h in range(H) if mask>>h&1),F(0)) for mask,mass in states.items()),F(0))
    assert dp==correct and sum(states.values())==1
    full=None
    if H**m<=5000:
        total=F(0)
        for draw in product(range(H),repeat=m):
            prob=F(1)
            for j in draw:prob*=mu[j]
            val=sum((theta[h] for h in range(H) if incidence[draw[0]][h]
                     and all(any(incidence[j][h2] for h2 in neighbors[h]) for j in draw[1:])),F(0))
            total+=prob*val
        assert total==correct;full=fs(total)
    example=None
    for h in range(H):
        choices=[j for j in range(H) if any(incidence[j][h2] for h2 in neighbors[h])]
        if len(choices)>=3:
            draw=[h]+[choices[(j+1)%len(choices)] for j in range(m-1)]
            if len(set(draw))>=3:
                example={'first_source':h,'receiver_indices':draw,
                         'replacement_sources':draw[1:],
                         'probability_exact':fs(__import__('functools').reduce(lambda x,j:x*mu[j],draw,F(1))),
                         'same_single_source_captures_all':False}
                assert all(incidence[j][j] and j in neighbors[h] for j in draw[1:]);break
    assert example is not None
    margin=min(F(1,2)-max(abs(c) for c in z) for z in centers)
    assert margin>0
    return {'name':name,'dimension':n,'source_count':H,'draws':m,'clusters':G,
            'alpha_exact':fs(ALPHA),'source_side_exact':'1','source_volume_bin':'[1,2)',
            'common_open_origin_cube_halfwidth_exact':fs(margin),
            'source_centers':[[fs(x) for x in c] for c in centers],
            'receiver_core_centers':[[fs(x) for x in c] for c in points],
            'receiver_core_halfwidths':[fs(r) for r in radii],
            'receiver_core_volumes':[fs(v) for v in volumes],'total_receiver_volume_exact':fs(V),
            'normalized_actual_receiver_weights':[fs(v) for v in mu],
            'theta':[fs(v) for v in theta],'theta_total_exact':'1/2',
            'whole_core_incidence_labels':[i for i in range(H)],'neighbors':neighbors,
            'p':[fs(v) for v in p],'p_plus':[fs(v) for v in pp],
            'first_row_marked_total_weights':[fs(v) for v in first],
            'first_row_max_marked_budget_exact':fs(max(first)),
            'first_row_expected_marked_budget_exact':fs(sum((mu[j]*first[j] for j in range(H)),F(0))),
            'mixed_moment_exact':fs(correct),'fixed_single_label_moment_exact':fs(fixed),
            'mixed_over_fixed_exact':fs(correct/fixed),
            'omitting_first_mark_exact':fs(unmarked),'omission_over_correct_exact':fs(unmarked/correct),
            'replacing_first_by_neighborhood_exact':fs(pooled_first),'pooled_first_over_correct_exact':fs(pooled_first/correct),
            'unmarked_total_over_first_row_max_exact':fs(sum(theta)/max(first)),
            'same_receiver_reused_all_draws_moment_exact':fs(sum((theta[h]*p[h] for h in range(H)),F(0))),
            'same_receiver_over_iid_exact':fs(sum((theta[h]*p[h] for h in range(H)),F(0))/correct),
            'exact_dp_moment':fs(dp),'dp_state_counts':state_counts,'full_cartesian_enumeration_moment':full,
            'different_replacement_sources_example':example}

def remote_checks():
    # Independent formula from explicit centers, not the local state-mask recursion.
    rows=[]
    for spec in SPECS:
        name,H,m,G,skew=spec;n=H+1
        eta=[ALPHA/F(64*(2**i if skew else 1)) for i in range(H)]
        volume=[(2*r)**n for r in eta];total=sum(volume,F(0));mass=[v/total for v in volume]
        theta=[F(i+1,H*(H+1)) for i in range(H)]
        pool=[sum((mass[j] for j in range(H) if i//(H//G)==j//(H//G)),F(0)) for i in range(H)]
        correct=sum((theta[i]*mass[i]*pool[i]**(m-1) for i in range(H)),F(0))
        fixed=sum((theta[i]*mass[i]**m for i in range(H)),F(0))
        omit=sum((theta[i]*pool[i]**(m-1) for i in range(H)),F(0))
        rows.append({'name':name,'mixed_moment_exact':fs(correct),'fixed_single_label_moment_exact':fs(fixed),
                     'omitting_first_mark_exact':fs(omit),'total_receiver_volume_exact':fs(total)})
    return {'host':socket.gethostname(),'python':platform.python_version(),'rows':rows}

if '--remote' in sys.argv:
    print(json.dumps(remote_checks()));sys.exit(0)

def main():
    rows=[fixture(s) for s in SPECS]
    cmd=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=5','macbook-math','/Users/zhengzhihao/.venv/bin/python -B - --remote']
    try:
        run=subprocess.run(cmd,input=Path(__file__).read_text(),text=True,capture_output=True,timeout=45)
        remote={'command':cmd,'exit_code':run.returncode,'stderr':run.stderr}
        if run.returncode==0:check=json.loads(run.stdout);remote['result']=check
        else:check=remote_checks();remote['local_fallback']=check
    except subprocess.TimeoutExpired:
        remote={'command':cmd,'timeout_seconds':45};check=remote_checks();remote['local_fallback']=check
    assert len(rows)==len(check['rows'])
    for a,b in zip(rows,check['rows']):
        for key in b:assert a[key]==b[key],(a['name'],key)
    remote['independent_formula_exact_match']=True
    output={'host':socket.gethostname(),'python':sys.executable,'python_version':platform.python_version(),
            'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'fixtures':rows,'remote':remote,
            'identities':['For independent actual receiver draws X1,...,Xm, E sum_h theta_h 1_Eh(X1) product_{a=2}^m 1_union_Nh(Xa) =sum_h theta_h p_h(p_h_plus)^(m-1).',
                          'Replacement source hprime may depend on both h and each later sample; it is not one fixed hprime for the entire tuple.',
                          'Pointwise first-row budget=sum_h theta_h 1_Eh(X1). Its exact maximum is recorded, and the marked mixed moment never exceeds it.',
                          'Dropping the first-row indicator gives sum_h theta_h (p_h_plus)^(m-1); replacing it by pooled membership gives sum_h theta_h (p_h_plus)^m. Both erroneous charges and exact inflation factors are recorded.'],
            'scope':['Exact rational finite physical cubes with positive-volume disjoint receiver cores; weights are their actual Lebesgue volumes normalized by the exact total. Every point of a receiver core has its recorded source incidence, so center representatives cause no approximation.',
                     'All source cubes have volume1 in the same dyadic shell. Neighborhood means coordinatewise center distance<=alpha*side_shell with alpha1/512. All sources contain a common open cube at the origin.',
                     'This is a finite geometric and IID integration model, not a newly constructed greedy history. The assigned theta values satisfy the tested first-row budget but are not claimed to be generated by a chronological greedy rule.',
                     'Local exact mask-state integration plus bounded full enumeration is compared with a separate exact rational closed-form implementation on MacBook when available. No remote files and no GPU are needed for these exact small computations.']}
    (BASE/'pooling.json').write_text(json.dumps(output,indent=2)+'\n')
    print(json.dumps({'remote':{k:v for k,v in remote.items() if k!='result'},'fixtures':[
        {k:r[k] for k in ('name','source_count','draws','mixed_moment_exact','omission_over_correct_exact','same_receiver_over_iid_exact')} for r in rows]},indent=2))
if __name__=='__main__':main()
