"""Compressed exact first-hit history. Output numerical enclosures from Arb."""
from fractions import Fraction as F
from math import comb,isqrt
from flint import arb,ctx
import json
def history(n,N):
    a=32*n
    alpha=F(4,a)
    pivot=1+3*alpha
    core=F(1,2*a)
    xc=F(3,2)-alpha/2
    dilation=1+F(6,n)
    assert xc-core>pivot*dilation and xc-core-2*alpha>dilation
    assert xc+core-(1+F(1,a))/2<1
    assert 2/a<(float(alpha))
    K=4096*isqrt(n)*a**n
    ell=arb(2).log()/K
    d=-(-ell).expm1()
    z=(-ell).exp()
    rp=(2*ell).exp()/2
    r0=ell.exp()/2
    tp=rp*d
    tags=-r0*(-2*N*ell).expm1()
    assert (-2*N*ell).exp()>arb(1)/2
    sumhigh=N*tp+tags-r0*z*d
    vt=arb(N+(2*N-1)*2**n)/a**n
    rh=sumhigh/a**n
    max_fraction=(tp+2*r0*d)/sumhigh
    assert 0<rh and rh<vt/4
    first_log=n*arb(32*n).log()+(K-3)*n*arb(4).log()+d.log()
    assert first_log>(arb(4)**n+2**n+N).log()
    return dict(n=n,receiver_count=str(N),R_high=str(rh),V_T=str(vt),
                max_true_tag_probability_upper=str(max_fraction),
                pooled_tag_probability='1',min_true_tag_probability='0 for the unused second tag of the first receiver',
                log_D_over_K_lower=str(first_log/K),
                log_D_over_K_upper=str((first_log+arb(3).log())/K),
                excess_at_one_quarter=0)
ctx.prec=256
print(json.dumps([history(n,N) for n in [64,256,1024] for N in [2,comb(n,n//2)]],indent=2))
