#!/usr/bin/env python3
"""Bounded real-point volume estimate audit. No greedy-history claim."""
from fractions import Fraction as F
from math import comb,factorial
from pathlib import Path
import hashlib,json,platform,socket,subprocess,sys
from decimal import Decimal as D,localcontext
sys.set_int_max_str_digits(100000)
BASE=Path(__file__).resolve().parent
BS=[4,6,8,10,12,16,24,32,48,64]
CS=[1,4,16,128]

def exact_fixtures():
    small=[]
    for n in (2,4,8,16):
        def irwin(t):
            return sum(((-1)**j*comb(n,j)*(t-j)**n for j in range(t.numerator//t.denominator+1)),F(0))/factorial(n)
        small.append({'n':n,'uniform_cube_side':'1','l1_radius':str(F(n,8)),
                      'centered_witness_small_ball_exact':str(irwin(F(n,4))),
                      'corner_witness_small_ball_exact':str(irwin(F(n,8)))})
    rows=[]
    for n in (8,16,64,512,1024):
        for kind in ('uniform_threshold','heterogeneous','saturated'):
            beta=F(65,64)+F(1,32*n)
            if kind=='uniform_threshold':delta=[F(1,8)]*n
            elif kind=='heterogeneous':delta=([F(1,16),F(3,16)]*(n//2))
            else:
                delta=[F(0)]*n;remaining=F(n,8)
                for i in range(n):
                    delta[i]=min(F(3,2),remaining);remaining-=delta[i]
                assert remaining==0
            w=[v/2 for v in delta];Y=[-v/2 for v in delta]
            p=[min(F(1),v/beta) for v in delta] # H/di=1, exactly rational
            k=n//512;dp=[F(1)]+[F(0)]*k
            for prob in p:
                nxt=[F(0)]*(k+1)
                for j in range(k+1):
                    nxt[j]+=dp[j]*(1-prob)
                    if j<k:nxt[j+1]+=dp[j]*prob
                dp=nxt
            tail=sum(dp,F(0))
            direct=None
            if n<=16:
                direct=sum((__import__('functools').reduce(lambda a,ip:a*(ip[1] if ip[0] else 1-ip[1]),zip(bits,p),F(1))
                           for bits in __import__('itertools').product((0,1),repeat=n) if sum(bits)<=k),F(0))
                assert tail==direct
            retained=sorted(delta,reverse=True)[k:]
            assert sum(delta)>=F(n,8) and max(delta)<=F(3,2)
            assert max(retained)>=F(1,8)-F(3,1024)
            assert sum(p)>=F(n,12) # max(1.5,beta*4^(1/n))=1.5 for n>=4
            rows.append({'n':n,'kind':kind,'H_over_di_exact':'1','beta_exact':str(beta),
                         'w_coordinates':[str(v) for v in w],'Y_coordinates':[str(v) for v in Y],
                         'p_coordinates':[str(v) for v in p],'l1_distance_exact':str(sum(delta)),
                         'mean_exact':str(sum(p)),'k':k,'poisson_binomial_tail_exact':str(tail),
                         'full_binary_enumeration_exact':None if direct is None else str(direct),
                         'largest_retained_difference_exact':str(max(retained)),
                         'retained_difference_required_exact':str(F(1,8)-F(3,1024)),
                         'associated_identical_bernoulli_tail_exact':str(1-p[0]) if kind=='uniform_threshold' else None})
    return {'small_ball':small,'poisson_binomial':rows}

def decimal_checks():
    with localcontext() as c:
        c.prec=110;one=D(1);out=[]
        for b in BS:
            n=1<<b;dn=D(n);beta=D(65)/64+one/(32*dn);M=max(D('1.5'),beta*(D(4).ln()/dn).exp())
            sm=dn*(one-D(4).ln()+one/32)
            a=dn/512-(one-(-one).exp())*dn/(8*M)
            for C in CS:
                far=D(4*C*n).ln()+dn*beta.ln()+a
                top=max(sm,far);diff=min(sm,far)-top
                total=top+(one+(diff.exp() if diff>D(-1000) else D(0))).ln()
                out.append({'b':b,'C':C,'log_total':str(total),'log_slack':str(-dn/64-total)})
        return {'host':socket.gethostname(),'python':platform.python_version(),'rows':out}

if '--remote' in sys.argv:
    e=exact_fixtures()
    # Independent odds/elementary-symmetric formula instead of forward Bernoulli DP.
    for row in e['poisson_binomial']:
        ps=[F(v) for v in row['p_coordinates']];forced=sum(q==1 for q in ps)
        budget=row['k']-forced
        if budget<0:other_tail=F(0)
        else:
            free=[q for q in ps if q!=1];zero=F(1);elementary=[F(1)]+[F(0)]*budget
            for q in free:
                zero*=1-q;odds=q/(1-q)
                for j in range(budget,0,-1):elementary[j]+=odds*elementary[j-1]
            other_tail=zero*sum(elementary,F(0))
        assert str(other_tail)==row['poisson_binomial_tail_exact']
        row['poisson_binomial_tail_exact']=str(other_tail)
    # Return exact probabilities and mean only; no large duplicated coordinate payload.
    print(json.dumps({'exact_small_ball':e['small_ball'],
                      'exact_poisson':[{k:r[k] for k in ('n','kind','mean_exact','poisson_binomial_tail_exact')} for r in e['poisson_binomial']],
                      'decimal':decimal_checks()}));sys.exit(0)

from flint import arb,ctx
ctx.prec=384

def st(x):return x.str(40)
def scalar(n,C,beta_add=F(1,64),max_difference=F(3,2),bits=384):
    ctx.prec=bits;A=arb;nn=A(n)
    beta=1+A(1)/(32*n)+A(beta_add.numerator)/beta_add.denominator
    candidate=beta*(A(4).log()/n).exp();M=max(A(max_difference.numerator)/max_difference.denominator,candidate)
    mean=nn/(8*M);small=nn*(1-A(4).log()+A(1)/32)
    tail=nn/512-(1-A(-1).exp())*mean
    far=A(4*C*n).log()+nn*beta.log()+tail
    top=max(small,far);total=top+(1+(min(small,far)-top).exp()).log();target=-nn/64
    assert total<target or total>target
    return {'n':str(n),'C':C,'beta':st(beta),'mean_lower_bound':st(mean),
            'log_small_ball_bound':st(small),'log_far_total_bound':st(far),'log_total_bound':st(total),
            'target_log':st(target),'log_slack':st(target-total),'passes':bool(total<target),'_total':total}

def first_pass(C):
    lo=64;hi=128
    while not scalar(hi,C)['passes']:hi*=2
    if scalar(lo,C)['passes']:return lo
    while hi-lo>1:
        mid=(hi+lo)//2
        if scalar(mid,C)['passes']:hi=mid
        else:lo=mid
    assert not scalar(hi-1,C)['passes'] and scalar(hi,C)['passes'];return hi

def main():
    exact=exact_fixtures();checks=[]
    for row in exact['poisson_binomial']:
        n=row['n'];mean=F(row['mean_exact']);tail=F(row['poisson_binomial_tail_exact'])
        cb=arb(row['k'])-(1-arb(-1).exp())*arb(mean.numerator)/mean.denominator
        if tail:
            logtail=(arb(tail.numerator)/tail.denominator).log();assert logtail<cb
            row['log_exact_tail']=st(logtail)
        else:row['log_exact_tail']='-infinity'
        row['chernoff_log_bound']=st(cb)
    for row in exact['small_ball']:
        n=row['n'];bound=arb(n)*(1-arb(4).log()+arb(1)/32)
        q=F(row['centered_witness_small_ball_exact'])
        assert (arb(q.numerator)/q.denominator).log()<bound
        row['supplied_small_ball_log_bound']=st(bound)
    samples=[]
    for b in BS:
        for C in CS:
            low=scalar(1<<b,C,bits=256);high=scalar(1<<b,C)
            assert low['_total'].overlaps(high['_total']);high['b']=b
            high['_float']=float(high.pop('_total'));samples.append(high)
    # Derivative in n of log_far+n/64 <=1/n+log(beta)+a+1/64.
    assert (arb(65)/64+arb(1)/128)*(arb(4).log()/4).exp()<arb(3)/2
    assert 1-arb(4).log()+arb(1)/32+arb(1)/64<0
    beta64=arb(65)/64+arb(1)/(32*64)
    derivative=arb(1)/64+beta64.log()+arb(1)/512-(1-arb(-1).exp())/12+arb(1)/64
    assert derivative<0
    thresholds=[]
    for C in CS:
        q=first_pass(C);a=scalar(q,C);b=scalar(q-1,C)
        del a['_total'];del b['_total'];thresholds.append({'C':C,'first_passing_integer_n_at_least64':q,'passing':a,'previous':b})
    negatives=[]
    for label,kw in [('larger_beta_padding',{'beta_add':F(1,16)}),('maximum_difference_doubled',{'max_difference':F(3)})]:
        r=scalar(1<<16,1,**kw);assert not r['passes'];del r['_total'];r['negative_control']=label;negatives.append(r)
    cmd=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=5','macbook-math','/Users/zhengzhihao/.venv/bin/python -B - --remote']
    try:
        run=subprocess.run(cmd,input=Path(__file__).read_text(),text=True,capture_output=True,timeout=45)
        remote={'command':cmd,'exit_code':run.returncode,'stderr':run.stderr}
        if run.returncode==0:other=json.loads(run.stdout);remote['result']=other
        else:other=None
    except subprocess.TimeoutExpired:remote={'command':cmd,'timeout':45};other=None
    if other is not None:
        clean=[{k:r[k] for k in ('n','kind','mean_exact','poisson_binomial_tail_exact')} for r in exact['poisson_binomial']]
        assert clean==other['exact_poisson']
        for a,b in zip(exact['small_ball'],other['exact_small_ball']):
            assert all(a[k]==v for k,v in b.items())
        assert len(samples)==len(other['decimal']['rows'])
        for a,b in zip(samples,other['decimal']['rows']):
            assert (a['b'],a['C'])==(b['b'],b['C'])
            assert abs(a['_float']-float(b['log_total']))<=max(1e-12,abs(a['_float'])*1e-12)
        remote['crosscheck_passed']=True
        remote['poisson_independent_algorithm']='Odds/elementary-symmetric coefficients after removing forced successes, compared with local forward Bernoulli convolution.'
    for r in samples:del r['_float']
    result={'host':socket.gethostname(),'python':sys.executable,'python_version':platform.python_version(),
            'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'definitions':['h=1+1/(32n), beta=h+1/64; dimension bins<=Cn, C=1,4,16,128.',
                           'Normalized total bound: exp[n(1-log4+1/32)]+4Cn beta^n exp[n/512-(1-exp(-1))*n/(8 max(1.5,beta4^(1/n)))]. Factor4 accounts for H/di<=4. The real threshold n/512, rather than its floor, conservatively enlarges the Chernoff bound.',
                           'For n>=4, beta4^(1/n)<1.5 and the mean lower bound is n/12. The maximum retained coordinate difference is at least1/8-1.5/512=125/1024.',
                           'The O(n) bin constant is not specified by the question; thresholds are conditional on each explicit choice of C.'],
            'dimension_samples':samples,'first_passing_thresholds':thresholds,
            'full_tail_monotonicity':{'minimum_n':64,'log_far_plus_n_over64_derivative_upper':st(derivative),
                                     'proof':'For n>=64 beta decreases; 1/n+log(beta64)+1/512-(1-e^-1)/12+1/64<0. The small-ball contribution after multiplication byexp(n/64) also decreases. Hence the total ratio to exp(-n/64) strictly decreases throughout all realn>=64.'},
            'exact_small_ball':exact['small_ball'],'exact_poisson_binomial':exact['poisson_binomial'],
            'negative_controls':negatives,'remote':remote,
            'scope':['Scalar volume bounds assume the supplied one-bin geometric estimate and independent Bernoulli coordinates. The exact rational w,Y fixtures retain physical positions but do not assert chronological first-witness status in a greedy history.',
                     'Actual small-ball probabilities are exact Lebesgue measures for uniform points in a unit cube, with centered/corner witness. No Monte Carlo is used.',
                     'Poisson-binomial tails use exact rational dynamic programming in dimensions8,16,64,512,1024 with threshold floor(n/512); dimensions8,16 also use full binary enumeration. Saturated and zero probabilities are included.',
                     'Reusing one uniform Bernoulli variable across axes gives probability1-p instead of the independent product, a recorded dependence negative control. Local Arb256/384 and remote Decimal110 check scalar values; remote Fraction probabilities agree exactly when connected.',
                     'Only realpoint.py/json are written; frozen pooling.py/json are untouched. No Git, remote files, background processes or GPU work.']}
    (BASE/'realpoint.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'remote_exit':remote.get('exit_code'),'crosscheck':remote.get('crosscheck_passed'),
                      'thresholds':[{k:r[k] for k in ('C','first_passing_integer_n_at_least64')} for r in thresholds],
                      'derivative':st(derivative),'samples':len(samples),'exact_tails':len(exact['poisson_binomial'])},indent=2))
if __name__=='__main__':main()
