"""Finite guards: exact rational winner/cancellation; high-precision coarea limit.
Decimal results are numerical evidence, not outward-rounded certificates.
Run python3 interface_guard.py; standard library only.
"""
from fractions import Fraction as F
from decimal import Decimal as D, localcontext
from pathlib import Path
import json


def maximal(atoms,x,a=F(1),b=F(2)):
    n=len(x)
    radii=[2*max(abs(t-y) for t,y in zip(x,z)) for z,w in atoms]
    rows=[]
    for r in sorted({a,b}|{r for r in radii if a<=r<=b}):
        mass=sum((w for (z,w),rr in zip(atoms,radii) if rr<=r),F(0))
        rows.append((mass/r**n,r))
    H=max(v for v,r in rows)
    return H,[r for v,r in rows if v==H]


def dec(q): return D(q.numerator)/D(q.denominator)


def run(precision):
    result={'precision':precision,'exact_cancellation':[],'coarea':[],
            'linear_quadratic':[],'scalar_hinge_checks':0}
    alpha=d=F(3,4)
    for n in [2,3,4,8,16,32,64,128,256]:
        delta=1-alpha**n
        atoms=[((F(0),)*n,alpha**n)]
        for s in [1,-1]:
            z=[F(0)]*n;z[1]=s*d
            atoms.append((tuple(z),delta/2))
        T=d/(100*n)
        for t in [T/4,T/2,3*T/4]:
            x=[F(0)]*n;x[0]=alpha*(d+t);x[1]=t
            Rs,R=2*alpha*(d+t),2*(d+t)
            H,win=maximal(atoms,x)
            assert H==R**(-n) and win==[Rs,R]
            tau=F(3,4)*(2*d)**(-n)
            assert tau<H<2*tau
            eps=T/100
            xm,xp=x.copy(),x.copy();xm[0]-=eps;xp[0]+=eps
            assert maximal(atoms,xm)[1]==[2*xm[0]]
            assert maximal(atoms,xp)[1]==[R]
            # Multiply normal by sqrt(1+alpha^2); exact rational densities.
            old=alpha**n*(R**(-n)-Rs**(-n))*(x[0]-alpha*x[1])
            near=delta/2*R**(-n)*(x[0]-alpha*(x[1]-d))
            far=delta/2*R**(-n)*(x[0]-alpha*(x[1]+d))
            assert old<0 and near==-old and far==0
        whole_negative=delta*alpha**(n-1)/4*T/(d+T)
        assert whole_negative>0
        result['exact_cancellation'].append({'n':n,'T':str(T),
          'source_negative_patch_integral':str(whole_negative),'centroid_patch_integral':'0'})
    with localcontext() as ctx:
        ctx.prec=precision
        # A two-atom orthogonal tube: only the two genuine arrival candidates.
        # Density in phase u=log(U_s/U_L) is proportional to exp(-u/n).
        for n in [2,4,16,64,256]:
            a=dec(alpha);ps=D(1);pl=2*a**n-1;dv=ps-pl
            for denom in [8,32,128,512,2048,8192]:
                t=D(1)/denom
                gm=((1-t*pl)/(1-t*ps)).ln()
                gp=((1+t*ps)/(1+t*pl)).ln()
                assert 0<gm<D('.5') and 0<gp<D('.5')
                nn=D(n)
                left=nn*gm-nn*nn*(1-(-gm/nn).exp())
                right=nn*nn*((gp/nn).exp()-1)-nn*gp
                ratio=(left+right)/(t*t*dv*dv)
                assert abs(ratio-1)<D('.08')
                if denom==8192: assert abs(ratio-1)<D('0.000001')
                result['coarea'].append({'n':n,'t_denominator':denom,
                  'switch_gain_over_t2_surface_coefficient':format(ratio,'.30g')})
        # The proposed finite hinge inequality, independent scalar pressure check.
        for pr in [D(-1),D('-.5'),D(0),D('.5'),D(1)]:
          for pl in [D(-1),D('-.5'),D(0),D('.5'),D(1)]:
            for z in [D('.001'),D('.1'),D(1)]:
              for g in [D(0),D('.01'),D('.3'),D(2)]:
                for t in [D('.125'),D('.5'),D('.9')]:
                  lhs=sum(max(D(0),z+(1+s*t*pr).ln(),z-g+(1+s*t*pl).ln()) for s in [-1,1])-2*z
                  rhs=(1-t*t*pr*pr).ln()+max(D(0),t/(1+t)*abs(pr-pl)-g)
                  assert lhs-rhs>=-D(10)**(-precision+5)
                  result['scalar_hinge_checks']+=1
    for n in [2,4,8,16]:
      for k in [2,4,8,16,32]:
        a=1-F(1,2**k);delta=1-a**n;r=F(7,4);d=F(3,4)*(1+a)
        x=[F(0)]*n;x[0]=d-r/2;x[1]=a*r/2
        z=[F(0)]*n;z[0]=d
        atoms=[((F(0),)*n,a**n),(tuple(z),delta)]
        assert maximal(atoms,x)==(r**(-n),[a*r,r])
        # tau=H/2, maximal |posterior difference|=2delta.
        ratio=n*d/(r*delta)
        assert ratio>0
        result['linear_quadratic'].append({'n':n,'k':k,'delta':str(delta),
         'centroid_density_over_tau_max_surface_fisher_density':str(ratio)})
    return result


if __name__=='__main__':
    low,high=run(70),run(110)
    assert low['coarea']==high['coarea']
    high['decimal_crosscheck']='70 and 110 digits agree to all 30 stored significant digits'
    high['status']='passed finite guards; no uniform dimension upper bound proved'
    Path(__file__).with_name('results.json').write_text(json.dumps(high,indent=2)+'\n')
    print(json.dumps({'cancellation_groups':len(high['exact_cancellation']),
      'coarea_groups':len(high['coarea']),'linear_quadratic_groups':len(high['linear_quadratic']),
      'scalar_hinge_checks_per_precision':high['scalar_hinge_checks'],'status':high['status']}))
