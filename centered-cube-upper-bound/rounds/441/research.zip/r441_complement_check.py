from pathlib import Path
import sympy as sp
u, m, p = sp.symbols('u m p', positive=True)
primitive = u * (sp.log(m/u) + 1)
residue = sp.simplify(sp.diff(primitive, u) - sp.log(m/u))
assert residue == 0
p1, p2 = sp.symbols('p1 p2', positive=True)
expanded = sum(x * (sp.log(m/(m*x)) + 1) for x in (p1, p2))
expected = p1 + p2 - p1*sp.log(p1) - p2*sp.log(p2)
entropy_residue = sp.simplify(sp.expand_log(expanded, force=True)-expected)
assert entropy_residue == 0
limit = sp.limit(primitive, u, 0, dir='+')
assert limit == 0
print('SymPy version:', sp.__version__)
print('clipped cell primitive residual:', residue)
print('zero mass endpoint limit:', limit)
print('two cell entropy identity residual:', entropy_residue)
print('Scope: scalar algebra only; no certification of original history or whole R433 bound.')
