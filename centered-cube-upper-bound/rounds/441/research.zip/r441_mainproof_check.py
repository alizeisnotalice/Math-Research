from fractions import Fraction as F
import sympy as sp


def q(x):
    x = F(x)
    return sp.Rational(x.numerator, x.denominator)


# Full signed derivative: the capture correction must retain both terms.
t = sp.symbols("t", positive=True)
g = sp.Function("g")(t)
ba = sp.Function("ba")(t)
bv = sp.Function("bv")(t)
ma, mv = sp.symbols("ma mv", positive=True)
pa = sp.log(ma) - sp.log(ba)
pv = sp.log(mv) - sp.log(bv)
xi = sp.log(ba) - sp.log(bv)
signed = sp.diff(g * pa, t) - sp.diff(g * pv, t) + sp.diff(g * xi, t)
assert sp.simplify(signed - sp.diff(g, t) * sp.log(ma / mv)) == 0
print("PASS symbolic signed derivative: all clipping-ratio terms cancel")


def clip_mass(parts, level):
    return sum((F(length) * min(F(density), level)
                for length, density in parts), F(0))


cases = [
    dict(ts=[F(1, 4), F(1), F(3)], f=F(2),
         ws=[F(1), F(1, 2), F(1, 4)],
         a=[(1, 2), (2, 1)], v=[(F(1, 2), 2)],
         ma=F(8), mv=F(2)),
    dict(ts=[F(1, 10), F(1, 5), F(8)], f=F(3, 2),
         ws=[F(3, 4), F(1, 3), F(0)],
         a=[(1, 3), (1, F(1, 2))], v=[(F(1, 3), 3)],
         ma=F(7), mv=F(3, 2)),
    dict(ts=[F(1, 8), F(2), F(5), F(9)], f=F(1),
         ws=[F(1), F(4, 5), F(1, 5), F(1, 10)],
         a=[(1, 1), (2, F(1, 3))], v=[(F(1, 2), 1)],
         ma=F(5), mv=F(1)),
]
for no, c in enumerate(cases, 1):
    ts, ws = c["ts"], c["ws"]
    gt = [min(c["f"], x) for x in ts]
    ell = sp.log(q(c["ma"] / c["mv"]))
    lhs = sum((q(ws[i]) * ell * q(gt[i + 1] - gt[i])
               for i in range(len(ts) - 1)), sp.S.Zero)
    terms = [[], [], []]
    for level, gi in zip(ts, gt):
        aa = clip_mass(c["a"], level)
        vv = clip_mass(c["v"], level)
        terms[0].append(q(gi) * sp.log(q(c["ma"] / aa)))
        terms[1].append(q(gi) * sp.log(q(c["mv"] / vv)))
        terms[2].append(q(gi) * sp.log(q(aa / vv)))

    def abel(xs):
        return (q(ws[-1]) * xs[-1] - q(ws[0]) * xs[0] +
                sum((q(ws[i] - ws[i + 1]) * xs[i + 1]
                     for i in range(len(ws) - 1)), sp.S.Zero))

    rhs = abel(terms[0]) - abel(terms[1]) + abel(terms[2])
    assert sp.simplify(sp.expand_log(rhs - lhs, force=True)) == 0
    assert all(x >= y for x, y in zip(ws, ws[1:]))
    print(f"PASS finite case {no}: jump identity; terminal weight {ws[-1]}")

    # Complete the parent by an additional positive-density source piece,
    # so the clipping mass tends to its actual prescribed full mass.
    parts = list(c["a"])
    inside = sum((F(l) * F(d) for l, d in parts), F(0))
    assert inside < c["ma"]
    parts.append((c["ma"] - inside, F(1)))
    levels = [F(0)] + sorted({F(d) for _, d in parts})
    masses = [clip_mass(parts, lev) for lev in levels]
    assert masses[0] == 0 and masses[-1] == c["ma"]

    def primitive(u):
        return q(u) * (1 + sp.log(q(c["ma"] / u))) if u else sp.S.Zero

    bulk = sum((primitive(v) - primitive(u)
                for u, v in zip(masses, masses[1:])), sp.S.Zero)
    assert sp.simplify(bulk - q(c["ma"])) == 0
    cells = [F(l) * F(d) for l, d in parts]
    total_phi = sum((primitive(v) for v in cells), sp.S.Zero)
    cell_entropy = sum((q(v) * sp.log(q(c["ma"] / v))
                        for v in cells), sp.S.Zero)
    assert sp.simplify(total_phi - cell_entropy - bulk) == 0
    print(f"PASS finite case {no}: bulk = full mass; cell-entropy decomposition")

u, mass = sp.symbols("u mass", positive=True)
assert sp.simplify(sp.diff(u * (1 + sp.log(mass / u)), u) - sp.log(mass / u)) == 0
print("PASS symbolic bulk primitive, including the zero-endpoint limit")
assert sp.limit(u * (1 + sp.log(mass / u)), u, 0, dir="+") == 0
print("Scope: exact symbolic/finite clipping algebra, not native history or root-budget evidence")
