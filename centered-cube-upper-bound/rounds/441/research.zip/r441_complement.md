# R441 complement：原父端投影收费与势函数可积性

结论：得到原流真实父端的边界熵付款
\[
 \int L_t(A,z)\,dP\le Sr C_\delta A_nW. \tag{1}
\]
另得到不要求 \(f\log f\) 可积的 native 全势粗预算，并据此证明原父端、原终端势均可积。这些是可用估计；没有证明全 R433 根阶预算。仅使用 /tmp/r441_contract.md 的同一原流与 /tmp/r435_contract.md 的准确负载，以及 /tmp/r440_geometry.md 的 native 几何预算；不改变历史、来源或阶段 early 比例。

## 1. 原父端真实投影

记 \(c_A(z)=1_{Q_A}(z)\)、\(\sigma(dA)=q_A\,dA\)，\(P_{\rm par}\) 是原路径测度 \(P\) 到 \((t,z,A)\) 的投影。对每一原起始记录，完整未来路径的保留权与终端选择总质量不超过一。先保留该起始记录，再积分旧来源 \(\pi_A\)、原标记和未来路径，利用 \(a_i^e\le B_e\)、\(\sum_eB_e=S\)，得
\[
 P_{\rm par}(dt,dz,dA)
 \le S q_A\,1_{\{f(z)>t\}}\frac{c_A(z)}{m_A}\,dt\,dz\,dA
 \le S\lambda\,N(dt,dz,dA). \tag{2}
\]
这里 stage 窗口 \([T_{i-1},T_i)\) 对固定 \(t\) 只选择原阶段；原 stage-averaged early 比例和所有历史门只在这个真实投影上作正限制，没有以新来源或任意 RN 帽代替它们。

令 \(C_\delta=(1+\delta/a)^n\le e^{1/n}\)、\(\delta=a/n^2\)。R440 已证
\(\int L\,dN\le C_\delta A_nW/q\)。以 (2) 应用于非负 \(L\) 即得 (1)。这里 \(\lambda/q=r\)，没有额外遗失 \(q\) 因子。

## 2. Native 全势的有限粗预算

对固定真实 receiver \(v\)，令 \(b_C(t)=B_{vC}(t)\)、\(m=m_v\)。\(b_C\) 绝对连续，且
\[
 \int_0^\infty b'_C(t)\log\frac{m}{b_C(t)}\,dt
 =b_C(\infty)\left[1+\log\frac{m}{b_C(\infty)}\right]. \tag{3}
\]
零质量项定义为零；零端点合法是因为 \(u\log(m/u)\to0\)。因此，对 \(p_{vC}=b_C(\infty)/m_v\)，
\[
 \int_0^\infty\int_{Q_v}1_{\{f(z)>t\}}
 \Phi_t(v,z)\frac{dz\,dt}{m_v}
 =1+H((p_{vC})_C). \tag{4}
\]
边长不超过 \(b\le2a\) 的真实立方体最多与
\(N_\delta=(2+\lceil b/\delta\rceil)^n\le(2n^2+2)^n\)
个正体积网格 cell 相交，故 \(H\le\log N_\delta\)。再积分真实 Lebesgue 中心，利用
\(\lvert E\rvert=\int N\le A_nW/q\)，得到
\[
 \int\Phi\,dN
 \le H_n A_nW/q,
 \qquad H_n=1+n\log(2n^2+2). \tag{5}
\]
这只是 \(O(n^2\log n)W/q\) 级的全势预算。它证明势可积，但不提供所需根阶收益。

由 (2)、(5)，
\[
 \int\Phi_t(A,z)\,dP\le Sr H_nA_nW. \tag{6}
\]
原终端列核界必须逐起始记录使用。按这种顺序保留起始权再积分，才得到粗比较
\[
 P_{\rm term}\le\frac{S\Theta}{h}
 \left(\int\frac{q_Ac_A(z)}{m_A}\,dA\right)N
 \le\frac{S\Theta rA_n}{h}N. \tag{7}
\]
第二步仅用 \(q_A\le\lambda\)、\(J(z)\le A_n/q\)。因此原终端 \(\Phi_t(v,z)\) 与 \(L_t(v,z)\) 也可积。式 (7) 是由原起始权推出的粗帽，仅用于这里的可积性；它的大小不足以给全目标付款，也没有声称它是一个可任意假设的 uniform arrival 定理。

## 3. 仍须证明的有符号比较

以下相同 \(t,z,C=C(z)\) 及真实父端、终端上的恒等式没有 \(\infty-\infty\)：
\[
 \log\frac{m_A}{m_v}
 =\log\frac{m_A}{M_C(t)}-\Phi_t(v,z)+L_t(v,z). \tag{8}
\]
上一节已保证其各项按 \(P\) 可积。特别地，将原 capture 正部上放为 \(L_v\) 后，不能再把初端 \(L_A\) 作为独立必要价格叠加：它在 (8) 中已精确消去。

若主线的 native exponential-moment/Fenchel 候选通过独审，给出同一原流的
\[
 \int L_v\,dP\le
 2\log_+\!\frac{S\Theta A_n}{qh}\,R
 +4rC_\delta A_nW,
 \qquad R=P(\Omega), \tag{9}
\]
则这里只剩真实有符号项
\[
 Q=\int\left[\log\frac{m_A}{M_C(t)}-\Phi_t(v,z)\right]dP. \tag{10}
\]
(9) 在本文仅作尚待独审的条件输入，不重复其证明。要关闭目标仍须给 (10) 适当的 \(\varepsilon\sqrt nX+O_\varepsilon(n\,\mathrm{polylog}(n)W)\) 价格（可保留可吸收的 \(O(\log n)R\)）。式 (2) 只控制初端正投影，不比较终端与初端的有符号势；式 (5) 的粗预算也不足以完成此步。本文不把重写 (10)、原删除费用的符号或有限探针当作该比较的证明。

本轮到此停止。独立实质收据为 (1)、(5) 及其带原起始权的可积性后果；全 R433 结论仍未闭合。

## 本机核验范围

实际运行 /tmp/r441_complement_check.py（Python 数学环境，SymPy）核验 (3) 的原函数、零端点极限与两 cell 熵代数，残差均为零，输出 /tmp/r441_complement_check.txt。这仅核标量代数，不认证历史门或全维目标。未运行 LP、模型扫描或特殊几何实验。
