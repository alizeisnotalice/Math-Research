# R441：真实质量门与保三项的阶段驻留核查

**结论。** 原 R433 上的 \(\log(m_A/m_v)>2\sqrt n\) 比较有效。同一完整原流的父端 bulk-clipping 对数项可付 \(SX_q\)，可在除以质量门后吸收；这是 R439 连续填充工具的全 profile 应用，不是一般闭合。父端 cell 集中与负终端势仍共同保留。直接三势分部积分的比例导数完全相消，不能再从其中抽取额外信用。

## 1. 原质量门的直接来源

引用均为仓库 `rounds/轮号/research.zip` 的原成员行号，本轮实际读档。

* **R425 `r425_main.md:59–69`**：从同一 \(\Pi_{423}\) 的 A 余项取
  \(\chi_B=\min(1,e\sum_v(Km_v/m_A)^{1/\sqrt n})\)。正余支给全部初始、后继、终端 \(m_v<m_A/K^2\)。第69行明确这是保留流的门，不将原生成步的 \(K\) 下降改为 \(K^2\)。
* **R423 `r423_main.md:7–20`**：完整 \(m_v=f(Q_v)=q_vR_v^n\)、真实中心测度固定；旧链保来源 \(y\)，新链保来源 \(z\)，严格 \(K\) 降质量到 own-low 停止，终端只计一次。未来筛选后的路径不重新归一。
* **R428 `r428_main.md:9–11`**：保留原阶段、首次删除、来源、soft 及 R427 裁剪；完整匹配质量区间与严格下降保证路径统一有限。路径代数不是删除阶段。
* **R433 `r433_main.md:99–106,129–138`**：R433 是此前同一原流的进一步正限制，保全部原路径/质量/历史。

因此取**新来源链的实际终端** \(v\)，若初始节点为 \(v_0\)，原剩余支有
\[
 m_A>K^2m_{v_0}\ge K^2m_v,\qquad
 \ell(A,v):=\log(m_A/m_v)>2\sqrt n.
\tag{1}
\]
后一个非严格比较只用实际路径质量下降；不用新增历史资格。零流单独处理。又由实际 octave 匹配，
\[
 0<\ell(A,v)\le B_m:=\log(\lambda/q)+n\log(b/a).
\tag{2}
\]
若两门不相容，则该支为空。原终端、父、两来源、阶段和全部历史仍为原标签。

令 \(\mathcal P\) 为合同指定的 R440 averaged-early level 提升。其总量仍为 R433。准确充分目标是
\[
 \int\ell\,d\mathcal P
 \le 2\epsilon\sqrt n\,X_q+
 C_\epsilon n\log^a(n+2)W.
\tag{3}
\]
(1) 可将 (3) 除以 \(2\sqrt n\) 回代；这仅是比较，**不是已证新估计**。

## 2. 唯一尝试：在同一记录上保三项作驻留分部积分

固定原共同记录：首次删除 \(j\)、方向、父 \(A\)、两来源 \(y,z\)、原时钟和两条完整路径，终端 \(v\) 随该记录确定。微格 \(C=C(z)\) 固定，记
\[
 B_u(t)=\int_{Q_u\cap C}\min(f,t),\quad
 M(t)=\int_C\min(f,t),\quad
 \Phi_u(t)=\log\frac{m_u}{B_u(t)},\quad
 \Xi(t)=\log\frac{B_A(t)}{B_v(t)}.
\]
对实际来源记录，\(B_A(t),B_v(t)>0\) 对所有 \(t>0\) 几乎处处成立；零来源不贡献。只在这些记录上写 logarithm。原生绝对连续来源保证 \(B_u\) 局部绝对连续。

精确恒等式是
\[
 \ell=\Phi_A(t)-\Phi_v(t)+\Xi(t).
\tag{4}
\]
保住正的父势和负的终端势，不把 \(\Phi_A\) 删除。特别地，\(\Phi_A,\Phi_v\ge0\)，而 \(\Xi\) 可有任意符号。

令 \(g(t)=\min(f(z),t)\)。在几乎处处可微点，
\[
\begin{aligned}
 d(g\Phi_A)&=\Phi_A\,dg-g\,B_A'/B_A\,dt,\\
 d(g\Phi_v)&=\Phi_v\,dg-g\,B_v'/B_v\,dt,\\
 d(g\Xi)&=\Xi\,dg+
               g(B_A'/B_A-B_v'/B_v)\,dt.
\end{aligned}\tag{5}
\]
三式按 (4) 的符号相加，所有比例导数**逐记录精确取消**：
\[
 d\{g\Phi_A-g\Phi_v+g\Xi\}=\ell\,dg.
\tag{6}
\]
这个抵消保留了真实两个交集 \(Q_A\cap C,Q_v\cap C\)，没有用独立坐标、来源密度帽或 \(D_{\max}\)。

因此把 \(-gB_A'/B_A\) 当作有利的 clipped-source 耗散，却仍把其在 \(\Xi\) 中的正同项忽略，是重复获益。R440 的原生熵积分不能只凭这次分部积分自动补上删除费用。

## 3. 原 stage 权和跳跃的确切费用

将固定记录的原权记为 \(w_i\in[0,1]\)。它含
\(1_{i\le j}\)、原 averaged early 比例、\((1-s/D_i(z))_+\)、当前高边缘/高旧源门，以及全部原固定权。R440 已逐原档核得 \(w_{i+1}\le w_i\)。它在阶段内固定；不能换成真实 level early 指标。原方向及 \(\Delta\Gamma_j\)、新来源的固定投影 \(c_A(z)dz/m_A\)、原路径核组成共同正记录测度 \(d\Lambda\)，故
\[
 d\mathcal P
 =\sum_i1_{[T_{i-1},T_i)}(t)\,1_{\{f(z)>t\}}
                 w_i\,dt\,d\Lambda.
\tag{7}
\]
这里没有丢掉另一来源或其条件核。

对有限 \(N\)，逐记录的精确 Abel 式为
\[
\begin{aligned}
 \sum_{i=1}^N w_i\ell[g(T_i)-g(T_{i-1})]
 ={}&\ell g(T_N)w_{N+1}-\ell g(T_0)w_1\\
 &+\sum_{i=1}^N\ell g(T_i)(w_i-w_{i+1}).
\end{aligned}\tag{8}
\]
这保原删除原子、大阈值跳及有限终端。用 (5) 分别对三势积分后相加，恰好得到同一个 (8)；没有额外负项。若另限制 R439 的 filled 正支，则阶段内新增 \(dw_i\ge0\) 的开启部分，右端还要减
\(\sum_i\int\ell g(t)\,d_{\rm fill}w_i(t)\)，stage 删除项及终端保持。这是同一原 light/filled 分拆，不是整个 R433 自动多得一笔负信用。

所有身份先在有限阶段、正 clipping 下端及有界各势上成立。解除截断时必须先按 (4) 合并三项；由 (2)、原正费用有限和 \(\int fD_0=2G_0\le SX_q\) 控制联合表达。不能在各势积分可能为无穷时分别减去它们。原有限尚存边仍按原清空合同处理，未在 (8) 中提前丢掉。

## 4. 同一全流的父端 bulk-clipping 项可精确支付

记 \(m_t(A)=\int_{Q_A}\min(f,t)\)。原 \(\mathcal P\) 到 \((A,z,t)\) 的正推前满足
\[
 d\mathcal P_{A,z,t}\le
 S\,\sigma(dA)\frac{c_A(z)}{m_A}1_{\{f(z)>t\}}\,dz\,dt.
\tag{9}
\]
理由是 level 区间只选择一个原阶段，\(\sum_e B_e=S\)，旧源后验、原路径及其他权的总积分至多 1；保原 averaged early 权而仅在上界中去掉。没有每阶段一份 \(S\)，没有来源刷新。

父势的精确正分解为
\[
 \Phi_A(t)=
 \underbrace{\log\frac{m_A}{m_t(A)}}_{\mathrm{bulk}}
 +\underbrace{\log\frac{m_t(A)}{B_A(t)}}_{\mathrm{cell}}.
\tag{10}
\]
两项均非负。由于 \(m_t(A)\) 绝对连续、从 0 增至完整 \(m_A\)，Tonelli 和变量替换给
\[
\begin{aligned}
 \int \log\frac{m_A}{m_t(A)}\,d\mathcal P
 &\le S\int\frac{\sigma(dA)}{m_A}
          \int_0^\infty m_t'(A)\log\frac{m_A}{m_t(A)}\,dt\\
 &=S\int\frac{\sigma(dA)}{m_A}
             \int_0^{m_A}\log\frac{m_A}{u}\,du
 =SX_q.
\end{aligned}\tag{11}
\]
原 level 下端若为 \(T_0>0\)，这里只是将非负积分扩到 0。零导数、密度平台和原阶段跳都不影响此式。完整 \(m_A>0\)，所以 \(m_t(A)>0\) 对 \(t>0\)；\(t=0\) 不取对数。

这对 full R433 成立，不限于 R439 的 filled 支。它是 R439 低填充连续积分思想的全对数 profile 应用：若先限制 filled，则已有 bulk \(\le\log(1/\tau_{\rm fill})\)；(11) 没有再加该支或旧费用，亦不退款 R439 已用的价格。

### 有限性，不能以 \(n\log n\,X_q\) 冒充付款

每个实际父与边长 \(\delta\) 的网格相交的正来源格数至多
\(N_\delta=(b/\delta+2)^n\)。固定父的有限分割 \(B_C(t)=\int_{Q_A\cap C}\min(f,t)\) 满足
\[
 \int_0^\infty\sum_C B_C'(t)
             \log\frac{m_A}{B_C(t)}\,dt
 =\sum_{C:B_C(\infty)>0}B_C(\infty)
       \left[1+\log\frac{m_A}{B_C(\infty)}\right]
 \le m_A(1+\log N_\delta).
\tag{12}
\]
这是每个格的真实 clipped 交集质量从 0 增至完整质量的积分；零格跳过。等价地，cell 项的全 profile 积分为完整父 cell Shannon entropy。由 (9)，
\(\int\Phi_A\,d\mathcal P\le S(1+\log N_\delta)X_q<\infty\)。
此上界**仅证明合法性**，不记入根阶预算。

## 5. 与同一原流的捕获收据整合，终端 signed cell 项不省略

正捕获修正确有
\[
 \Xi_+(t)\le\log\frac{M(t)}{B_v(t)}=:L_t(v,z).
\tag{13}
\]
R440 证明的是
\[
 \int L_t(v,z)\,
  1_{\{f(z)>t\}}c_v(z)\,dz\,dt\,\frac{dv}{m_v}
 \le e^{1/n}A_nW/q.
\tag{14}
\]
原 \(\mathcal P\) 到 \((t,z,v)\) 的推前不能直接无系数替换为 (14)。本轮几何作者在同一 \(\mathcal P\) 上使用原终端帽和原生幂矩，已证明如下捕获收据（`/tmp/r441_geometry.md` §1–4，式(1)；本稿已读取该准确接口，不重做或另收一份）：
\[
 \int \Xi_+\,d\mathcal P
 \le a_{\rm cap} R433+C_{\rm cap}W,\quad
 a_{\rm cap}=2\log_+M_*,
 \quad C_{\rm cap}=4r(1+\delta/a)^n A_n,
\tag{15}
\]
准确取 \(M_*=SA_n/(\lambda h)\)，\(r=\lambda/q\)；放大为 \(SA_n/(qh)\) 也安全。以下整合引用该已证原到达收据，不由 (14) 自行推出。R440 当时缺少这一步，本轮不再将捕获项列为未付。

由 \(\Phi_v=\Phi_A+\Xi-\ell\le\Phi_A+\Xi_+\)，(12)、(15) 保证终端势可积。于是
\[
 E_{\rm cell}
 :=\int\left[
       \log\frac{m_t(A)}{B_A(t)}-\Phi_v(t)
       \right]d\mathcal P
\tag{16}
\]
是合法的有符号有限积分，保全部原记录及另一来源，不是无穷减无穷。由 (4)、(10)、(11)、(15)，得到
\[
 \boxed{\quad
 (2\sqrt n-a_{\rm cap})R433
 \le SX_q+E_{\rm cell}+C_{\rm cap}W.
 \quad}
\tag{17}
\]
零流仍成立。只有系数 \(2\sqrt n-a_{\rm cap}>0\) 时才可除；若要把 bulk 贡献控制为 \(\epsilon X_q\)，还必须验证
\(2\sqrt n-a_{\rm cap}\ge S/\epsilon\)。
冻结 \(S,\epsilon_0,r\) 时 \(a_{\rm cap}=O(\log(n+2))\)，因此这是明确的大维条件；本稿没有自行删除其余维数或最终旧账系数。

**(16) 未获根阶上界。** 它是原正初始 cell 集中与负终端势的共同积分，不能将负终端势单独丢弃后援引 (12) 闭合。与只有恒等式相比，(11) 已从原完整对数价格中准确拿掉一项可吸收费用；但本轮全余目标仍依赖 (16) 的实际共同来源几何。

本次驻留尝试未能进一步支付 (16)。具体地，(8) 的**原正删除测度**
\[
 \ell(A,v)\,g(T_i,z)(w_i-w_{i+1})\,d\Lambda
\]
连同其终端仍须结算。删除权包含端点删除、原 early 比率下降及占用门关闭；其正号不能将它推到 (14) 的自由中心测度。捕获正项已由 (15) 支付，但其余 signed cell 部分没有因此消失；(6) 已结清连续比例导数，不能再将它们当作原跳的耗散。

这是直接三势分部积分机制的停止判据，不是断言一般几何桥不存在。未得到 (3)，没有退款或更改母账，也不把 (8) 再命名为新付款。

## 6. 本机核验范围

同前缀脚本在指定本机数学环境运行：SymPy 直接核 (5)–(6) 的符号取消；Fraction/SymPy 核三组非零首末势的阶段跳跃 (8)，包含有终端和全删除、来源提前耗尽、大阈值跳。另对同三组完整父 clipping 质量核验 bulk 积分等于父完整质量、父 cell entropy 分解，并符号核对 bulk 原函数和零端点极限。只验证代数及所有符号，不认证原生全历史，也不据有限结果主张一般反例。实际 stdout 随附。
