# R441 计算索引（完成）

指数矩、Fenchel与参数选择的数值责任：numeric。无agent、repo修改或他人文件修改；Astra提供准确公式／原来源，numeric仅核数学接口和有限输入。

只读输入：`/tmp/r441_contract.md`；Astra消息中general p primitive、ν=λN、Fenchel、cap M*安全式及后发Cterm1精确reference式。原history不作数值fixture。

实际工作：
1. SymPy一般power derivative和λ/q=r单位恒等式；5个clipping模型，36导数点及zero/empty/terminal分支。
2. 96个Arb capped-density Fenchel标量，含a0/1/M、L0/small/large；错误double-base变体单点拒绝。
3. 8个显式S/Θ/r输入系数决策（含2个临界±1%和1个条件Cterm1精确reference）；一次固定R/W的SciPy bounded p优化，再Arb验证有理p。

命令：`/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/r441_numeric.py`
环境：Python3.12.14，SymPy1.14.0，flint0.9.0，SciPy1.18.1，Arb256bit；环境功能不认证原命题。

输出：
- `/tmp/r441_numeric.py`
- `/tmp/r441_numeric_certificate.json`
- `/tmp/r441_numeric_run.txt`
- `/tmp/r441_numeric_resources.txt`
- `/tmp/r441_numeric.md`
- `/tmp/r441_compute_index.md`

状态：实际执行通过，.39秒、RSS约122.6MB；无新geometry/LP、无Θ一致假设、无原history或整体closure认证。交付停止。

## 其他有边界计算责任
- geometry: r441_geometry_check.py → r441_geometry.result.txt，3个固定质量CDF、9个active起点、87个Fraction断言，检查整条终端帽而非单代外推；不是原生立方体历史模拟。
- mainproof: r441_mainproof_check.py → r441_mainproof.result.txt，符号三势导数相消、3组阶段跳跃及bulk/有限格熵身份；不是新增几何样本。
- complement: r441_complement_check.py → r441_complement_check.txt，原函数和单位标量恒等式，SymPy精确残差；不做新参数扫描。
- 独立审查与归档隔离复跑用于复现，不增加参数覆盖或一般结论。各责任不重复昂贵优化。
