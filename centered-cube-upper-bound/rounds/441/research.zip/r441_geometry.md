# R441: the actual terminal capture entropy has a logarithmic multiplicity price

**New estimate, not whole closure.** For the original common-stage lifted measure \(\mathcal P\), let \(R=\mathcal P(1)\) and let \(v\) be its actual new-source terminal. All old-source, parent, stage, early, low-common, rank, and future marks remain in \(\mathcal P\). Put \(C_d=(1+d/a)^n\), \(d=a/n^2\), \(A_n=1+n\log(b/a)\), and \(r=\lambda/q\). The result proved here is

\[
 \boxed{\int \log\frac{M_{C(z)}(t)}{B_{v,C(z)}(t)}\,d\mathcal P
 \le 2\log_+ M_*\,R+4r C_d A_nW,
 \qquad M_*:=\frac{SA_n}{\lambda h}.} \tag{1}
\]

Thus the original arrival multiplicity enters a logarithm, rather than multiplying the native entropy budget. This prices the positive capture-log error on the **actual** measure. The signed initial-minus-terminal potential is still unpaid. No original ledger is changed automatically.

## 1. A native exponential moment across all clipping levels

For the fixed grid, write

\[
 M_C(t)=\int_C\min(f,t),\quad B_{vC}(t)=\int_{C\cap Q_v}\min(f,t),
 \quad L(t,x,v)=\log\frac{M_{C(x)}(t)}{B_{v,C(x)}(t)}\ge0,
\]

and

\[
 d\mathcal N=1_{\{f(x)>t\}}c_v(x)\,dx\,dt\,\frac{dv}{m_v}.
\]

All zero terms have zero \(\mathcal N\)-mass; set L=0 there. For every \(0<p<1\),

\[
 \boxed{\int e^{pL}\,d\mathcal N
 \le\frac{C_d A_n}{q(1-p)}W.} \tag{2}
\]

To prove this, fix v,C and abbreviate B=B(t), M=M(t). If B∞=0 the contribution is zero. Otherwise B,M>0 for t>0 and are locally absolutely continuous. For F=B^{1-p}M^p,

\[
 F'=(1-p)B'(M/B)^p+pB^{1-p}M^{p-1}M'
 \ge(1-p)B'(M/B)^p.
\]

Both terms are nonnegative. Since 0≤F≤M, F(0+)=0 and F(∞)≤M∞. Therefore

\[
 \int_0^\infty B'(t)(M(t)/B(t))^pdt\le M_\infty/(1-p).
\]

The actual-selector layer cake from R440, including its b-end base term, gives

\[
 \int_{Q_v\cap C\ne\varnothing}R_v^{-n}dv\le C_dA_n.
\]

Using m_v≥qR_v^n and summing the countable grid proves (2) by Tonelli. This includes cubes containing the entire cell; their exponential integrand equals 1, not 0. No density cap on f or independent-radius integration is used. Also \(\mathcal N(1)=|E|\), by full matching.

## 2. Whole terminal law: constant one, not a sum of single-generation caps

Fix a source x, let \(\rho_x(dv)=c_v(x)dv/m_v\), \(Z_v=\rho_x\{m_u<m_v/K\}\), and \(B_x=\{Z_v\le h\}\). An active receiver has Z_v>h. Its original next-step law is \(1_{D_v}\rho_x/Z_v\), where \(D_v=\{m_u<m_v/K\}\).

If an active state exists, \(\rho_x(B_x)\ge h\). Indeed the first mass quantile of total \(\rho_x\)-mass h, with its entire boundary atom retained, has strict smaller-mass measure at most h; its strict K-past is smaller still. Thus that quantile initial segment is contained in B_x. This handles atoms and continuous mass distributions without splitting a receiver atom.

Both B_x and D_v are mass initial segments. If D_v⊂B_x, the terminal law is the next-step law and its density is at most 1/h. Otherwise B_x⊂D_v. Induction on the maximum remaining path length bounds the terminal density by

\[
 \left[\frac1{Z_v}+\frac{Z_v-\rho_x(B_x)}{Z_vh}\right]1_{B_x}\rho_x
 \le\frac{1_{B_x}\rho_x}{h}. \tag{3}
\]

Strict K-decrease and the actual positive lower mass qa^n give finite maximum path length, so this induction is legitimate. It proves a bound for the **whole terminal law**, not merely each generation. This is the R426 §3 argument, rechecked here. The original initial nodes are own-high; mixing their subprobability laws preserves (3), with no initial terminal Dirac mass. Future positive weights only reduce the original generated law; they are never renormalized. If using only the archived exact-generation result instead, all statements below remain true with \(M_*\) replaced by \(\Theta M_*\); this weaker version is not needed.

## 3. Actual arrival density: keep the stage until its single use

Let \(\mathcal A\) be the pushforward of \(\mathcal P\) to (t,z,v). Then \(\mathcal A(1)=R\). Choose reference measure \(\nu=\lambda\mathcal N\), so the density ratio is dimensionless.

At a fixed t, there is at most one nonzero clipping interval \([T_{i-1},T_i)\). Its original averaged early factor is frozen, as in R440 mainproof; it is not replaced by a new levelwise early event. On each initial record, (3) bounds the new-source terminal marginal. To obtain this upper bound, one may delete future restrictions and integrate the other original generated path to at most 1. The actual \(\mathcal A\) itself retains all those marks.

Integrating the old-source original endpoint marginal gives \(\sigma(dA)s_i^e(A)\). Summing the two original directions, with no further factor two, yields

\[
 \begin{aligned}
 d\mathcal A(t,z,v)
 &\le\frac1h1_{f(z)>t}\frac{c_v(z)\,dv}{m_v}\,dz\,dt
       \sum_e\int\sigma(dA)s_i^e(A)\frac{c_A(z)}{m_A}\\
 &=\frac{D_i(z)}h\,d\mathcal N(t,z,v).
 \end{aligned} \tag{4}
\]

Here D_i is the original, unmodified occupancy. Its archived bound is D_i≤SA_n. No stage sum appears at a fixed t. The remaining original positive weights only decrease the left side. Consequently

\[
 a:=d\mathcal A/d\nu\le\frac{D_i(z)}{\lambda h}\le M_*.
 \tag{5}
\]

One may safely enlarge M_* to SA_n/(qh), but the first value keeps the exact q factors. This is not a dimension-free density assumption: M_* can grow like √n. It was derived from the actual original endpoint marginals, not assigned to an auxiliary parent or terminal.

## 4. Fenchel pays its logarithm

For a≥0 and L≥0,

\[
 apL\le a\log a-a+e^{pL},
\]

where 0 log0=0. Apply this to the **actual** projected density a; do not delete any coupling gate from a signed information term. The measure ν is finite, a is bounded, and a loga is integrable, since its negative part is at most 1/e and its positive part is at most a log_+M_*. Thus (2) and (5) prove

\[
 \int L\,d\mathcal A
 \le\frac{\log_+M_*}{p}R
   +\frac{rC_dA_n}{p(1-p)}W. \tag{6}
\]

The exact intermediate formula also has −R/p; it is not needed or reused as another credit. Taking p=1/2 proves (1). Since h=s/(ε_0q), the exact cap is M_*=Sε_0A_n/(rs); the safe cap is Sε_0A_n/s. The reference λN avoids taking a logarithm of a quantity with units.

## 5. Joint signed price: what is now paid, and what is still missing

On the same original record, with parent A and new terminal v,

\[
 \log(m_A/m_v)=\Phi_t(A,z)-\Phi_t(v,z)
      +\log[B_{A,C(z)}(t)/B_{v,C(z)}(t)],
 \quad \Phi_t(u,z)=\log[m_u/B_{u,C(z)}(t)]. \tag{7}
\]

The last positive part is bounded by L(t,z,v), hence by (1). Its negative part is bounded by L(t,z,A). The original parent projection is at most SλN, so R440 gives

\[
 \int [\log(B_A/B_v)]_-\,d\mathcal P\le SrC_dA_nW.
\]

Thus the signed capture term is integrable. The mass log is bounded by the finite octave log-span, so the **difference** \(\Phi_t(A,z)-\Phi_t(v,z)\) is integrable as well; individual infinite entropy expressions need not be subtracted.

Writing \(\mathcal I=\int[\Phi_t(A,z)-\Phi_t(v,z)]d\mathcal P\), the constructive consequence is

\[
 \int\log(m_A/m_v)d\mathcal P
 \le\mathcal I+2\log_+M_*\,R+4rC_dA_nW. \tag{8}
\]

The original mass gate gives log(m_A/m_v)>2√n. Therefore, whenever √n>log_+M_*,

\[
 2(\sqrt n-\log_+M_*)R
 \le\mathcal I+4rC_dA_nW. \tag{9}
\]

The terminal capture error now has the right nW scale and only a logarithmic relative R cost. **No bound for \(\mathcal I\) is proved.** It retains both sources, their original parent/path relation and signed terminal term. This is the remaining decision point; dropping the negative terminal potential or charging only capture entropy would not prove the target. No claim of a uniform contraction or a new original-history class is made.

## 6. Executed verification and scope

`/tmp/r441_geometry_check.py` was run with `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python`; stdout is `/tmp/r441_geometry.result.txt`. Three fixed exact Fraction mass-CDF models give **87 assertions, 9 active starts**, including a large rank atom, strict K-prefix equality, a zero receiver weight, and an initial subprobability mixture. They verify the whole-terminal estimate (3), rather than inferring it from a single-generation bound. They are finite ordered-measure checks, not native-cube or original-history fixtures.

Independent computation is recorded in `/tmp/r441_numeric.md`, `/tmp/r441_numeric.py`, and `/tmp/r441_numeric_certificate.json`: SymPy gives zero residual for the general power derivative and the λ/q unit conversion; python-flint/Arb verifies five fixed clipping models with 36 derivative points, zero/empty branches and terminal limits, and 96 scalar Fenchel cases including a=0 and its equality case. The supplied finite coefficient calculations keep reference units and explicitly distinguish Cterm=1 from arbitrary input Θ. Their finite p optimization is not needed for the theorem, whose displayed choice is p=1/2.

The general claims follow from the analytic proofs above. Neither collection proves the remaining signed endpoint estimate, whole closure, or a new original-history model. No counterexample scan, source refresh, or additional geometric subbranch was introduced. This bounded delivery stops with the actual capture entropy paid as in (1) and the exact signed endpoint term retained in (8).
