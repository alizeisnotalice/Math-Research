"""R441 bounded symbolic and Arb certificates, no original-history fixture.
Run with the user math-research-tools interpreter. Outputs beside this file.
"""
from pathlib import Path
from fractions import Fraction as F
import sys,platform,json
import sympy as sp
from flint import arb,ctx
import flint,scipy
from scipy.optimize import minimize_scalar
ROOT=Path(__file__).resolve().parent
ctx.prec=256

def A(x):
    if isinstance(x,F):return arb(str(x.numerator))/arb(str(x.denominator))
    return arb(str(x))
def logplus(x):
    if x<=1:return arb(0)
    assert x>1
    return x.log()
def nonneg(x,exact_zero=False):
    if exact_zero:return True
    assert x>=0
    return True

# General symbolic primitive: B=b is the actual intersection clipping mass.
b,m,db,dm=sp.symbols('b M bprime Mprime',positive=True)
p=sp.symbols('p',positive=True)
power=b**(1-p)*m**p
residual=sp.simplify(sp.diff(power,b)*db+sp.diff(power,m)*dm
 -(1-p)*db*(m/b)**p-p*b**(1-p)*m**(p-1)*dm)
assert residual==0
q,r,lam,cc,an=sp.symbols('q r lambda C An',positive=True)
unit_residual=sp.simplify((lam*cc*an/(q*p*(1-p))).subs(lam,r*q)-r*cc*an/(p*(1-p)))
assert unit_residual==0

# Stage 1/2: finite actual clipped-mass algebra, including empty/zero bases.
clip_specs=[('equal_masses',[F(1),F(3)],[F(1),F(1)],[F(1),F(1)]),
 ('proper_intersection',[F(1),F(3)],[F(1),F(1)],[F(1),F(0)]),
 ('fractional_intersection',[F(2),F(5)],[F(1),F(1)],[F(1,2),F(1,3)]),
 ('empty_intersection',[F(1),F(3)],[F(1),F(1)],[F(0),F(0)]),
 ('zero_source',[F(0)],[F(1)],[F(1)])]
cliprows=[];derivative_checks=0
for name,levels,mvol,bvol in clip_specs:
    knots=sorted({F(0),*levels});moments=[]
    for pp in [F(1,4),F(1,2),F(3,4)]:
        pa=A(pp)
        mf=sum((x*y for x,y in zip(levels,mvol)),F(0));bf=sum((x*y for x,y in zip(levels,bvol)),F(0))
        if not mf or not bf:
            # No dB reference mass, so no division by B nor L assignment.
            moments.append({'p':str(pp),'reference_dB_mass':str(bf),'empty_branch':True});continue
        ff=A(bf)**(1-pa)*A(mf)**pa
        if bf!=mf:assert A(mf)-ff>0
        for left,right in zip(knots,knots[1:]):
            for frac in [F(1,3),F(2,3)]:
                t=left+(right-left)*frac
                mv=sum((vv*min(f,t) for f,vv in zip(levels,mvol)),F(0))
                bv=sum((vv*min(f,t) for f,vv in zip(levels,bvol)),F(0))
                md=sum((vv for f,vv in zip(levels,mvol) if f>t),F(0))
                bd=sum((vv for f,vv in zip(levels,bvol) if f>t),F(0))
                if not bv:continue
                main=(1-pa)*A(bd)*(A(mv)/A(bv))**pa
                extra=pa*A(bv)**(1-pa)*A(mv)**(pa-1)*A(md)
                derivative=main+extra
                if md:assert extra>0
                assert derivative>=0
                derivative_checks+=1
        moments.append({'p':str(pp),'terminal_F_Arb':str(ff),
                        'terminal_M_exact':str(mf),'terminal_B_exact':str(bf),
                        'moment_upper_F_over_1_minus_p':str(ff/(1-pa)),
                        'coarse_M_over_1_minus_p':str(A(mf)/(1-pa))})
    cliprows.append({'name':name,'levels':list(map(str,levels)),
      'full_cell_volumes':list(map(str,mvol)),'intersection_volumes':list(map(str,bvol)),
      'F_at_zero':'0 by continuous clipping limit','checks':moments})

# Fenchel is verified on prescribed capped densities, not inferred from samples.
fenchel=[]
for M in [F(0),F(1,4),F(1),F(4)]:
    aa=sorted({F(0),M}|({F(1)} if M>=1 else set()))
    for a in aa:
        for L in [F(0),F(1,1000),F(5),F(40)]:
            for pp in [F(1,3),F(1,2),F(3,4)]:
                pa,xa,la=A(pp),A(a),A(L)
                aloga=xa*xa.log() if a else arb(0)
                gap=aloga-xa+(pa*la).exp()-xa*pa*la
                if a==1 and L==0:assert gap==0
                else:assert gap>0
                capgap=xa*logplus(A(M))/pa+(pa*la).exp()/pa-xa*la
                assert capgap>0
                fenchel.append({'M':str(M),'a':str(a),'L':str(L),'p':str(pp),
                   'Fenchel_gap_Arb':str(gap),'coarse_capped_gap_Arb':str(capgap)})
# A tempting double-base subtraction is false even at a=1,L=0.
assert arb(1).log()-1+arb(0).exp()-1==-1

# Stage 3: explicit inputs, never a guessed dimension-uniform Theta.
def coeff_case(label,n,S,theta,theta_description,eps0,r,eps,pp=F(1,2),tight_reference=False):
    sn=A(n).sqrt();s=1+sn;An=1+A(n)*A(2).log();C=(1+A(F(1,n*n)))**n
    M=A(S)*theta*A(eps0)*An/s/(A(r) if tight_reference else 1)
    cap=logplus(M)/A(pp);wcoef=A(r)*C*An/(A(pp)*(1-A(pp)))
    massmargin=2*sn-cap;directmargin=2*A(eps)*sn-A(S)*cap
    assert massmargin>0 or massmargin<0
    assert directmargin>0 or directmargin<0
    return {'label':label,'n':n,'S_input':str(S),'Theta_input':theta_description,
      'Theta_Arb':str(theta),'eps0_input':str(eps0),'r_input':str(r),'epsilon_input':str(eps),
      'p_input':str(pp),'scale_ratio_input':'2','Mstar_Arb':str(M),
      'Mstar_reference':'tight lambda=r*q' if tight_reference else 'safe q reference',
      'R_coefficient_logplusM_over_p':str(cap),'W_coefficient':str(wcoef),
      'conditional_massgap_absorption_margin_2sqrt_n_minus_Rcoefficient':str(massmargin),
      'conditional_massgap_margin_positive':bool(massmargin>0),
      'direct_epsX_margin_2epsilon_sqrt_n_minus_S_Rcoefficient':str(directmargin),
      'direct_epsX_margin_positive':bool(directmargin>0)}
coef=[]
for spec in [('small_M',16,F(1),A(1),'1',F(1,4),F(1)),
 ('large_explicit_STheta',16,F(4),A(100),'100',F(1,4),F(3)),
 ('moderate_explicit_Theta',256,F(2),A(10),'10',F(1,4),F(2)),
 ('tiny_explicit_Theta',256,F(2),A(F(1,100)),'1/100',F(1,4),F(2)),
 ('Theta_exp_sqrt_n_input',1024,F(2),A(32).exp(),'exp(32)',F(1,4),F(2))]:
    coef.append(coeff_case(*spec,F(1,10)))
n=256;S=F(2);eps0=F(1,4);An=1+A(n)*A(2).log();sn=A(n).sqrt()
critical=sn.exp()*(1+sn)/(A(S)*A(eps0)*An)
for fac in [F(99,100),F(101,100)]:
    coef.append(coeff_case('critical_Theta_'+str(fac),n,S,critical*A(fac),
       str(fac)+'*exp(16)*17/(2*(1/4)*(1+256*log(2)))',eps0,F(2),F(1,10)))

coef.append(coeff_case('Cterm1_tight_reference_explicit_input',256,F(2),A(1),'1 (conditional source input, not numerically proved)',F(1,4),F(2),F(1,10),F(1,2),True))

# One bounded p optimization with explicit R/W input; Arb certifies selected p.
# This is optimization of the displayed finite coefficient, not a whole bound.
n=256;S=F(2);eps0=F(1,4);rr=F(2);theta=A(10);ratio=F(1000)
sn=A(n).sqrt();An=1+A(n)*A(2).log();C=(1+A(F(1,n*n)))**n
M=A(S)*theta*A(eps0)*An/(1+sn);ell=logplus(M);bcoef=A(rr)*C*An
ellf=float(ell.mid());bf=float(bcoef.mid())
fun=lambda x:ellf*float(ratio)/x+bf/(x*(1-x))
opt=minimize_scalar(fun,bounds=(.01,.99),method='bounded',options={'xatol':1e-13})
assert opt.success
selected=F(round(float(opt.x)*10**8),10**8);pa=A(selected)
selected_value=ell*A(ratio)/pa+bcoef/(pa*(1-pa))
half_value=ell*A(ratio)/A(F(1,2))+4*bcoef
assert half_value-selected_value>0
# Symbolic critical point check via c=(ell R)/b, p=u/(1+u), u^2=1+c.
u=sp.symbols('u',positive=True);pp=sp.symbols('pp',positive=True)
opt_res=sp.factor(sp.diff((u*u-1)/pp+1/(pp*(1-pp)),pp).subs(pp,u/(1+u)))
assert opt_res==0
optimization={'R_over_W_input':str(ratio),'model_input':'n=256,S=2,Theta=10,eps0=1/4,r=2,b/a=2',
 'scipy_selected_p_float':float(opt.x),'selected_rational_p':str(selected),
 'Arb_bound_at_selected_p':str(selected_value),'Arb_bound_at_half':str(half_value),
 'Arb_strict_improvement':str(half_value-selected_value),
 'symbolic_optimum_p':'sqrt(1+ell*(R/W)/b)/(1+sqrt(1+ell*(R/W)/b))',
 'symbolic_derivative_residual':str(opt_res)}
report={'environment':{'sys_executable':sys.executable,'python':platform.python_version(),
 'sympy':sp.__version__,'flint':flint.__version__,'scipy':scipy.__version__,'Arb_bits':ctx.prec},
 'power_primitive_symbolic_residual':str(residual),'reference_units_symbolic_residual':str(unit_residual),
 'clipping_cases':cliprows,'clipping_derivative_checks':derivative_checks,
 'Fenchel_cases':fenchel,'Fenchel_case_count':len(fenchel),
 'false_double_base_variant_gap':'-1 at a=1,L=0',
 'coefficient_cases':coef,'single_p_optimization':optimization,
 'scope':'Finite coefficients/scalars and general symbolic identity only; no original-history fixture, uniform Theta theorem or full logmass payment.'}
(ROOT/'r441_numeric_certificate.json').write_text(json.dumps(report,indent=2)+'\n')
print('Environment:',report['environment'])
print('Stage 1/2: clipping cases',len(cliprows),'derivative samples',derivative_checks,
      'Fenchel scalar checks',len(fenchel),'symbolic residuals',residual,unit_residual)
for row in coef:print(row['label'],'massgap conditional',row['conditional_massgap_margin_positive'],
 'direct epsX',row['direct_epsX_margin_positive'],'M*',row['Mstar_Arb'],
 'Rcoef',row['R_coefficient_logplusM_over_p'],'Wcoef',row['W_coefficient'])
print('Selected p:',selected,'strict Arb improvement:',optimization['Arb_strict_improvement'])
print('PASS bounded finite certificates; no original full closure claim.')
