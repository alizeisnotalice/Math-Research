# R441 independent final audit

FINAL PASS（仅限真实终端capture-log价格、whole-P父端bulk价格、势可积性及同一原流的带符号比较；不认证完整R433上界或母账闭合）。2026-10-20。独立PRE先于本轮作者证明；后审16件冻结输入与原定义，已实际隔离复跑四脚本。范围内无剩余实质阻断。主稿零流严格号已修为≥，R>0时严格；原母账不变。

## 1. 原生幂矩及实际终端投影

独立推导与作者证明一致。固定实际(v,C)，M(t)=∫Cmin(f,t)、b(t)=∫C∩Qvmin(f,t)，对0<p<1，

 ∫b′(t)[M(t)/b(t)]^p dt
 ≤M∞^p B∞^(1−p)/(1−p)≤M∞/(1−p)。

零质量项为零；有效t>0时分母正，0端由幂可积及非负极限处理。真实可变边长的层饼含b端base，子水平中心域包含C+Q_r，故countable-grid Tonelli给 ∫e^(pL)dN≤C_d A_nW/[q(1−p)]。包括L=0的完整cell分支，未漏指数base；b=a或实际边长端点正测度亦合法。N总量=|E|有限，来自完整matching及 q a^n|E|≤b^nW。没有用来源密度帽或自由重选半径。

R411余流保留初始new witness own-active。固定来源ρ_x，own-low集合B_x是质量初段；active存在时ρ_x(B_x)≥h，跨CDF原子整体保留。严格K质量下降与统一正下界qa^n保证最大深度有限。按质量初段分D_v⊂B_x或B_x⊂D_v归纳，整条首次own-low终端law≤ρ_x|B_x/h。此为整终端帽，非逐代帽求和。保初始active子概率后平均仍合法；若允许初始inactive Dirac则不能免费使用。未来权仅正删除，过滤后的law不重归一，也不被宣称仍独立。

原stage δg_i/f与新来源π_A的f精确消去，stage平均early保持冻结。固定t至多选择一个原stage。保原旧来源投影Γ_i^e=σπ_A a_i^e，先积分原旧来源得s_i^e(A)，两方向合计一次，得到实际到达

 dA_term≤[D_i(z)/h]dN，D_i=∫Σ_e s_i^e(A)c_A(z)R_A^−n dA≤S A_n。

这是sourcewise推导，不由总质量SX单独推出。另一完整生成路径总量≤1足够，原受限双路径不需重新独立化。ν=λN下精确帽为 a=dA_term/dν≤M*=S A_n/(λh)=Sε_0A_n/(rs)。没有额外τ、Θ、方向2或缺失q；λ参考同时改变帽及指数矩W系数。可数stage由唯一i(t)及Tonelli处理，物理clock原子仍在原记录中。

## 2. Capture、bulk及尚未付项

对实际a用Fenchel apL≤a loga−a+e^(pL)，ν有限且a有界，正负熵部分可积。先截断L再取非负极限，严格得

 ∫L dA_term≤log_+(M*)R/p+r C_d A_nW/[p(1−p)]。

可保留的−R/p未另作信用。p=1/2给2log_+(M*)R+4r C_d A_nW。真实capture正部≤L_terminal；负部≤L_parent，原parent推前≤SλN及R440预算给其Sr C_d A_nW有限价。此父端工具不能在已消去的恒等式中重复收费。

同一全P的parent推前≤Sσ c_A(z)1_{f(z)>t}dzdt/m_A，因旧来源、原路径和其他权总积分至多1。完整m_t(A)从0绝对连续增至m_A，故∫m_t′log(m_A/m_t)dt=m_A，真实bulk≤SX。它不是直接的任意小εX；须结合原质量门和实际系数后才能讨论吸收。

父正势可积有两项独立合法粗证明：固定父有限cell分割给全profile积分≤m_A(1+logN_d)，从而∫Φ_parent dP≤S(1+logN_d)X；complement亦由native全势预算给有限W粗价。这些只保证合法性，不冒充根阶价格。原massgap>0给Φ_terminal≤Φ_parent+capture_+，所以终端势亦可积；不存在∞−∞。因此主稿定义的J_cell是同一P上的合法有限signed积分，并有

 (2√n−2log_+M*)R≤SX+J_cell+4r C_d A_nW。

只有正系数时才能除，给定ε还须核相应S/ε条件。固定S,r,ε_0的渐近说明不代替随n参数的实际核验。J_cell所需预算未证。直接三势的B′/B导数严格相消；有限Abel保原initial、删除原子和terminal，不能再从一项有利导数取得第二笔信用。原有限尚存片和清空条件未被提前省略。

## 3. 实际复现及证据边界

使用指定 `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python`，在独立目录 `/var/folders/lq/2c4qbz2n0354_tnttkv_qsz00000gn/T/r441_audit_isolated_hxspzlqw` 实际运行geometry、mainproof、complement、numeric四脚本，均退出0。四份stdout与冻结输入逐字一致，再生numeric_certificate.json亦逐字一致。环境Python3.12.14、SymPy1.14.0、flint0.9.0/Arb256bit、SciPy1.18.1一致；未运行MATLAB或新几何扫描。

geometry为3个有限质量CDF模型、9 active起点、87 Fraction断言（包括原子/严格门/零权/初始子概率）。mainproof与complement为符号身份及3组有限clipping/跳跃/熵代数，不是native历史。numeric为5个clipping模型/36导数点、96 Arb标量Fenchel、8个显式参数判别及一次有界SciPy候选选择；最终有理p由Arb严格核优于p=1/2，浮点优化状态自身不是证书。一般指数矩、到达帽和Fenchel依解析证明，不由有限点外推。资源文件仅记录实际进程，不能作为数学依据。

PRE的72个临时原子比较及符号辅助只用于独立审查，不纳入正式新增覆盖或归档实验统计；本次隔离复跑亦不增加样本。共享索引的各角色任务边界和复现说明已核。

最终限定：本轮真正保留capture与bulk收据及合法signed J_cell；未支付J_cell、完整联合logmass或全R433，不刷新来源、不转授history、不退款旧分支，不默认修改16/32/64母账或完成吸收。

## 冻结字节 SHA-256（16输入）

- `r441_main.md`: `8ba941589ce6e0d2cd594caee7a117f0fb58755ec5fba80399e5047302accff5`
- `r441_geometry.md`: `076cdb2096eb2e791c19cdc9a9ed3a806da1d6826a32f00b26da03c1576f858c`
- `r441_geometry_check.py`: `2a094adf0d535e71d0c662ae3adaee4df579afc31123611e68f5327ca9bc0e98`
- `r441_geometry.result.txt`: `88b7abd12e4ce754b7a317ef8ca5f734020e5377e198db5577882f21f9626f3e`
- `r441_mainproof.md`: `b7cb2cf5ac44c861356acd14659e8987adda1bd0697d50b1526999ad97e1f815`
- `r441_mainproof_check.py`: `4fe5aee5d992672a6c696a2bc779fa3a40cae57728c6bf2b12f06454ac674675`
- `r441_mainproof.result.txt`: `1c8c337c7d7faa388a497b3fcdbf2d75ec15f6ed2b554098f2d15e9ef2bc9c45`
- `r441_complement.md`: `fde8def65b1ccc721df1eb871a22c81f41c404ea4a7cd6b2f3e89d65ddecc294`
- `r441_complement_check.py`: `66d386ebc5a2fe3c0c60bdb15a1e3f6cf4fb3a55fa25bb7bb93701b2c852016d`
- `r441_complement_check.txt`: `625171dc8caaa3e06a4b8f5921de7852581c9a34584cdbdf3110359c601d0f5a`
- `r441_numeric.md`: `0311fd5aa4f388680ff88582458e3bdb71c2f9887aedd236b549a07d796d0c7b`
- `r441_numeric.py`: `6553b8e1221aecfb54ba3b7036ba5bc1815a6ca0fce98ba42be103940645e0af`
- `r441_numeric_certificate.json`: `a6e55577ae0bdc3dc82c65ea0c7d568e6ebbe52e1b4dca6e333553111ac71e14`
- `r441_numeric_run.txt`: `89b28b8da539668a614e530f45fc131aec4d667e4272334fed0183a2bbe765eb`
- `r441_numeric_resources.txt`: `4c81f2379b704bf999eafcce175eb8ab38ecdfc9f4ca3bd93fa9a548dbdbebf2`
- `r441_compute_index.md`: `8a1dcc1251849457b9afb3e3a79c05b0b08a56cb82464d5a5d45386ce330c717`
