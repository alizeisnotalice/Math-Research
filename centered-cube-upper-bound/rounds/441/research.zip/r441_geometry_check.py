"""Exact checks for the whole terminal law, not a native-history fixture."""
from fractions import Fraction as F
models=[
 ([1,2,4,8,16,32],[F(1,2),F(1,3),F(2,3),F(1,4),F(3,4),F(1,2)],F(2),F(1,2)),
 ([1,2,4,8,16,32],[F(2),F(1,7),F(1,5),F(1,3),F(1,2),F(2,3)],F(2),F(1)),
 ([1,3,3,9,27,81],[F(1,5),F(2,5),F(3,5),F(0),F(1,2),F(1,3)],F(3),F(1,4)),
]
checks=0; starts=0
for k,(m,w,K,h) in enumerate(models,1):
    m=list(map(F,m)); N=len(m)
    pred=[[j for j in range(N) if m[j]<m[i]/K] for i in range(N)]
    Z=[sum((w[j] for j in js),F(0)) for js in pred]
    low=[i for i in range(N) if Z[i]<=h]
    active=[i for i in range(N) if Z[i]>h]
    assert active and sum((w[j] for j in low),F(0))>=h; checks+=1
    law=[]
    for i in range(N):
        if i in low:
            row=[F(int(j==i)) for j in range(N)]
        else:
            row=[sum((w[u]*law[u][j]/Z[i] for u in pred[i]),F(0)) for j in range(N)]
        law.append(row)
        if i in active:
            starts+=1
            assert sum(row)==1; checks+=1
            for j in range(N):
                assert row[j] <= (w[j]/h if j in low else 0); checks+=1
    mixture=[sum((law[i][j]/(2*len(active)) for i in active),F(0)) for j in range(N)]
    assert sum(mixture)==F(1,2); checks+=1
    for j in range(N):
        assert mixture[j] <= (w[j]/h if j in low else 0); checks+=1
    print('model',k,'active starts',len(active),'whole terminal bound PASS')
print('PASS',checks,'Fraction assertions;',starts,'active starts; three fixed mass-CDF models.')
print('Scope: atoms, strict K-prefix equality, zero rho weight, and active-start subprobability mixture. Not actual Lebesgue cubes or original-history certification.')
