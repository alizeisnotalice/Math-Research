# R441 primitive、Fenchel及显式系数有限证书

指定环境实际运行：`/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/r441_numeric.py`。Python3.12.14、SymPy1.14.0、python-flint0.9.0、SciPy1.18.1；Arb精度256bit。冻结运行.39秒、RSS122,617,856字节。无原history fixture、几何采样、LP或Θ一致界推断。

## 1. 基础：一般power primitive及clipping边界

设B(t)为实际交集clipped mass，M(t)为整cell clipped mass，0≤B≤M，0<p<1。SymPy严格化简得到

`[B^(1−p)M^p]'−(1−p)B'(M/B)^p = p B^(1−p)M^(p−1)M'`。

残差为0；在M'≥0时后项非负。clipping从0开始，F(0)=0按连续极限；F∞=B∞^(1−p)M∞^p≤M∞。这给primitive积分上界，不能把F当成B'(M/B)^p的无余项原函数。

实际检查5个确定性clipping模型：M=B、proper intersection、fractional intersection、empty intersection、zero source；p=1/4,1/2,3/4，36个线性段内部导数点及全部terminal。体积／level数据为Fraction，非整数幂和符号由Arb区间核验。空B参考质量分支不计算M/B；零源不指派L。符号恒等式是一般代数，有限点只检查实现和边界。

## 2. 压力：Fenchel零点、base与reference单位

精确使用ν=λN，arrival density a=dA/dν，R=A(total)，L≥0。Fenchel为

`a pL≤a loga−a+exp(pL)`，`0log0=0`。

若a≤M*，丢−a并放大a loga≤a log_+M*，得到

`E≤log_+(M*) R/p + r Cδ A_n W/[p(1−p)]`。

保base exp(0)=1；若同时改成exp(pL)−1且仍保−a，a=1,L=0就给错误gap=−1。脚本显式核这个错误变体，防止漏base。另用SymPy核λ/q=r单位替换残差0，W项没有额外q或漏r。

96个固定Arb scalar覆盖M*=0,1/4,1,4，合法a=0,1,M*（去重且a≤cap），L=0,.001,5,40及p=1/3,1/2,3/4。所有正确gap通过；a=1,L=0的Fenchel等号单独精确核为0。未以有限samples证明一般Fenchel。

## 3. 扩大：S、Θ作为明确输入的临界决策

统一b/a=2、eps0=1/4、epsilon=1/10、p=1/2；A_n=1+nlog2，s=1+√n，Cδ=(1+1/n²)^n。前7例使用安全cap `M*=SΘeps0 A_n/s`，并明确列输入r；不是猜测Θ为一致常数。

|n;S;Θ;r|R系数2log_+M*|W系数4rCδA_n|R系数<2√n？|S·R系数≤2epsilon√n？|
|--|--|--|--|--|
|16;1;1;1|0|51.4742|是|是|
|16;4;100;3|10.9763|154.423|否|否|
|256;2;10;2|7.92102|1433.153|是|否|
|256;2;.01;2|0|1433.153|是|是|
|1024;2;exp32;2|68.7534|5691.817|否|否|
|256;2;.99Θcrit;2|31.9799|1433.153|是|否|
|256;2;1.01Θcrit;2|32.0199|1433.153|否|否|

Θcrit=exp(16)·17/[2·(1/4)·(1+256log2)]。所有是／否来自Arb严格分离区间，不是显示小数。第一比较只是一项系数余量，不能在initialΦ未付时称实际massgap吸收。第二比较使用R≤SX来评估这一个capture-loss项的直接epsilonX价格，同样不付initialΦ。

Astra随后提供Cterm=1来源主张；数值不证明该来源。只加一个**条件输入**例：n256,S2,Cterm1,r2，使用精确reference cap `M*=S eps0 A_n/(r s)`，核得M*=2.62420，R系数1.92955；第一余量正而第二仍负。保留1/r因子，未把安全cap与精确cap混用。

最后仅一次有界SciPy p优化：固定n256,S2,Θ10,r2和输入R/W=1000。选有理p=38819029/50000000；Arb给价格约7164.95485，对p=1/2约9354.17032，严格改善约2189.21546。此为**显示有限系数**优化，不是原几何优化。SymPy亦核一般最优点p=u/(1+u)，u=√(1+ell(R/W)/b)，其中ell=log_+M*、b=rCδA_nW/W。

## 交付与缺桥

一个脚本和JSON保全部输入、Arb误差、计数、环境及符号残差；shared计算索引见`r441_compute_index.md`。这些证书验证primitive/Fenchel接口与有限系数决定。arrival cap的原starting-record求和及Cterm=1适用性由作者来源证明；本任务不代替它。capture positive loss的付款也不能消去joint logmass中的initialΦ／terminal cancellation。未认证整体R433或原history。
