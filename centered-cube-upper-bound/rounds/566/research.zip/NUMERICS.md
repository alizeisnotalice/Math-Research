# R566 N9: shared-price full-mark flow and a fast restrictive witness

The approved model retains every high-Lfin old-source/sigma constant segment and every marked receiver (source, partner captured count), with the original true phase/window/ordered physical chi weights already integrated in N7 T. It is the same finite surrogate as N7, with X=1 and Kfin=1 as units only. Original full Lebesgue/history Li, Ndelta, head/stop/core marks are unavailable. No general Cstar or dimension-order theorem follows.

The useful certified finite result is a single common overlapping-cluster price exactly 575/128 W (4.4921875 W), using the original rational theta directly. N10 certified the analytically defined flow f=q p on eligible fine edges, without downward flow repair: adaptive weighted terminal is approximately 0.00022721873776812893 and optimum weighted terminal is strictly positive, approximately 5.4942265955811344e-14. The raw floating N9 output below is preserved separately. This is a feasible-upper-witness construction, not an optimum of the full shared-price flow LP. The latter produced no candidate within the actual bounded attempts.

## Exact model and lossless compression

Let p_Bs be the original old-source uniform probability on a fine old sigma mark s=(z,segment), restricted to Lfin>tau, tau=1/18. Thus p_Bs=segment_width/old_count_B, and p0_B=sum_s p_Bs. The sigma partition is the original integer mass-count endpoint partition from N7; Lfin(z,sigma) is constant on each segment. No D/p averaging is used.

Let Qraw_Bu=T[B,y,partnercount] and q_Bu=Qraw_Bu/sum_u Qraw_Bu. All receiver action/phase/window marks can be disintegrated back according to their original conditional law, since every new cluster predicate depends only on y and the partner captured mass. rowE_B=sum T is the actual physical chi row including the original center measure. Then V0=sum_Bs rowE_B p_Bs/Lfin_s reproduces N7's high weighted bill.

For each of the 2080 common source intervals H, theta_H>=0 is shared across all parents. Its price is Pi=sum_H theta_H |H|/64. For a type t=(y,z,partnercount), define a_t=sum_(H containing y,z and |H|<=2 partnercount) theta_H. A fine paid flow f_Bus obeys:

- f_Bus>=0 and f_Bus<=q_Bu p_Bs a_t;
- sum_s f_Bus<=p0_B q_Bu;
- sum_u f_Bus<=p_Bs.

The complete weighted terminal is Vterm=sum_Bs rowE_B(p_Bs-sum_u f_Bus)/Lfin_s. Minimizing Pi with Vterm<=v is the full finite partial-clearing LP. The cluster decomposition is lossless: split an edge flow among eligible H in proportions theta_H/a_t. Its RN density against the original product Q_B tensor P_B is at most theta_H, and the row and old margins remain unchanged. No separate per-parent source budget is introduced. The type equality a=incidence theta must not be reversed.

The actual c=2 model has 179880 variables (2080 prices, 4247 auxiliary types, 173553 fine flows), 185270 inequalities, 4247 equalities, and 1227046 sparse nonzeros. It retains 6711 receiver marks and 5005 fine old sigma marks. Eleven of the 173564 possible fine receiver/oldmark pairs have no eligible common interval; these remain terminal rather than being deleted. All qband cross terms remain in T and every physical bill.

## Actual solver history and changed bounded plan

Six LP objectives were approved: adaptive and optimum, each at terminal fractions .1,.01,0. Only adaptive .1V was attempted. HiGHS-IPM reached its120-second limit after62 iterations (actual120.152604458s, peak RSS608616448 bytes) without a primal candidate. The same mathematics was then retried once with HiGHS dual simplex under parent approval:300.113267125s,102214 iterations, peak RSS598114304 bytes, again no primal candidate. Both records are preserved under historical_attempts. This is neither infeasibility nor evidence about cube geometry. No timeout candidate is certified.

The remaining five full-frontier targets were not run. Parent explicitly replaced them with the following fast feasible-upper-witness experiment; no further full LP, warm-start refinement or scan is planned.

## Restrictive common set-cover witness

On all4247 eligible types solve the small set-cover LP min sum_H theta_H |H|/64 subject to incidence theta>=1. It has2080 variables and355034 nonzeros. Set f_Bus=q_Bu p_Bs on every eligible fine edge, leaving all other edges unpaid. Then each receiver row is at most p0_B q_Bu, each old column at most p_Bs, and every edge RN capacity is satisfied. Thus this is a restrictive feasible subclass of the full partial-flow problem, not a surrogate marginal metric.

The small LP terminated in164 iterations. Raw price and cover dual objective both equal4.4921875. The common theta is supported on48 intervals (some coefficients1/2). A relative inflation1+1e-10 gives price4.492187500449218 and minimum type cover1.0000000001. This cover dual concerns the cover problem only; it is not a lower bound or optimality certificate for the more general full-flow LP. The shared theta is serialized sparsely in JSON.

| Existing law | High weighted V0 | Witness terminal | Terminal/V0 | Low-Lfin complement | Terminal plus low complement |
|---|---:|---:|---:|---:|---:|
| adaptive |1.1794383321117998|0.000227218737768098|0.000192649951745472|0.0323794421688336|0.0326066609066017|
| optimum |0.9155926083291128|about5.51e-14|about6.01e-14|0.0210611108733483|0.0210611108734033|

These are the raw floating N9 witness figures, retained unchanged in n9.py/json. The maximum raw margin violation is1.11e-16, capacity violation is0, type equality residual is0. They are not the interval-certificate values.

N10 instead used the original rational theta (coefficients1 or1/2), proved its minimum type coverage exactly1 and its source price exactly575/128. The flow is defined analytically by f=q p on eligible edges with the structured normalized q and exact old sigma probabilities; it requires no downward repair or inflated theta. Arb192 bounds on the11 missing fine-product terms certify the following terminals:

| Law | Certified high terminal (approximation to the rigorous interval) | Certified terminal including low-Lfin complement |
|---|---:|---:|
| adaptive |0.00022721873776812893|0.03260666090660171|
| optimum |5.4942265955811344e-14, strictly positive|0.021061110873403198|

The exact rational interval endpoints are in `/tmp/ccu_r566_n10.json`; N10 certifies both witnesses feasible at the10% and1% high-terminal targets, but neither at mathematical zero. The optimum's raw subtraction-sensitive value about5.51e-14 must not replace the certified strictly positive value. The low-Lfin complement is always retained. N10's cover optimum concerns only the restricted cover problem; it is not a general-flow lower bound or optimality certificate.

The finite construction decision is different from N7's static common partition. N7 c=2,epsilon=1/8 had an RN-price upper benchmark W/epsilon=8W and about4.7–4.8% high weighted residual. The overlapping shared-price witness uses about4.492W in the same RN price units, with much smaller actual weighted terminal. The common external cluster coefficient c=2 multiplies both price invoices. Neither comparison is a complete mother payment: the local theorem's Lcl and all original low/terminal/head/stop obligations are still required. N7's matched percentage alone was not a payment. Moreover N9 imposes the high-cut row margin p0_B Q_B, while N7's score was generated from the full P,Q block followed by high-D integration; the RN-unit benchmark does not identify these two finite feasible classes or prove strict dominance over every static construction.

## Reproduction, archive, and certificate scope

Default execution is the fast witness, not the timed-out LP:

```
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python n9.py --mode witness --n7 PATH/n7.json --assembled PATH/n7_assembled.npz --optimizer PATH/optimizer.json --output PATH/n9.json
```

The original local filenames also work. Defaults look for adjacent original-prefix or short input names. Output defaults adjacent to the script. `--witness` is an equivalent alias. Large frontier reproduction requires explicit `--mode frontier` plus method/time options; it is not part of routine archive replay. Actual historical commands were the script before the default-mode portability change, first `--first`, then `--first --retry-first --method highs-ds --time-limit300`. The current explicit equivalent uses `--mode frontier`. Replaying either timed-out solve is unnecessary for reproducing the witness result.

JSON contains input hashes, both historical outcomes, the unrun-frontier explanation, sparse shared theta, source price and actual terminal summaries. The two model NPZ files contain complete sparse constraint matrices and structured Qraw, old pmark, sigma widths/count edges, Lmark, receiver/source/type metadata; the two witness NPZ files contain the full primal and cover-only dual. They remain on the local machine for N10. All matrices and flow arrays are regenerable from the SHA-identified N7/R562 inputs and code; an archive need not duplicate the large model arrays. The sparse theta in JSON and code define f=q p on all eligible edges, so the flow itself is also regenerable. Candidate and model hashes are recorded.

A final quick `--mode witness` replay reproduced the same model hashes, theta price, candidate hashes and mathematical quantities; its first-build-plus-cover phase was0.345273s. Peak RSS for that fast replay was245596160 bytes (234.2MiB). It used one Python process, BLAS thread limits2, and no QP or new geometry. The earlier420.27 seconds of unsuccessful full-LP work are explicitly retained rather than hidden in the fast replay cost.

Distribution independently audited the mathematical compression and numeric primitive assembly. N10 completed the structured-normalization, exact rational-theta coverage and analytic f=q p feasibility certificate, with Arb192 terminal intervals for the11 missing fine-product terms. A finite feasible upper witness is not an ideal-Lebesgue, general-dimension or general-flow-optimum certificate.


---

# R566 N10：共同簇价格 witness 的独立精确证书

## 1. 已认证结果与没有认证的结论

完整大 LP 的 IPM120秒、dual-simplex300秒尝试均无候选解。它们不证明不可行或最优；N10没有重跑任何solver。随后主代理批准的restricted setcover产生一个可审的正流上界witness，本证书仅认证该witness和其有限费用。

**准确共同sourceprice为 `575/128=4.4921875`。** raw θ只有0、1/2、1，所有4247个eligible type的准确coverage至少1，因此不需要N9浮点防护用的 `1+10^(−10)` 膨胀。

restricted setcover的准确primal和dual都等于575/128，gap准确为0；这个lower只属于“每个eligible type coverage≥1”的cover问题，**不是一般capacitated partial-flow LP的lower**。

把完整原product `q_u p_s` 放在全部eligible细edge上，保留11个missing fine edges的真实weighted terminal。Arb192给出：

| 冻结law | 严格高L terminal（近似显示） | terminal / 初始高L bill |
|---|---:|---:|
| adaptive | .00022721873776812893 | .00019264995174549806 |
| optimum | 5.4942265955811344e−14 | 6.000732799282514e−14 |

两项的下界都严格为正。这个witness对 `.1V` 和 `.01V` 两个正terminal目标严格可行，给sourceprice上界575/128；对target0不构成精确清空。不能据此否定一般零terminal流的存在，因为更一般流可以重新耦合原边际。

本轮有限决策是：在同一64来源、同一332父及原T/L数据上，用一套有重叠的共同价格，在相同RN价格单位下，R565的c=2、epsilon=1/8共同前沿基准至多8W，本witness价格为575W/128。两者预截边际约定不同，不据此声称一般可行集严格支配；它给出大幅降低该χ-lift surrogate terminal的实际构造。它没有支付原全Lebesgue Cstar或推出一般根阶。

## 2. 模型、标记和完整性检查

模型明确为已批准finite physical χ-lift surrogate，X=1、K_finite=1仅作单位，原全history L_i、Nδ、asymmetric head/stop/core无法恢复。N10使用全部旧source×实际常值σ段，未用D/p平均压缩旧σ。

- 64个等质量来源，2080个同一排序下的contiguous source intervals H；μH=|H|/64。
- 6711个receiver marks `u=(parent,source_y,partner_count)`，raw权为原T中准确同一double。
- 5005个高L旧marks `s=(parent,source_z,真实σ段)`。
- 4247个eligible type `(y,z,partner_count)`，所有父共用同一2080维θ。
- 173553个允许fine flow edges；相同父的全部receiver×oldmark组合中另有11个不允许edge。

N10独立核：oldmask与原states初始source set相同；所有高L旧marks与N7旧场/旧窗完整枚举准确相同；receiver labels及Qraw与共享T全部非零项逐值相同，没有漏掉mark。对每个H，全部type incidence（包括未存的0）按以下准确整数条件核验：

`y,z∈H` 且 `|H|≤2·partner_count`。

同父(u,s)存在至少一个eligible interval，当且仅当

`|rank(y_u)−rank(z_s)|+1≤2·partner_count_u`。

N10逐一核全部允许fine edges的完整性、type方向和旧σ索引，并显式列出11个missing pairs；没有靠抽样检查宣称全量。

sourceprice objective的每个θ_H系数准确为|H|/64，只有一套θ而没有parent下标。共同type系数是eligible θ的和，不能由等式变量a_type无偿放大。

## 3. 正确归一与严格数值范围

为避免独立float边际转Fraction后总mass不等的伪问题，本证书采用结构化有限原语：

`rowE_B=Σ_(u in B) Qraw_u`（raw double解释为准确dyadic），

`q_u=Qraw_u/rowE_B`，

`p_s=log2(edge_hi/edge_lo)/old_count_B`，

`p0_B=Σ_(s in B)p_s`，`w_s=rowE_B/L_s`。

每个正row的Σq准确为1。p保留真实count-log宽度和高L细段；L_s取序列化的正dyadic `L_mark`。Arb192包围全部width、p、p0、q、w及初始weighted bill

`V=Σ_s w_s p_s`。

这比把独立float Qnormalized、rowcap、p0全部当成互不相关的“准确输入”更严格，但仍只认证这个**结构化有限mark模型**。Qraw来自原浮点T，L_s来自原浮点旧场；其对理想几何、proposal、全history L_i及真正Lebesgue中心积分的误差没有本证书。

本证书按序列化旧L定义高低分类；不把这一有限分类视为原连续几何误差为零的证据。

## 4. exact setcover primal / dual

令I_(t,H)为准确0/1 incidence。restricted cover为

`min Σ_H μH θH`，`Iθ≥1`，`θ≥0`。

dual为

`max Σ_t d_t`，`Iᵀd≤μH`，`d≥0`。

N10将raw θ、cover dual double分别转为准确dyadic Fraction，逐项核2080个sourceprice约束和4247个coverage约束。结果为：

`min_t(Iθ)_t=1`，`Σ_H μH θH=575/128`，

`d≥0`，`Iᵀd≤μH`，`Σ_t d_t=575/128`。

所以raw θ自身准确可行且restricted cover准确最优，无数值膨胀需求。JSON保留48个非零θ和101个非零dual的完整有理值，足够独立重核，而非只提供solver status。

一般partial-flow LP的dual不同：若receiver/old子边际价为α_u,β_s≥0、terminal价η≥0，则需要edge价格λ_e≥0满足

`λ_e≥ηw_s−α_u−β_s`，

`Σ_(e eligible for H)q_u p_s λ_e≤μH`，

下界是

`η(V−v_target)−Σ_u α_u p0_B q_u−Σ_s β_s p_s`。

restricted cover dual没有这些margin/terminal条件，不能替代此式。完整LP无candidate，因此本次没有给一般LP最优值的非平凡lower或不可行证书。

## 5. full fine-mark正流和RN容量证明

固定上述共同θ，令

`A_t=Σ_(H eligible for t)θH≥1`。

对所有允许fine edge设 `f_us=q_u p_s`，missing edge设0。对任意正、准确归一的Q及任意非负旧cut P，此流自然满足

`Σ_s f_us≤p0_B q_u`，`Σ_u f_us≤p_s`。

无需通过浮点margin residual说服自己。old σ被保留在s中，没有按D/p平均。

把每edge进一步拆到共同簇：

`f_Hus=f_us θH 1_(H eligible)/A_t`。

它们准确相加为f；相对原 `Q⊗P_hi` product的密度为

`θH/A_t≤θH`，

且仅支撑在真实eligible `(y,z∈H,μH≤2M_partner)` 上。这正是所需共同RN价格方向。θ由整个输入共同选择，原action law没有按receiver改变。

paid子边际之外的两个剩余边际总mass相同，可以用其正product除以剩余mass补齐；全部terminal显式保留。逆L只依赖fine old mark，所以其weighted terminal准确由旧残余边际给出。

## 6. 11个missing edge的直接terminal证书

直接计算而不是用两个接近大数 `V−paid` 相减：

`T=Σ_missing (rowE_B/L_s) q_u p_s`

` =Σ_missing Qraw_u p_s/L_s`。

rowE与Q归一准确抵消，只有11个正项。N10用Arb192计算每项，并把lower/upper转为准确有理端点；JSON保存每个pair的receiver、source、oldσ段、partner_count及贡献区间。

为便于阅读，下列十进制外包另以Fraction准确比较验证过：

`0.00022721873776812892 < T_adaptive < 0.00022721873776812894`；

`0.00000000000005494226595581134 < T_optimum < 0.00000000000005494226595581135`。

两项严格正，target0不被这个witness达到。optimum的直接值约 `5.49422659558e−14`，较N9用大数相减所得 `5.50670620214e−14` 更准确；这不会改变near-clear的判断，却阻止将浮点0误认数学0。

本witness的两law terminal都严格小于 `.01V`，因此对`.1V`和`.01V`原有限目标，price575/128确为严格可行上界；这不说明该价格是一般flow最优。

低L补集也按同一exact count-log宽度和dyadic旧场另外积分保留：

- adaptive约 `.03237944216883359`；high terminal加low约 `.03260666090660171`。
- optimum约 `.021061110873348256`；high terminal加low约 `.021061110873403198`。

这些近似显示的严格上下界在JSON。没有把“高L terminal近零”写成完整来源费为零。

## 7. 实跑、复现与停止点

实际命令：

```
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r566_n10.py --n9 /tmp/ccu_r566_n9.json --n7 /tmp/ccu_r565_n7.json --assembled /tmp/ccu_r565_n7_assembled.npz --optimizer /tmp/ccu_r562_optimizer.json > /tmp/ccu_r566_n10.json
```

Python3.12.14、NumPy2.5.4、python-flint0.9.0、Arb192。最终独立审计约7.15秒；没有solver调用、没有重N7DP或完整action Gram。模型和candidate通过SHA核对后读取。

稳定N10脚本 SHA256：`6e24319b61bd4dbe1f7bf79c5c0a6395a3822eb59c0a620a9962b66f67455a68`。

最终N9 JSON SHA256：`02eadad6e041abfc1cfd834c6693533c38495fc1c8068b6184474bae9c2f61d4`。

每law model/candidate的hash亦保存于JSON。快速再生模型应使用N9明确的 `--mode witness`，不要误启已超时的完整LP；N10自身只读取既有数据、无solver入口。归档时可复制输入后使用同样的显式相对参数；若N9 JSON仍含旧绝对model/candidate路径，先由打包方的快速witness入口重建到归档目录，或仅修改读取定位，不能改变数学数据后沿用旧hash。

源码保留了正确partial dual的候选审计函数，但本次没有完整LP candidate，未用其输出任何general-flow bound。JSON的 `general_flow_lp_optimality_or_infeasibility_not_certified` 明确为true。

有限新证据是：一份共同价格575W/128可使同一surrogate的11-edge剩余极小，显著改善R565的单partition残差；restricted cover被准确优化并认证。原共同source价格如何对任意L1维数统一控制、原真实marks及weighted terminal如何付款，仍是未证全局步骤。仅写本角色文件，完成停止。
