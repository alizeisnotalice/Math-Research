# R566｜shared-cluster RN-capacity 的工具／原始定理核验

**结论：有一个真正适配有限模型的工具——capacitated flow 的全cut判据；没有现成工具保证polylog总cluster价格或完整加权terminal付款。** 它建议下一步几何选择针对实际缺容量的marked row/column cuts，而不是仅优化单cluster覆盖率。以下有限映射已把精确条件发给proof、complement角色；不另做LP推导或求解。

本轮读冻结合同，应用更新B01/E01/G03/M03并沿用已读D01；只查一个必要primary source。未读全历史、未计算、未下载PDF、未改他人或仓库。

## 1. 可直接调用的原始有限定理

David Gale, *A theorem on flows in networks*, Pacific J. Math. 7(2), 1073–1082 (1957)，[原刊PDF](https://msp.org/pjm/1957/7-2/pjm-v7-n2-p04-p.pdf)，DOI 10.2140/pjm.1957.7.1073。实读§2：printed p.1074的有限network／非负有向capacity定义，p.1075的未编号 **Feasibility Theorem**、式(5)，p.1076–1078的minimum-cut及证明。不是只引用搜索片段。

原条件：有限节点集，非负实capacity（允许+∞），实supply/demand；方向可不对称。需求可行当且仅当每个节点cut的净需求不超过流入capacity。有限maxflow等于mincut；没有n或节点数常数损失。整数性只在数据整数时另成立，本题不需要整数化。

## 2. 对当前RN价格的准确有限映射

固定同一全局有限cluster族H及共同非负价格θ_H。对某真实父B的一个**已审核、保留全部marks**的有限化，令行x属于 \(X_B\)、旧列zσ属于 \(Z_B\)。沿合同写
\[
 r_x=\xi_0(x)=p_0Q_B(x),\quad c_z=\nu_0(z)=q_0P_B(z),
 \quad\sum_xr_x=\sum_zc_z=\delta_0.
\]
这里p₀=P_BZ_B、q₀=Q_BX_B，Q、P在所示作用域取原权，不重新归一化。由各H的RN上限得到行列边capacity
\[
 U^\theta_{xz}=Q_B(x)P_B(z)
 \sum_H\theta_H1_{E_H}(x)1_H(z).
\]
共享θ已固定时，可先将同一cell的cluster capacities相加；finite可行流再按各capacity比例拆回各Γ_{B,H}，不会超过各自RN帽。这一步不改变action law。

Gale定理给出**完整付清两个marked边缘**的精确条件：对所有行集合A及旧列集合D，
\[
 r(A)+c(D)-\delta_0
 \le U^\theta(A,D)
 =\sum_H\theta_H\,Q_B(A\cap E_H)P_B(D\cap H).
 \tag{F1}
\]
这是标准source→row→column→sink网络的cut；cut容量为
\(2\delta_0-r(A)-c(D)+U^\theta(A,D)\)。因此最大未匹配**概率质量**为
\[
 \max_{A,D}\,[r(A)+c(D)-\delta_0-U^\theta(A,D)]_+.
 \tag{F2}
\]
所有真实mass-eligibility、head/stop/phase/window条件必须仍在x、E_H和实际Q_B中。只在source原子层丢掉这些marks后检(F1)，只能证明更大的放松问题可行。

对几何选择最具体的反馈是：一个H对坏cut(A,D)提供的容量/价格比为
\[
 \frac{Q_B(A\cap E_H)P_B(D\cap H)}{\mu(H)}.
\]
应保留高 \(1/L_i\) 旧列的坏cut，再寻找能同时补足多个父cut的共同H，而非每父单独选便宜H。该式不假设source坐标独立；它使用的是合同已经冻结的receiver×old-source正product base。

**原定理没有支付以下一步：** 找到对所有B共同的θ，使(F1)及 \(\sum_H\theta_H\mu(H)\le\mathrm{polylog}(n)W\) 同时成立，或只留下可由原credit吸收的weighted terminal。流缺质量小不是 \(1/L_i\) 加权缺费小；(F2)不能据此替代完整Vterm。finite判据也不自动给连续B上的可测flow、闭性／紧性和极限RN控制。

## 3. 更新64工具的逐项结论

|工具|本题可用部分|仍缺的条件／不能推断的结论|
|---|---|---|
|B01|有限真实矩阵下的Farkas、弱对偶及精确primal/dual gap；可证N9有限模型feasible／infeasible。|必须固定完整矩阵、方向、margin与原RN帽；浮点残差不是证书。有限sampling不证明连续全cut条件或统一margin。|
|D01|静态正coupling的质量／边缘与cost方向核验。|向量KR的边缘差中性计划不是两个指定正边缘；不担保本模型正RN-capacity flow或θ总价。可行流给上界，dual可行势给下界，不能反用。|
|E01|明确有限状态／边的流守恒可核；同一中间节点measure必须共享。|不能给每stage另发W，不能把弱measure LP可行当真实连续coupling已构造；本题没有指定MDP转移律，也无需强行套连续occupation／随机停止定理。|
|G03|仅已给完整finite Hermitian输入时可核全Gram交叉；本轮未运行。|不能从对角／有限PSD身份推出cluster RN-cap或几何共同source界；私有capture接口不是来源定理。|
|M03|可提醒区分目标gap与到最优face／几何构型的距离。|当前没有一般nearoptimal stability；流近最优不保证接近一个共同partition、唯一cluster集合或低重复source。若另用有限polyhedral error bound，也须给实际conditioning／误差常数，不能假定n一致。|

## 停止点与母式收益

这一个来源提供的是可实现性测试和准确失败cut，适合指导N9模型／shared-H几何；它没有原文source-capacity价格上界，也没有“近最优必接近好cluster几何”的定理。当前 \(a<d^4/(4J^2)\)、完整 \(L\) 与原outer费用均未获新增付款；净一般预算增益为0。下一必要输入是保全marks的共同θ构造或一组可解释的真实坏cuts，而不是再用名称调用对偶、occupation或nearoptimal stability。

有界查询仅Gale准确题名／supply-demand theorem，随后打开原刊§2条件与证明；没有扩展文献列表。


## Parent integration

Parent read updated G03, M03 and B01 skills; none supplies the missing global geometric price bound. Fixed-price continuum selection is proved explicitly in REPORT, not asserted from an infinite-dimensional LP slogan. The near-fibre bound is elementary measure theory applied to original frozen quantities. The decisive new finite witness retains full old sigma; count-log widths are interval-enclosed but Qraw and L remain serialized finite inputs.

Historical rank-Hardy/chain/dictionary explorations are saved outside Git and summarized only at their actual global gaps. No new literature theorem is claimed to close those gaps. GitHub official scale limits were checked on 2026-10-23 against https://docs.github.com/en/repositories/creating-and-managing-repositories/repository-limits; no total repository file-count limit is inferred from diff display limits.
