"""R566 N9: fixed finite chi-lift shared-cluster price / full weighted terminal LP."""
import os
for key in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[key]='2'
import argparse,json,time,math,hashlib,resource,platform
from pathlib import Path
import numpy as np
import scipy
from scipy import sparse
from scipy.optimize import linprog

def nearby(*names):
 base=Path(__file__).resolve().parent
 return str(next((base/name for name in names if (base/name).exists()),base/names[0]))

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def serialize_matrix(A,prefix,out):
 A=A.tocsc();out[prefix+'_data']=A.data;out[prefix+'_indices']=A.indices;out[prefix+'_indptr']=A.indptr;out[prefix+'_shape']=np.array(A.shape)
def build(law,paths):
 st=time.perf_counter();n7=json.load(open(paths['n7']));old=json.load(open(paths['optimizer']));arr=np.load(paths['assembled']);T=arr['T_'+law];parents=old['summary']['frozen_parent_records'];states=old['summary']['action_states'];P=len(parents);edges=np.array(n7['Li']['edges_integer']);length=np.log2(edges[1:]/edges[:-1]);L=np.array(n7['Li']['L_values']);tau=n7['Li']['tau'];order=arr['source_order'];rank=np.argsort(order);starts=arr['starts'];ends=arr['ends'];nc=len(starts);sizes=ends-starts
 oldmask=np.zeros((P,64),bool)
 for state in states:
  if state['kind']=='initial':oldmask[state['parent'],state['receiver_atoms']]=True
 # Every nonzero original fine old source/sigma mark is retained.
 op=[];oz=[];os=[];pm=[];lv=[];rp=[];ry=[];rm=[];raw=[];rowE=T.sum((1,2));rowptr=[0];oldptr=[0]
 for b,r in enumerate(parents):
  ys,ms=np.nonzero(T[b]);rp.extend([b]*len(ys));ry.extend(ys.tolist());rm.extend(ms.tolist());raw.extend(T[b,ys,ms].tolist());rowptr.append(len(rp))
  wins=(edges[:-1]>=r['old_count'])&(edges[:-1]<2*r['old_count']);zs,ss=np.nonzero(oldmask[b,:,None]&wins[None,:]&(L>tau))
  op.extend([b]*len(zs));oz.extend(zs.tolist());os.extend(ss.tolist());pm.extend((length[ss]/r['old_count']).tolist());lv.extend(L[zs,ss].tolist());oldptr.append(len(op))
 op=np.array(op);oz=np.array(oz);os=np.array(os);pm=np.array(pm);lv=np.array(lv);rp=np.array(rp);ry=np.array(ry);rm=np.array(rm);raw=np.array(raw);rowptr=np.array(rowptr);oldptr=np.array(oldptr);q=raw/rowE[rp];p0=np.bincount(op,weights=pm,minlength=P);rowcap=p0[rp]*q
 fu=[];fs=[];types=[];typeix={}
 for b in range(P):
  for u in range(rowptr[b],rowptr[b+1]):
   for s in range(oldptr[b],oldptr[b+1]):
    y=int(ry[u]);z=int(oz[s]);m=int(rm[u])
    if abs(int(rank[y])-int(rank[z]))+1>2*m:continue
    key=(y,z,m)
    if key not in typeix:typeix[key]=len(types);types.append(key)
    fu.append(u);fs.append(s)
 fu=np.array(fu);fs=np.array(fs);ft=np.array([typeix[(int(ry[u]),int(oz[s]),int(rm[u]))] for u,s in zip(fu,fs)]);types=np.array(types);nt=len(types);nf=len(fu);nr=len(rp);ns=len(op);aoff=nc;foff=nc+nt;nv=foff+nf
 # a_type = incidence(theta); this equality cannot amplify capacity.
 ti=[];hi=[]
 for t,(y,z,m) in enumerate(types):
  lo=min(rank[y],rank[z]);hh=max(rank[y],rank[z]);inds=np.flatnonzero((starts<=lo)&(ends>hh)&(sizes<=2*m));ti.extend([t]*len(inds));hi.extend(inds.tolist())
 incidence=sparse.csr_matrix((np.ones(len(ti)),(ti,hi)),shape=(nt,nc));Aeq=sparse.hstack([-incidence,sparse.eye(nt),sparse.csr_matrix((nt,nf))],format='csc');beq=np.zeros(nt)
 ix=np.arange(nf);capcoef=q[fu]*pm[fs]
 rr=np.r_[ix,ix,nf+fu,nf+nr+fs,np.full(nf,nf+nr+ns)];cc=np.r_[foff+ix,aoff+ft,foff+ix,foff+ix,foff+ix];benefit=rowE[op[fs]]/lv[fs];vv=np.r_[np.ones(nf),-capcoef,np.ones(nf),np.ones(nf),-benefit]
 Aub=sparse.csc_matrix((vv,(rr,cc)),shape=(nf+nr+ns+1,nv));V=float(np.sum(rowE[op]*pm/lv));rhs=np.r_[np.zeros(nf),rowcap,pm,-V];objective=np.r_[sizes/64,np.zeros(nt+nf)]
 assert abs(V-n7['results'][law]['total_high_weighted_bill'])<2e-12
 metadata=dict(source_order=order,interval_starts=starts,interval_ends=ends,type_y_z_mass=types,receiver_parent=rp,receiver_y=ry,receiver_partnercount=rm,Qraw=raw,Qnormalized=q,rowE=rowE,p0=p0,old_parent=op,old_y=oz,old_sigma_segment=os,p_mark=pm,L_mark=lv,sigma_edge_counts=edges,sigma_length=length,parent_old_count=np.array([r['old_count'] for r in parents]),old_parent_mask=oldmask,flow_receiver=fu,flow_oldmark=fs,flow_type=ft,capcoef=capcoef,objective=objective,b_ub_zero_target=rhs,b_eq=beq,variable_offsets=np.array([0,aoff,foff,nv]),row_offsets=np.array([0,nf,nf+nr,nf+nr+ns,nf+nr+ns+1]),low_Li_weighted_complement=np.array(n7['results'][law]['low_Li_weighted_complement']))
 serialize_matrix(Aub,'A_ub',metadata);serialize_matrix(Aeq,'A_eq',metadata);serialize_matrix(incidence,'type_cluster_incidence',metadata)
 summary=dict(law=law,parents=P,receivermarks=nr,oldmarks=ns,flowvariables=nf,types=nt,clusters=nc,variables=nv,inequalities=Aub.shape[0],equalities=nt,nnz=Aub.nnz+Aeq.nnz,build_seconds=time.perf_counter()-st,total_high_weighted_bill=V,low_Li_weighted_complement=n7['results'][law]['low_Li_weighted_complement'],complete_chi_energy=float(rowE.sum()),old_sigma_compression='none: every high-Lfin old-source/sigma constant segment retained',Q_normalization='Qraw=T[p,y,partnercount] / sum Qraw for each parent; p0=sum fine p_mark, rowcap=p0*Qnormalized')
 return objective,Aub,rhs,Aeq,beq,metadata,summary

def run_witness(args,out,result,paths):
 st=time.perf_counter();obj,Aub,rhs,Aeq,beq,meta,summary=build('adaptive',paths);nt=summary['types'];nc=summary['clusters'];inc=sparse.csc_matrix((meta['type_cluster_incidence_data'],meta['type_cluster_incidence_indices'],meta['type_cluster_incidence_indptr']),shape=meta['type_cluster_incidence_shape']);print('START setcover',inc.shape,inc.nnz,flush=True)
 sol=linprog(obj[:nc],A_ub=-inc,b_ub=-np.ones(nt),bounds=(0,None),method='highs-ds',options=dict(time_limit=120,primal_feasibility_tolerance=1e-9,dual_feasibility_tolerance=1e-9))
 record=dict(scope='Restrictive complete fine-mark feasible upper witness; not full LP optimum',success=bool(sol.success),status=int(sol.status),message=sol.message,iterations=int(sol.nit),solve_seconds=time.perf_counter()-st)
 if sol.x is not None:
  theta=np.maximum(sol.x,0);cover=np.asarray(inc@theta).ravel();scale=max(1.,1/float(min(cover)))*(1+1e-10);theta*=scale;record.update(shared_theta_sparse=dict(cluster_indices=np.flatnonzero(theta>0).tolist(),theta_values=theta[theta>0].tolist(),cluster_interval_rank_starts=meta['interval_starts'][theta>0].tolist(),cluster_interval_rank_ends=meta['interval_ends'][theta>0].tolist(),source_mass_per_atom=1/64),raw_setcover_price=float(sol.fun),setcover_dual_lower=float(-np.sum(sol.ineqlin.marginals)),theta_inflation=scale,sourceprice=float(obj[:nc]@theta),minimum_type_cover=float(min(inc@theta)));witnesses={}
  for law in ['adaptive','optimum']:
   if law!='adaptive':obj,Aub,rhs,Aeq,beq,meta,summary=build(law,paths)
   modelfile=out.with_name(out.stem+'_'+law+'_model.npz');np.savez_compressed(modelfile,**meta);summary.update(model_file=str(modelfile),model_sha256=sha(modelfile));result['models'][law]=summary
   offsets=meta['variable_offsets'];atype=np.asarray(inc@theta).ravel();flow=meta['capcoef'].copy();primal=np.r_[theta,atype,flow];res=Aub@primal-rhs;benefit=meta['rowE'][meta['old_parent'][meta['flow_oldmark']]]/meta['L_mark'][meta['flow_oldmark']];terminal=summary['total_high_weighted_bill']-float(benefit@flow);candidate=out.with_name(out.stem+'_'+law+'_setcover_witness.npz');np.savez_compressed(candidate,primal=primal,theta_raw_setcover=sol.x,cover_dual_inequality=sol.ineqlin.marginals,cover_rhs=-np.ones(nt),full_b_ub_zero_target=rhs)
   witnesses[law]=dict(sourceprice=float(obj@primal),weighted_terminal=terminal,terminal_fraction=terminal/summary['total_high_weighted_bill'],low_Li_weighted_complement=summary['low_Li_weighted_complement'],total_including_low_Li=terminal+summary['low_Li_weighted_complement'],max_cap_violation=float(max(0,max(res[:summary['flowvariables']]))),max_margin_violation=float(max(0,max(res[summary['flowvariables']:-1]))),type_equality_linf=float(max(abs(Aeq@primal))),minimum_variable=float(min(primal)),candidate_file=str(candidate),candidate_sha256=sha(candidate),target_scope='Floating fine-mark witness; independent safe repair must certify actual terminal, not mathematical zero')
  record['witnesses']=witnesses
 result['setcover_witness']=record;result['code_sha256']=sha(__file__);result['final_maxrss_bytes']=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss;out.write_text(json.dumps(result,indent=2));print('WITNESS',json.dumps(record),flush=True)

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--n7',default=nearby('ccu_r565_n7.json','n7.json'));ap.add_argument('--assembled',default=nearby('ccu_r565_n7_assembled.npz','n7_assembled.npz'));ap.add_argument('--optimizer',default=nearby('ccu_r562_optimizer.json','optimizer.json'));ap.add_argument('--output',default=str(Path(__file__).with_suffix('.json')));ap.add_argument('--mode',choices=['witness','frontier'],default='witness',help='Default fast bounded witness; frontier explicitly enables the archived large LP algorithm');ap.add_argument('--method',choices=['highs-ipm','highs-ds'],default='highs-ipm');ap.add_argument('--time-limit',type=float,default=120);ap.add_argument('--retry-first',action='store_true');ap.add_argument('--witness',action='store_true');ap.add_argument('--all',action='store_true');ap.add_argument('--first',action='store_true');args=ap.parse_args();out=Path(args.output);paths={k:getattr(args,k) for k in ['n7','assembled','optimizer']}
 result=json.load(open(out)) if out.exists() else dict(schema='R566.N9.1',scope='Approved finite physical chi-lift surrogate X=1, Kfin=1 units only; not original Cstar/Li/headstop',sourceprice='sum common theta_H |H|/64; overlapping H permitted, no per-parent theta',input_hashes={k:sha(v) for k,v in paths.items()},runs={},models={},versions=dict(python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__))
 if args.retry_first and 'adaptive_terminal_0.1' in result['runs']:
  result.setdefault('historical_attempts',[]).append(result['runs'].pop('adaptive_terminal_0.1'))
 assert result['input_hashes']=={k:sha(v) for k,v in paths.items()};result['code_sha256']=sha(__file__)
 if args.witness or args.mode=='witness':
  for key in list(result['runs']):
   if not result['runs'][key].get('success',False):result.setdefault('historical_attempts',[]).append(result['runs'].pop(key))
  result['frontier_plan_status']='Six target LPs were planned; only adaptive .1V was attempted (IPM120s and DS300s, both no candidate). Other five targets not run. Parent replaced further frontier solves by the restrictive setcover upper witness.'
  run_witness(args,out,result,paths);return
 laws=['adaptive','optimum'] if args.all else ['adaptive'];targets=[.1,.01,0.] if args.all else [.1]
 for law in laws:
  todo=[t for t in targets if f'{law}_terminal_{t:g}' not in result['runs']]
  if not todo:continue
  objective,Aub,rhs,Aeq,beq,meta,summary=build(law,paths);modelfile=out.with_name(out.stem+'_'+law+'_model.npz');np.savez_compressed(modelfile,**meta);summary['model_file']=str(modelfile);summary['model_sha256']=sha(modelfile);result['models'][law]=summary;out.write_text(json.dumps(result,indent=2));print('MODEL',json.dumps(summary),flush=True)
  for target in todo:
   key=f'{law}_terminal_{target:g}';b=rhs.copy();b[-1]=summary['total_high_weighted_bill']*(target-1);print('START',key,flush=True);st=time.perf_counter()
   sol=linprog(objective,A_ub=Aub,b_ub=b,A_eq=Aeq,b_eq=beq,bounds=(0,None),method=args.method,options=dict(presolve=True,dual_feasibility_tolerance=1e-8,primal_feasibility_tolerance=1e-8,ipm_optimality_tolerance=1e-9,time_limit=args.time_limit))
   run=dict(method=args.method,time_limit=args.time_limit,law=law,target_fraction=target,target_terminal=summary['total_high_weighted_bill']*target,status=int(sol.status),success=bool(sol.success),message=sol.message,iterations=int(sol.nit),elapsed_seconds=time.perf_counter()-st,maxrss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
   if sol.x is not None:
    primal=sol.x;res=Aub@primal-b;eq=Aeq@primal-beq;off=meta['variable_offsets'];flow=primal[off[2]:];paid=float(np.dot(meta['rowE'][meta['old_parent'][meta['flow_oldmark']]]/meta['L_mark'][meta['flow_oldmark']],flow));terminal=summary['total_high_weighted_bill']-paid;theta=primal[:off[1]];dualb=float(b@sol.ineqlin.marginals+beq@sol.eqlin.marginals);dualres=objective-Aub.T@sol.ineqlin.marginals-Aeq.T@sol.eqlin.marginals
    candidate=out.with_name(out.stem+'_'+key+'_candidate.npz');np.savez_compressed(candidate,primal=primal,dual_inequality=sol.ineqlin.marginals,dual_equality=sol.eqlin.marginals,dual_lower=sol.lower.marginals,b_ub=b)
    run.update(sourceprice=float(objective@primal),weighted_terminal=terminal,terminal_fraction=terminal/summary['total_high_weighted_bill'],low_Li_weighted_complement=summary['low_Li_weighted_complement'],total_including_low_Li=terminal+summary['low_Li_weighted_complement'],primal_inequality_violation=float(max(0,max(res))),primal_equality_linf=float(max(abs(eq))),minimum_variable=float(min(primal)),dual_objective=dualb,primal_dual_gap=float(objective@primal-dualb),dual_reduced_cost_min=float(min(dualres)),dual_inequality_positive_violation=float(max(0,max(sol.ineqlin.marginals))),active_cluster_count=int(sum(theta>1e-9)),source_atom_price_load=[float(sum(theta[(meta['interval_starts']<=j)&(meta['interval_ends']>j)])) for j in range(64)],candidate_file=str(candidate),candidate_sha256=sha(candidate),fullzero_scope='Target0 is a floating near-clear candidate until independent certificate; no exact clearing claim')
   result['runs'][key]=run;out.write_text(json.dumps(result,indent=2));print('DONE',key,json.dumps(run),flush=True)
 result['final_maxrss_bytes']=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss;out.write_text(json.dumps(result,indent=2))
if __name__=='__main__':main()
