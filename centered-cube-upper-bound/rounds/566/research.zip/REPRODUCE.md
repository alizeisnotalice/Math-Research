# R566 portable fast reproduction

Use `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python` (3.12.14). Actual versions: NumPy2.5.4, SciPy1.18.1, SymPy1.14.0, python-flint0.9.0/Arb192. The fast witness uses SciPy HiGHS; N10 uses no solver. No MATLAB, installation, PDF compilation or failed full-LP rerun is required.

Extract optimizer.json and optimizer_input.json from committed rounds/562/research.zip (5437711af449b8a8132a866334fd323562fbe9d6), n3.py from rounds/563/research.zip (ce025dc55748ef1e8985bc468a7b6cd4ed40615b), and n7.py from rounds/565/research.zip (5ab73c29419ba8538eda30d807a4169ea509da15). Put them beside this package's three scripts. Archive hashes and script/input hashes are in verification.json. Reuse data without rerunning the old optimizer.

```sh
export OPENBLAS_NUM_THREADS=2 OMP_NUM_THREADS=2 MKL_NUM_THREADS=2
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python n3.py --optimizer optimizer.json --output n3.json
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python n7.py --optimizer optimizer.json --n3 n3.json --input optimizer_input.json --output n7.json
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python n9.py --mode witness --n7 n7.json --assembled n7_assembled.npz --optimizer optimizer.json --output n9.json
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python n10.py --n9 n9.json --n7 n7.json --assembled n7_assembled.npz --optimizer optimizer.json > n10.json
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python verify.py > finite_checks.json
```

Parent actually executed this in a new /tmp/ccu_r566_repro directory. N7 results/Li and N10 every restricted_cover, full_fine_flow and primitive_certificate field matched exactly. New JSON contains execution-dependent timings/paths/hashes; compare mathematical fields, not whole-file metadata. Run from the directory containing the regenerated n9.json so its relative model/candidate paths resolve. Existing n9.json from a different input run should not be reused: the code asserts input hashes. numerics_summary.json is the original historical record, not the replay output filename.

N9 default is the fast restricted cover witness. Its historical plan-status text describes the authors' two old full-LP attempts, not new work performed by a clean witness replay. The original record retains IPM120s and DS300s timeouts without candidates; remaining five planned full objectives were not run. Do not run --mode frontier just to reproduce the result.

N9 regenerates complete sparse full-model matrices and witness arrays outside Git. N10 checks their hashes, every fine mark/edge/incidence, exact shared theta and cover-only dual, and Arb direct missing-edge bills. The archived certificate stores48 theta and101 dual entries, exact rational enclosures for each of11 missing edges per law, and low-field complements. All large regenerable arrays and old inputs are intentionally omitted from this archive.

N10's exact object uses dyadic Qraw and L with exactly normalized Q and true count-log old widths. It does not enclose ideal geometric assembly or original continuous/history Li. Cover optimality is not general partial-flow optimality. Both high-field terminals are strictly positive. verify.py's983 rational fibre checks and symbolic residual0 support implementation only; the general near theorem has its separate audited proof. No dimension-order extrapolation follows.

REPORT is TeX source only. Structural environment/reference checks are recorded; no PDF was compiled. The next missing result is a common affordable cube-geometric price meeting full marked demand cuts or an equivalent whole-far weighted budget.
