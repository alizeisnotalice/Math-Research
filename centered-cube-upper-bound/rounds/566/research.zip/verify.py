"""Exact finite checks for the source-mass fibre gate, not a dimension theorem."""
from fractions import Fraction as F
from random import Random
import json,sys,platform,time
import sympy as s

def case(seed,n,N,mode):
    rng=Random(seed)
    if mode=='diagonal':points=[tuple([rng.randrange(-4,5)]*n) for _ in range(N)]
    elif mode=='ties':points=[tuple(rng.choice([-2,0,2]) for _ in range(n)) for _ in range(N)]
    else:points=[tuple(rng.randrange(-8,9) for _ in range(n)) for _ in range(N)]
    weights=[F(rng.randrange(1,10)) for _ in points];W=sum(weights,F())
    centers=[points[0],tuple(0 for _ in range(n)),tuple(rng.randrange(-10,11) for _ in range(n))]
    count=0;worst_slack=F()
    for y in centers:
        dist=[max(abs(a-b) for a,b in zip(z,y)) for z in points]
        values=[sum((w for w,d in zip(weights,dist) if d<=r),F()) for r in dist]
        for b in [F(),W/F(64),W/F(8),W/F(2),W,F(2)*W]+sorted(set(values)):
            fibre=sum((w for w,c in zip(weights,values) if c<=b),F())
            assert fibre<=min(b,W)
            count+=1;worst_slack=max(worst_slack,b-fibre)
    return dict(seed=seed,dimension=n,atoms=N,mode=mode,checks=count,max_slack=str(worst_slack))

def main():
    start=time.perf_counter()
    phases={
        'initial':[case(566+i,1+i%2,4,'general') for i in range(4)],
        'pressure':[case(1566+i,2+i%2,12,['diagonal','ties'][i%2]) for i in range(8)],
        'expanded':[case(2566+i,[1,2,3,8][i%4],64,['general','diagonal','ties'][i%3]) for i in range(16)]}
    gamma,K,Lambda,ls,C0,d,J=s.symbols('gamma K Lambda ls C0 d J',positive=True)
    eta=C0*d**4/(8*gamma*K*Lambda**2*ls*J**2)
    a0=s.simplify(gamma*K*Lambda**2*ls*eta/C0)
    assert s.simplify(a0-d**4/(8*J**2))==0
    A,C,L,a1,W=s.symbols('A C L a1 W',positive=True)
    zeta=1/(2*A);q=(4*C+8*A*A*L)*W/(1-8*A*A*a1)
    residual=s.factor(q-A*(zeta+(1/(8*A*A)+a1)/zeta)*q-(C+A*L/zeta)*W)
    assert residual==0
    print(json.dumps(dict(python=sys.executable,version=platform.python_version(),sympy=s.__version__,phases=phases,
        total_fibre_checks=sum(x['checks'] for a in phases.values() for x in a),
        algebra=dict(a0=str(a0),combined_mother_residual=str(residual)),seconds=time.perf_counter()-start,
        scope='Exact finite weighted atoms with ties test the fibre inequality; the general measurable-source argument is a separate proof. No far-branch estimate or dimension order is inferred.'),indent=2))
if __name__=='__main__':main()
