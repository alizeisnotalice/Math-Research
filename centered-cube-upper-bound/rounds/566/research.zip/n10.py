"""R566 N10 independent structured finite-mark partial-flow certificate.
No solver. Primal subflows are clipped/scaled safely; duals are scaled safely.
"""
from pathlib import Path
from fractions import Fraction as F
import argparse,json,hashlib,platform,sys,time
import numpy as np
import flint
from flint import arb,ctx
ctx.prec=192
ZERO=F(0);ONE=F(1);PREC=160

def sha(p):return hashlib.sha256(open(p,'rb').read()).hexdigest()
def A(x):return arb(x.numerator)/x.denominator if isinstance(x,F) else arb(x)
def bounds(x):return F(str(x.lower().fmpq())),F(str(x.upper().fmpq()))
def floor_dyadic(x):return F((x.numerator*(2**PREC))//x.denominator,2**PREC)
def interval(lo,hi):
    assert lo<=hi
    return dict(lower_exact=str(lo),upper_exact=str(hi),display=[float(lo),float(hi)])
def addgroup(values,groups,n):
    out=[ZERO]*n
    for value,g in zip(values,groups):out[int(g)]+=value
    return out

def load_model(path,law,n7,assembled,optimizer):
    z=np.load(path);rp=z['receiver_parent'];op=z['old_parent'];oy=z['old_y'];seg=z['old_sigma_segment'];P=len(z['rowE']);nr=len(rp);ns=len(op);fu=z['flow_receiver'];fs=z['flow_oldmark'];ft=z['flow_type'];nf=len(fu);off=list(map(int,z['variable_offsets']));roff=list(map(int,z['row_offsets']));starts=z['interval_starts'];ends=z['interval_ends'];order=z['source_order'];types=z['type_y_z_mass'];nt=len(types);nc=len(starts)
    assert P==332 and nr==len(z['Qraw']) and ns==len(z['p_mark']) and off==[0,nc,nc+nt,nc+nt+nf] and roff==[0,nf,nf+nr,nf+nr+ns,nf+nr+ns+1]
    assert sorted(map(int,order))==list(range(64)) and list(order)==n7['source_order'];rank=np.argsort(order)
    assert np.array_equal(starts,assembled['starts']) and np.array_equal(ends,assembled['ends'])
    parents=optimizer['summary']['frozen_parent_records'];states=optimizer['summary']['action_states'];initial={s['parent']:set(s['receiver_atoms']) for s in states if s['kind']=='initial'}
    assert np.array_equal(z['old_parent_mask'],np.array([[y in initial[b] for y in range(64)] for b in range(P)]))
    edges=z['sigma_edge_counts'];assert list(edges)==n7['Li']['edges_integer'];L=np.array(n7['Li']['L_values']);tau=n7['Li']['tau'];expectedold=set()
    for b in range(P):
        for y in initial[b]:
            for k,e in enumerate(edges[:-1]):
                if parents[b]['old_count']<=e<2*parents[b]['old_count'] and L[y,k]>tau:expectedold.add((b,y,k))
    observedold=set(zip(map(int,op),map(int,oy),map(int,seg)));assert len(observedold)==ns and observedold==expectedold
    assert np.array_equal(z['L_mark'],L[oy,seg]) and np.all(z['L_mark']>0)
    T=assembled['T_'+law];expectedreceiver=set(zip(*np.nonzero(T)));observedreceiver=set(zip(map(int,rp),map(int,z['receiver_y']),map(int,z['receiver_partnercount'])));assert len(observedreceiver)==nr and observedreceiver==expectedreceiver
    assert np.array_equal(z['Qraw'],T[rp,z['receiver_y'],z['receiver_partnercount']]) and np.all(z['Qraw']>0)
    assert np.array_equal(z['Qnormalized'],z['Qraw']/z['rowE'][rp])
    assert np.array_equal(z['capcoef'],z['Qnormalized'][fu]*z['p_mark'][fs])
    # All source-cluster incidences, including absent entries, are checked.
    ip=z['type_cluster_incidence_indptr'];ii=z['type_cluster_incidence_indices'];dd=z['type_cluster_incidence_data'];assert np.all(dd==1)
    ty,tz,tm=types.T;lo=np.minimum(rank[ty],rank[tz]);hi=np.maximum(rank[ty],rank[tz])
    for h,(s,t) in enumerate(zip(starts,ends)):
        expected=np.flatnonzero((s<=lo)&(t>hi)&(t-s<=2*tm));assert np.array_equal(ii[ip[h]:ip[h+1]],expected)
    assert len(set(map(tuple,types.tolist())))==nt
    assert np.all(rp[fu]==op[fs]) and np.array_equal(types[ft,0],z['receiver_y'][fu]) and np.array_equal(types[ft,1],oy[fs]) and np.array_equal(types[ft,2],z['receiver_partnercount'][fu])
    observedkeys=set(map(int,fu.astype(np.int64)*ns+fs));assert len(observedkeys)==nf;expectedflowcount=0;missing=[];oldby=[np.flatnonzero(op==b) for b in range(P)]
    for u in range(nr):
        ss=oldby[int(rp[u])];good=ss[np.abs(rank[z['receiver_y'][u]]-rank[oy[ss]])+1<=2*z['receiver_partnercount'][u]];expectedflowcount+=len(good)
        assert all(int(u)*ns+int(s) in observedkeys for s in good)
        missing.extend((u,int(s)) for s in ss if int(u)*ns+int(s) not in observedkeys)
    assert expectedflowcount==nf
    costs=[F(int(t-s),64) for s,t in zip(starts,ends)];assert all(F(float(z['objective'][h]))==costs[h] for h in range(nc)) and np.all(z['objective'][nc:]==0)
    raw=[F(float(v)) for v in z['Qraw']];row=addgroup(raw,rp,P);q=[A(v)/A(row[int(b)]) for v,b in zip(raw,rp)]
    widths=[(A(F(int(b),int(a))).log()/arb(2).log()) for a,b in zip(edges[:-1],edges[1:])];p=[widths[int(k)]/int(z['parent_old_count'][int(b)]) for b,k in zip(op,seg)];p0=[arb(0) for _ in range(P)]
    for value,b in zip(p,op):p0[int(b)]+=value
    qsum=[arb(0) for _ in range(P)]
    for value,b in zip(q,rp):qsum[int(b)]+=value
    assert all(value.contains(1) for value in qsum)
    w=[A(row[int(b)])/A(F(float(l))) for b,l in zip(op,z['L_mark'])];pb=[bounds(v) for v in p];qb=[bounds(v) for v in q];wb=[bounds(v) for v in w];recb=[bounds(p0[int(b)]*v) for b,v in zip(rp,q)]
    Vlo=sum((a[0]*b[0] for a,b in zip(pb,wb)),ZERO);Vhi=sum((a[1]*b[1] for a,b in zip(pb,wb)),ZERO)
    maxp_error=max(max(abs(F(float(v))-a),abs(F(float(v))-b)) for v,(a,b) in zip(z['p_mark'],pb))
    primitive=dict(source_clusters=nc,types=nt,receivermarks=nr,old_sigma_marks=ns,flow_edges=nf,all_marks_and_allowed_flow_edges_complete=True,all_cluster_type_incidences_exact=True,shared_source_cost_coefficients_exact=True,full_Q_normalizes_from_Qraw=True,missing_fine_product_edges=len(missing),weighted_initial_bill=interval(Vlo,Vhi),maximum_float_pmark_error_bound_exact=str(maxp_error),old_sigma_not_averaged=True,normalization='q=exact dyadic Qraw divided by its exact parent sum; p=exact log2 edge ratio / oldcount; L=serialized positive dyadic L_mark; rowE=exact Qraw parent sum')
    return dict(missing=missing,raw=raw,row=row,widths=widths,n7=n7,parents=parents,initial=initial,z=z,P=P,nr=nr,ns=ns,nf=nf,nc=nc,nt=nt,off=off,roff=roff,rp=rp,op=op,fu=fu,fs=fs,ft=ft,ip=ip,ii=ii,q=q,p=p,p0=p0,w=w,pb=pb,qb=qb,wb=wb,recb=recb,Vlo=Vlo,Vhi=Vhi,costs=costs,primitive=primitive)

def audit_candidate(m,candidate_path,run):
    c=np.load(candidate_path);x=c['primal'];y=c['dual_inequality'];nc=m['nc'];nt=m['nt'];nf=m['nf'];nr=m['nr'];ns=m['ns'];P=m['P'];fu=m['fu'];fs=m['fs'];ft=m['ft'];rp=m['rp'];op=m['op'];ip=m['ip'];ii=m['ii'];target=F(str(run['target_fraction']))
    assert len(x)==m['off'][-1] and len(y)==m['roff'][-1] and 0<=target<=1 and np.all(np.isfinite(x)) and np.all(np.isfinite(y))
    theta=[max(ZERO,F(float(v))) for v in x[:nc]];atype=[ZERO]*nt
    for h,t in enumerate(theta):
        if t:
            for k in ii[ip[h]:ip[h+1]]:atype[int(k)]+=t
    flow=[ZERO]*nf;maxcapclip=ZERO
    for e,raw in enumerate(x[m['off'][2]:]):
        f=max(ZERO,F(float(raw)))
        if not f:continue
        u,s,t=int(fu[e]),int(fs[e]),int(ft[e]);cap=m['qb'][u][0]*m['pb'][s][0]*atype[t]
        flow[e]=min(f,cap);maxcapclip=max(maxcapclip,f-flow[e])
    rec=addgroup(flow,fu,nr);old=addgroup(flow,fs,ns);scale=[ONE]*P
    for u,v in enumerate(rec):
        if v:scale[int(rp[u])]=min(scale[int(rp[u])],m['recb'][u][0]/v)
    for s,v in enumerate(old):
        if v:scale[int(op[s])]=min(scale[int(op[s])],m['pb'][s][0]/v)
    scale=[max(ZERO,floor_dyadic(v)) for v in scale]
    flow=[v*scale[int(rp[int(u)])] for v,u in zip(flow,fu)];rec=addgroup(flow,fu,nr);old=addgroup(flow,fs,ns)
    assert all(v<=m['recb'][u][0] for u,v in enumerate(rec)) and all(v<=m['pb'][s][0] for s,v in enumerate(old))
    Tlo=sum(((m['pb'][s][0]-old[s])*m['wb'][s][0] for s in range(ns)),ZERO);Thi=sum(((m['pb'][s][1]-old[s])*m['wb'][s][1] for s in range(ns)),ZERO)
    price=sum((a*b for a,b in zip(theta,m['costs'])),ZERO);primal_feasible=Thi<=target*m['Vlo']
    # Correct partial-flow dual, not the equality-margin dual.
    alpha=[max(ZERO,-F(float(v))) for v in y[nf:nf+nr]];beta=[max(ZERO,-F(float(v))) for v in y[nf+nr:nf+nr+ns]];eta=max(ZERO,-F(float(y[-1])))
    loadtype=[ZERO]*nt
    for e,(u,s,t) in enumerate(zip(fu,fs,ft)):
        u,s,t=int(u),int(s),int(t);lam=max(ZERO,eta*m['wb'][s][1]-alpha[u]-beta[s])
        if lam:loadtype[t]+=m['qb'][u][1]*m['pb'][s][1]*lam
    loadH=[];factor=ONE
    for h in range(nc):
        load=sum((loadtype[int(k)] for k in ii[ip[h]:ip[h+1]]),ZERO);loadH.append(load)
        if load:factor=min(factor,m['costs'][h]/load)
    factor=max(ZERO,floor_dyadic(factor));assert all(factor*v<=cost for v,cost in zip(loadH,m['costs']))
    dual0=eta*(1-target)*m['Vlo']-sum((v*m['recb'][u][1] for u,v in enumerate(alpha)),ZERO)-sum((v*m['pb'][s][1] for s,v in enumerate(beta)),ZERO);dual=max(ZERO,factor*dual0)
    out=dict(candidate_sha256=sha(candidate_path),target_fraction_exact=str(target),shared_price_exact=str(price),weighted_terminal=interval(Tlo,Thi),terminal_fraction=interval(Tlo/m['Vhi'],Thi/m['Vlo']),strict_nominal_target_primal_feasible=primal_feasible,primal_repair=dict(nonnegative_clipping=True,max_single_flow_cap_clip_exact=str(maxcapclip),minimum_parent_downscale_exact=str(min(scale)),common_theta_not_parent_dependent=True,all_RN_caps_and_both_submargins_verified=True,old_sigma_retained=True),dual_certificate=dict(eta_serialized_exact=str(eta),uniform_safe_scaling_exact=str(factor),cluster_price_constraints_exact=True,lower_bound_exact=str(dual),correct_partial_dual=True),strict_nominal_optimum_upper_exact=str(price) if primal_feasible else None,strict_nominal_gap_upper_exact=str(price-dual) if primal_feasible else None,zero_terminal_claim=(Thi==0),scope='Structured finite marks using exact Qraw normalization, exact count-log old widths, dyadic L. Repaired positive subflow with explicit terminal; not original Cstar.')
    return out

def audit_cover_witness(m,path):
    data=np.load(path);theta=[max(ZERO,F(float(v))) for v in data['theta_raw_setcover']];nc=m['nc'];nt=m['nt'];ip=m['ip'];ii=m['ii'];assert len(theta)==nc
    coverage=[ZERO]*nt
    for h,t in enumerate(theta):
        if t:
            for k in ii[ip[h]:ip[h+1]]:coverage[int(k)]+=t
    minimum=min(coverage);assert minimum>0
    inflation=max(ONE,ONE/minimum);theta=[t*inflation for t in theta];coverage=[v*inflation for v in coverage];assert min(coverage)>=1
    price=sum((v*c for v,c in zip(theta,m['costs'])),ZERO)
    dual=[max(ZERO,-F(float(v))) for v in data['cover_dual_inequality']];assert len(dual)==nt
    factor=ONE
    for h in range(nc):
        load=sum((dual[int(k)] for k in ii[ip[h]:ip[h+1]]),ZERO)
        if load:factor=min(factor,m['costs'][h]/load)
    dual=[v*factor for v in dual]
    assert all(sum((dual[int(k)] for k in ii[ip[h]:ip[h+1]]),ZERO)<=m['costs'][h] for h in range(nc))
    lower=sum(dual,ZERO);assert lower<=price
    # f(u,s)=q_u p_s for every allowed fine edge. Its weighted terminal is the
    # missing product only; rowE*q=Qraw removes subtraction and normalization.
    terminal=arb(0);details=[]
    for u,s in m['missing']:
        L=F(float(m['z']['L_mark'][s]));term=A(m['raw'][u])*m['p'][s]/A(L);assert term>0;terminal+=term
        details.append(dict(receiver=u,old_sigma_mark=s,parent=int(m['rp'][u]),receiver_source=int(m['z']['receiver_y'][u]),old_source=int(m['z']['old_y'][s]),partner_count=int(m['z']['receiver_partnercount'][u]),sigma_segment=int(m['z']['old_sigma_segment'][s]),contribution=interval(*bounds(term))))
    Tlo,Thi=bounds(terminal);assert Tlo>=0
    # The low-Li complementary source bill is retained, using the same explicit
    # count-log widths and the same serialized positive global old field.
    low=arb(0);edges=m['z']['sigma_edge_counts'];Lglobal=np.array(m['n7']['Li']['L_values']);tau=m['n7']['Li']['tau']
    for b,parent in enumerate(m['parents']):
        for source in m['initial'][b]:
            for k,e in enumerate(edges[:-1]):
                lv=float(Lglobal[source,k])
                if parent['old_count']<=e<2*parent['old_count'] and 0<lv<=tau:low+=A(m['row'][b])*m['widths'][k]/parent['old_count']/A(F(lv))
    lowlo,lowhi=bounds(low)
    return dict(candidate_sha256=sha(path),restricted_cover=dict(theta_sparse_exact=[[h,str(v)] for h,v in enumerate(theta) if v],dual_sparse_exact=[[t,str(v)] for t,v in enumerate(dual) if v],raw_minimum_type_coverage_exact=str(minimum),exact_theta_inflation=str(inflation),all_type_coverages_at_least_one=True,sourceprice_upper_exact=str(price),safe_dual_lower_exact=str(lower),exact_restricted_primal_dual_gap=str(price-lower),restricted_setcover_exact_optimal=(price==lower),scope='Only min common sourceprice subject to every eligible type coverage>=1. This is not a lower bound for the general capacitated partial-flow LP.'),full_fine_flow=dict(definition='q_u*p_s on every eligible fine receiver/old-sigma edge; zero on missing edges',RN_cap_against_original_product_verified=True,both_submargins_for_any_positive_normalized_Q_and_P_verified=True,common_theta_shared_by_all_parents=True,old_sigma_not_averaged=True,missing_edge_count=len(m['missing']),missing_edge_details=details,weighted_high_terminal=interval(Tlo,Thi),weighted_high_terminal_fraction=interval(Tlo/m['Vhi'],Thi/m['Vlo']),strict_positive_terminal=(Tlo>0),exact_zero_terminal=(Thi==0),sourceprice_upper_exact=str(price),strictly_feasible_target_fractions={str(t):Thi<=t*m['Vlo'] for t in [F(1,10),F(1,100),ZERO]},low_Li_complement=interval(lowlo,lowhi),terminal_including_low_Li=interval(Tlo+lowlo,Thi+lowhi),general_flow_optimality_not_certified=True))

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--n9',type=Path,default=Path(__file__).resolve().parent/'n9.json');ap.add_argument('--n7',type=Path,default=Path(__file__).resolve().parent/'n7.json');ap.add_argument('--assembled',type=Path,default=Path(__file__).resolve().parent/'n7_assembled.npz');ap.add_argument('--optimizer',type=Path,default=Path(__file__).resolve().parent/'optimizer.json');args=ap.parse_args();start=time.perf_counter();n9=json.load(open(args.n9));n7=json.load(open(args.n7));assembled=np.load(args.assembled);optimizer=json.load(open(args.optimizer));models={};runs={};covers={}
    for law,record in n9.get('models',{}).items():
        path=Path(record['model_file']);assert sha(path)==record['model_sha256'];m=load_model(path,law,n7,assembled,optimizer);models[law]=dict(model_sha256=sha(path),primitive_certificate=m['primitive'])
        witness=n9.get('setcover_witness',{}).get('witnesses',{}).get(law)
        if witness:
            wp=Path(witness['candidate_file']);assert sha(wp)==witness['candidate_sha256'];covers[law]=audit_cover_witness(m,wp)
        for key,run in n9.get('runs',{}).items():
            if run['law']!=law or 'candidate_file' not in run:continue
            cp=Path(run['candidate_file']);assert sha(cp)==run['candidate_sha256'];runs[key]=audit_candidate(m,cp,run)
        # Positive-target feasibility can be restored by a convex mixture of two
        # already-certified subflows from the SAME frozen law, without a solver.
        local={k:v for k,v in runs.items() if n9['runs'][k]['law']==law}
        for key,r in local.items():
            t=F(r['target_fraction_exact']);T=F(r['weighted_terminal']['upper_exact']);C=F(r['shared_price_exact']);target=t*m['Vlo']
            if t<=0 or r['strict_nominal_target_primal_feasible']:continue
            donors=[(k,v) for k,v in local.items() if F(v['weighted_terminal']['upper_exact'])<target]
            if not donors:continue
            dk,d=min(donors,key=lambda kv:F(kv[1]['shared_price_exact']));Td=F(d['weighted_terminal']['upper_exact']);Cd=F(d['shared_price_exact']);mix=floor_dyadic((target-Td)/(T-Td));assert 0<=mix<=1 and mix*T+(1-mix)*Td<=target
            upper=mix*C+(1-mix)*Cd;r['convex_same_law_feasible_upper']=dict(donor=dk,own_weight_exact=str(mix),sourceprice_upper_exact=str(upper),terminal_upper_exact=str(mix*T+(1-mix)*Td),strict_nominal_target_feasible=True);r['strict_nominal_optimum_upper_exact']=str(upper);r['strict_nominal_gap_upper_exact']=str(upper-F(r['dual_certificate']['lower_bound_exact']))
    out=dict(python=sys.executable,python_version=platform.python_version(),numpy=np.__version__,flint=flint.__version__,arb_precision_bits=ctx.prec,code_sha256=sha(__file__),input_n9_sha256=sha(args.n9),models=models,runs=runs,setcover_upper_witnesses=covers,candidate_count=len(runs),general_flow_lp_optimality_or_infeasibility_not_certified=True,restricted_cover_witness_count=len(covers),no_candidate_status='No primal/dual or infeasibility conclusion without a serialized candidate; timeouts are not infeasibility.' if not runs and not covers else None,elapsed_seconds=time.perf_counter()-start,scope='Finite structured marks and explicit candidate subflows/dual bounds only. No optimizer rerun, original Li/headstop/Ndelta, empirical quadrature or general root-order certificate.')
    print(json.dumps(out,indent=2))
if __name__=='__main__':main()
