# R566 final independent audit ledger

Final state: general root-order theorem OPEN. The direct source-fibre estimate and rank-based near gate PASS; it pays only a branch. The fixed-input/countable-family/common-price continuum flow theorem PASS conditional on all Hall cuts; global prices and far payment remain unproved. N9/N10 finite evidence is separately certified below, never promoted to original continuous Cstar.

The following role records are chronological. Statements before the numeric solve saying no result yet refer to that stage. The final N10 certificate and NUMERICS.md supersede that timing only, not their scope restrictions. Parent REPORT reorganizes the audited fibre proof and avoids duplicating its tree alternative; capacity measure Lambda in the flow author's note is renamed Cap to avoid collision with original action mass.


---

## audit

# R566 独立命题审查：shared-cluster RN price flow

先只读 R566 冻结合同，不读本轮作者推导。使用 R564 已审 single-H mass-cap 和 R565 原R预截断为输入；不重证旧RN/DP。当前交付是命题级预算检查，不是共享价格构造或全局目标证明。

## 1. 完整被付对象和两种必须分开的预算

原动作、Li/alpha、真实来源、Lebesgue父、ordered head/stop/core、phase与旧σ均冻结。R=X_B(x)Z_B(z,σ)，Z=1_{Li>τ}；原概率Q_B,P_B及初始次边缘

 ξ0=p0 Q_B|X，ν0=q0 P_B|Z，δ0=p0q0

保持 R 的原积测度：ξ0⊗ν0/δ0=Q_B|X⊗P_B|Z。δ0=0时该父贡献为0；r_B或T_B=t_Bq_B为0的父略去。物理因子仍为r_BT_BdB，不能再次除δ0。

此轮必须同时满足：

1. 每个原父的两边缘容量，负责一次原score信用；
2. 所有父共享的来源价格Σ_Hθ_Hμ(H)，负责一次W预算。

第一项成立不推出第二项，第二项成立也不推出flow覆盖。价格/簇可以依完整输入和一次共同随机种子，但不能为每个父重新发一份价格预算。这里是分析coupling，不是receiver之后改action。

## 2. Shared-price付款命题：准确可行范围

取一个共同可数族H⊂C_i，μ(H)>0，允许重叠，取共同非负θ_H。c>0为指定参数；E_H={x:y∈H,μ(H)≤cM_C(v)}，保留原marks。每父取非负coupling pieces Γ_BH，要求

 Σ_H (receiver边缘Γ_BH)≤ξ0，
 Σ_H (old边缘Γ_BH)≤ν0，
 dΓ_BH/d(Q_B⊗P_B)≤θ_H1_R1_EH(x)1_H(z)。

这是足以支付该flow的正确主张。它既不要求每个piece rank1，也不要求簇互斥。所有piece仍需可测，old标记是(z,σ)，不能只处理source-count边缘后默认旧σ也匹配。

设剩余边缘为ξbar、νbar。由于每个Γ_BH的两边缘同质量，剩余边缘也有相同质量δbar。以ξbar⊗νbar/δbar补终端，零质量时取0。paid pieces加终端精确保原截断两边缘，因而保原R的总质量、Li旧score与Li倒数费。信用等于

 ∫(r_BT_B/K)∫Li dν0 dB≤Qfr≤Qg。

终端的准确来源费是

 Vterm=K∫r_BT_B∫Li⁻¹dνbar dB，

而非未配概率δbar，亦非δbar乘某个全局平均倒数场。Li⁻¹仅在Z使用、外部取0。

由RN支配及正项Tonelli，直接有

 Vpaid≤Σ_Hθ_H K∫_{R,E_H,z∈H}dM/Li
       ≤cLcl(K)Σ_Hθ_Hμ(H)。

所以若Σθ_Hμ(H)≤P W，完整结果仅是

 VR=Vpaid+Vterm≤cLcl(K)P W+Vterm。

这是真正的合法付款接口，但总价P及terminal的完整控制都尚待构造。单H引理给重叠加权和付款的理由是逐项正估计再求和，未把重叠族误称互斥。若不同H使用c_H，成本必须改成Σc_Hθ_Hμ(H)，不能仍收固定c。

## 3. 是否增加N7静态partition自由：可行集检查

共享flow允许：不同父在同一共享簇价下采用不同匹配量；多个重叠簇分摊同一父的边缘；非rank1且可依旧σ的piece。这些是静态共同partition+固定最大匹配块没有的一般变量。

但“变量更多”不能直接证明以同预算覆盖更多真实bill。比较必须固定同一个marked有限对象、旧Li、R截断、c和价格单位。一个固定共同互斥族、阈值ε的原最大匹配方案可嵌入这里：对被采用的簇取共同θ_H≥原RN的跨父上界，例如已证固定初始阈值下θ_H=1/ε。其来源总价最多W/ε，而不是自动W。不能把这种price factor省去后声称新模型免费支配N7。

静态pointwise packing Σθ_H1_H≤1只是Σθ_HμH≤W的充分条件，不是必要条件；积分价格约束可以容许局部大负载。但局部大负载仍受每父两边缘容量及整个联合edge容量约束。更弱来源packing与更一般joint flow可能扩可行集；在N7输入上是否严格改善及总价多少，交唯一N9队列证明，不在此猜测或重跑。

N9 surrogate的有限old field及Kfin单位必须按合同保留；rmax>4时不能把Kfin=1冒充原行帽。有限flow可行不自动证明连续原Li/全部headstop的流存在。

## 4. 有用的必要joint容量检验

固定prices后，合并edge容量为

 C_B(x,ℓ)=1_R Σ_Hθ_H1_EH(x)1_H(z)，ℓ=(z,σ)。

要求一个paid coupling≤C_B(Q_B⊗P_B)。反过来，在可数可测族及有限容量下，aggregate dominated coupling可按每项容量占总容量的比例拆回Γ_BH，零总容量处取0。故同prices下“分簇pieces”和“aggregate edge capacity”应保持一致，不能在转为flow时丢掉joint边界。

若要零terminal、完整恢复ξ0和ν0，则必要的单边容量为

 Σ_Hθ_H Q_B(X∩E_H)1_H(z)≥q0， 对P_B|Z-a.e.旧源，
 Σ_Hθ_H P_B(Z∩H)1_EH(x)≥p0， 对Q_B|X-a.e.receiver。

这些条件仍不充分，因为某个receiver子集与某个old子集之间可能共同缺容量。对任意可测A⊂{X=1}、D⊂{Z=1}，必须有完整cut不等式

 ξ0(A)+ν0(D)−δ0≤∫_{A×D}C_B d(Q_B⊗P_B)。

推导是Γ(A×全)+Γ(全×D)−δ0=Γ(A×D)−Γ(A^c×D^c)，随后用非负性和edge cap。这个必要式保真实旧σ，可用于检查几何构造缺的joint约束。有限网络可由完整min-cut/dual核验；本审查不把有限LP可行性未经极限证明搬成连续定理。

若允许terminal，可用剩余旧边缘νbar的原Li⁻¹加权费评价cut缺口；总缺口概率小不够。尤其不能只满足old边缘capacity而忽略receiver端，或反之。

## 5. 可数/连续极限和母账

有界总price对固定原父通常给可积aggregate capacity：旧空间概率密度为1/m_B，旧σ长1，所以其积分由Σθ_Hμ(H)/m_B控制。这个可积性有助于合法可数正和，但不等于已经构造共同measurable flow或证明全部有限逼近有同一极限。作者需要明确所用front/price族、可测选择、边缘收敛和weighted terminal；一般耦合/LP名称本身不补这些条件。

若最终Vterm≤aQg+LtermW，且来源price≤P W，则VR≤aQg+L W，L=cLcl(K)P+Lterm。令A=J/d²、C=2A(Kw+K+Fcap)+2Brem/d，原母账允许

 Q/W≤b0⁻² [C+AL/ζ]/[1−A(ζ+a/ζ)]，

其中ζ>0且分母严格为正。可选ζ存在的必要充分数值条件是a<1/(4A²)=d⁴/(4J²)；a=0单独按正ζ处理。这里所有price、terminal、c和动作/窗口参数都需入L，不能只报告P是polylog而丢Lcl或外层时钟。原入口、原子、极端分支等合同外层费用仍保留。

因此当前命题级判定为：shared-price-flow付款接口PASS；全局共享price构造、完整可行flow和可付terminal均OPEN。它可能增加静态partition之外的自由，但暂未证明有新的全局改善。后续只定点审核作者真正新构造，不重新证明旧RN或泛扫反例。

## 6. 实际工具与等待状态

指定本机Python/SymPy已实跑：预截断product系数残差正确；joint cut恒等式返回Γ(A×D)−Γ(A^c×D^c)；母账重排残差0。这些仅是精确代数校验，不是flow存在性或几何证据。

尚未读本轮作者稿。目前实际等待shared-price或fullU/terminal的决定性构造输入，初审到此停止；未改他人文件、repo，未spawn、未编译PDF、未运行昂贵实验。

## 7. 正式独审：完整小质量来源并集的原score吸收

按父代理明确新任务，先独立推导所述命题，再读 `/tmp/ccu_r566_coordinates.tex`。主定理 r566c:exact → r566c:masscancel → r566c:main 判定 PASS。以下只审该真实正子预算；shared-price全覆盖及其他构造仍按前文为OPEN。

### 7.1 固定森林与最大eligible节点

每个原source cell使用同一个可数rooted laminar森林；roots及siblings均μ-互斥，节点属于原source cell、每节点只有有限祖先，忽略μ-null节点。对固定实际C,v令t=ηα_C M_C(v)。最大eligible节点准确为μ(H)≤t且root或μ(parent H)>t。等号留在eligible侧，parent严格大于t，因而相同质量的嵌套节点不会重复选取。

任意eligible节点沿其有限祖先链都有最上方eligible祖先；因此所有eligible same-node pair事件的并集，恰等于最大节点的same-node事件并集。最大节点形成μ-disjoint antichain，未覆盖来源/来源对不被补造。可数性加每节点常数质量的可测阈值检验，使选择及pair event对C,v,y,z联合可测；不要求完整覆盖、无限细化或μ密度上界。

front依C,v、原α_C与实际M而变，只作为已冻结积分上的analysis gate。这不改变actions，也不调用每front一次W的旧mass-cap，因此此处父/receiver相关分析front合法。原森林仍共同；没有另给每个C一份来源预算。

### 7.2 原完整R、停止节点和旧窗

dV=K1_{Nδ^c}1_{Li>τ}dM/Li沿原定义。Uthin与B、T、g、σ无关（固定i,C,v,y,z后），所以可提到这些原积分外。receiver删减1_{Nδ^c}依内父B等真实变量，作者将其保留在原B积分/实际T求和之内，定义F^R。因此

 0≤F^R≤F≤Li，support_σ F^R⊂Σ_C=(s_C−1−h,s_C+2+h)。

这里Σ_C固定实际C，长度是3+2h；本证明没有对C质量档取union，不能误用旧mass-cap的4+2h+logγKmax，也没有遗漏这段旧窗。原w中M/(γI_B M_B(g))在真实相交窗上≤1；head、Gate、H_T、实际first-stop及phase条件均留在F后才作正上界。作者的r566c:exact因此确为原Vthin，外系数γK t_Cq_C/(I_C M²)、双方真实μ和全部ω端点无漏项。

将y积分写在Q_C(v)上合法：F^R已含真实Gate和core来源指标，在被扩大的域外部分为0；不是另将H_T的质量改成整个cube质量。

### 7.3 真正的μ²消项与原评分

固定C,v后，先由antichain互斥性对真实pair积分得到

 ∫_{QC(v)}∫1_Uthin μ(dz)μ(dy)
 =Σ_H μ(H)μ(H∩QC(v))
 ≤ηα_C M·Σ_Hμ(H∩QC(v))
 ≤ηα_C M²。

此处两个真实来源各积分一次；旧z无需位于QC(v)。没有假设来源坐标独立，没有将coupling diagonal当作μ²，也没有更换真实Lebesgue中心积分。两份外M分母都被该M²准确取消。

之后F^R/Li≤1仅支付长度3+2h，原g、v两个ω积分分别为Λ，I_C≥1，得到

 Vthin≤γKΛ²(3+2h)η Σ_i∫_{E_i^bulk}t_Cq_Cα_C dC
       =[γKΛ²(3+2h)/C0]η Qfr
       ≤a_η Qg。

外父确在原bulk；α_C没有因front选择而重算，e_C=C0t_Cq_Cα_C正是原score。因此Qfr归一化正确，没有遗漏C0或重复源格。该证明不经R565 recoupling，不携带2/ε的RN因子；也没有多前沿发W的问题。

### 7.4 母账中的实际吸收量

取η=C0d⁴/[8γKΛ²(3+2h)J²]，得到a_η=d⁴/(8J²)。它是所需平方系数阈值d⁴/(4J²)的一半；对应母账线性系数2J√a_η/d²=1/√2，而不是1/2。

完整正分割仍为VR=Vthin+Vrest，所以唯一实际新结论是VR≤a_ηQg+Vrest。Vrest未付，不能从可吸收的thin分支直接声称最终界。若未来再对rest给a_rest Qg，则必须将a_η+a_rest合并检验同一个阈值；不能再单独使用一整份吸收余量。原Cstar Cauchy以及母账外层费用保持不变。

### 7.5 一个scope修正与保留的OPEN接口

稿件中将∫_{U^c\Uthin}dV称为“original terminal”的一句需要区分对象：该项是原product测度在eligible union外的未付正项；R565 sequential freezing的真实terminal是残余边缘coupling，它可在U内部，且一般不等于原product的U^c restriction。已向作者及父代理指出，要求改成原pair union外部分，明示不识别为recoupled terminal。

这个措辞修正不影响主界、VR的准确正分割或任何常数。任意U的集合恒等分解

 Uthin^c=(U\Uthin) ⊔ (U^c\Uthin)

当然成立，但不能由它推出另一coupling的terminal identity。所有未被Uthin覆盖的原R，包括large-node、分离pairs及small-block来源，仍在Vrest；其全局付款OPEN。

此吸收本身仍只使用正支配与实际小质量条件，未产生方体特有的维数增益。它是本轮真实可吸收分支，并非完整目标闭合。

### 7.6 实际本机验证

指定Python/SymPy实跑：两M与pair M²消项残差0；η代入得到d⁴/(8J²)；相对平方阈值比例1/2；真实母账线性系数返回√2/2。仅为精确代数辅助，不替代上述测度证明。

主定理正式PASS；等待作者落盘上述一处terminal范围措辞小修后冻结，本轮不扩其他泛审。

## 8. 追加定点独审：无树的真实source fiber及cube-mass near/far

已按父代理新增任务，独立核验后读取同一作者稿的新 r566c:fiber 至 r566c:geosplit，并复读scope修订。结论全部PASS；§7.5的terminal指代小修已落实，当前稿明确原product union外费用不等于recoupled terminal，原修复项解除。

### 8.1 General fiber命题

允许G_i(C,v,g;y,z)是联合可测indicator，独立于内父B、停止标签T、旧σ；对每个实际C,v,g及μ_i-a.e. y∈Q_C(v)，要求

 ∫G_i(C,v,g;y,z)μ_i(dz)≤b(C,v)=ηα_C M_C(v)。

原capture cubes均在同一C_i，故双方真实来源都可用μ_i=μ|Ci，M_C(v)亦是其真实μ_i质量。G可依g，不影响先sum T/原B积分，因为g是此步骤的外层变量；随后逐g的同一fiber上界仍可积分ω。旧σ独立性使原长度3+2h的上界可直接使用，不能省去这一条件。

对固定C,v,g，真实pair积分≤bM=ηα_C M²；其余证明逐字承接§7.2–7.3。因此V_G≤a_ηQfr≤a_ηQg且VR=V_G+∫(1−G)dV，无需树或共同partition。每个参数fiber的a.e.条件结合联合可测性足以用Tonelli，不要求所有C,v,g共享同一个来源零集。该命题既非换action，也不引入新source coupling。

### 8.2 Cube源质量函数及所有边界情形

定义D_i(y,r)=μ_i{w:||w−y||∞≤r}，r≥0。因μ_i有限且绝对连续，D_i(y,0)=0；对任意(y_k,r_k)→(y,r)，cube indicators在限制cube边界之外收敛，该边界（r=0时为单点）μ_i-null，所以有界收敛给D_i联合连续。它对r非降并趋W_i。该结论不要求f连续或有统一密度帽。

在实际非零分支η>0、α_C>0、M>0，因此b>0。若0<b<W_i，{r:D_i(y,r)≤b}是非空、有界、闭的初始区间；最大半径r_b有限，连续性及最大性给D_i(y,r_b)=b。质量平台取最右端，边界质量仍为0，所以整个平台都纳入near不会增加fiber质量。作者的有理数测试{r_b>t}=∪_{q∈Q,q>t}{D_i(y,q)≤b}（t≥0）正确，给联合可测半径。

若b≥W_i，不声称半径有限，而取整个C_i（或r_b=∞），fiber质量W_i≤b。W_i=0没有active原父；S=0所有费用为0先单列。b=0不在作者active定理的量词内，所以没有除0/未定义半径；若仅把直接predicate延至b=0，其fiber也为μ_i-null，但本证明无需依赖这个延伸。

直接gate

 Gnear=1_Ci(z)1_{D_i(y,||z−y||∞)≤b}

在有限半径情形恰是最大平台半径cube∩Ci，质量b；在b≥W_i情形恰是全部Ci。其直接可测性亦由D_i联合连续和距离连续给出，无需选择定理。gate一般有序、未必对y/z对称；原ordered对象不要求对称，不能据此丢反方向。

### 8.3 准确全原对象near/far划分与一次吸收

原全部来源对均在C_i，所以Gnear补集精确为

 D_i(y,||z−y||∞)>ηα_C M_C(v)。

等号完整留在near，plateau及cube边界不造成遗漏。于是原VR准确分成Vnear+Vfar，Vnear≤d⁴/(8J²)Qg；Vfar保全部原Nδ^c、Li>τ、ordered/head/stop/phase/window及真实两M分母。这是原product上的真实source-mass-far余账，不识别成另一重配协议的terminal。

树thin与general/cube-near是同一定理的替代应用；不能各取a_η后免费并成一次a_η，更不能把两个单独fiber gates的union默认仍有fiber≤b。作者已明确选择near后替代树split，不另花第二份信用。

最终：tree thin主界、general fiber界、cube near可测构造及全原VR near/far正分割均PASS。其证明的吸收仍来自真实fiber质量及原score，不等于已获方体特有的维数收益。完整Vfar付款仍OPEN。所有实际工具证据沿§7.6，新增连续性、平台与可测性为上述解析证明。本轮到此冻结并停止，不继续审其他候选。

### 8.4 最终简化版本：finite-measure rank proof复核

作者按父建议将显式半径选择替换为r566c:rank；已读当前稿该完整段并核准PASS。对任意有限ν于[0,∞)，F(t)=ν[0,t]，A_b={F≤b}是初始区间；空集单列，否则取含最大点（若存在）的可数递增cofinal序列t_n，A_b=∪[0,t_n]，故ν(A_b)=limF(t_n)≤b。原子、distance ties、b=0、无穷端点均由该同一证明处理，不需要随机分裂tie。

以固定y下真实μ_i的距离pushforward应用该引理，直接给Gnear的fiber≤b。D_i(y,r)通过对Borel距离indicator积分而联合可测，近距gate本身保持原定义，所以§8.3的准确near/far划分、score归一和常数都不变。绝对连续输入下fiber恰等b只是备注；无需用它证明吸收。作者正确说明这个有限测度引理不自动将其他原L1/credit定理推广到atomic输入。

本最终版本更弱依赖、无需sup半径选择；§8.2是先前等价半径描述的独立核验，现不再是作者证明必需环节。当前稿全部相关主张PASS，无待修项，最终冻结。

## 9. REPORT最终整合定点复核

1. PASS：已读归档REPORT的N1–N7；直接fiber证明保留原Nδ补集、T先sum、两M、旧σ及双Λ，与已审coordinates无实质变化。
2. PASS：仅采用cube near一次a0Qg；树版本明确为替代，rank/tie/可测性和完整far正补集均未漏。
3. PASS：M2由M1取a=a0+a1、ζ=1/(2A)准确得到；严格条件a1<a0保留，M3正确计入price与terminal的Qg/W两种费用。
4. PASS：joint gate按C2重算真实边缘，paid RN保G；乘积terminal可能离开G，仅保旧边际账且不得再次领取near吸收，范围准确。
5. 无需修复；本次未重审连续流存在性或其他新稿，完整far付款仍OPEN。整合复核到此冻结并停止。


---

## screening

# R566：shared-cluster RN 价格与一般正流的 scope 独审

## 0. 独立判据与冻结对象

先仅按 `/tmp/ccu_r566_contract.md` 判断，再对照作者的准确构造。原 μ、Lebesgue 父中心、cube side R_B、实际 mass/phase/window/head/stop/core、原 L_i 和所有有序交叉冻结。本文不重跑 N7、不重复 R565 累计 RN 证明，也不把有限 surrogate 当原 Cstar。

目标不是扩大抽象可行集本身，而是对完整原 dV=K1_RdM/L_i 构造可计价的 paid 部分，且以原信用或一次源费支付准确 terminal。新动作不自动继承固定原 action law 的 K/Fcap 帽。

## 1. 一般正流新增什么，未新增什么

对每个正行 B，写 p0=P_B(Z)、q0=Q_B(X)、δ0=p0q0，原切后两个未归一边缘为

    ξ0=p0 Q_B|X，ν0=q0 P_B|Z。

它们同质量 δ0；原 product cut 为 ξ0⊗ν0/δ0=Q_B|X⊗P_B|Z。零 δ0 行无费用。一般正流允许把该 product coupling 改为任意具有同一两个边缘的正 coupling，或先只填一部分 Γ=Σ_HΓ_H，再显式保留残余。每个 cluster piece 必须满足

    dΓ_BH/d(Q_B⊗P_B)≤θ_H 1_R1_{E_H}(x)1_H(z)，
    E_H={y∈H，μH≤cM_C(v)}，
    Σ_H(x#Γ_BH)≤ξ0，Σ_H(z,σ)#Γ_BH≤ν0。

θ_H 是共享于全部父 B、实际接收 marks 和旧 σ 的 **原 product RN 帽**；可依赖完整输入，但不是每 B 自选后不计复用的价格。实际 H 也必须是共同 source clusters，不能换成每 B 的 Q_B(g) 后逐父重新给 W。

这里边缘容量逐原 B 保持；“共同源预算”是 RN 价格的质量积分，不是把所有 B 的旧边缘改成一个总供给 μ。跨 B 再加全局 atom-supply 约束可以定义一个更强的充分子类，但不是当前原对象的等价条件。反之，只约束逐 B margins 而不给共同 θ RN 帽，则没有控制 per-parent 复制价格。

新增的自由是真实的：H 可重叠；θ 只要求付总质量价 Σ_Hθ_HμH；每 B 可将一侧 marked mass 拆入多个 H，coupling 不必为 R565 的固定 rank-one maximum-match block；不同 B 可用不同的可行 flow，同时承受同一 θ 价格。可行 RN 价格不必满足 source-point packing≤1；平均质量价受控允许局部负载较高而别处较低。

没有改变的是两个原边缘、L_i、action law、marks、真实 eligibility 与同一个 score 信用。若 Γ_paid 的余边缘为 ξ_res、ν_res、同质量 t，则 terminal ξ_res⊗ν_res/t（t>0，零时取0）恢复原边缘。因此每 B 准确有

    paid inverse fee + terminal inverse fee
      =K r_Bt_Bq_B ∫ L_i^{-1}dν0，

其中 ν0 已含 Z，且每个接收 mark 仍含 X。这只是 old-marginal 恒等式：总原费用没有因换 coupling 自动下降。变化的是哪一部分能由同一共享 cluster 价格付款。

## 2. 与 N7 static partition / fractional packing 的准确比较

不能直接把旧 front/cluster 的选择系数 λ_H 当作新 θ_H。旧匹配 block 含 1/max(a,b) 的 coupling 归一，precut 的 p0q0 也必须保留。只有转换成对原 Q_B⊗P_B 的共同 RN 帽后，才是同单位比较。

因此：

* 每个已具共享 RN 帽的 static partition 或 fractional-front 方案，连同其准确价格和 terminal，都是新一般正流模型的一类可行构造；新模型不会因放宽 product/block 结构而丢失这些方案。
* N7 已认证 fractional interval packing 等于其 common-partition DP，只约束那一有限 static 问题。它没有覆盖带独立 marked flows、共享 RN 价格和边缘容量的新可行域。
* 一般正 coupling 相对固定 rank-one block 的表示自由更大；平均 source-mass 价格约束也弱于同单位的逐 source-point packing。两者均不等于已证明 **同价格下最优完整费用严格改善**。新自由可能只换一种表示，也可能为更多 paid mass 付出更高 θ 价。
* 特别是把所有 per-parent 最佳 partitions 合并成一个 family，θ 必须承担全部行的共同 RN 需求；不能以“只有一个总 LP”之名免掉此前 332W 一类的复制价格。

故本审可认证“模型更丰富、N7 static 等价结果不封死它”，不能在没有新 primal/dual 或连续估计前认证“严格改善 N7 最优值”。有限 N9 若完成，只证明它所保留 marked-table 模型的这一区别，不恢复 full L_i/Ndelta/headstop。

## 3. 新 payer 成立所需的全局一步

已审 single-H 定理对原 positive measure 给费用≤cL_cl μH。Tonelli 与共同 RN 帽只推出

    V_paid≤cL_cl Σ_Hθ_HμH。

这是合法 payer 的调用接口，不是免费给出的价格上界。必须同时实际构造：共同 measurable H/θ、全部 B 的正 flow、准确原 margins、以及不可删除的 terminal，证明

    cL_cl Σ_Hθ_HμH + V_terminal≤aQ_g+LW

（或分别给可合并的同强不等式），其中 a<d⁴/(4J²)，并保留原母式系数。仅控制 unmatched probability、残余总质量、某一 mass slice、某一坐标接触率或 Σθ 在单 source 格的值，都不足以控制原 inverse-L_i weighted terminal。

真正 cube-specific 的新几何必须穿过这一步：实际全坐标 capture/contact 限制使共享 RN 价格总量或原 weighted terminal/credit 明确改善，并在 old+new mass、旧 σ、全部 parent/receiver marks 积分后留下量化系数。一般流的 LP 可行性、边缘守恒、RN 分解或 generic cluster lemma 本身对一般形状也成立，不提供 cube 对一般对称凸体的多项式区分。

共同连续选择、所有零分母约定及正极限还须有可测性/一致价格和 terminal 控制。不能从“每个有限子问题可行”直接推无限同预算可行而不证 tightness/limit，或以求解器 status 替代该步骤。

## 4. 作者对照

### 4.1 nonradial：完整 small-mass union 是真可吸收分支，非 cube 区分

已定点读 `/tmp/ccu_r566_coordinates.tex` 的 exact、masscancel、main。这里不是对每个 C,v 的 front 重复调用 single-family payer，而是在同一原正积分中，按阈值 h_H≤ηα_C M 选共同 laminar tree 的 maximal qualifying antichain。它只作 analysis gate，未改 action、L_i 或任何 marks。

同一 C,v 下准确双 source 质量为 Σ_H h_H μ(H∩Q_C(v))≤ηα_C M²。原 F^R/L_i≤1 与旧 σ 全支持长度 3+2h 消去两个真实 M 分母，仍保两个 ω action 积分各 Λ、原 t_Cq_C α_C 信用，给

    V_thin≤a_η Q_fr≤a_η Q_g，
    a_η=γKΛ²(3+2h)η/C0。

η=C0d⁴/[8γKΛ²(3+2h)J²] 时 a_η=d⁴/(8J²)，严格低于合同阈值。这是对完整原 VR 的真实正分支付款，不是 RN/marginal 身份的改名，也没有每深度 W。其余 V_rest=∫1_Uthin^c dV 全保，尤其大节点与已分离终端没有被“refine”清空。最终估计只用质量/原 antichain 支配，故没有 cube 特有多项式系数；坐标限制留在准确积分内，尚未提供补集的几何 payer。本节只核这一 scope/系数接口；父指定独审负责完整本体推导。

### 4.2 generator：真 overlapping shared-price 子费，未支付 branching heavy union

已定点读 `/tmp/ccu_r566_potential.tex` G2—G9。固定共同中心、实际 mass-halving nested cubes 与 Ci 之交确可由连续 mass curve 选择；root 无需有限半径。h_ij=W_i2^{-j}，annuli H_ij\H_i,j+1 互斥，价格 θ_ij=ϑ 给 Σθh=2ϑΣWi≤2ϑW，真实 annulus 质量各为 h/2。因此这是一份实际共享 source bank，不是对每深度重新发 W。

G4 对同一原 tuple 按 j 顺序只填至总 product density1；各段 b_ij≤ϑ1_Eij，Σb=min(1,ϑN_c)。所有 marginals≤原 precut margins，RN 以原 QP 为基准，无额外 δ0 归一。原 positive terminal 精确为 (1−ϑN_c)_+ dV。由 individual-H payer：ϑ=1/2 支付 N≥2 并半付 N=1，总价 W；ϑ=1 支付这一个 chain 的整个 eligible union，总价2W。两者是同构造不同常数，不可算成两份独立收益。

这一子费确实利用新平均 mass-price 模型，而非静态 front pointwise packing；但已证明的支付对 nested homothetic capture families 同样成立，非 cube 多项式优势。唯一固定中心 chain 会漏掉实际交互 cube 内接近、但共同 chain cell 太大的一对 sources；其原 inverse-L_i terminal 全保。branching dictionary 仍没有 annular source reserve，因为所有 children 的总 mass 恰等于父 mass。限制到先前 thin branch 的补集可避免重复付款，原信用不得另发。

### 4.3 cover：全坐标 quantile dictionary 确有 positive coverage，价格归一留下真实 terminal

已定点读 `/tmp/ccu_r566_prices.tex` S2—S16。真实边缘 quantile outer rounding 的 mass 误差≤2nWi/L 来自实际 marginal-band union bound，不假坐标独立。应对任意实际 cube A 定义 bracket 后 intersect Ci，表述为 A∩Ci⊂H、μ(H\A)≤2nWi/L；仅先限定 A⊂Ci 需要额外冻结接口。已向作者发此定义性修复，不改变后续证明。真实两 sources 在 A∩Ci 即足够。

按 M 的 dyadic bins 选择 L≥2nWi/m，使 bracket mass<γM+m≤(γ+1)M，故每一真实 tuple 都有共同 eligible tag。quantile label 保同一个 side R；2n(L−1) 个 (B,R) affine hyperplanes 在 n+1 维的 arrangement bound 合法，严格 outward 的 boundary label 可微增 R 获得，不能各坐标独立选不同 side。它确有完整 cube 坐标内容，但仅为字典复杂度估计。

S8 的 θ_id=min(1,b_dWi/Σ_HμH)、Σb_d=1 给 Π≤W，tag flow 恰为 θ_id1_R1_assignment QP。它是原 physical product 的 positive subflow，两边缘和 exact product residual 均保留；没有 1/δ0、逐 parent W、改 action 或改 L_i。每一真实 pair 具有正容量，确实移除了该 dictionary 下的零共同 cluster 阻碍。

**未付全局步骤准确是 S15**：Σ_id(1−θ_id)∫_{该真实 mass bin}dV。复杂度帽只允许 θ 极小，没有给原 weighted demand 的收缩、价格同需求的相关控制，或原 score 吸收。因此 Σθμ≤W 与 positive coverage 不是 full fee bound。删 dictionary clusters 时须把原 assigned tuples 保终端，或构造替代合法 flow。保全坐标 arrangement 后，也没有完成 old+new mass integration 的 cube 特有系数改进；其来源费 cL_cl 和完整母式均仍在账中。

## 5. 连续 fixed-price flow 升级：先验命题与验收条件

父追加独审 fixed countable H/shared θ 的连续可行性升级。独立结论是：固定共同价格总额 Bθ=Σθ_HμH<∞ 确可给有限 capacity 测度，从而以 Hilbert 投影强极限取代未证的 tightness；但必须保留逐 B 条件约束。

令 λ=t_Bq_Br_B dB Q_B⊗P_B，c=1_RΣθ_H1_EH1_H。因原 m_B≥m_min=q a^n>0，P_B(H)≤μH/m_min 且 ∫tqr dB≤KS A_nW，Tonelli 给

    κ(total)=∫c dλ≤(Bθ/m_min) λ(total)<∞。

忽略零行；c=0 上无可用 flow，令 density u=0，非零支以 Γ=uκ、0≤u≤1 表示。一般 old quota ℓ_B≤ν0_B 只要求 old margin=ℓ_B、receiver margin≤ξ0_B。Hall 条件必须对 a.e. 原 B、全部 measurable marked A⊂X 与 D⊂old 有

    ℓ_B(D)≤ξ0_B(X\A)+∫_(A×D)c_B d(Q_B⊗P_B)。

不能仅核 cluster unions，也不能只核跨 B 汇总的 cuts。若 ℓ=ν0，因两端总质量同为 δ0，receiver≤ξ0 自动升级为 receiver=ξ0，才得到完整原两个 margins；一般 quota 的 terminal 必须保留 ν0−ℓ 及剩余 receiver。

取 full receiver/old 标记空间的 fixed nested finite generating partitions。每 B 的有限 capacitated flow 用唯一 min Σf_ab²/cap_ab 定义，cap=0 强制 f=0。须证明这些参数化 QP 的 canonical 系数可测（例如有限 active-set/KKT 分支加零容量分支），不能只说逐 B 存在便取一个选择。

将 finite flow lift 成各原 product cell 的 capacity-density 常数 u_n=f_ab/cap_ab 后，要证明它确为同一 L²(κ) 中 nested closed convex constraints C_n 的0投影：old coarse quota 等式与 receiver coarse上界均须对所有 bounded ψ(B)测试。只比较每个 B 的 finite表且未说明这一步，不能自动使用 global 投影范数差。

若上述接口成立，C_m⊂C_n（m≥n），投影变分式给

    ||u_m−u_n||²≤||u_m||²−||u_n||²。

范数递增且≤κ(total)，故强 Cauchy；极限0≤u≤1，并满足所有生成代数上的 conditional B constraints。以可数代数统一 conull B 后单调类扩展，恢复全 marked margins。此时无需另借概率 tightness。因为 Z={L_i>τ}，旧费用 integrand≤K/τ；L²κ 强收敛也使原 inverse-L_i 费用收敛，而不是仅控制弱概率质量。

这里不声称未截断的 L_i score 随 finite coarse flow 强收敛；L_i 可无界。最终 flow 的 score 上界应由其已恢复的准确 old margin 直接推出，仍只用一份 Q_g。

若作者扩展到真实 joint subgate G_B≤1_R 而不再有乘积结构，需用其真实两个 margins ξ_G、ν_G 与 c=G_BΣθ_H1_EH1_H；上述固定容量投影论证仍适用。一般 residual product completion 只保 margins，未必留在 joint gate G 上，所以只能当明确标记的 unpaid terminal；要保 physical joint G support，还需 residual Hall 或直接保留合法 joint residual。原 R=XZ 的 product-gate 情形无此额外障碍。

这是固定 θ 的连续实现定理。它不构造受控几何价格、也不证明 Hall；变动 θ_n 仅有 Σθ_nμH 有界时，不得不经 label/price tightness 或适当共同容量支配就挪用这条 fixed-κ 强极限定理。

### 5.1 作者对照验收：fixed-price 连续升级 PASS

已定点读 `/tmp/ccu_r566_recovery.tex` (4)—(13)，与上述先验判据逐项一致。本次认证限定固定输入、有限 primitive scale lower bound、固定 countable common H/θ、Bθ有限，及作者(5)的逐 B 全 marked Hall（或嵌套 full-marked generating partition 的全部 union cuts）。

finite weighted QP 的 zero-capacity pattern、active faces 与 Borel weighted affine projection 给足可测 canonical 选择；cellwise Cauchy 确认 lifted u_N 是 global L²(cλ) 同一条件 B 约束集的最小范数解。作者保留所有 bounded ψ(B) 测试，未把逐父条件放松成跨父汇总。因此 (7) 的差范数界、(8) 强 L¹ 及最终条件边缘识别成立；不需要另一个未证的 transport selection、弱连续 geometry 或 tightness 假设。有限步不被冒称 full legal coupling，这一点必要且稿中已写明。

(6) 的 component split u c_H 自动继承同一 θ_H RN 帽；原 physical payer (9) 只付 c_m L_cl Bθ。存在性辅助界中的 m_min^{-1} 不被误乘到 source invoice，这是正确的。终端(10)—(11)保留原 old margin，product R 时仍在 R 内，joint G 时只作为明确未付的 analysis terminal，禁止再套 G-specific 几何帽。

作者(12)选择真实 old remainder density

    h_B=min(d_B,a_abs L_i²/K²)P_B，ν_B=d_BP_B，

所以准确 terminal invoice≤(a_abs/K)∫r_Be_B dB≤a_abs Q_fr。若完整 Hall 对 quota ν_B−h_B 成立，确得条件完整式

    V_G≤a_abs Q_g+c_m L_cl Bθ。

它与 thin branch 合并时，两个 absorption 系数必须加在同一个 a 里，再检 a<d⁴/(4J²)；没有第二份 Q_g。一般 joint G 的原边缘正确替代 p0/q0 乘积式。作者没有以 finite-stage 强收敛误证无界 score 收敛，而是从最终 margins 读取原信用。

这是实质连续实现升级，不能归类为旧 RN/marginal 恒等式：它填上 fixed-price full-marked Hall 条件到可测连续 flow、正确完整费用极限之间的存在性/可测性缺口。其未付几何步骤仍精确为：在所需共同价格规模下为实际 cube object 验证全部 conditional Hall cuts，或找到同强原信用付款。没有任何已知局部 capture 公式自动给这些 cuts。

作者另列 changing-price tail closure (15)；本次父指定独审不认证该扩展，不借其来扩大 fixed-price PASS。未经 uniform label-tail/共同支配或额外 admissible-cluster closure，bounded variable price sequences 仍不能直接套 fixed-κ 定理。

## 6. 最终范围结论

* **真新增自由/实现：** 重叠共同 RN prices + 任意 per-B capacitated positive flow 是较丰富的统一模型；新 chain 子费与 full-coordinate quantile 字典均已给实际合法 subflow；fixed-price Hall 的 measurable continuum sufficiency 已独审通过。
* **真原信用正分支：** Uthin 的完整 mass-integrated 系数可小于母式 absorption 阈值，未逐深度/逐 front 发行 W。
* **没有认证的结论：** 未证同价优于 N7 optimum、未把 finite table 恢复为原 Cstar、未得完整 shared-price/Hall 构造、未付 heavy/weighted terminal、未完成 cube 相对一般对称凸体的多项式费用区分或最终 root 结论。

当前最关键 global step 不是再做 RN 望远镜或另一次 static packing，而是同一原 joint posterior 下的 **共同价格规模 + 所需 quota 的全部 conditional Hall feasibility**，或直接等强控制其完整 inverse-L_i weighted deficit。所有构造的 action law、原 L_i、margins 和未付补集均须沿用本合同。有限任务至此完成，停止扩展。

## 7. 工具与状态

已运行指定本机 Python 3.12.14 / SymPy 1.14.0，精确核验 precut 的 p0q0/(p0q0) 归一及给定原边缘恒等式后的 weighted paid+terminal 代数分解，残差为0。它们只是归一辅助，不是共享价格构造或 cube 预算证据。未优化 N7、未数值外推，本文仅编辑本文件，不改他人/仓库，不 spawn/PDF。

PASS/范围与准确未付项已发 parent 及相关作者。本稿冻结；后续只有 parent 明确派定的有限补审才恢复工作。

## 8. 最终 REPORT 整合定点审核

按 parent 追加指令，仅核 `/tmp/ccu_r566_archive/REPORT.tex` 的 C1—C14 与有限结果定位，不重算或重开历史。容量 measure 改 mathsf{Cap}、父 measure 改 mathfrak b 未改变已审证明。逐 B Hall、zero rows/zero capacity、quota 对应 partial margins、quota=ν 才 full margins、joint G residual product 仅作未付 terminal、bounded inverse-L_i 极限及一次原 Q_g 的母账限制均保留；changing-price 扩展已删除，未扩大主审 PASS。

**发现一处须恢复的明确假设：** 初次整合版本删去了 recovery 引言中 Bθ:=Σ_Hθ_HμH<∞ 的定义及有限性条件。REPORT 虽先定义 Π=ΣθμH，却在 C4 直接使用未定义 Bθ，且定理“fixed hypotheses”没有显式有限价格假设。已立即发 parent：在 C3 前补固定 countable family/common prices 与 Bθ=Π<∞。这是有限 Cap 与强 L² proof 的必要条件，不能仅凭“固定价格”代替。另将本节残留 (3)—(13) 的文本引用改为 (C3)—(C13) 可避免歧义；此属编辑修复。

有限结论定位通过：F2 的 575/128 是 restricted shared cover 的准确 primal/dual 最优值；报告明确不是完整 F1 flow 的最优下界。对应 fine marked flow 是合法有证上界，并保11项正终端、low-old-field 补集和 serialized-table 误差范围。未把有限模型的 witness 当作原 Cstar，也明确本轮有限模型尚未施行原 near/far joint-gate 切分，不能直接搬到真实 far 支。

完整定点审核结论为：除上述有限价格假设恢复外，已审数学条件与结果范围保真。parent 恢复后可沿原 fixed-price PASS；无需任何新计算或研究。

**最终复核 PASS：** 已按 parent 指令只读恢复处，REPORT C3 前现明确 `Assume throughout B_theta:=sum_H theta_H mu(H)=Pi<infty`。必要固定有限价格假设已恢复，原固定价格连续主定理及上述终端/母账/有限结论定位保持通过。括号引用修正由 parent 完成；不再重审或扩展。本次定点整合任务结束，停止。


---

## feature_audit

# R566 role10：N9 shared-cluster-priced flow 的完整标记与压缩审计

日期：2026-10-23。只写本文件，不改其他角色/仓库、不生子 agent、不编译 PDF、不重复 Gram、DP 或优化。先审命题并给可执行 primitive，再待 N9 规模/父批准及实现。N10 独立审序列化 LP 的有限算术，不替代理想连续对象。

## 1. 继承的 surrogate 与原对象缺口

N9 只能继承 R565 已运行前获批的 finite χ-lift：同 64 个来源、332 个固定 evaluation bulk 父、原父权、全部 q-band 同物理场、共享原动作律、真实 phase/window overlap。`Lfin=Σ_Bω_Bk_B`，完整 receiver row tensor `T[B,y,partnercount]`，`Q_B=T/rowE_B`，`r_B=rowE_B/(ω_Bq0_B)`，`Kfin=1` 只是单位倍率，不是 `r≤1`。

原全 Lebesgue/history `L_i`、原 `N_delta`、非对称 Cstar head/stop/core 不可从这些有限档恢复。本轮不将其突然恢复；surrogate 只取 `X=1`，旧 high cut `Z=1_{Lfin>1/18}`。原真正 R 的额外 receiver 筛选不能静默删除或用容易边缘替代。

每父的原 surrogate 概率是

\[
P_B(dz,d\sigma)=\frac{k_B(z,\sigma)\mu(dz)d\sigma}{q0_B},
\qquad Q_B(dx)=\frac{\mathcal R_B(dx)}{R_B}.
\]

`Q_B` 的完整 x 含实际两动作、partner 父/outer mass、真 receiver y 与 phase/window 交集积分。之前 T 的压缩只因本轮 predicate 依赖 y 和 partner mass 而允许，不能任意删除新 predicate 所需标记。

## 2. 独立完整零-terminal 正流命题

一般先写 pre-cut

\[
\xi_B=p0_BQ_B|X,\quad \nu_B=q0_B^{cut}P_B|Z,
\quad p0_B=P_BZ,\quad q0_B^{cut}=Q_BX,
\]

总质量 `δ0_B=p0_B q0_B^cut`。其原 cut product 是 `Q_B|X ⊗ P_B|Z`（等于 `ξ⊗ν/δ0`），不是再归一到质量 1。本 surrogate `X=1`，故 `q0^cut=1`。此处 `q0^cut` 与父原密度 `q0_B` 是不同量，不得混淆。

共同来源簇 H、共同非负价格 `θ_H`，eligibility

\[
E_H=\{x:y(x)\in H,\ \mu H\le c M_{partner}(x)\}.
\]

每父每簇付费 coupling 必须满足

\[
0\le d\Gamma_{B,H}\le\theta_H
1_X(x)1_Z(z,\sigma)1_{E_H}(x)1_H(z)
Q_B(dx)P_B(dz,d\sigma). \tag{F1}
\]

**zero-terminal full clearing** 还要求两边完整边缘分别为

\[
\sum_H(\Gamma_{B,H})_x=\xi_B,
\qquad\sum_H(\Gamma_{B,H})_{z,\sigma}=\nu_B. \tag{F2}
\]

尤其 receiver 的 capacity 是 `p0_B Q_B`，不是无 high-cut 系数的 `Q_B`。把它写错会允许偷用未在原 cut 内的 receiver 边缘。价格只计一次 `Σ_Hθ_H μH`，θ 共享全部父，不能改成每父单独 θ 后免费求和。

该模型不是要求 `Σ_HΓ` 等于原 product joint：它允许同边缘的正 relift，正是这次新自由度。保持旧边缘保证全部逆 `Lfin` 账单不变；它只是试图用共享 RN 价格给固定账单一个可支付表示，不是通过新 coupling 减掉原正费用。

## 3. Full clearing 时旧 sigma 可无损压缩

令旧 atom high mass

\[
p_{Bz}=\int P_B(\{z\},d\sigma)1_Z,\quad p0_B=\sum_zp_{Bz}.
\]

receiver 可按原子 u 聚合：同一 u 必须具有相同实际 y 和**全部候选 H 的 eligibility profile**；保留 `(y,partnercount)` 足够。记 `q_Bu=Q_B(u)`。由于 surrogate X=1，不需额外 X profile；若以后加入 X，必须保它或重新聚合。

有限变量 `f_BHuz≥0` 仅在 y_u,z∈H 且 mass eligibility 成立的边出现，约束为

\[
f_{BHuz}\le\theta_Hq_{Bu}p_{Bz},\qquad
\sum_{H,z}f_{BHuz}=p0_Bq_{Bu},\qquad
\sum_{H,u}f_{BHuz}=p_{Bz}. \tag{F3}
\]

零 q/p 的边直接为零，不除零。一般有 X 时相应使用 `Q|X` 聚合和 `q0^cut p_z` 的旧边缘。

任何 (F1)–(F2) 积分到这些有限块都给 (F3)。反向对正块定义

\[
d\Gamma_{BH}(x,z,d\sigma)
=f_{BHuz}\frac{Q_B(dx)|_u}{q_{Bu}}
\frac{P_B(\{z\},d\sigma)1_Z}{p_{Bz}}. \tag{F4}
\]

它恢复全部 receiver 动作/phase/window marks 的原条件分布、恢复旧 atom 内全部真实 old-σ 的原 high 条件分布；由 (F3) 的两组等式可逐完整 mark 验证 (F2)，且由 cap 得逐点 RN≤θ_H。只要 eligibility 在 receiver fiber 上常值，(F4) 不丢标记。

因此针对 **full-clear 可行性及最小共同 source price**，旧 σ 压成 `p_z`、receiver 压成上述 profile 是严格等价的，不是 shared-atom relaxation。旧 σ 的不均匀 `1/Lfin` 并未丢掉：full clearing 恢复其整个旧边缘，故加权 terminal 严格为零。

## 4. D 与 weighted terminal 的保留方向

定义 R565 已审

\[
D_{Bz}=\int\frac{k_B(z,\sigma)}{Lfin(z,\sigma)}1_Z\,\mu(\{z\})d\sigma,
\quad\int\frac{P_B(\{z\},d\sigma)1_Z}{Lfin}=D_{Bz}/q0_B.
\]

surrogate 的完整高字段加权账单是

\[
V_{hi}=\sum_B rowE_B\sum_zD_{Bz}/q0_B.
\]

Full clearing 的所有 pieces 加权成本之和仍为此值，terminal=0；不能因为 LP objective 只写 price 就声称这些成本消失。旧 low-Li 互补仍是原有限诊断之外明确保留的一项。

若改为 **partial clearing**、边际只 `≤`，则按 (F4) 回填 old σ 会给每 atom 一个 proportional-σ 子类，其平均逆权

\[
\bar\lambda_{Bz}=\frac{D_{Bz}/q0_B}{p_{Bz}}
\]

可用于该子类的精确 weighted terminal。但完整细 σ 流可选择付掉不同 `1/Lfin` 水平的旧片段；用平均值替换后不能再宣称是全自由 marked flow 的最优 weighted terminal。若要优化一般 partial terminal，必须保留旧 `(z,σ段)`，或明确把 proportional-σ 当**可行限制**，不可当无损 relaxation。此点已先发给 numeric/role8/N10。

## 5. 预执行协调 verdict

role8 独立提出的 zero-terminal full-clearing LP 与 (F1)–(F4) 一致，已核准其 receiver `p0q`/old `p`、cap `θqp` 和 source price 方向。numeric 在设计阶段明确未运行，等待具体规模与主代理批准；N10 将按同一 normalization 审 finite primal/dual 及 roundoff，不复制 Gram。

给 numeric 的可执行 primitive 已明确：复用 N7 的完整 T/旧 Li，不重建 χ-Gram；需要 `p_Bz`（真实 high-σ mass，不是 D）、`q_Bu`、candidate H 的精确 y/z membership 与 mass eligibility、同一共同 θ。不能把 `D_Bz` 当概率边缘，不能把 `p0Q` 写成 Q，不能用无 partner eligibility 的 source-count transport。

**当前有界 verdict：该 zero-terminal finite flow 命题通过；full-clear 的旧 σ 与 receiver profile 压缩合法。具体规模、可执行模型及父批准尚待确认，未默许任何 mark 省略，也没有授予 giant LP 或实验运行。原连续 R 不可恢复的 scope 继续显著保留。**

## 6. 后续独立核准：完整 fine-old-σ partial LP

numeric/role8 在统计真实稀疏支持后提出保留旧 σ 细段，而非上节平均压缩。主代理已明确批准 c=2、adaptive/旧 optimum 两 law、terminal 目标 `0.1V,0.01V,0` 共 6 次单进程稀疏 LP；本角色即时独立核准以下新 primitive 并已通知 numeric。此前 full-clear 压缩的批准不被拿来替代 partial 新证明。

### 6.1 真实旧 mark 与 receiver mark

旧 mark `s=(z,σ段 k)` 使用 N7 的共同旧窗划分，`Lfin(z,σ)=L_zk` 在该段常数，且本 high cut `L_zk>τ`。质量是

\[
p_{Bs}=\frac{a_B}{64q0_B}\Delta\sigma_k\,
1_{z\in O_B}1_{k\subset[s_B,s_B+1]}1_{L_{zk}>\tau},
\quad p0_B=\sum_sp_{Bs}.
\tag{F5}
\]

它是 high 旧概率片段，**不是 `D_Bz`**。receiver `u=(y,partnercount)` 的 `q_Bu` 来自同一完整 T row 归一。双方动作/真实 phase/window 已在 T 权中精确边缘化，且所有待用 eligibility predicate 只依 y/partnercount，所以按 Q 的条件 law 回填 full receiver mark 合法。旧 σ 段内 `P_B` 密度与 `1/Lfin` 都常数，故段内积分和条件回填对 partial weighted objective 也无损；这与 §4 的单 source 平均 `D/p` 限制不同。

### 6.2 shared type capacity 是完全等价合并

同一 source cell 下，type `t=(y,z,partnercount)` 对全部共同 H 的 eligible 集只依这三个标记，不依父 B 或旧 σ 段。定义

\[
A_t=\sum_{H:\ y,z\in H,\ \mu H\le cM_{partner}}\theta_H.
\]

聚合付费流变量 `f_Bus≥0` 满足

\[
f_{Bus}\le q_{Bu}p_{Bs} A_{t(u,z(s))},\qquad
\sum_sf_{Bus}\le p0_Bq_{Bu},\qquad
\sum_uf_{Bus}\le p_{Bs}. \tag{F6}
\]

辅助 A 必须等于或不超过上述 θ 和，不能用反向下界让 A 任意增大。每簇原流相加显然给 (F6)。反向对 `A_t>0` 令

\[
f_{BHus}=f_{Bus}\frac{\theta_H1_{H\ eligible\ for\ t}}{A_t}.
\]

其和恢复 f，且 `f_BHus≤θ_Hq_Bup_Bs`。再回填该 receiver fiber 和旧 σ 段的原条件分布，就有 (F1)，所有原标记与两边际保持。`A_t=0` 时 cap 强迫 f=0。这一 type 合并允许 overlapping H，不复制每父源价，是 marked model 的无损消元，不是 source-count transport。

### 6.3 weighted terminal 与完整正残余

receiver 与旧剩余边缘分别是

\[
\xi^{term}_{Bu}=p0_Bq_{Bu}-\sum_sf_{Bus},\quad
\nu^{term}_{Bs}=p_{Bs}-\sum_uf_{Bus}.
\]

二者非负，总质量相同 `p0_B−Σ_us f_Bus`。正质量时可取它们的 product 除共同总质量为 terminal coupling；零时取零。无论怎样正补全，逆场权仅依旧 mark，完整 terminal 恰为

\[
V_{term}=\sum_{B,s}\frac{rowE_B}{L_{z(s),k(s)}}
\left(p_{Bs}-\sum_uf_{Bus}\right). \tag{F7}
\]

初始值

\[
V_0=\sum_{B,s}\frac{rowE_Bp_{Bs}}{L_s}
=\sum_B\frac{rowE_B}{q0_B}\sum_zD_{Bz}^{hi}
\]

与 N7 high bill 一致。原 `ω_B q0_B r_B=rowE_B`，所以 (F7) **不再另乘或少乘** ω、q0；本式 Kfin=1，只是已批准的单位尺度。旧 low-Li 仍在外显式保留。原 N_delta 与原非对称 Cstar 标记仍不可恢复，不因这里保 fine σ 就变回原 R。

约束 `Vterm≤v` 配合目标 `minΣθ_HμH` 是固定完整 surrogate 的合法 price/terminal frontier。若 v=0 理想精确可行，则恢复 full clearing（所有 `p_s−used_s≥0,L_s>0`）；浮点近零不能自动称为数学 zero。N10 已提醒保存 q 的原始权并一致归一，避免把多个独立舍入 RHS 当 exact dyadic 后总量不平衡。若需缩流修复，必须报告实际正 residual 与 (F7)，不能把 residual 删掉。

## 7. 轻量实际核验与待实现范围

指定 Python 3.12.14 / SymPy 1.14.0 实际运行一个两 receiver、两旧 σ mark 的有理代数模型：`q=(1/4,3/4)`，`p=(1/6,1/3)`，`p0=1/2`，

\[
f=\begin{pmatrix}1/24&1/24\\1/24&1/6\end{pmatrix},\quad
L=(1/2,2),\quad rowE=3.
\]

返回 receiver residual `(1/24,1/6)`、old residual `(1/12,1/8)`，两残余总量差严格 `0`；初始 bill `3/2`、paid `13/16`、terminal `11/16`，恒等式残差严格 `0`。RN 比为 `(1,1/2,1/3,2/3)`；按两共同价格 `(1/3,2/3)` 分流再相加的矩阵残差为零。这仅核正剩余/权因子/type 分流代数，不是 N9 LP 计算或一般付款证明。

**fine-old-σ partial 模型预执行 verdict：F5–F7 与原 approved χ-lift 权/mark完全一致，保真 partial 加权目标，不用 source 平均 D/p；shared type 容量与 θ 分回可无损恢复完整有限 marks。已通知主代理/numeric/N10核准。具体 N9 实现待落盘再作只读审计，不重复其 LP，原连续 R scope 不变。**

## 8. N9 实现与首个模型的只读审计

已读 `/tmp/ccu_r566_n9.py`、`.json` 及 adaptive 序列化模型。审计时模型 SHA256 为

`38f9c2af2b314f97edd2b8137063a14d69c1ba5bab2ec38d808862879d276821`，

与实际文件相符。代码 hash 为

`929a178e3f21fc4ca6dceb1311a2be9be826234445aa39fdfead1679426b050e`。

numeric 已确认后续改动只增 solver method/time-limit/retry 接口，不改该 model primitive。本节审模型对象与范围，不认证某个后续 solver candidate。

### 8.1 old/receiver marks 与 LP 符号

实现保留每个 `Lfin>τ` 的真实旧 source/σ 常值段，`p_mark=Δσ/c0_B`。由于原有限旧体质量为 `c0_B/64`，该 count 归一恰是 (F5) 的 canonical old probability；没有用 inverse-D 或源平均权替换 old mass。实现的 `L_mark` 为该真实 source/σ 段的 L 值。receiver 非零 raw marks 从原 T 逐个保留 `(B,y,partnercount)`，再按 parent rowE 归一。

在变量 `[θ_H,A_type,f_edge]` 上，序列化矩阵为：

- 等式 `−incidence·θ + A=0`；
- flow cap `f_edge−q_up_s A_type≤0`；
- receiver row `Σ_s f≤p0_Bq_u`；
- old column `Σ_u f≤p_s`；
- terminal 行 `−Σ_e(rowE_B/L_s)f_e≤v−V0`；
- 非负变量及 objective `Σ_H(|H|/64)θ_H`。

这些符号与 (F5)–(F7) 全部一致，没有反向放大 A、没有把 receiver cap 改为 q、没有用 unweighted 残余质量替代 inverse-L weighted terminal。`V0` 是同一 fine p/L 的和。

type 的 eligibility 以 source 排序的真实 rank-span 和 partner count 判定。若最小包含 y,z 的 interval 长度 `|rank(y)−rank(z)|+1>2*partnercount`，没有任何本轮 c=2 eligible interval，省该 flow 边合法；反之 incidence 保留所有同时含 y,z 且 `|H|≤2*partnercount` 的 H。删边基于原 2080 interval 家族的精确 membership/质量条件，不是简化 source/phase 约束。

### 8.2 实际只读核查

adaptive 模型含 6711 receiver marks、5005 fine old marks、173553 flow variables、4247 types、2080 clusters；共 179880 variables、1,227,046 sparse 非零。没有 dense LP 或另一次 Gram 重建。本角色只读取模型/N7：

- `Qraw[B,y,count]` 与原 N7 T 对应项逐项差 **0**。
- 将 fine old `p_mark/L_mark` 按 `(B,z)` 相加，与 N7 `D_high[B,z]/q0_B` 的最大差 `8.88e−16`；完整 fine `V0=1.1794383321117998` 与 N7 high bill 相同。这里旧 q0 的存储舍入和 count 归一的理想等式不应在 exact certificate 中被混成彼此独立的 dyadic 恒等式。
- `p0` 与 fine `p_mark` 的存储求和相符；serialized receiver RHS 与 `p0*q` 逐项差 **0**，old RHS 与 `p_mark` 逐项差 **0**。
- q 的浮点归一和最大误差 `6.66e−16`。因此 `target=0` 的数学全清零不能只靠 solver tolerance 或把各 RHS 独立 dyadic 化：须 N10 的一致归一/正 flow 修复或显式保实际 weighted residual。此风险已直接发送 numeric/N10。

上述核查只读 sparse model/既有 T/D，不运行 build、solver、Gram 或 DP；所用本机 Python 3.12.14、NumPy 2.5.4。optimum law 的一般代码采用相同构造，但在本节交付时没有另行序列化数据核查该 law；不能把 adaptive 的实际数据核查写成两 law 的全部 primal/dual 认证。

### 8.3 求解状态不属于几何结论

首个 adaptive `v=0.1V0` 的 120 秒 IPM 尝试超时，无 primal；numeric 报主代理后暂停自动扩展，再由父协调同模型算法选择。本角色不把 timeout 解释为模型不可行、价格无界或几何构造失败；没有重复 solver。父批准的后续运行与 N10 的 candidate 算术证书另行记录，均不改变这里 full marked model 的审计范围。

**最终有界 verdict：已审 N9 fine-old-σ partial shared-price flow 的命题、type 无损消元、实施符号和 adaptive 首模型 primitive；完整 weighted terminal 与原有限 χ-lift 一致，未平均旧 σ 或省 receiver mass marks。原连续 R 仍不可恢复，N9 只是明确的 finite surrogate，未给出一般 joint-budget 付款。后续 primal/dual 数值证书不在此预模型审计内；角色10完成并停止。**


---

## ledger

# R566 共同sourceprice、完整R与实际母账

本账只审R566新增sharedprice／flow的完整净费用，不把R565已审RN或递归代数重列为成果。原adaptive动作、原Li/alpha、真实来源与Lebesgue父、全部ordered head/stop/core/phase/window保持。唯一对象为先在原product切出的完整R=X(x)Z(z,σ)；不再同时预付另一个高p子账。S=0零流另列。只写本文件，无新重计算、repo／他人文件／PDF／子agent。

## 1. 新预算单位：一个共同Π，而非每父一份W

令共同可测cluster族H及共同非负价格theta_H被全部原父使用，Π=Σ_H theta_H μ(H)。theta可依完整输入，但不能在每父估价后省略父标签，冒充同一组价格。cluster可重叠；

    Π=∫Σ_H theta_H 1_H dμ。

逐source点Σtheta_H1_H≤1仅是Π≤W的充分条件，不是必要条件。高负载集中在真实小质量集上也可能合法；最终只须完整积分价有界，并证明所有实际marked flow确受这组共同价格控制。μ(H)=0的块由原绝对连续RN约束不能承载正流，不使用0·∞价格。

对每父设正paid kernels Γ_B,H，要求

    dΓ_B,H/d(Q_B⊗P_B)
        ≤theta_H 1_R(x,z,σ)1_{EH}(x)1_H(z)，
    EH={y∈H, μ(H)≤c M_C(v)}。                         (Price-RN)

同一个cluster的多条流必须先相加再受theta_H支配；不可每piece各领一份theta_H。原fixed-family单簇lemma则给所有父／旧质量层合计的完整inverse费

    Vpaid≤c Lcl(K) Π。                                (Invoice)

这里价格theta_H已经是实际RN系数，不再自动乘R565的2/epsilon。若theta本来就是由2/epsilon放大得来，该因子应在Π里而不重复收取；若没有支配其累计流，该因子也不能省略。

## 2. 真实flow margin与唯一原credit

原R的precut等质量边际为xi0=p0 Q_B|X、nu0=q0 P_B|Z，delta0=p0q0。总paid receiver／old边际须分别≤xi0、nu0。保留相同剩余总mass，terminal可用正残余product/delta完成，零delta取0。这些是完整marked边际，不是只有空间source count的约束。

实际score和inverse账分别为

    Ppaid+Pterm=∫(r_B t_Bq_B/K)∫Li dnu0 dB≤Qg，
    V_R=Vpaid+Vterm，
    Vterm=K∫r_Bt_Bq_B∫1/Li dnu_term dB。

因此已完成positive flow无论重叠多少簇，都不重复使用原Qg；但只要terminal仍有正inverse账，就不能以sourceprice覆盖率把它删掉。constant a=1/K保持。改变a、改变共享动作、回到fullcouple后再删R，都须另给完整转换，不能借本式省费。

N9若把旧(z,σ)聚成空间atom，其流分配能否按原σ条件概率提升必须说明。保留每atom的inverseLi平均可证明“σ-uniform子类”的可行解；若因此限制了允许流，不能把该子类最优值当完整marked问题的不可行／最优证书。receiver中实际partner mass、shared-rho、eligible gate也不能仅由source count替代。此项交distribution审精确模型。

## 3. Π／terminal借旧score时的新增真实系数

假设真正完整共同price与terminal分别满足

    Π≤p_W W+p_Q Qg，Vterm≤a_T Qg+L_T W。

(Invoice)给完整R的参数恰为

    a=cLcl p_Q+a_T，L=cLcl p_W+L_T。                   (a,L)

这一步是新price方案必须审核的实际放大；不是p_Q<1或a_T<1就够。设A=J/d²，C=2A(Kw+K+Fcap)+2Brem/d，原母账准确为

    Q/W≤b0^-2 [C+A L/zeta]/[1−A(zeta+a/zeta)]，
    A(zeta+a/zeta)<1。                                (Mother)

可行门槛a<d⁴/(4J²)。故只对price借credit而言，必须

    p_Q < [d⁴/(4J²)−a_T]/[cLcl]，且a_T<d⁴/(4J²)。     (Price-credit)

统一余量也需控制；不能在每输入上仅以趋零间隙满足严格不等式。source-only p_Q=a_T=0时，安全zeta=d²/(2J)给

    Q/W≤b0^-2 {4J(Kw+K+Fcap)/d²+4Brem/d
                    +4J²[cLcl p_W+L_T]/d⁴}。          (Source-only)

原R*外层2sqrt(DclkWQ)、入口64(128/119)/(1−32deltaold−16etaold)、tau_entX、wide/lowpe/extreme ratios、time atoms、删除历史、全scale与terminal槽原样保留。没有据本轮有限价格造完整外层常数。

## 4. 真正要达到的维度价，而非332W对比标签

对source-only Π=pW的来源价格部分，(Source-only)送入R*后的弱常数平方上价贡献为

    (16 A² Dclk cLcl/b0²) p。                         (Dim-price)

故要在这条充分账中容纳T(n)=sqrt(n)log^B(n+2)，价格分项须满足

    p ≲ b0² n log^(2B)(n+2)/[16A²Dclk cLcl]，

并同时支付C中的直接费、terminal及全部外层槽。固定band参数Dclk约n、A及cLcl仅polylog时，Π/W必须是适配剩余log预算的n^o(1)级；Π/W约n^theta会令这个上价达到n^((1+theta)/2)乘log损失。这里是本账充分上界的费用判断，不把一个较差上价误当算子真下界。

N7按每父分别挑partition复制332W，332是该有限对象父数，不是一般问题的维度常数；任意L1允许无限复杂度，不能把有限332当统一参数。若每父产theta_B,H，共同价格可取theta_H=esssup_B theta_B,H，但

    Σ_H μH sup_B theta_B,H 不是 sup_B Σ_H μH theta_B,H。

逐父各价≤W不保证共同价≤W。另一方面，真正共用同theta的LP/flow确实比每父复制W更有机会省价：每cluster的价格只收一次，所有父同时受该价格RN cap，并受各自原margins约束；这不是静态source点packing的同义改写。是否可覆盖完整weighted terminal且保持Π/W足够小，才是新增决定。

## 5. N9有限结果的可回代门槛

本轮不运行第二个优化。N9必须给同一冻结finite physical chi对象的：共同theta、实际Π/W、完整paid／terminal weighted账、各父precut边际约束、RN约束及加总单位。其Kfin=1只是定义单位，不是row cap；rmax>4时不许用r≤1继承原Qg或原K。finite旧Li及score必须是其声明的old parent family，不能训练alpha或原Cstar标签替代。

若有限flow保持所有margins且terminal=0，便是该有限对象的完整合法sourceprice上界；若terminal>0，需报告其真实inverseLi费及相对总V比例，不能只报unmatched mass。若只限有限interval簇或σ-uniform flow，其最优dual证书范围也限该模型。finite价格优于332W可以改变下一轮构造选择，不说明任意L1、任意n有同样价格尺度。

连续共同price／flow的存在性及极限须由recovery给出实际measurable构造和uniform inverse-terminal控制；LP status或有界Π本身不能删除逃逸／奇异limiting flow的剩余费。只需有限正族时可直接Tonelli，不能把所选父数当source预算。

## 6. 实际工具与当前状态

指定本机Python3.12.14/SymPy1.14.0实跑核验了新(a,L)替换；source-only半吸收残差0；价格弱常数平方系数精确返回16A²Dclk cLcl Π/(b0²W)；price借credit上界精确返回[1/(4A²)−a_T]/(cLcl)。这些仅核价格恢复代数，不是共同price构造证明。无新QP、DP或独立实验。

已发送cover/complement价格单位和禁复制条件。待其决定式仅审共同Π、真实terminal及实际维度价，不重复R565 RN作为新成果。

## 7. 新terminal quota：可执行的score吸收要求

proof给出的新充分条件已独核。对同一原旧P_B，令旧残余允许上界

    dh_B/dP_B=min(q0_B 1_Z, a Li²/K²)，
    demand ell_B=nu0_B−h_B≥0。

若共同priced flow满足全部实际receiver／old容量，并在旧侧至少填满ell_B，则nu_term≤h_B，

    Vterm≤K∫r_Btq_B∫aLi/K² dP_B
           =a∫(r_B/K)e_B dB≤aQg。                    (Quota)

这里同一原score只出现一次，系数a无需另乘父数；proof的Hall cuts是证明这些真实需求能由共同theta承载的充分必要接口，不是已找到价格的结论。于是Π≤p_WW时L=cLcl p_W，准确门槛仍a<d⁴/(4J²)。允许Π再借score时按第3节加cLcl p_Q，不能重复发信用。

Quota比“残余mass小”更有选择性，也更严格：在Z内原旧次边际密度为q0，残余允许比例为

    min(1, aLi²/(K²q0))。

Li接tau=1/Dclk且q0不小的来源，需要支付的old-demand比例接近1−a/(K²q0Dclk²)，而非任意固定百分比；q0本来小到允许quota时则无需强迫近全覆盖。故finite的4.7%残余或普通mass接近0都不自动满足这个原score门槛。它揭示实际低Li terminal的约n^-2精度要求，不是额外凭空引入的假设。Quota的score密度恒等式已用本机SymPy核验残差0。

## 8. 已接N9设计：同单位比较与当前决定

已读取 /tmp/ccu_r566_allocation.tex 的决定式。其full primal以共同theta最小化Π，fine flow f_BHus具有原积cap theta_H q_Bu p_Bs e_Hus，双边实际precut需求p0 q与q0 p；partial保双边上界及精确weighted terminal。两个残余边际总mass相等，可补正terminal，不漏旧σ或1/Li。以type容量A_t=Σe_Ht theta_H压缩再按theta_H e_Ht/A_t回填，逐簇RN cap仍成立；压缩不改变费用。

源价dual的方向正确：可行primal给Π上界，可行dual给该候选有限族的下界。每个父的RN约束不能用其中心quadrature权去平均弱化；quadrature只在实际physical weighted terminal／score总量中出现。完整清算时旧σ可按原P条件概率无损回填；partial若只保空间atom平均inverseLi则是σ-uniform限制模型，可行解合法，最优值不可否定更灵活fineσ流。稿已保fineσ。

这是相对静态packing真实新增的自由：theta共享、簇可重叠且流能按双边margins调度，费用未被偷偷免除。它没有按父复制同一个source W。可是目前只有准确模型，没有已认证的完整Π／weighted terminal结果，更没有一般原L1的共享价格几何构造。

比较N7必须用相同RN单位：N9的theta已包含RN放大；一个静态共同front的大块匹配在相应precut归一后可用theta≤1/epsilon，故其完整共同price基准是至多W/epsilon，而不是裸W。按父分别选不同front时，粗复制基准相应至多N_parent W/epsilon（累计多front的2/epsilon须按实际构造计入）。若把RN因子统一放外面，也可比较裸W与裸332W，但不可只给N9包含该因子的Π而让N7裸价不含。此归一提醒已反馈complement。

最终状态：新增sharedprice-flow在预算上合法且比静态source点packing更灵活；Quota给出了不复制原credit的具体terminal吸收目标。未找到满足这些完整需求、且Π/W达到第4节维度尺度的共同价格；finite模型也不能自动继承原K／Qg。全局改善仍待实际price+terminal证据，不以模型等价、dual公式或RN重述冒充。当前有界整合交付完成；后续若有已审具体构造，仅需替入Π和terminal数，不重开一般母账。停止。

## 9. 新thin原正分支：准确联合吸收及joint-rest升级

已读 /tmp/ccu_r566_coordinates.tex。其common laminar forest对每个原(C,v)选mass≤eta alpha_C M_C(v)的最大节点反链，实际两source质量和≤eta alpha_C M²；结合原F^R/Li≤1及sigma跨度ell_sigma=3+2h，完整直接inverse费

    Vthin≤a_eta Qfr≤a_eta Qg，
    a_eta=gamma KΛ²ell_sigma eta/C0。

取eta=C0 d⁴/[8gamma KΛ²ell_sigma J²]得到a0=d⁴/(8J²)。这是原dV上的完整正子分支，不是另一个coupling或每mass层的新W；其中原alpha_C、两个M分母、全部ordered真实权及terminal标签均保。其与rest精确正分割V_R=Vthin+Vrest。末审由Astra负责；本账已独核该a0回代，未将thin称为全部R付款。

若余项最终满足Vrest≤a1Qg+LW，则完整一次Cauchy是

    C_R≤sqrt[(Pthin+Prest)(Vthin+Vrest)]
       ≤sqrt[Qg{(a0+a1)Qg+LW}]。

这里Pthin+Prest=P_R≤Qg，而不是每子支各发Qg。故严格联合阈值为

    a0+a1<d⁴/(4J²)，即a1<d⁴/(8J²)=a0。               (Thin-budget)

不能把两子支分别开根再把它们的旧credit省掉。设原A=J/d²、C=2A(Kw+K+Fcap)+2Brem/d，取同zeta=d²/(2J)，必要的统一最终母式简化为

    Q/W ≤ b0^(-2) [4C+8A²L]/[1−8A²a1]，a1<a0。       (Thin-mother)

rest source-only时为b0^-2(4C+8A²L)；a1接门槛时分母损失必须保留，不能只写存在吸收。若需留统一余量，可要求a1≤a0/2，代价再至多乘2。所有原直接低增长／低Li、入口、time/deletion、全scale和外层R*费用沿本账原mother保留，thin不另改这些常数。

### rest是joint gate，不能继续假设X·Z product

定义G_B(x,z,σ)=1_R 1_{Uthin^c}。原rest初始正joint为lambda_B=G_B Q_B⊗P_B，其真实边际是

    xi_G(dx)=Q_B(dx)∫G_B(x,z,σ)P_B(dz dσ)，
    nu_G(dz dσ)=P_B(dz dσ)∫G_B(x,z,σ)Q_B(dx)。

二者同mass delta_G；一般不再是p0Q|X、q0P|Z，也不能将两边际积除delta误称为原joint gate。sharedprice paid kernels必须按本次升级保

    RN_paid,H≤theta_H G_B 1_EH 1_H（相对于原Q_B⊗P_B），
    Σpaid receiver≤xi_G，Σpaid old≤nu_G。

这样原cluster invoice仍是cLcl Π，且thin加全部rest paid/terminal的原score总量仍恰为原P_R≤Qg。proof与recovery均已确认此合法升级，无新增action或receiver选择。

剩余两边际可用其product/剩余mass补一个正terminal。这个analysis terminal可能落在几何G之外；必须继续带“未付rest”的不可变标签，只以真实残余old边际计算inverseLi与原score，不再对它应用thin／G-specific cluster几何，也不把其碰巧落入thin区域再付一次。若要求整个terminal也support G，则须补residual support-Hall；仅两marginal上界不能保证。

Quota亦须升级：令f_G=dnu_G/dP_B，取h_G=min(f_G,a_T Li²/K²)P_B，需求为nu_G−h_G，而非原min(q01_Z,...)。若该需求确由paid flow填满，则Vterm≤a_TQg仍成立。若price Πrest≤p_WW+p_QQg，则本节rest参数为

    a1=cLcl p_Q+a_T，L=cLcl p_W+L_T，
    p_Q<[a0−a_T]/(cLcl)。

这比删除thin前的source-credit可用额度减半。共同price、quota和joint-support cuts必须针对这个真实rest重算，不能把原product模型的结果无条件搬来。未运行N9。

### 接cover实际正thinning候选的费用范围

随后收到cover /tmp/ccu_r566_prices.tex S9–16。其新共同字典价Π≤W、c=gamma+1，paid density本来就是vartheta_i,d(M) 1_R原product的正thinning，terminal density为(1−vartheta_i,d(M))1_R。因此在该构造几何／字典假设通过相应审查后，可直接再乘1_Uthin^c，Π上界及c不变；paid实际rest边际自动受xi_G、nu_G支配，source费≤(gamma+1)LclW。terminal应改成

    Vterm,rest=∫(1−vartheta_i,d(M))1_Uthin^c dV，

不是再用未经删除的完整terminal，也不是每bin另发W。若以后它被证明≤a_TQg+L_TW，本节只取a1=a_T、L=(gamma+1)Lcl+L_T送入(Thin-mother)。当前字典归一价≤W只保证正付款比例，未给vartheta的统一正下界或weighted terminal付款；因此这个升级合法扩大已付范围，却仍不闭合完整R。

工具：指定本机Python/SymPy实跑验证eta代入a_eta恰为d⁴/(8J²)，联合剩余门槛a1=1/(8A²)，以及(Thin-mother)对一般母式的残差均为0。没有新数值队列／优化。必要费用补充完成，停止。
