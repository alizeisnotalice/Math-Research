# R467 FINAL PASS（限定已证结论）

独立 PRE 后审最终七输入。PASS 限于联合 cut 交换、真实厚需求正部/分层比较、同源密度的加权层积分及准确未付项、有限复现。**没有认证缺额根价、统一覆盖比例或跨父收缩；R433 旧费与 \(P(1)\le\Lambda W+\delta\) 仅继承引用，完整一般目标仍未证明。**

同删/同加交换中的 \(-M\kappa(J\times D)\) 正确。对固定 \(D\) 取正部父集，得到 \(\int_I[M\pi_A(D)-r_A]_+\le\int_Ds\)。控制的是 \(\int_Jr_A\,d\nu\)，不能换成整块 \(\nu(J)\)；零厚度父不虚增覆盖。ties 与质量原子不需删除。近优版本增加 cut gap \(e\)；若另具安全阈值，完整尾式总误差 \(e(1+1/\alpha)\) 的符号和次数正确。

main (3)/complement (7) 保 \(-\Lambda\mu(B)\) 一次。\(M>1+\alpha\) 时补父集的 \(\pi_A(H_L)\) 下界及系数 \(M/(M-1-\alpha)\) 正确；取 \(L=\alpha\Lambda\) 只抵消该低层容量费，高层及指定父集仍未付。抛掉指定父集不能冒称超过既有单列尾界；不同来源层重数也未免费求和。可选降低 \(M\) 的式子带至少两倍放大，未被当作收缩。局部高外父式(9)方向确为厚需求下界，不是付款上界。

geometry 保 \(t=d(P1_{y\in B})_y/d\mu\le SD\le SA_n\)，而非刷新后验。\(H_J\) 的原终端质量/中心门只在上界正删除，再用同一 \(t\) 的水平集积分联合 cut，得到 main (4)。所有项在同一 \(\kappa,\mu,\nu\) 下，未乘两份自由总质量。新父中心外门仍为 \(A\notin Q_u\)，不等于 \(u\notin Q_A\)，也不赋新父旧 history。

\(\int_Bs_B\,d\mu=(M-1)\nu(I)+\delta_*\) 及
\(\int_Bs_Bt\,d\mu=M H_I+M L_{\rm rem}-\Lambda R_B\)
均准确。\(L_{\rm rem}\) 保 R466 的三块费用。零截断代回时 \(H_I\) 完全抵消，只得另一必要关系，没有上界或收缩；正截断的 \(\int s_B(t-a)_+\) 仍需独立来源预算。可逆性、单侧 row 逃逸或 cut 厚度没有被当该乘积的价格。

隔离目录
`/var/folders/lq/2c4qbz2n0354_tnttkv_qsz00000gn/T/r467_audit_t57etyba`
使用指定 Python 重放 geometry/complement 代码块及 numeric 脚本：92、24、13965项通过；stdout 与 replay 逐字一致，numeric JSON 仅 seconds 不同。92为有限加权层积分，24为单最优割的有限代数；numeric 使用三种真实区间 wholeblock incidence 的40个参数、77个最优cut，扩大部分只核最优cut，原7例另核近优/gap交换。1652等旧轮统计未混入本轮。13965是断言数，非独立几何样本数。

数值覆盖分母是厚需求 \(\int_Ir\,d\nu=\delta+\Lambda\mu(B)\)，非缺额；零分母记 None，\(r=0\) 不计正需求。有限零覆盖例只筛查预算是否自动覆盖，不能排除原 high-rank/stage/history 机制。输入没有实现原 hard 需求或原项目容量，因此没有由有限结果外推根阶失败/成立。PRE 临时符号核验不计归档。未改作者或仓库，未编译 PDF。

最终七输入 SHA256：

- `r467_main.md`: `3b1b24910514d14c8d887473cf65a18e3dbe3d6f2d49c29f99d9aa6f06951653`
- `r467_geometry.md`: `fa545fa5b954305b1621bbf8cf97c21b7186d36599eea2555ffdd4fa31583cdc`
- `r467_complement.md`: `1fa6e4975ab70534f07e7ab32e94f99178b1f621a77cb3edf4df7fdbfd17a50b`
- `r467_numeric.md`: `bcfac0f76e4da1d54f019d120c6eddaafd0d7c436f43d0d090c6b7dd8c4f0215`
- `r467_numeric.py`: `64120120794a543e9a33def175857a6af9c54f4bdd074cfffeb3852f5760f5cb`
- `r467_numeric.json`: `a151265d604d1b702df86961079edf6ea66c0f406ab676fa62abd1f39cb1414c`
- `r467_replay.json`: `f7609f6c991467fa785de7d9db367d8150790f2f3503fb28d1596f27c90f01f0`
