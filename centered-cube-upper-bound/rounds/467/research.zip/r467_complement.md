# R467：联合割交换、真实厚需求削减与父子集尾

范围：同一 R465 最优割 \((I,B)\)，实际 \(\nu\le S q_A dA\)、\(\mu=f\,dx\)、\(\pi_A=c_A\mu/m_A\)、\(\kappa=\nu\pi_A\)。质量和单 octave 选择器不改变。以下新增的是联合交换约束及其对原缺额的直接比较；未得到完整根阶缺额预算。

## 1. 双向联合交换，保交叉项

令
\[
 r_A=1-M\pi_A(B^c)\ge0\ (A\in I),\qquad
 s(x)=Mb_I(x)-\Lambda\ge0\ (x\in B).
\]
对可测 \(J\subset I,D\subset B\)，同删两侧的准确成本差为
\[
 C(I\setminus J,B\setminus D)-C(I,B)
 =\int_Jr_A\,d\nu+\int_Ds\,d\mu-M\kappa(J\times D)\ge0.     \tag{1}
\]
不能删掉最后的交叉项；它正是两次单侧比较缺少的部分。固定 \(D\) 并选择正部集合 \(J\) 得
\[
 \boxed{\int_I[M\pi_A(D)-r_A]_+\,d\nu
             \le\int_Ds\,d\mu.}                           \tag{2}
\]
所有集合可测，负载有限；等号集合任选，不需要最小最优割。

同加两侧，若 \(J\subset I^c,D\subset B^c\)，则
\[
 C(I\cup J,B\cup D)-C(I,B)
 =\int_J[M\pi_A(B^c)-1]d\nu
  +\int_D[\Lambda-Mb_I]d\mu-M\kappa(J\times D)\ge0.          \tag{3}
\]
(1)、(3) 由分成四个矩形直接展开。若原割仅有成本差
\(e=C(I,B)-V\ge0\)，两式右侧只要求至少为 \(-e\)，因而 (2) 的右侧增加 \(e\)。此近最优版本不需要先假设其单侧阈值成立。

## 2. 支付的是厚需求 \(r_A\)，不是整个 \(\nu(J)\)

任取 \(\alpha>0,L\ge0\)，在同一割定义
\[
 D_L=\{x\in B:0\le s(x)\le L\},\quad H_L=B\setminus D_L,
\quad
 J=\{A\in I:M\pi_A(D_L)\ge(1+\alpha)r_A\}.
\]
由 (2)
\[
 \boxed{\int_Jr_A\,d\nu
       \le\alpha^{-1}\int_{D_L}s\,d\mu
       \le(L/\alpha)\mu(D_L).}                             \tag{4}
\]
\(r_A=0\) 的父可任选归属，费用为零。这个结论比先以 \(r_A\le1\) 支付整块父质量更准确。若 \(L=C\sqrt n\,\mathrm{polylog}(n+2)\)，(4) 是该真实厚需求部分的一次来源价；不声称该部分覆盖全部原需求。

原缺额的准确连接为
\[
 \delta=\int_Ir_A\,d\nu-\Lambda\mu(B)
 \le (L/\alpha)\mu(D_L)
     +\int_{I\setminus J}r_A\,d\nu-\Lambda\mu(B).            \tag{5}
\]
负的 \(-\Lambda\mu(B)\) 保留一次，不能再在另一账扣除。若将父按真实质量分为互不相交层，且使用同一个 \(D_L\)，(2) 对它们的并集直接应用，(4) 只收一次。若各层改用不同 \(D_j\)，费用是
\(\alpha^{-1}\int s(x)\sum_j1_{D_j}(x)\,\mu(dx)\)；除非来源集合不交或重数另有预算，不能免费再求和。

对一般 \(e\)-近最优割，可在 \(D\subset B\cap\{0\le s\le L\}\) 及
\(J=\{A\in I:r_A>0,\ M\pi_A(D)\ge(1+\alpha)r_A\}\) 使用
\(\int_Jr_A\,d\nu\le(L\mu(D)+e)/\alpha\)。
若该近最优割另外满足两侧安全阈值，则下述完整尾式增加 \(e(1+1/\alpha)\)，因为真实最优缺额等于该割厚需求减来源价再加 \(e\)。

## 3. 同一缺额的高拥挤尾，明确损失

对 \(A\in I\setminus J\)，利用
\(M\pi_A(B)=M-1+r_A\)，得到
\[
 M\pi_A(H_L)>M-1-\alpha r_A.                               \tag{6}
\]
所以当 \(M>1+\alpha\)，
\[
 \int_{I\setminus J}r_A\,d\nu
 \le c_{M,\alpha}\,\kappa((I\setminus J)\times H_L),
 \qquad c_{M,\alpha}=\frac{M}{M-1-\alpha}.
\]
与 (5) 联立：
\[
 \boxed{\delta\le
 (L/\alpha-\Lambda)\mu(D_L)
 +c_{M,\alpha}\kappa((I\setminus J)\times H_L)
 -\Lambda\mu(H_L).}                                       \tag{7}
\]
若 \(L\le\alpha\Lambda\)，低层项非正，可直接保留或删除。高层确有
\(b_I>(\Lambda+L)/M\)，但 (7) 仍未支付。这里 \(\kappa=\nu\pi_A\) 是真实父匹配核；当 \(\nu\) 只是原流的父边缘时，不能把这个尾事件叫作原流已有来源的事件。重新附加后验来源也不会赋予它旧历史。

与已有粗界的区别必须保留：
\[
 \delta\le\int_B(b_I-\Lambda)\,d\mu
       \le\int_B(b_I-\Lambda)_+d\mu,                        \tag{8}
\]
因为 \(r_A\le\pi_A(B)\) 对 \(M\ge1\) 成立。故将 (7) 的指定父子集 \(I\setminus J\) 再放成整个 \(I\)，并不自动产生新的全局尾改善；本轮有效内容是 (2)、(4) 保真实 \(r_A\) 的联合削减。

可选参数比较也不是收缩：若 \(M\ge2+\alpha\)，令
\(M'=M/(2+\alpha)\)、\(T_{M'}(H)=\int(1-M'\pi_A(H^c))_+d\nu\)。
(6) 给
\[
 \delta\le(L/\alpha-\Lambda)\mu(D_L)
       +(2+\alpha)T_{M'}(H_L)-\Lambda\mu(H_L).
\]
它降低容量倍率且放大至少两倍，不能作为可求和递推闭合。

## 4. 对高质量外父的真实约束

固定实际终端 \(u\)，令
\(J_u^\kappa=\{A\in I:m_A>\kappa m_u,\ A\notin Q_u\}\)。
对任何 \(D\subset D_L\cap Q_u\) 且来源在 \(u\) 上 own-low，R466_geometry 的同场下界为
\[
 b_{J_u^\kappa}(x)\ge d_\kappa,\quad
 d_\kappa=
 \left[\frac{\Lambda}{M}-S\lambda h
 -Sr\{1+\log(\kappa K)\}-\frac{Sr}{\kappa}\right]_+ .
\]
把它插入 (1)，得到新的厚需求约束
\[
 \int_{J_u^\kappa}r_A\,d\nu
 \ge [M d_\kappa-L]_+\,\mu(D).                             \tag{9}
\]
这是同一来源/父关系的积分，没有两份总质量相乘。方向是必要下界，不是高父费用上界。它阻止把强制产生的高外父都当成“几乎无厚需求”的免费关联。

另一方面，若 \(D\subset Q_u\)，每个该高父满足
\(\pi_A(D)\le m_u/m_A<1/\kappa\)。
于是 (4) 能覆盖这些父，只可能在
\(r_A<M/[(1+\alpha)\kappa]\) 的范围。因而不能用单个小终端的局部 \(D\) 宣称已经支付 R466 的全部高外父；需要跨终端共享来源集合的重复控制。这个缺口与 (7) 的指定父子集尾尚未获一般预算，原辅助流也没有变成原历史。

## 5. 有界计算

指定 Python 实跑以下 24 项 Fraction 联合删除/正部/厚需求检查。有限模型只有一个最优割；不声称验证连续 cube 几何或原历史。连续结论由上述代数和测度积分证明。

~~~python
from fractions import Fraction as F
from itertools import product
nu=[F(1),F(2)];mu=[F(2),F(1)]
pi=[[F(1,3),F(2,3)],[F(3,4),F(1,4)]]
M=F(2);Lam=F(1,2)
sets=[set(i for i,b in enumerate(bits) if b) for bits in product([0,1],repeat=2)]
E=set(range(2))
def k(J,D):return sum((nu[i]*pi[i][j] for i in J for j in D),F(0))
def cost(I,B):return sum(nu[i] for i in E-I)+M*k(I,E-B)+Lam*sum(mu[j] for j in B)
V=min(cost(I,B) for I in sets for B in sets)
checks=opts=0
for I in sets:
 for B in sets:
  if cost(I,B)!=V:continue
  opts+=1
  r=[1-M*sum(pi[i][j] for j in E-B) for i in range(2)]
  s=[M*sum(nu[i]*pi[i][j] for i in I)/mu[j]-Lam for j in range(2)]
  for D in sets:
   if not D<=B:continue
   for J in sets:
    if not J<=I:continue
    rhs=sum(nu[i]*r[i] for i in J)+sum(mu[j]*s[j] for j in D)-M*k(J,D)
    assert cost(I-J,B-D)-V==rhs and rhs>=0;checks+=1
   positive=sum(nu[i]*max(F(0),M*sum(pi[i][j] for j in D)-r[i]) for i in I)
   assert positive<=sum(mu[j]*s[j] for j in D);checks+=1
   J={i for i in I if M*sum(pi[i][j] for j in D)>=2*r[i]}
   assert sum(nu[i]*r[i] for i in J)<=sum(mu[j]*s[j] for j in D);checks+=1
print("PASS",checks,"Fraction checks;",opts,"optimal cut")
~~~
