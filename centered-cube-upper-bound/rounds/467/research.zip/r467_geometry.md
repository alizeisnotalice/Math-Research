# R467：实际高外父负载的带权联合交换界

**结果。** 对 R465 最优割与同一实际 \(P\)，联合删除条件确实给出下述带权估计。它尚不能支付 R466 的 \(H\)：未付项是最优割来源松弛与**同一实际旧来源密度**的乘积；在零截断处，该项准确含回 \(H\) 本身。本附件据此停止，不将新的父关联赋予原历史。

## 1. 量词与唯一候选

令 \(\mu=fdy\)、\(\nu=P_A\le S\sigma\)，\((I,B)\) 为达到最优缺额 \(\delta_*\) 的割。定义
\[
 \kappa(dA,dy)=\nu(dA)\pi_A(dy),\quad
 r_A=1-M\pi_A(B^c)\ge0\ (A\in I),
 \quad s_B(y)=Mb_I(y)-\Lambda\ge0\ (y\in B).
\]
\(r_A\) 不是质量比，\(s_B\) 不是原参数 \(s=1+\sqrt n\)。记
\[
 P_B=1_B(y)P,\quad R_B=|P_B|,\quad
 t(y)=\frac{d(P_B)_y}{d\mu}(y),\quad
 0\le t(y)\le SD(y)\le T:=SA_n.
\tag{1}
\]
这里 \(t\) 是实际保留流的来源密度，未替换为父后验；其上界只用原静态支配。对任意可测 \(J\subset I\)，保原终端 \((u,y)\) 定义
\[
 H_J=\int P_B(d\xi)
 \int_J\frac{c_A(y)}{m_A}
 1_{\{m_A>Km_u,\ A\notin Q_u\}}\nu(dA).
\tag{2}
\]
\(H_I\) 正是本轮目标 \(H\)。方向仍是父中心 \(A\notin Q_u\)，不能替换成 \(u\notin Q_A\)。

可证：对所有 \(a\in[0,T]\)，
\[
 \boxed{H_J\le a\nu(J)+\frac{T-a}{M}\int_Jr_A\nu(dA)
   +\frac1M\int_B s_B(y)(t(y)-a)_+\mu(dy).}
\tag{3}
\]
这是一个带实际来源密度的整体交换式，不预设任何来源独立性。

## 2. 完整证明与收费范围

同时从最优割删除 \(J\subset I\) 与 \(D\subset B\)，最优性给
\[
 M\kappa(J\times D)\le
 \int_Jr_A\,d\nu+\int_Ds_B\,d\mu.
\tag{4}
\]
直接展开原割值与 \((I\setminus J,B\setminus D)\) 的差，正好得到右侧减左侧；因此 (4) 对质量原子和任意可测集合同样成立。

只在上界删除 (2) 的质量/中心门，非负 Tonelli 给
\[
 H_J\le\int_{J\times B}t(y)\,d\kappa.
\]
用 \(t\le a+(t-a)_+\)、\(\kappa(J\times B)\le\nu(J)\)，并对
\(D_v=B\cap\{t>v\}\)、\(a<v<T\) 积分 (4)，便得到 (3)。所有原历史仍在 (2)；上界删除门并不表示这些门对新父成立。

由最优割恒等式，
\[
 \int_Bs_B\,d\mu=(M-1)\nu(I)+\delta_*.
\tag{5}
\]
所以目前仅知未付项不超过
\(T[(M-1)\nu(I)+\delta_*]\)，其费用仍随原流质量，而非根阶 \(W\)。不能把这项称为已付“松弛预算”。

## 3. 为何这里没有得到收缩

R466 给出每条原记录的实际低/中质量与中心内部总负载上界
\[
 L_0=Sr\left[s/\varepsilon_0+1+2\sqrt n+e^{-\sqrt n}\right].
\]
保原门定义准确的剩余差
\[
 L_{\rm rem}=\int P_B(d\xi)\,[b_I(y)-F^K_{I,u}(y)],
 \qquad0\le L_{\rm rem}\le L_0R_B.
\]
因此
\[
 \int_Bs_B(y)t(y)\mu(dy)
   =M H+M L_{\rm rem}-\Lambda R_B.
\tag{6}
\]
这不是估计，而是同一实际来源边缘上的恒等式。把它代入 (3) 的 \(J=I,a=0\)，\(H\) 完全抵消，只留下
\[
 \Lambda R_B\le T\int_Ir_A\,d\nu+M L_{\rm rem}.
\tag{7}
\]
它没有给 \(H\) 的上界，也未使最优缺额缩小。选择正截断 \(a\) 仍需要独立控制
\(\int_Bs_B(t-a)_+d\mu\)。仅用 \(t\le SD\) 和 (5) 又回到线性占用费用。

**唯一缺桥。** 必须对 (2) 中同一原接受密度与新父空间门联合取价，使 (3) 最后一项获得真来源费用，或保留这些门直接估计 \(H_J\)。现有最优厚度、来源高拥挤和逐父外逃保证不能代替这个联合估计：厚度约束的是 \(\pi_A\)，而 \(t\) 含原阶段、low-common 与全部未来筛选；没有证明它与 \(s_B\) 的高值区反相关。可逆父核的对称性也不自动改变此正乘积。故本轮无新增根阶付款、无母账系数变动；(6) 是决定停止纯联合割代数迭代的具体检查。

## 4. 本机验证

指定 Python 实跑 92 项 Fraction 断言，核最优有限割的 (4) 及 layer-cake 估计。下列有限表仅验证测度代数，不声称原生立方体或原高秩历史实例。证明来自上文，不来自枚举。

```python
from fractions import Fraction as F
from itertools import product
mu=[F(1),F(3),F(1),F(10)];nu=[F(4),F(4),F(1)]
pi=[[F(1,4),F(3,4),0,0],[0,F(3,4),F(1,4),0],[0,0,0,F(1)]]
t=[F(0),F(8,3),F(0),F(1,10)];T=max(t);checks=0
sub=lambda n:list(product((0,1),repeat=n))
for M,L in [(F(2),F(1)),(F(3),F(1)),(F(2),F(2))]:
 def cut(I,B):
  return sum(nu[a]*I[a]*(1-M*sum(pi[a][x]*(1-B[x]) for x in range(4))) for a in range(3))-L*sum(mu[x]*B[x] for x in range(4))
 _,I,B=max((cut(I,B),I,B) for I in sub(3) for B in sub(4))
 r=[1-M*sum(pi[a][x]*(1-B[x]) for x in range(4)) for a in range(3)]
 s=[M*sum(nu[a]*I[a]*pi[a][x] for a in range(3))/mu[x]-L for x in range(4)]
 for J in sub(3):
  if any(J[a]>I[a] for a in range(3)):continue
  nr=sum(nu[a]*J[a]*r[a] for a in range(3));nj=sum(nu[a]*J[a] for a in range(3))
  for D in sub(4):
   if any(D[x]>B[x] for x in range(4)):continue
   kjd=sum(nu[a]*J[a]*pi[a][x]*D[x] for a in range(3) for x in range(4))
   assert M*kjd<=nr+sum(mu[x]*D[x]*s[x] for x in range(4));checks+=1
  lhs=sum(nu[a]*J[a]*pi[a][x]*B[x]*t[x] for a in range(3) for x in range(4))
  for z in (F(0),T/2,T):
   rhs=z*nj+(T-z)*nr/M+sum(mu[x]*B[x]*s[x]*max(F(0),t[x]-z) for x in range(4))/M
   assert lhs<=rhs;checks+=1
print('PASS',checks,'Fraction checks; finite cut and weighted layercake only, not native geometry/history.')
```

```text
PASS 92 Fraction checks; finite cut and weighted layercake only, not native geometry/history.
```
