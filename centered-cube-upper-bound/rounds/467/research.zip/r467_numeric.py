from fractions import Fraction as F
from pathlib import Path
from collections import deque
import json,sys,platform,time
ROOT=Path(__file__).resolve().parent
start=time.perf_counter();checks=0

def ck(z):
 global checks
 assert z
 checks+=1
H=F(1,100);R=F(6,5)
inputs=[('nested_full_reallocation',[0,1],[F(1,2),0],[1,1]),('nested_Hall_deficit',[0,1],[F(1,2),0],[F(1,2),F(3,2)]),('three_packet_chain',[0,1,2],[F(1,2),F(3,2),1],[1,1,1])]
models=[]
for name,sources,parents,d in inputs:
 sources=list(map(F,sources));parents=list(map(F,parents));d=list(map(F,d));B=[];margins=[]
 for a in parents:
  br=[];mr=[]
  for x in sources:
   hi=abs(a-x)+2*H;lo=max(F(0),abs(a-x)-2*H)
   if hi<R/2:br.append(1);mr.append(R/2-hi)
   else:ck(lo>R/2);br.append(0);mr.append(lo-R/2)
  B.append(br);margins.append(mr)
 for cs in (sources,parents):
  for k,x in enumerate(cs):
   for y in cs[k+1:]:ck(abs(x-y)>2*H)
 f=[F(1)]*len(sources);mass=[sum(br) for br in B]
 pi=[[F(z,mass[j]) for z in br] for j,br in enumerate(B)]
 a0=[[d[j]*pi[j][i] for i in range(len(f))] for j in range(len(d))]
 models.append(dict(name=name,sources=sources,parent_centers=parents,d=d,f=f,capture=B,geometry_margins=margins,pi=pi,a0=a0))

def maxflow(model,M,Lambda):
 d=model['d'];f=model['f'];a0=model['a0'];J=len(d);K=len(f);src=0;rn=list(range(1,J+1));cn=list(range(J+1,J+K+1));sink=J+K+1;N=sink+1
 cap=[[F(0)]*N for _ in range(N)];res=[[F(0)]*N for _ in range(N)];adj=[[] for _ in range(N)]
 def edge(u,v,c):cap[u][v]=res[u][v]=c;adj[u].append(v);adj[v].append(u)
 for j in range(J):edge(src,rn[j],d[j])
 for j in range(J):
  for i in range(K):
   if a0[j][i]:edge(rn[j],cn[i],M*a0[j][i])
 for i in range(K):edge(cn[i],sink,Lambda*f[i])
 value=F(0)
 while True:
  prev=[None]*N;prev[src]=src;q=deque([src])
  while q and prev[sink] is None:
   u=q.popleft()
   for v in adj[u]:
    if prev[v] is None and res[u][v]>0:prev[v]=u;q.append(v)
  if prev[sink] is None:break
  path=[];v=sink
  while v!=src:path.append((prev[v],v));v=prev[v]
  delta=min(res[u][v] for u,v in path);ck(delta>0)
  for u,v in path:res[u][v]-=delta;res[v][u]+=delta
  value+=delta
 p=[[cap[rn[j]][cn[i]]-res[rn[j]][cn[i]] for i in range(K)] for j in range(J)]
 for j in range(J):ck(sum(p[j])<=d[j]);ck(all(0<=p[j][i]<=M*a0[j][i] for i in range(K)))
 for i in range(K):ck(sum(p[j][i] for j in range(J))<=Lambda*f[i])
 ck(sum(map(sum,p))==value)
 return p,value


def subsets(S):
 S=sorted(S)
 for mask in range(1<<len(S)):yield {S[k] for k in range(len(S)) if mask>>k&1}

def certify(model,M,Lambda,nonoptimal_swaps=False):
 Jn=len(model['d']);In=len(model['f']);d=model['d'];f=model['f'];a0=model['a0'];pi=model['pi'];flow,opt=maxflow(model,M,Lambda)
 allrows=set(range(Jn));allsources=set(range(In))
 strong_checks=0;thick_checks=0
 def cost(I,B):return sum(d[j] for j in allrows-I)+M*sum(a0[j][i] for j in I for i in allsources-B)+Lambda*sum(f[i] for i in B)
 swap_count=0;optimal=[];budget_count=0;budgets=[]
 for I in subsets(allrows):
  for B in subsets(allsources):
   c=cost(I,B);gap=c-opt;ck(gap>=0)
   if gap and not nonoptimal_swaps:continue
   r=[1-M*sum(pi[j][i] for i in allsources-B) for j in range(Jn)]
   ss=[M*sum(a0[j][i] for j in I)/f[i]-Lambda for i in range(In)]
   for adding,rs,cs in ((False,I,B),(True,allrows-I,allsources-B)):
    for J in subsets(rs):
     for D in subsets(cs):
      Rmargin=sum(d[j]*r[j] for j in J);Smargin=sum(f[i]*ss[i] for i in D);kappa=sum(a0[j][i] for j in J for i in D)
      swapped=cost(I|J,B|D) if adding else cost(I-J,B-D)
      expr=(-Rmargin-Smargin if adding else Rmargin+Smargin)-M*kappa
      ck(swapped-c==expr)
      ck(M*kappa<=(-Rmargin-Smargin if adding else Rmargin+Smargin)+gap)
      swap_count+=1
   if gap:continue
   ck(all(r[j]>=0 for j in I));ck(all(ss[i]>=0 for i in B))
   localbudgets=[]
   for J in subsets(I):
    if not J:continue
    for D in subsets(B):
     if not D:continue
     theta=min(sum(pi[j][i] for i in D) for j in J);rho=max(r[j] for j in J);L=max(ss[i] for i in D)
     if M*theta<=rho:continue
     nu=sum(d[j] for j in J);mu=sum(f[i] for i in D);bound=L*mu/(M*theta-rho)
     ck(theta>0 and rho>=0 and L>=0);ck(nu<=bound)
     budget_count+=1
     z=dict(J=sorted(J),D=sorted(D),theta=theta,rho=rho,L=L,demand=nu,source_mass=mu,bound=bound,slack=bound-nu)
     localbudgets.append(z);budgets.append(z)
   profiles=[]
   for L in (F(0),F(1,2),F(1)):
    D={i for i in B if ss[i]<=L}
    incident={j for j in I if sum(pi[j][i] for i in D)>0}
    controlled={j for j in I if sum(pi[j][i] for i in D)>=F(1,2) and r[j]<=F(1,4)}
    bound=L*sum(f[i] for i in D)/(M*F(1,2)-F(1,4));demand=sum(d[j] for j in controlled)
    ck(demand<=bound)
    profiles.append(dict(L=L,D=sorted(D),source_mass=sum(f[i] for i in D),incident_demand=sum(d[j] for j in incident),controlled_demand=demand,bound=bound))
   thickcore=sum(d[j]*r[j] for j in I)
   positive_r_demand=sum(d[j] for j in I if r[j]>0)
   for D in subsets(B):
    paid=sum(f[i]*ss[i] for i in D)
    plus=sum(d[j]*max(F(0),M*sum(pi[j][i] for i in D)-r[j]) for j in I)
    ck(plus<=paid);strong_checks+=1
    for alpha in (F(1),F(2)):
     chosen={j for j in I if r[j]>0 and M*sum(pi[j][i] for i in D)>=(1+alpha)*r[j]}
     received=sum(d[j]*r[j] for j in chosen)
     ck(received<=paid/alpha);thick_checks+=1
   coverage=[]
   for Lfactor in (F(1),F(2)):
    L=Lfactor*Lambda;D={i for i in B if ss[i]<=L};paid=sum(f[i]*ss[i] for i in D)
    for alpha in (F(1),F(2)):
     chosen={j for j in I if r[j]>0 and M*sum(pi[j][i] for i in D)>=(1+alpha)*r[j]}
     received=sum(d[j]*r[j] for j in chosen)
     ck(received<=paid/alpha)
     coverage.append(dict(L_over_Lambda=Lfactor,alpha=alpha,D=sorted(D),source_surplus_budget=paid,
      covered_thick_mass=received,total_thick_mass=thickcore,coverage_fraction=received/thickcore if thickcore else None,
      covered_positive_r_demand=sum(d[j] for j in chosen),total_positive_r_demand=positive_r_demand))
   optimal.append(dict(I=I,B=B,r=r,s=ss,thick_mass=thickcore,coverage=coverage,core_demand=sum(d[j] for j in I),core_source_mass=sum(f[i] for i in B),
    core_min_source_surplus=min((ss[i] for i in B),default=None),near_profiles=profiles,budget_count=len(localbudgets)))
 ck(optimal)
 summary=[]
 for k,L in enumerate((F(0),F(1,2),F(1))):
  entries=[o['near_profiles'][k] for o in optimal]
  summary.append(dict(L=L,source_mass_range=[min(z['source_mass'] for z in entries),max(z['source_mass'] for z in entries)],
   incident_demand_range=[min(z['incident_demand'] for z in entries),max(z['incident_demand'] for z in entries)],
   controlled_demand_range=[min(z['controlled_demand'] for z in entries),max(z['controlled_demand'] for z in entries)]))
 coverage_summary=[]
 for k in range(4):
  entries=[o['coverage'][k] for o in optimal]
  fractions=[z['coverage_fraction'] for z in entries if z['coverage_fraction'] is not None]
  coverage_summary.append(dict(L_over_Lambda=entries[0]['L_over_Lambda'],alpha=entries[0]['alpha'],
   coverage_fraction_range=[min(fractions),max(fractions)] if fractions else None,
   covered_thick_mass_range=[min(z['covered_thick_mass'] for z in entries),max(z['covered_thick_mass'] for z in entries)],
   total_thick_mass_range=[min(z['total_thick_mass'] for z in entries),max(z['total_thick_mass'] for z in entries)]))
 # Positive-deficit instances are diagnostically important: retain all (few) optimal cores and margins.
 core_data=[dict(I=sorted(o['I']),B=sorted(o['B']),r=o['r'],s=o['s'],core_demand=o['core_demand'],core_source_mass=o['core_source_mass'],core_min_source_surplus=o['core_min_source_surplus']) for o in optimal] if sum(d)>opt else []
 return dict(geometry=model['name'],M=M,Lambda=Lambda,primal=flow,optimum=opt,deficit=sum(d)-opt,optimal_cut_count=len(optimal),
  all_cut_joint_swap_count=swap_count,nonoptimal_swaps_checked=nonoptimal_swaps,admissible_nonempty_budget_count=budget_count,
  positivepart_subset_checks=strong_checks,thickness_subset_checks=thick_checks,thickness_coverage=coverage_summary,
  tightest_budget=min(budgets,key=lambda z:z['slack']) if budgets else None,
  largest_controlled_demand_budget=max(budgets,key=lambda z:z['demand']) if budgets else None,
  nearcritical_profiles=summary,positive_deficit_cores=core_data)
rows=[certify(model,M,F(1),True) for model in models for M in (F(3,2),F(2))]
rows.append(certify(models[0],F(1),F(3,2),True))
keys={(r['geometry'],r['M'],r['Lambda']) for r in rows}
for model in models:
 for M in (F(2),F(4),F(8)):
  for Lambda in (F(1,2),F(1),F(3,2),F(2)):
   if (model['name'],M,Lambda) in keys:continue
   rows.append(certify(model,M,Lambda,False))
ck(len(rows)==40)
aggregate=[]
for M,Lambda in sorted({(r['M'],r['Lambda']) for r in rows}):
 selected=[r for r in rows if r['M']==M and r['Lambda']==Lambda]
 coverage=[]
 for k in range(4):
  valid=[r['thickness_coverage'][k]['coverage_fraction_range'] for r in selected if r['thickness_coverage'][k]['coverage_fraction_range'] is not None]
  pos=[r['thickness_coverage'][k]['coverage_fraction_range'] for r in selected if r['deficit']>0 and r['thickness_coverage'][k]['coverage_fraction_range'] is not None]
  coverage.append(dict(L_over_Lambda=selected[0]['thickness_coverage'][k]['L_over_Lambda'],alpha=selected[0]['thickness_coverage'][k]['alpha'],
   all_core_fraction_range=[min(z[0] for z in valid),max(z[1] for z in valid)] if valid else None,
   positive_deficit_core_fraction_range=[min(z[0] for z in pos),max(z[1] for z in pos)] if pos else None))
 aggregate.append(dict(M=M,Lambda=Lambda,case_count=len(selected),positive_deficit_case_count=sum(r['deficit']>0 for r in selected),coverage=coverage))
out=dict(scope='Exact finite joint-cut-swap and conditional nearcritical-budget interfaces on existing actual interval incidence models; no continuous/history/root bound',
 executable=sys.executable,python=platform.python_version(),checks=checks,geometries=models,source_halfwidth=H,center_halfwidth=H,side=R,cases=rows,aggregate=aggregate,
 identities=dict(deletion='C(I-J,B-D)-C(I,B)=int_J r dnu+int_D s dmu-M*kappa(J,D)',
 addition='C(I+J,B+D)-C(I,B)=-int_J r dnu-int_D s dmu-M*kappa(J,D)',
 nearoptimal='Both resulting inequalities add current cut-opt gap to right hand side',
 conditional_budget='s<=L on D, pi_j(D)>=theta and r_j<=rho<Mtheta on J imply nu(J)<=L mu(D)/(Mtheta-rho)',
 positivepart='For every D subset B, int_I (M*pi_j(D)-r_j)_+ dnu <=int_D s dmu',
 thickness='J_D_alpha={j in I:r_j>0, M*pi_j(D)>=(1+alpha)r_j}; int_J r dnu <=int_D s dmu/alpha',
 thickness_denominator='int_I r dnu; r=0 rows excluded from covered demand counts; no positive-core denominator means None, not coverage 100%'),
 compute_index=dict(status='complete',command='/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python r467_numeric.py',
 arithmetic='Fraction exact maxflow, all cuts/subsets; nonoptimal swap checks only old7, expanded grid optimal cuts only; no solver or unbounded scan',seconds=time.perf_counter()-start))
(ROOT/'r467_numeric.json').write_text(json.dumps(out,default=str,indent=2)+'\n')
print(sys.executable,'Python',platform.python_version())
for z in aggregate:
 print('M',z['M'],'Lambda',z['Lambda'],'positive deficit cases',z['positive_deficit_case_count'],'coverage',z['coverage'])
print('PASS',checks,'exact assertions;',len(rows),'fixed cases;',sum(z['all_cut_joint_swap_count'] for z in rows),'joint swaps;',sum(z['positivepart_subset_checks'] for z in rows),'positivepart subset checks;',sum(z['thickness_subset_checks'] for z in rows),'thickness subset checks')
