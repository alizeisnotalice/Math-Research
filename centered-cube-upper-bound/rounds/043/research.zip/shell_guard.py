#!/usr/bin/env python3
"""Round43 exact shell/Gram and latent-parity-source guards (standard library).
All pass/fail and boundary decisions use Fraction. Decimal only displays values.
A product prior and a two-product-component latent mixture are kept distinct.
"""
from fractions import Fraction as F
from decimal import Decimal as D, localcontext
from itertools import product
from pathlib import Path
import json


def fs(q):
    return str(q.numerator) if q.denominator == 1 else f'{q.numerator}/{q.denominator}'


def dd(q):
    with localcontext() as ctx:
        ctx.prec = 90
        z = D(q.numerator)/D(q.denominator)
        return '0' if not z else format(z,'.24E')


def val(q,expression):
    out={'decimal':dd(q),'exact_expression':expression}
    if max(q.numerator.bit_length(),q.denominator.bit_length()) <= 1800:
        out['fraction']=fs(q)
    else:
        out.update(numerator_bits=q.numerator.bit_length(),denominator_bits=q.denominator.bit_length())
    return out


def zeros(N):
    return [[F(0) for _ in range(N)] for _ in range(N)]


def quadratic(H,w,g):
    return sum(w[i]*w[j]*g[i]*g[j]*H[i][j] for i in range(len(w)) for j in range(len(w)))


def partition_patterns(points,a,b):
    n=len(points[0])
    edges=[sorted({p[j]+sign*L/2 for p in points for sign in (-1,1) for L in (a,b)}) for j in range(n)]
    intervals=[list(zip(axis[:-1],axis[1:])) for axis in edges]
    patterns={}
    rectangle_count=0
    for box in product(*intervals):
        x=tuple((lo+hi)/2 for lo,hi in box)
        captured_a=tuple(i for i,p in enumerate(points) if all(abs(x[j]-p[j]) < a/2 for j in range(n)))
        captured_b=tuple(i for i,p in enumerate(points) if all(abs(x[j]-p[j]) < b/2 for j in range(n)))
        if not captured_b:
            continue
        assert set(captured_a) <= set(captured_b)
        volume=F(1)
        for lo,hi in box:
            volume*=hi-lo
        patterns[(captured_a,captured_b)]=patterns.get((captured_a,captured_b),F(0))+volume
        rectangle_count+=1
    return patterns,rectangle_count


def shell_gram_case(name,points,weights,a,b,extra_vectors=(),product_prior=False):
    N,n=len(points),len(points[0])
    assert all(w>0 for w in weights) and sum(weights)==1 and a<b
    va,vb=a**n,b**n
    vs,q=vb-va,va/vb
    patterns,rectangles=partition_patterns(points,a,b)
    Ha,Hb,Hs,Hj=(zeros(N) for _ in range(4))
    records=[]
    for (A,B),volume in patterns.items():
        S=tuple(i for i in B if i not in A)
        ma,mb=sum(weights[i] for i in A),sum(weights[i] for i in B)
        ms=mb-ma
        for matrix,indices,mass,normalizer in ((Ha,A,ma,va),(Hb,B,mb,vb),(Hs,S,ms,vs)):
            if not mass:
                continue
            coefficient=volume/(normalizer*mass)
            for i in indices:
                for j in indices:
                    matrix[i][j]+=coefficient
        if ma and ms:
            coefficient=volume*ma*ms/(vb*mb)
            difference={i:F(1)/ma if i in A else -F(1)/ms for i in B}
            for i in B:
                for j in B:
                    Hj[i][j]+=coefficient*difference[i]*difference[j]
        records.append((volume,A,B,S,ma,mb,ms))
    for i in range(N):
        for j in range(N):
            assert Hb[i][j]==q*Ha[i][j]+(1-q)*Hs[i][j]-Hj[i][j]
            assert all(H[i][j]==H[j][i] for H in (Ha,Hb,Hs,Hj))
        assert all(sum(weights[j]*H[i][j] for j in range(N))==1 for H in (Ha,Hb,Hs))
        assert sum(weights[j]*Hj[i][j] for j in range(N))==0
    # Exact formal logarithm coefficients for the true Y,C,X_b entropy chain.
    entropy=[{} for _ in range(4)]  # Hb, qHa, (1-q)Hs, H(C|Xb)
    def add_log(store,argument,coefficient):
        if not coefficient or argument==1:
            return
        assert argument>0
        store[argument]=store.get(argument,F(0))+coefficient
        if not store[argument]:
            del store[argument]
    for volume,A,B,S,ma,mb,ms in records:
        factor=volume/vb
        for store,indices,mass in ((entropy[0],B,mb),(entropy[1],A,ma),(entropy[2],S,ms)):
            if mass:
                add_log(store,mass,factor*mass)
                for i in indices:
                    add_log(store,weights[i],-factor*weights[i])
        add_log(entropy[3],mb,factor*mb)
        if ma:
            add_log(entropy[3],ma,-factor*ma)
        if ms:
            add_log(entropy[3],ms,-factor*ms)
    residual={}
    for sign,store in zip((1,-1,-1,-1),entropy):
        for argument,coefficient in store.items():
            add_log(residual,argument,sign*coefficient)
    assert not residual
    vectors=[('constant',[F(1)]*N),('alternating',[F((-1)**i) for i in range(N)]),
             ('rational_signed',[F((3*i+2)%7-3,i+2) for i in range(N)]),
             ('positive',[F(i+1,i+2) for i in range(N)])]+list(extra_vectors)
    tests=[]
    for label,g in vectors:
        norm=sum(weights[i]*g[i]**2 for i in range(N))
        assert norm>0
        Ea=Eb=Es=J=F(0)
        for volume,A,B,S,ma,mb,ms in records:
            ga,gb,gs=(sum(weights[i]*g[i] for i in indices) for indices in (A,B,S))
            if ma:
                Ea+=volume*ga**2/(va*ma)
            Eb+=volume*gb**2/(vb*mb)
            if ms:
                Es+=volume*gs**2/(vs*ms)
            if ma and ms:
                J+=volume*ma*ms/(vb*mb)*(ga/ma-gs/ms)**2
        assert [Ea,Eb,Es,J]==[quadratic(H,weights,g) for H in (Ha,Hb,Hs,Hj)]
        assert J>=0 and Ea<=norm and Eb<=norm and Es<=norm
        assert Eb==q*Ea+(1-q)*Es-J
        Fa,Fb,Fs=norm-Ea,norm-Eb,norm-Es
        assert Fb==q*Fa+(1-q)*Fs+J
        assert Eb-Ea<=(1-q)*(norm-Ea)
        if product_prior:
            assert Eb-Ea<=(1-a/b)*norm
        tests.append({'label':label,'norm_squared':fs(norm),'E_a':fs(Ea),'E_b':fs(Eb),
                      'E_shell':fs(Es),'J':fs(J),'F_a':fs(Fa),'F_b':fs(Fb),'F_shell':fs(Fs),
                      'normalized_energy_gain':fs((Eb-Ea)/norm),
                      'normalized_energy_gain_decimal':dd((Eb-Ea)/norm)})
    return {'name':name,'dimension':n,'atom_count':N,'a':fs(a),'b':fs(b),'q_volume_ratio':fs(q),
            'source_positions':[[fs(x) for x in p] for p in points],'source_weights':list(map(fs,weights)),
            'nonzero_boundary_rectangles':rectangles,'aggregated_capture_patterns':len(patterns),
            'Gram_matrix_entries_checked':N*N,'fixed_scale_mu_weighted_row_sums':'all 1; J rows all 0',
            'source_Gram_identity':'Hb=q Ha+(1-q)Hs-Hj; tested entrywise independently of direct energies',
            'product_prior':product_prior,'one_coordinate_product_gain_bound':fs(1-a/b) if product_prior else None,
            'energy_tests':tests,
            'entropy_symbolic_log_identity':{'coefficient_dictionary_sizes':[len(store) for store in entropy],
              'residual_nonzero_log_coefficients':len(residual),
              'formula':'Hb=qHa+(1-q)Hs+H(C|Xb)',
              'scope':'Exact rational coefficients of log(wj), log(ma), log(ms), log(mb); zero masses skipped. No floating logarithms and no numerical certification of Jensen entropy upper bound.'},
            'scope':'Exact full boundary rectangles; equal capture patterns aggregate exact volumes. Lebesgue integral, not quadrature. All source weights positive; g alone may be signed.',
            'status':'PASS'}


def generic_fixture(kind,n):
    count={'weighted_correlated':5,'nested':4,'unequal':3,'two_atom':2}[kind]
    points=[]
    for i in range(count):
        r=F(2*i-count+1,4)
        if kind=='nested':
            p=tuple(r/(j+1) for j in range(n))
        elif kind=='weighted_correlated':
            p=tuple((-1)**j*r+F((i+j)%2,7) for j in range(n))
        elif kind=='two_atom':
            p=tuple(F(0) if i==0 else F(j+1,3) for j in range(n))
        else:
            p=tuple(F((i+2*j)%5-2,3) for j in range(n))
        points.append(p)
    w=[F((i+1)**2,i+2) for i in range(count)]
    W=sum(w)
    return points,[q/W for q in w]


def product_fixture(N,n):
    one=[F(j+1,j+2) for j in range(N)]
    total=sum(one)
    one=[w/total for w in one]
    points=[tuple(map(F,index)) for index in product(range(N),repeat=n)]
    weights=[]
    for index in product(range(N),repeat=n):
        w=F(1)
        for j in index:
            w*=one[j]
        weights.append(w)
    return points,weights


def latent_atom_fixture(N,d):
    assert N%2==0 and N>=4
    points=[]
    g=[]
    h=[]
    for s in (0,1):
        for p in product(range(s,N,2),repeat=d):
            points.append(tuple(map(F,p)))
            g.append(F((-1)**s))
            h.append(F(1-s))
    weights=[F(1,len(points))]*len(points)
    return points,weights,[('latent_sign',g),('nonnegative_latent_indicator',h)]


def latent_boundary(N,delta):
    assert N%2==0 and N>=4 and 0<=delta<=F(1,2)
    L=2*(1+delta)
    edges=sorted({F(j)+sign*L/2 for j in range(N) for sign in (-1,1)})
    cells=[]
    lengths={(1,0):F(0),(0,1):F(0),(2,1):F(0),(1,2):F(0),(1,1):F(0)}
    for lo,hi in zip(edges[:-1],edges[1:]):
        x=(lo+hi)/2
        counts=tuple(sum(abs(x-j)<L/2 for j in range(s,N,2)) for s in (0,1))
        assert counts in lengths
        assert all(abs(x-j)!=L/2 for j in range(N))
        densities=tuple(F(count,N//2)/L for count in counts)
        lengths[counts]+=hi-lo
        cells.append((lo,hi,densities[0],densities[1],counts))
    expected={(1,0):F(1),(0,1):F(1),(2,1):(N-2)*delta,
              (1,2):(N-2)*delta,(1,1):N-1-2*N*delta+6*delta}
    assert lengths==expected
    assert sum((hi-lo)*f0 for lo,hi,f0,f1,counts in cells)==1
    assert sum((hi-lo)*f1 for lo,hi,f0,f1,counts in cells)==1
    c=1/(N*(1+delta))
    rho_one=lengths[(1,1)]*c
    rho_sqrt2=(lengths[(2,1)]+lengths[(1,2)])*c
    sqrt_upper=F(17,12)
    assert sqrt_upper**2>2 and 3-2*sqrt_upper==F(1,6)
    rho_hat=rho_one+rho_sqrt2*sqrt_upper
    assert rho_hat==1-(1+(N-2)*delta/6)/(N*(1+delta))
    return cells,lengths,rho_one,rho_sqrt2,rho_hat


def latent_dp(N,d,delta):
    # Counts are integer coefficients of a likelihood-ratio walk. No source enumeration.
    assert N%2==0 and N>=4 and 0<=delta<=F(1,2)
    u,v=delta.numerator,delta.denominator
    denominator=N*(v+u)
    neutral=2*v+(N-3)*(v-2*u)
    plus=2*u*(N-2)
    minus=u*(N-2)
    exclusive=v
    assert neutral+plus+minus+exclusive==denominator
    walk={0:1}
    for _ in range(d):
        following={}
        for k,weight in walk.items():
            for step,multiplicity in ((0,neutral),(1,plus),(-1,minus)):
                if multiplicity:
                    following[k+step]=following.get(k+step,0)+weight*multiplicity
        walk=following
    scale=denominator**d
    common_mass=F(sum(walk.values()),scale)
    pure=1-common_mass
    Eg=Eh=mean_h=F(0)
    Eg=pure
    Eh=mean_h=pure/2
    for k,weight in walk.items():
        R=F(2**k) if k>=0 else F(1,2**(-k))
        posterior_g=(R-1)/(R+1)
        posterior_h=R/(R+1)
        Eg+=F(weight,scale)*posterior_g**2
        mixed_probability=F(weight+walk.get(-k,0),2*scale)
        Eh+=mixed_probability*posterior_h**2
        mean_h+=mixed_probability*posterior_h
    assert mean_h==F(1,2) and Eh==(1+Eg)/4 and 0<=Eg<=1
    return Eg,Eh,len(walk),neutral,plus,minus,exclusive,denominator


def latent_enumeration(N,d):
    delta=F(1,2) if d==1 else F(1,d)
    def integrate(cells):
        Eg=Eh=mass=mean_g=F(0)
        for states in product(cells,repeat=d):
            volume,f0,f1=F(1),F(1),F(1)
            for lo,hi,c0,c1,counts in states:
                volume*=hi-lo
                f0*=c0
                f1*=c1
            if not f0+f1:
                continue
            Eg+=volume*(f0-f1)**2/(2*(f0+f1))
            Eh+=volume*f0**2/(2*(f0+f1))
            mass+=volume*(f0+f1)/2
            mean_g+=volume*(f0-f1)/2
        assert mass==1 and mean_g==0 and Eh==(1+Eg)/4
        return Eg,Eh
    a_cells,*_=latent_boundary(N,F(0))
    b_cells,*_=latent_boundary(N,delta)
    Ea,Ha=integrate(a_cells)
    Eb,Hb=integrate(b_cells)
    da,dha,*_=latent_dp(N,d,F(0))
    db,dhb,*_=latent_dp(N,d,delta)
    assert Ea==da==1-(1-F(1,N))**d and Ha==dha
    assert Eb==db and Hb==dhb
    return {'N':N,'dimension':d,'delta':fs(delta),'a_product_states':len(a_cells)**d,
            'b_product_states':len(b_cells)**d,'E_a_g':fs(Ea),'E_b_g':fs(Eb),
            'E_a_h':fs(Ha),'E_b_h':fs(Hb),'signed_gain':fs(Eb-Ea),
            'signed_gain_decimal':dd(Eb-Ea),'positive_normalized_gain':fs(2*(Hb-Ha)),
            'scope':'Full product of actual conditional-density boundary cells; latent mixture joint posterior, not a product prior posterior. Direct g and nonnegative h integrals match DP separately.',
            'status':'PASS'}


def latent_power_case(N,d,delta,label,do_dp):
    c=1/(N*(1+delta))
    rho_hat=1-(1+(N-2)*delta/6)/(N*(1+delta))
    assert 0<=rho_hat<=1
    Ea=1-(1-F(1,N))**d
    U=1-(1+delta)**(-d)
    certified_gain=(1-F(1,N))**d-rho_hat**d
    out={'N':N,'dimension':d,'delta':fs(delta),'family':label,
         'source_atom_count_expression':f'2*({N}//2)^{d}',
         'E_a_g':val(Ea,'1-(1-1/N)^d'),'rho_affinity_rational_upper':fs(rho_hat),
         'signed_gain_affinity_certificate':val(certified_gain,'(1-1/N)^d-rhohat^d'),
         'positive_normalized_gain_affinity_certificate':val(certified_gain/2,'half of signed certificate'),
         'general_shell_upper_U':val(U,'1-(1+delta)^(-d)'),
         'product_prior_bound_for_comparison':fs(delta/(1+delta)),
         'scope':'Conditional product compression for a correlated two-component prior; source atoms are not explicitly enumerated at large N,d. A negative affinity certificate is inconclusive, not a negative actual gain.',
         'status':'PASS'}
    if do_dp:
        Eb,Hb,states,*_=latent_dp(N,d,delta)
        Ha=(1+Ea)/4
        gain=Eb-Ea
        positive_gain=2*(Hb-Ha)
        assert positive_gain==gain/2
        assert certified_gain<=gain<=U
        out.update(E_b_g=val(Eb,'exact integer likelihood-walk DP'),
                   E_b_h=val(Hb,'direct nonnegative posterior DP'),
                   signed_gain=val(gain,'E_b(g)-E_a(g)'),
                   positive_normalized_gain=val(positive_gain,'[E_b(h)-E_a(h)]/norm(h)^2'),
                   likelihood_walk_state_count=states,
                   exceeds_product_bound=(gain>delta/(1+delta)))
    return out


def constant_certificate(d):
    N=256*d
    delta=F(1,d)
    rho_hat=1-(1+(N-2)*delta/6)/(N*(1+delta))
    x=d*(1-rho_hat)
    Ea=1-(1-F(1,N))**d
    Eb_lower=1-rho_hat**d
    assert x>=F(1,10)
    assert Eb_lower>=x/(1+x)>=F(1,11)
    assert Ea<=F(d,N)==F(1,256)
    gap_lower=Eb_lower-Ea
    assert gap_lower>=F(1,11)-F(1,256)==F(245,2816)>F(1,12)
    assert gap_lower/2>F(1,24)
    return {'dimension':d,'N':N,'delta':fs(delta),'d_times_affinity_deficit':fs(x),
            'E_a':val(Ea,'<=1/256'),'E_b_rational_lower':val(Eb_lower,'>=1/11'),
            'signed_gain_lower':val(gap_lower,'>=245/2816>1/12'),
            'nonnegative_normalized_gain_lower':val(gap_lower/2,'>=245/5632>1/24'),
            'scope':'Exact parameter guards for the proved finite latent-source certificate, not a numerical asymptotic proof.', 'status':'PASS'}



def product_matching_lower_case(N,d):
    delta=F(1,d)
    def direct(delta):
        cells,*_=latent_boundary(N,delta)
        return sum((hi-lo)*(f0-f1)**2/(2*(f0+f1)) for lo,hi,f0,f1,counts in cells)
    Ea,Eb=direct(F(0)),direct(delta)
    assert Ea==F(1,N)
    gain=Eb-Ea
    p=1/(1+delta)
    assert gain==delta*(N-5)/(3*N*(1+delta))
    assert gain/(1-p)==F(N-5,3*N)
    return {'N':N,'dimension':d,'delta':fs(delta),'E_a':fs(Ea),'E_b':fs(Eb),
            'actual_product_prior_gain':fs(gain),'product_upper_1_minus_p':fs(1-p),
            'gain_divided_by_1_minus_p':fs(gain/(1-p)),
            'scope':'Positive uniform alternating 1D grid times point masses in the remaining coordinates. Direct 1D boundary integral; transverse observation volumes cancel exactly. Demonstrates the analytic product-class matching order, not a fit.',
            'status':'PASS'}


def general_scale_guard(d,delta,label):
    U=1-(1+delta)**(-d)
    rational_limit_lower=1-(1-delta/(6*(1+delta)))**d
    minimum=min(d*delta,F(1))
    assert U/6<=rational_limit_lower<=U
    assert minimum/12<=U/6 and U<=minimum
    row=latent_power_case(256*d,d,delta,label,True)
    row.update(rational_N_to_infinity_lower=val(rational_limit_lower,'1-[1-delta/(6(1+delta))]^d'),
               rational_worst_prior_lower_U_over_6=val(U/6,'U/6'),
               rational_worst_prior_coarse_lower=fs(minimum/12),
               positive_cone_worst_prior_coarse_lower=fs(minimum/24),
               universal_coarse_upper=fs(minimum),
               limiting_bound_scope='Worst-prior limiting lower, not automatically asserted for this finite N; finite N actual DP is recorded separately.')
    return row



def finite_grid_winner_case(kind,n):
    points,w=generic_fixture(kind,n)
    scales=(F(2),F(9,4),F(3))
    thresholds=(F(1,8),F(1,4),F(1,2))
    edges=[sorted({p[j]+sign*L/2 for p in points for sign in (-1,1) for L in scales}) for j in range(n)]
    rectangles=winner_later=0
    first_later={lam:0 for lam in thresholds}
    initial_volume={lam:F(0) for lam in thresholds}
    winner_initial_volume={lam:F(0) for lam in thresholds}
    for box in product(*[list(zip(e[:-1],e[1:])) for e in edges]):
        x=tuple((lo+hi)/2 for lo,hi in box)
        volume=F(1)
        for lo,hi in box:
            volume*=hi-lo
        masses=[sum(w[i] for i,p in enumerate(points) if all(abs(x[j]-p[j])<L/2 for j in range(n))) for L in scales]
        averages=[mass/L**n for mass,L in zip(masses,scales)]
        if not max(masses):
            continue
        rectangles+=1
        winner=averages.index(max(averages))
        if winner:
            ma,mb=masses[winner-1],masses[winner]
            q=(scales[winner-1]/scales[winner])**n
            assert ma/mb<=q and mb-ma>=(1-q)*mb
            winner_later+=1
        for lam in thresholds:
            if averages[winner]>lam and winner==0:
                winner_initial_volume[lam]+=volume
            hits=[j for j,A in enumerate(averages) if A>lam]
            if hits:
                first=hits[0]
                if first:
                    ma,mb=masses[first-1],masses[first]
                    q=(scales[first-1]/scales[first])**n
                    assert ma/mb<q and mb-ma>(1-q)*mb
                    first_later[lam]+=1
                else:
                    initial_volume[lam]+=volume
    for lam in thresholds:
        assert lam*initial_volume[lam]<=1 and lam*winner_initial_volume[lam]<=1
    return {'source_family':kind,'dimension':n,'scale_grid':list(map(fs,scales)),
            'nonzero_rectangles':rectangles,'later_true_grid_winners_checked':winner_later,
            'thresholds':[{'lambda':fs(lam),'later_first_hits_checked':first_later[lam],
                           'initial_first_hit_fixed_scale_fee':fs(lam*initial_volume[lam]),
                           'initial_winner_fixed_scale_fee':fs(lam*winner_initial_volume[lam])} for lam in thresholds],
            'scope':'Actual finite scale-grid winner and first threshold, earliest ties. This is not the all-scale or continuous-window maximum. Index zero is separately paid by the fixed initial-scale bound, not a shell fraction.',
            'status':'PASS'}


def main():
    generic=[]
    for kind in ('weighted_correlated','nested','unequal','two_atom'):
        for n in (1,2,3):
            points,w=generic_fixture(kind,n)
            for delta in (F(1,2),F(1,8)):
                generic.append(shell_gram_case(kind,points,w,F(2),2*(1+delta)))
    for N,n in ((2,1),(2,2),(2,3),(3,1),(3,2),(3,3),(6,1),(6,2)):
        points,w=product_fixture(N,n)
        delta=F(1,2) if n==1 else F(1,n)
        generic.append(shell_gram_case(f'actual_product_grid_N{N}',points,w,F(2),2*(1+delta),product_prior=True))
    for N,d,delta in ((6,1,F(1,2)),(6,2,F(1,2)),(6,3,F(1,3)),(8,2,F(1,8))):
        points,w,extra=latent_atom_fixture(N,d)
        row=shell_gram_case(f'latent_parity_N{N}',points,w,F(2),2*(1+delta),extra)
        eg,eh,*_=latent_dp(N,d,delta)
        indexed={test['label']:test for test in row['energy_tests']}
        assert F(indexed['latent_sign']['E_b'])==eg
        assert F(indexed['nonnegative_latent_indicator']['E_b'])==eh
        assert F(indexed['latent_sign']['E_a'])==1-(1-F(1,N))**d
        row['actual_atomic_Gram_matches_conditional_DP']=True
        generic.append(row)
    boundaries=[]
    for N in (4,6,8,16,32):
        for delta in (F(0),F(1,2),F(1,3),F(1,8)):
            cells,lengths,rone,rsqrt,rhat=latent_boundary(N,delta)
            boundaries.append({'N':N,'delta':fs(delta),
                               'cells':[{'interval':[fs(lo),fs(hi)],'f0':fs(f0),'f1':fs(f1),'counts':list(counts)} for lo,hi,f0,f1,counts in cells],
                               'category_lengths':{str(k):fs(v) for k,v in lengths.items()},
                               'affinity_exact_sqrt2_coefficients':[fs(rone),fs(rsqrt)],'affinity_rational_upper':fs(rhat),
                               'scope':'Actual complete conditional-density boundary partition; rho=rone+rsqrt*sqrt(2).','status':'PASS'})
    enumerated=[latent_enumeration(N,d) for N in (4,6,8,16,32) for d in (2,3)]
    enumerated += [latent_enumeration(N,4) for N in (4,6,8)]
    dp=[]
    for d in (2,4,8,16,32,64):
        for label,N in (('fixed_N6',6),('fixed_N8',8),('fixed_N16',16),('N_equals_256d',256*d),('N_equals_max6_2d_squared',max(6,2*d*d))):
            dp.append(latent_power_case(N,d,F(1,d),label,True))
    rational_large=[latent_power_case(N,d,F(1,d),label,False) for d in (128,512)
                    for label,N in (('N_equals_256d',256*d),('N_equals_2d_squared',2*d*d),('N_equals_16d',16*d))]
    finite=[constant_certificate(d) for d in (2,4,8,16,32,64,128,512)]
    product_vertex=[]
    for d in (1,2,3,8,32,128,512):
        p=F(2,3) if d==1 else F(d,d+1)
        gains=[(1-p)**k if k else F(0) for k in range(d+1)]
        assert max(gains)==1-p
        product_vertex.append({'dimension':d,'p':fs(p),'vertex_zero_counts_checked':d+1,
                               'largest_vertex_gain':fs(max(gains)),'scope':'Exact spectral-polynomial vertex guard for the analytic product-prior bound.','status':'PASS'})
    product_lower=[product_matching_lower_case(N,d) for N in (6,16,64,256) for d in (2,8,32,128,512)]
    general=[]
    for d in (1,2,8,32,128):
        for label,delta in (('fixed_half',F(1,2)),('fixed_eighth',F(1,8)),('fixed_32nd',F(1,32)),
                            ('inverse_dimension',F(1,d)),('inverse_dimension_squared',F(1,d*d))):
            if delta<=F(1,2):
                general.append(general_scale_guard(d,delta,label))
    grid_winner=[finite_grid_winner_case(kind,n) for kind in ('unequal','two_atom') for n in (1,2)]
    summary={'status':'PASS','executed_case_entries':len(generic)+len(boundaries)+len(enumerated)+len(dp)+len(rational_large)+len(finite)+len(product_vertex)+len(product_lower)+len(general)+len(grid_winner),
             'finite_scale_grid_winner_cases':len(grid_winner),
             'finite_scale_grid_later_winner_cells_checked':sum(row['later_true_grid_winners_checked'] for row in grid_winner),
             'finite_scale_grid_later_first_hit_cells_checked':sum(item['later_first_hits_checked'] for row in grid_winner for item in row['thresholds']),
             'product_matching_lower_cases':len(product_lower),'general_scale_latent_DP_cases':len(general),
             'actual_atom_Gram_conditional_DP_crosschecks':sum(row.get('actual_atomic_Gram_matches_conditional_DP',False) for row in generic),
             'generic_exact_cell_Gram_cases':len(generic),'generic_boundary_rectangles':sum(row['nonzero_boundary_rectangles'] for row in generic),
             'generic_capture_patterns':sum(row['aggregated_capture_patterns'] for row in generic),
             'Gram_matrix_entries_checked':sum(row['Gram_matrix_entries_checked'] for row in generic),
             'symbolic_entropy_log_coefficient_cases':len(generic),
             'symbolic_entropy_capture_patterns':sum(row['aggregated_capture_patterns'] for row in generic),
             'total_latent_DP_cases_including_general_delta':len(dp)+len(general),
             'direct_energy_vector_tests':sum(len(row['energy_tests']) for row in generic),
             'actual_product_Gram_cases':sum(row['product_prior'] for row in generic),
             'latent_1D_boundary_cases':len(boundaries),'latent_1D_boundary_cells':sum(len(row['cells']) for row in boundaries),
             'latent_low_dimensional_full_tensor_cases':len(enumerated),
             'latent_a_product_states':sum(row['a_product_states'] for row in enumerated),
             'latent_b_product_states':sum(row['b_product_states'] for row in enumerated),
             'latent_integer_likelihood_DP_cases':len(dp),'large_rational_affinity_cases':len(rational_large),
             'finite_constant_cases':len(finite),'product_spectral_vertex_cases':len(product_vertex),
             'product_vertex_zero_counts':sum(row['vertex_zero_counts_checked'] for row in product_vertex),
             'low_dimension_latent_signed_gain_range_decimal':[dd(min(F(row['signed_gain']) for row in enumerated)),dd(max(F(row['signed_gain']) for row in enumerated))],
             'DP_cases_exceeding_product_prior_bound':sum(row['exceeds_product_bound'] for row in dp),
             'fine_N256d_actual_signed_gain_range_decimal':[min((row['signed_gain']['decimal'] for row in dp if row['family']=='N_equals_256d'),key=D),max((row['signed_gain']['decimal'] for row in dp if row['family']=='N_equals_256d'),key=D)],
             'fine_N256d_actual_positive_normalized_gain_range_decimal':[min((row['positive_normalized_gain']['decimal'] for row in dp if row['family']=='N_equals_256d'),key=D),max((row['positive_normalized_gain']['decimal'] for row in dp if row['family']=='N_equals_256d'),key=D)],
             'finite_signed_gain_lower':'245/2816 > 1/12','finite_nonnegative_normalized_gain_lower':'245/5632 > 1/24',
             'scope':'Exact shell and source-Gram identities, actual low-dimensional correlated sources, and analytic compression guards. No numerical fit, no arbitrary-prior tensor factorization, no weak-endpoint theorem.'}
    result={'definition':'E_L=||B_Lg||^2 for a probability prior; F_L=norm(g)^2-E_L; q=(a/b)^dimension.',
            'shell_identity':'E_b=q E_a+(1-q)E_shell-J, J>=0; all denominator-zero terms vanish.',
            'sqrt2_guard':'17/12 squared is >2, so 3-2sqrt(2)>1/6; only rational upper affinity is used in pass/fail.',
            'nonnegative_test':'h=1_{S0}, norm(h)^2=1/2; its posterior energy is checked directly, then against (1+E_g)/4.',
            'summary':summary,'generic_exact_boundary_and_Gram':generic,'latent_1D_full_boundary':boundaries,
            'latent_low_dimensional_full_enumeration':enumerated,'latent_integer_likelihood_DP':dp,
            'large_rational_affinity_only':rational_large,'finite_constant_guard':finite,
            'product_spectral_vertex_guard':product_vertex,'product_matching_lower_guard':product_lower,
            'general_scale_and_positive_cone_guard':general,'finite_scale_grid_winner_shell_guard':grid_winner}
    Path(__file__).with_name('results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(summary,indent=2))


if __name__=='__main__':
    main()
