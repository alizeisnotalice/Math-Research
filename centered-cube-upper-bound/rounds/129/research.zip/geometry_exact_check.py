"""Finite rational checks of SC1 and its tail-cell repair; not a general upper bound."""
from fractions import Fraction as F
import json

def case(m):
    rs=[F(1,2**i) for i in range(1,m+1)]
    bands=[]
    reward=F(0)
    for r in rs:
        width=r/2
        for sign in (-1,1):
            lo,hi=(3/(4*r),1/r) if sign==1 else (-1/r,-3/(4*r))
            assert width*(2/r)==1
            assert width*(hi-lo)==F(1,8)
            # Bound weighted 2D convolution by the maximal horizontal overlap.
            assert 4*width*(2*r)/(2*r)**2==1
            bands.append((lo-r,hi+r))
            reward+=4*width*(hi-lo)
    bands.sort()
    gaps=[bands[j+1][0]-bands[j][1] for j in range(len(bands)-1)]
    assert min(gaps)>0
    assert reward==m
    return {'m':m,'coarse_optimum':'4','refined_reward':str(reward),
            'support_band_count':len(bands),'minimum_separation':str(min(gaps)),
            'full_source_cap':'<=1 via disjoint source supports', 'arithmetic':'Fraction'}

if __name__=='__main__':
    stages={'explore':[1,2,4], 'pressure':[3,5,8,16], 'expand':[32,64,128,256]}
    print(json.dumps({'scope':'finite exact checks; symbolic proof is separate; no general root estimate',
          'stages':{k:[case(m) for m in ms] for k,ms in stages.items()}},indent=2))
