# R276 independent input-kernel fluctuation and actual-positive screening

**Verdict: PASS.** There is a rigorous, uniformly adaptive input-kernel tail with polynomial dimension cost. Applied directly to the original positive mother integral, it pays its fluctuation-exception subbranch linearly in the actual soft source mass. The complementary mean-driven traffic is not paid by this argument. This screen precedes reading any R276 author proof.

## 1. Fixed-source input-kernel theorem

Fix `n>=1`, `0<a<=b<=2a` and arbitrary fixed `y,u,v`. Write `p_{s,L}(x)=P_{s,L}(x-y)` and

`Delta_A(x)=sum_i [1{|x_i-v_i|<=A/2}-1{|x_i-u_i|<=A/2}]`,

`mu(s,L,A;y,u,v)=integral p_{s,L}(x) Delta_A(x) dx`.

Here `0<=s<=1` and `a<=L,A<=b`. Then, for every `T>=0`,

`integral sup_{s,L,A} p_{s,L}(x) 1{|Delta_A(x)-mu(s,L,A)|>T} dx`

`<= U_n(T):=2e^2 n^2(n+1) exp(-((T-6)_+)^2/(2n)).`             (I1)

One may also take the minimum with the crude envelope mass `e^2 n(n+1)`. The requested looser coefficient `2e^2 n(n+2)^2` is consequently safe. No source-law independence is assumed. Only the product receiver law of one fixed input kernel is used for concentration.

### Proof, including the discontinuities

Let `f_s=(1-s)h+s phi`. Both h and phi are probability densities bounded by 1 and radially nonincreasing in one dimension.

**Soft menu:** Partition [0,1] into the n intervals `[(j-1)/n,j/n]`. Use the auxiliary node `s'_j=j/(n+1)`. For every s in that interval,

`f_s <= (1+1/n) f_{s'_j}`

coefficientwise on h and phi, since `(1+1/n)s'_j=j/n` and `(1+1/n)(1-s'_j)>=1-s`. This covers s=0 and s=1. Tensor domination costs `c_n=(1+1/n)^n<e`. Also `|s-s'_j|<=1/n`, so the one-dimensional total variation between these two densities is at most 1/n. These nodes are analytic upper bounds; no new FIRST or classification cap is asserted for them.

**Scale menu:** Round L upward on a gamma-grid, `gamma=1+1/n`, including a and the truncated endpoint b. There are at most n+1 nodes because `gamma^n>=2`. Radial monotonicity gives `p_{s,L}<=gamma^n p_{s,L'}`. In one dimension, `p_L<=r p_{L'}`, `r=L'/L<=gamma`, and normalization implies total variation at most `1-1/r<=1/n`.

Combining the soft and scale changes, the product kernel is dominated by `c_n^2<e^2` times the corresponding fixed grid kernel. A single coordinate contribution to Delta has range [-1,1]. Hence its expectation changes by at most twice its one-dimensional total variation. Summing the two changes over n coordinates gives, uniformly in A,

`|mu(s,L,A)-mu(s'_j,L',A)|<=4`.                         (I2)

This uses additive means; it does not use the full n-dimensional total variation, which could be order one.

**A menu with brackets:** Take at most n grid intervals in [a,b], each of width at most a/n. Separate `V_A=sum 1_v` and `U_A=sum 1_u`, both monotone in A. For A between consecutive endpoints, bracket `Delta_A` between `V_left-U_right` and `V_right-U_left`. Since each fixed grid kernel has coordinate density at most 1/a, the mean gap of either bracket is at most 2 (in fact at most 1 if the two subinterval widths are added). No pointwise bound on the number of crossings is required.

Each bracket, under a fixed product kernel, is a sum of n independent variables in [-1,1]. Its centered one-sided tail is at most `exp(-t^2/(2n))`: the second derivative of each centered log-mgf is a tilted variance at most 1, so Chernoff gives this estimate. A union over two brackets and at most n A intervals costs `2n`. A union over n soft and at most n+1 scale nodes, together with kernel domination and (I2), proves (I1), retaining the safe total bias 6. For T<=6 the same displayed bound exceeds the crude integrated kernel envelope and is valid trivially.

The mean is the sum of one-dimensional interval probabilities. Counts are right-continuous in A; means are continuous in all parameters; the original closed endpoints are retained by the brackets. Thus a countable dense parameter family with endpoint limits gives a measurable envelope. No random/source-dependent scale grid is introduced.

## 2. Actual original posterior qualification

Necessary historical sources were read narrowly, without reading an R276 author proof:

- R117 `joint_geometry.md`, JG1–2: fixed `(omega,V,j,y)` constructs the full weights, carrier, degrees, and posterior before choosing x; the process exists throughout the deterministic interval `tau_j=a/c_j <=t<=b c_j`.
- R223 frozen `negative_contract.md`, NC1–4, explicitly NC3: **fixed `(omega,V,j,y,t)` makes the complete posterior product independent of x and hard z**. Terminal G/B, selected g, capture, history, suffix, and high are still x-dependent in the actual integral. They may be removed in a positive upper bound, not identified with a fixed posterior restriction.
- R117 JG6: on the original valid receiver domain, `h_{R(x)}*nu_V<=4 lambda`, `q>=3lambda/4`, so the hard-source factor after division by q is at most 16/3.
- R237 frozen `source_ledger.md`, SL1/SL3: `beta_V<=alpha_V=mu_hi|V`, disjoint source leaves and probability seed averaging give `W_beta=E sum_V ||beta_V||<=W_hi<=||f||_1`. The proof here uses this beta bound only. It does not use or require `nu<=beta`.

## 3. Actual exceptional positive traffic is paid

Construct the exception directly in the original positive integrand:

`Exc_T={|Delta_{A(x)}(x;u,v)-mu(s(x),L(x),A(x);y,u,v)|>T}`,

where A(x) is any original scale in [a,b]. Using a supremum over A also covers the union of the two moving target core-count exceptions with no extra factor. This defines a nonnegative subbranch; the unchanged positive complement and all old signed negative terms remain in place.

Starting from the NC4 positive term with its outside factor `2 Lambda`, use the following order:

1. Bound the positive score by n. Remove terminal G/B and other bounded positive pair/history/capture gates. Retain the actual receiver domain long enough to integrate the independent hard-source slot. The exception does not depend on hard z.
2. Apply the original hardcap **on that original domain**, giving `4lambda/q<=16/3`. Do not assert this cap on the subsequently enlarged receiver domain.
3. Now enlarge x to all space and actual soft/scale parameters to the supremum in (I1). For fixed `(omega,V,j,y,t,u,v)`, this is exactly the fixed-source theorem, since the full pair posterior is independent of x. Its two full masses integrate to at most one. At zero-degree rows set the contribution to zero, without constructing a posterior there.
4. Enlarge only the positive clock to `[a/c_j,b c_j]` when nonempty. No remaining terminal g, classifier, or receiver-dependent time restriction is treated as fixed; it has been removed positively.

Let `ell=log(b/a)`, `gamma=1+1/n`, `c_j=gamma^{-j}`, and

`S_n(ell)=sum_{j>=0} (ell-2j log gamma)_+`.

This is the entire paid clock multiplicity. Monotonicity of the summand gives

`S_n(ell)<=ell+ell^2/(4 log gamma)<=log2(1+n/4)<=n`,

using `gamma^n>=2` and `(5/4)log2<1`. Empty bands contribute zero. There is no uncharged j count, and no receiver-leaf disjointness is required for the resulting source-mass sum.

Therefore the exceptional **original full positive** contribution satisfies

`P_exception <= (32 Lambda/3) n S_n(ell) U_n(T) W_beta`

`<= (64 Lambda e^2/3) n^4(n+1) exp(-((T-6)_+)^2/(2n)) W_beta`

`<= (128 Lambda e^2/3) n^5 exp(-((T-6)_+)^2/(2n)) W_beta`.     (I3)

These constants include the original `2 Lambda` exactly once, the hardcap ratio 16/3, the raw score n, the full time-band sum, and both analytic parameter menus. They do not multiply a normalized pair by another degree denominator. Source measures and the full posterior have not been rebuilt.

For example, for `0<epsilon<=1`, choosing

`T=6+sqrt(2n log[(128 Lambda e^2/(3 epsilon)) n^5])`

gives `P_exception<=epsilon W_beta<=epsilon ||f||_1`. Thus this is a genuine paid fluctuation subbranch at `T=O(sqrt(n log(n+2)))` for fixed epsilon, not only a receiver-measure statement. It does not prove that the remaining positive traffic is controlled: the exact input-kernel mean and its relation to score/net windows still remain. No new negative credit or general root-order closure is claimed. This proof must be applied to the original positive mother integrand, not retroactively to an arbitrary signed or previously enlarged source expression lacking its original qualifiers.

## 4. Actual local arithmetic evidence

A standard-library Python run passed **711 exact Fraction assertions** checking the coefficientwise soft domination, node proximity, and exact gamma-grid cardinality at n in {1,2,8,64}. This is finite algebra evidence, not a proof of concentration or an original FULL instance. The analytic proof above establishes the bounds. Reproduce:

```python
from fractions import Fraction as F
checks=0
for n in (1,2,8,64):
    for j in range(1,n+1):
        lo,hi=F(j-1,n),F(j,n)
        sp,c=F(j,n+1),F(n+1,n)
        for s in (lo,(lo+hi)/2,hi):
            assert c*(1-sp)>=1-s
            assert c*sp>=s
            assert abs(s-sp)<=F(1,n)
            checks+=3
    gamma=F(n+1,n)
    assert gamma**n>=2
    checks+=1
    for ratio in (F(1),F(5,4),F(3,2),F(2)):
        nodes=[F(1)]
        while nodes[-1]<ratio:
            nodes.append(min(ratio,nodes[-1]*gamma))
        assert len(nodes)<=n+1
        assert all(nodes[k+1]/nodes[k]<=gamma
                   for k in range(len(nodes)-1))
        checks+=2
print('PASS',checks,'exact Fraction soft-dominance/menu-size assertions')
```

## 5. Additional primary-source check and parent's conservative threshold

After the statement proof above was complete, the exact original R112 source qualification was independently read at `/Users/zhengzhihao/Desktop/T/output/centered_cube_round112_20261014/proof.tex.txt:508` and `:546`. It explicitly states that terminal V are disjoint, `alpha_V=mu_hi,omega|V`, and that the input `beta_V<=alpha_V` is pre-frozen. The intervening J1 explicitly gives `s(x) in [0,1]`, common q in `[3lambda/4,lambda]`, and the actual hardcap on E. Thus the mass charge in (I3) is to this same terminal-leaf soft source collection, without an ancestor or extra j multiplication of W_beta. No comparison between nu and beta is used.

The parent's looser dimension-free prefactor `C0=512 Lambda e^2/3` is safe relative to (I3). For any epsilon>0, the choice

`Theta_epsilon=6+sqrt(2n[5log(n+2)+log_+(C0/epsilon)])`

therefore gives `P_exception<=epsilon W_beta<=epsilon ||f||_1`. For epsilon<=C0 this follows by the exponential factor epsilon/C0 and `n^5/(n+2)^5<=1`; for epsilon>C0 the same bound follows from `C0<=epsilon`. There is no epsilon X term in this particular direct source payment. The full complementary mean-driven positive traffic and old negative ledger remain unchanged.
