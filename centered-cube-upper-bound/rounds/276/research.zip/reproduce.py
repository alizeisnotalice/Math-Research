#!/usr/bin/env python3
from pathlib import Path
import argparse,hashlib,json,os,re,subprocess,sys,tempfile
p=argparse.ArgumentParser();p.add_argument('--check-only',action='store_true');args=p.parse_args();b=Path(__file__).resolve().parent
manifest=json.loads((b/'manifest.json').read_text())
for name,sha in manifest['files'].items():assert hashlib.sha256((b/name).read_bytes()).hexdigest()==sha,name
print('PASS manifest',len(manifest['files']),flush=True)
if args.check_only:sys.exit(0)
try:import mpmath
except ImportError:
 sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
 import mpmath
env=os.environ.copy();env['PYTHONPATH']=str(Path(mpmath.__file__).parent.parent)+os.pathsep+env.get('PYTHONPATH','')
with tempfile.TemporaryDirectory(prefix='r276-replay-') as tmp:
 for stem in ['hard_checks','input_checks']:
  dest=Path(tmp)/(stem+'.json')
  subprocess.run([sys.executable,str(b/(stem+'.py')),'--output',str(dest)],env=env,check=True)
  assert dest.read_bytes()==(b/(stem+'.json')).read_bytes(),stem+' JSON mismatch'
  print('PASS byte-identical',stem,flush=True)
 for name in ['screen.md','numeric_audit.md']:
  codes=re.findall(r'```python\n(.*?)```',(b/name).read_text(),re.S);assert codes,name
  for code in codes:
   # Rebind only the auditor's two input paths to byte-identical archived JSON.
   code=code.replace('/tmp/r276_numeric.json',str(b/'hard_checks.json')).replace('/tmp/r276_input_numeric.json',str(b/'input_checks.json'))
   subprocess.run([sys.executable,'-c',code],env=env,check=True)
 subprocess.run([sys.executable,str(b/'auxiliary_checks.py')],env=env,check=True)
print('PASS full reproduction; finite evidence only')
