# R276 actual-input cover and mean audit

Executed with bundled Python3.12.14 and mpmath1.3.0 vendor. Replay: `PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor /Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 /tmp/r276_input_numeric.py --output /tmp/r276_input_numeric.json`.

Twelve physical-input models, stages4/4/4, n2/8,32/64,128/512. All194 finite pointwise density comparisons per precision passed the gamma² domination screen. Soft0,1,tiny positive values, cell boundaries, hard endpoints±1e−20, scale-ratio endpoints, homogeneous/alternating coordinates, and source distances beyond b1 are included.

The74 interval probability evaluations per precision have exact hard overlap terms and actual E3 soft quadrature split at core boundaries, independently matched to E4 primitives. All12 additive mean drift checks are below their displayed2nTV bound and4; largest actual drift in this menu is 0.7916786765591091. The rational TV upper bound is |s−r|+1−L/Lupper, not an empirically estimated posterior TV.

Orientation is the parent convention Delta=kappa(v)−kappa(u), mu=sum F_A(v)−F_A(u). This is opposite the earlier R276 hard-receiver suite, which explicitly used u−v. Sign must be reversed before comparing means across the two files; variance and centered absolute fluctuation comparisons are orientation symmetric.

All12 radial mean identities pass with D_r=#|u_i|<=r−#|v_i|<=r and mu=−sum D_mid[F_A(left)−F_A(right)]. b1 is inserted in the radial partition. For n2,s1,L=A1,u0,v2, F_A(1)=.18623119189787218 and F_A(2)=.04368185179717205, so the mean contribution from radii1..2 is−.28509868020140026; the full mean is−.92355292837056548. Thus truncating the soft mean at b would drop a genuine contribution. Beyond the last source radius D=0, while F at that last radius stays positive and is retained.

The207 numeric fields agree at actual scaled40/70 difference 5.073084197461337403452326489422497025642889264889061804430533600000000000000000000001976997700527424e-39. These are ordinary arithmetic and finite inequalities, not outward interval certificates or a proof of universal all-soft/all-scale cover. No FULL/history/FIRST/high qualification or dimension-order result is claimed.

Source SHA256: df9ea9151b315730cfe66d4b71249a0b5ac5a610416a9e2a380fadf3c5ecb9eb

JSON SHA256: c9e9bd9d297d60e9458692336f1fc2f96d3782ecfa7cb75772a750c5309ec8a7
