# R276 independent bounded numerical audit

## N1. Scope and file binding

Reviewed the full code, JSON and execution notes of both numerical suites. I did not repeat their twelve-law full convolutions or their complete 40/70-digit input menu. The parent replay files exist and are byte-for-byte identical to the corresponding author JSON. The independent compact checks in N5 were actually executed by this reviewer.

| File | SHA256 |
|---|---|
| `/tmp/r276_numeric.py` | `35133a40fd564d72e80a2e449b8e6fd30e5fcb5d5a28278338cb05b2b88edeb6` |
| `/tmp/r276_numeric.json` | `47b25b424657e85f53a480f33ad9f012ae5e26c7a5684b88aafb0aea313fbd55` |
| `/tmp/r276_numeric.md` | `ea25889bab789cf0472e30e6ff54055ca029441c95d33d4d32c11d214d7f0e59` |
| `/tmp/r276_input_numeric.py` | `df9ea9151b315730cfe66d4b71249a0b5ac5a610416a9e2a380fadf3c5ecb9eb` |
| `/tmp/r276_input_numeric.json` | `c9e9bd9d297d60e9458692336f1fc2f96d3782ecfa7cb75772a750c5309ec8a7` |
| `/tmp/r276_input_numeric.md` | `402e9ca3d1702688a733fd59ea49fca03e70e50fcc51941f50f5e0def2d784f8` |

Each JSON script_sha256 matches its actual reviewed source. The parent replay names are `/tmp/r276_hard_parent_replay.json` and `/tmp/r276_input_parent_replay.json`. Their execution is credited to the parent, not misdescribed as this reviewer's rerun.

## N2. Hard-receiver algorithm, orientation and counts

This suite uses
\[
 D^{\mathrm{hard}}=\kappa_A(X,u)-\kappa_A(X,v),\quad
 X\sim\mathrm{Uniform}(Q_R(z)).
\]
For one coordinate its minus,zero,plus probabilities are respectively the v-only intersection length/R, its complement, and the u-only intersection length/R. The triple-overlap subtraction is correct. Closed interval endpoints have zero receiver mass.

The integer polynomial convolution and its offset updates correctly implement values −1,0,1. Leading/trailing zeros are removed with the corresponding offset adjustment. The resulting moment formulas, positive-minus-negative identity, and centered absolute moment use the correct common-denominator powers. Independence is used solely for genuine product receiver coordinates, not for a posterior source law.

The code/JSON counts match: 12 laws in stages 4/4/4, 1492 convolved coordinate factors, 24 finite R comparisons, one exact zero-variance law, and maximum support 769 slots. There is no floating precision issue in this standard-library Fraction/integer suite. The table's decimal summaries are illustrative; its stored moments are exact Fractions.

The parent convention and actual-input suite are
\[
 D^{\mathrm{parent}}=\kappa_A(X,v)-\kappa_A(X,u)
                  =-D^{\mathrm{hard}}.
\]
Thus the mean reverses sign, **and positive and negative parts interchange**. Variance and centered absolute moments are invariant. A positive hard-suite mean must not be inserted into the parent's signed mean formula without reversing it. Both author notes explicitly disclose this distinction; no blocking orientation error was found.

## N3. Actual-input formulas, normalization and soft tail

The actual marginal density is f_s(x/L)/L. The interval probability centered at r is
\[
 F_A(r)=(1-s)\frac{|[-L/2,L/2]\cap[r-A/2,r+A/2]|}{L}
       +s\int_{(r-A/2)/L}^{(r+A/2)/L}\phi(t)dt.
\]
The source code has exactly this normalization. Its E3 phi expression and odd E4 primitive are consistent: the primitive is integral_0^x phi, not the CDF itself, so it tends to plus/minus 1/2. Differences of the primitive are the correct interval mass. The E3 quadrature splits at ±1/2 and zero and is compared against E4 differences.

The node sigma=k/(n+1), s in [(k−1)/n,k/n], and L<=Lupper<=gamma L give the stated coefficientwise/scale domination. Using k=1 at s=0 is a permitted neighboring node, not the unique ceil(0) convention; its inequality remains valid. The TV input |s−sigma|+1−L/Lupper is an exact rational upper bound. The finite pointwise comparisons and mean checks do not themselves prove its universal analytic statement.

With the parent v−u orientation,
\[
 \mu=\sum_i(F_A(|v_i|)-F_A(|u_i|)),\quad
 D_r=\#\{|u_i|\le r\}-\#\{|v_i|\le r\},
\]
\[
 \mu=-\sum_{\mathrm{radial\ cells}}D_{\mathrm{mid}}
                                  [F_A(r_{\mathrm{left}})-F_A(r_{\mathrm{right}})].
\]
The code inserts both b=1 and all source radii, so this is the correct finite Stieltjes telescoping formula. Beyond the largest source radius D_r=0; the code does not set F_A to zero there. In particular its beyond-b soft contribution is retained with the correct negative sign in the u=0,v=2 example.

The actual-input counts match: 12 cases in stages 4/4/4; 194 pointwise comparisons, 74 actual interval-probability quadratures, 12 mean checks and 12 radial identities per precision; 207 numeric fields compared. The 74 count also follows independently by twice the number of unique radii {0,1,|u|,|v|} across the twelve cases.

## N4. Precision and coverage limits

The input suite runs ordinary 40/70-digit mpmath. Its scaled comparison divides by max(1,|reference|), so tiny reported quantities are compared absolutely, not with a guaranteed relative error. The 1e-20 hard-boundary offsets are converted from exact Fractions, and the hard membership decisions are exact rational comparisons before the soft evaluations. No outward rounding or rigorous interval enclosure is claimed.

The static guard tolerances are 1e-32 for E3/E4 interval consistency, 1e-30 for density domination, and 1e-28 for mean/radial/precision comparisons. These are disclosed numerical tolerances, not proof certificates for all parameters. The suites diagnose finite physical receiver/kernel laws; neither constructs all original FIRST/high/history qualifications, a posterior source independence law, FULL data, or an asymptotic dimension conclusion.

## N5. Independent executable compact check

This code uses exact rational receiver interval partitions, rather than the author's overlap-subtraction implementation. For the soft probabilities it independently integrates the positive-r kernel primitive and compares with E4. It does not import either author module or invoke its main routine.

```python
from pathlib import Path
from fractions import Fraction as F
import json,sys
sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
import mpmath as m
m.mp.dps=70
hard=json.loads(Path('/tmp/r276_numeric.json').read_text())
soft=json.loads(Path('/tmp/r276_input_numeric.json').read_text())
checks=0

def partprob(A,R,u,v,z):
    left,right=z-R/2,z+R/2
    pts=sorted({left,right}|{p for p in [u-A/2,u+A/2,v-A/2,v+A/2] if left<p<right})
    out={-1:F(0),0:F(0),1:F(0)}
    for lo,hi in zip(pts[:-1],pts[1:]):
        x=(lo+hi)/2
        sign=int(abs(x-u)<=A/2)-int(abs(x-v)<=A/2)
        out[sign]+=(hi-lo)/R
    return [out[-1],out[0],out[1]]
for name in ['aligned_small_n2','opposite_n2','corecross_n8','boundary_n64','rare_n512']:
    row=next(r for r in hard['cases'] if r['name']==name)
    A,R=F(row['A']),F(row['R']);mu=var=F(0)
    for b in row['physical_coordinate_blocks']:
        p=partprob(A,R,F(b['u']),F(b['v']),F(b['z']))
        assert p==list(map(F,b['prob_minus_zero_plus']));checks+=1
        mean=p[2]-p[0];mu+=b['count']*mean
        var+=b['count']*(p[0]+p[2]-mean*mean)
    assert mu==F(row['mean_exact']);checks+=1
    assert var==F(row['variance_exact']);checks+=1
    assert F(row['E_positive_delta_exact'])-F(row['E_negative_delta_exact'])==mu;checks+=1
    # Under the parent's convention the positive part is this suite's negative part.
    assert -mu==F(row['E_negative_delta_exact'])-F(row['E_positive_delta_exact']);checks+=1

# Independent one-coordinate primitive before the r integral.
def G(r,x):
    if not r:return m.mpf(0)
    if x<0:return -G(r,-x)
    if x<=m.mpf('.5'):
        return 2*r*x-r*r*m.exp(-(m.mpf('.5')-x)/r)+r*r*m.exp(-(m.mpf('.5')+x)/r)
    return r-r*r*m.exp(-(x-m.mpf('.5'))/r)+r*r*m.exp(-(x+m.mpf('.5'))/r)
def E4primitive(x):
    if x<0:return -E4primitive(-x)
    if x<=m.mpf('.5'):
        return x-m.expint(4,m.mpf('.5')-x)+m.expint(4,m.mpf('.5')+x)
    return m.mpf('.5')-m.expint(4,x-m.mpf('.5'))+m.expint(4,x+m.mpf('.5'))
def prob(s,L,A,x):
    global checks
    lo=(x-A/2)/L;hi=(x+A/2)/L
    positive=m.quad(lambda r:G(r,hi)-G(r,lo),[0,m.mpf('.25'),m.mpf('.5'),1])
    closed=E4primitive(hi)-E4primitive(lo)
    assert abs(positive-closed)<m.mpf('1e-55');checks+=1
    hardmass=max(m.mpf(0),min(x+A/2,L/2)-max(x-A/2,-L/2))/L
    assert 0<=hardmass<=1 and 0<=positive<=1;checks+=1
    return (1-s)*hardmass+s*positive
vals={}
for x in [m.mpf(0),m.mpf(1),m.mpf(2)]:
    vals[int(x)]=prob(m.mpf(1),m.mpf(1),m.mpf(1),x)
for s,L,A,x in [('0','.5','.75','.25'),('.5','.75','.5','.6'),
                 ('1e-20','1','1','.5'),('.01','.5','.5','0')]:
    prob(*map(m.mpf,[s,L,A,x]))
row=next(r for r in soft['mp70']['cases'] if r['n']==2 and r['s_exact']=='1')
mean=2*(vals[2]-vals[0]);tail=-2*(vals[1]-vals[2])
assert abs(mean-m.mpf(row['mean_original_v_minus_u']))<m.mpf('1e-55');checks+=1
assert abs(tail-m.mpf(row['radial_tail_above_b1_contribution']))<m.mpf('1e-55');checks+=1
assert abs(vals[1]-m.mpf(row['F_A_at_b1_original']))<m.mpf('1e-55');checks+=1
assert abs(vals[2]-m.mpf(row['F_A_at_source_max_original']))<m.mpf('1e-55');checks+=1
print('PASS',checks)
print('F1',m.nstr(vals[1],24),'F2',m.nstr(vals[2],24))
print('parent mean',m.nstr(mean,24),'tail beyond b',m.nstr(tail,24))
```

## N6. Actual independent output and final mesh distinction

N5 was actually extracted and executed locally at 70 digits. Output:

```text
PASS 44
F1 0.186231191897872178668385 F2 0.0436818517971720468558241
parent mean -0.923552928370565485964274 tail beyond b -0.285098680201400263625122
```

There are 26 exact rational assertions and 18 ordinary arbitrary-precision probability/identity assertions. The nonzero negative beyond-b contribution matches the parent orientation and the stored actual-input radial identity. No full suite was rerun by this reviewer.

Final-proof mesh scope: the parent's final E3 chooses k=max(1,ceil(ns)), using only nodes 1,...,n. The auxiliary `/tmp/r276_empirical.md` diagnostic permits the larger 0,...,n menu and uses k=0 at s=0; this is a safe alternative for its 16e²n³ bound, not an assertion that the two selectors coincide. The actual-input numeric suite's s=0 cases use k=1 and therefore test that final endpoint choice. More generally its test condition s in [(k−1)/n,k/n] permits either neighboring node at a shared cell boundary: for example n=32,s=15/32,k=16 is an admissible alternative, while the final ceil convention selects k=15. This does not invalidate the tested coefficient/TV inequalities, but that record should not be represented as checking the identical final node selector at every boundary.

Final audit conclusion: PASS for the two stated finite numerical scopes, with the explicitly opposite hard/input orientations and the above mesh convention qualification. Source bindings, counts, algorithms and precision disclosures are consistent. The parent full replay is byte-identical; the independent compact interval/CDF tests pass. None of these numerical facts is promoted to a standalone universal all-scale theorem, FULL construction, unproved source independence, or signed-credit payment.
