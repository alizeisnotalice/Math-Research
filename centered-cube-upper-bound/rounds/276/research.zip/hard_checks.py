#!/usr/bin/env python3
"""R276 true uniform hard-receiver count fluctuations; exact rational law."""
import argparse,hashlib,json,math
from pathlib import Path
from fractions import Fraction as F

def st(x):return str(F(x))
def block(count,u,v,z='0'):return {'count':count,'u':F(u),'v':F(v),'z':F(z)}
def menus():
 return [('initial','aligned_small_n2',F(1),F(1),[block(2,'0','1/4')]),('initial','opposite_n2',F(1),F(1),[block(1,'0','1/4'),block(1,'1/4','0')]),('initial','corecross_n8',F(1),F(1),[block(8,'2/5','-2/5','3/10')]),('initial','zero_variance_n8',F(1),F(1),[block(8,'1/4','1/4')]),('stress','aligned_n32',F(1),F(1),[block(32,'0','3/4')]),('stress','opposite_n32',F(1),F(1),[block(16,'0','3/4'),block(16,'3/4','0')]),('stress','boundary_n64',F(1),F(3,2),[block(64,'0','3/2','3/4')]),('stress','rare_n64',F(1),F(1),[block(64,'0','1/1024')]),('expanded','aligned_corecross_n128',F(1),F(1),[block(128,'2/5','-2/5','3/10')]),('expanded','opposite_corecross_n128',F(1),F(1),[block(64,'2/5','-2/5','3/10'),block(64,'-2/5','2/5','3/10')]),('expanded','rare_n512',F(1),F(1),[block(512,'0','1/4096')]),('expanded','four_blocks_n512',F(1),F(1),[block(128,'0','1/4'),block(128,'1/4','0'),block(128,'2/5','-2/5','3/10'),block(128,'-2/5','2/5','3/10')])]
def length(*intervals):return max(F(0),min(b for a,b in intervals)-max(a for a,b in intervals))
def probabilities(A,R,b):
 u,v,z=b['u'],b['v'],b['z'];receiver=(z-R/2,z+R/2);Iu=(u-A/2,u+A/2);Iv=(v-A/2,v+A/2)
 both=length(receiver,Iu,Iv);plus=(length(receiver,Iu)-both)/R;minus=(length(receiver,Iv)-both)/R;zero=1-plus-minus;assert all(p>=0 for p in [minus,zero,plus]) and minus+zero+plus==1
 return [minus,zero,plus]
def mean_at(A,R,blocks):return sum(b['count']*(lambda p:p[2]-p[0])(probabilities(A,R,b)) for b in blocks)

def check(model):
 stage,name,A,R,blocks=model;n=sum(b['count'] for b in blocks);coeff=[1];den=1;offset=0;theorymean=F(0);theoryvar=F(0);probs=[]
 for b in blocks:
  ps=probabilities(A,R,b);d=math.lcm(*(p.denominator for p in ps));q=[int(p*d) for p in ps];theorymean+=b['count']*(ps[2]-ps[0]);theoryvar+=b['count']*(ps[2]+ps[0]-(ps[2]-ps[0])**2)
  probs.append({'count':b['count'],'u':st(b['u']),'v':st(b['v']),'z':st(b['z']),'prob_minus_zero_plus':list(map(st,ps))})
  for _ in range(b['count']):
   nxt=[0]*(len(coeff)+2)
   for i,c in enumerate(coeff):
    for j,p in enumerate(q):nxt[i+j]+=c*p
   offset-=1;den*=d
   while len(nxt)>1 and nxt[0]==0:nxt.pop(0);offset+=1
   while len(nxt)>1 and nxt[-1]==0:nxt.pop()
   coeff=nxt
 assert sum(coeff)==den
 M1=sum((offset+i)*c for i,c in enumerate(coeff));M2=sum((offset+i)**2*c for i,c in enumerate(coeff));mu=F(M1,den);var=F(M2,den)-mu*mu;assert mu==theorymean and var==theoryvar
 positive=F(sum(max(offset+i,0)*c for i,c in enumerate(coeff)),den);negative=F(sum(max(-offset-i,0)*c for i,c in enumerate(coeff)),den);assert positive-negative==mu
 centered_abs=F(sum(abs((offset+i)*den-M1)*c for i,c in enumerate(coeff)),den*den);centered_positive=centered_abs/2;assert centered_abs**2<=var
 excess=positive-max(mu,F(0));assert excess>=0 and excess**2<=var
 pzero=F(coeff[-offset],den) if offset<=0<offset+len(coeff) else F(0);ppos=F(sum(c for i,c in enumerate(coeff) if offset+i>0),den)
 tail=F(sum(c for i,c in enumerate(coeff) if abs(offset+i-mu)>=F(n,2)),den)
 coupling=[]
 for Rp in sorted({R+F(1,16),F(2)}-{R}):
  mup=mean_at(A,Rp,blocks);bound=2*n*abs(R-Rp)/min(R,Rp);assert abs(mu-mup)<=bound
  coupling.append({'R_prime':st(Rp),'mean_at_R_prime':st(mup),'mean_change':st(abs(mu-mup)),'candidate_bound':st(bound),'margin':st(bound-abs(mu-mup))})
 digest=hashlib.sha256((','.join(map(str,coeff))+'/'+str(den)+';offset='+str(offset)).encode()).hexdigest()
 return {'stage':stage,'name':name,'n':n,'A':st(A),'R':st(R),'physical_coordinate_blocks':probs,'support_min':offset,'support_max':offset+len(coeff)-1,'distribution_support_slots':len(coeff),'distribution_common_denominator_bits':den.bit_length(),'distribution_coefficients_sha256':digest,'mean_exact':st(mu),'variance_exact':st(var),'E_positive_delta_exact':st(positive),'E_negative_delta_exact':st(negative),'centered_E_absolute_exact':st(centered_abs),'centered_E_positive_exact':st(centered_positive),'positive_excess_above_positive_mean_exact':st(excess),'P_delta_zero_exact':st(pzero),'P_delta_positive_exact':st(ppos),'P_abs_centered_atleast_n_over2_exact':st(tail),'scale_centered_mean_checks':coupling,'all_distribution_mass_exact':'1','mean_dominates_centered_positive':max(mu,F(0))>centered_positive}

def main():
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));args=p.parse_args();rows=[check(x) for x in menus()]
 out={'schema':'R276-hard-receiver-fluctuation-v1','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'counts':{'true_uniform_receiver_models':12,'stages':{'initial':4,'stress':4,'expanded':4},'exact_convolved_dimensions':sum(r['n'] for r in rows),'exact_scale_mean_comparisons':sum(len(r['scale_centered_mean_checks']) for r in rows),'zero_variance_cases':sum(F(r['variance_exact'])==0 for r in rows)},'cases':rows,'scope':['For each fixed physical u,v,z,A,R, receiver X is genuinely uniform on product cube Q_R(z). Delta=sum[1_{Q_A(u)}(coordinate)-1_{Q_A(v)}(coordinate)]. Independence used only for these receiver coordinates, never for a posterior source law.','Each per-coordinate probability is an exact interval-intersection length divided byR. Integer polynomial convolution computes the full count distribution without simulation; JSON stores exact moments, tails and a canonical full-coefficient hash rather than a huge distribution dump.','Mean is preserved separately from centered fluctuations. Zero variance, aligned offsets, opposite-coordinate cancellation, boundary receivers, and rare shifts are finite diagnostics, not a fitted dimension law.','The scale-centered mean inequality |mu_R-mu_Rprime|<=2n|R-Rprime|/min(R,Rprime) is checked at the listed finite physical scales only; no universal coupling theorem inferred. No original FULL/FIRST/high/history/root qualification.']}
 args.output.write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps({'counts':out['counts'],'maximum_support_slots':max(r['distribution_support_slots'] for r in rows)}))
if __name__=='__main__':main()
