# R276 actual hard-receiver fluctuation diagnostics

Executed with bundled Python3.12.14, pure standard-library Fraction/integer arithmetic; no numerical quadrature or simulation. Command: `/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 /tmp/r276_numeric.py --output /tmp/r276_numeric.json`.

Twelve genuine uniform receiver models, three stages4/4/4, reach n512. The1492 coordinate factors are convolved exactly into integer polynomial coefficients. All total masses, mean/variance comparisons to independent-coordinate formulas, positive-minus-negative mean identities, centered fluctuation inequalities, and24 finite R/Rprime mean comparisons pass. The largest support has769 slots. One exact zero-variance case is retained. The JSON stores exact Fractions and full coefficient hashes, avoiding a large coefficient dump.

|Model|n|mean|variance|E Delta+|E(centered Delta)+|
|---|---:|---:|---:|---:|---:|
|aligned_small_n2|2|0.5|0.375|0.5|0.28125|
|opposite_n2|2|0|0.375|0.1875|0.1875|
|corecross_n8|8|4.8|3.52|4.808575|0.7529536|
|zero_variance_n8|8|0|0|0|0|
|aligned_n32|32|24|6|24|0.96624486|
|opposite_n32|32|0|6|0.96434226|0.96434226|
|boundary_n64|64|0|42.666667|2.6033515|2.6033515|
|rare_n64|64|0.0625|0.062438965|0.0625|0.058711523|
|aligned_corecross_n128|128|76.8|56.32|76.8|2.9950557|
|opposite_corecross_n128|128|0|56.32|2.9888761|2.9888761|
|rare_n512|512|0.125|0.12496948|0.125|0.11031043|
|four_blocks_n512|512|0|160.64|5.053522|5.053522|

Displayed table decimals are for reading only; exact values are in JSON. Aligned/core-crossing examples have a large positive mean: their positive part is not a centered fluctuation and should not be bounded as though mean were zero. Opposite-coordinate examples cancel the mean while retaining true receiver variance; the rare-shift examples show a different nearly degenerate regime. These decisions are finite comparisons, not asymptotic inference.

Per-coordinate independence comes only from the actual product-uniform receiver cube. It is not an assumption on posterior source coordinates or source labels. The scale mean bound is tested at two explicitly listed Rprime scales per model; the universal coupling argument remains analytic work. No original FULL, history, FIRST/high, or root conclusion is certified.

Source SHA256: 35133a40fd564d72e80a2e449b8e6fd30e5fcb5d5a28278338cb05b2b88edeb6

JSON SHA256: 47b25b424657e85f53a480f33ad9f012ae5e26c7a5684b88aafb0aea313fbd55
