# R276 final independent mathematical audit

**Verdict: PASS for the integrated all-parameter fluctuation theorem, its actual original positive-exception payment, and the stated radial-mean/complement interface. The general weak-type goal and the complementary mean-driven traffic remain unproved.**

## Bound versions and independent-screen order

Final source read in full:

- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round276_20261017_final_checkpoint/proof.tex.txt`
- SHA256 `defe38673842c13c2c8854462f2d586b890067f1275cdd4ae8d0a08284abf7a9`.

The independent screens were saved before either R276 author proof was read:

- `/tmp/r276_screen.md`, SHA256 `1f38571a91d47441a2d86b48e4a2ca6296c6a14216787ad533090296bc3b4893` (fixed hard-receiver screen; not separately counted as the new paid branch).
- `/tmp/r276_input_screen.md`, SHA256 `b3d089c644e4aec81595b0db75ee0c6889318f066a65c384567be950cca97bb7` (all-soft input-kernel and actual-source payment screen).

Author proofs subsequently read in full for the adopted claims:

- `/tmp/r276_empirical.md`, SHA256 `85c4b4b678c2022c6f4694718cb715544c04e3db34c061d25b067e501f4a3781`.
- `/tmp/r276_main.md`, SHA256 `bd9249bcbd6894937b40df479c3286f524901937659b088562542a53d2f6b0e2`.

The author's unused fixed-reference-Gamma and truncated hard-near variants are not registered as dependencies or new payments of this final audit.

## E1–E5: uniform input-kernel envelope — PASS

The clipped soft bins with nodes k/(n+1), k=1,...,n, dominate the entire closed soft interval, including s=0 and s=1, coefficientwise at cost gamma per coordinate. The upward gamma scale grid has at most n+1 nodes. Both tensor domination factors are paid once, giving at most e^2.

The coordinate total-variation bounds are legitimate for normalized receiver laws. Applying them to the additive net-count mean gives error at most 4, without claiming small full-dimensional total variation. The A-grid brackets the two monotone count functions separately. Each mean bracket error is at most the stated 2; the actual count discontinuities are not discarded. At a fixed product receiver law, the self-contained log-mgf argument gives the one-sided tail exp(-r^2/(2n)).

The finite nonnegative envelope E5 simultaneously covers the union over all A, not only each single A in isolation. Its explicit node count and the conservative constant 16e^2 n^3 in E2 are valid. Finite construction gives joint measurability and covers arbitrary actual measurable input selectors. All independence used here belongs to fixed input-kernel receiver coordinates; none is imposed on the original source measure.

## P1–P6: actual original positive-exception payment — PASS

The proof restarts at the original current positive mother integral. The event is independent of the hard-source slot. It retains the original valid receiver domain until the hardcap is applied, and only then extends the positive receiver integration to all space. The original pair posterior, with fixed (omega,V,j,y,t), is independent of x and hard z as explicitly stated in R223 NC3; no such claim is made about Pi_{g(x)} or terminal classifiers.

After positive removal of the original bounded gates, raw score <=n, hardcap/q <=16/3, and complete pair probability mass <=1 are legitimate. The deterministic time bands and their entire j multiplicity are charged by P4. In particular gamma^n>=2 implies log(gamma)>=log(2)/n, and S_n<=log(2)(1+n/4)<=n for all n>=1. Empty bands and zero-degree rows contribute zero.

The coefficient in P5 is exactly the safe product

`2 Lambda * (16/3) * n * n * (16e^2 n^3)`.

Thus C0=512 Lambda e^2/3 has included the original outside 2 Lambda once, both parameter menus, the raw score and the complete time-band sum. No target-leg factor is missing: the single exception event already covers both moving widths. No extra source-mass square, FIRST menu, or degree denominator is introduced.

The primary R112 source qualifications at lines 508 and 546 were independently read: disjoint terminal V, alpha_V=mu_hi|V, and pre-frozen beta_V<=alpha_V. Hence W_beta<=W_hi<=||f||_1 is legitimate for this same source collection. It neither uses nu<=beta nor duplicates a mass budget over ancestors or j. P6 is correct for every epsilon>0, including the case epsilon>C0 via log_+ and the trivial prefactor comparison. This is an actual paid positive subbranch with cost epsilon W_beta, and consumes no additional epsilon X or negative credit.

## G1–G4: mean and original complement — PASS

For any fixed soft input kernel, the one-dimensional window-hit function is absolutely continuous, even and decreasing on the positive half-line. Its derivative gives the displayed nonnegative omega_A and total mass F_A(0)<=1. The signed radial identity in G1 follows by finite coordinate summation; absolute integrability is explicit. The soft tail correctly extends to infinity.

The original strict activation inequality is exactly the strict radial-distance inequality in G2 because C is strictly decreasing on the positive half-line. The claimed monotonicity follows piecewise from max(h,phi): for 0<r<1 the inner profile is 1 and the outer profile is strictly less than 1; for r>1 both are strictly decreasing soft profiles. The inverse and the scanned range therefore have the stated orientation and endpoints. This does not identify the actual time measure with omega_A dr or create a new signed credit.

On the positive complement, all A deviations are at most T_epsilon simultaneously. Substituting the two actual moving-width upper bounds into the already verified R275 weighted-mixture inequality gives G3 with its original mixture weights, scales and signed means. The third pure-soft leg has no jump count. G4 is a valid coarsening. The potentially large jump coefficient and exp(vartheta_s T_epsilon) are not suppressed. The finite-jump formula is not extended to s=0; only the input-kernel exception theorem covers that endpoint. The complementary radial mean/score joint budget remains explicitly unpaid.

## Evidence and limits

The independent screens contain executable code for 1392 exact Fraction bracket/mean-transport assertions and 711 exact Fraction soft-domination/menu-size assertions actually run by this auditor. These finite calculations are arithmetic checks, not proofs of concentration or FULL instances. The final adopted lemmas were verified analytically above. No additional full parent/author numeric replay was performed for this consistency audit, and this audit does not take credit for another agent's numeric receipt.

No mathematical correction is required in the bound final source. This round's genuinely paid result is P6 for the exception subset of the original currently unpaid positive traffic. It does not pay the whole positive or signed remainder and does not establish the global root-order upper bound. No repository file, Git state, or PDF was modified.
