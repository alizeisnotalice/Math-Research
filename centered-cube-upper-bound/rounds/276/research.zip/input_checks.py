#!/usr/bin/env python3
"""R276 actual input soft/scale cover and radial mean identity."""
import argparse,hashlib,json
from fractions import Fraction as F
from pathlib import Path
import mpmath as mp

def st(x):return str(F(x))
def mm(x):
 x=F(x);return mp.mpf(x.numerator)/x.denominator
def enc(x):return mp.nstr(x,100)
def phi(x):
 x=abs(x)
 if x<=mp.mpf('.5'):return 1-mp.expint(3,mp.mpf('.5')-x)-mp.expint(3,mp.mpf('.5')+x)
 return mp.expint(3,x-mp.mpf('.5'))-mp.expint(3,x+mp.mpf('.5'))
def density(s,L,x):return ((1-s)*(1 if abs(x)<=L/2 else 0)+s*phi(x/L))/L
def primitive(x):
 sign=1 if x>=0 else -1;x=abs(x)
 return sign*(x-mp.expint(4,mp.mpf('.5')-x)+mp.expint(4,mp.mpf('.5')+x) if x<=mp.mpf('.5') else mp.mpf('.5')-mp.expint(4,x-mp.mpf('.5'))+mp.expint(4,x+mp.mpf('.5')))
def profile(n,name):
 if name=='near':return [(n,F(0),F(1,4))]
 if name=='far2':return [(n,F(0),F(2))]
 if name=='far4':return [(n,F(0),F(4))]
 if name=='shiftedfar':return [(n,F(1,4),F(2))]
 if name=='corecross':return [(n,F(0),F(1,2))]
 if name=='onepointone':return [(n,F(0),F(11,10))]
 if name=='balanced':return [(n//2,F(0),F(3,5)),(n//2,F(3,5),F(0))]
 return [(3*n//4,F(0),F(3,5)),(n//4,F(3,5),F(0))]
def menu():
 # (n,k,s,L,Lupper mode,A,profile)
 return [(2,1,F(0),F(1,2),'plus',F(1,2),'near'),(2,2,F(1),F(1),'same',F(1),'far2'),(8,1,F(1,8*10**50),F(3,4),'plus',F(3,4),'opposite'),(8,4,F(1,2),F(1,2),'plus',F(1),'onepointone'),(32,16,F(15,32),F(3,4),'plus',F(1,2),'far4'),(32,1,F(0),F(1),'same',F(3,4),'balanced'),(64,64,F(1),F(1,2),'plus',F(1),'shiftedfar'),(64,1,F(1,64*10**50),F(1),'same',F(1),'corecross'),(128,5,F(9,256),F(3,4),'plus',F(1,2),'far4'),(128,128,F(1),F(1),'same',F(1),'opposite'),(512,1,F(0),F(1,2),'plus',F(3,4),'near'),(512,1,F(1,512),F(1),'same',F(1),'far2')]

def interval_probability(s,L,A,x):
 # Exact hard term plus actual E3 quadrature, independently checked by E4.
 lo=(x-A/2)/L;hi=(x+A/2)/L;hard=max(F(0),min(x+A/2,L/2)-max(x-A/2,-L/2))/L
 pts=sorted({mm(lo),mm(hi)}|{k for k in [mp.mpf('-.5'),mp.mpf(0),mp.mpf('.5')] if mm(lo)<k<mm(hi)})
 soft=sum(mp.quad(phi,[a,b]) for a,b in zip(pts,pts[1:]));closed=primitive(mm(hi))-primitive(mm(lo));assert abs(soft-closed)<mp.mpf('1e-32')
 return mm(1-s)*mm(hard)+mm(s)*soft,abs(soft-closed)

def run(dps):
 with mp.workdps(dps):
  rows=[];pointchecks=0;cdfchecks=0
  for n,k,s,L,mode,A,pname in menu():
   gamma=F(n+1,n);upper=min(F(1),gamma*L) if mode=='plus' else L;r=F(k,n+1);assert F(k-1,n)<=s<=F(k,n) and L<=upper<=gamma*L
   tvbound=abs(s-r)+1-L/upper;assert tvbound<=F(2,n+1);meanbound=2*n*tvbound;assert meanbound<=4
   xs={F(0),F(1,4),F(1),F(2),F(4),F(16),F(64)}
   for a in [L/2,upper/2]:
    xs|={a,-a,a-F(1,10**20),a+F(1,10**20),-a-F(1,10**20),-a+F(1,10**20)}
   ratios=[]
   for x in sorted(xs):
    # Hard comparison uses exact rational membership before soft evaluation.
    g=(mm(1-s)*(1 if abs(x)<=L/2 else 0)+mm(s)*phi(mm(x/L)))/mm(L)
    gn=(mm(1-r)*(1 if abs(x)<=upper/2 else 0)+mm(r)*phi(mm(x/upper)))/mm(upper);ratio=g/gn;assert ratio<=mm(gamma**2)+mp.mpf('1e-30');ratios.append((ratio,x));pointchecks+=1
   blocks=profile(n,pname);radii=sorted({F(0),F(1)}|{abs(u) for cnt,u,v in blocks}|{abs(v) for cnt,u,v in blocks});original={};node={};cdfres=mp.mpf(0)
   for x in radii:
    original[x],er=interval_probability(s,L,A,x);node[x],en=interval_probability(r,upper,A,x);cdfres=max(cdfres,er,en);cdfchecks+=2
   mu=sum(cnt*(original[abs(v)]-original[abs(u)]) for cnt,u,v in blocks);munode=sum(cnt*(node[abs(v)]-node[abs(u)]) for cnt,u,v in blocks);assert abs(mu-munode)<=mm(meanbound)+mp.mpf('1e-28') and abs(mu-munode)<=4+mp.mpf('1e-28')
   radial=mp.mpf(0);tail=mp.mpf(0);segments=[]
   for a,b in zip(radii,radii[1:]):
    mid=(a+b)/2;D=sum(cnt*(int(abs(u)<=mid)-int(abs(v)<=mid)) for cnt,u,v in blocks);term=-D*(original[a]-original[b]);radial+=term
    if a>=1:tail+=term
    segments.append({'r_left_exact':st(a),'r_right_exact':st(b),'D_r_exact':D,'F_left':enc(original[a]),'F_right':enc(original[b]),'mean_contribution':enc(term)})
   assert abs(mu-radial)<mp.mpf('1e-28')
   source_max=max(max(abs(u),abs(v)) for cnt,u,v in blocks);beyond=sum(cnt*(1-1) for cnt,u,v in blocks);assert beyond==0
   # source_max and b=1 are both in the partition, so F at the last physical
   # source is never silently set to zero even though D is zero beyond it.
   best=max(ratios,key=lambda q:q[0]);rows.append({'stage':'initial' if n<=8 else 'stress' if n<=64 else 'expanded','n':n,'soft_cell_k':k,'s_exact':st(s),'node_r_exact':st(r),'L_exact':st(L),'Lupper_exact':st(upper),'A_exact':st(A),'gamma_squared_exact':st(gamma**2),'pointwise_test_count':len(xs),'max_pointwise_density_ratio':enc(best[0]),'max_ratio_x_exact':st(best[1]),'one_coordinate_TV_upper_exact':st(tvbound),'additive_mean_drift_upper_exact':st(meanbound),'physical_uv_coordinate_blocks':[{'count':cnt,'u_exact':st(u),'v_exact':st(v)} for cnt,u,v in blocks],'mean_original_v_minus_u':enc(mu),'mean_node_v_minus_u':enc(munode),'mean_drift':enc(abs(mu-munode)),'mean_drift_margin_to_4':enc(4-abs(mu-munode)),'radial_mean_from_score':enc(radial),'radial_identity_absolute_residual':enc(abs(mu-radial)),'radial_tail_above_b1_contribution':enc(tail),'F_A_at_b1_original':enc(original[F(1)]),'source_max_radius_exact':st(source_max),'F_A_at_source_max_original':enc(original[source_max]),'score_beyond_source_max_exact':0,'radial_segments':segments,'CDF_E3_quad_vs_E4_max_absolute_residual':enc(cdfres)})
  return {'cases':rows,'pointwise_checks':pointchecks,'actual_CDF_integrals':cdfchecks}

def fields(obj,path=''):
 out={}
 if isinstance(obj,dict):
  for k,v in obj.items():
   if isinstance(v,str) and not k.endswith('_exact') and k!='stage':
    try:
     z=mp.mpf(v)
     if mp.isfinite(z):out[path+k]=z
    except ValueError:pass
   elif isinstance(v,(dict,list)) and k not in ['physical_uv_coordinate_blocks']:out.update(fields(v,path+k+'/'))
 elif isinstance(obj,list):
  for i,v in enumerate(obj):out.update(fields(v,path+str(i)+'/'))
 return out

def main():
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));a=p.parse_args();lo=run(40);hi=run(70)
 with mp.workdps(120):
  x=fields(lo);y=fields(hi);assert x.keys()==y.keys();diff={k:abs(x[k]-y[k])/max(1,abs(y[k])) for k in x};worst=max(diff,key=diff.get);md=enc(diff[worst]);assert diff[worst]<mp.mpf('1e-28')
 out={'schema':'R276-actual-input-cover-mean-v1','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'counts':{'actual_input_models_per_precision':12,'stage_models':{'initial':4,'stress':4,'expanded':4},'pointwise_density_checks_per_precision':hi['pointwise_checks'],'actual_CDF_integrals_per_precision':hi['actual_CDF_integrals'],'mean_drift_checks_per_precision':12,'radial_score_identities_per_precision':12,'precision_fields_compared':len(diff)},'mp40':lo,'mp70':hi,'precision_max_relative_difference':md,'precision_worst_field':worst,'scope':['Actual physical input coordinate density is f_s(x/L)/L with y0; node density is f_(k/(n+1))(x/Lupper)/Lupper,s in[(k-1)/n,k/n],L<=Lupper<=gamma L. Pointwise tests include exact hard endpoints and distances1e-20 on both sides.','Each interval probability F_A(x) has an exact rational hard overlap plus actual E3 soft quadrature split at phi core boundaries, independently checked by E4 primitive. A in[.5,1] is the physical source-window side, not assumed tied to L.','Parent orientation is Delta=kappa(v)-kappa(u), mean=sum F(v)-F(u). This is opposite the earlier R276 hard suite orientation. Radial score D_r=#|u|<=r-#|v|<=r gives mean=-integral omega_A D_r with omega_A=-F_Aprime.','The radial partition includes b1 and every source radius; nonzero F_A(b) and beyond-b mean contributions are retained. Above the last source radius D=0, not F=0.','TV upper bound |s-node|+1-L/Lupper is exact rational tool input; additive mean drift is checked against2n times it and4. No independence of posterior source coordinates is used.','Ordinary40/70 arithmetic is not outward intervals or general all-soft/all-scale proof. No original FULL, history, FIRST/high qualification, or dimension-order conclusion.']}
 a.output.write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps({'counts':out['counts'],'maxdiff':md,'worst':worst}))
if __name__=='__main__':main()
