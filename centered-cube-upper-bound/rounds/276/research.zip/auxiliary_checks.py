# Auxiliary author menu includes sigma=0 at s=0; the final theorem
# uses k>=1. Both are covered by the recorded loose 16 n^3 fee.
import sys
sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
from fractions import Fraction as F
import mpmath as m
m.mp.dps=60
checks=0; maxshift=m.mpf(0); maxtailratio=m.mpf(0)
def mm(q):return m.mpf(q.numerator)/q.denominator

def phiCDF(x):
    if x==m.inf:return m.mpf(1)
    if x==-m.inf:return m.mpf(0)
    if x<0:return 1-phiCDF(-x)
    if x<=m.mpf('.5'):
        return m.mpf('.5')+x-m.expint(4,m.mpf('.5')-x)+m.expint(4,m.mpf('.5')+x)
    return 1-m.expint(4,x-m.mpf('.5'))+m.expint(4,x+m.mpf('.5'))
def cdf(x,s,L,center):
    z=(x-mm(center))/mm(L); sf=mm(s)
    hard=min(m.mpf(1),max(m.mpf(0),z+m.mpf('.5')))
    return (1-sf)*hard+sf*phiCDF(z)
def one_law(s,L,y,u,v,A_v,A_u):
    pts=sorted(set([u-A_u/2,u+A_u/2,v-A_v/2,v+A_v/2]))
    ends=[-m.inf]+[mm(z) for z in pts]+[m.inf]; law={}
    for lo,hi in zip(ends[:-1],ends[1:]):
        mid=(hi-1 if lo==-m.inf else lo+1 if hi==m.inf else (lo+hi)/2)
        value=int(abs(mid-mm(v))<=mm(A_v)/2)-int(abs(mid-mm(u))<=mm(A_u)/2)
        mass=cdf(hi,s,L,y)-cdf(lo,s,L,y)
        law[value]=law.get(value,m.mpf(0))+mass
    return law

def law_sum(n,s,L,A_v,A_u):
    law={0:m.mpf(1)}
    for i in range(n):
        y=F(1,8) if i%2==0 else -F(1,10)
        u=y+(F(2,5) if i%2==0 else -F(4,5))
        v=y+(F(3,5) if i%2==0 else -F(3,10))
        one=one_law(s,L,y,u,v,A_v,A_u); new={}
        for a,p in law.items():
            for b,q in one.items():new[a+b]=new.get(a+b,m.mpf(0))+p*q
        law=new
    return law
for n in [2,8]:
    gam=1+F(1,n); a=F(1); b=F(2); L=F(13,10)
    B=a
    while B<L:B=min(b,B*gam)
    for s in [F(0),F(1,100),F(1)]:
        k=(n*s.numerator+s.denominator-1)//s.denominator
        sig=F(k,n+1)
        assert abs(s-sig)<=F(1,n);checks+=1
        for Av,Au in [(F(11,10),F(11,10)+F(1,n)),
                      (F(11,10)+F(1,n),F(11,10))]:
            actual=law_sum(n,s,L,Av,Au);node=law_sum(n,sig,B,Av,Au)
            mean=sum(z*p for z,p in node.items())
            mean0=sum(z*p for z,p in actual.items())
            shift=abs(mean-mean0);maxshift=max(maxshift,shift)
            assert shift<=4+m.mpf('1e-45');checks+=1
            assert abs(sum(node.values())-1)<m.mpf('1e-45');checks+=1
            assert min(node.values())>=-m.mpf('1e-45');checks+=1
            for t in map(m.mpf,['.5','1','2']):
                upper=sum(p for z,p in node.items() if z-mean>t)
                lower=sum(p for z,p in node.items() if mean-z>t)
                bound=m.exp(-t*t/(2*n))
                assert max(upper,lower)<=bound+m.mpf('1e-45');checks+=1
                maxtailratio=max(maxtailratio,max(upper,lower)/bound)
for n in [1,2,8,32,512,10**6]:
    h=m.log(1+m.mpf(1)/n);ell=m.log(2)
    NL=1+int(m.ceil(ell/h));assert NL<=4*n;checks+=1
    if n<1000:
        total=sum(max(m.mpf(0),ell-2*j*h) for j in range(1+int(ell/(2*h))))
        assert total<=n;checks+=1
    analytic=ell+ell*ell/(4*h);assert analytic<=n;checks+=1
print('PASS',checks)
print('max node mean shift',m.nstr(maxshift,18))
print('max exact-distribution one-sided tail / Hoeffding',m.nstr(maxtailratio,18))
