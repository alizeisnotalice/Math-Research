#!/usr/bin/env python3
"""R164 bounded replay of the eight R151 m=8 positive receiver rows.

Run with the bundled Python 3.12 runtime (NumPy present). No new receiver grid.
Inputs and kernel producer are read in place; only geometry_probe.json is written.
"""
from pathlib import Path
from fractions import Fraction
import importlib.util
import json
import math
import hashlib
import sys

HERE = Path(__file__).resolve().parent
PRODUCER = Path('/Users/zhengzhihao/Desktop/T/output/centered_cube_round151_20261015_final_checkpoint/work/receiver_probe.py')
POINTS = Path('/Users/zhengzhihao/Desktop/T/output/centered_cube_round151_20261015/receiver_probe_points.json')
spec = importlib.util.spec_from_file_location('r151_receiver', PRODUCER)
old = importlib.util.module_from_spec(spec)
spec.loader.exec_module(old)
mp = old.mp
mp.mp.dps = 65


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def M(x):
    return mp.mpf(x.numerator) / x.denominator if isinstance(x, Fraction) else mp.mpf(str(x))


def rankone(a, supply, b, kappa):
    """Finite descending-demand / ascending-supply optimizer, retaining the plan."""
    demand = sorted((i for i, x in enumerate(a) if x > 0), key=lambda i: (-b[i], i))
    donors = sorted((j for j, x in enumerate(supply) if x > 0), key=lambda j: (kappa[j], j))
    left = list(supply)
    edges = []
    for i in demand:
        need = a[i]
        for j in donors:
            flow = min(need, left[j])
            if flow > 0:
                edges.append((i, j, flow))
                left[j] -= flow
                need -= flow
            if need <= 0:
                break
        if float(need) > 2e-14:
            raise AssertionError(('infeasible compensation', need))
    cost = sum(flow * b[i] * kappa[j] for i, j, flow in edges)
    return cost, edges


def data_at(model, row, high_precision=False):
    conv = M if high_precision else float
    nu = [conv(x) for x in model['nuF']]
    wg = [conv(x) for x in model['wgF']]
    A = [conv(x) for x in model['AF']]
    K, D, T = [conv(model[k]) for k in ('KF', 'DF', 'TF')]
    if high_precision:
        x = [M(old.Fq(x)) for x in row['xq']]
        pos = [[M(t) for t in v] for v in model['positions']]
        s, L, H, Lp, bb = [M(model[k]) for k in ('sF', 'LF', 'HF', 'LpF', 'bF')]
        dx = [[x[d] - pos[i][d] for d in range(4)] for i in range(6)]
        p = old.kernel_mp(s, L, [x[d] - M('.3') for d in range(4)])
        kernels = [[old.kernel_mp(ss, scale, dd) for dd in dx]
                   for ss, scale in ((s, H), (s, L), (s, Lp), (M(1), bb))]
        K0, K1, K2, J = kernels
        Q = [(K1[i] + K2[i] + J[i]) / 3 for i in range(6)]
        qtests = [sum(nu[i] * kern[i] for i in range(6)) for kern in (K0, J, Q)]
        q, qj = max(qtests), qtests[1]
        good = [p * wg[i] <= K * Q[i] for i in range(6)]
        U = [min(T * A[i], D * K0[i]) if good[i] and A[i] > 0 else M(0) for i in range(6)]
        alpha = (D * q - sum(nu[i] * U[i] for i in range(6))) / qj
        rho = [max(1 - (U[i] + alpha * J[i]) / (T * A[i]), M(0)) if good[i] and A[i] > 0 else M(0) for i in range(6)]
    else:
        z = old.eval_batch(model, old.np.array([row['x']]))
        p, K0, K1, K2, J, Q, qtests, q, qj, good, _, _, alpha, rho, _ = z
        p, q, qj, alpha = [float(v[0]) for v in (p, q, qj, alpha)]
        K0, K1, K2, J, Q, good, rho = [v[0].tolist() for v in (K0, K1, K2, J, Q, good, rho)]
    eg = sum(wg[i] * nu[i] for i in range(6))
    pi = [wg[i] * nu[i] / eg for i in range(6)]
    R = [K * Q[i] / (p * wg[i]) for i in range(6)]
    a = [(2 * R[i] - 1) * pi[i] if good[i] else conv(0) for i in range(6)]
    supply = [max(1 - 2 * R[i], conv(0)) * pi[i] for i in range(6)]
    kappa = [2 * K * K0[i] / (p * wg[i]) for i in range(6)]
    return dict(nu=nu, wg=wg, A=A, K=K, D=D, T=T, p=p, K0=K0, K1=K1, K2=K2, J=J, Q=Q,
                q=q, qj=qj, good=good, alpha=alpha, rho=rho, eg=eg, pi=pi, R=R, a=a, supply=supply, kappa=kappa)


def at_time(d, segment, t):
    cs, ks = segment['c'], segment['k']
    wt = [cs[i] * t ** (-ks[i]) for i in range(6)]
    et = sum(d['nu'][i] * wt[i] for i in range(6))
    current_pi = [d['nu'][i] * wt[i] / et for i in range(6)]
    b = [(d['eg'] / et) * (wt[i] / d['wg'][i]) / (2 * d['R'][i] - 1) if d['good'][i] else 0 for i in range(6)]
    cost, plan = rankone(d['a'], d['supply'], b, d['kappa'])
    return dict(wt=wt, et=et, pi=current_pi, b=b, cost=cost, plan=plan)


def pair_density(d, state, v, u, delta):
    score = d['rho'][v] * delta * state['pi'][v] * state['pi'][u]
    chiJ = d['J'][v] / (3 * d['Q'][v])
    c = d['D'] * d['K0'][u] * d['J'][v] * state['et'] / (d['T'] * d['A'][v] * d['qj'] * state['wt'][u] * delta)
    dv = max(1 - d['D'] * d['K0'][v] / (d['T'] * d['A'][v]), 0)
    return score, score * chiJ, c / ((25 / 3) * dv ** 2)


def route_density(d, state, segment, pairs):
    """Keep original (v,u) gates; new legs receive no additional gate claims."""
    original = leg1 = leg2 = chi1 = chi2 = between = base = 0
    ks = segment['k']
    for pair in pairs:
        v, u, delta = [pair[k] for k in ('v', 'u', 'delta')]
        original += pair_density(d, state, v, u, delta)[0]
        chi = d['J'][v] / (3 * d['Q'][v])
        for vv, w, flow in state['plan']:
            if vv != v:
                continue
            factor = d['rho'][v] * state['b'][v] * flow * state['pi'][u]
            first, second = max(ks[v]-ks[w], 0), max(ks[w]-ks[u], 0)
            leg1 += factor * first
            leg2 += factor * second
            chi1 += factor * first * chi
            chi2 += factor * second * chi
            base += factor
            if ks[u] <= ks[w] <= ks[v]:
                between += factor
    return dict(original=original, leg1=leg1, leg2=leg2, chiJ_leg1=chi1, chiJ_leg2=chi2,
                inflate=(leg1+leg2)/original, between_base_fraction=between/base)


def main():
    template = next(x for x in json.loads(old.R136.read_text())['cases'] if x['id'] == 'I1')
    rec = json.loads(old.R142.read_text())['cases']['I1']
    model = old.build(template, rec)
    all_rows = json.loads(POINTS.read_text())['point_records']['8']
    rows = [x for x in all_rows if x['after'] and x['gates']['high'] and x['I'] > 0]
    assert len(rows) == 8
    out = dict(scope='Eight saved R151 m8 orbit representatives only; fixed n=4 I1 six-source nu, lambda and same-alpha. No new receiver grid, no FULL certification.',
               inputs={str(p): sha(p) for p in (PRODUCER, POINTS, old.R136, old.R142)},
               source_names=[a['name'] for a in template['atoms']],
               source_positions=[[float(old.Fq(t)) for t in a['position']] for a in template['atoms']], n=4,
               normalization={'terminal': 'pi_g=wg*nu/eg, all six sources retained', 'demand': 'a=1good*(2R-1)*pi_g', 'supply': 'd=(1-2R)+*pi_g',
                              'tilt': 'b=(eg/et)*(wt/wg)/(2R-1)', 'cost': 'sum b_v*kappa_w*Gamma_vw; kappa=2K*K0/(p*wg)',
                              'score': 'sum rho_v*delta(v,u)*Pi_t(v)*Pi_t(u); producer I includes no chiJ',
                              'lowc': 'c=D*K0_u*J_v*et/(T*Delta_v*QJ*wt_u*delta); low iff c<(25/3)*d_v^2, d_v=(1-D*K0_v/(T*Delta_v))+'},
               counts={'m8_all': len(all_rows), 'after': sum(r['after'] for r in all_rows), 'after_high_positive': len(rows)}, rows=[])
    max_replay = max_mp = max_integral = max_cost_ref = max_restore = 0.
    totals = {k: 0. for k in ('dx_p_I', 'dx_p_chiJ_I', 'dx_p_lowc_chiJ_I', 'dx_p_tilt_cost_reference')}
    all_ratios, all_cost_ratios, all_labels = [], [], []
    for row in rows:
        replay = old.one_point(model, [old.Fq(x) for x in row['xq']], template)
        assert replay['after'] and replay['pair_count'] == row['pair_count'] and replay['good'] == row['good']
        max_replay = max(max_replay, abs(replay['I'] - row['I']))
        d, ref = data_at(model, row), data_at(model, row, True)
        assert ref['good'] == d['good'] and [x > 0 for x in ref['rho']] == [x > 0 for x in d['rho']]
        assert ref['p'] * ref['eg'] >= 2 * ref['K'] * ref['q']
        assert M('.75') * M(model['lamF']) <= ref['q'] <= M(model['lamF'])
        for key in ('p', 'q', 'alpha'):
            max_mp = max(max_mp, float(abs(M(d[key]) / ref[key] - 1)))
        max_mp = max(max_mp, max(float(abs(M(d['rho'][i]) - ref['rho'][i])) for i in range(6)))
        rr = dict(xq=row['xq'], dx_weight=row['dx_weight_corrected'], p=d['p'], alpha=d['alpha'], rho=d['rho'], good=d['good'],
                  pi_g=d['pi'], R=d['R'], demand=d['a'], supply=d['supply'], kappa=d['kappa'],
                  demand_total=sum(d['a']), supply_total=sum(d['supply']),
                  supply_kappa_total=sum(d['supply'][i]*d['kappa'][i] for i in range(6)),
                  producer_I=row['I'], mp_score_I=0., chiJ_I=0., lowc_chiJ_I=0.,
                  time_windows=[], midpoint_cost_integrals={str(n): 0. for n in (1, 3, 9)}, reference_cost_integral=0.)
        # All original positive FA pair windows. De-duplicate common endpoints before cost integration.
        windows = {}
        for pair in row['pair_terms']:
            si, v, u, delta = [pair[k] for k in ('segment', 'v', 'u', 'delta')]
            sg = model['profiles'][si]
            lo, hi = float(sg['lo']), min(float(sg['hi']), (model['BFA'] * delta * d['p'] * float(sg['c'][v]) / d['Q'][v]) ** .25)
            assert hi > lo
            windows.setdefault((si, lo, hi), []).append(pair)
        for (si, lo, hi), pairs in windows.items():
            sg = model['profiles'][si]
            sf = dict(c=[float(x) for x in sg['c']], k=sg['k'])
            sm = dict(c=[M(x) for x in sg['c']], k=sg['k'])
            lm = M(sg['lo'])
            hm = min(M(sg['hi']), (M(model['BFAF']) * pairs[0]['delta'] * ref['p'] * sm['c'][pairs[0]['v']] / ref['Q'][pairs[0]['v']]) ** M('.25'))
            loglo, loghi = math.log(lo), math.log(hi)
            mid = math.sqrt(lo * hi)
            state = at_time(d, sf, mid)
            for i, j, flow in state['plan']:
                max_restore = max(max_restore, abs(state['b'][i] * d['a'][i] - state['pi'][i]))
            edges = []
            for v, w, flow in state['plan']:
                logs = [math.log2((d[name][v] / d['wg'][v]) / (d[name][w] / d['wg'][w])) for name in ('K1', 'K2', 'J')]
                label = next(name for name, ratio in zip(('K1', 'K2', 'J'), logs) if ratio > 1)
                all_labels.append(label)
                plus = [i + 1 for i in range(4) if float(old.Fq(template['atoms'][v]['thresholds'][i])) < mid <= float(old.Fq(template['atoms'][w]['thresholds'][i]))]
                minus = [i + 1 for i in range(4) if float(old.Fq(template['atoms'][w]['thresholds'][i])) < mid <= float(old.Fq(template['atoms'][v]['thresholds'][i]))]
                edges.append(dict(v=v, w=w, flow=flow, log2_kernel_over_wg_ratio=dict(zip(('K1', 'K2', 'J'), logs)), first_gt2_label=label,
                                  score_plus_coordinates=plus, score_minus_coordinates=minus, delta=max(len(plus) - len(minus), 0)))
            tw = dict(segment=si, lo=lo, hi=hi, log_length=loghi-loglo, midpoint=mid, b=state['b'], optimum_cost=state['cost'],
                      original_score_density=0., original_chiJ_score_density=0., compensation_edges=edges, pairs=[],
                      route_midpoint=route_density(d, state, sf, pairs), finite_time_refinements={})
            for pair in pairs:
                v, u, delta = [pair[k] for k in ('v', 'u', 'delta')]
                score, chi, ratio = pair_density(d, state, v, u, delta)
                endpoint_ratios = [float(pair_density(d, at_time(d, sf, t), v, u, delta)[2]) for t in (lo, hi)]
                # Every occupied pair is k_v=4,k_u=0, hence et/wu=ac*t^-4+bc is decreasing.
                assert sf['k'][v] == 4 and sf['k'][u] == 0 and max(endpoint_ratios) < 1
                all_ratios.extend(endpoint_ratios)
                score_ref = mp.quad(lambda ell: pair_density(ref, at_time(ref, sm, mp.exp(ell)), v, u, delta)[0], [mp.log(lm), mp.log(hm)])
                chi_ref = score_ref * ref['J'][v] / (3 * ref['Q'][v])
                rr['mp_score_I'] += float(score_ref)
                rr['chiJ_I'] += float(chi_ref)
                rr['lowc_chiJ_I'] += float(chi_ref)
                tw['original_score_density'] += score
                tw['original_chiJ_score_density'] += chi
                tw['pairs'].append(dict(v=v, u=u, delta=delta, chiJ=d['J'][v]/(3*d['Q'][v]),
                                        score_I=pair['I'], lowc_ratio_mid=ratio, lowc_ratio_endpoints=endpoint_ratios,
                                        score_plus_coordinates=[1, 2, 3, 4], score_minus_coordinates=[]))
                max_integral = max(max_integral, abs(float(score_ref) - pair['I']) / pair['I'])
            # Split exact rank-order changes before high precision quadrature.
            cuts = [lm, hm]
            goods = [i for i in range(6) if ref['a'][i] > 0]
            for i in goods:
                for j in goods:
                    dk = sm['k'][i] - sm['k'][j]
                    if dk:
                        ci = sm['c'][i] / ref['wg'][i] / (2 * ref['R'][i] - 1)
                        cj = sm['c'][j] / ref['wg'][j] / (2 * ref['R'][j] - 1)
                        cross = (ci / cj) ** (M(1) / dk)
                        if lm < cross < hm:
                            cuts.append(cross)
            cuts = sorted(set(cuts))
            cref = sum(mp.quad(lambda ell: at_time(ref, sm, mp.exp(ell))['cost'], [mp.log(l), mp.log(h)]) for l, h in zip(cuts[:-1], cuts[1:]))
            rr['reference_cost_integral'] += float(cref)
            for nn in (1, 3, 9):
                samples = [at_time(d, sf, math.exp(loglo+(k+.5)*(loghi-loglo)/nn)) for k in range(nn)]
                routes = [route_density(d, state1, sf, pairs) for state1 in samples]
                dt = (loghi-loglo)/nn
                estimate = dt * sum(state1['cost'] for state1 in samples)
                rr['midpoint_cost_integrals'][str(nn)] += estimate
                tw['finite_time_refinements'][str(nn)] = dict(cost_integral=estimate,
                    score_integral=dt*sum(r['original'] for r in routes),
                    chiJ_leg1_integral=dt*sum(r['chiJ_leg1'] for r in routes),
                    chiJ_leg2_integral=dt*sum(r['chiJ_leg2'] for r in routes),
                    inflate_range=[min(r['inflate'] for r in routes), max(r['inflate'] for r in routes)],
                    between_base_fraction_range=[min(r['between_base_fraction'] for r in routes), max(r['between_base_fraction'] for r in routes)])
            tw['cost_reference_integral'] = float(cref)
            tw['score_to_cost_mid_ratio'] = tw['original_chiJ_score_density'] / state['cost']
            all_cost_ratios.append(tw['score_to_cost_mid_ratio'])
            rr['time_windows'].append(tw)
        rr['cost_9_relative_error'] = abs(rr['midpoint_cost_integrals']['9'] / rr['reference_cost_integral'] - 1)
        rr['finite_time_score_relative_error'] = {str(nn): abs(sum(w['finite_time_refinements'][str(nn)]['score_integral'] for w in rr['time_windows']) / rr['mp_score_I'] - 1) for nn in (1, 3, 9)}
        max_cost_ref = max(max_cost_ref, rr['cost_9_relative_error'])
        weight = float(old.Fq(row['dx_weight_corrected'])) * d['p']
        totals['dx_p_I'] += weight * row['I']
        totals['dx_p_chiJ_I'] += weight * rr['chiJ_I']
        totals['dx_p_lowc_chiJ_I'] += weight * rr['lowc_chiJ_I']
        totals['dx_p_tilt_cost_reference'] += weight * rr['reference_cost_integral']
        out['rows'].append(rr)
    out['checks'] = dict(float_replay_max_abs_I_error=max_replay, mp65_max_rel_p_q_alpha_or_abs_rho_error=max_mp,
                         mp65_max_rel_pair_I_error=max_integral, restore_ba_current_good_pi_max_abs_error=max_restore,
                         midpoint9_max_rel_cost_integral_error=max_cost_ref, all_original_occupied_pairs_lowc=True,
                         lowc_ratio_endpoint_range=[min(all_ratios), max(all_ratios)],
                         chiJ_score_density_to_optimal_cost_mid_range=[min(all_cost_ratios), max(all_cost_ratios)],
                         compensation_first_gt2_labels=sorted(set(all_labels)))
    out['totals'] = totals
    out['limitations'] = ['R151 FIRST_three is only three tested kernels; full FIRST/history absent.',
                          'The eight orbit rows and overlap-corrected midpoint weights are finite diagnostics, not a receiver integral certificate.',
                          '65-digit recomputation is not interval arithmetic.',
                          'The rank-one infimum is a compensation cost only: it supplies no domination of original rho*chiJ*delta traffic.',
                          'No hard16/3, 2Lambda, unique-j, beta/history payment or general-n conclusion is established.']
    (HERE/'geometry_probe.json').write_text(json.dumps(out, ensure_ascii=False, indent=2, allow_nan=False)+'\n')
    print(json.dumps(dict(counts=out['counts'], checks=out['checks'], totals=totals), ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
