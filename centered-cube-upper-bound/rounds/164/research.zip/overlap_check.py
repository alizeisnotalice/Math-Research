#!/usr/bin/env python3
"""Finite implementation checks for an affinity-times-actual-score candidate.

H=b=1 only. No claim of domination of the original traffic. Float quadrature is
not an interval certificate. The older geometry_probe artifacts are not changed.
"""
from pathlib import Path
import importlib.util
import json
import math
import hashlib

HERE = Path(__file__).resolve().parent
PRODUCER = Path('/Users/zhengzhihao/Desktop/T/output/centered_cube_round151_20261015_final_checkpoint/work/receiver_probe.py')
spec = importlib.util.spec_from_file_location('r151_affinity', PRODUCER)
old = importlib.util.module_from_spec(spec)
spec.loader.exec_module(old)
np, mp = old.np, old.mp
S = [0., .05, .5, 1.]
DS = [0., .01, .25, .5, 1., 2., 8.]
NS = [1, 4, 16, 64, 256, 4096, 65536]
RADIUS = 40.
CONSTANT = 8 / math.sqrt(math.e)


def G(t):
    a = np.asarray(t, dtype=float)
    out = np.empty_like(a)
    inside = a <= .5
    out[inside] = a[inside] - old.expn(4, .5-a[inside]) + old.expn(4, .5+a[inside])
    out[~inside] = .5 - old.expn(4, a[~inside]-.5) + old.expn(4, a[~inside]+.5)
    return out


def C(t):
    a = np.abs(np.asarray(t, dtype=float))
    out = np.empty_like(a)
    inside = a <= 1
    out[inside] = 1-a[inside]+G(.5+a[inside])-G(np.array(.5))
    out[~inside] = G(a[~inside]+.5)-G(a[~inside]-.5)
    return float(out) if out.ndim == 0 else out


def density(x, s):
    return (1-s)*(np.abs(x) <= .5) + s*old.phi_np(x)


def integration_cuts(d):
    # Hard jumps and phi formula breaks; long smooth intervals are also cut.
    base = sorted(set([-RADIUS, -.5, .5, d-.5, d+.5, RADIUS+d]))
    cuts = [base[0]]
    for l, h in zip(base[:-1], base[1:]):
        cuts.extend(np.linspace(l, h, max(1, math.ceil((h-l)/2))+1)[1:].tolist())
    return cuts


AFFINITY = {}


def affinity(s, d, order=96):
    d = abs(float(d))
    key = (s, d, order)
    if key not in AFFINITY:
        nodes, weights = np.polynomial.legendre.leggauss(order)
        cuts = integration_cuts(d)
        l, h = np.array(cuts[:-1]), np.array(cuts[1:])
        x = (l[:, None]+h[:, None])/2+(h-l)[:, None]/2*nodes[None, :]
        f = np.sqrt(density(x, s)*density(x-d, s))
        AFFINITY[key] = float(np.sum((h-l)/2*(f@weights)))
    return AFFINITY[key]


def actual_score(groups):
    """groups = [(multiplicity, v_i-y_i, u_i-y_i)], no coordinate expansion."""
    active = [(count, C(v), C(u)) for count, v, u in groups if count]
    events = sorted(set([.5, 1.] + [max(.5, min(1., t)) for _, cv, cu in active for t in (cv, cu)]))
    actual = sumabs = 0.
    for l, h in zip(events[:-1], events[1:]):
        mid = math.sqrt(l*h)
        signed = [count*(int(cv < mid)-int(cu < mid)) for count, cv, cu in active]
        actual += abs(sum(signed))*math.log(h/l)
        sumabs += sum(abs(x) for x in signed)*math.log(h/l)
    return actual, sumabs, len(events)-1


def evaluate(s, n, groups, name, order=96):
    assert sum(g[0] for g in groups) == n
    actual, sumabs, pieces = actual_score(groups)
    logs = []
    for count, v, u in groups:
        if count:
            a = affinity(s, abs(v-u), order)
            logs.append(-math.inf if a <= 0 else count*math.log(a))
    logaff = sum(logs)
    prod = math.exp(logaff) if logaff > -745 else 0.
    val = prod*actual
    return dict(name=name, s=s, n=n, groups=[list(g) for g in groups if g[0]],
                actual_time_score=actual, coordinate_sumabs_time_score=sumabs,
                cancellation_fraction=1-actual/sumabs if sumabs else 0., score_segments=pieces,
                log_tensor_affinity=None if not math.isfinite(logaff) else logaff,
                tensor_affinity=prod, lhs=val, lhs_over_sqrt_n=val/math.sqrt(n),
                fraction_of_candidate_bound=val/(CONSTANT*math.sqrt(n)))


def mp_C(t):
    t = abs(mp.mpf(str(t)))
    def gg(a):
        E = lambda x: mp.mpf(1)/3 if x == 0 else mp.expint(4, x)
        return a-E(mp.mpf('.5')-a)+E(mp.mpf('.5')+a) if a <= mp.mpf('.5') else mp.mpf('.5')-E(a-mp.mpf('.5'))+E(a+mp.mpf('.5'))
    return 1-t+gg(mp.mpf('.5')+t)-gg(mp.mpf('.5')) if t <= 1 else gg(t+mp.mpf('.5'))-gg(t-mp.mpf('.5'))


def mp_affinity(s, d):
    s, d = mp.mpf(str(s)), mp.mpf(str(d))
    def pp(x):
        return (1-s)*int(abs(x) <= mp.mpf('.5'))+s*old.phi_mp(x)
    cuts = [mp.mpf(str(x)) for x in integration_cuts(float(d))]
    return sum(mp.quad(lambda x: mp.sqrt(pp(x)*pp(x-d)), [l, h]) for l, h in zip(cuts[:-1], cuts[1:]))


def main():
    scalar = []
    for s in S:
        for d in DS:
            a48, a96 = affinity(s, d, 48), affinity(s, d, 96)
            scalar.append(dict(s=s, d=d, affinity_GL48=a48, affinity_GL96=a96, abs_GL_difference=abs(a48-a96),
                               hard_exact=max(1-d, 0.) if s == 0 else None,
                               C_d=C(d), C_0=C(0.)))
    initial = [evaluate(s, 1, [(1, 0., d)], f'initial_d{d}') for s in S for d in DS]
    for affinity_row, score_row in zip(scalar, initial):
        affinity_row.update(actual_time_score_v0_ud=score_row['actual_time_score'],
                            scalar_lhs=score_row['lhs'], fraction_of_candidate_bound=score_row['fraction_of_candidate_bound'])
    pressure = []
    for s in S:
        for d in [1-1e-8, 1., 1+1e-8]:
            pressure.append(evaluate(s, 1, [(1, 0., d)], f'hard_boundary_d{d}'))
        pressure.append(evaluate(s, 4, [(2, 0., .25), (2, .25, 0.)], 'balanced_mixed_sign_cancellation'))
        pressure.append(evaluate(s, 4, [(3, 0., .25), (1, .25, 0.)], 'unbalanced_mixed_sign_cancellation'))
        pressure.append(evaluate(s, 4, [(2, 0., .01), (1, .25, 0.), (1, .5, 1.)], 'different_threshold_intervals'))
    expanded = []
    for n in NS:
        for s in S:
            for d in DS:
                expanded.append(evaluate(s, n, [(n, 0., d)], f'uniform_center_d{d}'))
                expanded.append(evaluate(s, n, [(n, .5, .5+d)], f'uniform_shifted_d{d}'))
            j, k = n//2, n//3
            expanded.append(evaluate(s, n, [(j, 0., .01), (k, .3, .55), (n-j-k, .1, 1.1)], 'nonuniform_same_sign'))
            expanded.append(evaluate(s, n, [(j, 0., .01), (k, .25, 0.), (n-j-k, .5, 1.)], 'nonuniform_mixed_sign'))
            expanded.append(evaluate(s, n, [(n//2, 0., .25), (n-n//2, .25, 0.)], 'repeated_balanced_cancellation'))
    # Four scalar reference points only; no coordinate-wise mp tensor expansion.
    mp.mp.dps = 50
    refs = []
    for s, d in [(0., .25), (.05, .01), (.5, 1.), (1., 2.)]:
        ca, aa = mp_C(d), mp_affinity(s, d)
        refs.append(dict(s=s, d=d, mp50_C=mp.nstr(ca, 30), C_abs_error=float(abs(mp.mpf(C(d))-ca)),
                         mp50_affinity_window=mp.nstr(aa, 30), GL96_abs_error=float(abs(mp.mpf(affinity(s, d))-aa))))
    all_evals = initial+pressure+expanded
    tensor_logdiff = tensor_bounddiff = 0.
    for record in all_evals:
        r48 = evaluate(record['s'], record['n'], record['groups'], record['name'], 48)
        if r48['log_tensor_affinity'] is not None and record['log_tensor_affinity'] is not None:
            tensor_logdiff = max(tensor_logdiff, abs(r48['log_tensor_affinity']-record['log_tensor_affinity']))
        tensor_bounddiff = max(tensor_bounddiff, abs(r48['fraction_of_candidate_bound']-record['fraction_of_candidate_bound']))
    # Summary only: no large per-coordinate or full tensor menu dump.
    top = sorted(all_evals, key=lambda x: x['fraction_of_candidate_bound'], reverse=True)
    by_n = {str(n): max((r for r in expanded if r['n'] == n), key=lambda x: x['fraction_of_candidate_bound']) for n in NS}
    nonuniform = {name: max((r for r in expanded if r['name'] == name), key=lambda x: x['fraction_of_candidate_bound'])
                  for name in ('nonuniform_same_sign', 'nonuniform_mixed_sign', 'repeated_balanced_cancellation')}
    hard_error = max(abs(r['affinity_GL96']-r['hard_exact']) for r in scalar if r['s'] == 0)
    balanced = [r for r in pressure if r['name'] == 'balanced_mixed_sign_cancellation']
    assert max(r['actual_time_score'] for r in balanced) == 0
    assert all(r['coordinate_sumabs_time_score'] > 0 for r in balanced)
    out = dict(candidate='integral_x sqrt(P_s1(x-v)P_s1(x-u)) * integral_.5^1 |k_z(v)-k_z(u)| dz/z <= (8/sqrt(e))*sqrt(n)',
               scope='Finite implementation checks only, H=b=1, y=0; no original traffic domination or general-n certification.',
               input_producer=dict(path=str(PRODUCER), sha256=hashlib.sha256(PRODUCER.read_bytes()).hexdigest()),
               menus=dict(s=S, d=DS, n=NS), constant=CONSTANT,
               quadrature=dict(orders=[48, 96], window='[-40,40+d]', max_smooth_interval_length=2,
                               breaks='hard and phi formula endpoints -.5,.5,d-.5,d+.5',
                               omitted_affinity_tail_CS_upper=2*math.exp(.5-RADIUS),
                               tail_derivation='Each exterior one-sided density mass <= s*exp(.5-40); Cauchy-Schwarz per tail, then sum. This analytic tail bound does not bound GL floating quadrature error.'),
               stages=dict(initial_scalar=scalar,
                           pressure=dict(hard_exact_max_abs_error=hard_error, cases=pressure),
                           expanded=dict(evaluation_count=len(expanded), maximum_by_n=by_n, maximum_by_nonuniform_family=nonuniform)),
               mp50_checks=refs,
               summary=dict(total_evaluation_count=len(all_evals), GL48_GL96_max_abs_affinity_difference=max(r['abs_GL_difference'] for r in scalar),
                            GL48_GL96_max_abs_tensor_log_affinity_difference=tensor_logdiff,
                            GL48_GL96_max_abs_bound_fraction_difference=tensor_bounddiff,
                            mp50_max_abs_C_error=max(r['C_abs_error'] for r in refs),
                            mp50_max_abs_affinity_error=max(r['GL96_abs_error'] for r in refs),
                            maximum_bound_fraction=top[0]['fraction_of_candidate_bound'], top_five=top[:5],
                            finite_menu_exceedances=sum(r['fraction_of_candidate_bound']>1 for r in all_evals)),
               limitations=['Float quadrature agreement and four mp checks are not interval certificates.',
                            'For product kernels, affinity factorization is exact; time score is computed from the actual signed count before taking absolute value.',
                            'Only the stated finite source geometries and H=b=1 are tested.',
                            'No statement that original rho/chiJ/Psi/FA/history traffic is dominated by this candidate is made.'])
    (HERE/'overlap_check.json').write_text(json.dumps(out, ensure_ascii=False, indent=2, allow_nan=False)+'\n')
    print(json.dumps(dict(summary=out['summary'], mp50_checks=refs), indent=2))


if __name__ == '__main__':
    main()
