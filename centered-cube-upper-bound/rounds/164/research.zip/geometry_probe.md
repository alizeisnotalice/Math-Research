# R164：R151 八个真实正 receiver 的补偿—score 几何

**结论。** 在原 R151 六源 I1、n=4、固定 lambda 的 m8 网格，8 个 `after/high/I>0` 轨道代表点均能原样重放。最优 rank-one 补偿都把需求送至 G4；G4 正好也是全部原正交通的 bad 来源 u。三角路由第一腿承载全部 score，第二腿为零。补偿成本虽很小，原 chiJ-score 与它之比仍约 1.5–1.7 万，而且全部原正交通处于严格 low-c。此模型没有显示补偿费用能支付原交通。

这只是原实现门下的有限诊断。`FIRST_three` 不是完整 FIRST/history，8 个网格点不是 FULL 阳性样本或连续接收积分证书；这里不认证 FULL 反例、不推出一般 n 阶。

## 固定输入与重放口径

读取 `model_index.md` 标出的 R151 原 `receiver_probe.py`、16.5MB `receiver_probe_points.json`，以及原 producer 指向的 R136 模板、R142 `nu_exact`。沿用 producer 的六源再权重、共同 alpha、rho、good、Psi 和原 FA 截窗；不重新优化任何来源质量或 alpha。读取明细仅为筛出原 7776 个 m8 轨道行中的 12 个 after 行，其中恰有 8 个 I>0。未生成新的 receiver 网格或大历史数据。

所有六源始终保留在 terminal/current 支持中。逐点重建

\[
\pi_g(i)=w_g(i)\nu_i/e_g,\quad R_i=KQ_i/(p w_g(i)),
\quad a_i=1_G(i)(2R_i-1)\pi_g(i),\quad
d_i=(1-2R_i)_+\pi_g(i),\quad \kappa_i=2KK_{0,i}/(p w_g(i)).
\]

当前权由原 score profile 的 `wt=c*t^{-k}` 与同一个六源 et 求出；b 保留完整 `(eg/et)*(wt/wg)/(2R-1)`。按需求 b 降序、供给 kappa 升序填充 a，供给只取到满足总需求。JSON 保留逐行 terminal 向量、midpoint b、最优边、三核分离与 score 方向。

原 producer 的 I 是 `rho*delta*Pi(v)*Pi(u)` 的 dt/t 积分，**没有 chiJ**。本探路同时计算 I 及乘回 `chiJ_v=J_v/(3Q_v)` 后的积分，避免把二者互换。dt/t 在本模型 cj=b=1，等于 dz/z。

## 有限数值结果

所有原正 FA 窗口都是 `t in (.5,.628034991114724)`；正 pair 是 G1→G4，四行还含 G3→G4，均 delta=4。

| 量 | 八行范围或合计 |
|---|---:|
| 总需求 A | .19798534–.21523151 |
| G4 供给 | .82208792–.82326719 |
| G4 kappa | .0001278518–.0001372336 |
| midpoint b(G1) | 1.2846021–1.4065824 |
| midpoint b(G3)，仅 good 行 | 1.3214671–1.4949602 |
| midpoint b(CORE) | .2423511–.2427474 |
| midpoint 最优成本 | .0000235064–.0000263527 |
| midpoint 原 chiJ-score 密度 | .38805467–.41160349 |
| 上两量比值 | 15379.91–16765.14 |

全部最优供给边 w=G4。每条边的首个三核 `K_l(v)/wg(v)` 对 `K_l(w)/wg(w)` 超过2的标签都是 K1；JSON 同时保留 K1、K2、J 的 log2 比值。G1/G3→G4 的 score 正向坐标是 1,2,3,4，无负向坐标；CORE→G4 的 score 两向均空、delta=0，且 rho(CORE)=0。CORE 仍占 terminal 需求，未为减小成本而删除。

保留原 pair(v,u) 的 Psi/FA 门，按最优 Gamma 计算

\[
\sum_{v,u,w}\rho_v b_t(v)\Gamma_{vw}\Pi_t(u)
\big[(k_v-k_w)_++(k_w-k_u)_+\big],
\]

并另算同一个原 chiJ_v 加权版本。1/3/9 个 log-time midpoint 上，第一腿/原交通=1，第二腿=0，膨胀=1（浮点末位误差），介于 `[k_u,k_v]` 的路由权比例=1。这里 w=u=G4；更根本地，原 profiles 只有 k=0/4，原 pair 已取两端4/0，因此任意现有 w 都不会产生三角膨胀。**无膨胀是退化两值 score 的结果，不是一般几何发现。** 新腿没有另获原 Psi/FA/history 资格。

low-c 使用原定义

\[
c_t(v,u)=\frac{D K_{0,u}J_v e_t}
 {T\Delta_v Q_J w_t(u)\delta(v,u)},\qquad
d_v=(1-DK_{0,v}/(T\Delta_v))_+,
\quad\eta_4=25/3.
\]

所有正 pair 的 `c/(eta_4*d_v^2)` 在窗口端点范围为 `1.3836032e-6–1.7716592e-6`。该窗口 u 的 k=0，而 et=`ac*t^-4+bc`，故 c 随时间递减；端点检查覆盖整个原正窗口，不仅是 midpoint。于是该有限模型的全部原正 chiJ-score 仍在 low-c，旧高 c 付款门不覆盖它。

按原 `dx_weight_corrected*p` 加总，仅针对这8个轨道行：

| 有限离散量 | 值 |
|---|---:|
| 原 I | .00039927339883046584 |
| 原 chiJ-I | .00039642311306795563 |
| 原 low-c chiJ-I | .00039642311306795563 |
| 最优 tilt cost 时间积分 | 2.474487349469362e-8 |
| chiJ-I / tilt cost | 16020.4138 |

上述离散和不是连续 dx 积分；沿用原重叠修正权没有新增积分误差证书。hard16/3、2Lambda、唯一 j、beta/history 等外费用未由本实验支付。

## 数值核对与复现

8行 float producer I 逐值重放误差0。独立用原解析核 `kernel_mp` 在65位精度重算 p/q/QJ/共同 alpha/rho，并对 score 时间积分；p/q/alpha 相对或 rho 绝对误差最大 `9.86e-16`，逐 pair I 相对误差最大 `1.53e-15`。高区、lambda 窗口、good 及 rho 正负模式亦在 mp65 重核。b*a 恢复当前 good Pi 的最大绝对误差 `3.47e-18`。这些是高精对照，不是区间证书。

rank-one cost 的 mp65 时间积分先按 b 排序交点分段。log-time midpoint 1/3/9 点成本积分最大相对误差分别约 `.015862/.0017342/.00019234`；原 score 相应最大误差约 `.0042735/.00040858/.000044638`。无需扩大 receiver 网格即可检查时间离散误差。

在仓库根运行：

```sh
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 centered-cube-upper-bound/rounds/164/work/geometry_probe.py
```

脚本只写同目录 `geometry_probe.json`，输入路径和 SHA256 均写入其中。未加入新的外部定理或一般估计。下一步真正缺少的是：保留 same-alpha/high 与原 v,u 门，对承载全部 score 的第一腿建立与实际 p dx、dt/t、外费用兼容的联合预算；小 kappa 补偿供给和无三角膨胀本身均未给出这一付款不等式。有限任务到此停止。
