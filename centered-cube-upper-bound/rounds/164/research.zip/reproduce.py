#!/usr/bin/env python3
"""Local replay using the SHA-bound historical inputs listed in the reports."""
import argparse
import contextlib
import hashlib
import importlib.util
import io
import json
import sys
sys.dont_write_bytecode = True
from pathlib import Path

root = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--output-dir', type=Path)
parser.add_argument('--verify-only', action='store_true')
args = parser.parse_args()
manifest = json.loads((root/'manifest.json').read_text())
for name, expected in manifest['files'].items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest() == expected, name
if args.verify_only:
    print('PASS archive hashes only; no numerical rerun.')
else:
    if args.output_dir is None:
        parser.error('--output-dir is required for numerical replay')
    args.output_dir.mkdir(parents=True, exist_ok=False)
    for name in ['geometry_probe', 'overlap_check']:
        spec = importlib.util.spec_from_file_location(name, root/(name+'.py'))
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        module.HERE = args.output_dir
        with contextlib.redirect_stdout(io.StringIO()):
            module.main()
        expected = json.loads((root/(name+'.json')).read_text())
        actual = json.loads((args.output_dir/(name+'.json')).read_text())
        assert actual == expected, name
        print(name+': PASS full numerical rerun and all stored fields match.')
