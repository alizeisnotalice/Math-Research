# R144–R163 可复现真实接收模型索引

用途：给后续数值实现选取已有数据入口，不作证明。最接近目标的是 R151 的固定 I1 四维 receiver 网格；它是有限来源、真实三核/接收点的离散初探，尚非连续 FULL 认证。仓库中的轮次归档不重复包含大明细，下面标出仓库外保存路径和归档内重建入口。

## 首选：R151 receiver 网格（唯一已有多接收点联合模型）

- 明细：`/Users/zhengzhihao/Desktop/T/output/centered_cube_round151_20261015/receiver_probe_points.json`（16,552,669 bytes）。复现校验副本：`/Users/zhengzhihao/Desktop/T/output/r151_final_wrapper_replay_20261015/receiver_probe_points.json`；对应摘要 `receiver_probe.json` 记录SHA和复现输入。
- 源码/入口：`/Users/zhengzhihao/Desktop/T/output/centered_cube_round151_20261015_final_checkpoint/work/receiver_probe.py`；仓库入口为 `rounds/151/research.zip` 成员 `reproduce.py`、`receiver_verify.py`、`receiver_probe.py`。README给出的producer复现入口是 `python3 reproduce.py --rounds <绝对路径>/centered-cube-upper-bound/rounds --destination <新目录>`（需报告所列本机数值环境）。明细可以由归档包重建。
- 固定对象：I1、n=4、六个离散来源、固定lambda；m=4有600轨道点（1536展开点），m=8有7776轨道点（24576展开点）。每点同一记录含 `p,q,q_tests,QJ,alpha,rho,good,E,hard_sources,hardmass,gates,I,pair_count,pair_terms,A_integrand,B_integrand,dx_weight_corrected`。源码明确按同一来源模板 `Psi` 过滤pair；按原 FA 比值截窗形成 `I`，同时保留 hard-positive、high (`p*eg >= 2*K*q`)、heavy、FIRST_three、strict_s、scale、`tau_h_g`、`Hhat_less_Lplus` 门。`q_tests`保留q的三项原候选核检验；terminal `eg` 与当前接收 `q,p` 同行，未从rho倒推alpha。
- 正域读数：所有网格点都过初始 `before`（600/600与7776/7776）。通过完整实现后门 `after` 的点分别2/600和12/7776；再要求high后分别2点和12点，但m=4这2点 `I=0`、`rho`均为零，m=8只有8/7776点同时有 `I>0`、pair项及正rho。故已有的严格正离散交通数是 **8个 m=8 网格点**；不是连续正域体积。m=8未条件化 `2N_A≈0.008784`，条件p均值约1.427（不可互换）。
- 未认证项：cell重叠校正后网格权重总和仍为751/128=5.8671875，真并集体积3698/625=5.9168；粗细积分不收敛，且无积分误差区间证书。`FIRST_three`并非完整FIRST/history；有限I1质量、n=4、固定lambda不代表一般nu或FULL交通，也未付唯一j/top-light、beta等外价。因此将它用作可直接追加核字段/联合交通实验的种子，不能称为FULL阳性样本认证。

## 单点辅助：R154 joint-x0

- producer及输出：`/Users/zhengzhihao/Desktop/T/output/centered_cube_round154_20261015_final_checkpoint/joint_x0_probe.py`、`joint_x0_probe.json`；独立复核 `joint_x0_verify.py`、`joint_x0_verify.json`。归档入口 `rounds/154/research.zip` 同名成员；归档README记载父级完整重放与逐字段核验。
- 作用：在R151同一个I1的单个x0控制点，用R142六源mp70核缓存、R151最终 `nu_exact`，重算q、QJ、共同alpha、rho、good/bad及E；terminal权 `wg,delta` 与当前score分组另存，检查原Psi及有限FA/L菜单。72个控制行、360个固定L核查；零新核计算。
- 边界：输出scope明示“single x0 control…no other receiver/row”，不提供实际接收正域或FULL交通。可用于数值implementation核对同alpha/当前-终端字段和单行参考值，不可把72条cut/L检查计作72个空间样本。

## 仅作对照：R144 numeric_geometry

- `rounds/144/research.zip` 成员 `numeric_geometry.py`, `numeric_geometry.json`, `numeric_geometry_notes.md`。已有输入依赖R142/R143；Notes给出入口、样本口径与核误差说明。
- 6951旧接收行中179个合法正行（I1 11、P1 168），恢复出690个Psi正pair-segment；字段覆盖同一行原score、共同储备、rho、hard/FA端点及有限接收权。可作来源/位置和旧模型字段参照。
- 该包的扩展高门初筛对690段只取三处时间点，`c/eta`高门命中0，故没有符合该扩展门的高门正占用例；且原核仅局部mp精度复核，非区间证书。这里的 c/eta 高容量门与原 high 条件 p e_g≥2Kq 是不同门；不能从容量门零命中推断原 high 失败。本轮未逐行重新认证其原 high 联合资格，故仅列为旧门对照，不用它替代已经重放的 R151 样本。父级修正了初版索引中混淆这两种门的表述。

## 排除项

R162的 `research.zip` 只有单源单点log矩、同x pair、cross-core核点等有限诊断（README为52单源log矩、20同x pair、6核点）；未构成R151式FULL接收行，更没有共同alpha、当前/terminal分权及原硬/Psi/FA实际交通同域认证。不要把R162裸单源pair作为FULL来源。

## 后续数值实现的最小沿用清单

以R151 m=8点列为采样种子，保留六源同一`nu_exact`，每个receiver行独立重算原 `p,q,QJ,alpha,rho` 与终端 `eg`；逐pair保留good/bad、`Psi`、delta、hard/FA及所有资格门，分开记录当前权与terminal权。首先复核上文8个离散正点及零分支，再决定是否细化接收网格。连续正域计数、FULL/history、核向外误差和积分区间目前均未认证；R154只提供x0字段对照，R144只提供部分旧门参照。
