"""Check the simultaneous small-overlap and scale-separation test."""
from decimal import Decimal as D, localcontext
from fractions import Fraction as F
import json
from random import Random

def scale_checks(n):
    with localcontext() as ctx:
        ctx.prec=85
        v=D(n); log_n=(v+2).ln()
        last=int(v/64-1-log_n)
        levels=range(1,last+1) if n<=2**16 else sorted({1,2,4,16,64,max(1,last//3),max(1,last//2),last})
        margins=[]
        for b in levels:
            L=D(b)+1+log_n
            S=(v*L).sqrt()
            assert 8*S<=v and D(b)+1<=L
            # Exact geometric upper envelope after factoring out 4*kappa*D_g.
            log_vol=b-8*S+2*(2*v*(8*S/v).exp()*L).sqrt()
            margin=-b-2*S-log_vol
            assert margin>0
            margins.append(margin)
        return {'n':n,'levels_checked':len(margins),'smallest_margin':str(min(margins))}

def masks(seed):
    rng=Random(seed); N=24
    rows=[F(rng.randint(1,99),7) for _ in range(N)]
    a=[F(rng.randint(1,61),9) for _ in range(50)]
    P=[set(rng.sample(range(50),rng.randint(7,20))) for _ in rows]
    A=[sum(a[i] for i in p) for p in P]
    eta=[m/d for m,d in zip(rows,A)]
    # Model a directed geometrically certified pair predicate.
    mask=[[g!=h and rng.randrange(5)==0 for h in range(N)] for g in range(N)]
    u=max(sum((rows[h] for h in range(N) if mask[g][h]),F(0))/A[g] for g in range(N))
    hot=set(rng.sample(range(50),12))
    cross=sum(eta[g]*eta[h]*sum((a[i] for i in P[g]&P[h]&hot),F(0)) for g in range(N) for h in range(N) if mask[g][h] or mask[h][g])
    assert cross<=2*u*sum(rows)
    return True
if __name__=='__main__':
    print(json.dumps({'scale_geometry':[scale_checks(2**b) for b in (12,16,24,32,48,64)],'exact_directed_masks':sum(masks(i) for i in range(96)),'scope':'Small dimensions of mask fixture test ledger algebra only. Decimal scalar tests are finite numerical checks.'},indent=2))
