"""R721 rich-star scalar bounds, exact Steiner polynomials, true A comparison.

Only audit.json is generated. Local Arb256/384; independent Decimal110
backend runs on MacBook if SSH responds, otherwise locally with honest status.
"""
from fractions import Fraction as F
from math import comb,factorial
from pathlib import Path
import hashlib,json,platform,socket,subprocess,sys

BS=[12,16,20,24,32,40,48,56,64]


def steiner_exact():
    rows=[]
    for n in range(2,13):
        for s,r in [(F(1,2),F(0)),(F(1,2),F(1,16)),(F(1),F(1,4)),(F(3,2),F(1)),(F(1),F(4))]:
            coefficients=[F(1)]
            for dimension in range(1,n+1):
                coefficients=[2*s*(coefficients[j] if j<len(coefficients) else 0)
                              +(2*coefficients[j-1]/j if j else 0) for j in range(dimension+1)]
            recursive=sum((c*r**j for j,c in enumerate(coefficients)),F(0))
            closed=(2*s)**n*sum((F(comb(n,j),factorial(j))*(r/s)**j for j in range(n+1)),F(0))
            assert recursive==closed
            rows.append({'n':n,'s':str(s),'r':str(r),'volume_exact':str(closed)})
    return rows


def independent_decimal():
    from decimal import Decimal as D,localcontext
    with localcontext() as c:
        c.prec=110;scalars=[];real=[]
        for b in BS:
            n=1<<b;root=1<<(b//2);T=32*root;l2=D(2).ln();h=1+D(1)/(32*n);kappa=(D(n)*h.ln()).exp()
            middle=D(2).ln()+kappa.ln()-D(T-1)/2
            tail=D(2).ln()+kappa.ln()-D(n)/2
            sharp=D(2).ln()+kappa.ln()-T+2+2*D(1).exp()*n/T
            tailtest=32*D(1).exp()*D(n+1).ln()/n
            scalars.append({'b':b,'values':[str(middle),str(tail),str(sharp),str(tailtest)]})
        for b in [32,48,64]:
            n=1<<b;a=32*n;root=1<<(b//2);l2=D(2).ln();t=D(root)/l2
            lh=(1+D(1)/a).ln();g=(1-D(2)/a).ln();Q=(D(n-1)*g).exp();W=(1-Q)/8+Q/a
            JA=int(D(root)/W);kappa=(D(n)*lh).exp();Ta=t/(4*kappa)
            for K in [4,8,16]:
                JB=int(D(K*root)/W);lRB=lh-D(JB)*g;lAmin=lRB+l2/n+lh;lRA=lAmin-D(JA)*g
                Y=l2+D(n)*lRA;R=2*(lh+lRA).exp();radius=R*((1+Y)/Ta).ln()
                real.append({'b':b,'K':K,'values':[str(Y),str(Ta),str(radius)]})
        return {'host':socket.gethostname(),'python':sys.version,'Steiner_exact':steiner_exact(),
                'scalars':scalars,'real':real}


if '--remote' in sys.argv:
    print(json.dumps(independent_decimal()));raise SystemExit(0)


from flint import arb,ctx
BASE=Path(__file__).resolve().parent


def st(x):return x.str(38)


def floor_unique(x):
    v=x.floor().unique_fmpz();assert v is not None
    return int(v)


def scalar(b,bits):
    ctx.prec=bits;A=arb;n=1<<b;root=1<<(b//2);T=32*root;kmin=T-1
    h=1+A(1)/(32*n);logkappa=n*h.log();pref=A(2).log()+logkappa;e=A(1).exp()
    assert T>=2 and kmin<=n
    # For kmin<=k<=n, log((k+2)/T)<=k/T and exp(k/n)<=e.
    # Therefore4sqrt(n*a)/k <=sqrt(32e*n/(T*kmin))<1.
    middle_ratio=(32*e*n/(T*kmin)).sqrt()
    assert middle_ratio<1
    tail_ratio=32*e*A(n+1).log()/n
    assert tail_ratio<1
    middle=pref-A(kmin)/2;tail=pref-A(n)/2
    sharp=pref-T+2+2*e*n/T
    assert middle<=-15*root and tail<=-15*root and sharp<=middle
    all_strip_log=(middle.exp()/(-(-A('.5')).expm1())+tail.exp()).log()
    assert all_strip_log<=-15*root
    samples=[]
    for k in sorted({kmin,T,min(n,T+max(1,root//16)),min(n,3*T//2),min(n,2*T),n}):
        a=2*(A(k)/n).exp()*(A(k+2)/T).log()
        bound=pref-k+2*(n*a).sqrt()
        assert bound<=pref-A(k)/2
        samples.append({'k':str(k),'r_over_s_upper':st(a),'log_cluster_volume_over_B_upper_Bessel':st(bound),
                        'log_target_2kappa_exp_minus_k_over_2':st(pref-A(k)/2)})
    return {'b':b,'n':f'2^{b}','T_exact':str(T),'k_min_exact':str(kmin),'precision_bits':bits,
            'middle_sufficient_ratio_below_one':st(middle_ratio),
            'tail_sufficient_ratio_below_one':st(tail_ratio),
            'uniform_middle_log_bound':st(middle),'uniform_tail_log_bound':st(tail),
            'sharper_uniform_middle_log_bound':st(sharp),
            'all_middle_strips_plus_grouped_tail_log_bound':st(all_strip_log),
            'combined_cluster_volume_over_B_at_most_exp_minus_15sqrt_n':True,
            'sampled_k_envelopes':samples,'_values':(middle,tail,sharp,tail_ratio)}


def stringent_base():
    ctx.prec=384;A=arb;n=4096;T=2048;h=1+A(1)/(32*n);pref=A(2).log()+n*h.log()
    values=[]
    for k in range(T-1,n+1):
        a=2*(A(k)/n).exp()*(A(k+2)/T).log()
        values.append((k,pref-k+2*(n*a).sqrt()))
    kbest,best=values[0]
    for k,v in values[1:]:
        if v>best:kbest,best=k,v
    assert all(v<best for k,v in values if k!=kbest)
    exact=[]
    for k in sorted({T-1,T,kbest,n}):
        a=2*(A(k)/n).exp()*(A(k+2)/T).log()
        term=total=A(1)
        for ell in range(n):
            term*=A(n-ell)*a/(ell+1)**2;total+=term
        logvol=pref-k+total.log()
        assert logvol<=pref-A(k)/2
        exact.append({'k':k,'interval_Steiner_full_degree':n,'log_cluster_volume_over_B_upper':st(logvol)})
    return {'n':n,'all_integer_k_scanned':len(values),'worst_Bessel_k':kbest,
            'worst_Bessel_log_bound':st(best),'full_Steiner_checks':exact,
            'scope':'The entire middle-strip integer envelope was scanned only at the most stringent starting n. Larger dimensions are covered by the analytic uniform inequalities.'}


def real(b,K,bits):
    ctx.prec=bits;A=arb;n=1<<b;a=32*n;root=1<<(b//2);l2=A(2).log();L=b*l2;t=A(root)/l2
    lh=(A(1)/a).log1p();g=(-A(2)/a).log1p();kappa=(n*lh).exp()
    W=-((n-1)*g).expm1()/8+((n-1)*g).exp()/a
    JA=floor_unique(A(root)/W);JB=floor_unique(A(K*root)/W)
    lRB=lh-JB*g;lAmin=lRB+l2/n+lh;lRA=lAmin-JA*g
    assert lRA<l2 and n*(lAmin-lRB)>l2
    delta=A('.5');Ta=delta*t/(2*kappa)
    B_log=n*(l2+lRA);Y=l2+n*lRA;R=2*(lh+lRA).exp();distance=A('.25')
    shared_radius=R*((1+Y)/Ta).log();global_radius=R*A(n+1).log()
    assert Y>=Ta-1 and distance<=shared_radius and distance<=global_radius
    assert Ta<32*root
    # w=A=(1/2,0,...), z=(3/4,0,...) are strict common interior points
    # of every A parent and every retained receiver parent.
    assert A('.75')>A('.5') and A('.75')<A('.875')
    k=floor_unique(Y)
    scalar_upper=None
    if k<=n:
        aratio=2*(A(k)/n).exp()*(A(k+2)/Ta).log()
        scalar_upper=A(2).log()+kappa.log()-k+2*(n*aratio).sqrt()
        assert scalar_upper<0
    logVR=-A((3*b//4+4)*n)*l2
    return {'b':b,'n':f'2^{b}','K':K,'precision_bits':bits,
            'actual_t_definition':'sqrt(n)/log2','actual_shared_mass_delta_exact':'1/2',
            'actual_clipped_mass_exact':'1/2 (all A sources retained under B=max d_i)',
            'actual_T':st(Ta),'stress_T_exact':str(32*root),'actual_T_over_stress_T':st(Ta/(32*root)),
            'B_log':st(B_log),'Y':st(Y),'Y_over_sqrt_n':st(Y/root),
            'actual_common_points':'w=(1/2,0,...), z=(3/4,0,...); both lie in the genuine common A half-crossing cell',
            'actual_L1_distance_exact':'1/4','permitted_L1_distance_from_shared_bound':st(shared_radius),
            'permitted_L1_distance_from_global_cap':st(global_radius),
            'default_history_satisfies_T_32sqrt_n':False,
            'actual_Y_bin_k':str(k),'actual_T_scalar_log_volume_over_B_upper':st(scalar_upper) if scalar_upper is not None else None,
            'actual_true_receiver_VR_over_B_log':st(logVR-B_log),
            '_values':(Y,Ta,shared_radius)}


def main():
    exact=steiner_exact();scalars=[];histories=[]
    for b in BS:
        lo=scalar(b,256);hi=scalar(b,384)
        for x,y in zip(lo['_values'],hi['_values']):assert x.overlaps(y)
        hi['_remote_values']=[float(x) for x in hi['_values']];del hi['_values'];scalars.append(hi)
    for b in [32,48,64]:
        for K in [4,8,16]:
            lo=real(b,K,256);hi=real(b,K,384)
            for x,y in zip(lo['_values'],hi['_values']):assert x.overlaps(y)
            hi['_remote_values']=[float(x) for x in hi['_values']];del hi['_values'];histories.append(hi)
    base=stringent_base()
    command=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=5','macbook-math','/Users/zhengzhihao/.venv/bin/python -B - --remote']
    run=subprocess.run(command,input=Path(__file__).read_text(),text=True,capture_output=True,timeout=30)
    remote={'command':command,'exit_code':run.returncode,'stderr':run.stderr}
    if run.returncode==0:
        check=json.loads(run.stdout);remote['result']=check
    else:
        remote['stdout']=run.stdout;check=independent_decimal();remote['local_Decimal_fallback']=check
    assert exact==check['Steiner_exact']
    for local,other in zip(scalars,check['scalars']):
        assert local['b']==other['b']
        for x,y in zip(local['_remote_values'],other['values']):assert abs(x-float(y))<=max(1e-12,abs(x)*1e-12)
    for local,other in zip(histories,check['real']):
        assert local['b']==other['b'] and local['K']==other['K']
        for x,y in zip(local['_remote_values'],other['values']):assert abs(x-float(y))<=max(1e-12,abs(x)*1e-12)
    remote['independent_backend_crosscheck_passed']=True
    for row in scalars+histories:del row['_remote_values']
    result={'host':socket.gethostname(),'python':sys.executable,'python_version':platform.python_version(),
            'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'scalar_cases':scalars,'exact_small_dimension_Steiner':exact,'most_stringent_starting_dimension':base,
            'real_A_crosschecks':histories,'remote':remote,
            'uniform_scalar_proof':['Assume the rich-star hypotheses already give Y>=T-1 and r<=R*log((1+Y)/T), with T=32sqrt(n). For k=floorY<=n, r/s<=2exp(k/n)log((k+2)/T).',
                                   'All numerical cases have integer sqrt(n), so k_min=T-1 exactly. For arbitrary non-square n the correct implication is k>=floor(T-1)>T-2; replacing T-1 by T-2 changes only an absolute constant and preserves every stated stretched-exponential conclusion.',
                                   'For any a>=0, sum_l binom(n,l)a^l/l!<=sum_l(na)^l/(l!)^2=I0(2sqrt(na))<=exp(2sqrt(na)). This is an analytic upper bound, not numerical truncation.',
                                   'Since log((k+2)/T)<=k/T and exp(k/n)<=e, 4sqrt(na)/k<=sqrt(32en/(Tk_min))<1. Thus every integer middle bin satisfies volume/B<=2kappa exp(-k/2).',
                                   'The grouped k>=n radius cap gives a<=2e log(n+1). The sufficient condition n>=32e log(n+1) holds at n4096 and thereafter by monotonicity of n/log(n+1), giving2kappa exp(-n/2).',
                                   'Sum the middle-bin bounds geometrically, costing only1/(1-exp(-1/2)), and add the single grouped tail. Since kappa<exp(1/32), T=32sqrt(n), n>=4096, the entire sum is<=exp(-15sqrt(n)); no n-bin factor occurs.',
                                   'An additional valid bound replaces log((k+2)/T) by(k+2-T)/T and completes the square, yielding log(volume/B)<=log(2kappa)-T+2+2en/T for every middle bin.'],
            'Steiner_proof':['vol(Q_s+B1(r))=(2s)^n sum_l binom(n,l)(r/s)^l/l!. Independent exact recurrence: V_n=2s V_(n-1)+2 integral_0^rV_(n-1)(u)du.',
                             'Small dimensions2..12 and five rational radius pairs compare both expressions exactly. At n4096, the full degree4096 polynomial is interval-evaluated at the worst scanned Bessel bin and boundary samples.'],
            'scope':['The nine scalar tests span n2^12..2^64 and certify global inequalities, not just selected grid points. The complete2050-bin scan is supplementary at the starting dimension.',
                     'The real A histories retain their actual default t=sqrt(n)/log2. Their Tactual is about0.349sqrt(n), not32sqrt(n); they are NOT examples satisfying the new high-T hypotheses.',
                     'Real shared/clipped mass, Y, and nonzero common-point distance1/4 satisfy their corresponding actual-T inequalities. The actual cap Y is large enough that its own scalar envelope is negative.',
                     'The analytic rich-star reduction giving the initial Y/r constraints is assumed as requested; these computations verify the scalar consequences and the stated genuine-history comparison, not a uniform endpoint theorem.',
                     'The scalar and real-history Arb384 checks agree with256 bits and the independent Decimal110/exact rational backend. The supplemental full starting-dimension scan and degree4096 polynomials use384 bits. The independent backend actual host is recorded. Only audit.py/json are written; no Git or remote files.']}
    output=BASE/'audit.json';output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'output':str(output),'remote_exit':run.returncode,'independent_backend_passed':True,
                      'exact_Steiner_cases':len(exact),'worst_start':base,
                      'scalar_rows':[{k:r[k] for k in ['b','T_exact','uniform_middle_log_bound','uniform_tail_log_bound','combined_cluster_volume_over_B_at_most_exp_minus_15sqrt_n']} for r in scalars]},indent=2))


if __name__=='__main__':main()
