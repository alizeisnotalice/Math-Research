#!/usr/bin/env python3
"""Certified compact receiver subsets for actual positive L1 box inputs.
Stdlib rational / integer interval certificates. Continuous hard first contact,
whole-window genuine E2 gate, original middle test; conservative continuum
Hall brackets and sourcewise feasible flow. Finite fixtures, no general bound.
"""
from fractions import Fraction as F
from pathlib import Path
from functools import lru_cache
from itertools import product
from collections import deque
import json, math, time
SEED=840611
S=1<<60
Z=1<<24
def clean(x):
    if isinstance(x,F):return str(x)
    if isinstance(x,dict):return {str(k):clean(v) for k,v in x.items()}
    if isinstance(x,(tuple,list)):return [clean(v) for v in x]
    return x


def trim(p):
    p=list(map(F,p))
    while len(p)>1 and not p[-1]:p.pop()
    return tuple(p)


def zero(p):return len(p)==1 and p[0]==0
def add(p,q):return trim([(p[i] if i<len(p) else 0)+(q[i] if i<len(q) else 0) for i in range(max(len(p),len(q)))])
def scale(p,a):return trim([F(a)*x for x in p])
def derivative(p):return trim([i*p[i] for i in range(1,len(p))] or [0])


def multiply(p,q):
    out=[F(0)]*(len(p)+len(q)-1)
    for i,a in enumerate(p):
        for j,b in enumerate(q):out[i+j]+=a*b
    return trim(out)


def evaluate(p,x):
    value=F(0)
    for a in reversed(p):value=value*x+a
    return value


def remainder(p,q):
    assert not zero(q);out=list(p)
    while len(out)>=len(q) and not zero(trim(out)):
        a=out[-1]/q[-1];shift=len(out)-len(q)
        for j,b in enumerate(q):out[shift+j]-=a*b
        out=list(trim(out))
    return trim(out)


@lru_cache(None)
def sturm(p):
    p=trim(p)
    if zero(p):return ()
    seq=[p];d=derivative(p)
    if zero(d):return tuple(seq)
    seq.append(d)
    while True:
        rem=scale(remainder(seq[-2],seq[-1]),-1)
        if zero(rem):break
        # Positive rational scaling preserves the Sturm signs.
        rem=scale(rem,1/abs(rem[-1]));seq.append(rem)
    return tuple(seq)


def sign(x):return 1 if x>0 else -1 if x<0 else 0


def side_sign(p,x,side):
    """Exact one-sided endpoint sign, including repeated roots/gcd zeros."""
    assert side in (-1,1)
    d=p;order=0
    while not zero(d):
        value=evaluate(d,x)
        if value:return sign(value)*(side if order%2 else 1)
        d=derivative(d);order+=1
    return 0


def variation(seq,x,side):
    signs=[side_sign(p,x,side) for p in seq]
    signs=[v for v in signs if v]
    return sum(a!=b for a,b in zip(signs,signs[1:]))


def root_count(p,a,b):
    """Count distinct roots strictly in (a,b), using V(a+)-V(b-)."""
    assert a<b and not zero(p)
    seq=sturm(p);count=variation(seq,a,1)-variation(seq,b,-1)
    assert count>=0
    return count


class Flow:
    def __init__(self,N):self.graph=[[] for _ in range(N)];self.original=[]
    def edge(self,a,b,c):
        ai=len(self.graph[a]);bi=len(self.graph[b]);self.graph[a].append([b,bi,c]);self.graph[b].append([a,ai,0]);self.original.append((a,b,c,ai))
    def maxflow(self,s,t):
        value=0;N=len(self.graph)
        while True:
            level=[-1]*N;level[s]=0;q=deque([s])
            while q:
                v=q.popleft()
                for w,rev,c in self.graph[v]:
                    if c and level[w]<0:level[w]=level[v]+1;q.append(w)
            if level[t]<0:break
            ptr=[0]*N
            def dfs(v,f):
                if v==t:return f
                while ptr[v]<len(self.graph[v]):
                    e=self.graph[v][ptr[v]];w,rev,c=e
                    if c and level[w]==level[v]+1:
                        z=dfs(w,min(f,c))
                        if z:e[2]-=z;self.graph[w][rev][2]+=z;return z
                    ptr[v]+=1
                return 0
            while True:
                z=dfs(s,sum(c for a,b,c,i in self.original if a==s))
                if not z:break
                value+=z
        reachable={s};q=deque([s])
        while q:
            v=q.popleft()
            for w,rev,c in self.graph[v]:
                if c and w not in reachable:reachable.add(w);q.append(w)
        return value,reachable


def ceildiv(a,b):return -(-a//b)
def floor_scaled(x):return x.numerator*S//x.denominator
def ceil_scaled(x):return ceildiv(x.numerator*S,x.denominator)

@lru_cache(32768)
def expneg(x):
    """e^-x in exact dyadic enclosure; positive Taylor then inversion/squaring."""
    x=F(x);assert x>=0
    if x==0:return F(1),F(1)
    k=0;v=x
    while v>F(1,2):v/=2;k+=1
    vl=floor_scaled(v);vu=ceil_scaled(v)
    tl=tu=S;sl=su=S
    for j in range(1,21):
        tl=tl*vl//(S*j);tu=ceildiv(tu*vu,S*j);sl+=tl;su+=tu
    nxt=ceildiv(tu*vu,S*21);su+=2*nxt
    lo=S*S//su;hi=ceildiv(S*S,sl)
    for _ in range(k):lo=lo*lo//S;hi=ceildiv(hi*hi,S)
    return F(lo,S),F(hi,S)

@lru_cache(None)
def phi_grid(zint,nt):
    z=F(zint,Z);low=F(0);up=F(0)
    vals=[]
    for j in range(1,nt+1):
        t=F(j,nt)
        if z<=F(1,2):
            a,b=expneg((F(1,2)-z)/t),expneg((F(1,2)+z)/t)
            vals.append((t*(2-a[1]-b[1]),t*(2-a[0]-b[0])))
        else:
            a,b=expneg((z-F(1,2))/t),expneg((z+F(1,2))/t)
            vals.append((max(F(0),t*(a[0]-b[1])),t*(a[1]-b[0])))
    # The true t integrand is increasing, including across z=.5.
    low=sum(v[0] for v in vals[:-1])/nt;up=sum(v[1] for v in vals)/nt
    return F(floor_scaled(low),S),F(ceil_scaled(up),S)

def phi_bounds(z,nt):
    z=abs(F(z));lo=z.numerator*Z//z.denominator;hi=ceildiv(z.numerator*Z,z.denominator)
    return phi_grid(hi,nt)[0],phi_grid(lo,nt)[1]

def ov(x,a,b,L):return max(F(0),min(x+L/2,b)-max(x-L/2,a))
def capture(boxes,points,L):
    return sum(box['density']*math.prod(ov(x,a,b,L) for x,(a,b) in zip(point,box['bounds'])) for box,point in zip(boxes,points))

def point_envelope(boxes,receiver,upper):
    out=[]
    for box in boxes:
        point=[]
        for (a,b),(u,v) in zip(box['bounds'],receiver):
            c=(a+b)/2
            point.append(min(max(c,u),v) if upper else (u if abs(u-c)>=abs(v-c) else v))
        out.append(tuple(point))
    return tuple(out)

@lru_cache(None)
def hard_certificate_cached(boxkey,points,n):
    boxes=[dict(bounds=b,density=d) for b,d in boxkey]
    breaks=sorted({F(1),F(2)}|{2*abs(x-face) for box,point in zip(boxes,points) for x,ab in zip(point,box['bounds']) for face in ab if 1<2*abs(x-face)<2})
    rows=[];hit=None
    for a,b in zip(breaks,breaks[1:]):
        u=(2*a+b)/3;v=(a+2*b)/3;numerator=(F(0),)
        for box,point in zip(boxes,points):
            term=(box['density'],)
            for x,(c,d) in zip(point,box['bounds']):
                p=ov(x,c,d,u);q=ov(x,c,d,v);slope=(q-p)/(v-u)
                term=multiply(term,(p-slope*u,slope))
            numerator=add(numerator,term)
        diff=add(numerator,(F(0),)*n+(F(-1),))
        seq=sturm(diff);count=root_count(diff,a,b)
        rec=dict(left=a,right=b,numerator=numerator,difference=diff,sturm=seq,
                 variation_left_plus=variation(seq,a,1),variation_right_minus=variation(seq,b,-1),open_roots=count,
                 witness_point=(a+b)/2,witness_difference=evaluate(diff,(a+b)/2))
        for t in (u,v,(a+b)/2):assert evaluate(numerator,t)==capture(boxes,points,t)
        rows.append(rec)
        if hit is None:
            if evaluate(diff,a)==0:
                hit=dict(bracket=[a,a],interval_index=len(rows)-1,endpoint=True)
            elif count:
                assert count==1, "qualified fixtures require a unique first-interval root"
                aa,bb=a,b
                for _ in range(28):
                    mid=(aa+bb)/2
                    if evaluate(diff,mid)==0:aa=bb=mid;break
                    if root_count(diff,aa,mid):bb=mid
                    else:aa=mid
                assert aa==bb or root_count(diff,aa,bb)==1
                earlier=root_count(diff,a,aa) if aa>a else 0;assert earlier==0
                hit=dict(bracket=[aa,bb],interval_index=len(rows)-1,endpoint=False,within_first_interval_earlier_open_roots=earlier)
            else:assert evaluate(diff,(a+b)/2)<0
        rec['earlier_than_first_interval']=hit is None
    assert hit is not None
    idx=hit['interval_index'];p=rows[idx]['difference'];lo,hi=hit['bracket']
    assert side_sign(p,lo,-1)<0 and side_sign(p,hi,1)>0
    hit['left_sign']=side_sign(p,lo,-1);hit['right_sign']=side_sign(p,hi,1)
    return dict(physical_breakpoints=breaks,intervals=rows,first_contact=hit,anchor_average=capture(boxes,points,F(1)))

def hard_certificate(boxes,points,n):
    return hard_certificate_cached(tuple((tuple(b['bounds']),b['density']) for b in boxes),points,n)

def uniform_derivative(boxes,receiver,lo,hi,n):
    total=F(0);records=[]
    for box in boxes:
        mins=[];maxs=[];slopes=[]
        for (a,b),(u,v) in zip(box['bounds'],receiver):
            # These fixtures are strictly outside every source box.
            assert v<a or u>b
            near=a-v if v<a else u-b;far=a-u if v<a else v-b
            if hi/2<=near:om=ox=F(0);sl=F(0);branch='zero'
            elif lo/2>=far+(b-a):om=ox=b-a;sl=F(0);branch='full'
            else:
                assert lo/2>far and hi/2<near+(b-a),'root enclosure crosses a capture branch'
                om=lo/2-far;ox=hi/2-near;sl=F(1,2);branch='partial'
            mins.append(om);maxs.append(ox);slopes.append(sl)
        lower=box['density']*(lo*sum(slopes[j]*math.prod(mins[k] for k in range(n) if k!=j) for j in range(n))-n*math.prod(maxs))
        total+=lower;records.append(dict(overlap_min=mins,overlap_max=maxs,slopes=slopes,derivative_numerator_lower=lower))
    assert total>0
    return dict(components=records,derivative_numerator_lower=total)

def coordinate_integral(a,b,u,v,lo,hi,ny,nt):
    """Bound L^-1 int_a^b phi((x-y)/L)dy, for outside receiver interval."""
    assert v<a or u>b
    near=a-v if v<a else u-b;far=a-u if v<a else v-b
    width=b-a;lower=upper=F(0)
    for j in range(ny):
        lower+=phi_bounds((far+width*F(j+1,ny))/lo,nt)[0]
        upper+=phi_bounds((near+width*F(j,ny))/hi,nt)[1]
    return width*lower/(ny*hi),width*upper/(ny*lo)

@lru_cache(None)
def smooth_interval_cached(boxkey,receiver,lo,hi,ny,nt):
    lower=upper=F(0);parts=[]
    for bounds,density in boxkey:
        factors=[coordinate_integral(a,b,u,v,lo,hi,ny,nt) for (a,b),(u,v) in zip(bounds,receiver)]
        low=density*math.prod(x[0] for x in factors);up=density*math.prod(x[1] for x in factors)
        lower+=low;upper+=up;parts.append(dict(coordinate_intervals=factors,component_interval=[low,up]))
    # Outward round the final enclosure. Quantities may otherwise grow long.
    lower=F(floor_scaled(lower),S);upper=F(ceil_scaled(upper),S)
    return dict(interval=[lower,upper],components=parts)

def smooth_interval(boxes,receiver,lo,hi,ny,nt):
    return smooth_interval_cached(tuple((tuple(b['bounds']),b['density']) for b in boxes),tuple(receiver),lo,hi,ny,nt)

def receiver_certificate(boxes,receiver,n,ny=24,nt=48,nscale=32):
    upperpoints=point_envelope(boxes,receiver,True);lowerpoints=point_envelope(boxes,receiver,False)
    hcupper=hard_certificate(boxes,upperpoints,n);hclower=hard_certificate(boxes,lowerpoints,n)
    lo=hcupper['first_contact']['bracket'][0];hi=hclower['first_contact']['bracket'][1]
    assert 1<lo<=hi<2 and hcupper['anchor_average']<F(1,2)
    witness=min(F(2),hi+F(1,100000))
    strict=capture(boxes,lowerpoints,witness)/witness**n;assert strict>1
    deriv=uniform_derivative(boxes,receiver,lo,hi,n)
    selected=smooth_interval(boxes,receiver,lo,hi,ny,nt)
    window=[]
    for j in range(nscale):
        a=1+F(j,nscale);b=1+F(j+1,nscale)
        window.append(dict(scale_interval=[a,b],upper=smooth_interval(boxes,receiver,a,b,ny,nt)['interval'][1]))
    pmax=max(x['upper'] for x in window);m=phi_bounds(F(1,2),nt);M=phi_bounds(F(0),nt)
    middle_upper=F(1,2)*m[1]*M[1]**(n-1)
    pl,pu=selected['interval'];mid=pl>middle_upper
    layer=None;thresholds=[]
    for j in range(4):
        lower=tuple(F(1,2)*x for x in expneg(F((1<<(j+1))-1)))
        upper=tuple(F(1,2)*x for x in expneg(F((1<<j)-1)))
        thresholds.append(dict(j=j,lower_P_threshold=lower,upper_P_threshold=upper))
        if pl>lower[1] and pu<=upper[0]:layer=j
    qualified=pmax<=F(1,2) and mid and layer is not None
    assert qualified,(pmax,selected['interval'],middle_upper,layer)
    return dict(receiver=receiver,volume=math.prod(v-u for u,v in receiver),upper_envelope_points=upperpoints,lower_envelope_points=lowerpoints,
                upper_hard_certificate=hcupper,lower_hard_certificate=hclower,Lstar_interval=[lo,hi],uniform_derivative=deriv,
                anchor_upper=hcupper['anchor_average'],strict_witness_scale=witness,strict_witness_lower=strict,
                selected_P=selected,window_scale_intervals=window,whole_window_P_upper=pmax,phi_half_interval=m,phi_zero_interval=M,
                original_middle_threshold_upper=middle_upper,middle_test=mid,kappa_layer=layer,kappa_thresholds=thresholds,qualified=qualified,
                t_Riemann_count=nt,source_Riemann_count=ny,scale_window_count=nscale)
def source_partition(boxes,m):
    bins=[]
    for i,box in enumerate(boxes):
        for idx in product(range(m),repeat=len(box['bounds'])):
            bounds=tuple((a+(b-a)*F(k,m),a+(b-a)*F(k+1,m)) for (a,b),k in zip(box['bounds'],idx))
            bins.append(dict(component=i,bounds=bounds,mass=box['density']*math.prod(b-a for a,b in bounds)))
    assert sum(x['mass'] for x in bins)==sum(b['density']*math.prod(v-u for u,v in b['bounds']) for b in boxes)
    return bins

def graph_rows(certs,bins,boxes):
    rows=[]
    for c in certs:
        lo,hi=c['Lstar_interval'];r=c['receiver']
        inner=tuple((v-lo/2,u+lo/2) for u,v in r);outer=tuple((u-hi/2,v+hi/2) for u,v in r)
        im=om=0
        for i,b in enumerate(bins):
            if all(a>=u and z<=v for (a,z),(u,v) in zip(b['bounds'],inner)):im|=1<<i
            if all(min(z,v)>max(a,u) for (a,z),(u,v) in zip(b['bounds'],outer)):om|=1<<i
        assert im and im&om==im
        center=tuple((u+v)/2 for u,v in r)
        center_points=tuple(center for _ in c['upper_envelope_points'])
        center_hard=hard_certificate(boxes,center_points,len(r))
        rows.append(dict(receiver=r,volume=c['volume'],demand=c['volume'],Lstar_interval=[lo,hi],kappa_layer=c['kappa_layer'],midpoint_receiver_hard_certificate=center_hard,
                         guaranteed_capture_box=inner,possible_capture_box=outer,inner_source_mask=im,outer_source_mask=om))
    return rows

def mask_mass(mask,bins):return sum(b['mass'] for i,b in enumerate(bins) if mask>>i&1)

def hall(rows,bins,key,do_flow):
    m=len(rows);unions=[0]*(1<<m);demands=[F(0)]*(1<<m);best=F(0);maximizers=[];cuts=[]
    for mask in range(1,1<<m):
        bit=mask&-mask;i=bit.bit_length()-1;prev=mask^bit
        unions[mask]=unions[prev]|rows[i][key];demands[mask]=demands[prev]+rows[i]['demand']
        mass=mask_mass(unions[mask],bins);assert mass>0;ratio=demands[mask]/mass
        if ratio>best:best=ratio;maximizers=[mask]
        elif ratio==best:maximizers.append(mask)
        cuts.append(dict(receiver_mask=mask,source_union_mask=unions[mask],demand=demands[mask],source_union_mass=mass,ratio=ratio))
    maximal=0
    for x in maximizers:maximal|=x
    assert demands[maximal]/mask_mass(unions[maximal],bins)==best
    out=dict(K=best,all_receiver_cuts=cuts,maximal_maximizer_receiver_mask=maximal,maximal_maximizer_source_mask=unions[maximal])
    if not do_flow:return out
    N=len(bins);den=1
    for x in [r['demand'] for r in rows]+[best*b['mass'] for b in bins]:den=math.lcm(den,x.denominator)
    total=sum(r['demand'] for r in rows);infinite=int(total*den)+1;s=0;t=1+m+N;flow=Flow(t+1)
    for i,r in enumerate(rows):
        flow.edge(s,1+i,int(r['demand']*den))
        for j in range(N):
            if r[key]>>j&1:flow.edge(1+i,1+m+j,infinite)
    for j,b in enumerate(bins):flow.edge(1+m+j,t,int(best*b['mass']*den))
    value,reachable=flow.maxflow(s,t);assert value==total*den
    balance=[0]*(t+1);arcs=[]
    for a,b,cap,index in flow.original:
        used=cap-flow.graph[a][index][2];assert 0<=used<=cap
        balance[a]-=used;balance[b]+=used
        if used:arcs.append(dict(tail=a,head=b,capacity=F(cap,den),flow=F(used,den)))
    assert balance[s]==-value and balance[t]==value and all(v==0 for v in balance[1:t])
    cut=sum(cap for a,b,cap,_ in flow.original if a in reachable and b not in reachable);assert cut==value
    out['flow']=dict(total=F(value,den),integer_denominator=den,positive_arcs=arcs,residual_reachable=sorted(reachable),cut_capacity=F(cut,den),
                     all_arcs_count=len(flow.original),node_layout=dict(source=0,receiver_start=1,source_bin_start=1+m,sink=t))
    return out

def source_diagnostics(rows,bins,receiver_mask,n):
    """Midpoint quadrature only for logarithmic moments; load enclosures exact."""
    records=[];denom=F(0);sum_sigma=0.;logspan=0.;bmax=0.;weighted_b=0.;h_mass={str(c):F(0) for c in (F(1,100),F(1,10),F(1))}
    chosen=[r for i,r in enumerate(rows) if receiver_mask>>i&1]
    union=0
    for r in chosen:union|=r['outer_source_mask']
    for i,bin in enumerate(bins):
        if not union>>i&1:continue
        denom+=bin['mass'];lower=upper=F(0);weights=[];logs=[]
        y=[(u+v)/2 for u,v in bin['bounds']]
        for r in chosen:
            lo,hi=r['Lstar_interval'];lower+=(r['volume']/hi**n if r['inner_source_mask']>>i&1 else 0)
            upper+=(r['volume']/lo**n if r['outer_source_mask']>>i&1 else 0)
            cl,ch=r['midpoint_receiver_hard_certificate']['first_contact']['bracket'];L=float((cl+ch)/2);x=[float((u+v)/2) for u,v in r['receiver']]
            if all(abs(xx-float(yy))<L/2 for xx,yy in zip(x,y)):
                weights.append(float(r['volume'])/L**n);logs.append(math.log(L))
        b=sum(weights)
        if b:
            mean=sum(w*z for w,z in zip(weights,logs))/b
            variance=max(0.,sum(w*(z-mean)**2 for w,z in zip(weights,logs))/b);sigma=math.sqrt(variance)
            span=max(logs)-min(logs)
        else:mean=variance=sigma=span=0.
        sum_sigma+=float(bin['mass'])*sigma;weighted_b+=float(bin['mass'])*b;bmax=max(bmax,b);logspan=max(logspan,span)
        for c in (F(1,100),F(1,10),F(1)):
            if variance>float(c)/n:h_mass[str(c)]+=bin['mass']
        records.append(dict(source_bin=i,canonical_load_exact_interval=[lower,upper],midpoint_b=b,midpoint_log_mean=mean,
                            midpoint_log_variance=variance,midpoint_sigma=sigma,midpoint_log_span=span))
    avg=sum_sigma/float(denom)
    return dict(scope='Log moments are midpoint diagnostics, not rigorous integrals or gate certificates.',receiver_mask=receiver_mask,
                possible_union_mass=denom,midpoint_mass_weighted_sigma=avg,midpoint_max_b=bmax,midpoint_mass_weighted_b=weighted_b/float(denom),
                midpoint_log_span=logspan,midpoint_eta_c={c:float(v/denom) for c,v in h_mass.items()},
                diagnostic_cubic_Hall_bound=2+math.sqrt(12)*n*avg,source_records=records)

def fixture(label,n,e,m,extras=(),dvalues=None,stage=1):
    b=F(41,100);base=dict(bounds=((F(0),b),)*n,density=F(4**n))
    W=base['density']*b**n;boxes=[base]
    for bounds,fraction in extras:
        boxes.append(dict(bounds=tuple(bounds),density=W*F(fraction)/math.prod(v-u for u,v in bounds)))
    receivers=[]
    ds=dvalues or [F(2,5)]*(1<<n)
    for i,signs in enumerate(product((0,1),repeat=n)):
        d=ds[i];ee=e[i] if isinstance(e,(list,tuple)) else e;receivers.append(tuple(((-d if s==0 else b+d)-ee,(-d if s==0 else b+d)+ee) for s in signs))
    return dict(label=label,n=n,stage=stage,lambda_value=F(1),boxes=boxes,W=sum(x['density']*math.prod(v-u for u,v in x['bounds']) for x in boxes),
                receiver_boxes=receivers,source_partition_per_axis=m,seed=SEED)

def run_fixture(src):
    n=src['n'];certs=[receiver_certificate(src['boxes'],r,n,ny=16,nt=32,nscale=24) for r in src['receiver_boxes']]
    bins=source_partition(src['boxes'],src['source_partition_per_axis']);rows=graph_rows(certs,bins,src['boxes'])
    assert len({r['kappa_layer'] for r in rows})==1,'Do not mix kappa strata in a single Hall problem'
    inner=hall(rows,bins,'inner_source_mask',True);outer=hall(rows,bins,'outer_source_mask',False)
    assert outer['K']<=inner['K'];full=(1<<len(rows))-1
    canonical=[]
    for i,b in enumerate(bins):
        low=sum(r['volume']/r['Lstar_interval'][1]**n for r in rows if r['inner_source_mask']>>i&1)
        high=sum(r['volume']/r['Lstar_interval'][0]**n for r in rows if r['outer_source_mask']>>i&1)
        canonical.append(dict(source_bin=i,lower=low,upper=high))
    result=dict(input=src,receivers=certs,source_bins=bins,transport_rows=rows,continuum_Hall_K_interval=[outer['K'],inner['K']],
                inner_graph=inner,outer_graph=outer,canonical_source_load_enclosures=canonical,
                canonical_average_load=sum(r['demand'] for r in rows)/src['W'],canonical_essential_max_lower=max(x['lower'] for x in canonical),
                canonical_essential_max_upper=max(x['upper'] for x in canonical),retained_receiver_volume=sum(r['volume'] for r in rows),
                kappa_layer=rows[0]['kappa_layer'],qualified_receiver_count=len(rows),
                source_logscale_diagnostics_full=source_diagnostics(rows,bins,full,n),
                source_logscale_diagnostics_maxK=source_diagnostics(rows,bins,inner['maximal_maximizer_receiver_mask'],n))
    return result

def main():
    e=F(1,10000);cases=[]
    cases.append(fixture('pilot_n2_source_m2',2,e,2,stage=1))
    cases.append(fixture('pilot_n2_source_m4',2,e,4,stage=1))
    cases.append(fixture('pilot_n2_broader_receiver_volume',2,F(15,1000),8,dvalues=[F(35,100)]*4,stage=1))
    cases.append(fixture('pilot_n2_receiver_halfwidth_refined',2,e/2,4,stage=1))
    near=((F(1,100),F(8,100)),)*2;interior=((F(12,100),F(22,100)),)*2
    cases.append(fixture('correlated_nearface_n2',2,e,4,[(near,F(1,100))],stage=2))
    cases.append(fixture('correlated_three_components_n2',2,e,4,[(near,F(1,100)),(interior,F(1,100))],stage=2))
    cases.append(fixture('correlated_unequal_receiver_volume_n2',2,[F(1,1000),e/2,e/2,e/2],4,[(near,F(1,100)),(interior,F(1,100))],stage=2))
    cases.append(fixture('correlated_receiver_scale_spread_n2',2,e,4,[(near,F(1,100)),(interior,F(1,100))],
                         [F(345,1000),F(365,1000),F(385,1000),F(405,1000)],stage=2))
    cases.append(fixture('dimension_n3_base',3,e,4,stage=3))
    near3=((F(1,100),F(8,100)),)*3;interior3=((F(12,100),F(22,100)),)*3
    cases.append(fixture('dimension_n3_correlated',3,e,4,[(near3,F(1,100)),(interior3,F(1,100))],stage=3))
    cases.append(fixture('source_resolution_n2_m8',2,e,8,[(near,F(1,100)),(interior,F(1,100))],stage=3))
    cases.append(fixture('unequal_receiver_source_refinement_m32',2,[F(1,1000),e/2,e/2,e/2],32,[(near,F(1,100)),(interior,F(1,100))],stage=3))
    results=[]
    for case in cases:
        r=run_fixture(case);results.append(r)
        print(case['label'], 'qualified',len(r['receivers']),'K',str(r['continuum_Hall_K_interval']),flush=True)
    data=dict(schema='actual-L1-full-gate-conservative-continuum-Hall-v1',seed=SEED,
              exp_certificate=dict(fixedpoint_bits=60,Taylor_terms=20,range_reduction_v_max='1/2',remainder_factor=2,
                                   argument_monotone_phi_rounding_bits=24),
              scope='Finite explicitly specified compact receiver subsets of actual Eret intersect original Emid and one kappa layer; true positive L1 box mixtures. No claim that these subsets exhaust the retained event, no general dimension bound.',
              three_stages=dict(pilot_refinement=4,correlated_pressure=4,dimension_source_resolution=4),cases=results,
              counts=dict(cases=len(results),qualified_receivers=sum(len(r['receivers']) for r in results),source_bins=sum(len(r['source_bins']) for r in results),
                          receiver_Hall_cuts=sum(len(r['inner_graph']['all_receiver_cuts'])+len(r['outer_graph']['all_receiver_cuts']) for r in results),
                          positive_flow_arcs=sum(len(r['inner_graph']['flow']['positive_arcs']) for r in results)),
              limitations=['Compact B only; unsampled rest of Eret has no claimed upper bound.',
                           'Inner common-source flows lift to continuum and bound all receiver subsets; outer whole-cell cuts only give lower bounds.',
                           'Source components are separate labels but sum to the same physical L1 density; capacities lift additively.',
                           'Log-scale moments/eta are midpoint diagnostics and separate from exact gates/Hall bounds.',
                           'No E2 gate is inherited after a source cut; tests use the identical full input.',
                           'No unpublished lower-bound construction is included.'])
    target=Path(__file__).with_name('hall_results.json');target.write_text(json.dumps(clean(data),ensure_ascii=False,sort_keys=True,indent=2)+'\n')
    print('PASS',data['counts'],flush=True)

if __name__=='__main__':main()
