# 中心立方体第84轮：来源尺度方差、正停止分配与受限坐标支付

2026-10-11。一般目标 C_n^square <= sqrt(n)n^{o(1)} 尚未证明；保留全一般基准为 O(n log n)。本轮的正向结果适用于任意非负 L1 输入，但各平方根支付仅覆盖明示的分支，不能代替剩余事件的一般估计。

## 本轮实际成果与精确缺口

1. 对真实接收测度和同一完整捕获关系，证明来源尺度区间容量及三次方差不等式 (b-1)_+^3 <= 12 n^2 b sigma^2。因此高 Hall 比值必须有足够大的来源条件尺度方差；低方差来源提供真正的平方根已付分支。剩余输入必须更换阈值并重新选择首触、重新划分全部门槛。仅在额外来源质量收缩条件成立时才可吸收；该条件不是已知工具。
2. 固定较粗噪声宽度 theta=log^{-2}(n+2)，支付高平滑分支 O(sqrt(n)log(n+2))。余下接收点上，捕获内部的噪声路径单调，停止于 3lambda/4 后给出显式非负、原捕获支撑的共同分配。进一步证明：质量不超过 delta lambda/4 的共同来源集合可从分配中删除，其他来源列负载最多放大 1/(1-delta)。这里改变分配而不截断输入。一般来源尾质量或列容量仍未界定。
3. 精确计算来源所见接收矩形上的硬核包络。若 k 个坐标方向的接收范围受限，费用为 n/k；这支付一个真正的平方根分支。非受限来源的费用仍完整保留。坐标重置过程与确定性包络给同一个系数，没有额外的随机抵消收益。
4. 原始文献及更新后的64项技能按具体假设核对。现有树 Bellman、外测度、随机 Carleson、占用测度 LP 等没有自动提供所缺的来源装箱。保持原第82轮接口；额外删除第83轮不同窄核的极低似然并集必须再付一次预算。

强型绝对变化、无条件来源质量收缩等候选策略分别接受合资格压力测试。私人构造、参数及推导仅保留在本地研究记录，不进入本公开包；其作用是修改候选充分条件，不构成一般弱型目标的反例。仍可研究高总负担接收子集上的来源收缩，以及允许共同重新分配的来源容量。

## 核验与证据等级

两名审核者分别先记录独立命题预检，再读作者证明。公开程序包含 12 个真实 L1 输入、56 个完整合格接收盒、3796 个正质量源子盒、1320 个 Hall 割和7437条正流弧。认证使用真实连续首触、严格见证、整个物理窗口的平滑上界、原 middle 与 kappa 层；内图流给连续可行上界，外邻域割给下界。全部测试的 Hall 比值很低，不能认证高容量分支或一般维数阶数。保存的 log-scale 矩是明确标记的中点诊断。

证明型指数包围、有理多项式根认证与流守恒由独立实现核对；主代理实际执行及其字节哈希见 inventory.json。复现仅需 Python 标准库：运行 hall_probe.py 重建 hall_results.json；再从本文按顺序提取 coverage、alternative、audit 三个 Python 围栏，独立运行各脚本。审计脚本也可直接从本文提取并运行，它会自行定位并执行前两个守卫。有限证书和守卫不证明未决一般命题。

## 归档范围

公开包只有 proof.md、proof.tex.txt、hall_probe.py、hall_results.json、inventory.json 五个成员。详细 LaTeX 只做源码静态检查，不编译 PDF。Git 每轮仅增加一个说明文件和一个精简压缩包，并更新项目总览。完整私人压力记录和过程文件保留本地，不上传。

## 保持的最终返回

若原第82轮每个背景层的任意合资格紧接收子集有统一共同容量 K_n <= C sqrt(n)log^a(n+2)，背景层求和和全尺度返回各付一个对数，得到 O(sqrt(n)log^{a+2}(n+2))。本轮没有证明这一前提。下文每个条件性命题都保留其尚未成立的假设，不将运输表示、有限测试或已付分支称为最终闭合。


# R84 主账：保持第82轮接口，显式记入第83轮工具

日期：2026-10-11。当前一般目标仍 UNPROVED；保留全一般上界 O(n log n)。本账服从用户最新目标，私人未发表下界构造仅作内部压力测试，不进入公开归档。

## 原合同不变

全边长 L∈[1,2]，mu=f(y)dy，W=||f||_1，真实接收测度lambda dx。A_L=f*H_L；P_L=f*Phi_L，Phi使用原eta=1 E2核。

Eret={sup A_L>lambda,A_1<lambda/2,sup P_L<=lambda/2}。在同一输入上使用原最早接触L*(x)=inf{L:A_L>=lambda}；A_L*=lambda。最早接触可以早于严格上穿，凡截断后需保留严格见证处，另在已有正规紧致上穿类核对，不能将两个时刻混同。

费用B0(n)=4+2log2 sqrt(7n/3)。原极低背景集Eext={x∈Eret:P_L*/lambda<=exp(-s_n)/2}按Bext(n)=2(1+nlog2)/sqrt(n+2)支付。Emid=Eret\Eext，Dmid为其输入一致费用。此定义本轮不被窄核替换。

原条件返回：C_n<=C_loc log(n+2)[B0+Bext+Dmid]。

## 层数与容量的维数账

在Emid上kappa=1+log(lambda/(2P_L*))满足1<=kappa<1+s_n；按2^j<=kappa<2^(j+1)分层，非空可能层数J_n<=1+floor(log2(1+s_n))=O(log(n+2))。这是覆盖和层数恒等式，不是费用估计。

若所有实际合资格紧致B⊂Ej满足lambda|B|<=K_n mu(N(B))，且K_n<=C sqrt(n)log^a(n+2)与j、来源细分、网格、输入一致，则每层lambda|Ej|<=K_n W（先用正规紧致穷尽/已有连续运输接口）。普通不交事件求和得Dmid<=J_n K_n，再返回全尺度得sqrt(n)log^{a+2}(n+2)。没有弱准范数三角不等式或无限窗口直接求和。

一般几何K_n尚未证明；有限可行流的证书不证明无限维一致K_n。对每一候选割几何命题，分别记录它在真正高Hall比值区域提供何种新约束，不能以所有有限图的Hall重写或主分块恒等式替代。

## 第83轮工具如何加入而不改变旧事件

可选择预定宽度eta_j与权重a_j，用已证窄核极低似然并集U_new。将它限制到Emid仍有费用<=Bext(n)W。于是

    Dmid(n) <= Bext(n) + D_remaining_old_and_new(n),
    C_n <= C_loc log(n+2)[B0(n)+2Bext(n)+D_remaining_old_and_new(n)].

这里remaining=Emid\U_new，保留旧P_1门槛，同时在每个注册窄核上有P_eta,L*>beta_eta lambda。对于eta<=1/n以及log(1/a)=O(logn)，beta_eta=n^-o(1)。不同核的比值下界不可混同；本账明确额外支付一次Bext，未把新阈值偷换成旧P_1阈值。

固定L的全噪声变化<= (2+log51)sqrt n W仅是局部工具。选成L*(x)后的绝对积分不是已付费用。硬端点可一致取极限，但范数估计不能沿选择器直接代入。若原Emid上的绝对变化被合资格反例证伪，则记录该充分路线失败；改为阈值停止/正来源分配/先付额外分支，仍须完整覆盖Emid。

## 截断与剩余收费

完整捕获邻域稍扩张后限制来源，保留原历史和邻近严格见证需既有正规假设。锚点及原平滑上界在同阈值下保持；中间背景或窄核下界都不自动保持。必须重分支，已付极低部分按同一新来源质量计费，不能用待证Dmid作循环容量证明。主分块后块失去早来源时，原hard首达甚至可能消失，不能套用最顶捕获割的稳定性。

所有新分支必须登记其对象、阈值、真实来源/接收集合、总费用、是否与旧分支重叠以及余集。给出一个停止表示或双边等价式，不等于建立维数增益。当前三个路线的归约都须交付超出等价改写的实际新估计。

## 第84轮已证支付如何接入

来源方差方案：对原接收子集 B 的规范共同捕获分配定义来源条件方差 sigma_y^2，令 G={sigma_y^2<=c/n}、H=G^c、T_n=max(2,sqrt(96cn))。原行捕获 H 份额不超过 theta 的部分收费 T_n mu(G)/(1-theta)；其余行用新输入 f1_H、阈值 theta lambda，重选并重分全部门槛，收费 (B0+Bext+Dmid)mu(H)/theta。所有量均对当前完整输入计算。仅需在 lambda|B|>T_n W 的子集上要求额外的 mu(H)<=eta W、eta<theta，便可条件吸收；此 MD-high 仍未证明。D/mu(N(B)) 不能替代此处 D/W。要求每个合资格低负担子集也收缩的更强前提已被排除；不影响本条件返回的正确性。

捕获停止方案：theta=log^{-2}(n+2)，在原 Emid 内令 H_theta={P_theta,L*>=lambda/2}，其费用为 2[1+log2 U(n,theta)]W，其中 U=min(2n,sqrt(n(theta^{-1}+4theta/3)))。剩余 F_theta=Emid\H_theta 上，捕获内部从 C_x(theta)<lambda/2 单调停止于3lambda/4，形成非负共同分配。其列为 ell_B，若 q_B=integral_B k_x dx，则 (4/3)q_B<=ell_B<=4q_B。

若另外证明 mu{q_B>K}<=delta lambda/4、delta<1，已证重新分配给容量4K/(1-delta)；该尾质量条件尚未证明。若它对每个原背景层统一成立，完整返回为 C_loc log(n+2)[B0+Bext+2(1+log2 U)+4J_n K/(1-delta)]。这里 theta 是噪声宽度，区别于前段来源份额阈值。新增第83轮窄核极低并集仍另加Bext。

受限坐标方案：来源 y 所见整个 B 的接收矩形若在 k 个坐标方向的半径不超过1/2，精确包络收费至多n/k。令 k0=ceil(sqrt(n))，捕获该来源集合份额至少1/2的原接收行费用至多2sqrt(n)W。其他行或非受限来源尚未付清。随接收子集改变的矩形不得逐件重收来源质量后不计重叠。

三条方案是可选择的独立拆分，不能把各自已付份额相加后宣布覆盖全余集。MD-high、停止列尾质量及非受限来源费用都没有一般估计；不存在从本轮有限测试到一般维数阶数的推断。当前主目标仍为 UNPROVED。


# R84 coverage: a common-source scale-variance obstruction to high Hall capacity

**Status: partial theorem, no general closure.** A new sourcewise anti-concentration inequality, an exact older-union overlap bound, and a measurable square-root paid branch are proved below. The branch's remainder is a real restricted input with a new threshold and fully recomputed gates; its recursion has explicit costs. The high-capacity obstruction uses actual canonical source occupation of log scale. A universal variance estimate, a suitable older-union packing bound, or a fixed source-mass contraction would each suffice for closure, but **none is proved**. The elementary range bound still gives only order n. This is not a reproof of the principal partition and does not assert that a finite numerical test proves an asymptotic estimate.

The R84 contract, all five pages of `source_routes.txt`, R82 `transport.md`, and R83 `peeling.md`/`geometry.md` were read. Updated E03, G01, B01, M03 skills and their cube interfaces were read: no unconstructed tree, automatic Carleson condition, infinite-dimensional strong duality, or generic stability theorem is invoked. All inequalities here have direct proofs. Before this author proof was written, the exact candidate was sent to both R84 auditors, the parent and the Hall numerical owner. Both auditors independently derived the stronger cubic inequality used below (the author's initial candidate had a quartic deficit). The pressure run remains owned by the Hall numerical role.

## 1. The actual cut and one shared joint measure

Let n≥1, f≥0 belong to L1(R^n), μ=f dy, λ>0. Let B be a measurable finite-volume receiver set, L:B→[1,2] measurable, with

    μ(Q(x,L(x)))=λ L(x)^n  for almost every x∈B.             (1)

The intended application is every admissible regular compact B⊂E_j in the R84 contract, with its original hard selector. In that application the anchor, full continuous smooth gate, middle condition, κ layer and strict witnesses are all retained. The new estimate does not need those gates and therefore holds uniformly in j and κ. It does need actual Lebesgue receiver measure: arbitrary weighted receiver points cannot replace dx.

Write N=N(B)=∪_{x∈B}Q(x,L(x)), D=λ|B| and M=μ(N). For compact B and continuous L the neighborhood is compact, hence measurable. More generally only measurable N is required. We treat D=0 separately; if D>0, (1) implies M>0. Define

    dΓ(x,y)=1_B(x)L(x)^(-n)1_{Q(x,L(x))}(y) dx μ(dy),
    b(y)=∫_B L(x)^(-n)1_{Q(x,L(x))}(y) dx.                 (2)

This is a single common-source plan. Its receiver marginal is λ1_B dx by (1), its source marginal is b μ, and ∫_N b dμ=D. It is not claimed to minimize the maximum source load.

For b(y)>0 let ν_y be the probability law of t=log L(x) under the normalized x-section of Γ:

    β_y(E)=∫_B L(x)^(-n)1_{Q(x,L(x))}(y)1_{log L(x)∈E}dx,
    ν_y=β_y/b(y),  m_y=∫t dν_y,  σ_y²=∫(t−m_y)²dν_y.     (3)

When b=0 set σ=0 and m=0. All these quantities are measurable through the zeroth, first and second t moments. They require no independence of source coordinates and no disintegration theorem beyond these displayed integrals.

The averaged conditional variance used below is

    V_B = D^(-1)∫_N b(y)σ_y² dμ(y).                       (4)

It is a variance averaged with the actual source marginal Γ_Y/D. It is **not** the unweighted source average of σ², the variance of log L under receiver dx alone, or a reference-product variance. The law of total variance gives V_B≤Var_{λ1_Bdx/D}(log L), but that receiver variance need not be small. Always V_B≤(log 2)²/4.

## 2. Exact scale-interval capacity at a fixed source

For any real a≤c,

    β_y([a,c]) ≤ 1+n(c−a).                                (5)

To prove this, intersect the interval with [0,log 2]; enlarging it can only weaken the estimate. For A=e^a and C=e^c, the integrand defining β_y is bounded by

    sup_{A≤s≤C} s^(-n)1_{||x−y||∞≤s/2}.

The integral of this envelope over all x is exactly

    A^(-n)|Q(y,A)| + ∫_A^C s^(-n)d(s^n)
      =1+n log(C/A).

No source mass has been discarded: this bound includes sources deep inside N, irrespective of whether they are fresh for particular rows. Also b(y)≤1+n log 2, recovering the existing full-window column bound.

There is a useful stronger cumulative constraint, though no extra dimension gain is claimed from it:

    ∫_{s≤t}e^{ns}dβ_y(s)
      =|{x∈B:log L(x)≤t, y∈Q(x,L(x))}|
      ≤e^{nt}.                                           (6)

Indeed all those x lie in Q(y,e^t). Both (5) and (6) use physical receiver volume, not a source-private capacity copy.

## 3. Sourcewise cubic variance inequality

**Theorem 1.** For every source y,

    (b(y)−1)_+³ ≤ 12 n² b(y)σ_y².                         (7)

The convention at b=0 makes both sides zero. If b≤1 there is nothing to prove. Otherwise put δ=b−1>0. Apply (5) to the interval [m_y−h,m_y+h]:

    β_y({|t−m_y|>h}) ≥ (δ−2nh)_+.

The layer-cake identity for the nonnegative square gives

    bσ² = ∫_0^∞ 2h β_y({|t−m_y|>h})dh
         ≥∫_0^{δ/(2n)}2h(δ−2nh)dh
         =δ³/(12n²).

This proves (7). Endpoints or atoms of ν_y cause no issue: use the closed interval in (5), whose complement is the strict tail in the layer-cake identity.

The numerical constant 12 is sharp for the abstract interval constraint (5): β=δ_0+n1_{[−a,a]}dt has total mass b=1+2na and centered second moment 2na³/3=(b−1)³/(12n²). This abstract measure is **not asserted to be realizable** by an actual first-hit cut; in particular the additional cumulative constraint (6) must still hold in a geometric realization. Sharpness here only says that (5) alone cannot improve that constant.

The initially proposed quartic statement follows from δ≤b:

    (b−1)_+⁴≤12n²b²σ²,  b≤2+√12 nσ.                     (8)

It is weaker than (7) and is retained only to reconcile the precheck statement with this final theorem.

## 4. Quantitative high-capacity obstruction and conditional root-order return

Define the capture ratio of this actual cut by K_B=D/M. This is not necessarily the largest Hall ratio on its ambient event. Convexity of s↦(s−1)_+³, Jensen against μ|_N/M, (7), and (4) give

    M(K_B−1)_+³
      ≤∫_N(b−1)_+³dμ
      ≤12n²∫_N bσ²dμ
      =12n² K_B M V_B.

Hence the new necessary condition is

    (K_B−1)_+³/K_B ≤12n² V_B.                             (9)

For K_B≥2 this implies K_B²≤96n²V_B. In particular a high-ratio cut cannot have its common-source conditional scale variance arbitrarily small. This is distinct from R83's quadratic load deficit: it uses a physical log-scale occupation and a proved upper bound for each source's scale-interval mass, rather than a gap between principal densities.

**Conditional closure proposition (not established).** Suppose fixed C,a≥0, independent of f, λ, n, layer j, source subdivision and receiver complexity, satisfy

    V_B≤ C log^{2a}(n+2)/n                                (V)

for every admissible compact B⊂E_j with K_B>2, every n≥2, every original input, and every allowed j. Then

    K_B≤max{2,√(96C)√n log^a(n+2)}                        (10)

for every such cut. Thus the requested layerwise Hall estimate follows; R82's compact common-source transport theorem applies; the O(log(n+2)) κ layers cost one logarithm; the R81 all-scale return costs one more. The resulting general weak coefficient would be O(√n log^{a+2}(n+2)), in addition to the already paid terms in the contract.

It would suffice to prove (V) only for all cuts with K_B above the proposed target, but assuming it merely for one numerical maximizing cut is insufficient. No attainment of the Hall supremum is needed: the estimate is stated for every qualifying compact cut. A uniform estimate on the regular compact class can be assembled with the already established full-window approximation/return interface. We do not assert stability of individual E_mid or E_j indicators under arbitrary input approximation.

No proof of (V) is supplied. The unconditional range estimate V_B≤(log2)²/4 inserted in (9) is still O(n). Nor do the original smooth gate, the κ label, or a product reference law by themselves prove (V). It is an explicit new geometric duty, not an available lemma.

## 5. Why this records overlap without the R83 deletion errors

All receivers in B retain the original L and the entire source f. The definitions of β_y and Γ count a source against every actual cube that captures it; a source which is interior to N but fresh in many constituent cubes remains fully present. No physical block is deleted, so a later row never inherits a false first hit from a reduced input. We do not try to convert variance between principal block densities into captured-mass loss.

The statistic is also not a tautological rewriting of Hall capacity. It retains the conditional second moments of original scale under the canonical plan, while Hall capacity optimizes all common plans and depends only on demands and adjacency. Different original scale assignments can change V without changing that finite adjacency data. The implication (V)⇒(10) is proved; its converse is not asserted. In particular efficient source reallocation can yield a small optimal capacity even when the canonical plan has substantial load or scale variance. Therefore (V) is a possibly stronger route which must be pressure-tested, particularly on high-capacity cuts.

A rigorous warning against using only scale-envelope geometry is available. Put y=0,

    B={x:1<2||x||∞<2},  L(x)=2||x||∞.

Then β_0=n1_{(0,log2)}dt, b(0)=n log2 and σ_0²=(log2)²/12. The conditional scale variance stays constant as n grows, while (5) and (6) hold. This is an exact geometric selector example, **not an admissible actual-level L1 counterexample**: a unit point source would have average L^(-n), not a common λ throughout this shell. It proves only that the first-contact equations coupling all source columns are indispensable for any proof of (V). Neither the shell example nor a weighted receiver-point surrogate may be described as a counterexample to the retained Hall conjecture.

The adaptive route's tiny-box radial family likewise cannot be declared a counterexample to (V) from its broad raw-flux scale range. At its actual contact the hard cube catches a small source fraction, so one must compute the source-conditioned law with the indicator 1_{Q(x,L(x))}, and normalize by D as in (4). The Hall numerical owner has been asked to preserve precisely this distinction.

## 6. A source-overlap upper bound: the earliest capturing scale

The variance theorem also admits a concrete sufficient mechanism in terms of actual common-source overlap, rather than leaving only a desired moment estimate. Here take B compact and L continuous. For y∈N define

    τ(y)=min{log L(z):z∈B, y∈Q(z,L(z))},
    U_s=∪_{z∈B:log L(z)≤s}Q(z,L(z)),  U_s=∅ for s<0.

The minimum is attained: its feasible subset of compact B is closed. The sublevel sets {τ≤s}=U_s are compact, so τ is measurable on N. On every edge of Γ, τ(y)≤t=log L(x). A conditional mean minimizes squared error, so

    V_B ≤ D^(-1)∫(t−τ(y))²dΓ(x,y)
        =D^(-1)∫_B λ dx ∫_0^{log2}2h
             μ(Q(x,L(x))∩U_{t−h})/[λL(x)^n] dh.          (11)

The equality follows from layer cake and Tonelli; using ≤ rather than < in U changes only the integration endpoint h=t−τ(y) for each pair. The predictor τ is the first scale at which **any original receiver cube** captures this source. It is not the source's age in the current row. In particular U_{t−h} must not be replaced by the smaller concentric cube Q(x,e^{t−h}). Such a replacement discards precisely the shared interior sources identified in R83.

Suppose an actual cut satisfies the following additional source-overlap bound, with R≥1:

    μ(Q(x,L(x))∩U_{t−h})≤R λ exp(n(t−h))                 (12)

for almost every x∈B and h≥0. Then the ratio in (11) is at most min{1,R exp(−nh)}. Extending the h integral to infinity and splitting at (log R)/n proves

    V_B≤[(log R)²+2log R+2]/n²,
    K_B≤max{2,√96 sqrt[(log R)²+2log R+2]}.               (13)

If R is allowed to depend measurably on x, the same proof replaces the numerator in the first bound by its λdx/D average; consequently the square of a logarithmic local source-cover factor, rather than its raw size, controls this sufficient estimate.

One valid way to certify (12) is to cover Q(x,L(x))∩U_{t−h}, up to μ-null sets, by at most R actual original selected cubes with log side at most t−h. Each such cube has mass at most λexp(n(t−h)) by its original contact equation, and a union bound then gives (12). More generally (12) itself may hold without a finite cardinal cover. In neither case does a receiver-private source copy enter the proof: the bound estimates the shared older union before the one integration against μ.

Thus a uniform R≤exp(C√n log^a(n+2)) would suffice for the desired root-order fee. No such bound is established. A cover by exp(Cn) cubes, or the trivial bound of each individual old cube without controlling its union, is inadequate. The original smooth gate only controls specific positive kernel averages; it has not supplied (12) for this union of cubes centered at other receivers. The old first-hit inequality controls a smaller cube at the *same* center and is insufficient by itself. Equation (11) and its explicit conditional consequence (13) isolate the exact source growth/overlap quantity which a proposed packing argument must actually bound.

## 7. An actual paid split and an honest source-restriction bootstrap

The previous mechanism has no universal packing estimate yet. Independently, the cubic theorem gives a measurable square-root paid branch and a legitimate recursive remainder, including every threshold and gate cost.

Fix c>0 and θ∈(0,1). For the actual current B and its β_y define

    G={y:σ_y²≤c/n},  H={y:σ_y²>c/n},
    T_n=max{2,sqrt(96 c n)},  h=f1_H.

Sources with b=0 lie in G. By (7), b≤T_n on G: when b≥2, (b−1)³/b≥b²/8. Define the original captured fraction

    α(x)=μ(Q(x,L(x))∩H)/[λL(x)^n].

The low-H rows B_lo={x∈B:α(x)≤θ} are paid directly:

    (1−θ)λ|B_lo|
      ≤∫_{B_lo}L(x)^(-n)μ(Q(x,L(x))∩G)dx
      ≤∫_G b dμ≤T_n μ(G).                               (14)

This is a genuine square-root common-source payment for a measurable portion of any actual cut. Its source set and receiver set are specified, and its fee is independent of scale count and decomposition depth.

For x∈B_hi=B\B_lo, the ORIGINAL selected cube gives

    A_{L(x)}h(x)>θλ.                                     (15)

This is a strict witness for the restricted input h at the NEW threshold θλ. We do not claim the old contact remains its first contact, and we do not inherit any lower smooth ratio or background layer. Instead classify the full actual hard superlevel for h at threshold θλ afresh. Let

    B_0(n)=4+2log2 sqrt(7n/3),
    B_ext(n)=2(1+nlog2)/sqrt(n+2),
    D_mid(n)=sup_{g≥0 in L1,ρ>0} ρ|E_mid(g,ρ)|/||g||_1.

These are exactly the original R81/R82 quantities in the parent ledger. In fact D_mid≤1+nlog2 directly from the strong full-window kernel envelope, so its finiteness needs no new approximation argument. The new anchor/smooth exceptions cost B_0(n)μ(H)/(θλ); the newly classified original-kernel extreme branch costs B_ext(n)μ(H)/(θλ); its middle remainder costs D_mid(n)μ(H)/(θλ). Consequently the unconditional split is

    λ|B|≤ T_n μ(G)/(1−θ)
            +[B_0(n)+B_ext(n)+D_mid(n)] μ(H)/θ.           (16)

The original source f is used to decide H and α once; h is then a real positive L1 input. All its gates and its selector are recomputed. No later-block deletion retains a false hard hit. No extra R83 narrow kernel union is used, so this split does not silently change E_mid or invoke that additional paid branch.

### A high-total-burden mass-drop condition that would close the bootstrap

Consider the following stronger-than-current-evidence hypothesis, with fixed c>0 and 0≤η<θ<1:

    if λ|B|>T_n W, then μ({σ_{B,y}²>c/n})≤η W.            (MD-high)

The quantifiers are every n≥2, every nonnegative positive-mass L1 input f, every threshold λ>0, and every compact B⊂E_mid of that input with continuous restricted selector. The constants c,η,θ are fixed independently of all these objects. Here W=||f||_1 is the total mass of the original current input, not μ(N(B)) or the mass of a subsequently restricted source. This includes compacts meeting several original κ layers; it does not add transversality or immediate-strict-crossing assumptions. The low-total-burden branch λ|B|≤T_nW is already paid directly and requires no mass drop. For a high-total-burden cut apply (16) and (MD-high). Taking compact suprema gives first

    D_mid≤max{T_n, A_n+(η/θ)D_mid},
    A_n=T_n/(1−θ)+(η/θ)(B_0+B_ext).

Since A_n≥T_n and D_mid≥0, the maximum reduces to its second entry. Thus

    D_mid≤ T_n/(1−θ)+(η/θ)(B_0+B_ext+D_mid),
    D_mid≤[T_n/(1−θ)+(η/θ)(B_0+B_ext)]/(1−η/θ).           (17)

The passage is legitimate because the actual measurable selector on the finite-volume middle event admits Lusin/inner-regular compact exhaustion on which its restriction is continuous. The split theorem itself needs only measurable L, so no unstable lower-gate passage or transverse approximation is used. D_mid is defined for all L1 inputs, hence can be applied directly to h=f1_H even if h is irregular. Its known finite bound justifies subtraction in (17).

For the concrete choice θ=1/2 and η=1/4,

    D_mid≤4T_n+B_0+B_ext,
    C_window≤B_0+B_ext+D_mid≤4T_n+2B_0+2B_ext.            (18)

This would give a root-order full-window weak coefficient and, after the established localization, a root-order bound with one logarithm. It would also give the requested capture-Hall estimate: for g=f1_{N(B)}, every original selected cube still has average λ; apply the proved full-window weak bound for g at λ−ε and let ε↓0. Once a full-window weak bound has been obtained, this last step does not need to preserve a middle label or strict witness under source cutting.

Hypothesis (MD-high) is **not proved**. Neither (7), the smooth gate, the κ layer count nor numerical low-capacity fixtures imply it. It is a concrete source-mass contraction task for the high-variance remainder. Requiring the mass drop on all cuts would be unnecessarily stronger: low-total-burden cuts have already been paid, and the independent internal pressure work specifically tests failure of that unrestricted version. No such low-burden failure refutes (MD-high). We also do not silently replace its total-input-mass hypothesis by a Hall ratio against μ(N(B)).

If only a separate per-layer mass drop μ(H_j)≤η W is available on the high-total-burden cuts of each layer, pay each low-total-burden layer cut by T_nW and apply (16) to the others. The same A_n≥T_n observation gives, after summing over J_n layers,

    D_mid≤J_n T_n/(1−θ)+(J_n η/θ)(B_0+B_ext+D_mid).

Absorption then requires J_nη<θ; η=1/4 on each layer is not enough uniformly in n. For θ=1/2, the sufficient per-layer requirement η≤1/(4J_n) gives D_mid≤4J_nT_n+B_0+B_ext. This explicit logarithmic bookkeeping avoids treating background reclassification as free.

## 8. Three-stage pressure protocol and current evidence boundary

The exact candidate and then the cubic strengthening were sent to the existing Hall numerical owner. The requested measurements on that owner's pilot, known-counterexample pressure and enlarged-parameter runs are b(y), the first two moments of log L with weight L^(-n)1_Q, V_B, K_B, and the two sides of (9), for both full qualified cuts and maximal-cut candidates where available. Dimension, source count and receiver/scale resolution are to vary separately. This author has not duplicated those scans or written a separate numeric program.

Actual L1 source boxes, continuous first-hit certificates, entire-window smooth gate and a verified common κ layer remain required before a result is described as testing the target. Integrating the log-scale moments by quadrature is a diagnostic unless separately enclosed; an exact hard/gate certificate does not automatically certify those moments. For arbitrary weighted point receivers, (5) may fail because the physical dx constraint is gone. For atomic sources with genuine Lebesgue receiver sets, (5)–(7) remain geometric statements, but jumps can invalidate the actual contact identity (1) and therefore (9) unless that identity is separately justified.

The mass-drop statistic μ{σ²>c/n}/μ(N), for c=1/100,1/10,1, has also been requested from the same runs. The independent flux numerical owner was asked to compute this captured-source statistic on its qualified inputs rather than substitute the raw adaptive-flux distribution. A fixed c and η=1/4 on high-total-burden cuts are a sufficient full-middle bootstrap target; per-layer use requires the smaller η≤1/(4J_n) above. These are pressure targets, not established constants. Failures on low-total-burden cuts are evidence against only the unnecessarily unrestricted version.

The finalized `hall_numeric.md` and `hall_results.json` now record 12 qualified L1 fixtures, 56 complete receiver boxes, 3,796 positive source subboxes, 1,320 inner/outer receiver cuts and 7,437 positive flow arcs. All original continuous first-hit, anchor, entire-window smooth, middle and common-κ qualifications are certified. The largest displayed K is still small; the refined unequal-volume cut has the certified bracket [64/41246697,16/9670793]. The log-moment values remain midpoint diagnostics, normalized by the saved possible source union rather than a certified exact μ(N). For example the scale-spread fixture has source-average σ approximately 0.050677 and diagnostic η_(1/100) approximately 0.00122549. These measurements neither prove (V)/(MD-high) nor test a high-capacity asymptotic regime.

Both auditors independently checked the cubic theorem, the older-union formula, the paid split, the high-total-burden correction and the absorption constants. The internal countertest has now passed the exact scalar whole-window and contact-factor certificates, together with an analytic positive-volume/actual-selector proof. Its qualified conclusion is: for every fixed c>0 and η<1 there exist admissible low-total-burden compact cuts, even inside a single original background layer, for which μ{σ²>c/n}>ηW. Thus the unrestricted all-cuts mass-drop hypothesis is false. The private construction and parameters are intentionally omitted; this result neither refutes (MD-high) nor supplies a high-Hall-ratio counterexample.

The direct positive results above are independent of that countertest. No successful general-root fee is claimed. The concrete unproved tasks are (12), (V), or the high-total-burden source-mass contraction (MD-high); the proved results are the interval/cubic estimates, the actual older-union occupation formula, and the paid split with all reselection costs. The public component is frozen at this qualified status; further certificate replay metadata belongs to the audit report.

## 9. Portable exact algebra guard

This is an algebra guard, separate from the Hall owner's actual-input pressure tests. It checks the cubic and weaker quartic consequences on 60, 800 and 12,800 exact rational interval measures, the abstract equality cases in 147 dimension-stage pairs (three widths each), and three absorption identities. Every tested measure has continuous density at most n and total atomic mass at most one, so its interval constraint is proved directly. No such measure is advertised as an actual first-hit realization, and this guard does not check (V), (12), or (MD-high). The code below was run with all checks passing.

```python
from fractions import Fraction as F
from random import Random
r=Random(84043)
counts=[]
for nmax,cases in [(3,20),(16,50),(128,100)]:
    tested=0
    for n in range(1,nmax+1):
        for _ in range(cases):
            parts=[]
            for k in range(8):
                lo=F(k,16);hi=F(k+1,16)
                rho=F(r.randrange(n*8+1),8)
                parts.append((rho*(hi-lo),rho*(hi*hi-lo*lo)/2,
                              rho*(hi**3-lo**3)/3))
            atom=F(r.randrange(17),16);where=F(r.randrange(9),16)
            b=sum((p[0] for p in parts),F(0))+atom
            if not b:continue
            m1=sum((p[1] for p in parts),F(0))+atom*where
            m2=sum((p[2] for p in parts),F(0))+atom*where*where
            energy=m2-m1*m1/b
            delta=max(b-1,F(0))
            assert delta**3<=12*n*n*energy
            assert delta**4<=12*n*n*b*energy
            tested+=1
        for a in [F(1,100),F(1,20),F(1,4)]:
            b=1+2*n*a;energy=2*n*a**3/3
            assert (b-1)**3==12*n*n*energy
    counts.append(tested)
for eta,theta in [(F(1,4),F(1,2)),(F(1,8),F(3,4)),(F(2,5),F(3,5))]:
    T=F(37,11);fees=F(51,7)
    bound=(T/(1-theta)+(eta/theta)*fees)/(1-eta/theta)
    assert bound==T/(1-theta)+(eta/theta)*(fees+bound)
    if (eta,theta)==(F(1,4),F(1,2)):
        assert bound==4*T+fees
print('PASS',counts,'interval-measure algebra; no geometric mass-drop claim')
```


# Public upper interfaces: paid noise branch, captured stop, and light-source repair

**Scope and status.** This section is a self-contained public extraction containing only positive upper interfaces and finite qualified-fixture checks. The general sqrt(n) polylogarithmic adaptive source-column bound remains unproved. Definitions and arguments in this section do not depend on the internal constructions earlier in this file.

## Public Theorem B: one paid branch and a capture-supported stopped allocation

Let f>=0 belong to L1(R^n), mu=f dy, W=||f||1, lambda>0, and Q(x,L)=x+[-L/2,L/2]^n, with full sides 1<=L<=2. Retain the original hard first-contact selector L*(x), with A_L*f=lambda, on the original R82 middle Emid. Set

    w(u)=integral_0^1 exp(-|u|/t)dt,
    phi_eta=1_[-1/2,1/2]*[eta^-1 w(./eta)],
    Phi_eta=phi_eta^tensor n,
    P_eta,L=f*(Phi_eta)_L.

Fix a predetermined theta in (0,1], and define H_theta={x in Emid:P_theta,L*>=lambda/2} and F_theta=Emid\H_theta. The established physical derivative upper bound, valid for every theta in this interval, is

    ||partial_logL(Phi_theta)_L||1 <= U(n,theta),
    U(n,theta)=min(2n,sqrt(n(theta^-1+4theta/3))).

The fundamental theorem in log L and positive Tonelli give integral sup_[1,2]P_theta,L<= [1+(log2)U]W. Consequently

    lambda|H_theta|<=2[1+(log2)U(n,theta)]W.                (PB1)

For each x in F_theta define the captured contribution

    C_x(eta)=integral_Q(x,L*) (Phi_eta)_L*(x-y)dmu(y).

For |z|<=1/2, with u=(1/2-z)/eta and v=(1/2+z)/eta, the exact identity eta partial_eta phi_eta(z)=-u w(u)-v w(v)<=0 shows captured monotonicity as eta decreases. The cube boundary is mu-null and Phi_eta tends to one on its interior. Thus C_x is continuous, C_x(theta)<lambda/2 and C_x(0)=lambda. Let eta_x be its first crossing of 3lambda/4 in decreasing noise width. Then

    k_x(y)=1_Q(x,L*)(y)[(Phi_eta_x)_L*(x-y)-(Phi_theta)_L*(x-y)]>=0,
    d_x=integral k_x dmu=3lambda/4-C_x(theta),
    lambda/4<d_x<=3lambda/4,
    a_x(y)=k_x(y)/d_x,
    integral a_x dmu=1.                                  (PB2)

The first crossing is measurable by continuous-path level tests. No stochastic stopping theorem or posterior independence is used. The occupation is nonnegative inside the original capture relation, so its exchanges are justified by Tonelli.

For a receiver set B subset F_theta put

    q_B(y)=integral_B k_x(y)dx,
    ell_B(y)=lambda integral_B a_x(y)dx.

Then (4/3)q_B<=ell_B<=4q_B. The common measure gamma(dx,dy)=lambda 1_B(x)a_x(y)dx dmu(y) has exact receiver demand and original capture support. The estimate esssup_mu q_B<=C sqrt(n)polylog(n) is **not proved**. Its integrated counterpart alone is equivalent, within constant factors, to the unknown receiver fee and is not counted as a new bound.

Taking theta=log^-2(n+2), n>=2, makes (PB1) O(sqrt(n)log(n+2))W. The original R82 extreme fee Cext=2(1+n log2)/sqrt(n+2) remains in the ledger. If R83's separate registered-width low-likelihood union is also used, it costs another Cext W. The original O(log(n+2)) background layers and R81 localization are retained; no scale-count or stopping-depth cost has been suppressed.

## Public Theorem C: remove a light common source set and redistribute its demand

Keep the original f, gates, selector and stopped rows from (PB2). Let 0<=delta<1 and S be any measurable **common** source set such that

    mu(S)<=delta lambda/4.                                (PC1)

Then define

    r_S(x)=integral_S a_x(y)dmu(y),
    a'_x(y)=1_(S^c)(y) a_x(y)/(1-r_S(x)).                  (PC2)

These rows are well defined, preserve exact receiver demand and the original capture support, and give the source-column comparison

    ell'_B=0 on S,
    ell'_B(y)<=ell_B(y)/(1-delta) on S^c.                 (PC3)

**Proof.** Since L*>=1 and 0<=Phi_eta<=1, k_x(y)<=L*^-n<=1. The coarse-noise residual gives d_x>lambda/4. Hence

    0<=r_S(x)<=4mu(S)/lambda<=delta.

Integrating (PC2) over mu gives one. Its nonnegativity and capture support are inherited from a_x, and 1/(1-r_S)<=1/(1-delta) proves (PC3) by Tonelli. Every receiver is retained. This changes only the allocation; **f is not truncated**, so no first-contact perturbation, new smooth gate or likelihood reclassification is needed.

The threshold in (PC1) is an absolute source mass relative to lambda on the normalized physical window. It is not delta W. The condition is homogeneous when f and lambda are multiplied by the same positive constant. A sequence of individually light sets cannot all be discarded unless their union satisfies the stated mass condition, or the cumulative normalization cost is separately controlled.

**Source-sublevel consequence.** If, for some K>=0,

    mu({y:q_B(y)>K})<=delta lambda/4,                      (PC4)

choose precisely this set as S. On its complement ell_B<=4K, so (PC3) provides an admissible common transport with

    (gamma')_Y <=[4K/(1-delta)]mu,
    lambda|B|<=[4K/(1-delta)]W.                           (PC5)

Unlike a uniform essential-supremum assertion, (PC4) permits arbitrarily large values of the prescribed stopped column on a sufficiently light exceptional source set. This is a rigorous redistribution estimate, not an assertion that (PC4) follows automatically from the coarse gate. A dimension-uniform target K and a proof of its tail-mass condition are still missing. Thus a large fixed column carried by a light shared source does not by itself obstruct an efficient common allocation.

For example delta=1/2 permits deleting any common source set of mass at most lambda/8, with at most a factor two increase in all remaining stopped columns. Smaller source masses give proportionally smaller losses. These constants contain no n, kappa, receiver count, source subdivision count or stopping-time factor.

## Public finite check: the n=2 and n=3 Hall base fixtures survive the narrowed-noise deletion

This is a finite qualified-fixture calculation, **not** a general dimension bound. Use the Hall numeric base fixtures

    n in {2,3}, lambda=1,
    f=4^n 1_[0,41/100]^n,
    B=union over 2^n corner centers of their receiver boxes,
    each center coordinate is -2/5 or 81/100,
    each receiver half-width is h=1/10000.

The Hall report certifies the original anchor, continuous full-window eta=1 smooth gate, strict continuous first contact, and R82 middle on these complete receiver boxes. The additional gate proved here is P_theta,L*(x)<1/2 for every x in every receiver box, with theta=log^-2(n+2). It is not inferred from the original eta=1 gate.

By reflection, in each coordinate let d_i be the receiver's distance to the nearer source face, so 3999/10000<=d_i<=4001/10000. During partial capture,

    A_L=4^n product_i(1/2-d_i/L).

It is strictly increasing near contact, and comparison with all d_i equal to the endpoints gives the exact bracket

    L_minus=3999/2500<=L*(x)<=L_plus=4001/2500.           (PF1)

The captured source is a rectangle. For its normalized hard posterior, each positive displacement coordinate is uniform on [d_i/L*,1/2]. This product structure holds for this specific constant-density rectangle only. For each eta, phi_eta is concave on [0,1/2], as follows directly from its positive Laplace-mixture expression. Jensen therefore gives

    C_x(theta)<=product_i phi_theta((1/2+d_i/L*)/2).

Put u_min=(1/2+(3999/10000)/(4001/2500))/2 and Delta=3/8-u_min>0. The following elementary bounds suffice:

    n=2: theta>=1/2,  phi_theta(3/8)<2/3;
    n=3: theta>=3/8,  phi_theta(3/8)<3/4;
    |phi_eta'(z)|<=1/eta.                                (PF2)

For completeness, let I(a)=integral_0^1 t exp(-a/t)dt. Then phi_eta(3/8)=1-I(1/(8eta))-I(7/(8eta)). Monotonicity in eta on the hard interval permits using its indicated lower bound. At eta=1/2, integrate the cubic Taylor lower bound for exp(-1/(4t)) on t in [1/4,1], and use log4>4/3, to obtain I(1/4)>121/384. On t in [3/4,1], exp(-7/(4t))>=exp(-7/3)>1/11, giving I(7/4)>7/352. Their sum exceeds 1/3 because 121/384+7/352-1/3=7/4224>0. The elementary inequality e^(7/3)<11 follows from e<11/4 and 11^4<4^7. At eta=3/8, Jensen gives I(1/3)>=e^(-2/3)/2>1/4, which suffices. Finally log4<7/5 yields theta>25/49>1/2; log5<13/8 yields theta>64/169>3/8. These logarithmic bounds follow from finite exponential-series comparisons (and log2>2/3 follows from midpoint integration of 1/t).

All uncaptured source contributes at most its mass times L*^-n, since Phi_theta<=1. At hard contact the captured mass is L*^n. With W=(41/25)^n, (PF1)--(PF2) give the full, untruncated convolution bound

    P_theta,L* <= (b_n+Delta/t_n)^n+(4100/3999)^n-1,
    (b_2,t_2)=(2/3,1/2), (b_3,t_3)=(3/4,3/8).           (PF3)

Both right sides are exact rational numbers strictly below 1/2:

| n | rational bound, decimal display only |
|---|---:|
| 2 | 0.4957615946299211 |
| 3 | 0.4998549391495234 |

Thus the whole finite receiver set lies in F_theta. This proof controls the actual convolution at the actual selector throughout the receiver boxes, not sampled centers or numerical noise roots.

Let D=|B|=(4h)^n=(1/2500)^n. Any nonempty receiver subset has capture-neighborhood mass at least L_minus^n: choose any one of its receiver cubes and use exact hard contact. The retained continuous Hall interface therefore gives

    D/W <= K*_B <= D/L_minus^n.                           (PF4)

The lower bound uses only that the full capture neighborhood has mass at most W. The upper bound applies to every admissible compact receiver subset, since its volume is at most D. The explicit stopped column satisfies ell_B(y)<=4D/L_minus^n, by k_x<=L_minus^-n and d_x>1/4. Hence

    K_stop/K*_B <=4 W/L_minus^n=4(4100/3999)^n,

which is below 4.32 for n=2,3. Here K_stop is the essential supremum of the particular stopped allocation; no exact optimum or exact stopped-column maximum is claimed. This comparison shows no dimension-growing failure in these two fixtures. It does not establish the general OPEN bound or a growing-dimension asymptotic. The light-source repair can further modify these same rows without changing the input or the certified gates.

## Public validation and unresolved work

The Astra and Sol auditors independently read and passed the light-source deletion, source-sublevel consequence, and the full finite PF1--PF4 proof. Both independently reproduced the exact Fraction bounds 507659809443557/1023999872000004 (n=2) and 4853109207390525645735/9709035216592706370368 (n=3), and the conservative capacity ratios 4.204602038231489 and 4.310794787884246. Decimal values are displays only. No noise quadrature, finite exponent fit, atom-to-L1 approximation, or private source capacity enters these checks.

The outstanding general question is a root-n polylogarithmic shared capacity after the paid coarse-noise branch, allowing legitimate redistribution such as Theorem C. Neither a uniform essential-supremum bound for the fixed stopped allocation nor the source-tail condition (PC4) has been proved. The two qualified finite fixtures and the general repair lemma must remain separate from that unresolved claim.

# R84 alternative: conservative source occupation and a coordinate-confinement gain

**Status.** A new, general geometry-sensitive source budget is proved below. It applies to arbitrary nonnegative L1 inputs and the original receiver measure lambda dx. If a common source sees the receiver set confined in k coordinates, its charge is at most n/k; this gives an actual square-root paid receiver branch when a positive captured fraction comes from sources with k at least ceil(sqrt(n)). The complement is explicitly retained. Nothing proves that this fraction is uniformly positive for all inputs, so the general root-n polylog target remains open. The general O(n log n) benchmark and R82 accounting remain unchanged.

An initially tempting stopping rule—kill whenever the moving state is anywhere above the hard threshold—fails even for a fully gated positive L1 input in dimension two. We give that counterexample, replace it by marking only the original first-contact graph, and prove the actual source occupation identity. A direct deterministic envelope proof independently verifies the new estimate. This route does not use Hall decomposition or selected noise flux.

## 1. Objects, assumptions, and exact statement

Let f>=0 be in L1(R^n), mu=f dy, W=mu(R^n), lambda>0, T=log 2. Full side lengths are L. Let B be a compact regular subset of the actual retained middle event, with its original common first contact L(x) in [1,2], continuous on B, and

    mu(Q(x,L(x)))=lambda L(x)^n.

The original anchor, whole-window E2 upper gate, and middle label are not changed. These gates are not needed for the new inequality itself; they establish that B is the intended original receiver set. The estimate in fact holds for any measurable B and measurable L in [1,2] satisfying the displayed contact identity, whenever the envelopes below are measurable. Using compact B avoids all projection measurability issues and suffices for the established regular exhaustion.

For each physical source y, define

    B_y=B intersect Q(y,2),
    R_i(y)=max_{x in B_y}|x_i-y_i|,    0<=R_i<=1.

If B_y is empty, put C_B(y)=0. Otherwise set

    p_y=product_i min(1,2R_i),
    a_i(y)=max(0,log(2R_i)) in [0,T],
    A_y(t)=#{i:t<a_i(y)},
    S_y(t)=exp[-sum_i(t-a_i(y))_+],
    C_B(y)=p_y [1+integral_0^T A_y(t)S_y(t)dt].             (1)

If an R_i is zero, use a_i=0 and C_B=0, consistently with p_y=0. For compact B these functions are Borel: the feasible correspondence {x in B:|x-y|_infty<=1} has compact fibers and closed graph, and maxima of the continuous coordinate-distance functions over its nonempty fibers are upper semicontinuous. The empty-fiber locus is Borel. No source-density regularity is required.

**Universal confinement estimate.**

    lambda |B| <= integral C_B(y) mu(dy).                  (2)

Every source has one budget in this integral. In particular

    C_B(y)<=1+n log 2.                                    (3)

Define k_B(y)=#{i:R_i(y)<=1/2}. If k=k_B(y)>=1, then

    C_B(y)<=p_y[1+(n-k)(1-2^{-k})/k]<=n/k.                (4)

The constant is independent of source subdivisions, scale grids, labels, input complexity, and the number of receiver components. All radii and p_y are measured relative to the SAME original B; they must not be independently recomputed on many pieces and then summed without paying the repeated source mass.

## 2. A direct proof, including the complete source fee

At contact, Tonelli gives the exact canonical common-source load

    lambda |B|=integral b_B(y) mu(dy),
    b_B(y)=integral_B L(x)^(-n) 1_{Q(y,L(x))}(x) dx.        (5)

Fix y and let D_y=product_i[y_i-R_i,y_i+R_i]. Any x contributing to b_B(y) belongs to B_y and hence to D_y. Therefore

    b_B(y)<=integral_{D_y} sup_{1<=L<=2}
                         L^(-n)1_{Q(y,L)}(x) dx.          (6)

This is a rectangle-restricted source envelope, not the full-space envelope. It keeps the actual source geometry.

Let V_y(t)=|D_y intersect Q(y,e^t)|. Direct multiplication of interval lengths gives

    V_y(t)=product_i min(2R_i,e^t)
          =p_y exp[sum_i min(t,a_i)],
    V_y'(t)=A_y(t)V_y(t) for a.e. t in [0,T].             (7)

The supremum kernel equals one inside Q(y,1), and equals exp(-n t_entry) for points first entering at t_entry=log(2|x-y|_infty) in (0,T]. Its integral over D_y is consequently

    V_y(0)+integral_0^T e^(-nt)dV_y(t)
      =p_y[1+integral_0^T A_y(t)
                    exp(-sum_i(t-a_i)_+)dt]
      =C_B(y).                                           (8)

There is no endpoint atom because ordinary rectangle volume is absolutely continuous in t. Degenerate rectangles have zero volume. Equations (5)-(8) prove (2).

Since A_y<=n and S_y<=1, (3) follows. If k coordinates have a_i=0, then A_y<=n-k and S_y(t)<=e^(-kt). Thus

    C_B<=p_y[1+(n-k)integral_0^T e^(-kt)dt]
         =p_y[1+(n-k)(1-2^{-k})/k]<=n/k,

proving (4). This is a dimension gain of n/k for actual common source mass, with no independence assumption on f.

The formula is explicitly computable. Sort the a_i. On a time cell [u,v] with exactly j expired coordinates and E_j their index set, the integral in (1) contributes

    (n-j) exp(sum_{i in E_j}a_i)
          [exp(-ju)-exp(-jv)]/j,              j>0,
    n(v-u),                                 j=0.         (9)

Repeated a_i are grouped; zero-length cells contribute zero. Formula (9) is a calculation aid, not an assumption of bounded input complexity.

## 3. A real square-root paid branch and the unresolved complement

Take any integer 1<=k0<=n and define the common source subset

    G_B={y:B_y nonempty and k_B(y)>=k0}.

At an original contact define its captured-source fraction

    theta_B(x)=mu(G_B intersect Q(x,L(x)))/(lambda L(x)^n).

It lies in [0,1]. Applying the same Tonelli identity only to G_B, followed by (4), gives the universal estimate

    lambda integral_B theta_B(x)dx
      <=(n/k0)mu(G_B).                                    (10)

For every 0<c<=1 this proves

    lambda |{x in B:theta_B(x)>=c}|
      <= n/(c k0) mu(G_B)<=n/(c k0) W.                    (11)

With k0=ceil(sqrt(n)) and c=1/2 the fee is at most 2sqrt(n)W. This is a branch of the original receiver event defined by a measurable fraction of a common physical source set. It does not create private source capacities, change lambda, or replace the original first contact. Posterior dependence is unrestricted.

All branches are accounted for by the sharper general residual

    lambda |B| <= (n/k0)mu(G_B)
                     +integral_{G_B^c intersect N_B} C_B(y)mu(dy)
                <= (n/k0)W+(1+n log2)mu(G_B^c intersect N_B), (12)

where N_B=union_{x in B}Q(x,L(x)); the last restriction is legitimate because b_B(y)=0 outside N_B, so (2) may first be integrated over N_B. Likewise, on B_low={theta_B<c}, the original hard contact has more than a (1-c) fraction from G_B^c. One must not claim that restricting f to G_B^c preserves the original contact or smooth lower ratio; no such truncation is used here.

To close the full middle event by this route, one still needs an actual estimate controlling the unconfined contribution in (12), or a decomposition whose sum of these source budgets is root-n polylog. No theorem here makes k_B large for every source. For example, when R_i=1 for every i, (1) is exactly 1+n log2, the old linear fee. This equality concerns the envelope geometry; it is not an assertion that a fully gated input attains that fee.

If (11) is applied separately to O(log n) genuine background layers, its paid pieces cost O(sqrt(n)log n)W, and the established all-scale return adds its usual logarithm. The unconfined pieces of those same layers remain unpaid. No additional R83 exception is silently inserted into the R82 baseline.

## 4. An actual conservative source process

The probabilistic construction explains the confinement gain and supplies a separate exact occupation representation. Work first under the finite measure mu(dy) times a probability law. Conditional on Y=y, let U_i be independent uniform variables on [-1/2,1/2], set X_i(0)=y_i+U_i, and give each coordinate an independent rate-one Poisson clock. At a coordinate-i jump at time t, replace that physical coordinate by

    X_i(t)=y_i+epsilon e^t/2,

where epsilon is an independent equiprobable sign. All other physical coordinates remain fixed; every coordinate is fixed between its own jumps. The filtration contains Y,U, all clocks and signs up to time t, completed and made right continuous. Rates sum to n, so the process is nonexplosive on [0,T]. Conditional reference coordinates are independent; Y distributed according to arbitrary mu is not assumed to have independent coordinates.

For a bounded measurable test g on the retained source and physical state, the actual generator is

    L_t g(y,x)=sum_i [ (g(y,x^{i,+}(t))+g(y,x^{i,-}(t)))/2
                      -g(y,x) ].                         (13)

It annihilates constants, preserves Y, and has no omitted continuous drift in physical X. The normalization drift -n in the forward hard-average equation is the total loss term of (13), not a free negative term that can be discarded.

Conditional on y, X_t is uniform on Q(y,e^t). In one coordinate, no reset has probability e^-t and fills the original unit interval with density e^-t. A last reset at s in (0,t] and a prescribed sign has density e^{-(t-s)}ds/2. The transformation x_i-y_i=epsilon e^s/2 has Jacobian dx_i=e^s ds/2 and therefore again gives density e^-t on the outer interval. Their union is precisely [-e^t/2,e^t/2]. Taking the independent reference-coordinate product proves the marginal. Mixing over mu gives the actual hard density A_{e^t}f(x)dx with total mass W.

## 5. Marking only the original first-contact graph

Write t(x)=log L(x) on B. On every constant-position holding interval of the entire process, mark it once if its held position x belongs to B and that interval contains t(x). There is at most one mark per holding interval. Original retained receivers have t(x)>0; endpoint conventions at T can be taken consistently. For a general process state, this is an adapted first-graph-encounter rule: between jumps the future test time t(x) is known from the present state and the deterministic graph.

Graph-at-jump ties have zero mass for L1 sources. A jump at time s sets y_i=x_i±e^s/2. If s=t(x), then y lies on a face of Q(x,L(x)); for fixed x this is a source-Lebesgue null hyperplane. Integrating the jump-arrival law in s and then in y,x gives zero. The same conclusion follows from the explicit density transformation below. Thus ignoring or including such ties does not change the marked measure. Initial t=0 ties do not occur on the retained set.

Let N_B be the number of marks. The expected joint marked measure is exactly

    nu(dy,dx)=1_B(x)L(x)^(-n)1_{Q(x,L(x))}(y)mu(dy)dx
             =lambda 1_B(x)dx pi_x(dy),                  (14)

where pi_x is the actual captured-source posterior. In particular

    integral E_y N_B mu(dy)=lambda|B|.                   (15)

Here is a canonical proof, avoiding evaluation of an arbitrary almost-everywhere density on a variable graph. For fixed y, a marked hold either starts at time zero or starts with the most recent jump among all coordinates. Initial holds contribute exp[-n t(x)]1_{Q(y,1)}(x)dx. A hold starting by a coordinate-i jump at s contributes the landing law (other coordinates uniform in their side-e^s intervals), multiplied by the no-further-jump factor exp[-n(t(x)-s)] and restricted to 0<s<t(x). For a prescribed sign, the landing factor is

    (1/2)e^{-(n-1)s} dx_{-i} delta_{y_i±e^s/2}(dx_i) ds.

Changing variable s=log(2|x_i-y_i|) multiplies by 2e^-s. The resulting density is exp[-n t(x)] exactly. Its admissible region requires |x_i-y_i|>1/2, this coordinate to be maximal among all |x_j-y_j|, and |x_i-y_i|<=L(x)/2. There is a unique maximal coordinate off the pairwise-tie hyperplanes. The initial region and these outer regions partition Q(y,L(x)) up to null sets, proving (14). This is a path-arrival proof valid for arbitrary f; it is not a substitution into a time-slice Radon–Nikodym version.

This also proves the process explanation of (1). Relative magnitudes |X_i(t)-Y_i| never decrease. If the initial state lies outside D_y, no future mark in B_y is possible. The probability to start inside D_y is p_y. A coordinate-i reset after a_i makes its magnitude exceed R_i permanently and is fatal to future B_y marks. Conditional on the initial rectangle, survival against all such fatal resets until t has probability S_y(t). Before fatality, nonfatal coordinate resets have total rate A_y(t). By direct Poisson conditioning (or its elementary predictable compensator), their expected number is p_y integral A_y S_y. Each can begin at most one marked holding interval, with at most one additional initial mark. Hence E_y N_B<=C_B(y). Formula (15) gives (2) again.

All switch fees are present: nonfatal resets contribute the integral in (1); fatal resets end possible occupation; initial occupancy contributes p_y; final incomplete holding intervals are included; and the total loss rate n is carried in survival factors. No negative first-contact Jacobian is assumed favorable.

## 6. Renewal bookkeeping and what it does not prove

Let eta be the distribution of the first mark, with mass eta(total)<=W. Starting at a mark state (y,x,t(x)), retain y and use the same clock law forward in time. Let R be the subprobability kernel of the next mark, at strictly larger time; if no next mark occurs, send the trajectory to the cemetery state. A next mark requires at least one reset because the same holding interval cannot mark twice. The strong Markov statement here follows directly from independent exponential residual clocks at stopping times; the finite-jump construction also proves it by conditioning successively on clock histories.

The exact common-source renewal identity is

    nu=eta+nu R.                                          (16)

All terms are finite since N_B<=1+N_jumps and E N_jumps=nT. Define r(y,x)=R((y,x),whole mark space) and rbar(x)=integral r(y,x)pi_x(dy). Taking total masses in (16) yields

    lambda integral_B (1-rbar(x))dx=eta(total)<=W.         (17)

Thus rbar<=1-1/K is another actual branch with fee KW. This alone is a conditional interface, not a new uniform bound. The coordinate-confinement estimate (1)-(4), unlike an assumed small-return condition, bounds occupation by explicit receiver/source geometry and explains a real n/k gain. The remaining high-return/unconfined geometry has not been paid.

## 8. Novelty comparison, verification, skills, and exact limits

The R75 envelope note was read in full after the candidate was derived. R75 inflates a fixed SOURCE PACKET box, pays product_i(1+2d_i), and needs powered-posterior packet coverage. The present result instead restricts the RECEIVER extent relative to each individual common source, computes the anisotropic hard-envelope integral exactly, and pays a captured-source fraction linearly. These are different interfaces. The source process gives the same C_B as the direct envelope proof, not a second independent dynamic saving. The global 1+n log2 envelope and the positive-domination principle were already retained tools. R75’s bbox-only obstruction remains in its original scope; it cannot be used to assert failure or success of general confinement here.

The positive confinement statements were independently checked before author-proof review. The public scalar guard below checks the exact coefficient in three dimension ranges; it does not certify a generic confinement hypothesis.

Read and applied updated skills E01 occupation/flow LP, J01 genuine jump generator, I02 filtration/compensators, and K03 mixed-tail chaining, including their cube interfaces. Only elementary finite-rate process and direct integration arguments are used. E01 does not license a no-gap assertion or replace a common deterministic contact graph by arbitrary stopping. J01 requires the actual reset law and retained source; these are explicit. I02 requires the actual filtration and predictable jump count; these are explicit. K03 supplies no applicable small entropy or mixed-tail theorem here, and none is invoked. The probabilistic product law is only the independent reference clocks and uniforms, never the arbitrary posterior pi_x.

Compact regular B is enough for the original framework. To pass to a larger measurable receiver event, apply the universal estimate to each compact regular exhaustion set with its actual original selector. The source radii and C_B can increase with the set; one must keep their resulting limits or prove a uniform bound. A fixed lower confined fraction c may disappear during exhaustion. Therefore a paid branch for each finite piece is not silently promoted to a general root-n budget. The retained all-scale and low-background payments cover their original branches; (11) covers a new confined-source branch; the unconfined middle branch in (12) is the exact remaining duty.

No Git operation, PDF compilation, additional subagent, or external publication was performed.


Portable scalar confinement guard (algebra only; no whole-input exponent claim):

```python
from fractions import Fraction as F
from math import isqrt
for stage, dims in enumerate(((2,4),(16,64),(256,)), 1):
    count=0
    for n in dims:
        q=isqrt(n)+(isqrt(n)**2<n)
        for k in sorted({1,q,n}):
            C=1+F(n-k,k)*(1-F(1,2**k))
            assert C<=F(n,k)
            assert 0<C<=1+F(n,1) # conservative T=log2<1
            if k>=q: assert F(n,k)**2<=n
            count+=1
    print('stage',stage,'dimensions',dims,'exact cases',count,'PASS')
print('Only the explicit scalar formula is checked; no generic confinement is assumed.')
```


# R84 targeted original-source and updated-skill applicability audit

No checked source theorem supplies the missing general capacity. The precise reading scope and required transfer conditions are recorded below.

## 1. Actual source access and reading scope

Applied updated64 E01/E03/G01/G02/D02/D04/I02/I04/N02 and the K05 source locator. The registry `/Users/zhengzhihao/.codex/math-skill-evidence-roots.json` has one `math64-20261007` entry, resolving the complete evidence bundle under Desktop/T. Resolver PASS verified current `audit_current/e/claims.json`, `audit_current/e/cases/cases.json`, and original PDF bytes for E1502, E0182, E1994, E0925 and E2838. PASS certifies bytes/path, not a theorem. Original PDF text and the corresponding theorem/proof sections were actually read; auto-converted `paper.md` was used as a page locator, not as independent proof authority. Public arXiv originals were opened to check identity/version. No global “all64 literature fully read” claim is made.

| Original | Exact scope read this round | Local original identifier |
|---|---|---|
| Arcozzi–Holmes–Mozolyako–Volberg, *Bellman function sitting on a tree*, v2 | PDF pp.2–10, Theorem 1.3 and Lemma 1.5 proof, Theorem 2.1 proof; p.11 comparison | P-ee5e7f1d2f3397ce; SHA ee5e7f1d2f3397ceb9459d295450a1ae5352eac94962a37de361d20ca530a032 |
| Do–Thiele, *Lp theory for outer measures*, v3 | PDF pp.20–23, actual tent/size definitions and Theorem 4.1 weak-endpoint/embedding proof | P-c0cdd27d39fd5e63; SHA c0cdd27d39fd5e6301fc2f66f3041ae0a33f42b1eb182f69d74a2d0f5ac99a8a |
| Miller–Tacchi–Sznaier–Jasour, chance-peak paper, v4 | PDF pp.6–8 and 10–11, Eq.(15), A1–A7, Theorems 5.4–5.6; no independent reproof of cited generator representation | P-610d8ca4e35b8a23; SHA 610d8ca4e35b8a23fb81ddfb55520310698802aac96cfddd1b2aaebbe74beb73 |
| Domelevo et al., *A stochastic Carleson embedding theorem with constant e*, v1 | PDF pp.2–8, Theorem 2.1, Bellman quadratic-form proof and terminal step; analytic Riesz corollary not used | P-6a781aff4000e334; SHA 6a781aff4000e334ac3283b20493ba9177900726ff17d38f557a8bf60b1d8f87 |
| Pham, *A sharp version of Talagrand's selector process conjecture*, v2, 2026-09-06 | PDF pp.1–7, Theorems 1.4/1.7, definitions; pp.19–22 rounding proof. That proof invokes Theorem 1.4, whose entire tower proof was not independently certified here | P-2a906ead5c858909; SHA 2a906ead5c858909798cd3ac31dd645cfcdf52cfa5fee4f7760502195d6b195e |
| Eldan, *Thin shell implies spectral gap up to polylog*, v5 | Original PDF pp.2–8, Theorem 1.1, definitions and localization setup; covariance/localization proof not independently recertified | [Primary original](https://arxiv.org/pdf/1203.0893) |

This round does not reuse the unresolved G01 bi-tree box-counting argument, G02 printed endpoint/OR claims, E01 fixed-time no-gap claim, or D04 degenerate coarea claims as certified source theorems.

## 2. Precisely usable source tools and their cube bridges

**Tree Bellman.** On a rooted dyadic tree, let nonnegative node masses define Λ(I)=Σ_{K⊆I}λ_K and (Λ)_I=Λ(I)/|I|. Theorem 1.3 assumes, for **every** subtree I,

    Σ_{K⊆I} α_K (Λ)_K² ≤ Λ(I),   α_K≥0.

It yields Σ_I α_I(φΛ)_I²≤4 Σ_I φ(I)²λ_I. The verified potential is B=4(F−f²/(v+A)), on f²≤Fv, 0≤A≤v, v>0. Lemma 1.5 needs the exact increments F=F̃+b², f=f̃+ab, A=Ã+c, v=ṽ+a², a,c≥0. Theorem 2.1, under its particular |K|² coefficient hypothesis, gives constant32 through stopping plus Theorem1.3. [Original pp.3–10](https://arxiv.org/pdf/1809.03397v2).

Cube bridge: the actual full capture relation has nonnested centers. A tree name does not create disjoint child source masses, these increment identities, or the all-subtree inequality. The root source overlap must also be paid. Once a genuine source tree and its packing constant are proved, this theorem is useful for telescoping; obtaining that packing constant is the R84 task itself. Neither4 nor32 introduces a dimension gain.

**Outer tent embedding.** Theorem4.1 uses the real-line convolution F_φ(f)(y,t)=∫f(x)t⁻¹φ((y−x)/t)dx, smooth φ supported in [−1,1], the paper's upper-half-plane tents with their length cost, and sizes S∞ or S2. For 1<p≤∞ it gives C_{p,φ}; S2 also needs ∫φ=0. Its proof establishes an outer weak(1,1) endpoint by covering {Mf>c_φλ} with one-dimensional tents. [Original pp.20–23](https://arxiv.org/pdf/1309.0945v3).

Cube bridge: physical dx demand on the graph L*(x) must be dominated by the chosen outer exceptional-set cost; the source representation and size must fit that geometry. The original proof pays via the underlying maximal theorem. Substituting n-dimensional cube tents and asserting an inexpensive weak endpoint would assume the desired budget. A zero-mean derivative alone supplies neither the receiver-graph Carleson condition nor this cost comparison. The definition of outer distribution remains usable, but is not a new estimate.

**Stochastic Carleson.** Theorem2.1 assumes a usual filtration and n+1 continuous square-integrable martingales X^k with zero cross brackets and equal diagonal brackets. The u-system must use common integrands as in (2.2)–(2.3). For nonnegative progressive α it requires

    E[∫_t^∞ α_s ds | F_t]≤1, for every t≥0 almost surely,

and the martingale of total α-mass must have representation (2.4) in the same driving system, with the stated local square integrability. Then E∫α_sΣ_k(u_s^k)²ds≤e EΣ_k(u_∞^k)². [Original pp.2–7](https://arxiv.org/pdf/2609.39919).

Cube bridge: deterministic eta differentiation of the E2 family is not this martingale representation. A natural filtration, conditional future packing, Cauchy–Riemann integrands and L2 terminal input have not been supplied. The theorem does not prove an LlogL endpoint. Arbitrary L1 cube inputs need not have the needed L2 or entropy integrability. The R84 adaptive author's signed endpoint occupation identity remains valid independently, but its positive source load still requires a new estimate.

**Occupation LP.** Eq.(15) is the weak balance ⟨v,μ_τ⟩=⟨v(0,·),μ_0⟩+⟨Lv,μ_occ⟩. Theorem5.4 states only the upper-bound direction under A2 boundary killing, A3 continuous reward, and A4 probability initial law. The printed Theorem5.5 adds compactness A1 and generator conditions A5–A7 (constants, separating multiplicative domain and a countable graph core). [Original pp.6–11](https://arxiv.org/pdf/2303.16064v4).

The updated E01 audit retains the fixed deterministic scalar t* versus unrestricted random terminal-measure mismatch. Thus no-gap is not used. The actual finite-rate process in R84 alternative can instead be verified directly by its generator. Its abandoned killed-survival proposal needs a surviving-density bridge; conservation alone cannot provide it. The adjusted mark-only process counts real graph entries while continuing the same path, so repeat marks require a continuation-occupation budget. Its source-confinement estimate is an elementary Poisson calculation, not an application of LP no-gap. Restarting paths privately for each receiver would duplicate the original source budget.

**Fractional expectation covers.** Pham's Theorem1.7 has finite X, 0<p≤1, an increasing-family cover w:2^X→[0,1], Σ_{W⊆H}w(W)≥1, Σ_W w(W)p^{|W|}≤1/2, and support |W|≤t. It rounds to an integral cover at q=cp/log₂(2t), c absolute. Theorem1.4 instead uses independent Bernoulli selection on X, a family that is not p-small, supported weights λ_H∈[0,1] with total≥1, and integer s≥1; density Csp captures≥1−2⁻ˢ of **some** member with probability≥1−2⁻ˢ⁻¹. Displayed densities≥1 mean X itself. Constants are absolute but unoptimized. [Original pp.3–5,19–22](https://arxiv.org/pdf/2412.03540v2).

Cube bridge: Hall uses weighted source capacity μ(N(B)), whereas expectation-cover cost is p^{|W|}. The theorem controls an event under product Bernoulli law, not λ|B| under dx, and does not upgrade fractional capacity. No refinement-invariant bound on support size t or cardinality |X| has been proved; replacing source cells by arbitrarily many equal-mass subcells makes those parameters diverge. Sampling source labels independently is permitted as an auxiliary construction, but needs a separate receiver-cost and common-capacity comparison. Consequently the theorem cannot yet replace R82 Hall.

**Stochastic localization.** Eldan's Theorem1.1 gives G_n≤C√[(log n)Σ_{k=1}^n σ_k²/k], n≥2, C universal, with G_n the optimal inverse Cheeger constant and σ_k the thin-shell parameter over **isotropic log-concave** laws. Localization begins with such a probability density and normalized covariance. [Original pp.2–8](https://arxiv.org/pdf/1203.0893).

Cube bridge: arbitrary f, capture posteriors, source-scale occupation ν_y and receiver graph laws have no proved log-concavity. Whitening a general source changes centered axis-parallel cubes into parallelepipeds. The theorem concerns same-measure boundary expansion; R84 demand is dx and capacity is μ. No conversion has been supplied. Even a valid log-concave restricted-family theorem would not cover the general input.

## 4. Candidate coordination and retained R82 ledger

Coverage's final cubic inequality is a checked independent derivation, not a concentration theorem from the references. With D=λ|B| and its actual canonical source load b, the statistic is

    V_B=D^{-1}∫b(y)σ_y² dμ(y),
    (K_B−1)_+³/K_B≤12n²V_B.

The desired high-K-only bound V_B≤C log^{2a}(n+2)/n remains a new geometric hypothesis. Coverage also offers a genuine low-variance source split and reclassifies residual sources through the original gates; its uniform source-mass drop μ(H)≤ηW with η<θ is the explicit unproved absorption condition. No concentration theorem above supplies that mass drop. The general bounded log-scale interval only gives V_B≤(log2)²/4, returning O(n). Adaptive's stopped signed endpoint identity is legitimate, but its source-positive budget is not provided by stochastic Carleson. Alternative abandoned the cheap killed-survival proposal and now uses the actual continuing mark process. Its direct Poisson confinement estimate can pay sources confined in k≥√n coordinates at coefficient n/k; unconfined-source continuation remains explicit. Neither the independence of auxiliary Poisson clocks nor the source Markov construction implies product structure of arbitrary capture posteriors. These precise findings were sent to all three authors and both independent auditors; no source citation is being used to conceal missing bridges.

The five-page input PDF's R81/R82 accounting is preserved: original anchor/smooth fee [4+2(log2)√(7n/3)]W; original extreme fee C_ext W=2(1+n log2)W/√(n+2); C_loc log(n+2) full-scale return. The printed source extraction `e−sn/2` is read as **e^{-s_n}/2**, verified in the shared contract. Then r>e^{-s_n}/2 gives

    1≤κ=1+log(λ/(2P_L*))<1+s_n,
    J_n≤1+floor(log₂(1+s_n))=O(log(n+2)).

The O(log n) layer count does not prove a layer budget. If one proves uniform layerwise K_j≤C√n log^a(n+2), layer summation and localization cost two more logarithms. A κ-dependent power would need an explicit new ledger.

R83 registered-width exception unions are different-kernel branches. Retaining the original R82 decomposition and adding the R83 union costs another C_ext W unless an overlap/rebudget proof is supplied. R83's fixed-L noise variation bound (2+log51)√n W cannot be inserted at L*(x). This source audit adds source applicability contracts, with **no new unconditional general payment from literature** and no reduction in D_mid. Any restricted R84 source-confinement or coarse-width payment must use its author’s stated residual and fee, rather than silently changing this R82 ledger.


## 5. Necessary novelty check against the actual R75 envelopes

Read R75 `envelope.md` Sections2–6 and `soft.md` Section4, and R84 alternative Sections1–3. This comparison concerns the actual source and receiver formulas. It identifies the new conditional refinement and the retained global envelope.

**Exact identity and retained principle.** For a source y let B_y=B∩Q(y,2), R_i=max_{x∈B_y}|x_i−y_i| and D_y=∏[y_i−R_i,y_i+R_i]. Then R84's coefficient is exactly

    C_B(y)=∫_{D_y} sup_{1≤L≤2} L^{-n}1_{Q(y,L)}(x) dx.

Indeed F_y(s)=|D_y∩Q(y,e^s)|=p0 exp(Σ_i min(s,a_i)), a_i=max(0,log(2R_i)), and dF_y=A_yF_y ds. Points inside Q(y,1) have envelope1; points entering at s have envelope e^{-ns}. Thus the integral is F_y(0)+∫_0^{log2}e^{-ns}dF_y(s)=p0[1+∫A_yS_y ds]. This is the same price as the author's independent Poisson argument, not an extra dynamic improvement over deterministic positive-envelope payment.

The underlying domination b_B(y)≤∫sup_L hard kernel and the full-window bound1+nlog2 are **retained tools**. R75 soft Section4 already proves the ray-decreasing finite-window envelope with this dimensional factor; its hard-kernel specialization extends to continuous scales directly (or by rational-scale approximation). When R_i=1 in every coordinate, R84's formula is exactly1+nlog2. This case must not be counted as a new round advance.

**The finer geometric information is distinct.** R75 envelope Section2 encloses a fixed **source packet P** in c_P+∏[−d_i,d_i], constructs a pointwise positive kernel e_{m,d}, and charges source mass w_P times envelope mass≤∏(1+2d_i). Its Sections3–4 then seek coverage by Σ_Pα_Pπ_P^{1+t}, with shared capacities and an explicit1/t fee. R84 D_y instead encloses the **receiver section seen from one source**, leaves the canonical capture posterior at power1, and evaluates the hard supremum on this non-dilating physical rectangle. No source-packet expansion price or powered-posterior coverage assertion occurs. Conversely, R75's packet-box sizes do not determine these receiver extents.

R84's explicit rectangle integral and its anisotropic estimate are not stated in the cited R75 results. If k coordinates have R_i≤1/2, then A_y≤n−k and S_y≤e^{-ks}, giving

    C_B(y)≤p0[1+(n−k)(1−2^{-k})/k]≤n/k.

This is a **new explicit geometry refinement of the retained envelope**, rather than a new unconditional general-input bound. Its capture-fraction branch is then a direct Tonelli/Markov consequence: for the common confined source set G_B, θ_B(x)=μ(G_B∩Q*)/(λL*^n),

    λ∫_Bθ_B dx=∫_{G_B}b_B dμ≤(n/k0)μ(G_B),
    λ|{θ_B≥c}|≤nμ(G_B)/(c k0).

With k0≥√n it genuinely pays that restricted branch. The new assumption is actual receiver-relative confinement of enough captured source mass. Nothing in either R75 or R84 proves that assumption for all remaining R82 cuts. Thus it should be credited as a conditional geometric refinement/paid branch, not as independent conservative-flow cancellation or progress on the unrestricted residual capacity.



# R84：真实 L1、全门槛的紧接收子集与 Hall 输运夹逼

本记录只研究下列公开上接口测试输入。它不包含、也不公开用户未发表的下界构造。`hall_probe.py` 是独立标准库程序；`python3 hall_probe.py` 在同目录重建确定性的 `hall_results.json`。没有原子噪声替代、有限尺度首触替代或旧轮门槛继承。这里的结论是有限组真实正 L1 输入和紧接收子集的认证，不是一般维数上界，也不声称覆盖完整保留事件。

## 1. 输入与三阶段

输入是有限个轴盒指示函数的正线性组合，`lambda=1`，物理窗口为完整 `[1,2]`。基础盒是 `[0,41/100]^n`，密度 `4^n`；这属于已公开审查的上接口几何。额外的小盒加入非乘积的相关混合，源质量、接收盒和权重均以有理数完整保存。额外盒与基础盒可重叠；原输入是这些密度的物理相加。

三个阶段分别改变：基础 n=2 测试的源分割及接收范围；相关源组件、接收体积不平衡与首触尺度范围；n=3、源组件数及同一物理输入的源分割分辨率。最细不等体积测试使用每组件每轴 32 等分。源分割只是输运证书的内外近似，不改变输入或原 selector。随机种子字段为 840611，但这些输入全为显式确定性的有理数，不作随机抽样。

每个接收盒的全部 Lebesgue 体积均被认证；盒边界为零测度。接收点始终在源盒之外，所以局部输入密度为零。所有门槛、Hall 需求和源容量使用同一个完整输入、同一个原首触 selector、同一个 κ 层。

## 2. 连续首触与严格事件

固定源盒的每一坐标重叠长度为

`max(0,min(x+L/2,b)-max(x-L/2,a))`。

接收小盒内，上包络取各源盒坐标中心的最近接收位置，下包络取最远接收端点。这些不同组件可使用不同接收位置；它们是正确的逐组件正上下包络，不冒充一个共同点。每个包络的全部 `[1,2]` 物理断点 `2|x-a|,2|x-b|` 被加入。断点之间，实际捕获分子是次数不超过 n 的精确有理多项式；减去 `L^n`，保存完整 Sturm 链、单侧变号数、较早区间的负值见证和首根隔离区间。

上包络首根的下端与下包络首根的上端夹住整个接收盒上的真实 `L* = inf{L∈[1,2]:A_L≥1}`。原点门由 `A_upper(1)<1/2` 精确验证。还保存一个共同尺度的下包络严格见证 `A_lower(L)>1`，所以各点属于原严格极大事件。每个根包围区间内，各重叠分支的状态被精确核对；`L*C'(L)-n*C(L)` 的统一正下界保证真实首触是上穿而非切触。原 selector 连续变化，没有用尺度网格定义首触。用于包络根的 28 次二分只隔离多项式根。

## 3. 真实 E2 平滑门、原 middle 截断与 κ

采用原核

`w(z)=∫_0^1 exp(-|z|/t)dt`, `phi=h*w`, `h=1[-1/2,1/2]`。

对 `z≥0`，真实 φ 的 t 被积函数是

- `t*(2-exp(-(.5-z)/t)-exp(-(.5+z)/t))`，当 `z≤.5`；
- `t*(exp(-(z-.5)/t)-exp(-(z+.5)/t))`，当 `z≥.5`。

两式均关于 t 单调非减。内区间每项 `t(1-exp(-c/t))` 的导数非负；外区间导数之差由 `(1+v)exp(-v)` 的单调性为正。因此左右 t-Riemann 和是证明型上下界，不是经验误差估计。

指数值以 60 位定点整数向外包围：范围缩减到 `v≤1/2`；正指数 Taylor 20 项的逐项定点上下界加上两倍下一项的严格余项上界；随后取倒数、逐次平方并每次向外取整。φ 的参数利用其偶性及单调递减性，向两侧取 24 位网格值；这个参数网格只用于正核的单调区间包围。代码没有把浮点 `exp` 当作门槛证书。

源坐标积分采用有理左右和。完整窗口 `[1,2]` 被 24 个有理尺度区间覆盖；每个尺度区间使用 `1/L` 及核参数的正确相反方向，逐组件形成正包络再相加。保存每一段的上界及全窗口最大上界，全部严格低于 `1/2`。它覆盖全部尺度，而非仅检验有限尺度值。所用计数是 t=32、每个源坐标=16。selected P 的区间另使用真实根包围区间。

原 R82 middle 截断并未换成方便的阈值。由于 `mu_ell≥-log M` 且 s_n 中附加项非负，有

`(1/2)exp(-s_n) ≤ (1/2)m*M^(n-1)`。

保存的 `middle_threshold_upper=(1/2)m_upper*M_upper^(n-1)` 是原 extreme 门的保守上界。仅当 selected P 的严格下界超过它时，才认证属于原 `Emid`。这无需把 μell、对数或平方根的数值积分当成证明。κ 的层测试也不用浮点对数：`κ∈[2^j,2^(j+1))` 等价于 P 落在相应指数阈值区间；代码以指数包围的正确严格方向验证。n=2 测试在 j=0，n=3 测试在 j=1。

## 4. 连续源容量 Hall 下上界

每个源组件分割为正质量子盒。对一个完整接收盒及其 `L*∈[lo,hi]`，保证捕获盒为各坐标 `[x_hi-lo/2,x_lo+lo/2]`，可能捕获外盒为 `[x_lo-hi/2,x_hi+hi/2]`。

内图只在源子盒整体落入保证捕获盒时连边；外图只要源子盒与可能外盒有正体积交集就连边。需求是完整接收盒的 `lambda*volume`，源容量为同一物理源分量的 `K*mass`。没有按接收行生成私人源容量。重叠组件的标签容量相加恰不超过 `K*f(y)dy`；因此标签流可推回真实物理源。

对有限二部图，枚举全部非空接收行子集。其 Hall 比值为总需求除以所邻接源子盒的质量并集；这与源子集形式等价。内图所得 K 以独立整数最大流验证：所有正流弧、容量、整数公共分母、守恒、满需求及残余割均保存。

**内图 K 是真实连续 B 上的可行输运上界。** 将每个接收行到源子盒的流均匀分布于行的整个接收盒和整个源子盒。所有这样的物理对均满足原捕获关系，所以对任意可测接收子集仍满足需求；不是仅对有限行做检查后猜测连续可行。**外图 K 是真实连续 B 上的割下界。** 对见证行并集，其实际源邻域包含于外图源子盒并集；后者质量偏大，故有限比值只会偏小。外图自身的有限可行流不被用于宣称真实连续上界。

该对内外区间有明确有限分割含义。源网格细化时，外源邻域多收边界层、内邻域少收边界层的误差趋零；进一步细分接收盒时，首触包围及空间边界层也收敛。本次只给实际保存的有限夹逼，不把一次分割精度直接升级成一般最优值收敛速率。

## 5. 固定原后验与 log-scale 诊断

因 `A_L*=lambda=1`，原硬后验给出的规范源负载是 `b(y)=∫_B L*(x)^(-n)1_Q(x,L*) (y) dx`。每个正质量源子盒上的精确 b 区间使用内外邻域及根区间；全部子盒的最大下/上端分别给 essential 最大负载的下/上界。平均负载严格等于 `lambda*|B|/W`。它与自由输运的 Hall K 在同一输入、同一 B、同一 κ 层下比较。

log-scale 矩、σ 和 `eta_c=mu{sigma²>c/n}/mu(N)` 则明确是独立的中点诊断。接收中心使用该实际点的另一个精确物理多项式首根隔离区间；源使用源子盒中心，之后才以浮点对数计算矩。它们不参与资格、Hall 上下界或 flow 守恒认证，也没有“证明型 σ 上界”的标签。分别保存完整接收集合和内图最大 K 割的诊断，c 为 `1/100,1/10,1`。诊断分母是保存的 `possible_union_mass`，即外邻域源子盒并集质量；真实 N 的精确质量未在这些矩诊断中求出。因此表内 σ 和 η 是该外邻域分割上的中点近似，不是已认证的 `mu(N)` 归一化积分。理论式 `b*sigma²≥(b-1)_+³/(12n²)` 及 `2+sqrt(12)*n*avg_sigma` 仅被列作诊断参照；这些例子的 K 很低，不能检验或证明高 K 分支所需的维数一致条件。

## 6. 结果范围

下面表格及精确计数由冻结 JSON 产生。对称测试的内外 K 相等；它不是数值拟合。相关源加上不等体积接收盒产生局部最大割，粗源分割给非零夹逼间隙；相同原输入在 m=32 时收窄该间隙。没有发现 qualified 高 K 反例，也没有因此证实一般便宜覆盖。对源截断后重新计算 smooth/middle/κ 的问题，这些数据不给自动稳定结论。

| 测试 | n / 源组件 / 源子盒 | 真实 Hall K 的严格区间 | 全窗口 P 上界 | 最大原后验负载区间 |
|---|---:|---|---:|---|
| pilot_n2_source_m2 | 2 / 1 / 4 | [1/16810000, 1/16810000] | 0.343619 | [1.561719e-08, 6.253126e-08] |
| pilot_n2_source_m4 | 2 / 1 / 16 | [1/16810000, 1/16810000] | 0.343619 | [6.246876e-08, 6.253126e-08] |
| pilot_n2_broader_receiver_volume | 2 / 1 / 64 | [9/6724, 9/6724] | 0.419657 | [0.001688872, 0.002004901] |
| pilot_n2_receiver_halfwidth_refined | 2 / 1 / 16 | [1/67240000, 1/67240000] | 0.343564 | [1.562109e-08, 1.562891e-08] |
| correlated_nearface_n2 | 2 / 2 / 32 | [1/16978100, 1/16978100] | 0.349151 | [6.309906e-08, 6.316109e-08] |
| correlated_three_components_n2 | 2 / 3 / 48 | [1/17146200, 1/17146200] | 0.352772 | [6.374846e-08, 6.381179e-08] |
| correlated_unequal_receiver_volume_n2 | 2 / 3 / 48 | [403/274339200, 1/391673] | 0.353795 | [1.600234e-06, 1.616554e-06] |
| correlated_receiver_scale_spread_n2 | 2 / 3 / 48 | [1/17146200, 1/17146200] | 0.418295 | [7.343841e-08, 7.351739e-08] |
| dimension_n3_base | 3 / 1 / 64 | [1/68921000000, 1/68921000000] | 0.201426 | [1.561329e-11, 1.563672e-11] |
| dimension_n3_correlated | 3 / 3 / 192 | [1/70299420000, 1/70299420000] | 0.207720 | [1.594204e-11, 1.59658e-11] |
| source_resolution_n2_m8 | 2 / 3 / 192 | [1/17146200, 1/17146200] | 0.352772 | [6.374846e-08, 6.381179e-08] |
| unequal_receiver_source_refinement_m32 | 2 / 3 / 3072 | [64/41246697, 16/9670793] | 0.353795 | [1.600234e-06, 1.616554e-06] |

精确计数：12 输入，56 个完整合格接收盒，3796 个正质量源子盒，1320 个内外图接收割，以及 7437 条正流弧。所有费用均针对这些盒的原 Lebesgue 体积。

原后验负载上界本身也给一个合法可行输运上界，因此可以进一步与内图流上界取较小值。这里为使有限图证书对应清楚，表内 Hall 上端保留独立内图最大流值。

不等体积例的内图最大割是第一接收盒；同一输入粗分割 m=4 到细分割 m=32 的上界约从 2.5532e-6 降到 1.6545e-6，割下界约从 1.4690e-6 升到 1.5516e-6。细分误差有可见控制，但没有声称这两个有限间隙就是连续最优值的全部误差率。

log-scale 诊断摘要：

| 测试 | 全集合源质量加权 σ | 最大 K 割的 σ | 全集合 η_(1/100) |
|---|---:|---:|---:|
| pilot_n2_source_m2 | 0 | 0 | 0 |
| pilot_n2_source_m4 | 0 | 0 | 0 |
| pilot_n2_broader_receiver_volume | 0 | 0 | 0 |
| pilot_n2_receiver_halfwidth_refined | 0 | 0 | 0 |
| correlated_nearface_n2 | 0.0001998655 | 0.0001998655 | 0 |
| correlated_three_components_n2 | 0.000400985 | 0.000400985 | 0 |
| correlated_unequal_receiver_volume_n2 | 7.136372e-05 | 0 | 0 |
| correlated_receiver_scale_spread_n2 | 0.05067705 | 0.05067705 | 0.00122549 |
| dimension_n3_base | 0 | 0 | 0 |
| dimension_n3_correlated | 0.0002268272 | 0.0002268272 | 0 |
| source_resolution_n2_m8 | 0.0004007386 | 0.0004007386 | 0 |
| unequal_receiver_source_refinement_m32 | 7.900197e-05 | 0 | 0 |

这是捕获源上的 log L 统计，不是未经捕获加权的原始通量统计。尺度扩展测试出现正的低阈值 η，但全部 K 仍低；不能把低 K 分支的广尺度现象当作高 K 分支失败证书。


# Independent audit of the R84 positive interfaces

**Verdict.** The positive lemmas below pass within their stated hypotheses. They provide general inequalities, explicit paid receiver portions, and conditional closure mechanisms. They do not prove the general centered-cube bound C_n<=sqrt(n)n^{o(1)}. The retained general benchmark remains O(n log n).

| Item | Audit result and exact scope |
|---|---|
| Shared-source scale variance | PASS. For the actual Lebesgue receiver plan, (b-1)_+^3<=12n²b sigma². Jensen gives (K-1)_+^3/K<=12n²V_B. No arbitrary weighted point model substitutes for dx. |
| Older-source union mechanism | PASS as an identity and conditional estimate. The earliest capturing scale gives an upper bound on V_B through the actual union of other receivers' earlier cubes. A uniform bound for that union is not supplied. |
| Paid variance split | PASS. Low-variance source mass pays the corresponding receiver fraction. The remaining positive L1 input is reselected and reclassified at its new threshold, with anchor, smooth and original extreme fees explicitly charged. |
| High-total-demand bootstrap | PASS as a conditional theorem. MD-high is required only for D>T_nW, where W is the total current input mass. It is not a condition on D/mu(N). The low-demand alternative and compact supremum justify the displayed absorption. |
| Paid coarse-noise branch and captured stop | PASS. The physical-dilation upper estimate applies throughout its stated noise range; the captured stopped kernel is nonnegative, uses the original selector and has exact row normalization. Its shared source-column capacity is still unknown. |
| Light-source deletion and redistribution | PASS. If a common source set has mass at most delta lambda/4 with delta<1, removing it from every stopped row and renormalizing increases remaining columns by at most 1/(1-delta). The corresponding column-tail condition yields capacity 4K/(1-delta). The condition is an absolute mass relative to lambda, not a fraction of W. |
| Finite narrowed-noise checks | PASS. The specified n=2 and n=3 complete receiver-box fixtures remain after the extra coarse-noise deletion. Exact rational upper bounds and conservative stopped/optimal capacity comparisons hold. No exact optimum or growing-dimension conclusion is asserted. |
| Source-coordinate confinement | PASS. The rectangle-restricted source envelope gives the stated n/k fee when k coordinates are confined, and therefore an explicit paid receiver portion. The unconfined source contribution remains in the ledger. |
| Graph-only source occupation | PASS. The explicit arrival calculation defines the graph measure canonically and avoids evaluating arbitrary fixed-time density versions on a variable graph. The first/next-mark renewal retains the common source and charges repeated visits. |
| Qualified finite Hall certificates | Mathematical qualification and bound directions pass. Whole receiver cells satisfy continuous first-contact, strict-witness, anchor, smooth and original-middle/layer gates. Inner flows give continuum upper certificates; outer whole-cell neighborhoods give lower certificates. Moment diagnostics are not certified uniform variance bounds. |

The exact remaining general interfaces are: a uniform older-union or high-capacity conditional-variance estimate; the source-mass contraction MD-high on all qualifying high-total-demand cuts; a root-order shared capacity for the captured-stopped residual, possibly through its light-source tail condition; or a uniform payment of the unconfined/high-return source remainder. None has been established. A per-layer mass contraction carries the factor J_n and requires J_n eta<theta for absorption.

The original R81 anchor/smooth fee, R82 extreme fee, O(log(n+2)) original background-layer count and all-scale localization are retained. An additional registered-width exception union requires its additional charge. Restricting a source does not preserve its original lower smooth floor or layer label; the proved recursive split recomputes both.

Several stronger shortcuts have been ruled out or corrected without affecting the desired weak-type target: the raw selected absolute-noise budget cannot be inferred from the fixed-scale bound; an integrated signed stopping budget is comparable to the unknown receiver demand; initial threshold killing does not supply a uniform survivor-density lower bound; and the original gates do not impose a general small-posterior-entropy condition. Requiring source-mass contraction on every qualified cut is also too strong; the surviving bootstrap hypothesis is restricted to high total demand. This does not refute MD-high or the high-capacity variance interface. Details of the internal pressure constructions are excluded from this public audit.

The review found and resolved two formal issues: graph densities now use an explicit arrival representative, and source-neighborhood restriction is applied before replacing the actual source load by an envelope. No unresolved defect was found in the positive lemmas listed above. Finite computations and conditional implications remain separate from the unproved general theorem.

# R84 independent certificate and general-proof audit

**Public conclusion.** The common-source upper lemmas and paid branches pass this audit in their stated scopes. The qualified finite continuum Hall certificates pass independent exact verification. The general bound \(C_n\le\sqrt n\,n^{o(1)}\) remains **UNPROVED**. No finite fixture, source-normalized row, conservative process, or theorem cited in the source review supplies the missing general capacity estimate.

## Independence, objects and publication boundary

The contract and all five pages of source text were read before the new author proofs, at **2026-10-11 12:39:49 UTC**. Timestamped independent candidate derivations were saved at 12:45:09 UTC, with further prechecks before proof review. The initial precheck SHA256 was `765d363317d22c54c27ff84b1c4b84d3f85bbe1138ba5a4de2d7a2e648e63804`. Candidate statements were audited as mathematical claims, rather than accepted from author conclusions or another auditor's receipt. The formal coverage, adaptive, alternative and source manuscripts and their TeX counterparts were subsequently read. TeX review is static; no compilation is claimed.

The audit retains positive L1 source \(\mu=fdy\), one shared mass \(W\), original Lebesgue receiver demand \(\lambda dx\), full-side window \([1,2]\), original continuous hard contact, and the R82 middle/layer ledger. The cutoff is \(e^{-s_n}/2\). The R83 different-kernel union is an additional paid deletion; it does not replace the original middle globally. Every logarithmic layer/localization cost remains explicit.

Only this public section may be integrated into public deliverables. The delimited private section below preserves the complete blind precheck and local method-pressure receipts. Private recipes, programs and data are not dependencies of the public guard, and are excluded from the public archive. Anonymous failures of hypotheses may be reported without publishing their inputs.

## General mathematics checked

**Scale spread.** At a fixed physical source, the actual weighted log-scale occupation satisfies \(\beta_y([a,c])\le1+n(c-a)\). Centered layer cake independently gives
\[
 (b-1)_+^3\le12n^2b\sigma_y^2.
\]
Jensen against \(\mu\) yields \((K-1)_+^3/K\le12n^2V_B\), where \(V_B=\int b\sigma_y^2d\mu/(\lambda|B|)\), not a reference or unweighted source variance. For \(K\ge2\), \(K^2\le96n^2V_B\). A uniform high-capacity variance estimate of order polylog/n is **open**; bounded scale range alone gives order n.

The earliest capture predictor uses the union of all older original cubes. Layer cake gives its overlap integral exactly (up to immaterial h endpoints). Under the additional actual bound \(\mu(Q_x\cap U_{t-h})\le R\lambda e^{n(t-h)}\), integrating \(2h\min(1,Re^{-nh})\) gives \(((\log R)^2+2\log R+2)/n^2\). No inexpensive common-union cover is proved. Replacing that union by a concentric old cube would be invalid.

The low-variance-source branch costs \(\max(2,\sqrt{96cn})\mu(G)/(1-\theta)\). High-source-share rows are genuine strict witnesses of \(f1_H\) at the **new** threshold \(\theta\lambda\); the author correctly reselects and reclassifies all gates and pays \((B_0+B_{\rm ext}+D_{\rm mid})\mu(H)/\theta\). Absorption requires an additional uniform source mass drop \(\eta<\theta\) only on cuts with \(\lambda|B|>T_nW\), which is **open**. Lower total-burden cuts are already paid by \(T_nW\); the compact-supremum maximum reduces because the recursive constant is at least \(T_n\). This is a total-input-mass condition, not a condition obtained by substituting \(\mu(N(B))\) for W. Lusin/inner regularity supports compact continuous-restricted-selector exhaustion because this hypothesis adds no transversality. A per-layer drop has the additional layer factor in its recursive coefficient; it cannot be substituted free of charge.

**Noise upper interfaces.** The predetermined-width high branch has fee \(2[1+(\log2)\min(2n,\sqrt{n(\theta^{-1}+4\theta/3)})]W\). Captured-only smoothing is monotone as noise decreases; the full smoothing path need not be. Absolute continuity makes the selected cube boundary source-null. The measurable first captured crossing of \(3\lambda/4\) gives a nonnegative kernel k, gain \(d\in(\lambda/4,3\lambda/4]\), and exact capture-supported transport rows. Their source columns satisfy \((4/3)q\le\ell\le4q\); a target uniform column bound is **open**. An integrated signed stopped budget alone is equivalent within constants to the receiver fee and is not an independent estimate.

Deleting a common source set of mass at most \(\delta\lambda/4\), with \(\delta<1\), and renormalizing each row raises its off-set columns by at most \((1-\delta)^{-1}\). This is allocation repair, not source truncation: the input, hard selector and all gates remain fixed. The sufficient tail-mass condition on \(\{q>K\}\) is not proved. The threshold is absolute source mass relative to \(\lambda\), not \(\delta W\).

The separately stated public n=2/3 base-fixture narrowed-width checks pass: actual first-contact bracket, captured rectangular-posterior Jensen, rational scalar Taylor bounds and uncaptured source mass together give full selected smoothing upper bounds
\[
507659809443557/1023999872000004<1/2,
\qquad4853109207390525645735/9709035216592706370368<1/2.
\]
These refer to the narrowed kernel at the original selector, not an inherited eta=1 gate. The resulting finite stopped/Hall comparison is below 4.32 in these two dimensions only. It gives no growing-dimension capacity estimate.

**Conservative occupation and confinement.** The rectangle coefficient is exactly the hard finite-window supremum integrated over the receiver section seen by a fixed physical source. If k coordinates of that section have radius at most 1/2, the coefficient is at most \(p_0[1+(n-k)(1-2^{-k})/k]\le n/k\). The captured-fraction branch with \(k\ge\lceil\sqrt n\rceil\) is genuinely paid at order \(\sqrt n\); the unconfined source contribution remains explicit and **unpaid**. The full-window envelope principle is retained from earlier work; this explicit anisotropic refinement is distinct from a source-packet bbox price.

The rate-one coordinate-reset generator, normalization loss and growing uniform-cube marginal were checked. The marked graph measure is derived canonically by the actual last-arrival change of variables, not by substituting a time-slice density on a variable graph. Jump/graph ties are source-null after integration for L1 input. Initial occupancy, all reset arrivals and the final holding interval are charged. The source-preserving next-mark identity pays a continuation-deficit branch; it supplies no uniform small-return or generic confinement bound. Reference clock independence does not make arbitrary capture posteriors independent.

**Limits and source use.** The original selector may touch the level before a later strict crossing. Field convergence alone does not imply a regular first branch; lower likelihood labels must be reclassified after source cuts. Uniform hard endpoint convergence on the bounded physical window is valid by tight scaled noise laws and L1 translation continuity, also at the selected scale. It does not convert a fixed-L variation bound to a selected-L integral. The source literature review specifies its hypotheses and missing bridges; this audit does not claim to have independently reread every cited original paper. No tree packing, stochastic Carleson condition, posterior log-concavity, occupation-LP no-gap assertion or expectation-cover capacity conversion is accepted merely by naming that theorem.

## Independent public numerical verification

The frozen Hall input has **12 cases, 56 complete qualified receiver boxes, 3796 physical source bins, 1320 exhaustive inner/outer receiver cuts, and 7437 positive flow arcs**. These are actual positive L1 box mixtures and whole-box receiver dx. They do not exhaust the complete retained event.

The independent guard imports no author program. It reconstructs the physical overlap polynomials, all 496 upper/lower envelope interval rows and 248 actual-center interval rows, exact Sturm prefix/root signs, uniform derivative lower bounds, anchor and strict witnesses. It independently encloses genuine E2 values with **80-bit outward alternating Taylor arithmetic**, distinct from the author's positive-series/inversion method, and checks source/t Riemann bounds, all continuous scale intervals, the original middle inequality and common κ layer.

It also reconstructs every source partition, guaranteed/possible capture mask, exhaustive Hall cut and exact flow conservation/capacity/saturation. The inner graph's feasible flow lifts to all continuum receiver subsets; the outer graph cut gives a lower bound. Overlapping source-component labels add to the same physical density. Canonical load bounds use exact inner/outer directions. Saved log-scale means, variances and η statistics remain midpoint diagnostics; their possible-union denominator is not certified exact \(\mu(N)\).

An independent temporary-directory run of the frozen main program exited 0 in **37.976611 s**, with empty stderr and byte-identical JSON. The independent exact checker passed in **40.444481 s** before the final public scalar checks were added. The final five-member-only extraction test then exited 0 in **41.784414 s** (guard internal elapsed **39.152120 s**), with empty stderr and all six additional public rational checks passing. These are separate receipts: the guard verifies saved certificates; it does not re-run the main program.

Frozen public main SHA256: `7de54e891e1978f053ec7cabfc92cec4d36ff41d7f992b3ace1f4e632b434e8f`.
Frozen public result SHA256: `fc986f30cf1acc4d0d08198f566771a8e28495fa0c32a2c7a076d3ebb1602f03`.

Final public guard SHA256: `3d1988315ac793eed269497c5dd5214ba68b7d92cb727d9e3b4d09d823d3ed22`. Component code hashes are `1e3b6de8e5fa69237bfe573c9e81a123f50bdf2a3558c5ed1862a9ae4935561d` and `200e04833979d4919ba9e1b56f5f0724c21d9e322fb985788922aa2015c89918`.

The public guard additionally replays the frozen embedded interval-measure algebra and scalar confinement guards. They certify their finite algebraic cases, not a geometric mass-drop or generic confinement theorem. Its archive-only path reads only the five public members: proof.md, proof.tex.txt, hall_probe.py, hall_results.json, inventory.json. Extracted guard files are optional; otherwise the two component code blocks are found by exact hash in proof.md. There is no dependency on local component manuscripts, skills, private numerical files, or an unarchived workspace path.

## Remaining duties

The high-capacity variance/source-overlap estimate, source mass contraction, stopped-column/tail-mass estimate, and unconfined continuation budget are all unresolved. Three-stage qualified finite tests do not settle these uniform quantifiers. The original R82 exception ledger, optional additional payments, actual background-layer sum and all-scale localization remain required. This round supplies verified upper interfaces and finite certificates; it does not prove the requested general square-root bound.

## 公开独立证书核验脚本

```python
#!/usr/bin/env python3
"""Public R84 audit: no author imports, no external documents or private inputs.
Run beside hall_probe.py/hall_results.json and public proof.md, or development
coverage.md/alternative.md. Exact certificates do not prove a general bound.
"""
from fractions import Fraction as F
from functools import lru_cache
from itertools import product
from pathlib import Path
import hashlib,json,re,subprocess,sys,tempfile,time,math
ROOT=Path(__file__).resolve().parent
EXPECTED={'hall_probe.py':'7de54e891e1978f053ec7cabfc92cec4d36ff41d7f992b3ace1f4e632b434e8f','hall_results.json':'fc986f30cf1acc4d0d08198f566771a8e28495fa0c32a2c7a076d3ebb1602f03'}
GUARDS={'coverage': '1e3b6de8e5fa69237bfe573c9e81a123f50bdf2a3558c5ed1862a9ae4935561d', 'alternative': '200e04833979d4919ba9e1b56f5f0724c21d9e322fb985788922aa2015c89918'}
COUNTS={}
def check(v,label):
    if not v:raise AssertionError(label)
    COUNTS[label.split(':')[0]]=COUNTS.get(label.split(':')[0],0)+1

def fs(v):return F(v)
def box(v):return tuple(tuple(map(F,ab)) for ab in v)
def vol(b):return math.prod(v-u for u,v in b)
def ov(x,a,b,L):return max(F(0),min(b,x+L/2)-max(a,x-L/2))
def cap(boxes,pts,L):
    return sum(F(b['density'])*math.prod(ov(x,a,z,L) for x,(a,z) in zip(pt,box(b['bounds']))) for b,pt in zip(boxes,pts))
def tr(p):
    p=list(map(F,p))
    while len(p)>1 and p[-1]==0:p.pop()
    return p

def padd(p,q):return tr([(p[i] if i<len(p) else 0)+(q[i] if i<len(q) else 0) for i in range(max(len(p),len(q)))])
def pmul(p,q):
    r=[F(0)]*(len(p)+len(q)-1)
    for i,a in enumerate(p):
        for j,b in enumerate(q):r[i+j]+=a*b
    return tr(r)
def peval(p,x):
    v=F(0)
    for a in reversed(p):v=v*x+a
    return v

def pd(p):return tr([i*p[i] for i in range(1,len(p))] or [0])
def rem(p,q):
    p=tr(p);q=tr(q)
    while len(p)>=len(q) and p!=[0]:
        c=p[-1]/q[-1];s=len(p)-len(q)
        for i,v in enumerate(q):p[s+i]-=c*v
        p=tr(p)
    return p

def sturm(p):
    p=tr(p);r=[p,pd(p)]
    if r[-1]==[0]:return r[:1]
    while True:
        z=[-v for v in rem(r[-2],r[-1])]
        if z==[0]:return r
        r.append(z)
def sgn(v):return (v>0)-(v<0)
def side(p,x,direction):
    k=0;p=tr(p)
    while p!=[0]:
        v=peval(p,x)
        if v:return sgn(v)*(direction if k%2 else 1)
        p=pd(p);k+=1
    return 0

def V(seq,x,direction):
    signs=[side(p,x,direction) for p in seq];signs=[s for s in signs if s]
    return sum(a!=b for a,b in zip(signs,signs[1:]))
def nr(p,a,b):return V(sturm(p),a,1)-V(sturm(p),b,-1)

def hard(h,boxes,pts,n):
    pts=[tuple(map(F,p)) for p in pts]
    breaks=sorted({F(1),F(2)}|{2*abs(x-y) for b,pt in zip(boxes,pts) for x,ab in zip(pt,box(b['bounds'])) for y in ab if 1<2*abs(x-y)<2})
    check(breaks==list(map(F,h['physical_breakpoints'])),'hard:physical arrangement')
    check(len(h['intervals'])==len(breaks)-1,'hard:interval count')
    polys=[]
    for i,(a,b,r) in enumerate(zip(breaks,breaks[1:],h['intervals'])):
        u=(3*a+b)/4;v=(a+3*b)/4;p=[F(0)]
        for src,pt in zip(boxes,pts):
            term=[F(src['density'])]
            for x,(lo,hi) in zip(pt,box(src['bounds'])):
                p0=ov(x,lo,hi,u);p1=ov(x,lo,hi,v);s=(p1-p0)/(v-u)
                term=pmul(term,[p0-s*u,s])
            p=padd(p,term)
        q=padd(p,[0]*n+[-1]);polys.append(q)
        check(p==tr(r['numerator']) and q==tr(r['difference']),'hard:independent overlap polynomial')
        check(nr(q,a,b)==r['open_roots'],'hard:independent Sturm root count')
        check(peval(q,F(r['witness_point']))==F(r['witness_difference']),'hard:witness residual')
    hit=h['first_contact'];i=hit['interval_index'];lo,hi=map(F,hit['bracket']);p=polys[i]
    check(breaks[i]<=lo<=hi<=breaks[i+1],'hard:first root enclosure')
    for j in range(i):
        check(nr(polys[j],breaks[j],breaks[j+1])==0 and peval(polys[j],breaks[j])<0 and peval(polys[j],(breaks[j]+breaks[j+1])/2)<0,'hard:complete negative prefix')
    check(nr(p,breaks[i],lo)==0 if lo>breaks[i] else True,'hard:root prefix within cell')
    check((peval(p,lo)==0 if lo==hi else nr(p,lo,hi)==1),'hard:isolated contact')
    check(side(p,lo,-1)<0 and side(p,hi,1)>0,'hard:strict first crossing signs')
    check(cap(boxes,pts,F(1))==F(h['anchor_average']),'hard:anchor direct mass')

# Independent alternating Taylor enclosure rather than the author's positive
# Taylor/inversion procedure. 80-bit integer intervals with range reduction and
# outward squaring. Every comparison is rational.
BITS=60;S=1<<BITS;Z=1<<24
@lru_cache(None)
def expminus(x):
    x=F(x);check(x>=0,'exp:nonnegative argument')
    k=0
    while x>F(1,2):x/=2;k+=1
    # 80-bit outward basic-integer arithmetic on alternating Taylor terms.
    # The 25th odd partial sum is below exp(-x); the 24th even sum is above.
    # Independent of the author's positive-exp series and inversion route.
    P=1<<80;vl=x.numerator*P//x.denominator;vu=-(-x.numerator*P//x.denominator)
    tl=tu=P;sl=su=P;even_upper=P
    for j in range(1,26):
        tl=tl*vl//(P*j);tu=-(-tu*vu//(P*j))
        if j%2:sl-=tu;su-=tl
        else:sl+=tl;su+=tu;even_upper=su
    l,u=sl,even_upper
    check(0<l<=u,'exp:alternating enclosure')
    for _ in range(k):l=l*l//P;u=-(-u*u//P)
    return F(l,P),F(u,P)
@lru_cache(None)
def phi_at(zi,nt):
    z=F(zi,Z);lower=upper=F(0)
    for j in range(1,nt+1):
        t=F(j,nt)
        if z<=F(1,2):
            a,b=expminus((F(1,2)-z)/t),expminus((F(1,2)+z)/t)
            l,u=t*(2-a[1]-b[1]),t*(2-a[0]-b[0])
        else:
            a,b=expminus((z-F(1,2))/t),expminus((z+F(1,2))/t)
            l,u=max(F(0),t*(a[0]-b[1])),t*(a[1]-b[0])
        if j<nt:lower+=l/nt
        upper+=u/nt
    return lower,upper

def phi(z,nt):
    z=abs(F(z));l=z.numerator*Z//z.denominator;u=-(-z.numerator*Z//z.denominator)
    return phi_at(u,nt)[0],phi_at(l,nt)[1]
@lru_cache(None)
def coord(a,b,u,v,lo,hi,ny,nt):
    check(v<a or u>b,'smooth:outside coordinate')
    near=a-v if v<a else u-b;far=a-u if v<a else v-b;w=b-a
    l=sum(phi((far+w*F(j+1,ny))/lo,nt)[0] for j in range(ny))*w/(ny*hi)
    r=sum(phi((near+w*F(j,ny))/hi,nt)[1] for j in range(ny))*w/(ny*lo)
    return l,r

def smooth(boxes,receiver,lo,hi,ny,nt,parts=None):
    low=up=F(0)
    for i,src in enumerate(boxes):
        factors=[coord(a,b,u,v,lo,hi,ny,nt) for (a,b),(u,v) in zip(box(src['bounds']),receiver)]
        if parts is not None:
            for f,p in zip(factors,parts[i]['coordinate_intervals']):check(F(p[0])<=f[0]<=f[1]<=F(p[1]),'smooth:independent scalar enclosure')
        low+=F(src['density'])*math.prod(f[0] for f in factors)
        up+=F(src['density'])*math.prod(f[1] for f in factors)
    return low,up

def receiver(c,boxes,n):
    r=box(c['receiver']);check(vol(r)==F(c['volume']),'receiver:physical dx volume')
    for upper,key in [(True,'upper'),(False,'lower')]:
        pts=[]
        for src in boxes:
            pt=[]
            for (a,b),(u,v) in zip(box(src['bounds']),r):
                center=(a+b)/2;pt.append(min(max(center,u),v) if upper else (u if abs(u-center)>=abs(v-center) else v))
            pts.append(pt)
        check(pts==[list(map(F,p)) for p in c[key+'_envelope_points']],'hard:receiver uniform envelope points')
        hard(c[key+'_hard_certificate'],boxes,pts,n)
    lo,hi=map(F,c['Lstar_interval']);check(1<lo<=hi<2,'receiver:window bracket')
    check(lo==F(c['upper_hard_certificate']['first_contact']['bracket'][0]) and hi==F(c['lower_hard_certificate']['first_contact']['bracket'][1]),'receiver:uniform bracket direction')
    check(F(c['anchor_upper'])<F(1,2),'receiver:strict anchor gate')
    w=F(c['strict_witness_scale']);strict=cap(boxes,[tuple(map(F,p)) for p in c['lower_envelope_points']],w)/w**n
    check(strict==F(c['strict_witness_lower']) and strict>1 and hi<w<=2,'receiver:uniform strict witness')
    deriv=F(0)
    for src,saved in zip(boxes,c['uniform_derivative']['components']):
        mins=[];maxs=[];slopes=[]
        for (a,b),(u,v) in zip(box(src['bounds']),r):
            check(v<a or u>b,'hard:outside source component')
            near=a-v if v<a else u-b;far=a-u if v<a else v-b
            if hi/2<=near:mn=mx=F(0);s=F(0)
            elif lo/2>=far+b-a:mn=mx=b-a;s=F(0)
            else:
                check(lo/2>far and hi/2<near+b-a,'hard:uniform capture branch')
                mn=lo/2-far;mx=hi/2-near;s=F(1,2)
            mins.append(mn);maxs.append(mx);slopes.append(s)
        d=F(src['density'])*(lo*sum(slopes[j]*math.prod(mins[k] for k in range(n) if k!=j) for j in range(n))-n*math.prod(maxs))
        check(d==F(saved['derivative_numerator_lower']),'hard:uniform derivative reconstruction');deriv+=d
    check(deriv==F(c['uniform_derivative']['derivative_numerator_lower']) and deriv>0,'hard:uniform positive derivative')
    ny,nt=c['source_Riemann_count'],c['t_Riemann_count'];sel=smooth(boxes,r,lo,hi,ny,nt,c['selected_P']['components'])
    pl,pu=map(F,c['selected_P']['interval']);check(pl<=sel[0]<=sel[1]<=pu,'smooth:selected interval enclosure')
    window=c['window_scale_intervals'];check(F(window[0]['scale_interval'][0])==1 and F(window[-1]['scale_interval'][1])==2,'smooth:full continuous window endpoints')
    for j,x in enumerate(window):
        a,b=map(F,x['scale_interval'])
        check(a<b and (not j or a==F(window[j-1]['scale_interval'][1])),'smooth:continuous window coverage')
        check(smooth(boxes,r,a,b,ny,nt)[1]<=F(x['upper']),'smooth:whole scale-cell enclosure')
    pmax=max(F(x['upper']) for x in window);check(pmax==F(c['whole_window_P_upper']) and pmax<=F(1,2),'smooth:entire original upper gate')
    m,M=c['phi_half_interval'],c['phi_zero_interval']
    for z,v in [(F(1,2),m),(F(0),M)]:
        l,u=phi(z,nt);check(F(v[0])<=l<=u<=F(v[1]),'smooth:kernel endpoint enclosure')
    mid=F(1,2)*F(m[1])*F(M[1])**(n-1)
    check(mid==F(c['original_middle_threshold_upper']) and pl>mid,'smooth:original R82 middle qualification')
    j=c['kappa_layer'];threshold=c['kappa_thresholds'][j]
    for a,k in [((1<<(j+1))-1,'lower_P_threshold'),((1<<j)-1,'upper_P_threshold')]:
        l,u=expminus(F(a));v=threshold[k];check(F(v[0])<=l/2<=u/2<=F(v[1]),'smooth:kappa exp threshold enclosure')
    check(pl>F(threshold['lower_P_threshold'][1]) and pu<=F(threshold['upper_P_threshold'][0]),'smooth:common original kappa stratum')


def masks_and_flow(case):
    inp=case['input'];boxes=inp['boxes'];n=inp['n'];m=inp['source_partition_per_axis'];bins=case['source_bins'];i=0
    for k,src in enumerate(boxes):
        for idx in product(range(m),repeat=n):
            b=tuple((a+(z-a)*F(j,m),a+(z-a)*F(j+1,m)) for (a,z),j in zip(box(src['bounds']),idx));p=F(src['density'])*vol(b)
            check(box(bins[i]['bounds'])==b and F(bins[i]['mass'])==p and bins[i]['component']==k,'source:complete physical partition');i+=1
    check(i==len(bins) and sum(F(b['mass']) for b in bins)==F(inp['W']),'source:one additive actual mass')
    rows=case['transport_rows'];check(len(rows)==len(case['receivers']),'Hall:row coverage')
    for row,c in zip(rows,case['receivers']):
        r=box(row['receiver']);lo,hi=map(F,row['Lstar_interval']);inner=tuple((v-lo/2,u+lo/2) for u,v in r);outer=tuple((u-hi/2,v+hi/2) for u,v in r)
        check(r==box(c['receiver']) and F(row['demand'])==vol(r) and F(row['volume'])==vol(r),'Hall:actual receiver dx demand')
        im=om=0
        for j,b in enumerate(bins):
            bb=box(b['bounds'])
            if all(u>=a and v<=z for (u,v),(a,z) in zip(bb,inner)):im|=1<<j
            if all(min(v,z)>max(u,a) for (u,v),(a,z) in zip(bb,outer)):om|=1<<j
        check(im==row['inner_source_mask'] and om==row['outer_source_mask'] and im&om==im,'Hall:actual inner/outer neighborhoods')
        center=tuple((u+v)/2 for u,v in r);hard(row['midpoint_receiver_hard_certificate'],boxes,[center]*len(boxes),n)
    check(len({r['kappa_layer'] for r in rows})==1,'Hall:single actual layer')
    mass=lambda mask:sum(F(b['mass']) for j,b in enumerate(bins) if mask>>j&1)
    for key,graphkey in [('inner_source_mask','inner_graph'),('outer_source_mask','outer_graph')]:
        graph=case[graphkey];best=F(0);maxmask=0;cuts=graph['all_receiver_cuts'];check(len(cuts)==(1<<len(rows))-1,'Hall:all receiver subsets')
        for mask,c in enumerate(cuts,1):
            union=0;d=F(0)
            for j,r in enumerate(rows):
                if mask>>j&1:union|=r[key];d+=F(r['demand'])
            p=mass(union);ratio=d/p
            check(c['receiver_mask']==mask and c['source_union_mask']==union and F(c['demand'])==d and F(c['source_union_mass'])==p and F(c['ratio'])==ratio,'Hall:independent exhaustive cut')
            if ratio>best:best=ratio;maxmask=mask
            elif ratio==best:maxmask|=mask
        check(best==F(graph['K']) and maxmask==graph['maximal_maximizer_receiver_mask'],'Hall:exact maximum cut')
    ki,ko=F(case['inner_graph']['K']),F(case['outer_graph']['K']);check(ko<=ki and list(map(F,case['continuum_Hall_K_interval']))==[ko,ki],'Hall:continuum bracket direction')
    flow=case['inner_graph']['flow'];layout=flow['node_layout'];sr=1;sb=1+len(rows);sink=sb+len(bins);check(layout==dict(source=0,receiver_start=sr,source_bin_start=sb,sink=sink),'flow:node layout')
    total=sum(F(r['demand']) for r in rows);balance=[F(0)]*(sink+1);seen=set();binused=[F(0)]*len(bins);rowout=[F(0)]*len(rows)
    for a in flow['positive_arcs']:
        u,v=a['tail'],a['head'];value,capacity=F(a['flow']),F(a['capacity']);check((u,v) not in seen and 0<value<=capacity,'flow:arc capacity');seen.add((u,v));balance[u]-=value;balance[v]+=value
        if u==0:check(sr<=v<sb and capacity==F(rows[v-sr]['demand']),'flow:receiver demand capacity')
        elif sr<=u<sb:
            check(sb<=v<sink and rows[u-sr]['inner_source_mask']>>(v-sb)&1,'flow:guaranteed continuum capture support');rowout[u-sr]+=value
        else:
            check(sb<=u<sink and v==sink and capacity==ki*F(bins[u-sb]['mass']),'flow:common actual source capacity');binused[u-sb]+=value
    check(balance[0]==-total and balance[sink]==total and all(v==0 for v in balance[1:sink]),'flow:exact conservation and saturation')
    check(rowout==[F(r['demand']) for r in rows] and all(v<=ki*F(b['mass']) for v,b in zip(binused,bins)),'flow:continuum feasible upper witness')
    check(F(flow['total'])==total and F(flow['cut_capacity'])==total,'flow:saved totals')
    for j,b in enumerate(bins):
        lower=sum(F(r['volume'])/F(r['Lstar_interval'][1])**n for r in rows if r['inner_source_mask']>>j&1)
        upper=sum(F(r['volume'])/F(r['Lstar_interval'][0])**n for r in rows if r['outer_source_mask']>>j&1)
        saved=case['canonical_source_load_enclosures'][j]
        check(F(saved['lower'])==lower and F(saved['upper'])==upper,'source:canonical actual load enclosure')
    # Saved logarithmic midpoint moments remain diagnostics, not certificates.


def component_guards():
    texts=[]
    if (ROOT/'proof.md').exists():texts.append((ROOT/'proof.md').read_text())
    for name in ('coverage','alternative'):
        p=ROOT/(name+'.md')
        if p.exists():texts.append(p.read_text())
    blocks=[s.rstrip()+'\n' for t in texts for s in re.findall(r'^```python\s*\n(.*?)^```\s*$',t,re.M|re.S)]
    with tempfile.TemporaryDirectory() as td:
        for name,expected in GUARDS.items():
            p=ROOT/(name+'_guard.py');code=p.read_bytes() if p.exists() else next((b.encode() for b in blocks if hashlib.sha256(b.encode()).hexdigest()==expected),None)
            check(code is not None and hashlib.sha256(code).hexdigest()==expected,'portable:frozen public component '+name)
            p=Path(td)/(name+'.py');p.write_bytes(code);r=subprocess.run([sys.executable,'-B',str(p)],cwd=td,capture_output=True,text=True,timeout=120)
            check(r.returncode==0 and not r.stderr,'portable:public component replay '+name);print(name,r.stdout.strip())

def public_finite_width_checks():
    # The public base-fixture narrowed-width gate, distinct from eta=1 gate.
    delta=F(3,8)-(F(1,2)+F(3999,10000)/F(4001,2500))/2
    check(F(121,384)+F(7,352)-F(1,3)==F(7,4224),'public:scalar Jensen/Taylor margin')
    check(11**4<4**7,'public:finite exponential comparison')
    for n,b,t in [(2,F(2,3),F(1,2)),(3,F(3,4),F(3,8))]:
        upper=(b+delta/t)**n+F(4100,3999)**n-1
        check(upper<F(1,2),'public:narrowed-width finite-fixture gate')
        check(4*F(4100,3999)**n<F(108,25),'public:finite stopped/Hall comparison')


def main():
    start=time.monotonic()
    for name,h in EXPECTED.items():check(hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==h,'bytes:frozen '+name)
    data=json.loads((ROOT/'hall_results.json').read_text());check(data['schema']=='actual-L1-full-gate-conservative-continuum-Hall-v1','schema:actual L1 model')
    for c in data['cases']:
        for r in c['receivers']:receiver(r,c['input']['boxes'],c['input']['n'])
        masks_and_flow(c)
    public_finite_width_checks()
    component_guards()
    print('PASS R84 independent public audit',json.dumps(COUNTS,sort_keys=True),'elapsed',round(time.monotonic()-start,6))
    print('Scope: finite continuum certificates; midpoint log moments diagnostic; general square-root bound UNPROVED.')
if __name__=='__main__':main()
```
