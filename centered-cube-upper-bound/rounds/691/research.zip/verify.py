from pathlib import Path
from itertools import product,combinations
from fractions import Fraction as F
import json,hashlib
import sympy as s
p=Path(__file__).resolve().parent;r=json.loads((p/'RESULT.json').read_text())
assert r['script_sha256']==hashlib.sha256((p/'NUMERIC.py').read_bytes()).hexdigest()
total=0
for f in r['fixtures']:
 boxes=[[(F(a),F(b)) for a,b in B] for B in f['boxes']];N=len(boxes)
 axes=[]
 for k in range(len(boxes[0])):
  ep=sorted({x for B in boxes for x in B[k]});axes.append([(a+b)/2 for a,b in zip(ep,ep[1:])])
 masks=set()
 for point in product(*axes):
  bits=tuple(int(all(a<x<b for x,(a,b) in zip(point,B))) for B in boxes)
  if any(bits):masks.add(bits)
 masks=sorted(masks,key=lambda bits:sum(v<<i for i,v in enumerate(bits)))
 assert masks==[tuple(g['bits']) for g in f['merged_incidence_masks']]
 m=len(masks);d=[]
 for B in boxes:
  v=F(1)
  for a,b in B:v*=b-a
  d.append(v)
 P=F(f['P0_exact']);q=list(map(F,f['q_equals_toy_baseline_u']));w=list(map(F,f['receiver_weights_w']));theta=list(map(F,f['original_packing_primal_theta']))
 assert sum(d[i]*theta[i] for i in range(N))==P
 for b in masks:assert sum(b[i]*theta[i] for i in range(N))<=1 and sum(b[i]*q[i] for i in range(N))<=1
 Ffield=[sum(b[i]*w[i] for i in range(N)) for b in masks];mi=[max(Ffield[j] for j,b in enumerate(masks) if b[i]) for i in range(N)]
 assert mi==list(map(F,f['m_i']))
 env=[sum(q[i]*(mi[i]-Ffield[j])*b[i] for i in range(N)) for j,b in enumerate(masks)];err=[env[j]+Ffield[j]/8 for j in range(m)]
 for j,g in enumerate(f['merged_incidence_masks']): assert env[j]==F(g['Eenv']) and err[j]==F(g['Etotal'])
 cons=[([int(k==j) for k in range(m)],F(0)) for j in range(m)]+[([b[i] for b in masks],d[i]) for i in range(N)]
 vertices=set(); count=0
 for c in combinations(range(len(cons)),m-1):
  count+=1;M=s.Matrix([[1]*m]+[cons[j][0] for j in c]);rhs=s.Matrix([s.Rational(P)]+[s.Rational(cons[j][1]) for j in c])
  if M.det()==0:continue
  y=tuple(F(v) for v in M.inv()*rhs)
  if min(y)<0 or any(sum(a*b for a,b in zip(row,y))<bound for row,bound in cons):continue
  vertices.add(y)
 assert count==f['enumeration']['basis_systems_exhaustively_considered'];total+=count
 stored={tuple(map(F,v['mask_masses_y'])) for v in f['all_exact_vertices']};assert vertices==stored and vertices
 V=sum(d[i]*w[i] for i in range(N));U=sum(d[i]*q[i] for i in range(N))
 for y in vertices:
  ri=[sum(y[j]*masks[j][i] for j in range(m))-d[i] for i in range(N)]
  B=sum(d[i]*q[i]*mi[i]+q[i]*mi[i]*ri[i]-F(7,8)*w[i]*ri[i] for i in range(N))+sum(y[j]*Ffield[j]*(1-sum(q[i]*masks[j][i] for i in range(N))) for j in range(m))
  assert B-F(7,8)*V==sum(y[j]*err[j] for j in range(m))
 for name,coeff in [('Eenv',env),('Etotal',err)]:
  vals=[sum(a*b for a,b in zip(y,coeff)) for y in vertices]
  assert min(vals)==F(f['extrema'][name]['minimum']) and max(vals)==F(f['extrema'][name]['maximum'])
assert total==784
if (p/'MANIFEST.json').exists():
 for name,digest in json.loads((p/'MANIFEST.json').read_text())['sha256'].items(): assert hashlib.sha256((p/name).read_bytes()).hexdigest()==digest,name
print('PASS: rebuilt all masks; independently enumerated 784 exact systems, 3 full optimal dual faces, all extrema and signed identities. Toy scope only.')
