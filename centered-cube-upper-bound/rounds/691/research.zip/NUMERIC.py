#!/usr/bin/env python3
"""R691 three frozen toy identities on the full original packing-dual optimal face."""
from fractions import Fraction as Q
from itertools import product,combinations
from math import comb
from pathlib import Path
import json,hashlib,sys,time,platform
import numpy as np
import scipy
from scipy.optimize import linprog
ROOT=Path(__file__).resolve().parent;start=time.time();tau=Q(1);R=Q(10);kap=Q(7,8)
def cube(y,s):return [(v-s,v+s) for v in y]
def inside(p,B):return all(lo<=x<=hi for x,(lo,hi) in zip(p,B))
def volume(B):
 v=Q(1)
 for lo,hi in B:v*=hi-lo
 return v
def poscells(boxes):
 axes=[]
 for t in range(len(boxes[0])):
  ep=sorted(set(v for B in boxes for v in B[t]));axes.append([((a+b)/2,b-a) for a,b in zip(ep,ep[1:])])
 out=[]
 for xx in product(*axes):
  p=[v[0] for v in xx];mass=Q(1)
  for v in xx:mass*=v[1]
  bits=[int(inside(p,B)) for B in boxes];mask=sum(v<<i for i,v in enumerate(bits))
  if mask:out.append({'point':p,'mass':mass,'bits':bits,'mask':mask})
 return out
def solve_square(matrix,rhs):
 n=len(rhs);M=[[Q(v) for v in row]+[Q(b)] for row,b in zip(matrix,rhs)]
 for col in range(n):
  piv=next((i for i in range(col,n) if M[i][col]),None)
  if piv is None:return None
  M[col],M[piv]=M[piv],M[col];a=M[col][col];M[col]=[v/a for v in M[col]]
  for i in range(n):
   if i!=col and M[i][col]:
    a=M[i][col];M[i]=[v-a*w for v,w in zip(M[i],M[col])]
 return tuple(M[i][-1] for i in range(n))
def serial(v):
 if isinstance(v,Q):return str(v)
 if isinstance(v,(list,tuple)):return [serial(x) for x in v]
 if isinstance(v,dict):return {k:serial(x) for k,x in v.items()}
 return v

def audit(name,boxes,radii,q,w,P0,theta):
 n=len(boxes);d=[volume(B) for B in boxes];cells=poscells(boxes)
 for row in cells:
  row['g']=sum((q[i]*row['bits'][i] for i in range(n)),Q(0));row['F']=sum((w[i]*row['bits'][i] for i in range(n)),Q(0))
  assert row['g']<=1 and row['F']<=1
  row['D_i']=[sum((w[j]*row['bits'][j] for j in range(n) if radii[j]>radii[i]/R),Q(0)) for i in range(n)]
  assert all(x==row['F'] for x in row['D_i'])
  assert sum((theta[i]*row['bits'][i] for i in range(n)),Q(0))<=1
 assert sum((theta[i]*d[i] for i in range(n)),Q(0))==P0
 mi=[max(row['D_i'][i] for row in cells if row['bits'][i]) for i in range(n)]
 for row in cells:
  row['Eenv']=sum((q[i]*(mi[i]-row['D_i'][i])*row['bits'][i] for i in range(n)),Q(0));far=[sum((q[i]*row['bits'][i] for i in range(n) if radii[i]>=R*radii[j]),Q(0)) for j in range(n)]
  assert all(far[j]==0 for j in range(n) if w[j])
  row['Etotal']=row['Eenv']+sum((w[j]*(tau/8-far[j])*row['bits'][j] for j in range(n)),Q(0));assert row['Eenv']>=0 and row['Etotal']>=0
 groups={}
 for row in cells:
  key=row['mask']
  if key not in groups:groups[key]={'mask':key,'bits':row['bits'],'mass':Q(0),'Eenv':row['Eenv'],'Etotal':row['Etotal'],'g':row['g'],'F':row['F'],'witness':row['point']}
  else:assert (groups[key]['Eenv'],groups[key]['Etotal'])==(row['Eenv'],row['Etotal'])
  groups[key]['mass']+=row['mass']
 masks=sorted(groups);gs=[groups[k] for k in masks];m=len(gs);parent_rows=[[Q(g['bits'][i]) for g in gs] for i in range(n)]
 # Full rational vertex enumeration of y>=0,A^T y>=d,sum y=P0.
 cons=[]
 for j in range(m):cons.append(([Q(int(k==j)) for k in range(m)],Q(0),'nonnegative_'+str(j)))
 for i in range(n):cons.append((parent_rows[i],d[i],'parent_'+str(i)))
 vertices={};singular=0;feasiblebases=0
 for active in combinations(range(len(cons)),m-1):
  value=solve_square([[Q(1)]*m]+[cons[j][0] for j in active],[P0]+[cons[j][1] for j in active])
  if value is None:singular+=1;continue
  if any(v<0 for v in value) or any(sum((a*b for a,b in zip(row,value)),Q(0))<dd for row,dd in zip(parent_rows,d)):continue
  assert sum(value,Q(0))==P0;feasiblebases+=1
  vertices.setdefault(value,[cons[j][2] for j in active])
 assert vertices
 V=sum((d[i]*w[i] for i in range(n)),Q(0));mu=[d[i]*q[i] for i in range(n)];U=sum(mu,Q(0));vr=[]
 for value,active in vertices.items():
  parentmass=[sum((a*b for a,b in zip(row,value)),Q(0)) for row in parent_rows];slack=[parentmass[i]-d[i] for i in range(n)];assert all(v>=0 for v in slack)
  env=sum((value[j]*gs[j]['Eenv'] for j in range(m)),Q(0));total=sum((value[j]*gs[j]['Etotal'] for j in range(m)),Q(0))
  t1=sum((mu[i]*mi[i] for i in range(n)),Q(0));t2=sum((q[i]*mi[i]*slack[i] for i in range(n)),Q(0));t3=sum((value[j]*gs[j]['F']*(tau-gs[j]['g']) for j in range(m)),Q(0));t4=-kap*sum((w[i]*slack[i] for i in range(n)),Q(0));B=t1+t2+t3+t4
  assert B-kap*V==total
  vr.append({'mask_masses_y':value,'one_active_basis':active,'parent_integrals':parentmass,'parent_slacks_r':slack,'Eenv_integral':env,'Etotal_integral':total,'signed_bill_terms':{'sum_mu_m':t1,'sum_q_m_r':t2,'integral_h_F_tau_minus_g':t3,'minus_kappa_sum_w_r':t4},'B':B,'kappaV':kap*V,'B_minus_kappaV':B-kap*V,'exact_identity_passed':True})
 extrema={}
 for objective in ('Eenv','Etotal'):
  key=objective+'_integral';low=min(v[key] for v in vr);high=max(v[key] for v in vr)
  tests=[]
  for sign,expected in ((1,low),(-1,high)):
   obj=np.array([sign*float(g[objective]) for g in gs]);lp=linprog(obj,A_ub=-np.array(parent_rows,dtype=float),b_ub=-np.array([float(v) for v in d]),A_eq=np.ones((1,m)),b_eq=np.array([float(P0)]),bounds=(0,None),method='highs')
   assert lp.success and abs(sign*lp.fun-float(expected))<1e-10
   tests.append({'sense':'min' if sign==1 else 'max','success':bool(lp.success),'objective':float(sign*lp.fun),'exact_value':expected,'absolute_error':abs(sign*lp.fun-float(expected))})
  extrema[objective]={'minimum':low,'maximum':high,'minimizer_vertex_indices':[j for j,v in enumerate(vr) if v[key]==low],'maximizer_vertex_indices':[j for j,v in enumerate(vr) if v[key]==high],'HiGHS_crosschecks':tests}
 return {'name':name,'boxes':boxes,'radii':radii,'q_equals_toy_baseline_u':q,'receiver_weights_w':w,'P0_exact':P0,'original_packing_primal_theta':theta,'U_toy':U,'V_toy':V,'Delta_toy':P0-U,'m_i':mi,'all_positive_cells':cells,'merged_incidence_masks':gs,'enumeration':{'variables':m,'inequalities':len(cons),'basis_systems_exhaustively_considered':comb(len(cons),m-1),'singular_bases':singular,'feasible_bases':feasiblebases,'unique_vertices':len(vr),'proof_scope':'Compact polytope y>=0,sum y=P0; every vertex has a full-rank set of m-1 active inequalities with the equality. All such systems were enumerated exactly.'},'all_exact_vertices':vr,'extrema':extrema,'all_original_parent_constraints_included':True,'q0_parent_constraints_included':True,'h_not_forced_to_qtight_support':True,'scope':'Abstract identity diagnostic on finite actual boxes, not actual owner/receiver/high-tau history or payment of V.'}

fixtures=[]
fixtures.append(audit('shared three-square baseline',[cube([Q(0),Q(0)],Q(1)),cube([Q(-3,2),Q(0)],Q(1)),cube([Q(3,2),Q(0)],Q(1))],[Q(1)]*3,[Q(1,8),Q(7,8),Q(7,8)],[Q(0),Q(1),Q(1)],Q(8),[Q(0),Q(1),Q(1)]))
fixtures.append(audit('cheap four-square baseline',[cube([Q(0),Q(0)],Q(1)),cube([Q(-2),Q(0)],Q(1,4)),cube([Q(-3,2),Q(0)],Q(1)),cube([Q(3,2),Q(0)],Q(1))],[Q(1),Q(1,4),Q(1),Q(1)],[Q(1),Q(15,16),Q(0),Q(0)],[Q(0),Q(0),Q(1),Q(1)],Q(8),[Q(0),Q(0),Q(1),Q(1)]))
fixtures.append(audit('four-interval variable dual face',[[(Q(-1),Q(1))],[(Q(-6),Q(-2))],[(Q(-5,2),Q(-1,2))],[(Q(1,2),Q(5,2))]],[Q(1),Q(2),Q(1),Q(1)],[Q(1),Q(15,16),Q(0),Q(0)],[Q(0),Q(0),Q(1),Q(1)],Q(6),[Q(0),Q(1),Q(0),Q(1)]))
assert fixtures[0]['extrema']['Eenv']['minimum']==fixtures[0]['extrema']['Eenv']['maximum']==0
assert fixtures[1]['extrema']['Eenv']['minimum']==fixtures[1]['extrema']['Eenv']['maximum']==0
assert fixtures[0]['extrema']['Etotal']['minimum']==fixtures[0]['extrema']['Etotal']['maximum']==1
assert fixtures[1]['extrema']['Etotal']['minimum']==fixtures[1]['extrema']['Etotal']['maximum']==1
assert fixtures[2]['extrema']['Eenv']['minimum']==0 and fixtures[2]['extrema']['Eenv']['maximum']==Q(15,8)
assert fixtures[2]['extrema']['Etotal']['minimum']==Q(3,4) and fixtures[2]['extrema']['Etotal']['maximum']==Q(19,8)
out={'scope':'Only three coordinator-frozen finite identity diagnostics, tau_toy1,R_toy10,kappa7/8. No original tau, raw admission, actual owners, actual receiver pieces or historical saturation is claimed. Optimizing the dual face is not a valuable whole-parent selection and does not pay V.','python':sys.version,'platform':platform.platform(),'numpy_version':np.__version__,'scipy_version':scipy.__version__,'command':[sys.executable,str(Path(__file__).resolve())],'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'toy_parameters':{'tau':str(tau),'R':str(R),'kappa':str(kap),'all_g_large_zero':True},'dual_face':'y>=0,A^T y>=d,sum y=P0 for ALL parents, including q0; y are positive-cell masses','envelope':'Eenv=sum_i qi(mi-F)1Ai, Etotal=Eenv+F/8 under the frozen all-small-radius condition','identity':'B=kappa V+integral h Etotal; every signed term uses the same h','arithmetic':'Complete rational active-basis vertex enumeration and Fraction geometry/identities; HiGHS min/max checks only secondary','fixtures':serial(fixtures),'summary':{'fixture_count':len(fixtures),'complete_basis_systems':sum(f['enumeration']['basis_systems_exhaustively_considered'] for f in fixtures),'all_vertex_identities_and_parent_constraints_passed':True,'all_min_max_HiGHS_crosschecks_passed':True,'dual_face_error_changes_only_in_third_fixture':True},'elapsed_seconds':time.time()-start,'errors':[]}
(ROOT/'RESULT.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'summary':out['summary'],'elapsed_seconds':out['elapsed_seconds'],'source_sha256':out['script_sha256'],'RESULT_sha256':hashlib.sha256((ROOT/'RESULT.json').read_bytes()).hexdigest(),'extrema':[serial({'name':f['name'],'enumeration':f['enumeration'],'Eenv':f['extrema']['Eenv'],'Etotal':f['extrema']['Etotal']}) for f in fixtures]},indent=2))
