# R691 frozen optimal-dual-face identity diagnostics

## Outcome

Optimizing the original packing-dual optimal face changes the envelope error in the third frozen interval example and does not change it in either square example.

| frozen case | P0 | min/max integral h Eenv | min/max integral h Etotal |
|---|---:|---|---|
| shared three-square baseline | 8 | 0,0 | 1,1 |
| cheap four-square baseline | 8 | 0,0 | 1,1 |
| four-interval variable face | 6 | 0,15/8 | 3/4,19/8 |

The third example reduces the total error by13/8 while keeping the same original P0. The signed B changes from47/8 to17/4. This is an identity/dual-choice diagnostic. It does not pay a real remaining receiver volume, construct valuable whole-parent selections, or establish an original-history budget.

Only the coordinator's final three fixtures were run. The earlier four-case suggestion was not executed.

## Frozen normalization and original dual constraints

All examples use the explicitly abstract normalization

`tau_toy=1`, `R_toy=10`, `kappa=7/8`, `q=u`, `mu_i=d_i q_i`.

The receiver coefficients w are the frozen algebraic weights below. Their volume Vtoy=sum_i di wi is not asserted to be the volume of disjoint actual receiver pieces. There is no raw admission, original tau=16384sqrt(n), tiny owner constraint or historical saturation realization.

All positive arrangement cells are constructed exactly. Cells sharing an incidence mask are merged, and y_m denotes the total Lebesgue dual mass in that mask. The full original packing-dual optimal face is

`y>=0`, `A^T y>=d`, `sum_m y_m=P0`.

All original parents, including q=0 labels, remain constraints. An exact packing primal of value P0 is checked on every cell; each enumerated feasible dual has total P0. Together these certify that it is indeed the original optimal face. No support restriction to q-tight cells is imposed.

A mass y_m is realized by the density y_m/|mask-region| on that positive-volume region. No boundary Dirac mass is used. Incidence merging preserves both parent integrals and the objectives because their coefficients are constant on each mask.

## Same-h signed identity

With F=sum_j w_j 1_Aj, every frozen positive source is small relative to every positive target at Rtoy=10. Consequently all large-source fields vanish and every Di equals F. Define

`mi=esssup_(Ai) F`,

`Eenv=sum_i qi(mi−F)1_Ai`,

`Etotal=Eenv+F/8`.

Both fields are checked nonnegative on every positive cell. For one dual h define `ri=integral_Ai h−di`. The complete signed expression is

`B=sum_i mu_i mi + sum_i qi mi ri`

`  +integral h F(1−g) −(7/8)sum_j wj rj`.

Every term uses this same h, and all favorable target slack is retained. Direct exact evaluation verifies

`B=(7/8)Vtoy+integral h Etotal`

at every vertex. RESULT.json records all four signed terms, every parent integral/slack and the identity check. The pointwise expansion supplies the same affine identity throughout the face; no signed term is optimized separately.

## Exact finite optimization certificate

The three merged polytopes have5,6,7 nonnegative variables. For each, the script enumerates every choice of m−1 active inequalities together with `sum y=P0`, solves the square system by Fraction Gaussian elimination, rejects singular/infeasible systems, and deduplicates feasible vertices. There are respectively70,252,462 systems, totaling784; the numbers of distinct feasible vertices are3,4,2.

The polytopes are compact because y>=0 and their total mass is fixed. Every vertex has a full-rank active system among the enumerated choices. Therefore evaluating both linear objectives at all retained vertices proves their global minima and maxima on these finite faces. This is the exact certificate; the twelve HiGHS min/max LPs are only secondary floating checks and all agree.

## Case1: shared three-square baseline

Radius-one squares are centered at `(0,0),(-3/2,0),(3/2,0)`, with

`u=(1/8,7/8,7/8)`, `w=(0,1,1)`.

The original packing `(0,1,1)` has value8. Here Vtoy=8. The target field F itself is an optimal packing field, so every optimal dual is supported where F=1 by complementary slackness. On that support Eenv=0 and Etotal=1/8. Thus every dual on the face has envelope integral0 and total integral1. The signed bill is always8, with `(7/8)Vtoy=7`.

## Case2: cheap four-square baseline

The squares are

`A=Q((0,0),1)`, `B=Q((-2,0),1/4)`,

`L=Q((-3/2,0),1)`, `R=Q((3/2,0),1)`.

Use `u=(1,15/16,0,0)`, `w=(0,0,1,1)`. The original packing `(0,0,1,1)` has value8, and Vtoy=8. Again F is itself optimal, so every dual-face point has envelope integral0, total integral1 and signed B=8. Choosing the dual differently cannot reduce these objective values.

## Case3: a genuinely variable optimal face

The intervals are

`A=[-1,1]`, `B=[-6,-2]`,

`L=[-5/2,-1/2]`, `R=[1/2,5/2]`,

with `u=(1,15/16,0,0)`, `w=(0,0,1,1)` and volumes `(2,4,2,2)`. The original packing B+R has value6, so P0=6, while Vtoy=4.

Every dual-face point has mass2 on A intersect R and mass4 on B. The L constraint requires mass at least2 on B intersect L. Write v for this latter mass; the exact face is parameterized by `2<=v<=4`. Remaining B mass4−v lies on B-only. Its objective values are

`integral h Eenv=(15/16)(4−v)`,

`integral h Etotal=4−(13/16)v`.

The two enumerated vertices are v=2 and v=4. At the minimizing vertex, h has mass4 on(-5/2,-2) and mass2 on(1/2,1), realizable as densities8 and4 there. Parent integrals are `(2,4,4,2)`, so all four original constraints hold and total mass is6. It gives

`integral h Eenv=0`, `integral h Etotal=3/4`, `B=17/4`.

At the other vertex, mass2 is on B-only, mass2 on B intersect L and mass2 on A intersect R. It gives

`integral h Eenv=15/8`, `integral h Etotal=19/8`, `B=47/8`.

Both have `(7/8)Vtoy=7/2`. The optimizing dual necessarily carries B mass where g=15/16, so it is not obtained by forcing h onto q-tight cells. The error reduction is a real optimal-face choice effect, but a small error in this toy identity is not a payment of an actual Vdagger.

## Reproducibility and stopping

Executed command:

```text
/Users/zzh/.local/share/math-research-tools/venv/bin/python /Volumes/data/CodexTemp/centered-cube-r691-20261116/NUMERIC.py
```

RESULT.json retains boxes/radii, all positive cells and exact masses, merged masks, every rational vertex and an active basis, original packing primals, all parent slack checks, signed terms, extrema and HiGHS outcomes. Python/platform/NumPy/SciPy versions and the actual command are recorded. Geometry, enumeration and identities are exact Fraction arithmetic; SciPy1.18.1/HiGHS supplies no proof by itself.

The run body completed in about0.073seconds. All original-parent constraints, all vertex identities and all twelve min/max checks passed; errors are empty and the process exited with code zero. Source SHA-256: `b1fac94eaf06223ac892fdd03a11a98453d6461f2716ef933fe7188d0048294c`. Result SHA-256: `0d9442847fd0a60833b7c2535e32acd34fc3885ea7ae12999ecb04f617b7e25d`.

Only the three owned R691 files were written. No additional fixture, broad scan, actual-history claim, MATLAB, package installation, Git, PDF or agent was used. Computation is stopped.
