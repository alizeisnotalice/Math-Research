# R474 FINAL PASS（限定 winner 保留、逆矩合法性及外部来源分拆）

先独立预审再读作者稿。通过所列一般恒等式、选择/费用比较及有限复现；未证明同一 winner 计划的实际捕获缺陷可吸收，未完成原全流根阶预算。原母账、所有旧门及未付费用保留；两条不同概率扩展不自动拼接信用。

1. **同输入最大带选择。** (t(A)=dPi_A/dsigmain[0,S]) 是原完整接受边缘，非代表父的新 history。完整有限质量带、最小 max tie-break、零 (u) 行弃权均可测。原附源正限制质量恰为 (T=\int_H\max_j u_j,d\mu)，故 (R_{\rm hi}/N\le T\le R_{\rm hi})。其 subMarkov 代表核对 (sigma) 可逆，只连接同带；实际 (ell(A,y,z)) 未被 (t(A)) 替换。平方权价精确为 (\mu(H\cap\{u>0\}))，而非 (N\mu(H))，故 (C_*\le4rS\mu(H))。参数 (r,S)、全带数和两端点均保留；(u=0) 的原 lift 零质量不产生保留费用。

2. **恢复与吸收方向。** 左侧是保留量 (T)，准确为交叉项加有符号差，取正差得 (T\le C_*+E_*)。这不是旧双来源的共同捕获恢复保证。条件 (6) 若另证，必须先除 (1-\eta)，再用 (R_{\rm hi}\le NT)；主稿(7)常数和 (N) 一次费用正确。(d\asymp\sqrt n)、(N=O_r(\sqrt n)) 只在此条件成立时给目标阶。小阈值与大 (d) 的代价取舍保留；极端恢复上界不能当作原质量分支付款或擅添 (p_d)。实际 (E_*) 仍未获所需几何界。

3. **软逆矩。** 同一实际 (Pi) 支配与共同父 Tonelli 严格给 (p_d>0\Rightarrow F_d>0)，(Pi)-a.e.；零商约定合法，不需假定 selector 连续或 history product AC。来源 Cauchy 的 (m_A^{-2}) 系数与原密度结合恰产生 (K_{4,\ell}/K_2)，接受权留在实际原父。(K_{4,\ell}\le SK_2/m_-^2) 给固定场有限逆矩，而非维度一致价格；Young 后的 (rS^2W^3/(\varepsilon m_-^2)) 不能隐入 root 常数。新比较与 winner 路线没有交叉挪用未证前提。

4. **独立外部来源分配。** 真实质量权 (t^{-1}\min(m,t)/\max(m,t)) 非增且积分为2，含质量原子的 CDF 比较正确。原记录后抽 (x,B,t\sim\pi_{\rm larger}) 得真实正分拆 (R=R_{\rm low}+R_{\rm fall}+R_{\rm ext})，费用 (SdW)、(2rS\mu(H)\le2rSW) 合法。精确外部列交换原父两方向后确含 (omega(A)+\omega(B))、(m_Am_B^2) 分母；同质量全序及连续中心对角无费用。现有列上界 (2SD(t)) 仍未支付跨父重复，人工来源和代表父未继承原门。

5. **数值范围。** 变量边长高占用场的完整质量 (m=M+R)、分段 (D)、共同来源对支持质量及 (K_4/K_2) 解析夹界正确，三例均有严格 (D_{\rm core}>1.5)、外部占用低于阈值。逆矩区间不是求积估值。它们使用静态 (Pi=sigmapi_A^2)，并未认证原 high-Z、路径或 history；不由有限比值推出一般吸收/逆矩阶数。main、geometry 和 complement 的有限算例也按各自真实连续块或纯 incidence 代数范围列明。

## 独立隔离复现

指定本机 Python；目录 `/var/folders/lq/2c4qbz2n0354_tnttkv_qsz00000gn/T/r474_audit_goclrnik`。提取 main/geometry/complement 内嵌代码并运行 numeric.py，231、153、175、96项断言通过，四份 stdout 与冻结 replay 逐字节一致。numeric JSON 仅删除 `compute_index.seconds` 后完全一致；规范化 SHA256 为 `37ebe6c7a3d2c1dd38ba1f1276dab6e74c0995f8d0b4c3c19fc82d16cd9bdd2c`。PRE 的13/45项辅助代数不计入归档统计，不扩研究范围。

## 冻结输入 SHA256

- `r474_main.md`: `651df321905ca5c7db7cf28881fd61197c0bd3e1189c2b06d2d51619912838b4`
- `r474_geometry.md`: `ab67de6c939067a85a9858af98231eb30f31a1c2f88a6f8e02d71c7cbca49da8`
- `r474_complement.md`: `8c33c035e4d2267a5ea412832eb78792e9c6bec60491776a005f4b7f9bab8851`
- `r474_numeric.md`: `519ba1fd431cef1854d86b5861bf417915e241cce9f48966891f2017015b12d8`
- `r474_numeric.py`: `4f716b839f5309ce3a50fb44024a96b1f24641931d9e51b0aaf8e25f4136945e`
- `r474_numeric.json`: `9ab5c5b8c4d37945f0caa5662fbc3e0644a641eac44537f59e38d0c71b99aab5`
- `r474_replay.json`: `a7df9d8d70bdc3f45ce13ef370dd71afbc9e415c7f089a18b4b7e429c0be89cd`
