# 第474轮：原接受流的共同来源选带与高占用软恢复

## 结论及研究决策

本轮证明一个作用于完整原接受流的选择引理：在高真实占用来源上，每个来源只选择一个质量带，选择依据为原接受流的真实父边缘。若完整质量区间分成 \(N\) 带，则保留的原流质量至少为高占用原流的 \(1/N\)，而同带代表计划的交叉项仍只收一次来源价 \(4rSW\)。取带宽 \(\sqrt n\)，\(N=O_r(\sqrt n)\)，所有代表父自动进入质量可比范围。

这证明了**选择阶段**的保留量，不是旧双来源被代表父捕获的下界。选择后的实际捕获亏损尚未获得可吸收预算，一般上界仍未闭合。与此同时，另一个独立的外部来源分配给出常数 \(W\) 回落损失；不能把两条不同扩展的费用与信用无条件拼接。

本轮真实变量边长的连续高占用模型已运行，区别于此前低占用两父模型。它支持继续研究高占用与来源重叠的联合几何，不外推一般维数或原历史。

## 1. 冻结原输入与费用

\(\mu=f\,dx\)、\(f\ge0\)、\(W=\mu(\mathbb R^n)<\infty\)。实际中心 \(A\in E\)，\(a\le R_A\le b\le2a\)，\(m_A=\mu(Q_A)=q_AR_A^n\)，\(q\le q_A\le\lambda\)、\(r=\lambda/q\)、\(\sigma=q_A dA\)、\(X=\sigma(E)\)，\(\pi_A=c_A\mu/m_A\)。全部来源用完整 \(f\) 计算。原接受测度的准确投影为
\[
 d\Pi(A,y,z)=\ell(A,y,z)\sigma(dA)\pi_A(dy)\pi_A(dz),\quad
 \ell=\sum_{i,e}a_i^e(A,y)b_i(z)\theta_i^e(A,y,z),\quad0\le\ell\le S.
\]
全部原阶段、时钟、严格路径、初始和接受门保存在原权中；\(R=|\Pi|\)。令
\[
 t(A)=\int\ell(A,y,z)\pi_A(dy)\pi_A(dz)\in[0,S],\quad
 D(x)=\int\frac{c_A(x)}{m_A}\sigma(dA).
\]
于是 \(\Pi_A=t(A)\sigma\)、\(\int Dd\mu=X\)，\(D\le A_n=1+n\log(b/a)\)。\(D\) 不同于原阶段占用 \(D_i\)。对 \(d>0\) 置 \(H=\{x:D(x)>d\}\)，\(p_d(A)=\pi_A(H)\)，\(R_{\rm hi}=\int p_d d\Pi\)。原记录后独立附 \(x\sim\pi_A\)，只作分析分拆，则
\[
 R-R_{\rm hi}\le SdW,\qquad\mu(H)\le\min(W,X/d). \tag{1}
\]
这是一条正分数费用，不是对原父的确定性事件，也不刷新任何旧来源或历史。

以下只用已核第472轮真实阶段加权行界和第473轮分数分组交叉界。前者由真实质量 CDF \(|\{B:x\in Q_B,m_B\le u\}|\le u/q\) 给出，不由任意来源密度帽得出。所有费用在同一场内计算。

## 2. 共同来源最大带选择引理

把完整区间 \([qa^n,\lambda b^n]\) 分成不交可测质量带 \(J_1,\ldots,J_N\)，每带对数宽至多 \(L\)，两端点归属明确。可取
\[
 N\le1+\frac{\log r+n\log(b/a)}L,
\]
零长度区间用一带。所有原父均被覆盖，不删任何极端质量补集。

对每个来源定义原接受列
\[
 u_j(x)=\int_{m_A\in J_j}\frac{t(A)c_A(x)}{m_A}\sigma(dA),\qquad
 u(x)=\sum_j u_j(x).
\]
令 \(j_*(x)\) 为使 \(u_j(x)\) 最大的最小下标。有限个可测函数的此选择可测；\(u=0\) 处不保留任何记录。以原 \(\Pi\) 附源 \(x\sim\pi_A\)，仅保留
\[
 x\in H,\quad u(x)>0,\quad m_A\in J_{j_*(x)}.
\]
保留量准确为
\[
 T=\int_H\max_j u_j(x)d\mu(x),\qquad
 \boxed{\ R_{\rm hi}/N\le T\le R_{\rm hi}.\ } \tag{2}
\]
证明只用 \(\sum_j u_j=u\) 及 \(R_{\rm hi}=\int_Hu\,d\mu\)，没有把父平均接受权 \(t\) 移给代表父。

该选择由完整原输入及接受测度的边缘定义。它是在固定原测度上进行事后的正分拆，不是构造一个声称对原时钟可预测的新控制算法；本证明不调用可选停止、鞅条件化或新的历史资格。原记录的具体 \(\ell(A,y,z)\) 在分拆后仍保留，不能用 \(t(A)\) 替代其双来源分布。

## 3. 同带代表计划及一次来源价

定义未标记的真实来源占用
\[
 D_j(x)=\int_{m_B\in J_j}\frac{c_B(x)}{m_B}\sigma(dB).
\]
若 \(u_j(x)>0\)，则 \(D_j(x)>0\)，因为 \(t\le S\)。对保留记录，在同带按
\[
 R_{x,j}(dB)=\frac{1_{m_B\in J_j}c_B(x)\sigma(dB)}{m_BD_j(x)}
\]
取实际代表父。所有原标记仍留在 \(A\)。记该计划对 \(A\) 的次概率核为
\[
 P_*(A,dB)=\int\pi_A(dx)1_H(x)1_{u(x)>0}1_{m_A\in J_{j_*(x)}}
 R_{x,j_*(x)}(dB),\quad \alpha(A)=P_*1(A)\le p_d(A).
\]
原保留量 \(T=\int\alpha(A)d\Pi\)。该核可写成第473轮分数组形式，其指标 \((j,x)\) 权为
\[
 w_{j,x}(A)=1_H(x)1_{u(x)>0}1_{j=j_*(x)}
 1_{m_A\in J_j}\frac{c_A(x)}{m_A}.
\]
虽然行和可小于1，交叉界证明只用其对称平方权，不要求行和为1。\(\sigma(dA)P_*(A,dB)\) 对称，且 \(P_*\) 只连接同带父。

设 \(e_A(y,z)=c_A(y)c_A(z)/m_A\)。保持原父接受权，定义
\[
 C_* =\int\sigma(dA)P_*(A,dB)\int\ell(A,y,z)e_Ae_B\,d\mu^2,
\]
\[
 E_* =\int\sigma(dA)P_*(A,dB)\int\ell(A,y,z)(e_A^2-e_Ae_B)_+d\mu^2.
\]
于是准确有符号分解及正上界为
\[
 T=C_*+\int\sigma P_*\int\ell(e_A^2-e_Ae_B)d\mu^2,
 \qquad T\le C_*+E_*. \tag{3}
\]
第473轮平方权来源价在本计划中准确消去：
\[
 \mathcal B_*=
 \sum_j\int\frac{\int w_{j,x}(A)^2m_A\sigma(dA)}
                       {\int w_{j,x}(A)\sigma(dA)}d\mu(x)
 =\mu(H\cap\{u>0\})\le\mu(H).
\]
零分母项置零。这里对每个 \(x\) 只选择一个组，故没有 \(N\) 倍来源费。因此
\[
 \boxed{C_*\le4rS\mu(H)\le4rSW.} \tag{4}
\]
若 \(L=\sqrt n\)，每个保留比较满足 \(e^{-\sqrt n}\le m_B/m_A\le e^{\sqrt n}\)，并且 \(N=O_r(\sqrt n)\)；正是完整质量可比范围的原流选择，未赋予 \(B\) 原历史。

由 (1)–(4) 得到无条件、但尚含真实损失的比较
\[
 R\le SdW+N(C_*+E_*). \tag{5}
\]
这里因子 \(N\) 只在恢复原流时出现一次，不能既把交叉费当 \(NW\) 又重复收这个因子。

## 4. 准确剩余目标与吸收方向

本轮没有证明 \(E_*\) 小。一个足够的、作用于同一选择计划的目标为
\[
 E_*\le\eta T+\frac\varepsilon N X+C_\varepsilon W,\qquad0\le\eta<1. \tag{6}
\]
必须先由 (3) 得
\((1-\eta)T\le C_*+\varepsilon X/N+C_\varepsilon W\)，再用 \(R_{\rm hi}\le NT\)。正确回代为
\[
 R\le SdW+\frac\varepsilon{1-\eta}X+
 \frac N{1-\eta}(4rS\mu(H)+C_\varepsilon W). \tag{7}
\]
取 \(d\asymp\sqrt n\)、\(L=\sqrt n\) 才得到所需阶数。不能从 \(R_{\rm hi}\le NT\) 错推 \(N\eta T\le\eta R_{\rm hi}\)。\(E_*\) 的定义包含原 \(y,z\)、真实质量分母和原接受权；(2) 的保留保证不能替代 (6) 的共同捕获几何。

## 5. 两个互补结果及其价格

**软逆矩。** 未选带的原共同来源计划，在高 \(D\) 上恢复函数为
\[
 F_d(A,y,z)=\int_{Q_A\cap H}\frac{K_2(x,y,z)}{D(x)}d\mu(x),\quad
 K_j(x,y,z)=\int\frac{c_B(x)c_B(y)c_B(z)}{m_B^j}\sigma(dB).
\]
辅助证明严格排除 \(\Pi\{p_d>0,F_d=0\}\) 的正质量。令
\(K_{4,\ell}=\int c_A(x)c_A(y)c_A(z)\ell(A,y,z)m_A^{-4}d\sigma(A)\)，则
\[
 I_d:=\int p_d^2/F_d\,d\Pi
 \le\int_H D(x)\frac{K_{4,\ell}(x,y,z)}{K_2(x,y,z)}d\mu^3
 \le\frac{SW^2X}{(qa^n)^2}. \tag{8}
\]
零商置零，逆矩在固定场上有限。由 \(\int F_d d\Pi\le4rSW\) 作 Cauchy–Schwarz 合法，但现有粗价只给
\[
 R\le SdW+\varepsilon X+\frac{rS^2W^3}{\varepsilon(qa^n)^2},
\]
并非根阶。若能把实际 \(I_d\) 控为 \(C\sqrt n\log^A(n+2)X\)，才可得到目标。此为独立备选桥，不与 (6) 未证条件混用。

**外部来源分配。** 几何附件从同一原记录另附 \(x\sim\pi_A\)、\(B\sim R_x\)，再从 \(A,B\) 中质量较大者的完整来源分布抽 \(t\)。真实 CDF 证明
\[
 \mathbb E_{B\sim R_x}\frac{I_{AB}}{\max(m_A,m_B)}\le2r/D(x).
\]
当 \(x\in H\)，新来源落回较小父的总损失至多 \(2rS\mu(H)\le2rSW\)，而非只能付 \((2r/d)R\)。因此有精确正分拆
\[
 R=R_{\rm low}+R_{\rm fall}+R_{\rm ext},\quad
 R_{\rm low}\le SdW,\quad R_{\rm fall}\le2rSW. \tag{9}
\]
外部来源的真实列包含 \(t(A)+t(B)\)、高占用交集权及 \(1-c_A(t)\)，完整公式在附件。其现有上界仍仅 \(2SD(t)\)，积分回到 \(2SX\)。外部来源的跨父重复未付；不能仅因每次抽样落到外部就把总量算成一次 \(W\)。该扩展和 (2) 的选带扩展不同，当前没有证明可将它们无损同时应用。

## 6. 原参数权衡及完整总账

第473轮极端代表恢复量上界为 \(\lambda hR/d+2rR/(dK)\)，其中 \(K=e^{\sqrt n}\)、\(h=s/(\varepsilon_0q)\)、\(s=1+\sqrt n\)。如果另想让它低于 \(\tau R\)，需要相应增大 \(d\)；\(\tau\asymp1/\sqrt n\) 时 \(d\asymp n\) 会使低占用费变为线性。不能同时拿小阈值恢复和免费极端删除。本轮选带引理通过真正正分拆直接限制代表质量，而不使用这个错误组合。

(7) 的吸收仍以 (6) 为待证前提。原宽距离、低pe、初始、跳跃删除、未来被删来源、极小尺度比及全尺度拼接的旧费用不变；第458轮系数 \(S\zeta+2S\varepsilon_0/s+2S\delta_{\rm round}\) 及完整母账乘数保持，尚未核成全局总吸收。未以新原子流或换序接口宣称闭合。

## 7. 实际本机计算与决策作用

本轮指定 Python 环境实跑四组自含验证，分别保留范围：

- 主代理：231项 Fraction，1个实际连续三父场、3个静态父接受权、3个辅助阈值。核来源最大带的保留量、同带支持、一次来源价及保持原父标记的交叉分解；不认证原历史。
- 几何附件：153项 Fraction，实际连续块上核外部来源正分拆、精确来源列与常数 \(W\) 回落费用；辅助参数不替代原门。
- 互补附件：175项有限 incidence 代数，核零域、逆矩换序和粗有限上界；不把任意矩阵称作实际连续原场。
- 数值附件：3个真实连续变量边长模型，96项 Fraction/SymPy/200-bit Arb 检查；\(D_{\rm core}>1.5\)、\(r<2\) 均认证。高集中例 \(X/W=1.37639974\)、\(R_{\rm hi}/X=0.93644897\)，实际逆矩 \(I_d/X\) 严格包围为 \([1.1260509829,1.2624239394]\)。它使用静态 \(\Pi=\sigma\pi_A^2\)，未认证原 high-Z 或历史，也不外推一般阶数。

真实高占用模型确认变量尺度和来源集中可以同时出现，且软恢复逆矩可用解析后验夹界认证，不必猜测数值求积误差。它支持继续检验实际来源重叠机制。三个有限例不能证明 (6) 或一般逆矩界。

沿64项工具 L03 精确证书和既有来源/误差账流程，所有浮点展示与严格区间分开。没有调用新的未核文献定理，也未编译PDF。只有实际运行脚本及最终必要证据随包保存。

主代理自含复现代码：

```python
from fractions import Fraction as F
checks=0
def ck(p):
 global checks
 assert p
 checks+=1
mu=list(map(F,(1,2,8)))
centers=list(map(F,(0,F(-2,5),F(2,5))))
source=[F(-4,5),F(0),F(4,5)]
sides=[F(2),F(1),F(1)];vol=F(1,100);srcvol=F(1,50)
caps=[]
for A in range(3):
 row=[]
 for x in range(3):
  far=abs(centers[A]-source[x])+(vol+srcvol)/2
  near=abs(centers[A]-source[x])-(vol+srcvol)/2
  row.append(int(far<sides[A]/2))
  ck(row[-1] or near>sides[A]/2)
 caps.append(row)
ck(caps==[[1,1,1],[1,1,0],[0,1,1]])
m=[sum(mu[x]*caps[A][x] for x in range(3)) for A in range(3)]
q=[m[A]/sides[A] for A in range(3)];sig=[v*vol for v in q]
r=max(q)/min(q);D=[sum(sig[A]*caps[A][x]/m[A] for A in range(3)) for x in range(3)]
# Three complete log2 bins covering [q_min*a, lambda*b]=[3,20].
edges=[F(3),F(6),F(12),F(24)];N=3
bins=[next(j for j in range(N) if edges[j]<=mass<edges[j+1]) for mass in m]
for A in range(3):
 for B in range(3):
  if bins[A]==bins[B]:ck(max(m[A],m[B])<2*min(m[A],m[B]))
summary=[]
for t in [(F(1),F(1,4),F(0)),(F(1,16),F(1),F(1,4)),(F(0),F(0),F(0))]:
 for d in [min(D)/2,min(D),max(D)]:
  high=[Dx>d for Dx in D]
  aj=[[sum(sig[A]*t[A]*caps[A][x]/m[A] for A in range(3) if bins[A]==j)
       for j in range(N)] for x in range(3)]
  win=[max(range(N),key=lambda j:aj[x][j]) for x in range(3)]
  Dj=[[sum(sig[A]*caps[A][x]/m[A] for A in range(3) if bins[A]==j)
       for j in range(N)] for x in range(3)]
  Rhi=sum(mu[x]*high[x]*sum(aj[x]) for x in range(3))
  T=sum(mu[x]*high[x]*aj[x][win[x]] for x in range(3))
  ck(T*N>=Rhi)
  K=[[sum(mu[x]*high[x]*(bins[A]==win[x])*(bins[B]==win[x])
       *caps[A][x]*caps[B][x]*sig[B]/(m[A]*m[B]*Dj[x][win[x]])
       for x in range(3) if Dj[x][win[x]]>0) for B in range(3)] for A in range(3)]
  alpha=[sum(K[A]) for A in range(3)]
  ck(sum(sig[A]*t[A]*alpha[A] for A in range(3))==T)
  for A in range(3):
   ck(0<=alpha[A]<=sum(mu[x]*high[x]*caps[A][x]/m[A] for x in range(3)))
   for B in range(3):
    ck(sig[A]*K[A][B]==sig[B]*K[B][A])
    if bins[A]!=bins[B]:ck(K[A][B]==0)
  Cross=F(0);Def=F(0);Signed=F(0)
  for A in range(3):
   for B in range(3):
    for y in range(3):
     for z in range(3):
      ea=F(caps[A][y]*caps[A][z])/m[A]
      eb=F(caps[B][y]*caps[B][z])/m[B]
      weight=sig[A]*K[A][B]*mu[y]*mu[z]*t[A]
      Cross+=weight*ea*eb
      Signed+=weight*(ea*ea-ea*eb)
      Def+=weight*max(F(0),ea*ea-ea*eb)
  ck(Cross+Signed==T);ck(T<=Cross+Def)
  cost=sum(mu[x]*high[x]*(Dj[x][win[x]]>0) for x in range(3))
  WH=sum(mu[x]*high[x] for x in range(3))
  ck(cost<=WH);ck(Cross<=4*r*cost)
  # The original parent mark t[A] was never transferred to B.
  R=sum(sig[A]*t[A] for A in range(3));Rlow=R-Rhi
  ck(Rlow<=d*sum(mu));ck(R<=d*sum(mu)+N*(Cross+Def))
  summary.append((T,Rhi,Cross,Def,cost))
print('PASS',checks,'Fraction source-winner retention/cross checks; 1 continuous three-parent field, 3 static marks, 3 thresholds; no original history claim')
print('nonzero retained records',sum(T>0 for T,_,_,_,_ in summary))

```
