# R474：高真实占用流的外部来源分配及常数 W 回落损失

## 1. 准确输入及输出

沿冻结合同，\(\mu=f\,dx\)、\(W=\mu(\mathbb R^n)\)、\(m_A=\mu(Q_A)=q_AR_A^n\)、\(q\le q_A\le\lambda\)、\(r=\lambda/q\)、\(\sigma(dA)=q_A\,dA\)。完整原接受流记 \(\Pi\)，其全部 stage、来源 \(y,z\)、时钟和历史保留，\(R=|\Pi|\)，且
\[
 \Pi_{A,y,z}\le S\sigma(dA)\pi_A(dy)\pi_A(dz),\qquad
 D(x)=\int\frac{c_A(x)}{m_A}\,\sigma(dA),\quad
 R_x(dB)=\frac{c_B(x)\sigma(dB)}{m_BD(x)}.
\tag{1}
\]
在 \(D>0\) 上 \(R_x\) 是概率核。零占用不承载所用来源边缘。

**本附件证明的整体分拆。** 对任意 \(d>0\)，可仅在原记录后附真实概率核，将原 \(\Pi\) 分为三个正分数：低人工来源占用、回落、外部来源。前两者的总费用满足
\[
 R_{\rm low}(d)\le SdW,\qquad R_{\rm fall}(d)\le2rSW;
 \qquad R=R_{\rm low}+R_{\rm fall}+R_{\rm ext}.
\tag{2}
\]
因此 \(d=c(1+\sqrt n)\) 给前两项 \(S[c(1+\sqrt n)+2r]W\)。这是一条可选的自洽分拆；不与其他路线对同一原流的收费无条件相加。外部项没有得到根阶预算。

## 2. 固定来源的真实质量积分

对固定来源 \(x\) 和任意 \(m>0\)，真实中心 CDF 满足
\(F_x(t)=|\{B:x\in Q_B,m_B\le t\}|\le t/q\)。函数
\[
 w_m(t)=\frac1t\frac{\min(m,t)}{\max(m,t)}
 =\begin{cases}1/m,&t\le m,\\m/t^2,&t>m\end{cases}
\]
非增，且 \(\int_0^\infty w_m(t)dt=2\)。由 Stieltjes 分部积分（或非负层饼，包含质量原子）得到
\[
 \int c_B(x)w_m(m_B)\,dB\le2/q.
\tag{3}
\]
因此每个固定 \(A,x\) 满足
\[
 \int R_x(dB)\frac{I_{AB}}{\max(m_A,m_B)}
 \le\int R_x(dB)\frac{\min(m_A,m_B)}{\max(m_A,m_B)}
 \le\frac{2r}{D(x)}.
\tag{4}
\]
这里 \(I_{AB}=\mu(Q_A\cap Q_B)\)。式 (4) 利用了真实匹配的中心容量，不假设来源密度上限。它是平均共同捕获的上界，不是原恢复量的下界。

## 3. 原标签不变的具体分配

在每条原记录 \(\xi\) 之后，独立抽 \(x\sim\pi_A\)。\(D(x)\le d\) 的部分归低占用。否则按 (1) 抽实际比较父 \(B\)。令 \(L\) 为 \(A,B\) 中质量较大者，\(J\) 为另一者；质量相等时以一个固定可测全序破同。再抽 \(t\sim\pi_L\)。若 \(t\in Q_J\)，归回落；否则归外部。

这不改变原父、\(y,z\) 或任何原接受标记。新 \(B,x,t\) 只有分析标签；特别是 \(B\) 没有获得原历史，\(t\) 没有被宣布满足原 high-rank 或 low-common。

低占用项由原静态支配和 Tonelli 给出
\[
 R_{\rm low}\le S\int\sigma(dA)\pi_A\{D\le d\}
 =S\int_{D\le d}D(x)\,d\mu(x)\le SdW.
\]
固定 \(A,B\)，回落概率正是 \(I_{AB}/\max(m_A,m_B)\)。由 (4)，
\[
 \begin{aligned}
 R_{\rm fall}
 &\le2r\int\Pi(d\xi)\int\pi_A(dx)\frac{1_{D(x)>d}}{D(x)}\\
 &\le2rS\int\sigma(dA)\int\pi_A(dx)
          \frac{1_{D(x)>d}}{D(x)}
 =2rS\mu\{D>d\}\le2rSW.
 \end{aligned}
\tag{5}
\]
最后一个等号使用同一个全场 \(D\)，不逐父重新选择。所有新增核都是概率核，故 (2) 为精确正分拆；投影回 \(\xi\) 后，每部分仍为原 \(\Pi\) 的正分数。没有使用旧负平方信用。

## 4. 外部来源的真实列与唯一未付处

令 \(\omega(A)=d\Pi_A/d\sigma(A)\in[0,S]\)，以及
\[
 H_d(A,B)=\int_{Q_A\cap Q_B}\frac{1_{D(x)>d}}{D(x)}\,d\mu(x).
\]
用质量加固定全序记 \(A\prec B\)。实际中心测度非原子，故对角无费用。保留完整接受权后，外部 \(t\)-边缘相对 \(\mu\) 的密度**精确**为
\[
 G_d^{\rm act}(t)=\int_{A\prec B}
 \frac{[\omega(A)+\omega(B)]H_d(A,B)}{m_Am_B^2}
 c_B(t)(1-c_A(t))\,\sigma(dA)\sigma(dB).
\tag{6}
\]
这是同一原记录扩展的投影恒等式，\(\omega(B)\) 来自交换两积分变量后的另一批原记录，不是赋予比较父历史。

仅使用 \(\omega\le S\) 时，可将 (6) 上放为
\[
 G_d^{\rm act}(t)\le2S\int\frac{c_B(t)}{m_B}\sigma(dB)
 \int\pi_B(dx)\frac{1_{D(x)>d}}{D(x)}
 [D_{\le m_B}(x)-D_{\le m_B}(x,t)]\le2S D(t),
\tag{7}
\]
其中 \(D_{\le m}(x,t)=\int_{m_A\le m}c_A(x)c_A(t)\sigma(dA)/m_A\)，单源版本省去 \(c_A(t)\)。相同质量的边界只在此上界中扩大。

式 (7) 表明外部质量在许多真实父之间仍可重复，现有结算仅给 \(2SX\)。本次唯一未证几何步骤是：对 (6) 中同一接受权 \(\omega(A)+\omega(B)\)、高占用交集权 \(H_d\) 及真实外部因子 \(1-c_A(t)\)，取得可求和的跨父列预算或收缩。若删除这些联系而只用 \(D\le A_n\)，即回到 \(O(nW)\)。本附件不把 (6) 重新命名为已付项，也不假设新来源继承原 low-common 门；完整 root 目标仍未闭合。

## 5. 自含有限精确核查

下列三个非均匀来源 packet 的中心为 \(-4/5,0,4/5\)，长度 \(1/50\)；实际接收中心块中心为 \(0,-2/5,2/5\)，长度 \(1/100\)，cube 边长 \(2,1,1\)。捕获在整个连续块恒定，故有限和是实际 Lebesgue 积分。使用三个完整来源质量向量、三个辅助 \(d\)，并带一个非恒定原父静态接受权。这里 \(d\) 仅核有限公式，不代表该场满足原高占用/全部历史；不宣称原完整流实例。

```python
from fractions import Fraction as F
checks=0
caps=((1,1,1),(1,1,0),(0,1,1)); sides=(F(2),F(1),F(1)); vol=F(1,100)
for mu in ((F(1),F(2),F(8)),(F(3),F(1),F(8)),(F(1),F(4),F(2))):
    m=[sum(mu[x]*caps[a][x] for x in range(3)) for a in range(3)]
    qa=[m[a]/sides[a] for a in range(3)];r=max(qa)/min(qa)
    sig=[qa[a]*vol for a in range(3)];omega=(F(1),F(1,2),F(3,4));S=F(1)
    pi=[[mu[x]*caps[a][x]/m[a] for x in range(3)] for a in range(3)]
    D=[sum(sig[a]*caps[a][x]/m[a] for a in range(3)) for x in range(3)]
    for d in (min(D)/2,min(D),max(D)):
        low=F(0);fall=F(0);ext=F(0);out=[F(0)]*3
        R=sum(sig[a]*omega[a] for a in range(3))
        for a in range(3):
            for x in range(3):
                w=sig[a]*omega[a]*pi[a][x]
                if D[x]<=d: low+=w;continue
                law=[sig[b]*caps[b][x]/(m[b]*D[x]) for b in range(3)]
                assert sum(law)==1;checks+=1
                aff=F(0)
                for b in range(3):
                    small,large=sorted((a,b),key=lambda j:(m[j],j))
                    I=sum(mu[t]*caps[a][t]*caps[b][t] for t in range(3))
                    aff+=law[b]*I/max(m[a],m[b])
                    for t in range(3):
                        amount=w*law[b]*pi[large][t]
                        if caps[small][t]:fall+=amount
                        else:ext+=amount;out[t]+=amount
                assert aff<=2*r/D[x];checks+=1
        assert R==low+fall+ext;checks+=1
        assert low<=S*d*sum(mu);checks+=1
        assert fall<=2*r*S*sum(mu[x] for x in range(3) if D[x]>d);checks+=1
        for t in range(3):
            direct=F(0)
            for a in range(3):
                for b in range(3):
                    if (m[a],a)>=(m[b],b):continue
                    H=sum(mu[x]*caps[a][x]*caps[b][x]/D[x]
                          for x in range(3) if D[x]>d)
                    direct+=(omega[a]+omega[b])*H*sig[a]*sig[b]*caps[b][t]*(1-caps[a][t])/(m[a]*m[b]**2)
            assert out[t]==mu[t]*direct;checks+=1
            assert direct<=2*S*D[t];checks+=1
print('PASS',checks,'Fraction native-block disintegration assertions; no full-history claim')
```

实际运行输出：

```text
PASS 153 Fraction native-block disintegration assertions; no full-history claim
```
