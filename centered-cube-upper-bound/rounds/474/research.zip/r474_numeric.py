from fractions import Fraction as Q
from pathlib import Path
import sys, platform, json, time
import sympy as sp
from flint import arb, ctx
ROOT=Path(__file__).resolve().parent
ctx.prec=200
start=time.perf_counter(); checks=0

def ck(v):
 global checks
 assert v
 checks+=1

def rat(v):
 v=Q(v); return arb(v.numerator)/v.denominator

def out(v): return str(v)
def sq(v): return sp.Rational(v.numerator,v.denominator)

# Symbolic integration in the actual radius layer R, whose two arms
# together have dA=dR. The fixed-radius central interval has length c0.
R,M=sp.symbols('R M', positive=True)
primitive=(sp.log(R)-sp.log(R+M))/M
ck(sp.cancel(sp.diff(primitive,R)-1/(R*(R+M)))==0)
ck(sp.integrate(1/R,(R,1,2))==sp.log(2))
ck(sp.integrate(1,(R,1,2))==1)
eta=sp.symbols('eta',positive=True)
a,b=sp.symbols('a b',real=True)
# Opposite-wing compatible ordered pair area: a,b>eta, a+b<1.
triangle=2*sp.integrate(1-a-eta,(a,eta,1-eta))
ck(sp.expand(triangle-(1-2*eta)**2)==0)
# The identity behind inverse cancellation, before any bound on masses.
H,D,K2,K4=sp.symbols('H D K2 K4',positive=True)
ck(sp.cancel((H**2*K4)/(H*K2/D)-H*D*K4/K2)==0)

cases=[]
for name,e,m in [('initial',Q(1,20),Q(1)),('high_spike_pressure',Q(1,20),Q(16)),('narrow_core_expanded',Q(1,100),Q(4))]:
 c0=1-2*e; edge=1-e; support=2-e; hmass=m+2*e
 # Interval geometry, checked on each affine selector piece via endpoints.
 ck(0<e<Q(1,2)); ck(c0>0)
 # central: A in [-.5+e,.5-e], R=1; arms: R=2(|A|+e).
 for A in [-Q(1,2)+e,Q(1,2)-e]:
  ck(A-Q(1,2)>=-support);ck(A+Q(1,2)<=support)
  ck(A-Q(1,2)<=-e);ck(A+Q(1,2)>=e)
 for A in [Q(1,2)-e,edge]:
  radius=A+e
  ck(1<=2*radius<=2)
  ck(A-radius==-e);ck(A+radius<=support)
 # Complete f mass is R+M, since every selected cube lies in base support
 # and captures the entire spike; q decreases monotonically with R.
 qlo=1+m/2;qhi=1+m;r=qhi/qlo
 ck(1<r<2)
 d0=rat(c0)+arb(2).log();dout=rat(c0)+arb(2).log()/2
 ck(d0>rat(Q(3,2)));ck(dout<rat(Q(3,2)))
 # Direct Fubini occupation integral: central and radius arms.
 # Integrate D(x) against base and extra spike independently.
 # Core 2e*D0; middle 2 int_e^(1-e) (1-e-x+.5log2)dx;
 # outer 2 int_(1-e)^(2-e) .5log(2/(x+e))dx.
 # outer antiderivative x-shift u: u*(1+log(2/u)).
 middle=rat(2*((1-e)*(1-2*e)-((1-e)**2-e**2)/2))+rat(1-2*e)*arb(2).log()
 outer=2-(1+arb(2).log())
 base_int=rat(2*e)*d0+middle+outer
 ck((base_int-rat(2*edge)).contains(0))
 X=rat(2*edge)+rat(m)*d0;W=4-2*e+m
 Rhi=rat(hmass)*d0;Rlow=X-Rhi
 ck(Rlow>0);ck(Rhi<X)
 ck((Rlow-rat(2*edge)+rat(2*e)*d0).contains(0))
 # Full pair support: all pairs except opposite wings, restoring triangle.
 wing=2-2*e;G=W**2-2*wing**2+c0**2
 ck(0<G<=W**2)
 # K2 core/core independently integrated in R from 1 to 2.
 kall=rat(c0/(m+1))+(rat(2*(m+1)/(m+2))).log()/rat(m)
 primitive_eval=(arb(2).log()-(rat(m+2)).log()+(rat(m+1)).log())/rat(m)
 ck((kall-rat(c0/(m+1))-primitive_eval).contains(0))
 ck(kall>0)
 fd=rat(hmass)*kall/d0
 ratio_lo=rat(m+1)*kall/d0;ratio_hi=rat(m+2)*kall/d0
 ck(ratio_lo>0);ck(ratio_hi>ratio_lo)
 # K4/K2 is a probability average of (M+R)^-2 for every compatible pair.
 inv_lo=rat(hmass*G/(m+2)**2)*d0
 inv_hi=rat(hmass*G/(m+1)**2)*d0
 ck(inv_lo>0);ck(inv_hi>inv_lo)
 if m==16:ck(X/rat(W)>1)
 cases.append(dict(name=name,eta=str(e),M=str(m),center_E=[str(-edge),str(edge)],base_support=[str(-support),str(support)],core=[str(-e),str(e)],W=str(W),core_mass=str(hmass),q_min=str(qlo),q_max=str(qhi),r=str(r),D_core=out(d0),D_outside_ess_sup=out(dout),high_threshold='3/2',strict_high_margin=out(d0-rat(Q(3,2))),strict_outside_margin=out(rat(Q(3,2))-dout),X=out(X),X_over_W=out(X/rat(W)),R_hi=out(Rhi),R_hi_over_X=out(Rhi/X),R_low=out(Rlow),R_low_over_W=out(Rlow/rat(W)),compatible_pair_mu2=str(G),K2_core_core=out(kall),F_d_core_core=out(fd),F_d_over_p_core_core_range=[out(ratio_lo),out(ratio_hi)],inverse_lower=out(inv_lo),inverse_upper=out(inv_hi),inverse_over_X_lower=out(inv_lo/X),inverse_over_X_upper=out(inv_hi/X)))
result=dict(scope='STATIC-ONLY actual continuous 1D selector, full nonuniform L1 f; Pi=sigma*pi_A^2, marks 1. No original high-Z/history certification; no general-order conclusion.',compute_index=dict(executable=sys.executable,python=platform.python_version(),sympy=sp.__version__,arb_precision_bits=ctx.prec,command='"'+sys.executable+'" r474_numeric.py',seconds=time.perf_counter()-start),cases=cases,checks=checks,exactness='Rational inputs/geometry and symbolic identities exact. All log diagnostics are 200-bit Arb enclosures. Inverse is a rigorous analytic bracket, not full numerical quadrature.')
(ROOT/'r474_numeric.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS',checks,'exact/Arb assertions; 3 actual continuous high-occupancy models; no general-order or original-history claim')
for c in cases: print(c['name'], 'Dcore',c['D_core'],'X/W',c['X_over_W'],'inverse/X',c['inverse_over_X_lower'],c['inverse_over_X_upper'])
