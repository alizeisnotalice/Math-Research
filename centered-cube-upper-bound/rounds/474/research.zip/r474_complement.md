# R474：高真实占用的三来源换序与软恢复逆矩

结论：原接受测度上的零分母障碍可严格排除，逆矩在固定场上有限；但已取得的统一价格仍含 \((W/(qa^n))^2\)，不是根阶付款。本稿保留原 \(D\) 和全部接受权，定位一个准确待估积分；没有把人工第三来源赋予旧历史。

## 1. 原场、接受密度与共同父核

沿冻结合同，\(\mu=f\,dx,\sigma=q_A dA,m_A=\mu(Q_A)\)，\(m_-=qa^n>0\)，\(m_+=\lambda b^n<\infty\)，\(X=\sigma(E),W=\mu(\mathbb R^n)\)。写实际投影为
\[
 d\Pi=\ell(A,y,z)\sigma(dA)\pi_A(dy)\pi_A(dz),\qquad
 \ell=\sum_{i,e}a_i^e(A,y)b_i(z)\theta_i^e(A,y,z)\in[0,S].       \tag{1}
\]
原 stage、时钟及路径筛选均在 \(\ell\) 中，式 (1) 仅是准确投影。令
\[
 D(x)=\int\frac{c_A(x)}{m_A}d\sigma(A),\quad
 K_j(x,y,z)=\int\frac{c_A(x)c_A(y)c_A(z)}{m_A^j}d\sigma(A),
\]
并定义保原父接受权的
\[
 K_{4,\ell}(x,y,z)=\int\frac{c_A(x)c_A(y)c_A(z)}{m_A^4}
                                  \ell(A,y,z)d\sigma(A).       \tag{2}
\]
这些是实际共同父积分，不是几何上包络。三来源的坐标 hull 必须包含于同一个实际 \(Q_A\)，但此必要条件不会把 \(\mu\) 变成体积。

固定 \(d\ge0\)，\(p_d(A)=\pi_A\{D>d\}\)。合同的高占用恢复准确为
\[
 F_d(A,y,z)=\int_{Q_A\cap\{D>d\}}\frac{K_2(x,y,z)}{D(x)}d\mu(x).
                                                               \tag{3}
\]
仅在 \(D>0\) 上用该商。记 \(R_{\rm hi}=\int p_d\,d\Pi\)，
\(C_{\rm hi}=\int F_d\,d\Pi\le4rSW\)。另有已付
\(R-R_{\rm hi}\le SdW\)，其中 \(r=\lambda/q\)。

## 2. 零域排除及保原权的逆矩换序

**命题。** 在上述同一场中，\(\Pi\{p_d>0,F_d=0\}=0\)。置 \(0/0=0\)，则
\[
 I_d:=\int\frac{p_d(A)^2}{F_d(A,y,z)}d\Pi
 \le\mathcal Q_d:=
 \int_{\{D(x)>d\}}D(x)\frac{K_{4,\ell}(x,y,z)}{K_2(x,y,z)}
                          d\mu(x)d\mu(y)d\mu(z),               \tag{4}
\]
商在 \(K_2=0\) 处置零，且
\[
 \mathcal Q_d\le\frac{SW^2}{m_-^2}
              \int_{\{D>d\}}D\,d\mu
 \le\frac{SW^2X}{m_-^2}<\infty.                               \tag{5}
\]

**证明。** 若 (3) 为零，则其非负被积项 \(K_2\) 在该父的高 \(D\) 来源部分几乎处处为零。另一方面
\[
 \int_{\{K_2=0\}}K_3\,d\mu^3=0,
\]
因为 \(K_3\le K_2/m_-\)。Tonelli 表明，对 \(\sigma(dA)\pi_A(dy)\pi_A(dz)\)-几乎处处的原父两来源记录，捕获的第三来源落在 \(K_2=0\) 的 \(\pi_A\) 质量为零。故 \(F_d=0\) 迫使 \(p_d=0\)，并可传给正限制 (1)。这不是从单个父点的零 Lebesgue 质量猜测邻父存在。

在正域，对来源 \(x\) 作 Cauchy–Schwarz：
\[
 \frac{p_d(A)^2}{F_d(A,y,z)}
 \le\frac1{m_A^2}\int_{Q_A\cap\{D>d\}}
                                      \frac{D(x)}{K_2(x,y,z)}d\mu(x).
                                                               \tag{6}
\]
将 (6) 对原 (1) 积分并 Tonelli 换序，正好得到 (4)，没有将 \(\ell\) 移到代表父或删掉它。最后
\(K_{4,\ell}\le S K_2/m_-^2\)，以及真实匹配恒等式
\(\int D\,d\mu=X\)，给 (5)。所有零域可先截断倒数再单调取极限；(5) 证明极限有限。

## 3. 实际回代价格与尚缺的一步

同测度 Cauchy–Schwarz 现在可合法使用：
\[
 R_{\rm hi}^2\le C_{\rm hi}I_d\le4rSW\mathcal Q_d.            \tag{7}
\]
但 (5) 只给
\[
 R\le SdW+2\sqrt r\,S\frac W{m_-}\sqrt{WX}
 \le SdW+\varepsilon X+
                  \frac{rS^2}{\varepsilon}\frac{W^3}{m_-^2}.   \tag{8}
\]
取 \(d\asymp\sqrt n\) 只支付第一项，不能把最后一项隐入根阶常数。

若要以本机制闭合，具体需要控制的是 (4) 中**同一个** \(K_{4,\ell}/K_2\) 的来源积分，例如 \(\mathcal Q_d\lesssim\sqrt n\,\mathrm{polylog}(n)X\)，或直接证明 (6) 的 Cauchy 损失使实际 \(I_d\) 更小。前者只是充分条件，未证明且不主张必要。其几何困难很明确：\(K_2\) 是第三来源与原两来源共同捕获的实际中心质量，\(D(x)\) 则计全部捕获第三来源的中心；原 high-\(Z\)/low-\(C\) 门没有已证下界把两者比较。用 \(D\le A_n\)、\(m_A\ge m_-\) 或只保 hull 相容性会退回 (5) 类型费用。不能用上包络 \(K_2\) 代替分母来估上界，也不能将原接受 \(\ell\) 换成独立来源后验。

因此本轮只完成零域和逆矩合法性的严格检查，以及保真实标记的换序；未取得新全余付款，也未叠加旧平方/时钟信用。

## 4. 已实际执行的有限代数检查

下面代码用标准库 Fraction，实跑输出 `PASS 175 Fraction assertions; finite incidence/source algebra, not continuous native-history certification`。五个 \(d\)（含零、原子边界及全空高域）和三种父—来源接受权检验零域、(4)、(5)、(7)。这是有限 incidence 代数检验，不是连续实际选择器或原历史认证；一般结论由上述证明给出。

```python
from fractions import Fraction as F
mu=[F(1),F(2),F(1)]; sig=[F(1,3),F(1,4),F(1,5),F(1,6)]
c=[[1,0,0],[1,1,0],[0,1,1],[1,1,1]]
m=[sum(mu[x]*c[A][x] for x in range(3)) for A in range(4)]
D=[sum(sig[A]*c[A][x]/m[A] for A in range(4)) for x in range(3)]
K2={(x,y,z):sum(sig[A]*c[A][x]*c[A][y]*c[A][z]/m[A]**2 for A in range(4)) for x in range(3) for y in range(3) for z in range(3)}
checks=0
for d in [F(0),min(D),sum(D)/3,max(D),max(D)+1]:
 for mode in range(3):
  ell=lambda A,y,z:F(1) if mode==0 else (F((A+2*y+z+mode)%5,5))
  inv=rhs=mass=cross=F(0)
  for A in range(4):
   p=sum(mu[x]*c[A][x]*(D[x]>d) for x in range(3))/m[A]
   for y in range(3):
    for z in range(3):
     base=sig[A]*mu[y]*mu[z]*c[A][y]*c[A][z]/m[A]**2*ell(A,y,z)
     ff=sum(mu[x]*c[A][x]*K2[x,y,z]/D[x] for x in range(3) if D[x]>d)
     if base and p: assert ff>0; checks+=1
     if ff: inv+=base*p*p/ff
     mass+=base*p;cross+=base*ff
  for x in range(3):
   if D[x]<=d:continue
   for y in range(3):
    for z in range(3):
     k=K2[x,y,z]
     kk=sum(sig[A]*c[A][x]*c[A][y]*c[A][z]*ell(A,y,z)/m[A]**4 for A in range(4))
     if k:rhs+=mu[x]*mu[y]*mu[z]*D[x]*kk/k
     else:assert kk==0;checks+=1
  assert inv<=rhs;checks+=1
  assert mass*mass<=cross*inv;checks+=1
  assert rhs<=sum(mu)**2/min(m)**2*sum(mu[x]*D[x] for x in range(3) if D[x]>d);checks+=1
print('PASS',checks,'Fraction assertions; finite incidence/source algebra, not continuous native-history certification')
```
