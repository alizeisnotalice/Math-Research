from fractions import Fraction as F
from collections import Counter
# Native, continuous receiver blocks and concentrated full L1 sources.
# Sources are all 2^n corners (+/-3/10)^n, side d, masses a/N or (2-a)/N
# according to first coordinate. Receiver blocks side e have same centers.
# First half chooses edge 1; second half edge 2. All incidences are constant
# throughout each source and receiver block, so formulas below are exact.
counts=Counter(); rows=[]
for phase,roots in [('initial',(2,3)),('pressure',(4,5)),('expanded',(8,12,16))]:
 for k in roots:
  n=k*k; N=2**n
  for a in (F(1,4),F(1),F(3,2)):
   for d,e in ((F(1,64),F(1,64)),(F(1,1024),F(1,32)),(F(1,2**20),F(1,64))):
    assert (d+e)/2<F(1,10)
    # 2<euler's number<3 proves exact native strict-prefix pattern.
    assert a*3**k<N
    v=e**n; qmin=min(a,F(1))/N; h=F(2*(1+k))/qmin
    Jsmall=N*v/a+F(N,2)*v; Jother=F(N,2)*v
    Csame=N*v/a
    meanC=F(a,N)*Csame
    assert meanC==v and meanC<=Jsmall/F(3**k)
    # Stronger than J/K since native K<3^k.
    assert max(Jsmall,Jother)<=F(1+n)/qmin
    mean_soft_small=1-F(a,N)*min(Csame/h,F(1))
    assert mean_soft_small>=1-Jsmall/(F(3**k)*h)
    X=F(1,2)*(a+1)*v
    U=X
    loss=F(1,2)*v*F(a*a,2*N)*min(Csame/h,F(1))
    T=U-loss
    alphabar=F(1+n)/(F(2**k)*qmin*h)
    assert max(F(0),1-alphabar)*U<=T<=U
    # Three stages: decreasing si and same-source marks sum 1, exact scaling.
    sc=(F(1),F(2,3),F(1,3)); marks=(F(1,6),F(1,3),F(1,2))
    mult=sum((x*y for x,y in zip(sc,marks)),F(0))
    assert max(F(0),1-alphabar)*(mult*U)<=mult*T<=mult*U
    # All source masses sum 1, heights may be arbitrarily large as d decreases.
    assert F(N,2)*(a/N+(2-a)/N)==1
    counts[phase]+=1
    rows.append((n,float(alphabar)))
print('PASS native tensor-spike continuous-center models',dict(counts),'total',sum(counts.values()))
print('dimensions',sorted({n for n,_ in rows}))
print('conservative alpha bounds', sorted(set(rows)))
print('Exact Fraction matching, strict native K-prefix, conditional overlap, soft loss and 3-stage sum.')
print('No original high-occupancy/deletion-history realization; not an extremal lower-bound or general upper-bound certificate.')
