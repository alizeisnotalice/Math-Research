from fractions import Fraction as F
from itertools import product

# Exact integration of products of clipped affine interval lengths.
def integral_product(intervals, lo, hi, increasing):
    # length of [p,q] intersect (-infinity, endpoint), endpoint=x+1/2 or 1/2-x.
    cuts={lo,hi}
    for p,q in intervals:
        for e in (p,q):
            x=e-F(1,2) if increasing else F(1,2)-e
            if lo<x<hi: cuts.add(x)
    ans=F(0)
    xs=sorted(cuts)
    def length(I,x):
        p,q=I; e=x+F(1,2) if increasing else F(1,2)-x
        return max(F(0),min(q,e)-p)
    for a,b in zip(xs,xs[1:]):
        # product is a quadratic on this interval; Simpson is exact.
        def val(x):
            out=F(1)
            for I in intervals: out*=length(I,x)
            return out
        ans+=(b-a)*(val(a)+4*val((a+b)/2)+val(b))/6
    return ans

counts={}; positive=0
stages=[('initial',[(F(-1,2),F(1,2)),(F(0),F(1,2))],[F(1)]),
        ('boundary',[(F(-1,2),F(0)),(F(0),F(1,2)),(F(-1,4),F(1,4))],[F(1,8),F(1,2),F(2)]),
        ('expanded',[(F(-1,2),F(-1,4)),(F(-1,4),F(1,4)),(F(1,4),F(1,2)),(F(-1,2),F(1,2))],[F(1,16),F(1,4),F(3,4)])]
for name, intervals, hs in stages:
    count=0
    for Iy,Iz,h,q in product(intervals,intervals,hs,[F(3,4),F(1)]):
        # full f=q 1[-4,4], actual centers [-1,0):R=1, [0,1]:R=2.
        # actual parent A=1/2, QA=[-1/2,3/2], mA=2q;
        # far diagnostic K=3/2 selects exactly the smaller centers.
        p=(Iy[1]-Iy[0])/2; bz=(Iz[1]-Iz[0])/2
        # Native overlap identity: I_g=q*length(Iy cap Qw), I_b=q*length(Iz cap Qw).
        by_receiver=integral_product([Iy,Iz],F(-1),F(0),True)/(4*q)
        # Direct source formula C(y,z)=(1/2-max(y,z))/q on these intervals.
        by_source=integral_product([Iy,Iz],F(0),F(1),False)/(4*q)
        assert by_receiver==by_source
        deficit=integral_product([Iy,Iz],F(0),q*h,False)/(4*q*h)
        soft=p*bz-deficit
        assert F(0)<=soft<=p*bz
        assert deficit<=min(p*bz,by_receiver/h)
        # Exact gated lower bound using actual J <= total mu(E)=3/(2q).
        alpha=F(3,2)/(q*F(3,2)*h)
        assert soft>=p*bz-min(p,alpha)*bz
        if q*h>=1: assert deficit==by_receiver/h
        positive+=int(by_receiver>0)
        count+=1
    counts[name]=count
print('PASS',counts,'total',sum(counts.values()),'positive overlap moments',positive)
print('Exact Fraction continuous-center pointwise-parent identities; diagnostic K,h and arbitrary gate/b, not original stages/history.')
