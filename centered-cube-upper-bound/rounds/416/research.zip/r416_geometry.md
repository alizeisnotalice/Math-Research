# R416：真实旧来源条件下 soft 共同捕获的删减上界

2026-10-20。有界交付：本轮没有证明 R414 的根阶总预算，也没有新增密度门或付款。完成的计算说明，固定 pair 的 soft 容量不能在完整来源平均后自动给出强删减；即使保留实际旧来源的高 stage 条件密度，能够绕开该结论的也必须是一个很小、并依赖另一来源的条件子事件。该子事件的存在不等于剩余费用已获控制。

## 1. 唯一尝试与真实 matching 计算

原 A、w 都是真实接收者，μ(dw)=dw/m_w，m_A=f(Q_A)，π_A=f1_QA/m_A。所有阶段、时钟与历史冻结；K=e^(√n)，h、τ、S=β+C_col 均沿用原值。设
\[
C_A(y,z)=\int_{m_w<m_A/K}c_w(y)c_w(z)\mu(dw),\quad
Z_A(z)=\int_{m_w<m_A/K}c_w(z)\mu(dw),
\quad\psi_A=(1-C_A/h)_+.
\]
尝试从共同父容量 B_0+h/2 得到来源线性费用时，必须先保住每个父的真实 m_A。正确的完整旧来源积分是
\[
\begin{aligned}
\int\pi_A(dy)C_A(y,z)
 &=\frac1{m_A}\int_{m_w<m_A/K}c_w(z)
                  \frac{f(Q_A\cap Q_w)}{m_w}\,dw\\
 &\le\frac1{m_A}\int_{m_w<m_A/K}c_w(z)dw
 \le\frac{Z_A(z)}K\le\frac{J(z)}K.                 \tag{1}
\end{aligned}
\]
第一步是实际 full f 的 Tonelli 等式，第二步用 f(Q_A∩Q_w)≤m_w，第三步逐个真实 w 用 m_w<m_A/K。不需要把选定半径作为独立积分变量，不需要来源密度帽，也没有给 w 新历史资格。严格门的质量原子保持排除；所有界写成非严格安全上界。

因此完整后验的 soft 平均满足
\[
\int\pi_A(dy)\psi_A(y,z)\ge1-\frac{Z_A(z)}{Kh}.
                                                               \tag{2}
\]
它表明按完整 π_A 平均时，soft 所删的是小量，而不是已知可占固定比例的费用。本轮不把 (1) 包装为新付款；它检验了此前拟用固定 pair 容量作来源 Carleson 收费的方向。

## 2. 保留实际旧来源分布，不能免费换成 π_A

原方向 e∈{u,v} 的来源投影是
\[
\Gamma_i^e(dA,dy)=\sigma(dA)a_i^e(A,y)\pi_A(dy),\quad
0\le a_i^e\le B_e,\quad B_u=\beta,\ B_v=C_{\rm col}.
\]
记 s_i^e(A)=∫a_i^eπ_A。在已经支付 low-stage 边缘后的原补集，s_i^e>τB_e。故真正归一化旧来源条件分布是
\[
P_i^e(A,dy)=\frac{a_i^e(A,y)}{s_i^e(A)}\pi_A(dy),\qquad
\frac{a_i^e}{s_i^e}\le\tau^{-1}.
\]
由 (1) 严格得到
\[
\mathbb E_{P_i^e}C_A(y,z)\le\frac{Z_A(z)}{\tau K}.       \tag{3}
\]
原其他端点、时钟、历史标签先用 Γ_i 的实际条件核保留；a_i=0 处用零 subkernel。令 Ω_i^e(A,y,z)∈[0,1] 为这些实际标签及原双路径上后续正门的条件期望，不包含 ψ 本身。它包括原 early、relative、双 current-high、重尾以及 initial/terminal 几何门。双 exclusive 路径只在 C_A<h 上定义，其他位置把 Ω 置零；不是在门外构造新路径。没有重新归一化任何余项。

设
\[
r_i^e(A,z)=\mathbb E_{P_i^e}\Omega_i^e(A,y,z).
\]
则对每个真实 A,z 有
\[
0\le r_i^e-\mathbb E_{P_i^e}[\Omega_i^e\psi_A]
 \le\frac{Z_A(z)}{\tau Kh}.                              \tag{4}
\]
这里不能把右边擅自再乘 r_i^e。若 r_i^e>0，后续全部门条件化后的旧来源 law 满足
\[
\frac{\mathbb E_{P_i^e}[\Omega_i^e C_A/h]}{r_i^e}
 \le\frac{Z_A(z)}{\tau Kh\,r_i^e}.                       \tag{5}
\]
所以，若该条件 law 的共同捕获均值至少 c h（c>0），必有
\[
r_i^e(A,z)\le\frac{Z_A(z)}{\tau Khc}.                   \tag{6}
\]
这准确区分两个问题：原 a_i/s_i 的浓缩受 τ^(-1) 控制；再由依赖 z 的全部门条件化后仍可有 1/r_i 的浓缩。原 sourcewise cap 不禁止后者，但它只发生于相应较小的条件质量上。没有证明这个小事件承担 R414 的固定比例；实际剩余恰容许共同捕获极低。

## 3. 同一实际标记的累计删减量，不丢 stage 一次费用

仅为比较，令 T_mark 是在同一原 R414 费用中把 ψ 因子替换为1、但保持 Ω 的所有门（包括 C_A<h 支持及原路径核）所得的量。R414 本身没有被重新定义。

不用 (3) 的 τ 损失，而直接用 a_i^e≤B_e、(1) 和原 Σ_i b_i(z)≤1，有
\[
\begin{aligned}
0\le T_{\rm mark}-R414
&\le\sum_e\sum_i\int\sigma(dA)\pi_A(dz)b_i(z)
       \frac{B_e Z_A(z)}{Kh}\\
&\le\frac{S}{Kh}\int\sigma(dA)\pi_A(dz)J(z)\\
&\le\frac{S A_n}{Kq_-h}X_q.                              \tag{7}
\end{aligned}
\]
其中 A_n=1+n log(b/a)。这是一次累计比较，不是逐阶段 X 账，也不需要改变 b_i/D_i。替换 ψ 后仍未付的 T_mark 只用于说明同一原标记的关系；不作为新正式余项，亦不将 (7) 的上界再扣一次旧信用。

若令 α=A_n/(Kq_-h)，无其他 Ω 门、但保原 high-stage 条件时，(3) 给每个 A,z 的乘法下界 1−α/τ；带完整 Ω 后只保留加法式 (4)、(7)。因此“实际旧来源并非完整后验”本身不足以使 soft 容量成为主要来源线性付款机制。现有 cap 已排除了不经 Ω 选择的指数级条件浓缩，而 Ω 的稀薄选择尚无几何收益下界。

## 4. 决定性的未证一步与原账

本次实际尝试停在下面一步，而不是另立一个充分超额条件：固定 pair 的秩容量控制的是共同父数量；对这些父先按真实 f(Q_A) 归一，再积分旧来源时，(1)–(2) 显示绝大多数后验对本就具有很小共同远捕获。因此不能由该容量推出来源线性 Carleson 收费，也不能由“low-common”推断 Ω 选择消耗了足够父来源质量。

若要沿本路线继续，必须从 Ω 内**原阶段删除及共同父几何**证明可累计的损失，控制那些 r_i^e 并不小而共同捕获均值仍很小的实际 A,z。当前 (1)–(7) 没有这种损失；它们也没有产生 D_i(y)^(-1/2) 权。用固定 pair 上界直接积分仍会引入 W²；用 (7) 则仅把同一未付费用在两个几乎相等的写法间比较。两者都不是根阶预算。

因此本轮原账不变：
\[
G_0\le16\widehat F[R414+C413X_q+V413W],\qquad
\widehat F=(1-32\delta-16\eta)^{-1}.
\]
没有把 (7) 作为新 X 支付款加入或从旧账退款。没有建立 P，没有主张闭合。

## 5. 实际精确检查

实际运行 `/tmp/r416_geometry_check.py`。完整 f 在八个单位区间上分段常数，父区间覆盖全部八格，子区间覆盖连续四格；全部交集质量均由同一 f 精确计算。接收中心使用有限有理 quadrature。

三阶段分别为6、16、18个模型，共40个；实际检验 (1)、(3)–(5) 和同一 stage 累计比较，分别出现126、315、378条正 masked-soft 删减记录，共819条。Fraction 运算全部通过。

旧来源 profile 和 Ω 是满足所验算代数条件的有限模型，不认证原 Γ/history、q-band、原生连续 du 或完整 R414 非空样本。脚本不要求这些 profile 来自真实删除历史，也不将它们用于原定理存在性。一般式 (1)–(7) 依靠上面的 Tonelli、matching 与已审原 stage 合同；有限计算只核等式和不等式方向。停止本轮扩展。
