from fractions import Fraction as F
from itertools import product

# Piecewise-constant full f on eight unit cells; finite receiver quadrature.
# This checks matching identities, not native du, q-band, original histories or stages.
def check(weights, K, h):
    weights=tuple(map(F,weights)); n=len(weights); m=sum(weights)
    cubes=[tuple(range(j,j+4)) for j in range(5)]
    masses=[sum(weights[j] for j in Q) for Q in cubes]
    centerweights=[F(j+1,7) for j in range(len(cubes))]
    J=[sum((centerweights[k]/masses[k] for k,Q in enumerate(cubes) if z in Q),F(0)) for z in range(n)]
    C=[[sum((centerweights[k]/masses[k] for k,Q in enumerate(cubes)
              if y in Q and z in Q and K*masses[k]<m),F(0))
         for z in range(n)] for y in range(n)]
    pi=[w/m for w in weights]
    B=F(1); tau=F(1,4)
    profiles=[[F(2+(y+i)%3,4)*F(4-i,4) for y in range(n)] for i in range(3)]
    # Actual monotone stages are not asserted; once-only budget only needs a_i<=B.
    bis=[[F((z+i)%3+1,12) for z in range(n)] for i in range(3)]
    assert all(sum(b[z] for b in bis)<=1 for z in range(n))
    total_loss=F(0); positive=0
    for z in range(n):
        matching=sum((pi[y]*C[y][z] for y in range(n)),F(0))
        assert matching <= J[z]/K
        for i,a in enumerate(profiles):
            s=sum((pi[y]*a[y] for y in range(n)),F(0))
            if s<=tau*B:
                continue
            old=[pi[y]*a[y]/s for y in range(n)]
            assert all(a[y]/s<=1/tau for y in range(n))
            assert sum((old[y]*C[y][z] for y in range(n)),F(0)) <= J[z]/(tau*K)
            # Parent/old/new-dependent mask, restricted to the true soft support.
            Omega=[F((y+2*z+i)%3,2)*F(C[y][z]<h) for y in range(n)]
            r=sum((old[y]*Omega[y] for y in range(n)),F(0))
            retained=sum((old[y]*Omega[y]*max(F(0),1-C[y][z]/h) for y in range(n)),F(0))
            loss=r-retained
            assert 0<=loss<=J[z]/(tau*K*h)
            if r:
                conditional=sum((old[y]*Omega[y]*C[y][z]/h for y in range(n)),F(0))/r
                assert r*conditional<=J[z]/(tau*K*h)
            total_loss += pi[z]*bis[i][z]*s*loss
            positive += loss>0
    # sigma-parent normalized to 1. The bound uses the sharper source-average J.
    bound=sum((pi[z]*J[z] for z in range(n)),F(0))/(K*h)
    assert total_loss<=bound<=max(J)/(K*h)
    return positive

stages=[
 [(tuple([1]*7+[M]),F(2),F(1)) for M in (2,4,8,16,32,64)],
 [(tuple([a]*4+[b]*3+[M]),F(K),F(1,2)) for a,b,M,K in product((1,2),(1,3),(8,32),(2,3))],
 [(tuple([a,1,2,a,1,3,2,M]),F(5,2),F(h,3)) for a,M,h in product((1,3,5),(16,64),(1,2,4))]
]
for i,cases in enumerate(stages,1):
    positive=sum(check(*args) for args in cases)
    print(f'Stage {i}: PASS; {len(cases)} matching models; {positive} positive masked-soft-loss records')
print('Scope: exact full-f interval matching with finite center quadrature and algebraic source profiles; not native du/q-band/far-core/history examples and not a root budget.')
