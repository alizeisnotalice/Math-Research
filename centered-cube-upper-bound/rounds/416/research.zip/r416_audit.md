# R416 independent audit — frozen

FINAL PASS within the stated R416 scope: full-f matching comparison and actual-label additive soft-removal bound. Final main/README, both proofs and three scripts reviewed; all three scripts independently rerun and delivered stdout matched byte-for-byte. No new payment, no P and no root-bound closure are certified. R414 and its full ledger remain unchanged. Independent screening preceded author reading; only this audit file was edited.

For a fixed true parent A and source z, positive Tonelli and full matching give

E_{π_A(dy)} C_A(y,z)=m_A^−1 ∫_{m_w<m_A/K} c_w(z) f(Q_A∩Q_w) μ(dw).

The intersection mass is ≤m_w, and strict far mass implies m_w/m_A<1/K. Thus this average is ≤J(z)/K≤A_n/(Kq_-). One may use ≤ throughout; mass atoms at m_w=m_A/K are excluded by the original strict gate. No source-density cap, independent radius selector, source independence assumption or additional q factor occurs. The octave native center bound supplies A_n=1+n log(b/a). α=A_n/(Kq_-h) is dimensionless.

For ψ=(1−C/h)_+, pointwise ψ≥1−C/h and ψ≥0. Hence at every parent/source pair E_{π_A}ψ≥(1−α)_+ and Eψ≤1. Multiplication by the ORIGINAL nonnegative s_i(A)b_i(z), integration and countable positive Tonelli yield

(1−α)_+ U≤T≤U,
U=Σ_i∫ f(z)b_i(z)D_i(z)dz,
D_i(z)=∫s_i(A)q_Ac_A(z)dA/m_A.

This is exactly the unsoftened matching identity Σ_i∫σs_iπ_A(dz)b_i(z)=U. With the original decreasing s_i≤s_0 and same-z Σ_i b_i(z)≤1, U≤∫fD_0=2G_0 is finite. For arbitrary nonnegative inputs allowed to have infinite integrals, inequalities remain extended-positive statements, but if α≥1 write the lower bound as 0≤T rather than an undefined product 0·∞. Empty field, zero common capture, zero stage or source weights cause no normalization issue. h>0 and K>1 are required.

The result concerns the R415 full-parent-posterior positive relaxation. It gives no reverse domination of the actual restricted old-source law by π_A. A pre-filter normalized original stage law dominated by π_A/τ has E C≤αh/τ and thus Eψ≥(1−α/τ)_+ BEFORE subsequent filtering. For an arbitrary additional positive restriction, only an additive soft-loss bound relative to that unfiltered mother measure follows; there need not be the same multiplicative lower bound relative to the surviving restricted mass. Renormalization after rare gates can increase conditional C. No original source/history may be replaced or refreshed using this calculation.

## Actual independent local arithmetic

Executed 2088 finite full-f matched incidence parent/source/K configurations (dimensions 2,3,4; 3 rational K values), each checked at three positive h values with Fraction arithmetic. Tested exact average common past ≤J/K and the averaged soft comparison, retaining mass ties and strict thresholds. All passed. This is finite incidence algebra with true subset mass matching, not a native Lebesgue-center or original-history realization. It is reviewer execution, not a standalone archived script or additional delivered experiment count.

## Final actual-label bound

The post-author strengthening is valid. For each orientation e the ORIGINAL old-source projection has unnormalized density a_i^e(A,y)≤B_e relative to σ(dA)π_A(dy), with Σ_eB_e=S. Keep b_i(z) at the same original new source. Condition all other actual labels/path kernels on (i,e,A,y,z), obtaining Ω_i^e∈[0,1] excluding ψ itself. Retain the domain C_A<h: the double-exclusive path was defined only there, and Ω is set to zero outside; replacing ψ by 1 does not enlarge that domain.

Dropping Ω only in the positive error and applying matching gives

0≤Δsoft≤Σ_{i,e}B_e∫σπ_A(dz)b_i(z) E_{π_A(dy)}(1−ψ_A)
≤S/(Kh) ∫σπ_A(dz)J(z)
≤SαX_q.

Here Σ_i b_i(z)≤1 is used once on the SAME source z; there is no stage count, extra orientation factor, or τ^-1 loss. The density cap is unnormalized. Conditional path probability mass≤1 suffices even when its geometry depends on the original u/v/clock/history; no path on the excluded support is invented. The comparison is additive, not payment: it does not certify the unsoftened actual quantity or reduce any already booked fee.

The geometry proof correctly distinguishes the stage-high conditional law a_i/s_i≤1/τ from the law after all Ω gates. The latter can incur a factor 1/r_i. Its soft loss is bounded relative to the unfiltered mother quantity; no omitted factor r_i is inserted in the error bound. The auxiliary proof retains the two actual intersection masses I_Aw and I_Aw^b. With a bounded gate g it retains I_g(A,w;z), and derives only absolute loss≤GαU, not Q_g≥(1−α)V_g. These are valid positive Tonelli statements with mass atoms and finite/countable stages.

## Native parent-model verification

Independently checked the symmetry compression in the delivered parent script. Sources occupy disjoint cubes centered at all corners (±3/10)^n, of side d; center blocks of side e have the same corners and are disjoint up to null boundaries. The asserted margin (d+e)/2<1/10 ensures side-1 receivers capture only their same-corner source cube and side-2 receivers capture every source cube. Full f is zero outside these source cubes. Thus source masses and all receiver matches are exact at every center, not just midpoint matches.

Writing N=2^n, source masses are a*/N on one half and (2−a*)/N on the other. The selected receiver masses are a*/N and 1; q values are a*/N and 1/N, with the model-specific declared q_- and λ. These test values are not a claim that all models satisfy an additional historically fixed narrow λ/q_- ratio. The general matching lemma requires only the stated positive band. The rational inequality a*3^sqrt(n)<N implies the original strict K=e^sqrt(n) prefix selects precisely the smaller receivers below a big parent. Small-parent common past is empty.

For a source in the small half, J=Nv/a*+Nv/2; for the other half J=Nv/2. Under a big parent C is Nv/a* only when both sources lie in the same small-half source cube, and otherwise is zero. Hence its posterior C mean at such z is exactly v, and

X_q=(a*+1)v/2,
U=X_q,
U−T=(v/2)[a*²/(2N)] min(Nv/(a*h),1).

These agree with the script. Its alpha bound uses log 2<1 and K>2^sqrt(n), so is conservative. Fraction assertions provide the evidence; float alpha displays do not form a numerical certificate. Three stage weights test positive sum identities only, not an original deletion-history construction.

## Computation evidence and formal scope

Independent final-code reruns succeeded and matched all three delivered result files:

- parent: 63 continuous-center tensor models, [18,18,27], dimensions 4,9,16,25,64,144,256. Exact Fraction matching/strict prefix/loss/scaling; no original high-occupancy or deletion-history certification.
- aux: 158 one-dimensional continuous-center fixed-parent configurations, [8,54,96]. Clipped affine lengths are integrated by exact piecewise-quadratic Simpson identities. The source/layer representation and soft loss agree exactly. K=3/2 and h are diagnostic; no original full Γ/history contract.
- geometry: 40 full-f interval matching models with finite receiver quadrature, [6,16,18], yielding [126,315,378] positive masked-loss records. Source profiles and Ω gates are algebraic, not actual deleted-flow fixtures; native du/q-band/history are expressly not certified.

These are different model/configuration types, not a pooled collection of native complete-contract samples. The separate 2088 reviewer configurations above are not added to delivered counts and have no archived standalone script.

Final main and README make no new payment, no new formal remainder, no P and no unfiltered-to-filtered multiplicative claim. The R414 G/BH/entrance coefficients are copied unchanged, including Fhat=(1−32δ−16η)^−1 and all outside terms. No negative/cross/clock credit is reused. The general joint geometric budget remains unproved.

## SHA-256 bindings

Final bytes reviewed below; no generated TeX or later package bytes are bound by this record.

- `r416_main.md`: `74aae18d74d3603e7f006a875b696ab04014f7ddec8e3321e5d77d5342a9604b`
- `r416_readme.md`: `7ef42fcba755e9847ab255e5b78fc0e65e5ea09c8fdc969dec0935166b23d3ea`
- `r416_aux.md`: `3fafcd6bd6164d601fe638a12d35f5f6374870c932f64475211d65d4904055b8`
- `r416_geometry.md`: `521c8cd35b140a1bec168a2525683a801ffa688bfa8b896b0f39cdd7babbf661`
- `r416_parent_check.py`: `ac0a7dd8fefbe023778572263b9a58c624fd0b697c1e803c2c0be6ef4c5a4fb3`
- `r416_aux_check.py`: `d9867eacd6839c89ab89bb39d8ced9ac6f63e24471b407bdc6675f7a86d3e2b4`
- `r416_geometry_check.py`: `b53cac1bb39957c6c48184427a64a108151be865f3775b19beaf65648d7366ee`
- `r416_parent.result.txt`: `5ebcc52979fa6e3c204d149728c1798e0d2e6095b39f7cb42a26e2d858c03ec1`
- `r416_aux.result.txt`: `8b615cd90058d0880acaf821f44bc805cd888b40172ef96ba8cb00744c3c5393`
- `r416_geometry.result.txt`: `b340fd43270e621e3a67c041f924c0bd128ee1addc2123b73d1b33b11b7cffa3`
- `r415_main.md`: `34a9c8e9f16c4706781333f3239159a713df0ec0107f96cf1dc6b55823e567e2`
- `r414_main.md`: `4b22ddb135ac2f13eb1f282b7e5c965b293f2ea4ec259d5efa8a6f961e390ddc`

Frozen bounded result: matching diagnostic and additive comparison only; no new global source budget.
