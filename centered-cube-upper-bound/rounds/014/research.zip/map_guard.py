from fractions import Fraction as F
import json

def witness(N):
 R=[F(2)-F(1,2)*F(1,4)**k for k in range(N)]
 z=[F(3,4)*r for r in R];x=[r/4 for r in R]
 masses=[r*r for r in R];weights=[F(1),masses[0]-1]+[masses[k]-masses[k-1] for k in range(1,N)]
 assert sum(weights)==masses[-1]<4 and all(w>0 for w in weights)
 images=[];centers=[]
 for k in range(N):
  arrival=[2*(p-x[k]) for p in z]
  assert all(1<t<2 for t in arrival[:k+1]) and all(t>2 for t in arrival[k+1:])
  vals=[F(1),masses[k]/2]+[masses[j]/arrival[j] for j in range(k)]
  gap=R[k]-max(vals);assert gap>0 and masses[k]/arrival[k]==R[k]
  margins=[x[k],F(1,2)-x[k]]+[abs(t-1)/2 for t in arrival]+[abs(t-2)/2 for t in arrival]
  if N>1:margins+=[abs(x[k]-xx)/2 for j,xx in enumerate(x) if j!=k]
  radius=min([gap/32]+[v/2 for v in margins]);assert radius>0
  def T(t):return t/(2*(z[k]-t))
  left,right=T(x[k]-radius),T(x[k]+radius)
  assert left<F(1,4)<right
  # On each whole interval, all arrival eligibility is stable. Each response
  # derivative is <=2*m_j<=8; a difference has Lipschitz constant <=16.
  assert 16*radius<gap
  for xx in [x[k]-radius,x[k],x[k]+radius]:
   arrivals=[2*(p-xx) for p in z]
   assert all(1<t<2 for t in arrivals[:k+1]) and all(t>2 for t in arrivals[k+1:])
   H=masses[k]/arrivals[k]
   assert H>max([F(1),masses[k]/2]+[masses[j]/arrivals[j] for j in range(k)])
   jac=2*z[k]/arrivals[k]**2
   assert jac==(1+2*T(xx))/arrivals[k] and jac>0
  images.append((left,right));centers.append({'k':k+1,'R':str(R[k]),'winner_gap':str(gap),'x_radius':str(radius)})
 lo=max(t[0] for t in images);hi=min(t[1] for t in images);assert lo<F(1,4)<hi
 for k in range(N):
  for u in [lo,(lo+hi)/2,hi]:
   xx=2*z[k]*u/(1+2*u);RR=2*z[k]/(1+2*u)
   assert abs(xx-x[k])<=F(centers[k]['x_radius'])
   assert xx/RR==u
 # Weighted fee identity on each inverse branch, exact in dimension one:
 # lambda=1, source y=0 of weight1. Original 1/m_k integrates length/m_k;
 # transformed 1/(H*c)=2*z_k/[m_k*(1+2u)^2].
 total=F(0)
 for k in range(N):
  a=2*z[k]*lo/(1+2*lo);b=2*z[k]*hi/(1+2*hi)
  direct=(b-a)/masses[k]
  transformed=z[k]/masses[k]*(1/(1+2*lo)-1/(1+2*hi))
  assert direct==transformed;total+=direct
 return {'N':N,'W':str(masses[-1]),'common_u_interval':[str(lo),str(hi)],'width_display':float(hi-lo),'verified_preimages':N,'exact_source_fee_on_preimages':str(total),'centers':centers}
rows=[witness(N) for N in [1,2,4,8,16,32,64]]
# Singular arrival branch of a unit atom: x in (1/2,1), R=2x, T=1/2.
# Its Lebesgue mass and weak contribution are positive despite zero Jacobian.
assert F(3,4)/(2*F(3,4))==F(1,2)
print(json.dumps({'status':'PASS','scope':'exact rational winner neighborhoods and positive-measure inverse multiplicity, no fitted asymptotic bound','rows':rows,'singular_branch':{'n':1,'source':'delta_0','lambda':'1/4','x_interval':['1/2','1'],'T':'1/2','jacobian':0,'weak_fee':'1/8'}},indent=2,sort_keys=True))
