# R679 S3 independent two-point/all-outside pre-review

Status: FINAL PASS within the bounded scope below. No mandatory mathematical correction found in the finalized REPORT and two author notes. The initial two-point/all-outside deductions and later collision propositions were independently checked before their author treatments. The complete all-outside/pair owner budget is not certified.

## 1. Retained complete demand and whole-key two-point object

Keep the entire R677/R678 original finite input, static radius order, genuine owners, actual disjoint residual receivers Y_b and their complete account. The parent task is a complete budget for that SAME receiver volume V, not a restricted-scale or selected-input statement. The weaker sufficient causal target is D<=C U(T_*^k-1)/k!, or the analogous C tau P0 target. No old exponential exp(-2k) saving is required.

For a core-eligible multi-index m, use its ORIGINAL first-core anchor, halo radius c0 rho_m, intersection I_m and causal future Z_m. At an actual receiver x in Y_b, define z_m(x) by coordinatewise clamping x to the box I_m. Then

    dist_infinity(x,I_m)=||x-z_m(x)||_infinity,
    x in H_m minus I_m iff 0<||x-z_m(x)||_infinity<=c0rho_m.

All sources in this key contain the SAME z_m(x). The exact whole-key causal cost is therefore

    D=integral_Y sum_{eligible m:a(m)<=b(x)} w_m
           1{0<dist_infinity(x,I_m)<=c0rho_m} dx.

Equivalently one can retain the key-dependent measure kernel with a Dirac mass at z_m(x). Its support records a genuine two-point relation (actual x, common clamped z). It is not a Lebesgue density in the z variable and is not a fixed-point multinomial kernel.

## 2. Boundary and moving-projection quantifiers

The global cap g<=tau is a.e. A clamped point lies on source faces, so an unrestricted CLOSED-boundary value g(z) need not satisfy that cap. The key itself has a common inward approach from the positive intersection. A common one-sided directional trace, or a face-free interior approximation, legitimately preserves the tau capacity for the corresponding compatible pool. Combining different approach directions without payment can add otherwise disjoint boundary populations.

For a fixed genuine pair and a common compatible trace pool, the labels that also contain the actual x have rate G<=g_<h(x)<=1. The remaining labels, which contain the common trace point but avoid x, have rate B with G+B<=tau. The exact unrestricted factorial polynomial with at least one outside label is

    [(G+B)^k-G^k]/k!.

There is no premise that exactly one label avoids x, that a key must contain any x-containing label, or that its outside population has small rate. Those would be new assumptions. Every key may have its own clamped point, approach direction, endpoint tags and selected radius; a bound for one fixed pair/pool cannot simply be integrated over the resulting moving singular measure as if that measure were uniform.

For each fixed key, clamping is Lipschitz but collapses normal directions on the collar. Its n-dimensional volume Jacobian is not one there. The correct unit-Jacobian variables are tangential face coordinates together with all active outward offsets, retaining the actual receiving point x. Replacing the moving clamp by a fixed point, a source-independent shift or a random translation requires an exact measure/conditioning argument which has not been supplied.

Thin intersection width is not low source rate. Boundary mass or a key-dependent trace measure cannot be bounded by thin-layer volume times an unproved density cap. Original a.e. Lebesgue load does not automatically give density for the clamped-point marginal or owner-to-face transport.

## 3. Exact outside-label marking for the general collar

Let R_m(x)=sum_i m_i 1_{A_i complement}(x). On the collar R_m(x)>=1. Multiplicity marking gives the exact pointwise identity

    w_m 1_collar(x)
      =sum_{i:m_i>0} q_i 1_{A_i complement}(x)
          [q^(m-e_i)/(m-e_i)!]
          1_collar(x)/R_m(x).

For m=v+e_i with x outside A_i, the denominator is

    R_m(x)=1+sum_j v_j 1_{A_j complement}(x).

Eligibility, causal first-group selection, halo radius, intersection and clamped point must all still be evaluated for the COMPLETE v+e_i. This identity can mark a genuine source owner through q_i=|F_i|/d_i; it does not make the other labels iid from a fixed pool or remove source reuse.

## 4. All-outside weighted cover: independently checked

For x in an actual X_h subset Y_b, let

    b_x=sum_{i in K'_b}q_i1_Ai(x)<=1.

The inequality is the proved whole-B_h admission bound. The core labels avoiding x have total rate T_b-b_x>=T_*-1. Every multi-index supported on this outside subpool is naturally globally core-eligible, has a(m)<=b, and has a halo containing x because its original anchor radius dominates the group's target radii. It is also counted by Z_m. These facts do not require global eligibility to be independent of x.

Define, with complements taken using the SAME parent membership convention,

    D_allout=sum_{eligible m}w_m
        |H_m intersect Z_m intersect intersection_{i in support(m)}A_i complement|.

The exact multinomial identity on the x-dependent outside subpool gives pointwise coverage at least (T_b-b_x)^k/k!, hence

    D_allout >=(T_*-1)^k V/k!,
    D_allout <=D_causal.

The latter follows because a nonempty key whose every parent avoids x certainly has x outside I_m. The entire SAME actual receiver Y remains in the lower bound. This is a recomputed weighted cover, not an arbitrary deletion of inconvenient keys or a local truncation.

Closed-boundary values cause no hidden loss: the admitted whole-box bound controls b_x under the chosen indicator convention. Receiver partition and any null-set representative choices are needed only a.e. for integration. The unrelated global a.e. g cap is not substituted at a clamped boundary point in this argument.

## 5. Uniform constant retained by all-outside restriction

In the stipulated nonempty n>=256 regime,

    k<=129sqrt(n),
    T_*=6144sqrt(n)-(32n)^(-n)>=6143sqrt(n),
    k/T_*<=129/6143<1/40.

Bernoulli's inequality therefore yields

    (T_*-1)^k=T_*^k(1-1/T_*)^k
       >=(1-k/T_*)T_*^k >=(39/40)T_*^k.

This is an analytic all-dimension estimate under the stated parameters, not a numerical probe. A bound D_allout<=C U T_*^k/k! would consequently pay V<=(40/39)C U. The analogous tau P0 version also suffices. The all-outside budget is smaller than the full causal collar, but still unproved.

The same coverage argument is valid for the spatial-full-first variant with its own original-anchor halo and future mask: its first group is at most the first-core group, and both objects are larger. Those costs cannot be silently interchanged. Unlike the earlier unexpanded-term absorption, the all-outside coverage does not count a self-source at x, because all counted labels avoid x.

## 6. Whole-key all-outside owner identity

Let E_m(x) be the indicator of eligibility, a(m)<=b(x), and x in H_m, without the outside factors. Multiplicity marking gives

    D_allout=(1/k)sum_i q_i integral_{Y minus A_i}
        sum_{|v|=k-1} (q^v/v!) E_{v+e_i}(x)
             product_{j:v_j>0}1_{A_j complement}(x) dx.

Every remaining label avoids the SAME actual x; every source still contains the SAME clamped z_{v+e_i}(x). The factor 1/k is exact because every occurrence in an all-outside key is an eligible outside mark. This is also the special case R_m(x)=k of the preceding general-collar marking formula.

Replacing q_i by |F_i|/d_i produces a genuine owner integral, with its original mass and no atoms replacing the actual owners. It preserves the whole-key selection kernel. It is an identity, not a bound for that kernel. The owner point, actual receiver and common clamp cannot be decoupled by assuming an unproved density, Jacobian or conditional law.

## Preliminary disposition

Legal: actual-x/common-key-clamp representation; compatible inward traces; exact multiplicity/outside marking; genuine owner integration; and the all-outside cover retaining at least 39/40 of the normalized whole-receiver weight.

Still required: a global actual-receiver/owner estimate for the selected all-outside two-point kernel (or another complete packing), preserving every first-group, radius, direction and multiplicity condition. No moving-projection/Fubini shortcut presently supplies it. No R679 author text was read in forming this pre-review; no subagent, Git/PDF action or numerical rerun was used. Only S3_REVIEW.md is written.

## 7. Same-direction collision cover: independently checked next candidate

This additional pure-cover proposition was independently checked before reading an author treatment. For an outside label i at actual x, choose its smallest violated coordinate j(i,x) and its violation sign. This choice depends only on (i,x), so it defines a common measurable global key property; it is not redefined separately for each witnessing group.

Fix the local outside subpool of K'_b at x. Every one of its parents contains z_b. If x exceeds a parent's upper endpoint in coordinate j, then z_b,j<x_j; if x is below a lower endpoint, then z_b,j>x_j. Thus in a fixed coordinate only one sign can occur in this common-point subpool. There are at most n direction classes, not 2n.

Let R=T_b-b_x be the outside rate and p_j the normalized class rates, padded by zeros to n classes. For k iid label OCCURRENCES, the probability of no repeated direction is

    k! e_k(p) <=(n)_k/n^k
              <=exp(-k(k-1)/(2n))

when k<=n, and is zero when k>n. The first bound follows by averaging two p coordinates at fixed sum: their only nonlinear contribution to e_k is the nonnegative multiple p_i p_j e_(k-2) of the other coordinates, maximized by equalization. The maximum is the uniform n-class vector. The second bound is the product inequality log(1-u)<=-u.

At the actual prescribed parameters,

    k(k-1)/(2n)>=8192-64/sqrt(n)>=8188.

Consequently the multi-index subfamily having a same-direction collision carries local factorial weight at least

    (1-exp(-8188)) R^k/k!
      >=(1-exp(-8188))(39/40)T_*^k/k!.

Every such local key is already globally eligible and retains its original causal halo cover. Therefore its GLOBAL all-outside collision subkernel still covers the complete same V with that constant. This is a genuine cube/common-point cover property, not a paid pair budget.

Multiplicity matters: a collision is two label occurrences sharing a direction. A repeated source m_i>=2 qualifies. If a subsequent geometric payment needs two DISTINCT source labels, that stronger property requires a separate subtraction or argument. The displayed probability does not supply it by terminology alone.

This is a mathematically valid next candidate. No global same-direction-pair transport/owner fee is proved. The collision restriction does not conflict with the all-outside reduction; both preserve quantitative weighted coverage rather than discard receivers.

## 8. Distinct-source same-direction pairs retain over 97 percent

Independently checked the supplied refinement before reading an author treatment. In the fixed local outside pool, R>=T_*-1>=6142sqrt(n), and max_i q_i<=a^(-n). The iid union bound gives

    P(any repeated source label)
       <=binom(k,2)sum_i(q_i/R)^2
       <=binom(k,2)max_i q_i/R
       <=16641 n/[2*6142sqrt(n)*(32n)^n]
       <=16641/[2*6142*1024*n^(3/2)] <1/1000.

The penultimate step uses n>=256, hence (32n)^n>=(32n)^2. The last estimate is uniform in the entire stipulated regime. Also the no-direction-collision probability is at most exp(-8188)<2^(-10)<1/1000. Thus the event of a direction collision and NO repeated source has probability at least 499/500. In particular the event of a same-direction pair of DISTINCT original sources has at least that probability.

Combining with the all-outside cover yields the complete pointwise factorial-weight lower bound

    (499/500)(39/40) T_*^k/k!
      = (19461/20000) T_*^k/k!
      > (97/100) T_*^k/k!.

Global eligibility, first-group halo coverage and causal reception are unchanged. The direction selection is the same fixed function of (i,x), so the global key property is measurable and consistent across the different local covering pools. The inequality comes from a whole-key weighted cover, not unweighted pair counting.

For clarity, the proof lower-bounds the stronger subfamily with all k source labels distinct and a direction collision. If the later cost is defined more broadly by merely requiring a distinct-source pair, that family can still contain other repeated labels; one must not silently assume all its labels are distinct. Either family has the displayed lower cover if defined explicitly. No pair payment, transport bound or root-order improvement follows from this probability/cover refinement alone.


## 9. Final three-text mathematical comparison

Read REPORT.tex and both author notes, A1_TWO_POINT_BUDGET.md and S2_JOINT_TRANSPORT.md, including the finalized A1 clarifications. The full receiver account, all-outside 39/40 cover, distinct-source pair cover exceeding 97/100, core/full-first distinction, common-clamp boundary conditions and unproved global payment agree with the independent derivations above. No mandatory mathematical correction remains.

The one-coordinate center implication is valid. For a same-direction pair with s_i>=s_j>=rho_m, the two near endpoints lie between x_l and the common clamped coordinate, with separation at most c0rho_m. Thus |y_i,l-y_j,l|<=s_i-s_j+c0rho_m<=c0s_i. This does not establish the other n-1 center coordinates. A1's listed dimension-256 local diagnostic indeed has common z, both sources outside x in the first coordinate, and second-coordinate center separation 9/5>c0, so full expanded-center containment fails. This is a diagnostic of that implication, not a high-rate admitted instance or a global counterexample.

S2's exact identity dist_infinity(x,I_m)=max_i dist_infinity(x,A_i) is valid because the nonempty intersection is an axis-parallel product. It gives the whole-key product of tests 0<delta_i(x)<=c0rho_m, retaining all-outside membership and the selected radius. Its stated Stieltjes rewriting does not remove key selection or common-intersection conditions.

Deleting occurrences to a positive-degree subkey legally moves first-core eligibility earlier, enlarges its intersection, original-anchor halo and future receiver mask, and weakens its outside constraints. This is a geometric monotonicity of the ALL-OUTSIDE kernel, not of the pair event after its pair is removed. S2 makes the correct distinction. Its added-pair marked sum is an upper bound: for a fixed retained m its coefficient is multiplied by the sum of m_i m_j over distinct collision pairs, which is at least one when the pair event holds. The overcount and its possible size are not hidden as a gain. The true owner F_i/F_j integral is exact but still leaves the complete selected-pair kernel unpaid.

A1's field inequality g_<=h(z)-L<=G_h(x,z)<=g_<=h(z)<=tau is correctly stated only for a.e. Lebesgue z (or an explicitly compatible boundary trace). It does not evaluate arbitrary closed-face clamp points using the global a.e. cap.

For the normalized common-point representation, F_m(x)=I_m intersect (x+c0rho_m Q) has positive volume beta_m(x) on int(H_m). The finalized outer integral is restricted to this domain, and the omitted halo boundary is null. The bracket integral_Fm dz/beta_m(x) is exactly one there. Tonelli and the whole-key dependence are valid. For the listed square diagnostic beta(x)=epsilon^2 follows directly from its interval overlaps. This does not justify taking beta_m^(-1) outside the key sum or using it as a bounded global density. The source, first group, halo, actual receiver and inverse fiber remain coupled.

## 10. Saved algorithm and metadata audit

Read CROSSING_CHECK.py and DIRECTION_CHECK.py in full without executing either. Inspected the two final results' headers, definitions, scope, counts, stage metadata and stored constant summaries; no per-cell or per-key manual data audit is claimed.

The crossing algorithm reconstructs the saved actual rational strips, uses strict original P minus its anchor rather than a hard K', deduplicates complete multi-indices, and partitions positive H_m/receiver intersections at every support-source face. Midpoint membership is constant on each positive subcell, so its Fraction volumes correctly represent the recorded crossing multiplicity R_m including repeated labels. It separately verifies the local all-outside multinomial on actual receiver cells, integrates it, and compares it with the global R_m=k cost. Its once-marked m_i/R_m calculation is applied only for R_m>0. The metadata records 120 records, 3547 crossing cells, 984 additional local outside cells in the report's saved aggregates, and agreement with all 60 previous causal reference records. These are low-threshold degrees-at-most-six structural checks, not empirical tests of 39/40 retention or the high-rate pair budget.

The direction algorithm uses exact elementary-symmetric coefficients for uniform/sparse/concentrated rational vectors; checks uniform equality and k>n zero cases; and checks the stated range constants using rational reductions. The saved 117 records and stage counts 30/33/54 match the algorithm. Its constants 16641/51522830336, 1/8189 and 19461/20000 match REPORT's stated scope. It contains no geometry input and does not empirically verify the common-point sign lemma, actual direction classification or global owner payment. Those cover statements were independently checked analytically above.

A read-only JSON structural comparison confirmed that CROSSING_AGGREGATES.json equals CROSSING_SUMMARY.json after removing ONLY each record's per_key field, with the two added provenance fields archive_note and full_result_sha256. This was a serialization/provenance check, not a rerun of cells or numerical identities. All 120 aggregate records remain. Their individual cells were not manually examined by this reviewer. Script hashes match their result metadata; the prior input and prior causal reference remain externally referenced by hash rather than duplicated.

## Final disposition and artifact binding

FINAL PASS covers the exact whole-key two-point/moving-clamp conditions; actual all-outside weighted cover; uniform 39/40 and over-97/100 distinct-source same-direction cover constants; one-coordinate capture and its n-dimensional limitation; nonempty-box distance identity; lower-degree geometry monotonicity; valid pair marking/owner integrals; finalized a.e. and positive-fiber quantifiers; and bounded report/source/metadata consistency.

No complete D_out or D_pair upper bound, all-coordinate owner/receiver transport, cumulative source payment, general root-order bound, hard-near counterexample or impossibility theorem is certified. Local diagnostics and finite probability/crossing checks are not promoted to such claims. The complete SAME actual receiver objective and original full-family P0 remain in every stated sufficient target.

Final SHA-256 values under /Volumes/data/CodexTemp/centered-cube-r679-20261115:

- REPORT.tex: af44f05bdf13bc3b71a73bc7234b30a360f18b24b003847a0da76a33676bcbd0
- A1_TWO_POINT_BUDGET.md: 667e201571dbd906bff1e8e51ececa54868149c8022cf0d064605e4b94138639
- S2_JOINT_TRANSPORT.md: 978ae4172e33d72b5cd92fde0b614480d46a5dbd865d18b1cf59ac6a8dcb9c7a
- CROSSING_CHECK.py: 9ed7520e3a692afb5f7944773e7d56a427df47cbefcb6f041cb19eff72c7ae40
- CROSSING_AGGREGATES.json: c55d5e4287bf491797f92fd9591e30c944e5e633526fc19ff0580ddaf2089f98
- DIRECTION_CHECK.py: dfd8129a6da547024dc4b99f305e763103ca466afd3284a85cec8daa997fb0f3
- DIRECTION_RESULT.json: 941f95b5e732a053c2bfeb829a293e38029ab9c1fa2717691015d77eddba9b01

Referenced prior input SHA-256: 51133281e98e46889690d01d1a3a47a114c6dad79ec123cb9d3929f95e16d642. Referenced prior causal summary SHA-256: 91a2483ee382ee8a21226544460e857820d3ee2dc69aa5109e09effd65dad944. Hashes bind artifacts, not independent mathematical or per-cell correctness. Only S3_REVIEW.md was written by this reviewer. No subagent, Git/PDF action or numerical experiment rerun was performed. Bounded audit complete; stop.
