# R679 A1 — whole-key two-point traffic after all-out and distinct-pair restriction

## Result

No complete owner budget or original-family packing estimate is proved. The precise new restriction is legitimate for the whole receiver cover: one may retain only keys for which every source avoids the actual receiver, and then only keys having two distinct sources with the same first violated coordinate and sign. More than 97/100 of the T_min^k weighted cover remains. This is a whole-key event; the other labels, the halo, and the actual causal receiver mask are retained.

The pair condition supplies one coordinate of expanded-center containment. It has not supplied containment in all coordinates, which is required by the original admission budget. An exact common-point fiber representation makes the other missing cost explicit: its inverse fiber volume depends on the entire key and cannot be removed when applying the original q-load bound. Neither obstruction is asserted to prove the desired estimate impossible.

## 1. Unchanged full-family contract

Use the R677–R678 ordered groups, actual disjoint receivers Y_b, strictly earlier cores K'_b, and eligible multiindices m of size k. Let

    T_b=sum_{i in K'_b}q_i>T_min=3tau/8-a_geom^(-n),
    tau=16384 sqrt(n), a_geom=32n, c0=1+1/a_geom,
    k=ceil(128 sqrt(n)), n>=256.

An eligible key is supported on some K'_b. Its weight is w_m=q^m/m!, with repetitions retained. The intersection I_m is nonempty and has positive widths. Either of the following versions can be used, consistently:

* Core-first: a(m) is the first b with support(m) contained in K'_b.
* Full-first: a(m) is the first b with support(m) contained in the complete saturated P_b; the eligible key set is still the core-eligible set.

Set rho_m=s_{r_{a(m)}}, H_m=I_m+c0 rho_m Q, and E_m=union_{b>=a(m)}Y_b. The radius is the original anchor radius. In the full-first version every earlier chosen witness is outside I_m. The core-first version does not automatically have that spatial property. Full-first halos and masks are larger, so their costs cannot be replaced by core-first costs for free.

For either version, every key supported on K'_b covers the entire actual Y_b and has b>=a(m). The earlier causal absorption remains valid: its unexpanded coefficient is 1 in the strict core-first account and L=1+a_geom^(-n) in the full-first account. The original P0 still ranges over all original parents, not just q support.

## 2. All sources may be required to avoid the receiver

Fix x in an actual X_h contained in Y_b. Strict core history and expanded-center admission give

    b_x=sum_{i in K'_b}q_i1_Ai(x)<=1.

The sources of K'_b whose parents avoid x therefore have rate

    T_out(x)=T_b-b_x>=T_min-1.

All multiindices on this outside subfamily are still eligible, and their earliest halo and causal mask cover x. Define the complete all-out cost

    D_out=sum_m w_m
       |H_m intersect E_m intersect intersection_{i in support(m)}A_i^c|.

The multinomial identity yields

    (T_min-1)^k V_rem/k! <=D_out<=D_causal.                 (1)

Here D_causal denotes the corresponding version's halo-minus-intersection expense. Since every source avoids x, such an x is outside I_m automatically.

In the hard regime k<=129 sqrt(n) and T_min>=6143 sqrt(n), hence k/T_min<1/40. Bernoulli's inequality gives

    (T_min-1)^k>= (1-k/T_min)T_min^k
                   >=(39/40)T_min^k.                      (2)

Thus all-out is a constant-loss restriction on the same complete demand, not a selected receiver subfamily or a new measure.

## 3. A distinct same-direction pair also preserves the complete cover

For an outside source at x, assign the first coordinate in a fixed coordinate order in which x violates the source interval, together with its sign. In any common-point source pool, opposite signs cannot occur on the same coordinate: they would exclude a common point. Consequently there are at most n direction categories for the outside sampling law of K'_b.

Draw k labels iid from that outside law. For k<=n, the elementary-symmetric-polynomial bound gives

    P(no direction collision)<=(n)_k/n^k
       <=exp[-k(k-1)/(2n)]<=exp(-8188)<1/1000.

For k>n this probability is zero. To avoid relying on a repeated label as an empty pair, separately bound

    P(any repeated source)
      <=binom(k,2) max_i(q_i/T_out)
      <=16641/[2*6142*1024*n^(3/2)]<1/1000.                (3)

Here T_out>=6142 sqrt(n), q_i<=a_geom^(-n), and a_geom^(-n)<=1/(1024n^2) were used. Therefore the event that two distinct sources share a direction has probability at least 499/500. It is a permutation-invariant whole-key condition, so it passes directly to multiindex weights.

Let D_pair be D_out with the additional indicator that the key has such a distinct-source direction pair at the actual receiver x. Then

    D_pair >=(499/500)(39/40) T_min^k V_rem/k!
            >(97/100) T_min^k V_rem/k!,
    D_pair<=D_out<=D_causal.                               (4)

These inequalities remain true for the full-first version with its own larger halo and mask. They do not provide an upper bound on D_pair. A bound D_pair<=C U T_min^k/k!, or the analogous bound with tau P0, would suffice for the unchanged objective. That is the missing global estimate.

## 4. What a same-direction pair actually implies geometrically

Suppose two distinct key sources i,j have s_i>=s_j>=rho_m, share a common point z with ||x-z||_infinity<=c0 rho_m, and violate x in the same oriented coordinate ell. In the upper-violation case their upper endpoints U_i,ell and U_j,ell lie between z_ell and x_ell, so

    |U_i,ell-U_j,ell|<=c0 rho_m.

Since y_i,ell=U_i,ell-s_i and y_j,ell=U_j,ell-s_j,

    |y_i,ell-y_j,ell|
       <=s_i-s_j+c0 rho_m
       <=s_i+(c0-1)s_j<=c0s_i.                             (5)

The reflected lower-violation case is identical. Thus the smaller source center is contained in the larger source's c0-expanded interval in that one coordinate. This is a real geometric consequence of the pair event, not merely a collision count.

It is not full expanded-parent containment. The first-violated-coordinate rule does not fix this: in other coordinates two intervals may both contain x and the common intersection while excluding each other's centers. The original center-admission estimate sums sources only when **every** coordinate contains the later center. Applying its load-one conclusion after (5) alone would omit the remaining coordinate constraints.

An exact local diagnostic illustrates this. In dimension n=256, with both source radii one, take

    y_i=(0,-9/10,0,...,0),
    y_j=(1/5,9/10,0,...,0),
    z=(9/10,0,...,0),       x=(3/2,0,...,0).

Both cubes contain z, both avoid x in their first coordinate with the same positive sign, and ||x-z||_infinity=3/5<=c0. Coordinate 1 satisfies (5). But neither center is in the other's c0-expanded full cube, due to coordinate 2. This is a local test of the proposed pair-to-admission implication, not a high-rate eligible family or a counterexample to the global estimate.

## 5. The exact two-point density and its unpaid cost

The low receiving load has a definite direction of implication. For an actual receiver X_h, let

    G_h(x,z)=sum_{i<=h}q_i1_Ai(z)1_Ai^c(x),
    g_<=h(u)=sum_{i<=h}q_i1_Ai(u).

In the full-first causal account, g_<=h(x)<=L. Therefore, for Lebesgue-almost every z,

    g_<=h(z)-L<=G_h(x,z)<=g_<=h(z)<=tau.                    (6)

This a.e. statement suffices for the subsequent dz integration. The last inequality is not asserted at an arbitrary closed-face clamp point; a boundary evaluation would require a specified common inward trace.

The low value at x does not give a smaller pointwise upper bound for the all-out field at z. At a high common point it shows that almost all that high rate may be outside x. A contraction must come from the joint spatial measure or genuine source-owner allocation, not from replacing G_h(x,z) by L.

There is an exact whole-key common-point representation retaining every coordinate. Put r_m=c0 rho_m and, for x in the interior of H_m, define

    F_m(x)=I_m intersect (x+r_m Q),
    beta_m(x)=|F_m(x)|
      =product_j [min(U_m,j,x_j+r_m)
                    -max(L_m,j,x_j-r_m)]_+.

This volume is positive almost everywhere in H_m. Let A_m(x) be the indicator of E_m, all sources outside x, and the distinct same-direction pair event. Then

    D_pair=sum_m w_m integral_{int(H_m)} A_m(x)
               [integral_{F_m(x)} dz / beta_m(x)] dx.       (7)

The outer integral is explicitly restricted to the interior of H_m, where beta_m(x)>0. The omitted halo boundary is null. The bracket equals one on this integration domain. Tonelli applies. No independent coordinate law, projected receiver mask, or missing Jacobian is used in (7).

For a fixed common point z and prefix, original q-load can count the unweighted label condition through G_h(x,z)^k/k!. But beta_m(x)^(-1), the halo radius, and the earliest group depend on the entire key. Pulling that density outside the key sum has no supplied bound. Even for a fixed simple box, it diverges near an outer halo corner: for I=[-1,1]^2, r=1, and x=(2-epsilon,2-epsilon), beta(x)=epsilon^2. Its exact cancellation is with that key's own integration fiber, not with an unrelated aggregate source-load bound.

The clamp map x to projection_{I_m}(x) has the same issue in geometric form. It sends positive-volume collars to lower-dimensional faces and does not have a unit n-dimensional Jacobian. Valid face coarea retains the corresponding traces and all coordinate offsets; it does not transfer the low-load receiver indicator to the projected point. Likewise, the R673 two-point lens estimate concerns sources containing its two comparison points; it cannot be invoked for the two external endpoints x and a source owner when those sources can avoid them in different coordinates.

Thus the unpaid step is a joint estimate for (7), or an equivalent whole-product trace, that uses the actual owner disjointness and history while retaining its full inverse-fiber density. The pair restriction supplies (5), but no proof converts that one-coordinate capture into the required complete source debit.

## Verification and stop

One local Python Fraction calculation verified the dimension-256 pair diagnostic: both sources contain z and avoid x, coordinate-1 expanded-center capture holds, and full expanded-center capture fails in both directions. It also checked the separate fiber volumes epsilon^2 for epsilon=1/10 and 1/100, giving inverse volumes 100 and 10000. These are exact local geometry checks only; neither is a high-rate example or evidence against the final theorem. The all-out and distinct-pair cover estimates are analytic, not inferred from those tests.

No full global owner or P0 budget is claimed. The complete receiver cover has been restricted at constant loss to an all-out, distinct same-direction pair event, but its all-coordinate joint payment remains open. No new prefix dilution, high-fraction optimization, historical scan, child agent, Git operation, PDF, MATLAB session, or edit to another agent's file was performed. Work stops at this bounded checkpoint.
