#!/usr/bin/env python3
"""Finite iid direction-class coefficient checks and exact n>=256 constants; no geometry/pair budget."""
from pathlib import Path
from fractions import Fraction as F
from math import factorial,prod
import json,sys,platform,hashlib,time
BASE=Path(__file__).resolve().parent

def enc(x):
    if isinstance(x,F):return str(x)
    if isinstance(x,dict):return {str(k):enc(v) for k,v in x.items()}
    if isinstance(x,(tuple,list)):return [enc(v) for v in x]
    return x

def elementary(p,k):
    if k>len(p):return F(0)
    e=[F(1)]+[F(0)]*k
    for j,x in enumerate(p):
        for d in range(min(k,j+1),0,-1):e[d]+=x*e[d-1]
    return e[k]

def run():
    start=time.time();records=[]
    stages=[('initial',[2,3,4]),('pressure',[8,16]),('expanded',[32,64,128])]
    for stage,ns in stages:
        for n in ns:
            sparse=max(1,n//4)
            distributions=dict(uniform=[F(1,n)]*n,sparse=[F(1,sparse)]*sparse+[F(0)]*(n-sparse),concentrated=[F(3,4)]+[F(1,4*(n-1))]*(n-1))
            ks=sorted({k for k in (1,2,4,8,16) if k<=n}|{n+1})
            for label,p in distributions.items():
                assert len(p)==n and sum(p,F(0))==1 and min(p)>=0
                for k in ks:
                    ek=elementary(p,k);prob=factorial(k)*ek
                    bound=F(prod(range(n-k+1,n+1)),n**k) if k<=n else F(0)
                    assert 0<=prob<=bound<=1
                    if label=='uniform':assert prob==bound
                    if k>n:assert prob==bound==0
                    records.append(dict(stage=stage,n=n,k=k,distribution=label,p=p,elementary_symmetric=ek,no_collision_probability=prob,falling_factorial_uniform_bound=bound,collision_probability=1-prob,uniform_collision_lower_bound=1-bound,k_exceeds_n=k>n,all_checks_passed=True))
    # Symbolic range reductions use only exact rational arithmetic and the
    # monotonic implications n>=256 => sqrt(n)>=16 => n**(3/2)>=4096.
    nmin=256;sqrt_min=16
    assert sqrt_min**2==nmin
    source_repeat_at_min=F(16641,2*6142*1024*nmin*sqrt_min)
    assert source_repeat_at_min<F(1,1000)
    exponent_lower=F(128**2,2)-F(128,2*sqrt_min)
    assert exponent_lower==8188
    # exp(t)>=1+t for t>=0: e^-8188 <=1/8189<1/1000.
    exponential_upper=F(1,1+8188)
    assert exponential_upper<F(1,1000)
    collision_cover=1-F(1,1000)-F(1,1000)
    assert collision_cover==F(499,500)
    combined=F(39,40)*collision_cover
    assert combined==F(19461,20000) and combined>F(97,100)
    # k=ceil(128sqrt(n)) <=129sqrt(n) for n>=1, and max qi<=
    # (32n)^-n <=(1024n^2)^-1 for n>=2. These symbolic implications
    # produce the range-wide repeat bound verified at nmin above.
    constants=dict(n_min=nmin,sqrt_n_min=sqrt_min,k_rule='ceil(128*sqrt(n))',k_upper_factor=129,k_squared_upper_factor=16641,max_q_bound='(32n)^(-n) <= 1/(1024*n^2) for n>=2',Tout_lower_factor=6142,source_repeat_union_bound='16641/(2*6142*1024*n^(3/2))',source_repeat_upper_at_n_min=source_repeat_at_min,source_repeat_threshold=F(1,1000),source_repeat_strict_margin=F(1,1000)-source_repeat_at_min,birthday_exponent_lower=exponent_lower,birthday_reason='k(k-1)/(2n) >=8192-64/sqrt(n)>=8188 for n>=256; if k>n no-collision is exactly zero',exponential_majorant_reason='exp(8188)>=1+8188, hence exp(-8188)<=1/8189<1/1000',exponential_rational_upper=exponential_upper,no_collision_threshold=F(1,1000),collision_cover_lower=collision_cover,local_outside_retention_factor=F(39,40),combined_cover_lower=combined,target=F(97,100),combined_margin=combined-F(97,100),all_checks_passed=True)
    stage_counts={s:sum(R['stage']==s for R in records) for s,_ in stages}
    result=dict(title='R679 finite direction-class probability coefficients and exact constants',python=sys.executable,python_version=sys.version,platform=platform.platform(),script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),command=[sys.executable,str(Path(__file__).resolve())],elapsed_seconds=time.time()-start,input_policy='No geometry input and no external dataset: all rational probability vectors and nmin constants are explicitly generated in this script and saved in records.',formula='iid k tags have no repeated direction class with probability k!*e_k(p); this is <=(n)_k/n^k, with 0 when k>n.',record_count=len(records),stage_counts=stage_counts,records=records,constants=constants,all_checks_passed=True,scope='Finite probability-parameter checks and exact range-constant arithmetic only. Uniform/sparse/concentrated class vectors for n=2,3,4,8,16,32,64,128 and k in {1,2,4,8,16} where legal plus n+1. No geometric direction classification, common-z sign lemma, pair budget, or high-tau absorption is empirically certified. The 39/40 factor is an analytic premise, not a low-tau numerical finding.')
    (BASE/'DIRECTION_RESULT.json').write_text(json.dumps(enc(result),indent=2)+'\n')
    print(json.dumps(enc(dict(all_checks_passed=True,records=len(records),stage_counts=stage_counts,constants=constants,script_sha256=result['script_sha256']))))
if __name__=='__main__':run()
