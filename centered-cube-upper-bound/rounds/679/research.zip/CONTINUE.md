# R679 checkpoint

General pure C_n<=K sqrt(n) and earlier n^(1/2+o(1)) goal remain unproved. Read REPORT.tex and the final independent review, not only this checkpoint. All original finite-family variables, true source owners, actual receiver union, history and far/upper account are unchanged.

Proved: local core original load at an actual receiver <=1 allows ALL key sources to avoid that receiver, retaining >=39/40 of the uniform T_*^k cover. Cube coordinate directions then permit restriction to a same-directed-coordinate pair of DISTINCT sources, retaining >97/100 of that cover after explicitly paying duplicate-label probability. This is a complete-receiver covering reduction, not a source-budget theorem. It applies consistently with core-first or larger full-P-first halos/masks; their costs cannot be interchanged for free.

The pair yields one coordinate of expanded-center capture. The other n-1 coordinates and moving common intersection still lack an owner-paid joint estimate. Next work must attack that COMPLETE pair kernel or a true contraction with full fees; do not make another round of scalar birthday constants, local face orders, marker identities or source-field normalization into the main task. Source deletion enlarges the shorter-key geometry, but does not pay the added pair. Marking overcounts pair multiplicity; no negative or missing factorial may be assumed.

Original q-load at a common point is only a.e. (or requires a compatible inward trace). A1's common-point fiber formula integrates only inside H_m and retains beta_m(x)^(-1); neither a boundary clamp nor that inverse-volume density can be discarded. Low load at receiver x does not make the outside source field small at z.

## Reproduction

Use `/Users/zzh/.local/share/math-research-tools/venv/bin/python`.

1. From R677 research.zip obtain WITNESS_RESULT.json; required SHA256 51133281e98e46889690d01d1a3a47a114c6dad79ec123cb9d3929f95e16d642.
2. Optional independent comparison input from R678 research.zip: CAUSAL_SUMMARY.json, SHA256 91a2483ee382ee8a21226544460e857820d3ee2dc69aa5109e09effd65dad944.
3. Run CROSSING_CHECK.py --input /actual/path/WITNESS_RESULT.json --causal-reference /actual/path/CAUSAL_SUMMARY.json. The latter option may be omitted; then no previous-round equality check is claimed. It writes CROSSING_SUMMARY.json (full per-key output retained locally). The archive contains CROSSING_AGGREGATES.json, all 120 aggregate and per-group records with only per_key omitted, plus its original full-result hash.
4. Run DIRECTION_CHECK.py to reproduce the 117 exact finite probability cases and constant calculations. These do not certify direction geometry or any pair budget.
5. Run verify.py for 237 exact aggregate/probability rechecks, final file bindings and manifest. Volatile execution metadata can change result hashes on rerun; compare mathematical records.

All crossing geometry is finite LOW tau, n<=6, k<=6 with strict P minus anchor, not the hard K' construction. Reused trailing zero center coordinates limit the experiments. Actual hard-regime retention constants are analytically proved and independently reviewed, not inferred from these tests. MATLAB not opened, PDF not compiled.

Configuration at most 1 Astra and 3 GPT-6.1 Sol active. Only compact completed-round archive and README changes enter the repository; preserve one independent commit and verify remote receipt. Latest actual Git status must be checked next turn.
