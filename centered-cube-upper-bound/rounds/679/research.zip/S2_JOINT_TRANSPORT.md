# R679 S2 — whole-key all-outside transport and the unpaid same-direction pair capacity

**Bounded status.** The whole-key outside kernel admits an exact distance/transport formulation. Almost the full real receiving objective can be retained on keys with a collision of TWO DISTINCT sources in one violated coordinate. Such a pair has a genuine geometric relation: the smaller source's center is captured by the larger source's c0-expanded interval in that ONE coordinate.

This does not establish full n-dimensional center capture or an owner-paid pair budget. Source deletion is geometrically monotone, but summing the added pair after deletion still involves a moving common point depending on the complete key. No global bound for the full all-outside cost is proved.

The next joint geometric step is therefore precise: pay the remaining coordinates of this true two-source/real-receiver kernel, rather than treat a birthday collision as free. No codimension expansion, local-order optimization, poolwise iid sum, generic dual normalization or abstract counterexample is introduced.

Only this file is written. The original q, owners, self-corrected cores, parents and new residual classification remain fixed. No child, Git, PDF, MATLAB or new numerical task is opened.

## 1. Exact original-key quantities

Let T_*=3tau/8-a_geom^(-n), a_geom=32n, and k=ceil(128sqrt(n)), n>=256. The actual cores K'_a have rate greater than T_*. Their sources strictly precede every target in their groups. The actual remaining receiver union is Y=disjoint union_a Y_a.

For an eligible multiplicity key m, let

    a(m)=earliest core containing support(m),
    rho_m=s_{r_{a(m)}},
    I_m=intersection_{i:m_i>0}A_i,
    H_m=I_m+c0rho_m[-1,1]^n,
    Z_m=union_{b>=a(m)}Y_b,
    w_m=product_i q_i^(m_i)/m_i!.

The radius is the ORIGINAL anchor radius. Core first eligibility is not spatial first hit; no full-population first-hit property is inserted.

Define the full outside cost

    D_out=sum_m w_m
       |H_m intersect Z_m intersect intersection_{m_i>0}A_i^c|. (1)

This is a positive subkernel of the causal boundary. Its budget is not inherited from the corresponding whole causal cost.

## 2. The low real-receiver load permits all-outside coverage

Fix x in a real X_h belonging to group b. All K'_b sources precede h. Original center admission gives their full load at x at most one:

    b_x=sum_{i in K'_b}q_i1_{A_i}(x)<=1.

The outside pool in this ONE actual core therefore has rate

    T_out(x)=sum_{i in K'_b:x notin A_i}q_i
       >=T_*-1.

Every key from this pool is globally eligible, its first core is at or before b, and its intersection contains the group's shared z_b. Its H_m contains x and its causal Z_m contains X_h. Hence the multinomial formula yields

    (T_*-1)^k Vrem/k!<=D_out.                               (2)

No old source class, Poisson law or loss-row self term is silently omitted. Strict source priority comes from the core with the anchor self label explicitly removed.

For the actual parameters k/T_*<1/40, so Bernoulli's inequality gives

    (T_*-1)^k >=(39/40)T_*^k.                               (3)

Equations (2)-(3) are a COVER reduction, not a payment of (1).

## 3. A whole-product distance representation

For a source put delta_i(x)=dist_infinity(x,A_i). Since I_m is a nonempty box,

    dist_infinity(x,I_m)=max_{i:m_i>0}delta_i(x).

Therefore the kernel in (1) is exactly

    1_{Z_m}(x)
      product_{i:m_i>0}1{0<delta_i(x)<=c0rho_m}.              (4)

This keeps the entire key product and every source's outside condition. It avoids selecting one mixed face or dropping projected coordinates.

Equivalently, the last upper-threshold test is the Stieltjes layer at
r=max_i delta_i(x)/c0, integrated up to the key-dependent rho_m. Nonnegative Tonelli permits swapping this layer, real receiver integration and the finite key sum.

However the common point in the source intersection, and the upper radius selector a(m), still depend on ALL labels. There is no proved fixed common-point q-capacity after that interchange. Replacing it by a single outside-shell q field would drop the key's common-intersection/first-core restriction; no bound for such an enlarged field is asserted.

## 4. Collision coverage uses actual coordinates and distinct sources

For each outside source at a fixed x, assign its first violated coordinate l(i,x), with the sign determined by which side of its interval x lies on. This assignment depends only on that source and x.

In any eligible all-outside key, two sources with the same violated coordinate cannot have opposite signs: one parent would lie strictly below x and the other strictly above x in that coordinate, contradicting their nonempty intersection. Thus there are at most n coordinate colors within a key, and a same-coordinate collision is a same-directed-coordinate collision.

For the local iid rate law of the outside pool in Section 2, the probability of no coordinate collision is at most

    exp(-k(k-1)/(2n))<=exp(-8188)<1/1000.                    (5)

If k>n, no collision has probability zero. Otherwise the elementary symmetric-polynomial/Maclaurin bound gives at most (n)_k/n^k, followed by log(1-t)<=-t. This use of the iid law is LOCAL to the actual covering pool, not an assertion about the selected global key-volume law.

Repeated occurrences of the SAME label are not a distinct-owner pair. Their local probability is at most

    binom(k,2) sum_i(q_i/T_out)^2
       <=binom(k,2)a_geom^(-n)/(T_*-1)
       <=16641/[2*6142*1024*n^(3/2)]
       <1/1000.                                           (6)

Here k<=129sqrt(n), T_*-1>=6142sqrt(n), and
a_geom^(-n)<=1/(1024n^2) for n>=256. No duplicate owner is charged as two genuine source pieces.

Consequently the subcost D_pair of (1), restricted at x to keys with a same-coordinate pair of DISTINCT labels, still satisfies

    (97/100)T_*^k Vrem/k!<=D_pair<=D_out.                   (7)

Indeed (39/40)(1-1/1000-1/1000)>97/100. This retains a large fixed portion of the COMPLETE real objective. It does not upper-bound D_pair. The elementary collision estimates themselves are not counted as a source budget.

## 5. The true one-coordinate center relation

Consider one such full key at x. Let u be the coordinate clamp of x to I_m. Then u lies in EVERY key parent and

    ||u-x||_infinity<=c0rho_m.

Suppose distinct sources i,j violate the same coordinate l in the same direction, and s_i>=s_j>=rho_m. For the direction in which both source intervals lie above x_l, write their near endpoints as L_i,L_j. They obey

    x_l<L_i,L_j<=u_l.

Their center coordinates are L_i+s_i and L_j+s_j. Therefore

    |y_i,l-y_j,l|
      <=s_i-s_j+|L_i-L_j|
      <=s_i-s_j+c0rho_m
      <=s_i+(c0-1)s_j
      <=c0s_i.                                            (8)

The opposite direction is identical using the upper endpoints. Thus the smaller center DOES satisfy the expanded admission interval test in that coordinate.

But the other n-1 coordinates are not supplied by (8). Containment of the shared u in both parents only gives their ordinary overlap constraints there, not y_j in the complete Q(y_i,c0s_i). Original center admission is a full n-dimensional test. It cannot be applied to (8) alone.

No assertion that a same-direction collision is free, a full center edge, or a pair of disjoint newly available owner pieces is made.

## 6. Source deletion is monotone, but the pair summation is not paid

Delete one occurrence, or two distinct colliding labels, while leaving positive total degree. For the shorter key m' one has

    a(m')<=a(m),  rho_m'>=rho_m,
    I_m' contains I_m,
    H_m' contains H_m,
    Z_m' contains Z_m.

The outside constraints also weaken. Thus the full pointwise kernel in (1) for m is bounded by that of m'. This monotonicity is valid for CORE eligibility without pretending it is spatial first hit.

It does not yet provide a numerical recursion. After fixing the shorter key, the deleted sources must be summed with their q_iq_j weights. The full-key common point u, its original first-core radius, and the same-direction pair condition can all vary with the deleted pair. Original q capacity applies at one fixed FULL point, not to all those moving common points at once.

A genuine pair payment would need to bound the positive marked sum over shorter keys and added distinct same-direction sources, while retaining the actual x in its causal receiver set and the full-key intersection test. A nonnegative marking upper bound is

    sum_{i<j}q_iq_j
       sum_{|ell|=k-2}q^ell/ell!
          integral_Y [full kernel for ell+e_i+e_j at x]
                       1{l(i,x)=l(j,x)} dx.                (9)

It dominates D_pair because every retained key has at least one distinct collision; marking may overcount multiple pairs and no gain is inferred from that overcount.

Source/receiver Fubini is legitimate in (9):

    q_iq_j integral_Y G(x)dx
       =integral_{F_i}integral_{F_j}integral_Y
                     G(x)/(d_i d_j) dx dv du.

This uses the TRUE owner measures. It does not turn the one-coordinate relation (8) into a full original admission edge or select one common point independently of i,j. It is exactly here that the attempted owner charge stops. No factor of tau, n, or pair multiplicity is suppressed.

## 7. Precise next step and bounded stop

The complete receiving objective can be retained in a whole-key all-outside kernel, then on a distinct same-direction pair subkernel. Removing that pair enlarges the lower-degree geometry legally. What remains is a REAL joint owner/receiver capacity estimate for (9), paying its other coordinates and moving common point.

The existing local short-sample theorem does not supply this global added-pair estimate. Nor do the old q-load bound, source-owner disjointness, or center admission applied in only one coordinate. No generic low-kernel normalization, LP/Hall restatement, local pool sum or further codimension expansion is substituted for it.

The scalar collision bounds here match the main agent's proposed bookkeeping; the parent owns the actual computation/archive and independent audit. No numerical run is claimed by this note. This bounded task ends at the precise pair transport bottleneck; the global all-input packing bound remains open.
