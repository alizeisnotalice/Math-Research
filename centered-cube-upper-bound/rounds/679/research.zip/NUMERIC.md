# R679 exact crossing multiplicities

Python 3.12.14, `/Users/zzh/.local/share/math-research-tools/venv/bin/python`. Input SHA256 `51133281e98e46889690d01d1a3a47a114c6dad79ec123cb9d3929f95e16d642`. Script SHA256 `9ed7520e3a692afb5f7944773e7d56a427df47cbefcb6f041cb19eff72c7ae40`.

All 120 records passed. Estimated and enumerated positive subcells: 3547; largest halo/receiver pair: 2. 60 k<=3 records also match the prior causal summary exactly. Full source/label data, per-key distributions, and per-label once-marked contributions are retained in CROSSING_SUMMARY.json.

Each actual H intersect receiver strip is partitioned at support-source faces. Exact Fraction volumes verify r=0 equals S0, sum r>=1 equals D, and total equals Scausal. At each r>0 cell, sum_i m_i*1_(outside Ai)/r=1 is checked, preserving all repeated tags.

| Statistic | Min | Max |
|---|---:|---:|
| rk_share_of_full | 0 | 0.6 |
| rk_share_of_boundary | 0.312332876802 | 1 |
| average_r_full | 0 | 3.6 |
| average_r_boundary | 1 | 6 |
| multiple_crossing_share_of_boundary | 0 | 1 |

Local all-outside check: the sum over original groups of integral_Yb (T_b-g_strictPb(x))^k/k! is at most the global r=k term in all 120 records. Local source-face partition cells: 984. The pointwise all-outside multi-index identity was checked at every local cell; empty strict P contributes zero. Three-stage statistics and exact per-group values are saved. The low-tau experiment makes no 39/40 claim.

The boundary cannot be treated as only a one-crossing term: cells with r>1 are retained. Repeating a single source label k times already produces r=k outside that source, even with no crossing of multiple distinct source cubes. The once-marked 1/r formula counts boundary exactly once; omitting it gives the r-weighted boundary, whose average multiplicity is reported above.

All fixtures remain the original low-tau R677 ones, with strict P defined only by removing the original anchor. There is no hard-core or high-tau absorption test here. Higher-dimensional centers reuse trailing zero coordinates. The three requested stage views are marked in JSON. No original experiment was regenerated; --input selects the existing JSON (default adjacent WITNESS_RESULT.json), and optional --causal-reference supplies the previous summary for k<=3 comparison.
