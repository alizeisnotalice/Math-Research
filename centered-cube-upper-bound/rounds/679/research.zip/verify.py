from pathlib import Path
from fractions import Fraction as F
from math import factorial,prod
import ast,hashlib,json,re
p=Path(__file__).resolve().parent
for n in ['CROSSING_CHECK.py','DIRECTION_CHECK.py','verify.py']:ast.parse((p/n).read_text())
c=json.loads((p/'CROSSING_AGGREGATES.json').read_text());d=json.loads((p/'DIRECTION_RESULT.json').read_text())
for stem,r in [('CROSSING',c),('DIRECTION',d)]:
 assert r['all_checks_passed']
 assert r['script_sha256']==hashlib.sha256((p/(stem+'_CHECK.py')).read_bytes()).hexdigest()
assert c['input_sha256']=='51133281e98e46889690d01d1a3a47a114c6dad79ec123cb9d3929f95e16d642'
assert len(c['records'])==120 and c['enumerated_cells']==3547 and c['reference_records_checked']==60
for r in c['records']:
 v=list(map(F,r['weighted_crossing_distribution']));assert len(v)==r['k']+1
 assert sum(v)==F(r['S_causal']) and v[0]==F(r['S0_causal'])
 assert sum(v[1:])==F(r['D'])==F(r['once_marked_boundary'])
 assert v[-1]==F(r['global_r_equals_k'])>=F(r['localAllOutsideLHS'])
 assert sum(F(z['all_outside_integral']) for z in r['local_all_outside_groups'])==F(r['localAllOutsideLHS'])
 assert F(r['local_all_outside_slack'])==v[-1]-F(r['localAllOutsideLHS'])>=0
assert sum(r['local_all_outside_cell_count'] for r in c['records'])==984
assert len(d['records'])==117
for r in d['records']:
 ps=list(map(F,r['p']));n=r['n'];k=r['k'];assert len(ps)==n and sum(ps)==1
 e=[F(1)]+[F(0)]*k
 for x in ps:
  for j in range(k,0,-1):e[j]+=x*e[j-1]
 prob=factorial(k)*e[k];bound=F(prod(range(n-k+1,n+1)),n**k) if k<=n else F(0)
 assert prob==F(r['no_collision_probability'])<=bound==F(r['falling_factorial_uniform_bound'])
 if r['distribution']=='uniform':assert prob==bound
C=d['constants'];assert F(C['source_repeat_upper_at_n_min'])==F(16641,2*6142*1024*4096)<F(1,1000)
assert F(C['exponential_rational_upper'])==F(1,8189)<F(1,1000)
assert F(C['combined_cover_lower'])==F(39,40)*F(499,500)>F(97,100)
s=(p/'REPORT.tex').read_text();stack=[]
for m in re.finditer(re.escape(chr(92))+r'(begin|end)\{([^}]+)\}',s):
 if m[1]=='begin':stack.append(m[2])
 else:assert stack and stack.pop()==m[2]
assert not stack
review=(p/'S3_REVIEW.md').read_text()
for n in ['REPORT.tex','A1_TWO_POINT_BUDGET.md','S2_JOINT_TRANSPORT.md','CROSSING_CHECK.py','CROSSING_AGGREGATES.json','DIRECTION_CHECK.py','DIRECTION_RESULT.json']:
 assert hashlib.sha256((p/n).read_bytes()).hexdigest() in review,n
if (p/'MANIFEST.json').exists():
 for n,v in json.loads((p/'MANIFEST.json').read_text())['members'].items():
  b=(p/n).read_bytes();assert len(b)==v['bytes'] and hashlib.sha256(b).hexdigest()==v['sha256']
print(json.dumps(dict(passed=True,exact_aggregate_and_probability_records=237,manifest_checked=(p/'MANIFEST.json').exists(),scope='recorded finite arithmetic and integrity, not a general geometric proof checker')))
