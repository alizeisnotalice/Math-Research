#!/usr/bin/env python3
"""R679 exact crossing-count distribution on prior low-tau causal halo strips."""
from fractions import Fraction as F
from pathlib import Path
from itertools import combinations_with_replacement,product
from collections import Counter
from math import factorial,prod
import argparse,json,hashlib,sys,platform,time
BASE=Path(__file__).resolve().parent

def enc(x):
    if isinstance(x,F):return str(x)
    if isinstance(x,dict):return {str(k):enc(v) for k,v in x.items()}
    if isinstance(x,(tuple,list)):return [enc(v) for v in x]
    return x

def vol(box):return prod(max(F(0),h-l) for l,h in box)
def intersect(A,B):return [(max(a,c),min(b,d)) for (a,b),(c,d) in zip(A,B)]

def setup(src):
    """All original fixtures; all keys use strict original full P minus anchor."""
    tasks=[]
    for fi in src['fixtures']:
        assert fi['all_checks_passed'];n=fi['n'];a=fi['a'];c0=F(fi['c0']);q=list(map(F,fi['q']))
        A=[[(F(y)-F(C['s']),F(y)+F(C['s'])) for y in C['y']] for C in fi['cubes']]
        radii=[F(C['s']) for C in fi['cubes']]
        X=[]
        for h,C in enumerate(fi['cubes']):
            box=[(F(y)-radii[h]/a,F(y)+radii[h]/a) for y in C['y']]
            box[0]=(F(fi['receiver_strips'][h]['cut']),box[0][1])
            assert vol(box)==F(fi['receiver_strips'][h]['X_volume']);X.append(box)
        for policy,pr in fi['policies'].items():
            groups=pr['groups'];P=[set(G['positive_sources'])-{G['anchor']} for G in groups]
            for k in range(1,7):
                keys=set(tuple(sorted(Counter(t).items())) for p in P for t in combinations_with_replacement(sorted(p),k))
                tasks.append((fi,policy,k,groups,P,A,X,radii,q,c0,sorted(keys)))
    return tasks

def geometry(task,key):
    fi,policy,k,groups,P,A,X,radii,q,c0,keys=task;n=fi['n'];supp={i for i,m in key}
    first=next(b for b,p in enumerate(P) if supp<=p);rho=radii[groups[first]['anchor']]
    I=[(max(A[i][d][0] for i in supp),min(A[i][d][1] for i in supp)) for d in range(n)]
    assert vol(I)>0
    H=[(l-c0*rho,h+c0*rho) for l,h in I]
    coeff=prod(q[i]**m for i,m in key)/prod(factorial(m) for i,m in key)
    return supp,first,I,H,coeff

def pieces(A,supp,box):
    axes=[]
    for d,(lo,hi) in enumerate(box):
        cuts=sorted({lo,hi}|{x for i in supp for x in A[i][d] if lo<x<hi})
        axes.append(list(zip(cuts,cuts[1:])))
    return axes

def run(args):
    start=time.time();raw=args.input.read_bytes();src=json.loads(raw);tasks=setup(src)
    references={};reference_info=None
    if args.causal_reference:
        rr=args.causal_reference.read_bytes();ref=json.loads(rr)
        assert ref['input_sha256']==hashlib.sha256(raw).hexdigest()
        references={(r['fixture'],r['policy'],r['k']):r for r in ref['records']}
        reference_info=dict(path=str(args.causal_reference.resolve()),sha256=hashlib.sha256(rr).hexdigest(),owning_script_sha256=ref['script_sha256'])
    estimate=0;max_pair_cells=0;positive_pairs=0
    for T in tasks:
        fi,policy,k,groups,P,A,X,radii,q,c0,keys=T
        for key in keys:
            supp,first,I,H,coeff=geometry(T,key)
            for b in range(first,len(groups)):
                for h in groups[b]['members']:
                    box=intersect(H,X[h])
                    if vol(box):
                        c=prod(len(axis) for axis in pieces(A,supp,box));estimate+=c;max_pair_cells=max(max_pair_cells,c);positive_pairs+=1
    print(json.dumps(dict(estimated_cells=estimate,max_pair_cells=max_pair_cells,positive_pairs=positive_pairs,cell_limit=args.cell_limit)),flush=True)
    if estimate>args.cell_limit:
        raise SystemExit('Exact cell estimate exceeds limit; no expansion run. Return estimate before changing scope.')
    records=[];donecells=0;refchecks=0
    for T in tasks:
        fi,policy,k,groups,P,A,X,radii,q,c0,keys=T;n=fi['n']
        rates=[sum((q[i] for i in p),F(0)) for p in P]
        distribution=[F(0)]*(k+1);tagged_total=F(0);direct=F(0);zero=F(0);repeat_dist=[F(0)]*(k+1)
        perkey=[];cellcounts=[0]*(k+1);sumcells=0;nonzero_keys=0;repeated_keys=0;single_source_repeated_keys=0
        for key in keys:
            supp,first,I,H,coeff=geometry(T,key);kd=[F(0)]*(k+1);tagged_by_label={i:F(0) for i in supp};keycells=0
            for b in range(first,len(groups)):
                for h in groups[b]['members']:
                    box=intersect(H,X[h]);boxvol=vol(box)
                    if not boxvol:continue
                    direct+=coeff*boxvol;zero+=coeff*vol(intersect(I,X[h]))
                    cells=pieces(A,supp,box);partition_volume=F(0)
                    for intervals in product(*cells):
                        x=[(l+u)/2 for l,u in intervals];v=prod(u-l for l,u in intervals)
                        outside=[i for i in supp if any(not (lo<x[d]<hi) for d,(lo,hi) in enumerate(A[i]))]
                        r=sum(m for i,m in key if i in outside)
                        assert 0<=r<=k
                        kd[r]+=coeff*v;partition_volume+=v;cellcounts[r]+=1;keycells+=1
                        if r:
                            mark=sum((F(m,r) for i,m in key if i in outside),F(0));assert mark==1
                            tagged_total+=coeff*v*mark
                            for i,m in key:
                                if i in outside:tagged_by_label[i]+=coeff*v*F(m,r)
                    assert partition_volume==boxvol
            assert sum(tagged_by_label.values(),F(0))==sum(kd[1:],F(0))
            for r,v in enumerate(kd):distribution[r]+=v
            isrepeat=any(m>1 for i,m in key)
            if isrepeat:
                repeated_keys+=1
                for r,v in enumerate(kd):repeat_dist[r]+=v
                if len(supp)==1:single_source_repeated_keys+=1
            perkey.append(dict(multi_index=key,first_eligible_group=first,original_anchor=groups[first]['anchor'],crossing_distribution=kd,once_marked_by_source_label=tagged_by_label,cell_count=keycells,single_source_repeated=(len(supp)==1 and k>1)))
            nonzero_keys+=bool(sum(kd,F(0)));sumcells+=keycells
        Sc=sum(distribution,F(0));S0=distribution[0];D=sum(distribution[1:],F(0))
        assert Sc==direct and S0==zero and D==Sc-S0 and tagged_total==D
        if (fi['name'],policy,k) in references:
            ref=references[(fi['name'],policy,k)]
            assert Sc==F(ref['S_causal']) and S0==F(ref['S0_causal']) and D==F(ref['D']);refchecks+=1
        local_outside=F(0);local_groups=[];local_cell_count=0
        for b,G in enumerate(groups):
            p=P[b];T= rates[b];group_integral=F(0);group_cells=0
            for h in G['members']:
                if not vol(X[h]):continue
                partition=pieces(A,p,X[h]);partition_vol=F(0)
                for intervals in product(*partition):
                    x=[(lo+hi)/2 for lo,hi in intervals];v=prod(hi-lo for lo,hi in intervals)
                    outside=[i for i in sorted(p) if any(not (lo<x[d]<hi) for d,(lo,hi) in enumerate(A[i]))]
                    gx=sum((q[i] for i in p if i not in outside),F(0))
                    rate_outside=T-gx
                    assert rate_outside==sum((q[i] for i in outside),F(0)) and rate_outside>=0
                    point_polynomial=rate_outside**k/factorial(k)
                    repeated_sum=F(0)
                    for tup in combinations_with_replacement(outside,k):
                        counts=Counter(tup)
                        repeated_sum+=prod(q[i]**m for i,m in counts.items())/prod(factorial(m) for m in counts.values())
                    assert point_polynomial==repeated_sum
                    group_integral+=v*point_polynomial;partition_vol+=v;group_cells+=1
                assert partition_vol==vol(X[h])
            if not p:assert group_integral==0
            local_outside+=group_integral;local_cell_count+=group_cells
            local_groups.append(dict(group=b,anchor=G['anchor'],strict_P=sorted(p),T=T,all_outside_integral=group_integral,cell_count=group_cells))
        assert local_outside<=distribution[k]
        weighted_r=sum((r*v for r,v in enumerate(distribution)),F(0))
        stages=[]
        if n in (1,2) and k in (1,2):stages.append('initial_n1_n2_k1_k2')
        if 'multiscale' in fi['name'] and k in (3,4):stages.append('stress_multiscale_k3_k4')
        if n in (3,4,6) and k in (5,6):stages.append('expanded_n3_n4_n6_k5_k6')
        records.append(dict(fixture=fi['name'],n=n,k=k,policy=policy,stages=stages,localAllOutsideLHS=local_outside,global_r_equals_k=distribution[k],local_all_outside_slack=distribution[k]-local_outside,local_all_outside_cell_count=local_cell_count,local_all_outside_groups=local_groups,strict_source_rates=rates,key_count=len(keys),nonzero_keys=nonzero_keys,repeated_label_keys=repeated_keys,single_source_repeated_keys=single_source_repeated_keys,cell_count=sumcells,cell_counts_by_r=cellcounts,weighted_crossing_distribution=distribution,distribution_for_repeated_label_keys=repeat_dist,S_causal=Sc,S0_causal=S0,D=D,once_marked_boundary=tagged_total,rk_share_of_full=distribution[k]/Sc if Sc else None,rk_share_of_boundary=distribution[k]/D if D else None,average_r_full=weighted_r/Sc if Sc else None,average_r_boundary=weighted_r/D if D else None,multiple_crossing_share_of_boundary=sum(distribution[2:],F(0))/D if D else None,per_key=perkey,all_checks_passed=True))
        donecells+=sumcells
    assert donecells==estimate
    def range_of(field):
        rr=[R for R in records if R[field] is not None]
        def item(R):return dict(fixture=R['fixture'],n=R['n'],k=R['k'],policy=R['policy'],value=R[field],decimal=float(R[field]))
        return dict(min=item(min(rr,key=lambda R:R[field])),max=item(max(rr,key=lambda R:R[field])))
    stats={name:range_of(name) for name in ('rk_share_of_full','rk_share_of_boundary','average_r_full','average_r_boundary','multiple_crossing_share_of_boundary')}
    local_stages={}
    for stage in ('initial_n1_n2_k1_k2','stress_multiscale_k3_k4','expanded_n3_n4_n6_k5_k6'):
        subset=[R for R in records if stage in R['stages']]
        local_stages[stage]=dict(records=len(subset),local_cells=sum(R['local_all_outside_cell_count'] for R in subset),nonzero_local=sum(bool(R['localAllOutsideLHS']) for R in subset),zero_local=sum(not R['localAllOutsideLHS'] for R in subset),strict_inequality_count=sum(R['local_all_outside_slack']>0 for R in subset),all_checks_passed=True)
    result=dict(title='R679 exact source-crossing multiplicity distributions',input_path=str(args.input.resolve()),input_sha256=hashlib.sha256(raw).hexdigest(),causal_reference=reference_info,script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),python=sys.executable,python_version=sys.version,platform=platform.platform(),elapsed_seconds=time.time()-start,record_count=len(records),estimated_cells=estimate,enumerated_cells=donecells,max_pair_cells=max_pair_cells,reference_records_checked=refchecks,all_checks_passed=True,definitions=dict(strict_P='original positive_sources minus original group anchor; no hard-core claim',causal_geometry='first strict-P eligible group selects original anchor rho; Z is all actual X_h in groups at or after that group',crossing_r='sum_i m_i * indicator(x outside original source cube A_i)',once_marked='for r>0, sum_i (m_i/r)*indicator(x outside A_i)=1; no term for r=0',partition='each positive-volume H intersect actual strip is split at every original support-source cube face, coordinate by coordinate',rk_share='reported separately relative to Scausal and to boundary D; undefined zero denominators use null'),statistics=stats,local_all_outside_stage_statistics=local_stages,local_all_outside_definitions=dict(LHS='sum_b integral over actual Y_b of (T_b-g_strict_P_b(x))**k/k!',pointwise_identity='all supported multi-index coefficients whose labels all lie outside Ai sum exactly to (T_b-g(x))**k/k!',check='localAllOutsideLHS <= global r=k contribution',low_tau_limit='no 39/40 claim or hard-core absorption inference'),records=records,scope='Original R677 true geometry only, k1..6, low tau. Repeated source labels and multiplicities retained, including one-source tags repeated k times. Trailing coordinates reused at zero in n>=3. No high-tau, hard-core, exponential-budget or root-order inference.')
    (BASE/'CROSSING_SUMMARY.json').write_text(json.dumps(enc(result),indent=2)+'\n')
    lines=['# R679 exact crossing multiplicities','',f"Python {platform.python_version()}, `{sys.executable}`. Input SHA256 `{result['input_sha256']}`. Script SHA256 `{result['script_sha256']}`.",'',f"All {len(records)} records passed. Estimated and enumerated positive subcells: {donecells}; largest halo/receiver pair: {max_pair_cells}. {refchecks} k<=3 records also match the prior causal summary exactly. Full source/label data, per-key distributions, and per-label once-marked contributions are retained in CROSSING_SUMMARY.json.",'','Each actual H intersect receiver strip is partitioned at support-source faces. Exact Fraction volumes verify r=0 equals S0, sum r>=1 equals D, and total equals Scausal. At each r>0 cell, sum_i m_i*1_(outside Ai)/r=1 is checked, preserving all repeated tags.','', '| Statistic | Min | Max |','|---|---:|---:|']
    for name,s in stats.items():lines.append(f"| {name} | {s['min']['decimal']:.12g} | {s['max']['decimal']:.12g} |")
    lines+=['',f"Local all-outside check: the sum over original groups of integral_Yb (T_b-g_strictPb(x))^k/k! is at most the global r=k term in all 120 records. Local source-face partition cells: {sum(R['local_all_outside_cell_count'] for R in records)}. The pointwise all-outside multi-index identity was checked at every local cell; empty strict P contributes zero. Three-stage statistics and exact per-group values are saved. The low-tau experiment makes no 39/40 claim.",'','The boundary cannot be treated as only a one-crossing term: cells with r>1 are retained. Repeating a single source label k times already produces r=k outside that source, even with no crossing of multiple distinct source cubes. The once-marked 1/r formula counts boundary exactly once; omitting it gives the r-weighted boundary, whose average multiplicity is reported above.','', 'All fixtures remain the original low-tau R677 ones, with strict P defined only by removing the original anchor. There is no hard-core or high-tau absorption test here. Higher-dimensional centers reuse trailing zero coordinates. The three requested stage views are marked in JSON. No original experiment was regenerated; --input selects the existing JSON (default adjacent WITNESS_RESULT.json), and optional --causal-reference supplies the previous summary for k<=3 comparison.','']
    (BASE/'NUMERIC.md').write_text('\n'.join(lines))
    print(json.dumps(enc(dict(all_checks_passed=True,records=len(records),enumerated_cells=donecells,max_pair_cells=max_pair_cells,reference_records_checked=refchecks,local_outside_stage_statistics=local_stages,statistics=stats,script_sha256=result['script_sha256']))),flush=True)
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',type=Path,default=BASE/'WITNESS_RESULT.json')
    p.add_argument('--causal-reference',type=Path)
    p.add_argument('--cell-limit',type=int,default=2000000)
    run(p.parse_args())
