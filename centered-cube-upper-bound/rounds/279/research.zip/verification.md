主代理完整复跑 r279_numeric.py，保存JSON逐字节一致；另实际执行 main_checks.py 的20200+101项 Fraction 检查及 screen_checks.py 的62项 Fraction 检查、40/70位正尾积分，全部通过。不是区间认证。
数值代码与最终证明独立；120个40/60位字段最大相对尺度差2.438462401860505e-41。
