#!/usr/bin/env python3
"""R279 actual kernels: bounded finite diagnostics, not interval/FULL proof."""
import argparse,hashlib,json
from fractions import Fraction as F
from pathlib import Path
import mpmath as m

def mm(s):
 q=F(s);return m.mpf(q.numerator)/q.denominator
def enc(x):return m.nstr(x,90)
def phi(x):
 x=abs(x)
 return 1-m.expint(3,m.mpf('.5')-x)-m.expint(3,m.mpf('.5')+x) if x<=m.mpf('.5') else m.expint(3,x-m.mpf('.5'))-m.expint(3,x+m.mpf('.5'))
def C(r):
 r=abs(r)
 return 1-r+m.mpf(1)/3-m.expint(4,r)-m.expint(4,1)+m.expint(4,r+1) if r<=1 else m.expint(4,r-1)-2*m.expint(4,r)+m.expint(4,r+1)
def P(s,L,x):return ((1-s)*int(abs(x)<L/2)+s*phi(x/L))/L

def primitive(x):
 t=abs(x);v=t-m.expint(4,m.mpf('.5')-t)+m.expint(4,m.mpf('.5')+t) if t<=m.mpf('.5') else m.mpf('.5')-m.expint(4,t-m.mpf('.5'))+m.expint(4,t+m.mpf('.5'))
 return v if x>=0 else -v

def integrate(fn,lo,hi,knots):
 pts=[lo]+sorted(set(k for k in knots if lo<k<hi))+[hi]
 return sum(m.quad(fn,[x,y]) for x,y in zip(pts,pts[1:]))
MENU=[('initial','0','0','1','1','1/4'),('initial','1/100','1/100','1/2','1/2','0'),('stress','1/2','1','3/4','1','1/2'),('stress','1','1/2','1','1','1'),('expanded','1/100','1','1/2','1','2'),('expanded','1/2','1/2','3/4','1','4')]
def run(dps):
 with m.workdps(dps):
  kappa=m.mpf(25)/2**68;c=kappa/432;rows=[]
  for stage,ss,sg,ll,aa,rr in MENU:
   s,sigma,L,A,r=map(mm,[ss,sg,ll,aa,rr]);omega=min(m.mpf(1),C(r)/L);delta=1-omega;chi=min(r*r,m.mpf(1));fn=lambda x:m.sqrt(P(s,L,x)*P(sigma,A,x-r));knots=[-L/2,L/2,r-A/2,r+A/2,0,r]
   # A hard factor restricts the product to its compact core exactly.
   lo=max(-L/2 if s==0 else -m.inf,r-A/2 if sigma==0 else -m.inf)
   hi=min(L/2 if s==0 else m.inf,r+A/2 if sigma==0 else m.inf)
   full=integrate(fn,lo,hi,knots) if lo<hi else m.mpf(0)
   core=integrate(fn,-m.mpf('.5'),m.mpf('.5'),knots)/m.sqrt(omega)
   source_mass=1-s+2*s*primitive(1/(2*L));source_bound=1-s/54
   gap=1-full;bound_gap=3*chi/32;strong_gap=r*r/(2*(m.mpf(13)/3+r*r))
   d2bounds=[1-kappa*delta,(1-3*chi/32)/omega,source_bound/omega];combined=min(d2bounds);exponential=m.exp(-c*(s+chi))
   tol=m.mpf(10)**(-dps+10)
   assert gap+tol>=bound_gap and gap+tol>=strong_gap
   assert source_mass<=source_bound+tol and core*core<=combined+tol and core<=exponential+tol
   row={'stage':stage,'s':ss,'sigma':sg,'L':ll,'A':aa,'r':rr,'compact_support_integration':s==0 or sigma==0}
   for key,value in [('Omega',omega),('delta',delta),('chi',chi),('H_full',full),('full_gap',gap),('gap_3chi_over32',bound_gap),('gap_stronger',strong_gap),('full_gap_margin',gap-bound_gap),('strong_gap_margin',gap-strong_gap),('D_core',core),('D_core_squared',core*core),('source_core_mass',source_mass),('source_mass_bound',source_bound),('source_mass_margin',source_bound-source_mass),('D2_kappa_bound',d2bounds[0]),('D2_affinity_bound',d2bounds[1]),('D2_source_bound',d2bounds[2]),('D2_combined_margin',combined-core*core),('D_exponential_bound',exponential),('D_exponential_margin',exponential-core)]:row[key]=enc(value)
   rows.append(row);print('completed',dps,stage,rr,flush=True)
  return {'cases':rows,'kappa':enc(kappa),'c':enc(c)}
def moments():
 # w(x)=int_0^1 exp(-|x|/r)dr: int exp=2r; int x² exp=4r³.
 mass=F(2,2);first=F(0);second=F(4,4);hardmass=F(1);hardfirst=F(0);hardvar=F(1,12);phivar=second+hardvar
 assert mass==1 and first==0 and second==1 and hardmass==1 and hardfirst==0 and phivar==F(13,12)
 return {'exact_checks':6,'w_mass':str(mass),'w_first_moment':str(first),'w_variance':str(second),'h_variance':str(hardvar),'phi_variance':str(phivar),'coefficient_derivation':'2*int_0^1 r dr=1;4*int_0^1 r^3 dr=1;convolution independent centered moments adds1/12. This is exact rational coefficient arithmetic, not numerical integration.'}
def main():
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));a=p.parse_args();low=run(40);high=run(60)
 with m.workdps(110):
  diffs={}
  for i,(x,y) in enumerate(zip(low['cases'],high['cases'])):
   for k in x:
    if k in ['stage','s','sigma','L','A','r','compact_support_integration']:continue
    xx,yy=m.mpf(x[k]),m.mpf(y[k]);diffs[str(i)+'/'+k]=abs(xx-yy)/max(1,abs(yy))
  worst=max(diffs,key=diffs.get);maxdiff=enc(diffs[worst]);assert diffs[worst]<m.mpf('1e-28')
 out={'schema':'R279-actual-kernel-gap-diagnostic-v1','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'counts':{'actual_geometries':6,'stage_cases':{'initial':2,'stress':2,'expanded':2},'precision_runs':12,'compared_fields':len(diffs),'exact_moment_checks':6},'mp40':low,'mp60':high,'precision_max_scaled_difference':maxdiff,'precision_worst_field':worst,'exact_moments':moments(),'definitions':{'b':'1','Hfull':'int_R sqrt(P_s,L(x)P_sigma,A(x-r)) dx','Dcore':'int_[-.5,.5] same /sqrt(Omega)','Omega':'min(1,C(r)/L)','chi':'min(r²,1)','delta':'1-Omega','kappa':'25/2^68','c':'kappa/432'},'scope':['Actual phi=h*w E3 kernel and C E4, same-soft and independent target soft including sigma1. Whole real-line tails integrated directly; hard factors restrict support exactly. Hard boundaries, phi breakpoints and centers are split explicitly.','Ordinary mpmath40/60, not outward intervals. No finite tail truncation is used, but quadrature error is assessed only by precision refinement. Saved90-digit strings retain actual working-precision errors.','Tiny kappa gaps and exponential claims are analytic external hypotheses; numerical checks only test consistency, with explicit tolerance. No interval certification of tiny gaps.','Six one-dimensional geometries only; no FULL/high/FIRST/history, source payment, general dimension-order or tensor theorem is certified. Kernel formulas copied from earlier R277 method, old cases not rerun.']}
 a.output.write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps({'counts':out['counts'],'maxdiff':maxdiff,'worst':worst}))
if __name__=='__main__':main()
