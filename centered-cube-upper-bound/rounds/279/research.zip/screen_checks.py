from fractions import Fraction as F
import mpmath as mp
kap=F(25,2**68)
c=kap/432
checks=0
for x in (F(0),F(1,10000),F(1,10),F(1),F(4),F(100)):
    assert x/(2*(F(13,3)+x))>=F(3,32)*min(x,F(1))
    checks+=1
for q0 in (F(0),F(1,10000),F(1,54),F(3,32)):
    for delta in (F(0),q0/4,q0/2,q0,F(1,2),F(1023,1024)):
        upper=min(1-kap*delta,(1-q0)/(1-delta))
        assert upper<=1-kap*q0/2
        checks+=1
for s in (F(0),F(1,100),F(1,2),F(1)):
    for r2 in (F(0),F(1,100),F(1,2),F(1)):
        assert c*(s+r2)<=max(kap*s/216,3*kap*r2/128)
        checks+=1
for n in (1,2,8,512):
    for s in (F(0),F(1,1000),F(1,2),F(1)):
        ns=n*s
        k=max(1,(ns.numerator+ns.denominator-1)//ns.denominator)
        sigma=F(k,n+1)
        assert n*sigma>=n*s-1
        checks+=1
print('PASS',checks,'exact Fraction assertions')
vals=[]
for dps in (40,70):
    mp.mp.dps=dps
    wtail=2*mp.quad(lambda t:t*mp.exp(-mp.mpf('1.5')/t),[0,1])
    phitail=2*mp.quad(lambda t:t*t*(-mp.expm1(-1/t))
                                *mp.exp(-mp.mpf('.5')/t),[0,1])
    lower=mp.exp(-3)/2
    assert phitail>=wtail>=lower>mp.mpf(1)/54
    vals.append((wtail,phitail))
    print('ordinary mp',dps,'w tail',mp.nstr(wtail,24),
          'phi tail',mp.nstr(phitail,24))
mp.mp.dps=70
print('max40/70absdiff',mp.nstr(max(abs(vals[0][i]-vals[1][i])
                                  for i in range(2)),10))
