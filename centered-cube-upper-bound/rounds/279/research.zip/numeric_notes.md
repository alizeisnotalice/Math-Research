# R279 actual-kernel finite diagnostics

Completed 6 distinct one-dimensional geometries, with initial/stress/expanded stages of 2 each, at mp40 and mp60 (12 precision runs). All requested finite consistency inequalities passed. There are 120 compared numerical fields and 6 separate exact moment-coefficient assertions. Maximum scaled40/60 difference is 2.438462401860505e-41, at the first geometry's D² source bound. No interval certificate, FULL input, source payment or dimension-order conclusion is asserted.

The model has b=1, y=0, P_s,L(x)=L^-1[(1-s)h(x/L)+s phi(x/L)], h=1_{[-.5,.5]}. phi is evaluated by its E3 inside/outside formulas and C by the E4 inside/outside formulas. Omega=min(1,C(r)/L), delta=1-Omega, chi=min(r²,1). Hfull is the full-line integral of sqrt(P_s,L P_sigma,A); Dcore is its integral over[-.5,.5], divided by sqrt(Omega). Source core mass is the P_s,L mass of that same fixed interval, evaluated with the odd E4 primitive of phi plus exact hard mass. L<=A<=1 in every row; sigma is independent in three rows (including two J rows sigma1), so no same-soft qualification is silently assumed.

|stage|s|sigma|L|A|r|Hfull|Dcore|
|---|---:|---:|---:|---:|---:|---:|---:|
|initial|0|0|1|1|.25|.75|.824479191835736|
|initial|.01|.01|.5|.5|0|1|.997615282982119|
|stress|.5|1|.75|1|.5|.852068083627261|.578734457764603|
|stress|1|.5|1|1|1|.749229339392201|.488797485231896|
|expanded|.01|1|.5|1|2|.173837422840112|.507407222849557|
|expanded|.5|.5|.75|1|4|.117602304085496|.522790324845747|

Each precision checks 1-Hfull >=3chi/32 and the stronger r²/[2(13/3+r²)], source core mass <=1-s/54, and Dcore² <=min(1-kappa delta,(1-3chi/32)/Omega,(1-s/54)/Omega). It also checks Dcore<=exp[-c(s+chi)], kappa=25/2^68,c=kappa/432. All raw values, individual margins and the combined margin are saved. Equality cases at r0 and s0 are preserved. The smallest positive full-gap margin is .12449441637; the smallest positive source-core margin is .0021995318327; the smallest D² combined margin is .0045785619753. These margins describe only this menu. The tiny kappa/exponential gaps are analytic hypotheses being screened: passing ordinary multiprecision with a finite tolerance does not certify them rigorously. In this menu the D inequalities have much larger actual margins.

Full-line tails are integrated directly with mpmath, never cut off at a finite radius. Hard factors restrict the integration to their exact compact support. Source hard boundaries±L/2, target boundaries r±A/2, and centers0,r split all integrations. The listed error diagnostic is working-precision refinement only; it is not a certified quadrature or tail error bound. Ninety-digit output strings retain the actual errors of their40/60 working precision rather than claiming90-digit accuracy.

Exact moment arithmetic is separate: w(x)=int_0^1 exp(-|x|/u)du has mass2 int_0^1 u du=1, zero mean by symmetry, and second moment4 int_0^1 u³du=1. The hard density h has mass1,mean0,variance1/12. Thus phi=h*w has variance13/12. Six Fraction assertions record these rational coefficients. This is an exact coefficient calculation, not an empirical moment estimate.

The E3/E4 implementation follows the previous R277 method, copied into this self-contained script; no old menu was run or modified. No other file or repository was changed. The six scalar rows are not original FIRST/high/history-qualified traffic or a tensor counterexample/closure claim.

Run with Python3.12.14 and mpmath1.3.0:

```sh
PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor \
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 \
r279_numeric.py --output r279_numeric.json
```

The deterministic JSON binds the script SHA256 and contains no time or output path. For migration place this script anywhere and use the same runtime/library; only mpmath plus the standard library is needed. Actual completed computation was one full40/60 run; no unnecessary timing replay was performed.
