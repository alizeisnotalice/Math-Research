from fractions import Fraction as F
kap=F(25,2**68)
count=0
for j in range(101):
    r=F(j,10); zeta=F(3,32)*min(r*r,F(1))
    assert r*r/(2*(F(13,3)+r*r))>=zeta
    for k in range(100):
        delta=F(k,100)
        assert min(1-kap*delta,(1-zeta)/(1-delta))<=1-kap*zeta/2
        count+=1
for j in range(101):
    zeta=F(j,100)/54
    for k in range(100):
        delta=F(k,100)
        assert min(1-kap*delta,(1-zeta)/(1-delta))<=1-kap*zeta/2
        count+=1
print(count, 'normalized-gap checks PASS; 101 distance checks PASS')
