import argparse,hashlib,json,pathlib,subprocess,sys,tempfile
p=pathlib.Path(__file__).resolve().parent
q=argparse.ArgumentParser();q.add_argument('--check-only',action='store_true');a=q.parse_args()
for name,digest in json.loads((p/'manifest.json').read_text()).items():
 assert hashlib.sha256((p/name).read_bytes()).hexdigest()==digest,name
print('Manifest PASS')
if not a.check_only:
 for name in ['main_checks.py','screen_checks.py']:
  subprocess.run([sys.executable,str(p/name)],check=True)
 with tempfile.TemporaryDirectory() as d:
  out=pathlib.Path(d)/'result.json'
  subprocess.run([sys.executable,str(p/'r279_numeric.py'),'--output',str(out)],check=True)
  assert out.read_bytes()==(p/'r279_numeric.json').read_bytes()
 print('Replay and byte comparison PASS')
