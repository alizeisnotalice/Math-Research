# R279 independent geometry/source proposition screen

**Verdict: PASS for the stated quantitative core refinement, its adaptive positive cover, and the resulting large-`ns+R2` source payment.** This is not a bound for the surviving small-geometry traffic or the general weak-type goal. The proof below was independently derived before reading any R279 author output.

Use the exact old R224 normalization, not a replacement: in one dimension let `p=P_{s,L}(.-y)`, `q=P_{sigma,A}(.-v)`, with `b/2<=L<=A<=b`, `s,sigma in [0,1]`. Put `r=|y-v|/b`, `Omega=min(1,bC(r)/L)`, `delta=1-Omega`, and

`D=integral_{Q_b(y)} sqrt(pq) dx /sqrt(Omega)`.

All finite source positions have Omega>0. R224 at R=b,m=L,M=b gives `D^2<=1-kappa delta`, `kappa=25/2^68`. This is the historical fixed-state input; it does not itself pay an adaptive source integral.

## 1. Quantitative Hellinger separation from source displacement

The probability density w(x)=integral_0^1 exp(-|x|/t)dt has mass 1 and variance

`integral_0^1 4t^3 dt=1`.

The uniform h has variance 1/12, so phi=h*w has variance 13/12; f_s has variance 1/12+s. Thus both scaled densities p,q have variances at most `13b^2/12`, with means y,v. This remains true at s or sigma equal to zero.

Let `H=integral_R sqrt(pq)<=1`, `d0=|y-v|`, and choose the midpoint m=(y+v)/2. Factoring p-q into the difference and sum of square roots and applying Cauchy gives

`d0^2 <= 2(1-H) integral (x-m)^2(sqrt(p)+sqrt(q))^2 dx`

`       <=2(1-H)(13b^2/3+d0^2)`.

The second bound uses `(sqrt(p)+sqrt(q))^2<=2(p+q)`. Consequently

`1-H >= r^2/[2(13/3+r^2)] >= (3/32)min(r^2,1)`.

Since H^2<=H and the core integral is at most H,

`D^2 <= [1-q0]/(1-delta)`, `q0=(3/32)min(r^2,1)`.

The following elementary split is valid for 0<=q0<1. If delta>=q0/2, QG gives `D^2<=1-kappa q0/2`. If delta<q0/2, the displayed fractional bound is at most `1-q0/2`, hence at most `1-kappa q0/2` since kappa<1. The q0=0 case is harmless. Thus

`D<=exp[-kappa q0/4]=exp[-(3kappa/128)min(r^2,1)]`.       (H1)

No angular-source or coordinate-source independence appears in this argument. The global Hellinger integral is used only to prove a fixed one-coordinate core bound.

## 2. Quantitative loss from source softness

Let W have density w and U be independent uniform on [-1/2,1/2], so U+W has density phi. Then

`P_phi{|X|>1} >= P_w{|W|>3/2}`

`=2 integral_0^1 t exp[-3/(2t)]dt >=(1/2)exp(-3)>1/54`.

The last inequality follows from e<3. Since L>=b/2, the normalized core threshold b/(2L) is <=1. The hard source component lies inside Q_b(y), whereas the soft source component loses at least 1/54 of its mass. Therefore

`integral_{Q_b(y)}p <=1-s/54`.

Ordinary Cauchy on this same core, with target core mass <=1, yields

`D^2 <= (1-s/54)/(1-delta)`.

The identical split with q0=s/54 gives

`D<=exp[-kappa s/216]`.                                    (H2)

This is a source-softness statement, uniform in the independent target softness sigma; it does not assume both endpoint laws have the same s.

## 3. Combined core loss and safe common-window collar

Both H1 and H2 hold simultaneously. With `c=kappa/432`, their minimum gives

`D<=exp[-c(s+min(r^2,1))]`,

because `max((kappa/216)s,(3kappa/128)min(r^2,1))>=c(s+min(r^2,1))`.

For the fixed n-dimensional kernels put

`R2(y,v)=sum_i min(|y_i-v_i|^2/b^2,1)`, `Z=ns+R2`.

The R278 safe collar bound is `48epsilon_h sqrt(s)` per coordinate, valid with independent target softness; `epsilon_h=d/b`, `d=a/(8sqrt(n))`. Each new core exponent `a_i=c(s+min(r_i^2,1))` lies in [0,2c]. Adding collar coordinatewise and tensorizing gives

`integral_{W_y} sqrt(P_{s,L}(x-y)P_{sigma,A}(x-v)/barw_L) dx`

`<=exp[-c(ns+R2)+48exp(2c)n epsilon_h sqrt(s)]`

`<=exp[-c(ns+R2)+6exp(2c)sqrt(ns)]`.                         (H3)

The second inequality uses a/b<=1. Completing the square in sqrt(ns) gives

`6exp(2c)sqrt(ns) <= (c/2)ns+18exp(4c)/c`.

Weakening the R2 coefficient from c to c/2 therefore yields

`integral_{W_y} halfkernel <=exp[C_y-(c/2)(ns+R2)]`,

`C_y=18exp(4c)/c`.                                         (H4)

All constants in the proposed statement are consequently safe. No small-n exception is needed; the price is the very large explicit constant C_y. The old collar handles the target-hard contribution, so it has not been deleted in this refinement.

## 4. Actual all-parameter cover and original-source price

For the actual moving maps A_1(L)=L and A_2(L)=min(b,gamma L), use the already proved R276/R278 common soft menu and paired upward physical node B. Its source soft value sigma satisfies `|sigma-s|<=1/n`, the two maps remain in [B,b], and R2 is unchanged because its definition uses the fixed outer b, not L or the clamp level. Hence

`n sigma+R2>=ns+R2-1`.

On the original gate `ns+R2>=T`, retain the static node gate `n sigma+R2>=T-1`. H4 bounds every gated node half-mass by

`exp[C_y+c/2-cT/2]`.

There are at most n(n+1) nodes per actual moving leg. The two positive density covers cost c_n^2, and the original terminal-weight comparison `w_g>=c_n^(-1)barw_L` costs c_n^(1/2), so the total is at most e^(5/2). The window indicator 1_{W_y} must remain explicit in the pointwise envelope; H3/H4 are not full-space half-affinity bounds.

On the actual certification event `E_i={p_y w_g<=K K_i}`, apply `p_y<=sqrt(K)sqrt(p_y K_i/w_g)` before removing any original positive gate. Original near plus hard support implies x in W_y. Apply hardcap/q<=16/3 on the original E before extending the receiver integral. Fixed (omega,V,j,y,t) makes the complete pair posterior independent of x and hard z. Use score<=n and the full original j-clock sum<=n, exactly as in R278. For the union of the two moving certification events the resulting bound, including the original 2 Lambda once, is

`P[ (E_1 union E_2) and {ns+R2>=T} ]`

`<= (64 Lambda/3)e^(5/2)sqrt(K)n^3(n+1)`

`   *exp[18exp(4c)/c+c/2-cT/2] W_beta`.                       (H5)

This reproduces the candidate coefficient. It does not introduce a third target-scale menu, a receiver-volume Holder factor, a source-mass square, or a new posterior. W_beta is still the same pre-frozen terminal-leaf source mass, with W_beta<=W_hi<=||f||_1. No nu<=beta is required. The original Q/J/bad/high definitions and negative ledger remain unchanged.

For example, let `A_n=(64 Lambda/3)e^(5/2)sqrt(K)n^3(n+1)` and take

`T_epsilon=(2/c)[18exp(4c)/c+c/2+log_+(A_n/epsilon)]`.

Then H5 costs at most epsilon W_beta. After the J-certified subset has been removed as in R277, original good implies certification by at least one moving leg. Thus the surviving portion of this original near positive branch satisfies `ns+R2<T_epsilon` (up to the chosen inclusive/strict decomposition). For fixed original K and epsilon,

`T_epsilon <= 36exp(4c)/c^2+1`

` + (2/c)log_+[(64 Lambda/3)e^(5/2)sqrt(K)/epsilon]`

` + (8/c)log(n+2)`.

This is the claimed `C0+C1 log(n+2)` form. Its constants are enormous, including c^(-2), so the paid gate may be empty throughout many finite dimensions. No nonempty positive-volume FULL example or positive fraction of actual traffic is asserted. If K varies with outer data, retain the factor or choose the corresponding threshold within that same original outer-data source account.

This genuinely refines the remaining actual source/kernel geometry: source softness and truncated squared displacement are now controlled together rather than merely the possibly saturated Delta_L. It does not yet give a budget for the surviving small-geometry traffic or for the bad auxiliary source slot.

## 5. Actual bounded arithmetic and quadrature evidence

A local run passed **62 exact Fraction assertions** checking the rational mean/variance Hellinger coefficient, both branches of the normalization split, the combined-loss coefficient, and the soft-node loss shift. Separate ordinary mp40/mp70 positive-integral evaluations checked the two source-tail formulas. Actual values were

- w tail beyond 3/2: approximately 0.113478980340708552312656;
- phi tail beyond 1: approximately 0.238471701788097186813574;
- largest 40/70 absolute difference: approximately 7.118985753e-43.

These are not interval certificates or FULL examples; the analytic proof above supplies the inequalities. Complete reproducible diagnostic code:

```python
from fractions import Fraction as F
import mpmath as mp
kap=F(25,2**68)
c=kap/432
checks=0
for x in (F(0),F(1,10000),F(1,10),F(1),F(4),F(100)):
    assert x/(2*(F(13,3)+x))>=F(3,32)*min(x,F(1))
    checks+=1
for q0 in (F(0),F(1,10000),F(1,54),F(3,32)):
    for delta in (F(0),q0/4,q0/2,q0,F(1,2),F(1023,1024)):
        upper=min(1-kap*delta,(1-q0)/(1-delta))
        assert upper<=1-kap*q0/2
        checks+=1
for s in (F(0),F(1,100),F(1,2),F(1)):
    for r2 in (F(0),F(1,100),F(1,2),F(1)):
        assert c*(s+r2)<=max(kap*s/216,3*kap*r2/128)
        checks+=1
for n in (1,2,8,512):
    for s in (F(0),F(1,1000),F(1,2),F(1)):
        ns=n*s
        k=max(1,(ns.numerator+ns.denominator-1)//ns.denominator)
        sigma=F(k,n+1)
        assert n*sigma>=n*s-1
        checks+=1
print('PASS',checks,'exact Fraction assertions')
vals=[]
for dps in (40,70):
    mp.mp.dps=dps
    wtail=2*mp.quad(lambda t:t*mp.exp(-mp.mpf('1.5')/t),[0,1])
    phitail=2*mp.quad(lambda t:t*t*(-mp.expm1(-1/t))
                                *mp.exp(-mp.mpf('.5')/t),[0,1])
    lower=mp.exp(-3)/2
    assert phitail>=wtail>=lower>mp.mpf(1)/54
    vals.append((wtail,phitail))
    print('ordinary mp',dps,'w tail',mp.nstr(wtail,24),
          'phi tail',mp.nstr(phitail,24))
mp.mp.dps=70
print('max40/70absdiff',mp.nstr(max(abs(vals[0][i]-vals[1][i])
                                  for i in range(2)),10))
```

Only `/tmp/r279_screen.md` was written. No R279 author output was read, and no repository/Git/PDF action was taken. Stop at this bounded candidate theorem and its stated still-unpaid complement.
