# R279 final independent mathematical audit

**Verdict: PASS for the integrated joint core-loss theorem, its all-parameter positive envelope, and the specified original large-geometry source payment.** The surviving small-geometry near traffic and the global weak-type goal remain unproved.

## Bound version and review order

The integrated proof was read in full:

- `/tmp/r279_proof.tex.txt`
- SHA256 `67ffe3f3c271245d45c3666f6e9f9014e4abf3d68fded611bacf20661a7155c2`.

The independent proposition screen preceded any R279 author reading:

- `/tmp/r279_screen.md`
- SHA256 `71fbbed25a209ba1086a37b551a5dc139f6b920ae0d245826e4df811ce0b7830`.

This final audit certifies the mathematical content of the integrated main proof. It does not certify the separate auxiliary entropy/source-energy proposal or its numerical receipt.

## Verified deductions

1. **Probability normalization and Hellinger coefficient pass.** The density w has mass `integral_0^1 2t dt=1`, zero mean and variance `integral_0^1 4t^3 dt=1`. Hence phi=h*w has variance 13/12 and f_s has variance 1/12+s. Both scaled input/target laws have the stated mean and variance bound. With the midpoint as origin, Cauchy and `(sqrt(p)+sqrt(q_1))^2<=2(p+q_1)` give the second squared factor at most `b^2(13/3+r^2)`. Thus equation (4), including the coefficient 3/32 and truncation at r=1, is correct. All endpoint soft values are included; neither absolute continuity of a log-likelihood nor positivity of the densities on all space is needed.

2. **The exact-min normalization is used correctly.** The unrestricted probability affinity H is not itself asserted to control a globally normalized source column. The proof retains the core denominator Omega and simultaneously uses the R224 exact-min theorem with R=b, m=L, M=b, hard center y, target scale A>=L. The split at delta=zeta/2 gives `D^2<=1-kappa*zeta/2` in both branches, including zeta=0 and saturation delta=0. Taking square roots yields `exp[-3kappa min(r^2,1)/128]`. No false KL normalization or free clamp replacement appears.

3. **The source-soft tail bound passes.** The random convolution representation gives the event inclusion `|W|>3/2 => |U+W|>1`. Restricting the positive Laplace integral to [1/2,1] proves the tail lower bound `(1/2)e^{-3}>1/54`. Since L>=b/2, the source core loses at least s/54, independently of target softness. The same exact-min split then yields equation (8). Taking the geometric mean of the two valid D bounds gives `c=kappa/432` in equation (9); the comparison 3/256>=1/432 is in the correct direction.

4. **The common-window collar and its absorption pass.** The adopted R278 collar bound retains the potentially nonzero target-hard contribution and is valid with independent source/target soft parameters. The new one-coordinate core exponent is at most 2c. Thus adding the collar and tensorizing gives the factor `48e^{2c}n epsilon_h sqrt(s)`, which is at most `6e^{2c}sqrt(ns)`. Completing the square gives the stated constant `18e^{4c}/c`; weakening both geometric coefficients to c/2 in equation (12) is valid. This bound is only for W_y. It is not reinterpreted as a full-space inverse-weight affinity inequality.

5. **All adaptive parameter fees pass.** One common n-node soft grid and one at-most-(n+1)-node upward physical grid are used per actual moving leg. The paired target maps stay in the exact-min legal range. Two positive density covers give e^2 on the half-product, and upward denominator rounding has the correct direction. The squared-displacement sum R2 depends on the fixed outer b, so it is unchanged by the L mesh. The inequality `n sigma_k>=ns-1` is sufficient for the exact threshold in equation (1); the node gate then gives column mass at most e^{-T}, with no missing e^{c/2} because the explicit leading 1 in the original gate has already paid that rounding loss. The text explicitly retains 1_{W_y} in the pointwise finite-sum envelope. No new node FIRST or posterior is claimed.

6. **Original source/receiver accounting passes.** The raw certification gate yields the sqrt(K) factor, without a 3^{-1/2} factor. The original scale band gives `w_g>=gamma^{-n}barw_L`, contributing sqrt(e) once. Near plus the actual hard support gives W_y before hard-source integration. The hardcap/q<=16/3 is used on the original receiver domain, before its positive extension. At fixed original (omega,V,j,y,t), the complete posterior pair is independent of x and hard z. Its total mass is at most one, raw score is at most n, and the full j-clock sum costs at most n. Together with the original outside 2 Lambda these are exactly the per-leg coefficient `(32Lambda/3)e^{5/2}sqrt(K)n^3(n+1)e^{-T}`. Union of both moving certifications gives equation (2). The same pre-frozen terminal-leaf source ledger gives W_beta<=||f||_1 without assuming nu<=beta or multiplying source mass by the number of j bands.

7. **Threshold and residual scope pass.** The log_+ threshold gives epsilon W_beta for every positive epsilon and original positive K; when its logarithm is nonpositive, the unreduced prefactor is already at most epsilon. Equation (13) is precisely the complement of the gate, with `2B_c/c=36e^{4c}/c^2`. Its O(log(n+2)) description is qualified by fixed K and epsilon and by the enormous explicit constants. K-dependent charges cannot be silently removed if K varies with outer data. The remaining constraint applies only to the original near positive branch's good kernel slot after the stated disjoint payments, not to bad u, arbitrary source pairs, or the entire global mother quantity. Q, J, bad/high/history and the original signed negative credits are not changed or reused.

## Actual computation scope

During the independent screen this auditor actually ran 62 exact Fraction assertions for the Hellinger coefficient, normalized split, combined-loss coefficient, and node-loss shift, plus ordinary mp40/mp70 positive-integral evaluations of the two tail formulas. Their largest recorded absolute difference was approximately 7.119e-43. Full reproduction code and the numerical values are in the SHA-bound screen.

The integrated proof's separate 20200+101 finite rational checks are consistent with their displayed formulas, but were not rerun by this auditor for the final review. None of these finite calculations is used in place of the analytic proof, an interval certificate, or an original FULL input. No additional numerical or geometric route was opened.

No necessary mathematical correction was found in the bound integrated main source. Only `/tmp/r279_final_audit.md` was written for this final task; the proof, repository, Git state and PDFs were not modified. Work stops at the requested scope.
