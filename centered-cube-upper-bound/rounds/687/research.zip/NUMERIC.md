# R687 common-point cube projection and exact packing exchanges

## Outcome

The closed axis-aligned cube projection identity passes every exact check, including contact and degenerate targets. Its elementary proof is independent of the finite tests. With the stronger strict-anchor premise z interior to every source and a positive-volume target, the positive-volume/interior-clamp identity and essential-maximum formula also hold; these are verified in the appended scope correction below. Removing the common source point or replacing product cubes by Euclidean balls can invalidate the projection mechanism.

The actual two-dimensional packing fixtures also verify two valid operations: combining a source profile with target packing outside its superlevel set, and replacing neighboring packing mass jointly. The frozen three-square example has zero gain for either single-target replacement but gain 1/2 for the two-target batch, with an exact dual density certifying the optimum 8.

These are geometry and packing consistency certificates. No original high-threshold saturated history, strict core, or complete maximal-operator upper bound is asserted.

## Closed projection identity and boundary scope

Let the closed source boxes Ai all contain z, let H be a closed axis-aligned target box, and let p be the coordinatewise clamp of z to H. Then

`Ai intersect H is nonempty iff p belongs to Ai`.

For one coordinate, any source interval containing z and meeting the target interval also contains the clamped point: that point lies between z and a point in their intersection. Taking the coordinate product proves the identity, including zero-width coordinates. The converse follows because p belongs to H.

For nonnegative profile weights vi, every source contributing at a point of H must intersect H, while p belongs to all such sources simultaneously. Consequently

`max_(x in H) sum_i vi 1_Ai(x) = sum_(i:Ai intersects H)vi`.

This is a **closed, pointwise maximum**. Contact-only intersections count. For the closed superlevel set `Ev={fv>=gamma*sigma}`, the exact avoidance test is the strict inequality

`H intersect Ev empty iff sum_(i:Ai intersects H)vi < gamma*sigma`.

Positive volume is checked separately. In one dimension, the two sources [-1,0] and [0,1], target [-1/2,1/2], common point z=0 and weights one each have positive-length source-target intersections. The closed maximum is two at p=0, but the full-dimensional essential maximum is one. Thus summing sources with positive-volume target overlap does not give an essential-maximum identity.

The initial exact boundary fixtures are:

| fixture | closed maximum | full-dimensional essential maximum |
|---|---:|---:|
| one-dimensional opposing intervals | 2 | 1 |
| two-dimensional opposing radius-one squares, weights2,3 | 5 | 3 |
| point target in dimension two | 3 | not applicable: target has zero area |
| one-coordinate-degenerate box target | 2 | not applicable: target has zero area |

The partially degenerate target is an axis-aligned box extension; it is not mislabeled as a positive-radius cube. Relative-dimensional measure on a degenerate target is not substituted for ambient Lebesgue measure.

## Stronger historical open-cell premise: positive hits and essential maximum

The actual historical contract supplies more than a common boundary point when its witness z lies in every parent open cell. Under the precise additional hypotheses

`z in int(Ai) for every profile source`, `volume(H)>0`,

the stronger product-geometric statement is valid:

`volume(Ai intersect H)>0 iff p=clamp(z,H) belongs to int(Ai)`.

In each coordinate the source interval contains z strictly. Positive interval overlap with the target is then equivalent to strict containment of the clamped coordinate in the source interval. All positive-hit sources therefore contain p in their interiors and contain a common open neighborhood of p. Its intersection with the positive-volume target has positive volume, even when p lies on a target face. Nonpositive source-target contacts contribute only null sets. Hence

`esssup_(x in H) fv(x)=sum_(i:volume(Ai intersect H)>0)vi`.

Thus the earlier boundary-common-z counterexample is not an obstruction under the historical open-cell premise: its z lies on source boundaries. This corrected scope should be used for positive-overlap graphs and a.e. packing when that historical premise has been verified. The numerical appendix does not itself audit an original high-threshold history.

The added computation **filters the already saved160 cases**, rather than generating a new scan. It finds44 cases with strict anchors and positive-volume targets. Including the single explicit tangent fixture,155 source-target positive-hit/interior-clamp equivalences pass. Twenty selected cases in dimensions one and two receive complete exact arrangement checks of the essential maximum. Higher-dimensional selected cases only check the exact equivalence; their finite success is not extrapolated as a proof. The interval proof above supplies the general statement.

The explicit strict tangent fixture is source[-2,2],z=0,H=[2,3],weight1. Closed contact is true, positive-volume hit is false, p=2 is on the source boundary, closed maximum is1, and essential maximum on H is0. Strict anchors do not erase tangencies; they make the interior-clamp test distinguish them correctly.

Reproduce only this scope append without rerunning earlier cases:

```text
/Users/zzh/.local/share/math-research-tools/venv/bin/python /Volumes/data/CodexTemp/centered-cube-r687-20261116/NUMERIC.py --strict-anchor-only
```

All checks passed in about0.036seconds. The earlier boundary, ball, joint-packing and batch-exchange certificates remain intact.

## Scope pressure tests

Without a common source point, the two source squares centered at (-3/2,0),(3/2,0), each of radius1/2, both meet the radius-two target centered at zero. Their weighted intersection count is two, actual maximum is one, and the clamp of z=0 lies in neither source. The common-z premise fails explicitly.

For Euclidean balls, use the specified rational data

`z=(0,0)`, source center `(0,3/2)`, radius `8/5`,

`target center=(2,0)`, radius `1`, nearest target projection `p=(1,0)`.

The source strictly contains z since `9/4<64/25`, but p is outside it since `13/4>64/25`. The centers have distance5/2, less than the radii sum13/5. More explicitly, `(5/4,9/16)` is strictly inside both balls: its squared distances are `625/256<64/25` and `225/256<1`. Thus the balls have positive-area overlap while the projected point misses the source ball. This is a mechanism-scope contrast, not an upper-bound counterexample.

## Bounded exact expansion

The run freezes seed68720261116 and generates 32 rational cases in each dimension1,2,3,4,8: 160 cases and 625 source-target equivalence checks. Each source is a cube explicitly constructed to contain the common rational z; source weights are positive fractions. Target radii may be zero. Every closed-contact equivalence passes. Every case retains its exact source boxes, target, clamp, contact flags, positive-volume flags and boundary flags in RESULT.json.

Only the small fixtures use full arrangements. No high-dimensional exponential arrangement or geometric grid is constructed. The finite seeded checks are consistency evidence; the arbitrary-dimensional identity follows from the elementary interval proof above, not extrapolation from the seed.

## Profile plus target packing: actual2D arrangement

The four source cubes have centers `(-1,0),(1,0),(0,-1),(0,1)`, radius2 and weights one. Therefore sigma=4, each source volume16, and M=64. For gamma=4/5 the source field is integer-valued, so

`Ev={fv>=16/5}=intersection of all four sources=[-1,1]^2`.

The targets have centers/radii

`((3,0),1/2)`, `((3,1/2),3/4)`, `((0,3),1/2)`.

All avoid the closed Ev. Their volumes are `(1,9/4,1)`. The first two targets overlap in positive area; the third is disjoint. Exact target packing is

`theta=(0,1,1)`, `Ptarget=13/4`.

A dual price9/4 on a full-dimensional first/second-target overlap atom and price1 on a third-target atom has total13/4 and dominates every target volume coefficient. This matches the exact primal. HiGHS independently returns the same objective.

The combined load is

`fv/sigma+(1-gamma)ftheta`.

All 529 arrangement atoms, including lower-dimensional boundary atoms, satisfy the bound at most one. The actual maximum is one; restricted to target atoms it is9/20. Its exact Lebesgue integral is

`M/sigma+(1-gamma)Ptarget=16+(1/5)(13/4)=333/20`.

The general pointwise proof uses `fv/sigma<=1` on Ev, where remaining targets vanish. Outside Ev, `fv/sigma<gamma` and target load is at most one, giving total at most one. The proof depends on the stated avoidance and packing conventions; measure-only avoidance does not automatically give a closed-boundary conclusion.

## Valid single and batch exchanges: frozen three-square fixture

Take radius-one squares with centers `(0,0),(-3/2,0),(3/2,0)`, all of volume4. The baseline

`theta=(1/8,7/8,7/8)`

is feasible and has objective15/2. The latter two squares are disjoint.

For any feasible proposal psi, put

`beta_i=esssup_(Ai) fpsi`,

`theta_i'=(1-beta_i)theta_i+psi_i`.

Because beta_i>=fpsi almost everywhere on Ai,

`ftheta'<=ftheta+(1-ftheta)fpsi<=1` almost everywhere.

Also0<=beta_i<=1, so the new coefficients remain nonnegative. In this specific fixture essential and closed beta agree; the script verifies the inequality on every arrangement atom including boundaries.

| proposal | beta | new theta | new objective | gain |
|---|---|---|---:|---:|
| left target only | (1,1,0) | (0,1,7/8) | 15/2 | 0 |
| right target only | (1,0,1) | (0,7/8,1) | 15/2 | 0 |
| both targets | (1,1,1) | (0,1,1) | 8 | 1/2 |

For the batch, the central old neighbor is removed once. Adding the two separate zero-gain calculations would miss this shared expense. Closed and positive-volume neighbor tests are checked separately and coincide for this fixture.

An exact packing dual is the density4 on

`[-1,-1/2]x[-1,1]` and `[1/2,1]x[-1,1]`,

and zero elsewhere. Each rectangle has area one, so total dual integral is8. Its integrals over the three squares are `(8,4,4)`, each at least the corresponding volume4. The primal `(0,1,1)` also has value8. Thus the optimal packing value is exactly8, and the batch gain1/2 is certified.

## Reproducibility and status

Command for the initial single bounded geometry run:

```text
/Users/zzh/.local/share/math-research-tools/venv/bin/python /Volumes/data/CodexTemp/centered-cube-r687-20261116/NUMERIC.py
```

The final requested frozen exchange was appended without rerunning the seeded cases:

```text
/Users/zzh/.local/share/math-research-tools/venv/bin/python /Volumes/data/CodexTemp/centered-cube-r687-20261116/NUMERIC.py --exchange-only
```

Every geometry, arrangement volume, profile load, primal flow, dual density integral and objective uses exact Fraction arithmetic. Python/platform/NumPy/SciPy versions and the frozen seed are retained in RESULT.json. SciPy1.18.1/HiGHS only cross-checks the first target packing LP; the proof uses its exact primal and dual. The initial run finished in about0.48seconds, the exchange append in about0.009seconds, all assertions passed, errors are empty, and all processes exited with code zero; the later strict-anchor append also passed as recorded above.

Source SHA-256: `243d6154b301be98d0c8e1088cd67ccc42965ac25cbb407f5ca3960526b7a5e0`. Result SHA-256: `c833f6848180a3f8b42ab11a4b0d634d17be1e243fdc675a074c14816b38a3f1`.

Only the three owned R687 files were written. No package installation, Git operation, PDF, child agent, Monte Carlo extrapolation or further parameter scan was used. Computation is stopped pending acceptance.
