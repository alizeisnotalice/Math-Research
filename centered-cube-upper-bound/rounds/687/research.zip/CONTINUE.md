# R687 continuation: target the cross-history refund, not more one-group tools

Original all-L1/all-scales/fixedLebesgue C_n<=Ksqrt(n) remains unproved. Round687 has no new uniform upper bound. User configuration stays maxONE Astra andTHREE GPT-6.1 Sol, reused. Full original P0 has ALL parents inclq0, no oldq caps. Preserve R684 receiver normalization and full entrance fees, not false old fixed G-rich moment.

## Verified original product geometry

Sources Ai sharing z, H axisaligned, p=clamp(z,H): closedhit iff p∈Ai, so closedmax_H fv=sum closedhit vi. Actual historical z lies in ALL-parent OPEN arrangementcell, hence strictinside all sources AND assigned targets. Therefore for positive-volume H, positivehit iff p∈intAi, and esssup_H fv=sum positivehit vi. The earlier boundary-commonpoint example does NOT defeat this actual strict version. Cross-anchor maxima still cannot be treated as the same point.

R686 actual-parent capture remains etaM(v) for radius-compatible parents meetingEv, eta3exp[-(2+ln.8)ceil128sqrt(n)]. One-profile mix t v/sigma+(1−.8t)theta is feasible for targets avoidingEv, but netgain=t(M/sigma−.8P_rem), maynonpositive. Multi-profile Halpha must retain nonnegativealpha, globalHalpha<=1 and one actualGamma=esssup_remaining-parent-union Halpha. No cumulativeGamma improvement established.

## The genuine exchange and actual whole-V connection

For any feasible baseline theta and feasible target proposal psi, fpsi<=1, beta_i=esssup_Ai fpsi. theta'=(1−beta)theta+psi is feasible; gain Dpsi−Σdi theta_i beta_i. This uses full-parent essentialsup, not ownerFi or a common intersection. Shared-neighbor costs may be removed once. Exact3square fixture verifies single gains0,0 but batchgain1/2; dualopt8. It is a geometry certificate, NOT a high-tau history.

For the actual baseline theta=q/tau, Δ=tauP0−U=∫(tau−g)h+Σqi ri>=0, where h attainingdual,ri=∫Ai h−di. Each actual remaining target contains a positive-volume cell where g=tau, so Δ is NOT pointwise room to addtargetcoefficients.

For actual disjoint X_h definew_h=|X_h|/dh,F=Σw1Ah,L=esssupF,m_i=esssup_Ai F. ForV>0,psi=w/L is explicitfeasible, and exactexchange gives

    tau V <= Σmu_i m_i + LΔ.

More generally same holds for any nonnegative originaldebitp with Dp>=V, usingFp. R686profile+residualdebit is allowed. A sufficient complete missingbudget is

    Σmu_i esssup_Ai Fp + ||Fp||infty Δ <= C tau(U+Δ).

THIS IS UNPROVED. Simply writing the fee, or assuming a goodpsi exists, is not progress toward payment. True global geometry must control different histories on same sources with real receiver volume and all scales.

## New decision: no positive exchange inside one original group

Forpsi supportedone truehistorygroupb, strictcommonz_b gives beta_i=Σ_{h∈b:positivehit(Ai,Ah)}psi_h. Thusremovalcost is LINEAR inpsi; packingfeasibility is exactlyΣpsi_h<=1. Bestgain≤bestsingleparentgain.

More strongly foractualbaselineq/tau: everytargeth has entire fullpoolPb rate tau, sourcesradii>=seedradius>=sh, and positive-volume source-target overlaps. Hence itsneighborremovalcostc_h=(1/tau)Σ_positivehit qi di >= (1/tau)Σ_Pb qi di >=dh. EVERYsingle-group proposal has nonpositivegain. To obtain a positive static batchgain one MUST mix distinct historical groups, or first changebaseline. This follows actualhistory, not finiteexamples. Do not spend another round searching one-group improvements of this fixedexchange.

## Actual checks and saved evidence

Python3.12.14 local mathvenv ran exactFraction geometry andpackings.4boundary fixtures,160seededcases(n1,2,3,4,8),625seededclosedchecks;529-atom packingidentity;3square exchange exactprimal/dual;strictanchor155checks and20fullarrangements reused existingcases. Generalclaims have writtenintervalproofs, not extrapolatedtests. HiGHS onlyfloatingcrosscheck. Mainverify independentlyrebuilds633totalclosedchecks inclfixtures,155strictchecks,20essentialarrangements andgain0,0,1/2 withdual8. PASS. NoMATLAB/PDF/install. NUMERIC default runs allcurrentcertificates;appendflags retainolddata. Originalmanifest verification first; rerun in separatecopy ifcomparingmathfields becauseelapsedtimechangeshash.

Next completedround688. Research next: cross-history joint selection / source deletion with positive summable truegain or equivalent fullfee bound. No arbitrary terminalT theorem or localrepeat can replace that missingglobalstep.
