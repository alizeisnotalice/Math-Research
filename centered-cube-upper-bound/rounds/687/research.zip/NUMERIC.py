#!/usr/bin/env python3
"""R687 exact common-point cube projection and joint packing consistency audit."""
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import json,hashlib,sys,platform,time,random
ROOT=Path(__file__).resolve().parent;tick=time.time();SEED=68720261116

def cube(y,s):return [(v-s,v+s) for v in y]
def inside(p,B):return all(lo<=v<=hi for v,(lo,hi) in zip(p,B))
def clamp(z,H):return [max(lo,min(hi,v)) for v,(lo,hi) in zip(z,H)]
def overlap(A,B):return all(max(a0,b0)<=min(a1,b1) for (a0,a1),(b0,b1) in zip(A,B))
def positive(A,B):return all(max(a0,b0)<min(a1,b1) for (a0,a1),(b0,b1) in zip(A,B))
def volume(B):
 out=F(1)
 for lo,hi in B:out*=hi-lo
 return out

def atoms(boxes):
 axes=[]
 for t in range(len(boxes[0])):
  ends=sorted(set(v for B in boxes for v in B[t]));aa=[]
  for j,e in enumerate(ends):
   aa.append((e,F(0),0))
   if j+1<len(ends):aa.append(((e+ends[j+1])/2,ends[j+1]-e,1))
  axes.append(aa)
 for xs in product(*axes):yield [v[0] for v in xs],volume([(F(0),v[1]) for v in xs]),sum(v[2] for v in xs)
def serial(v):
 if isinstance(v,F):return str(v)
 if isinstance(v,(list,tuple)):return [serial(x) for x in v]
 if isinstance(v,dict):return {k:serial(x) for k,x in v.items()}
 return v

def check_case(name,z,As,H,weights,with_arrangement=False):
 assert all(inside(z,A) for A in As)
 p=clamp(z,H);flags=[overlap(A,H) for A in As];atp=[inside(p,A) for A in As]
 assert flags==atp
 closed=sum((w for w,a in zip(weights,flags) if a),F(0))
 result={'name':name,'z':z,'sources':As,'target':H,'weights':weights,'clamped_point':p,'closed_contact_flags':flags,'positive_volume_overlap_flags':[positive(A,H) for A in As],'p_on_source_boundary':[inside(p,A) and any(v==lo or v==hi for v,(lo,hi) in zip(p,A)) for A in As],'closed_maximum_from_clamp':closed,'closed_contact_equivalence_passed':True,'target_dimension':sum(lo<hi for lo,hi in H)}
 if with_arrangement:
  mx=F(0);essential=F(0);count=0
  for pt,mass,dim in atoms(As+[H]):
   if inside(pt,H):
    value=sum((w for w,A in zip(weights,As) if inside(pt,A)),F(0));mx=max(mx,value)
    if mass>0:essential=max(essential,value)
    count+=1
  assert mx==closed
  result.update({'arrangement_closed_maximum':mx,'full_dimensional_essential_maximum':essential if volume(H)>0 else None,'arrangement_atoms_in_target':count})
 return result
def append_exchange_certificate():
 old=json.loads((ROOT/'RESULT.json').read_text());start=time.time()
 # Preserve previous fixtures; replace packing dual witnesses by full-dimensional atoms.
 for entry in old['joint_packing_fixture']['exact_dual_pattern_prices']:
  for row in old['joint_packing_fixture']['arrangement_atoms']:
   if row['target_mask']==entry['mask'] and F(row['Lebesgue_mass'])>0:
    entry['witness']=row['point'];entry['witness_is_full_dimensional']=True;break
 Bs=[cube([F(0),F(0)],F(1)),cube([F(-3,2),F(0)],F(1)),cube([F(3,2),F(0)],F(1))]
 theta=[F(1,8),F(7,8),F(7,8)];vol=[volume(B) for B in Bs];baseline=sum((a*b for a,b in zip(theta,vol)),F(0))
 assert baseline==F(15,2)
 aa=list(atoms(Bs));models=[]
 for name,psi in (('left_single',[F(0),F(1),F(0)]),('right_single',[F(0),F(0),F(1)]),('two_target_batch',[F(0),F(1),F(1)])):
  beta=[F(0)]*3;closedbeta=[F(0)]*3
  for pt,mass,dim in aa:
   ff=sum((w for w,B in zip(psi,Bs) if inside(pt,B)),F(0));assert ff<=1
   for i,B in enumerate(Bs):
    if inside(pt,B):
     closedbeta[i]=max(closedbeta[i],ff)
     if mass>0:beta[i]=max(beta[i],ff)
  assert beta==closedbeta
  newtheta=[(1-beta[i])*theta[i]+psi[i] for i in range(3)]
  rows=[]
  for pt,mass,dim in aa:
   load=sum((w for w,B in zip(theta,Bs) if inside(pt,B)),F(0));ff=sum((w for w,B in zip(psi,Bs) if inside(pt,B)),F(0))
   after=sum((w for w,B in zip(newtheta,Bs) if inside(pt,B)),F(0));upper=load+(1-load)*ff
   assert load<=1 and after<=upper<=1
   rows.append({'point':pt,'mass':mass,'dimension':dim,'baseline_load':load,'proposal_load':ff,'new_load':after,'exchange_upper_bound':upper})
  objective=sum((a*b for a,b in zip(newtheta,vol)),F(0));gain=objective-baseline
  assert gain==(F(1,2) if name=='two_target_batch' else F(0))
  neigh_pos=[any(positive(Bs[i],Bs[j]) for j,w in enumerate(psi) if w) for i in range(3)]
  neigh_closed=[any(overlap(Bs[i],Bs[j]) for j,w in enumerate(psi) if w) for i in range(3)]
  assert neigh_pos==neigh_closed
  models.append({'name':name,'psi':psi,'beta_essential_supremum':beta,'beta_closed_maximum':closedbeta,'theta_prime':newtheta,'objective':objective,'gain':gain,'positive_volume_neighbor_flags':neigh_pos,'closed_neighbor_flags':neigh_closed,'all_exchange_load_inequalities_passed':True,'arrangement':rows})
 overlapboxes=[[(F(-1),F(-1,2)),(F(-1),F(1))],[(F(1,2),F(1)),(F(-1),F(1))]]
 dual_integrals=[F(0)]*3;dual_cost=F(0)
 for pt,mass,dim in atoms(Bs+overlapboxes):
  h=4*sum(inside(pt,B) for B in overlapboxes)
  dual_cost+=mass*h
  for i,B in enumerate(Bs):
   if inside(pt,B):dual_integrals[i]+=mass*h
 assert dual_integrals==[F(8),F(4),F(4)] and dual_cost==8
 assert all(dual_integrals[i]>=vol[i] for i in range(3))
 old['exchange_certificate']=serial({'scope':'Actual rational2D squares and valid packing exchange/primal-dual certificate, not original high-tau history.','squares':Bs,'volumes':vol,'baseline_theta':theta,'baseline_objective':baseline,'proposal_models':models,'dual_density':'4 on each of two disjoint overlap rectangles,0 elsewhere','dual_overlap_rectangles':overlapboxes,'dual_integrals_on_squares':dual_integrals,'dual_total_integral':dual_cost,'optimal_primal_theta':[F(0),F(1),F(1)],'optimal_packing_value':F(8),'single_gain_zero_batch_gain_half':True,'general_exchange_formula':'theta_i_prime=(1-beta_i)theta_i+psi_i, beta_i=esssup_(Ai) fpsi','general_load_bound':'ftheta_prime <= ftheta+(1-ftheta)fpsi <=1 a.e., for feasible theta,psi','boundary_scope':'The general essential-supremum formula is a.e.; in this fixture essential and closed beta agree, and all arrangement atoms including boundary points satisfy the inequality.','elapsed_seconds':time.time()-start})
 old['script_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
 (ROOT/'RESULT.json').write_text(json.dumps(old,indent=2)+'\n')
 print(json.dumps({'exchange_values':{'baseline':str(baseline),'optimum':str(dual_cost),'dual_integrals':[str(v) for v in dual_integrals]},'elapsed_seconds':time.time()-start,'source_sha256':old['script_sha256'],'RESULT_sha256':hashlib.sha256((ROOT/'RESULT.json').read_bytes()).hexdigest()},indent=2))

def append_strict_anchor_certificate():
 old=json.loads((ROOT/'RESULT.json').read_text());start=time.time()
 def interior(x,B):return all(lo<v<hi for v,(lo,hi) in zip(x,B))
 def parse_box(B):return [(F(lo),F(hi)) for lo,hi in B]
 chosen=[];pair_count=0;arr_count=0
 inputs=[]
 for row in old['seeded_expanded_cases']:
  z=[F(v) for v in row['z']];H=parse_box(row['target']);As=[parse_box(B) for B in row['sources']];ww=[F(v) for v in row['weights']]
  if volume(H)>0 and all(interior(z,B) for B in As):inputs.append((row['name'],z,As,H,ww,False))
 reused_count=len(inputs)
 inputs.append(('explicit strict anchor tangent interval',[F(0)],[[(-F(2),F(2))]],[(F(2),F(3))],[F(1)],True))
 for name,z,As,H,ww,explicit in inputs:
  assert volume(H)>0 and all(interior(z,B) for B in As)
  pp=clamp(z,H);poshit=[positive(B,H) for B in As];intp=[interior(pp,B) for B in As];closed=[overlap(B,H) for B in As]
  assert poshit==intp
  wanted=sum((w for w,hit in zip(ww,poshit) if hit),F(0));rec={'name':name,'dimension':len(z),'explicit_tangent_fixture':explicit,'positive_volume_flags':poshit,'interior_clamp_flags':intp,'closed_contact_flags':closed,'clamped_point':pp,'predicted_essential_maximum':wanted,'strict_anchor_verified':True,'positive_target_volume':volume(H),'all_positive_hit_equivalences_passed':True}
  pair_count+=len(As)
  if len(z)<=2:
   essential=F(0);closedmax=F(0);count=0
   for pt,mass,dim in atoms(As+[H]):
    if inside(pt,H):
     field=sum((w for w,B in zip(ww,As) if inside(pt,B)),F(0));closedmax=max(closedmax,field)
     if mass>0:essential=max(essential,field)
     count+=1
   assert essential==wanted
   rec.update({'complete_arrangement_essential_maximum':essential,'complete_arrangement_closed_maximum':closedmax,'complete_arrangement_atom_count_in_target':count,'complete_essential_maximum_verified':True});arr_count+=1
  if explicit:
   assert closed==[True] and poshit==[False] and intp==[False] and pp==[F(2)] and wanted==0 and rec['complete_arrangement_closed_maximum']==1
   rec.update({'z':z,'sources':As,'target':H,'weights':ww})
  chosen.append(rec)
 assert reused_count>0 and arr_count>1
 old['strict_anchor_positive_volume_certificate']=serial({'scope':'Stronger valid essential-maximum lemma under z strictly interior to every profile source and positive-volume target. Reuses existing seeded cases; no new random scan or original-history realization is asserted.','general_statement':'For closed axis-aligned source boxes with z in every interior and positive-volume H, volume(Ai intersect H)>0 iff clamp(z,H) is in int(Ai). Hence esssup_H fv=sum_(positive-volume hits)i vi.','proof':'Coordinatewise strict interval overlap is equivalent to strict source containment of the clamped point when z is interior. All positive-hit sources contain one common open neighborhood of p; its intersection with positive-volume H has positive volume. Nonpositive contacts contribute only null sets.','reused_existing_case_count':reused_count,'explicit_tangent_fixture_count':1,'source_target_equivalence_checks':pair_count,'complete_small_dimension_arrangements':arr_count,'cases':chosen,'boundary_interpretation':'Closed tangent sources remain in the closed maximum but are excluded from positive-volume hits and essential maximum. The old nonstrict common-z counterexample does not contradict this stronger statement.','historical_contract_relevance':'A verified actual historical common witness lying in every parent open cell supplies this strict-anchor premise; this numerical appendix does not independently audit an original high-threshold history.','elapsed_seconds':time.time()-start,'all_checks_passed':True})
 old['script_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
 (ROOT/'RESULT.json').write_text(json.dumps(old,indent=2)+'\n')
 print(json.dumps({'strict_anchor_reused_cases':reused_count,'positive_hit_checks':pair_count,'small_complete_arrangements':arr_count,'explicit_tangent_checked':True,'elapsed_seconds':time.time()-start,'source_sha256':old['script_sha256'],'RESULT_sha256':hashlib.sha256((ROOT/'RESULT.json').read_bytes()).hexdigest()},indent=2))

if '--strict-anchor-only' in sys.argv:
 append_strict_anchor_certificate()
 raise SystemExit(0)

if '--exchange-only' in sys.argv:
 append_exchange_certificate()
 raise SystemExit(0)

# Stage1 initial exact closed/contact/positive-volume/degenerate fixtures.
small=[]
small.append(check_case('1D boundary contact versus essential maximum',[F(0)],[[(-F(1),F(0))],[(F(0),F(1))]],[(-F(1,2),F(1,2))],[F(1),F(1)],True))
small.append(check_case('2D boundary-only common witness',[F(0),F(0)],[cube([F(-1),F(0)],F(1)),cube([F(1),F(0)],F(1))],cube([F(0),F(0)],F(1,2)),[F(2),F(3)],True))
small.append(check_case('2D target point degeneration',[F(0),F(0)],[cube([F(1),F(0)],F(1)),cube([F(0),F(1)],F(1))],cube([F(1),F(1)],F(0)),[F(1),F(2)],True))
small.append(check_case('2D coordinate-degenerate axis-box target',[F(0),F(0)],[cube([F(-1),F(0)],F(1)),cube([F(1),F(0)],F(1))],[(F(0),F(0)),(-F(1,2),F(1,2))],[F(1),F(1)],True))
# Stage2 scope contrasts: missing common point and Euclidean balls.
Aleft=cube([F(-3,2),F(0)],F(1,2));Aright=cube([F(3,2),F(0)],F(1,2));HH=cube([F(0),F(0)],F(2));zz=[F(0),F(0)];pp=clamp(zz,HH)
assert not inside(zz,Aleft) and not inside(zz,Aright)
assert overlap(Aleft,HH) and overlap(Aright,HH) and not inside(pp,Aleft) and not inside(pp,Aright)
no_common={'sources':[Aleft,Aright],'target':HH,'candidate_z':zz,'clamp':pp,'intersecting_source_count':2,'load_at_clamp':0,'actual_closed_maximum':1,'scope':'Common-z hypothesis is absent; the claimed conclusion must not be applied.'}
z=[F(0),F(0)];ca=[F(0),F(3,2)];ra=F(8,5);ch=[F(2),F(0)];rh=F(1);p=[F(1),F(0)];w=[F(5,4),F(9,16)]
def dist2(a,b):return sum(((u-v)**2 for u,v in zip(a,b)),F(0))
assert dist2(z,ca)<ra**2 and dist2(p,ca)>ra**2 and dist2(ca,ch)<(ra+rh)**2
assert dist2(w,ca)<ra**2 and dist2(w,ch)<rh**2
balls={'z':z,'source_ball_center':ca,'source_ball_radius':ra,'target_ball_center':ch,'target_ball_radius':rh,'nearest_projection_point':p,'z_distance2_to_source_center':dist2(z,ca),'p_distance2_to_source_center':dist2(p,ca),'source_radius2':ra**2,'center_distance2':dist2(ca,ch),'radii_sum_squared':(ra+rh)**2,'strict_intersection_witness':w,'w_source_distance2':dist2(w,ca),'w_target_distance2':dist2(w,ch),'scope':'Euclidean balls have positive overlap but the nearest target projection of z misses the source ball. Axis-aligned product geometry is essential.'}
# Stage3 bounded seeded Fraction expansion, no exponential arrangement in high dimension.
rng=random.Random(SEED);expanded=[];pair_checks=0
for n in (1,2,3,4,8):
 for j in range(32):
  z=[F(rng.randint(-4,4),4) for _ in range(n)];As=[];ww=[]
  for i in range(2+j%5):
   center=[z[t]+F(rng.randint(-8,8),4) for t in range(n)]
   radius=max(abs(center[t]-z[t]) for t in range(n))+F(rng.randrange(4),4)
   As.append(cube(center,radius));ww.append(F(rng.randint(1,7),3))
  hc=[F(rng.randint(-12,12),4) for _ in range(n)];hr=F(rng.randint(0,8),4);H=cube(hc,hr)
  row=check_case(f'seeded_n{n}_case{j}',z,As,H,ww)
  expanded.append(row);pair_checks+=len(As)
# Actual2D cube arrangement for the joint packing identity.
v=[F(1)]*4;sources=[cube([F(-1),F(0)],F(2)),cube([F(1),F(0)],F(2)),cube([F(0),F(-1)],F(2)),cube([F(0),F(1)],F(2))]
targets=[cube([F(3),F(0)],F(1,2)),cube([F(3),F(1,2)],F(3,4)),cube([F(0),F(3)],F(1,2))]
sigma=sum(v,F(0));gamma=F(4,5);Ev=cube([F(0),F(0)],F(1));theta=[F(0),F(1),F(1)];targetvol=[volume(B) for B in targets];patterns={};jointmax=F(0);targetjointmax=F(0);arr=[]
for pt,mass,dim in atoms(sources+targets+[Ev]):
 f=sum((vv for vv,B in zip(v,sources) if inside(pt,B)),F(0));tf=[inside(pt,B) for B in targets]
 assert (f>=gamma*sigma)==inside(pt,Ev)
 assert not inside(pt,Ev) or not any(tf)
 tload=sum((tt for tt,yes in zip(theta,tf) if yes),F(0));assert tload<=1
 joint=f/sigma+(1-gamma)*tload;assert joint<=1
 jointmax=max(jointmax,joint)
 if any(tf):targetjointmax=max(targetjointmax,joint)
 mask=sum((1<<i) for i,yes in enumerate(tf) if yes)
 if mask and mask not in patterns:patterns[mask]=pt
 arr.append({'point':pt,'atom_dimension':dim,'Lebesgue_mass':mass,'source_field':f,'target_mask':mask,'target_load':tload,'joint_load':joint})
assert 3 in patterns and 4 in patterns
# Exact packing primal/dual on every occurring target overlap pattern.
dual={3:F(9,4),4:F(1)};P=sum((tt*vv for tt,vv in zip(theta,targetvol)),F(0))
assert P==F(13,4)
for i in range(3):assert sum((yy for mask,yy in dual.items() if mask>>i&1),F(0))>=targetvol[i]
assert sum(dual.values(),F(0))==P
M=sum((vv*volume(B) for vv,B in zip(v,sources)),F(0));objective=M/sigma+(1-gamma)*P
assert M==64 and objective==F(333,20) and jointmax==1 and targetjointmax==F(9,20)
# Integral cross-check of the actual arrangement, boundaries excluded only for integration.
assert sum((row['Lebesgue_mass']*row['joint_load'] for row in arr),F(0))==objective
import numpy as np
import scipy
from scipy.optimize import linprog
masks=sorted(patterns);AA=np.array([[int(mask>>i&1) for i in range(3)] for mask in masks],dtype=float)
lp=linprog(-np.array([float(x) for x in targetvol]),A_ub=AA,b_ub=np.ones(len(masks)),bounds=(0,None),method='highs');assert lp.success and abs(-lp.fun-float(P))<1e-10
packing={'source_cubes':sources,'source_weights':v,'sigma':sigma,'gamma':gamma,'superlevel_set_Ev':Ev,'target_cubes':targets,'target_volumes':targetvol,'all_targets_avoid_closed_Ev':True,'target_overlap_patterns':[{'mask':mask,'witness':patterns[mask]} for mask in masks],'theta_exact_primal':theta,'target_packing_optimum_exact':P,'exact_dual_pattern_prices':[{'mask':mask,'price':value,'witness':patterns[mask]} for mask,value in dual.items()],'M':M,'source_objective_M_over_sigma':M/sigma,'joint_objective_exact':objective,'joint_maximum_on_all_atoms':jointmax,'joint_maximum_on_target_atoms':targetjointmax,'arrangement_integral_exact':objective,'arrangement_atoms':arr,'HiGHS_crosscheck':{'scipy_version':scipy.__version__,'success':bool(lp.success),'objective':float(-lp.fun),'max_objective_discrepancy':abs(float(-lp.fun)-float(P))},'scope':'Actual rational2D cube arrangement and packing identity only; no original high-tau saturation history is asserted.'}
out={'scope':'Exact geometric scope and consistency checks; no original maximal-operator upper bound or hard-history counterexample claimed.','python':sys.version,'platform':platform.platform(),'numpy_version':np.__version__,'scipy_version':scipy.__version__,'arithmetic':'Fraction for all geometry, atom volumes, profile loads and primal/dual certificates; SciPy HiGHS floating cross-check only','seed':SEED,'command':[sys.executable,str(Path(__file__).resolve())],'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'small_closed_and_boundary_fixtures':serial(small),'missing_common_point_contrast':serial(no_common),'Euclidean_ball_contrast':serial(balls),'seeded_expanded_cases':serial(expanded),'joint_packing_fixture':serial(packing),'summary':{'small_fixture_count':len(small),'expanded_fixture_count':len(expanded),'expanded_pair_checks':pair_checks,'dimensions':[1,2,3,4,8],'all_closed_contact_equivalences_passed':True,'joint_arrangement_atom_count':len(arr),'exact_packing_primal_dual_equal':True,'closed_vs_positive_volume_distinguished':True},'elapsed_seconds':time.time()-tick,'errors':[]}
(ROOT/'RESULT.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'summary':out['summary'],'elapsed_seconds':out['elapsed_seconds'],'source_sha256':out['script_sha256'],'RESULT_sha256':hashlib.sha256((ROOT/'RESULT.json').read_bytes()).hexdigest(),'packing_values':{'P':str(P),'objective':str(objective),'target_joint_max':str(targetjointmax)}},indent=2))

append_exchange_certificate()

append_strict_anchor_certificate()
