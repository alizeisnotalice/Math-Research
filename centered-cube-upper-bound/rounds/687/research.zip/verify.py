from pathlib import Path
from fractions import Fraction as F
from itertools import product
import json,hashlib
P=Path(__file__).resolve().parent;j=json.loads((P/'RESULT.json').read_text())
assert hashlib.sha256((P/'NUMERIC.py').read_bytes()).hexdigest()==j['script_sha256']
def box(v):return [tuple(map(F,t)) for t in v]
def contains(A,x,strict=False):return all(l<t<u if strict else l<=t<=u for (l,u),t in zip(A,x))
def hit(A,B,strict=False):return all(max(l,a)<min(u,b) if strict else max(l,a)<=min(u,b) for (l,u),(a,b) in zip(A,B))
def vol(A):
 r=F(1)
 for l,u in A:r*=u-l
 return r
def cells(boxes):
 axes=[]
 for t in range(len(boxes[0])):
  e=sorted({v for A in boxes for v in A[t]})
  axes.append([(e[q]+e[q+1])/2 for q in range(len(e)-1)])
 return product(*axes)
def field(A,w,x):return sum((a for a,B in zip(w,A) if contains(B,x)),F(0))
count=0;records=j['small_closed_and_boundary_fixtures']+j['seeded_expanded_cases'];lookup={r['name']:r for r in records}
for row in records:
 z=list(map(F,row['z']));H=box(row['target']);As=list(map(box,row['sources']));p=[min(u,max(l,t)) for (l,u),t in zip(H,z)]
 assert p==list(map(F,row['clamped_point']))
 for A,flag in zip(As,row['closed_contact_flags']):
  assert contains(A,z) and hit(A,H)==contains(A,p)==flag;count+=1
strictcount=0;essentialchecks=0
for rr in j['strict_anchor_positive_volume_certificate']['cases']:
 row=rr if rr['explicit_tangent_fixture'] else lookup[rr['name']]
 z=list(map(F,row['z']));H=box(row['target']);As=list(map(box,row['sources']));w=list(map(F,row['weights']));p=[min(u,max(l,t)) for (l,u),t in zip(H,z)]
 assert vol(H)>0 and all(contains(A,z,True) for A in As)
 flags=[hit(A,H,True) for A in As]
 assert flags==[contains(A,p,True) for A in As]==rr['positive_volume_flags']
 expected=sum((v for v,flag in zip(w,flags) if flag),F(0));assert expected==F(rr['predicted_essential_maximum']);strictcount+=len(As)
 if 'complete_arrangement_essential_maximum' in rr:
  observed=max((field(As,w,x) for x in cells(As+[H]) if contains(H,x,True)),default=F(0))
  assert observed==expected==F(rr['complete_arrangement_essential_maximum']);essentialchecks+=1
p=j['joint_packing_fixture'];As=list(map(box,p['source_cubes']));Hs=list(map(box,p['target_cubes']));v=list(map(F,p['source_weights']));theta=list(map(F,p['theta_exact_primal']));sigma=F(p['sigma']);gamma=F(p['gamma'])
assert sum(vol(H)*t for H,t in zip(Hs,theta))==F(13,4)
for x in cells(As+Hs):assert field(As,v,x)/sigma+(1-gamma)*field(Hs,theta,x)<=1
prices=p['exact_dual_pattern_prices'];assert sum(F(q['price']) for q in prices)==F(13,4)
for h,H in enumerate(Hs):assert sum(F(q['price']) for q in prices if q['mask']>>h&1)>=vol(H)
for q in prices:
 x=list(map(F,q['witness']));assert sum(1<<h for h,H in enumerate(Hs) if contains(H,x,True))==q['mask']
e=j['exchange_certificate'];Bs=list(map(box,e['squares']));old=list(map(F,e['baseline_theta']));assert sum(vol(B)*w for B,w in zip(Bs,old))==F(15,2)
for row,want in zip(e['proposal_models'],[F(0),F(0),F(1,2)]):
 psi=list(map(F,row['psi']));xs=list(cells(Bs));beta=[max(field(Bs,psi,x) for x in xs if contains(B,x,True)) for B in Bs]
 assert beta==list(map(F,row['beta_essential_supremum']))
 new=[(1-b)*o+p for b,o,p in zip(beta,old,psi)]
 assert new==list(map(F,row['theta_prime']))
 assert all(field(Bs,new,x)<=1 for x in xs)
 assert sum(vol(B)*(a-b) for B,a,b in zip(Bs,new,old))==want==F(row['gain'])
rects=list(map(box,e['dual_overlap_rectangles']));assert 4*sum(map(vol,rects))==8
ints=[]
for B in Bs:
 ints.append(4*sum((vol([(max(l,a),min(u,b)) for (l,u),(a,b) in zip(B,R)]) if hit(B,R,True) else F(0)) for R in rects))
assert ints==[F(8),F(4),F(4)]==list(map(F,e['dual_integrals_on_squares']))
assert sum(vol(B)*v for B,v in zip(Bs,map(F,e['optimal_primal_theta'])))==8
ball=j['Euclidean_ball_contrast'];x=list(map(F,ball['strict_intersection_witness']))
for key,rkey in [('source_ball_center','source_ball_radius'),('target_ball_center','target_ball_radius')]:assert sum((a-F(b))**2 for a,b in zip(x,ball[key]))<F(ball[rkey])**2
if (P/'MANIFEST.json').exists():
 for name,digest in json.loads((P/'MANIFEST.json').read_text()).items():assert hashlib.sha256((P/name).read_bytes()).hexdigest()==digest,name
print(json.dumps({'status':'PASS','closed_pair_checks':count,'strict_pair_checks':strictcount,'independent_essential_arrangements':essentialchecks,'exact_exchange_gains':['0','0','1/2'],'scope':'finite geometric/packing certificates; no general upper bound'}))
