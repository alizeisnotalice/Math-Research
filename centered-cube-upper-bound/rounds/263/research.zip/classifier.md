# R263：actual classifier 的目标测度表达与连续平方路线的准确缺口

本稿是一次有界、未成功付款的检查。没有证明新的连续恢复根阶预算；以下转化不登记为新付款。始终保原 receiver、近 hard 来源、完整后验、后缀图与原负账。

## 1. 同一实际 receiver 的目标测度

固定完整原行及实际 x，记
\[
 T_x(v)=Q_x^*(v)=\tfrac13\left[P_{s(x),L(x)}(x-v)
 +P_{s(x),L^+(x)}(x-v)+P_{1,b}(x-v)\right],
 \quad L^+=\min\{b,(1+1/n)L\}.
\]
三腿完整保留。原 actual/future FIRST 授
\(\int T_x\,d\nu\le q\)。定义真实有限子概率测度
\[
 d\Sigma_x(v)=T_x(v)d\nu(v)/q,\qquad \Sigma_x(V)\le1.
\]
第三 J 腿保证 \(T_x(v)>0\)。对合法 \(e_t(y)>0\) 行，定义
\[
 L_t(v)=\frac{d\Pi_{y,t}}{d\Sigma_x}(v)
 =\frac{q\,1_{Z_t(y)}(v)w_t(y,v)}{e_t(y)T_x(v)}.
 \tag{1}
\]
于是 \(\int L_t\,d\Sigma_x=1\)。这是完整原 \(\Pi\) 的 RN 表达，不是换来源，也不把 \(\Sigma_x\) 重新归一。其依赖实际 x 及 actual s,L，不是静态节点或所有参数的 supremum。

原 terminal classifier 恰等价于
\[
 \gamma=\frac{Kq}{p_y e_g}\le\tfrac12,
 \qquad G=Z_g\cap\{L_g\le\gamma\},\quad
 B=Z_g\cap\{L_g>\gamma\}. \tag{2}
\]
因此 \(\Pi_g(G)\le\gamma\Sigma_x(G)\le1/2\)。该帽只在 g；它不授当前 \(\Pi_t(G)\le1/2\)，也不授 \(L_t\) 的平方帽。

## 2. 实际后缀图上的 signed 二次项

记 \(h=ge^{-u/n}\)。在 G、B 上所有来源活到 g，故 \(L_h>0\)。写
\[
 R_v(t)=L_t(v)/L_h(v)
 =w_t(v)e_h/[w_h(v)e_t].
\]
原 suffix 资格给每条 \((b,c)\in\mathcal Z\subset B\times G\) 上
\(R_b(t)\ge R_c(t)\)，但不授其当前导数的符号。完整 \(\Pi_h=L_h\Sigma_x\) 还含 \(Z_h\setminus Z_g\)，不能只用 B、G 重新归一。

原 raw pair potential 为
\(Q_{bc}=w_t(b)w_t(c)-[w_h(b)/w_h(c)]w_t(c)^2\)。其准确目标测度表达是
\[
 \frac{Q_{bc}}{e_t^2}\,d\nu(b)d\nu(c)
 =\left[L_t(b)L_t(c)-\frac{L_h(b)}{L_h(c)}L_t(c)^2\right]
 d\Sigma_x(b)d\Sigma_x(c). \tag{3}
\]
所以 R262 连续项完整地变为
\[
 2\int_\ell^h\iint_{\mathcal Z}(m_t-k_t(c))
 \left[L_t(b)L_t(c)-\frac{L_h(b)}{L_h(c)}L_t(c)^2\right]
 d\Sigma_x^2\,\frac{dt}{t}. \tag{4}
\]
不补齐 \(\mathcal Z\)，不丢第二平方项或 \(-k_t(c)\)。式 (2) 只是 terminal 似然的阈值分类；FIRST 的 \(\Sigma_x(V)\le1\) 不能直接给式 (4) 的有符号系数施加质量帽。

## 3. good/FIRST 能消去的量及最早未付平方

仍使用 R261 的图保留 Jensen 上界 \(Q_t\le Q_{\rm row}(t)\)。令
\[
 V_B(t,h)=\int_B\frac{w_t(b)^2}{w_h(b)}d\nu(b).
\]
完成平方与原 good/FIRST 给
\[
 Q_{\rm row}(t)\le\frac14\left(\int_Gw_h(c)d\nu(c)\right)V_B(t,h)
 \le\frac{e^uKq}{4p_y}V_B(t,h). \tag{5}
\]
这里必须保 \(w_h\le e^u w_g\)；终端 good 不能无损搬到 h。

关键平方有精确恒等式
\[
 \boxed{\frac{V_B(t,h)}{e_t^2}
 =\frac1{e_h}\int_B\frac{L_t(b)^2}{L_h(b)}\,d\Sigma_x(b).} \tag{6}
\]
其反权是同一 actual 目标测度下的真实坏槽二阶似然。\(\int L_t d\Sigma_x=1\)、\(\Sigma_x(V)\le1\) 与 terminal 阈值 (2) 都不提供它的上界。粗比较只能给
\[
 V_B(t,h)\le(h/t)^n\int_Bw_t\,d\nu,
\]
从而退回已经明确的尺度/归一化费用。

如先把式 (4) 中 \(m_t-k_c\) 正上放为 \(m_t\)，则 (5) 的确消去原外测度 \(p_y/q\) 中的 p；但付出的代价是丢掉所要利用的 good-score 补偿，剩下
\[
 \Lambda K e^u\int h_R(x-z)a_\omega(x,y,z)
 \int_{J_{\rm far}}\frac{m_t}{e_h}
 \left[\int_B\frac{L_t^2}{L_h}d\Sigma_x\right]\frac{dt}{t}
 \,dx\,d\beta(y)d\nu(z), \tag{7}
\]
以及原外期望、叶和唯一 j 门。式 (7) 不是新的已付预算；本次检查没有采用它来宣称连续恢复已付。这正是最早失损：质量型 FIRST 无法控制当前坏槽二阶似然，且直接取质量帽会丢掉式 (4) 的负补偿。它与 R245 JS3 已识别的实际测试加权平方障碍一致，不作为新问题重命名登记。

## 4. 与原连续 signed 账、删除净额的关系

在同一原共同测度
\(d\mathcal T=(p_y/q)h_Ra_\omega\,dx\,d\beta\,d\nu\)
上，仍保 NC8 的四部分：

- R262 已合并支付的坏边界与恢复初值；
- 真实删除净额 \(\Delta(e^{-2})Q_t-\Delta F_B\)，只在 R261 的准确系数条件下吸收，未满足部分保留；
- 式 (4) 的完整连续项；
- 原 future 正损失及 \(\Psi(1-\theta^+)D^+\) 门损失。

原负项只使用一次。式 (4) 支持在旧后缀图 \(\mathcal Z\)，而门损失支持在其补域 \(\Psi\)，不能用 FIRST 正帽把两者当同一来源核抵消。近 hard-anchor 支持允许把原 hard \(\nu\) 转为 \(e_t\Pi_t/w_t\)，但该 \(e_t\) 仍在；本稿未作此转换，也未把 hard z 当任意辅助 posterior。

实际 x 的所有选择器均留在 \(T_x\) 与原测度内，未发生参数 supremum 或节点替换，因此没有隐藏 selector 价；也没有因此获得额外可支付能力。原 lowsoft/lowlabel 限制不改变第三 J 腿，人工软标签不控制 \(k_t\)。

结论：本次 classifier-square 策略没有给出新的根阶付款。可用的精确检查对象是 (2)–(6)，但需要的是 actual receiver、同一 \(T_x\) 与原来源联合控制坏槽二阶似然，并同时保住 (4) 的 good-score 负补偿；不能仅从子概率总量推该结论。到此有界停止。
