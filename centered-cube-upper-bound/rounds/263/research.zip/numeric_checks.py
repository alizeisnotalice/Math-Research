#!/usr/bin/env python3
"""Exact finite nested receiver intersections, R263. No continuous-family proof."""
import argparse,hashlib,json
from fractions import Fraction as F
from pathlib import Path
from math import prod

def fs(x):
 x=F(x);return f'{x.numerator}/{x.denominator}'
def models():
 out=[]
 for n in [1,2,8,32,128]:
  phase='initial' if n<=2 else 'stress' if n==8 else 'expanded'
  for pattern in ['centered','mixed_thresholds','sparse_allowed','edge_empty_then_positive','all_empty']:
   L=[F(1),F(9,8),F(5,4),F(3,2),F(7,4),F(2)]
   theta=F(3,4)
   if pattern=='centered': gaps=[F(0)]*n;c=[F(1,4)]*n
   elif pattern=='mixed_thresholds':
    gaps=[F(i%4,4) for i in range(n)];c=[F([3,4,6,8][i%4],8) for i in range(n)]
   elif pattern=='sparse_allowed':
    L=[F(1),F(5,4),F(2)];gaps=[F(1,3) if i%2 else F(4,5) for i in range(n)];c=[F(3,4) if i%2 else F(3,2) for i in range(n)]
   elif pattern=='edge_empty_then_positive':
    gaps=[F(5,4)]+[F(1,2)]*(n-1);c=[F(15,16)]+[F(3,8)]*(n-1)
   else:gaps=[F(2)]+[F(0)]*(n-1);c=[F(1)]*n
   out.append((phase,n,pattern,L,theta,gaps,c))
 return out

def check(model):
 phase,n,pattern,L,theta,gaps,c=model;a=L[0];b=L[-1]
 V=[prod(max(F(0),t-d) for d in gaps) for t in L]
 w=[prod(min(F(1),ci/(theta*t)) for ci in c) for t in L]
 A2=[t**(-2*n)/wi for t,wi in zip(L,w)]
 assert all(wi>0 for wi in w)
 assert all(V[i]<=V[i+1] and A2[i]>=A2[i+1] for i in range(len(L)-1))
 # Spatial annuli: on I_j \ I_(j-1), the largest available amplitude is A_j.
 shell=[V[j]-(V[j-1] if j else 0) for j in range(len(L))]
 square=sum(q*v for q,v in zip(A2,shell))
 # Independent height layer-cake: for squared height t between consecutive
 # amplitude levels, {sup A 1_I squared >t} is the largest eligible I.
 heights=sorted(set([F(0)]+A2));layer=F(0);weak2=F(0);distribution=[]
 for lo,hi in zip(heights,heights[1:]):
  mid=(lo+hi)/2;eligible=[j for j,q in enumerate(A2) if q>mid]
  volume=V[max(eligible)] if eligible else F(0)
  layer+=(hi-lo)*volume
  weak2=max(weak2,hi*volume**2)
  distribution.append({'height_squared_lo':fs(lo),'height_squared_hi':fs(hi),'superlevel_volume':fs(volume)})
 directweak=max(q*v*v for q,v in zip(A2,V))
 D=max(t**n*q*v for t,q,v in zip(L,A2,V));bound=2*a**(-n)*D
 assert square==layer and weak2==directweak and square<=bound
 return {'phase':phase,'n':n,'pattern':pattern,'a':fs(a),'b':fs(b),'theta':fs(theta),'allowed_L':list(map(fs,L)),'absolute_offsets':list(map(fs,gaps)),'positive_c':list(map(fs,c)),'volumes':list(map(fs,V)),'clamp_weights':list(map(fs,w)),'amplitudes_squared':list(map(fs,A2)),'shell_volumes':list(map(fs,shell)),'height_distribution':distribution,'square_integral':fs(square),'layer_cake_square_integral':fs(layer),'weak_L1_squared':fs(weak2),'max_A_V_squared':fs(directweak),'D':fs(D),'square_bound':fs(bound),'bound_margin':fs(bound-square),'square_bound_ratio':fs(square/bound) if bound else None,'empty_intersection_family':not any(V),'exact_assertions':5}

def main():
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));args=p.parse_args()
 rows=[check(m) for m in models()];valid=[r for r in rows if r['square_bound_ratio'] is not None]
 best=max(valid,key=lambda r:F(r['square_bound_ratio']))
 out={'schema':'R263-finite-nested-exact-v1','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'counts':{'finite_families':len(rows),'stages':{s:sum(r['phase']==s for r in rows) for s in ['initial','stress','expanded']},'exact_assertions':sum(r['exact_assertions'] for r in rows),'empty_families':sum(r['empty_intersection_family'] for r in rows),'height_slabs':sum(len(r['height_distribution']) for r in rows)},'maximum_square_bound_ratio':best['square_bound_ratio'],'maximum_ratio_case':{'n':best['n'],'pattern':best['pattern']},'cases':rows,'scope':['All outputs are exact Fraction arithmetic for explicitly finite allowed scale families and nested genuine cube intersections. Offsets are coordinatewise absolute y-v; intersection side lengths are (L-offset)+.','The height-layer algorithm independently evaluates finite superlevel distribution; weak-L1 is a supremum, so strict height endpoints use one-sided limits. Only its square is stored to avoid irrational amplitudes.','Finite passing examples do not prove the general continuous-family bound. No FULL, history, source budget, original good/high qualification, or root conclusion.','c_i are arbitrary positive rational constants. Actual-C fixed-gap experiment is not supplied: no specific fixed-gap inequality was specified, and arbitrary constants are not called actual source geometry.','Mixtures of labels require separate treatment: posterior weights depending on receiver x cannot be treated as fixed source mixture coefficients.'],'formulas':{'amplitude_squared':'L^(-2n)/prod min(1,c_i/(theta L))','weak_squared':'max_j A_j^2 V_j^2','square':'sum_j A_j^2 (V_j-V_(j-1))','D':'max_allowed L^n A^2 V','tested_bound':'square <= 2 a^(-n) D'}}
 args.output.write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps({'counts':out['counts'],'max_ratio':out['maximum_square_bound_ratio'],'case':out['maximum_ratio_case']}))
if __name__=='__main__':main()
