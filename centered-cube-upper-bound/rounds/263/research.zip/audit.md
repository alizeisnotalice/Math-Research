# R263 独立嵌套族审核

结论：下述纯 hard-hard 嵌套族的 weak-1 等式与 square 常数通过。它们是一般几何策略的构件；未证明完整 soft 正混合、原双后验或一般弱型闭合。只写本临时审核文件，无项目文件/Git/PDF操作。

## 1. 定义、允许集及可测性

固定 n≥1、0<a≤b、θ>0、y,v∈R^n。令 d_i=|y_i−v_i|，

\[
 C(u)=\int_{-1/2}^{1/2}\max\{h_1(r-u),\varphi(r-u)\}\,dr,
 \quad h_1=1_{[-1/2,1/2]},\quad
 \varphi=h_1*\left(\int_0^1e^{-|\cdot|/r}dr\right).
\]

这是原实际 C；不是矩形分量重算的另一个捕获函数。它正、≤1、非增。置

\[
 \alpha_i=bC(d_i/b)>0,\quad
 \omega_i(L)=\min(1,\alpha_i/(\theta L)),\quad
 w(L)=\prod_i\omega_i(L),\quad
 A(L)=L^{-n}w(L)^{-1/2},
\]
\[
 I_L=Q_L(y)\cap Q_L(v),\quad
 V(L)=|I_L|=\prod_i(L-d_i)_+,\quad F_L=A(L)1_{I_L}.
\]

允许集 \(\mathcal A\subset[a,b]\) 是任意固定集合，空集的上确界置零。固定(y,v)时不要求该集合闭：r(x)=2max(||x−y||∞,||x−v||∞)，有

\[
 F^*(x)=\sup_{L\in\mathcal A}F_L(x)
 =\sup\{A(L):L\in\mathcal A,\ L\ge r(x)\}.
\]

右边作为r的函数非增，故Borel可测。也可取一个从右稠密的可数子集，再加入全部从右孤立的允许点，得到逐点相同上确界：从右孤立点可数（各有不交右侧空隙），其余点可由上方允许点逼近。普通稠密集可能漏掉边界；加入这些点避免这一问题。I_L闭边界的不同约定只改Lebesgue零集，退化交盒体积为零。

若允许集随(y,v)变化，后文积分另要求F*(x,y,v)及所用D(y,v)联合可测（或在完成测度上可测）。不能只凭逐纤维可测推出联合可测；常见显式阈值区间/有限或可数菜单可分别验证。以下论证不以任意多值选择定理补造该资格。

## 2. weak-1 精确等式：无尺度菜单费

除有限个阈值外，

\[
 \frac{d\log A}{d\log L}=-n+\tfrac12N_{\theta L}\in[-n,-n/2],
 \qquad N_r=\#\{i:\alpha_i<r\}.
\]

A连续且递减，I_L嵌套递增。因此对u>0，{F*>u}是I_L在允许A(L)>u尺度上的嵌套并。令这些尺度的上确界为L_u；V连续，故此并的体积是V(L_u)（若集合空则零）。用达到上确界的尺度序列得

\[
 uV(L_u)\le\sup_{L\in\mathcal A}A(L)V(L).
\]

反向对任意允许L取u↑A(L)，即可得精确等式

\[
 \boxed{\|F^*\|_{L^{1,\infty}(dx)}
 =\sup_{L\in\mathcal A}A(L)V(L).}
\]

这里weak范数定义为sup_(u>0)u|{F*>u}|。此结论对任意θ>0成立；若引用固定尺度的≤1或指数缺口，还须核该缺口自己的物理资格。

## 3. 任意允许尺度集的平方界

假设某D≥0满足每个允许L的真实固定尺度square界

\[
 A(L)^2V(L)\le D L^{-n}. \tag{S}
\]

对任意非空有限允许集L1<...<Lm，嵌套性给

\[
 \int\max_jF_{L_j}^2dx
 =\sum_j A_j^2(V_j-V_{j-1})
 =A_m^2V_m+\sum_{j<m}(A_j^2-A_{j+1}^2)V_j,
 \quad V_0=0.
\]

由于w递减，

\[
 A_{j+1}^2/A_j^2
 =(L_j/L_{j+1})^{2n}\,w(L_j)/w(L_{j+1})
 \ge(L_j/L_{j+1})^{2n}.
\]

利用(S)和1−z²≤2(1−z)，

\[
\begin{aligned}
 \int\max_jF_{L_j}^2
 &\le D\left[L_m^{-n}+\sum_{j<m}L_j^{-n}
 (1-A_{j+1}^2/A_j^2)\right]\\
 &\le D\left[2L_1^{-n}-L_m^{-n}\right]
 \le2a^{-n}D.
\end{aligned}
\]

对上述可数尺度子集取递增有限前缀，单调收敛得到

\[
 \boxed{\|F^*\|_2^2\le2a^{-n}D.}
\]

所以不需要允许集为尾区间，更没有尺度个数或额外n费。注意(S)是square质量假设；单独的固定半密度L1缺口不能自动替代(S)。

## 4. 原C给出的合法square缺口及方向

现在要求每个允许尺度满足 \(\theta L\le b\)，并保L≤b。令

\[
 \Delta_L=\sum_i(1-\omega_i(L)),\qquad \sigma_0=\varphi(3/2)>0.
\]

若某d_i≥L，则V(L)=0，square界直接成立。否则u=d_i/b<1，l=L/b≤1，τ=θL/b≤1。记a_i=(1−d_i/L)>0。若ω_i<1，则ω_i=C(u)/τ≥C(u)，且

\[
 a_i/\omega_i=\tau a_i/C(u)
 \le(1-u)/C(u).
\]

R224 QG6实际使用的方向可直接核：

\[
 C(u)-(1-u)=\int_{1/2}^{u+1/2}\varphi\ge u\sigma_0,
 \qquad 1-C(u)\le u.
\]

于是

\[
 (1-u)/C(u)
 \le1-\sigma_0(1-C(u))
 \le1-\sigma_0(1-\omega_i)
 \le e^{-\sigma_0(1-\omega_i)}.
\]

若ω_i=1，只用a_i≤1。因此

\[
 \int F_L^2dx=L^{-n}\prod_i a_i/\omega_i
 \le L^{-n}e^{-\sigma_0\Delta_L}.
\]

可取

\[
 D_{y,v}=\exp[-\sigma_0\inf_{L\in\mathcal A}\Delta_L]\le1
\]

进入(S)；空允许集取D=0。更尖的D是sup_allowed ∏a_i/ω_i。另有a_i≤ω_i（同一合法范围，直接由θ(L−d_i)≤b−d_i≤bC_i），故固定L1质量≤√w(L)≤exp(−Δ_L/2)。weak等式可继承这个L1缺口，但它与square缺口应分别记账。

**单有N_(θL)≥k0不保证固定正率exp(−c k0)**：刚活跃的ω_i可接近1。若另授N_(q0θL)≥k0、0<q0<1，则Δ_L≥(1−q0)k0；或者对原固定clock t保c_jt≤q0θL，则Δ_L≥(1−q0)k_t(y,v)。这些严格内侧条件不能省略。

θ任意且θL>b时，weak等式仍成立，但上述合法square缺口与无维数D≤1不自动成立。不能把这个参数区间遗漏。

## 5. 固定来源的Minkowski：允许及未付部分

设σ是固定非负来源测度，独立接收点x和积分中的尺度选择；假设联合可测，且∫√D_yv dσ有限。由Minkowski积分不等式及第3节，

\[
 \boxed{
 \left\|\int F^*_{y,v}(x)\,\sigma(dy,dv)\right\|_{L^2(dx)}
 \le\sqrt{2a^{-n}}\int\sqrt{D_{y,v}}\,\sigma(dy,dv).}
\]

先有限正截断再单调极限可保扩展值版本；右边无穷时不构成有限付款。式中σ的质量/权并未消失，不能在外部再无价归一化。

原裸Π_y,t在固定seed,V,j,t后确可独立x；但实际j(x)、t窗口、g(x)、good/high/history、三腿和原归一化权构成的有效来源一般依赖x。不能直接把整项写成同一个固定σ再用上述Minkowski。若先固定j,t，并将允许上放的门置一，则仍须单独核实际共同θ/同伦族、所损来源容量、全部clock和j求和费用；没有由本引理一次支付。这不是完整soft混合或原交通闭合。

## 6. 实际计算与既有工具范围

本人实际运行：9个标准库Fraction非连续尺度模板，核有限嵌套积分telescoping和常数2；另2个actual-C低维硬核族用mp50求积核square包络上界。后者非interval；Fraction模板的α_i=1−d_i仅核代数，非actual C输入。它们不替代上述一般证明，也不是FULL实例。

已窄读R224 QG16–17与R257 MG3–5，以及F03技能的SKILL、cube-interface和provenance。R224给固定参数列，F03明确HS/径向层不自动控制全尺度sup；未在所读接口中找到本文这个具体嵌套上确界定理。本文不给文献新颖性或完整soft迁移结论。

## 整合终审

独审者复核主代理proof.tex.txt全文的新增定理、物理C特化、来源混合边界和无多付声明，结论PASS。建议将后验依x改为完整有效来源依x，主代理已落实；裸Π在固定seed,V,j,t后可独立x。
