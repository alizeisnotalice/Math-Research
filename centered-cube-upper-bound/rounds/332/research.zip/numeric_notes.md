# R332 — aggregate capacity objective screen on actual cube incidence

Run with the bundled Python, standard library only:

```
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 /tmp/r332_numeric.py
```

This is the bounded pivot requested after the aggregate objective was screened analytically. No solver optimization or worst-source/shared-potential certificate is claimed.

## Tool availability actually checked

Bundled Python imports NumPy2.3.5. Bundled `scipy` and `cvxpy` are absent. Adding the pre-existing local directory `/Users/zhengzhihao/Desktop/T/output/centered_cube_math_runtime` allows import of SciPy1.15.3 itself, but `from scipy.optimize import minimize` fails loading `scipy/sparse/linalg/_propack/_spropack.cpython-312-darwin.so`: Mach-O `__DATA/__thread_bss` has a zero-fill section type with nonzero offset. No installation, binary repair, global path or system-environment change was made. The delivered script needs none of these packages.

## Actual geometry; receiver discretization limitation

Three stages use genuine centered axis-aligned cube receivers in n1/2/3 with mixed radii1,3/2,2 and centers explicitly listed in JSON. The compact positive-L1 source is β=f=ν=1_Q4. Each kernel cube lies inside Q4, hence actual captured mass m_i=R_i^n and actual hard response q=λ=1. Each receiver has a specified positive rational quadrature weight w_i, with μ_i=w_i/m_i. These weights are **finite receiver quadrature**, not a claimed Lebesgue receiver field or complete original selector. This limitation applies to all budgets in this diagnostic.

Every source coordinate is partitioned at the compact support endpoints and every receiver cube face. All resulting source boxes are retained, including J=0 boxes; each is wholly captured or missed by every receiver, up to null boundaries. Their exact volumes are source masses. The models have5,64,900 positive-volume source boxes, and source masses4,16,64. Direct mass sums verify m_i exactly. Thus source integration is complete and exact for this finite receiver field; no source sampling replaces it.

Prefixes are grouped by their actual physical radii. The ell weight is r_k^(−n)−r_(k+1)^(−n), with terminal r_last^(−n), which combines the unchanged final-prefix tail through b=2 and its endpoint atom. All-row B_all is computed; no representative root high-J gate or full history is asserted.

## Why aggregate coverage optimization adds no new bill

At each prefix let

I_ij=∫f c_i c_j, SG_ij=∫f c_i c_j/J,
G_ij=∫f c_i c_j/√J.

Zero J terms are0. Cauchy gives G_ij²≤I_ij SG_ij and geometric inclusion gives I_ij≤min(m_i,m_j). Therefore

S0_ij=4G_ij²/(√m_i+√m_j)²≤SG_ij.

The Gibbs kernel has exact saturated row capacities Σ_j μ_j SG_ij=m_i. Thus S0 is capacity-feasible, and with θ=1 its feature h_ij=√S0_ij(√m_i+√m_j)/2 equals G_ij. This conclusion is analytic, not a solver discovery.

Write Q=Σell μ_iμ_j G_ij² for the symmetric original square and E=Σell μ_iμ_j I_ij SG_ij for the original one-sided square. Source symmetry gives E≥Q. For any feasible S, the complete signed-potential aggregate bill is exactly

integrated(source cut + square fit) − (capacity slack + edge energy)
 = X−Q + ||h−G||²,

where X=Σ_i w_i under actual q=1. Maximizing coverage2<G,h> alone omits the norm/credit part of this expression. S0 minimizes the complete aggregate bill over the class, attaining X−Q. That may improve the Gibbs member, but it simply recovers the existing full symmetric-square bound; it is not a new root-size payment or a worst-source/shared-ζ certificate.

The actual original all-row cost in this finite field is B_all=X−E, computed from exact fractions. It may be smaller than X−Q, as it is in every tested model.

## Exact feasibility versus ordinary decimal diagnostics

The implemented S0 candidate is rationally repaired downward. Exact integer-square-root intervals enclose √J and √m. These give a rational lower G and upper denominator, hence rational t_ij≤√S0_ij. All pair inequalities, Gibbs saturation and row capacities for S=t² are verified with exact fractions. These are genuine finite feasible certificates.

Actual irrational G, h, square norms, source cut+fit identities and bill comparisons are evaluated separately with ordinary `Decimal` precision60 and80. Assertions use tolerances10^(−precision+12); the final bill agrees between the two precisions to better than10^−45. These calculations are **not interval certificates**. The rational candidate's numerically observed ||h−G||² is below3e−60; exact row feasibility does not depend on this numerical error estimate.

|n|exact original B_all|Gibbs complete bill|S0 candidate complete bill≈X−Q|
|---|---:|---:|---:|
|1|0.040000000|0.052967409|0.048024613|
|2|0.082635442|0.118485995|0.095678237|
|3|0.100840028|0.151673202|0.122595796|

The full cut+fit and credit values are in JSON. For n3, Gibbs cut≈.1008400, fit≈.0591031 and credit≈.0082700. S0 increases cut≈.1502890 and fit≈.0949026, with compensating credit≈.1225958. Thus coverage or cut alone would misdescribe the complete budget.

## Actual execution and bounded conclusion

Two fresh standalone processes pass8,295 total assertions, rigorously separated as **5,188 exact rational/integer checks** and **3,107 ordinary Decimal diagnostics**. Stage totals are106,850,7,339 for n1/2/3. Exact source partitions retain all sources and zero-J cells. No assertion count is described as8,295 exact certificates.

This screen confirms that optimizing only the full-source aggregate objective is not a new geometric-budget direction. A genuine worst-source defect and common signed receiver-potential certificate remains unoptimized and unproved. With the available solver failure and the analytic aggregate minimum already explicit, no long coverage-maximization run was undertaken. No dimension-rate fit, continuum receiver claim, root budget or original-history admissibility conclusion is made. Only the three owned `/tmp/r332_numeric` files are changed.
