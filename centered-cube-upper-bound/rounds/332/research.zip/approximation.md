# R332 — capacity-preserving source-cell approximation and its boundary-mass error

**Scope.** The source-cell coupling below increases to the actual Gibbs coupling. There is a finite, source-conserving error certificate involving real cube-boundary source mass. It gives a root-sized approximation error when that measured boundary quantity is small enough. It does not pay the limiting Gibbs/source-profile defect or prove the original root theorem. No uniform input-independent resolution or rate is obtained. Arithmetic normalization and geometric Gram normalization have different limits and must not be conflated.

## 1. Actual field and simultaneous prefix continuity

Keep the frozen R331 hard-matched contract: `f≥0` in `L¹`, `m_u=∫f c_u=q(u)R(u)^n`, `dμ=1_Edu/m_u`, `q_-≤q≤λ`, finite `E`, and `a≤R≤b≤2a`. In particular `μ(E)<∞`. The argument for continuity and capacities also applies to any finite positive receiver measure with these cube/source identities. Set

\[
 J_z(r)=\int_{R\le r}c_u(z)d\mu(u),\quad
 A_{yz}(r)=\int_{R\le r}c_u(y)c_u(z)d\mu(u),\quad
 V_z(r)=\int_{R\le r}c_u(z)du,
\]

with original prefixes, `ell=b^-nδ_b+nr^-n-1dr`, `A_n=1+n log(b/a)`, `W=∫f`, and `X_q=∫_E q≤X=λ|E|`.

Take ONE nested dyadic partition `C_k` of all source space, with side/ℓ∞ diameter `d_k↓0`. On its cell `C_k(z)` define

\[
 M_k(r,z)=\operatorname*{ess\,sup}_{w\in C_k(z)}J_w(r)
\]

using Lebesgue essential supremum. Define the actual boundary modulus

\[
 \omega_k(z)=\int_E1_{\{\operatorname{dist}_\infty
 (z,\partial Q_{R(u)}(u))\le d_k\}}d\mu(u),\qquad
 B_k=\int f(z)\omega_k(z)dz.                                  \tag{1}
\]

There is one Lebesgue-full, hence `f dz`-full, set of `z` on which, SIMULTANEOUSLY for every `r∈[a,b]`,

\[
 J_z(r)\le M_k(r,z)\le J_z(r)+\omega_k(z),\quad
 M_{k+1}(r,z)\le M_k(r,z),\quad
 \sup_r|M_k(r,z)-J_z(r)|\longrightarrow0.                     \tag{2}
\]

Proof: Fubini gives `μ{u:z∈∂Q_u}=0` for almost every `z`, since each cube boundary has Lebesgue measure zero. If `|w−z|∞≤d`, a change of cube membership forces `dist∞(z,∂Q_u)≤d`; consequently
`sup_r|J_w(r)−J_z(r)|≤ω_d(z)`. At a boundary-null `z`, dominated convergence makes `ω_d(z)→0`; it also proves continuity of `w↦J_w(·)` in the supremum norm at this `z`. This implies the essential-supremum bounds, including the lower bound, and refinement implies monotonicity.

Measurability has no uncountable-null-set gap. Each cell is from a countable grid; its essential supremum can be tested by the measure of `{w∈C:J_w(r)>t}` for rational `t`. Moreover

\[
 \sup_z|J_z(s)-J_z(r)|\le\mu\{r<R\le s\}\longrightarrow0
 \quad(s\downarrow r).
\]

Thus `J` and its cell essential suprema are right-continuous in the physical prefix. Rational-prefix statements extend to all prefixes, including `b` and every actual radius atom. Alternatively the direct modulus argument already holds for all prefixes at once. All zero denominators below are assigned integrand zero. The exceptional set with `J_z(r)=0` but `c_u(z)=1` has zero `ell(dr)dμ(u)f(z)dz` measure, because its integral over `u∈E_r` is `J_z(r)=0`.

The boundary certificate is an ACTUAL source integral:

\[
 B_k=\int_E f\{z:\operatorname{dist}_\infty(z,\partial Q_u)\le d_k\}
                    d\mu(u)\longrightarrow0.                 \tag{3}
\]

This is Tonelli followed by dominated convergence, bounded by `μ(E)W`. It is not boundary volume multiplied by a presumed density bound. Concentrating `f` close to actual faces prevents a universal rate from this argument.

## 2. Symmetric row subcapacity and its increasing limit

Define

\[
 S_{k,r}(u,v)=\int f(z)\frac{c_u(z)c_v(z)}{M_k(r,z)}dz,
 \qquad u,v\in E_r.                                         \tag{4}
\]

It is measurable, symmetric and nonnegative. Positive Fubini gives the exact row marginal

\[
 a_{k,r}(u)=\int_{E_r}S_{k,r}(u,v)d\mu(v)
 =\int f(z)c_u(z)\frac{J_z(r)}{M_k(r,z)}dz\le m_u.             \tag{5}
\]

Hence every `k` is a feasible coupling in the R331 row-capacity class. For `ell(dr)dμ(u)dμ(v)`-almost every triple,

\[
 S_{k,r}(u,v)\uparrow S^{\rm G}_r(u,v)
 =\int f(z)\frac{c_u(z)c_v(z)}{J_z(r)}dz.                     \tag{6}
\]

Monotone convergence applies to the original integrands using (2); the zero-row exception is removed as above. The Gibbs kernel has saturated row marginal `m_u`. No separate source copy is used for a cell, level or physical radius.

The total lost marginal at each prefix is explicitly controlled:

\[
 \int_{E_r}[m_u-a_{k,r}(u)]d\mu(u)
 =\int f(z)J_z(r)\left(1-\frac{J_z(r)}{M_k(r,z)}\right)dz
 \le B_k.                                                     \tag{7}
\]

For a bounded R331 receiver coefficient `θ(u)`, its capacity-slack cost is consequently at most
`λ A_n ||θ||∞² B_k`, since `m_u≤λr^n` on `E_r` and `∫ell r^n=A_n`. This bound retains its actual dimension/scale factor.

## 3. Arithmetic energy: exact limit and a finite error certificate

Define the arithmetic square energies

\[
 E_{\rm all}=\int\ell(dr)\iint f(y)f(z)\frac{A_{yz}(r)^2}{J_z(r)}dydz,
 \quad
 E_k=\int\ell(dr)\iint f(y)f(z)\frac{A_{yz}(r)^2}{M_k(r,z)}dydz.
\]

Equivalently `E_k=∫ell∫f(y)∬S_k c_u(y)c_v(y)dμ(u)dμ(v)dy`. Then

\[
 0\le E_k\uparrow E_{\rm all}\le X_q.                         \tag{8}
\]

For every `t>0`, the exact nonnegative difference obeys

\[
 \Delta E_k\le
 \int f(z)\int\ell(dr)V_z(r)\left(1-\frac{J_z(r)}{M_k(r,z)}\right)dz
 \le\lambda tW+\frac{A_n}{t}B_k,
\]
\[
 \boxed{\quad\Delta E_k\le2\sqrt{\lambda A_n W B_k}.\quad}    \tag{9}
\]

The first inequality uses `A²≤J_z A` and `∫f(y)A_yz dy=V_z`. On `J<t`, the old stopped first-moment payment is `∫ell1_(J<t)V_z≤λt`, including crossing atoms and the terminal atom. On `J≥t`, (2) gives `1−J/M≤ω_k/t`. Finally the original hard band envelope gives

\[
 \int\ell(dr)V_z(r)=\int_E c_u(z)R(u)^{-n}du\le A_n,
\]

which proves (9). This is a full-input geometric envelope, with no density assumption. Zero `W` or `B_k` is interpreted by taking the infimum over positive `t`.

At a specified resolution satisfying `λB_k≤C W`, (9) pays the approximation error by `2√C√A_n W`. Such a resolution exists for each fixed input/receiver field by (3), but its index and computational size have no uniform bound here. This does not estimate `E_all` or its old Gibbs escape defect; only their finite approximation error is paid. It cannot turn a root bound that is unproved for the limiting coupling into a proved one.

## 4. Geometric square normalization has a different limit

Let

\[
 Q_k=\int\ell(dr)\iint f(y)f(z)
 \frac{A_{yz}(r)^2}{\sqrt{M_k(r,y)M_k(r,z)}}dydz.
\]

Every `Q_k` uses a PSD Gram kernel, and `Q_k↑Q_all`, with denominators `√(J_yJ_z)`. In general it does NOT converge to `E_all`. Their nonnegative reciprocal-clock credit from R329 remains. Monotonicity here is for the nonnegative source energy, not a claim that successive kernel differences are PSD in the Loewner order.

There is also an actual mixed error bound. Let `Φf` and `Φ_kf` be the two real receiver-pair feature vectors normalized by `√J` and `√M_k`. Symmetry, `ab≤(a²+b²)/2`, and
`(J^-1/2−M^-1/2)²≤J^-1−M^-1` give

\[
 \|\Phi f-\Phi_kf\|^2\le\Delta E_k.
\]

Since `Q_all≤E_all≤X_q`,

\[
 0\le Q_{\rm all}-Q_k\le2\sqrt{X_q\Delta E_k}
 \le\varepsilon X_q+\frac{\Delta E_k}{\varepsilon}.           \tag{10}
\]

Thus (9) supplies a controlled source/receiver approximation fee for the PSD square as well. The same original `f`, all original prefixes and the entire source square are used. Neither (8) nor (10) supplies the remaining R331 source-profile certificate.

## 5. Local exact check and reproducibility

A standard Python `Fraction` calculation passed **70** assertions on a genuine finite-atomic receiver measure with one-dimensional cube intervals, complete continuous source `f=1_[-3,3]`, and five nested dyadic resolutions. It checked exact row subcapacities, full-source energy monotonicity and the finite boundary error bound. This tests the finite-measure statement, not the original Lebesgue receiver selector or a global operator bound. The bound was tested with the safe rational envelope `A_n≤2`; no logarithm or floating test was needed. The following is the executed reproduction.

```python
from fractions import Fraction as F
from collections import defaultdict
centers=[F(-1,4),F(1,3),F(4,5)]
radii=[F(1),F(3,2),F(2)]; mu=[F(1,2),F(2,3),F(3,4)]
ends=[(c-r/2,c+r/2) for c,r in zip(centers,radii)]
oldE=F(0); checks=0
for k in range(2,7):
    d=F(1,2**k); B=4*d*sum(mu); totE=totEk=F(0)
    grid=[F(i,2**k) for i in range(-3*2**k,3*2**k+1)]
    knots=sorted(set(grid+[x for e in ends for x in e])); seg=[]
    for x,y in zip(knots,knots[1:]):
        z=(x+y)/2; bits=tuple(int(l<z<r) for l,r in ends)
        seg.append((int(z//d),y-x,bits))
    for p in range(3):
        ell=1/radii[p]-(1/radii[p+1] if p<2 else 0)
        MC=defaultdict(F)
        for cell,m,bits in seg:
            J=sum(mu[u]*bits[u] for u in range(p+1))
            MC[cell]=max(MC[cell],J)
        states=defaultdict(F)
        for cell,m,bits in seg: states[(bits,MC[cell])]+=m
        E=Ek=F(0)
        S=[[F(0) for _ in range(p+1)] for _ in range(p+1)]
        for (bz,M),mz in states.items():
            Jz=sum(mu[u]*bz[u] for u in range(p+1))
            if not Jz: continue
            for u in range(p+1):
                for v in range(p+1): S[u][v]+=mz*bz[u]*bz[v]/M
            for (by,_),my in states.items():
                A=sum(mu[u]*bz[u]*by[u] for u in range(p+1))
                E+=mz*my*A*A/Jz; Ek+=mz*my*A*A/M
        for u in range(p+1):
            assert sum(S[u][v]*mu[v] for v in range(p+1))<=radii[u]
            checks+=1
        assert 0<=Ek<=E; checks+=1
        totE+=ell*E; totEk+=ell*Ek
    err=totE-totEk
    assert err<=oldE if k>2 else True; checks+=1
    oldE=err
    for t in [F(1,2),F(1),F(2)]:
        assert err<=t*6+2*B/t; checks+=1
    assert err*err<=4*2*6*B; checks+=1
print('PASS',checks)
```

Only `/tmp/r332_aux.md` is authored. No other research file or Git state is changed.
