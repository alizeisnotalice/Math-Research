[x,v,flag]=quadprog(2,-2,[],[],[],[],0,2,[],optimoptions('quadprog','Display','off'));
disp([x,v,flag]); assert(flag>0 && abs(x-1)<1e-7);
% Actual R2026a result: [1,-1,2]. Tool smoke only, not a research certificate.
