# R332 independent preauthor screen — dyadic source normalization limits

Ownership only /tmp/r332_audit.md; no Git/other-author edits. No R332 author proof has been read. Positive finite real receiver measure mu on a measurable cube field c_u(z)=1_Q_Ru(u)(z), a>0,R in[a,b], finite ell and f>=0,L1 are the convergence contract. The usual original density mu=1_E du/(qR^n) with q>=q_->0 and finite E is sufficient. Source domination by Lebesgue is essential to the argument; arbitrary singular point sources are not included.

## 1. Source-position continuity at a common full-measure set

For every fixed receiver u, its cube boundary is Lebesgue-null. Positive Tonelli implies mu{u:z on boundary Q_Ru(u)}=0 for Lebesgue-a.e.z. At such a good z, c_u(z') converges to c_u(z) for mu-a.e.u whenever z' approaches z. Dominated convergence gives integral |c_u(z')-c_u(z)|dmu(u) ->0. Since

 sup_(r in[a,b]) |J_z'(r)-J_z(r)|<=integral |c_u(z')-c_u(z)|dmu(u),

this is source-position continuity UNIFORM in r at every good z. The good set is common to all r and includes f-a.e.source point. No regularity of R or actual receiver masks is assumed. It need not hold at EVERY source position; a positive receiver family can share a common boundary point.

## 2. Essential cell maxima, joint measure and denominators

Use a genuinely nested countable dyadic partition sequence, with positive-volume finite cells C_k(z) whose diameters tend to0 along the source chains. Merely nested partitions without shrinking cells are insufficient. Set M_C(r)=Lebesgue-esssup_(z in C)J_z(r). It is jointly measurable in r/cell via rational tests of positive measure {z in C:J_z(r)>t}; the field M_k(r,z)=M_Ck(z)(r) is measurable. Refinement decreases M. At every good z, continuity at z and positive volume of C_k(z) near z give J_z(r)<=M_k(r,z), while the whole shrinking cell lies within a small neighborhood of z. Hence M_k(r,z) decreases to J_z(r), uniformly in r, at the same f-a.e.z. Cell-face half-open conventions do not change essential maxima or integrals. Bounds0<=M<=mu(total) are finite.

Zero M means J_z(r)=0 for a.e.z in that cell. In the original source-square integrand A_yz(r)^2 is0 whenever J_y(r)0. Thus its0/0 contribution is0, not an infinite or fabricated charge. For the receiver coupling S_k a pointwise-in-ALL-receivers monotonicity claim would be too strong: a zero-J source set may capture exceptional mu-null receivers. Zero-cell numerators vanish under the ACTUAL prefix mu pair measure by Tonelli. The resulting monotonicity/convergence and row capacities are asserted ell(dr)mu(du)mu(dv)-a.e., with common countable cell/k null-set removal.

## 3. Convergence and the exact row-capacity qualification

Define S_k(r,u,v)=sum_C [integral_C f(z)c_u(z)c_v(z)dz]/M_C(r) on actual prefix pairs, zero denominators assigned0. It is symmetric/nonnegative, and

 integral_prefix S_k(r,u,v)dmu(v)=sum_C integral_C f(z)c_u(z) J_z(r)/M_C(r) dz<=integral f(z)c_u(z)dz.

Therefore it is a row SUBCAPACITY relative to m_u^f=integral f c_u for arbitrary f>=0,L1. It is a subcapacity relative to the ORIGINAL m_u=qR^n only if Tf<=q on actual E, in particular the frozen hard-matched Tf=q contract. A lower cap on q ALONE does not imply this source-to-row inequality. The convergence results themselves need no such matching. This qualification must be explicit in the final theorem.

The reciprocal maxima increase to1/J on positive J sources; zero-J contributions vanish under the relevant actual measures. Thus S_k increases to S^G=integral f c_uc_v/J_z dz a.e.on the real pair feature measure. Its marginal tends to integral f c_u for mu-a.e.prefix receiver by the same zero-row Tonelli argument. All physical prefix/b atoms remain.

For the complete original source-square, E_k=integral ell sum_C [integral_(y in C) f(y) integral f(z)A_yz(r)^2 dzdy]/M_C(r) increases to E_all=integral ell f(y)f(z)A_yz²/J_y by positive MCT. This is the original DIRECTED reciprocal square, not automatically a gated or endpoint-masked replacement. With symmetric denominators sqrt(M_C M_D) the analogous DOUBLE source partition increases to normalized Q_all. The common good-source set/uniform-r continuity makes the joint ell/source limit legitimate. Either full energy is finite for finite mu and L1 f, e.g.A²/J_y<=A<=mu(total), before applying the finite ell measure; no subtraction of divergent signed terms is used.

Countable cells require nonnegative Tonelli. A finite approximation must refine retained cells AND retain an increasing source union exhausting the source domain; arbitrary independent truncations need not be monotone. Certified upper bounds on M remain valid lower energy bounds, but converge only if their own errors vanish with compatible refinement. Exact essential maxima/box masses and real A integrations are proof objects, not an algorithm for arbitrary black-box selectors/f. No uniform rate, practical cell count, dimension saving, root estimate, free coverage union, altered q/history or new source payment follows from monotone convergence.

## 4. Independent quantitative boundary-error screen

This section additionally uses the frozen hard matching Tf<=q (equality in the original common-source field), q<=lambda, and f>=0. Let delta_k(y)=diam_infinity C_k(y), omega_k(y)=mu{u:dist_infinity(y,boundary Q_u)<=delta_k(y)}, and B_k=integral f omega_k. Any source point in its cell is within delta_k(y), so a membership change crosses this true boundary tube. Hence M_k(r,y)-J_y(r)<=omega_k(y) at source-good points, UNIFORMLY in physical prefixr. The diameter is full cell diameter in infinity norm, not an unannounced halfwidth. B_k->0 by the same boundary-Tonelli good set and dominated convergence (omega<=mu(total)). This does not supply a rate or a field-independent mesh.

Let DeltaE=Eall-E_k. Its row error equals the nonnegative square row [integral f_z A²/J_y] times(1-J_y/M_k). On J<t it is<=V_y, paid by the original strict low-row lambda t W. On J>=t it is<=omega_k/t timesV_y. Since integral ell V_y=T*1_E(y)<=A_n by the hard scale-envelope integral,

 DeltaE<=lambda t W+(A_n/t)B_k for every t>0,
 DeltaE<=2sqrt(lambda A_n W B_k).

The parameter t is an auxiliary split in this ERROR estimate, not a change of the originalH gate. W0/B_k0 cases follow trivially or by t->0 limits. A claimed root error at a preselected mesh still needs a genuine bound lambda B_k<=C W; dominated convergence alone does not give it uniformly. This approximates a retained original energy and is not an extra favorable square to subtract again.

For normalized shared-source features, write F=Phi f and F_k with source-row factor sqrt(J_y/M_k). They are nonnegative vectors with F_k<=F. The difference D=F-F_k satisfies

 ||D||²<=integral ell f_y f_z A_yz²(1/sqrt(J_y)-1/sqrt(M_k(y)))²<=DeltaE.

The first inequality is symmetric2ab<=a²+b²; the second uses(1/sqrt(J)-1/sqrt(M))²<=1/J-1/M. Zero-J rows are zero features under the actual pair measure. Thus0<=Qall-Qk<=2||F||||D||<=2sqrt(X DeltaE)<=epsilon X+DeltaE/epsilon, because Qall<=Eall<=integral_E q<=X=lambda|E| in the actual hard shared field. The common-source and actual mean constraint are essential; this is not a bound for independent source/receiver optimizers or arbitrary general-soft kernels. No general root value of Eall/Qall or continuum certificate follows from error convergence alone.

## 5. Actually executed independent local diagnostics

Reviewer ran642 exact Fraction assertions: {'cell_bound': 294, 'refinement': 245, 'pair_refinement': 45, 'row_capacity': 18, 'energy_error': 30, 'reciprocal_scalar': 10}. Actual1D source f=1_[-2,2],receiverE=[-1/2,1/2],R=q=1,mu=du, hence J_y=(1-|y|)+ and exact Eall=7/9. Six dyadic meshes check true boundary tube/cell maxima, nested normalized pair references, actual row subcapacity, monotone energies and the stated error bound. Source f and real interval dx are retained; this is a fixed illustrative case, not a uniform convergence rate or general root proof. No author proof/code was read before this diagnostic. Reciprocal checks use exact rational square roots by construction.

Initial verdict: PASS subject to the explicit source-matching qualification in section3 and a.e.actual-pair/compatible-truncation conditions. Await author comparison.

## 6. Final auxiliary proof and numeric implementation comparison

Read complete /tmp/r332_aux.md after the preauthor screen. PASS. Its final contract explicitly retains frozen hard matching m_u=integral f c_u=qR^n; it does NOT assert original row capacity from a q lower bound alone. The boundary modulus, one common good-source set, right continuity of J and essential maxima, zero-cell Tonelli exceptions, ell-prefix pair a.e. monotone subcapacity/Gibbs limit and capacity-slack bound lambda A_n||theta||inf² B_k are correct. Arithmetic normalization converges to Eall; double geometric normalization to Qall, with no Loewner-monotone kernel-difference claim. The explicit DeltaE and Qerror constants agree with section4 and retain actual X_q<=X, complete source mass and physical/terminal atoms. No convergence-rate or root budget for the limiting Gibbs defect is inferred. Author70 Fraction checks are finite-atomic receiver tests with actual continuous source integration, not original Lebesgue dx selectors; the reviewer did not replay them.

Read /tmp/r332_numeric.py/md fully. PASS within their finite receiver-quadrature contract. Actual receiver cubes lie inside Q4 and source axes are cut at every face and support endpoint; positive-volume source cells cover the ENTIRE original f=1_Q4, including zero-J cells. Each incidence is constant a.e. on its source cell, so integration is exact rather than sampling. Prefixes group equal physical radii, and the last radius tail combines the constant remaining prefix and the b atom even when the last radius<b. Positive receiver weights are explicitly QUADRATURE, not a claimed dx selector/full history.

Exact rational feasibility is independent of the ordinary Decimal arithmetic. For x>=0, sqrtbox computes q=isqrt(floor(x*2^(2bits))); hence q/2^bits<=sqrt(x)<(q+1)/2^bits. Thus summing source masses divided by UPPERsqrt(J) gives rational gl<=actualG; an upper sqrt(m_i)+sqrt(m_j) denominator gives t_ij<=2G/d. Exact Cauchy gl²<=I SG, t²<=SG and row capacities are checked in Fraction. This is a finite feasible certificate, not a continuum receiver/pointwise dual certificate.

Ordinary Decimal60/80 separately evaluates irrational G,h, norms, cut/fit/credit identities and aggregate comparison at stated tolerances; two-precision agreement is NOT an interval bound. Source symmetry yields original E>=normalized Q. Aggregate bill equals X-Q+||h-G||² under actual q1. Analytic S0=4G²/(sqrt(m_i)+sqrt(m_j))² is feasible by G²<=I SG and4I<=d²; its h=G attains the existing aggregate symmetric-square bound. The rationally lowered S candidate approximates that analytic minimizer while preserving exact finite capacities. This objective by itself provides no worst-source/shared-zeta or new root estimate. The code accurately retains exact original all-row B_all=X-E for its finite receiver field.

Numeric author reports8295 assertions, split5188 exact rational/integer and3107 ordinary Decimal; exact repeated comparisons at two precisions are executions, not all-distinct model cases. Their arithmetic types/scope are not conflated. This reviewer read but did not rerun the full module; reviewer642 independent exact interval-model tests remain separate. No unavailable SciPy/CVXPY solver result is claimed.

The corrected geometric slack identity is
 d²-4I=2D_src-(sqrt(m_u)-sqrt(m_v))²=(sqrt(m_u)-sqrt(m_v))²+4(sqrt(m_um_v)-I),
 where d=sqrt(m_u)+sqrt(m_v),D_src=m_u+m_v-2I. The previously proposed plus sign before the square in the FIRST expression is WRONG and is not included among certified results. The second displayed sum is nonnegative by actual source overlap I<=sqrt(m_um_v). Await final core proof for its exact application.

Current hashes:
- /tmp/r332_aux.md — 6e9c8f0039867e92428bb00a9a8d8ee86b0582326217e572a46bd403d5ca62a3
- /tmp/r332_numeric.py — bac463f2b556622e9d90def01cf00724c25f2e2ffe737d4d7e2af387b985edf5
- /tmp/r332_numeric.md — e638e81f38110f4f031cf94c733385373877319a4fe9bc178629c03cddd16659

## 7. Final core proof and ledger review — PASS

Read /tmp/r332_core.md in full. PASS for its bounded constructive statements. Formula(2) uses the CORRECT minus sign and equal nonnegative form. Since(√m_u-√m_v)²<=D_src by I<=√(m_um_v), both comparisons(3) hold. The intersection-posterior variance V_J=I² Var(J^(-1/2)) is exact with the zero-row convention and actual pair-measure null exceptions. All source masses and q/R fields are shared and frozen.

The row slack s=m-row(S0) is nonnegative and integrable. Z_r=integral_prefix s is finite/measurable. X=s⊗s/Z is symmetric and has actual marginal s when Z>0; at Z0 the slack vanishes mu-a.e. Thus S+ saturates the ORIGINAL prefix capacities without a source-dependent posterior or receiver selection. It may add pairs with little common-cube incidence; no useful coverage fraction is presumed. The reference h+=sqrt(G²+d²X/4)>=G is exact and finite-energy. Its signed potential -1_E keeps bill -D+ nonpositive using the original inclusive ell tail, not independent per-prefix charges.

For the pointwise gain, integral Minkowski in R² has first coordinate M_y=integral captured G and second coordinate integral captured d sqrt(X)/2=P_y T_y/sqrt(Z). This proves(8) with factor2/sqrt(J_y). Positive captured slack gives positive P,T and hence a STRICT gain for that candidate, a.e.where the quantities are defined; this is not a source-mass consequence of small boundary volume. Zero/inactive cases are assigned0.

Credit identity(9) is correct: old norm bill is -(L0+D0), new is -D+, so the norm increase equals L0+D0-D+. Because G=Phi f, it also equals integral f Delta+||delta h||². The rank-one increment D_X is exactly the weighted variance in(10), between0 andL0/2. Therefore the pointwise gain is NOT a free improvement of the whole integrated budget. Retaining all old slack credit as well would double-spend it; final proof does not do so. No comparison with every feasible or Gibbs source profile is asserted.

Condition(11) is the correct remaining common zeta/pointwise-defect certificate. Its actual receiver bill is -D+ +integral zeta q; if the displayed inequality is proved, it is<=epsilon X and the R330 completion gives source coefficient c+lambda H ONCE. Original nu<=f is used only to enlarge the nonnegative full slot BH(f,nu)<=BH(f,f); this is not arbitrary unequal-source symmetrization or general-soft A symmetry. No qualifying root c/zeta is constructed. All old field/history/entrance qualifications remain, and no generally paid root branch is claimed.

Read final /tmp/r332_ledger.md. PASS: it distinguishes arithmetic E and geometric Q limits, actual boundary-source approximation error from limiting-defect payment, and allocation of each new epsilon under outer factors2Lambda. Existing1/256 is not declared the complete absorption budget. Whole-slot alternatives do not add crossing/large-atom charges from the same slot. The signed recoupling consumes credit, and time/deletion/entry/aspect/general-soft/outer/global missing terms are retained. The MATLAB scalar smoke test is only tool availability evidence, not a research solve or replacement for unavailable SciPy optimization. No claim all local optimization tools are unavailable remains.

Read primary /tmp/r332_checks.py:4160 exact finite-incidence source-boundary/posterior/Cauchy/subcapacity assertions plus162 unequal-square-mass corrected-sign regression assertions=4322, scoped as algebra-only. Actual reported primary numeric5188 exact plus4322=9510 exact assertions;3107 ordinary Decimal diagnostics are separate. These are execution counts, with no implication all repeated precision cases are distinct geometries. Reviewer642 actual1D interval-model checks and auxiliary70 finite-atomic checks are separate. No reviewer repetition of complete runs.

Final verdict PASS within this bounded source-proof/code/ledger scope. All convergence is input-dependent without uniform resolution/rate; the limiting Gibbs/coupled pointwise source-profile root certificate remains unproved. No general theorem closure, full original chronology/entry certification or free Schur lower correlation is inferred.

## 8. Frozen SHA256 bindings

- /tmp/r332_aux.md — 6e9c8f0039867e92428bb00a9a8d8ee86b0582326217e572a46bd403d5ca62a3
- /tmp/r332_core.md — a4b6ab845f45ca39726a7d1f6d5cf070b105ee92576e8b7767babc32e6304f1e
- /tmp/r332_ledger.md — 1622db9bd400e88f7e48e71e927bbd9f6c3d0de66b5f0074d987b40451f28d39
- /tmp/r332_numeric.py — bac463f2b556622e9d90def01cf00724c25f2e2ffe737d4d7e2af387b985edf5
- /tmp/r332_numeric.md — e638e81f38110f4f031cf94c733385373877319a4fe9bc178629c03cddd16659
- /tmp/r332_numeric.json — 9606dbf852eb3d2613f26be510b91af7bd1d79616dab5fb31f6f4f77e3f196ee
- /tmp/r332_checks.py — 250f8c5ab0d69216e36dc5d3c392668478a72d6bc4eb1295eb3f02e68258cd16

Frozen after this append. Only /tmp/r332_audit.md was edited. No Git, other-author edits, extra full numeric run or TeX/PDF compilation. Numeric JSON is evidence-hash metadata; later parent archive/typesetting is outside this receipt.
