#!/usr/bin/env python3
"""Actual source incidence, discrete receivers: audit aggregate capacity objective."""
from fractions import Fraction as F
from decimal import Decimal,localcontext
from itertools import product
from math import isqrt
from collections import Counter
from pathlib import Path
import json
C=Counter()
EXACT_KEYS={'whole_source_cell_incidence','complete_source_partition','actual_q1_compact_source','exact_Cauchy_lower_G','exact_S0_sub_Gibbs','exact_Gibbs_saturated_capacity','exact_rational_S0_capacity'}
def ck(k,v):
 C[k]+=1
 assert v,k
def dec(x):return Decimal(x.numerator)/Decimal(x.denominator)
def sqrtbox(x,bits=100):
 scale=1<<bits;q=isqrt((x.numerator*scale*scale)//x.denominator);lo=F(q,scale);return lo,lo+F(1,scale)
def cells(n,receivers):
 axes=[]
 for a in range(n):axes.append(sorted(set([F(-2),F(2)]+[x[a]+sgn*r/2 for x,r,w in receivers for sgn in [-1,1]])))
 out=[]
 for ids in product(*[range(len(p)-1) for p in axes]):
  box=[(axes[a][i],axes[a][i+1]) for a,i in enumerate(ids)];mass=F(1)
  for lo,hi in box:mass*=hi-lo
  signature=tuple(int(all(lo>=x[a]-r/2 and hi<=x[a]+r/2 for a,(lo,hi) in enumerate(box))) for x,r,w in receivers)
  # Every source cell is fully contained or disjoint (null faces ignored).
  for c,(x,r,w) in zip(signature,receivers):
   outside=any(hi<=x[a]-r/2 or lo>=x[a]+r/2 for a,(lo,hi) in enumerate(box))
   ck('whole_source_cell_incidence',bool(c) or outside)
  out.append((mass,signature))
 ck('complete_source_partition',sum(m for m,c in out)==4**n)
 return out

def model(n,receivers,name):
 source=cells(n,receivers);N=len(receivers);ms=[r**n for x,r,w in receivers];mu=[w/m for (x,r,w),m in zip(receivers,ms)];W=F(4**n)
 for i,(x,r,w) in enumerate(receivers):
  ck('actual_q1_compact_source',sum(m*c[i] for m,c in source)==ms[i] and all(abs(z)+r/2<=2 for z in x))
 radii=sorted(set(r for x,r,w in receivers));ell=[r**(-n)-(radii[k+1]**(-n) if k+1<len(radii) else 0) for k,r in enumerate(radii)]
 result=[]
 for precision in [60,80]:
  with localcontext() as ctx:
   ctx.prec=precision;tol=Decimal(10)**(-(precision-12));X=sum(w for x,r,w in receivers);E=F(0);Q=Decimal(0);sums={k:Decimal(0) for k in ['gibbs_bill','gibbs_norm','gibbs_cut','gibbs_fit','gibbs_credit','S0_bill','S0_norm','S0_cut','S0_fit','S0_credit','S0_norm_error']};worst={k:Decimal('-Infinity') for k in ['gibbs','S0']};zeroJ=0
   for radius,weight in zip(radii,ell):
    active=[i for i,(x,r,w) in enumerate(receivers) if r<=radius];J=[sum(mu[i]*c[i] for i in active) for mass,c in source]
    I={};SG={};G={};t0={}
    for i in active:
     for j in active:
      key=i,j;I[key]=sum(m*c[i]*c[j] for m,c in source);SG[key]=sum((m*c[i]*c[j]/jj for (m,c),jj in zip(source,J) if jj),F(0));G[key]=sum((dec(m)*Decimal(c[i]*c[j])/dec(jj).sqrt() for (m,c),jj in zip(source,J) if jj),Decimal(0))
      ck('actual_G_Cauchy_numeric',G[key]**2<=dec(I[key]*SG[key])+tol)
      ck('actual_S0_sub_Gibbs_numeric',4*G[key]**2/(dec(ms[i]).sqrt()+dec(ms[j]).sqrt())**2<=dec(SG[key])+tol)
      # Rigorous rational lower G and upper sqrt(m) produce feasible rational sqrt(S0).
      gl=F(0)
      for (mass,c),jj in zip(source,J):
       if jj and c[i]*c[j]:gl+=mass/sqrtbox(jj)[1]
      den=sqrtbox(ms[i])[1]+sqrtbox(ms[j])[1];t0[key]=2*gl/den
      ck('exact_Cauchy_lower_G',gl*gl<=I[key]*SG[key])
      ck('exact_S0_sub_Gibbs',t0[key]**2<=SG[key])
    for i in active:
     ck('exact_Gibbs_saturated_capacity',sum(SG[i,j]*mu[j] for j in active)==ms[i])
     ck('exact_rational_S0_capacity',sum(t0[i,j]**2*mu[j] for j in active)<=ms[i])
    ep=sum((mu[i]*mu[j]*I[i,j]*SG[i,j] for i in active for j in active),F(0));E+=weight*ep
    q=sum((dec(mu[i]*mu[j])*G[i,j]**2 for i in active for j in active),Decimal(0));Q+=dec(weight)*q
    for label in ['gibbs','S0']:
     S={key:dec(v) if label=='gibbs' else dec(t0[key])**2 for key,v in SG.items()}
     h={key:(dec(ms[key[0]]).sqrt()+dec(ms[key[1]]).sqrt())*S[key].sqrt()/2 for key in S}
     norm=sum((dec(mu[i]*mu[j])*h[i,j]**2 for i in active for j in active),Decimal(0));cross=sum((dec(mu[i]*mu[j])*h[i,j]*G[i,j] for i in active for j in active),Decimal(0));error=sum((dec(mu[i]*mu[j])*(h[i,j]-G[i,j])**2 for i in active for j in active),Decimal(0))
     slack=sum((dec(mu[i]*ms[i])*(dec(ms[i])-sum(dec(mu[j])*S[i,j] for j in active)) for i in active),Decimal(0));energy=sum((dec(mu[i]*mu[j])*S[i,j]*(dec(ms[i]).sqrt()-dec(ms[j]).sqrt())**2/4 for i in active for j in active),Decimal(0));base=sum((dec(mu[i]*ms[i]**2) for i in active),Decimal(0))
     ck('norm_credit_identity',abs(norm+slack+energy-base)<=tol)
     cut=fit=meanD=Decimal(0)
     for (mass,c),jj in zip(source,J):
      if not jj:
       if label=='gibbs':zeroJ+=1
       continue
      V=sum((dec(receivers[i][2])*c[i] for i in active),Decimal(0));ss=sum((dec(mu[i]*mu[j])*S[i,j]*c[i]*c[j] for i in active for j in active),Decimal(0));fit_y=sum((dec(mu[i]*mu[j])*c[i]*c[j]*(dec(ms[i]).sqrt()/dec(jj).sqrt()-S[i,j].sqrt())**2 for i in active for j in active),Decimal(0));coverage=2*sum((dec(mu[i]*mu[j])*h[i,j]*c[i]*c[j]/dec(jj).sqrt() for i in active for j in active),Decimal(0));defect=2*V-coverage
      ck('source_cut_fit_identity',abs(V-ss+fit_y-defect)<=tol)
      cut+=dec(mass)*(V-ss);fit+=dec(mass)*fit_y;meanD+=dec(mass)*defect;worst[label]=max(worst[label],defect)
     bill=meanD-(slack+energy)
     ck('complete_aggregate_square_identity',abs(bill-(base-q+error))<=tol)
     for k,v in [('bill',bill),('norm',norm),('cut',cut),('fit',fit),('credit',slack+energy)]:sums[label+'_'+k]+=dec(weight)*v
     if label=='S0':sums['S0_norm_error']+=dec(weight)*error
   ck('original_square_vs_symmetric',dec(E)+tol>=Q)
   ck('S0_optimal_aggregate_approximation',sums['S0_norm_error']<Decimal('1e-50'))
   values=dict(precision=precision,original_Ball=str(dec(X-E)),symmetric_upper_X_minus_Q=str(dec(X)-Q),X=str(dec(X)),E_original=str(dec(E)),Q_symmetric=str(Q),zero_J_source_cells_over_prefixes=zeroJ,**{k:str(v) for k,v in sums.items()})
   result.append(values)
 ck('two_precision_budget_agreement',abs(Decimal(result[0]['S0_bill'])-Decimal(result[1]['S0_bill']))<Decimal('1e-45'))
 return dict(name=name,n=n,receivers=[dict(center=[str(z) for z in x],radius=str(r),weight=str(w)) for x,r,w in receivers],receiver_scope='finite actual-cube receiver quadrature, not continuous dx or original selector proof',source_cell_count=len(source),source_mass=str(W),results=result)
def main():
 fixtures=[('initial',1,[((F(-1,4),),F(1),F(1,5)),((F(1,4),),F(3,2),F(1,5))]),('overlap_boundary',2,[((F(-1,2),F(0)),F(1),F(1,10)),((F(0),F(-1,2)),F(1),F(1,10)),((F(1,2),F(1,2)),F(3,2),F(1,5)),((F(0),F(0)),F(2),F(1,10))]),('expanded',3,[((F(-1,2),F(0),F(0)),F(1),F(1,10)),((F(0),F(-1,2),F(0)),F(1),F(1,10)),((F(0),F(0),F(1,2)),F(3,2),F(1,10)),((F(1,2),F(1,2),F(0)),F(3,2),F(1,10)),((F(0),F(0),F(0)),F(2),F(1,10))])]
 models=[];stages=[]
 for name,n,r in fixtures:
  before=sum(C.values());models.append(model(n,r,name));stages.append(dict(stage=name,n=n,checks=sum(C.values())-before))
 result=dict(status='PASS',total_checks=sum(C.values()),exact_rational_checks=sum(C[k] for k in EXACT_KEYS),ordinary_decimal_checks=sum(v for k,v in C.items() if k not in EXACT_KEYS),check_counts=dict(C),stages=stages,models=models,solver_status='NumPy2.3.5 imports; bundled scipy/cvxpy absent; local scipy1.15.3 optimize import fails malformed _spropack Mach-O. No solver optimization claim.',conclusion='S0 realizes the full aggregate-optimal h=Phi_f within row capacities; maximizing coverage alone is not minimizing the complete bill. Worst-source/shared-zeta optimization remains unsolved.')
 Path(__file__).with_suffix('.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n');print(json.dumps({k:result[k] for k in ['status','total_checks','exact_rational_checks','ordinary_decimal_checks','check_counts','stages']},sort_keys=True))
if __name__=='__main__':main()
