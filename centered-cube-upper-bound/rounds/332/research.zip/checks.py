from fractions import Fraction as F
import json
count=0
for case in range(1,81):
    # Four receiver rows, full common source plus four unique sources.
    # Finite incidence algebra only; no continuum receiver or root claim.
    f=[F(1+((case*7+i*3)%11),9) for i in range(5)]
    c=[[1]+[int(u==j) for j in range(4)] for u in range(4)]
    J=[F(4),F(1),F(1),F(1),F(1)]
    rootJ=[F(2),F(1),F(1),F(1),F(1)]
    m=[sum(f[y]*c[u][y] for y in range(5)) for u in range(4)]
    # General m roots need irrational numbers: use unequal masses only for
    # Cauchy and posterior variance; exact capacity Sbar=G²/max(m_u,m_v).
    for u in range(4):
      row=F(0)
      for v in range(4):
        I=sum(f[y]*c[u][y]*c[v][y] for y in range(5))
        G=sum(f[y]*c[u][y]*c[v][y]/rootJ[y] for y in range(5))
        SG=sum(f[y]*c[u][y]*c[v][y]/J[y] for y in range(5))
        D=sum(f[y]*abs(c[u][y]-c[v][y]) for y in range(5))
        variance= sum(f[y]*f[z]*c[u][y]*c[v][y]*c[u][z]*c[v][z]*(1/rootJ[y]-1/rootJ[z])**2 for y in range(5) for z in range(5))/2
        assert D==m[u]+m[v]-2*I; count+=1
        assert I*SG-G*G==variance>=0; count+=1
        assert G*G/max(m[u],m[v])<=SG; count+=1
        row+=G*G/max(m[u],m[v])
      assert row<=m[u]; count+=1
print(json.dumps({'status':'PASS','checks':count,'scope':'finite incidence exact Cauchy, source symmetric difference, posterior variance and subcapacity; not continuum/root'}))
# Exact unequal square-mass regression for the corrected slack decomposition.
extra=0
for a in range(1,10):
 for b in range(1,10):
  mu,mv=F(a*a),F(b*b); I=min(mu,mv)/2
  SG=I*F(5,8); G=I*F(3,4) # equal overlap weights at J=1 and J=4
  d=F(a+b); ds=mu+mv-2*I; variance=I*SG-G*G
  S0=4*G*G/(d*d)
  assert d*d-4*I==2*ds-F((a-b)**2); extra+=1
  assert SG-S0==SG*(F((a-b)**2)+4*(a*b-I))/(d*d)+4*variance/(d*d)>=0; extra+=1
print(json.dumps({'corrected_slack_exact_checks':extra,'combined_exact_checks':count+extra}))
