import json, sys
import sympy as s
b,d,G,J,L,C,S,xi=s.symbols('b d G J L C S xi',positive=True)
rho=xi*J/(b*b*d*d)
original=(G*G*J*L/(b*b*d*d)+2*C*S*(1+2*G)/(b*b*d))/(1-rho)
closed=(G*G*J*L+2*C*S*(1+2*G)*d)/(b*b*d*d-xi*J)
residual=s.factor(original-closed)
assert residual==0
print(json.dumps({'interpreter':sys.executable,'sympy':s.__version__,'absorption_residual':str(residual),'scope':'symbolic identity only; no new geometric inequality tested'},ensure_ascii=False,indent=2))
