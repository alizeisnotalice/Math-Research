# Round 67: compensated weak occupation and integrated row obstructions

2026-10-11. **The uniform bound sqrt(n)n^{o(1)} remains unproved.**
The retained fully general benchmark is O(n log n). This round returns to
actual weak threshold bands and keeps the source-weighted average as the
objective. It does not replace that average by a uniform per-source row.

## Results and scope

For arbitrary finite positive atomic sources, complete capture batches
give a finite Borel maximal-cube selector and a compensated running-record
identity. Incoming source mass repays the exact volume-decay deficit
before producing a new record. A clipped record potential gives actual
Lebesgue band volume, with a finite random-threshold hazard and one common
source allocation. This equality is not itself an upper bound; its source
marginal is not automatically the source prior. No spatial martingale or
Snell-envelope claim is imported.

The full-superlevel one-site and strict-majority optimal-cube branches
are paid by W each. The remaining class has at least two captured sites
and at most half the total mass. A uniform residual-band budget b_n would
give C_n<=2+2b_n, with the all-band summation explicit. The residual budget
is unproved. Dropping the compensation instead gives only a visible
source-entropy bound. An exact grid demonstrates arbitrarily many true
records and clipped-positive records at fixed weak-band volume.

The energy alternative also needs a weaker interface than the natural
mass-weighted row Schur test. The companion proof gives a one-dimensional
geometric-source obstruction after spatial integration, then transfers
it to actual uniform Calderon--Zygmund target blocks at a specified fixed
large dilation. This does not refute source-weighted total signed energy,
operator estimates with other weights, or the canonical small-dilation
target. Any small-dilation quadrature is separately labelled finite
numerical evidence.

## Reproduction and evidence

The archive contains proof.md, proof.tex.txt, record_probe.py,
record_results.json, and inventory.json. Preserve record_results.json,
then run `python3 -B record_probe.py` in an extracted temporary directory
with Python 3.12.14 and NumPy 2.3.5. The two supplemental guards are
embedded in the corresponding proof sections; extract and run each
Python block independently with the dependencies stated there.
The parent independently replays the final script and guards, reviews
their proof interfaces, and checks the output hashes. Those checks do
not turn sampled receiver integration into a proof of a uniform bound.
Decimal precision agreement is not outward-rounded interval arithmetic.
LaTeX is saved as .tex.txt without compilation or PDF output.

The installed 64-skill collection was refreshed again in this round:
all 64 entry hashes match Round66, all 437 direct references exist, and
two evidence-resolver checks pass. This round rereads the used
E01/E04/M04 and F05 interfaces and their limitations. Finite flow algebra,
Borel selection and exact kernel estimates are proved directly. No
external occupation-LP equivalence, source-preserving stopping theorem,
or unverified row/column estimate is silently assumed.



# Round 67: true weak bands and compensated record occupation

The general centered-cube weak estimate remains unproved. This note returns to the original maximal function of an arbitrary finite positive atomic source. It gives an exact finite occupation flow, retains the volume-decay debt that ordinary positive-arrival charges discard, pays two branches of the genuine optimal-cube selection, and isolates the remaining general geometric budget. The occupation equality itself is a reduction, not a new upper bound.

## 1. One common, actual optimal selection

Merge duplicate source sites first, and write \(\mu=\sum_{i=1}^Np_i\delta_{y_i}\), \(p_i>0\), \(W=\sum_i p_i\). Ignore the finite set of source receivers, where the maximal function is infinite and which has Lebesgue measure zero. At every other receiver \(x\), put \(v_i(x)=(2\|x-y_i\|_\infty)^n>0\), and group equal volumes into distinct ordered arrivals

\[
 0<v_1<\cdots<v_K,\qquad
 \delta_j=\sum_{i:v_i=v_j}p_i,\qquad
 F_j=\sum_{\ell\le j}\delta_\ell,
 \quad a_j=F_j/v_j.
\]

Here and below the grouped notation depends on \(x\). All averages between arrivals decrease with the volume. Consequently

\[
 M\mu(x)=\max_{j\le K}a_j(x).
\]

Choose the smallest arrival volume attaining this maximum; when a source index is needed, choose the smallest index among its boundary group. This gives one Borel selection \(Q_*(x)\), used throughout the note. Indeed there are finitely many distances and all comparisons of distances and atomic averages are Borel. No general measurable selection theorem is needed. Grouping is mandatory in dimensions where equal distances occur on positive-measure sets.

Fix the actual band

\[
 B_H=\{x:H<M\mu(x)\le2H\},\qquad H>0.
\]

This band is bounded: a cube with average greater than \(H\) has volume less than \(W/H\), and contains a source site. Thus \(B_H\) is contained in the finite union of source-centered cubes of volume \(W/H\).

## 2. The exact new-record flow and its debt

Let \(R_0=F_0=0\), \(R_j=\max_{\ell\le j}a_\ell\), and

\[
 \Delta_j=R_j-R_{j-1}=(a_j-R_{j-1})_+,
 \quad \kappa_j=v_j\Delta_j/\delta_j.
\]

The coefficients satisfy \(0\le\kappa_j\le1\), and

\[
 M\mu(x)=\sum_j\Delta_j
 =\sum_i\frac{p_i\kappa_{j(i,x)}(x)}{v_i(x)}. \tag{2.1}
\]

The key compensation is exact, not a positive majorant:

\[
 \boxed{\quad
 \kappa_j=
 \left[1-\frac{v_jR_{j-1}-F_{j-1}}{\delta_j}\right]_+.
 \quad} \tag{2.2}
\]

The numerator is nonnegative because \(R_{j-1}\ge F_{j-1}/v_{j-1}\ge F_{j-1}/v_j\). It includes both decay of the captured inventory while the volume grows and any shortfall below an earlier record. In particular, for \(j\ge2\),

\[
 \kappa_j\le
 \left[1-\frac{(v_j/v_{j-1}-1)F_{j-1}}{\delta_j}\right]_+. \tag{2.3}
\]

Thus an arrival that merely maintains a coherent mass-volume profile does not get a fresh full charge. A record requires the new arrival mass to beat the volume-decay debt. This is the concrete additional constraint missing from ordinary positive arrival charge, source-ray mean identities, and positive curvature variation. It is not yet an integrated geometric estimate.

The smallest maximal winner index \(j_*\) stops this deterministic record flow: all \(\Delta_j\) with \(j>j_*\) vanish. Since \(j_*\) depends on future arrivals, it is not silently identified with a stopping time for a filtration that reveals only the past. No Snell-envelope or optional-stopping theorem is invoked here.

There is also an exact inventory flow. Extend \(F(v)\) as the captured mass and \(R(v)\) as the running record, with their post-arrival values. Put \(D(v)=vR(v)-F(v)\ge0\). Between arrivals, \(dD=R\,dv\). Just before arrival \(v_j\),

\[
 D_j^-=v_jR_{j-1}-F_{j-1},\qquad
 D_j^+=\max\{D_j^--\delta_j,0\},\qquad
 v_j\Delta_j=(\delta_j-D_j^-)_+.
\]

The arriving mass splits exactly into deficit repayment \(\min\{\delta_j,D_j^-\}\) and new record payment \(v_j\Delta_j\); it is not charged to both. As a signed finite-measure identity,

\[
 dD=R\,dv+v\,dR-dF.
\]

For \(0\le a<b\), using post-arrival values at both endpoints and summing arrivals in \((a,b]\),

\[
 \sum_{a<v_j\le b}v_j\Delta_j
 =F(b)-F(a)-\int_a^bR(v)dv+D(b)-D(a). \tag{2.4}
\]

Off source receivers, the zero-volume values are \(R(0)=F(0)=D(0)=0\). All statements are finite deterministic calculus, not a martingale decomposition. For the whole source path, \(\sum_j\delta_j\kappa_j\le W\) at each receiver. Dividing these payments by their receiver-dependent volumes is what creates the remaining spatial geometry problem; this pointwise mass bound does not pay all receivers at once.

The finite-window endpoint cannot be discarded: beyond the last arrival, \(R=M\) and \(F=W\), so \(D(b)=bM-W\) grows linearly and compensates the running integral. Formula (2.4) is not a summable infinite-window budget with a free terminal term.

## 3. A randomized threshold gives exact Lebesgue receiver occupation

Define the increasing one-Lipschitz potential

\[
 \phi_H(r)=\min\{H/2,(r-H/2)_+\}.
\]

Set

\[
 d_j=\phi_H(R_j)-\phi_H(R_{j-1}),\qquad
 \kappa_j^{\rm clip}=v_jd_j/\delta_j.
\]

Then \(0\le\kappa_j^{\rm clip}\le\kappa_j\le1\). On the ORIGINAL band \(B_H\),

\[
 \sum_jd_j=H/2,
 \qquad
 \boxed{\frac H2|B_H|
 =\sum_i p_i L_i^{\rm clip}(H),\quad
 L_i^{\rm clip}(H)=\int_{B_H}
       \frac{\kappa_{j(i,x)}^{\rm clip}(x)}{v_i(x)}dx.} \tag{3.1}
\]

The left side uses actual Lebesgue receiver volume. Each source weight \(p_i\) occurs only in the one displayed source sum; no source is independently replaced at each receiver. Nevertheless, source-column loads \(L_i^{\rm clip}\) are not automatically bounded. The right side is not already a source mass budget.

Here is the exact finite stopping interpretation, with its filtration stated. For fixed \(x\), draw \(T\) uniformly from \([H/2,H]\), and let \(J\) be the first record index with \(R_J\ge T\). Given \(x\), the arrival sequence is deterministic. In the filtration generated by the past threshold-crossing indicators, \(J\) is a stopping time. Before crossing, the conditional threshold law is uniform on \([\max\{H/2,R_{j-1}\},H]\); endpoint equalities have probability zero. The conditional hazard is

\[
 h_j(x)=\frac{d_j(x)}{H/2-\phi_H(R_{j-1}(x))}
\]

when the denominator is positive. After survival is zero, the hazard is irrelevant and may be assigned zero. On \(B_H\),

\[
 \Pr(J=j\mid x)=2d_j/H,
 \qquad \sum_j\Pr(J=j\mid x)=1.
\]

At the crossing, select a source from the arrival group with probability \(p_i/\delta_j\). The resulting receiver-to-source row kernel is

\[
 P(I=i\mid x)=\frac2H\frac{p_i}{\delta_{j(i,x)}}d_{j(i,x)}
 =\frac{2p_i}{H}\frac{\kappa_{j(i,x)}^{\rm clip}}{v_i}.
\]

It has row sum one. Its source marginal after integrating \(dx\) is \((2p_i/H)L_i^{\rm clip}\), not \(p_i/W\). A proof that this marginal has an affordable aggregate load is precisely what is missing. Independent-coin tails, Freedman bounds, a Poisson compensator, and source-prior preservation do not follow from the displayed hazard.

## 4. A valid finite-complexity upper bound, with its dependence visible

If \(\kappa_j^{\rm clip}>0\), then \(a_j>H/2\), hence \(v_j<2W/H\). On \(B_H\), every original cube average is at most \(2H\), so \(p_i/v_i\le2H\) at any source arrival. Thus the nonzero column is supported within

\[
 p_i/(2H)\le v_i<2W/H.
\]

The source-centered volume coordinate has the exact pushforward \(dx\mapsto dv\), because \(|\{x:(2\|x-y_i\|_\infty)^n\le v\}|=v\). With \(\kappa^{\rm clip}\le1\),

\[
 L_i^{\rm clip}\le\log(4W/p_i),
 \qquad
 H|B_H|\le2\sum_i p_i\log(4W/p_i). \tag{4.1}
\]

This is a proved entropy-dependent estimate, not the dimension-only target. For equal weights it contains \(\log N\). The radial pushforward in this proof is the previously known cone identity, not new payment. What is new in the candidate is the record debt (2.2), which must improve the integral rather than merely be dropped as in (4.1).

For one atom, the exact all-scale benchmark is particularly simple:

\[
 |B_H|=p/(2H),\quad L^{\rm full}=\log2,
 \quad\kappa^{\rm clip}=H/(2M),\quad L^{\rm clip}=1/4.
\]

There is one physical arrival at each receiver, so the old shared-uniform finite-scale rare simultaneous-activation mechanism is absent. This benchmark does not establish a uniform many-source column bound.

An actual finite lattice also rules out charging unweighted record counts. Take \(h=1/N\), \(\mu_N=h\sum_{i=1}^N\delta_{(i-1/2)h}\), and \(H=1/4\). For an exterior receiver whose distance to the first site is \(d\),

\[
 a_k=\frac{kh}{2(d+(k-1)h)}
\]

strictly increases exactly when \(d>h\). The actual left band interior is \((-1-h/2,-h/2)\), where \(d>h\), and the right band is its reflection about \(1/2\). The two intervals have total volume two and \(H|B_H|=1/2\), while every one of the \(N\) arrivals is a record almost everywhere in the band. At \(x=-1/2-h/2\), for \(N\) divisible by six, \(a_k=kh/(1+2kh)\); exactly \(N/3\) arrivals have positive clipped increments, yet their sum is always \(H/2=1/8\). This defeats raw count charging, not the compensated occupation budget.

## 5. Two general weak branches really are paid

Use the same smallest-volume optimal cube \(Q_*\) to define three full-space classes, ignoring the finite source receiver set. Let \(S_{\rm single}\) contain receivers whose winner captures one distinct source site. Let \(S_{\rm maj}\) contain the remaining receivers whose winner captures strictly more than \(W/2\). Let \(S_{\rm res}\) contain the remaining receivers: the winner captures at least two distinct sites and mass at most \(W/2\), including equality. These classes are independent of all thresholds. Set \(E_\lambda=\{M\mu>\lambda\}\) and \(E_{\rm type}=E_\lambda\cap S_{\rm type}\).

For the single-source branch, the selected average is \(p_i/v_i>\lambda\), so its receiver lies in a source-centered cube of volume \(p_i/\lambda\). The union bound proves

\[
 \lambda|E_{\rm single}|\le W. \tag{5.1}
\]

For the strict-majority branch, every selected cube has volume \(v_*<W/\lambda\). Enlarge it about the same receiver to the common volume \(V=W/\lambda\). The enlarged cube still captures more than half the total source mass. Any two such cubes have captured-source intersection of positive mass, hence intersect geometrically. Their common side length is \(V^{1/n}\), so their centers have pairwise coordinate distance at most \(V^{1/n}\). Each coordinate range of the receiver set therefore has length at most \(V^{1/n}\). Its bounding box has volume at most \(V\), giving

\[
 \lambda|E_{\rm maj}|\le W. \tag{5.2}
\]

Strict majority is necessary: two distant equal half-mass clusters need not have overlapping capture sets. Tie resolution does not remove the equality case, which stays in the residual branch.

Consequently it suffices to prove, for all finite positive sources and all \(H>0\),

\[
 H|B_{\rm res}(H)|\le b_nW,
 \quad
 B_{\rm res}(H)=\{H<M\mu\le2H\}\cap S_{\rm res},
 \quad b_n=O(\sqrt n\,n^{o(1)}). \tag{5.3}
\]

The classifications depend only on the common winner and the source, not on \(H\), apart from the band. Split \(E_{\rm res}\) into the disjoint bands \(H_k=2^k\lambda\), \(k\ge0\). Their weights satisfy \(\sum_k\lambda/H_k=2\), so (5.3), (5.1), and (5.2) give

\[
 \lambda|E_\lambda|\le(2+2b_n)W. \tag{5.4}
\]

There is no hidden depth fee in this conditional implication: the explicit geometric weights pay the sum over all bands. The unknown is (5.3), not summation over bands.

The final weak constant also applies to general nonnegative \(L^1\) sources through the zero-loss atomic reduction. For completeness, truncate \(f\,dx\) to \([-k,k]^n\), partition into cells of side tending to zero, and put each cell's exact mass at its center. The finite atomic masses \(W_k\) tend to \(W\). For any witnessing centered cube whose average is strictly above \(\lambda\), slightly enlarge it while retaining the strict inequality. Its original mass is inside the enlarged open cube; all sufficiently fine interior cells have their centers inside that cube. Thus every receiver with \(Mf>\lambda\) belongs to \(\{M\mu_k>\lambda\}\) eventually. Fatou's lemma and the uniform finite-atomic inequality give \(\lambda|\{Mf>\lambda\}|\le(2+2b_n)W\). This reduction has no atom-number or depth loss.

Formula (3.1) remains exact when restricted to \(B_{\rm res}(H)\). Thus its precise source-weighted sufficient budget is

\[
 \sum_i p_i\int_{B_{\rm res}(H)}
  \frac{\kappa_{j(i,x)}^{\rm clip}}{v_i(x)}dx\le\frac{b_n}2W. \tag{5.5}
\]

This last inequality is equivalent to the band volume through the exact flow; it is not proved by introducing occupation variables. The actionable structural information beyond that equivalence is the bounded coefficient, its explicit decay debt, the first-crossing hazard, the fixed source sum, and the paid exclusion of the one-site and strict-majority optimal branches. None yet implies (5.5).

## 6. Relation to prior failures and skill boundaries

The old `radial_shared_uniform_budget_20261007.md` first 150 lines and `gated_occupancy_bridge.md` cone identity were reread. Their shared-uniform mean is the weak volume itself, and their stronger Palm small-count contract fails on the genuine one-source finite hard model. This note asserts no new payment from the same radial mean and no count-tail contract. It changes the physical charge from winner acceptance or all arrival mass to the compensated increment of the original running maximal record. The coefficient (2.2) is the difference that must be used by a future geometric proof.

The Round 66 positive-curvature majority-digit counterexample remains relevant: no uniform positive-curvature budget is sought here. The record process is monotone, so it does not pay every alternating scale fluctuation. This distinction does not automatically prove its source columns are affordable.

Current E01/E04/M04 entrances, methods, cube interfaces, and provenance status sections were reread. We use finite explicit occupation and threshold algebra, not an occupation-LP no-gap theorem. The actual optimum is obtained by finitely many Borel comparisons, not an unverified general selection theorem. The first threshold crossing has an explicit finite filtration, but its record rewards are not asserted to be a Snell envelope, a supermartingale, or a source-spatial compensated process. No external skill theorem is needed for the displayed identities.

## 7. Multistage numerical pressure design

The numerical agent separately owns the actual physical-cube record probe. Its design has been synchronized with this note: grouped arrivals, original band, common smallest-volume winner, \(\kappa\), clipped \(\kappa\), and debt are mandatory.

Stage A checks exact finite receiver algebra and ties, including source group allocations. Stage B measures actual Lebesgue volume using a documented deterministic or importance-sampling spatial rule, with explicit error limitations. Stage C stratifies the winner into one-site, strict-majority, and multisource-at-most-half branches; only the last is the unpaid target. Stage D compares weighted clipped attribution, full record attribution, and true optimal-cube attribution, and records low-mass column peaks and the compensation ratio \(((v_j/v_{j-1})-1)F_{j-1}/\delta_j\). All-source weights and original receiver bands must be retained; raw record counts or unweighted arrivals cannot replace the charge. Grid refinement and exact benchmark checks are required before interpreting any trend.

The exact guard below is limited to finite algebra and physical receiver checks, so it does not duplicate the larger spatial probe or claim unsampled volume certification.

```python
from fractions import Fraction as F
from itertools import product
from decimal import Decimal, localcontext

def phi(r,H):
    return min(H/2,max(F(0),r-H/2))

def arrivals(sites,weights,x):
    n=len(x)
    groups={}
    for i,(y,p) in enumerate(zip(sites,weights)):
        v=(2*max(abs(x[k]-y[k]) for k in range(n)))**n
        if v==0:
            return None
        groups.setdefault(v,[]).append(i)
    return sorted(groups.items())

# Stage A: exact physical arrivals, ties, debt and source-row allocation.
models=[
    ([(F(0),),(F(1),)],[F(1,2),F(1,2)]),
    ([(F(0),),(F(1,4),),(F(1),)],[F(1,10),F(2,10),F(7,10)]),
    ([(F(i)+F(1,2),) for i in range(6)],[F(1,6)]*6),
    (list(product((F(-1),F(1)),repeat=2)),[F(1,4)]*4),
    (list(product((F(-1),F(1)),repeat=3)),[F(1,8)]*8),
]
physical_checks=band_checks=tie_checks=majority_pair_checks=0
for sites,weights in models:
    n=len(sites[0]); W=sum(weights)
    axis=[F(i,2) for i in range(-4,5)]
    sample=list(product(axis,repeat=n))
    for H in (F(1,8),F(1,4),F(1),F(4)):
        majority_receivers=[]
        for x in sample:
            groups=arrivals(sites,weights,x)
            if groups is None:
                continue
            Fprev=Rprev=F(0)
            vprev=F(0)
            records=[]
            running_integral=record_payment=F(0)
            for v,ids in groups:
                delta=sum(weights[i] for i in ids)
                if vprev:
                    running_integral+=Rprev*(v-vprev)
                debt=v*Rprev-Fprev
                assert debt>=0
                mass=Fprev+delta
                a=mass/v; R=max(Rprev,a)
                Delta=R-Rprev; kappa=v*Delta/delta
                d=phi(R,H)-phi(Rprev,H)
                clipped=v*d/delta
                assert kappa==max(F(0),1-debt/delta)
                assert v*R-mass==max(F(0),debt-delta)
                assert min(delta,debt)+v*Delta==delta
                assert 0<=clipped<=kappa<=1
                if vprev:
                    chi=(v/vprev-1)*Fprev/delta
                    assert kappa<=max(F(0),1-chi)
                records.append((v,ids,mass,a,Delta,kappa,d,clipped))
                record_payment+=v*Delta
                Fprev,Rprev,vprev=mass,R,v
                physical_checks+=1
                tie_checks+=(len(ids)>1)
            M=Rprev
            assert sum(z[4] for z in records)==M
            assert record_payment<=W
            # Integrate to a post-arrival endpoint b=2*v_last.
            b=2*vprev
            running_integral+=M*(b-vprev)
            endpoint_debt=b*M-W
            assert record_payment==W-running_integral+endpoint_debt
            winner=next(z for z in records if z[3]==M)
            if winner[2]>W/2 and M>H:
                majority_receivers.append(x)
            if not H<M<=2*H:
                continue
            assert sum(z[6] for z in records)==H/2
            probs=[]; survival=F(1)
            for v,ids,mass,a,Delta,kappa,d,clipped in records:
                probability=2*d/H
                if survival:
                    hazard=probability/survival
                    assert 0<=hazard<=1
                    assert survival*hazard==probability
                elif probability:
                    raise AssertionError('payment after survival exhausted')
                survival-=probability
                for i in ids:
                    probs.append(2*weights[i]*clipped/(H*v))
                    if clipped:
                        assert weights[i]/(2*H)<=v<2*W/H
                band_checks+=1
            assert survival==0 and sum(probs)==1
        # Any two majority receivers fit the common equal-volume cube bound.
        for x,y in product(majority_receivers,repeat=2):
            assert max(abs(x[k]-y[k]) for k in range(n))**n<=W/H
            majority_pair_checks+=1
print('stageA exact physical/group/band checks:',physical_checks,tie_checks,band_checks)
print('stageA exact majority receiver-pair checks:',majority_pair_checks)

# Stage B: the actual one-atom band has volume p/(2H) in every dimension.
for n in (1,2,3,8,32):
    p,H=F(3,7),F(5,11)
    band_volume=p/H-p/(2*H)
    Lclip=(H/(2*p))*band_volume
    assert H*band_volume==p/2
    assert Lclip==F(1,4)
print('stageB exact one-atom clipped-load checks: 5')

# Stage C: true exterior-band records can be numerous without volume growth.
for N in (6,12,24,48,96,192):
    h=F(1,N); H=F(1,4)
    sites=[((F(i)+F(1,2))*h,) for i in range(N)]
    weights=[h]*N
    x=(-F(1,2)-h/2,)
    gs=arrivals(sites,weights,x)
    R=F(0); mass=F(0); count=clipcount=0; clipsum=F(0)
    for v,ids in gs:
        mass+=sum(weights[i] for i in ids)
        a=mass/v
        assert a>R
        count+=1
        d=phi(a,H)-phi(R,H)
        clipcount+=(d>0); clipsum+=d; R=a
    assert H<R<=2*H and R==F(1,3)
    assert count==N and clipcount==N//3 and clipsum==H/2
    # d=h endpoint: all arrival averages tie, smallest winner is first.
    endpoint=(-h/2,)
    mass=F(0); values=[]
    for v,ids in arrivals(sites,weights,endpoint):
        mass+=sum(weights[i] for i in ids)
        values.append(mass/v)
    assert set(values)=={F(1,2)}
print('stageC exact record-count/clip-count/endpoint checks: 6')

# Stage D: visible entropy cost and the infinite band-summation factor.
assert sum(F(1,2**k) for k in range(20))==2-F(1,2**19)
maxdiff=Decimal(0)
for N in (1,2,16,256,4096):
    answers=[]
    for precision in (80,140):
        with localcontext() as ctx:
            ctx.prec=precision
            answers.append(2*Decimal(4*N).ln())
    maxdiff=max(maxdiff,abs(answers[0]-answers[1]))
    assert abs(answers[0]-answers[1])<Decimal('1e-70')
print('stageD max Decimal entropy-cost refinement:',maxdiff)
print('PASS: finite algebra and actual physical receivers; no spatial quadrature claim')
```

Actual replay passed: 10,120 exact physical-arrival/debt checks, including 6,060 grouped-tie events; 131 band-event row allocations and survival checks; 76 exact majority receiver-pair checks; five one-atom clipped-load checks; six complete lattice record-count and endpoint checks. The five 80/140-digit entropy-cost comparisons had maximum difference below \(3.122\cdot10^{-79}\). These checks support the finite algebra and conventions. They are not Lebesgue quadrature certification and do not establish the remaining geometric budget.


# Round 67: spatially integrated natural-row obstruction

The natural source-mass row Schur condition fails even after the receiver variable has been integrated. The example consists of actual uniform maximal dyadic CZ blocks in dimension one, with fixed height and a fixed large dilation parameter. This is a counterexample to a stronger sufficient interface, not to the desired source-mass averaged or signed energy budget. The general cube weak upper bound remains unproved.

## Interface and precise scope

Put H=1, n=1, q=e, u=log L, and D=A_{eL}-A_L. For disjoint target blocks F_i of mass p_i, let

\[
 {\cal K}_{ij}=\int_G\int_{\mathbb R}DF_i(x,u)DF_j(x,u)\,du\,dx,
 \qquad G=\{M\mu\le1\}.
\]

The interface under test is

\[
 \sup_i {1\over p_i}\sum_j|{\cal K}_{ij}|\le C(1,\alpha).
 \tag{R}
\]

It would imply the absolute mass-averaged budget by summing the rows. Equivalently, for B_{ij}={\cal K}_{ij}/\sqrt{p_ip_j}, it is the weighted Schur test with weights w_i=\sqrt{p_i}. Symmetry supplies the matching column condition if (R) holds. Positive semidefiniteness of the Gram matrix alone does not imply (R).

We prove that no finite C(1,2^{20}-1) works for (R). This also refutes a statement uniform over all admissible alpha. It does NOT establish failure for the canonical alpha=2n^2+1 (which equals 3 here). A finite numerical check at alpha=3 is recorded below as evidence only.

The small row has exponentially tiny mass. Thus its divergence does not establish divergence of the normalized Gram operator norm, of the mass-averaged absolute Gram sum, or of the desired signed sum. Adaptive positive Schur weights are not ruled out.

## Exact original good set

For N>=4, define c_0=1/8, d_j=2^{-j}, p_j=c_0d_j (1<=j<=N), and p_0=c_0 2^{-N-8}. Take

\[
 \mu_N=p_0\delta_0+\sum_{j=1}^Np_j\delta_{d_j}.
\]

For a contiguous source block with endpoints a<=b and mass P, an interval centered at x captures that block with average greater than 1 precisely when x lies in (b-P/2,a+P/2), provided the latter interval is nonempty. Indeed the smallest capturing radius is max(|x-a|,|x-b|); endpoint conventions affect only null boundaries. Every captured collection is contiguous, so taking the union over all contiguous blocks gives the full bad set.

Any block of at least two positive atoms, with largest position d, has span at least d/2 and mass less than 2c_0d=d/4. A block containing zero and a positive atom has span d and mass less than d/4+p_0<d. Consequently only singleton blocks contribute:

\[
 \Omega_N=\{M\mu_N>1\}
 =(-p_0/2,p_0/2)\ \cup\
 \bigcup_{j=1}^N(15d_j/16,17d_j/16)
 \quad\hbox{a.e.}
 \tag{1}
\]

These open intervals are disjoint. In particular there is no unverified atomic-to-continuum cap limit.

## Integrated atom interaction

If two capture lengths satisfy a<=b, direct integration in u gives

\[
 J(a,b)=
 \begin{cases}
 (1-\frac1{2e})b^{-2}-\frac1{2e}a^{-2},&b\le ea,\\
 -\frac{(e-1)^2}{2e}b^{-2},&b>ea.
 \end{cases}
 \tag{2}
\]

For distinct source locations y,z define J_{y,z}(x) by a=2min(|x-y|,|x-z|) and b=2max(|x-y|,|x-z|). All scale factors in (2) correspond to u=log L, not log radius. The full spatial integral is zero:

\[
 \int_{\mathbb R}J_{y,z}(x)\,dx=0,\qquad
 g_G(y,z):=\int_GJ_{y,z}=-\int_{\Omega_N}J_{y,z}.
 \tag{3}
\]

This is the one-dimensional off-diagonal identity from Round 64; it can also be checked directly by splitting at the five switch points used in the executable guard. For fixed y!=z the spacetime product is absolutely integrable, so this instance of Fubini is legitimate. The atom Gram entry is p_ip_j g_G(y_i,y_j).

Here is a fully rational lower bound for the right side of (3). Normalize the pair (0,d_j) by x=d_j t. The positive-atom holes become

\[
 I_k=(15\,2^k/16,17\,2^k/16),\qquad j-N\le k\le j-1.
\]

For 3<=j<=N-1 the range includes k=-1,0,1,2. The bounds 8/3<e<11/4 follow from the exponential series (the upper tail after degree 3 is at most 5/96). Set C=(e-1)^2/(2e)<9/16. Write Psi(t)=J_{0,1}(t). The following estimates are bounds on the actual integrals over the indicated holes:

\[
\begin{array}{c|c}
 \hbox{holes} & \hbox{lower bound on integral of Psi}\\ \hline
 I_{-1} & M=(343/600)(256/289)/16\\
 I_0 & -A=-3/170\\
 \bigcup_{k\le-2}I_k & -B=-(9/64)(64/47)^2/16\\
 I_1 & L_1=4/255-(3/4)(1/255+1/63)\\
 I_2 & L_2=(449/968)(4/289)/2\\
 I_k,\ k\ge3 & 0
\end{array}
\tag{4}
\]

For clarity, I_{-1} has far/near ratio at most 17/15 and far capture length at most 17/16. On I_0 the remote branch is exact and its integral is -8C/255. For k<=-2, t<=17/64, the ratio is at least 47/17>e, the total length is at most 1/16, and 2(1-t)>=47/32. On I_1 the exact integral is 4/255-(2/255+2/63)/e. On I_2 the ratio is at most 15/11 and far capture length at most 17/2. For k>=3 the first branch is positive. These checks account for every sign, including the negative remote holes.

The rational total is

\[
 \delta=M-A-B+L_1+L_2
 ={284799437\over162217694100}>0.00175.
\]

The tiny zero hole has normalized total length p_0/d_j<=1/4096 for j<=N-1, and half length at most 1/8192. Its negative contribution is bounded by

\[
 E_0={9\over64}(8192/8191)^2/4096,\qquad
 \delta-E_0>{1\over1000}.
 \tag{5}
\]

Therefore, for every 3<=j<=N-1,

\[
 g_G(0,d_j)\le-{1\over1000d_j},
 \qquad
 {1\over p_0}\sum_{j=1}^N|p_0p_jg_G(0,d_j)|
 \ge {N-3\over8000}.
 \tag{6}
\]

This divergence has already survived the full spatial integration.

## Transfer to actual uniform CZ blocks

Fix lambda=2^{20} and alpha=lambda-1. This is the Round 65 choice lambda=(alpha+1)H in dimension one. Define

\[
 \ell_i=p_i/(2\lambda),\qquad
 Q_i=[y_i,y_i+\ell_i),\qquad
 F_i=2\lambda\,1_{Q_i}.
 \tag{7}
\]

Each interval is a standard dyadic interval: its length is a power of two and its left endpoint is aligned. Its density is 2lambda, and its dyadic parent has density exactly lambda, which is a tie and is not selected under the strict stopping condition. Larger ancestors containing only one atom have density at most lambda; an interval containing at least two atoms has mass/span<1/2 by the preceding estimates. Thus the Q_i are exactly the maximal dyadic intervals of density greater than lambda. Their target height is 2lambda, fixed independently of N.

We now control the actual block integral, rather than asserting that narrow smearing preserves it. Psi is continuous, piecewise inverse square, and every active source-pole distance is at least 1/(e+1)>4/15. Each inverse-square coefficient has absolute value at most 1/4. Consequently

\[
 \|\Psi\|_1<8,\qquad
 \|\Psi'\|_1\le225/16<15,\qquad
 \|t\Psi'\|_1\le465/32<15.
 \tag{8}
\]

One way to verify the last two constants is to extend each pole contribution to both rays with distance at least 4/15; for the pole at 1 use |t|<=|t-1|+1. Continuity at branch switches eliminates distributional jump terms.

For d=z-y>0 and t=(x-y)/d,

\[
 \partial_yJ=d^{-3}[2\Psi+(t-1)\Psi'],\qquad
 \partial_zJ=d^{-3}[-2\Psi-t\Psi'].
\]

Their spatial L1 norms are at most 46/d^2 and 31/d^2. Along the rectangular path from (0,d_j) to (y,z) in Q_0 x Q_j, the separation is at least d_j/2. Hence

\[
 \int_{\mathbb R}|J_{y,z}-J_{0,d_j}|
 \le {200(\ell_0+\ell_j)\over d_j^2}.
 \tag{9}
\]

The restriction to the fixed original G only decreases this absolute error. For j<=N-1,

\[
 { \ell_0+\ell_j\over d_j}
 ={p_0/d_j+1/8\over2\lambda}
 <{1\over8\lambda}.
\]

The error in (9) is at most 25/(lambda d_j)<1/(2000d_j), since 50000<2^{20}. The blocks have positive separation from the original G, and the off-diagonal pair separations are positive, so the source average and spacetime integral may be exchanged. Averaging (6) over Q_0 x Q_j gives

\[
 {\cal K}^{F}_{0j}\le-{p_0p_j\over2000d_j},
 \qquad
 {1\over p_0}\sum_j|{\cal K}^{F}_{0j}|
 \ge {N-3\over16000}.
 \tag{10}
\]

Thus (R) is false for fixed alpha=2^{20}-1, for actual uniform maximal CZ targets and the actual original cap set.

## What remains viable

The diverging row has p_0=2^{-N}/2048. Its lower bound contributes only O(N2^{-N}) to the total absolute Gram sum, so the example does not refute

\[
 \sum_{i,j}|{\cal K}_{ij}|\le C_n HW,
 \quad\hbox{or the weaker}\quad
 \sum_{i,j}{\cal K}_{ij}\le C_n HW.
 \tag{11}
\]

Neither inequality in (11) is proved here. A dimension-controlled normalized-Gram operator bound with genuinely suitable positive Schur weights would also suffice; the natural choice w_i=sqrt(p_i) is simply too strong. No depth-independent Carleson condition follows from disjointness of the source blocks.

There is in fact a rigorous operator bound for the actual fixed-height targets in this counterexample. Because their supports are disjoint,

\[
 \left\|\sum_i v_iF_i/\sqrt{p_i}\right\|_2^2
 =2\lambda\sum_i|v_i|^2.
\]

The retained general L2 square-energy theorem therefore gives

\[
 \|B\|_{\ell^2\to\ell^2}\le2\lambda\kappa_1
\]

after restriction to G. This constant is independent of N. Thus the failure of the natural-weight row test coexists with an actual bounded normalized Gram operator. Its dependence on lambda prevents this observation from closing the high-dimensional replacement route.

## Current skill and hypothesis ledger

I re-read the disk versions of F05, G01, and G02, including their method and cube-interface files. F05 requires both actual weighted absolute row and column margins; its PSD multiplier statement is different from a row Schur bound. G01 requires an actual packing-to-embedding bridge; G02 requires the prescribed outer geometry, size and parameter hypotheses. Neither bridge is supplied by the present source blocks. No external theorem from these packages is imported into the counterexample.

Entry SHA256:
F05: 9b61d3e4cb62f20394285d8b071cace85c44260f56329fdd5ec2b11066a52dc9
G01: a09c5ad3047b402a07c26651b8c79b42a46843228b48cc961956c76372bc0cd4
G02: 2d17a11f000d8016583ca4427a9a9099f5c37b9ec09286fb50d01c6aa848ec1d

## Reproduction guard

The code below uses only the Python standard library. The rational portion checks (4)--(10), all contiguous source blocks for N=4,...,20, dyadic alignment and parent ties. The float portion integrates the piecewise rational spatial kernel analytically and uses two Simpson meshes only for the source-coordinate average of actual alpha=3 uniform blocks. This last portion is a finite diagnostic, not interval arithmetic and not a proof that canonical alpha=3 fails. It avoids inverse-distance subtraction by using (b-a)/((a-pole)(b-pole)).

```python
from fractions import Fraction as F
import math
import json

def exact_guards():
    M=F(343,600)*F(256,289)/16
    A=F(3,170)
    B=F(9,64)*F(64,47)**2/16
    L1=F(4,255)-F(3,4)*(F(1,255)+F(1,63))
    L2=F(449,968)*F(4,289)/2
    delta=M-A-B+L1+L2
    E0=F(9,64)*F(8192,8191)**2/4096
    assert delta==F(284799437,162217694100)
    assert delta-E0>F(1,1000)
    assert F(17,15)<F(8,3)
    assert F(47,17)>F(11,4)
    assert F(15,7)<F(8,3)
    assert F(15,11)<F(8,3)
    assert F(225,16)<15 and F(465,32)<15
    assert F(25,2**20)<F(1,2000)
    checked=0
    lam=F(2**20)
    for N in range(4,21):
        ys=[F(0)]+[F(1,2**j) for j in range(1,N+1)]
        ps=[F(1,2**(N+11))]+[y/8 for y in ys[1:]]
        ordered=sorted(zip(ys,ps))
        for a in range(len(ordered)):
            mass=F(0)
            for b in range(a,len(ordered)):
                mass+=ordered[b][1]
                if b>a:
                    assert mass<=ordered[b][0]-ordered[a][0]
                checked+=1
        holes=sorted((y-p/2,y+p/2) for y,p in ordered)
        assert all(holes[i][1]<holes[i+1][0]
                   for i in range(len(holes)-1))
        for y,p in zip(ys,ps):
            ell=p/(2*lam)
            assert ell.numerator==1
            assert (y/ell).denominator==1
            parent=2*ell
            left=(y//parent)*parent
            captured=sum((w for z,w in zip(ys,ps)
                          if left<=z<left+parent),F(0))
            assert captured/parent==lam
            for j in range(1,N+1):
                if y==0 and j<=N-1:
                    assert (ell+ps[j]/(2*lam))/ys[j]<F(1,8)/lam
        for j in range(3,N):
            assert j-N<=-1 and j-1>=2
    return {"contiguous_blocks":checked,
            "delta_minus_zero_hole":str(delta-E0),
            "target_row_lower":"(N-3)/16000",
            "fixed_alpha":2**20-1}

def kernel_integral(y,z,a,b):
    if a>=b:
        return 0.0
    if y>z:
        y,z=z,y
    e=math.e
    d=z-y
    switches=[y-d/(e-1),y+d/(e+1),y+d/2,
              y+e*d/(e+1),y+e*d/(e-1)]
    cuts=[a]+[v for v in switches if a<v<b]+[b]
    pieces=[]
    for lo,hi in zip(cuts,cuts[1:]):
        mid=(lo+hi)/2
        near,far=sorted((y,z),key=lambda w:abs(mid-w))
        dn,df=abs(mid-near),abs(mid-far)
        first=df<=e*dn
        cf=(1-1/(2*e))/4 if first else -(e-1)**2/(8*e)
        value=cf*(hi-lo)/((lo-far)*(hi-far))
        if first:
            value-= (hi-lo)/(8*e*(lo-near)*(hi-near))
        pieces.append(value)
    return math.fsum(pieces)

def source_average(N,j,lam,ny,nz):
    dj=math.ldexp(1.0,-j)
    p0=math.ldexp(1.0,-N)/2048
    width0=p0/(2*lam*dj)
    width1=1/(16*lam)
    holes=[(-p0/(2*dj),p0/(2*dj))]
    holes += [(15*math.ldexp(1.0,k)/16,
               17*math.ldexp(1.0,k)/16)
              for k in range(j-N,j)]
    def sw(k,n):
        return 1 if k in (0,n) else (4 if k%2 else 2)
    vals=[]
    for iy in range(ny+1):
        y=width0*iy/ny
        for iz in range(nz+1):
            z=1+width1*iz/nz
            g=-math.fsum(kernel_integral(y,z,a,b) for a,b in holes)
            vals.append(sw(iy,ny)*sw(iz,nz)*g)
    return math.fsum(vals)/(9*ny*nz)/8

def diagnostics():
    results=[]
    max_gap=0.0
    for N in (8,16,32,64):
        coarse=math.fsum(abs(source_average(N,j,4,2,8))
                        for j in range(1,N+1))
        fine=math.fsum(abs(source_average(N,j,4,4,16))
                      for j in range(1,N+1))
        gap=abs(coarse-fine)
        max_gap=max(max_gap,gap)
        assert gap<2e-9
        results.append({"N":N,"offdiagonal_row":round(fine,12),
                        "mesh_difference":float(format(gap,'.4g'))})
    # Whole-line off-diagonal integral, truncated only outside two remote rays.
    # Each omitted ray has explicit inverse-square primitive.
    residuals=[]
    for y,z in ((0.0,1.0),(-3.0,0.25),(0.3,0.3001)):
        d=z-y
        lo=y-10*d
        hi=z+10*d
        cf=(1-1/(2*math.e))/4
        cn=-1/(8*math.e)
        tails=cf/(z-lo)+cn/(y-lo)+cf/(hi-y)+cn/(hi-z)
        residuals.append(abs(kernel_integral(y,z,lo,hi)+tails)*d)
    assert max(residuals)<2e-11
    return {"canonical_alpha_3_float_only":results,
            "max_mesh_difference":float(format(max_gap,'.6g')),
            "full_spatial_cancellation_residual":
                float(format(max(residuals),'.6g'))}

if __name__=='__main__':
    print(json.dumps({"exact":exact_guards(),"diagnostic":diagnostics()},
                     sort_keys=True,separators=(',',':')))
```

Actual replay: the exact portion checked 1751 contiguous blocks and all specified dyadic alignment/parent ties. The canonical alpha=3 diagnostic rows for N=8,16,32,64 were respectively 0.013534810278, 0.028627802686, 0.058896786523, and 0.119435081082; maximum two-mesh difference was 8.03265e-11. The whole-line cancellation residual was 3.1225e-17. An initial diagnostic used the remote negative branch in the far spatial tails and failed; it was corrected to the first branch shown in the final code, and the final replay passed. No interval certificate is claimed for the floating-point diagnostics.


# Round 67: actual record attribution on a true maximal band

The final computation tests complete-batch records of actual centered-cube averages for finite positive atomic sources. It finds that many genuine records can coexist with a fixed weak-band volume, and that a band dominated by multi-source, submajority winners can have very few records. Neither record counts nor the largest estimated source column closes the general weak-type budget. No dimension exponent was fitted, and this computation proves no uniform weak-type bound.

The frozen program is `record_probe.py`; its adjacent output is `record_results.json`. There are 92 rows and 295,936 receiver draws: 18 pilot rows / 9,216 draws, then 74 heldout rows / 286,720 draws. Full receiver coordinates, source coordinates and rational weights, thresholds, seeds, proposal branches, retained extremes, and near-gate points are stored. The computation uses full-space Lebesgue importance sampling, with no receiver box or scale grid.

## Definitions and attribution

Write the source as \(\mu=\sum_i p_i\delta_{y_i}\), \(W=\sum_i p_i\), and \(B_H=\{H<M\mu\le2H\}\). At a receiver, merge all equal actual arrival volumes \(v_j=(2\|x-y_i\|_\infty)^n\). A batch has mass \(\delta_j\), cumulative mass \(F_j\), density \(a_j=F_j/v_j\), and running record \(R_j=\max_{\ell\le j}a_\ell\). Define

\[
\Delta_j=(a_j-R_{j-1})_+,
\qquad \kappa_j=v_j\Delta_j/\delta_j.
\]

All source labels in a tied batch receive the same \(\kappa_j\); attribution is then weighted by their actual masses. This is a common record process of one source, not independently chosen source records. Between arrivals the cube average decreases, so these batches compute the all-scale maximum. The exact identities are \(0\le\kappa_j\le1\) and \(\sum_j\Delta_j=M\mu(x)\).

Clip the running record to \([H/2,H]\), and let \(\Delta_j^{\rm clip}\) be its increments. On \(B_H\), their sum is \(H/2\). The principal source loads are

\[
L_i^{\rm clip}=\int_{B_H}\frac{\kappa_i^{\rm clip}}{v_i}\,dx,
\qquad
L_i^*=\int_{B_H}\frac{\mathbf1_{\{y_i\in Q_*(x)\}}}{v_*(x)}\,dx,
\]

where \(Q_*\) is the smallest-volume cube attaining the actual maximum. Consequently

\[
\sum_i p_iL_i^{\rm clip}=H|B_H|/2,
\qquad
\sum_i p_iL_i^*=\int_{B_H}M\mu\,dx.
\]

The program checks these point identities and their sampled weighted sums. It also records the debt between consecutive physical batches,
\(\chi_j=(v_j/v_{j-1}-1)F_{j-1}/\delta_j\), with zero debt for the first batch, and checks \(\kappa_j\le(1-\chi_j)_+\). Clipped charge is split by current captured mass fraction: below one half, one half to three quarters, and at least three quarters. Counts and mass-weighted occupancy are secondary diagnostics, not replacements for the loads.

Winner categories are disjoint: a single distinct source site; a strict-majority winner on the single-site complement; and a multi-source winner with captured mass at most \(W/2\), including equality. This is a partition of the true maximizing cube on the weak band. It is different from Round 66's time-energy partition; no time-energy integral is computed here.

## Registered scope and proposal change

Heldout draws comprise:

| Scope | Rows | Draws |
|---|---:|---:|
| One-dimensional midpoint grids, \(N=16,64,256\), \(H=1/4,2\), two seeds of 8,192 | 12 | 98,304 |
| Midpoint grid \(N=1024,H=1/4\), two seeds of 4,096 | 2 | 8,192 |
| Equal/unequal nested sources, \(n=1,4,16\), \(N=16,64\), two seeds of 2,048 | 24 | 49,152 |
| Actual common-face line sources, \(n=2,4,8,16\), \(N=16,64\), two seeds of 2,048 | 16 | 32,768 |
| Four frozen Round 65 sources, two seeds of 4,096 | 8 | 32,768 |
| Tiny source inside nested sources, \(n=1,4,N=16\), masses \(2^{-8},2^{-16}\), two seeds of 4,096 | 8 | 32,768 |
| Tiny isolated one-dimensional source control, two seeds of 8,192 | 2 | 16,384 |
| Single atom in dimensions 1 and 16, 8,192 each | 2 | 16,384 |

Dimension and source count are varied separately. The Round 65 geometries retain their historical selection bias; this round uses fresh receiver seeds for them. Pilot results use a different proposal and are explicitly labeled. They are not pooled into the heldout estimates.

For a center \(y_i\), cube-cone radial volume \(v=(2\|x-y_i\|_\infty)^n\), and scale \(b\), use the normalized density

\[
q_b(v)=\begin{cases}(2b)^{-1},&v\le b,\\b/(2v^2),&v>b.\end{cases}
\]

Uniform cube-cone directions give \(dx=dv\,d\sigma\); the two branches each integrate to one half. Sampling chooses either \(v=bU\) or \(b/U\) with equal probability. A machine zero for \(U\) is replaced by the next positive float.

Let \(V=W/(2H)\), \(a_i=p_i/W\), and \(\tau_i=v_i/V\). The pilot chooses half global-scale centers with probabilities \(a_i\), and half individual-scale \(a_iV\) centers with probabilities \(a_i\). Its dimensionless density is

\[
q_{\rm base}=\tfrac14\sum_i a_i\min(1,\tau_i^{-2})+
\tfrac14\sum_i\min(1,(a_i/\tau_i)^2).
\]

The final proposal chooses one quarter global weighted centers, one quarter individual weighted centers, and one half individual centers chosen uniformly among distinct sites. Its complete density is

\[
q_{\rm core}=\tfrac12q_{\rm base}+
\frac1{4N}\sum_i a_i^{-1}\min(1,(a_i/\tau_i)^2),
\qquad q(x)=(2H/W)q_{\rm core}(x).
\]

Every component is evaluated at every receiver, including receivers outside the band. Division by the sampled component alone would be wrong. The uniform-site component was added to give tiny-mass source columns direct sampling opportunities; improved precision is measured rather than assumed.

On the band, \(\tau_i\ge a_i\). Nonzero clipped attribution has \(\tau_i<4\), and the maximizing cube has \(\tau_*<2\). Thus the final normalized weak score is bounded by \(16N\), clipped column score by \(16N/a_i\), and optimal column score by \(8N/a_i\). The pilot bounds are also stored. The individual analytic clipped-load bound is \(L_i^{\rm clip}\le\log(4W/p_i)\); its mass dependence is retained and gives no uniform column estimate.

Each JSON summary contains its mean, sample standard error, observed maximum, proved ideal score envelope, and formal two-sided 95% Hoeffding radius \(B\sqrt{\log40/(2S)}\). This is an ideal independent-sampling, per-summary statement, not a simultaneous confidence guarantee or a certificate for machine implementation error. Heldout weak-score SEs range from 0.001720 to 0.048267; formal Hoeffding radii range from 0.240081 to 347.674 and are generally uninformative. Estimated ratios and maxima over columns are not assigned certified confidence intervals.

## Findings and exact family-specific calibrations

For midpoint grids \(y_j=(j+1/2)/N-1/2\), masses \(1/N\), and \(H=1/4\), the two-seed mean of \(H|B_H|/W\), with the SE of that average, is:

| \(N\) | Weak-band estimate | Actual-record average | Clipped-record average | Clipped charge below half mass |
|---:|---:|---:|---:|---:|
| 16 | 0.506095 ± 0.010170 | 16 | 6.234 | 0.751 |
| 64 | 0.508815 ± 0.011320 | 64 | 22.386 | 0.793 |
| 256 | 0.494903 ± 0.011642 | 256 | 86.726 | 0.806 |
| 1024 | 0.521822 ± 0.017194 | 1024 | 353.369 | 0.800 |

There is an exact explanation. The right exterior band is
\([1/2+1/(2N),\,3/2+1/(2N))\), with its left reflection. All \(N\) arrival densities increase there, outside null boundary equalities, and the full-source cube wins. The total band length is 2, so \(H|B_H|=1/2\) and the record count is exactly \(N\) almost everywhere on the band. This is a direct obstruction to treating record count as an affordable fee. It supplies no obstruction to the weighted clipped identity, whose total is fixed at \(1/4\).

At \(H=2\), a cube containing \(k\ge2\) grid sites has length at least \((k-1)/N\), so its average is at most \(k/(k-1)\le2\). Hence \(\{2<M\le4\}\) consists of disjoint nearest-atom annuli \(p/4\le v<p/2\), \(p=1/N\). Every band receiver has one record and a single-site winner. Exactly

\[
H|B_H|=1/2,\qquad L_i^{\rm clip}=1/4,\qquad L_i^*=\log2.
\]

The largest estimated clipped column reaches about 0.683 for \(N=256\), although every true column is exactly 0.25. Selecting a maximum among many noisy columns creates an apparent rise. This calibration prevents interpreting that statistic as true column growth. Single-atom cases in dimensions 1 and 16 independently reproduce the same exact references: weak score integral \(1/2\), clipped load \(1/4\), and optimal load \(\log2\); sampled weak means are 0.496513 and 0.515151.

For the actual common-face source in \(n=16,N=64\), the two heldout weak estimates are 0.537943 ± 0.046885 and 0.500055 ± 0.044547. The multi-submajority winner component accounts for 99.72% and 100% of those estimates; strict-majority contribution is zero observed. Yet average record counts are only about 1.06, and clipped counts about 1.00. A geometrically relevant residual band can therefore be sampled without a large record count. This finite example does not establish a uniform residual-band bound.

Equal deeply nested \(N=64\) sources have about 52–57 records and 20–23 clipped records; unequal nested sources have about 52–55 records but only about 6 clipped records. Their sampled bands are mostly strict-majority winners. Tiny sources inside nested configurations receive far less clipped load than optimal-cube load in these cases. For mass \(2^{-16}\), no nonzero clipped load was observed despite roughly 129–142 direct center draws per row. That is a sampling observation, not an exact zero or a general column theorem. The isolated tiny-source control instead has nonzero clipped-load estimates 0.328789 ± 0.039838 and 0.255094 ± 0.033503, with 79 and 67 nonzero draws. Common records can redistribute attribution, but these tests do not prove a uniform bound on individual columns.

Frozen Round 65 sources give differing winner decompositions: the perturbed \(n=4,N=16\) source has residual weak components about 0.042–0.065, while its matched vertex control has about 0–0.0013; the retained \(n=16,N=64\) candidate has about 0.050–0.060. Most of their sampled band volume is single-winner volume. These are heldout observations at fixed, previously selected geometries, not new optimization certificates.

## Precision audit and limitations

Near floating log-distance ties trigger exact binary-integer coordinate differences and actual L-infinity distance ordering. Complete physical batches are reconstructed before cumulative-mass attribution. Across all rows, 61,468 receivers used this path, correcting 195,907 falsely equal log-distance boundaries. Near record equality, clipping thresholds or band gates, and in very unequal sources, the record decisions are recomputed using rational volumes and exact cumulative masses; 59,392 receivers used that path.

Five controlled geometries cover deep near-ties, unequal weights, positive-volume common-face ties, clipping-boundary equality, and an equal-density peak with the minimal-volume winner convention. In addition, each heldout row retains a maximum weak score and an extreme in its largest estimated clipped column: 148 actual extremes. Both sides of both band gates are retained per heldout row: 296 closest-gate points. These guards use exact Fraction geometry for ordering, records, gate classification, debt and weighted point identities; full-mixture density and score values are compared at nearest-rounded Decimal precisions 80 and 120.

All retained classifications and record counts agree with the rational checks. Maximum relative discrepancies are \(3.27\times10^{-15}\) for full density, \(7.75\times10^{-13}\) for clipped scores, and \(2.74\times10^{-15}\) for optimal scores. The largest 80/120-digit relative density change is \(3.37\times10^{-79}\). Maximum aggregate clipped/optimal weighted-identity residuals are \(1.39\times10^{-16}\) and \(6.67\times10^{-16}\); the maximum sampled floating debt-inequality residual is \(3.60\times10^{-13}\). The minimum retained gate log-margin is \(7.02\times10^{-7}\).

Failed development checks were corrected before the frozen run: unequal-weight cancellation required rational record recomputation; an absolute record-sum tolerance outside the band required relative scaling; an exact clipping-boundary tie required rational threshold decisions; and a band-only lower-volume assertion was incorrectly applied to an off-band retained gate point. Sources, final seeds and registered draw counts were kept fixed. These are implementation corrections, not mathematical counterexamples.

Current L01/L02/L03/H05 skill entries and their relevant method/interface boundaries were reread. Actual positive sources and strict gates are retained. Fraction checks certify the stated finite point decisions; nearest-rounded Decimal agreement is not an outward interval certificate. No general interval API, all-receiver floating classification, unbiased continuum machine sampler, or continuous-space integral is certified by these checks. No external paper theorem is imported through a skill name or evidence index. The finite observations cannot establish a worst-source upper bound or a dimension growth law.

## Reproduction and freeze

Run without arguments:

```sh
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 -B /Users/zhengzhihao/Desktop/T/output/centered_cube_round067_20261011/record_probe.py
```

The script is standalone and writes `record_results.json` beside itself; it has no previous-round runtime import. Python 3.12.14 / NumPy 2.3.5 were used, with BLAS thread counts set to one by the program. The final local run took 38.7985 seconds. The parent independently replayed the full program in a temporary directory: exit 0, 38.7688 seconds, byte-identical JSON. There is no live computation session. Runtime is excluded from the serialized output.

Frozen SHA-256:

- `record_probe.py`: `055eb51a6f1b5d53f59b2cd3f78ce2abc7d992567c97943dc678b229642a914c`
- `record_results.json`: `ca12934fc5675ead12275e2a45184c4b5068f765b4bf50a6f6d16645f9ccdab1`

The program and data are frozen; no further sampling or changes are planned.


## Independent verification receipt

```json
{
  "corrected_preliminary_diagnostics": [
    {
      "description": "Initial full-spatial cancellation guard used the remote negative time-kernel branch in far spatial tails. Replaced with correct first-branch far/near primitives; finite-hole proof unchanged.",
      "failed_run": {
        "exit_code": 1,
        "guard_sha256": "93fe30486e65ae018a31013edf42393f7954e2c819cd3780c7de366c9b89459f",
        "replay_directory": "/var/folders/lq/2c4qbz2n0354_tnttkv_qsz00000gn/T/round067-cross-kqj_ht80",
        "stderr": "Traceback (most recent call last):\n  File \"/var/folders/lq/2c4qbz2n0354_tnttkv_qsz00000gn/T/round067-cross-kqj_ht80/guard.py\", line 129, in <module>\n    print(json.dumps({\"exact\":exact_guards(),\"diagnostic\":diagnostics()},\n                                                          ~~~~~~~~~~~^^\n  File \"/var/folders/lq/2c4qbz2n0354_tnttkv_qsz00000gn/T/round067-cross-kqj_ht80/guard.py\", line 122, in diagnostics\n    assert max(residuals)<2e-11\n           ^^^^^^^^^^^^^^^^^^^^\nAssertionError\n",
        "stdout": ""
      }
    }
  ],
  "embedded": {
    "integrated_cross": {
      "exit_code": 0,
      "guard_sha256": "052d292f1a14b37bdebfb1f8d6a1fc74c3d51b8dff3fbd98d0c08abbcf102ef0",
      "replay_directory": "/var/folders/lq/2c4qbz2n0354_tnttkv_qsz00000gn/T/round067-cross-final-magt2crd",
      "runtime_seconds": 0.49234699999942677,
      "source_sha256": "30fda2d8bea2ffe6aa10afafa6c7e940f8f52b8b3df7ae070917cfdfbe434f66",
      "stderr": "",
      "stdout": "{\"diagnostic\":{\"canonical_alpha_3_float_only\":[{\"N\":8,\"mesh_difference\":8.856e-12,\"offdiagonal_row\":0.013534810278},{\"N\":16,\"mesh_difference\":1.907e-11,\"offdiagonal_row\":0.028627802686},{\"N\":32,\"mesh_difference\":3.949e-11,\"offdiagonal_row\":0.058896786523},{\"N\":64,\"mesh_difference\":8.033e-11,\"offdiagonal_row\":0.119435081082}],\"full_spatial_cancellation_residual\":3.1225e-17,\"max_mesh_difference\":8.03265e-11},\"exact\":{\"contiguous_blocks\":1751,\"delta_minus_zero_hole\":\"18734151248526797/10883587559268062100\",\"fixed_alpha\":1048575,\"target_row_lower\":\"(N-3)/16000\"}}\n"
    },
    "stopped_occupation": {
      "exit_code": 0,
      "guard_sha256": "0c83ef3eee1eca44556a5efe67da874eb9ddb3a5e575ee4fcdfef8b3d2db842d",
      "replay_directory": "/var/folders/lq/2c4qbz2n0354_tnttkv_qsz00000gn/T/round067-guard-obtm8bb_",
      "runtime_seconds": 0.2441296670003794,
      "source_sha256": "e606056d856162533fab961a52c00bd1a5a36cbc559a9dbeee3d201d088940f0",
      "stderr": "",
      "stdout": "stageA exact physical/group/band checks: 10120 6060 131\nstageA exact majority receiver-pair checks: 76\nstageB exact one-atom clipped-load checks: 5\nstageC exact record-count/clip-count/endpoint checks: 6\nstageD max Decimal entropy-cost refinement: 3.121172665399283737508400296E-79\nPASS: finite algebra and actual physical receivers; no spatial quadrature claim\n"
    }
  },
  "frozen_hashes": {
    "integrated_cross.md": "30fda2d8bea2ffe6aa10afafa6c7e940f8f52b8b3df7ae070917cfdfbe434f66",
    "integrated_cross.tex.txt": "52d86102d88f0de8dfd0501892d5d0441b0db3239ceedf520758be38013fdd77",
    "record_numeric.md": "bb4a8cb2dbf4f7fb47ab5cc6b03a4a36f76b82df9da9ec7e62baaac0e6133173",
    "record_probe.py": "055eb51a6f1b5d53f59b2cd3f78ce2abc7d992567c97943dc678b229642a914c",
    "record_results.json": "ca12934fc5675ead12275e2a45184c4b5068f765b4bf50a6f6d16645f9ccdab1",
    "stopped_occupation.md": "e606056d856162533fab961a52c00bd1a5a36cbc559a9dbeee3d201d088940f0",
    "stopped_occupation.tex.txt": "96e35e35131b0131146ad8a7f9f6c2d0c7a66dc322db314876626b1774f03f5c"
  },
  "main": {
    "exit_code": 0,
    "replay_directory": "/var/folders/lq/2c4qbz2n0354_tnttkv_qsz00000gn/T/round067-main-replay-qoa550m7",
    "result_byte_identical": true,
    "runtime_seconds": 38.768840582997655,
    "script_sha256": "055eb51a6f1b5d53f59b2cd3f78ce2abc7d992567c97943dc678b229642a914c",
    "stderr": ""
  },
  "proof_review": {
    "integrated_cross": "Full Markdown, guard and TeX reviewed; rational hole constants, all negative holes, dyadic parent ties, L1 location derivative bounds, fixed-alpha transfer, normalized operator bound and canonical-alpha scope checked. Initial incorrect far-tail diagnostic corrected, failed and successful runs retained.",
    "record_numeric": "Full report reviewed; exact low-H grid band and high-H per-column calibrations checked; selected noisy maxima are not true column growth; sampling and finite arithmetic evidence boundaries retained.",
    "stopped_occupation": "Full Markdown, guard and TeX reviewed; decay deficit, finite terminal term, true threshold hazard, two winner branches and zero-loss atomic-to-L1 return checked. Corrected radius convention in lattice count (d>h)."
  },
  "skill_reload": {
    "bytes": 277108,
    "changed_entries": [],
    "checked_at": "2026-10-11T05:21:44.074571+08:00",
    "count": 64,
    "direct_reference_count": 437,
    "manifest_sha256": "5f3396f9ef9eb515b6edf173d8fb5dd465896ada5eb54e16a4e0b031ba1a60e4",
    "missing_references": [],
    "resolver_checks": [
      {
        "args": [
          "python3",
          "/Users/zhengzhihao/Desktop/T/\u6570\u5b66\u5de5\u517764\u9879_\u5b8c\u6574\u9a8c\u6536\u63d0\u5347_20261007/audit_current/delivery/resolve_evidence.py",
          "--root-id",
          "math64-20261007",
          "--registry",
          "/Users/zhengzhihao/.codex/math-skill-evidence-roots.json",
          "--artifact-path",
          "audit_current/e/claims.json"
        ],
        "exit_code": 0,
        "stderr": "",
        "stdout": "{\"status\": \"PASS\", \"artifact_path\": \"audit_current/e/claims.json\", \"resolved_path\": \"/Users/zhengzhihao/Desktop/T/\u6570\u5b66\u5de5\u517764\u9879_\u5b8c\u6574\u9a8c\u6536\u63d0\u5347_20261007/audit_current/e/claims.json\", \"sha256\": \"300c93e237f7e2b885dc1e468d12190bca87ebec0ffe88ab93a4715d49fc22fd\", \"sha256_verified\": true}\n"
      },
      {
        "args": [
          "python3",
          "/Users/zhengzhihao/Desktop/T/\u6570\u5b66\u5de5\u517764\u9879_\u5b8c\u6574\u9a8c\u6536\u63d0\u5347_20261007/audit_current/delivery/resolve_evidence.py",
          "--root-id",
          "math64-20261007",
          "--registry",
          "/Users/zhengzhihao/.codex/math-skill-evidence-roots.json",
          "--skill-dir",
          "/Users/zhengzhihao/.codex/skills/math-e01-occupation-measure-flow-lp",
          "--evidence-id",
          "E1970",
          "--verify-sha256"
        ],
        "exit_code": 0,
        "stderr": "",
        "stdout": "{\"status\": \"PASS\", \"evidence_id\": \"E1970\", \"paper_id\": \"P-aac215965bebc368\", \"portable_path\": \"papers/P-aac215965bebc368/paper.pdf\", \"resolved_path\": \"/Users/zhengzhihao/Desktop/T/\u6570\u5b66\u5de5\u517764\u9879_\u5b8c\u6574\u9a8c\u6536\u63d0\u5347_20261007/evidence/papers/P-aac215965bebc368/paper.pdf\", \"expected_sha256\": \"aac215965bebc368d318d664d0723c914a3706ae3eb805d988c4ece77289ed37\", \"expected_sha256_source\": \"status_annotation\", \"verified_sha256\": \"aac215965bebc368d318d664d0723c914a3706ae3eb805d988c4ece77289ed37\"}\n"
      }
    ]
  }
}
```
