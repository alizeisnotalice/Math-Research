# R226：当前共同来源、cut继承与真正可交换的核

**范围。** 本稿核实当前 R215→R225 祖链的真实软源是 R113 耦合构造的 `β=β^c`，因而这条同构造链确有 `ν≤β`；这不是给 R112 任意独立软余源添加新假设。共同 cut 承载、硬 rank 和原低邻域接收门亦保留。固定 `(ω,V,j,t)` 的未归一来源核确实对称，但实际 heavy/high/history 与归一分母不对称。下文给能直接插入当前 `B_d` 的来源分解和带真实转置费用的交换恒等式；未得到新的根阶付款。按父级最新限域，不开展含细格体积倒数的弱价格。

## SG1 准确来源链与可用门

以下行号指本机冻结原文，不将同名的独立流与耦合流混用。

| 原文定位 | 当前可用内容 |
|---|---|
| [R112 proof.tex.txt:871–885](/Users/zhengzhihao/Desktop/T/output/centered_cube_round112_20261014/proof.tex.txt:871)，J25–26 | 独立软网络的余源 `ζα` 由菜单 cut-piece 交 `Sα` 承载。未缩放 cut 计划有 `ηα^A ↔ τr 1Nα du`，`ηα^A≤ηα`，`τr|Nα|=||ηα^A||`。这是已提取计划的目标密度帽，不是剩余源密度帽。 |
| [R112:928–946](/Users/zhengzhihao/Desktop/T/output/centered_cube_round112_20261014/proof.tex.txt:928)，J29–30 | 当前正子核显式乘 `1Hα^c`，软支配换为 `q^−1p ζα`。hard ν 的原身份/rank保留；`H_{r,a,V}(Sα)⊂Nα`，软侧不能换成硬低叶均值。 |
| [R113 proof.tex.txt:192–201](/Users/zhengzhihao/Desktop/T/output/centered_cube_round113_20261014/proof.tex.txt:192)，B17 | `Sσ⊂Sα`、`Nσ⊂Nα`。两端都由 Sα 承载；软/硬低邻域不是两个独立因子。该早期独立版本本身仍不保证 ν≤β。 |
| [R113:572–611](/Users/zhengzhihao/Desktop/T/output/centered_cube_round113_20261014/proof.tex.txt:572)，C9 后与 I1–3 | 明确重选耦合软流 `β^c=α−ηα^c`，hard ν不变，`ν≤ζσ*≤β^c≤α`。R112 J25–26/J28–29、soft/hard cuts、低 Nα占比、hard rank都保留。原R112 J27逐点严格正提取不保留，不能混入。 |
| [R114 ratio_settlement.md:9](/Users/zhengzhihao/Desktop/T/output/centered_cube_round114_20261014/ratio_settlement.md:9) 与 [122–145行](/Users/zhengzhihao/Desktop/T/output/centered_cube_round114_20261014/ratio_settlement.md:122) | 输入严格为该 `Γ_F^c,T_F^c,β=β^c`，不是任意早期独立流；新余项保旧I3、ν≤β、rank和全部原门，只再删已付正子交通。 |
| [R116 astra_first.md:96](/Users/zhengzhihao/Desktop/T/output/centered_cube_round116_20261014/astra_first.md:96)、[147行](/Users/zhengzhihao/Desktop/T/output/centered_cube_round116_20261014/astra_first.md:147) | 同一实际 T_small 明文使用 `ν≤β≤f dx`；规范 RN 因子 a∈[0,1]保全部联合门。 |
| [R117 joint_geometry.md:9–23](/Users/zhengzhihao/Desktop/T/output/centered_cube_round117_20261014/joint_geometry.md:9)、[47–62行](/Users/zhengzhihao/Desktop/T/output/centered_cube_round117_20261014/joint_geometry.md:47) | 沿 R114 构造原 Z、w、e、Π；高 pe 正子核继承 FULL/FIRST/CP/GP/deep、种子及新旧删除门。辅助 v/u 有 source-born 支持，不能继承原 hard z 的接收捕获。 |
| [R215 proof.tex.txt:131–139](/Users/zhengzhihao/Desktop/T/output/centered_cube_round215_20261016_final_checkpoint/proof.tex.txt:131)、[211–226行](/Users/zhengzhihao/Desktop/T/output/centered_cube_round215_20261016_final_checkpoint/proof.tex.txt:211) | 原 Π 仍为 `1Z w ν/e`。W4 是已用 hard 帽与正放松的上界；不能把 W4 的扩大 receiver/门重新称 FULL 或凭同名 β授新资格。R224/TR1 与R225/JG1–7仍针对原实际正子交通并保实际唯一叶/j与全部正门。 |

因此在本条实际祖链，每个原终端叶有预冻结测度

\[
 0\le\nu_V\le\beta_V=\beta_V^c\le\alpha_V\le f\,dx,
 \quad\beta_V(V\setminus S_{\alpha,V})=0,
 \quad\nu_V(V\setminus S_{\sigma,V})=0,\quad S_{\sigma,V}\subset S_{\alpha,V}. \tag{SG1}
\]

`ν≤β`可在这份构造上使用；反向`β≤ν`、soft rank、soft低叶均值、两源后验相同均不可用。两源绝对连续不提供维数/输入一致的点态密度帽。

## SG2 低邻域、尺度与rank的精确含义

原固定物理窗为 `a≤L(x),R(x)≤b≤2a`，a是窗下端，不要求恰等b/2。原细格全边长为 `d_f=a/n`，pieces为 `C∩V`。按 [R109 proof.tex.txt:199–209](/Users/zhengzhihao/Desktop/T/output/centered_cube_round109_20261013/proof.tex.txt:199)，n≥512，

\[
 r_n=\max\{1,\lfloor\log n/\log729\rfloor\},\quad
 \ell_n=1+\log n,\quad\tau_r=\ell_n\lambda/\sqrt n.
\]

[R109:298–318](/Users/zhengzhihao/Desktop/T/output/centered_cube_round109_20261013/proof.tex.txt:298) 给

\[
 \mathcal H_{r,a,V}(S)=\{u\in V:\exists y\in S,
   \#\{i:u_i\ne y_i\}\le r,\ \|u-y\|_\infty\le a\},
 \qquad\mathcal H_{r_n,a,V}(S_{\alpha,V})\subset N_{\alpha,V}. \tag{SG2}
\]

这只移动r_n个坐标，不是完整n维halo。当前实际receiver还保

\[
 Q_x=Q_{R(x)}(x)\subset V,\qquad
 |N_{\alpha,V}\cap Q_x|<R(x)^n/\ell_n. \tag{SG3}
\]

软高邻域整行此前价格是 `4C2² ell_n sqrt(n) W_{ηα^c}`，与软提取价格相加，不能重领。硬Nσ⊂Nα使其低占比随之成立，不能再相乘得ell_n^−2。

SG3是x,V门，故在原a的RN表示外可精确保留：原a在其补集为零。如果当前Ω按R225 JG2所声明保全部history和原实际receiver域，则Ω=0于SG3补集；如果实际使用的是将a/η删为1后扩大receiver的上界Ω_enl，则只能给
`Ω_ret=1_{SG3}Ω_enl`保此门，不能把Ω_enl本身冒称有SG3。类似地，未归一ν的source-born cut支持始终保留，但原hard z的capture不能授给辅助v/u。

令 `mV=νV(V)`、`MV=αV(V)`。原已付相对小尾叶后，在当前非零叶 `mV≤MV<sqrt(n)mV`；原top-k给

\[
 \theta_V:=\sup_C\frac{\nu_V(C\cap V)}{m_V}
 \le\frac{m_V^{before}}{(k+1)m_V}
 \le\frac{M_V}{(k+1)m_V}<\frac{\sqrt n}{k+1}. \tag{SG4}
\]

准确出处为 [R107 proof.md:1243–1266](/Users/zhengzhihao/Desktop/T/output/centered_cube_round107_20261013/proof.md:1243)。分母是当前叶硬尾总质量，C是原空间细格，不是FULL parent或cut块。该格质量限制不给格内密度帽，也不给β同样rank。

SG1与该同叶质量比较另给一个真实有限来源后果：设 `ρV=βV−νV≥0`（这是excess源，区别原capture余权ρ0），则

\[
 \beta_V=\nu_V+\rho_V,\qquad
 \|\rho_V\|=\|\beta_V\|-m_V\le M_V-m_V<(\sqrt n-1)m_V. \tag{SG5}
\]

这是预冻结源总质量，不能推成actual `p_yβ/q` 后验中共有部分比例≥1/√n。对空间响应加权后，p_y可能对两部分给完全不同权；本稿不授权该后验下界。

## SG3 Z的对称性：共同partition、fallback与距离门

固定同一 `(ω,V,j,t)`，在原有限森林上使用同一合格硬质量h和同一阈值

\[
 H_j(t)=q\max\{t^n,\sqrt n\,c_{j+1}^nt^n,
                       \sqrt n(t^2/b)^n\}.
\]

[R114:28–43](/Users/zhengzhihao/Desktop/T/output/centered_cube_round114_20261014/ratio_settlement.md:28) 定义A_{j,t}(y)为含y的最粗 `h(A)≤H_j(t)` 块；沿路径无light块则取原最细格。所有最大light块两两不交；不在这些块的点落在各自heavy最细fallback格。这些块合成同一顶格内的共同partition `P_{j,t}`。因此y,v同顶格时

\[
 v\in A_{j,t}(y)\iff A_{j,t}(v)=A_{j,t}(y)
 \iff y\in A_{j,t}(v). \tag{SG6}
\]

最细重fallback不能省略或换成逐y任意中间块；共同闭阈值 `h≤H` 与半开树格处理所有ties，原右连续版本仍成立。不同顶格双方都不被接受。

原 [R113:68–76](/Users/zhengzhihao/Desktop/T/output/centered_cube_round113_20261014/proof.tex.txt:68) 距离门是

\[
 D_V(y)=V\cap\{v:\|v-y\|_1\le17na\}
              \cap\{v:\|v-y\|_\infty\le b(5\log n+1/2)\}.
\]

于是对y,v∈V，

\[
 Z_{j,t}(y,v):=1_{D_V(y)}(v)1_{T_0(y)}(v)1_{v\notin A_{j,t}(y)}
       =Z_{j,t}(v,y). \tag{SG7}
\]

`w_{j,t}(y,v)=∏i min{1,b C(|y_i−v_i|/b)/(c_jt)}`亦对称。故未归一核

\[
 \mathsf K_{j,t}(y,v)=Z_{j,t}(y,v)w_{j,t}(y,v)
          =\mathsf K_{j,t}(v,y),\qquad
 e_t(y)=\int\mathsf K_{j,t}(y,v)\nu_V(dv). \tag{SG8}
\]

在e_t>0处Π_y,t(dv)=K_t(y,v)ν(dv)/e_t(y)；e_t=0行取零。由此有真实详细平衡

\[
 e_t(y)\nu_V(dy)\Pi_{y,t}(dv)
 =\mathsf K_t(y,v)\nu_V(dy)\nu_V(dv)
 =e_t(v)\nu_V(dv)\Pi_{v,t}(dy). \tag{SG9}
\]

这是一条固定j,t的未筛核身份，不是说Π在ν底测度下对称。实际heavy区间I_{j,V,y}依y；`e_t(y)>ell q c_j^{-n/2}t^n`、high `p_y e_g(y)≥2Kq`、terminal good/bad、capture及其它η也一般不对称。若要在两个端点都调用Π，必须保各自有效行；一端有效另一端无效的部分是明确的one-sided余项，不能抹掉。e_t(v)=0时SG9右端也自然为零，但不因此给该v有效heavy资格。

## SG4 对当前B_d的合法来源分解和确切交换价

保R225 JG2/JG7所有原参数与共同终端窗 `I_d(x)=[g e^(−d/n),g]`，原J_far及过程有效性在η内置零。写

\[
 U_{x,t}(y,v)=1_{high,valid}(x,y)\int\eta(x,y,v,u,t)
                           \delta_{y,t}(v,u)\Pi_{y,t}(du),\quad 0\le U_{x,t}\le n,
\]

\[
 G_{a,x,t}(y,v)=1_{Z_t(y,v)}\frac{K_{a,x}(v)}{e_t(y)}U_{x,t}(y,v).
 \tag{SG10}
\]

零e或无效行直接定义为零，a=1,2为两actual移动腿。当前每腿B的精确积分就是

\[
 B_{a,d}=\mathbb E\sum_V\int_{E_{\omega,V}}dx\int_{I_d(x)}\frac{dt}{t}
              \iint G_{a,x,t}(y,v)\beta_V(dy)\nu_V(dv)
       =B^{shared}_{a,d}+B^{excess}_{a,d}, \tag{SG11}
\]

其中shared/excess准确将β替为ν/ρ，都是原非负source allocation。两Π的第二份及原score在U内，未重建；未消费负账仍原位一次。SG5给ρ总质量代价，但不能仅凭总质量比较消除source-dependent e_t或历史门。

由SG7，对任意有限非负截断、同一x,j,t，shared项有无附加假设的交换身份

\[
 \iint G(y,v)\nu(dy)\nu(dv)
 =\frac12\iint\frac{Z_t(y,v)}{w_t(y,v)}
       \left[\frac{K_{a,x}(v)U(y,v)}{e_t(y)}
            +\frac{K_{a,x}(y)U(v,y)}{e_t(v)}\right]
       w_t(y,v)\nu(dy)\nu(dv). \tag{SG12}
\]

各比值按SG10零行约定；实际w>0，分母w绝不删除。证明只把同一ν⊗ν交换y,v，保原gate的转置。SG12可以连同SG11直接插入B_d；这是当前真实共同来源结构，比任意不相关β/ν更强。

它也精确指出尚未授权的付款步骤：JG3的第二平方因子含 `1Z/e_t(y)`，已经没有v槽的w_t。故不能将SG12直接按SG9的Markov质量归一；需支付显示的 `1/w_t(y,v)`，以及实际 `e_t(y)^{-1}`/`e_t(v)^{-1}`、U和其转置的差异。U(v,y)的high/valid是转置后的真实门，不能改成U(y,v)；source交换后的另一Π以v为anchor，score的第三来源也随之改变。来源cut/低N和SG5没有自动给这些比值统一帽。

因此目前能够严格加入主攻的结构为：同构造β=ν+ρ、共同cut承载与实际低N、SG8–9的对称conductance、以及SG11–12的真实source allocation/交换价。没有证明全域B_d根阶预算；未授权的最早一步是把这个未归一对称核的平衡，误用为当前带receiver/high/history的 `β/e_t` 或 `Z/e_t` 核的免费容量。

## SG5 实际有限工具核验

本机Python `fractions.Fraction` 对8个叶的有限二叉树、11个共同阈值（含等号、全heavy fallback及全root-light），实际完成704项partition外关系对称断言、704项详细平衡断言、11项β=ν+ρ分解断言，1419项全部通过。距离门和权取显式对称有理数据。该检查只验证有限代数与endpoint实现；一般SG6–12由上文共同partition及测度证明，不以这些样本认证FULL或付款。
