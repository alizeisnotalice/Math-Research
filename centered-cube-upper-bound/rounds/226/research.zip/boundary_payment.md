# R226：保整段权变化的静态测试门与全时钟正交通付款

本稿证明一项覆盖全部实际尺度、软度与历史的原正子交通付款。它从原正母式出发，在辅助时钟积分中保留同一个静态测试门及整段权变化 D，使用权的总变差和原测试容量；不需要估计移动尺度列，也不使用任何负信用。对当前尚未付的正交通，

\[
 \boxed{\mathcal P_{\rm cur}[Q_x^*(v)\ge r p_y(x)D_{x,y}(v)]
       \le {16\Lambda\over3Kr}X.} \tag{BP0}
\]

其中 `D_{x,y}(v)=w_{a/c_j}(y,v)−w_g(y,v)∈[0,1]`。因此取 `r=16Λ/(3Kε_st)` 可支付独立的 `ε_st X`。此门包含不保 D 的静态门 `Q*≥rp`，并支付更多整段权变化较小的来源。这是原正量的新分配接口，不是整个中间硬层、`B_d` 或根阶总预算已付。其补域有真实的测试核下降关系；本稿保留共同来源交换后的实际权，未从下降关系推出有界拥塞。

## 1. 原量和一般静态门命题

沿 R224 `traffic_reentry.md` TR1–2、R225 `joint_geometry.md`，令 `X=λ|E|`、`Λ=128/119`、`3λ/4≤q≤λ`。`𝒫_cur` 表示已经乘 `2Λ` 的当前原正余量；它已经删除/分配此前支付的 FA、捕获、浮动带及终端 J 子交通。这里仅再把 `𝒫_cur` 作不交分配，不把此前删去的交通加回，也不复制存活或删除负信用。

固定实际 `(ω,V,x,j(x))`，保原 `a≤L,R≤b≤2a`、`g=√(LR)`、`s=s(x)`。原输入核为 `p_y=P_{s,L}(x−y)`，三个测试为

\[
 K_{1,x}(v)=P_{s,L}(x-v),\quad K_{2,x}(v)=P_{s,L^+}(x-v),\quad
 J_x(v)=P_{1,b}(x-v),\quad
 Q_x^*=(K_{1,x}+K_{2,x}+J_x)/3,
 \quad L^+=\min(b,\gamma L). \tag{BP1}
\]

它们依实际 x，**不依辅助 t**。原 FIRST 给

\[
 \int p_y\,\beta_V(dy)\le q,\qquad
 \int Q_x^*(v)\,\nu_V(dv)\le q. \tag{BP2}
\]

原 high 给 `p_y e_g(y)≥2Kq`；原合法 `t≤g` 上 `e_t(y)≥e_g(y)>0`。无效或零分母行始终置零。固定 `(ω,V,j,y)`，

\[
 W_t(y,v)=1_{Z_t(y)}(v)w_t(y,v),\quad
 w_t(y,v)=\prod_{i=1}^n\min(1,\alpha_i(y,v)/t),\quad
 \Pi_{y,t}(dv)=W_t(y,v)\nu_V(dv)/e_t(y).
 \tag{BP3}
\]

`v` 是原 terminal-good 槽，`u` 是 terminal-bad 槽；正 score 为
`δ_{y,t}(v,u)=[k_t(y,v)−k_t(y,u)]_+≤k_t(y,v)`。

**一般命题。** 在每个上述实际 receiver 行上，设可测非负 `T_x(v)` 不依辅助 t，且

\[
 \int T_x(v)\nu_V(dv)\le c_T q,\qquad c_T<\infty. \tag{BP4}
\]

允许 T 随全部实际物理参数及预冻结行参数变化；本命题要求所用容量在每个实际行成立。令 `D_{x,y}(v)=w_{a/c_j}(y,v)−w_g(y,v)`，它只依固定实际行及 v，不随积分变量 t 变化。取 `r>0` 和

\[
 A_r(x,y)=\{v:T_x(v)\ge r p_yD_{x,y}(v)\}. \tag{BP4a}
\]

D=0 行无需除法，依下一节权 FTC 其整个正 score 积分为零。则对原 current 交通乘这个门，有

\[
 \boxed{\mathcal P_{\rm cur}[A_r]\le {16\Lambda c_T\over3Kr}X.} \tag{BP5}
\]

量词包含任意原合法输入、全部实际 x 自适应 L/R/s、所有比例带、原删源路径、捕获/history、完整原远时钟及其任意正子集。本命题既不要求物理参数在 x 积分下固定，也不要求 `ν≤β`；不存在 soft 菜单、scale 菜单或终端时钟宽度费用。

## 2. 保静态门的权 FTC

固定 x、y、v，令 `l=τ_j=a/c_j`。对原非空时钟窗 `l≤t≤g`，w 是连续、分段绝对连续的非增函数，且在除有限阈值外

\[
 -{d\over d\log t}w_t(y,v)=k_t(y,v)w_t(y,v).
\]

因此

\[
 \int_l^g k_t(y,v)w_t(y,v){dt\over t}
 =w_l(y,v)-w_g(y,v)\le1. \tag{BP6}
\]

原实际 far 窗可能只是 `I_{j,V,y}∩[l,h]`，其中 `h≤g`。删源的 `1Z_t`、所有有效时钟和历史指示只使这个非负积分减小。BP6不将这些指示或 `Π_t` 视为 t 不变；它只对原显式乘积 w 求导，因而不遗漏删除原子，也无需给删除跳跃领取信用。

固定 high 行，在原两份后验上先对 bad 槽 u 用其子概率质量 `≤1`，再用 `e_t≥e_g`，得到

\[
\begin{aligned}
 &\int_{J_{far}}\iint 1_{A_r}(v)\,\eta_t(v,u)\,
       \delta_{y,t}(v,u)\,\Pi_{y,t}(dv)\Pi_{y,t}(du){dt\over t}\\
 &\quad\le {1\over e_g(y)}\int_{A_r}\nu_V(dv)
       \int_l^g k_t(y,v)w_t(y,v){dt\over t}\\
 &\quad= {1\over e_g(y)}\int_{A_r}
       [w_l(y,v)-w_g(y,v)]\nu_V(dv)\\
 &\quad\le {1\over r p_y e_g(y)}\int_{A_r}T_x(v)\nu_V(dv)
 \le {c_Tq\over r p_y e_g(y)}
 \le {c_T\over2Kr}. \tag{BP7}
\end{aligned}
\]

这里 `0≤η_t≤1` 可含全部剩余正门、任意已付项后的补权及原 capture；若还依 hard z，先逐 z 用同一非负上界。正是中间保留的 D 权差允许 BP4a 的更大门；没有把 D 先上放成1再要求 T≥rp。静态 A_r 可移到同一 v 的 FTC 外；一个任意逐 t 变化的测试门不能因此免费得到单个静态源集合的容量。D=0 时左边相应来源为零，不存在 0/0。

### 2a. 保原删源支持的版本及其实际适用范围

还可定义整个积分完成后的静态量

\[
 D_Z(x,y,v)=\int_l^g1_{Z_{j,t}(y)}(v)k_t(y,v)w_t(y,v){dt\over t}
 \le D_{x,y}(v). \tag{BP7a}
\]

BP7的第一步保 `1Z_t` 即得 `ℛ_A≤e_g(y)^{-1}∫_A D_Zν`。故把 BP4a 的 D 换成 D_Z，BP5同常数成立，D_Z=0 的行也无需除法。此处不使用任何 signed 删除负项；只是计算正交通已经具有的支持。

本轮 `source_geometry.md` 已核固定 j,t 的 Z/W对称；固定实际 x（故 l,g,j相同）后，D_Z关于 y,v对称。原有限森林使Z_t递减且仅有限跳。令 τ(y,v)为固定 pair 离开Z的时刻，未离开记∞；则按右连续版本，

\[
 D_Z(x,y,v)=1_{Z_l(y)}(v)
 [w_l(y,v)-w_{\min(g,\tau(y,v))}(y,v)]. \tag{BP7b}
\]

端点不影响 dt积分。若 `J_e(l,g;y)` 为 `(l,g]` 内删除时权质量之和（每次删除贡献 `∫_{Z_{t-}(y)\setminus Z_t(y)}w_t(y,v)ν(dv)`），则

\[
 \int D_Z(x,y,v)\nu(dv)
 =e_l(y)-e_g(y)-J_e(l,g;y)\ge0. \tag{BP7c}
\]

证明是逐常值Z时段对w使用BP6，再把有限端点望远镜求和；连续权变化与删除质量分别记账。这不是把 N_del 作为新增付款。

**实际原槽限制。** R223 `negative_contract.md` NC1精确定义 `S_g=Z_g\setminus D_g`。当前原正量的good来源 `v∈S_g⊂Z_g`，而所有积分 t≤g，故该 v在整个 `[l,g]` 都属于Z_t。于是

\[
 D_Z(x,y,v)=D_{x,y}(v)\quad\hbox{在当前原非零good槽上}. \tag{BP7d}
\]

因此D_Z门是一般扩大源行上的更强合法版本，但在当前原terminal-good交通上与D门相同。本稿不将两者差异再登记为原支付域的新增扩张；主成果仍是相对 `T≥rp` 保留D的BP4a。

## 3. 回代真实来源和接收积分

从原 RT1–2 母式而不是已经三腿上放的 TR1 再开始。保实际 receiver 域 `E_{ω,V}⊂E∩V`、唯一 j(x)、high 及本轮静态门；其余正门可在估计时上放。原 hard 来源满足

\[
 H_R(x):=\int h_R(x-z)\nu_V(dz)\le {16\over3}q.
\]

原 RN `a_ω∈[0,1]`。只用这一遍 hard 帽，原带 `2Λ` 的正量满足

\[
 \mathcal P_{\rm cur}[A_r]
 \le {32\Lambda\over3}\,
 \mathbb E\sum_V\int_{E_{\omega,V}}dx\int
       1_{high,valid}p_y\beta_V(dy)\,
       \mathcal R_{A_r}(x,y), \tag{BP8}
\]

其中行量 `ℛ` 是 BP7 左边，全部原时钟已在其中；若原门依 hard z，先取 `H_R^{-1}∫h_R·原正门·a_ω dν(z)` 的条件平均作为η（H_R=0行直接为零），它在[0,1]。原有更小正权不会使右边增加。BP7、同一实际 x 的 FIRST 以及不交叶/唯一 j 给

\[
 \mathcal P_{\rm cur}[A_r]
 \le {16\Lambda c_T\over3Kr}
 \mathbb E\sum_V\int_{E_{\omega,V}}q\,dx
 \le {16\Lambda c_T\over3Kr}\lambda|E|.
\]

这证明 BP5。没有用 `∫p_actual(x,y)dx=1`：实际 p 的尺度和软度随 x 变化时，该声明未获授权。这里只用它在同一 x 的原 FIRST。也没有把 hard z 计为辅助 v 或再用一次16/3帽。

取 `T=Q_x^*`、`c_T=1` 得 BP0。因为 D≤1，旧形式 `T≥rp` 是 BP4a 的子门，并有相同上界。取 `T=K1+K2`、`c_T=3` 得

\[
 \mathcal P_{\rm cur}[K1_v+K2_v\ge\tau p_yD_{x,y}(v)]
 \le {16\Lambda\over K\tau}X. \tag{BP9}
\]

由本轮另稿核实的**当前耦合构造** `ν≤β^c`，还可在该构造取 `T=K1`、`c_T=1`，因为 K1就是同一 FIRST 测试。BP0及BP9不依赖这项额外继承事实。

## 4. 与旧付款的区别和精确剩余

R119 `quantitative_future.md` FA9–11 支付的是逐 t 的动态门

\[
 \ell_t(v)={Q_x^*(v)\over p_y w_t(y,v)}\ge B_{FA}\delta_{y,t}(v,u).
 \tag{BP10}
\]

它要求 `δ_t w_t≤Q*/(B_FA p_y)`，其证明按该逐时门和 FIRST 测试支付整个时钟。BP0的静态门要求 `Q*/p_y≥rD`，不限制当时的 `δ_t w_t` 峰；故不能仅凭该静态条件把所有这些行宣称已在 BP10 内。相反，本稿用 `∫k_t w_t≤1`，并保 D，再给整个静态源集合一次测试容量。此前提出的 `δ≤τK(K1+K2)/p_y` 点时门可落入旧 FA，不能另登记为本轮新增付款。

R212及后续动态/浮动帽依固定 J_v 对 `p_y w_t` 或 `ρ0(w_t−h0)` 截断。BP0没有授予这些 J 门，也没有把其付款重复相加。本轮只声明：对已保全部旧补权的 `𝒫_cur`，BP0额外支付其与静态门的交；无需声称所有静态门点均未被旧门覆盖。本稿的历史比对限于上述准确公式，不宣称逐篇穷尽全部历史。

给独立误差份额 `ε_st>0`，固定

\[
 r={16\Lambda\over3K\varepsilon_{st}},\qquad
 \mathcal P_{hiQ}=\mathcal P_{cur}[Q_v^*\ge r p_yD_{x,y}(v)],\qquad
 \mathcal P_{loQ}=\mathcal P_{cur}[Q_v^*<r p_yD_{x,y}(v)].
 \tag{BP11}
\]

两项对当前原正量不交且和等于它，`𝒫_hiQ≤ε_st X`。低门严格，且其非零来源必有 D>0；D=0 行进入高门但正量为零。原负项完整留给 `𝒫_loQ`，不能分别给两项各一份。

## 5. 低测试补域的真实下降与来源交换障碍

原 p_y=K1_y，所以 `p_y≤3Q_y^*`。在 BP11 的剩余非零行，原 good 槽 v 和 bad 槽 u 分别满足

\[
 Q_v^*<r p_yD_{x,y}(v)\le r p_y\le3rQ_y^*,\qquad
 Q_u^*<{p_y w_g(y,u)\over K}\le{p_y\over K}\le{3\over K}Q_y^*.
 \tag{BP12}
\]

若 `K>max(16Λ/ε_st,3)`，则两个比例均严格小于1。对固定实际 x，这确实是同一个可测势 `Q_x^*` 从中心 y 到两个目标的严格下降。Q*>0（J腿严格正），所以 logQ亦有相应固定下降幅度。这个结论不要求额外软度下界，不只是特殊硬极限；但势随实际 x 变化，不是跨全部 receiver 的单一预冻结势。

本轮 `source_geometry.md` 核实：当前祖链 `β=β^c=ν+ρ_exc`，`ρ_exc≥0`；固定 `(ω,V,j,t)` 的 `W_t(y,v)` 对称，conductance

\[
 d\mathsf C_t(y,v)=W_t(y,v)\nu(dy)\nu(dv)
 =e_t(y)\nu(dy)\Pi_{y,t}(dv)
\]

也对称。这里 ρ_exc 是来源余量，不是 capture 权。

为检查下降能否实际付款，把 BP8 中保低测试门的原正行写为

\[
 I_{x,t}^{shared}
 =\iint {p_y\over e_t(y)} F_{x,t}(y,v)\,d\mathsf C_t(y,v),\qquad
 F_{x,t}(y,v)=\int\Theta_{x,t}(y,v,u)
       [k_t(y,v)-k_t(y,u)]_+\Pi_{y,t}(du). \tag{BP13}
\]

Θ保全部实际 high、有效域、原good/bad、history、当前未付补权和 BP11低门；它可取 hard 条件平均，`0≤Θ≤1`。式子是在 hard 帽后的正上界中准确的双Π展开，不是对原负项的新权。`ρ_exc`部分还须另加把中心 `ν(dy)` 换为 `ρ_exc(dy)` 的同一实际式。

共同源交换给

\[
 I_{x,t}^{shared}
 ={1\over2}\iint\left[
 {p_y\over e_t(y)}F_{x,t}(y,v)
 +{p_v\over e_t(v)}F_{x,t}(v,y)\right]d\mathsf C_t(y,v). \tag{BP14}
\]

零分母无效行取零；交换后的第二Π以 v 为中心，score及所有门亦真正转置，不能仍用 y 的 high 资格。BP12使每个非零方向严格下行，因此互反方向不能同时成立；**这不控制边的总占用**。实际权是 `p_y/e_t(y)` 乘三来源 F，并非 stationary 测度中一个无权、固定可积势的差。详细平衡只允许 BP14 的原样交换，不允许删掉这两个实际权或把正部改成可望远镜的 signed 差。

例如令 `θ=3r<1`，BP12只能立即给

\[
 p_y1_{\{Q_v<\theta Q_y\}}
 \le {3\over1-\theta}(Q_y-Q_v)_+.
\]

代入 BP13后仍保 `e_t(y)^{-1}F(y,v)`。仅以 `F≤n`、Markov归一和 `∫Qν≤q` 估计，得到的是每个实际 x,t至多 `3nq/(1−θ)`；整窗至多另乘 `log2`。这个直接步骤只有线性 n 的 receiver 价格，不能成为所需根阶来源预算。源交换也不处理 `ρ_exc`槽；`ν≤β`不能反向把它删掉。

因此本稿没有证明 `B_d≤Cd polylog(n)Wν/K`，没有证明 BP11低测试补域的原根阶价。下一步需要对 BP13实际三来源权、score和严格下降联合估计，或者合法使用尚未消费的原 signed信用；仅凭无环/每边下降、单核列容量或未归一核对称性均不足以完成该步骤。这里精确记录一次受限推导的费用，不把 BP13另命名为已经支付的量。

## 6. 实际本机核验与交付界限

本轮实际运行 Python `fractions.Fraction`：4组有理 min-product 权（含重复阈值、饱和段和内部阈值），逐段解析积分核对 `∫k_t w_t dlogt=w_l−w_g`，并枚举各段任意删门；另12组静态容量阈值（使用≥以含等号）核对 `ν{T≥rp}≤q/(rp)`，再检查付款常数；另12组保D门（含D=0）核对 `∫_{T≥rpD}D dν≤q/(rp)`。共75项精确有理断言全部通过。没有浮点积分、没有据有限模型授予FULL或新history；一般结论由 BP6–8 的测度证明保证。

本轮已付成果仅为 BP5/BP0 在当前原正量上的静态高测试子交通，余量准确为 BP11低测试支。它覆盖全原时钟与全部实际 L/R/s，费用明确且无新增菜单。整项根阶目标仍未完成。
