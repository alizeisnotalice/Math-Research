#!/usr/bin/env python3
"""R226 finite exact product clocks and static-likelihood payment algebra, not FULL."""
import argparse,hashlib,json
from collections import Counter
from fractions import Fraction as F
from pathlib import Path
HERE=Path(__file__).resolve().parent
CONTRACT_SHA256='5705ef06667ca5154e0930fe3a2783a608af4eb8215f16521d4f32601ade31d6'
def rat(x):return f'{x.numerator}/{x.denominator}'
def summary(x,small=False):
    out={'sha256_hex_fraction':hashlib.sha256((format(x.numerator,'x')+'/'+format(x.denominator,'x')).encode()).hexdigest(),'sign':(x>0)-(x<0),'numerator_bits':abs(x.numerator).bit_length(),'denominator_bits':x.denominator.bit_length()}
    if small:out['exact']=rat(x)
    return out

def counts(n,cycle):return Counter(cycle[i%len(cycle)] for i in range(n))
def weight(t,cs):
    result=F(1)
    for alpha,count in cs.items():result*=min(F(1),alpha/t)**count
    return result

def clock(n,cycle,lower,g,deletion=None):
    cs=counts(n,cycle);knots=sorted(set([lower,g]+[a for a in cs if lower<a<g]+([deletion] if deletion is not None and lower<deletion<g else [])));segments=[];integral=F(0);flux=F(0)
    for left,right in zip(knots,knots[1:]):
        mid=(left+right)/2;k=sum(count for alpha,count in cs.items() if alpha<mid);wl=weight(left,cs);wr=weight(right,cs);alive=deletion is None or mid<deletion;drop=wl-wr if alive else F(0)
        # On each open threshold segment w=C*t^-k; exact antiderivative of k*w dt/t is -w.
        coefficient=wl*left**k;assert coefficient/right**k==wr
        if k==0:assert wl==wr
        integral+=drop
        piece=1/(1+wr)-1/(1+wl) if alive else F(0);flux+=piece
        segments.append({'left':rat(left),'right':rat(right),'k':k,'alive':alive,'w_left':summary(wl,n<=16),'w_right':summary(wr,n<=16),'exact_integral_k_w_dt_over_t':summary(drop,n<=16),'two_source_unit_mass_flux_piece':summary(piece,n<=16),'piecewise_power_identity':True})
    wlower=weight(lower,cs);wg=weight(g,cs);loss=weight(deletion,cs) if deletion is not None and lower<deletion<=g else F(0);terminal_alive_weight=wg if deletion is None or deletion>g else F(0)
    assert integral==wlower-terminal_alive_weight-loss and 0<=integral<=wlower<=1 and integral<=wlower-wg
    cutoff=g if deletion is None else min(g,deletion);globalflux=1/(1+weight(cutoff,cs))-1/(1+wlower);assert flux==globalflux
    return {'n':n,'alpha_cycle':[rat(x) for x in cycle],'alpha_multiplicities':[{'alpha':rat(a),'count':count} for a,count in sorted(cs.items())],'lower':rat(lower),'g':rat(g),'deletion':rat(deletion) if deletion is not None else None,'knots':[rat(x) for x in knots],'segments':segments,'w_lower':summary(wlower,n<=16),'w_g_product_clock':summary(wg,n<=16),'terminal_alive_weight':summary(terminal_alive_weight,n<=16),'deletion_loss':summary(loss,n<=16),'exact_integral_k_w':summary(integral,n<=16),'unit_two_source_flux_until_cutoff':summary(flux,n<=16),'checks':{'clock_integral_endpoint_account':True,'integral_le_one':True,'piecewise_flux_telescopes':True,'alive_interval_drop_le_full_product_drop':True},'scope':'Product clock and optional monotone alive deletion only; a deleted target is not automatically an original terminal-good payment row.'}

def static_model(n,tau,mode='ordinary',K=F(3),capA=F(3),large_K=False):
    alpha=1-F(1,2*n);lower=alpha/(1+F(1,10*n));g=F(1);cs={alpha:n};wg=weight(g,cs);wlower=weight(lower,cs);q=F(1);Lam=F(128,119);mg=capA/tau if large_K else F(1);mb=2*K if large_K else F(1);eg=mb+mg*wg;p=F(1) if large_K else 2*K*q/eg;beta=F(0) if mode=='beta_zero' else q/p;S=tau*p if mode!='A_empty' else tau*p/2;inA=S>=tau*p;nuA=mg if inA else F(0)
    assert p*beta<=q and p*eg>=2*K*q and S*mg<=capA*q
    single=S*mg<=q
    knots=sorted(set([lower,g]+[a for a in cs if lower<a<g]));flux=F(0);clock_integral=F(0);pieces=[]
    for left,right in zip(knots,knots[1:]):
        wl=weight(left,cs);wr=weight(right,cs);etL=mb+mg*wl;etR=mb+mg*wr;k=n if alpha<(left+right)/2 else 0;piece=mb*(1/etR-1/etL);flux+=piece;clock_integral+=wl-wr
        assert etL>=eg and etR>=eg
        pieces.append({'left':rat(left),'right':rat(right),'k_good':k,'k_bad':0,'et_left':summary(etL,n<=16),'et_right':summary(etR,n<=16),'flux_delta_Pi_good_Pi_bad':summary(piece,n<=16)})
    exact_formula=mb*(1/(mb+mg*wg)-1/(mb+mg*wlower));assert flux==exact_formula and clock_integral==wlower-wg and clock_integral<=1
    qualified_flux=flux if inA else F(0);assert qualified_flux<=nuA/eg*clock_integral<=nuA/eg
    X=F(1);Pproxy=F(32,3)*Lam*p*beta*qualified_flux;static_bound=16*Lam*capA/(3*K*tau)*X;assert Pproxy<=static_bound
    assert nuA<=capA*q/(tau*p)
    if single:assert Pproxy<=16*Lam/(3*K*tau)*X
    probe=alpha*(1+F(1,10*n));wp=weight(probe,cs);delta=n;score=delta*wp;assert alpha<probe<g
    PiG=mg*wp/(mb+mg*wp);PiB=mb/(mb+mg*wp);peakflux=delta*PiG*PiB
    epsilon=16*Lam*capA/(3*K*tau)
    if large_K:assert 0<epsilon<1
    rawFAfail=score>F(8,3);FAfail=rawFAfail and 0<epsilon<1 and S==tau*p
    vals={'mg':mg,'mb':mb,'q':q,'Lambda':Lam,'K':K,'tau':tau,'p':p,'beta':beta,'T_source_column':S,'cap_A':capA,'Qstar_for_FA_comparison':S/capA,'eg':eg,'w_lower':wlower,'w_g':wg,'nu_A_tau':nuA,'integral_k_w':clock_integral,'exact_full_clock_flux':flux,'qualified_flux':qualified_flux,'X':X,'P_proxy_after_one_hardcap':Pproxy,'static_bound_16Lambda_A_over_3Ktau_X':static_bound,'single_cap_bound_16Lambda_over_3Ktau_X':16*Lam/(3*K*tau)*X,'probe_t':probe,'probe_wt':wp,'probe_delta_wt':score,'probe_delta_Pig_Pib':peakflux,'epsilon_for_FA_comparison':epsilon}
    return {'n':n,'mode':mode,'large_K_construction':large_K,'cap_A':rat(capA),'target_column_interpretation':'S=K1+K2 scalar' if capA==3 else 'Qstar scalar','in_A_tau':inA,'single_cap_q_actually_satisfied':single,'alpha':rat(alpha),'lower':rat(lower),'g':'1/1','good_bad_alive_entire_interval':True,'bad_clock':'all alpha_i=1, w_u=1,k_u=0','values':{k:summary(v,n<=16) for k,v in vals.items()},'tau_exact':rat(tau),'pieces':pieces,'checks':{'FIRST_p_beta_le_q':True,'high_p_eg_ge_2Kq':True,'source_cap_T_mg_le_Aq':True,'A_tau_gate_selected_consistently':qualified_flux==(flux if inA else 0),'nu_A_bound_Aq_over_tau_p':True,'flux_exact_primitive_and_endpoints':True,'flux_le_nuA_over_eg_clock_drop':True,'static_integrated_payment_proxy_bound':True,'single_cap_payment_proxy_bound_if_applicable':not single or Pproxy<=16*Lam/(3*K*tau)*X},'FA_comparison':{'J_zero_scalar_comparison_only':True,'Qstar':'T/A','paid_gate_equivalent_if_T_equals_tau_p':'delta*wt<=4/(3*log(2))','rigorous_threshold_upper':'8/3 from log(2)>=1/2','delta_wt_exact':summary(score,n<=16),'raw_delta_wt_gt_8_over_3':rawFAfail,'epsilon_in_original_range_0_1':0<epsilon<1,'T_equals_tau_p_for_equivalence':S==tau*p,'sufficient_original_range_paid_gate_failure_exact':FAfail,'integrated_static_bound_still_holds':True},'scope':'Necessary scalar/FIRST/high/product-clock constraints only; not geometry-realizable FULL input, true coupled sources, or actual history/FA eligibility.'}

def drop_aware_model(n,K,A,tau,zero_D=False):
    alpha=F(1) if zero_D else 1-F(1,2*n);lower=alpha/(1+F(1,10*n));g=F(1);wg=alpha**n;wlower=F(1);D=wlower-wg;Lam=F(128,119);p=beta=q=F(1);T=tau*p*D;mg=A*q/T if T else F(1);mb=2*K*q/p;eg=mb+mg*wg;etlower=mb+mg*wlower
    flux=mb*(1/eg-1/etlower);nuD=mg*D;Pproxy=F(32,3)*Lam*p*beta*flux;bound=16*Lam*A/(3*K*tau);epsilon=bound
    checks={'FIRST':p*beta<=q,'high':p*eg>=2*K*q,'source_cap_T_mg_le_Aq':T*mg<=A*q,'drop_aware_gate':T>=tau*p*D,'old_gate_strictly_fails':T<tau*p,'drop_range':0<=D<1,'two_source_flux_nonnegative':flux>=0,'flux_le_nuD_over_eg':flux<=nuD/eg,'nuD_source_bound':nuD<=A*q/(tau*p),'same_static_payment_price':Pproxy<=bound,'epsilon_in_original_0_1':0<epsilon<1,'et_lower_ge_eg':etlower>=eg}
    if zero_D:checks['D_zero_no_score_no_flux']=D==0 and flux==0 and alpha>=g
    else:checks['D_strictly_between_zero_one']=0<D<1;checks['mg_equals_Aq_over_T']=mg==A*q/T
    assert all(checks.values())
    vals={'alpha':alpha,'lower':lower,'w_lower':wlower,'w_g':wg,'D':D,'T':T,'tau':tau,'A':A,'K':K,'Lambda':Lam,'p':p,'beta':beta,'q':q,'mg':mg,'mb':mb,'eg':eg,'et_lower':etlower,'flux_integral':flux,'nu_times_D':nuD,'nuD_over_eg':nuD/eg,'Aq_over_tau_p_eg':A*q/(tau*p*eg),'P_proxy_after_one_hardcap':Pproxy,'same_price_16Lambda_A_over_3Ktau':bound,'epsilon':epsilon}
    return {'n':n,'zero_D_branch':zero_D,'cap_A':rat(A),'K_exact':rat(K),'tau_exact':rat(tau),'source_column':'S' if A==3 else 'Qstar','values':{k:summary(v,n<=16) for k,v in vals.items()},'checks':checks,'expanded_gate_strictness':'T=tau*p*D<tau*p; D in (0,1), or explicitly zero D no score','scope':'Finite necessary scalar/product-clock model only; no actual FULL or geometry/coupled-source realization.'}

def main(output):
    stages=[]
    for name,ns in [('baseline',(1,2,4)),('known_boundary_FA_peak',(4,16,128)),('expanded',(512,1024))]:
        clockrows=[]
        for n in ns:
            cycle=[F(1,4),F(1,2),F(3,4),F(1)] if name=='baseline' else [1-F(1,2*n)] if name=='known_boundary_FA_peak' else [F(1,4),F(1,2),F(3,4),1-F(1,2*n),F(1)]
            lower=F(1,8) if name!='known_boundary_FA_peak' else cycle[0]/(1+F(1,10*n))
            dels=(None,F(5,8)) if name!='known_boundary_FA_peak' else (None,)
            clockrows.extend(clock(n,cycle,lower,F(1),d) for d in dels)
        stages.append({'stage':name,'clock_cases':clockrows});print(name,len(clockrows),'clock cases passed',flush=True)
    models=[static_model(n,tau,capA=A) for n in (1,2,4,16,128,512,1024) for A,tau in ((F(3),F(1,2)),(F(1),F(1,8)))]+[static_model(16,F(1,2),mode) for mode in ('beta_zero','A_empty')]+[static_model(n,tau,K=K,capA=A,large_K=True) for n in (4,512,1024) for K in (F(256),F(4096)) for A,tau in ((F(3),F(1,2)),(F(1),F(1,8)))]
    result={'schema':'R226_fullclock_candidate_finite_checks_v1','complete':True,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'contract_sha256':CONTRACT_SHA256,'arithmetic':'Fraction and arbitrary-precision integers only; no numerical logarithm or float','stages':stages,'two_posterior_static_models':models,'drop_aware_models':[drop_aware_model(n,K,A,tau) for n in (4,512) for K in (F(256),F(4096)) for A,tau in ((F(3),F(1,2)),(F(1),F(1,8)))]+[drop_aware_model(4,F(256),A,tau,True) for A,tau in ((F(3),F(1,2)),(F(1),F(1,8)))],'assumptions_and_interfaces':['t_lower<=g; product weights use positive thresholds and probability source masses.','Two-source exact primitive assumes good and bad remain alive on the displayed interval; optional deletions are checked separately as clock accounts.','General upper bound tolerates monotone Z_t drops: discarded deletion mass only reduces positive clock occupation.','D-aware extension retains D=w_lower-w_g: T>=tau*p*D and T*mg<=Aq imply mg*D<=Aq/(tau*p); D=0 handled without division.','T>=tau*p and T*mg<=Aq with A=1 or 3, p*beta<=q, p*eg>=2Kq checked at the same finite receiver; Lambda=128/119.','Original hardcap is represented only once by 32Lambda/3; no original negative credit is used.','FA comparison uses supplied R119 FA11 scalar J=0 specialization Qstar=T/A and epsilon=16Lambda*A/(3Ktau); valid failure labels additionally require 0<epsilon<1 and T=tau*p. log2>=1/2 is analytic.'],'scope':['Finite exact clock and necessary scalar data, not arbitrary matrices labeled FULL.','No actual C-threshold geometry, actual good/bad source coupling, original suffix/history/FA domain or arbitrary-input realization certified.','A sufficient scalar FA paid-gate failure is not a full-input counterexample.','No fitted dimension order or general payment proof inferred from these samples.','Large exact results are summarized by canonical hex Fraction hashes and bit lengths.']}
    output.write_text(json.dumps(result,indent=2)+'\n')
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=HERE/'clock_checks.json');args=ap.parse_args();main(args.output)
