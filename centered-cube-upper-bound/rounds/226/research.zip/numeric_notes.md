# R226 finite FULLCLOCK-candidate checks：运行前方案

本脚本不把任意有限矩阵称为FULL。只核必要标量/真实product-clock代数，保同点FIRST、高门、来源似然门与一份hard cap系数；不认证阈值来自真实C几何、原good/bad/FA/history与完整输入资格。

有限菜单三阶段：baseline n=1,2,4，alpha循环1/4,1/2,3/4,1，t_lower=1/8,g=1，每个有/无在5/8删除的alive mask；压力n=4,16,128，共同alpha=1−1/(2n)，并保原阈值knots；expanded n=512,1024，alpha循环1/4,1/2,3/4,1−1/(2n),1，亦有/无5/8删除。每段以确切端点差w(left)−w(right)核∫k_t w_t dt/t，删除loss分开，不能把可删除clock自动当terminal-good付款模型。

独立两源模型：good v真实product-clock，bad u所有alpha_i=1故k_u=0,w_u=1；mg=mb=q=Lambda=1,K=3，g=1，两个来源全段alive。good共同alpha=1−1/(2n)，lower在alpha左侧，p=6/(1+wg)，beta=1/p，高门p eg=2Kq，FIRST p beta=q。取tau=1/2令S=tau p，满足S mg≤3q；tau=1/8还满足single-K1 capq。n=1,2,4,16,128,512,1024，两tau各一例，再补beta零/静态A门空两零支。完整两posterior flux按每个真实threshold段的有理原函数计算，保mg、mb、et、eg。

原FA比较按父级定位R119 FA11：J=0 scalar comparison,Qstar=S/3，epsilon=16Lambda/(Ktau)，则paid gate为delta wt≤4/(3 log2)。只用解析log2≥1/2推出其右边≤8/3；在t=alpha(1+1/(10n))精确核delta wt>8/3作为充分失败。失败只针对这个scalar paid-gate比较，不叫原FULL输入反例。与全clock静态积分上界同时核验。

积分后有限交通代理仅取原hardcap一次的系数32Lambda/3乘p beta和真实flux；以nu(A_tau)≤3q/(tau p)、et≥eg、高门核32Lambda/3 *p beta*flux≤16Lambda/(Ktau)X，X=1；single-capq用16Lambda/(3Ktau)。不把有限样本当一般证明。所有数值Fraction，无log浮点评价，脚本自足--output，最终JSON逐字节复跑，无runtime/路径。

最终菜单校准（运行前）：Lambda统一原值128/119；列T的帽参数A=3对应S，A=1对应Qstar，通用价格16Lambda A/(3Ktau)，FA比较Qstar=T/A、epsilon取该价格。小K例若epsilon≥1只标raw score，不叫原FA允许范围内失败。新增n4/512/1024、K256/4096、两种(A,tau)=(3,1/2),(1,1/8)，取p=beta=q1,mb=2K,mg=A/tau，高门与source cap同时满足且epsilon<1；其他原菜单保留。

## 实际运行结果

13个piecewise product-clock例全部通过，包括threshold knots与5个单调删除clock。所有段以Fraction端点差核积分；删除loss从连续clock下降量中扣除，未把它混成终端good模型。28个两posterior模型全部通过完整et/eg、FIRST/high/source cap和静态积分代理上界；包括beta零、A_tau空两零支。

最终Lambda=128/119。通用列帽T nu≤Aq、T≥tau p对应价格16Lambda A/(3Ktau)X；A=3为S，A=1为Qstar重标。未把两种列帽的阈值或系数混用。

新增12个大K例均有epsilon∈(0,1)、T=tau p且delta wt>8/3，因而在已给FA11 scalar comparison资格内充分不满足该paid gate；同时每例的全clock静态上界仍通过。数据是必要标量/clock资格，不是实际原FULL输入。

|n|K|A|tau|mg|mb|epsilon精确|
|---|---|---|---|---|---|---|
|4|256|3|1/2|6|512|16/119|
|4|256|1|1/8|8|512|64/357|
|4|4096|3|1/2|6|8192|1/119|
|4|4096|1|1/8|8|8192|4/357|
|512|256|3|1/2|6|512|16/119|
|512|256|1|1/8|8|512|64/357|
|512|4096|3|1/2|6|8192|1/119|
|512|4096|1|1/8|8|8192|4/357|
|1024|256|3|1/2|6|512|16/119|
|1024|256|1|1/8|8|512|64/357|
|1024|4096|3|1/2|6|8192|1/119|
|1024|4096|1|1/8|8|8192|4/357|

FA充分失败采用解析log2≥1/2，故不需要浮点log作证书。delta wt=n(1+1/(10n))^(−n)；n=4即严格超过8/3。小K正式模型的epsilon超出(0,1)时只记录raw score，不标允许参数范围内FA失败。

每个有限支付代理只乘一次原hardcap后的32Lambda/3，不复用负账或把nu替换beta。源mg/mb在大K例故意可远大于beta，未额外假设nu≤beta。对原geometry、C阈值、good/bad耦合、可用clock窗口与history/FA剩余资格没有认证；这些精确样本不能替代一般证明。

显式--output完整复跑后JSON逐字节相同。SHA256=3fe62e4534122f667519a326d74fa63d57983379e4975249472125964764d04c；源码及合同指纹在JSON，所有比较均为Fraction/整数，大值保规范hex分数哈希和bit长度，无runtime/路径字段。

复现：

```sh
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 /Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/226/work/clock_checks.py
```

## D-aware增强：实际有限核验

新增8个高K正D例（n4/512、K256/4096、A1/3），取D=1−w_g、T=tau p D、mg=Aq/T、mb=2Kq/p，p=beta=q1。全部满足0<D<1、新门等号而旧T≥tau p严格失败；完整两Pi积分精确满足flux≤mg D/e_g≤Aq/(tau p e_g)，最终价格仍16Lambda A/(3Ktau)，epsilon均在(0,1)。另2个D=0、alpha=1例有零score/零flux，不除T=0。原28个模型完整保留，已有删除clock另精确核D_Z≤D。以上只验证有限必要代数与clock约束，非FULL或实际联合几何实例。

本次最终JSON显式--output完整复跑字节相同，更新SHA256=2e0b087afaaa3c17339bb0742e9ebba7e57e68d17c56f0af5b1976fc204bff3c。
