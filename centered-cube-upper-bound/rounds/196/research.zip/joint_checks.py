#!/usr/bin/env python3
"""Exact finite scalar checks of the CC4 joint reserve envelope."""
import argparse
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path
HERE=Path(__file__).resolve().parent


def encode(x):
    if isinstance(x,F):return str(x)
    if isinstance(x,dict):return {k:encode(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)):return [encode(v) for v in x]
    return x


def check(stage,name,c,r,b):
    c,r,b=map(F,(c,r,b))
    assert c>0 and r>=0 and b>=0
    raw=c-r-(c+1)*b
    d=max(F(0),raw)
    a=c+1
    denominator=c*(1+r)
    upper=d*d/(4*a*denominator)
    optimum=d/(2*a)
    if d:
        us=sorted({F(0),optimum/2,optimum,2*optimum,4*optimum})
    else:
        us=[F(0),F(1,10),F(1)]
    rows=[]
    for y_alpha in us:
        active=max(F(0),d-a*y_alpha)
        Ad=active/denominator
        direct=y_alpha*Ad
        assert 0<=direct<=upper
        if y_alpha<=d/a:
            deficit=(d-2*a*y_alpha)**2/(4*a*denominator)
            polynomial=(d*y_alpha-a*y_alpha*y_alpha)/denominator
            assert direct==polynomial and upper-direct==deficit
            branch='quadratic'
        else:
            deficit=upper
            assert direct==0
            branch='positive-part-zero'
        # Rebuild the dimensional prefactor with a scalar QJ distinct from J.
        Tdelta,J,QJ=F(3,2),F(5,7),F(11,3)
        alpha=y_alpha*Tdelta/J
        assert alpha*J/Tdelta==y_alpha
        budget=alpha*QJ
        integral_tests=[]
        for fraction_used in (F(0),F(1,3),F(1)):
            # This is only an abstract nonnegative integral obeying the budget.
            integral=fraction_used*budget
            lhs=J/(Tdelta*QJ)*Ad*integral
            assert lhs==fraction_used*direct and lhs<=direct<=upper
            integral_tests.append({'fraction_used':fraction_used,'H_kM_integral':integral,'joint_lhs':lhs})
        rows.append({'y_alpha':y_alpha,'A_d':Ad,'y_alpha_A_d':direct,'bound_deficit':deficit,'branch':branch,
             'dimensional_scalars':{'T_delta':Tdelta,'J_target':J,'QJ_original_scalar':QJ,'alpha':alpha,'alpha_QJ_budget':budget},
             'abstract_integral_checks':integral_tests})
    # Independent stationary-point/endpoints calculation on the supported
    # parabola [0,d/(c+1)]; outside it the objective is identically zero.
    candidates=[F(0),optimum,d/a]
    candidate_values=[(d*x-a*x*x)/denominator for x in candidates]
    assert max(candidate_values)==upper
    optimum_Ad=max(F(0),d-a*optimum)/denominator
    assert optimum*optimum_Ad==upper
    if d==0:assert all(x['A_d']==0 for x in rows)
    return {'stage':stage,'name':name,'c':c,'r':r,'b':b,'unclipped_d':raw,'d':d,
        'upper':upper,'y_alpha_optimum':optimum,'stationary_endpoint_candidates':candidates,
        'stationary_endpoint_values':candidate_values,'y_alpha_checks':rows,'status':'PASS'}


def run():
    fixtures=[
      ('initial','unit_active',1,0,0),
      ('initial','exact_r_threshold',1,1,0),
      ('initial','exact_b_threshold',1,0,'1/2'),
      ('stress','strictly_below_capture',1,'1/4','1/2'),
      ('stress','nonunit_active',2,'1/2','1/6'),
      ('stress','small_fractional_active','1/2','1/8','1/12'),
      ('expanded','tiny_c','1/1024',0,0),
      ('expanded','large_c',1024,'1/3','1/7'),
      ('expanded','all_fractional','7/3','5/7','2/9'),
    ]
    cases=[check(*f) for f in fixtures]
    return {'schema':'r196_joint_scalar_v1','arithmetic':'stdlib fractions.Fraction only',
        'inputs':{'task_contract.md':hashlib.sha256((HERE/'task_contract.md').read_bytes()).hexdigest()},
        'formulas':{'d':'[c-r-(c+1)b]_+','A_d':'[d-(c+1)y_alpha]_+ / [c(1+r)]',
            'upper':'d^2/[4c(c+1)(1+r)]','optimum':'y_alpha=d/[2(c+1)]',
            'active_square_deficit':'upper-y_alpha A_d = [d-2(c+1)y_alpha]^2/[4c(c+1)(1+r)]',
            'joint_budget':'(J/(T_delta QJ)) A_d integral(H k M) <= y_alpha A_d, given integral<=alpha QJ and y_alpha=alpha J/T_delta'},
        'case_count':len(cases),'stage_counts':{'initial':3,'stress':3,'expanded':3},
        'y_alpha_check_count':sum(len(c['y_alpha_checks']) for c in cases),
        'abstract_integral_check_count':sum(3*len(c['y_alpha_checks']) for c in cases),
        'cases':cases,'status':'PASS','limitations':[
            'Finite exact scalar algebra only, not original physical kernels, FIRST/history, or realizable full source data.',
            'The integral examples are prescribed scalar budget values, not independently constructed original M or H.',
            'QJ is the original scalar denominator; it is not the product of a pointwise Q and J.',
            'Square completion is checked independently from direct positive-part evaluation; finite samples do not replace the general proof.',
            'No numerical quadrature, asymptotic order fit, or global root-budget claim.']}

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=HERE/'joint_checks.json');args=parser.parse_args()
    result=run();args.output.write_text(json.dumps(encode(result),indent=2,sort_keys=True)+'\n')
    print('PASS: '+str(result['case_count'])+' fixtures, '+str(result['y_alpha_check_count'])+' y_alpha checks, '+str(result['abstract_integral_check_count'])+' abstract integral checks')
