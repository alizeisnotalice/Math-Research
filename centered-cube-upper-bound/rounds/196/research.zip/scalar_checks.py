from fractions import Fraction as F
from pathlib import Path
import json,argparse
rows=[]
for stage,N in [('initial',4),('pressure',12),('expanded',40)]:
 count=0
 for a in [F(1),F(3,2),F(2)]:
  for w in [F(1,N),F(1,2),F(1)]:
   for r in [F(1,N),F(1),F(N),F(2)*a/(3*w),F(2)*a/(3*w)+F(1,N)]:
    K=F(1);c=3*w*r/K;z=max(2*a,c)
    bound=r/(4*a) if c<=2*a else K/(3*w)-a*K*K/(9*w*w*r)
    assert r*(z-a)/(z*z)==bound
    for bi in range(N+1):
     b=a+F(bi,N)
     for ti in range(N+1):
      t=F(ti,N)*max(c,2*a)*2
      if b+t<c:continue
      assert r*t/(b+t)**2<=bound
      count+=1
 rows.append({'stage':stage,'grid_N':N,'eligible_exact_cases':count})
out={'status':'PASS','scope':'Scalar relaxation only; K=1, rational grids, no physical/full source certificate','stages':rows}
parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));args=parser.parse_args()
args.output.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out))
