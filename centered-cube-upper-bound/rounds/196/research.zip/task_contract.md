# 第196轮任务合同

目标仍为任意正 L1 输入的一般中心立方体 n^(1/2+o(1)) 一致弱型上界。本轮聚焦第195轮 CG11 真实加权平方位移与 CC22 单次储备加权占用，不以接口改名或固定参数结果宣称闭合。

权威基线：第195轮提交 f4f0dbe615890f5cffc10c64ed873557dce398e6，独审与复现已完成；外部展开检查点为 /Users/zhengzhihao/Desktop/T/output/centered_cube_round195_20261016_final_checkpoint。

准确主要问题：对原 A=rho J/(p_v+pplus_v+J) 的 good 槽，利用完整分母、近 outer-bad 来源和真实目标几何，估计 CG11 的积分；所有 receiver、posterior、alpha、窗口和 unique-j 保持原定义。希望得到 polylog(n) W_A 的平方伴随预算，但此为目标而非假设。

辅助问题：实际剩余 neutral 排除已消费 Theta_c 后，构造 CC22 占用积分的可支付几何估计。不得凭邻近距离断言来源密度；不得重复消费储备。

允许：R195 已审两条来源定位、CG 和 CC 恒等式、修复后的 E_J<=n W_nu/(2K)、共同父 W_A、R194 物理捕获率。限制：无 nu<=beta；y-u 近不代表 y-v 近；fixed-parameter TV 不支付 inverse-J square；完整 Tstar 和自适应费用保留。

分工：Astra target_displacement.md；Sol high capture_geometry.md；独立 Sol high audit.md 先审命题再读作者；父负责主推导及整合。数值待准确候选确定后启动，使用本机数学工具，三阶段验证，不拟合猜测阶数。所有子代理不得 git、启动子代理或修改他人文件，交付后停止。

成功标准：新增经过独审且带真实总费用的估计，或明确改变下一步的构造。一般证明、条件结论、有限数值分开。轮次未核验完之前不作研究完成提交；最终按本轮独立归档提交推送，不编译 PDF。
