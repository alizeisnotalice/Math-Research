# R196 exact joint scalar envelope checks

The author confirmed the interface. To distinguish it from a source index, the scalar called u in the parent request is named y_alpha=alpha J_v/(T Delta_v) in this checker. The domain is c>0 and r,b,y_alpha>=0, with d=[c-r-(c+1)b]_+ and A_d=[d-(c+1)y_alpha]_+/[c(1+r)]. Physical r,b are generally positive; zero-boundary fixtures below are abstract algebra controls.

All nine fixtures passed using standard-library Fraction only. Three initial cases include c=1 with positive d, exact r threshold, and exact b threshold. Three stress cases include strictly negative unclipped d and nonunit fractional c,r,b. Three expanded cases include c=1/1024, c=1024 and fully fractional data. Six cases have d>0 and three have d=0. Each active case tests y_alpha=0, half the maximizer, the maximizer, the positive-part threshold and twice that threshold. Zero-d cases also test positive y_alpha. The resulting 39 scalar checks cover both branches.

The direct positive-part objective y_alpha A_d is checked against d^2/[4c(c+1)(1+r)]. Independently, on its supported interval the checker verifies the exact square deficit and evaluates the quadratic at its stationary point and both endpoints. The optimum y_alpha=d/[2(c+1)] attains the bound. Outside the supported interval the objective is zero and the bound is retained; when d=0 the entire objective vanishes. No claim is made that a physical original source realizes equality.

For every scalar test, three abstract integral values (zero, one-third and the whole alpha QJ budget) give 117 dimensional budget checks. They use T Delta=3/2, J_v=5/7 and QJ=11/3, compute alpha=y_alpha(T Delta)/J_v, and verify exactly

(J_v/((T Delta)QJ)) A_d I = fraction_used * y_alpha A_d.

Here I is only a prescribed nonnegative scalar satisfying I<=alpha QJ. The checker does not construct M,H or actual source occupation. Using the whole budget illustrates the algebraic equality condition only; actual application must supply the original source budget and H normalization. QJ remains the original scalar throughout, not a product of a pointwise Q and J.

I also statically read the parent's scalar_checks.py without modifying or rerunning it. Its label is a rational-grid scalar relaxation with K=1; it does not claim a physical/full source certificate. This brief read is not an independent proof of its general envelope.

Reproduce using Python 3, without third-party dependencies:

```sh
python3 joint_checks.py --output joint_checks.json
```

Relocation requires only the script and its local task_contract.md; the JSON binds the latter by a filename hash key. A temporary-directory copy was independently executed and its complete JSON matched the work output byte-for-byte. The code and output are deterministic; no runtime or absolute local paths enter the mathematical data. These are finite exact scalar certificates, not FIRST/history or FULL instances, a realizability result, an asymptotic fit, or a proof of the remaining general geometry budget.
