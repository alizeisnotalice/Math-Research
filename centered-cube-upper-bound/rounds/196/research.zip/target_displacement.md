# R196: the actual denominator on the high-capture displacement core

This checkpoint proves a quantitative split and an exact common-high column identity for the original R195 CG11 integral. It does not establish a general polylogarithmic companion budget. The comparable-current part has an explicit original source price; this is a consequence of the previously paid J-energy and is not advertised as a strict new enlargement of the solved physical domain. The large-current-difference part is retained with all its actual weights.

## TD1. Same original row and positive measure

Use the original notation

    S_v=p_v+pplus_v+J_v=3Q_v,
    A=1_good rho J_v/S_v,
    a_n=1+gamma^(-n), gamma=1+1/n.

The current kernels have the same `(s(x),L(x))`, `Lplus=min(b,gamma L)`, and `J_v=P_(1,b)(x-v)`. Thus `S_v>=a_n p_v+J_v`. The selector, alpha, terminal capture and posterior are unchanged. Let H retain all original receiver/high/reciprocal/history/time/unique-j masks and the core restrictions being studied. In this manuscript H also restricts to

    A>=1-eta, 0<eta<1.                             (TD1)

Changing strict to non-strict inequalities in the high-A gate causes no difficulty in these upper estimates. Put

    dM=E sum_V sum_j 1_E(x) H dx beta_V(dy) dt/t
                         Pi_(y,j,t)(dv)Pi_(y,j,t)(du).

This is exactly the positive measure used for the R195 companion. All receiver integrals start on the original set E. The definitions are first read on finite restrictions, and nonnegative integral limits are taken afterwards. Original zero-posterior rows contribute zero.

Write

    C_shift=integral A^2(p_y-p_v)_+^2/J_v dM,
    C_core =integral p_y^2 A^2/J_v dM,
    Z_J    =integral J_v dM.

The legal J kernel is strictly positive. Any other zero-density slot is removed before taking its ratio. No relation nu<=beta is assumed.

## TD2. What the actual denominator does on high A

Since A>0 on TD1, its good indicator is one. The exact identity is

    A(p_v+pplus_v)=(rho-A)J_v.

Consequently

    a_n p_v A <= (rho-A)J_v <= eta J_v.            (TD2)

At the same actual points,

    1 <= S_v/J_v=rho/A <= 1/(1-eta),
    (1-eta)^2/J_v <= A^2/J_v <= 1/J_v.             (TD3)

The last line is especially relevant here. Replacing `A^2/J` by the full expression `rho^2 J/S^2` is exact, but on the high-A core its denominator is already quantitatively comparable to J. Thus an estimate that only uses this substitution has not yet changed the inverse-J square into an ordinary translation norm. This is not an impossibility statement for a geometric estimate using the original measures or masks.

The upper inequalities TD2 hold more generally on `rho-A<=eta`; the lower comparisons in TD3 require the actual high-A gate TD1. No such lower comparison is claimed merely from a small share deficit.

## TD3. Exact comparable-current and large-difference split

Fix a number R>1 before integration. Split the same original measure into `p_y<=R p_v` and `p_y>R p_v`. On the first part TD2 gives

    A^2(p_y-p_v)_+^2/J_v
       <= (R-1)^2 eta^2 J_v/a_n^2,
    p_y^2 A^2/J_v <= R^2 eta^2 J_v/a_n^2.          (TD4)

On the second part define the actual integral

    B_R=integral 1_{p_y>R p_v} p_y^2/J_v dM.       (TD5)

This measure still includes the original posterior, high-A, same-alpha capture, reciprocal bad source, receiver and history restrictions. It is not a free source moment. The following two-sided comparison follows pointwise:

    (1-eta)^2(1-1/R)^2 B_R
       <= integral 1_{p_y>R p_v}
                    A^2(p_y-p_v)^2/J_v dM
       <= B_R.                                   (TD6)

For the original companion itself on this part,

    (1-eta)^2 B_R <= C_core[p_y>R p_v] <= B_R.      (TD7)

These are extended nonnegative inequalities and do not require B_R to be finite. They locate the relevant geometric issue more precisely than an unweighted TV estimate: on this actual part, a companion bound is equivalent, up to the displayed constants, to paying TD5. Equivalence of companions does not imply that every possible proof of the raw bound must use this companion route.

## TD4. Complete original fees of this split

For each original window define the same full auxiliary-time cost as in R195 CG5, and let Tstar be its supremum over the original window ledger:

    Tstar=sup_windows sum_j log_+(b c_j^2/a)
         <=log 2+(n+1)(log 2)^2/4.

Fixed `(omega,V,j,y,t)` has the original x-independent posterior. Positively enlarging only to its original defining auxiliary time interval and then integrating the fixed J kernel gives

    Z_J<=Tstar W_beta.

The j/time cost has not disappeared. In particular unique j cannot be used a second time after replacing the receiver-dependent indicator by the sum of these different posterior measures. Independent windows retain their existing source ledger.

Use the repaired original energy `E_J<=n W_nu/(2K)`, and `W_beta,W_nu<=W_A`. Cauchy on the same measure and TD4 give the actual source price

    Raw^+[high A; p_y<=R p_v]
      <=(32 Lambda/3) (R eta/a_n)
                    sqrt(n Tstar/(2K)) W_A.       (TD8)

For the whole high-A core, splitting the two nonnegative contributions gives

    Raw_core^+
      <=(32 Lambda/3) [
          (R eta/a_n)sqrt(n Tstar/(2K)) W_A
           +sqrt(n W_nu B_R/(2K)) ].              (TD9)

The one hard factor 16/3 and original outer factor 2 Lambda occur exactly once. No negative deletion or capture credit has been consumed. The first source fee is at root scale if `R eta sqrt(Tstar)/a_n` is bounded, or root-polylog scale if this factor is polylogarithmic. For fixed eta,R it is generally of order n, rather than root. Tstar=0 means zero traffic. No small eta is substituted into a previously selected high-A region without accounting for the remaining targets.

TD8 is a transparent use of the earlier J-energy, not a proof that the original leftover core is contained in its condition. In particular the arbitrary parameter R is not a replacement for a geometric argument on TD5.

## TD5. Exact common-high normalization of the remaining column

The following identity retains the normalizations that a further proof must use. Fix x and an original window. Its q is common and fixed; only the legal current FIRST inequality is used. Define the current outer-source subprobability

    P_beta,x,V(dy)=p_y beta_V(dy)/q.

Its appropriate common-window sum has total mass at most one. For eligible rows put

    h_t(x,y)=2K q/(p_y e_t(y)).

Original high and `e_t>=e_g` imply `0<h_t<=1`. Set the product with the original masks to zero on ineligible, p_y=0 or e_t=0 rows. This is not a new high selection. Integrate the actual u mask first:

    b_H(x,y,v,j,t)=integral H(x,y,v,u,j,t) Pi_(y,j,t)(du).

This retains every u-dependent history, bad, reciprocal and support condition. It is not replaced by an ordinary bad probability. If H includes the high-A gate, b_H also includes it.

Writing the original target posterior as

    Pi_(y,j,t)(dv)=1_{Z_(y,j,t)}(v)
                         w_t(y,v) nu_V(dv)/e_t(y),

gives the exact identity

    B_R=(1/(2K)) E sum_V sum_j integral dt/t integral_E dx
          integral J_v nu_V(dv)
          integral P_beta,x,V(dy)
            h_t(x,y) 1_{Z_(y,j,t)}(v) w_t(y,v)
            (p_y/J_v)^2 b_H(x,y,v,j,t)
            1_{p_y>R p_v}.                        (TD10)

Verification is purely multiplication: `(1/(2K))P_beta h_t=beta/e_t`; the remaining `J_v(p_y/J_v)^2` equals `p_y^2/J_v`. Both the alive indicator and the original h_t factor are indispensable for this equality. The full current-normalized measure P_beta depends on x; it cannot be moved outside the receiver integral as a fixed source reference. This derivation does not introduce nu<=beta, an independent source product or an additional source mass cap.

This normalization pays the high-column coefficient exactly once. It displays the remaining object as a physical ratio-square average under the actual current input subprobability, with the real target source J_v nu_V and actual posterior restrictions. No assertion is made that a subprobability automatically controls an unbounded ratio-square.

## TD6. Good geometry retained in that column

On the actual good and high-A slots,

    p_y w_g(y,v)<=K S_v/3,
    S_v/J_v=rho/A<=rho/(1-eta),

and hence

    (p_y/J_v) w_g(y,v)
        <=K rho/[3(1-eta)]<=K/[3(1-eta)].          (TD11)

Thus TD10 also has the genuine upper estimate obtained by replacing its ratio-square factor by

    K^2 rho^2/[9(1-eta)^2 w_g(y,v)^2].            (TD12)

This replacement is not used as a payment: the accompanying factor is the original `w_t(y,v)`, and the unresolved time amplification is `w_t/w_g^2`. It is not bounded by the mass of P_beta or by the fixed posterior's probability normalization. The original capture rho and same alpha can still interact with this factor; they were not removed in TD10 or TD11.

The R195 reciprocal localization controls the y-u pair. It does not change the y-v weight in TD11--12 into a near-source weight. The reciprocal/source masks in b_H may be essential to a future joint estimate. Replacing them by 1 is a positive upper bound but does not by itself produce a small or root-size column.

## TD7. Bounded conclusion and the next precise obligation

The proved output consists of TD2--9, including an actual additive source fee, and TD10, an exact common-high representation with every original support retained. These narrow the next question to a specific all-input physical column: can the original same-alpha and reciprocal geometry control the TD10 ratio-square average after its actual J_v nu_V dx integration, with the full original j/time ledger? Such an estimate would pay TD5 and therefore the large-difference companion by TD6--7.

Neither the scalar fact that a denominator is positive, the ordinary fixed-parameter translation-TV bound, nor the outer--bad proximity controls this column. Conversely TD3 and TD6 do not rule out such a geometric estimate; they identify where it must act. There is no new unproved small-moment assumption, no further cutoff declared free, and no claim that all of the remaining original core has been paid in this checkpoint.
