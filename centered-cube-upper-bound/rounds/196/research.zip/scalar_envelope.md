# 原目标分母的精确标量外放松

本结果不是新增已支付来源分支；目的为在保留 good 条件下找出最强标量补偿，避免将损失藏入逆 J。

令 p=p_y>0,v=p_v>0,j=J_v>0，b=(p_v+p_v^+)/v>=a=1+gamma^{-n}，r=p/v,t=j/v,w=w_g(y,v)>0。原 good 条件为 wr<=K(b+t)/3，A=rho t/(b+t)。零槽在积分前设零；原 strictsoft 正槽允许这些除法。

则 p² A²/j=rho² p r t/(b+t)²。记 z=b+t，允许 b>=a,t>=0 的正外放松给 t<=z-a，且 z>=max(a,3wr/K)。因此精确标量上包络为

F(r,w)=r/(4a), 当 3wr/K<=2a；
F(r,w)=K/(3w)-a K²/(9w² r), 当 3wr/K>=2a。

证明：r(z-a)/z² 的导数为 r(2a-z)/z³，故最大值在 z=max(2a,3wr/K)，取 b=a,t=z-a 达到外放松极值。两式在阈值连续。这里“精确”仅指标量外放松，未断言该极值由真实核及历史实现。

由此原 C_shift<=C_core<=积分 rho² p_y F(r,w) dM。dM 必须保留原后验、接收域、共同 alpha 与全部时间/尺度费用。这仍需联合几何估计，不能把积分 p_y 当作没有 Tstar 的来源质量，不能把 w_g(y,v) 换为 reciprocal 坏来源的 w_g(y,u)。

可用价值：完整分母把显式 inverse-J 奇点替换为连续的 ratio/target-overlap 权重；任何进一步一般根阶方案必须支付这一权重或利用原 A/rho 更强约束。已通过独立命题初审；有限有理核验仅检查标量外放松。high A>1/2 时原 rho<=1 排除 z=2a、b=a 的松弛极值（此时 A<=1/2），故不能据松弛等号认定真实核心极值。
