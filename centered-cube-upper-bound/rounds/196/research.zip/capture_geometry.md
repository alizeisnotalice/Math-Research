# R196：实际 reserve 与剩余 target 的联合二次补偿

本稿沿 R195 CC22 的实际占用账，证明一个保留同 α 的联合二次不等式，并通过恢复 target 标签把它接回原 raw 的系数。它避免把 target 抑制与 reserve 分别取极值。尚未证明一般 core 的补偿核 majorant 或占用尾项可付；outer–bad 近只作为原实际限制保留，不推导来源密度。

## CG1. 原同一行、reserve 和剩余 target

固定原 `(ω,V,x,j,y)`，保留固定 q、原 window、唯一 j(x)、全部 current/FIRST、Pi、history 和删除。使用冻结 R195 CC 的同一实际对象

\[
 \mu=\mu_{\rm hi},\quad \nu=\nu_V,\quad
 k_z=DK_{0,z},\quad K_0=P_{s,\widehat H},\quad
 a_z=T\Delta_z,\quad\Delta_z=w_{\tau_0}(y,z)-w_h(y,z),
\]
\[
 \chi=1_E\min(1,a/k)\nu,\quad
 A_v=1_{\rm good}\rho_v{J_v\over p_v+p_v^++J_v},\quad
 \rho_v=[1-(k_v+\alpha J_v)/a_v]_+,
 \quad 0\le A\nu\le\chi\le\nu\le\mu.
\]

符号 a_z 是 capture 高度，不是辅助运行时刻；辅助时刻仍用 t。实际 reserve 和完整未捕获测度为

\[
 QJ=\int J\,d\nu,\quad
 M=\mu-\chi\ge0,\quad
 R=\alpha QJ=Dq-\int k\,d\chi,\quad
 \boxed{\int k\,dM\le\alpha QJ.}
 \tag{CG1}
\]

最后一步只用同一合法 K0 的 FIRST。μ、ν、β 不重选，不使用 ν≤β。

固定 c>0，先保留原同点方案

\[
 A_m=\min(A,(1-A)/c),\quad
 A_d={[(c+1)A-1]_+\over c},\quad
 \Theta_c=\min((c+1)A,1)\nu\le\chi.
 \tag{CG2}
\]

已消费的 neutral 为 cA_mν，剩余供给只能是 χ−Θ_c，不能重新使用 χ−Aν。本文 c 固定于本原行且不依正在积分的 bad u，以便下面共同恢复 target 标签；它也可预先固定为原 window 的一个常数。

## CG2. 准确变量域与二次包络

只在原有效 good/capture target 且 a_v>0、J_v>0、QJ>0 的槽定义

\[
 r_v={p_v+p_v^+\over J_v}\ge0,\quad
 b_v={k_v\over a_v}\ge0,\quad
 y_\alpha(v)={\alpha J_v\over a_v}\ge0,\quad
 d_0(v)=[c-r_v-(c+1)b_v]_+.
\]

strictsoft 原模型实际 k、p、J 为正；允许标量非负边界只为代数陈述，不将其认证为物理输入。R194 SC10 的精确正部式是

\[
 A_d(v)={ [d_0(v)-(c+1)y_\alpha(v)]_+\over c(1+r_v)}.
 \tag{CG3}
\]

非有效 target 槽 A_d 取零。定义

\[
 F_c(v)={d_0(v)^2\over4c(c+1)(1+r_v)}
 \le {c\over4(c+1)}<\tfrac14.
 \tag{CG4}
\]

对任意 y≥0，

\[
 {y[d_0-(c+1)y]_+\over c(1+r)}
 \le {d_0^2\over4c(c+1)(1+r)}.
 \tag{CG5}
\]

证明：若 d0=0，两边均为零。若 d0>0 且 0≤y≤d0/(c+1)，两边之差精确等于

\[
 {c+1\over c(1+r)}\left(y-{d_0\over2(c+1)}\right)^2.
\]

超过该区间左边为零。标量等号在且仅在 y=d0/[2(c+1)]；d0=0 时任意 y 都给零等号。这个 optimizer 只证明代数包络尖锐，不能据此重新选择原 α、q 或 capture。

## CG3. 一个实际 reserve 对真实来源 packing 的补偿

对固定原 target v，令 H_i(v,z)≥0 为有限或可数可测来源权，满足

\[
 \sum_iH_i(v,z)\le1\quad kM\text{-a.e. }z.
\]

它们可以是互斥空间 cells 的指标，或合法 fractional packing；可依本固定 row/v，但不是重新匹配的来源。令

\[
 M_i(v)=\int H_i(v,z)k_z\,M(dz).
\]

由 CG1，Σ_iM_i(v)≤αQJ。于是

\[
 \boxed{
 {J_v\over a_vQJ}A_d(v)\sum_iM_i(v)
 \le y_\alpha(v)A_d(v)\le F_c(v).}
 \tag{CG6}
\]

这给出了无 1/α 的真实 joint bound。若 d0>0，非零等号还要求 packing 捕获完整预算 ΣMi=αQJ，同时 yα=d0/[2(c+1)]；特别 ∫kM 必须达到 αQJ。一般原几何不保证这些条件，本文不声称存在物理等号例。

CG6 是逐 v 的来源测试。将它对 target 测度积分时必须保留该测度及全部 a_vQJ/J_v 系数；不能说每个 v 各获得一份可相加的免费 source 预算。H_i 依 v 的合法性只是估计原正积分，不允许在 R193 匹配中对运行 v 临时重领 neutral。

## CG4. 恢复 CC22 中被积分掉的 target 标签

使用 R195 CC 的一个已经合法的 cell 方案：对每个原 bad u，target pieces T_i(u) 互斥，来源 cells C_i(u) 互斥，有原全 pair 阈值顺序及物理捕获率 b_i^cap(u)>0，原名义余量 ζ_i(u)>0 已认证，且方案沿辅助时间固定、与 u 联合可测。它们使用剩余供给 χ−Θ_c。

记实际失败索引 F(u)，原 R195 target 数量为

\[
 M_i^{\rm tar}(u)=\int_{T_i(u)}w_\ell(v)A_d(v)\nu(dv)>0,
\]
\[
 D_i(u)=\int_{T_i(u)}\theta_v A_d(v)\nu(dv),\quad
 \theta_v=w_\ell(y,v)-w_g(y,v)\ge0,\quad
 f_i(u)=D_i(u)/M_i^{\rm tar}(u).
 \tag{CG7}
\]

这里 θ_v=well−wg 是真实 future loss 因子，不是 well；Mi^tar 用 well·Adν，而 Di 用 θ·Adν，所以 fi=Di/Mi 正是原 CC19 系数。Mi^tar 与 CG3 的 kernel-cost Mi 不是同一种质量。零 target mass cells 先除，不作除法。以下将 θ_vAd(v)ν(dv) 视为一个非负测度；在其零密度集合不形成 0×∞。原 bad 有限测度

\[
 P_R(du)={1_{R_y}(u)w_\ell(y,u)\nu(du)\over e},\quad
 e=e_g(y)>0,\quad \|P_R\|\le{1\over2K\kappa}
\]

一般不是 subprobability。

定义不改变实际来源的 target-lifted 占用

\[
 \mathcal O_{u,v}(z)={w_\ell(y,z)\over k_z}
 \sum_{i\in F(u)}1_{T_i(u)}(v)
 {b_i^{\rm cap}(u)\over\zeta_i(u)M_i^{\rm tar}(u)}1_{C_i(u)}(z),
\]
\[
 \overline{\mathcal O}_v(z)=\int P_R(du)\mathcal O_{u,v}(z).
 \tag{CG8}
\]

原 strict k>0。Tonelli 和 CG7 精确给

\[
 \int\theta_v A_d(v)\overline{\mathcal O}_v(z)\nu(dv)
 ={w_\ell(y,z)\over k_z}\int P_R(du)
 \sum_{i\in F(u)}{f_i(u)b_i^{\rm cap}(u)\over\zeta_i(u)}1_{C_i(u)}(z).
 \tag{CG9}
\]

右侧恰为 R195 CC19 的 O(z)。没有把小 Mi^tar 归一掉；CG8 中的逆质量是真实系数。

R195 的来源缺失 L=μ−1_Eν≤M。因此其 CC22 failed-cells 账可正上放为

\[
 {32\Lambda\over3}\,\mathbb E\sum_V\int_{E_{\rm rec}}dx
 \int\beta_V(dy){p_y\over e}
 \int\theta_v A_d(v)\nu(dv)
 \int k_zM(dz)\overline{\mathcal O}_v(z).
 \tag{CG10}
\]

所有 receiver 仍为原 Lebesgue dx，outer β、inner ν、q/window、unique-j 及实际 masks 保留。这只替换 L 为更大的实际完整 M，没有另给一份 reserve。未被该 cell 方案覆盖的 A_out 未来损失必须另留，CG10 不包含它。

## CG5. 可接入 CC22 的 bounded packing 与精确尾项

任取可测有限 B_v≥0；它可依固定 row 和 v，但不依正在积分的 z、u 或辅助运行时钟。先在 Ad>0 的有效槽应用下式，Ad=0 的原项直接取零。对原占用作截断

\[
 \overline{\mathcal O}_v
 =\min(\overline{\mathcal O}_v,B_v)
       +(\overline{\mathcal O}_v-B_v)_+.
\]

当 Bv>0，第一项除以 Bv 是一个合法 H∈[0,1]；Bv=0 时第一项先取零。由 CG6，

\[
 \boxed{
 A_d(v)\int kM\,\overline{\mathcal O}_v
 \le B_v{a_vQJ\over J_v}F_c(v)
 +A_d(v)\int kM(\overline{\mathcal O}_v-B_v)_+.}
 \tag{CG11}
\]

因此 CG10 的 bounded 部分精确保留以下系数：

\[
 {32\Lambda\over3}\,\mathbb E\sum_V\int_{E_{\rm rec}}dx
 \int\beta_V(dy){p_y\over e}
 \int\theta_v B_v{a_vQJ\over J_v}F_c(v)\nu(dv).
 \tag{CG12}
\]

剩余 tail 是

\[
 {32\Lambda\over3}\,\mathbb E\sum_V\int_{E_{\rm rec}}dx
 \int\beta_V(dy){p_y\over e}
 \int\theta_v A_d(v)\nu(dv)
 \int kM(\overline{\mathcal O}_v-B_v)_+.
 \tag{CG13}
\]

二者都使用同一 α、M 与原 target；没有把 CG6 逐 v 的常数误当成线性父来源总账。CG11 的收益是 bounded-part 对 α 的补偿已完成，剩余成本明确为 a_vQJ/J_v、θ、target normalization 和 tail，而非 1/α。

一个具体的充分核 majorant 是，对全部实际有效 row/target 认证

\[
 p_y\theta_vB_v{a_vQJ\over J_v}F_c(v)\le C J_v
 \tag{CG14}
\]

且 C 为原窗口全部 selected-j 的统一有限常数。此时 bounded 部分可用原 high/current 的 ∫high β/e≤1/(2K)、固定 J_b 的 receiver 质量 1 和原 unique-j 得

\[
 \text{CG12}\le{16\Lambda\over3K}C\,W_\nu
 \le{16\Lambda\over3K}C\,W_A.
 \tag{CG15}
\]

FTC 时间已在 CC22 前完成，这里没有额外 Tstar；原 unique-j 保持到统一 majorant 后再求和。多窗口若常数不同，须取全原窗族共同 C*=sup C_window，或保留逐窗 C_window·W_nu,window 按原来源账汇总；不能无说明抽出单窗 C。CG14 是足够几何不等式的准确形状，本稿**未证明它在一般 core 成立**，也没有证明 CG13 小。不能把给这两个未知量起名算作原 raw 已付。

## CG6. 新 outer–bad 定位实际能推出什么

保留父 R195 已付域补集

\[
 (1-s(x))^2D_1(y,u)<r_{1,n},\quad
 D_1(y,u)=\sum_i\min(|y_i-u_i|/b,1).
\]

若同保原坐标载体帽 |y_i−u_i|/b≤Rbar_n，则 s<1 时

\[
 \|y-u\|_1/b
 \le\max(1,\mathrm{Rbar}_n)r_{1,n}/(1-s)^2.
 \tag{CG16}
\]

它可以降低一个**已经证明**围绕 u 的来源 cell 半径费用；不能把 u 的近换成 z∈Ci(u) 对 target v 的近，也不推出 cell 内 ν 或 E 质量。近全 soft 的分母退化仍保留。

在 CG8 中，仅知道 u 支持在 CG16 的区域，最多可结合原 bad 总质量界写成

\[
 \overline{\mathcal O}_v(z)
 \le{w_\ell(y,z)\over2K\kappa k_z}
 \sup_{u\in R_y}\sum_{i\in F(u)}
 1_{T_i(u)}(v){b_i^{\rm cap}(u)\over\zeta_i(u)M_i^{\rm tar}(u)}1_{C_i(u)}(z).
 \tag{CG17}
\]

这一步不借来源密度，但保留了低 k/w 与小 target 质量的实际损失。CG16 本身没有控制右侧，因其距离变量中没有 z 或 v。R194 的 source/target 邻点比较也仍需真实 ||z−v||1、signed Hhat 硬面数及全 nS/Hhat 指数；不能从 CG16 插入一个无维常数。

## CG7. 实际 capture 的零增长平台：一条短范围检查

原 C 偶、径向严格递减，C(0)=1。非零 far 行有 τ0<h 且 0<ξh<1。令 r_h=C^{-1}(ξh)，则闭 cube

\[
 \mathcal B_h=y+[-br_h,br_h]^n
       =\{z:C((y_i-z_i)/b)\ge\xi_h\text{ for every }i\}
\]

上准确有 w_h=w_τ0=1、Δ=0、χ=0，因此 M|Bh=μ|Bh。反过来，若某坐标 C_i<ξh，由 τ0<h 得对应 τ0 因子严格大于 h 因子，其余因子非小，故 Δ>0。所有闭面属于零增长平台。

若 u 在此 cube 内且 d_h(u)=min_i(br_h−|y_i−u_i|)>0，则 ||z−u||∞≤d_h(u) 的整邻域仍是零 capture。这个事实只用来核查一个企图：outer–bad 近的来源邻域不自动成为合格 captured ν。它不是反例搜索，也不否定别处可有足够 neutral。

实际 kμ 平台质量已包含在同一个 reserve：∫Bh k dμ≤αQJ，可直接放入 CG6 的 H=1Bh。可是原 weighted occupation 需要 wM；平台上 w_ell=1，不能免费把 μ 质量改成 kμ。低 k/w 的补偿仍须通过 CG14 或别的真实 receiver 估计，而不是来源点距离文字。

## CG8. 零边界与有限结论

α=0 时先由 CG1 得 ∫kM=0；原 strictsoft k>0 使 M=0，所有 joint 来源项为零，不能写 0×∞。QJ=0 时原 Aν=0，交通先取零。a_v=0 或 J_v=0 的原有效 target 余权也先取零，不形成 CG6 分母。零 target cell mass 不定义 CG8；Bv=0 的截断项先零。未证有限的积分只按 extended nonnegative 积分和有限限制后单调极限使用。

若扩展到纯硬 k=0 来源，kM 不控制该处的 wM，必须另留该质量；本文没有此扩展。任何 c、cell、capture 或 α 都没有独立重采样，来源没有坐标独立假设。

本轮可证明的改进是 CG6 的 actual-reserve 联合二次补偿，以及 CG8–13 对原 CC22 系数的精确回代。下一步需要一个真实几何估计控制 CG14 与 CG13，尤其要连上 distant target、source-cell membership、小 Mi^tar 和低 K0/w；outer–bad 的 D1 定位单独尚不足。本文不登记新一般付款，不宣称一般 core/root 结论闭合。到此停止。
