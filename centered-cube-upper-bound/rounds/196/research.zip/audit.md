# R196 独立审计

仅维护本文件，其他作者同时工作；无 Git/spawn/他人编辑。先读取共同 task_contract.md 与 R195 冻结 core_geometry.md、capture_core.md 必要段；本节先对准确候选独立筛查，再读父级 scalar_envelope.md，尚未读本轮两作者证明。一般目标未闭合。

## 1. 原分母中可保留的点态补偿

写 S=p_v+p_v^++J_v，a_n=1+γ^(−n)，原 good target A=ρJ/S。strictsoft 保正核；零 target/分母在任何比例前先隔离。原 good 是 p_y w_g≤KS/3，reciprocal 比较仅外 y 与 bad u，不是 target v。原 exact identity A(p_v+p_v^+)=(ρ−A)J 只在 good target 槽成立，good 外 A=0，所需不等式仍成立。

在不丢原分母时

A²/J=ρ²J/S²≤ρ²/S，且 A²/J≤ρ²/[4(p_v+p_v^+)]≤ρ²/(4a_np_v)。

这些界可用于 C_shift，但只把显式 inverse J 改为 actual denominator/current-ratio 权重，不自动给 source 价。例如 py≤R pv 的片上，A²(py−pv)_+²/J≤ρ²(R−1)(py−pv)_+/(4a_n)；若参数固定可联系 first-power TV，原 adaptive selector/Π/β/门和完整参数费仍在。py/pu 可比不能无费替成 py/pv 可比。

## 2. 精确标量 envelope：独筛及父稿后读

令 p=py>0,v=pv>0,j=J>0，b=(pv+pplus)/v≥a=a_n，r=p/v，t=j/v，w=wg(y,v)>0。good 为 wr≤K(b+t)/3，且 p²A²/j=ρ²p·rt/(b+t)²。固定 z=b+t 后 t≤z−a；故外放松优化为 r(z−a)/z²，z≥max(a,3wr/K)。导数 r(2a−z)/z³ 给最大 z=max(2a,3wr/K)，于是

F(r,w)=r/(4a) 若3wr/K≤2a；否则F=K/(3w)−aK²/(9w²r)。

两段连续，b=a、t=z−a 在外放松中达到。父级 scalar_envelope.md 全文同此独推，数学通过；C_shift≤C_core≤∫ρ² p_y F(r,w)dM 的方向正确。所有 r/w 是同一实际 row、同一点相关量；原 ρ不重选，w不能换成bad-u overlap，不能把∫p_y当成无T*的source价或用Jensen时悄悄换测度。真实 pplus/历史会缩小可行域。

尤其 high A≥h>1/2 时，原ρ≤1给 z≥a/(1−h)>2a（更精确保实际ρ时 z≥aρ/(ρ−h)，ρ>h）。因此 scalar 的 z=2a optimizer 在该 high-A 片不合法；“外放松精确”不等于真实 high-A 可达到，更不是一般 receiver/source 付款。

## 3. 高 A 分片的独立必要比较

在 A≥1−η，0<η<1 时，1≤S/J≤ρ/(1−η)≤1/(1−η)，且 (1−η)²/J≤A²/J≤1/J。对 r0>1，将 C_shift 依 py≤r0 pv 和 py>r0 pv 分。前片由 a_np_vA≤ηJ 给 C_shift,near≤(r0−1)²η² Z_J/a_n²，Z_J≤T*Wβ。后片与保持全部同一门、同一Π的 B_r=∫1_{py>r0pv}py²/J dM 有两侧比较

(1−η)²(1−1/r0)²B_r≤C_shift,far≤B_r。

因此 high-A、大 current-ratio 部分实际分母只有常数级补偿；它是准确待付积分的等价定位，不证明其不可支付。首片要 root 仍须 (r0−1)η√T* 有明确界，不能省去 T*。

## 4. 单一 reserve 与新二次联合界独立筛查

区分 full missing M=μ−χ 与 eligible-source missing L0=μ−1_Eν。二者非负，L0≤M，且 M=L0+(1_Eν−χ)。同一 α 只给一次 ∫kM≤R=αQJ；不能给这两部分各领一份免费R后求和。Θ_c 已消费的 diagonal neutral 也不能再用于 spatial matching。

原 ξ_h∈(0,1] 下，plateau B_h={各Ci≥ξ_h} 恰给 wh=wτ=1、Δ=0、χ=0（k>0），故 M|Bh=μ|Bh。r_h=C^{-1}(ξ_h)，若 u 距闭plateau每face余量 d_h>0，则 ||z−u||∞≤d_h 的点均在 plateau，不能仅凭其μ/ν质量认证capture。闭面方向正确。新 y−u 近不排除此原plateau。

对原 residual A_d，写 a_v=TΔ_v>0、r_v=(p_v+pplus_v)/J_v，d0=[c−r_v−(c+1)k_v/a_v]_+，yα=αJ_v/a_v。则

A_d=[d0−(c+1)yα]_+/[c(1+r_v)]。

若实际 measurable packing H_i(v,z)≥0、Σ_iH_i(v,z)≤1，令 M_i(v)=∫H_i k dM，则Σ_iM_i≤αQJ，从而

[J_v/(a_vQJ)] A_dΣ_iM_i≤yα[d0−(c+1)yα]_+/[c(1+r_v)]≤d0²/[4c(c+1)(1+r_v)]。

常数为标量精确值，α0先由strict k>0推出M0，a0/QJ0原target先零，不除它们。H_i可依fixedrow/v，须共同measurable且沿辅助clock固定；这里只是逐v actual test，不是可按每个target累加R的全局source价，更非可依runtime v重选matching供给。原CC22含 w/k 的occupation，要接上述界必须有实际 bounded packing compensation；near(y,u)不保证near(z,v)或k/w下界。等待两作者完整稿后审，不预先认证一般付款。


## 5. TD 全文后审与父级现有 LaTeX

已实读 target_displacement.md 全文。TD2–9 的 high-A 条件、近 current 片的 C_shift/C_core 区分、far 与 B_R 的两侧常数、原 E_J(Wν)/Z_J(T*Wβ) 和真实 source 费准确。high-A 用非严格门仅改变合法上界，不造成闭面省费。未把同一ρ、原 eligibility、actual time/history/unique-j 删除为自由模型。

TD10 列恒等式在阅读全文前逐项独推：(1/(2K))P_beta h_t=β/e_t，乘 J_v·(p_y/J_v)²、1_Z w_tν 即精确恢复原 B_R；原 high 保 h_t≤1。b_H 是含全部 u-history 的实际条件积分，不是普通 bad mass。P_beta 随 receiver 变，不能取出 dx。TD11/12 同ρ保留的比值上放正确，但 w_t/w_g² 明确保留未付。全文通过。

已读父 proof.tex.txt 当前 scalar 与 joint quadratic 两段：变量 QJ 与 pointwise Q/J 区分、positive-denominator范围、per-target packing 只作 test、sameα不被模型重选、原 occupation 缺口均准确。待作者完整 target-lift 与 TD8/10 整合后再核最终段。

## 6. Sol target-lift 准确候选独立筛查

同一个 c 不依 bad u 时 residual A_d(v)共同。对互斥 T_i(u)、M_i>0 的 actual方案，O_uv(z)=(w(z)/k_z)Σ_failed1_Ti(v)b_i/(ζ_iM_i)1_Ci(z)，barO_v=∫P_R O_uv。Tonelli 确有 ∫θν(dv)A_d(v)barO_v(z)=旧 CC19 的 O(z)，θ=well−wg；这是 CC22 上界表达式的 exact lift，不是原 raw 等号。L0≤M 可正上放同一 full missing。有限、measurable B_v（不依z/u/运行clock）给

A_d∫kM barO_v≤B_v(QJ a_v/J_v)F_c(v)+A_d∫kM(barO_v−B_v)_+。

这是同一二次界与正截断，尚未控制 tail。Ad0/α0/a0/QJ0先隔离或以 A_dθν 作测度，避免0×∞。若另证全原 selected row/window 的 majorant p_yθ_vB_v QJ a_v F_c/J_v≤C J_v，原high列、fixedJ dx、FTC后unique-j确给 bounded项32Λ C/(6K)Wν，无新 T*。但1/M_i、低k/w、source-cell/order及actualtail仍未证，此条件不登记为新 paid 门或一般闭合。

## 7. 有限数值与当前整合静态审

已读 scalar_checks.py、joint_checks.py、numerical_review.md 与当前 report/reproduce。scalar为K=1有限外放松，等号点与有理网格检查无physical声称，三阶段933/6378/63868共71179。joint为9抽象fixture、39标量/117预算回代，direct正部、平方deficit及驻点端点独立计算一致；QJ明确是原标量，预算积分是指定scalar而非构造原M/H。两份证据均不验证一般source/geometry或维数阶。driver先manifest哈希、双脚本fresh output与全JSONbytes比较；本独审不重跑。父已报告两次单脚本bytes一致，总driver仍待manifest后真实执行。


## 8. CG 全文及最终整合审核

已实读 capture_geometry.md 全文。CG1–6 保持同一实际 M=μ−χ/α 的 quadratic、标量等号和零分母资格正确；CG8–10 target-lift 准确恢复旧 CC19 的 f_i 与1/M_i，Adθν作测度避免0×∞。CG11–13 对同一占用的有限Bv截断、原α补偿与真实tail均保留；CG14–15仅在全窗统一majorant成立时给16ΛC/(3K)Wν条件价，FTC后unique-j合并无额外T*，未冒称majorant已证。CG16/17的新近来源条件不足以控制实际z/v距离、低k/w与小target mass；平台及其converse、closedface、zero-reserve分支准确。

已复读最终 proof.tex.txt 的TD费/共同high列与CG target-lift/bounded+tail/majorant回代，常数和详细稿一致；最终report对这些局部估计和未解决全局价的划分准确。两JSON静态计数为scalar933/6378/63868及joint9/39/117，与报告吻合。父已报告两脚本实际重跑全JSONbytes一致；本独审不复跑，总driver仍待未来manifest后父运行，不提前认证。reproduce静态核过，未编译PDF。

## 9. 最终结论与字节绑定

**严格通过：** 原good分母的精确标量外放松；高A comparable/far伴随分片及原共同high列恒等式；同α单一实际储备与residual target的联合二次界；对已合法cell方案的精确target标签恢复、正截断及条件性majorant价格。原source/α/Π/删除/receiver/window/unique-j量词保持。

**尚未认证：** CG14一般majorant或CG13 tail可付，原CC22占用的全局根价，TD10真实ratio-square列的一般控制，以及一般弱型/all-mother/FULL闭合。标量optimizer不等于physical实现，conditional价格不等于新全覆盖；邻近outer-bad也不等于合格target/source占用。

以下SHA256为最终字节实算，排除audit.md自身与未来manifest，避免循环绑定。现冻结停止。

| 文件 | SHA256 |
|---|---|
| task_contract.md | `0dac80dde74a1b9fbf6b56aec400fd357938cfddec524a6b4a2a259f1b4e4b0a` |
| scalar_envelope.md | `dfdee8d66af037bc5aba3507804c916d91cc20a1f20ee9b63cafc5dec001a630` |
| target_displacement.md | `11ace85a2fb0bd70c3519231eb2583745415726a7b2007cd3ebe29537f0adab6` |
| capture_geometry.md | `08a193b8f3109745cb3fc186dd729f203c46693844225cce6df500aa763ae7de` |
| proof.tex.txt | `a92e08590b6dc5145b28469e65f361b8f5c9be759dc2ef95ce6b79f23311a36a` |
| report.md | `3d71060299562a3ef17c2a25f7682cf29251e7f5ea89c471153d1d8de3ea3dfe` |
| scalar_checks.py | `4692ae1bbc961ec0b68bd464b02837ba1a2a19d1a60454a139dd57dd6dd55c54` |
| scalar_checks.json | `8e3a9f3394fc71b063959080abc7a5836dd4e69f55158fe647a0c28b8c89a95d` |
| joint_checks.py | `843697ba3b9ad8468f50c6bdd607d7085141452a18830402fd7bd7051835dea8` |
| joint_checks.json | `98791fa35b0ba30e1cce1ee833ccda8112127c28ca4d76fc71361c7a7544296b` |
| numerical_review.md | `f11e6a789324fa37e807b8265bd8079cf66c60dfa732d54a5502d68763289fd9` |
| reproduce.py | `d494b2326206815c29058041c1c5df02f891ca826ca3ff1a13523f3fae465a26` |
