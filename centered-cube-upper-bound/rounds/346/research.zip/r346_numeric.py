#!/usr/bin/env python3
"""Exact source-relative terminal-future window on genuine 1D receiver dx."""
from fractions import Fraction as F
from pathlib import Path
from collections import Counter
from math import isqrt
import json
BASE=Path(__file__).resolve().parent
C=Counter()
def ck(k,v):C[k]+=1;assert v,k
def logbounds(x,N=32):
 t=(x-1)/(x+1);lo=2*sum((t**(2*j+1)/F(2*j+1) for j in range(N)),F(0));return lo,lo+2*t**(2*N+1)/(F(2*N+1)*(1-t*t))
def source(mode):
 if mode=='uniform':return [(F(-2),F(2),F(1))]
 profile=[(F(0),F(1,4),F(4)),(F(1,4),F(1),F(0))] if mode=='single_packet' else [(F(0),F(1,4),F(3)),(F(1,4),F(1,2),F(1)),(F(1,2),F(1),F(0))]
 return [(a+j,b+j,d) for j in range(-2,2) for a,b,d in profile]
def mass(src,lo,hi):return sum((max(F(0),min(b,hi)-max(a,lo))*d for a,b,d in src),F(0))
def cap(e,y):
 a,b,R=e;return max(F(0),min(b,y+R/2)-max(a,y-R/2))
def J(E,y):return sum((cap(e,y)/e[2] for e in E),F(0))
def future(E,y,K,R):return sum((cap(e,y)/e[2] for e in E if e[2]>K*R),F(0))
def fields():
 return [('initial',[(F(-1),F(-1),F(2)),(F(-1,2),F(0),F(1)),(F(1,4),F(1,2),F(2))],'uniform'),('boundary_stress',[(F(-3,4),F(-1,2),F(1)),(F(-1,4),F(0),F(2)),(F(1,4),F(1,2),F(1))],'single_packet'),('expanded',[(F(-1),F(-1,2),F(2)),(F(-1,2),F(1,2),F(1)),(F(1,2),F(1),F(2))],'two_level_packet')]

def model(name,E,mode):
 before=sum(C.values());src=source(mode);W=mass(src,F(-2),F(2));X=sum(b-a for a,b,R in E);radii=sorted(set(e[2] for e in E));base=sorted(set([F(-2),F(2)]+[z+sgn*R/2 for a,b,R in E for z in [a,b] for sgn in [-1,1]]+[z for a,b,d in src for z in [a,b]]))
 ck('receiver_intervals_disjoint',all(E[i][1]<=E[i+1][0] for i in range(len(E)-1)))
 for a,b,R in E:
  points=sorted(set([a,b]+[z+sgn*R/2 for lo,hi,d in src for z in [lo,hi] for sgn in [-1,1] if a<z+sgn*R/2<b]))
  for u in points:ck('actual_full_source_q_one',mass(src,u-R/2,u+R/2)==R)
 totalJ=F(0)
 for a,b in zip(base,base[1:]):
  y=(a+b)/2;d=next((d for lo,hi,d in src if lo<y<hi),F(0));totalJ+=d*(b-a)*(J(E,a)+J(E,b))/2
 ck('exact_original_fJ_equals_Xq',totalJ==X)
 rows=[]
 for K in [F(5,4),F(3,2)]:
  dl,dh=logbounds(K);Dlo=1+dl;Dhi=1+dh
  for theta in [F(119,3072),F(1,8),F(1,4),F(1,2)]:
   points=set(base)
   for a,b in zip(base,base[1:]):
    for R in radii:
     fa=future(E,a,K,R)-theta*J(E,a);fb=future(E,b,K,R)-theta*J(E,b)
     if fa*fb<0:points.add(a-fa*(b-a)/(fb-fa))
   points=sorted(points);sourceXi=F(0);parts={T:[F(0),F(0),F(0),F(0)] for T in [F(1,2),F(2),F(4)]};segments=[];stats=Counter();maximum=F(0)
   for a,b in zip(points,points[1:]):
    y=(a+b)/2;j=J(E,y);ja=J(E,a);jb=J(E,b);gates={R:future(E,y,K,R)<=theta*j for R in radii};xa=sum(cap(e,a)/e[2] for e in E if gates[e[2]]);xb=sum(cap(e,b)/e[2] for e in E if gates[e[2]]);xm=sum(cap(e,y)/e[2] for e in E if gates[e[2]])
    ck('relative_kernel_affine_with_frozen_gate',xm==(xa+xb)/2)
    ck('relative_sourcewise_envelope',xa<=theta*ja+Dlo and xb<=theta*jb+Dlo)
    ck('relative_kernel_below_original_J',0<=xm<=j)
    if not j:
     ck('zero_J_no_ratio_or_traffic',xm==0 and all(future(E,y,K,R)==0 for R in radii));stats['zero_J_segments']+=1
    for R in radii:
     expected=sum(cap(e,y)/2 for e in E if e[2]==2) if R==1 else F(0)
     ck('terminal_future_full_receiver_field',future(E,y,K,R)==expected)
     diff=future(E,y,K,R)-theta*j
     if diff==0:
      ck('relative_equality_plateau_inclusive',gates[R]);stats['equality_plateaus']+=1
     if gates[R]!=(future(E,a,K,R)<=theta*ja) or gates[R]!=(future(E,b,K,R)<=theta*jb):stats['endpoint_gate_changes']+=1
    layered=F(0)
    for z,r in enumerate(radii):
     ell=1/r-(1/radii[z+1] if z+1<len(radii) else 0);layered+=ell*sum(cap(e,y) for e in E if e[2]<=r and gates[e[2]])
    ck('physical_continuous_layers_plus_b_atom',layered==xm)
    d=next((d for lo,hi,d in src if lo<y<hi),F(0));intXi=(b-a)*(xa+xb)/2;intJ=(b-a)*(ja+jb)/2;sourceXi+=d*intXi;maximum=max(maximum,xa,xb)
    for T,values in parts.items():
     dg=min(d,T);de=max(F(0),d-T);values[0]+=dg*intXi;values[1]+=de*intXi;values[2]+=dg*intJ;values[3]+=de*intJ
    segments.append(dict(lo=str(a),hi=str(b),J_left=str(ja),J_right=str(jb),relative_lowfuture_by_mass={str(R):gates[R] for R in radii},terminal_future_by_mass={str(R):str(future(E,y,K,R)) for R in radii},Xi_left_limit=str(xa),Xi_right_limit=str(xb),source_density=str(d)))
   for y in points:
    j=J(E,y);xi=sum(cap(e,y)/e[2] for e in E if future(E,y,K,e[2])<=theta*j)
    ck('relative_crossing_point_budget',xi<=theta*j+Dlo)
   ck('full_f_relative_source_integral',sourceXi<=theta*X+Dlo*W)
   clips=[]
   for T,(gXi,eXi,gJ,eJ) in parts.items():
    Wg=sum((b-a)*min(d,T) for a,b,d in src);We=sum((b-a)*max(F(0),d-T) for a,b,d in src)
    ck('frozen_clip_excess_full_account',gXi+eXi==sourceXi and gJ+eJ==X and Wg+We==W)
    ck('g_relative_source_budget',gXi<=theta*gJ+Dlo*Wg)
    ck('excess_relative_source_budget',eXi<=theta*eJ+Dlo*We)
    ck('excess_first_moment_epsilon_X',0<=eJ<=X and theta*eJ<=theta*X)
    ck('combined_first_moment_paid_once',theta*(gJ+eJ)==theta*X)
    clips.append(dict(T=str(T),g_mass=str(Wg),excess_mass=str(We),g_Xi_integral=str(gXi),excess_Xi_integral=str(eXi),g_J_integral=str(gJ),excess_J_integral=str(eJ)))
   rows.append(dict(K_diagnostic=str(K),theta=str(theta),Dtop_lower=str(Dlo),Dtop_upper=str(Dhi),Xi_rel_max=str(maximum),source_Xi_integral=str(sourceXi),original_fJ_integral=str(X),source_bound_lower=str(theta*X+Dlo*W),stats=dict(stats),clipped_and_excess=clips,segments=segments))
 eps=F(119,3072);h=F(2)/(eps*F(3,4));maximumJ=max(J(E,y) for y in base);ck('original_n1_root_gate_empty',maximumJ<h)
 return dict(stage=name,source_mode=mode,source_intervals=[list(map(str,e)) for e in src],receiver_intervals=[list(map(str,e)) for e in E],W=str(W),Xq=str(X),q_original='1',Jmax=str(maximumJ),original_n1_root_h=str(h),original_highpast_empty=True,rows=rows,exact_checks=sum(C.values())-before)

def parameters():
 before=sum(C.values());eps=F(119,3072);q=F(3,4);rows=[]
 for n in [1,4,16,64,256,1024,4096]:
  k=isqrt(n);ck('square_root_dimension',k*k==n);h=F(1+k)/(eps*q)
  for theta in [eps,F(1,8),F(1,4),F(1,2)]:
   for Jvalue in [h,h+F(1,16),2*h]:ck('high_J_relative_threshold_above_sqrt_gate',theta*Jvalue>F(k)/q)
  rows.append(dict(n=n,qminus=str(q),epsilon=str(eps),h=str(h),relative_threshold_at_J_equals_h=str(eps*h),sqrt_n_over_qminus=str(F(k)/q),scope='Algebra for theta>=epsilon; original highpast implies J>h, and even J=h suffices for the strict inequality.'))
 Lambda=F(128,119);slot=F(13,3)*eps;outer=2*Lambda;paid=outer*slot;CZplus=paid+F(1,256)
 ck('actual_Lambda_and_slot_arithmetic',slot==F(1547,9216) and outer==F(256,119))
 ck('actual_outer_slot_product',paid==F(13,36))
 ck('actual_CZ_plus_small_source_term',CZplus==F(841,2304))
 return dict(exact_checks=sum(C.values())-before,rows=rows,epsilon=str(eps),Lambda=str(Lambda),slot_13epsilon_over3=str(slot),outer_2Lambda=str(outer),outer_times_slot=str(paid),plus_1over256=str(CZplus),scope='Exact specified coefficient arithmetic only, not numerical proof of the receipts.')

def main():
 models=[model(*f) for f in fields()];p=parameters();out=dict(status='PASS',total_exact_checks=sum(C.values()),check_counts=dict(C),models=models,parameter_checks=p,scope='Actual positive receiver dx with full compact positive-L1 sources, original q/m/J frozen. New relative terminal-future envelope only; no original highpast G or complete history certification. Rational log enclosures; float-free tests.')
 (BASE/'r346_numeric_result.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(status='PASS',total_exact_checks=sum(C.values()),model_checks=[m['exact_checks'] for m in models],parameter_checks=p['exact_checks']),sort_keys=True))
if __name__=='__main__':main()
