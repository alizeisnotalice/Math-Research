# R346 final independent audit

**PASS within the stated contracts.** The relative-terminal-future branch is a genuine positive original-traffic payment. The flow and clock appendices are valid bounded diagnostics and provide no additional root-order payment. No substantive correction to the frozen author files is required. This audit preserves, rather than replaces, the earlier independent screen `/tmp/r346_audit_pre.md`.

Only this audit and its preliminary file were written by this reviewer. No author file, Git state, or numerical output was modified. The primary's full numerical pipelines were not repeated unnecessarily.

## Main theorem: independent screen versus frozen proof

The independent pre-author argument agrees with `/tmp/r346_geometry.md` (1)–(10). At each actual source y, the strict survival U_y(t)=ρ_y{m>t} is decreasing and right-continuous. The measurable threshold s(y)=θJ_b(y) is legitimate. Its quantile τ has U_y(τ)≤s(y); the entire τ atom is in the closed middle mass window, while only m>τ is charged to the strict upper tail. The full first moment of accepted large receivers is bounded by λθJ_b(y)+D_top,n. The middle-window receiver envelope uses actual du, and B^n ell([B,b])=1 keeps the original b atom; it does not insert a new physical atom at the moving window endpoint.

The decisive exact source receipt is

    ∫g J_b=∫_E [∫Q_u g]/m_u du≤|E|≤X_q/q_-,
    ∫f J_b=|E|,

with 0≤g≤f and every q,m,J,source gate and selector still computed from f. Thus the relative low-future original positive branch costs at most (λ/q_-)θX_q+D_top,n∫g. No density cap, receiver posterior replacement, private partition, or altered source field is used.

For θ=ε, the nonzero original high-past gate gives εJ_b>(1+√n)/q_->√n/q_-. Hence the newly unpaid relative-high set is a subset of the former absolute-high set on the actual traffic support. This does not identify terminal upper witnesses with receivers in the current physical prefix. The additional support inequality J_b>h/(1-θ) follows from disjoint past and future sets; no new fee is silently inferred from it.

Clipping is applied first. The exact source split is G[f]=G[g_clip]+G_low-relative[g_ex]+G_high-relative[g_ex]. R344 clipping remains applicable because the full field is frozen. The actual receiver charge before coarse bounding is 3εX_q+λε∫g_ex J_b; after the common-source identity it is (13/3)εX_q. The source costs are C_{ε,n}W+D_top,n W_ex. This replaces the R345 covering slot, and the old D_nW_ex or R342 covering bill is not added again.

The supplied entrance multiplies this slot by 2, giving (26/3)εX_q. With ε=119/3072 and Λ=128/119, its outer coefficient is 13/36. If the historical CZ 1/256 belongs to the same authenticated X account, the combined coefficient is 841/2304, leaving 1463/2304 unallocated. The extra outer cost versus the preceding slot is 1/9; the old 1/4 is not also charged. These are conditional same-account ledger coefficients, not a new authentication of every historical aggregation or an assurance that all remaining fees can be absorbed.

## Clock and conservative-flow checks

Geometry (11) is an exact physical-clock swap: K>λ/q_- implies every small receiver has R_v<R_u, so its prefix gate is automatic once u is active. Upper witnesses have R_w>R_u. The original H-weighted tail T_y(R) retains the full J and terminal atom. Equations (12) split the original traffic by whether a genuine upper witness is present at the old physical r. The delay is nonnegative and must remain.

For full H, the activation radius is r_H and the effective starting radius is r0=max(R_u,r_H). On [r0,b], 1/J_y(r) is nonincreasing. Its weighted upper-tail fraction is at most the unweighted fraction min(1,(r0/R_w)^n), including the b atom. This validates (13) also with late activation; the stronger early-activation bound is used only when J_y(R_u)≥H. On that part, the exact mass-compensated ratio lies between J_y(R_u)/J_b(y) and one, as in (15). No absent occupancy factor or q_w/q_u is discarded.

Core (1)–(3) reconstruct the original positive residual in true du. The outgoing density relative to ρ_y is g(y)q_uω_y(u), 0≤ω≤1. The normalized upper kernel is probability-valued only where its denominator exceeds s. The incoming κ(w) in (3) is relative to actual dw, with the same source y and its own U_y(Km_u) retained. The receiver-center radial envelope yields κ≤A_w/s, without a source density assumption or a 2^n enlargement. Its integrated bound is only O(√n)X_q at the absolute s used there, not an εX_q or source-root payment.

The tilted column (7) includes m_u/m_w. It is not the conserved flow and cannot replace its column bound. The deterministic clock map r'=min((R_w/R_u)r,b) pushes the original tail to the radius-expanded tail with multiplier (R_w/R_u)^n. In particular, the entire old tail [bR_u/R_w,b] collapses to the terminal b atom. Core (9) uses its correct conditional average of the old Ω, including old J and old gates; it does not substitute new-prefix fields. The exact pairwise overlap cancellation (11) is sound, but it does not eliminate summation over all incoming u or the y-dependent denominator.

The auxiliary core was proved with the old absolute upper threshold. It can be applied to the new relative-high residual through the established support inclusion. Its initial and terminal measures are auxiliary transported cost, not a claim that the new large endpoint satisfies the original outside/history/upper gates. The explicit column and terminal-budget warnings in the independent preliminary audit remain necessary for any further iteration. No flow fee is added to the main payment, and no flow conservation identity is treated as an extra paid branch.

## Numerical/code scope and actual evidence

All three frozen scripts and the numerical note/result were read. The primary reports fresh successful execution of 4,022 geometry assertions, 2,481 numerical assertions and 73 flow/clock check units, totaling 6,576. The saved numeric JSON was parsed in this audit and records PASS, the stated 2,481 total, model counts 696/857/834 plus 94 parameter checks, and outer fractions 13/36 and 841/2304. This reviewer did not rerun the full scripts or count source-code reading as execution.

The numeric script uses actual one-dimensional receiver intervals and compact nonuniform periodic source densities. The original hard q=1 is checked at every moving-source-response breakpoint; the response is affine between them. All source and J breakpoints plus every affine relative-gate crossing are inserted. Segment interiors use a frozen gate, crossing points are separately checked inclusively, and zero-J intervals have no division or traffic. Exact affine integration uses the original J for full, clipped, and excess sources. Their source masses and source-J charges add back to the same original account. Rational atanh-series lower log bounds make the tested envelope conservative; there are no floating inequality decisions in these scripts.

These are first-moment/relative-gate fixtures, not nonempty original n=1 root high-past G. The flow fixture uses genuine positive-volume source packets and receiver intervals, diagnostic K and thresholds, but deliberately omits the original outside-center gate. Its mass and b-clock tests therefore are not numerical evidence that the full remaining root residual is paid. Scalar atomic clocks and finite quantiles test algebra, not substituted physical source fields. Earlier independent scratch diagnostics and the 866 exact preliminary assertions remain separate from the primary's 6,576 count.

## Remaining general obligations

The main and ledger correctly retain G_rel[g_ex], with strict lower past >h and terminal future >εJ_b, all original physical/full-J/high-H/far/outside gates. Its general source-integrated joint budget remains unproved. General soft terms, crossing/innovation fees, extreme-scale/height complements, chronological initialization/deletion/future-deleted-source slots, and authenticated outer integration still require their own budgets. The physical b atom is not a chronological history atom; the residual terminal upper mass is not a current prefix. Original negative-square/suffix credit is available only once. This round does not prove the general consistent root-order weak bound or reduce the remaining work to constant/logarithm tuning.

## Frozen SHA256 bindings
- `/tmp/r346_main.md` — `7d50f32f871762c50fb1e063ecb7708f20eb2b26d7783810dc3d0690f7361f6a`
- `/tmp/r346_ledger.md` — `ba2b1d1dcae61ebd8fec467fb525d8adc23b941cd78a1de17626d78100a5cfcc`
- `/tmp/r346_geometry.md` — `54c86eed5a889c94fc6568c455dd43ffd979894b82acf1c2b9772def18d26570`
- `/tmp/r346_core.md` — `6536c1eccf98ab90e7160022f3140e83f505d23010987421fa95cd1c54e604ed`
- `/tmp/r346_numeric.md` — `69b96b2cb27d74e4f8055d0a65ffe058bad2498bc8c4572cff38f08f038c66a7`
- `/tmp/r346_numeric.py` — `d9b5eb23c65bbd2d3a7a164625f482ed3f187fb225da4ad37d10faf62fe9eccc`
- `/tmp/r346_numeric_result.json` — `6e0e24488d2b4415912d7d640d6efb6dbb0f8864947e2775282dfb3863ab1097`
- `/tmp/r346_geometry_checks.py` — `e9cd62e5f4e3b7df1f52dadb6fc14448962d5d52743bd2008c7e774a2c813ec8`
- `/tmp/r346_core_checks.py` — `3e51a7099aaf6b08f0e65d51a93e416c8a991adf0be616a7c2c3d3c01b30358c`
- `/tmp/r346_audit_pre.md` — `964dd8a7268d19aa11558c98e3858858f19aaff65044155c154fa6f4dc21beaa`
- `/tmp/r345_geometry.md` — `7b8af94f0820e5f6c79b75bd2ee0b89647a53effa38599a95d2e148635148f66`
- `/tmp/r344_geometry.md` — `d5b2f2d4468367dc53dbaf927e7cf1be57d1e7f31c777f87c51794a8b9c6b90a`
- `/tmp/r340_core.md` — `f030035399e805bb1a6a5f369d9c499bbf1500f74de02b53471d58107bc3ee90`

R345 geometry was read for the independently screened quantile contract. R344 clipping and R340 original contract were checked for the necessary inherited interfaces; their entire historical derivations were not reaudited this round. The preliminary audit remains an earlier screen, not a hash binding to later author bytes. The present final receipt binds the listed final bytes.
