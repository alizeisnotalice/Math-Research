"""R346 exact flow checks. Root outside gate is not simulated."""
from fractions import Fraction as F

counts={"geometry":0,"normalized_upper":0,"tilted_column":0,"flow":0,"clock":0,"overlap_cancellation":0}
source=[(-F(1,100),F(1,100),F(50)),
        (F(59,100),F(61,100),F(20)),
        (F(104,100),F(106,100),F(30))]
receivers=[(-F(12,100),-F(8,100)),
           (F(18,100),F(22,100)),
           (F(38,100),F(42,100))]
R=[F(1),F(7,5),F(2)]
C=[[1,0,0],[1,1,0],[1,1,1]]
source_mass=[(b-a)*d for a,b,d in source]
vol=[b-a for a,b in receivers]
for u,(left,right) in enumerate(receivers):
    for y,(a,b,d) in enumerate(source):
        if C[u][y]:
            assert right-R[u]/2<=a and b<=left+R[u]/2
        else:
            assert b<=left-R[u]/2 or a>=right+R[u]/2
        counts["geometry"]+=1
m=[sum(source_mass[y]*C[u][y] for y in range(3)) for u in range(3)]
assert m==R and m==[1,F(7,5),2]
assert all(v==F(1,25) for v in vol)
counts["geometry"]+=2
mu=[vol[u]/m[u] for u in range(3)]
K,h,s,qminus=F(11,8),F(1,100),F(1,100),F(3,4)
assert K>1/qminus
rho=[[C[u][y]*mu[u] for u in range(3)] for y in range(3)]
U=[[sum(rho[y][w] for w in range(3) if m[w]>K*m[u]) for u in range(3)] for y in range(3)]
for y in range(3):
    for u in range(3):
        if rho[y][u] and U[y][u]>s:
            total=sum(rho[y][w]/U[y][u] for w in range(3) if m[w]>K*m[u])
            assert total==1
            counts["normalized_upper"]+=1
    for w in range(3):
        tilted=sum((m[u]/m[w])*rho[y][u]/U[y][u] for u in range(3)
                   if m[w]>K*m[u] and U[y][u]>s)
        assert tilted<=1/(K*qminus*s)
        counts["tilted_column"]+=1

# Source packet 0 and middle receiver have both lower and upper occupancy.
lower=sum(rho[0][v] for v in range(3) if m[v]<m[1]/K)
assert lower>h and U[0][1]>s
Jbefore=rho[0][0]+rho[0][1]
Jterminal=sum(rho[0])
Omega_before=(m[1]-m[0])*rho[0][0]/(m[1]*Jbefore)
Omega_terminal=(m[1]-m[0])*rho[0][0]/(m[1]*Jterminal)
assert Omega_before==F(1,6) and Omega_terminal==F(4,31)
clock_integral=Omega_before*(1/R[1]-F(1,2))+Omega_terminal/F(2)
assert clock_integral==F(87,868)
omega=R[1]*clock_integral
outgoing=source_mass[0]*vol[1]*clock_integral
lifted=sum(source_mass[0]*rho[0][1]*omega*rho[0][w]/U[0][1]
           for w in range(3) if m[w]>K*m[1])
assert outgoing==lifted==F(87,21700)
incoming_density=lifted/vol[2]
assert incoming_density==clock_integral
# Here R_w=b: every old continuous time is pushed to the terminal atom.
z=R[2]/R[1]
Omegabar=R[1]*clock_integral
assert 0<=Omegabar<=1
assert z*(F(1,2)*Omegabar)==clock_integral
counts["flow"]+=7

# Exact pushforward tails, including all terminal atoms.
for n in (1,2,4,8):
    Ru=F(1); b=F(2)
    for Rw in (F(5,4),F(3,2),F(2)):
        z=Rw/Ru
        for t in sorted(set((Rw,(Rw+b)/2,b))):
            old_threshold=t/z
            assert old_threshold>=Ru
            assert old_threshold**(-n)==z**n*t**(-n)
            counts["clock"]+=1
        old_atom_preimage=(b/z)**(-n)
        new_atom=z**n*b**(-n)
        assert old_atom_preimage==new_atom
        counts["clock"]+=1

for u in range(3):
    for w in range(3):
        if m[w]<=m[u]: continue
        I=sum(source_mass[y]*C[u][y]*C[w][y] for y in range(3))
        clock_ratio=R[w]/R[u] # n=1 in the actual fixture
        assert clock_ratio*I/m[w]==I/m[u]<=1
        counts["overlap_cancellation"]+=1
print("PASS",counts,"total",sum(counts.values()))
print("Real-dx diagnostic lifted mass =",outgoing,"incoming dw-density =",incoming_density)
print("Diagnostic K=11/8; original root outside-center traffic is not asserted.")
