# R346 — relative terminal-future source window

This checks the new threshold `s(y)=theta J_b(y)` on real positive-volume one-dimensional receiver fields. It does not test general high-past Gout, a full historical selector, or nonempty original root traffic. All original f,q,m,J and terminal receiver measure remain frozen.

## Exact contract and implementation

For the original hard s=0 field with q=lambda=1 and R in {1,2}, let

`J(y)=sum_i |E_i intersect [y-R_i/2,y+R_i/2]|/R_i`,

`U_y(t)=sum_{R_i>t}|E_i intersect [y-R_i/2,y+R_i/2]|/R_i`.

This is the terminal full receiver measure, not an r-prefix. The mass1 endpoint's future is exactly J2(y), the R2 portion of J; mass2's future is zero for K=5/4 or3/2. The tested kernel is

`Xi_rel(y)=sum_i length_i(y)/R_i *1{U_y(KR_i)<=theta J(y)}`.

K is a manageable rational diagnostic, not e^sqrt(n). Theta is 119/3072,1/8,1/4,1/2. The code constructs all original J/source breakpoints, then every affine crossing `J2-theta J=0`. Within each open piece, it freezes the gate before exact affine integration. At all crossing points it separately uses the actual inclusive gate; equality points are not lost through an arbitrary one-sided assignment. Zero-J pieces are explicitly recorded with Xi=0 and no division by J. The physical clock is also checked: the effective [1,2) continuous weight is integral r^-2 dr=1/2 and the separate terminal atom at2 has weight1/2. There is no clock atom at1.

For the sharper actual q=lambda=1 contract, verify pointwise and after source integration

`Xi_rel <= theta J + Dtop`, `Dtop=1+log K`.

The code encloses log K outward with rational atanh series and uses the lower bound Dtop_lower to establish the true inequality. Every comparison is Fraction arithmetic, with no floating-point test. The data retain every exact segment and source density.

## Actual positive-L1 fields

The fixtures retain the same physical ideas as R345, copied self-contained:

| Stage | receiver intervals with assigned R | full source f on [-2,2] |
|---|---|---|
|initial|[-1,-1],R2 (zero measure); [-1/2,0],R1; [1/4,1/2],R2|uniform density1|
|boundary stress|[-3/4,-1/2],R1; [-1/4,0],R2; [1/4,1/2],R1|each unit period: density4 on first quarter, else0|
|expanded|[-1,-1/2],R2; [-1/2,1/2],R1; [1/2,1],R2|each period: density3 on first quarter,1 on second quarter,else0|

There are four unit periods, each mass1, so W=4. Every hard interval stays in [-2,2]. Intervals of sides 1 and 2 integrate exactly one and two full unit periods; independently, all breakpoints of the moving full-source response are checked to certify q=1 for every u in a receiver interval. This is not a finite receiver quadrature. The zero-measure receiver contributes no J or future traffic.

The full-source first moment is integrated exactly and equals the actual receiver expense:

`integral f J = Xq = |E|`, respectively 3/4,3/4,2.

For g=min(f,T), excess e=(f-T)_+, T=1/2,2,4, the same original Xi and J are retained. The code checks

`integral g Xi <= theta integral g J + Dtop integral g`,

and the analogous excess budget. Also `integral gJ + integral eJ=Xq`, `theta integral eJ<=theta Xq`, and the combined first-moment charge is exactly `theta Xq`, so clipping does not silently charge two copies of that expense. Source masses and Xi integrals add back to the full original f exactly.

## Actual results

Two independent fresh processes passed **2,481 exact rational checks**: 696/857/834 in the three actual models and94 parameter/ledger checks. The count includes outward rational log bounds, not exact evaluation of logarithms. There are no floating-point inequality comparisons.

For K=5/4 (K=3/2 gives the same gate here because there are only two masses):

| Stage | theta | Xi_rel max | exact integral f Xi_rel |
|---|---:|---:|---:|
|initial|119/3072|256/905|67690009/235879200|
|initial|1/8|2/5|249/800|
|initial|1/4|5/8|87/128|
|initial|1/2|5/8|95/128|
|boundary stress|119/3072,1/8,1/4|1/8|1/4|
|boundary stress|1/2|3/8|3/4|
|expanded|119/3072,1/8,1/4|1/2|1|
|expanded|1/2|3/2|61/32|

The actual relative gate has positive-source effects and exact threshold crossings. It is not merely a relabeling of the previous fixed-s result. However the source-row budget is not claimed sharp, and the two-mass field does not explore general K-dependence. Original n1 root h=2/(epsilon qminus), epsilon119/3072, qminus3/4, exceeds J throughout all fields, so original high-past traffic remains empty.

## Root and ledger arithmetic

For n1,4,16,64,256,1024,4096, put k=sqrt(n), qminus=3/4 and h=(1+k)/(epsilon qminus). At theta>=epsilon and J>=h,

`theta J >= (1+k)/qminus > k/qminus`.

The code tests the equality boundary J=h and two larger rational J values for all four theta choices. This is an algebraic interface check; it does not claim these large J values occur in the one-dimensional fixtures.

The fixed ledger factors are computed with their actual meanings:

`epsilon=119/3072`, `Lambda=128/119`,

`slot=(13/3)epsilon=1547/9216`, `2Lambda=256/119`,

`2Lambda*slot=13/36`, `13/36+1/256=841/2304`.

In particular, 13/36 is the product **after** multiplying the slot, not the value of 2Lambda. These exact arithmetic checks do not prove the analytic receipts that supply the slot.

## Reproduction

Only `r346_numeric.py`, `r346_numeric_result.json`, and this note are needed. Standard library, no old /tmp imports, external source, or optimizer:

```sh
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 /path/to/r346_numeric.py
```

The JSON is written beside the script and records all sources, receivers, crossing segments, zero-J counts, clipped/excess integrals, and exact root/ledger parameters.
