# 第346轮完整替换总账

原hard合同及历史入口按既有记录承接，不声称本轮重新认证所有历史归约。W=W_beta=∫f，ν≤f dx，W_nu=ν(Rⁿ)，Xq=∫E q_u du≤X=λ|E|，A_n=1+nlog(b/a)。
\[
T_{\rm entrance}\le8\lambda HW+2d_{\rm eff}A_nW_\nu/H+2B_H.
\]
保持ε=119/3072及所有原门，
\[
C_{\varepsilon,n}=\frac\lambda{q_-}[(2+3\sqrt n+2e^{-\sqrt n})/\varepsilon+1+\sqrt n],
\quad C_{\rm top,n}=1+\sqrt n+\log(4/3).
\]

冻结完整f，令g_ex=(f−T_clip)_+、W_ex=∫g_ex、T_clip=q_-n/(C_(4/3)^4 ε³)。本轮θ=ε，相对上尾新余项G_rel是在原G中另加U_y(Km_u)>εJ_b(y)，只外来源换成g_ex。

精确付款槽
\[
B_H\le G_{\rm rel}[g_{\rm ex}]+3\varepsilon X_q
+\lambda\varepsilon\int g_{\rm ex}J_b+C_{\varepsilon,n}W+C_{\rm top,n}W_{\rm ex}
\]
由∫g_exJ_b≤|E|≤Xq/q_-得到
\[
B_H\le G_{\rm rel}[g_{\rm ex}]+\tfrac{13}{3}\varepsilon X_q
+C_{\varepsilon,n}W+C_{\rm top,n}W_{\rm ex}.
\]
此式替换第345轮同槽，不再次累加旧覆盖费或旧D_nW_ex。新增接收费用是(4/3)εXq，来源系数从D_n降为C_top,n；新的剩余域严格要求相对高质量捕获比例。

原入口据此为
\[
T_{\rm entrance}\le8\lambda HW+2d_{\rm eff}A_nW_\nu/H
+2G_{\rm rel}[g_{\rm ex}]+\tfrac{26}{3}\varepsilon X_q
+2C_{\varepsilon,n}W+2C_{\rm top,n}W_{\rm ex}.
\]
历史外乘Λ=128/119给Λ(26/3)ε=13/36。若历史CZ的1/256属于已认证的同一X外账，合计841/2304，剩1463/2304未分配。相较345额外外账费用1/9，不能把旧1/4再与新13/36叠加。没有以剩余吸收空间认定其他项已付。

一般θ形式的槽费为3ε+(λ/q_-)θ；此轮只选θ=ε，不优化或提前承诺别的吸收分配。

未付清单：

1. G_rel的真实双侧捕获与超截断来源联合交通；终端高质量捕获可能在当前半径之后，时钟延迟、接收列拥挤及负信用尚无可吸收总预算。
2. 一般软密集C_H−S_H、越阈I_H、hard合同外的质量可比重尾交通及其他未嵌入hard项。
3. 宽距离、低pe、极端尺度比与全部阈值补集；高度折扣、逆尺度比费用并存。
4. 历史初始I_time、删除跳跃J_time、未来被删来源D_time独立留账；物理b原子不替代它们。
5. 后缀P/Phi_next负信用只用一次；H、层、物理尺度、来源、外积分及极限费用不自动求和。

辅助同源转移和延迟公式均未新增付款。一般一致n^(1/2+o(1))上界仍未闭合，不能认为只剩常数和对数优化。
