# R345 — A terminal future-occupancy cap pays an expanded original branch

The new payment is a source-dependent covering theorem for the actual receiver measure. It replaces the R342 local-growth covering fee and combines with R344 source clipping. It does not pay the remaining two-sided high-occupancy traffic or prove a general root-order weak-(1,1) bound.

## Contract and theorem

Keep the full original field f≥0 in L¹, W=∫f, finite Lebesgue receiver set E, a≤R_u≤b≤2a, m_u=∫Q_u f=q_uR_uⁿ, q_-=3λ/4≤q_u≤λ, and dμ(u)=du/m_u. Write c_u(y)=1Q_u(y), E_r={R_u≤r}, J_y(r)=∫E_r c_u dμ. The original clock is

    ell=b^(-n)δ_b+n r^(-n-1)dr on [a,b],
    ell([R,b])=R^(-n), including both endpoints.

Let K=e^(√n), h=(1+√n)/(εq_-), α=(1+√n)^(1/n), and Z_y(t-)=∫E c_v(y)1(m_v<t)dμ(v). Define the terminal finite capture measure and its strict upper mass tail by

    ρ_y(du)=c_u(y)dμ(u),    J_b(y)=ρ_y(E),
    U_y(t)=ρ_y{u:m_u>t}.

For any s≥0 use the measurable source–receiver gate

    B_s(y,u)={U_y(Km_u)≤s},    B_s^c(y,u)={U_y(Km_u)>s}.

For any nonnegative g≤f, all quantities above remain computed from f. Define G_B[g] as the original traffic with only outer source factor g and extra gate B(y,u):

    G_B[g]=∫ell(dr)∫dy g(y) 1(J_y(r)≥H)/J_y(r)
       ×∫∫_{E_r²} c_u(y)c_v(y)(m_u-m_v)1(m_u>Km_v)
          1(Z_y(m_u/K-)>h)1(||u-v||∞>αR_u/2)
          1_B(y,u)dμ(u)dμ(v).

Zero-J rows are zero. No original pair, high-past, outside-center, denominator, or physical-clock field is reset.

The new estimate is

    G_{B_s}[g] ≤ [λs+1+log(λK/q_-)] ∫g.                 (1)

In fact the same bound holds for the larger source-dependent first moment:

    ∫dy g(y)∫E c_u(y)R_u^(-n)1_{B_s}(y,u)du
       ≤ [λs+1+log(λK/q_-)] ∫g.                       (2)

For s=√n/q_-, the coefficient is

    D_n=1+log(4/3)+(7/3)√n.                           (3)

This costs no receiver absorption. The proof of (2) does not use high past. Its usefulness for the hard traffic is that the exact complementary branch now has substantial actual capture both below and above its large-endpoint mass.

## Measurable quantile with exact atom conventions

The uniform mass bounds are

    0<m0=q_-aⁿ≤m_u≤m1=λbⁿ.

Because E has finite measure and m_u≥m0, each ρ_y is finite. The function (y,t)↦U_y(t) is measurable by Tonelli, and t↦U_y(t) is decreasing and right-continuous. Right-continuity follows from {m>t_j} increasing to {m>t} when t_j decreases to t. Define

    τ(y)=inf{t≥m0:U_y(t)≤s}.                          (4)

The set is nonempty because U_y(m1)=0, so m0≤τ≤m1. Monotonicity and right-continuity give

    U_y(τ(y))≤s.                                     (5)

For example, choose a decreasing sequence of points in the upper ray {U≤s} tending to its infimum and use continuity from below of the finite measure. The threshold includes its atom in the middle interval; (5) bounds only the strict upper tail.

Measurability is immediate from rational thresholds: for every t>m0,

    {τ<t}=⋃_{r∈Q, m0<r<t}{U_y(r)≤s}.

For t≤m0 the left set is empty. The formula follows since every point strictly above τ lies in the upper ray. Thus all source-dependent gates below are jointly measurable.

Since Km_u≥m0, membership in B_s implies

    Km_u≥τ(y), or equivalently m_u≥τ(y)/K.            (6)

Consequently the accepted endpoints lie in the disjoint union of

    strict upper tail: m_u>τ(y),
    closed middle window: τ(y)/K≤m_u≤τ(y).            (7)

This remains correct when J_b≤s: then τ=m0, and one can alternatively pay the entire row directly by λJ_b≤λs. The proof below works without separating that case. In particular there is no missing mass at m0 or at τ.

## The strict upper tail is paid using the complete original clock

First bound an original small-endpoint row by the full original J:

    (1/J_y(r))∫_{E_r} c_v(m_u-m_v)[original gates]dμ(v)
       ≤m_u.

After multiplication by c_u dμ(u), this leaves c_u du. Tonelli and the inclusive clock tail therefore bound any masked original source row by

    ∫E c_u(y)R_u^(-n)1_B(y,u)du.                      (8)

For the upper-tail piece of (7), use R_u^(-n)du=q_u dμ(u):

    ∫E c_u R_u^(-n)1(m_u>τ)du
       =∫E q_u1(m_u>τ)dρ_y
       ≤λU_y(τ)≤λs.                                 (9)

This is a bound in actual receiver measure with the physical tail already integrated. No posterior source distribution is introduced, and no future receiver is inserted into J_y(r).

## A source-dependent mass window is legitimate

For each fixed y, τ(y)>0 is a scalar. The middle window in (7) forces the actual radii into

    A(y)=max(a,(τ(y)/(Kλ))^(1/n)),
    B(y)=min(b,(τ(y)/q_-)^(1/n)).

An empty interval contributes zero. Otherwise let V_y(r) be the actual Lebesgue volume of centers u in this window with R_u≤r and y∈Q_u. Since such u lie in the cube of side r centered at y,

    V_y(r)=0 for r<A,
    V_y(r)≤rⁿ for A≤r<B,
    V_y(r)≤Bⁿ for B≤r≤b.

Integrate against the original ell:

    ∫ell(dr)V_y(r)
       ≤n∫_A^B dr/r+Bⁿell([B,b])
       =n log(B/A)+1
       ≤1+log(λK/q_-).                              (10)

The terminal contribution is exactly one because

    Bⁿ[b^(-n)+n∫_B^b r^(-n-1)dr]=1.

It is the original b atom and original continuous tail, not a new atom at B. Formula (10) includes A=B and boundary radii a or b. The factor λ/q_- occurs only inside the logarithm in this window term.

The proof is pointwise in y, so the window endpoints may depend measurably on y. Integrating (9),(10) against any g≥0 proves (2), and (8) gives (1). In particular, no common source partition, private source partition, density cap, or favorable component decomposition is assumed. The statement only needs g≤f to identify it as a positive portion of the original traffic.

## Zero future and the actual essential maximum

As a limiting special case, s=0 gives a smaller source fee

    C_top,n=1+√n+log(4/3).

Let Mmax(y) be the essential supremum of m_u under the actual measure c_u(y)du, with value zero when that measure is zero. The same essential supremum is obtained under ρ_y, since m0≤m_u≤m1. It is measurable, since for t≥0,

    {Mmax>t}={∫E c_u(y)1(m_u>t)du>0}.

Except for the zero-capture case, U_y(Km_u)=0 is precisely Km_u≥Mmax(y). Thus the sourcewise top window m_u≥Mmax(y)/K is paid by C_top,n∫g. Essential-supremum inequalities hold for almost every capturing receiver at each y; Tonelli transfers those null sets to the full source–receiver integral. This is not a statement about every point representative of E.

The positive-s theorem (1) is stronger as a covered branch: it allows a terminal upper tail of actual μ-mass as large as s rather than requiring it to vanish.

## Relation to the R342 paid branch and the new residual

For n≥4, suppose u is an old R342 good endpoint:

    m_u≥K^(-1)∫Q_{(1+√n)b}(u) f.

If u and w both capture y, then every z∈Q_w satisfies

    ||z-u||∞≤R_w/2+R_w/2+R_u/2≤3b/2.

Therefore Q_w⊂Q_{3b}(u)⊂Q_{(1+√n)b}(u), so

    m_w≤∫Q_{(1+√n)b}(u)f≤Km_u.

Hence U_y(Km_u)=0 and every such contribution belongs to B_s. The new paid source–receiver branch contains the entire former good-endpoint branch. Consequently B_s^c contributions are a subset of the R342 localbad contributions for n≥4.

For n≤3, at the actual ledger parameter ε=119/3072 (indeed whenever ε≤1/2), the original high-past gate is empty: the established cap J_b≤[1+n log(b/a)]/q_- is strictly below h. This claim is restricted to that parameter range; it is not asserted for every ε<1. Thus, at the prescribed ledger parameters, the new residual is contained in the previous R344 residual in every dimension.

Every nonzero new residual pair has the exact two-sided occupancy conditions

    ρ_y{v:m_v<m_u/K}>h,
    ρ_y{w:m_w>Km_u}>√n/q_-.                          (11)

All these are real receivers capturing the same y. Their masses satisfy m_w>K m_u>K²m_v. Since K>λ/q_-, their radii satisfy R_v<R_u<R_w. The lower receivers therefore already belong to E_r whenever u does, but the upper receivers may lie beyond the current r. Equation (11) does not permit replacing the terminal upper tail by a prefix upper tail or enlarging the original denominator J_y(r).

The new upper condition supplies quantitative capture μ-mass, unlike merely asserting existence of a larger witness. No general source-integrated budget for this two-sided condition has been proved here. In particular, its upper mass is not a disposable source-entropy or negative-credit fee.

## Clipping first gives the full replacement ledger

Use the R344 verified fixed-exponent constant C=C_{4/3}, independent of n, and retain

    T=q_-n/(C⁴ε³),
    g_clip=min(f,T),    g_ex=(f-T)_+,
    W_ex=∫g_ex≤W.

All geometry and gates remain the full-f ones. R344 applied to the full original endpoint field gives G[g_clip]≤εX_q. The source split followed by the new future split is the exact identity

    G[f]=G[g_clip]+G_{B_s}[g_ex]+G_{B_s^c}[g_ex].       (12)

Use s=√n/q_- in (1). Then

    G[f]≤εX_q+D_n W_ex+G_{B_s^c}[g_ex].              (13)

This pays the new branch using the actual excess-source mass; charging D_nW instead is a valid but weaker consequence. There is no additional R342 covering fee and no duplicated clipped-source fee.

With the unchanged R338 coefficient

    C_{ε,n}=(λ/q_-)[(2+3√n+2e^(-√n))/ε+1+√n],

its original hard slot becomes

    B_H(f,ν)≤G_{B_s^c}[g_ex]+3εX_q+C_{ε,n}W+D_nW_ex. (14)

Inserting this into the supplied entrance gives

    T_*≤8λH W_β+2d_eff A_n W_ν/H
         +2G_{B_s^c}[g_ex]+6εX_q
         +2C_{ε,n}W+2D_nW_ex.                        (15)

Mass labels in a larger historical ledger must refer to this same frozen input; (15) does not identify unrelated source measures. The receiver coefficient remains 6ε. For ε=119/3072 and the supplied outer multiplier 128/119, it is 1/4. If the historical CZ fee 1/256 is in the same certified receiver ledger, the combined fee is 65/256 and 191/256 remains unallocated. Other historical or extreme-scale slots are unchanged.

The remaining term is precisely original far/high-past/outside-center traffic with source g_ex and the additional terminal-future condition in (11). Its quantitative two-sided capture structure is a genuine strengthening of the residual. A root-order estimate for that term remains unproved.

## Actually run checks

`python3 /tmp/r345_geometry_checks.py` passed 5,190 exact Fraction assertions. These test strict upper tails and quantile atoms for finite scalar measures, mass-window membership, the inclusive clock-tail identity, and ledger arithmetic. The scalar measures are diagnostics and are not surrogate receiver models used in the proof.

The script also uses an actual one-dimensional receiver fixture: f=1 on [-4,4], E=[-1,0] with R=1 and E=[0,1] with R=2. Both actual q values equal one. For diagnostic K=3/2 and s=1/4, direct integration of capture lengths gives covered first moment 3/2 and complementary first moment 1/2, out of total 2. At s=0 the covered first moment is 9/8. These integrals use whole receiver intervals with exact du. The fixture does not satisfy the original root high-past gate and is not a numerical evaluation of hard G. The general theorem is proved analytically above; the checks certify only the stated finite algebra and integration calculations.
