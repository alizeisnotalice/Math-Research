"""Exact diagnostics for relative quantiles, source integration and clock delay."""
from fractions import Fraction as F
from itertools import product
N=0

def check(x):
    global N
    assert x
    N+=1

# Source-dependent threshold delta times total terminal occupancy.
for masses in [(F(1),F(2)),(F(1),F(3,2),F(3)),(F(1),F(1),F(4))]:
    for weights in product((F(1,4),F(1),F(3,2)),repeat=len(masses)):
        J=sum(weights)
        U=lambda t:sum((w for m,w in zip(masses,weights) if m>t),F(0))
        for delta in (F(0),F(1,100),F(119,3072),F(1,4),F(1,2)):
            s=delta*J
            tau=min(t for t in sorted(set(masses)) if U(t)<=s)
            check(U(tau)<=s)
            for K in (F(3,2),F(2),F(3)):
                for m in masses:
                    if U(K*m)<=s:
                        check(K*m>=tau)
                        check(m>tau or tau/K<=m<=tau)

# Real 1-D receiver fixture: f=1[-4,4], E_small=[-1,0],R=1;
# E_large=[0,1],R=2, so q=1 for all actual receivers.
def overlap(y,l,r,R):return max(F(0),min(r,y+R/2)-max(l,y-R/2))
def ls(y):return overlap(y,F(-1),F(0),F(1))
def ll(y):return overlap(y,F(0),F(1),F(2))
def J(y):return ls(y)+ll(y)/2
def integ(fn,points):return sum(((r-l)*(fn(l)+fn(r))/2 for l,r in zip(points,points[1:])),F(0))
check(integ(J,list(map(F,[-2]))+[F(-3,2),F(-1),F(-1,2),F(0),F(1,2),F(1),F(2)])==2)
check(integ(J,[F(-1),F(-1,2),F(0)])==1)
# K=3/2, delta=1/4: the small endpoint is accepted exactly up to y=-2/5.
for y in (F(-5,4),F(-3,4),F(-1,2),F(-2,5),F(-1,10),F(1,4)):
    check((ll(y)/2<=J(y)/4)==(y<=F(-2,5)))
paid_small=integ(ls,[F(-3,2),F(-1,2),F(-2,5)])
check(paid_small==F(119,200))
check(1+paid_small==F(319,200))
check(2-(1+paid_small)==F(81,200))

# Scalar clock diagnostic with exact b atom and step-function occupancy.
radii=[F(1),F(5,4),F(3,2),F(2)]
values=[F(2),F(3),F(5),F(7)]
for n in (1,2,3,4,8):
    for H in (F(1),F(4),F(6)):
        rH=next(r for r,j in zip(radii,values) if j>=H)
        def tail(R):
            total=radii[-1]**(-n)/values[-1]
            for i,(l,r) in enumerate(zip(radii,radii[1:])):
                l=max(l,R)
                if l<r and values[i]>=H:
                    total+=(l**(-n)-r**(-n))/values[i]
            return total
        for i,Ru in enumerate(radii):
            for j in range(i+1,len(radii)):
                Rw=radii[j]; r0=max(Ru,rH)
                ratio=tail(Rw)/tail(Ru)
                check(ratio<=min(F(1),(r0/Rw)**n))
                check(tail(Ru)==tail(Rw)+(tail(Ru)-tail(Rw)))
                if values[i]>=H:
                    compensated=(Rw/Ru)**n*ratio
                    check(values[i]/values[-1]<=compensated<=1)

# Receiver ledger and exact inclusion threshold arithmetic.
eps=F(119,3072); outer=F(128,119)
check(F(2)+1+F(4,3)==F(13,3))
check(2*outer*F(13,3)*eps==F(13,36))
check(F(13,36)+F(1,256)==F(841,2304))
check(1-F(841,2304)==F(1463,2304))
for root in (F(1),F(2),F(3),F(4),F(10)):
    q=F(3,4); h=(1+root)/(eps*q)
    check(eps*h>root/q)
print(f'PASS: {N} exact Fraction assertions. Relative-tail algebra, actual 1-D first moments, scalar clock diagnostics and ledger; not a hard-traffic simulation.')
