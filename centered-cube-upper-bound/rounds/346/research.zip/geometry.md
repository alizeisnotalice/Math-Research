# R346 — Relative future occupancy is paid by the exact source–receiver identity

The main result expands the R345 paid branch from an absolute terminal upper-tail cap to a fixed fraction of the actual terminal capture measure. Its extra cost is a quantified receiver fee, obtained by integrating the true source field. The new residual still has no general root-order budget. A separate exact clock decomposition records the cost of transferring that residual to future witnesses.

## Frozen original contract

Use precisely the R345 field: f≥0 in L¹, W=∫f, actual finite Lebesgue receiver set E, a≤R_u≤b≤2a, m_u=∫Q_u f=q_uR_uⁿ, q_-=3λ/4≤q_u≤λ, dμ=du/m_u, c_u(y)=1Q_u(y), E_r={R_u≤r}. Write

    ρ_y(du)=c_u(y)dμ(u),  J_y(r)=ρ_y(E_r),  J_b(y)=J_y(b),
    U_y(t)=ρ_y{u:m_u>t},  Z_y(t-)=ρ_y{u:m_u<t}.

The original parameters are K=e^(√n), h=(1+√n)/(εq_-), α=(1+√n)^(1/n). The original physical clock is

    ell=b^(-n)δ_b+n r^(-n-1)dr on [a,b],
    ell([R,b])=R^(-n).

G_B[g] denotes the exact R345 traffic with outer source g≤f and additional source–large-endpoint mask B(y,u). It retains 1(J_y(r)≥H)/J_y(r), the two original endpoints in E_r, c_uc_v(m_u-m_v), m_u>Km_v, Z_y(m_u/K-)>h, ||u-v||∞>αR_u/2, actual dμ_u dμ_v, dy and ell. Zero-J rows are zero. All m,q,J,U,Z and gates remain computed from f, even after splitting g.

## General relative-cap payment

Fix 0<θ<1 and define

    B_θ(y,u)={U_y(Km_u)≤θJ_b(y)},
    B_θ^c(y,u)={U_y(Km_u)>θJ_b(y)},
    D_top,n=1+log(λK/q_-)=1+√n+log(4/3).

For every 0≤g≤f,

    G_{B_θ}[g]
      ≤λθ∫g(y)J_b(y)dy+D_top,n∫g
      ≤(λ/q_-)θX_q+D_top,n∫g.                    (1)

The first bound retains the actual captured mass of g and may be sharper. As in R345, it also bounds the full source-dependent first moment

    ∫g(y)∫E c_u(y)R_u^(-n)1_{B_θ}(y,u)du dy.      (2)

Thus the payment is not inferred from the small volume of a source region. It follows from an exact source–receiver identity with the original density f.

## Proof: variable threshold and a genuine source-integrated fee

Let m0=q_-aⁿ, m1=λbⁿ and s(y)=θJ_b(y). Both J_b and s are measurable and finite. The strict upper tail U_y(t) is jointly measurable, decreasing and right-continuous in t. Define

    τ(y)=inf{t≥m0:U_y(t)≤s(y)}∈[m0,m1].

Right-continuity gives U_y(τ(y))≤s(y). For t>m0 its sublevel set is

    {τ<t}=⋃_{r∈Q, m0<r<t}{U_y(r)≤s(y)},

so τ is measurable. This proof is unchanged when the threshold depends on y; it uses no uniform threshold choice and no private source partition.

If U_y(Km_u)≤s(y), then m_u≥τ(y)/K. Split accepted endpoints into the strict tail m_u>τ and the closed window τ/K≤m_u≤τ. For the strict tail, the inclusive physical clock gives the pointwise source-row bound

    ∫E c_u R_u^(-n)1(m_u>τ)du
       =∫ q_u1(m_u>τ)dρ_y
       ≤λU_y(τ)≤λθJ_b(y).                       (3)

The atom at m_u=τ belongs to the middle window, not the strict tail. For that window the radii lie between

    A=max(a,(τ/(Kλ))^(1/n)), B=min(b,(τ/q_-)^(1/n)).

Actual capturing center volume is zero before A, at most rⁿ between A and B, and at most Bⁿ after B. Its entire clock integral is consequently

    n log(B/A)+Bⁿell([B,b])
       =1+n log(B/A)≤1+log(λK/q_-)=D_top,n.        (4)

An empty window contributes zero. Formula (4) includes A=B and the original b atom; Bⁿell([B,b])=1. It is valid pointwise in y for this measurable source-dependent window.

As before, the original small-endpoint row divided by full J is at most m_u. Cancelling m_u against dμ(u), and then integrating the physical tail, bounds G by (2). Integrating (3),(4) against g proves the first inequality in (1).

Crucially, its apparently unbounded source factor J_b has the exact integrated receipt

    ∫g(y)J_b(y)dy
      =∫E [m_u^(-1)∫Q_u g(y)dy]du
      ≤∫E [m_u^(-1)∫Q_u f(y)dy]du
      =|E|≤X_q/q_-.                              (5)

These are actual du and dy integrals, justified by Tonelli. Equality holds in the middle when g=f. For general g≤f the inner bracket is its true captured source fraction; no independent posterior replaces the actual source. This proves the second inequality in (1).

## Expansion over R345 and exact remaining structure

Any nonzero original high-past contribution has

    J_b≥J_y(r)≥Z_y(m_u/K-)>h.

If θ≥ε, then

    θJ_b≥εJ_b>(1+√n)/q_->√n/q_-.

Therefore the absolute low-future branch paid in R345 is contained in B_θ on the support of the original traffic. At θ=ε the new residual is a subset of the R345 residual, including the same excess-source restriction. This comparison does not claim an inclusion away from the original high-past support.

Every remaining pair now has

    ρ_y{v:m_v<m_u/K}>h,
    ρ_y{w:m_w>Km_u}>θJ_b(y).                     (6)

The upper witnesses constitute a fixed positive fraction of the actual terminal capture measure. The two sets in (6) are disjoint, so additionally J_b>h/(1-θ). This last support condition is recorded without claiming another fee or optimizing the source clip.

For each upper witness, m_w>Km_u>K²m_v and R_w>R_u>R_v, since K>λ/q_-. Upper witnesses may still lie beyond the current physical r. Relative terminal occupancy is not relative prefix occupancy, and (6) does not permit modifying the original J_y(r).

## Full replacement ledger

Retain the R344 proved clip, with its dimension-independent fixed-exponent maximal norm C=C_{4/3}:

    T=q_-n/(C⁴ε³),  g_clip=min(f,T),
    g_ex=(f-T)_+,   W_ex=∫g_ex≤W.

The R344 receipt is G[g_clip]≤εX_q, with the full original field frozen. The exact split is

    G[f]=G[g_clip]+G_{B_θ}[g_ex]+G_{B_θ^c}[g_ex].

Consequently

    G[f]≤G_{B_θ^c}[g_ex]+[ε+(λ/q_-)θ]X_q
                              +D_top,n W_ex.     (7)

Keeping the unchanged R338 coefficient C_{ε,n} from the R345 ledger, the complete hard slot becomes

    B_H≤G_{B_θ^c}[g_ex]+[3ε+(λ/q_-)θ]X_q
                              +C_{ε,n}W+D_top,nW_ex. (8)

This replaces the R345 low-future fee; the old D_nW_ex and R342 coverage fee are not added again. The exact refined receiver fee in (8) is 3εX_q+λθ∫g_ex J_b before applying (5).

Choose θ=ε, without further constant optimization. Since λ/q_-=4/3,

    B_H≤G_rel[g_ex]+(13/3)εX_q+C_{ε,n}W+D_top,nW_ex. (9)

Here G_rel is exactly the original hard traffic with U_y(Km_u)>εJ_b(y). Inserting (9) into the unchanged entrance yields

    T_entrance≤8λHW+2d_eff A_nW_ν/H+2G_rel[g_ex]
                +(26/3)εX_q+2C_{ε,n}W+2D_top,nW_ex. (10)

At ε=119/3072 and external multiplier Λ=128/119 the receiver coefficient is 13/36. If the historical CZ fee 1/256 belongs to the same certified receiver ledger, the sum is 841/2304; 1463/2304 remains unallocated. These numbers do not pay any other slot. All other unresolved items in the R345 ledger remain unresolved.

## Auxiliary exact clock identity and its quantified delay

The following applies to the actual new residual (or any of the earlier positive source-dependent masks). It records the cost of trying to replace terminal witnesses by witnesses already present in the current physical prefix.

Put

    T_y(R)=∫_[R,b] [1(J_y(r)≥H)/J_y(r)]ell(dr),
    S_y(u)=∫ρ_y(dv)(m_u-m_v)1(m_v<m_u/K)
                              1(||u-v||∞>αR_u/2),
    A_y(u)=1(Z_y(m_u/K-)>h)1(U_y(Km_u)>θJ_b(y)).

For a nonzero integrand, all v in S_y(u) have R_v<R_u. Thus the original physical-radius integral is exactly

    G_rel[g]=∫g(y)∫ρ_y(du) A_y(u)S_y(u)T_y(R_u)dy. (11)

There is no changed denominator or lost endpoint atom in (11). On A=1 define the actual upper-witness probability

    π_y(u,dw)=1(m_w>Km_u)ρ_y(dw)/U_y(Km_u).

It is supported on real receivers capturing the same source y. It is only a disintegration of the original terminal witness measure; it does not change the source distribution. Then

    G_rel[g]=L[g]+D[g],
    L[g]=∫g∫ρ_y(du)AS∫π_y(u,dw)T_y(R_w),
    D[g]=∫g∫ρ_y(du)AS∫π_y(u,dw)[T_y(R_u)-T_y(R_w)]. (12)

Both terms are nonnegative. In the original r integral, L is precisely the original traffic multiplied by

    ρ_y{w:m_w>Km_u, R_w≤r}/U_y(Km_u),

and D uses the complementary fraction with R_w>r. Thus (12) is the exact actual-transport leakage, rather than a cube-boundary probability.

For each y with J_b≥H, define r_H(y)=inf{r∈[a,b]:J_y(r)≥H}. Right-continuity of the actual receiver distribution function makes this threshold attained and measurable. Set r0=max(R_u,r_H). After r0 the function 1/J_y(r) is nonincreasing. Comparing its average on an upper tail with its average on the entire physical interval gives

    T_y(R_w)/T_y(R_u)
       ≤min{1,(r0/R_w)ⁿ}
       ≤min{1,[λ/(Kq_-)](r0/R_u)ⁿ}.              (13)

Indeed the unweighted clock-tail ratio is exactly (r0/R_w)ⁿ when R_w>r0, including the b atom, and weighting by a nonincreasing function can only decrease that ratio. The second inequality uses m_w>Km_u and q_-≤q≤λ. Rows with no H activation have zero traffic and need no ratio.

In particular, on the early-activation part J_y(R_u)≥H, (13) gives

    D_active[g]≥[1-λ/(Kq_-)]G_active[g].           (14)

Thus ordinary positive clock transfer cannot discard its delay as a small error on that part. This is an inequality for the original accepted traffic, not a counterexample construction.

Mass compensation cancels the physical scale factor but leaves a genuine occupancy ratio. On the same early-activation part, put a_uw=(R_w/R_u)ⁿ. Direct bounds on the reciprocal occupancy and (13) give

    J_y(R_u)/J_b(y)
       ≤a_uw T_y(R_w)/T_y(R_u)≤1,
    m_w/m_u=(q_w/q_u)a_uw.                       (15)

The lower bound follows from T_y(R_w)≥R_w^(-n)/J_b and T_y(R_u)≤R_u^(-n)/J_y(R_u). Hence replacing the time loss by m_w/m_u does not automatically preserve the original traffic coefficient: q_w/q_u and the ratio of current to terminal occupancy remain. No cancellation of these factors with an independently chosen source posterior is asserted. Their source-integrated compensation by negative credit remains unproved. Equations (12)–(15) are auxiliary fee diagnostics; the actual new payment in this round is (1)–(10).

## Actually run checks and scope

`python3 /tmp/r346_geometry_checks.py` passed 4,022 exact Fraction assertions. They test source-dependent relative quantiles and mass atoms, the ledger, and scalar step-occupancy clocks with the exact terminal atom, including late H activation and the mass-compensation bounds (13),(15).

The actual one-dimensional receiver fixture is f=1[-4,4], E=[-1,0] with R=1 and E=[0,1] with R=2; q=1. Direct whole-interval integration gives ∫fJ_b=2 and ∫1[-1,0]J_b=1. For diagnostic K=3/2, θ=1/4, the covered first moment is 319/200 and the complementary first moment is 81/200. The small-receiver acceptance boundary is y=-2/5. An initial hand-computed fixture boundary was corrected by this exact check before recording the final values.

The finite scalar clocks and atomic measures are diagnostics, not substituted source fields in the proof. The real one-dimensional fixture has no original root high-past traffic. None of these checks certifies the general G_rel budget; its remaining source-integrated joint geometry is still open.
