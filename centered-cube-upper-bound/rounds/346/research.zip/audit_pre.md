# R346 independent preliminary audit

Status: PASS for the relative-future payment below; the proposed upward flow is a legal auxiliary construction only with the explicit column/terminal budget stated below. No R346 author proof was read for this screen. This file is an independent preliminary receipt, not the final author-file audit or a general root-order conclusion.

## 1. Fixed contract and new payable branch

Use the actual hard matched R345 field: finite Lebesgue E, f≥0 in L¹, a≤R_u≤b≤2a, m_u=f(Q_u)=q_u R_u^n, q_-=3λ/4≤q_u≤λ, dμ(u)=du/m_u. All original prefixes, gates, sources, physical clock ell, and denominators remain frozen. Let ρ_y(du)=c_u(y)dμ(u), J_b(y)=ρ_y(E), and U_y(t)=ρ_y{m_u>t}. The original G has positive far-mass, high-past, and outside-center gates. Its sourcewise density is bounded by the actual first moment ∫q_u dρ_y after the inclusive physical tail is integrated. This is a bound, not an equality identifying G with that first moment.

For every measurable s(y)≥0, R345's pointwise-in-y quantile argument gives

    G_{U_y(Km_u)≤s(y)}[g]
      ≤ λ∫g(y)s(y)dy + D_top∫g,
    D_top=1+log(λK/q_-),

for any 0≤g≤f, with all fields still computed from full f. Here K=exp(√n), so D_top=1+√n+log(4/3).

Indeed, at fixed y set τ=inf{t≥m0:U_y(t)≤s(y)}, m0=q_-a^n. Right continuity of the strict survival function gives U_y(τ)≤s(y). The accepted receivers have m_u≥τ/K. The strict tail m_u>τ costs λs(y). The closed middle window [τ/K,τ] costs 1+log(λK/q_-) by the actual receiver-center envelope and the original inclusive ell tail. The whole τ atom belongs to the middle window; no split, new clock atom, or missing bottom atom is allowed. A zero capture row contributes zero. Joint measurability follows from Tonelli and rational threshold sublevel sets, also when s depends on y.

Take s(y)=εJ_b(y), with fixed 0<ε<1. The exact matched-source identity is

    ∫f(y)J_b(y)dy
      =∫_E [∫f(y)c_u(y)dy]/m_u du=|E|.

Consequently g_ex=(f-T_clip)_+≤f satisfies

    λ ε∫g_ex J_b ≤λ ε|E|≤(4/3)εX_q,
    X_q=∫_E q_u du.

Therefore the genuinely original positive branch with U_y(Km_u)≤εJ_b(y) is paid by

    (4/3)εX_q+D_top W_ex.

This proof does not turn the source-dependent gate into a global receiver set, change q, or recompute J. It applies sourcewise before integration. On the original high-past support, J_b(y)>h=(1+√n)/(εq_-), so εJ_b(y)>(1+√n)/q_->√n/q_-. Thus the new paid branch contains the former R345 absolute-future branch on that support. This inclusion is not asserted outside the original traffic support.

## 2. Exact replacement ledger and limitation

Clip first, then split only the excess-source traffic:

    G[f]=G[g_clip]+G_low-relative[g_ex]+G_high-relative[g_ex].

The inherited clipping fee is εX_q, the inherited R338 hard-slot fee is 2εX_q, and the new relative fee is (4/3)εX_q. Hence the replacement hard-slot bound is

    B_H ≤ G_high-relative[g_ex]
          +(13/3)εX_q+C_{ε,n}W+D_top W_ex.

It replaces the R345 slot; the old covering/low-future fee is not added again. Under the supplied outer normalization 2Λε=1/12, the new receiver coefficient is 13/36. If the old CZ 1/256 belongs to the same authenticated X account, their sum is 841/2304 and the unallocated fraction is 1463/2304. This is conditional ledger arithmetic, not certification that every remaining historical slot can be absorbed.

The unpaid term retains all original gates and satisfies both strict lower past >h and terminal upper future >εJ_b(y). Upper-tail witnesses need not lie in the active physical prefix. No extra current-clock J is created from their terminal occupancy. There is no general root-order estimate for this residual here.

## 3. Upward-flow auxiliary: the exact column and terminal bill

Fix y and write the initial original residual measure after integrating its physical clock and small endpoint as ν_y^0(du)=a_y^0(u)ρ_y(du), 0≤a_y^0≤q_u. It is supported on the original start gates. For a measurable positive threshold s(y), put H_y={U_y(Km_u)>s(y)}, T_y=H_y^c. Define

    P_y(u,dw)=1_Hy(u)1_{m_w>Km_u}ρ_y(dw)/U_y(Km_u).

Rows have mass one on H_y and zero on T_y. To guarantee that the final stopping set is T_y, continuation must use ALL H_y states. If continuation is allowed only at states satisfying the original start/history gates, mass that exits those gates while still in H_y is an additional stopped component, not a paid low-future terminal. Continuing on the larger H_y is a legal auxiliary flow after the old clocks have been integrated, but its new receivers do not inherit the old original-traffic qualifications.

For any incoming density a with respect to ρ_y, the actual column is

    (P_y^*a)(w)=∫_{H_y,m_u<m_w/K}
                     a(u)/U_y(Km_u) ρ_y(du).

To compare incoming mass with q_wρ_y(dw), the relevant normalized column is

    Λ_y(w)=(1/q_w)∫_{H_y,m_u<m_w/K}
                         q_u/U_y(Km_u)ρ_y(du),

not the row sum. An honest crude bound is

    Λ_y(w)≤λ Z_y(m_w/K-)/(q_-s(y)).

No root-order column estimate follows from row conservation. Every step increases m by more than K. Since m0≤m≤m1=λb^n, P_y^L=0 for the safe integer L=floor(log(m1/m0)/logK)+1. Thus

    σ_y=1_Ty ∑_{k=0}^{L-1} ν_y^0 P_y^k

has exactly the initial total mass (with continuation on all H_y). Integrating its mass against the unchanged exterior source g_ex recovers the original residual cost. These are transported cost tokens; σ_y is not asserted to be actual original traffic at its terminal receiver.

A usable terminal charge requires a separate certified bound dσ_y/dρ_y≤B(y)q_w on T_y. The low-future first-moment receipt then costs

    ∫g_ex(y)B(y)[λs(y)+D_top]dy.

For relative s(y)=εJ_b(y), this is controlled by the new main receipt only if B(y) has a proved compatible source-integrated budget; bounded B gives B times that receipt. Finite depth alone yields no such B and cannot collapse L root fees into one root fee.

For domination uniformly over all 0≤a0≤q1_H, the exact worst-case terminal condition in this scheme is

    1_T ∑_{k=0}^{L-1}(P^*)^k(q1_H)≤Bq.

It is necessary and sufficient for this terminal domination by positivity. A concrete sufficient certificate is a nonnegative live occupancy supersolution v≥a0+1_H P^*v, together with terminal bound 1_T P^*v≤Bq (plus an initial terminal density when present). These are explicit joint column conditions to prove, not established new root payments. A one-step live-column factor c<1 and terminal factor d would yield B≤d/(1-c); c=1 with L layers generally retains an L factor.

## 4. Evidence and scope

The analytic arguments above are independent derivations, not inferred from finite tests. A local Python Fraction check actually executed during this screen passed 866 assertions on finite strict-tail relative quantiles and the ledger fractions. Those finite scalar rows are not substitute actual cube fields. Earlier bounded scratch checks executed in this audit session tested 1,944 finite-mass flow identities in 486 cases and 736 relative-quantile/source-identity/ledger assertions; they are diagnostics only, separate from any primary R346 replay totals. The actual one-dimensional source-identity fixture in the latter check has finite period-one nonuniform f, actual R=1 or2 on receiver intervals, and verifies ∫fJ_b=|E|=3/4 and three excess-source integral inequalities. It does not certify the original high-past branch.

No R346 author proof, numerical pipeline, global closure, new external literature claim, or historical coefficient inventory is certified by this preliminary file.

## 5. Read contract binding

- /tmp/r345_geometry.md SHA256 7b8af94f0820e5f6c79b75bd2ee0b89647a53effa38599a95d2e148635148f66 (necessary theorem read for this screen).
- /tmp/r345_main.md SHA256 c460f71f589e2be0111dae203b2d2dc3091c1862fc6f9cfd5bdd196de377647f (binding only; prior-round audit remains separate).
- /tmp/r345_ledger.md SHA256 c0fb4dbe928b0bd7cbfbba3c9d06e8445e9ac94a209b67a05fe3dbe319c8f2e2 (binding only; prior-round audit remains separate).
