"""Exact cube dilation, sparse-coordinate envelope, and large-dimension budget diagnostics for R798."""
import argparse
from fractions import Fraction as F
from itertools import product
import json
from math import comb, factorial
from pathlib import Path
import platform

import flint
from flint import arb, ctx
ctx.prec = 768

def frac_sum(v):
    return sum(v, F(0))

def rounded_cube(n, h, rho):
    return frac_sum(F(comb(n,j),factorial(j)) * h**(n-j) * rho**j for j in range(n+1))

def coordinate_volume(sides, bands, cutoff):
    coeff = [F(1)]
    for inner, outer in zip(sides, bands):
        result = [F(0)]*(len(coeff)+1)
        for j, v in enumerate(coeff):
            result[j] += v*2*inner
            result[j+1] += v*2*(outer-inner)
        coeff = result
    assert sum(coeff) == prod(F(2)*b for b in bands)
    return sum(coeff[:cutoff+1])

def prod(items):
    result = F(1)
    for value in items:
        result *= value
    return result

def mask_check(n):
    # In the true reference cube [-1,1]^n, the old observing center is U_j=2*p_j.
    probabilities = [F(1+(j*3)%7,32) for j in range(n)]
    counts=[F(1)]
    for p in probabilities:
        nxt=[F(0)]*(len(counts)+1)
        for i,v in enumerate(counts):
            nxt[i]+=(1-p)*v
            nxt[i+1]+=p*v
        counts=nxt
    mean=sum(probabilities)
    assert sum(counts)==1 and sum(j*v for j,v in enumerate(counts))==mean
    threshold=min(n,int(3*mean)+1)
    tail=sum(counts[threshold:])
    if n<=8:
        masses=[prod(probabilities[i] if bit else 1-probabilities[i] for i,bit in enumerate(bits))
                for bits in product(range(2),repeat=n)]
        assert max(masses)==counts[0] and sum(masses)==1
    mg=(arb(mean.numerator)/mean.denominator)
    assert arb(counts[0].numerator)/counts[0].denominator < (-mg).exp()
    chernoff=(-mg+threshold*(1+(mg/threshold).log())).exp()
    assert arb(tail.numerator)/tail.denominator < chernoff
    return dict(p=[str(p) for p in probabilities],mean=str(mean),threshold=threshold,
                top_pattern_mass=str(counts[0]),tail=str(tail),chernoff=chernoff.str(35))

def stage(name,n,h,rho,k):
    shape = rounded_cube(n,h,rho)
    h_arb = arb(h.numerator)/h.denominator
    rho_arb = arb(rho.numerator)/rho.denominator
    bound = h_arb**n*(2*(n*rho_arb/h_arb).sqrt()).exp()
    assert arb(shape.numerator)/shape.denominator < bound
    inner = [F(1)+(F((j+1)%3,16)) for j in range(n)]
    outer = [v+F(1+(j%2),2) for j,v in enumerate(inner)]
    coord = coordinate_volume(inner,outer,k)
    if n<=10:
        brute = frac_sum(prod(2*(outer[j]-inner[j] if bits[j] else inner[j]) for j in range(n))
                         for bits in product(range(2),repeat=n) if sum(bits)<=k)
        assert coord == brute
    homo = coordinate_volume([F(1)]*n,[F(3)]*n,k)/2**n
    independent = sum(comb(n,j)*2**j for j in range(k+1))
    union_hi = sum(comb(n,j)*3**j for j in range(k+1))
    assert homo == independent <= union_hi
    return dict(name=name,n=n,h=str(h),rho=str(rho),k=k,relative_rounded_volume=str(shape),
                relative_rounded_upper_arb=bound.str(35),inhomogeneous_volume=str(coord),
                homothetic_sparse_ratio=str(homo),coarse_union_bound=str(union_hi),mask=mask_check(n))

def large(power):
    n=2**power
    ell=arb(n+2).log()
    real_r=arb(n).sqrt()*ell**2
    r=int(real_r.ceil().unique_fmpz())
    k=int((arb(r)/(65536*ell)).floor().unique_fmpz())
    edge=arb(r)/(8192*n)
    J=arb(n).sqrt()*ell**8
    # k(n) log(3n)+log(k+1) bounds the log of all exception choices.
    log_union=edge*n+arb(k)*arb(3*n).log()+arb(k+1).log()
    budget=arb(r)/4096
    assert log_union<budget
    return dict(n_power=power,r=str(r),k=str(k),log_sparse_volume_upper=log_union.str(35),
                log_available=budget.str(35),sparse_bound_proved=True,
                J_over_n=(J/n).str(35),paired_hard_volume_gap_nonvacuous=bool(J<n*arb(2).log()))

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    group=parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--output",type=Path)
    group.add_argument("--check",type=Path)
    args=parser.parse_args()
    cases=[stage("initial",3,F(1),F(1,4),1),stage("pressure",8,F(65,64),F(3,4),2),
           stage("expanded",16,F(129,128),F(5,3),4)]
    data=dict(runtime=dict(python=platform.python_version(),python_flint=flint.__version__,
                           arb_bits=ctx.prec,architecture=platform.machine()),
              scope="Exact volumes of true boxes and rounded cubes; diagnostic shape parameters for first three tests. Large powers use the R798 asymptotic parameters, independently certified for the listed n only. No path data are inferred from these calculations.",
              cases=cases,asymptotic_checks=[large(p) for p in (24,48,80,128,256,512)])
    result=json.dumps(data,ensure_ascii=False,indent=2,sort_keys=True)+"\n"
    if args.output:
        args.output.write_text(result)
    else:
        assert args.check.read_text()==result
    for c in cases:
        print(c["name"], c["n"], "sparse volume / cube",c["homothetic_sparse_ratio"],"union bound",c["coarse_union_bound"])
    print("paired volume gap possible",[(v["n_power"],v["paired_hard_volume_gap_nonvacuous"]) for v in data["asymptotic_checks"]])
    if args.check:
        print("byte-identical")

if __name__=="__main__":
    main()
