#!/usr/bin/env python3
"""One physical source budget and one physical receiver budget for both true arms."""
import argparse
from collections import deque
from fractions import Fraction as F
from hashlib import sha256
from itertools import product
import json
from pathlib import Path
import platform

import rows798 as base


ROWS_SHA="04bbd600cd68bd2bb371559590a1902b97a345c02404ffc759a1147fb4b2bae9"
EPS=F(1,64)
L=F(1,32768)


def external(base_set,obstacle):
    c=base.point(obstacle)
    R=(1+EPS)*base.length(obstacle)/2
    lo,hi=c-R,c+R
    pieces=[b for a,d in base_set for b in ((a,min(d,lo)),(max(a,hi),d)) if base.length(b)]
    assert all(base.length(base.clip(b,(lo,hi)))==0 for b in pieces)
    return pieces


def exact_flow(records,caps,options):
    """Independent rational augmenting paths and residual-cut certificate."""
    used_keys=sorted({key for row in options for key in row})
    ng=len(records)
    keys={r:i+ng+1 for i,r in enumerate(used_keys)}
    sink=ng+len(keys)+1
    adj=[[] for _ in range(sink+1)]
    capacity={}
    raw={}

    def edge(u,v,c):
        adj[u].append(v)
        adj[v].append(u)
        capacity[u,v]=raw[u,v]=c
        capacity[v,u]=F(0)

    M=base.total(a["mass"] for a in records)
    for i,R in enumerate(records,1):
        edge(0,i,R["mass"])
        for r in sorted(options[i-1]):
            edge(i,keys[r],M+1)
    for k,j in keys.items():
        edge(j,sink,caps[k])
    value=F(0)
    augments=0
    while True:
        previous={0:-1}
        queue=deque([0])
        while queue and sink not in previous:
            u=queue.popleft()
            for v in adj[u]:
                if v not in previous and capacity[u,v]>0:
                    previous[v]=u
                    queue.append(v)
        if sink not in previous:
            break
        path=[]
        v=sink
        while v:
            u=previous[v]
            path.append((u,v))
            v=u
        step=min(capacity[e] for e in path)
        for u,v in path:
            capacity[u,v]-=step
            capacity[v,u]+=step
        value+=step
        augments+=1
    cut=base.total(c for (u,v),c in raw.items() if u in previous and v not in previous)
    assert value==cut
    received={tag:base.total(capacity[sink,keys[k]] for k in keys if k[0]==tag) for tag in sorted({k[0] for k in keys})}
    assert base.total(received.values())==value
    ledgers=[]
    for i,opts in enumerate(options,1):
        paid=[(r,capacity[keys[r],i]) for r in sorted(opts) if capacity[keys[r],i]]
        assert base.total(v for r,v in paid)==capacity[i,0]<=records[i-1]["mass"]
        ledgers.extend((i-1,k,v) for k,v in paid)
    assert all(base.total(w for _,j,w in ledgers if j==k)<=caps[k] for k in keys)
    return dict(paid=value,mincut=cut,unpaid=M-value,amount_paid_by_resource_family=received,
                augmentations=augments,source_side_cut_records=sorted(i-1 for i in previous if 1<=i<=ng),
                source_side_cut_resources=sorted(k for k,j in keys.items() if j in previous),
                actual_primal=ledgers)


def enumerate_cut(records,mu,recv,P):
    """Choose price sets B and receiver sets W, independently of augmenting paths."""
    def compress(ids,incidence,cellsize):
        groups={}
        for j in ids:
            stamp=tuple(i for i,r in enumerate(records) if j in incidence(r))
            if stamp:
                groups.setdefault(stamp,[]).append(j)
        cgroup=list(groups.values())
        bit={j:1<<k for k,group in enumerate(cgroup) for j in group}
        size=[base.total(cellsize[j] for j in group) for group in cgroup]
        return cgroup,bit,size

    nsrc=range(len(mu))
    nrecv=range(len(recv))
    source_groups,S,smass=compress(nsrc,lambda r:{*r["source_indices"],r["z"],r["q"]},mu)
    recv_groups,W,rsizes=compress(nrecv,lambda r:{r["U"],r["V"]},recv)
    assert len(smass)+len(rsizes)<=16
    demand=[]
    for r in records:
        bits=0
        for a in r["source_indices"]:
            bits|=S[a]
        demand.append((S[r["z"]],S[r["q"]],bits,W[r["U"]],W[r["V"]],r["mass"]))

    def options(q):
        return [base.total(v for i,v in enumerate(q) if mask&(1<<i)) for mask in range(1<<len(q))]

    prepared_s=options(smass)
    prepared_r=options(rsizes)
    best=F(0)
    best_sets=[]
    for B,Wmask in product(range(len(prepared_s)),range(len(prepared_r))):
        picked=[i for i,(z,q,s,u,v,w) in enumerate(demand)
                if (B&z and B&q and B&s==s and Wmask&u and Wmask&v)]
        peak=base.total(demand[i][-1] for i in picked)
        charge=P*prepared_s[B]+L*prepared_r[Wmask]
        if peak-charge>best:
            best=peak-charge
            best_sets=[]
        if peak-charge==best:
            best_sets.append(dict(price_cells=sorted(j for i,g in enumerate(source_groups) if B&(1<<i) for j in g),
                                  marked_receiver_cells=sorted(j for i,g in enumerate(recv_groups) if Wmask&(1<<i) for j in g),
                                  included_true_records=picked,contained_weight=peak,price_capacity=P*prepared_s[B],
                                  receiving_capacity=L*prepared_r[Wmask],deficit=peak-charge))
    return dict(deficit=best,optimal_cuts=best_sets,price_resource_groups=source_groups,
                receiver_resource_groups=recv_groups,enumerated_resource_cuts=len(prepared_s)*len(prepared_r))



def paired_support_comparison(records,cuts,price_cells,recv_boxes,mub,A,TrueA,I_a,mu):
    """Actual pair support in each optimal cut versus its Cartesian projections."""
    results=[]
    for cut_id,cut in enumerate(cuts):
        record_ids=cut["included_true_records"]
        actual={(records[i][z],records[i][u])
                for i in record_ids for z,u in (("z","U"),("q","V"))}
        X={a for a,r in actual}
        W={r for a,r in actual}
        rectangle=set(product(X,W))

        def xi(a,r):
            old=r//2
            price=mu(base.clip(price_cells[a],A[old]))
            assert price in (F(0),mub[a]) and base.inside(recv_boxes[r],TrueA[old])
            return I_a[old]*price*base.length(recv_boxes[r])/(base.length(A[old])*base.length(TrueA[old]))

        def item(a,r):
            return dict(price_cell_index=a,price_cell=price_cells[a],receiving_cell_index=r,
                        true_old_parent_index=r//2,receiving_cell=recv_boxes[r],reference_mass=xi(a,r))

        paired=base.total(xi(a,r) for a,r in sorted(actual))
        boxed=base.total(xi(a,r) for a,r in sorted(rectangle))
        by_physical_old=base.total(
            I_a[old]/(base.length(A[old])*base.length(TrueA[old]))
            *base.total(mu(base.clip(price_cells[a],A[old])) for a in X)
            *base.total(base.length(recv_boxes[r]) for r in W if r//2==old)
            for old in range(len(A))
        )
        wrong=[item(a,r) for a,r in sorted(rectangle-actual)]
        lost=[item(a,r) for a,r in sorted(actual-rectangle)]
        assert not lost
        assert all(xi(a,r)>0 for a,r in actual)
        assert boxed==by_physical_old and boxed-paired==base.total(x["reference_mass"] for x in wrong)
        assert paired<=boxed
        results.append(dict(optimal_cut_index=cut_id,record_indices=record_ids,
                            actual_pair_reference_mass=paired,product_projection_reference_mass=boxed,
                            check_by_true_owner_disintegration=by_physical_old,
                            extra_weight=boxed-paired,actual_pairs=[item(a,r) for a,r in sorted(actual)],
                            price_projection=sorted(X),receiving_projection=sorted(W),
                            missed_pairs=lost,positive_wrongly_admitted_pairs=[x for x in wrong if x["reference_mass"]],
                            formally_added_null_reference_pairs=[x for x in wrong if not x["reference_mass"]]))
    return results

def experiment(name,T,A,tshares,value,mask,P):
    TrueT=[base.owner(q,w) for q,w in zip(T,tshares)]
    TrueA=[base.owner(q,F(1)) for q in A]
    physical=sorted(TrueT+TrueA)
    assert all(x[1]<y[0] for x,y in zip(physical,physical[1:]))
    mt=list(map(base.length,T))
    ma=list(map(base.length,A))
    mu=lambda a:base.real_mass(a,value)
    assert list(map(mu,T+A))==mt+ma
    I_t=list(map(base.length,TrueT))
    I_a=list(map(base.length,TrueA))
    cut_g=[[(F(2),F(9,4))] for _ in T]
    cut_l=[[(F(-3,4),F(-5,8))],[(F(19,4),F(5))] if name!="initial" else []]
    if len(A)>2:
        cut_l.append([(F(9,4),F(5,2))])
    assert all(base.inside(c,q) for family,q in zip(cut_g+cut_l,T+A) for c in family)
    overlaps={}
    for t,i in product(range(len(T)),range(len(A))):
        K=base.clip(T[t],A[i])
        m=mu(K)
        if m and ma[i]<mt[t]:
            overlaps[t,i]=(K,m,m/(mt[t]*ma[i]))
    d=[base.total(I_a[i]*r[2] for (j,i),r in overlaps.items() if j==t) for t in range(len(T))]
    assert min(d)>0
    receiver_boxes=[R for E in TrueA for R in ((E[0],base.point(E)),(base.point(E),E[1]))]
    recv_measure=list(map(base.length,receiver_boxes))
    candidates={}
    for t,u,g,z,q,side_u,side_g in mask:
        if (t,u,g) not in candidates:
            side_groups=[external(cut_g[t],A[u]),external(cut_l[u],T[t]),
                         external(cut_g[t],A[g]),external(cut_l[g],T[t])]
            candidates[t,u,g]=side_groups
        assert base.inside(z,overlaps[t,u][0]) and base.inside(q,overlaps[t,g][0])
    cuts=sorted({*base.SOURCE,*(v for p in T+A for v in p),
                 *(v for row in mask for a in row[3:5] for v in a),
                 *(v for groups in candidates.values() for g in groups for a in g for v in a)})
    price_cells=list(zip(cuts,cuts[1:]))
    mub=list(map(mu,price_cells))
    assert min(mub)>0
    records=[]
    labels=set()
    for group,(t,u,g,z_box,q_box,side_u,side_g) in enumerate(mask):
        nu,nv=2*u+side_u,2*g+side_g
        source_groups=candidates[t,u,g]
        source=sorted({j for j,b in enumerate(price_cells)
                       if any(base.inside(b,a) for family in source_groups for a in family)})
        assert source
        a0,B,K0=overlaps[t,u]
        a1,C,K1=overlaps[t,g]
        exact_weight=I_t[t]*I_a[u]*I_a[g]*K0*K1/d[t]
        explicit_sum=F(0)
        geometry_factor=I_t[t]/(mt[t]**2*d[t])
        for a,b in product(range(len(mub)),repeat=2):
            if not(base.inside(price_cells[a],z_box) and base.inside(price_cells[b],q_box)):
                continue
            key=t,u,g,nu,nv,a,b
            assert key not in labels
            labels.add(key)
            mass=exact_weight*mub[a]*mub[b]/(B*C)*recv_measure[nu]*recv_measure[nv]/(I_a[u]*I_a[g])
            xi=recv_measure[nu]*mub[a]/ma[u]
            xip=recv_measure[nv]*mub[b]/ma[g]
            assert 0<mass==xi*xip*geometry_factor
            explicit_sum+=mass
            records.append(dict(mask=group,t=t,u=u,g=g,U=nu,V=nv,z=a,q=b,
                                source_indices=source,mass=mass))
        assert explicit_sum==exact_weight*mu(z_box)*mu(q_box)/(B*C)*recv_measure[nu]*recv_measure[nv]/(I_a[u]*I_a[g])>0

    caps={**{("source",j):P*m for j,m in enumerate(mub)},
          **{("receive",j):L*m for j,m in enumerate(recv_measure)}}
    def opts(both_price=True,both_receive=True,ext=True,duplicated=False):
        rows=[]
        for r in records:
            source={("source",r["z"])}
            receiving={("receive",r["U"])}
            if both_price:
                source.add(("source",r["q"]))
            if both_receive:
                receiving.add(("receive",r["V"]))
            exterior_options={("exterior" if duplicated else "source",a) for a in r["source_indices"]} if ext else set()
            rows.append(source|receiving|exterior_options)
        return rows

    methods={}
    for key,flags in (("full",{}),("first_actual_price_only",{"both_price":False}),
                      ("first_actual_receiver_only",{"both_receive":False}),
                      ("first_price_and_receiver_only",{"both_price":False,"both_receive":False}),
                      ("no_external_source",{"ext":False})):
        methods[key]=exact_flow(records,caps,opts(**flags))
    split_caps={**caps,**{("exterior",j):P*m for j,m in enumerate(mub)}}
    wrong_duplicate=exact_flow(records,split_caps,opts(duplicated=True))
    independently=enumerate_cut(records,mub,recv_measure,P)
    full=methods["full"]
    assert 0<independently["deficit"]==full["unpaid"]
    assert 0<full["paid"] and all(q["unpaid"]>=full["unpaid"] for q in methods.values())
    assert wrong_duplicate["unpaid"]<=full["unpaid"]
    assert any(len(c["included_true_records"])<len(records) for c in independently["optimal_cuts"])
    if name=="initial":
        assert all(q["unpaid"]>full["unpaid"] for k,q in methods.items() if k!="full")
    if name!="initial":
        # One actual chosen old price used by a true arm is also eligible as
        # the same physical source for an exterior choice, at the same cap.
        actual_price_atoms={r[k] for r in records for k in ("z","q")}
        assert any(actual_price_atoms.intersection(r["source_indices"]) for r in records)
        assert wrong_duplicate["unpaid"]<full["unpaid"]
    partitions=dict(actual_price_cells=price_cells,actual_price_mu=mub,actual_receiver_cells=receiver_boxes,
                    actual_recv_Leb=recv_measure)
    return dict(stage=name,physical_terminal=T,physical_old=A,actual_center_owners=TrueT,actual_old_owners=TrueA,
                source_amplitude=value,terminal_I=I_t,old_I=I_a,original_degrees=d,
                terminal_absolute_bins=[base.volume_bucket(m) for m in mt],
                common_G_for_t=cut_g,common_G_for_old=cut_l,source_holdings_by_type=[
                    dict(t=t,u=u,g=g,four_external_options=groups,
                         true_mass_each=[base.total(mu(a) for a in one) for one in groups])
                    for (t,u,g),groups in sorted(candidates.items())],
                actual_diagnostic_windows=mask,all_received_mass=base.total(r["mass"] for r in records),
                continuous_cell_catalog=partitions,physical_records=records,
                mu_capacity_density=P,receiver_capacity_density=L,actual_methods=methods,
                invalid_copy_same_source_as_external=wrong_duplicate,
                independent_B_W_cut=independently,
                paired_support_on_each_true_optimal_cut=paired_support_comparison(
                    records,independently["optimal_cuts"],price_cells,receiver_boxes,mub,A,TrueA,I_a,mu))



def two_matching_pairs(initial):
    """One physical old father, two actual values, two matching receiver halves."""
    T,A=initial["physical_terminal"],initial["physical_old"]
    E,I=initial["actual_old_owners"],initial["old_I"]
    I_t=initial["terminal_I"][0]
    d=initial["original_degrees"][0]
    t,u,g=0,0,1
    cat=initial["continuous_cell_catalog"]
    cells,recv=cat["actual_price_cells"],cat["actual_receiver_cells"]
    mub,recv_sizes=cat["actual_price_mu"],cat["actual_recv_Leb"]
    mu=lambda box:base.real_mass(box,initial["source_amplitude"])
    zcells=[cells.index(base.iv("5/8","3/4")),cells.index(base.iv("7/8",1))]
    q=cells.index(base.iv("13/4","7/2"))
    V=2
    assert base.inside(cells[q],base.clip(T[t],A[g]))
    m_t,m_u,m_g=map(base.length,(T[t],A[u],A[g]))
    overlap_u=mu(base.clip(T[t],A[u]))
    overlap_g=mu(base.clip(T[t],A[g]))
    old_all=I_t*I[u]*I[g]*(overlap_u/(m_t*m_u))*(overlap_g/(m_t*m_g))/d
    exterior_ids=initial["physical_records"][0]["source_indices"]
    assert initial["physical_records"][0]["t"]==t
    records=[]
    for j,z in enumerate(zcells):
        U=j
        assert base.inside(cells[z],base.clip(T[t],A[u])) and base.inside(recv[U],E[u])
        w=old_all*mub[z]/overlap_u*mub[q]/overlap_g*recv_sizes[U]/I[u]*recv_sizes[V]/I[g]
        assert w==I_t/(m_t*m_t*d)*(mub[z]*recv_sizes[U]/m_u)*(mub[q]*recv_sizes[V]/m_g)>0
        records.append(dict(t=t,u=u,g=g,z=z,q=q,U=U,V=V,source_indices=exterior_ids,mass=w))
    assert recv_sizes[0]==recv_sizes[1]
    rejected_cross_mass=[r["mass"] for r in records]  # the old U halves have the same true length
    P=F(1,4194304)
    caps={**{("source",i):P*m for i,m in enumerate(mub)},
          **{("receive",i):L*m for i,m in enumerate(recv_sizes)}}
    opts=[{("source",i) for i in [r["z"],r["q"],*r["source_indices"]]}
          | {("receive",r["U"]),("receive",r["V"])} for r in records]
    flow=exact_flow(records,caps,opts)
    cuts=enumerate_cut(records,mub,recv_sizes,P)
    assert 0<flow["unpaid"]==cuts["deficit"] and len(cuts["optimal_cuts"])==1
    assert cuts["optimal_cuts"][0]["included_true_records"]==[0,1]
    paired=paired_support_comparison(records,cuts["optimal_cuts"],cells,recv,mub,A,E,I,mu)[0]
    assert paired["actual_pair_reference_mass"]==F(7,1024)
    assert paired["product_projection_reference_mass"]==F(11,1024)
    assert sorted(x["reference_mass"] for x in paired["positive_wrongly_admitted_pairs"])==[F(3,2048),F(5,2048)]
    left_coupled=base.total(mub[r["z"]]*recv_sizes[r["U"]]/m_u for r in records)
    left_box=base.total(mub[z]*recv_sizes[U]/m_u for z,U in product(zcells,(0,1)))
    assert left_coupled==F(1,256) and left_box==F(1,128)
    return dict(terminal=t,first_old=u,second_old=g,old_degree=d,exterior_cap_P=P,
                fixed_second_arm=dict(price=cells[q],receiver=recv[V]),
                selected_record_cells=[dict(price=cells[r["z"]],receiver=recv[r["U"]],
                                            true_original_two_arm_mass=r["mass"]) for r in records],
                rejected_cross_pre_mask_actual_two_arm_masses=rejected_cross_mass,
                first_arm_pair_reference_mass=left_coupled,first_arm_product_reference_mass=left_box,
                combined_full_two_arm_support=paired,actual_small_cap_flow=flow,
                actual_small_cap_cuts=cuts,price_and_owner_cells_are_from_original_initial_stage=True)

def suite():
    T=[base.iv(0,4),base.iv("1/4","17/4"),base.iv("1/2","9/2")]
    U=[base.iv(-1,1),base.iv(3,5),base.iv("9/8","25/8")]
    z,q=base.iv("5/8","3/4"),base.iv("13/4","7/2")
    tailz,tailq=base.iv("7/8",1),base.iv("17/4","35/8")
    overlap=base.iv(2,"9/4")
    two=[(0,0,1,z,q,0,0),(1,0,1,z,q,0,0),(1,0,1,tailz,tailq,1,1)]
    stress=[(t,0,1,z,q,0,0) for t in range(3)]+[
         (1,1,0,q,z,0,0),(2,0,2,z,overlap,0,0),(2,0,1,tailz,tailq,1,1)]
    expanded=stress+[(3,0,2,z,overlap,0,0),(4,0,2,tailz,overlap,1,0),
                     (0,0,0,z,z,0,0)]
    return [
      experiment("initial",[T[0],T[2]],[U[0],base.iv("5/2","9/2")],[F(1),F(3,4)],F(1,4),two,F(1,262144)),
      experiment("pressure",T,U,[F(1),F(3,4),F(1,2)],F(1,2),stress,F(1,524288)),
      experiment("expanded",T+[base.iv("3/8","27/8"),base.iv("7/8","31/8")],U,
                 [F(1),F(3,4),F(1,2),F(7,8),F(5,8)],F(3,4),expanded,F(1,524288)),
    ]


def main():
    p=argparse.ArgumentParser(description=__doc__)
    a=p.add_mutually_exclusive_group()
    a.add_argument("--output",type=Path)
    a.add_argument("--check",type=Path)
    args=p.parse_args()
    dep=Path(base.__file__)
    assert sha256(dep.read_bytes()).hexdigest()==ROWS_SHA
    stages=suite()
    obj=dict(runtime=dict(python=platform.python_version(),architecture=platform.machine()),
             command="python -B joint798.py --check joint798.json",dependency={"rows798.py":ROWS_SHA},
             diagnostic=dict(precision="exact Fraction and independent capacitated cuts",
                 joint="true ordered two-arm original measures evaluated on agreed rational half-open physical cells",
                 scope="true parents, both old intersections, two actual disjoint owner systems; imposed finite rectangular diagnostic gates, no high-dimensional mask",
                 exterior="for each old arm subtract the opposing closed (1+1/64) parent from the preassigned source part, then use the union",
                 endpoint="upper endpoints are taken half-open in disintegration; all null endpoints are immaterial",
                 capacities="one actual mu measure at price atoms and one actual Lebesgue measure at owner atoms. Only the named invalid comparison copies a physical price capacity.",
                 continuous_lift="allocate each flow amount as a constant fraction of its original product cell. An actual-price or receiver payment keeps that exact observed coordinate. For a free exterior option use real mu restricted to its assigned atom, normalized."),
             stages=stages, exact_pairing_shared_old_parent_control=two_matching_pairs(stages[0]))
    s=json.dumps(obj,sort_keys=True,indent=2,default=str)+"\n"
    if args.output:
        args.output.write_text(s)
    if args.check:
        assert args.check.read_text()==s
    if args.output or args.check:
        for stage in stages:
            methods=stage["actual_methods"]
            print(stage["stage"],"received",stage["all_received_mass"],"unpaid",methods["full"]["unpaid"],
                  "one both",methods["first_price_and_receiver_only"]["unpaid"],
                  "no exterior",methods["no_external_source"]["unpaid"],
                  "actual records",len(stage["physical_records"]))
        if args.check:
            print("byte-identical")
    else:
        print(s,end="")


if __name__=="__main__":
    main()
