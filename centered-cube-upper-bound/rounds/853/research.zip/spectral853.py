"""R853: physical parent fibres and nonnegative spectral payment certificates."""

from fractions import Fraction as F
from itertools import permutations
from math import sqrt
import sys

import cvxpy as cp
import numpy as np


DIM = 16
EPS = F(1,1024)
SIDE = (F(1),F(17,16),F(5,4),F(3,2),F(2))
LAM = F(1)
UNIT_MASS = F(1,128)
VOLUME = (2*EPS)**DIM
DENSITY = F(5,4)


def volume_bin(v):
    k = v.numerator.bit_length()-v.denominator.bit_length()
    if F(2)**k<v:
        k+=1
    assert F(2)**(k-1)<v<=F(2)**k
    return k


def geometry():
    # All source packets are disjoint positive boxes, centrally placed on
    # physical axis 1; all parent cores are on physical axis 2. The one
    # fixed eta is sigma cut to these entire packets.
    masses = (1,)*10 + (1,4,9,4,1,1)
    source_coords = tuple((j-F(15,2))/64 for j in range(16))
    parent_coords = tuple(F(j-2,16) for j in range(5))
    assert all(y-x>2*EPS for x,y in zip(source_coords,source_coords[1:]))
    assert all(y-x>2*EPS for x,y in zip(parent_coords,parent_coords[1:]))
    for center,l in zip(parent_coords,SIDE):
        assert abs(center)+EPS+1<4
        assert max(abs(center),max(map(abs,source_coords)))+2*EPS<l/2
    assert all(m*UNIT_MASS/VOLUME>DENSITY for m in masses)
    total_mass = sum(masses)*UNIT_MASS
    assert LAM<DENSITY<=DENSITY+total_mass<2*LAM
    # On [-4,4]^16 set sigma to 5/4 outside the packets and to the given
    # uniform densities inside. All scales in [1,2] on each tested real
    # core have value in [5/4,5/4+total_mass], even with partial packets.
    volumes = tuple(l**DIM for l in SIDE)
    bins = tuple(map(volume_bin,volumes))
    assert bins==(0,2,6,10,16)
    weights = tuple(VOLUME/(LAM*v**2) for v in volumes)
    print("16D real disjoint source and parent boxes: all [1,2] heights in [5/4,",DENSITY+total_mass,"]")
    print("  true source cut eta mass",total_mass,"; packet unit",UNIT_MASS,
          "; fixed parent lengths",",".join(map(str,SIDE)))
    print("  true parent bins",bins,"; each receiving core has volume 2^(-144).")
    return volumes,weights,total_mass


def mat(rows):
    return tuple(tuple(F(v) for v in row) for row in rows)


def actual_m(kappa,left,right):
    assert len(kappa)==len(left) and all(len(row)==len(right) for row in kappa)
    assert all(0<=g<=1 for row in kappa for g in row)
    # Units of UNIT_MASS^2. Alpha_i,beta_j are characteristic functions
    # of their preassigned real packets, kept fixed on all parent cores.
    return tuple(tuple(g*a*b for g,b in zip(row,right)) for row,a in zip(kappa,left))


def pairing(m,permutation):
    return sum(m[i][j] for i,j in enumerate(permutation))


def pairing_scores(m):
    k=len(m)
    perms=tuple(permutations(range(k)))
    return pairing(m,range(k)),max(pairing(m,p) for p in perms)


def normalized_schur(m):
    a=np.asarray(m,dtype=float)
    r,c=a.sum(axis=1),a.sum(axis=0)
    denom=np.sqrt(r[:,None]*c[None,:])
    T=np.divide(a,denom,out=np.zeros_like(a),where=denom>0)
    # Algebraic feasibility: weighted Cauchy--Schwarz with row and
    # column sums proves ||T||<=1; active sqrt(column sums) maps to
    # sqrt(row sums), with equal Euclidean norms.
    assert abs(np.linalg.norm(T,2)-1)<1e-12
    assert np.max(np.abs(T@np.sqrt(c)-np.sqrt(r)))<1e-12
    return np.sum(a*T)


def candidate(m,exact):
    a=np.asarray(m,dtype=float)
    nleft,nright=a.shape
    T=cp.Variable(a.shape,nonneg=True)
    lifted=cp.bmat([[np.eye(nleft),T],[T.T,np.eye(nright)]])
    prob=cp.Problem(cp.Maximize(cp.sum(cp.multiply(a,T))),[lifted>>0])
    prob.solve(solver="CLARABEL",tol_gap_abs=1e-9,tol_gap_rel=1e-9,tol_feas=1e-9,max_iter=200)
    assert prob.status in (cp.OPTIMAL,cp.OPTIMAL_INACCURATE)
    data=np.maximum(T.value,0)
    data/=max(1.,np.linalg.norm(data,2))
    value=float(np.sum(a*data))
    assert abs(value-exact)<2e-6
    return value


def cyclic(k,volumes,weights,total_mass):
    equal_unit=weights[k-1]*UNIT_MASS**2
    balanced=[(volumes[y]/volumes[k-1])**2 for y in range(k)]
    assert all(0<g<=1 for g in balanced)
    blocks=(1,)*k
    fibre=[]
    for y,g in enumerate(balanced):
        perm=tuple((i+y)%k for i in range(k))
        kernel=mat([[g*int(j==perm[i]) for j in range(k)] for i in range(k)])
        m=actual_m(kernel,blocks,blocks)
        assert sum(map(sum,m))==k*g
        assert weights[y]*UNIT_MASS**2*sum(map(sum,m))<=weights[y]*total_mass**2
        fibre.append(m)
    aggregate=tuple(tuple(sum(weights[y]*UNIT_MASS**2*fibre[y][i][j] for y in range(k))/equal_unit
                          for j in range(k)) for i in range(k))
    assert aggregate==mat([[1]*k]*k)
    global_diag,global_perm=pairing_scores(aggregate)
    local_perm=sum(weights[y]*UNIT_MASS**2*pairing_scores(m)[1] for y,m in enumerate(fibre))/equal_unit
    local_schur=sum(weights[y]*UNIT_MASS**2*balanced[y]*k for y in range(k))/equal_unit
    assert (global_diag,global_perm,local_perm,local_schur)==(k,k,k*k,k*k)
    # Fixed aggregate J: 1^T T 1 <= k, attained by J/k.
    # Each normalized fibre is a permutation with spectral norm one:
    # its score <= k from individual entries <=1, attained by itself.
    global_score=candidate(aggregate,k)
    local_score=candidate(tuple(tuple(v/balanced[0] for v in row) for row in fibre[0]),k)*k
    print("Cyclic",k,"labels and parents; fixed source labels; k transmitted pairs per parent.")
    print("  physical parent income unit |core|*mu^2/(lambda*v_last^2) =",f"{float(equal_unit):.8e}")
    print("  exact fixed same-label / best global perm / global contraction:",
          global_diag,global_perm,k,"; exact local perm / Schur / contraction:",local_perm,local_schur,k*k)
    print("  numerical SDP global/local",f"{global_score:.7f}",f"{local_score:.7f}",
          "; positive actual marked flow",f"{float(equal_unit*k*k):.8e}")


def single(name,kappa,left,right,expect,schur_formula,schur,exact_formula,exact,y,weights,total_mass):
    m=actual_m(kappa,left,right)
    same,matched=pairing_scores(m)
    assert (same,matched)==expect
    actual_scale=weights[y]*UNIT_MASS**2
    input_flow=actual_scale*sum(map(sum,m))
    assert 0<input_flow<=weights[y]*total_mass**2
    schur_score=normalized_schur(m)
    assert abs(schur_score-schur)<1e-12
    fitted=candidate(m,exact)
    print(name,"on parent bin",volume_bin(SIDE[y]**DIM),"; m/mu^2:",
          tuple(tuple(map(str,row)) for row in m))
    print("  exact same-label / local perm:",same,matched,
          "; Schur =",schur_formula,"; spectral optimum =",exact_formula,
          "; numerical SDP",f"{fitted:.7f}")
    print("  positive actual marked flow",f"{float(input_flow):.8e}",
          "; spectral income",f"{float(actual_scale)*exact:.8e}")


def exact_cases(weights,total_mass):
    u=(1,1,1)
    # Flat star and uniform rectangle: for all-ones r-by-s support the
    # upper bound sqrt(r*s) is attained by its normalized rank-one matrix.
    single("Flat star",mat(((1,1,1),(0,0,0),(0,0,0))),u,u,(1,1),
           "sqrt(3)",sqrt(3),"sqrt(3)",sqrt(3),0,weights,total_mass)
    single("Uniform 2x3 block",mat(((1,1,1),(1,1,1),(0,0,0))),u,u,(2,2),
           "sqrt(6)",sqrt(6),"sqrt(6)",sqrt(6),1,weights,total_mass)
    # Star constrained on one row: ||T_{row}||_2<=1, optimum is m/||m||.
    assert 1<F(8,7)<F(98,81)
    single("Unequal star",mat(((F(1,9),F(4,9),1),(0,0,0),(0,0,0))),u,u,
           (F(1,9),1),"4/sqrt(14)",4/sqrt(14),"sqrt(98)/9",sqrt(98)/9,2,weights,total_mass)
    # For a nonnegative T the dual majorant J_2 + [1/2] supplies
    # the upper bound 2+1/2. Equality: swap the first labels, fix third.
    ell = mat(((1,1,0),(1,0,0),(0,0,F(1,2))))
    dual = mat(((1,1,0),(1,1,0),(0,0,F(1,2))))
    assert all(a<=b for row,top in zip(ell,dual) for a,b in zip(row,top))
    assert pairing(ell,(1,0,2))==F(5,2)
    single("Padded L / active nonnegativity",ell,u,u,
           (F(3,2),F(5,2)),"1+sqrt(2)",1+sqrt(2),"5/2",2.5,3,weights,total_mass)
    assert F(2)**2<5
    print("  Dual upper certificate J_2 direct-sum [1/2] has nuclear norm 5/2.")
    print("  Unconstrained signed optimum for the padded L is 1/2+sqrt(5) > 5/2.")
    # Rank-one real unequal shares: a^T T b <= ||a|| ||b||. The
    # normalized outer product is a nonnegative norm-one certificate.
    assert (1+16+81)*(16+1+1)==42**2 and F(360)**2/F(84)<41**2<42**2
    single("Unequal real source shares",mat(((1,1,1),)*3),(1,4,9),(4,1,1),
           (17,41),"360/sqrt(84)",360/sqrt(84),"42",42.,4,weights,total_mass)


if __name__=="__main__":
    print("Python",sys.version.split()[0],"CVXPY",cp.__version__,"| CLARABEL numerical candidates and algebraic certificates")
    v,w,S=geometry()
    for k in (3,5):
        cyclic(k,v,w,S)
    exact_cases(w,S)
    print("All assertions passed. Exact certificates and numerical candidate values are stated separately.")
    print("Scope: frozen true fibre kernels on positive boxes.")
