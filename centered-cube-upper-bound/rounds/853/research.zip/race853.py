"""Exact all-competitor marked races and cross-parent four-corner density."""
from argparse import ArgumentParser
from collections import namedtuple
from decimal import Decimal, localcontext
from fractions import Fraction as F
from hashlib import sha256
from itertools import product
from pathlib import Path
from zipfile import ZipFile
import sys

PIN = "d7e0cc5e31eb94cd6bb536dca40af122bc4793adfdf0dfb43e0e2b94be01c674"
CORE = F(1, 4096)
PACK = F(1, 128)
SIGMA = F(3, 2)
Parent = namedtuple("Parent", "name side bin rho graph")


def model(path):
    assert sha256(path.read_bytes()).hexdigest() == PIN
    with ZipFile(path) as archive:
        name = "handoff850.py"
        env = {"__name__": "pinned_fixture", "__file__": name}
        exec(compile(archive.read(name), name, "exec"), env)
    return env


def fmt(q):
    with localcontext() as ctx:
        ctx.prec = 15
        return f"{Decimal(q.numerator) / Decimal(q.denominator):.8E}"


def point(k, a, z):
    return k.graph.get((a, z), 0)


def anchor_flux(root, other, w, u):
    """Intensities in units of rho_unit times the common source mass squared."""
    left = right = joint = both_four = F(0)
    for (a, z), anchor in other.graph.items():
        intensity = other.rho * anchor
        l, r = point(other, w, z), point(other, a, u)
        left += intensity * l
        right += intensity * r
        hit = intensity * l * r
        joint += hit
        both_four += hit * point(other, w, u) * point(root, a, z) * point(root, w, z) * point(root, a, u)
    competition = left + right - joint
    assert 0 <= both_four <= joint <= competition
    return left, right, joint, both_four, competition


def payments(root, candidates):
    # The nonempty resampling sets are exactly the contributing competitors.
    assert all(y.bin < root.bin and y.side < root.side for y in candidates)
    total = best = common = cross = source_rows = F(0)
    result = {}
    for (w, u), weight in root.graph.items():
        fluxes = [anchor_flux(root, other, w, u) for other in candidates]
        union = sum(flux[-1] for flux in fluxes)
        free = max((q / a for _, _, q, _, a in fluxes if a), default=F(0))
        simultaneous = sum(f[2] for f in fluxes) / union if union else F(0)
        common_four = sum(f[3] for f in fluxes) / union if union else F(0)
        assert 0 <= common_four <= simultaneous <= free <= 1
        total += weight
        best += weight * free
        common += weight * simultaneous
        cross += weight * common_four
        source_rows += weight * sum(f[3] for f in fluxes)
        result[w, u] = (free, simultaneous, common_four, fluxes)
    return (best / total, common / total, cross / total), result, root.rho * source_rows


def mixed_square(a, b):
    # Integrate over ordered w,w',u,u' using the ACTUAL common packet mass.
    # M^4 factored out, and rho_a,rho_b supplied by the caller.
    rows = {}
    for (w, u), g in a.graph.items():
        h = point(b, w, u)
        if h:
            rows.setdefault(w, {})[u] = g * h
    return sum(sum(g * other.get(u, 0) for u, g in row.items()) ** 2
               for row in rows.values() for other in rows.values())


def comparison(parents):
    diagonals = [row.rho ** 2 * mixed_square(row, row) for row in parents]
    off = sum(a.rho * b.rho * mixed_square(a, b)
              for a in parents for b in parents if a.name != b.name)
    strict = sum(a.rho * b.rho * mixed_square(a, b)
                 for a in parents for b in parents if a.side > b.side)
    assert len({r.side for r in parents}) == len(parents) and off == 2 * strict
    norm = sum(diagonals) + off
    assert norm > 0
    assert (strict + sum(diagonals)) / norm >= F(1, 2)
    # Check the cross-corner raw numerator independently by enumerating anchors.
    direct = F(0)
    for root in parents:
        earlier = [other for other in parents if other.side < root.side]
        direct += payments(root, earlier)[2]
    assert direct == strict
    return diagonals, off, strict, norm


def initial(module):
    n = 64
    fixture, _, packet = module["real_fixture"](n)
    p, _, _, _ = module["kernels"](fixture, n, 8)
    e = module["normal_state"](fixture, 58)
    focus = fixture[e // 2]
    rho_unit = (2 * CORE) ** n

    def projected(r):
        return Parent(str(r.slot), r.side, r.bin, r.volume / (r.side ** (2 * n) * rho_unit),
                      {(0, 0): r.g})

    root = projected(focus)
    candidates = [projected(fixture[end // 2]) for end in p[e]]
    assert [c.bin for c in candidates] == [47, 48, 49]
    ratios, table, explicit = payments(root, candidates)
    bound = sum(root.rho * x.rho * mixed_square(root, x) for x in candidates)
    assert bound == explicit
    assert 0 < ratios[-1] < ratios[1] < ratios[0] < 1
    print("INITIAL pinned R850/852 true n=64 path cores, root bin 58, H/t=8 candidates", [y.bin for y in candidates])
    print("  kappa is real R850 g; actual whole-bin first-step scale/geometry mask, no R852 full histories.")
    print("  marked rates left,right,Q,A (physical units divided by rho_unit*M^2):",
          *(fmt(sum(flux[i] for flux in table[0, 0][3])) for i in (0, 1, 2, 4)))
    print("  normalized paid root fractions best parent / common / both-parent four corners:",
          *(fmt(value) for value in ratios))


def physical_parents(n, h):
    m = 3 * h
    points = [(F(2 * (i % 8) - 7, 64), F(2 * (i // 8) - 5, 64))
              for i in range(2 * m)]
    # Ordered left and right roles use disjoint true source packets.
    assert all(max(abs(a - b) for a, b in zip(x, y)) > 2 * PACK
               for i, x in enumerate(points) for y in points[i + 1:])
    side = (F(1), F(5, 4), F(3, 2))
    weights = (F(1), F(1, 2), F(1))
    centers = (F(-1, 8), F(0), F(1, 8))
    dist = [CORE * l ** 2 for l in side]
    assert all(y - x > dx + dy for x, y, dx, dy in zip(centers, centers[1:], dist, dist[1:]))
    ranks = []
    for c, l, width, weight in zip(centers, side, dist, weights):
        assert abs(c) + width + 1 < 4 and 0 < weight <= 1
        assert all(max(abs(a - c), abs(b)) + width + PACK < l / 2 for a, b in points)
        assert width + PACK < l / 2
        ranks.append(next(j for j in range(n + 1) if 2 ** j >= l ** n))
        # One transverse side of this positive receiver box is reduced by weight.
        assert (2 * width) ** n * weight / l ** (2 * n) == (2 * CORE) ** n * weight
    assert ranks[0] < ranks[1] < ranks[2]
    group0, group1, group2 = range(h), range(h, 2 * h), range(2 * h, 3 * h)
    distract = {edge: F(1) for edge in product((*group0, *group2), group2)}
    bridge = {edge: F(1) for a, z in ((group0, group1), (group1, group0), (group1, group1))
              for edge in product(a, z)}
    root = {edge: F(1) for edge in product(group0, group0)}
    root[h, h] = F(1)
    eta_mass = 2 * m * SIGMA * (2 * PACK) ** n
    graphs = distract, bridge, root
    assert all(0 < g <= 1 for table in graphs for g in table.values())
    parents = [Parent(name, l, j, rho, graph) for name, l, j, rho, graph
               in zip(("one-sided", "three-edge", "root"), side, ranks, weights, graphs)]
    return parents, eta_mass


def pressure(n, h, name):
    parents, eta = physical_parents(n, h)
    early, bridge, root = parents
    values, table, incident = payments(root, parents[:-1])
    assert table[0, 0][:3] == (F(1, 3), F(1, 7), F(0))
    assert table[h, h][:3] == (F(1), F(1), F(1, 3 * h ** 2))
    assert values == ((F(h ** 2, 3) + 1) / (h ** 2 + 1),
                      (F(h ** 2, 7) + 1) / (h ** 2 + 1),
                      F(1, 3 * h ** 2 * (h ** 2 + 1)))
    diags, off, strict, norm = comparison(parents)
    assert diags == [4 * h ** 4, F(7, 4) * h ** 4, h ** 4 + 1]
    assert off == 1 and strict == F(1, 2) == incident
    print(f"{name}, n={n}, equal positive packets={6*h}, eta={eta}, true bins {[y.bin for y in parents]}")
    print("  rho/rho_unit (all competitors); base root I/(rho_unit*M^2):",
          [y.rho for y in parents], h ** 2 + 1)
    print("  main root: (P-,P+,Q,Qfour,A) each true competitor:", table[0, 0][3])
    print("  main root best/common/four:", *table[0, 0][:3],
          "; exceptional single true cell:", *table[h, h][:3])
    print("  entire main-parent I paid best/common/four:", *values)
    print("  square in units rho_unit^2*M^4: same-core terms", diags,
          "cross-core", off, "strict earlier cross", strict, "cross/whole", off / norm)
    print("  strict-earlier/cross =", strict / off,
          "; non-strict-order/whole =", (strict + sum(diags)) / norm)
    print("  Same-core terms include two independent continuous positions; exact equality has zero mass.")


if __name__ == "__main__":
    parser = ArgumentParser()
    parser.add_argument("--handoff", required=True, type=Path, help="pinned R850 research.zip")
    args = parser.parse_args()
    print("Python", sys.version.split()[0], "Fraction exact; baseline decimals rounded.")
    print("True sigma=3/2 background; lambda=1; rho=|E|/v^2; M is a real packet mass.")
    print("All original competing rates remain in A=P-+P+-Q; both-parent gate only lowers numerator.")
    print("Four corners include distinct actual points from the same packet; no label exclusions.")
    print("New pressure boxes use strict true-bin matching and kappa<=1; they do not impose R852 histories.")
    initial(model(args.handoff))
    pressure(4, 2, "PRESSURE")
    pressure(16, 8, "EXPANDED")
