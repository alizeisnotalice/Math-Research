"""R853 true packet incidence, R852 degree gate, and cross-parent Gram replay."""

from fractions import Fraction as F
from itertools import product
from math import isqrt
import sys

from flint import arb, ctx, __version__ as flint_version


def geometry_parameters(n,k):
    assert n%2==0 and 1<=k<=n//2
    # All coordinates here are divided by the true side l=sqrt(2).
    a = F(1,2)-F(1,100*n)
    rho = F(1,1000*n)
    assert a+2*rho < F(1,2)
    assert 3*a-2*rho > 0 and (3*a-2*rho)**2 > F(1,2)
    assert 2*a>2*rho
    first_visible_ratio = 2*(a-2*rho)
    assert first_visible_ratio == 1-F(3,125*n)
    # Bernoulli: (ell'/l)^n >= (1-3/(125n))^n >= 122/125
    # for any l' on the real core which sees positive source mass.
    assert F(6,5)/F(122,125)==F(75,61)<2
    return a,rho


def distance(x,y):
    return max(abs(a-b) for a,b in zip(x,y,strict=True))


def small_incidence(k):
    n=2*k
    a,rho=geometry_parameters(n,k)
    signs=tuple(product((-1,1),repeat=k))
    count=len(signs)
    assert count==2**k
    Z=(F(0),)*k
    A=tuple(tuple(2*a*v for v in sign)+Z for sign in signs)
    B=tuple(Z+tuple(2*a*v for v in sign) for sign in signs)

    def inside(source,center):
        d=distance(source,center)
        if d+2*rho<F(1,2):
            assert d==a and d-2*rho==a-2*rho
            return True
        assert d-2*rho>0 and (d-2*rho)**2>F(1,2)
        return False

    parents={}
    p_cap=F(11,500*n)**(2*k)
    for i,h in product(range(count),repeat=2):
        center=tuple(a*v for v in signs[i]+signs[h])
        left=tuple(j for j,p in enumerate(A) if inside(p,center))
        right=tuple(j for j,p in enumerate(B) if inside(p,center))
        assert (left,right)==((i,),(h,))
        parents[i,h]=center
        # Source-tuple spans over A_i,A_i,B_h,B_h. For one coordinate,
        # the smallest possible span is the gap of the two closed source
        # intervals; repeat the nearest endpoint within each packet.
        gap=tuple(max(F(0),abs(x-y)-2*rho) for x,y in zip(A[i],B[h]))
        overlap_sup=F(1)
        for d in gap:
            overlap_sup*=max(F(0),1-d)
        assert sum(d>0 for d in gap)==2*k
        assert overlap_sup==p_cap
    assert len(set(parents.values()))==count**2

    # For fixed physical s in A_i, draw two parents independently
    # under degree times Lebesgue core divided by lambda*l^(2n).
    # Every parent y_ih has the same real receiving weight.
    right_gram=F(0)
    left_gram=F(0)
    for i in range(count):
        h_labels=[h for p,h in parents if p==i]
        assert len(h_labels)==count
        # Partner overlaps normalized by m are exactly the Kronecker
        # delta, because the positive B packets are disjoint.
        right_gram+=F(sum(h==q for h,q in product(h_labels,repeat=2)),count**2)
        i_labels=[h for h,p in parents if p==i]
        assert len(i_labels)==count
        left_gram+=F(sum(h==q for h,q in product(i_labels,repeat=2)),count**2)
    assert right_gram/count==left_gram/count==F(1,count)
    # All parents have exactly one labelled edge. A local permutation
    # can contain that edge. Any single global permutation uses N of
    # N^2 cores. For a fixed arbitrary norm-one nonnegative T,
    # sum_ih T_ih <= ||1||^2=N; J_N/N attains it.
    fixed_capture=F(sum(i==h for i,h in parents),len(parents))
    assert fixed_capture==F(1,count)
    raw_ratio=F(3,10)*count/F(500*n)**n
    print("Geometry k",k,"n",n,"N*",count,";",len(parents),"actual parent incidences checked.")
    print("  Fixed-source conditional squared Gram (both orientations)",right_gram/count,
          "; locally matched 1; best global perm or common contraction",fixed_capture)
    print("  ordered raw/S",raw_ratio)
    # In units lambda*l^n, m=3/5. Each fixed-source parent has one
    # full corner triple of volume m^3, and N* real parents have total
    # triple volume N*m^3. The normalized comparison divisor is m^2.
    m=F(3,5)
    triple=count*m**3
    cap=4*triple*p_cap/m**2
    row=m*count/F(500*n)**n
    assert cap==F(12,5)*count*p_cap and row==2*raw_ratio
    assert row/cap==F(1,4*11**n)
    print("  Triple mass/(lambda*l^n)^3",triple,"; exact sup p_j",p_cap)
    print("  Original source row",row,"; geometric cap",cap,"; row/cap",row/cap)


def source_row_logs(n,k):
    log2=arb(2).log()
    log_unit=arb(500*n).log()/log2
    log_p=2*k*(arb(11).log()/log2-log_unit)
    log_row=(arb(3)/5).log()/log2 + k - n*log_unit
    log_cap=(arb(12)/5).log()/log2 + k + log_p
    quotient=-2-n*arb(11).log()/log2
    assert n==2*k
    assert (log_row-log_cap).overlaps(quotient)
    assert log_row<log_cap<0
    print("  log2(p_j cap, original row, geometric row cap, row/cap):",
          *(x.str(11) for x in (log_p,log_row,log_cap,quotient)))


def uniform_source_row_cap():
    # For k=n/2 the cap is (12/5)*(c/n)^n, c=11*sqrt(2)/500.
    # Its n+2/n ratio is (c/(n+2))^2*(n/(n+2))^n < 1.
    assert 2*F(11,500)**2<1
    first=F(12,5)*2*F(11,1000)**2
    assert first==F(363,625000)<F(1,1000)
    print("For even n>=2 and k=n/2, geometric row cap decreases from",first,"< 1/1000.")


def gates(n):
    n=int(n)
    b=isqrt(n-1)+1
    assert (b-1)**2<n<=b*b
    H=8*(b+2)
    ell=arb(n+2).log()
    floor_ell=ell.floor().unique_fmpz()
    ceil_ell2=(ell**2).ceil().unique_fmpz()
    assert floor_ell is not None and ceil_ell2 is not None
    q,c=int(floor_ell),int(ceil_ell2)
    assert q<ell<q+1 and c-1<ell**2<c
    mpar=min(q,1+H//16)
    J=max(c,4*(mpar-1)**2)
    a0=J*(b+1)
    j=n//2
    assert j<=n-b-1
    gap=j-a0
    print("n",n,"b",b,"m_par",mpar,"J",J,"a0",a0,"j",j,"gap",gap)
    if gap<0:
        print("  outside j>=a0; Gamma not evaluated")
        return "ineligible",gap
    gamma=arb(b)*(arb(2)**(-gap)+1/arb(1+gap)**2)
    target=arb(3)/5
    accepted=gamma<target
    assert accepted or gamma>target
    assert (gamma**4<target**4 if accepted else gamma**4>target**4)
    print("  Gamma/(lambda*l^n)",gamma.str(10),"; strict packet degree gate",
          "PASS" if accepted else "FAIL")
    if accepted and n>=2**21:
        k=n//2
        geometry_parameters(n,k)
        # No source-label arrays or big powers for the high-dimensional model.
        log2=arb(2).log()
        log_raw=(arb(3)/10).log()/log2 + k - n*arb(500*n).log()/log2
        assert log_raw < -n
        print("  k=n/2: log2 conditional squared Gram, global matched fraction",-k,
              "; local matched fraction 1; log2(raw/S)",log_raw.str(11))
        source_row_logs(n,k)
    return ("pass" if accepted else "fail"),gap


def certify_uniform_pass_range():
    n0=2**21
    n1=3_000_000
    assert 1449**2>=n0 and 1450**2>n0
    assert arb(n1+2).log()<15 and arb(n1+2).log()>5
    # On [n0,n1]: mpar<=14 and J<=676. The lower envelope
    # n/2-676*(sqrt(n)+2) is increasing and >= 67024.
    gap_lower=n0//2-676*1452
    assert gap_lower==67024 and isqrt(n1-1)+1==1733
    assert F(2*1733,(1+gap_lower)**2)<F(3,5)
    # For n>=n1, (ell-1)^2/sqrt(n) decreases once ell-1>4.
    # Since J<=4*(ell-1)^2, a0/n<=4*(ell-1)^2/sqrt(n)*(1+2/sqrt(n)).
    assert 1732**2<n1
    assert 4*14**2*F(1,1732)*(1+F(2,1732))<F(23,50)
    # gap >= n/25. For gap>=6, 2^(-gap)<=(1+gap)^(-2).
    # Therefore Gamma/v <= 2500/n^(3/2).
    assert n1//25>6 and F(2500,n1*1732)<F(3,5)
    print("Uniform algebraic/Arb-backed bound: strict degree gate for every even n>=2^21.")


if __name__=="__main__":
    ctx.prec=192
    print("Python",sys.version.split()[0],"python-flint",flint_version,"| exact Fraction and 192-bit Arb")
    print("True packet mass m=3*lambda*l^n/5; same-fibre four-corner integral m^4.")
    print("All real core heights on [1,2] lie in [6/5,75/61] times lambda; l=sqrt(2).")
    for k in (2,4):
        small_incidence(k)
    uniform_source_row_cap()
    certify_uniform_pass_range()
    expected={
        2**20:("ineligible",-66112),
        1_830_608:("fail",0),
        1_830_610:("ineligible",-675),
        1_832_052:("fail",46),
        1_832_054:("pass",47),
        2**21:("pass",68376),
        2**22:("pass",490736),
        2**24:("pass",4701308),
    }
    for n,want in expected.items():
        assert gates(n)==want
    print("General ordered raw/S=(3/10)*N*/(500n)^n. These are local geometric gate tests.")
