"""Exact four-corner walks on a chain of positive-width partner packages."""
from argparse import ArgumentParser
from fractions import Fraction as F
from math import prod
import sys

CORE = F(1, 4096)
PACK = F(1, 128)
SIGMA = F(3, 2)


def side_at(n, k):
    scale = 2 ** 14
    target = 2 ** (k + 14 * n)
    lo, hi = scale, 2 * scale + 1
    while hi - lo > 1:
        mid = (lo + hi) // 2
        if mid ** n <= target:
            lo = mid
        else:
            hi = mid
    side = F(lo, scale)
    assert 1 <= side <= 2 and F(2) ** (k - 1) < side ** n <= 2 ** k
    return side


def actual_parents(n, m, varied, cut=None):
    centers = [F(2 * i - m - 1, 64) for i in range(m + 2)]
    assert all(z - w > 2 * PACK for w, z in zip(centers, centers[1:]))
    side = [side_at(n, i) for i in range(m)]
    half = [CORE * s ** 2 for s in side]
    receiver = [F(2 * j - m + 1, 512) for j in range(m)]
    assert all(z - w > x + y for w, z, x, y in zip(receiver, receiver[1:], half, half[1:]))
    for y, small, s in zip(receiver, half, side):
        assert abs(y) + small + 1 < 4
        assert all(abs(y - x) + small + PACK < s / 2 for x in centers)
        assert small + PACK < s / 2
    rho_factor = [F(1)] * m
    left = [{m - 1: F(1)}]  # the old parent at bin 0
    auxiliary = [{m - 1: F(1, 2)}]
    varied_s = ((F(3, 4), F(1)), (F(1), F(2, 3)), (F(2, 3), F(3, 4)))
    varied_w = ((F(1, 2), F(1, 3)), (F(1, 3), F(2, 3)), (F(3, 4), F(1, 2)))
    if varied:
        assert m == 4
        rho_factor = list(map(F, ("1", "1", "1/2", "3/4")))
    for j in range(m - 1):
        s_weights = varied_s[j] if varied else (F(3, 4), F(3, 4))
        w_weights = varied_w[j] if varied else (F(1, 2), F(1, 2))
        keep = 1 if cut == j else 2  # real bridge parent remains, link gate is restricted
        left.append({j + k: s_weights[k] for k in range(keep)})
        auxiliary.append({j + k: w_weights[k] for k in range(keep)})
    rho = [f * (2 * r) ** n / s ** (2 * n) for f, r, s in zip(rho_factor, half, side)]
    rho_unit = (2 * CORE) ** n
    assert [q / rho_unit for q in rho] == rho_factor
    assert all(0 < v <= 1 for maps in (*left, *auxiliary) for v in maps.values())
    mpacket = SIGMA * (2 * PACK) ** n
    return left, auxiliary, rho, rho_unit, mpacket


def completion_energy(left, auxiliary, mass):
    ratios = []
    diagnostic = []
    for y, rows in enumerate(zip(left, auxiliary)):
        for s, gates in enumerate(rows):
            degree = mass * sum(gates.values())
            g = [mass * sum(value * row.get(u, 0) for u, value in gates.items())
                 for row in rows]
            support = mass * sum(v > 0 for v in g)
            assert degree > 0 and support > 0
            energy = dual = F(0)
            for u, weight in gates.items():
                incoming = [row.get(u, F(0)) for row in rows]
                dplus = mass * sum(incoming)
                omega = mass * sum(v * q for v, q in zip(incoming, g))
                assert omega > 0 and all(a == 0 or q > 0 for a, q in zip(incoming, g))
                upper = mass * sum(a / q for a, q in zip(incoming, g) if a)
                term = dplus ** 2 / omega
                assert 0 < term <= upper
                energy += mass * weight * term
                dual += mass * weight * upper
                diagnostic.append((omega / mass ** 2, y, s, u, term / upper,
                                   len(ratios), degree / mass, support / mass))
            assert 0 < energy <= dual == support
            ratios.append(energy / support)
    omega, y, s, u, local, row_number, scaled_d, scaled_l = min(diagnostic)
    return (min(ratios), max(ratios), len(ratios),
            (y, s, u, omega, local, ratios[row_number], scaled_d, scaled_l))


def four_corner(n, m, varied, cut):
    left, other, rho, unit, mass = actual_parents(n, m, varied, cut)
    unnorm = [[F(0)] * m for _ in range(m)]
    for gates, partner, ry in zip(left, other, rho):
        for a, z in ((a, z) for a in gates for z in gates):
            # The true w-integral is over two equal positive-width source
            # packets, one containing the fixed s and the other independent of s.
            shared = mass * (gates[a] * gates[z] + partner[a] * partner[z])
            unnorm[a][z] += ry * gates[a] * gates[z] * shared
    row_mass = [mass * sum(row) for row in unnorm]
    assert all(q > 0 for q in row_mass)
    assert all(unnorm[a][z] == unnorm[z][a] for a in range(m) for z in range(m))
    p = [[mass * unnorm[a][z] / max(row_mass[a], row_mass[z]) for z in range(m)]
         for a in range(m)]
    assert all(p[a][z] == p[z][a] for a in range(m) for z in range(m))
    kills = [1 - sum(row) for row in p]
    assert min(kills) >= 0
    h = [left[0].get(a, F(0)) for a in range(m)]
    assert left[1][0] > 0 and h[0] == 0 and h[-1] == 1
    energy = completion_energy(left, other, mass)
    return p, h, tuple(q / unit for q in rho), row_mass, kills, unit, mass, energy


def apply(matrix, vector):
    return [sum(x * a for x, a in zip(row, vector)) for row in matrix]


def solve(matrix):
    m = len(matrix)
    for i in range(m):
        pivot = next(j for j in range(i, m) if matrix[j][i])
        matrix[i], matrix[pivot] = matrix[pivot], matrix[i]
        pivot_value = matrix[i][i]
        matrix[i] = [x / pivot_value for x in matrix[i]]
        for j in range(m):
            if j != i and matrix[j][i]:
                factor = matrix[j][i]
                matrix[j] = [a - factor * b for a, b in zip(matrix[j], matrix[i])]
    return [row[-1] for row in matrix]


def ever_hit(p, target):
    possible = {target}
    while True:
        prior = possible.copy()
        possible |= {i for i, row in enumerate(p) if any(row[j] for j in prior)}
        if possible == prior:
            break
    free = sorted(possible - {target})
    matrix = [[F(i == j) - p[i][j] for j in free] + [p[i][target]] for i in free]
    eventual = [F(0)] * len(p)
    eventual[target] = F(1)
    for i, value in zip(free, solve(matrix)):
        eventual[i] = value
    assert all(F(0) <= z <= 1 for z in eventual)
    first = apply(p, eventual)
    assert all(first[i] == eventual[i] for i in range(len(p)) if i != target)
    return eventual


def readable(q):
    if q.denominator.bit_length() <= 53:
        return str(q)
    scale = 10 ** 9
    floor = q.numerator * scale // q.denominator
    integer, truncated = divmod(floor, scale)
    return f"{integer}.{truncated:09d}↓"


def show(name, n, m, varied, horizon, cut=None, threshold=None):
    p, h, rates, row_mass, kill, rho_unit, mass, energy = four_corner(n, m, varied, cut)
    direct, hit = h.copy(), h.copy()
    values, passage = [direct[0]], [hit[0]]
    high = h.copy()
    for _ in range(horizon):
        direct = apply(p, direct)
        hit = apply(p, hit)
        hit[-1] = F(1)
        assert all(a <= b for a, b in zip(direct, hit))
        values.append(direct[0])
        passage.append(hit[0])
        high = [max(a, b) for a, b in zip(high, direct)]
    eventual = ever_hit(p, m - 1)
    assert all(a <= b for a, b in zip(hit, eventual))
    min_time = m - 1
    path = prod(p[i][i + 1] for i in range(min_time))
    assert all(x == 0 for x in values[:min_time]) and values[min_time] == path
    if threshold is None:
        assert path > 0
        threshold = path / 2
    if cut is not None:
        assert not any(values) and eventual[0] == 0
    else:
        assert values[min_time] >= threshold and passage[-1] > values[-1]
    print(f"{name}: n={n}, partner packets={m}, bin 0 old, remaining true bins 1..{m-1}")
    print("  eta total, rho unit, individual rho/rho_unit:",
          (m + 2) * mass, rho_unit, " ".join(map(str, rates)))
    print("  a_s/(rho_unit*M^2), row death probabilities:",
          " ".join(str(a / (rho_unit * mass ** 2)) for a in row_mass),
          ";", " ".join(map(str, kill)))
    print("  U0: direct h, first nonzero-time path product:", h[0], path,
          "; threshold inherited/selected:", threshold)
    print("  U0: fixed-time probabilities m=0..horizon:", " ".join(map(readable, values)))
    print("  finite horizon thresholds hit packets", [i for i, x in enumerate(high) if x >= threshold],
          "; U0 first hit by horizon:", readable(passage[-1]), "; ever before death:", eventual[0])
    lo, hi, n_rows, rare = energy
    print("  completion energy / l (min,max over true source rows), row count:", lo, hi, n_rows)
    print("  smallest positive omega edge (bin,s,u,omega/M^2,local CS ratio,row ratio,d/M,l/M):",
          *rare)
    return threshold


if __name__ == "__main__":
    parser = ArgumentParser()
    parser.add_argument("--horizon", type=int, default=9, help="any integer at least 8")
    M = parser.parse_args().horizon
    assert M >= 8
    print("Python", sys.version.split()[0], "Fraction exact; ↓ is rounded down within 10^-9.")
    print("Real positive-width parents with prescribed soft gates; full R852 histories are not imposed.")
    print("s is fixed in its real source packet, M in formulas is one packet mass.")
    print("Completion-energy audit uses both left rows of each true parent; sigma=3/2, lambda=1.")
    print("L converts to P=L*deta; row deficit is death; h is the true old parent's target indicator.")
    show("INITIAL", 4, 3, False, M)
    same_threshold = show("CONNECTED SOFT PRESSURE", 4, 4, True, M)
    show("SAME REAL PARENTS, BRIDGE GATE DISCONNECTED", 4, 4, True, M,
         cut=1, threshold=same_threshold)
    show("EXPANDED", 8, 8, False, M)
