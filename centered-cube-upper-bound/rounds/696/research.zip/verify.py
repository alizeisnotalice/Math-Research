from fractions import Fraction as F
from flint import arb,ctx
from pathlib import Path
import json
from math import isqrt
ctx.prec=768
I=6*arb(2).sqrt()*(1+arb(2).sqrt()).log()-4*arb(2).log()-4
J=2*arb(2).sqrt()*(1+arb(2).sqrt()).log()
assert I>0 and I.sqrt()<arb('0.841') and J>0 and J<arb('2.493')
# Exact sign and bound from rational-integral series for I,J (independent of logarithm expressions).
# Negative edge y=1+v: 1/T = sum_{k>=0} y^(2k)/2^k. Positive edge rho²/T=2.
i0=F(2,3);j0=F(2)
for k in range(160):
    m=2*k+2
    i0+=(F(1,m+1)-F(2,m+2)+F(1,m+3))/2**k
    j0+=F(1,(m+1)*2**k)
def ab(x):return arb(x.numerator)/x.denominator
tail=F(1,2**159)
assert ab(i0)<I<ab(i0+tail) and ab(j0)<J<ab(j0+tail)
for n in (1,4,16,64,256):
    a=32*n; t=isqrt(n-1)+1; Q=t*a**n
    # Instead of resolving huge ceilings, the analytic ceiling inequality gives r_pre in (1/2, exp(1/Q)/2].
    assert arb(1)/2*(arb(1)/Q).exp()<1
    u=F(1,2);hi=1-F(1,a);lo=1-F(3,a)
    assert hi-2*u<0 and lo-4*u>-8
    print('cold n',n,'upper bound on centered S:',float((arb(9)/(2*a*a))**n) if n<64 else str(((arb(9)/(2*a*a))**n).str(6)), 'directional S >= 1/2')
files=[json.loads(Path(__file__).with_name(f+'.json').read_text()) for f in ('mini','laptop')]
rows=sum([j['rows'] for j in files],[])
assert [r['N'] for r in rows]==list(range(30,84))
for r in rows:
    assert 0<=F(r['poolmenu'])<=F(r['menu'])<=F(r['witness'])
print('PASS 54 actual inputs, component integrals, and five cold-family parameter tests.')
directions=sum([json.loads(Path(__file__).with_name(f+'-drift.json').read_text())['rows'] for f in ('mini','laptop')],[])
assert [r['N'] for r in directions]==list(range(30,84))
assert all(F(r['centered'])<F(r['covered'])<=F(r['bad']) for r in directions)
assert all(F(99644,100000)<F(r['covered'])/F(r['bad'])<F(99815,100000) for r in directions)
print('PASS: 54 finite directional allocations compared with the centered fixed width.')
