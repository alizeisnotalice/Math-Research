from fractions import Fraction as Q
from multiprocessing import get_context
from itertools import product
import json, sys, os, time, socket

def positive(x):return max(Q(0),x)

def response(d,u,b):
    # Mean over E=[d-b,d+b], of the smoothed source [-1,1].
    if u==0:return positive(min(d+b,1)-max(d-b,-1))/(2*b)
    def integral_cdf(s):
        return (positive(s+u)**3-2*positive(s)**3+positive(s-u)**3)/(6*u*u)
    def primitive(s):return integral_cdf(s+1)-integral_cdf(s-1)
    return (primitive(d+b)-primitive(d-b))/(2*b)

def case(N):
    start=time.process_time()
    b=Q(1,32); ys=[(2*i+1-N)*b for i in range(N)]
    ends=sorted({y+v for y in ys for v in (-1,1)})
    mids=[(a+c)/2 for a,c in zip(ends,ends[1:])]
    rows=[[m for m,x in enumerate(mids) if abs(x-y)<1] for y in ys]
    scales=[Q(v,32) for v in range(17)] # up to 1/2
    tab={(i,u):response(2*b*i,u,b) for i in range(N) for u in scales}
    remaining=set(range(N)); load=[Q(0)]*len(mids); selected=[]; first={}; D=Q(0)
    while remaining:
        caps={i:1-max(load[m] for m in rows[i]) for i in remaining}
        i=max(remaining,key=lambda j:(caps[j],-j))
        th=b*caps[i];D+=2*th;selected.append((i,th));remaining.remove(i)
        for m in rows[i]:load[m]+=th
        for j in remaining:
            if j in first or max(load[m] for m in rows[j])<Q(1,2):continue
            values=[sum(coef*tab[abs(j-l),u] for l,coef in selected) for u in scales]
            top=max(load[m] for m in rows[j])
            assert 0<=values[0]<=max(values)<=top
            witness=max(rows[j],key=lambda m:load[m])
            pool=[(l,coef) for l,coef in selected if witness in rows[l]]
            poolvalues=[sum(coef*tab[abs(j-l),u] for l,coef in pool) for u in scales]
            assert max(poolvalues)<=max(values)
            first[j]=tuple(2*b*v for v in (values[0],max(values),top,max(poolvalues)))
    totals=[sum((v[i] for v in first.values()),Q(0)) for i in range(4)]
    assert totals[0]<=D and totals[1]<=2*D
    return dict(N=N,D=str(D),bad=len(first),base=str(totals[0]),menu=str(totals[1]),witness=str(totals[2]),poolmenu=str(totals[3]),cpu=time.process_time()-start)
if __name__=='__main__':
    lo,hi,workers=map(int,sys.argv[1:]);start=time.monotonic()
    with get_context('fork').Pool(workers) as pool: rows=pool.map(case,range(lo,hi+1),1)
    print(json.dumps(dict(rows=rows,workers=workers,elapsed=time.monotonic()-start,host=socket.gethostname(),python=sys.version)))
