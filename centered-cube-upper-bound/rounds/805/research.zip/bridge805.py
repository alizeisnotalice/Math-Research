"""Exact bridge disintegration and scalar geometric costs for round 805.

Run with the research Python environment using -B and --check bridge805.json.
The continuum diagnostic is piecewise constant in the original source variable.
"""
import argparse
import hashlib
import itertools
import json
import math
import platform
from collections import defaultdict
from fractions import Fraction as F
from pathlib import Path

import flint
from flint import arb, ctx


def case(weights, mu, steps, required, start=0):
    # w[t][i] is the mass on row t and source interval i.
    # Each interval has length one and true source mass mu[i].
    nr, nc = len(weights), len(mu)
    w = [[F(v) for v in row] for row in weights]
    rows = [sum(r) for r in w]
    cols = [sum(r[i] for r in w) for i in range(nc)]
    assert all(rows) and all(cols) and all(mu)
    step = [[sum(w[t][i] / cols[i] * w[t][j] / rows[t]
                 for t in range(nr)) for j in range(nc)] for i in range(nc)]
    assert all(sum(q) == 1 for q in step)
    assert all(cols[i] * step[i][j] == cols[j] * step[j][i]
               for i in range(nc) for j in range(nc))
    terms = defaultdict(list)
    for path in itertools.product(range(nc), repeat=steps):
        left = start
        prob = F(1)
        for right in path:
            prob *= step[left][right]
            left = right
        if prob:
            terms[path[-1]].append((path[:-1], prob))
    terminal = [sum((p for _, p in terms[i]), F(0)) for i in range(nc)]
    assert sum(terminal) == 1

    # Directly enumerate ordered pairs of intermediate source strings.
    direct = []
    for y in range(nc):
        records = terms[y]
        total = sum((p * q for path, p in records for path2, q in records
                     if sum(a == b for a, b in zip(path, path2)) >= required), F(0))
        direct.append(total)
    # Independently evolve the two-walk state and truncate the count of hits.
    dp = {(start, start, 0): F(1)}
    for time in range(1, steps + 1):
        nxt = defaultdict(F)
        for (a, b, hits), mass in dp.items():
            for i, x in enumerate(step[a]):
                if not x:
                    continue
                for j, y in enumerate(step[b]):
                    if y:
                        h = min(required, hits + (time < steps and i == j))
                        nxt[i, j, h] += mass * x * y
        dp = nxt
    assert direct == [dp[i, i, required] for i in range(nc)]
    assert all(sum(dp[i, j, h] for j in range(nc) for h in range(required + 1))
               == terminal[i] for i in range(nc))

    shared = sum(d / p for d, p in zip(direct, terminal) if p)
    rejection = sum(direct) / sum(p * p for p in terminal)
    conditional = [d / (p*p) if p else None for d, p in zip(direct, terminal)]
    # Density w.r.t. the true, nonuniform measure; integrates over reachable intervals only.
    last_density = max(w[t][i] / rows[t] / mu[i] for t in range(nr) for i in range(nc))
    cell_max = max(w[t][i] / rows[t] for t in range(nr) for i in range(nc))
    ball_mass = sum(m for m, p in zip(mu, terminal) if p)
    certificate = last_density * ball_mass * math.comb(steps-1, required) * cell_max**required
    assert shared <= certificate
    assert shared == sum(p * c for p, c in zip(terminal, conditional) if p)
    assert shared != rejection
    return {
        "row_cell_mass": weights, "source_interval_masses": mu,
        "nsteps": steps, "required_interior_matches": required, "start": start,
        "terminal": list(map(str, terminal)), "conditional_matches": [
            str(c) if c is not None else None for c in conditional],
        "shared_exact_endpoint": str(shared), "independent_cell_rejection": str(rejection),
        "last_density": str(last_density), "row_cell_max": str(cell_max),
        "uniform_untruncated_bound": str(certificate),
        "positive_source_strings": sum(map(len, terms.values())),
        "two_exact_methods_agree": True,
    }


def bracket(z, scale=10**9):
    lower = z.lower() * scale
    upper = z.upper() * scale
    low = lower.floor().unique_fmpz()
    high = upper.ceil().unique_fmpz()
    assert low is not None and high is not None
    return [int(low), int(high), scale]


def scalar_checks():
    ctx.prec = 4096
    out = []
    log2 = arb(2).log()
    for power in (8, 64, 128, 192, 256, 512, 1024):
        n = 2**power
        ell = arb(n + 2).log()
        gap = arb(n).sqrt() * ell**8
        feasible = gap < (n-2) * log2
        if not feasible:
            assert gap > (n-2) * log2
            out.append({"dimension_power": power, "tested_dyadic_range_exists": False})
            continue
        low = int((gap / log2).ceil().unique_fmpz()) + 2
        for which, dyadic_shift in (("near_min", low), ("half", n // 2), ("near_max", n-2)):
            s = dyadic_shift * log2
            assert s > gap and s < n * log2
            a = arb(n) / s
            k = int((256 * a * (32 * (1+a)).log()).ceil().unique_fmpz()) + 4
            h = k // 2
            frac = n * arb(1 + 12*k).log() / (k*s)
            # Uses B<=1, the (proved for large n) one-step bound p<=exp(-3s/4),
            # K<=exp(s/16), and the true-source outer cap 256.
            log_risk = (arb(512).log() + s/16 - s + n*arb(1+12*k).log()
                        + k*log2 - 3*s*h/4)
            # Also check the explicit geometric union cost with B<=1 and the
            # dilation (1+gamma)^n=exp(s/16) and at most 2k K source/receiver pairs.
            # 2048 bounds 2*(512+2 h0**n) with h0=1+1/(32n).
            one_step = arb(2048*k).log() - 7*s/8
            assert one_step < -3*s/4
            assert frac < arb(1)/64 and log_risk < -k*s/4
            out.append({"dimension_power": power, "range": which, "log2_mass_ratio": str(dyadic_shift),
                        "steps": str(k), "h": str(h), "ball_cost_over_ks": bracket(frac),
                        "log_risk_over_ks": bracket(log_risk/(k*s)),
                        "explicit_one_step_below_minus_3s_over_4": True})
    return out


def data():
    cases = {
        "initial": case([[3, 2, 0], [1, 3, 1], [0, 2, 4]], [2, 5, 1], 3, 2),
        "rare_endpoint": case([[11, 1, 0, 0], [0, 7, 2, 0], [0, 0, 13, 1]],
                              [31, 2, 19, 1], 3, 2),
        "expanded": case([[4, 1, 0, 0, 3], [1, 9, 5, 0, 0], [0, 2, 4, 3, 0],
                          [0, 0, 1, 4, 2], [3, 0, 0, 2, 9], [1, 2, 0, 3, 0]],
                         [1, 11, 2, 17, 5], 4, 2),
    }
    assert cases["rare_endpoint"]["conditional_matches"][-1] == "1"
    return {"python": platform.python_version(), "flint": flint.__version__,
            "arithmetics": "Fraction; Arb 4096 bits, integer brackets [lower,upper,scale]",
            "cases": cases, "scalar": scalar_checks()}


if __name__ == "__main__":
    par = argparse.ArgumentParser()
    group = par.add_mutually_exclusive_group(required=True)
    group.add_argument("--write", type=Path)
    group.add_argument("--check", type=Path)
    opts = par.parse_args()
    contents = (json.dumps(data(), indent=2, sort_keys=True) + "\n").encode()
    if opts.write is not None:
        opts.write.write_bytes(contents)
    elif opts.check.read_bytes() != contents:
        raise SystemExit("result mismatch")
    print("PASS", hashlib.sha256(contents).hexdigest())

