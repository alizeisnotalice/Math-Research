"""Compressed genuine positive-loss history with separated radii; compare actual rooms."""
from fractions import Fraction as F
from math import isqrt
from flint import arb,ctx
import json
ctx.prec=256
def calc(n,eta):
    a=32*n
    K=4096*isqrt(n)*a**n
    ell=arb(2).log()/K
    d=-(-ell).expm1()
    rcv=F(1,16)
    x=F(3,50)
    u=rcv*(1+F(1,a))
    scale=[F(3),F(2),F(3,2),F(1)]
    widths=[]
    for sig in (-1,1):
        centers=[3-eta, -2+eta, F(0), -sig*F(63,64)]
        intervals=[(c-s,c+s) for c,s in zip(centers,scale)]
        assert max(l for l,h in intervals)<0<min(h for l,h in intervals)
        width=min(h for l,h in intervals)-max(l for l,h in intervals)
        pair=[min(intervals[k][1],intervals[l][1])-max(intervals[k][0],intervals[l][0])
              for k in (0,1) for l in (2,3)]
        widths.append([str(s) for s in pair])
        assert width==2*eta and min(pair)>=F(1,64)
    assert x-rcv/a+F(63,64)>1+F(6,n)
    assert x+rcv/a-u+F(63,64)<1
    assert x+rcv/a-u<eta
    z=(-ell).exp()
    vt=F(1,(8*a)**n)
    rh=arb(vt.numerator)/vt.denominator*ell.expm1()/2
    full_room=arb((eta+u).numerator)/(eta+u).denominator
    logroom=n*full_room.log()
    logcap=-3*n*arb(2).log()-(2*arb(3*n).sqrt()).log()
    logfirst=n*arb(32*n).log()+(K-5)*n*arb(4).log()+d.log()
    assert logfirst>(4*arb(6)**n+1).log()
    return dict(n=n,eta=str(eta),cross_widths=widths,common_width=str(2*eta),
                log_room_div_small= str(logroom),
                log_capacity_lower_div_small=str(logcap),
                log_room_over_cert=str(logroom-logcap),
                positive_high=str(rh),bad_volume=str(arb(1)/vt.denominator),
                owner_excess=0 if rh<arb(1)/(4*vt.denominator) else None,
                logD_div_K_lower=str(logfirst/K),logD_div_K_upper=str((logfirst+arb(3).log())/K))
print(json.dumps([calc(n,eta) for n in (256,1024,4096) for eta in (F(1,128),F(1,(32*n)**2))],indent=2))
