#!/usr/bin/env python3
"""Exact bounded C4 completion pruning, finite-cell coarea, prefix capacities."""
from fractions import Fraction as F
from itertools import product
from math import comb
from pathlib import Path
import hashlib,json,platform,random,socket,subprocess,sys
sys.set_int_max_str_digits(1000000)
BASE=Path(__file__).resolve().parent

def completion(B,wa,wb,factor=False):
    na=len(wa);nb=len(wb)
    if factor:
        G=[[sum((wb[b]*B[a][b]*B[c][b] for b in range(nb)),F(0)) for c in range(na)] for a in range(na)]
        return [[sum((wa[c]*G[a][c]*B[c][b] for c in range(na)),F(0)) for b in range(nb)] for a in range(na)]
    return [[sum((wa[c]*wb[d]*B[a][d]*B[c][d]*B[c][b] for c in range(na) for d in range(nb)),F(0))
             for b in range(nb)] for a in range(na)]
def mass(B,wa,wb):return sum((wa[a]*wb[b]*B[a][b] for a in range(len(wa)) for b in range(len(wb))),F(0))
def overlap_volume(a,b):
    ans=F(1)
    for (x,y),(u,v) in zip(a,b):ans*=max(F(0),min(y,v)-max(x,u))
    return ans

def graph_cases():
    cases=[];rng=random.Random(729)
    for stage,n,na,nb in [('initial',2,3,3),('pressure',3,6,7),('expanded',4,8,10)]:
        rows=[];cols=[]
        for count,bag in ((na,rows),(nb,cols)):
            for _ in range(count):
                centers=[F(2)+F(rng.randint(-3,3),4) for axis in range(n)]
                bag.append([(c-F(1,2),c+F(1,2)) for c in centers])
        B=[[overlap_volume(a,b) for b in cols] for a in rows]
        wa=[F(3*(a+1),4*sum(range(1,na+1))) for a in range(na)]
        wb=[F(2,3*nb)]*nb
        cases.append({'name':stage,'dimension':n,'row_rectangles':rows,'column_rectangles':cols,'B':B,'wa':wa,'wb':wb})
    # Actual equal-label cubes make B constantq and exactly saturate the pruning bound.
    for q in (F(1,8),F(1,2),F(1)):
        cases.append({'name':'sharp_constant_'+str(q),'dimension':1,
                      'row_rectangles':[[(F(0),F(1))]]*3,
                      'column_rectangles':[[(1-q,2-q)]]*4,
                      'B':[[q]*4 for _ in range(3)],'wa':[F(1,3)]*3,'wb':[F(1,4)]*4})
    return cases

def graph_data(factor=False):
    out=[]
    for case in graph_cases():
        B=case['B'];wa=case['wa'];wb=case['wb'];assert sum(wa)<=1 and sum(wb)<=1
        assert all(0<=x<=1 for row in B for x in row)
        R=completion(B,wa,wb,factor);values=sorted(set(x for row in R for x in row))
        thresholds=sorted({F(0),F(1)}|{values[int((len(values)-1)*q/8)] for q in range(9)})
        tests=[]
        for tau in thresholds:
            bad=[[B[a][b] if R[a][b]<=tau else F(0) for b in range(len(wb))] for a in range(len(wa))]
            d=mass(bad,wa,wb);Rb=completion(bad,wa,wb,factor)
            c4=sum((wa[a]*wb[b]*bad[a][b]*Rb[a][b] for a in range(len(wa)) for b in range(len(wb))),F(0))
            upper=sum((wa[a]*wb[b]*bad[a][b]*R[a][b] for a in range(len(wa)) for b in range(len(wb))),F(0))
            assert d**4<=c4<=upper<=tau*d and d**3<=tau
            tests.append({'tau':str(tau),'bad_edge_mass':str(d),'bad_mass_cubed':str(d**3),
                          'C4_bad':str(c4),'C4_using_original_completion':str(upper),
                          'tau_times_bad_mass':str(tau*d),'exact_pruning_holds':True,'sharp':bool(d>0 and d**3==tau)})
        out.append({'name':case['name'],'dimension':case['dimension'],
                    'row_rectangles':[[[str(x),str(y)] for x,y in r] for r in case['row_rectangles']],
                    'column_rectangles':[[[str(x),str(y)] for x,y in r] for r in case['column_rectangles']],
                    'row_weights':[str(x) for x in wa],'column_weights':[str(x) for x in wb],
                    'B':[[str(x) for x in row] for row in B],'completion_R':[[str(x) for x in row] for row in R],
                    'total_edge_mass':str(mass(B,wa,wb)),'tests':tests})
    # Omitting the subprobability hypothesis breaks d_bad^3<=tau.
    q=F(1,4);wa=[F(2)];wb=[F(2)];B=[[q]];R=completion(B,wa,wb,factor)
    tau=R[0][0];d=mass(B,wa,wb);assert d**3>tau
    return {'cases':out,'negative_control':{'B':'1/4','row_mass':'2','column_mass':'2','tau':str(tau),
                                         'bad_mass':str(d),'bad_mass_cubed':str(d**3),'pruning_fails':True}}

def arrangement(rectangles):
    n=len(rectangles[0]);N=len(rectangles);states={(1<<N)-1:F(1)}
    for axis in range(n):
        edges=sorted({v for r in rectangles for v in r[axis]});nxt={}
        for a,b in zip(edges,edges[1:]):
            mid=(a+b)/2;mask=sum(1<<i for i,r in enumerate(rectangles) if r[axis][0]<mid<r[axis][1])
            for old,vol in states.items():
                key=old&mask;nxt[key]=nxt.get(key,F(0))+vol*(b-a)
        states=nxt
    return {m:v for m,v in states.items() if m and v>0}

def coarea_fixtures():
    out=[]
    for N in (4,16,64,256):
        q=F(3,8);raw=[q+(1-q)*F(i,N-1) for i in range(N)];norm=sum(raw,F(0))
        out.append(('disjoint_near_sharp_'+str(N),[[(F(2*i),F(2*i+1))] for i in range(N)],
                    [v/norm for v in raw],[q/v for v in raw]))
    rectangles=[[(F(0),F(2)),(F(0),F(1))],[(F(1),F(3)),(F(0),F(2))],
                [(F(2),F(4)),(F(1),F(3))],[(F(0),F(3)),(F(2),F(4))],
                [(F(1),F(2)),(F(1),F(4))],[(F(3),F(5)),(F(0),F(3))]]
    theta=[F(i+1,21) for i in range(6)]
    out.append(('overlapping_rectangles',rectangles,theta,[F(1,8),F(3,4),F(1,3),F(1),F(1,2),F(0)]))
    out.append(('constant_z_zero_gap',rectangles,theta,[F(2,5)]*6))
    out.append(('zero_z',rectangles,theta,[F(0)]*6))
    return out

def coarea_data(independent=False):
    rows=[]
    for name,rectangles,theta,z in coarea_fixtures():
        cells=arrangement(rectangles);indices={m:[i for i in range(len(theta)) if m>>i&1] for m in cells}
        A=max(sum((theta[i] for i in ix),F(0)) for ix in indices.values())
        B=max(sum((theta[i]*z[i] for i in ix),F(0)) for ix in indices.values())
        thresholds=sorted({F(0),F(1)}|set(z));layers=[];L=F(0)
        loads={m:sum((theta[i] for i in ix if z[i]>0),F(0)) for m,ix in indices.items()}
        for left,right in zip(thresholds,thresholds[1:]):
            if independent:
                height=max(sum((theta[i] for i in ix if z[i]>left),F(0)) for ix in indices.values())
            else:
                if left>0:
                    for i in range(len(theta)):
                        if z[i]==left:
                            for m,ix in indices.items():
                                if i in ix:loads[m]-=theta[i]
                height=max(loads.values())
            L+=(right-left)*height;layers.append({'s_left':str(left),'s_right':str(right),'J_layer':str(height)})
        gap=L-B;assert 0<=gap and B<=A
        if not B:assert gap==0
        rows.append({'name':name,'rectangles':[[[str(x),str(y)] for x,y in r] for r in rectangles],
                     'theta':[str(v) for v in theta],'z':[str(v) for v in z],
                     'positive_volume_cells':[{'source_mask':str(m),'volume':str(v)} for m,v in sorted(cells.items())],
                     'A_J1':str(A),'B_Jz':str(B),'exact_layer_integral':str(L),'exact_layer_gap':str(gap),
                     'gap_over_A_exact':str(gap/A),'layers':layers})
    return rows

def betaterm(k,j):return F(comb(2*j,j)*comb(2*(k-j),k-j),4**k*comb(k,j))
def prefix_data():
    rows=[]
    for k in (4,8,16,64):
        capacity=sum((comb(k,j)*betaterm(k,j) for j in range(k+1)),F(0));assert capacity==1
        freely_optimized=sum((comb(k,j)*F(j,k)**j*F(k-j,k)**(k-j) for j in range(k+1)),F(0))
        assert freely_optimized**2<=4*k
        rows.append({'common_depth':k,'number_of_prefix_free_words':str(2**k),'total_arcsine_capacity':'1',
                     'sum_individually_optimized_shared_p_likelihoods_exact':str(freely_optimized),
                     'root_order_bound_squared_check':True,'per_step_independently_optimized_total':str(2**k)})
    words=['0','10','110','1110','1111']
    cap=sum((betaterm(len(w),w.count('1')) for w in words),F(0));assert cap==1
    grid=[]
    for i in range(17):
        p=F(i,16);prob=sum((p**w.count('1')*(1-p)**w.count('0') for w in words),F(0));assert prob==1
        grid.append({'p':str(p),'total_probability_exact':str(prob)})
    return {'fixed_depth':rows,'variable_depth_complete_prefix_code':words,'variable_depth_capacity_exact':str(cap),'p_grid':grid}

def exact_data(remote=False):return {'graphs':graph_data(remote),'coarea':coarea_data(remote),'prefix':prefix_data()}
def canonical(d):return json.dumps(d,sort_keys=True,separators=(',',':')).encode()
if '--remote' in sys.argv:
    d=exact_data(True)
    print(json.dumps({'host':socket.gethostname(),'python':platform.python_version(),
                      'independent_methods':'C4 completion via weighted matrix factorization; coarea layer heights recomputed from actual cell incidence.',
                      'exact_data_sha256':hashlib.sha256(canonical(d)).hexdigest()}));sys.exit(0)

from flint import arb,ctx

def main():
    data=exact_data();digest=hashlib.sha256(canonical(data)).hexdigest();interval=[]
    for row in data['coarea']:
        A=F(row['A_J1']);B=F(row['B_Jz']);gap=F(row['exact_layer_gap']);checks=[]
        for bits in (256,384):
            ctx.prec=bits;aa=arb(A.numerator)/A.denominator;bb=arb(B.numerator)/B.denominator;gg=arb(gap.numerator)/gap.denominator
            logarithmic=bb*(aa/bb).log() if B else arb(0);universal=aa/arb(1).exp()
            if B and B<A:assert gg<logarithmic and logarithmic<universal
            elif not B:assert gap==0
            elif B==A:assert gap==0
            checks.append((logarithmic,universal))
        assert all(x.overlaps(y) for x,y in zip(checks[0],checks[1]))
        interval.append({'name':row['name'],'Jz_log_A_over_Jz':checks[1][0].str(40),
                         'A_over_e':checks[1][1].str(40),'gap_over_A_approx':float(gap/A),'precisions':[256,384]})
    cmd=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=5','macbook-math','/Users/zhengzhihao/.venv/bin/python -B - --remote']
    try:
        run=subprocess.run(cmd,input=Path(__file__).read_text(),text=True,capture_output=True,timeout=45)
        remote={'command':cmd,'exit_code':run.returncode,'stderr':run.stderr}
        if run.returncode==0:
            remote['result']=json.loads(run.stdout);assert remote['result']['exact_data_sha256']==digest;remote['all_exact_data_match']=True
    except subprocess.TimeoutExpired:remote={'command':cmd,'timeout_seconds':45}
    result={'host':socket.gethostname(),'python':sys.executable,'python_version':platform.python_version(),
            'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'exact_data_digest':digest,
            **data,'coarea_arb_checks':interval,'remote':remote,
            'definitions':['R_ab=sum_{a_prime,b_prime}theta_a_prime theta_b_prime B_a,b_prime B_a_prime,b_prime B_a_prime,b.',
                           'Bad root edges use the inclusive testR_ab<=tau, andd_bad=sum theta_a theta_b B_ab 1_bad. Inclusive pruning also covers the strict test.',
                           'The finite graph checks recordd_bad^4<=C4(B_bad)<=sum_root theta_a theta_b B_bad R_original<=tau d_bad, and testd_bad^3<=tau exactly.',
                           'For positive-volume rectangle cells,J(z)=max_cell sum_i theta_i z_i1_Ai. A=J(1),B=J(z),layer integral=sum over exact rational threshold intervals ofJ(1_{z>s}) times intervalwidth.'],
            'scope':['Subprobability vertex weights andB in[0,1] are verified for every positive graph case. GeometricB values are actual intersection volumes of side1 cubes. Repeated equal cubes are permitted labels and give sharp constant-B examples.',
                     'All geometry and layer integrals are exact rational finite calculations. The coarea logarithms andA/e are checked with local Arb256/384. The rectangles are positive physical cells; no zero-volume boundary is used to achieve a supremum.',
                     'Prefix-free capacities use one shared Bernoullip per entire path, then integrate its arcsine prior. Per-step independent optimization is explicitly a different operation and gives the exponential negative control.',
                     'These bounded numerical certificates do not claim to prove the general pruning or coarea theorem, nor to construct a chronological greedy history. No Git, remote files, GPU use or remaining background jobs. Onlycycles.py/json are written.']}
    (BASE/'cycles.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'remote_exit':remote.get('exit_code'),'exact_match':remote.get('all_exact_data_match'),
                      'graph_cases':len(data['graphs']['cases']),'graph_threshold_tests':sum(len(r['tests']) for r in data['graphs']['cases']),
                      'coarea_cases':len(data['coarea']),'coarea_gap_over_A':[r['gap_over_A_approx'] for r in interval]},indent=2))
if __name__=='__main__':main()
