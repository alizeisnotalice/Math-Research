#!/usr/bin/env python3
"""Round 40: exact finite identities and explicitly scoped numerical guards.
Standard library only.  No sampled result is a continuous spectral theorem.
Run this file to regenerate its sibling results.json.
"""
from fractions import Fraction as F
from decimal import Decimal as D, localcontext
from itertools import product
from pathlib import Path
import json
from random import Random


def fs(x):
    return str(x.numerator) if x.denominator == 1 else f'{x.numerator}/{x.denominator}'


def dec(x):
    return D(x.numerator) / D(x.denominator) if isinstance(x, F) else D(x)


def ds(x):
    return '0' if x == 0 else format(x, '.24E')


def fixture(kind, n, count):
    points, weights = [], []
    rng = Random(20261010 + 1009*n + 9176*count)
    radius = 0
    while (2*radius+1)**n < count:
        radius += 1
    lattice = list(product(range(-radius, radius+1), repeat=n))[:count]
    for i in range(count):
        r = F(2 * i - count + 1, max(count, 3))
        if kind == 'unequal_weights':
            p = tuple(r if j == 0 else F((i + 2*j) % 5 - 2, 5) for j in range(n))
            w = F((i + 1)**2, i + 2)
        elif kind == 'anisotropic_line':
            p = tuple(r / (j + 1) for j in range(n))
            w = F(i + 2, 2*i + 3)
        elif kind == 'correlated':
            p = tuple(((-1)**j) * r + F(i % 2, 7) for j in range(n))
            w = F(2*i + 3, i + 3)
        elif kind == 'two_peaks':
            p = tuple((F(-1 if i % 2 == 0 else 1) + r/5) if j == 0
                      else F((i + j) % 3 - 1, 6) for j in range(n))
            w = F(i + 1, i + 2)
        elif kind == 'integer_lattice':
            p = tuple(F(2*i-count+1, 2) for j in range(n))
            w = F(i+2, i+3)
        elif kind == 'tensor_lattice':
            p = tuple(F(q) for q in lattice[i])
            w = F(2*i+3, i+2)
        elif kind == 'seeded_positive':
            p = tuple(F(rng.randrange(-12, 13), 8) for j in range(n))
            while p in points:
                p = tuple(F(rng.randrange(-12, 13), 8) for j in range(n))
            w = F(rng.randrange(1, 17), rng.randrange(2, 13))
        else:
            raise ValueError(kind)
        points.append(p)
        weights.append(w)
    return points, weights


def gram_from_cells(cells, weights):
    """Each cell is (dx, cube volume, enclosed mass, captured index tuple)."""
    count = len(weights)
    assert all(w > 0 for w in weights)
    H = [[F(0) for _ in weights] for _ in weights]
    norm_sq = F(0)
    for dx, volume, mass, captured in cells:
        assert dx > 0 and volume > 0 and mass > 0
        norm_sq += dx * mass / volume
        coefficient = dx / (volume * mass)
        for i in captured:
            for j in captured:
                H[i][j] += coefficient
    pairing = sum(weights[i]*weights[j]*H[i][j]
                  for i in range(count) for j in range(count))
    assert pairing == norm_sq
    assert all(H[i][j] == H[j][i] for i in range(count) for j in range(count))
    rows = [sum(weights[j]*H[i][j] for j in range(count)) for i in range(count)]
    assert all(x >= 0 for x in rows)
    # Exact factorization, including signed test vectors, checks L2(mu) weights.
    quadratic_values, rayleigh_values = [], []
    for k in range(5):
        z = [F((i+1)*(k+2) % 7 - 3, k+1) for i in range(count)]
        lhs = sum(weights[i]*weights[j]*z[i]*z[j]*H[i][j]
                  for i in range(count) for j in range(count))
        rhs = sum(dx/(volume*mass) * sum(weights[i]*z[i] for i in captured)**2
                  for dx, volume, mass, captured in cells)
        assert lhs == rhs and lhs >= 0
        quadratic_values.append(fs(lhs))
        denominator = sum(weights[i]*z[i]**2 for i in range(count))
        assert denominator > 0
        rayleigh_values.append(lhs/denominator)
    W = sum(weights)
    trace = sum(weights[i]*H[i][i] for i in range(count))
    lower, upper = norm_sq/W, max(rows, default=F(0))
    best_lower = max([lower]+rayleigh_values)
    assert best_lower <= upper and best_lower <= trace
    return H, norm_sq, rows, {
        'constant_vector_rayleigh_lower': fs(lower),
        'best_of_six_test_vector_rayleigh_lower': fs(best_lower),
        'five_signed_test_vector_rayleigh_quotients': list(map(fs, rayleigh_values)),
        'positive_kernel_schur_upper': fs(upper),
        'trace_upper': fs(trace),
        'five_signed_quadratic_factorizations': quadratic_values,
        'scope': 'Exact bounds only for the operator represented by these cells.'}


def fixed_scale_case(n, count):
    points, weights = fixture('correlated', n, count)
    L = F(count + n + 1, count + 1)
    edges = [sorted({p[j] - L/2 for p in points} | {p[j] + L/2 for p in points})
             for j in range(n)]
    intervals = [list(zip(e[:-1], e[1:])) for e in edges]
    cells = []
    for box in product(*intervals):
        x = tuple((lo+hi)/2 for lo, hi in box)
        captured = tuple(i for i, p in enumerate(points)
                         if all(abs(x[j]-p[j]) <= L/2 for j in range(n)))
        if not captured:
            continue
        dx = F(1)
        for lo, hi in box:
            dx *= hi-lo
        mass = sum(weights[i] for i in captured)
        cells.append((dx, L**n, mass, captured))
    H, norm_sq, rows, spectral = gram_from_cells(cells, weights)
    W = sum(weights)
    assert rows == [F(1)] * count
    assert norm_sq == W
    assert spectral['constant_vector_rayleigh_lower'] == '1'
    assert spectral['positive_kernel_schur_upper'] == '1'
    return {'dimension': n, 'atom_count': count, 'scale': fs(L),
            'points': [[fs(q) for q in p] for p in points],
            'weights': list(map(fs, weights)), 'mass': fs(W),
            'nonzero_rectangles': len(cells),
            'source_gram_H': [[fs(q) for q in row] for row in H],
            'mu_weighted_row_sums': list(map(fs, rows)),
            'B1_squared_norm_and_source_pairing': fs(norm_sq),
            'spectral_bounds': spectral, 'status': 'PASS'}


def direct_winner(x, points, weights, a, b):
    entries = [2*max(abs(x[j]-p[j]) for j in range(len(x))) for p in points]
    candidates = sorted({a} | {r for r in entries if a < r <= b})
    best = None
    for L in candidates:
        captured = tuple(i for i, r in enumerate(entries) if r <= L)
        mass = sum(weights[i] for i in captured)
        A = mass/L**len(x)
        if best is None or A > best[0]:
            best = (A, L, mass, captured)
    return best, entries, len(candidates)


def grouped_winner(entries, weights, n, a, b):
    groups = {}
    for i, r in enumerate(entries):
        if r <= b:
            groups.setdefault(max(a, r), []).append(i)
    groups.setdefault(a, [])
    captured, mass, best = [], F(0), None
    for L in sorted(groups):
        captured.extend(groups[L])
        mass += sum(weights[i] for i in groups[L])
        A = mass/L**n
        result = (A, L, mass, tuple(sorted(captured)))
        if best is None or A > best[0]:
            best = result
    return best, sum(len(group) > 1 for group in groups.values())


def sampled_case(kind, varied_factor, n, count, density):
    points, weights = fixture(kind, n, count)
    a, b, threshold = F(1), F(3), F(1, 2)
    lo, hi = F(-3), F(3)
    step = (hi-lo)/density
    axis = [lo+(F(k)+F(1, 2))*step for k in range(density)]
    cells, winners, tie_groups, candidate_total = [], [], 0, 0
    band_cells = []
    all_receivers = density**n
    for x in product(axis, repeat=n):
        direct, entries, candidates = direct_winner(x, points, weights, a, b)
        grouped, ties = grouped_winner(entries, weights, n, a, b)
        assert direct == grouped
        tie_groups += ties
        candidate_total += candidates
        A, L, mass, captured = direct
        if A > threshold:
            cells.append((step**n, L**n, mass, captured))
            winners.append((A, L))
            if A <= 2*threshold:
                band_cells.append((step**n, L**n, mass, captured))
    H, norm_sq, rows, spectral = gram_from_cells(cells, weights)
    _, band_norm, band_rows, band_spectral = gram_from_cells(band_cells, weights)
    return {'fixture': kind, 'varied_factor': varied_factor, 'dimension': n,
            'atom_count': count, 'grid_density_per_coordinate': density,
            'receiver_count': all_receivers, 'retained_receiver_count': len(cells),
            'true_band_receiver_count': len(band_cells),
            'true_band_B1_squared_norm_and_source_pairing': fs(band_norm),
            'true_band_spectral_bounds': band_spectral,
            'threshold_sets': 'full level M>lambda; true band lambda<M<=2lambda',
            'random_seed': 20261010+1009*n+9176*count if kind == 'seeded_positive' else None,
            'window': [fs(a), fs(b)], 'common_threshold': fs(threshold),
            'grid_box': [fs(lo), fs(hi)], 'cell_volume': fs(step**n),
            'points': [[fs(q) for q in p] for p in points],
            'weights': list(map(fs, weights)),
            'direct_candidates_checked': candidate_total,
            'equal_entry_groups_checked': tie_groups,
            'winner_scale_range': [fs(min(L for A,L in winners)), fs(max(L for A,L in winners))] if winners else None,
            'winner_average_range': [fs(min(A for A,L in winners)), fs(max(A for A,L in winners))] if winners else None,
            'B1_squared_norm_and_source_pairing': fs(norm_sq),
            'mu_weighted_row_sum_range': [fs(min(rows)), fs(max(rows))],
            'spectral_bounds': spectral,
            'scope': 'Rational midpoint quadrature only. Exact continuous window winner at each sampled point; no assertion about continuous integration or continuous spectrum.',
            'status': 'PASS'}


def mixed_mass_at_precision(n, precision):
    with localcontext() as ctx:
        ctx.prec = precision
        h = D(2).ln()
        T = D(n)*h
        m = int(T.sqrt())
        if D(m)**2 < T:
            m += 1
        d = T/D(m)
        k = (n*(m-1))//(2*m)
        N = 1 << k
        ws = D(2)
        log_wb = ws.ln()+T-d-3*h
        wb = log_wb.exp()
        W = wb+ws*D(N)
        ratio = (ws.ln()+D(N).ln()-log_wb).exp()
        # Each shell: H_ii=h/wi, so sqrt(wi) H_ii sqrt(wi)=h.
        small_eigenvalue = ws*(h/ws)
        large_eigenvalue = wb*(h/wb)
        assert abs(small_eigenvalue/h-1) < D('1e-55')
        assert abs(large_eigenvalue/h-1) < D('1e-55')
        assert 3*h < 2*d and ratio <= 1
        assert 0 < T-d-3*h < T-d-2*h < T-h
        assert W <= 2*wb
        initial_volume = D(1)
        initial_small_H = initial_volume/(initial_volume*ws)
        assert ws*initial_small_H == 1 and ws/initial_volume == 2
        assert wb/initial_volume > 2
        assert abs((ws*(initial_small_H+h/ws))/(1+h)-1) < D('1e-55')
        return {'dimension': n, 'm': m, 'small_atom_count_power_of_two': k,
                'small_atom_count_exact': str(N), 'h_log2': ds(h), 'T': ds(T), 'd': ds(d),
                'small_mass': ds(ws), 'big_mass': ds(wb), 'total_mass': ds(W),
                'small_total_to_big_mass': ds(ratio),
                'small_entry_time_interval': [ds(D(0)), ds(h)],
                'big_entry_time_interval': [ds(T-d-3*h), ds(T-d-2*h)],
                'occupation_upper_3h': ds(3*h), 'short_cutoff_2d': ds(2*d),
                'small_weighted_diagonal': ds(small_eigenvalue),
                'big_weighted_diagonal': ds(large_eigenvalue),
                'normalized_gram_operator_norm': ds(h),
                'ring_restriction': 'Ei: wi/(2lambda)<v<wi/lambda; excludes the initial cube',
                'full_window_true_band_small_weighted_diagonal': ds(D(1)+h),
                'full_window_true_band_big_weighted_diagonal': ds(h),
                'full_window_true_band_gram_norm': ds(D(1)+h),
                'full_window_true_band_B1_squared_norm_divided_by_W': ds(h+ratio/(1+ratio)),
                'full_window_true_band_level_fee': ds((1+ratio/(1+ratio))/2),
                'initial_cube_explanation': 'Small mass ws=2lambda a^n has M=2lambda on Q(a), included in the true band, and adds exactly 1 to its weighted diagonal. Big initial cube has M>2lambda and is excluded.',
                'B1_squared_norm_and_source_pairing_divided_by_W': ds(h),
                'true_shell_level_fee': '1/2', 'specified_window_level_fee': '1',
                'parameters': 'a=lambda=1, b=2; centers spaced by 3b; N=2^floor(n(m-1)/(2m)).',
                'exact_formulas': {'shell_volume': 'wi/(2lambda)<v<wi/lambda',
                                   'H_ii': 'log(2)/wi', 'H_ij_i_ne_j': '0',
                                   'L2_mu_weighted_gram': 'log(2) times identity',
                                   'B1_norm_squared': 'W log(2)'},
                'scope': 'Norm log(2) is restricted to the noninitial open rings Ei, not the entire finite-window true band. No enormous atom enumeration; level fee is for the specified window and lambda only.',
                'status': 'PASS'}


def mixed_mass_case(n):
    first, second = mixed_mass_at_precision(n, 80), mixed_mass_at_precision(n, 120)
    stable_fields = ['h_log2', 'T', 'd', 'big_mass', 'total_mass', 'small_total_to_big_mass',
                     'occupation_upper_3h', 'short_cutoff_2d', 'normalized_gram_operator_norm']
    worst = D(0)
    with localcontext() as ctx:
        ctx.prec = 80
        for field in stable_fields:
            x, y = D(first[field]), D(second[field])
            relative = abs(x-y)/abs(y)
            worst = max(worst, relative)
            assert relative <= D('1e-23')
    second['decimal_precisions_compared'] = [80, 120]
    second['max_relative_difference_of_reported_values'] = ds(worst)
    return second


def box_case(n, radius_factor):
    a, b = F(1), F(2)
    # R/b=n*factor; core side 2R-b.  Arbitrary positive density cancels.
    R = b*n*radius_factor
    rho = F(3, 2)
    core_ratio = (1-b/(2*R))**n
    decay = F(1, 2)**(n//2)
    W = rho*(2*R)**n
    core_mass = rho*(2*R-b)**n
    assert core_mass/W == core_ratio and core_ratio > decay
    with localcontext() as ctx:
        ctx.prec = 80
        gap = D(n)*D(2).ln()
        decay_decimal = (-gap/2).exp()
        assert abs(decay_decimal/dec(decay)-1) < D('1e-70')
        return {'dimension': n, 'radius_over_b': fs(R/b), 'radius_factor': radius_factor,
                'source_density': fs(rho), 'a': fs(a), 'b': fs(b),
                'source_mass': fs(W), 'core_mass': fs(core_mass),
                'cross_pairing_divided_by_W_lower_exact': fs(core_ratio),
                'cross_pairing_divided_by_W_lower_decimal': ds(dec(core_ratio)),
                'proposed_scale_only_decay_exact': fs(decay),
                'proposed_scale_only_decay_decimal': ds(decay_decimal),
                'logvolume_time_gap': ds(gap),
                'formulas': {'core': '[-R+b/2,R-b/2]^n',
                             'on_core_Bs1_Bt1': 'rho',
                             'lower_ratio': '(1-b/(2R))^n',
                             'decay': '(a/b)^(n/2)'},
                'scope': 'Actual finite uniform source box and fixed-scale normalized kernels, E={muQ>0}. Core lower bound only; this is not a winner-selector example.',
                'status': 'PASS'}



def coarse_case(n, k):
    points, weights = fixture('correlated', n, 4)
    g = [F(2*i-3, i+2) for i in range(4)]
    shifts = [tuple(F(j)-F(k-1, 2) for j in index)
              for index in product(range(k), repeat=n)]
    density_checks = numerator_checks = posterior_checks = 0
    for r in range(1, 14):
        x = tuple(F((r+3*j) % 13 + 1, 13) for j in range(n))
        coarse_values, fine_values = [], []
        fine_densities, fine_numerators = [], []
        for shift in shifts:
            indicators = [all(abs(x[j]-points[i][j]-shift[j]) < F(1, 2)
                              for j in range(n)) for i in range(4)]
            # These points avoid all coarse and fine cube boundaries.
            assert all(abs(x[j]-points[i][j]-shift[j]) != F(1, 2)
                       for j in range(n) for i in range(4))
            fine_densities.append(sum(weights[i] for i in range(4) if indicators[i]))
            fine_numerators.append(sum(weights[i]*g[i] for i in range(4) if indicators[i]))
            fine_values.append(indicators)
        for i in range(4):
            assert all(abs(x[j]-points[i][j]) != F(k, 2) for j in range(n))
            coarse = F(int(all(abs(x[j]-points[i][j]) < F(k, 2) for j in range(n))), k**n)
            fine = F(sum(row[i] for row in fine_values), k**n)
            assert coarse == fine
            coarse_values.append(coarse)
            density_checks += 1
        coarse_density = sum(weights[i]*coarse_values[i] for i in range(4))
        coarse_numerator = sum(weights[i]*g[i]*coarse_values[i] for i in range(4))
        assert coarse_density == sum(fine_densities)/k**n
        assert coarse_numerator == sum(fine_numerators)/k**n
        numerator_checks += 1
        if coarse_density:
            posterior = coarse_numerator/coarse_density
            # Zero fine densities have zero numerators and receive zero posterior weight.
            fine_posterior = sum(fd/coarse_density/k**n * fn/fd
                                 for fd,fn in zip(fine_densities,fine_numerators) if fd)
            assert posterior == fine_posterior
            posterior_checks += 1
    return {'dimension': n, 'integer_scale_ratio': k, 'fine_scale': '1',
            'atom_count': 4, 'test_receivers': 13, 'atom_kernel_identities': density_checks,
            'weighted_numerator_and_density_identities': numerator_checks,
            'nonzero_density_posterior_identities': posterior_checks,
            'g_values': list(map(fs, g)), 'weights': list(map(fs, weights)),
            'formula': 'h_b(x-y)=k^(-n) sum_j h_a(x-y-a(j-(k-1)/2)); a=1, b=k.',
            'scope': 'Exact rational tests of integer-ratio finite translation coarse graining; signed g is a test vector, all source weights remain positive.',
            'status': 'PASS'}


def deep_entry_case(n, depth):
    points, weights = [], []
    for level in range(1, depth+1):
        radius = F(1, 2**level)
        for sign in (-1, 1):
            points.append(tuple(sign*radius*(-1)**j for j in range(n)))
            weights.append(radius**n*F(level+2+(sign==1), level+3))
    x = tuple(F(0) for _ in range(n))
    a, b = F(1, 2**(depth+2)), F(3)
    direct, entries, candidates = direct_winner(x, points, weights, a, b)
    grouped, ties = grouped_winner(entries, weights, n, a, b)
    assert direct == grouped and ties == depth and candidates == depth+1
    A, L, mass, captured = direct
    _, value, rows, spectral = gram_from_cells([(F(1), L**n, mass, captured)], weights)
    assert value == A
    return {'dimension': n, 'depth': depth, 'atom_count': 2*depth,
            'window': [fs(a), fs(b)], 'equal_entry_groups': ties,
            'candidate_count': candidates, 'winner_scale': fs(L),
            'winner_average': fs(A), 'captured_atom_count': len(captured),
            'spectral_bounds': spectral,
            'definition': 'At each level i=1..depth, two points sign*2^(-i)*((-1)^j)_j; weights 2^(-i*n)*(i+2+indicator(sign=1))/(i+3).',
            'scope': 'One exact receiver at the origin with unit discrete mass; nested entry/tie implementation guard only, not a Lebesgue volume or continuous spectrum.',
            'status': 'PASS'}


def main():
    deep = [deep_entry_case(n,d) for n in (1,4,16) for d in (8,16,32)]
    fixed = [fixed_scale_case(n, count) for n in (1, 2, 3) for count in (3, 4, 5)]
    sampled = []
    kinds = ('unequal_weights', 'anisotropic_line', 'correlated', 'two_peaks',
             'integer_lattice', 'tensor_lattice', 'seeded_positive')
    settings = [('dimension', n, 5, 5) for n in (1, 2, 3)]
    settings += [('atom_count', 2, count, 5) for count in (3, 5, 7)]
    settings += [('grid_density', 2, 5, density) for density in (3, 5, 7)]
    for kind in kinds:
        for varied, n, count, density in settings:
            sampled.append(sampled_case(kind, varied, n, count, density))
    for n in (1, 2, 3):
        for density in (3, 5):
            sampled.append(sampled_case('tensor_lattice', 'full_tensor_lattice', n, 3**n, density))
    mixed = [mixed_mass_case(n) for n in (512, 2048, 8192)]
    coarse = [coarse_case(n,k) for n in (1,2,3) for k in (2,3,5)]
    boxes = [box_case(n, factor) for n in (8, 32, 128) for factor in (1, 16, 256)]
    band_lowers = [F(row['true_band_spectral_bounds']['constant_vector_rayleigh_lower']) for row in sampled]
    band_uppers = [F(row['true_band_spectral_bounds']['positive_kernel_schur_upper']) for row in sampled]
    best_band_lowers = [F(row['true_band_spectral_bounds']['best_of_six_test_vector_rayleigh_lower']) for row in sampled]
    best_sample_lowers = [F(row['spectral_bounds']['best_of_six_test_vector_rayleigh_lower']) for row in sampled]
    sample_lowers = [F(row['spectral_bounds']['constant_vector_rayleigh_lower']) for row in sampled]
    sample_uppers = [F(row['spectral_bounds']['positive_kernel_schur_upper']) for row in sampled]
    with localcontext() as ctx:
        ctx.prec = 80
        summary = {'status': 'PASS', 'test_case_count': len(fixed)+len(sampled)+len(mixed)+len(boxes)+len(coarse)+len(deep),
                   'deep_entry_tie_cases': len(deep), 'fixed_scale_exact_cases': len(fixed), 'winner_quadrature_cases': len(sampled),
                   'isolated_shell_cases': len(mixed), 'uniform_box_cases': len(boxes), 'integer_coarse_graining_cases': len(coarse),
                   'coarse_atom_kernel_identities': sum(row['atom_kernel_identities'] for row in coarse),
                   'coarse_numerator_and_density_identities': sum(row['weighted_numerator_and_density_identities'] for row in coarse),
                   'coarse_nonzero_posterior_identities': sum(row['nonzero_density_posterior_identities'] for row in coarse),
                   'fixed_scale_nonzero_rectangles': sum(row['nonzero_rectangles'] for row in fixed),
                   'sampled_receiver_count': sum(row['receiver_count'] for row in sampled),
                   'true_band_sampled_receiver_count': sum(row['true_band_receiver_count'] for row in sampled),
                   'retained_sampled_receiver_count': sum(row['retained_receiver_count'] for row in sampled),
                   'winner_candidates_crosschecked': sum(row['direct_candidates_checked'] for row in sampled),
                   'equal_entry_groups_checked': sum(row['equal_entry_groups_checked'] for row in sampled),
                   'signed_quadratic_factorization_checks': 5*(len(fixed)+2*len(sampled)+len(deep)),
                   'quadrature_rayleigh_lower_range_decimal': [ds(dec(min(sample_lowers))), ds(dec(max(sample_lowers)))],
                   'quadrature_schur_upper_range_decimal': [ds(dec(min(sample_uppers))), ds(dec(max(sample_uppers)))],
                   'true_band_quadrature_rayleigh_lower_range_decimal': [ds(dec(min(band_lowers))), ds(dec(max(band_lowers)))],
                   'best_of_six_quadrature_rayleigh_lower_range_decimal': [ds(dec(min(best_sample_lowers))), ds(dec(max(best_sample_lowers)))],
                   'best_of_six_true_band_quadrature_rayleigh_lower_range_decimal': [ds(dec(min(best_band_lowers))), ds(dec(max(best_band_lowers)))],
                   'true_band_quadrature_schur_upper_range_decimal': [ds(dec(min(band_uppers))), ds(dec(max(band_uppers)))],
                   'uniform_box_core_ratio_range_decimal': [ds(min(D(row['cross_pairing_divided_by_W_lower_decimal']) for row in boxes)), ds(max(D(row['cross_pairing_divided_by_W_lower_decimal']) for row in boxes))],
                   'scope': 'Finite cases and exact identities do not establish a continuous winner-selector spectral bound, a dimension asymptotic, or a root-n maximal bound.'}
    result = {'definition': 'B(x,y)=1_E(x)1_Q(x)(y)/sqrt(v(x) mu(Q(x))); source space is L2(mu).',
              'source_gram': 'H_ij=integral_E 1_Q(yi)1_Q(yj)/(v mu(Q)) dx; weighted matrix is sqrt(wi) H_ij sqrt(wj).',
              'summary': summary, 'deep_entry_tie_guards': deep, 'fixed_scale_exact': fixed, 'winner_quadrature': sampled,
              'mixed_mass_true_shells': mixed, 'uniform_box_no_cross_scale_decay': boxes, 'integer_coarse_graining': coarse}
    target = Path(__file__).with_name('results.json')
    target.write_text(json.dumps(result, indent=2, ensure_ascii=False)+'\n', encoding='utf-8')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
