#!/usr/bin/env python3
"""Exact finite periodic short-window three-stage coverage diagnostics."""
from fractions import Fraction as Q
from itertools import product
from math import lcm
from collections import Counter
from hashlib import sha256
from pathlib import Path
import json, sys

def weight(a):
 return 1+(3*a[0]+5*a[1]+7*a[0]*a[1]+sum((i+3)*v for i,v in enumerate(a[2:]))+sum(a[i]*a[i+1] for i in range(1,len(a)-1)))%13

def fixture(n,m):
 # Distinct shifts, alternating low and high on successive coarse labels.
 ranks=[]
 for a in range(m): ranks.append(a//2 if a%2==0 else m-1-a//2)
 shifts=[Q(9*r,20*(m-1)) for r in ranks]
 assert len(set(shifts))==m and min(shifts)==0 and max(shifts)==Q(9,20)
 L=lcm(40*(m-1),8,20); B=m*L; s=[int(v*L) for v in shifts]; assert all(Q(x,L)==v for x,v in zip(s,shifts))
 words=list(product(range(m), repeat=n)); coords={a:tuple(a[i]*L+s[a[0]] for i in range(n)) for a in words}; weights={a:weight(a) for a in words}
 offsets=[tuple(0 for _ in range(n)),tuple((1 if i%2==0 else -1)*L//4 for i in range(n)), tuple((-1 if i%2==0 else 1)*L//4 for i in range(n)),tuple((1 if i%2==0 else -1)*9*L//20 for i in range(n)),tuple((-1 if i%2==0 else 1)*9*L//20 for i in range(n))]
 widths=[L//4,L//2,3*L//4,L]; thresholds=[Q(1,2),Q(1),Q(2),Q(4)]
 # Stage 1: full words; stage 2: all three absolute-coarse candidates per axis;
 # stage 3: construct the receiver-local fine alphabet and filter exact centres.
 evals=0; count_hist=Counter(); dictionary_hist=Counter(); tight_dictionary_hist=Counter(); checksum=0; threshold_hits=Counter(); overlap_witness=None
 for k in words:
  neighborhood=[[(v-1)%m,v,(v+1)%m] for v in k]
  candidate=set(product(*neighborhood)); local_dict={s[i] for i in neighborhood[0]}
  tight_neighborhood=[[(v-1)%m,v] for v in k]; tight_candidate=set(product(*tight_neighborhood)); tight_dict={s[i] for i in tight_neighborhood[0]}
  assert len(tight_dict)<=2; tight_dictionary_hist[len(tight_dict)]+=1
  assert len(local_dict)<=3
  dictionary_hist[len(local_dict)]+=1
  for off,t in product(offsets,widths):
   x=tuple((k[i]*L+off[i])%B for i in range(n)); left=tuple((v-t//2)%B for v in x)
   # Integer comparisons: sources are all fully enumerated; periodic half-open window.
   full={a for a in words if all((coords[a][i]-left[i])%B<t for i in range(n))}
   rough={a for a in candidate if all((coords[a][i]-left[i])%B<t for i in range(n))}
   local={a for a in candidate if s[a[0]] in local_dict and all((coords[a][i]-left[i])%B<t for i in range(n))}
   tight={a for a in tight_candidate if s[a[0]] in tight_dict and all((coords[a][i]-left[i])%B<t for i in range(n))}
   assert full==rough==local==tight
   total=sum(weights[a] for a in full); assert total==sum(weights[a] for a in rough)==sum(weights[a] for a in local)
   # compare same window/threshold with unscaled atomic average mass / t^n
   for threshold in thresholds:
    hit=Q(total)*L**n>threshold*t**n
    assert hit==(Q(sum(weights[a] for a in local))*L**n>threshold*t**n)
    threshold_hits[str(threshold)]+=hit
   count_hist[len(full)]+=1;checksum=(checksum+total*(evals+1))%1000000007; evals+=1
 # Explicit genuinely overlapping neighbor sources and actual reception strip.
 for a in words:
  b=((a[0]+1)%m,*a[1:]); d=(coords[b][0]-coords[a][0])%B
  if not 0<d<L: continue
  # Construct midpoint on periodic torus, denominator 2L.
  X=[2*coords[a][0]+d]
  for i in range(1,n):
   diff=(coords[b][i]-coords[a][i])%B
   if diff>B//2: diff-=B
   X.append(2*coords[a][i]+diff)
  BB=2*B; LL=2*L; left=[(v-L)%BB for v in X]
  if all((2*coords[z][i]-left[i])%BB<2*L for z in (a,b) for i in range(n)):
   k=[((v+L)//(2*L))%m for v in X]
   assert all(z[i] in {(k[i]-1)%m,k[i],(k[i]+1)%m} for z in (a,b) for i in range(n))
   overlap_witness={'sources':[a,b],'receiver_coarse':k,'point_in_units_1_over_2L':[v%BB for v in X], 'L':L,'width':'1','source_shift':[str(shifts[z[0]]) for z in (a,b)],'distance_first_axis':str(Q(d,L))};break
 assert overlap_witness is not None
 # Demonstrate genuinely nonproduct joint weights in the first two axes.
 w00=weights[(0,0)+tuple(0 for _ in range(n-2))]; w10=weights[(1,0)+tuple(0 for _ in range(n-2))];w01=weights[(0,1)+tuple(0 for _ in range(n-2))];w11=weights[(1,1)+tuple(0 for _ in range(n-2))]
 assert w00*w11!=w10*w01
 # A fixed source lies in exactly three coarse reception strips per axis,
 # hence the tensor incidence bookkeeping is 3^n, not 3.
 one_axis_usage={a:sum(a in {(k-1)%m,k,(k+1)%m} for k in range(m)) for a in range(m)}
 assert all(v==3 for v in one_axis_usage.values())
 usage=Counter(sum(a in set(product(*[[(v-1)%m,v,(v+1)%m] for v in k])) for k in words) for a in words)
 assert dict(usage)=={3**n:m**n}
 tight_usage=Counter(sum(a in set(product(*[[((v-1)%m),v] for v in k])) for k in words) for a in words)
 assert dict(tight_usage)=={2**n:m**n}
 return {'n':n,'m':m,'global_fine_cardinality':m,'distinct_local_fine_counts':dict(sorted(dictionary_hist.items())), 'tight_local_fine_counts':dict(sorted(tight_dictionary_hist.items())), 'shifts':[str(v) for v in shifts], 'arbitrary_nonproduct_weight_rule':'1+(3a0+5a1+7a0a1+sum((i+1)ai for i>=2)+sum(ai a(i+1) for i>=1)) mod 13','nonproduct_minor':[w00,w10,w01,w11], 'test_grid':'all m^n receiving words; 5 listed offsets with alternating signs; side lengths 1/4,1/2,3/4,1; thresholds 1/2,1,2,4; periodic half-open windows','window_count':evals,'positive_source_counts':dict(sorted(count_hist.items())),'threshold_hits':dict(threshold_hits),'integer_weight_checksum_mod_1e9p7':checksum,'overlap':overlap_witness,'axis_source_usage':one_axis_usage,'tensor_source_usage_histogram':dict(usage),'tight_tensor_source_usage_histogram':dict(tight_usage)}

def run():
 cases=[]
 for n in (2,3):
  for m in (3,4,5,6,7,8):
   x=fixture(n,m);cases.append(x);print(n,m,'tested',x['window_count'],'local',x['distinct_local_fine_counts'],'overlap',x['overlap']['sources'],flush=True)
 family={'m':'even integer >= 4','n':'integer >= 2','shifts':'s_(2r)=r/(16m), s_(2r+1)=1/4+r/(16m), 0<=r<m/2','bounds':'0<=s<9/20; all m shifts distinct','neighbor':'alpha_1=2r+1, beta=alpha+e_1, r<m/2-1','delta':'1/4-1/(16m) in (0,1)','coordinate_differences':'(1-delta, -delta, ..., -delta)','width':'1; midpoint contains both sources strictly','receiver':'k=alpha+e_1 in first coordinate and k_i=alpha_i otherwise','local_dictionary_size':'<=2 per axis in this one-sided-offset model; the original three-neighbor relaxation gives <=3','source_usage':'candidate accounting gives exactly 2 receiving strips per coarse coordinate (3 for the broader relaxation), and 2^n tensor strip products (3^n for the broader relaxation)','restriction':'This is a coverage/incidence identity, not a weak-type bound; m may grow, and R120 common-dictionary variation/payment does not automatically localize.'}
 return {'title':'R815 exact finite short-window tests', 'periodic_domain':'(R/mZ)^n with one positive atom at alpha_i+s_alpha0 per coarse word alpha; nonnegative correlated weights', 'scales':'0<t<=1; tested four rational scales', 'scope':'All source words are exhausted for every selected test window; not every real receiving point or scale is enumerated. Universal coverage follows from the elementary coordinate inequality.', 'universal_strip_proof':'If x in [k-1/2,k+1/2), 0<=s<=9/20 and |x-(alpha+s)|<=t/2<=1/2, then alpha in {k-1,k}: the upper endpoint is <k+1 and alpha<=k-2 gives alpha+s<k-1. Interpret periodic labels using lifted integer copies.', 'symbolic_family':family,'cases':cases}
if __name__=='__main__':
 path=Path(__file__).with_suffix('.json');out=run();data=json.dumps(out,indent=2,sort_keys=True)+'\n'
 if '--check' in sys.argv:
  assert path.read_text()==data;print('byte-identical exact replay')
 else:path.write_text(data)
