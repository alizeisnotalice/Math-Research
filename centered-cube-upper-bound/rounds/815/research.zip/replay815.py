"""Replay the four exact tests for the source-conditioned short-window bound."""
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys


def main():
    root = Path(__file__).resolve().parent
    manifest = json.loads((root / "MANIFEST.json").read_bytes())
    for path, expected in manifest["members"].items():
        actual = sha256((root / path).read_bytes()).hexdigest()
        if actual != expected:
            raise ValueError(f"SHA-256 mismatch for {path}")
    print(f"Validated {len(manifest['members'])} archive members.", flush=True)
    for program in manifest["checks"]:
        subprocess.run([sys.executable, "-B", str(root / program), "--check"], cwd=root, check=True)
    print("All four exact reports reproduced.")


if __name__ == "__main__":
    main()
