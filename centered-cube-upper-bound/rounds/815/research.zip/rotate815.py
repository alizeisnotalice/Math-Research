#!/usr/bin/env python3
"""Exact cyclic-XOR two-word, true receiver-box overlap checks."""
from fractions import Fraction as F
from itertools import product
from collections import Counter,deque
from pathlib import Path
import json,sys

def point(a,eps,M):
 n=len(a);return tuple(F(v)+F(v//2,64*M)+F(v%2,8)+F((a[(i+1)%n]%2)^eps,4) for i,v in enumerate(a))
def bitword(a,eps):return tuple((a[(i+1)%len(a)]%2)^eps for i in range(len(a)))
def vol(p,q):
 v=F(1)
 for a,b in zip(p,q):v*=max(F(0),1-abs(a-b))
 return v

def fixture(n,m):
 M=m//2; words=list(product(range(m),repeat=n)); sources=[(a,e) for a in words for e in (0,1)]; P={(a,e):point(a,e,M) for a,e in sources}
 assert len(P)==2*m**n and len(set(P.values()))==len(P)
 fine=[{P[a,e][i]-a[i] for a,e in sources} for i in range(n)]
 assert all(len(f)==4*M for f in fine)
 binary={bitword(a,e) for a,e in sources};assert len(binary)==2**n
 graph={s:set() for s in sources}; internal=ordinary=seam=0; seam_values=set(); descend_values=set(); ascend_values=set(); witness={}
 def edge(u,v,volume):
  assert volume>0;graph[u].add(v);graph[v].add(u)
 for a in words:
  u,v=(a,0),(a,1);volume=vol(P[u],P[v]);assert volume==F(3,4)**n;edge(u,v,volume);internal+=1
  for i in range(n):
   b=list(a);b[i]=(b[i]+1)%m;b=tuple(b);wrap=a[i]==m-1
   # The source bits in changed axis are high on the left and low on the right.
   eta=a[(i+1)%n]%2; u=(a,1^eta);v=(b,eta)
   left=P[u];right=list(P[v]);right[i]+=m if wrap else 0;right=tuple(right)
   overlap=vol(left,right);assert overlap>0;edge(u,v,overlap)
   if wrap:
    # A second valid pair with equal epsilon has exact wrap value.
    u0=(a,0);v0=(b,0);q=list(P[v0]);q[i]+=m;vwrap=vol(P[u0],q)
    expected=F(3,4)*(F(1,8)+F(M-1,64*M));assert vwrap==expected
    seam_values.add(vwrap);seam+=1
    witness.setdefault('seam',{'axis':i,'left':a,'right':b,'same_epsilon':0,'volume':str(vwrap),'positive_cross_bit_volume':str(overlap)})
   else:
    ordinary+=1
    if a[i]%2:
     for e in (0,1):
      same=vol(P[a,e],P[b,e]);expected=F(3,4)*(F(1,8)-F(1,64*M));assert same==expected
      descend_values.add(same)
     witness.setdefault('descending',{'axis':i,'left':a,'right':b,'same_epsilon':0,'volume':str(expected)})
    else:
     expected=F(1,8)*F(3,4)**(n-2);assert overlap==expected
     ascend_values.add(overlap)
     witness.setdefault('ascending',{'axis':i,'left':a,'right':b,'volume':str(overlap)})
 # These edges alone prove graph connectivity, independent of any omitted edges.
 seen={sources[0]};queue=deque([sources[0]])
 while queue:
  for z in graph[queue.popleft()]:
   if z not in seen:seen.add(z);queue.append(z)
 assert len(seen)==len(sources)
 return {'n':n,'m':m,'M':M,'true_sources':len(sources),'sources_per_cell':2,'fine_values_per_axis':[len(v) for v in fine],'binary_word_count':len(binary),'within_cell_pairs_checked':internal,'ordinary_directed_coarse_edges_checked':ordinary,'periodic_seam_edges_checked':seam,'graph_connected_using_verified_edges':True,'descending_same_epsilon_volumes':sorted(map(str,descend_values)),'ascending_cross_epsilon_volumes':sorted(map(str,ascend_values)),'seam_same_epsilon_volumes':sorted(map(str,seam_values)),'witnesses':witness}

def sampled(n,M):
 # Explicit edges in n dimensions, no full set of m^n cells is enumerated.
 m=2*M; selected=sorted({0,1,2,m//2,m-2,m-1});loc=[]
 for a in selected:
  for eps in (0,1):
   x=F(a)+F(a//2,64*M)+F(a%2,8)+F(eps,4)
   # One-dimensional candidate projection over nearby cells, with periodic lifts.
   values=set()
   for raw in range(a-2,a+3):
    k=raw%m;lift=raw-k
    for bit in (0,1):
     y=F(raw)+F(k//2,64*M)+F(k%2,8)+F(bit,4)
     if abs(y-x)<=1:values.add(y)
   assert len(values)<=6;loc.append(len(values))
 a=[0]*n;a[0]=1;b=a.copy();b[0]=2;a=tuple(a);b=tuple(b)
 common=vol(point(a,0,M),point(b,0,M));assert common==F(3,4)*(F(1,8)-F(1,64*M))
 x=[0]*n;x[0]=m-1;y=x.copy();y[0]=0;x=tuple(x);y=tuple(y);q=list(point(y,0,M));q[0]+=m
 wrap=vol(point(x,0,M),q);assert wrap==F(3,4)*(F(1,8)+F(M-1,64*M))
 return {'n':n,'M':M,'m':m,'scope':'only explicit 1D local phase probes and two n-dimensional edges; no full-space enumeration','one_dimensional_phase_probes':len(loc),'local_coordinate_cardinalities':dict(Counter(loc)),'ordinary_same_bit_volume':str(common),'seam_same_bit_volume':str(wrap)}

def main():
 cases=[]
 for n,m in [(2,4),(2,6),(3,4),(3,6),(4,4)]:
  v=fixture(n,m);cases.append(v);print(n,m,'sources',v['true_sources'],'words',v['binary_word_count'],'edges',v['ordinary_directed_coarse_edges_checked'],v['periodic_seam_edges_checked'],flush=True)
 probes=[sampled(n,M) for n,M in [(8,8),(16,64),(64,1000)]]
 return {'model':'m=2M; alpha in {0,...,m-1}^n, epsilon in {0,1}, eta_i=alpha_(i+1) mod 2 (cyclic), e_i=eta_i XOR epsilon; p_i=alpha_i+floor(alpha_i/2)/(64M)+(alpha_i mod 2)/8+e_i/4.', 'reception':'unit cubes centered at sources, with periodic lifts on the period-m torus; overlap means strictly positive n-dimensional volume.', 'scope':'Finite cases exhaust every coarse word, both source bits, each positive-coordinate adjacency (including seams), and every within-cell pair; a chosen positive source pair per adjacency suffices for connectivity. Large probes are explicitly sampled only.', 'formulas':'For ordinary odd-to-even edges, same epsilon volume is (3/4)(1/8-1/(64M)); the periodic seam is (3/4)(1/8+(M-1)/(64M)). Ordinary even-to-odd adjacency has a cross-epsilon overlap (1/8)(3/4)^(n-2).','cases':cases,'large_parameter_probes':probes}
if __name__=='__main__':
 path=Path(__file__).with_suffix('.json');encoded=json.dumps(main(),sort_keys=True,indent=2)+'\n'
 if '--check' in sys.argv:assert path.read_text()==encoded;print('byte-identical exact replay',flush=True)
 else:path.write_text(encoded)
