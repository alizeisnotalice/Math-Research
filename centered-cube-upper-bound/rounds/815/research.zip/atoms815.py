#!/usr/bin/env python3
"""Exact local-source-gap, Fisher and joint payment checks for R815."""
from fractions import Fraction as F
from itertools import product
from bisect import bisect_right
from collections import Counter,deque
from pathlib import Path
import json,sys

def source(n,m):
 M=m//2; out=[]
 for a in product(range(m),repeat=n):
  for bit in (0,1):
   p=tuple(F(v)+F(v//2,64*M)+F(v%2,8)+F(bit,4) for v in a)
   w=1+(3*a[0]+5*a[1]+7*a[0]*a[1]+sum((i+3)*v for i,v in enumerate(a[2:]))+11*bit+3*bit*a[0])%17
   out.append((a,bit,p,w))
 return out

def intervals(d,p,t):
 # Cover xi in [p-t,p], refining exactly where xi or xi+t crosses a D point.
 edges={p-t:{-1},p:{0}}
 for v in d:
  if p-t<v<p: edges.setdefault(v,set()).add(0)
  x=v-t
  if p-t<x<p:edges.setdefault(x,set()).add(-1)
 points=sorted(edges); ret={}
 for lo,hi in zip(points,points[1:]):
  mid=(lo+hi)/2; key=(bisect_right(d,mid),bisect_right(d,mid+t))
  slope=None if len(edges[lo])!=1 or len(edges[hi])!=1 else next(iter(edges[hi]))-next(iter(edges[lo]))
  assert key not in ret and hi>lo
  ret[key]=(hi-lo,slope,lo,hi)
 return ret

def run_case(n,m):
 src=source(n,m); P=len(src); full=(1<<P)-1; axes=[sorted(set(x[2][i] for x in src)) for i in range(n)]
 assert all(len(x)==2*m for x in axes) # finite samples have m physical coarse sites
 # True nonnegative, correlated law; common bit is shared by all axes.
 assert len({x[2] for x in src})==P
 wt={(a,b):w for a,b,p,w in src}; rest=(0,)*(n-2)
 minor=wt[((0,0)+rest,0)]*wt[((1,1)+rest,0)]-wt[((1,0)+rest,0)]*wt[((0,1)+rest,0)]
 assert minor!=0
 nn=[];ds=[];maxD=0;seen=Counter()
 for _,_,p,_ in src:
  ids=[j for j,(_,_,q,_) in enumerate(src) if all(abs(q[i]-p[i])<=1 for i in range(n))]
  local=[sorted({src[j][2][i] for j in ids}) for i in range(n)]
  assert all(p[i] in local[i] and len(local[i])<=6 for i in range(n))
  nn.append(ids); ds.append(local);maxD=max(maxD,max(map(len,local)))
  for d in local:seen[len(d)]+=1
 # Strict-overlap graph: connected physical reception boxes.
 seen_graph={0}; Q=deque([0]); edges=0
 while Q:
  j=Q.popleft();p=src[j][2]
  for k,(_,_,q,_) in enumerate(src):
   if k!=j and all(abs(q[i]-p[i])<1 for i in range(n)):
    edges+=1
    if k not in seen_graph:seen_graph.add(k);Q.append(k)
 assert len(seen_graph)==P
 reg=[F(1,3),F(2,3),F(7,10)]; collision=[F(1,8),F(1,4),F(3,8),F(7,8),F(1)];eps=F(1,2048*m)
 distributions=joint_cells=zero_states=full_checks=collision_checks=root_shares=0
 for ix,(_,_,p,wp) in enumerate(src):
  localmask=sum(1<<j for j in nn[ix])
  for t in reg:
   allints=[]
   for i,d in enumerate(ds[ix]):
    I=intervals(d,p[i],t); assert sum(v[0] for v in I.values())==t
    assert all(v[1] is not None for v in I.values())
    assert sum(v[1] for v in I.values())==1
    probs=[v[0]/t for v in I.values()];assert sum(probs)==1
    left=sum(((F(v[1])*t-v[0])/t**2)**2/(v[0]/t) for v in I.values())
    right=sum(F(v[1]**2,1)/v[0] for v in I.values())/t-F(1,t**2)
    assert left==right
    zero_states+=(len(d)+1)**2-len(I);distributions+=1
    axis=[]
    for key,(ell,slope,lo,hi) in I.items():
     # Actual global sources, exact membership at two interior points.
     masks=[]
     for u in ((3*lo+hi)/4,(lo+3*hi)/4):
      mask=sum(1<<j for j,(_,_,q,_) in enumerate(src) if u<=q[i]<u+t)
      masks.append(mask)
     assert (masks[0]&localmask)==(masks[1]&localmask)
     axis.append((ell,masks[0],masks[1]))
    allints.append(axis)
   for combo in product(*allints):
    ell=F(1);ma=full;mb=full
    for e,a,b in combo:ell*=e;ma&=a;mb&=b
    assert ma==mb and ma&~localmask==0 and ma&(1<<ix)
    selected=[j for j in range(P) if ma>>j&1];mass=sum(src[j][3] for j in selected)
    # root t=(mass/lambda)^(1/n) is exactly t with lambda=mass/t^n.
    pay=F(mass)*ell/t**n
    shares=sum(F(src[j][3])*ell/t**n for j in selected)
    assert pay==shares and F(wp)*ell/t**n>0
    root_shares+=len(selected);joint_cells+=1;full_checks+=1
  for i,d in enumerate(ds[ix]):
   for t in collision:
    center=intervals(d,p[i],t)
    for side in (-1,1):
     if side==1 and t==1:continue
     near=intervals(d,p[i],t+side*eps)
     # The exact state-wise limit of affine lengths, then probabilities,
     # equals the t-centre value; include states disappearing at collision.
     for key in set(center)|set(near):
      target=center.get(key,(F(0),None,None,None))[0]
      leng,slope,*_=near.get(key,(F(0),0,None,None))
      assert slope is not None and leng-side*eps*slope==target
      collision_checks+=1
 assert all((a[0],a[1],a[2])!=(b[0],b[1],b[2]) for j,a in enumerate(src) for b in src[j+1:])
 return {'n':n,'m':m,'sources':P,'nonproduct_weight_minor':minor,'global_coordinate_fine_labels':2*m,'max_true_local_D':maxD,'local_D_size_histogram':dict(sorted(seen.items())),'strict_reception_overlap_graph_connected':True,'directed_overlap_edges':edges,'regular_t':[str(t) for t in reg],'per_coordinate_distributions_checked':distributions,'zero_state_terms_checked':zero_states,'joint_original_mass_cells_checked':joint_cells,'individual_root_share_terms_checked':root_shares,'collision_t':[str(t) for t in collision],'epsilon':str(eps),'collision_one_sided_state_limits_checked':collision_checks}

def main():
 rows=[]
 for n,m in [(2,4),(2,6),(2,8),(3,4)]:
  r=run_case(n,m);rows.append(r);print(n,m,'max_D',r['max_true_local_D'],'joint cells',r['joint_original_mass_cells_checked'],'collision',r['collision_one_sided_state_limits_checked'],flush=True)
 return {'model':'for alpha in {0,...,m-1}^n and common bit epsilon in {0,1}, p_i=alpha_i+floor(alpha_i/2)/(64M)+(alpha_i mod 2)/8+epsilon/4, m=2M','normalization':'Each tested left endpoint xi_i lies in [p_i-t,p_i]; probability state is ell/t. Windows are half-open with boundary events of zero endpoint measure.','source_weight':'1+(3a0+5a1+7a0a1+sum((i+3)*a[i+2])+11*bit+3*bit*a0) mod 17; weights are positive, joint and correlated.','tests':'Exact fractions throughout. For each source at each regular t verify normalization, all zero states, Fisher identity, original all-source inclusion equals local inclusion, and root payment decomposition. Collision limits are exact one-sided affine length continuations.','limits':'Finite box of sources, no periodic copies. Numerical tests cover listed t values and finite source sets, not arbitrary t or dimension.','symbolic_accounting':'The D_i subset of one coordinate 2-neighborhood of p_i meets at most three unit coarse cells because all fine offsets lie in [0,1/2); two candidates per cell, so |D_i|<=6. For D<=6, endpoint crossing times among p and D occur among pairwise differences, at most 15; tensor across a common source and coordinate needs separate proof for any global estimate.','cases':rows}
if __name__=='__main__':
 p=Path(__file__).with_suffix('.json');s=json.dumps(main(),sort_keys=True,indent=2)+'\n'
 if '--check' in sys.argv:assert p.read_text()==s;print('byte-identical exact replay')
 else:p.write_text(s)
