"""Continuous-scale, common-threshold payment on an exact planar chain."""
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import argparse
import json


def make_source(count):
    points = [(F(5*j, 8), F((5*j) % 7, 16)) for j in range(count)]
    return dict(zip(points, [9 if j % 2 == 0 else 16 for j in range(count)]))


def captured(source, x, t):
    return [p for p in source if all(2*abs(p[i]-x[i]) <= t for i in (0,1))]


def axis_prob(positions, p, t):
    # The two open gaps identify the complete local set on this axis.
    from bisect import bisect_right
    ends = sorted(v for v in ({p-t, p} | set(positions) | {z-t for z in positions}) if p-t <= v <= p)
    out = {}
    for lo, hi in zip(ends, ends[1:]):
        u = (lo+hi)/2
        key = (bisect_right(positions,u), bisect_right(positions,u+t))
        assert key not in out
        out[key] = (hi-lo)/t
    assert sum(out.values()) == 1
    return out


def verify(count, a, s):
    mu = make_source(count)
    lam = s*s
    # Any three consecutive points span 5/4; only singles and adjacent pairs fit.
    groups = [[p] for p in mu] + [list(pair) for pair in zip(list(mu),list(mu)[1:])]
    candidates = {a, F(1)} | {r/s for r in map(F,(3,4,5)) if a <= r/s <= 1}
    # Each group enters the strict level exactly on the interior of its common
    # receiver box at its largest admissible radius, up to the faces.
    boxes = []
    for group in groups:
        mass = sum(mu[p] for p in group)
        sr = {9:3,16:4,25:5}[mass]
        if mass <= lam*a*a:
            continue
        t = min(F(1), F(sr)/s)
        b = [(max(p[i] for p in group)-t/2,min(p[i] for p in group)+t/2) for i in (0,1)]
        if all(l < h for l,h in b):
            boxes.append(b)
    axes = [sorted({p[i]+sign*t/2 for p in mu for t in candidates for sign in (-1,1)}) for i in (0,1)]
    whole = end_vol = F(0)
    shares = dict.fromkeys(mu,F(0))
    cells = roots = 0
    for bx, by in product(zip(axes[0],axes[0][1:]), zip(axes[1],axes[1][1:])):
        x = ((bx[0]+bx[1])/2,(by[0]+by[1])/2)
        area = (bx[1]-bx[0])*(by[1]-by[0])
        cells += 1
        inside = any(all(lo < v < hi for (lo,hi),v in zip(b,x)) for b in boxes)
        births = {max(2*abs(p[i]-x[i]) for i in (0,1)) for p in mu}
        times = {a,F(1)} | {b for b in births if a <= b <= 1}
        def mass(t):
            return sum(mu[p] for p in captured(mu,x,t))
        direct = max(F(mass(t))/t**2 for t in times)
        assert inside == (direct > lam)
        if not inside:
            continue
        whole += area
        if mass(F(1)) >= lam:
            end_vol += area
            continue
        # A crossing born at equality alone is excluded; the left limit must pay.
        valid = [t for t in candidates if a<t<1 and mass(t)==lam*t*t
                 and sum(mu[p] for p in mu if max(2*abs(p[i]-x[i]) for i in (0,1))<t)==lam*t*t]
        t = max(valid)
        for p in captured(mu,x,t):
            shares[p] += area*mu[p]/t**2
        roots += 1
    assert lam*whole == lam*end_vol+sum(shares.values())
    env = F(0)
    for p,w in mu.items():
        neighbors = [q for q in mu if all(abs(p[i]-q[i])<=1 for i in (0,1))]
        ds = [sorted({q[i] for q in neighbors}) for i in (0,1)]
        maxima = {}
        for t in candidates:
            px, py = [axis_prob(ds[i],p[i],t) for i in (0,1)]
            for (kx,u),(ky,v) in product(px.items(),py.items()):
                maxima[kx,ky] = max(maxima.get((kx,ky),0),u*v)
        bound = w*sum(maxima.values())
        assert shares[p] <= bound
        env += bound
    assert lam*end_vol <= sum(mu.values())
    return dict(points=count, a=str(a), threshold=str(lam), cells=cells, root_cells=roots,
                level_volume=str(whole), endpoint_volume=str(end_vol), source_total=sum(mu.values()),
                assigned_root_mass=str(sum(shares.values())), candidate_envelope=str(env))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    cases = [(2,F(1,2),F(6)),(3,F(1,2),F(4)),(4,F(2,3),F(6)),
             (7,F(1,3),F(7)),(11,F(1,2),F(5)),(13,F(1,4),F(8))]
    rows = [verify(*case) for case in cases]
    assert any(F(x["endpoint_volume"])>0 for x in rows)
    assert any(x["root_cells"]>0 for x in rows)
    saved = Path(__file__).with_suffix(".json")
    result = (json.dumps(rows,indent=2,sort_keys=True)+"\n").encode()
    if args.check:
        assert saved.read_bytes() == result
    else:
        saved.write_bytes(result)
    print(len(rows), "continuous-window threshold cases;",sum(x["cells"] for x in rows),
          "arrangement rectangles;",sum(x["root_cells"] for x in rows),"interior-root rectangles")


if __name__ == "__main__":
    main()
