#!/usr/bin/env python3
"""Certified compact receiver subsets for actual positive L1 box inputs.
Stdlib rational / integer interval certificates. Continuous hard first contact,
whole-window genuine E2 gate, original middle test; conservative continuum
Hall brackets and sourcewise feasible flow. Finite fixtures, no general bound.
"""
from fractions import Fraction as F
from pathlib import Path
from functools import lru_cache
from itertools import product
from collections import deque
import json, math, time
SEED=850611
S=1<<60
Z=1<<24
def clean(x):
    if isinstance(x,F):return str(x)
    if isinstance(x,dict):return {str(k):clean(v) for k,v in x.items()}
    if isinstance(x,(tuple,list)):return [clean(v) for v in x]
    return x


def trim(p):
    p=list(map(F,p))
    while len(p)>1 and not p[-1]:p.pop()
    return tuple(p)


def zero(p):return len(p)==1 and p[0]==0
def add(p,q):return trim([(p[i] if i<len(p) else 0)+(q[i] if i<len(q) else 0) for i in range(max(len(p),len(q)))])
def scale(p,a):return trim([F(a)*x for x in p])
def derivative(p):return trim([i*p[i] for i in range(1,len(p))] or [0])


def multiply(p,q):
    out=[F(0)]*(len(p)+len(q)-1)
    for i,a in enumerate(p):
        for j,b in enumerate(q):out[i+j]+=a*b
    return trim(out)


def evaluate(p,x):
    value=F(0)
    for a in reversed(p):value=value*x+a
    return value


def remainder(p,q):
    assert not zero(q);out=list(p)
    while len(out)>=len(q) and not zero(trim(out)):
        a=out[-1]/q[-1];shift=len(out)-len(q)
        for j,b in enumerate(q):out[shift+j]-=a*b
        out=list(trim(out))
    return trim(out)


@lru_cache(None)
def sturm(p):
    p=trim(p)
    if zero(p):return ()
    seq=[p];d=derivative(p)
    if zero(d):return tuple(seq)
    seq.append(d)
    while True:
        rem=scale(remainder(seq[-2],seq[-1]),-1)
        if zero(rem):break
        # Positive rational scaling preserves the Sturm signs.
        rem=scale(rem,1/abs(rem[-1]));seq.append(rem)
    return tuple(seq)


def sign(x):return 1 if x>0 else -1 if x<0 else 0


def side_sign(p,x,side):
    """Exact one-sided endpoint sign, including repeated roots/gcd zeros."""
    assert side in (-1,1)
    d=p;order=0
    while not zero(d):
        value=evaluate(d,x)
        if value:return sign(value)*(side if order%2 else 1)
        d=derivative(d);order+=1
    return 0


def variation(seq,x,side):
    signs=[side_sign(p,x,side) for p in seq]
    signs=[v for v in signs if v]
    return sum(a!=b for a,b in zip(signs,signs[1:]))


def root_count(p,a,b):
    """Count distinct roots strictly in (a,b), using V(a+)-V(b-)."""
    assert a<b and not zero(p)
    seq=sturm(p);count=variation(seq,a,1)-variation(seq,b,-1)
    assert count>=0
    return count


class Flow:
    def __init__(self,N):self.graph=[[] for _ in range(N)];self.original=[]
    def edge(self,a,b,c):
        ai=len(self.graph[a]);bi=len(self.graph[b]);self.graph[a].append([b,bi,c]);self.graph[b].append([a,ai,0]);self.original.append((a,b,c,ai))
    def maxflow(self,s,t):
        value=0;N=len(self.graph)
        while True:
            level=[-1]*N;level[s]=0;q=deque([s])
            while q:
                v=q.popleft()
                for w,rev,c in self.graph[v]:
                    if c and level[w]<0:level[w]=level[v]+1;q.append(w)
            if level[t]<0:break
            ptr=[0]*N
            def dfs(v,f):
                if v==t:return f
                while ptr[v]<len(self.graph[v]):
                    e=self.graph[v][ptr[v]];w,rev,c=e
                    if c and level[w]==level[v]+1:
                        z=dfs(w,min(f,c))
                        if z:e[2]-=z;self.graph[w][rev][2]+=z;return z
                    ptr[v]+=1
                return 0
            while True:
                z=dfs(s,sum(c for a,b,c,i in self.original if a==s))
                if not z:break
                value+=z
        reachable={s};q=deque([s])
        while q:
            v=q.popleft()
            for w,rev,c in self.graph[v]:
                if c and w not in reachable:reachable.add(w);q.append(w)
        return value,reachable


def ceildiv(a,b):return -(-a//b)
def floor_scaled(x):return x.numerator*S//x.denominator
def ceil_scaled(x):return ceildiv(x.numerator*S,x.denominator)

@lru_cache(32768)
def expneg(x):
    """e^-x in exact dyadic enclosure; positive Taylor then inversion/squaring."""
    x=F(x);assert x>=0
    if x==0:return F(1),F(1)
    k=0;v=x
    while v>F(1,2):v/=2;k+=1
    vl=floor_scaled(v);vu=ceil_scaled(v)
    tl=tu=S;sl=su=S
    for j in range(1,21):
        tl=tl*vl//(S*j);tu=ceildiv(tu*vu,S*j);sl+=tl;su+=tu
    nxt=ceildiv(tu*vu,S*21);su+=2*nxt
    lo=S*S//su;hi=ceildiv(S*S,sl)
    for _ in range(k):lo=lo*lo//S;hi=ceildiv(hi*hi,S)
    return F(lo,S),F(hi,S)

@lru_cache(None)
def phi_grid(zint,nt):
    z=F(zint,Z);low=F(0);up=F(0)
    vals=[]
    for j in range(1,nt+1):
        t=F(j,nt)
        if z<=F(1,2):
            a,b=expneg((F(1,2)-z)/t),expneg((F(1,2)+z)/t)
            vals.append((t*(2-a[1]-b[1]),t*(2-a[0]-b[0])))
        else:
            a,b=expneg((z-F(1,2))/t),expneg((z+F(1,2))/t)
            vals.append((max(F(0),t*(a[0]-b[1])),t*(a[1]-b[0])))
    # The true t integrand is increasing, including across z=.5.
    low=sum(v[0] for v in vals[:-1])/nt;up=sum(v[1] for v in vals)/nt
    return F(floor_scaled(low),S),F(ceil_scaled(up),S)

def phi_bounds(z,nt):
    z=abs(F(z));lo=z.numerator*Z//z.denominator;hi=ceildiv(z.numerator*Z,z.denominator)
    return phi_grid(hi,nt)[0],phi_grid(lo,nt)[1]

def ov(x,a,b,L):return max(F(0),min(x+L/2,b)-max(x-L/2,a))
def capture(boxes,points,L):
    return sum(box['density']*math.prod(ov(x,a,b,L) for x,(a,b) in zip(point,box['bounds'])) for box,point in zip(boxes,points))

def point_envelope(boxes,receiver,upper):
    out=[]
    for box in boxes:
        point=[]
        for (a,b),(u,v) in zip(box['bounds'],receiver):
            c=(a+b)/2
            point.append(min(max(c,u),v) if upper else (u if abs(u-c)>=abs(v-c) else v))
        out.append(tuple(point))
    return tuple(out)

@lru_cache(None)
def hard_certificate_cached(boxkey,points,n):
    boxes=[dict(bounds=b,density=d) for b,d in boxkey]
    breaks=sorted({F(1),F(2)}|{2*abs(x-face) for box,point in zip(boxes,points) for x,ab in zip(point,box['bounds']) for face in ab if 1<2*abs(x-face)<2})
    rows=[];hit=None
    for a,b in zip(breaks,breaks[1:]):
        u=(2*a+b)/3;v=(a+2*b)/3;numerator=(F(0),)
        for box,point in zip(boxes,points):
            term=(box['density'],)
            for x,(c,d) in zip(point,box['bounds']):
                p=ov(x,c,d,u);q=ov(x,c,d,v);slope=(q-p)/(v-u)
                term=multiply(term,(p-slope*u,slope))
            numerator=add(numerator,term)
        diff=add(numerator,(F(0),)*n+(F(-1),))
        seq=sturm(diff);count=root_count(diff,a,b)
        rec=dict(left=a,right=b,numerator=numerator,difference=diff,sturm=seq,
                 variation_left_plus=variation(seq,a,1),variation_right_minus=variation(seq,b,-1),open_roots=count,
                 witness_point=(a+b)/2,witness_difference=evaluate(diff,(a+b)/2))
        for t in (u,v,(a+b)/2):assert evaluate(numerator,t)==capture(boxes,points,t)
        rows.append(rec)
        if hit is None:
            if evaluate(diff,a)==0:
                hit=dict(bracket=[a,a],interval_index=len(rows)-1,endpoint=True)
            elif count:
                assert count==1, "qualified fixtures require a unique first-interval root"
                aa,bb=a,b
                for _ in range(28):
                    mid=(aa+bb)/2
                    if evaluate(diff,mid)==0:aa=bb=mid;break
                    if root_count(diff,aa,mid):bb=mid
                    else:aa=mid
                assert aa==bb or root_count(diff,aa,bb)==1
                earlier=root_count(diff,a,aa) if aa>a else 0;assert earlier==0
                hit=dict(bracket=[aa,bb],interval_index=len(rows)-1,endpoint=False,within_first_interval_earlier_open_roots=earlier)
            else:assert evaluate(diff,(a+b)/2)<0
        rec['earlier_than_first_interval']=hit is None
    assert hit is not None
    idx=hit['interval_index'];p=rows[idx]['difference'];lo,hi=hit['bracket']
    assert side_sign(p,lo,-1)<0 and side_sign(p,hi,1)>0
    hit['left_sign']=side_sign(p,lo,-1);hit['right_sign']=side_sign(p,hi,1)
    return dict(physical_breakpoints=breaks,intervals=rows,first_contact=hit,anchor_average=capture(boxes,points,F(1)))

def hard_certificate(boxes,points,n):
    return hard_certificate_cached(tuple((tuple(b['bounds']),b['density']) for b in boxes),points,n)

def uniform_derivative(boxes,receiver,lo,hi,n):
    # Primary is a constant-density box. At a true root it contributes
    # positive but less than its full mass, hence has a partial coordinate.
    primary=boxes[0];mass=primary['density']*math.prod(v-u for u,v in primary['bounds'])
    extra=sum(b['density']*math.prod(v-u for u,v in b['bounds']) for b in boxes[1:])
    width=max(v-u for u,v in primary['bounds'])
    assert extra<lo**n and hi**n<mass
    lower=F(1,2)/width-F(n,lo)-extra/(2*width*lo**n)
    assert lower>0
    return dict(proof='At any actual root, primary capture>=L^n-extra>0 and <primary_mass; a partial coordinate has overlap<=max_primary_width and slope1/2. All other derivatives are nonnegative.',
                derivative_A_at_root_lower=lower,primary_mass=mass,extra_mass=extra,max_primary_width=width)

def coordinate_integral(a,b,u,v,lo,hi,ny,nt):
    width=b-a;lower=upper=F(0)
    for j in range(ny):
        ya=a+width*F(j,ny);yb=a+width*F(j+1,ny)
        mind=max(F(0),u-yb,ya-v)
        maxd=max(abs(u-ya),abs(u-yb),abs(v-ya),abs(v-yb))
        lower+=phi_bounds(maxd/lo,nt)[0];upper+=phi_bounds(mind/hi,nt)[1]
    return width*lower/(ny*hi),width*upper/(ny*lo)

@lru_cache(None)
def smooth_interval_cached(boxkey,receiver,lo,hi,ny,nt):
    lower=upper=F(0);parts=[]
    for bounds,density in boxkey:
        factors=[coordinate_integral(a,b,u,v,lo,hi,ny,nt) for (a,b),(u,v) in zip(bounds,receiver)]
        low=density*math.prod(x[0] for x in factors);up=density*math.prod(x[1] for x in factors)
        lower+=low;upper+=up;parts.append(dict(coordinate_intervals=factors,component_interval=[low,up]))
    # Outward round the final enclosure. Quantities may otherwise grow long.
    lower=F(floor_scaled(lower),S);upper=F(ceil_scaled(upper),S)
    return dict(interval=[lower,upper],components=parts)

def smooth_interval(boxes,receiver,lo,hi,ny,nt):
    return smooth_interval_cached(tuple((tuple(b['bounds']),b['density']) for b in boxes),tuple(receiver),lo,hi,ny,nt)

def receiver_certificate(boxes,receiver,n,ny=24,nt=48,nscale=32):
    upperpoints=point_envelope(boxes,receiver,True);lowerpoints=point_envelope(boxes,receiver,False)
    hcupper=hard_certificate(boxes,upperpoints,n);hclower=hard_certificate(boxes,lowerpoints,n)
    lo=hcupper['first_contact']['bracket'][0];hi=hclower['first_contact']['bracket'][1]
    assert 1<lo<=hi<2 and hcupper['anchor_average']<F(1,2)
    primary=boxes[0]
    full_scale=2*max(abs(x-y) for uv,ab in zip(receiver,primary['bounds']) for x in uv for y in ab)
    witness=min(F(2),max(hi+F(1,100000),full_scale))
    strict=capture(boxes,lowerpoints,witness)/witness**n;assert strict>1
    deriv=uniform_derivative(boxes,receiver,lo,hi,n)
    selected=smooth_interval(boxes,receiver,lo,hi,ny,nt)
    window=[]
    for j in range(nscale):
        a=1+F(j,nscale);b=1+F(j+1,nscale)
        window.append(dict(scale_interval=[a,b],upper=smooth_interval(boxes,receiver,a,b,ny,nt)['interval'][1]))
    pmax=max(x['upper'] for x in window);m=phi_bounds(F(1,2),nt);M=phi_bounds(F(0),nt)
    middle_upper=F(1,2)*m[1]*M[1]**(n-1)
    pl,pu=selected['interval'];mid=pl>middle_upper
    layer=None;thresholds=[]
    for j in range(4):
        lower=tuple(F(1,2)*x for x in expneg(F((1<<(j+1))-1)))
        upper=tuple(F(1,2)*x for x in expneg(F((1<<j)-1)))
        thresholds.append(dict(j=j,lower_P_threshold=lower,upper_P_threshold=upper))
        if pl>lower[1] and pu<=upper[0]:layer=j
    qualified=pmax<=F(1,2) and mid and layer is not None
    # Failure is retained as a diagnostic and may be refined by the driver.
    return dict(receiver=receiver,volume=math.prod(v-u for u,v in receiver),upper_envelope_points=upperpoints,lower_envelope_points=lowerpoints,
                upper_hard_certificate=hcupper,lower_hard_certificate=hclower,Lstar_interval=[lo,hi],uniform_derivative=deriv,
                anchor_upper=hcupper['anchor_average'],strict_witness_scale=witness,strict_witness_lower=strict,
                selected_P=selected,window_scale_intervals=window,whole_window_P_upper=pmax,phi_half_interval=m,phi_zero_interval=M,
                original_middle_threshold_upper=middle_upper,middle_test=mid,kappa_layer=layer,kappa_thresholds=thresholds,qualified=qualified,
                t_Riemann_count=nt,source_Riemann_count=ny,scale_window_count=nscale)
def source_partition(boxes,m):
    bins=[]
    for i,box in enumerate(boxes):
        for idx in product(range(m),repeat=len(box['bounds'])):
            bounds=tuple((a+(b-a)*F(k,m),a+(b-a)*F(k+1,m)) for (a,b),k in zip(box['bounds'],idx))
            bins.append(dict(component=i,bounds=bounds,mass=box['density']*math.prod(b-a for a,b in bounds)))
    assert sum(x['mass'] for x in bins)==sum(b['density']*math.prod(v-u for u,v in b['bounds']) for b in boxes)
    return bins

def graph_rows(certs,bins,boxes):
    rows=[]
    for c in certs:
        lo,hi=c['Lstar_interval'];r=c['receiver']
        inner=tuple((v-lo/2,u+lo/2) for u,v in r);outer=tuple((u-hi/2,v+hi/2) for u,v in r)
        im=om=0
        primary=boxes[0];primary_mass=primary['density']*math.prod(v-u for u,v in primary['bounds'])
        extra=sum(box['density']*math.prod(v-u for u,v in box['bounds']) for box in boxes[1:])
        fraction=(lo**len(r)-extra)/primary_mass;assert fraction>0
        root_mass_box=[]
        for (a,b),(u,v) in zip(primary['bounds'],r):
            depth=min(F(1),fraction)*(b-a)
            if v<a:root_mass_box.append((a,a+depth))
            elif u>b:root_mass_box.append((b-depth,b))
            else:
                assert lo/2>=max(abs(x-y) for x in (u,v) for y in (a,b)), 'inside-projection coordinate must be uniformly fully captured'
                root_mass_box.append((a,b))
        root_mass_box=tuple(root_mass_box)
        for i,b in enumerate(bins):
            if all(a>=u and z<=v for (a,z),(u,v) in zip(b['bounds'],inner)) or (b['component']==0 and all(a>=u and z<=v for (a,z),(u,v) in zip(b['bounds'],root_mass_box))):im|=1<<i
            if all(min(z,v)>max(a,u) for (a,z),(u,v) in zip(b['bounds'],outer)):om|=1<<i
        assert im and im&om==im
        center=tuple((u+v)/2 for u,v in r)
        center_points=tuple(center for _ in c['upper_envelope_points'])
        center_hard=hard_certificate(boxes,center_points,len(r))
        rows.append(dict(receiver=r,volume=c['volume'],demand=c['volume'],Lstar_interval=[lo,hi],kappa_layer=c['kappa_layer'],midpoint_receiver_hard_certificate=center_hard,
                         guaranteed_capture_box=inner,primary_root_mass_capture_box=root_mass_box,primary_capture_fraction_lower=fraction,possible_capture_box=outer,inner_source_mask=im,outer_source_mask=om))
    return rows

def mask_mass(mask,bins):return sum(b['mass'] for i,b in enumerate(bins) if mask>>i&1)

def flow_at(rows,bins,key,K,save):
    m=len(rows);N=len(bins);total=sum(r['demand'] for r in rows);den=1
    for v in [r['demand'] for r in rows]+[K*b['mass'] for b in bins]:den=math.lcm(den,v.denominator)
    s=0;t=m+N+1;flow=Flow(t+1);infinite=int(total*den)+1
    for i,r in enumerate(rows):
        flow.edge(s,i+1,int(r['demand']*den))
        mask=r[key]
        while mask:
            bit=mask&-mask;j=bit.bit_length()-1;flow.edge(i+1,m+j+1,infinite);mask^=bit
    for j,b in enumerate(bins):flow.edge(m+j+1,t,int(K*b['mass']*den))
    val,reach=flow.maxflow(s,t);rm=sum(1<<i for i in range(m) if i+1 in reach)
    arcs=[];balance=[0]*(t+1)
    for a,b,cap,index in flow.original:
        used=cap-flow.graph[a][index][2];assert 0<=used<=cap
        balance[a]-=used;balance[b]+=used
        if save and used:arcs.append(dict(tail=a,head=b,capacity=F(cap,den),flow=F(used,den)))
    assert balance[s]==-val and balance[t]==val and all(v==0 for v in balance[1:t])
    cut=sum(c for a,b,c,_ in flow.original if a in reach and b not in reach);assert cut==val
    # Largest source side among all minimum cuts = complement of vertices
    # that can reach sink in the residual digraph.
    rev=[[] for _ in range(t+1)]
    for a,edges in enumerate(flow.graph):
        for b,_,cap in edges:
            if cap:rev[b].append(a)
    co={t};q=deque([t])
    while q:
        v=q.popleft()
        for a in rev[v]:
            if a not in co:co.add(a);q.append(a)
    maxrm=sum(1<<i for i in range(m) if i+1 not in co)
    rec=dict(total=F(val,den),required=total,integer_denominator=den,positive_arcs=arcs,all_arcs_count=len(flow.original),
             residual_reachable=sorted(reach),cut_capacity=F(cut,den),maximal_min_cut_receiver_mask=maxrm,
             sink_coreachable=sorted(co),node_layout=dict(source=0,receiver_start=1,source_bin_start=1+m,sink=t))
    return F(val,den),rm,maxrm,rec

def hall_density(rows,bins,key,save_flow):
    K=F(0);iterations=[];total=sum(r['demand'] for r in rows)
    for step in range(100):
        val,rm,maxrm,rec=flow_at(rows,bins,key,K,False)
        if val==total:
            union=0;demand=F(0)
            for i,r in enumerate(rows):
                if maxrm>>i&1:union|=r[key];demand+=r['demand']
            assert maxrm and demand==K*mask_mass(union,bins)
            if save_flow:val,_,_,rec=flow_at(rows,bins,key,K,True)
            return dict(K=K,iterations=iterations,maximal_maximizer_receiver_mask=maxrm,maximal_maximizer_source_mask=union,
                        maximal_cut_demand=demand,maximal_cut_source_mass=mask_mass(union,bins),flow=rec if save_flow else None)
        union=0;demand=F(0)
        for i,r in enumerate(rows):
            if rm>>i&1:union|=r[key];demand+=r['demand']
        mass=mask_mass(union,bins);new=demand/mass;assert new>K
        iterations.append(dict(K=K,maxflow=val,receiver_mask=rm,source_union_mask=union,demand=demand,mass=mass,new_K=new));K=new
    raise AssertionError('explicit density iteration budget exceeded')

GAMMA=0.5772156649015329
@lru_cache(200000)
def e1(x):
    if x<=0:return float('inf')
    if x<=1:
        term=-x;s=term
        for k in range(2,100):
            term*=-x/k;z=term/k;s+=z
            if abs(z)<1e-17:break
        return -GAMMA-math.log(x)-s
    b=x+1.;c=1e300;d=1/b;h=d
    for k in range(1,200):
        a=-float(k*k);b+=2.;d=a*d+b;c=b+a/c
        if abs(d)<1e-300:d=1e-300
        if abs(c)<1e-300:c=1e-300
        d=1/d;delta=d*c;h*=delta
        if abs(delta-1)<2e-15:break
    return math.exp(-x)*h

def wf(x):
    if x<=0:return 0.
    if x>700:return .5
    return (1+(x-1)*math.exp(-x)-x*x*e1(x))/2

def wg(x):
    if x<=0:return 0.
    if x>700:return x/2-1/3
    return x/2+math.exp(-x)*(x*x-x+2)/6-x**3*e1(x)/6-1/3

def phif(z,eta=1.):
    z=abs(z)
    if z<=.5:return max(0.,wf((.5+z)/eta)+wf((.5-z)/eta))
    return max(0.,wf((z+.5)/eta)-wf((z-.5)/eta))

def phiprim(z,eta=1.):
    if z<0:return -phiprim(-z,eta)
    return eta*(wg((z+.5)/eta)-wg(abs(z-.5)/eta))

def smooth_float(boxes,x,L,eta,captured=False):
    total=0.
    for box in boxes:
        term=float(box['density'])
        for (a,b),xx in zip(box['bounds'],x):
            aa=float(a);bb=float(b)
            if captured:aa=max(aa,xx-L/2);bb=min(bb,xx+L/2)
            if aa>=bb:term=0.;break
            term*=max(0.,phiprim((xx-aa)/L,eta)-phiprim((xx-bb)/L,eta))
        total+=term
    return total

def diagnostic_columns(rows,bins,boxes,n,receiver_mask):
    selected=[r for i,r in enumerate(rows) if receiver_mask>>i&1];theta=1/math.log(n+2)**2
    bvals=[0.]*len(bins);bsurv=[0.]*len(bins);survivor_mask=0;ell=[0.]*len(bins);qvals=[0.]*len(bins);weights=[[] for _ in bins];logs=[[] for _ in bins];logu=[[] for _ in bins]
    row_stop=[];fail=0
    for row in selected:
        cl,ch=row['midpoint_receiver_hard_certificate']['first_contact']['bracket'];L=float((cl+ch)/2);x=[float((u+v)/2) for u,v in row['receiver']]
        vol=float(row['volume']);pth=smooth_float(boxes,x,L,theta,False);cth=smooth_float(boxes,x,L,theta,True)
        stop=None;d=None
        if pth<.5 and cth<.5:
            low=1e-10;high=theta
            for _ in range(35):
                mid=(low+high)/2;c=smooth_float(boxes,x,L,mid,True)
                if c>.75:low=mid
                else:high=mid
            stop=(low+high)/2;d=.75-cth;survivor_mask|=1<<rows.index(row)
        else:fail+=1
        row_stop.append(dict(receiver_index=rows.index(row),center_Ptheta=pth,center_Ctheta=cth,eta_stop=stop,d_stop=d))
        for j,bin in enumerate(bins):
            y=[float((a+b)/2) for a,b in bin['bounds']]
            if all(abs(a-b)<L/2 for a,b in zip(x,y)):
                w=vol/L**n;bvals[j]+=w;weights[j].append(w);logs[j].append(math.log(L));u=math.log(max(1.,2*max(abs(a-b) for a,b in zip(x,y))));logu[j].append(u)
                if stop is not None:
                    bsurv[j]+=w
                    k=(math.prod(phif((a-b)/L,stop) for a,b in zip(x,y))-math.prod(phif((a-b)/L,theta) for a,b in zip(x,y)))/L**n
                    k=max(0.,k);qvals[j]+=vol*k;ell[j]+=vol*k/d
    Vt=Vu=Er2=loadmass=0.;sigma=[]
    for j,bin in enumerate(bins):
        b=bvals[j]
        if b:
            mt=sum(w*z for w,z in zip(weights[j],logs[j]))/b;mu=sum(w*z for w,z in zip(weights[j],logu[j]))/b
            vt=sum(w*(z-mt)**2 for w,z in zip(weights[j],logs[j]))/b;vu=sum(w*(z-mu)**2 for w,z in zip(weights[j],logu[j]))/b
            er=sum(w*(t-u)**2 for w,t,u in zip(weights[j],logs[j],logu[j]))/b
        else:vt=vu=er=0.
        mass=float(bin['mass']);loadmass+=mass*b;Vt+=mass*b*vt;Vu+=mass*b*vu;Er2+=mass*b*er;sigma.append(math.sqrt(vt))
    D=sum(float(r['demand']) for r in selected)
    return dict(scope='All stopped, variance and moment values are receiver/source midpoint diagnostics. Ptheta and stop are not interval certificates.',
                receiver_mask=receiver_mask,theta=theta,narrow_gate_failed_center_rows=fail,center_rows=row_stop,
                source_b=bvals,source_b_same_center_coarse_survivors=bsurv,center_coarse_survivor_mask=survivor_mask,canonical_same_center_survivors_max=max(bsurv),source_ell=ell,source_q=qvals,source_sigma=sigma,canonical_max=max(bvals),stopped_max=max(ell),q_max=max(qvals),
                load_integral_midpoint=loadmass,exact_D=D,V_t_midpoint=Vt/D,V_u_midpoint=Vu/D,E_r2_midpoint=Er2/D,
                firstcontact_E_r2_target=2/n**2,sqrt_variance_difference=abs(math.sqrt(Vt/D)-math.sqrt(Vu/D)),sqrt_difference_target=math.sqrt(2)/n)


def boxes_fixture(label,n,base_bounds,W,extras=(),domain=(F(3,5),F(9,10)),tiles=3,partition=4,stage=1):
    base=dict(bounds=tuple(base_bounds),density=F(W)/math.prod(v-u for u,v in base_bounds));boxes=[base]
    for bounds,mass in extras:boxes.append(dict(bounds=tuple(bounds),density=F(mass)/math.prod(v-u for u,v in bounds)))
    source_lo=[a for a,b in base_bounds];source_hi=[b for a,b in base_bounds];receivers=[];da,db=domain
    for signs in product((0,1),repeat=n):
        for idx in product(range(tiles),repeat=n):
            r=[]
            for j,(sign,k) in enumerate(zip(signs,idx)):
                a=da+(db-da)*F(k,tiles);b=da+(db-da)*F(k+1,tiles)
                r.append((source_lo[j]-b,source_lo[j]-a) if not sign else (source_hi[j]+a,source_hi[j]+b))
            receivers.append(tuple(r))
    return dict(label=label,n=n,stage=stage,lambda_value=F(1),boxes=boxes,W=sum(b['density']*math.prod(v-u for u,v in b['bounds']) for b in boxes),
                receiver_boxes=receivers,source_partition_per_axis=partition,seed=SEED,publication='Neutral upper-interface finite-L1 test; not supplied lower-catalog construction.')


def split_receiver(r):
    j=max(range(len(r)),key=lambda i:r[i][1]-r[i][0]);a,b=r[j];mid=(a+b)/2
    u=list(r);v=list(r);u[j]=(a,mid);v[j]=(mid,b);return tuple(u),tuple(v)

def qualify(src,max_depth=3):
    pending=[(r,0) for r in src['receiver_boxes']];certs=[];failed=[]
    while pending:
        r,depth=pending.pop()
        try:c=receiver_certificate(src['boxes'],r,src['n'],ny=4,nt=64,nscale=16)
        except AssertionError as exc:
            failed.append(dict(receiver=r,depth=depth,reason='hard/root regularity failed',detail=str(exc)));continue
        if c['qualified']:certs.append(c)
        elif depth<max_depth:
            pending.extend((rr,depth+1) for rr in split_receiver(r))
        else:failed.append(dict(receiver=r,depth=depth,reason='full E2/middle/kappa not certified',window_P_upper=c['whole_window_P_upper'],selected_P_interval=c['selected_P']['interval'],middle_threshold_upper=c['original_middle_threshold_upper'],kappa_layer=c['kappa_layer']))
    return certs,failed


def rectangle_envelope_float(radii):
    if not radii or min(radii)<=0:return 0.
    c=[min(2.,max(0.,2*float(r))) for r in radii]
    breaks=sorted(set([1.,2.]+[x for x in c if 1<x<2]))
    value=math.prod(min(x,2.) for x in c)/2**len(c)
    n=len(c)
    for a,b in zip(breaks,breaks[1:]):
        mid=(a+b)/2;m=sum(x>mid for x in c);p=math.prod(x for x in c if x<=mid)
        value+=n*p*(math.log(b/a) if m==n else (a**(m-n)-b**(m-n))/(n-m))
    return value

def fibre_metrics(rows,bins,n):
    full=(1<<len(rows))-1
    left=sum(1<<i for i,r in enumerate(rows) if sum(r['receiver'][0])<0)
    family={'whole':[full],'coordinate_halves':[left,full^left],'individual_receiver_cells':[1<<i for i in range(len(rows))]}
    summaries={};whole_records=[]
    for name,masks in family.items():
        feeslo=[0.]*len(bins);feeshi=[0.]*len(bins)
        for mask in masks:
            if not mask:continue
            selected=[r for i,r in enumerate(rows) if mask>>i&1]
            for j,bin in enumerate(bins):
                y=[(a+b)/2 for a,b in bin['bounds']];lower=[F(0)]*n;upper=[F(0)]*n
                for row in selected:
                    if row['inner_source_mask']>>j&1:
                        for k,(a,b) in enumerate(row['receiver']):lower[k]=max(lower[k],abs(a-y[k]),abs(b-y[k]))
                    if row['outer_source_mask']>>j&1:
                        hi=row['Lstar_interval'][1];inter=[(max(a,yy-hi/2),min(b,yy+hi/2)) for (a,b),yy in zip(row['receiver'],y)]
                        if all(a<b for a,b in inter):
                            for k,(a,b) in enumerate(inter):upper[k]=max(upper[k],abs(a-y[k]),abs(b-y[k]))
                assert all(a<=b for a,b in zip(lower,upper))
                cl=rectangle_envelope_float(lower);cu=rectangle_envelope_float(upper);feeslo[j]+=cl;feeshi[j]+=cu
                if name=='whole':whole_records.append(dict(source_bin=j,source_center=y,actual_fibre_radius_intervals=list(zip(lower,upper)),envelope_float_interval=[cl,cu]))
        W=sum(float(b['mass']) for b in bins)
        summaries[name]=dict(patch_count=sum(bool(x) for x in masks),summed_source_envelope_max_float_interval=[max(feeslo),max(feeshi)],
                             summed_source_envelope_mass_average_float_interval=[sum(float(b['mass'])*v for b,v in zip(bins,feeslo))/W,sum(float(b['mass'])*v for b,v in zip(bins,feeshi))/W])
    return dict(scope='Fibre radii bounds at source-bin centers are exact; rectangle log evaluation and source mass quadrature are diagnostic. Patches cover the same B; shared source envelope is summed once per patch with all repeated charges retained.',
                patch_families=summaries,whole_source_center_fibres=whole_records)

def run_case(src):
    certs,failed=qualify(src);bins=source_partition(src['boxes'],src['source_partition_per_axis']);allrows=graph_rows(certs,bins,src['boxes'])
    strata=[]
    for layer in sorted({r['kappa_layer'] for r in allrows}):
        rows=[r for r in allrows if r['kappa_layer']==layer];inner=hall_density(rows,bins,'inner_source_mask',True);outer=hall_density(rows,bins,'outer_source_mask',True)
        full=(1<<len(rows))-1;dm=diagnostic_columns(rows,bins,src['boxes'],src['n'],full);cutdm=diagnostic_columns(rows,bins,src['boxes'],src['n'],inner['maximal_maximizer_receiver_mask'])
        canonical=[]
        for j,bin in enumerate(bins):
            lower=sum(F(floor_scaled(r['volume']/r['Lstar_interval'][1]**src['n']),S) for r in rows if r['inner_source_mask']>>j&1)
            upper=sum(F(ceil_scaled(r['volume']/r['Lstar_interval'][0]**src['n']),S) for r in rows if r['outer_source_mask']>>j&1)
            canonical.append(dict(source_bin=j,interval=[lower,upper]))
        union=inner['maximal_maximizer_source_mask'];leak=sum(float(b['mass'])*(dm['source_b'][j]-cutdm['source_b'][j]) for j,b in enumerate(bins) if union>>j&1)
        A=inner['maximal_maximizer_receiver_mask'];outer_union=0
        for i,r in enumerate(rows):
            if A>>i&1:outer_union|=r['outer_source_mask']
        leaklo=leakhi=F(0)
        for j,bin in enumerate(bins):
            if union>>j&1:leaklo+=bin['mass']*sum(F(floor_scaled(r['volume']/r['Lstar_interval'][1]**src['n']),S) for i,r in enumerate(rows) if not A>>i&1 and r['inner_source_mask']>>j&1)
            if outer_union>>j&1:leakhi+=bin['mass']*sum(F(ceil_scaled(r['volume']/r['Lstar_interval'][0]**src['n']),S) for i,r in enumerate(rows) if not A>>i&1 and r['outer_source_mask']>>j&1)
        fibres=fibre_metrics(rows,bins,src['n'])
        strata.append(dict(kappa_layer=layer,rows=rows,inner_Hall=inner,outer_Hall=outer,continuum_K_interval=[outer['K'],inner['K']],
                           burden_D_over_W=sum(r['demand'] for r in rows)/src['W'],canonical_source_intervals=canonical,
                           canonical_essential_max_interval=[max(c['interval'][0] for c in canonical),max(c['interval'][1] for c in canonical)],
                           certified_canonical_excess_over_feasible_Hall=max(c['interval'][0] for c in canonical)-inner['K'],
                           certified_canonical_strictly_exceeds_Hall_upper=max(c['interval'][0] for c in canonical)>inner['K'],
                           full_diagnostics=dm,maxcut_diagnostics=cutdm,canonical_complementary_leakage_on_inner_source_union_midpoint=leak,canonical_complementary_leakage_actual_N_interval=[leaklo,leakhi],
                           selected_inner_maxcut_actual_neighborhood_mass_interval=[mask_mass(union,bins),mask_mass(outer_union,bins)],fibre_patch_metrics=fibres,
                           leakage_scope='Diagnostic with the inner-bin maximal neighborhood; not exact physical N(A).'))
    requested=sum(math.prod(v-u for u,v in r) for r in src['receiver_boxes'])
    qualified=sum(c['volume'] for c in certs);badvolume=sum(math.prod(v-u for u,v in f['receiver']) for f in failed)
    assert qualified+badvolume==requested
    return dict(input=src,qualified_receivers=certs,unqualified_cells=failed,source_bins=bins,strata=strata,
                requested_receiver_volume=requested,qualified_receiver_volume=qualified,unqualified_receiver_volume=badvolume,qualified_volume_fraction=qualified/requested)


def main():
    b=F(1,50);cases=[]
    cases.append(boxes_fixture('broad_spike_n2',2,((F(0),b),)*2,4,domain=(F(3,5),F(9,10)),tiles=3,stage=1))
    combined=boxes_fixture('broad_corner_and_side_union_n2',2,((F(0),b),)*2,4,domain=(F(3,5),F(9,10)),tiles=3,partition=8,stage=1)
    for axis in range(2):
        for sign in (0,1):
            for k in range(2):
                da=F(43,50)+F(1,25)*k;db=da+F(1,25)
                outside=(-db,-da) if sign==0 else (b+da,b+db)
                for j in range(4):
                    inside=(F(-1,2)+F(51,200)*j,F(-1,2)+F(51,200)*(j+1))
                    combined['receiver_boxes'].append((outside,inside) if axis==0 else (inside,outside))
    cases.append(combined)
    cases.append(boxes_fixture('broad_spike_n2_refinement',2,((F(0),b),)*2,4,domain=(F(3,5),F(9,10)),tiles=3,partition=8,stage=1))
    extra=((F(1,5),F(11,50)),)*2
    cases.append(boxes_fixture('correlated_spike_plus_satellite_n2',2,((F(0),b),)*2,4,[(extra,F(2,5))],domain=(F(13,20),F(9,10)),tiles=3,stage=2))
    cases.append(boxes_fixture('correlated_spike_satellite_source_refined_n2',2,((F(0),b),)*2,4,[(extra,F(2,5))],domain=(F(13,20),F(9,10)),tiles=3,partition=8,stage=2))
    cases.append(boxes_fixture('anisotropic_primary_n2',2,((F(0),b),(F(0),F(3,25))),4,domain=(F(13,20),F(17,20)),tiles=3,partition=8,stage=2))
    cases.append(boxes_fixture('dimension_aligned_n2',2,((F(0),b),)*2,4,domain=(F(13,20),F(9,10)),tiles=2,partition=4,stage=3))
    cases.append(boxes_fixture('broad_spike_n3',3,((F(0),b),)*3,8,domain=(F(13,20),F(9,10)),tiles=2,partition=4,stage=3))
    out=[]
    for case in cases:
        r=run_case(case);out.append(r);print(case['label'],'qualified',len(r['qualified_receivers']),'failed',len(r['unqualified_cells']),[(s['kappa_layer'],str(s['burden_D_over_W']),str(s['continuum_K_interval'])) for s in r['strata']],flush=True)
    data=dict(schema='R85-broad-actual-L1-certified-Hall-v1',seed=SEED,cases=out,
              scope='New larger actual receiver unions, no reuse of R84 twelve tiny fixtures. Original continuous firstcontact, full E2, original middle and kappa certs on accepted cells; stopped and fibre moments diagnostic only.',
              counts=dict(cases=len(out),qualified_receiver_cells=sum(len(c['qualified_receivers']) for c in out),unqualified_cells=sum(len(c['unqualified_cells']) for c in out),
                          strata=sum(len(c['strata']) for c in out),source_bins=sum(len(c['source_bins']) for c in out)),
              publication='Neutral box tests only; no unpublished lower-catalog construction is encoded.')
    Path(__file__).with_name('hall_results.json').write_text(json.dumps(clean(data),sort_keys=True,indent=2)+'\n');print('PASS',data['counts'])

if __name__=='__main__':main()
