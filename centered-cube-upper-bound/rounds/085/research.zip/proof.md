# 中心立方体第85轮：径向接触预算与共同来源递推

2026-10-11。主目标 $C_n^\square\le\sqrt n\,n^{o(1)}$ **仍未证明**；保留的一般上界为 $O(n\log n)$。本轮沿一般输入路线推进，不以有限函数族、局部接口或条件性返回作为完成。

新的统一结论来自真实首次接触：来源到立方体边界的截断对数深度具有 $e^{-nh}$ 尾界。由此将来源尺度方差转移到真实接收几何，并证明高 Hall 比值必须对应高规范列来源上的径向方差。余下任务是证明这个径向方差的共同来源预算，而非继续优化单个标量矩不等式。

自适应路线给出可调的局部来源删除规则和完整有限深度账。它保留每次降低阈值、重新分类、重复来源支付及终端余项。将递归收缩因子改进到接近局部删除份额，只增加对数费用；几何收缩本身仍缺证明。空间复制、远处来源质量和已有压力测试排除了若干不能提供该收缩的简化论证。

8名复用子代理分工为：3名 Astra high 证明作者、Astra high 与 Sol high 独立审计、2名 Sol high 数值/精确证书作者、1名 Sol high 文献与更新技能核验。审核员先独立检查命题和潜在反例，再阅读作者证明。主代理统一符号、审核整合、重放程序和逐轮提交。过程没有编译 PDF。

公开内容只包括已审核正向工具、匿名失败结论、明确缺口、原文适用条件及中性的可复现数值证书。用户未发表下界构造和本轮私人压力配方不进入 Git；它们的完整本地推导与独审记录保留在本轮工作目录。以下数值记录明确区分严格区间/有理证书和近似求积，均不证明一般渐近阶数。


# 第85轮主账：真实径向几何与带阈值费用的来源递归

一般目标 $C_n^\square\le\sqrt n\,n^{o(1)}$ **尚未证明**。保留的一般上界仍为 $O(n\log n)$。本轮不把条件返回、有限证书或局部接口当作目标闭合。原始文献和附件是研究资料，结论均须核验。

## 原事件、接收测度和返回式

令 $Q(x,L)=x+[-L/2,L/2]^n$，$L\in[1,2]$，$\mu=f\,dy$，$W=\|f\|_1$。接收需求始终为真实的 $\lambda\,dx$。在原保留事件上，$A_1f<\lambda/2$，$\sup_{1\le L\le2}P_{1,L}f\le\lambda/2$，存在窗口内硬平均严格超阈见证；$L_*(x)$ 是最早硬接触，$A_{L_*}f=\lambda$。最早接触与最早严格上穿不混同。

保留第82轮 $E_{\rm mid}$：$e^{-s_n}/2<P_{1,L_*}/\lambda\le1/2$；本轮不以窄核改写其定义。已付系数为

$$B_0=4+2\log2\sqrt{7n/3},\qquad B_{\rm ext}=2(1+n\log2)/\sqrt{n+2}.$$

若 $D_{\rm mid}$ 是原中间事件的一致费用，第81轮返回给出

$$C_n^\square\le C_{\rm loc}\log(n+2)(B_0+B_{\rm ext}+D_{\rm mid}).$$

若只得到每个原 $\kappa=1+\log[\lambda/(2P_{1,L_*})]$ 二进层的费用 $K_n$，则必须另付 $J_n=O(\log(n+2))$ 层数：$D_{\rm mid}\le J_nK_n$。可选第83轮注册窄核极低背景并集另收一次 $B_{\rm ext}$。本轮各方案不能将各自已付集合相加后假定覆盖同一余集。

## 覆盖路线：把尺度差转移到真实径向几何

对实际接收子集 $B$，令 $D=\lambda|B|$，$\Gamma(dx,dy)=1_B(x)L_*^{-n}1_{Q_*}(y)dx\,\mu(dy)$，列质量为 $b(y)$。第84轮已证

$$(b-1)_+^3\le12n^2b\,\operatorname{Var}(\log L_*\mid y).$$

首次接触仅控制物理尺度 $[1,L_*]$，因此本轮必须用截断径向变量

$$t=\log L_*,\quad u=\log\max\{1,2\|x-y\|_\infty\},\quad r=t-u\ge0.$$

每行后验尾概率至多 $e^{-nh}$，从而 $\int r^2d\Gamma\le2D/n^2$。在 $\Gamma/D$ 的条件 $L^2$ 投影中，令 $V_t,V_u$ 为来源条件方差的平均，则

$$|\sqrt{V_t}-\sqrt{V_u}|\le\sqrt2/n.$$

因此原高 Hall 比值若 $K_B=D/\mu(N(B))\ge2$，有 $K_B\le\sqrt{96}\,n\sqrt{V_u}+\sqrt{192}$。这是统一的几何转移不等式；没有证明 $V_u=O(1/n)$。

进一步令 $I_T=\int_{b>T}\operatorname{Var}(u\mid y)\,d\mu$。过滤后的统一估计为

$$\int(b-T)_+^2d\mu\le24n^2I_T+48D/T,\qquad T\ge2.$$

直接使用 Jensen，对于任意实际割 $K_B\ge4$ 得

$$K_B^2\le96n^2I_{K_B/2}/\mu(N(B))+384.$$

此式无需最大割达值或连续主分块存在。有限实际主分块的凸序表示另给高主块总需求估计，可吸收径向深度误差；使用该表示时仍须满足原接口的明确适用条件。低规范列来源上的宽方差不进入 $I_T$。其剩余高列来源径向预算尚未建立，单独径向边缘限制允许线性负载，不能凭此闭合目标。

## 自适应路线：局部份额与真实多步账

取 $\vartheta=\log^{-2}(n+2)$，$\alpha,\varepsilon>0$ 且 $c=1-\alpha-\varepsilon>0$。原中间事件中，选定粗噪声值 $P_{\vartheta,L_*}\ge\alpha\lambda$ 的部分支付 $T(n,\vartheta)W/\alpha$，其中

$$T=1+\log2\min\{2n,\sqrt{n(\vartheta^{-1}+4\vartheta/3)}\}.$$

余集内捕获积分停止在 $(1-\varepsilon)\lambda$，正核 $k_x$ 支持于原硬立方体，积分 $d_x>c\lambda$。令 $a_x=k_x/d_x$，$q_B(y)=\int_Bk_x(y)dx$。共同来源集 $S$ 只可在行内份额 $r_S(x)=\int_Sa_xd\mu\le\delta<1$ 的行上删除并重归一化。若 $q_B\le K$ 于 $S^c$，这些行收费

$$G_n\mu(S^c),\qquad G_n=K/[c(1-\delta)].$$

其他行对实际输入 $f1_S$ 有严格硬见证，阈值为 $\beta\lambda$，$\beta=\delta c$。它们必须重新选择硬接触并重新支付锚点、原平滑、原极低背景和粗噪声分支。后续选择器不自动属于原捕获图，所以递归证明的是接收测度费用，不是原图上的运输拼接。

设 $f_{i+1}=f_i1_{S_i}$，$W_i=\|f_i\|_1$，$\lambda_i=\beta^i\lambda_0$，$A_n=B_0+B_{\rm ext}+T/\alpha$。有限深度账为

$$\lambda_0|R_0|\le\sum_{i<m}\beta^{-i}[A_nW_i+G_n(W_i-W_{i+1})]+\beta^{-m}(1+n\log2)W_m.$$

来源壳层不交，但阈值权重会增加；异常分支会重复收费。这两项均保留。若**另行证明** $W_{i+1}\le\rho W_i$ 且 $\rho<\beta$，分部求和才给出

$$\lambda_0|R_0|\le\frac{A_n+G_n(1-\rho)}{1-\rho/\beta}W_0.$$

取 $\alpha=\varepsilon=1/[10\log(n+2)]$，粗噪声费用为 $O(\sqrt n\log^2(n+2))$，且 $c$ 接近1。几何质量收缩仍未证明；总停止质量的一阶 Markov 界在有用的支付范围内是平凡的，不能填补该缺口。远离的来源质量也不能代替行内份额控制。

## 接收包络路线的失败与替代

对于任意有限或可数的正分数接收覆盖，每块若按其真实捕获纤维取以来源为中心的对称坐标矩形，则共享包络费用至少为实际接收纤维的本质坐标阴影的硬核积分。使用正接收体积的见证定义阴影，排除了零测例外点产生虚假矩形的漏洞。

本轮独立审查的真实正 $L^1$ 家族通过原锚点、连续首次硬接触、严格后继见证、全窗口原平滑上界和原中间背景条件，却令任意上述分数覆盖支付至少 $c nW$，而真实接收需求仅为 $O(W/n)$。这排除的是该包络机制的统一费用要求；不反驳一般弱型目标、优化来源容量或只针对高总负担的路线。配方及完整检验保留本地，公开只列匿名结论和一般阴影定理。

新的非对称尺度包络保留原接收中心，仅将边长从两侧舍入；嵌套细化时，其共同来源积分递减到 $D$。它严格去除了人为填入的区域，却不提供 $D/W$ 的新上界。下一步必须估计真实耦合占用或改变来源分配。

## 证据与本轮边界

真实空间有限数值证书、近似求积、标量代数守卫及一般证明分别标注。新的有限压力构造和用户提供的未发表下界资料仅留本地；公开归档只收已审核的正工具、匿名失败结论、适用条件及可公开复现材料。没有统一几何预算之前，不登记一般 $n^{1/2+o(1)}$ 上界，不从有限维拟合猜测阶数。每个结论的最终审核状态以本轮独立审核记录和主代理实际重放回执为准。


**Status.** The general root-order cube bound remains unproved. This round proves a uniform physical coupling that is unavailable for an arbitrary abstract scale occupation measure: at an actual first contact, the clamped logarithmic receiver–source radius differs from the selected logarithmic side by an exponentially integrable depth of size $1/n$. Combining this with the retained cubic occupation inequality gives a new constraint on every high-capacity cut, involving only the radial variance at canonically high-load sources. A finite principal representation gives a corresponding distributional estimate and an absorbable error. The remaining radial-variance packing estimate is open. Neither maximal-cut saturation nor the existence of a balanced optimized allocation supplies it.

## 1. Objects, gates, and scope

Let $n\ge2$, $f\ge0$ be a nonzero $L^1(\mathbb R^n)$ input, $d\mu=fdy$, and $\lambda>0$. Let $B$ be a finite-volume measurable receiver set with measurable original earliest-contact selector $L(x)\in[1,2]$, satisfying

\[
 \mu(Q(x,L(x)))=\lambda L(x)^n,
 \qquad \mu(Q(x,s))\le\lambda s^n\quad(1\le s<L(x)).       \tag{1}
\]

Every actual retained compact cut in an original middle layer is included. The upper anchor, full-window original smooth gate, original middle floor, and original layer labels are retained, but are not needed for the positive estimates below. Thus the estimates hold on a larger class, without changing any gate in their application. No source is removed and no later-block first hit is inherited after deletion.

Write $N=N(B)$, $M=\mu(N)$, $D=\lambda|B|$, $K=D/M$, and assume $D>0$; otherwise all demand statements are trivial. We use measurable neighborhoods (for Borel data their analytic projections are measurable in the completed finite source measure). Define the single canonical measure

\[
 d\Gamma(x,y)=1_B(x)L(x)^{-n}1_{Q(x,L(x))}(y)\,dx\,d\mu(y).
\]

Its receiver marginal is $\lambda1_Bdx$, its source marginal is $b(y)d\mu(y)$, and $\int b\,d\mu=D$. For $b(y)>0$, conditional expectation $E_y$ uses the explicit probability density $L(x)^{-n}1_B1_{Q_x}/b(y)$ in $x$. All conditional variances are zero where $b=0$.

On captured pairs put

\[
 t=\log L(x),\quad u=\log\max\{1,2\|x-y\|_\infty\},
 \quad r=t-u,\qquad 0\le u\le t\le H:=\log2.             \tag{2}
\]

The clamp at $1$ is essential: (1) gives no control at sides below the physical window. An untruncated logarithmic radius can have arbitrarily large depth and is not used.

## 2. A uniform radial-depth theorem

For every receiver $x$, its normalized captured-source probability is $1_{Q_x}d\mu/(\lambda L(x)^n)$. For $0<h<t(x)$, the event $r>h$ is the interior of the concentric cube of full side $L(x)e^{-h}>1$. Since an $L^1$ source gives cube boundaries zero mass, (1) yields

\[
 \Pr_x\{r>h\}\le e^{-nh};\qquad \Pr_x\{r>h\}=0\quad(h\ge t(x)). \tag{3}
\]

Tonelli and the tail formula therefore give, for every real $p>0$,

\[
 \frac1D\int r^p\,d\Gamma\le \frac{\Gamma(p+1)}{n^p},
 \quad \frac1D\int e^{a n r}\,d\Gamma\le\frac1{1-a}
       \quad(0<a<1).                                    \tag{4}
\]

The second formula follows from $E e^{anr}=1+an\int_0^\infty e^{anh}\Pr(r>h)dh$. In particular $\int r^2d\Gamma\le2D/n^2$. These are receiverwise tail bounds and source-weighted average bounds, not uniform bounds on each conditional source law. No independent exponential random variable is asserted.

Define

\[
 V_t=D^{-1}\int b\operatorname{Var}_y(t)d\mu,
 \qquad V_u=D^{-1}\int b\operatorname{Var}_y(u)d\mu.
\]

Conditional expectation onto the source coordinate is an orthogonal projection in $L^2(\Gamma/D)$. Therefore conditional centering is a contraction; applying the reverse triangle inequality to the centered $t,u$ gives

\[
 |\sqrt{V_t}-\sqrt{V_u}|\le\sqrt2/n.                    \tag{5}
\]

For every measurable source predictor $a(y)$ with finite error,

\[
 \sqrt{V_t}\le\left(D^{-1}\int (u-a(y))^2d\Gamma\right)^{1/2}
                 +\sqrt2/n.                            \tag{6}
\]

Indeed conditional variance minimizes squared error, and $t-a=(u-a)+r$. More generally the actual joint conditional law of $t,u$ is an admissible coupling, so its conditional $p$-transport cost, averaged with $b\mu/D$, is at most $\Gamma(p+1)/n^p$ for $p\ge1$. This last statement is only the coupling inequality, with no regularity claim for either source marginal.

There is also a pointwise physical occupation restriction. Let $\zeta_y$ be the unnormalized pushforward of $L^{-n}1_B1_{Q_x}dx$ under $u$. Then

\[
 \zeta_y(\{0\})\le1,\qquad \zeta_y|_{(0,H]}\le n\,du.  \tag{7}
\]

For $u>0$, capture implies $L^{-n}\le(2\|x-y\|_\infty)^{-n}$. The volume of the cube of full side $e^s$ is $e^{ns}$, so radial integration gives the density bound $e^{-ns}ne^{ns}=n$. At $u=0$ the receiver set lies in a unit cube and $L^{-n}\le1$. This uses actual Lebesgue receiver geometry; an arbitrary abstract scale measure need not obey (7).

## 3. Filtered variance and a high-capacity cut constraint

Retain the previously proved sourcewise first-contact occupation bound

\[
 (b-1)_+^3\le12n^2b\operatorname{Var}_y(t).             \tag{8}
\]

For $T\ge2$, define the unweighted **high-load radial variance budget**

\[
 I_T=\int_{\{b>T\}}\operatorname{Var}_y(u)\,d\mu.       \tag{9}
\]

The qualifier “unweighted” distinguishes (9) from $V_u$; it is not a uniform per-source bound. Sources with small canonical load contribute nothing to (9), however broad their scale distributions are.

**Filtered hinge estimate.** For every such actual cut,

\[
 \int(b-T)_+^2d\mu\le24n^2 I_T+48D/T.                 \tag{10}
\]

For $b>T\ge2$,

\[
 (b-T)^2\le(b-2)^2\le(b-1)^3/b
                  \le12n^2\operatorname{Var}_y(t).
\]

The middle inequality has difference $b-1-1/b>0$. Also

\[
 \operatorname{Var}_y(t)\le2\operatorname{Var}_y(u)+2E_y(r^2).
\]

On $b>T$, integration of the last term costs at most

\[
 \int_{b>T}E_y(r^2)d\mu
 \le T^{-1}\int r^2d\Gamma\le2D/(Tn^2).
\]

This proves (10) with the displayed constants. All original captured mass remains in the calculation, including sources used by other blocks.

Taking Jensen against the constant mean $K=D/M$ on $N$ gives

\[
 (K-T)_+^2 M\le24n^2 I_T+48D/T.                       \tag{11}
\]

In particular, for every actual cut with $K\ge4$, choose $T=K/2$:

\[
 \boxed{K^2\le96n^2\,I_{K/2}/M+384.}                 \tag{12}
\]

For $K\ge\sqrt{768}$, necessarily

\[
 \int_{b>K/2}\operatorname{Var}_y(u)d\mu
       \ge K^2 M/(192n^2).                             \tag{13}
\]

This is a genuine constraint on high-capacity cuts, valid for arbitrary receiver subsets and without an attained Hall supremum. It says that high capacity requires physical radial dispersion on sources which also carry high canonical load. A low-load broad-scale example cannot violate this necessary condition. Equation (12) does not itself upper-bound $K$: a uniform upper estimate for its filtered radial budget is not proved.

## 4. What principal blocks add, and what they do not

Suppose an actual finite principal representation has a density field $k(y)\ge0$, with $\int k\,d\mu=D$, for which the retained convex-order theorem applies:

\[
 \int\Phi(k)d\mu\le\int\Phi(b)d\mu
\]

for the relevant convex functions. This explicitly requires the same physical source measure and the canonical captured plan as a feasible comparison plan. A finite graph alone does not prove existence of a continuum principal representation. On such a representation (10) gives

\[
 \int(k-T)_+^2d\mu\le24n^2 I_T+48D/T.                 \tag{14}
\]

For $k\ge2T$, $k\le2(k-T)^2/T$; hence the demand of the high-density principal blocks satisfies

\[
 D_{\{k\ge2T\}}\le48n^2I_T/T+96D/T^2.               \tag{15}
\]

The other principal blocks cost at most $2TW$, where $W=\mu(\mathbb R^n)$. If $T>\sqrt{96}$,

\[
 D\le\frac{2TW+(48n^2/T)I_T}{1-96/T^2}.              \tag{16}
\]

Thus the radial-depth remainder has a real paid contraction, without dividing by gaps between principal densities or deleting earlier sources. The principal conclusion is a distributional constraint on all high blocks, not merely their maximum. Choosing $T\asymp\sqrt n$ would give a root-order payment if the independent physical estimate $I_T\lesssim W/n$ held. That estimate remains open. The variance on canonically high-load sources cannot be inferred from the flat load of the *optimized* principal allocation: those are different source laws.

## 5. Stability on arbitrary near-extremal receiver cuts

This lemma makes precise what maximal-cut information does control. Fix a parent actual cut $B$, and let $A\subset B$ be any measurable receiver subset with measurable $N_A$. Write $\beta_{A,y}\le\beta_{B,y}$ for their unnormalized conditional scale measures and

\[
 E_y(A)=\inf_{a\in[0,H]}\int(t-a)^2d\beta_{A,y}(t)
       =b_A(y)\operatorname{Var}_{A,y}(t).
\]

The equality uses a conditional mean if $b_A>0$, and zero otherwise. Then

\[
 0\le E_y(B)-E_y(A)\le H^2(b_B-b_A).                  \tag{17}
\]

Monotonicity follows by taking an infimum after adding a nonnegative integral. To prove the upper bound, test $E_y(B)$ at the mean of $\beta_A$, which lies in $[0,H]$; when $b_A=0$, use any point in that interval.

Let $k$ be any finite upper bound for the Hall ratios of subsets of $B$. Put $\epsilon_A=k\mu(N_A)-\lambda|A|\ge0$. Exact canonical marginal accounting gives the complementary-row leakage

\[
 R_A:=\int_{N_A}(b_B-b_A)d\mu
     =\epsilon_A+\int_{N_A}(b_B-k)d\mu.               \tag{18}
\]

Consequently

\[
 \int_{N_A}E_y(A)d\mu\ge\int_{N_A}E_y(B)d\mu
 -H^2\left[\epsilon_A+\int_{N_A}(b_B-k)_+d\mu\right]. \tag{19}
\]

The sign in the last positive part is essential. In the special case $b_B=k$ almost everywhere, near-tight cuts lose at most $H^2\epsilon_A$ of source variance energy on their neighborhood. No maximizing subset or finite union of receiver cells is assumed. The conclusion concerns variance *energy*, not automatically the normalized variance after changing denominators. Flatness of an optimized principal load is not flatness of $b_B$.

Thus near-maximality can preserve canonical dispersion; it does not automatically remove it. The proposed shortcut “pass to a worst cut, then assume small scale variance” remains unsupported. This stability statement is a directly proved inequality, not an invocation of a generic near-extremizer theorem.

## 6. Verification, quantifiers, and the unresolved geometric step

The retained E03 and G01 interfaces require a real common source budget before tree or packing language is used. B01 is used only through the already justified finite convex-order representation; it does not supply a continuum partition. The stability estimate is derived directly within the M03 scope. No generic extremizer theorem, infinite strong duality, or automatic packing is invoked.

All three statements were sent to both independent auditors before author proofs. Both blind prechecks and subsequent full proof reads passed the radial tail/coupling, hinge/principal constants, arbitrary-subset energy/slack formula, and stated scope. Static MD/TeX consistency passed; no compilation was performed. The independently owned public audit guard actually passed the coverage checks twice: 27 truncated-tail models, 342 tail comparisons, 144 conditional-projection checks, 189 hinge checks, 9 energy checks, and 27 relaxation/clamp pressure checks. It uses exact Fraction arithmetic and 80-bit outward exponential enclosures. These are scalar verification records, not actual receiver-volume or gate certificates. Actual-input scans are separately owned and reported by the Hall numeric role; their midpoint conditional moments remain diagnostics.

The public scalar guard also includes a generic **nonphysical** relaxation, unrelated to any supplied lower construction. Set $h_0=1/2$, take one abstract source of mass one, and let $\beta=\zeta=\delta_0+n1_{[0,h_0]}du$, with $t=u$ and $r=0$. Then $b=1+nh_0$ and

\[
 \sigma^2=\frac{nh_0^3(nh_0+4)}{12(1+nh_0)^2},\qquad
 \frac{12n^2b\sigma^2}{(b-1)^3}=1+\frac3{1+nh_0}\ge1.
\]

The interval and radial-density constraints, every age moment, and the cubic inequality all hold, yet the load is linear. This proves only a limitation of the listed necessary marginal constraints. There is no physical $L^1$ input, row-contact realization, actual receiver set, or gate certificate here. It cannot refute the cube bound, MD-high, or a packing statement on actual cuts. Both independent auditors checked this scalar consistency test.

The guard uses three dimension ranges: pilot $n=2,3,4$; pressure $n=8,16,32$; and enlarged $n=64,256,4096$, with three truncation times per dimension. Its synthetic broad-scale relaxation and unclamped exclusion test check the domains of the claims. These passed calculations verify formulas and boundaries, not a high-dimensional cube bound. Actual geometric scans remain the Hall numeric owner's responsibility.

No new dimensional or layer fee is hidden in (3)–(19). They apply within each original layer and also to a union of original retained rows. Summing independently proved layer capacity estimates would still cost $J_n$; a full-event estimate avoids that repetition. The original anchor, smooth-exterior, and localization costs remain exactly those of the R85 contract. Source restriction or threshold change would require reselection and reclassification, but neither is used in these positive results.

The next geometric task is to control (9) on high-capacity cuts or on their actual high-density principal blocks, using common source mass and genuine captured receiver geometry. An independently checked abstract relaxation satisfies the interval, radial-density, all depth-moment, and cubic constraints while retaining a linear-in-dimension load. It is not an actual input or a gated counterexample. Thus pointwise radial occupation (7) and the depth coupling (4) alone do not force a root-order bound. They do not prove the needed packing. Any further annular or directional argument must allow shared-source reallocation and must pay all rows and sources; a common source with large canonical load is not by itself an obstruction to optimized capacity.

## 1. Objects, branch parameters, and proven baseline

Let f>=0 be in L1(R^n), mu=f dy, W=||f||1 and lambda>0. All sides are full sides, 1<=L<=2. Use the original Eret, R82 Emid, original earliest hard contact L*(x), A_L*f=lambda, and actual receiver measure lambda dx. The original anchor and full-window smooth gate, original R82 extreme deletion, and strict hard witnesses are retained. Let

    w(u)=integral_0^1 exp(-|u|/t)dt,
    phi_eta=1_[-1/2,1/2]*[eta^-1 w(./eta)],
    Phi_eta=phi_eta^tensor n,
    P_eta,L=f*(Phi_eta)_L.

The available fixed-window hard bound is

    H_n=1+n log2,
    lambda |{sup_[1,2]A_Lf>lambda}|<=H_n W.               (1)

Indeed the sourcewise supremum of L^-n 1_Q(0,L) equals 1 on the unit cube, equals (2||z||infinity)^-n on the annulus of full radii 1 to 2, and vanishes outside the side-2 cube. Its integral is exactly 1+n log2. This finite, input-uniform bound will pay every terminal remainder. It is not a new root-order bound.

For theta in (0,1], write

    U(n,theta)=min(2n,sqrt(n(theta^-1+4theta/3))),
    T(n,theta)=1+(log2)U(n,theta).

The retained physical derivative upper estimate gives integral sup_[1,2]P_theta,L<=T(n,theta)W. Its upper-bound scope is all theta in (0,1]; no use is made of the more restricted two-sided narrow-width comparison.

## 2. Replication theorem: an absolute global source-tail condition is not a weaker uniform hypothesis

Fix n, theta, positive branch parameters, and a finite K>=0. Consider compactly supported inputs and compact actual receiver sets B in the relevant middle/coarse-low class, with uniform strict upper margins for the full original smooth gate and the selected coarse-noise gate. If membership in one particular kappa layer is required, assume a uniform margin to its relevant endpoints as well. The original hard contact and strict witness qualifications are retained. Let the prescribed allocation be obtained from captured-only stopping, so its kernels depend on f only inside the actual selected cube. In particular write q_B(y)=integral_B k_x(y)dx.

**Replication theorem.** For every positive integer N there is a translated N-copy input and receiver union, at the same lambda, on which the hard histories, original hard selectors, captured noise paths and stopped kernels on each copy are exactly those of the seed. On the source support of each copy, q is the translated original q. Consequently

    mu_N({q_(B_N)>K})=N mu({q_B>K}),
    W_N=NW,
    local r_S and the ratio mu({q>K})/W are unchanged.     (2)

The full smooth averages, unlike captured paths, are perturbed by positive remote tails. Sufficient separation preserves all stipulated strict gates and layer margins.

**Proof.** Translate the compact source support and B together along the first coordinate, with spacing R. Choose R so a selected cube of side at most 2 meets only its own source copy. Then every original hard average for L in [1,2], and every captured noise integral at the resulting selector, is unchanged exactly. This includes every stopping width and each k_x restricted to any physical source copy. Cross-copy k_x vanishes by its capture indicator.

For the noncompact smooth kernels, if |u|>=1/2 then phi_eta(u)<=exp[-(|u|-1/2)/eta]/2. For eta in {1,theta}, this is bounded by the eta=1 tail. Compactness gives a finite D0 with every cross-copy source/receiver first-coordinate distance at least R-D0. Uniformly in L in [1,2], the sum of remote convolutions is therefore at most

    ((N-1)W/2) exp(1/2-(R-D0)/2).

For each fixed finite N this tends to zero as R tends to infinity. Choose it smaller than the strict original and coarse margins. A fixed kappa-layer margin is preserved by also making this perturbation sufficiently small relative to the positive selected original background on compact B. The original middle lower bound is only helped by positive remote background. Thus B_N is qualified, while the exact hard/captured identities imply (2). The number of source labels is irrelevant: these are physically separated copies of one common measure, not independent private capacities.

**Consequence.** On any such replication-stable class, a universal assertion

    mu({q_B>K})<=C lambda                               (3)

with a fixed finite C independent of support size, input mass and copy count forces mu({q_B>K})=0 for every member of the class. Otherwise (2) violates (3) for large finite N. Conversely a uniform essential bound q_B<=K implies (3) trivially. Therefore the proposed absolute threshold delta lambda/4, when required uniformly over this class, is not a genuinely weaker substitute for the essential column bound.

This theorem does **not** prove that a target K=C sqrt(n)polylog(n) is false. It proves an equivalence of universal hypotheses on the stated strict compact class. No passage through closed zero-margin gates is claimed. For a single input an absolute light-source condition can still be useful; the distinction is between a data-dependent certificate and a uniform theorem. Scaling f and lambda by the same positive factor leaves q, local removed fractions, and normalized columns unchanged, and scales both sides of (3) equally. Thus amplitude scaling is harmless; spatial replication is the relevant obstruction.

### Remote-source invariance and the limit of one-step mass-ratio evidence

In the same strict compact class, add a compact source of any prescribed finite mass M at sufficiently large distance. It is outside every original window cube of B. Therefore every hard history and captured stop on B is unchanged, and q_B vanishes on the added source. The old q_B, any old high-load set S, and every receiver-local fraction r_S are unchanged exactly. The same exponential tail estimate, with M in place of the remote-copy mass, preserves the full smooth and coarse gates. Consequently

    mu_new(S)/(W+M) ->0 as M->infinity,

while the fraction of bad receivers is unchanged. This does not invalidate a valid weak-fee estimate involving W+M: the right side becomes larger and the receiver burden D/(W+M) decreases. It proves that a global source-mass fraction alone does not describe receiver progress or justify the next iteration's contraction.

For an exact logical example, choose S to be the whole original source support. Every original row has r_S=1 and remains bad for delta<1. Adding a remote source makes the first retained-source ratio W/(W+M) arbitrarily small. After restriction the remote source disappears; repeating S then has retained-source ratio one. Thus a single verified contraction cannot be extrapolated to all future steps. This statement concerns an arbitrary common S, not a claim that S equals a prescribed positive-K superlevel. For genuine superlevels the invariance statement above still holds, but any positive bad-row fraction must be separately verified.

This is an anonymous structural qualification, not a weak-type lower construction. High-burden hypotheses must retain their actual D/W test; remote added mass cannot be used to refute them. When evaluating intrinsic local source geometry one should also record mu(N(B)), since the added source lies outside the actual capture neighborhood.

## 3. Tunable local transfer, with a near-unit threshold factor

Fix alpha>0 and epsilon>0 with alpha+epsilon<1, and put

    c=1-alpha-epsilon>0.

Within the original Emid delete the coarse-high branch

    H_alpha={P_theta,L*>=alpha lambda}.

It costs at most T(n,theta)W/alpha. For the remaining receivers F_alpha, define

    C_x(eta)=integral_Q(x,L*) (Phi_eta)_L*(x-y)dmu(y).

On the hard cube, eta partial_eta phi_eta(z)=-u w(u)-v w(v)<=0, where u=(1/2-z)/eta and v=(1/2+z)/eta. Hence C_x increases continuously as eta decreases, starts below alpha lambda, and tends to lambda because f dy charges no cube boundary. Stop at the first value

    C_x(eta_x)=(1-epsilon)lambda.

For measurability, choose a Borel representative of f and the original Borel selector. The displayed captured integral is jointly Borel in (x,eta)>0 by measurability of its nonnegative integrand; for each x it is continuous in eta by dominated convergence on compact positive-width intervals. Put u_x(t)=C_x(theta exp(-t)) and h=(1-epsilon)lambda. The finite first time tau(x)=inf{t>=0:u_x(t)>=h} satisfies {tau>t}={u_x(t)<h} for every t>=0, so tau and eta_x=theta exp(-tau) are Borel. This argument does not require differentiability or continuity of L*(x).

The measurable, positive, capture-supported difference is

    k_x(y)=1_Q(x,L*)(y)[(Phi_eta_x)_L*(x-y)-(Phi_theta)_L*(x-y)],
    d_x=integral k_x dmu=(1-epsilon)lambda-C_x(theta),
    c lambda<d_x<=(1-epsilon)lambda,
    a_x=k_x/d_x,  integral a_xdmu=1.                    (4)

For B subset F_alpha let q_B=integral_B k_xdx and ell_B=lambda integral_B a_xdx. Then

    q_B/(1-epsilon)<=ell_B<=q_B/c,
    c lambda|B|<=integral q_Bdmu<=(1-epsilon)lambda|B|.   (5)

The lower integral inequality is strict when |B|>0; the upper column inequality is strict where q_B>0. All inequalities use the same original capture relation and common source. No source-coordinate independence or stochastic stopping theorem is invoked.

Choose any measurable common source set S and 0<delta<1. Let

    r_S(x)=integral_S a_x dmu,
    G={x in B:r_S(x)<=delta},  R=B\G.

On G erase S from the allocation and renormalize by 1/(1-r_S). If q_B<=K mu-almost everywhere on S^c, the resulting common columns are supported on S^c and bounded by K/[c(1-delta)]. Therefore

    lambda|G| <= [K/(c(1-delta))] mu(S^c).              (6)

This is genuinely receiver-local: it does not require S to have small global mass. The original input is unchanged on this paid branch, so its original gates and selector remain unchanged.

On each bad receiver x in R,

    integral_S k_x dmu>delta d_x>delta c lambda.

Since k_x<=L*^-n 1_Q*, the actual restricted input g=f1_S satisfies the strict witness

    A_L*(x)g(x)>delta c lambda.                         (7)

Set beta=delta c. These receivers belong to the full window maximal event for g at beta lambda. The first selector and **all** anchor, original smooth, R82 background, coarse-noise and optional registered-width labels must be recomputed at this new threshold. Neither original middle membership nor original capture support is inherited. In particular a recursive weak-fee proof is valid, but combining later transport rows would not automatically yield a transport on the original capture graph.

The classical alpha=1/2, epsilon=1/4 choice has c=1/4. One may instead choose, for n>=2,

    theta=log^-2(n+2),
    alpha=epsilon=1/[10 log(n+2)],
    c=1-1/[5 log(n+2)]>0.85.                            (8)

Then the extra coarse fee is O(sqrt(n)log^2(n+2))W, while the strict transfer threshold in (7) is beta lambda=delta c lambda, close to delta lambda. The coefficient 1/4 is therefore avoidable at only an additional logarithmic cost. This is an improved transfer constant, not a dimension-order gain.

## 4. Exact finite-depth ledger with common source shells and a paid terminal remainder

This theorem makes no assumption that the geometric contraction needed below actually holds. Its finite-depth version is an a posteriori certificate for any specified sequence.

Start with R_0 subset {M_[1,2]f_0>lambda_0}, W_0=||f_0||1. At stage i use the **current** input f_i and threshold lambda_i, and decompose current receivers R_i by the original R81/R82 reductions and the coarse threshold alpha. These paid exceptions have current fee at most

    A_n W_i,
    A_n=B0(n)+Bext(n)+T(n,theta)/alpha.                  (9)

If the separate R83 union is used at a stage, add another Bext(n) there; it is not hidden in A_n. Let B_i be the current receivers remaining in F_alpha. Compute their current stopped q_i, set S_i={q_i>K}, and split good/bad rows by r_(S_i)<=delta or >delta. Use (6) on good rows, and set

    f_(i+1)=f_i1_(S_i),
    W_(i+1)=mu_i(S_i),
    lambda_(i+1)=beta lambda_i,
    R_(i+1)=the current bad rows,
    G_n=K/[c(1-delta)],  beta=delta c.                   (10)

By (7), the next current set has the required strict full-window witness. Every original receiver is either paid once as an exception/good row or belongs to the next residual. Source supports are nested; good rows at stage i use only the shell removed at that stage.

For every finite depth m,

    lambda_0|R_0|
    <= sum_(i=0)^(m-1) beta^-i
          [A_n W_i+G_n(W_i-W_(i+1))]
       +beta^-m H_n W_m.                               (11)

**Proof.** At stage i the current threshold times the current exception measure is bounded by A_n W_i. The good rows use only S_i^c and hence cost G_n(W_i-W_(i+1)), not G_n W_i. Multiply these bounds by lambda_0/lambda_i=beta^-i, and sum the disjoint receiver pieces. The residual is contained in the full-window event of f_m at lambda_m, so (1) pays it by beta^-m H_n W_m. This proves (11), with no infinite stopping or unproved convergence assertion.

The shells themselves are disjoint in the original source space, but their fees have factors beta^-i. The exception fees are charged to nested W_i and do repeat source mass. Neither feature is omitted.

**Conditional contraction corollary.** If the actual sequence satisfies an independently justified uniform bound

    W_(i+1)<=rho W_i,  0<=rho<beta,                     (12)

then the terminal term is at most H_n(rho/beta)^m W_0 and tends to zero. The complete infinite ledger is

    lambda_0|R_0|
       <= [A_n+G_n(1-rho)]/[1-rho/beta] W_0.             (13)

The source-shell factor is obtained by summation by parts, not by a false termwise upper bound on shell mass:

    sum_(i=0)^(m-1) beta^-i(W_i-W_(i+1))
     =W_0+sum_(i=1)^(m-1)(beta^-i-beta^(-(i-1)))W_i
       -beta^(-(m-1))W_m.

Since the middle coefficients are nonnegative and W_i<=rho^i W_0, its infinite limit is at most (1-rho)/(1-rho/beta) W_0. In fact W_(i+1)<=rho W_i gives a lower, not an upper, bound on each shell relative to W_i; the displayed summation is essential.

The independently missing input is (12), or another explicit summable bound on beta^-i W_i. It is not supplied by local normalization. A uniform ratio rho/beta bounded away from one and a target K=O(sqrt(n)polylog(n)) would give the desired window order, and R81 would add its stated O(log(n+2)) factor. Near-unit transfer replaces the former contraction requirement rho<delta/4 by rho<delta c. No such dimension-uniform source contraction has been proved.

With varying parameters, replace beta^-i by t_i=lambda_0/lambda_i=product_(j<i)(delta_j c_j)^-1, and use A_i,G_i in (11). Termination requires a stated bound on t_m W_m. No bound independent of iteration count follows merely by naming the construction a stopping tree.

## 5. Why the total stopped-mass estimate cannot prove the required contraction

Let D=lambda|B| and R=D/W for a nonempty current B. The usual Markov estimate for S={q_B>K} is

    mu(S)<=K^-1 integral q_Bdmu
             <=(1-epsilon)D/K.                         (14)

Its right side depends on the unpaid receiver demand, not just on source mass. There is a sharper diagnostic of this limitation. Suppose K is chosen so the uniform good-row payment would be genuinely smaller than D:

    [K/(c(1-delta))]W<D.

Then K<c(1-delta)R. Even using the **exact** total stopped mass, (5) gives

    [integral q_Bdmu]/(KW)>cR/K>1/(1-delta)>1.          (15)

Thus the tail upper bound obtained from that first moment is already larger than W. It cannot certify even a nontrivial source-mass drop in this useful-payment regime, much less (12). This statement concerns what the first-moment argument proves; it does not assert that the actual tail mass is large. Actual geometry may make the tail much smaller.

Equivalently, inserting (14) into the bad-row payment based on the existing full-window coefficient generates a coefficient of order H_n/(beta K) multiplying D. Absorption then requires K comparable to the already linear H_n. Near-unit transfer improves constants but does not remove this dimension obstruction. A higher-moment, source-local, extremal-cut or other geometric estimate must enter before (13) can yield a new order.

The retained R84 canonical variance inequality provides a precise possible connection, not a new bound: q_B<=b_B, and for K>1,

    {q_B>K} subset {sigma_y^2>(K-1)^3/(12 n^2 K)}.       (16)

Indeed (b-1)^3/b is increasing for b>1, and (b-1)_+^3<=12n^2 b sigma^2. At K of order sqrt(n), the right-hand variance threshold is of order 1/n. A suitable high-burden mass-drop statement could therefore feed (12), but the requisite general statement remains unproved. The previously excluded unrestricted all-cut mass-drop condition must not be substituted for it.

## 6. General passage, evidence and remaining task

The positive stopped identities and local split apply directly to L1 inputs: cube boundaries are mu-null, captured kernels are bounded and positive, and Tonelli or continuous-path endpoint identities justify exchanges. Compact regular classes are used for the replication theorem and the retained Hall framework only. Each recursive input has fresh thresholds and branch labels. Optional original kappa layers require their own explicit source-overlap and layer budget; layerwise source sets are not disjoint merely because receiver layers are disjoint. The primary ledger (11) uses the whole current retained receiver subset and therefore introduces no hidden kappa sum.

The updated A02, B02 and G01 skills and the R84 contract/ledger were read. Their conditions are retained: no finite sample certifies a full source-tail estimate, and no tree or Carleson packing is inferred from a formal recursion. No external source theorem is needed for the self-contained statements above.

Both auditors independently prechecked replication, the tunable transfer, and the finite-depth ledger, then passed full mathematical and Markdown/TeX consistency reads. Thirty-six exact rational finite-ledger checks also verified the shell summation identity, its conditional infinite upper bound and the terminal bound for nongeometric nested mass sequences. Static source checks passed; no compilation was performed.

The separately owned three-stage pressure includes an exact, originally gated finite-dimensional example for the older stopping parameters in which a genuine stopped-load superlevel leaves every receiver row locally bad. Remote source mass can make its global tail fraction arbitrarily small without changing those rows. After source restriction and threshold reduction, the old receivers can fail the new original gates, confirming that every recursive stage needs fresh classification. These assertions have an independent exact arithmetic replay; the source recipes and private pressure parameters are excluded from this public extraction. The stronger tunable coarse branch used above deletes this entire example. Thus the finite pressure gives no obstruction on that new residual, no lower bound at square-root load, and no conclusion against optimized Hall allocation. It does not establish (12) or any asymptotic exponent.

**Next required gain.** A genuinely geometric estimate for receiver-local high-load source mass or weighted nested source occupation is still required. The absolute global-tail relaxation is not a viable distinct uniform hypothesis, and the first stopped moment cannot supply the missing contraction. The correct remaining budgets are explicit in (11)--(13); the general centered-cube target remains unproved.

## Status and change of route

The general root-n polylog weak bound is **not proved**. This round proves an obstruction to the proposed fractional receiver-patch mechanism, rather than ending with the R84 conditional n/k branch. Even when each patch uses the **actual captured source fibre**, its smallest source-centered symmetric rectangle fills in extra receiver points. Every fractional cover inherits the hard-kernel cost of a common coordinatewise shadow. An internally verified, fully gated L1 family forces the integrated sum of these envelope costs to be at least c n W, although its actual receiver demand is only O(W/n). Thus arbitrary fractional patch selection cannot make this particular envelope scheme a uniform root-order budget. This does not contradict the maximal target, a high-Hall-only theorem, or optimized source redistribution.

We then switch to asymmetric local-scale enclosures. They remove the artificial shadow and approximate the exact actual source occupation without excess. Their optimal integrated cost equals the original receiver demand, so localization alone supplies no numerical upper bound. The next action is to estimate the actual coupled occupation or redistribute source mass, not to continue optimizing source-centered rectangle patches.

## 1. Exact patch model and the retained hard kernel

Let f>=0 be L1, mu=f dy, W=mu(R^n), and let B be a compact regular subset of the original retained middle event. Its original selector L(x) in [1,2] is continuous and obeys mu(Q(x,L(x)))=lambda L(x)^n. All scales are full sides; demand is lambda dx.

Define the common hard source kernel

    H_y(z)=sup_{1<=L<=2} L^(-n)1_{Q(y,L)}(z).

It is one on Q(y,1), equals (2|z-y|_infty)^(-n) between sides one and two, and is zero outside Q(y,2). For a measurable patch P subset B define the actual captured fibre and its canonical column

    F_P(y)={x in P:y in Q(x,L(x))},
    b_P(y)=integral_P L(x)^(-n)1_{Q(x,L(x))}(y)dx.

Take essential coordinate radii

    R_i^P(y)=ess sup_{x in F_P(y)} |x_i-y_i|,
    D_P(y)=product_i[y_i-R_i^P(y),y_i+R_i^P(y)],
    C_P(y)=integral_{D_P(y)} H_y(z)dz.                     (1)

A fibre of zero receiver measure has C_P=0. Essential radii are measurable: their superlevel sets are detected by positive integrals of the jointly measurable captured-fibre indicator. Formula (1) is exactly the R84 rectangle-envelope price, now applied to the true captured fibre. It dominates b_P. The discussion also covers any larger price C'_P>=C_P.

A fractional receiver cover is a finite or countable family P_j subset B with constants alpha_j>=0 satisfying

    sum_j alpha_j 1_{P_j}(x)>=1 for dx-a.e. x in B.        (2)

The family may depend on f, B, lambda, and the selector. Patches may overlap, be disconnected, have arbitrary shapes and arbitrary scale ranges. There is no fixed bound on their number. They all charge the same source measure. The proposed shared integrated fee is

    Fee=sum_j alpha_j integral C_{P_j}(y)mu(dy).          (3)

An uncountable measured family needs additional joint-measurability and Fubini assumptions and is not silently included.

## 2. Two unavoidable lower bounds

First, every positive receiver-only cover inherits the original canonical column:

    sum_j alpha_j b_{P_j}(y)>=b_B(y)                      (4)

for every source for which the displayed integrals are defined. This is just Tonelli applied to (2), and has no loss depending on labels, dimension, or depth. Thus pointwise domination by patch envelopes cannot lower the canonical source load. This fact alone does not refute an integrated budget.

There is a stronger geometric obstruction. Define the **essential coordinatewise shadow**

    S_B(y)={z: |{x in F_B(y):
                    |x_i-y_i|>|z_i-y_i| for every i}|>0}.

The inner absolute bars denote actual receiver Lebesgue volume. Strict inequalities and positive witness volume eliminate dependence on null fibres and boundary representatives. The set is jointly measurable, since it is the positivity set of a measurable nonnegative integral. It is contained in Q(y,2).

**Shadow theorem.** Every countable fractional cover (2) satisfies

    sum_j alpha_j 1_{D_{P_j}(y)}(z)>=1_{S_B(y)}(z),
    sum_j alpha_j C_{P_j}(y)>=J_B(y),
    Fee>=integral J_B(y)mu(dy),                           (5)

where

    J_B(y)=integral_{S_B(y)} H_y(z)dz.

These inequalities hold sourcewise, with the harmless source-null qualifications needed for density representatives.

**Proof.** Fix y and discard the receiver-null cover exception, together with the countable union of fibre-null exceptions where a coordinate exceeds its patch essential radius. If z belongs to S_B(y), its positive-volume witness set still contains an x outside all these exceptions. Every patch containing that x has z in its source-centered rectangle, because all coordinate distances of z are strictly smaller. Hence the sum of rectangle weights at z is at least the covering sum at x, which is at least one. Integrate first against H_y(z)dz and then against the one common mu. This proves (5). No coordinate independence of arbitrary f, tree packing, or private source capacity is used.

The theorem precisely identifies the loss: filling coordinates inward toward y remains mandatory even if patches are chosen optimally and fractionally. Refining a patch cannot remove this common shadow lower bound.

## 3. Qualified failure of the summed rectangle mechanism

An internal analytic construction, independent scalar certificates, and exact-margin replay establish the following anonymous statement.

**Failure theorem.** There is an absolute c>0 and arbitrarily large dimensions for which a nonnegative L1 input, threshold, and positive-volume compact regular receiver set B satisfy all the original conditions: the unit anchor, actual continuous earliest hard contact, a strict later witness, the entire-window original E2 upper gate, and the original R82 middle cutoff. Nevertheless

    integral J_B(y)mu(dy)>=c n W.                         (6)

The same examples have lambda|B|<=C W/n. Consequently every countable fractional cover by the true-fibre symmetric rectangle prices (1) obeys Fee>=c n W. In particular no fixed root-n polylog shared fee can hold for every admissible B within this mechanism.

This is an overcharge obstruction for a prescribed positive envelope scheme. It does not give a large weak maximal constant, does not refute optimized common transport, and does not refute a theorem restricted to already-high-burden cuts. It also does not rule out a proof that deletes these examples by a separately paid branch and supplies a new high-burden geometric estimate. The full target remains unchanged.

The private input recipe, parameter values, sampled kernel arguments, and certificate details are deliberately excluded from this public region. The proof below the publication boundary is available only for internal audit.

## 4. A genuinely different localization: asymmetric local-scale enclosures

The preceding obstruction is caused by symmetric coordinate filling. It disappears if an enclosure keeps the actual receiver patch and only rounds its scale.

For a nested finite partition of [1,2] into intervals of mesh tending to zero, assign each x in B its scale cell [l_m(x),u_m(x)] containing L(x). Resolve grid endpoints consistently so l_m increases to L and u_m decreases to L. Define the one common source envelope

    E_m(y)=integral_B l_m(x)^(-n)
                       1_{Q(x,u_m(x))}(y)dx.             (7)

The integral is the sum over its scale patches. It is an asymmetric enclosure centered at the actual receiver x; it does not insert a source-centered coordinate hull. Every row retains its original center and source measure.

**Sharp localization theorem.**

    E_m(y)>=b_B(y),
    E_m(y) decreases to b_B(y),
    integral E_m(y)mu(dy) decreases to lambda|B|.          (8)

For each fixed pair (x,y), the positive integrand in (7) decreases to L(x)^(-n)1_{Q(x,L(x))}(y); even boundary points have the correct closed-cube limit. It is dominated by 1_B(x), and |B|W is finite. Tonelli and dominated convergence prove (8). No uniform convergence rate is claimed for all L1 inputs. Spatial subpartitions can be inserted without changing the common sum, provided they are partitions of the actual receiver set rather than enlargements into new source-centered rectangles.

Thus the infimum of the integrated local-scale enclosure costs is exactly lambda|B|. This repairs the excess introduced by the symmetric envelope, but is not a numerical weak-type estimate: a bound on the infimum is the original budget problem. Its useful role is to preserve exact capture while passing to finite scale certificates. Any next dimension gain must use actual input coupling, such as a proved occupation inequality, or change the source allocation. It cannot be credited to the enclosure identity itself.

## 5. Coverage, dependence, skills, and verification scope

The shadow theorem covers arbitrary countable fractional receiver covers, including ones depending on the full input. There are no omitted receiver branches in its negative conclusion. The internal failure input passes the actual original gates, but has low total burden; this distinction is retained in every conclusion. The asymmetric theorem covers every compact regular original receiver set and passes to established regular exhaustions with the displayed common integral; it does not supply an input-independent convergence rate or root-order bound.

Read the updated A02 outer-relaxation and G01 Carleson/packing skills and their cube interfaces. A02 requires a proved positive domination before upper-budget transfer; here it also exposes the unavoidable extra points in the domination. G01 supplies no generic common-source packing for these nonnested receiver rectangles. No external covering theorem is invoked without its dimension/mesh cost. The R84 E/J/I/K process results are retained only as earlier context; no new free stochastic independence or stopping estimate is used here.

The precise candidate and its scope were sent to both independent auditors before author proofs. The general shadow lemma passed their blind checks. The private construction is verified by scalar interval certificates, dimension-uniform analytic first-contact brackets, a continuous smooth-gate proof, and exact middle-cutoff comparison. Independent replay refined a coarse scalar stage that was inconclusive; the two finer stages certified every requested threshold. Dimension checks verify the stated analytic margins and are not numerical hard-root scans. The dimension-uniform obstruction follows from the analytic family and its inequalities, not fitted numerical exponents.

Both independent auditors passed the full mathematical argument and independently replayed the scalar certificates and rational margins. The TeX companion passed static consistency review. No Git action, compilation, source-private replication, or public release of private lower recipes was performed.

## 1. Weighted finite covering: what the original proof actually buys

Chvátal, *A Greedy Heuristic for the Set-Covering Problem* (1979), pp.233–235, unnumbered Theorem and proof equation (1): finite sets P_j covering a finite set I, costs c_j>0, and binary incidence matrix A. For **every** u≥0 with Au≥1, weighted greedy has cost

    cost(greedy) ≤ Σ_j H(|P_j|) c_j u_j ≤ H(d) Σ_j c_j u_j,
    d=max_j |P_j|, H(d)=Σ_{k=1}^d 1/k.

The proof prices each newly covered element and verifies each column inequality; it does not need a strong-duality theorem. This is stronger than the displayed comparison with the integral optimum. The original three-page proof was read. [Original article](https://people.stfx.ca/tjsmith/lec/W23CSCI435/Chv79.pdf).

Here d counts receiver atoms in a patch, not the ambient dimension or source frequency. Refining a receiver mesh can send d to infinity. Rounding controls the scalar cost, not each physical source column. A mesh-uniform source-capacity statement must be proved separately. Lovász's 1975 publisher abstract was located, but its full original proof was not accessible in this audit; no weighted theorem is attributed to that unread proof.

There is an additional exact redundancy test. Let actual receiver patches P_j⊂B have nonnegative source envelopes w_j with ∫w_j dμ≥λ|P_j|. If u_j≥0 cover B fractionally and Σ_j u_j w_j≤K μ-a.e., then Tonelli already gives

    λ|B| ≤ Σ_j u_j λ|P_j| ≤ ∫Σ_j u_j w_j dμ ≤ KW.

Thus rounding is unnecessary for the weak measure target once that common fractional packing inequality is known. Chvátal can make a finite cover explicit; it cannot prove the missing packing inequality or improve K.

## 2. An actual source-sharing covering proof, with its geometric price

Stein–Strömberg (1983), §2, Theorem1 and its unnumbered covering lemma, take a bounded open symmetric convex body in R^n, n>1. For every finite family of its homothetic balls there is an ordered subfamily B_j with disjoint increments I_j=B_j\(∪_{i<j}B_i), covering the original union up to a universal factor, and

    Σ_j |I_j|/|B_j*| 1_{B_j*} ≤ c_2 n log n,   B_j*=n B_j.

The constants are universal; the theorem gives no numerical c_2. The selection tests the accumulated weighted load on (n+1)B_j; the proof bins radii at ratio 1+1/n. The resulting weak (1,1) constant is c n log n. §2 was read. [Original article](https://archive.ymsc.tsinghua.edu.cn/pacm_download/116/7398-11512_2006_Article_BF02384314.pdf).

For the cube, the convex-body hypothesis holds. This is a genuine shared summed source envelope rather than separate patch estimates. Its bound is nevertheless a retained baseline, not an R85 dimension gain. Replacing B_j* by each original captured cube requires a new selection/coverage argument. Replacing the radius-bin count by a square-root count requires a new actual packing estimate. The original middle and coarse deletion alone establish neither replacement.

Naor–Tao, *Random Martingales and Localization of Maximal Inequalities*, §4, Theorem4.1, uses a separable metric space, Radon ambient measure σ, and positive finite ball masses. For every f∈L¹(σ), λ>0, a finite increasing radius sequence tempered with constant K has weak (1,1) constant 2eK/(e−1). With B(x,r,s)=∪_{z∈B(x,r)}B(z,s), equation(57) requires every j,x and y∈B(x,r_j) to satisfy

    σ(B(x,r_j) ∪ ⋃_{i<j}B(x,r_j,r_i)) ≤ K σ(B(y,r_j)).

Here σ is the ambient averaging and receiver measure. The randomized induction removes a source region F only from earlier balls geometrically disjoint from F. This is the reason their threshold witnesses survive the recursion. The statement and §4 proof were read. [Author's original manuscript](https://web.math.princeton.edu/~naor/homepage%20files/HLM.pdf).

For ℓ∞ balls and σ=dx the condition is exactly

    K ≥ max_{j≥2}(1+r_{j−1}/r_j)^n.

Any two radii in [1/2,1] therefore require K≥(3/2)^n; densely spaced radii cost nearly 2^n. Full sides [1,2] have the same ratios. The theorem is useful for sufficiently separated radii, but does not cover arbitrary earliest contacts with a small K. Substituting σ=μ=f dy changes the operator and additionally lacks the required uniform volume comparison. Adaptive bad-source removal is not the geometric disjointness used in this induction.

Proof-reading note: use Campbell expectation and Poisson indicator counts; the printed arbitrary weighted-Poisson assertion is unnecessary. Replace |B*(x)|=1/p(x) by ≤1/p(x). These corrections do not strengthen the estimate.

## 3. Fisher information under a legitimate fixed coarsening

Pollard, arXiv:1107.3797v2, Definition4 and Theorem7, assumes a real-parameter experiment differentiable in quadratic mean (DQM), an L² score Δ_t, and a parameter-independent measurable statistic S. The image experiment is DQM with score E_t[Δ_t|S]. Information is preserved at t exactly when Δ_t is S-measurable modulo P_t. Definition4 requires singular mass o(h²), besides the quadratic-mean expansion. The theorem and its complete §5 proof were read. [Original manuscript](https://arxiv.org/pdf/1107.3797).

The following finite version and transfer statements are proved here directly, so no DQM assertion is needed at state collisions. Let p_t(y) be a probability curve on a **fixed finite** state set, with absolutely continuous coordinates on [a,b]. Let S be fixed and q_t(z)=Σ_{S(y)=z}p_t(y). Work at almost every t where derivatives exist. A nonnegative absolutely continuous coordinate has derivative zero almost everywhere on its zero set. Sum only positive probabilities and define I_p(t)=Σ p'_t(y)²/p_t(y). Then

    I_p(t)−I_q(t)
      = Σ_{z:q_t(z)>0} q_t(z) Var_{p_t(.|z)}(p'_t(y)/p_t(y)) ≥0.       (F1)

Proof: the conditional mean score is q'_t(z)/q_t(z). Expand conditional variance, multiply by q_t(z), and sum. Both sides are finite at points where I_p is finite; if I_p is infinite use the inequality version. This explicitly records the information hidden by refinement.

Let L_p=∫_a^b√I_p(t)dt<∞. Coordinate positive variation and Cauchy–Schwarz give the nonasymptotic envelope bound

    Z_p:=Σ_y sup_{t∈[a,b]}p_t(y) ≤ 1+L_p/2.                         (F2)

Indeed each coordinate maximum is at most its initial value plus positive variation; Σ(p'_t)_+=(1/2)Σ|p'_t|, and Σ|p'_t|≤√I_p because Σp_t=1. This applies across finitely many collision points by absolute continuity and the integrable length bound. A one-dimensional parameter does not give a uniform bound on L_p.

Coarsening gives L_q≤L_p, whose direction is insufficient to bound Z_p by L_q. A necessary payment can be isolated without pretending it is automatically small. Define

    c_z=Σ_{S(y)=z} sup_{t:q_t(z)>0} p_t(y)/q_t(z),

with c_z=0 if q_t(z) vanishes identically. Then

    Z_q≤Z_p≤Σ_z c_z sup_t q_t(z)
          ≤(max_z c_z)(1+L_q/2).                                 (F3)

The first inequality follows by moving the supremum inside a finite sum. For the second, use p_t(y)=q_t(z)p_t(y|z), take separate suprema, and sum. No positive lower bound on q_t is needed. This is a usable conditional reconstruction inequality, not a dimension gain: c_z can be as large as the fibre size. A statistic depending on t is not covered by Pollard's theorem or (F1).

For a fixed latent label A with weights w_A≥0, Σw_A=1, the joint curve p_t(A,y)=w_A p_t^A(y) satisfies exactly

    Z_joint=Σ_A w_A Z_A,
    I_joint(t)=Σ_A w_A I_A(t),
    Z_joint≤1+(1/2)Σ_A w_A L_A.

Forgetting A is a fixed coarsening and reduces both the pointwise Fisher information and the envelope. Returning from the mixture to label-dependent selected scales requires the reconstruction payment in (F3), or a separate proof that all fine states grouped together use the same parameter. This distinguishes an actual positive mixture from separately optimized label events.

## 4. Why a modern regret theorem does not supply the required envelope

Jia–Polyanskiy–Rakhlin, arXiv:2503.17823v1, Definition1 and Theorem1, considers arbitrary classes Q of joint laws on a finite alphabet Y to depth m≥7. Its sequential square-root cover controls **all** conditional outcomes and times along **every** history, with quantifier order sup_q max_history min_representative max_time max_outcome. With H_sq the logarithm of the smallest cover, it bounds

    log Z(Q)=Õ(1+inf_{γ>δ>0}{mδ√|Y|
          +√(m|Y|)∫_δ^γ√H_sq(Q,α,m)dα+H_sq(Q,γ,m)}).

The notation hides logarithmic factors in m and |Y|, not an explicit numerical constant. The definitions, theorem and appendix B.5 assembly were read; this is not a full independent audit of every supporting lemma. [Original manuscript](https://arxiv.org/pdf/2503.17823).

For an envelope Z, even log Z=Õ(√n) yields Z≤exp(Õ(√n)), not Z≤√n polylog n. The latter would require log Z≤(1/2)log n+O(log log n). The full conditional-history cover is also not supplied by a scalar scale parameter or a single marginal Fisher calculation. This candidate therefore gives no current cube gain.

## 5. Updated64 interfaces: concrete permitted uses

The present source arguments need finite calculations, positive domination and exact geometric transfer. A02 correctly requires a real pointwise domination and a separate approximation/error ledger; coarsening an envelope without (F3) reverses the needed transfer. B01 permits finite Farkas/weak-dual certificates, but not replacing a family of source-dependent multipliers by one common multiplier. M01's d+1 support bound uses affine constraint dimension, which grows with the receiver/source mesh; physical dimension n is not that rank.

G03 admits explicit finite Hermitian/PSD arithmetic only; its source-to-capture Gram map remains undefined. G05 requires every subtree's packing and p>1 for the standard embedding; it gives neither endpoint packing nor the missing actual tree. D04 uses the same joint law and true conditional reference kernels; it does not certify a fixed-parameter score projection when the statistic changes with scale. K04 requires an actual probabilistic/Gaussian approximation and complexity/nondegeneracy inputs; deterministic selected source columns are not such an input. No new applicability is inferred from these skill names.

The strongest usable addition here is (F1)–(F3): it separates coarse Fisher length from the exact fine-state reconstruction cost. The new action is to prove a gate-compatible reconstruction/parameter-compatibility estimate, or a shared geometric packing inequality. No reviewed source supplies either uniformly for arbitrary retained inputs. All R82 continuous Hall and R83 principal-partition conclusions, R82 B0/Bext fees, original middle gates, κ layer count O(log n), and all-scale localization remain unchanged. A layer-by-layer application must pay its layers; none of the sources above cancels them.

# R85：扩大真实接收域，比较自由 Hall 流与规定列

一般目标仍未证明。本轮的新结果是一个有限、真实 L1、原门槛全部合资格的例子：**原硬后验的最大源负载严格大于同一输入、同一接收域、同一 κ 层的最优共同源容量**。这说明最优共同流的平坦负载不能自动当成规范后验的平坦负载。它不否定一般优化覆盖，也不给渐近维数阶。

`hall_probe.py` 自包含、只依赖 Python 标准库；同目录运行 `python3 hall_probe.py` 重建确定性 `hall_results.json`。本轮没有重复第84轮的12个微小接收盒。源均为真实正 L1 轴盒密度；接收测度均为原 Lebesgue dx，没有原子接收端点替代或尺度网格首触替代。输入、源分割、被接受的接收盒、被拒绝认证的余盒和全部证书均保存。

## 三阶段与负担范围

阶段一改变集中源的真实接收域：角部整片区域、角部与侧面片区的并集，以及同一输入/接收域的源分割细化。阶段二改变物理源：加入相关卫星源、细化同一相关输入、改用各向异性主源。阶段三采用对齐域参数的 n=2/n=3 输入。共8个新测试，维数2、3；输入、源几何、分割分辨率的变化明确分开登记。

最大的认证接收体积是 `3003/5000=0.6006`，远大于旧轮的微小盒。对应 `D/W=3003/20000=0.15015`。这仍远低于 MD-high 的 `D>T_n W`（其中 `T_n≥2`），所以本轮没有测试到该关键高负担分支，也不以低负担结果反驳它。

未认证的子盒完整保留。它们不是被证明不属于原事件：有些只是当前区间精度不能判定原 κ 层或平滑门。请求域体积严格等于已认证体积加未认证体积。被接受的每个盒整体均通过所有原门槛；没有把一个中心点的合资格性扩展到整盒。

## 连续 selector 与完整原门槛

原对象为全边长 `L∈[1,2]`、`lambda=1`、`A_L=L^-n mu(Q(x,L))`，真实 E2 `phi=h*w`、`w(z)=∫_0^1 exp(-|z|/t)dt`。selector 是连续窗口内最早硬接触 `L*(x)=inf{L:A_L≥1}`。

对每个接收盒，逐源组件的最近/最远坐标给硬捕获上下包络。全部物理断点 `2|x-a|,2|x-b|` 被加入；断点之间使用实际有理重叠乘积多项式、完整 Sturm 链、单侧端点变号与较早区间负值见证，隔离首根。首根所在区间明确要求唯一根，并保存区间内部更早根数为零。根包围、精确 `A_1<1/2` 和共同严格硬见证均保存。

宽接收盒不再沿用第84轮窄盒的导数分支方法。设主源盒质量 M、最大边宽 b，其他源总质量 w；整个真实根包围满足 `w<lo^n`、`hi^n<M`。在任一真实根处，主源贡献至少 `L^n-w>0`，同时不可能已全捕获。至少一个主源坐标仍为部分重叠，其斜率至少1/2、长度至多 b；其他捕获导数非负。因此单侧导数有统一正下界

`A'_L* ≥ 1/(2b)-n/lo-w/(2b lo^n)>0`。

这认证原最早接触为上穿，并保证接收片区内的实际首触正规性；不把一个抽象流的行尺度当成真实首触。

φ 的 t 被积函数采用真实卷积的内/外两式，关于 t 单调非减，左右 Riemann 和给严格上下界。指数计算使用60位整数向外舍入、20项正 Taylor/严格余项、倒数及平方，φ 参数使用单调方向的24位舍入。源积分一般坐标上使用每个子区间到接收坐标区间的最小/最大距离，不要求接收点在每个源投影之外。完整 `[1,2]` 用16段正包络覆盖；这不是有限尺度最大值诊断。接受记录使用 t=64、每个源坐标=4，selected P 另使用真实根区间。

原 middle 未被替换：`exp(-s_n)/2≤m*Mphi^(n-1)/2`，所以仅当 selected P 的下界超过右侧的严格区间上界时才认证原 `Emid`。κ 层通过相应指数阈值的向外包围验证，避免浮点对数。接受的 n=2 子域在 j=0，n=3 在 j=1。没有继承源截断后的原门槛。

## 同一物理源的连续 Hall 夹逼

源按正质量子盒分割，组件标签的容量相加恰为原物理 L1 密度。内图边要求源子盒对接收盒每个点都被原 Q* 捕获；外图边包含一切可能捕获。宽盒另利用根身份建立主源的共同捕获角盒：若主源捕获矩形边长 o_i≤b_i，则

`o_i≥[(lo^n-w)/M]*b_i`。

外侧坐标取相应源角部前缀/后缀；投影内坐标只在整个主源坐标确被 `lo` 尺度统一捕获时使用全边。此保证保留 x 与 L*(x) 的相关性，没有错误地把不相关的最小尺度代入每个最远接收点。

每行需求是完整接收盒的 `volume`。自由 Hall 容量用有理违反割迭代求解：从 K=0 开始，未满流的残余割给严格更大的需求/邻源质量比；最终满流给可行上界，等比紧割给下界。最大紧割的并集用残余图中不能到达 sink 的顶点重建。两图均保存完整正流弧、容量、整数公分母、守恒、残余割与最大紧割，而不是只保存求解器的最优值。

内流均匀提升到接收盒×源子盒，因所有该物理对均被捕获，它对任意可测接收子集也可行；所以内图 K 是真实连续容量上界。外图的紧行并集源邻域质量偏大，所以给真实连续容量下界。内外 K 相等的记录给这些具体 B 的真实精确最优值。源容量在所有行间共同使用；没有私人行容量或任意代表列。

原后验负载为 `b(y)=∫_B L*^-n 1_Q* dx`。内外捕获边及根区间给每个正质量源子盒的严格负载区间，各行项先按60位 dyadic 向外舍入再相加，避免巨大有理公分母。其最大下端是真实 essential 最大负载的下界。各向异性例的该下界严格超过自由 Hall 的精确可行值，故差异是认证结论，不是中点现象。

对内图最大紧割 A，还保存实际 `N(A)` 质量的内外区间，以及真正的规范互补泄漏 `∫_{N(A)}(b_B-b_A)dmu` 的上下界。它们是给定有限图割的物理夹逼，不声称该图割已等于连续问题的最大割。

## 规定停止列、方差与 patch：只作诊断

浮点 closed E1/原函数用于新的中点诊断，并与独立 Gauss 实现核值核对。θ 取 `log^-2(n+2)`，真实捕获限制先用于 `C_x(η)`，然后在中心行上求停止 `C_x(η)=3/4`，计算 q、ell。原 Pθ 必须用全部源计算；没有把 captured Cθ 冒充 full Pθ。

**停止列仅与相同中心粗门存活行的规范列比较。** 字段 `center_coarse_survivor_mask` 与 `source_b_same_center_coarse_survivors` 保存该集合。若中心 Pθ 不低于1/2，该行不进入停止列；它仍可属于完整原 B 的 Hall/规范比较。中心门、停止积分和源中点积分均未做整盒区间认证，故没有把它们当成真实 `F_theta` 的费用或停止列失败证书。即使全部中心存活，也不推断整盒窄核门。

同样，V_t、V_u、E r²（`u=log max(1,2||x-y||∞)`、`r=log L*-u`）是捕获源/接收中点积分，使用实际中心首根；D 保留原接收体积。它们与 `E r²≤2/n²`、`|sqrt Vt-sqrt Vu|≤sqrt2/n` 作对照，不能升级成证明。

实际 captured fibre 的矩形半径在源子盒中心有严格内/外区间，来自保证/可能捕获的完整接收盒。矩形包络中的 log 值与源质量积分仍为诊断。whole B、坐标二分、单接收盒分区都覆盖同一 B；每个 patch 的源包络合收费全部保留，没有漏掉重复源质量。这些自然分区的合费明显增加，但没有求任意 fractional patch 的全局最优值，也不以此证明所有 patch 方法失败。

## 最终数据

以下表格来自冻结证书；负载的有理认证区间以小数近似显示，精确分数保存在 JSON，小数显示本身不作向外区间证书。停止/矩形矩为诊断。全部 K 仍为低容量，不能据此拟合 n 阶数。
| 测试 | 阶段 / n | 合格 / 未认证盒数 | 合格体积 | 自由连续 Hall K 区间 | 原后验最大负载有理认证区间（约值） |
|---|---:|---:|---:|---|---|
| broad_spike_n2 | 1 / 2 | 88 / 36 | 63/200 | [63/800, 63/800] | [0.0288840148, 0.136763844] |
| broad_corner_and_side_union_n2 | 1 / 2 | 120 / 68 | 3003/5000 | [3003/20000, 3003/20000] | [0.141576606, 0.225241725] |
| broad_spike_n2_refinement | 1 / 2 | 88 / 36 | 63/200 | [63/800, 63/800] | [0.0607499248, 0.136763844] |
| correlated_spike_plus_satellite_n2 | 2 / 2 | 63 / 5 | 283/1152 | [1415/25344, 1/9] | [0.0212581075, 0.100512699] |
| correlated_spike_satellite_source_refined_n2 | 2 / 2 | 63 / 5 | 283/1152 | [1415/25344, 1415/25344] | [0.0212581075, 0.100512699] |
| anisotropic_primary_n2 | 2 / 2 | 84 / 40 | 31/225 | [31/900, 31/900] | [0.036359893, 0.0541461075] |
| dimension_aligned_n2 | 3 / 2 | 44 / 36 | 23/128 | [23/512, 23/512] | [0.0161240495, 0.0753589103] |
| broad_spike_n3 | 3 / 3 | 232 / 144 | 23/256 | [23/2048, 5/256] | [0.00192044202, 0.0193100058] |

各向异性例：Hall K=31/900；原后验 essential 最大负载≥20960051247661755/576460752303423488≈0.036359892957。严格差≥248440700372362843/129703669268270284800≈0.00191544851255，下界比值≥1.055609796。因此至少约5.56%的规定列/最优列差异被精确认证；这是有限例，不是渐近失败。

| 测试 | 同一中心粗门存活行数 | 该行集规范列最大值（诊断） | 该行集停止列最大值（诊断） |
|---|---:|---:|---:|
| broad_spike_n2 | 80 | 0.08537497 | 0.076772835 |
| broad_corner_and_side_union_n2 | 112 | 0.19318785 | 0.17102741 |
| broad_spike_n2_refinement | 80 | 0.10866369 | 0.088359929 |
| correlated_spike_plus_satellite_n2 | 62 | 0.076120532 | 0.067006942 |
| correlated_spike_satellite_source_refined_n2 | 62 | 0.087936821 | 0.075118783 |
| anisotropic_primary_n2 | 84 | 0.050301447 | 0.045347878 |
| dimension_aligned_n2 | 44 | 0.059397079 | 0.050968104 |
| broad_spike_n3 | 232 | 0.016539904 | 0.014436154 |

这些数值不与被删除行仍在内的完整 B 混作停止容量比较；没有将中心粗门存活认证为整盒 Fθ。

| 测试 | Vt（诊断） | Vu（诊断） | E r²（诊断） | whole 源矩形包络平均值区间（诊断） |
|---|---:|---:|---:|---|
| broad_spike_n2 | 0.00856525 | 0.00839081 | 8.4753e-05 | [2.18937, 2.20787] |
| broad_corner_and_side_union_n2 | 0.00953428 | 0.00934362 | 9.96648e-05 | [2.27838, 2.29399] |
| broad_spike_n2_refinement | 0.00802515 | 0.00787259 | 8.684e-05 | [2.19005, 2.20756] |
| correlated_spike_plus_satellite_n2 | 0.00588124 | 0.00595242 | 0.00320097 | [2.14251, 2.20898] |
| correlated_spike_satellite_source_refined_n2 | 0.00570706 | 0.00577798 | 0.00320032 | [2.14375, 2.20879] |
| anisotropic_primary_n2 | 0.004512 | 0.0039398 | 0.00228344 | [2.11728, 2.17532] |
| dimension_aligned_n2 | 0.00551989 | 0.00543635 | 8.65751e-05 | [2.18937, 2.20787] |
| broad_spike_n3 | 0.000901755 | 0.000909474 | 7.3703e-05 | [2.77995, 2.81291] |

全数据保存最大紧图割上的相同矩诊断、严格互补泄漏夹逼和所有自然 patch 的合收费。单盒 patch 的重复合费比 whole 大很多；没有由这些自然家族推出任意 fractional patch 的下界。

计数：8个新输入/接收域测试，782个完整合格接收盒，370个未认证余盒，8个κ层输运问题，448个正质量源子盒。所有原门槛重新计算；原子/有限尺度事件均未替代连续输入。

本轮改变下一步的证据是有限但严格的 prescribed-versus-optimized 差异。MD-high、高容量割的一致预算和一般 root-order 目标仍未证明；增加此类低负担成功测试不能补上这些缺口。

# Independent audit conclusions for R85

The general sqrt(n) n^{o(1)} centered-cube bound remains unproved.

**PASS — actual radial estimates.** Earliest contact gives an exponential tail for the clamped logarithmic depth from captured source radius to selected cube side. Its second moment is at most 2/n^2. The resulting conditional-variance transfer and filtered high-load inequality are valid on actual Lebesgue receiver cuts. In particular, for K=D/mu(N)>=4,

K^2 <=96 n^2 [integral_(b>K/2) Var(log max(1,2||x-y||_infinity)|y)dmu]/mu(N)+384.

This is a necessary high-Hall constraint. A uniform upper bound on its filtered radial-variance budget is still missing. The stronger principal-density distribution estimate is conditional on the stated actual finite principal representation and convex-order comparison; no continuum attainment is inferred.

**PASS — local redistribution and full recursion accounting.** Tunable captured stopping gives gain d>c lambda, good-row capacity K/[c(1-delta)], and a strict bad-row witness at the new threshold delta*c*lambda. All later gates and selectors must be recomputed. The finite-depth weak receiver-fee ledger includes weighted source shells, repeated exception charges, and a terminal full-window bound. A uniform source contraction rho<delta*c closes its infinite sum, but that contraction is unproved. Later allocations are not automatically allocations on the original capture graph.

**PASS — structural and finite-state limits.** On the stated strict compact class, spatial replication turns a uniform absolute source-tail condition into an essential column bound. Remote source mass can dilute a global mass fraction without changing local rows; it does not refute a weak bound charged to the enlarged total input mass. First-moment Markov control cannot certify the needed source contraction in the useful-payment regime. The finite Fisher coarsening identity, envelope-length bound, and conditional reconstruction inequality are correct under their explicit finite-state hypotheses; coarse information alone supplies no uniform reconstruction bound.

**PASS — the rectangle-envelope obstruction and its scope.** Every countable fractional receiver cover by true-fibre source-centered symmetric rectangles pays the common essential coordinatewise shadow. The positive-volume witness definition and essential radii correctly eliminate null-set artifacts. A fully qualified actual L1 family forces an integrated linear-in-n source fee for this envelope mechanism, while its actual receiver burden is small. This excludes the proposed universal root-order rectangle-envelope budget, not the maximal target, optimized source reassignment, or a high-burden-only theorem. Asymmetric enclosures retaining actual receiver centers and rounding only scales decrease to the exact canonical occupation and exact demand; that valid limit supplies no new numerical budget.

**Open interfaces.** A shared source packing or filtered radial-variance estimate, or a geometrically proved repeated source-mass contraction, is still needed. High total burden D/W and high Hall ratio D/mu(N) remain distinct. Receiver-only fractional patch covers do not reduce the canonical source column by algebra alone, and repeated patch charges need a common-source budget. Finite numerical success and conditional recursions do not establish a dimension exponent.

These conclusions contain no private construction parameters. Author-proof and numerical additions not yet explicitly audited below must not be inferred to have passed from this summary.

# R85 independent Sol audit

The general bound C_n <= sqrt(n) n^{o(1)} is **UNPROVED**. The audited positive results retain the original R82 event, one physical source measure and Lebesgue receiver demand. They do not replace that event with a narrower-kernel event, infer a common source budget from independent patch prices, or infer dimension gain from finite feasibility.

The three route candidates were independently derived and timestamped before the new author proofs were read. The completed formal review covers coverage, adaptive, alternative and source contracts, with their TeX counterparts. Private pressure proofs and receipts remain outside this public extraction.

The coverage proof is valid on its stated first-contact class. The unit clamp is essential: earlier physical sides in [1,L] imply the receiverwise depth tail exp(-nh), every pth moment Gamma(p+1)/n^p, and the exponential moment 1/(1-a). Conditional centering uses the same joint capture measure. The pointwise radial occupation has atom at zero at most one and density at most n above zero. The filtered hinge estimate, continuum Jensen corollary and arbitrary-subset energy/slack estimate have the stated constants and signs. A continuum principal representation is not asserted by the optional finite principal result. The missing high-load radial-variance budget is still open.

The adaptive proof correctly recomputes every gate and threshold after source restriction. The true transfer is beta=delta(1-alpha-epsilon); good rows pay only the removed source shell, while exceptional rows repeatedly charge the current nested source mass. Its summation-by-parts and terminal remainder are valid. The condition W_(i+1)<=rho W_i with rho<beta is an independent, unproved geometric hypothesis. Spatial replication shows what a uniform absolute stopped-source tail hypothesis must establish on the stated strict compact class; it does not refute the target capacity. A total stopped-mass Markov estimate cannot establish the needed contraction in its useful-payment range.

The alternative shadow lemma covers countable fractional receiver covers, preserves actual capture fibres, and charges the common source. The audited anonymous failure is an overcharge of the symmetric-rectangle mechanism on fully qualified low-burden inputs. It is not a maximal weak-type lower bound, a high-Hall counterexample, or a refutation of optimized transport. Asymmetric nested scale enclosures converge to the exact canonical column and their total price converges to the original receiver demand; that identity supplies no upper budget.

The finite score/coarsening, positive-variation envelope and conditional reconstruction formulas F1–F3 are directly valid. Coarse Fisher information has the wrong direction for controlling a fine-state envelope without a reconstruction fee. I checked the relevant statements of [Pollard's theorem](https://arxiv.org/pdf/1107.3797), [Naor–Tao's tempered-radius theorem](https://web.math.princeton.edu/~naor/homepage%20files/HLM.pdf), the finite [Chvatal cover theorem](https://people.stfx.ca/tjsmith/lec/W23CSCI435/Chv79.pdf), and the [sequential-regret theorem](https://arxiv.org/pdf/2503.17823). This is a statement/transfer audit, not independent verification of every supporting lemma in those papers.

## Independent reproducible checks

The public guard contains three parameter ranges. Its scalar portion passed with 27 truncated-tail models and 27 nested ledgers, plus exact conditional-projection, energy, hinge, finite Fisher-reconstruction and cover checks. All comparisons use rational arithmetic or outward exponential enclosures. The synthetic scalar pressure law is explicitly nonphysical; it is not an actual L1 input, contact, gate or dimension counterexample. These checks verify algebra and domains.

The final frozen Hall pair independently passed on 8 new positive L1 inputs, 782 qualified receiver cells, 370 uncertified cells, 8 original-layer transport problems and 448 positive source bins. It verified 8,244 upper/lower envelope polynomial intervals, 4,278 actual-center intervals, 16 Hall graphs and 4,814 positive saved flow arcs. The complete requested receiver domains are partitioned exactly into accepted and uncertified cells. The guard reconstructs full physical breakpoint polynomials and one-sided Sturm counts, root brackets and derivative bounds, continuous original E2 upper/middle/layer gates, actual source partitions, guaranteed capture corners, and inner/outer neighborhoods. A separate integer Edmonds–Karp computation verifies both exact Hall capacities and the union of all tight cuts; saved flows are checked for common source capacity and conservation. Author code is not imported by this verification. The anisotropic fixture certifies a strict prescribed-versus-optimized difference: its canonical essential-maximum lower bound exceeds the exact shared Hall capacity 31/900. The largest recorded demand/source ratio is only 0.15015, so none of these fixtures tests the MD-high branch or an asymptotic exponent.

Registered stopped values, fibre envelopes, logarithmic moments, source-tail diagnostics and fitted exponents remain numerical diagnostics where so labeled. They do not certify an input-uniform contraction or an asymptotic bound. Failed qualification cells are excluded from certified demand and cannot be silently counted as retained receivers.

The independent complete-result guard passed in **16.790083 seconds**. A standalone temporary-copy production run passed in **24.076578 seconds**, with exit zero, empty stderr and byte-identical JSON. A separate five-member-only extraction harness passed in **17.259442 seconds** (guard internal time 16.384983 seconds); the extracted Python fence was byte-identical, and no component or prior-round file was present. The main-program replay and independent certificate audit are distinct checks.

Frozen SHA-256 identities:

- hall_probe.py: `222937b0ad241c339a7aeb6205a4553f98d312317d7542103cbd971cd3523914`.
- hall_results.json: `c521dea8ec45663b34851350a7d510821df8eeabf65bdf35556de92729ef39ec`.
- extracted audit_guard.py: `fc356bb4f1101c02ff95ba0ab3c86a30e6d8a05c31066d27275086d349c66aac`.

The final public package has five members: proof.md, proof.tex.txt, hall_probe.py, hall_results.json and inventory.json. Its single embedded audit Python fence can be extracted and run beside the frozen Hall pair. The guard requires no private program, former-round data, component manuscript, network or skill path. The program replay and the independent JSON certificate audit are separate receipts; the guard does not itself rerun the production program.

Every independently applied original layer estimate still costs its actual layer count, and the all-scale return still incurs the retained localization factor. No general packing/contraction theorem, uniform convergence rate or root-order upper closure is certified.

## 独立公开证书审核程序

```python
#!/usr/bin/env python3
"""R85 public independent audit. Scalar/projection/ledger checks are algebraic,
not actual cube fixtures. Frozen continuous Hall certificates are checked
separately. No private files, author imports, network, or external skills.
"""
from fractions import Fraction as F
from functools import lru_cache
from pathlib import Path
from itertools import product
from collections import deque
import hashlib,json,math,re,subprocess,sys,tempfile,time
ROOT=Path(__file__).resolve().parent
COUNTS={}
def check(v,label):
    if not v: raise AssertionError(label)
    COUNTS[label.split(':')[0]]=COUNTS.get(label.split(':')[0],0)+1

@lru_cache(None)
def expminus(x):
    x=F(x);check(x>=0,'exp:domain');k=0
    while x>F(1,2):x/=2;k+=1
    term=F(1);s=F(1)
    for j in range(1,26):
        term*=x/j;s+=(-1 if j%2 else 1)*term
        if j==24:upper=s
    lower=s
    for _ in range(k):lower*=lower;upper*=upper
    return lower,upper

def weighted_var(rows,index):
    total=sum(w for w,*_ in rows)
    mean=sum(r[0]*r[index] for r in rows)/total
    v=sum(r[0]*(r[index]-mean)**2 for r in rows)/total
    pair=sum(a[0]*b[0]*(a[index]-b[index])**2 for a in rows for b in rows)/(2*total**2)
    check(v==pair,'projection:independent pairwise variance')
    return v

def sqrt_triangle(A,B,R):
    # Exact equivalent to |sqrt(A)-sqrt(B)|<=sqrt(R).
    return A+B<=R or (A+B-R)**2<=4*A*B

def scalar_checks():
    stages=[(1,[2,3,4],[1,2,3]),(2,[8,16,32],[1,2,4]),(3,[64,256,4096],[1,2,4,8])]
    models=0
    for stage,ns,ps in stages:
        for n in ns:
            for t in [F(1,16),F(1,4),F(1,2)]:
                z=n*t;l,u=expminus(z)
                for p in ps:
                    # p*integral_0^t h^(p-1)e^-nh dh, the exact truncated
                    # exponential pth moment. Bounds use rational Taylor.
                    poly=sum(z**j/F(math.factorial(j)) for j in range(p))
                    constant=F(math.factorial(p),n**p)
                    lower=constant*(1-poly*u);upper=constant*(1-poly*l)
                    check(lower>=0 and upper<=constant,'tail:truncated moment enclosure')
                for a in [F(1,4),F(1,2),F(3,4)]:
                    el,eu=expminus((1-a)*z)
                    lower=(1-a*eu)/(1-a);upper=(1-a*el)/(1-a)
                    check(1<=lower<=upper<=1/(1-a),'tail:truncated exponential moment')
                models+=1
            # Abstract finite tail-admissible joint laws, coupled through a
            # common source label. They are not dx/gate certificates.
            J=min(8,n);q=F(1,4);step=F(1,2*n)
            groups=[]
            for g in range(3):
                rows=[]
                for j in range(J+1):
                    w=q**j*(1-q) if j<J else q**J
                    r=j*step;u=F(g+1,32)+F(j%3,32*n);t=u+r
                    check(0<=u<=t<=F(2,3),'projection:finite law physical parameter range')
                    rows.append((w,t,u))
                for j in range(J):
                    survival=sum(w for w,t,u in rows if t-u>j*step)
                    check(survival<=expminus(F(j,2))[0],'tail:finite admissible survival')
                vt=weighted_var(rows,1);vu=weighted_var(rows,2)
                er2=sum(w*(t-u)**2 for w,t,u in rows)
                check(er2<=F(2,n*n),'projection:radial moment budget')
                check(sqrt_triangle(vt,vu,er2),'projection:conditional centering contraction')
                # Predictor distinct from conditional mean, finite and exact.
                predictor=F(g+1,32)
                epu=sum(w*(u-predictor)**2 for w,t,u in rows)
                check(sqrt_triangle(vt,epu,er2) or vt<=epu,'projection:predictor triangle')
                groups.append((F(g+1,6),vt,vu,er2))
            A=sum(w*v for w,v,_,_ in groups);B=sum(w*v for w,_,v,_ in groups);R=sum(w*v for w,_,_,v in groups)
            check(sqrt_triangle(A,B,R),'projection:common-source joint norm')
            # beta=delta0+n du, t=u,r=0. Exact scalar pressure: marginal
            # restrictions and every radial moment alone permit linear b.
            H=F(1,2);b=1+n*H;m1=n*H**2/2;m2=n*H**3/3
            variance=m2/b-(m1/b)**2
            check((b-1)**3<=12*n*n*b*variance,'pressure:abstract cubic admissibility')
            check(b>n/2,'pressure:abstract linear mass no geometric claim')
            # Unclamped radius has no scalar depth control: even fixed t,
            # a subunit radius can have depth much larger than 1/n.
            check(F(1)**2>F(2,n*n),'pressure:unclamped depth exclusion')
            for T in [F(2),F(4),F(16)]:
                for load in [T+F(1,10),2*T,4*T]:
                    check((load-T)**2<=(load-1)**3/load,'hinge:pointwise cubic comparison')
                    if load>=2*T:check(load<=2*(load-T)**2/T,'hinge:high mass comparison')
            for K in [F(4),F(16),F(32)]:
                check((K/2)**2 == K*K/4 and 48*K/(K/2)==96,'hinge:continuum Jensen constants')
                check(F(96)*2==192 and F(384)*2==768,'hinge:large K absorption constants')
    # General finite submeasure variance-energy checks (H=1/2), no selector.
    for count in [3,8,32]:
        rows=[(F(j+1),F(j,2*count)) for j in range(count)]
        def energy(rr):
            m=sum(w for w,t in rr)
            return sum(w*t*t for w,t in rr)-sum(w*t for w,t in rr)**2/m if m else F(0)
        EB=energy(rows)
        for modulus in [2,3,5]:
            sub=[(w/F(modulus),t) for j,(w,t) in enumerate(rows) if j%modulus]
            removed=sum(w for w,t in rows)-sum(w for w,t in sub)
            check(0<=EB-energy(sub)<=F(1,4)*removed,'energy:submeasure stability')
    ledgers=0
    for depth in [2,8,32]:
        for beta,rho in [(F(1,4),F(1,8)),(F(3,8),F(1,4)),(F(4,5),F(3,4))]:
            for pattern in range(3):
                W=[F(1)]
                for i in range(depth):W.append(W[-1]*rho*(F(1) if (i+pattern)%3 else F(1,2)))
                direct=sum(beta**(-i)*(W[i]-W[i+1]) for i in range(depth))
                sbp=W[0]+sum((beta**(-i)-beta**(-(i-1)))*W[i] for i in range(1,depth))-beta**(-(depth-1))*W[-1]
                check(direct==sbp,'ledger:exact summation by parts')
                check(direct<=(1-rho)/(1-rho/beta),'ledger:weighted source-shell bound')
                check(beta**(-depth)*W[-1]<=(rho/beta)**depth,'ledger:terminal remainder')
                check(sum(beta**(-i)*W[i] for i in range(depth))<=1/(1-rho/beta),'ledger:repeated exception source fee')
                check(W[0]-W[1]>=1-rho,'ledger:termwise shell direction')
                ledgers+=1
    print('Scalar stages PASS:',models,'tail models;',ledgers,'nested ledgers; algebraic, not physical fixtures')

def fs(v):return F(v)
def box(v):return tuple(tuple(map(F,ab)) for ab in v)
def vol(b):return math.prod(v-u for u,v in b)
def ov(x,a,b,L):return max(F(0),min(b,x+L/2)-max(a,x-L/2))
def cap(boxes,pts,L):
    return sum(F(b['density'])*math.prod(ov(x,a,z,L) for x,(a,z) in zip(pt,box(b['bounds']))) for b,pt in zip(boxes,pts))
def tr(p):
    p=list(map(F,p))
    while len(p)>1 and p[-1]==0:p.pop()
    return p

def padd(p,q):return tr([(p[i] if i<len(p) else 0)+(q[i] if i<len(q) else 0) for i in range(max(len(p),len(q)))])
def pmul(p,q):
    r=[F(0)]*(len(p)+len(q)-1)
    for i,a in enumerate(p):
        for j,b in enumerate(q):r[i+j]+=a*b
    return tr(r)
def peval(p,x):
    v=F(0)
    for a in reversed(p):v=v*x+a
    return v

def pd(p):return tr([i*p[i] for i in range(1,len(p))] or [0])
def rem(p,q):
    p=tr(p);q=tr(q)
    while len(p)>=len(q) and p!=[0]:
        c=p[-1]/q[-1];s=len(p)-len(q)
        for i,v in enumerate(q):p[s+i]-=c*v
        p=tr(p)
    return p

def sturm(p):
    p=tr(p);r=[p,pd(p)]
    if r[-1]==[0]:return r[:1]
    while True:
        z=[-v for v in rem(r[-2],r[-1])]
        if z==[0]:return r
        r.append(z)
def sgn(v):return (v>0)-(v<0)
def side(p,x,direction):
    k=0;p=tr(p)
    while p!=[0]:
        v=peval(p,x)
        if v:return sgn(v)*(direction if k%2 else 1)
        p=pd(p);k+=1
    return 0

def V(seq,x,direction):
    signs=[side(p,x,direction) for p in seq];signs=[s for s in signs if s]
    return sum(a!=b for a,b in zip(signs,signs[1:]))
def nr(p,a,b):return V(sturm(p),a,1)-V(sturm(p),b,-1)

def hard(h,boxes,pts,n):
    pts=[tuple(map(F,p)) for p in pts]
    breaks=sorted({F(1),F(2)}|{2*abs(x-y) for b,pt in zip(boxes,pts) for x,ab in zip(pt,box(b['bounds'])) for y in ab if 1<2*abs(x-y)<2})
    check(breaks==list(map(F,h['physical_breakpoints'])),'hard:physical arrangement')
    check(len(h['intervals'])==len(breaks)-1,'hard:interval count')
    polys=[]
    for i,(a,b,r) in enumerate(zip(breaks,breaks[1:],h['intervals'])):
        u=(3*a+b)/4;v=(a+3*b)/4;p=[F(0)]
        for src,pt in zip(boxes,pts):
            term=[F(src['density'])]
            for x,(lo,hi) in zip(pt,box(src['bounds'])):
                p0=ov(x,lo,hi,u);p1=ov(x,lo,hi,v);s=(p1-p0)/(v-u)
                term=pmul(term,[p0-s*u,s])
            p=padd(p,term)
        q=padd(p,[0]*n+[-1]);polys.append(q)
        check(p==tr(r['numerator']) and q==tr(r['difference']),'hard:independent overlap polynomial')
        check(nr(q,a,b)==r['open_roots'],'hard:independent Sturm root count')
        check(peval(q,F(r['witness_point']))==F(r['witness_difference']),'hard:witness residual')
    hit=h['first_contact'];i=hit['interval_index'];lo,hi=map(F,hit['bracket']);p=polys[i]
    check(breaks[i]<=lo<=hi<=breaks[i+1],'hard:first root enclosure')
    for j in range(i):
        check(nr(polys[j],breaks[j],breaks[j+1])==0 and peval(polys[j],breaks[j])<0 and peval(polys[j],(breaks[j]+breaks[j+1])/2)<0,'hard:complete negative prefix')
    check(nr(p,breaks[i],lo)==0 if lo>breaks[i] else True,'hard:root prefix within cell')
    check((peval(p,lo)==0 if lo==hi else nr(p,lo,hi)==1),'hard:isolated contact')
    check(side(p,lo,-1)<0 and side(p,hi,1)>0,'hard:strict first crossing signs')
    check(cap(boxes,pts,F(1))==F(h['anchor_average']),'hard:anchor direct mass')



BITS=60;S=1<<BITS;Z=1<<24
@lru_cache(None)
def expminus(x):
    x=F(x);check(x>=0,'exp:nonnegative argument')
    k=0
    while x>F(1,2):x/=2;k+=1
    # 80-bit outward basic-integer arithmetic on alternating Taylor terms.
    # The 25th odd partial sum is below exp(-x); the 24th even sum is above.
    # Independent of the author's positive-exp series and inversion route.
    P=1<<80;vl=x.numerator*P//x.denominator;vu=-(-x.numerator*P//x.denominator)
    tl=tu=P;sl=su=P;even_upper=P
    for j in range(1,26):
        tl=tl*vl//(P*j);tu=-(-tu*vu//(P*j))
        if j%2:sl-=tu;su-=tl
        else:sl+=tl;su+=tu;even_upper=su
    l,u=sl,even_upper
    check(0<l<=u,'exp:alternating enclosure')
    for _ in range(k):l=l*l//P;u=-(-u*u//P)
    return F(l,P),F(u,P)
@lru_cache(None)
def phi_at(zi,nt):
    z=F(zi,Z);lower=upper=F(0)
    for j in range(1,nt+1):
        t=F(j,nt)
        if z<=F(1,2):
            a,b=expminus((F(1,2)-z)/t),expminus((F(1,2)+z)/t)
            l,u=t*(2-a[1]-b[1]),t*(2-a[0]-b[0])
        else:
            a,b=expminus((z-F(1,2))/t),expminus((z+F(1,2))/t)
            l,u=max(F(0),t*(a[0]-b[1])),t*(a[1]-b[0])
        if j<nt:lower+=l/nt
        upper+=u/nt
    return lower,upper

def phi(z,nt):
    z=abs(F(z));l=z.numerator*Z//z.denominator;u=-(-z.numerator*Z//z.denominator)
    return phi_at(u,nt)[0],phi_at(l,nt)[1]
@lru_cache(None)
def coord(a,b,u,v,lo,hi,ny,nt):
    width=b-a;lower=upper=F(0)
    for j in range(ny):
        left=a+width*F(j,ny);right=a+width*F(j+1,ny)
        nearest=max(F(0),left-v,u-right)
        farthest=max(abs(u-right),abs(v-left))
        lower+=phi(farthest/lo,nt)[0];upper+=phi(nearest/hi,nt)[1]
    return width*lower/(ny*hi),width*upper/(ny*lo)

def smooth(boxes,receiver,lo,hi,ny,nt,parts=None):
    low=up=F(0)
    for i,src in enumerate(boxes):
        factors=[coord(a,b,u,v,lo,hi,ny,nt) for (a,b),(u,v) in zip(box(src['bounds']),receiver)]
        if parts is not None:
            for f,p in zip(factors,parts[i]['coordinate_intervals']):check(F(p[0])<=f[0]<=f[1]<=F(p[1]),'smooth:independent scalar enclosure')
        low+=F(src['density'])*math.prod(f[0] for f in factors)
        up+=F(src['density'])*math.prod(f[1] for f in factors)
    return low,up



def receiver(c,boxes,n):
    r=box(c['receiver']);check(vol(r)==F(c['volume']),'receiver:physical dx volume')
    for upper,key in [(True,'upper'),(False,'lower')]:
        pts=[]
        for src in boxes:
            pt=[]
            for (a,b),(u,v) in zip(box(src['bounds']),r):
                center=(a+b)/2;pt.append(min(max(center,u),v) if upper else (u if abs(u-center)>=abs(v-center) else v))
            pts.append(pt)
        check(pts==[list(map(F,p)) for p in c[key+'_envelope_points']],'hard:receiver uniform envelope points')
        hard(c[key+'_hard_certificate'],boxes,pts,n)
    lo,hi=map(F,c['Lstar_interval']);check(1<lo<=hi<2,'receiver:window bracket')
    check(lo==F(c['upper_hard_certificate']['first_contact']['bracket'][0]) and hi==F(c['lower_hard_certificate']['first_contact']['bracket'][1]),'receiver:uniform bracket direction')
    check(F(c['anchor_upper'])==cap(boxes,[tuple(map(F,p)) for p in c['upper_envelope_points']],F(1))<F(1,2),'receiver:strict anchor gate')
    w=F(c['strict_witness_scale']);strict=cap(boxes,[tuple(map(F,p)) for p in c['lower_envelope_points']],w)/w**n
    check(strict==F(c['strict_witness_lower']) and strict>1 and hi<w<=2,'receiver:uniform strict witness')
    primary=boxes[0];mass=F(primary['density'])*vol(box(primary['bounds']))
    extra=sum(F(src['density'])*vol(box(src['bounds'])) for src in boxes[1:]);width=max(v-u for u,v in box(primary['bounds']))
    check(extra<lo**n and hi**n<mass,'hard:primary partial capture at every root')
    lower=F(1,2)/width-F(n)/lo-extra/(2*width*lo**n)
    saved=c['uniform_derivative'];check(lower==F(saved['derivative_A_at_root_lower']) and lower>0,'hard:root derivative lower reconstruction')
    check(F(saved['primary_mass'])==mass and F(saved['extra_mass'])==extra and F(saved['max_primary_width'])==width,'hard:root derivative inputs')
    ny,nt=c['source_Riemann_count'],c['t_Riemann_count'];sel=smooth(boxes,r,lo,hi,ny,nt,c['selected_P']['components'])
    pl,pu=map(F,c['selected_P']['interval']);check(pl<=sel[0]<=sel[1]<=pu,'smooth:selected interval enclosure')
    window=c['window_scale_intervals'];check(F(window[0]['scale_interval'][0])==1 and F(window[-1]['scale_interval'][1])==2,'smooth:full continuous window endpoints')
    for j,x in enumerate(window):
        a,b=map(F,x['scale_interval'])
        check(a<b and (not j or a==F(window[j-1]['scale_interval'][1])),'smooth:continuous window coverage')
        check(smooth(boxes,r,a,b,ny,nt)[1]<=F(x['upper']),'smooth:whole scale-cell enclosure')
    pmax=max(F(x['upper']) for x in window);check(pmax==F(c['whole_window_P_upper']) and pmax<=F(1,2),'smooth:entire original upper gate')
    m,M=c['phi_half_interval'],c['phi_zero_interval']
    for z,v in [(F(1,2),m),(F(0),M)]:
        l,u=phi(z,nt);check(F(v[0])<=l<=u<=F(v[1]),'smooth:kernel endpoint enclosure')
    mid=F(1,2)*F(m[1])*F(M[1])**(n-1)
    check(mid==F(c['original_middle_threshold_upper']) and pl>mid,'smooth:original R82 middle qualification')
    j=c['kappa_layer'];threshold=c['kappa_thresholds'][j]
    for a,k in [((1<<(j+1))-1,'lower_P_threshold'),((1<<j)-1,'upper_P_threshold')]:
        l,u=expminus(F(a));v=threshold[k];check(F(v[0])<=l/2<=u/2<=F(v[1]),'smooth:kappa exponential threshold')
    check(pl>F(threshold['lower_P_threshold'][1]) and pu<=F(threshold['upper_P_threshold'][0]),'smooth:common original kappa stratum')

def network(rows,bins,key,K):
    m=len(rows);N=len(bins);sink=m+N+1;total=sum(F(r['demand']) for r in rows)
    den=1
    for v in [F(r['demand']) for r in rows]+[K*F(b['mass']) for b in bins]:den=math.lcm(den,v.denominator)
    inf=int(total*den)+1;caps={}
    for i,r in enumerate(rows):
        caps[0,i+1]=int(F(r['demand'])*den)
        for j in range(N):
            if r[key]>>j&1:caps[i+1,m+j+1]=inf
    for j,b in enumerate(bins):caps[m+j+1,sink]=int(K*F(b['mass'])*den)
    return caps,den,sink,total

def own_flow(caps,sink):
    # Independent integer Edmonds-Karp, rather than author's Dinic density loop.
    adj=[[] for _ in range(sink+1)];res={}
    for (a,b),v in caps.items():adj[a].append(b);adj[b].append(a);res[a,b]=v;res[b,a]=0
    value=0
    while True:
        prev={0:None};q=deque([0])
        while q and sink not in prev:
            a=q.popleft()
            for b in adj[a]:
                if b not in prev and res[a,b]>0:prev[b]=a;q.append(b)
        if sink not in prev:break
        v=sink;delta=None
        while prev[v] is not None:
            a=prev[v];delta=res[a,v] if delta is None else min(delta,res[a,v]);v=a
        v=sink
        while prev[v] is not None:
            a=prev[v];res[a,v]-=delta;res[v,a]+=delta;v=a
        value+=delta
    co={sink};q=deque([sink])
    while q:
        b=q.popleft()
        for a in adj[b]:
            if a not in co and res[a,b]>0:co.add(a);q.append(a)
    return value,res,co

def graph_certificate(graph,rows,bins,key,verify_saved):
    K=F(graph['K']);caps,den,sink,total=network(rows,bins,key,K);m=len(rows)
    maximal=graph['maximal_maximizer_receiver_mask'];union=0;d=F(0)
    for i,r in enumerate(rows):
        if maximal>>i&1:union|=r[key];d+=F(r['demand'])
    mass=sum(F(b['mass']) for j,b in enumerate(bins) if union>>j&1)
    check(0<maximal<(1<<m) and union==graph['maximal_maximizer_source_mask'],'Hall:maximal cut actual union')
    check(d==F(graph['maximal_cut_demand']) and mass==F(graph['maximal_cut_source_mass']) and d==K*mass,'Hall:exact optimal lower witness')
    value,res,co=own_flow(caps,sink)
    check(F(value,den)==total,'Hall:independent exact feasible flow at K')
    largest=sum(1<<i for i in range(m) if i+1 not in co)
    check(largest==maximal,'Hall:independent union of all tight cuts')
    # Final feasible flow plus tight cut proves every receiver-subset Hall bound,
    # without sampling or assuming a solver's optimality status.
    if verify_saved:
        flow=graph['flow'];check(flow is not None,'flow:saved upper witness')
        check(flow['integer_denominator']==den,'flow:integer scale')
        bal=[F(0)]*(sink+1);seen=set()
        for arc in flow['positive_arcs']:
            a,b=arc['tail'],arc['head'];v=F(arc['flow']);cap0=F(arc['capacity'])
            check((a,b) in caps and (a,b) not in seen and 0<v<=cap0==F(caps[a,b],den),'flow:physical supported exact capacity')
            seen.add((a,b));bal[a]-=v;bal[b]+=v
        check(bal[0]==-total and bal[sink]==total and all(x==0 for x in bal[1:sink]),'flow:one source conservation saturation')
        check(F(flow['total'])==F(flow['cut_capacity'])==total and F(flow['required'])==total,'flow:saved total equality')
    return K

def masks_and_flow(case):
    inp=case['input'];boxes=inp['boxes'];n=inp['n'];m=inp['source_partition_per_axis'];bins=case['source_bins'];i=0
    for k,src in enumerate(boxes):
        for idx in product(range(m),repeat=n):
            b=tuple((a+(z-a)*F(j,m),a+(z-a)*F(j+1,m)) for (a,z),j in zip(box(src['bounds']),idx));p=F(src['density'])*vol(b)
            check(box(bins[i]['bounds'])==b and F(bins[i]['mass'])==p and bins[i]['component']==k,'source:complete physical partition');i+=1
    check(i==len(bins) and sum(F(b['mass']) for b in bins)==F(inp['W']),'source:actual additive mass')
    certs={tuple(map(tuple,c['receiver'])):c for c in case['qualified_receivers']}
    accepted=[box(c['receiver']) for c in case['qualified_receivers']]
    rejected=[box(c['receiver']) for c in case['unqualified_cells']]
    requested=[box(r) for r in inp['receiver_boxes']]
    allcells=accepted+rejected
    for j,a in enumerate(allcells):
        check(vol(a)>0 and any(all(u>=w and v<=z for (u,v),(w,z) in zip(a,b)) for b in requested),'receiver:each subcell in requested physical domain')
        for b in allcells[:j]:check(any(min(v,z)<=max(u,w) for (u,v),(w,z) in zip(a,b)),'receiver:disjoint accepted rejected dx cells')
    check(sum(map(vol,allcells))==sum(map(vol,requested))==F(case['requested_receiver_volume']),'receiver:complete requested domain partition')
    check(sum(map(vol,accepted))==F(case['qualified_receiver_volume']),'receiver:only qualified physical demand counted')
    seen=[]
    for stratum in case['strata']:
        rows=stratum['rows'];layer=stratum['kappa_layer']
        for row in rows:
            r=box(row['receiver']);lo,hi=map(F,row['Lstar_interval']);inner=tuple((v-lo/2,u+lo/2) for u,v in r);outer=tuple((u-hi/2,v+hi/2) for u,v in r)
            c=certs[tuple(map(tuple,row['receiver']))];seen.append(tuple(map(tuple,row['receiver'])))
            check(r==box(c['receiver']) and F(row['demand'])==vol(r) and F(row['volume'])==vol(r),'Hall:actual receiver dx demand')
            check(row['kappa_layer']==layer==c['kappa_layer'],'Hall:original stratum')
            primary=boxes[0];mass=F(primary['density'])*vol(box(primary['bounds']))
            extra=sum(F(b['density'])*vol(box(b['bounds'])) for b in boxes[1:]);frac=(lo**n-extra)/mass
            rootbox=[]
            for (a,b),(u,v) in zip(box(primary['bounds']),r):
                depth=min(F(1),frac)*(b-a)
                if v<a:rootbox.append((a,a+depth))
                elif u>b:rootbox.append((b-depth,b))
                else:
                    check(lo/2>=max(abs(x-y) for x in (u,v) for y in (a,b)),'Hall:inside projection uniformly full coordinate')
                    rootbox.append((a,b))
            rootbox=tuple(rootbox)
            check(frac==F(row['primary_capture_fraction_lower']) and frac>0 and rootbox==box(row['primary_root_mass_capture_box']),'Hall:root-mass uniform captured corner')
            check(inner==box(row['guaranteed_capture_box']) and outer==box(row['possible_capture_box']),'Hall:uniform physical boxes')
            im=om=0
            for j,b in enumerate(bins):
                bb=box(b['bounds'])
                ordinary=all(u>=a and v<=z for (u,v),(a,z) in zip(bb,inner))
                corner=b['component']==0 and all(u>=a and v<=z for (u,v),(a,z) in zip(bb,rootbox))
                if ordinary or corner:im|=1<<j
                if all(min(v,z)>max(u,a) for (u,v),(a,z) in zip(bb,outer)):om|=1<<j
            check(im==row['inner_source_mask'] and om==row['outer_source_mask'] and im&om==im,'Hall:independent inner outer source masks')
            center=tuple((u+v)/2 for u,v in r);hard(row['midpoint_receiver_hard_certificate'],boxes,[center]*len(boxes),n)
        ki=graph_certificate(stratum['inner_Hall'],rows,bins,'inner_source_mask',True)
        ko=graph_certificate(stratum['outer_Hall'],rows,bins,'outer_source_mask',True)
        check(ko<=ki and list(map(F,stratum['continuum_K_interval']))==[ko,ki],'Hall:rigorous continuum bracket direction')
        for j,b in enumerate(bins):
            lower=sum(F(r['volume'])/F(r['Lstar_interval'][1])**n for r in rows if r['inner_source_mask']>>j&1)
            upper=sum(F(r['volume'])/F(r['Lstar_interval'][0])**n for r in rows if r['outer_source_mask']>>j&1)
            saved=stratum['canonical_source_intervals'][j]
            check(saved['source_bin']==j and F(saved['interval'][0])<=lower<=upper<=F(saved['interval'][1]),'source:canonical actual column enclosure')
        maximum=[max(F(c['interval'][0]) for c in stratum['canonical_source_intervals']),max(F(c['interval'][1]) for c in stratum['canonical_source_intervals'])]
        check(maximum==list(map(F,stratum['canonical_essential_max_interval'])),'source:canonical essential maximum enclosure')
        if maximum[0]>ki:print('Certified prescribed-versus-optimized gap:',inp['label'])
        check(F(stratum['burden_D_over_W'])==sum(F(r['demand']) for r in rows)/F(inp['W']),'Hall:actual global burden normalization')
    check(len(seen)==len(certs) and len(set(seen))==len(seen),'Hall:all accepted receiver rows exactly once')


def finite_transfer_checks():
    # Fixed finite probability curves and countable-cover finite analogues.
    # No claimed cube state map, independence, or mesh-uniform reconstruction.
    for N in [3,8,32]:
        p0=[F(i+1) for i in range(N)];p1=list(reversed(p0));z=sum(p0);p0=[v/z for v in p0];p1=[v/z for v in p1]
        dp=[b-a for a,b in zip(p0,p1)];groups=[[i for i in range(N) if i%3==g] for g in range(min(3,N))]
        for t in [F(0),F(1,4),F(1,2),F(1)]:
            p=[a+t*d for a,d in zip(p0,dp)]
            Ip=sum(d*d/v for d,v in zip(dp,p));Iq=loss=F(0)
            for ids in groups:
                q=sum(p[i] for i in ids);dq=sum(dp[i] for i in ids);Iq+=dq*dq/q
                loss+=sum(p[i]*(dp[i]/p[i]-dq/q)**2 for i in ids)
            check(Ip-Iq==loss>=0,'Fisher:fixed coarsening exact information loss')
            check(sum(abs(d) for d in dp)**2<=Ip,'Fisher:pointwise variation Cauchy bound')
        Zp=sum(max(a,b) for a,b in zip(p0,p1));TV=sum(abs(d) for d in dp)
        check(Zp==1+TV/2,'Fisher:linear curve positive variation envelope')
        q0=[sum(p0[i] for i in ids) for ids in groups];q1=[sum(p1[i] for i in ids) for ids in groups]
        cz=[sum(max(p0[i]/a,p1[i]/b) for i in ids) for ids,a,b in zip(groups,q0,q1)]
        Zq=sum(max(a,b) for a,b in zip(q0,q1))
        check(Zq<=Zp<=sum(c*max(a,b) for c,a,b in zip(cz,q0,q1)),'Fisher:exact conditional fibre reconstruction')
        # Cover inherited source columns; three generic source labels.
        weights=[F(i+1,N*N) for i in range(N)]
        patches=[(F(1,2),set(range(N))),(F(1,2),set(range(N)))]
        patches.extend((F(1,3),{i}) for i in range(N))
        for y in range(3):
            capture=[(i+y)%3!=0 for i in range(N)]
            b=sum(w for w,yes in zip(weights,capture) if yes)
            summed=sum(alpha*sum(weights[i] for i in ids if capture[i]) for alpha,ids in patches)
            check(summed>=b,'cover:shared captured column inheritance')
        # Dyadic asymmetric scale enclosures decrease pairwise, including
        # an exact boundary pair; finite algebra mirrors the analytic DCT.
        for L in [F(5,4),F(4,3),F(7,4)]:
            for radius in [L/2,F(1,2),F(7,8)]:
                prev=None
                for depth in [1,2,4,8]:
                    grid=1<<depth;k=(L-1)*grid;k=k.numerator//k.denominator
                    lo=1+F(k,grid);hi=min(F(2),lo+F(1,grid))
                    value=lo**(-2) if radius<=hi/2 else F(0)
                    actual=L**(-2) if radius<=L/2 else F(0)
                    check(value>=actual and (prev is None or value<=prev),'cover:nested local-scale enclosure')
                    prev=value

EXPECTED={'hall_probe.py':'222937b0ad241c339a7aeb6205a4553f98d312317d7542103cbd971cd3523914','hall_results.json':'c521dea8ec45663b34851350a7d510821df8eeabf65bdf35556de92729ef39ec'}
def main():
    start=time.monotonic();scalar_checks();finite_transfer_checks()
    if EXPECTED:
        for name,h in EXPECTED.items():check(hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==h,'bytes:frozen '+name)
        data=json.loads((ROOT/'hall_results.json').read_text());check(data['schema']=='R85-broad-actual-L1-certified-Hall-v1','schema:actual L1 model')
        counts=data['counts']
        check(counts==dict(cases=len(data['cases']),qualified_receiver_cells=sum(len(c['qualified_receivers']) for c in data['cases']),unqualified_cells=sum(len(c['unqualified_cells']) for c in data['cases']),strata=sum(len(c['strata']) for c in data['cases']),source_bins=sum(len(c['source_bins']) for c in data['cases'])),'schema:actual counts')
        for c in data['cases']:
            for r in c['qualified_receivers']:receiver(r,c['input']['boxes'],c['input']['n'])
            masks_and_flow(c)
    print('PASS R85 independent public audit',json.dumps(COUNTS,sort_keys=True),'elapsed',round(time.monotonic()-start,6))
    print('Scope: finite continuum certificates; midpoint moments/stops diagnostic; general square-root bound UNPROVED.')
if __name__=='__main__':main()
```
