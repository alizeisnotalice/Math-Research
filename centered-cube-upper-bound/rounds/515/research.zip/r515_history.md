# R515 必要来源与复现

起始专用仓库 /Users/zhengzhihao/Math-Research-centered-cube-work，main 44c25b272723e36cdb72f57c88068a7dc8b8417e，status干净。R514已有新来源预算并推送，上一轮分类为进展。

沿[R514](https://github.com/alizeisnotalice/Math-Research/tree/main/centered-cube-upper-bound/rounds/514)及R513连续窗/原逐父支配。主代理提出一次带放宽不需EX、保原t、相对score吸收和任意输入有限公共网格覆盖；Astra high量化真实首达区间，Sol high独立审方向和最终论证，Sol medium完成数值探路。各自/tmp文件，只有主代理改仓库。

本轮查阅64项工具A02的SKILL及来源状态说明，按集合与目标关系分开核验：扩大动作域不自动保持极值性，故本轮不用其EX，只用直接score比较。未引入或认证A02外部优化文献定理。证明使用连续核、Tonelli、Cauchy、非负/支配收敛及真实中心体积。先前M03的通用稳定性缺口仍未填补。

实际本机数学解释器 /Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python；数值脚本记录Python与依赖版本。geometry为Fraction/SymPy精确检查；numeric为SciPy积分、求根与加密探路，quad报错估计不是严格误差包络。审查PRE另有符号与Arb量词诊断，不能当一般目标证据。MATLAB本轮未运行，未安装工具，未编译PDF。

复现提取geometry正文Python代码、隔离执行numeric，输出和JSON比较只排顶层seconds运行时间（具体实际比对规则见replay）。浮点结果可复现不提升为严格证书；有限模型不会提供统一维数或任意L1覆盖率。归档解压重放及SHA清单另核。
