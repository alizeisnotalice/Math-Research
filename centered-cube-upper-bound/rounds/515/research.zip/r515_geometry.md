# R515：一次放宽后的相对 score 首达区间与真实壳账

本轮在原固定场上构造了真实正宽度的可用动作区间，消除了 r=1 原带单点纤维的障碍。替代只需一次辅助带 [q/2,2λ]，不重取极值、不用 EX。相对 score 门使质量增量阈值随原 score 调整；薄区间的坏中心交叉 score 可准确变成同一 μ 的首达壳费用，小 score 分母完全抵消。尚未证明该壳列的多对数/收缩预算，也未把共同对数半径覆盖的线性 n 费用降为多对数。

## 1. 固定原场；只把辅助动作带放宽一次

保持 R513/R514 的真实 μ、E、a≤R_B≤b≤2a、m_B=q_BR_B^n、q≤q_B≤λ、r=λ/q 固定，以及统一 S 的 raw 场

\[
k_B=S R_B^{-n}1_{Q_B}(y)1_{[\log_\gamma m_B,\log_\gamma m_B+1]}(\sigma),
\quad L=\int_E k_BdB,\quad Q=\|L\|^2.
\]

原场满足 0≤L≤C，C=S[1+log(γr)]。本稿无需 L 为极值。令 ψ_B=〈L,k_B〉，X=∫E q_BdB。已有

\[
0\le\psi_B\le CSq_B,\qquad\int_E\psi_BdB=Q.
\]

辅助动作 R∈[a,b] 允许密度在 [q/2,2λ]，其核仍使用真实 μQ(B,R) 的连续窗，不沿用旧质量标签。任何这样的混合平均场有帽

\[
C'=S[1+\log(4\gamma r)].\tag{1}
\]

只有辅助场帽改变；score 始终与原 L 内积。旧来源、history、gate 不重生成，最终只通过 raw 平方的旧桥回代。

## 2. 相对 score 允许的整个首达区间

固定 0<θ<1，记

\[
\alpha_B=\frac{\psi_B}{CSq_B}\in[0,1],\quad
h_0=-\log(1-\theta/2)<\log2,\quad
c=\min\{1,\theta\log\gamma/2\}.
\]

只需覆盖 α_B>0 的中心；α_B=0 对 Q 的贡献恰为零。对正 score 中心定义实际质量阈值

\[
u_B=c\alpha_B\in(0,1],\qquad
T_B=\sup\{R\in[R_B,b]:\mu Q(B,R)\le(1+u_B)m_B\}.
\tag{2}
\]

式(2)中的变量为 u_B（即 cα_B）；它是实际质量增量比，不是几何壳体积。μ 为 L1 密度，立方体边界 μ 零，故径向质量连续且非减。于是若 R_B<b，T_B>R_B；若 T_B<b，则

\[
\mu Q(B,T_B)=(1+u_B)m_B.\tag{3}
\]

可测性可由有理半径超水平集得到。定义

\[
U_B=\min\{e^{h_0/n}R_B,b,T_B\},\qquad J_B=[R_B,U_B].\tag{4}
\]

**命题。** 对每个 R'∈J_B，辅助动作都位于一次放宽带，且

\[
\psi(B,R')\ge(1-\theta)\psi_B.\tag{5}
\]

证明：写 g=(R'/R_B)^n、δ=[μQ(B,R')−m_B]/m_B。有 1≤g≤e^{h₀}<2、0≤δ≤u_B≤1，因此

\[
\frac{q_B}{2}\le q'=q_B\frac{1+\delta}{g}\le2q_B,
\]

确在 [q/2,2λ]。由 R513 的单边嵌套 score 恒等式与原帽 C，

\[
\psi_B-\psi(B,R')
\le(1-g^{-1})\psi_B+CSq_Bg^{-1}\tau,
\quad\tau=\min\{\log_\gamma(1+\delta),1\}.
\]

这里新增来源的正贡献不收费。由于

\[
1-g^{-1}\le\theta/2,\qquad
\tau\le\frac{u_B}{\log\gamma}
=\frac{c\alpha_B}{\log\gamma}\le\theta\alpha_B/2,
\]

右边不超过 θψ_B。证明结束。该论证保留全部集中壳质量；没有把其大小换成薄壳体积。

体积变量的允许上限 h₀ 是固定常数，不随 α_B 缩小；只有真实质量首达阈值 u_B 随 α_B 调整。这比同时把几何步长缩到 α_B 量级更省。

端点 R_B=b 时 J_B={b}，直接保原动作即可，score 完全相同。R_B<b 且 ψ_B>0 时 J_B 有正宽度，所以 R514 中由原带导致的单点纤维确被这一次放宽消除。但正宽度尚无输入无关的下界。

## 3. 一个实际共同覆盖测度，以及全部未覆盖中心

置 x(R)=nlog(R/a)，T=nlog(b/a)。固定 0<h≤h₀，采用中心无关有限测度

\[
\rho_h(dR)=\frac{n}{h}\frac{dR}{R}+\delta_b(dR),
\qquad M_h=1+T/h.\tag{6}
\]

对每个 J_B，若 b∈J_B，端点原子已给覆盖质量 1；若 x(U_B)−x(R_B)≥h，连续部分也给至少 1。令 good 为这两类正 score 中心，其余正 score 中心记为 E_h。零 score 中心既不需覆盖，也不产生坏交叉项。

在 good 上将 ρ_h 条件化到 J_B，即得真实合法、满足相对门(5)且 π_B≤ρ_h 的辅助动作。R514 的一次来源付款仍成立，但场帽换为 C'：

\[
\|A_h\|^2\le C'SM_hW.\tag{7}
\]

该覆盖是具体构造，不需要极值存在或近最佳纤维的抽象选择。其缺点也明确：M_h=1+nlog(b/a)/h，当前仍线性于 n。没有把它称为多对数覆盖。

## 4. 薄区间坏交叉 score 的真实首达壳付款

若 B∈E_h，则 b 不在 J_B 且其 x 宽度<h≤h₀。因此造成截断的只能是实际质量首达 T_B，而非体积帽或 b 端点：

\[
R_B<T_B<e^{h/n}R_B,\quad T_B<b,\quad
\Delta_B:=\mu(Q(B,T_B)\setminus Q_B)=u_Bm_B=c\alpha_Bm_B.
\tag{8}
\]

定义保原大分母的真实壳列

\[
\Lambda_h(y)=\int_{E_h}R_B^{-n}
1_{Q(B,T_B)\setminus Q_B}(y)\,dB.
\tag{9}
\]

坏交叉 score 不是坏场自身平方。准确地，

\[
\begin{aligned}
\mathcal E_h:=\langle L,L_{E_h}\rangle
&=\int_{E_h}\psi_BdB=CS\int_{E_h}\alpha_Bq_BdB\\
&=\boxed{\frac{CS}{c}\int\Lambda_h(y)d\mu(y).}
\end{aligned}\tag{10}
\]

最后一步是(8)与 Tonelli。这里无需除以小 α_B：质量阈值 u_B=cα_B 与 score 权重精确抵消，费用系数仅依赖 θ,γ,r,S。来源仍是一次 μ，不是 μ²；外壳来源是辅助 raw 估计里的真实 μ，不假称它是原接受记录中的某个既有来源。

式(10)保留了每个原 B、R_B、原大分母及其唯一实际首达半径。不能在固定 y 后重选父半径，也不能把 Q(B,T_B) 内的质量当成任意放大盒来源帽。首达半径自身确在一次放宽带内，但这不自动给列 Λ_h 一个维数无关上界。

## 5. 完整一步公式与真正剩余几何

相对 score 门和(7)给

\[
(1-\theta)(Q-\mathcal E_h)\le\langle L,A_h\rangle
\le\sqrt{Q}\sqrt{C'SM_hW}.
\]

因此

\[
\boxed{Q\le\frac{C'S}{(1-\theta)^2}
\left(1+\frac{n\log(b/a)}h\right)W
+\frac{2CS}{c}\int\Lambda_h\,d\mu.}\tag{11}
\]

这是当前所有中心的完整账，坏中心没有删除。可随真实输入把(6)换成更经济的共同区间覆盖测度；只要对保留中心的 J_B 覆盖至少 1，同一(7)与相对 score 回代成立。

但(11)尚非目标改进：共同对数测度的总覆盖费仍为线性 n，而真实首达壳列也没有独立多对数或严格收缩预算。需要继续证明的几何内容是：用原 score/来源交叠构造低代价的共同区间覆盖，或把覆盖不足的中心通过(10)的首达壳作一次来源结算，并且防止对相同来源在许多半径重复收费。仅知 T_B/R_B≤e^(h/n) 不能把 Λ_h 免费估成 O(h)，因为 R_B 对中心是既定但可变的 selector；其适应性仍须使用原 score 和首达条件共同处理。

本轮的实际进展是可用区间及端点的全覆盖结构、一次固定放宽的合法性、相对 score 控制，以及薄区间交叉 score 的精确来源转换。没有建立所需多对数 M，没有完成一般根阶预算。

原 t(B)≤S 的直接扩展：保持每中心核系数 t_B 不动，在 t_B>0 上用 α_B=ψ_B/(C t_Bq_B)，零系数单列；式(10)改为 (C/c)∫dμ∫_(E_h)t_BR_B^(-n)1_shell dB。相对 score 回代仍不需要极值或 X* 比较，本稿其余计算保持统一 S 版本。

## 6. 本机精确核验

实际使用本机 math-research-tools Python 的 Fraction/SymPy，核验相对 score 常数、一次放宽带、score/首达质量抵消、共同测度的区间与端点覆盖、二次回代。选 γ=exp(2)，故 logγ=2 精确，θ=1/2、c=1/2；不用浮点对数作证明。结果：`PASS 32 exact relative-score, widened-band, first-passage and coverage checks`。

```python
from fractions import Fraction as F
import sympy as sp
count=0
theta=F(1,2);c=F(1,2);g0=1/(1-theta/2)
for alpha in (F(1,8),F(1,2),F(1)):
 u=c*alpha
 for g in (F(1),F(7,6),g0):
  tau_bound=theta*alpha/2
  loss_bound=(1-1/g)*alpha+tau_bound/g
  assert loss_bound<=theta*alpha;count+=1
  assert F(1,2)<=(1+u)/g<=2;count+=1
 for mass in (F(1),F(3),F(7,2)):
  delta=u*mass
  assert alpha==delta/(c*mass);count+=1
T=F(3);h=F(1,4)
for start,end in ((F(0),h),(F(1),F(3,2)),(T-F(1,100),T),(T,T)):
 rho=(end-start)/h+(1 if end==T else 0)
 assert rho>=1;count+=1
z,a,e,d=sp.symbols('z a e d',nonnegative=True)
assert sp.expand((z-a)**2+2*(a*z+e-z*z))==a*a+2*e-z*z;count+=1
print('PASS',count,'exact relative-score, widened-band, first-passage and coverage checks')
```
