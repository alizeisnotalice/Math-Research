#!/usr/bin/env python3
"""R515 continuous B,C floating quadrature exploration; not a strict certificate."""
from pathlib import Path
from functools import lru_cache
import math,time,sys,platform,json
import numpy as np
import scipy
from scipy.integrate import quad
from scipy.optimize import brentq,minimize_scalar
import sympy as sp
ROOT=Path(__file__).resolve().parent
L=5/6;U=9/10;LOG4=math.log(4);MAXERR=0.;NQUAD=0

def Rold(B):return math.sqrt(12*(1-B*B))
def mass(B,R):return R*(B*B+R*R/12)
def breakpoints(B,R):
 out=[];m=mass(B,R)
 if 0<m<math.sqrt(12):
  c=math.sqrt(1-m*m/12)
  if L<c<U:out.append(c)
 for y in [B-R/2,B+R/2]:
  disc=12-3*y*y
  if disc>=0:
   for c in [(y-math.sqrt(disc))/4,(y+math.sqrt(disc))/4]:
    if L<c<U:out.append(c)
 return sorted(set(out))

def score_uncached(B,R,tight=False):
 global MAXERR,NQUAD
 m=mass(B,R)
 def f(C):
  Rc=Rold(C);lo=max(B-R/2,C-Rc/2);hi=min(B+R/2,C+Rc/2)
  mu=max(0.,(hi**3-lo**3)/3)
  ov=max(0.,1-abs(math.log(m/Rc))/LOG4)
  return mu*ov/(R*Rc)
 val,err=quad(f,L,U,points=breakpoints(B,R),epsabs=1e-13 if tight else 2e-11,epsrel=1e-11 if tight else 2e-9,limit=100)
 MAXERR=max(MAXERR,err);NQUAD+=1
 return val,err

@lru_cache(maxsize=None)
def score(B,R):return score_uncached(float(B),float(R))[0]
@lru_cache(maxsize=None)
def oldscore(B):return score(float(B),Rold(float(B)))

def positive_intervals(fun,points):
 points=sorted(set(points));vals=[fun(x) for x in points];roots=[]
 for a,b,fa,fb in zip(points,points[1:],vals,vals[1:]):
  if fa==0:roots.append(a)
  if fa*fb<0:roots.append(brentq(fun,a,b,xtol=1e-12,rtol=1e-12))
 if vals[-1]==0:roots.append(points[-1])
 cuts=sorted(set([points[0],points[-1],*roots]));regions=[]
 for a,b in zip(cuts,cuts[1:]):
  if fun((a+b)/2)>=0:regions.append((a,b))
 return regions

def radius_intervals(B,theta,Rmesh=33):
 points=list(np.linspace(1,2,Rmesh))+[Rold(B)]
 return positive_intervals(lambda R:score(B,float(R))-(1-theta)*oldscore(B),points)

def merge(intervals):
 out=[]
 for a,b in sorted(intervals):
  if out and a<=out[-1][1]+1e-12:out[-1]=(out[-1][0],max(b,out[-1][1]))
  else:out.append((a,b))
 return out

def complement(intervals):
 out=[];x=L
 for a,b in intervals:
  if a>x:out.append((x,a))
  x=max(x,b)
 if x<U:out.append((x,U))
 return out

def weighted(regions):
 val=err=0.
 for a,b in regions:
  z,e=quad(oldscore,a,b,epsabs=2e-11,epsrel=2e-9,limit=80)
  val+=z;err+=e
 return val,err

def grid_report(theta,K,Bmesh):
 radii=list(np.linspace(1,2,K+1));hits=[];allregions=[]
 for R in radii:
  points=list(np.linspace(L,U,Bmesh))
  c=math.sqrt(1-R*R/12)
  if L<c<U:points.append(c)
  regions=positive_intervals(lambda B:score(float(B),float(R))-(1-theta)*oldscore(float(B)),points)
  hits.append({'R':float(R),'B_hit_intervals':regions});allregions.extend(regions)
 cover=merge(allregions);bad=complement(cover);badscore,baderr=weighted(bad)
 cuts=sorted(set([L,U,*[x for z in hits for ab in z['B_hit_intervals'] for x in ab]]));counts=[]
 for a,b in zip(cuts,cuts[1:]):
  x=(a+b)/2;counts.append(sum(any(lo-1e-13<=x<=hi+1e-13 for lo,hi in z['B_hit_intervals']) for z in hits))
 goodcounts=[c for c in counts if c>0]
 return {'theta':theta,'K_subintervals':K,'common_radius_count':K+1,'B_search_mesh':Bmesh,'radii_hit_regions':hits,'covered_B_intervals':cover,'bad_B_intervals':bad,'bad_B_measure':sum(b-a for a,b in bad),'bad_score_integral':badscore,'bad_score_outer_quad_error_estimate':baderr,'minimum_hit_probability_over_all_B':min(counts)/(K+1) if counts else 0.,'minimum_positive_hit_probability_on_covered_B':min(goodcounts)/(K+1) if goodcounts else 0.,'M_on_covered_B':(K+1)/min(goodcounts) if goodcounts else None,'uniform_radius_mean_hit_probability':sum(b-a for z in hits for a,b in z['B_hit_intervals'])/((K+1)*(U-L))}

def width_report(theta):
 def width(B):return sum(b-a for a,b in radius_intervals(float(B),theta))
 xs=np.linspace(L,U,33);ws=[width(x) for x in xs];i=int(np.argmin(ws))
 a=xs[max(0,i-1)];b=xs[min(len(xs)-1,i+1)]
 opt=minimize_scalar(width,bounds=(a,b),method='bounded',options={'xatol':2e-10}) if a<b else None
 cand=[(float(xs[i]),ws[i]),(L,width(L)),(U,width(U))]
 if opt is not None:cand.append((float(opt.x),float(opt.fun)))
 x,w=min(cand,key=lambda z:z[1]);integ,err=quad(width,L,U,epsabs=2e-8,epsrel=2e-6,limit=60)
 return {'theta':theta,'width_grid_B':list(map(float,xs)),'width_grid_values':ws,'located_minimum_B':x,'located_minimum_width':w,'minimum_search_scope':'33-node bracket plus bounded scalar minimizer; no global certified minimum','mean_near_score_radius_width':integ/(U-L),'width_outer_quad_error_estimate':err,'uniform_grid_sufficient_K_from_located_width_not_certified':math.ceil(1/w) if w>0 else None,'radius_intervals_at_located_minimum':radius_intervals(x,theta)}

def main():
 start=time.perf_counter();B,R=sp.symbols('B R',real=True);m=sp.integrate(sp.Symbol('x')**2,(sp.Symbol('x'),B-R/2,B+R/2))
 assert sp.expand(m-R*(B*B+R*R/12))==0
 assert sp.Rational(1,2)<sp.Rational(7,9) and sp.Rational(343,300)<2
 Qold,Qerr=weighted([(L,U)])
 print('OLD Q',Qold,'outer_err',Qerr,flush=True)
 widths=[];coarse=[];fine=[]
 for theta in [.1,.01,.001]:
  w=width_report(theta);widths.append(w)
  print('WIDTH',theta,w['located_minimum_width'],'B',w['located_minimum_B'],flush=True)
  for K in [8,16,32]:
   z=grid_report(theta,K,17);z['bad_score_fraction_Q']=z['bad_score_integral']/Qold;coarse.append(z)
   print('COARSE',theta,K,'bad/Q',z['bad_score_fraction_Q'],'M',z['M_on_covered_B'],flush=True)
 # High density of B bracketing, plus a finer radius grid; only existing theta cases.
 for theta in [.1,.01,.001]:
  for K in [32,64]:
   z=grid_report(theta,K,65);z['bad_score_fraction_Q']=z['bad_score_integral']/Qold;fine.append(z)
   print('FINE',theta,K,'bad/Q',z['bad_score_fraction_Q'],'M',z['M_on_covered_B'],flush=True)
 convergence=[]
 for theta in [.1,.01,.001]:
  a=next(z for z in coarse if z['theta']==theta and z['K_subintervals']==32)
  b=next(z for z in fine if z['theta']==theta and z['K_subintervals']==32)
  oldends=[x for z in a['radii_hit_regions'] for ab in z['B_hit_intervals'] for x in ab]
  newends=[x for z in b['radii_hit_regions'] for ab in z['B_hit_intervals'] for x in ab]
  convergence.append({'theta':theta,'same_interval_endpoint_count':len(oldends)==len(newends),'max_hit_region_endpoint_change_B17_to_B65':max((abs(x-y) for x,y in zip(oldends,newends)),default=0.) if len(oldends)==len(newends) else None,'bad_score_fraction_change':abs(a['bad_score_fraction_Q']-b['bad_score_fraction_Q'])})
 audit=[]
 for B0 in [L,(L+U)/2,U]:
  for R0 in [1.,Rold(B0),2.]:
   standard=score(B0,R0);tight,err=score_uncached(B0,R0,True)
   audit.append({'B':B0,'R':R0,'standard':standard,'tight':tight,'absolute_difference':abs(tight-standard),'tight_quad_error_estimate':err})
 def stationary_B(step):
  def slope(B0):
   r=Rold(B0);return (score(B0,r+step)-score(B0,r-step))/(2*step)
  return brentq(slope,L,U,xtol=1e-12)
 bstar1=stationary_B(1e-5);bstar=stationary_B(5e-6);rstar=Rold(bstar)
 def relgap(B0):return score(float(B0),rstar)/oldscore(float(B0))-1
 gx=np.linspace(L,U,65);gv=[relgap(x) for x in gx];ii=int(np.argmin(gv))
 go=minimize_scalar(relgap,bounds=(gx[max(0,ii-1)],gx[min(len(gx)-1,ii+1)]),method='bounded',options={'xatol':1e-12})
 singleton={'Rstar':rstar,'Bstar_from_score_radius_stationarity':bstar,'Rstar_step_refinement_difference':abs(Rold(bstar1)-rstar),'located_minimum_relative_score_gap':float(go.fun),'located_minimum_gap_B':float(go.x),'scope':'one common radius derived from this field; numerical tangency, no certified dominance','theta_reports':[]}
 for theta in [.1,.01,.001]:
  hit=positive_intervals(lambda B0:score(float(B0),rstar)-(1-theta)*oldscore(float(B0)),list(gx)+[bstar])
  bad=complement(hit);ev,ee=weighted(bad)
  singleton['theta_reports'].append({'theta':theta,'hit_B_intervals':hit,'bad_B_intervals':bad,'Ebad_score_fraction_Q':ev/Qold,'outer_quad_error_estimate':ee,'M_if_covered':1 if not bad else None})
 print('SINGLETON Rstar',rstar,'min relative gap',go.fun,'B',go.x,'theta Ebad/Q',[(z['theta'],z['Ebad_score_fraction_Q']) for z in singleton['theta_reports']],flush=True)
 result={'scope':'continuous real B,C floating quadrature/root exploration, not a strict/global certificate','environment':{'executable':sys.executable,'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__,'sympy':sp.__version__},'model':{'f':'x^2 1[-3,3]','W':18,'E_exact':['5/6','9/10'],'E_measure_exact':'1/15','a':1,'b':2,'density_range_on_full_candidate_rectangle_exact':['7/9','343/300'],'R_old_range_exact':['sqrt(57)/5','sqrt(33)/3'],'q':1,'lambda':1,'gamma':4,'S':1,'R_old':'sqrt(12(1-B^2))','mass':'R(B^2+R^2/12)','original_legal_set':'singleton R_old(B)','c':2,'expanded_density_band':[.5,2.],'expanded_legal_set':'entire R in [1,2]','near_score_gate':'psi(B,R)>=(1-theta)*psi(B,R_old(B))','old_L':'generated by common measurable original R_old over true Lebesgue E'},'Qold_continuous_integral':Qold,'Qold_outer_quad_error_estimate':Qerr,'original_band_finite_common_grid_score_coverage':'zero a.e.; any fixed R intersects unique R_old graph at at most one B','width_reports':widths,'coarse_grid_reports':coarse,'fine_grid_reports':fine,'one_common_stationary_radius_diagnostic':singleton,'B_mesh_convergence_at_K32':convergence,'tight_score_audits':audit,'max_inner_quad_error_estimate':MAXERR,'inner_quad_call_count':NQUAD,'seconds':time.perf_counter()-start,'error_scope':'quad error estimates are heuristic, not certified bounds; root-region search can miss unbracketed components; no atomization of B or C'}
 (ROOT/'r515_numeric.json').write_text(json.dumps(result,indent=2)+'\n');print('DONE continuous B/C exploration; no strict certificate',flush=True)
if __name__=='__main__':main()
