"""Exact directional-budget replay for 1D synthetic positive-measure boxes.

The partners Y are labelled uniform interval measures, with total lambda mass
one. Price eligibility is part of the fixture. These examples carry neither
the archived R814 receiver marginals nor an original geometric history.
"""

from collections import Counter
from dataclasses import dataclass
from fractions import Fraction as F

from sympy import Rational, expand, log


HALF = F(1, 2)
H = F(1, 32)
Z = F(0)


@dataclass(frozen=True)
class Partner:
    label: str
    lower: F
    upper: F
    mass: F
    widths: tuple[F, ...]


def overlap_mass(partner, width, direction):
    """Lambda mass in Q_w(z + w*e), with z = 0 and side length w."""
    left = max(partner.lower, width * (direction - HALF))
    right = min(partner.upper, width * (direction + HALF))
    overlap = max(Z, right - left)
    return partner.mass * overlap / (partner.upper - partner.lower)


def ratio_integral(length, left, right, total_left, total_right):
    """Integrate the quotient of two affine functions over an interval."""
    if total_left == 0:
        assert left == 0 and total_right > 0
        return length * right / total_right
    if total_right == 0:
        assert right == 0 and total_left > 0
        return length * left / total_left
    if total_left == total_right:
        return length * (left + right) / (2 * total_left)

    increment = total_right - total_left
    constant = (right - left) / increment
    log_coefficient = (left - constant * total_left) / increment
    return length * (
        constant
        + log_coefficient * log(Rational(total_right / total_left))
    )


def raw_fubini(partner, width):
    """Independent integration in q of |{e : q in Q_w(z + w*e)}|."""
    left = max(partner.lower, -width)
    right = min(partner.upper, width)
    if left >= right:
        return Z
    left_primitive = left * abs(left) / (2 * width)
    right_primitive = right * abs(right) / (2 * width)
    return partner.mass * (
        right - left - right_primitive + left_primitive
    ) / (partner.upper - partner.lower)


def fraction_text(value):
    return str(value) if value else "empty"


def probe(partners, widths, direction):
    individual = {
        width: sum(overlap_mass(p, width, direction) for p in partners if width in p.widths)
        for width in widths
    }
    union = sum(overlap_mass(p, max(p.widths), direction) for p in partners)
    print(
        f"  e={direction}: sum_D L_D(e)={sum(individual.values())}; "
        f"L(e)={union}; union 1/L(e)={fraction_text(1 / union if union else None)}"
    )
    print(
        "    per-D 1/L_D(e) in increasing D:",
        [fraction_text(1 / value if value else None) for value in individual.values()],
    )


def analyze(name, partners, probes):
    assert all(p.lower < p.upper and p.mass > 0 and p.widths for p in partners)
    assert sum(p.mass for p in partners) == 1
    widths = sorted({w for p in partners for w in p.widths})
    dyadic_prices = tuple(w / (2 * H) for w in widths)
    assert all(
        d.numerator.bit_count() == d.denominator.bit_count() == 1
        for d in dyadic_prices
    )

    breaks = {-HALF, HALF}
    for p in partners:
        for w in p.widths:
            for endpoint in (p.lower, p.upper):
                for offset in (-HALF, HALF):
                    point = endpoint / w + offset
                    if -HALF < point < HALF:
                        breaks.add(point)
    breaks = sorted(breaks)

    direction_volume = Z
    separate_volume = {w: Z for w in widths}
    separate_raw = {w: Z for w in widths}
    multiplicities = Counter()
    union_raw = Z
    paid = [Z for p in partners]
    for a, b in zip(breaks, breaks[1:]):
        length = b - a
        mid = (a + b) / 2

        active_prices = 0
        for width in widths:
            eligible = [p for p in partners if width in p.widths]
            left = sum(overlap_mass(p, width, a) for p in eligible)
            right = sum(overlap_mass(p, width, b) for p in eligible)
            assert sum(overlap_mass(p, width, mid) for p in eligible) == (left + right) / 2
            if left or right:
                active_prices += 1
                separate_volume[width] += length
                separate_raw[width] += length * (left + right) / 2
        multiplicities[active_prices] += length

        # For each allowed price and each e, the translated direction cube is
        # a dilation of a convex interval containing 0. Hence its widths nest.
        left = [overlap_mass(p, max(p.widths), a) for p in partners]
        right = [overlap_mass(p, max(p.widths), b) for p in partners]
        total_left, total_right = sum(left), sum(right)
        assert 0 <= total_left <= 1 and 0 <= total_right <= 1
        assert bool(active_prices) == bool(total_left or total_right)
        if active_prices:
            direction_volume += length
            union_raw += length * (total_left + total_right) / 2
            for i, (n_left, n_right) in enumerate(zip(left, right)):
                paid[i] += ratio_integral(length, n_left, n_right, total_left, total_right)

    assert sum(multiplicities.values()) == 1
    assert sum(m * size for m, size in multiplicities.items()) == sum(separate_volume.values())
    assert direction_volume == 1 - multiplicities[0] <= 1
    assert all(
        separate_raw[w] == sum(raw_fubini(p, w) for p in partners if w in p.widths)
        for w in widths
    )
    assert union_raw == sum(raw_fubini(p, max(p.widths)) for p in partners)
    assert expand(sum(paid) - direction_volume) == 0

    print(name)
    print("  dyadic prices D:", [str(d) for d in dyadic_prices])
    for p, payment in zip(partners, paid):
        exact = expand(payment)
        print(
            f"  partner {p.label}: q=[{p.lower},{p.upper}], lambda={p.mass}, "
            f"priced at {len(p.widths)} levels; "
            f"integral of K_* against lambda = {exact} (~{float(exact):.12f})"
        )
    print("  individual paid direction volumes:", [str(v) for v in separate_volume.values()])
    print(
        "  direction volume by number of active price levels:",
        {count: str(size) for count, size in sorted(multiplicities.items())},
    )
    separate = sum(separate_volume.values())
    print(
        f"  normalized separate payments={separate}; normalized union payment={direction_volume}; "
        f"factor={separate / direction_volume} (~{float(separate/direction_volume):.12f})"
    )
    print(f"  raw separate masses={sum(separate_raw.values())}; raw union mass={union_raw}")
    for direction in probes:
        probe(partners, widths, direction)
    print()
    return direction_volume, separate, union_raw


def main():
    print("Synthetic fixed-left partner boxes in dimension one, with z=0 and h=1/32.")
    print("Receiver labels and price eligibility are synthesized, absent original history.")
    print("All overlap and saturation assertions use rational or exact logarithmic expressions.")
    print()
    solo = Partner("single", F(1, 8), F(1, 4), F(1), (F(1),))
    result = analyze(
        "Single price",
        (solo,),
        (-F(3, 8) + F(1, 128), -F(3, 8) + F(1, 8192), F(0)),
    )
    assert result[:2] == (F(7, 8), F(7, 8))

    widths = tuple(F(1, 2**i) for i in range(11, -1, -1))
    smallest = widths[0]
    common = Partner("shared", smallest / 8, smallest / 4, F(3, 4), widths)
    extra = Partner("largest only", F(1, 4), F(1, 2), F(1, 4), (widths[-1],))
    result = analyze("Twelve prices, shared partner", (common, extra), (-F(1, 4), F(0)))
    assert result[0] == F(16383, 16384) and result[1] > F(11)

    left = Partner("left partner only", -F(3, 8), -F(1, 8), F(2, 5), (F(1, 2),))
    right = Partner("right partner only", F(1, 4), F(1, 2), F(3, 5), (F(1),))
    result = analyze("Two prices, disjoint partners", (left, right), (-F(1, 4), F(0), F(1, 4)))
    assert result[:2] == (F(1), F(3, 2))
    print("PASS exact directional occupancy, per-price normalizations and union payment.")


if __name__ == "__main__":
    main()
