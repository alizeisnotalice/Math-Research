"""R831 hard-root replay. Run python3 -B root831.py (standard library only)."""

from fractions import Fraction as Fr
from itertools import product


ZERO = Fr(0)
SUPPORTS = ((Fr(-1, 64), Fr(1, 64)), (Fr(47, 64), Fr(49, 64)))
DENSITY = 32
CELLS = (
    (Fr(-7, 16), Fr(-3, 8), Fr(1), frozenset({0})),
    (Fr(9, 8), Fr(19, 16), Fr(1), frozenset({1})),
    (Fr(0), Fr(3, 4), Fr(2), frozenset({0, 1})),
)


def certify_original_roots():
    """Each assigned root has strict overlevel centers at widths just below it."""
    for lo, hi in SUPPORTS:
        assert DENSITY * (hi - lo) == 1
    for lo, hi, v, captured in CELLS:
        assert len(captured) == v  # lambda=1, before the source cut
        for index, (a, b) in enumerate(SUPPORTS):
            if index in captured:
                assert max(abs(x - p) for x, p in product((lo, hi), (a, b))) < v / 2
            else:
                assert max(a - hi, lo - b) > 1
    # For v=1 the other box stays outside for 1<b<=2, and for
    # all centers b>2 cannot be strictly overlevel since total mass is 2.


def audit(cut, delta, gates):
    # In each source box keep the interval of mass cut[j] at the left end.
    kept = tuple((a, a + mass / DENSITY) for (a, _), mass in zip(SUPPORTS, cut))
    assert all(a <= stop <= b for (a, b), (_, stop) in zip(SUPPORTS, kept))
    source_mass = sum(cut)
    source_ids = range(len(cut))
    roots = tuple((hi - lo, v, support, sum(cut[i] for i in support) / v)
                  for lo, hi, v, support in CELLS)
    low_mass = sum(length * m**2 for length, _, _, m in roots if m < delta)
    if delta > 0:
        # In n=1 one may use the elementary centered weak bound 2.
        assert low_mass <= 4 * delta * source_mass
    retained = tuple(root for root in roots if root[3] >= delta)
    root_ids = range(len(retained))
    a = {p: sum(length * m / v for length, v, support, m in retained if p in support)
         for p in source_ids}
    f = {(p, q): sum(length / v**2 for length, v, support, _ in retained
                     if {p, q} <= support)
         for p, q in product(source_ids, repeat=2)}
    tau = sum(length * m**2 for length, _, _, m in retained)
    first_moment = sum(length * m for length, _, _, m in retained)
    assert tau == sum(cut[p] * cut[q] * f[p, q] for p, q in f)
    assert tau == sum(cut[p] * a[p] for p in a)
    if delta > 0:
        assert first_moment <= tau / delta

    orders = (Fr(1, 2), Fr(1), Fr(2))
    directed = dict.fromkeys(orders, ZERO)
    mutual = ZERO
    first_total = ZERO
    for p, q, qp in product(source_ids, repeat=3):
        if not all(cut[index] for index in (p, q, qp)) or not a[p]:
            continue
        for x, y in product(retained, repeat=2):
            lx, vx, sx, _ = x
            ly, vy, sy, _ = y
            if {p, q} <= sx and {p, qp} <= sy:
                weight = cut[p] * cut[q] * cut[qp] * lx * ly / (vx**2 * vy**2 * a[p])
                first_total += weight
                for scale in orders:
                    if q in sy and vy <= scale * vx:
                        directed[scale] += weight
                if q in sy and qp in sx:
                    mutual += weight
    assert first_total == tau
    assert mutual <= 4 * source_mass
    assert all(weight <= 2 * scale * source_mass for scale, weight in directed.items())

    for p, q in product(source_ids, repeat=2):
        if not (cut[p] and cut[q] and f[p, q]):
            continue
        for length, v, support, m in retained:
            if not {p, q} <= support:
                continue
            p_law = length * m / (v * a[p])
            pq_law = length / (v**2 * f[p, q])
            assert p_law == m * v * f[p, q] / a[p] * pq_law

    print(f"cut={cut}, delta={delta}, low={low_mass}, tau={tau}, M1={first_moment}")
    print(f"  directed(C=1/2,1,2)={tuple(map(str, directed.values()))}, mutual={mutual}")
    for k in (2, 3):
        gate_mass = dict.fromkeys(gates, ZERO)
        pair_total = ZERO
        min_score = ZERO
        for indices in product(root_ids, repeat=k):
            ordered = tuple(retained[i] for i in indices)
            ell, volume, label, density = zip(*ordered)
            jstar = min(range(k), key=lambda j: volume[j])
            minimum = volume[jstar]
            shared = frozenset.intersection(*label)
            capacity = sum(cut[i] for i in shared) / minimum
            if not capacity:
                continue
            receiver_weight = Fr(1)
            for measure, v in zip(ell, volume):
                receiver_weight *= measure / v**2
            for p, q in product(shared, repeat=2):
                if not (cut[p] and cut[q]):
                    continue
                pair_density = f[p, q]
                weight = cut[p] * cut[q] * receiver_weight / pair_density**(k - 1)
                pair_total += weight
                score = density[jstar] * minimum * pair_density / a[p]
                min_score += score * weight
                critical = capacity / (minimum * pair_density)**(k - 1)
                for d in gates:
                    if d >= critical:
                        gate_mass[d] += weight
        assert pair_total == tau
        assert min_score <= 2 * k * source_mass
        for d, mass in gate_mass.items():
            assert mass <= k * 2**(k - 1) * d * first_moment
            if delta > 0:
                assert mass <= k * 2**(k - 1) * d * tau / delta
        print(f"  k={k}, total={pair_total}, small-root weighted={min_score}, "
              f"d:mass=" + " ".join(f"{d}:{mass}" for d, mass in gate_mass.items()))
    return tau, directed[Fr(1)], mutual


def main():
    certify_original_roots()
    gates = tuple(map(Fr, ("1/64", "1/8", "1/4", "1", "2", "3", "4", "8", "16")))
    full = (Fr(1), Fr(1))
    partial = (Fr(1, 4), Fr(1))
    one_box = (Fr(1), Fr(0))
    cases = (
        (full, Fr(1, 2)),
        (partial, Fr(1, 8)),
        (partial, Fr(1, 2)),
        (partial, Fr(3, 4)),
        (one_box, Fr(1, 4)),
        (one_box, Fr(3, 4)),
    )
    baseline = audit(*cases[0], gates)
    assert baseline == (Fr(7, 8), Fr(5, 7), Fr(43, 56))
    for case in cases[1:]:
        audit(*case, gates)


if __name__ == "__main__":
    main()
