"""Exact four-cycle and complete-two-arm conditional laws for R814.

An arm is (old parent, exact real source in a membership cell). Its base
measure in a cell is j_i * mu(cell) / m_i. Receiver locations have the
archive's conditional uniform law on the actual disjoint owner cubes; after
fixing the owner label, these factor out. A membership cell compresses
constant conditional densities, and does not identify two independently
sampled points in that cell. All probabilities and gate decisions are rational.
"""

import argparse
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
from itertools import product
import json
from pathlib import Path
from zipfile import ZipFile

PIN = '891d8cbcbd35537e6abc18c938e53b1b4f300327357c24c8d14a51a46ad5e190'
ARCHIVE = Path('/Volumes/data/CodexProjects/T/Math-Research-cube-sqrt-20261114/'
               'centered-cube-upper-bound/rounds/814/research.zip')


def total(values):
    return sum(values, F(0))


def output(label, values, exact):
    pretty = {key: format(float(value), '.12g') for key, value in values.items()}
    print(label, pretty)
    if exact:
        print(' EX', {key: str(value) for key, value in values.items()})


def build(stage):
    n = stage['dimension']
    assert n == 4
    parents = {i['id']: i for i in stage['parents']}
    source = {i['mask']: F(i['mass']) for i in stage['cells'] if F(i['mass']) > 0}
    middle = tuple(stage['middle_labels'])
    volumes = {i: F(p['m']) for i, p in parents.items()}
    bins = {i: F(p['volume_bin']) for i, p in parents.items()}
    base = {}
    for i, p in parents.items():
        if p['role'] != 'old':
            continue
        assert total(mu for cell, mu in source.items() if cell & p['bit']) == volumes[i]
        # The archive weights each disjoint owner by its j_i; its
        # conditional physical distribution is uniform with total mass one.
        assert 0 < F(p['j']) <= F(p['owner_volume'])
        for cell, mu in source.items():
            if cell & p['bit']:
                base[i, cell] = F(p['j']) * mu / volumes[i]
        assert total(lam for x, lam in base.items() if x[0] == i) == F(p['j'])
    permitted = {
        t: {x for x in base if x[0] in stage['degrees'][t]['old_terms']
            and x[1] & parents[t]['bit']}
        for t in middle
    }
    c = {t: F(parents[t]['j']) / volumes[t]**2 for t in middle}
    d = {t: F(stage['degrees'][t]['full_d']) for t in middle}
    coeff = {t: c[t] / d[t] for t in middle}
    for t in middle:
        assert d[t] == F(parents[t]['full_d']) > 0
        assert total(base[x] for x in permitted[t]) == F(parents[t]['old_d']) * volumes[t]

    Q = {(t, x, y): c[t] for t in middle for x, y in product(permitted[t], repeat=2)}
    Qd = {(t, x, y): coeff[t] for t, x, y in Q}
    R = {(t, x, y): value for (t, x, y), value in Qd.items() if bins[x[0]] != bins[y[0]]}
    for section, law in (('cross', R), ('all', Qd)):
        rows = stage[f'roots_{section}']
        reconstructed = {}
        for root in rows:
            t, u, g = (root[key] for key in ('t', 'u', 'g'))
            weight = F(root['coefficient'])
            assert weight == coeff[t] * F(parents[u]['j']) / volumes[u] * F(parents[g]['j']) / volumes[g]
            assert F(root['root_mass']) == weight * total(source[z] * source[q]
                                                          for z, q in product(root['z_masks'], root['q_masks']))
            for z, q in product(root['z_masks'], root['q_masks']):
                x, y = (u, z), (g, q)
                assert (t, x, y) not in reconstructed
                reconstructed[t, x, y] = weight * source[z] * source[q] / (base[x] * base[y])
        assert reconstructed == law
        assert total(value * base[x] * base[y] for (t, x, y), value in law.items()) == F(stage['benchmarks'][section]['mother'])
        if section == 'cross':
            assert len(rows) == 34 and len(law) == 230
    return middle, bins, base, c, coeff, permitted, R, Qd, Q


def group_right(records, bins, lock_bin):
    groups = defaultdict(list)
    for (t, x, y), w in records.items():
        D = bins[t] if lock_bin else None
        groups[y, D].append((t, x, w))
    return groups


def right_density(law, base, bins, lock_bin):
    plus, minus = defaultdict(F), defaultdict(F)
    for (t, x, y), strength in law.items():
        D = bins[t] if lock_bin else None
        plus[y, D] += strength * base[x]
        minus[x, D] += strength * base[y]
    assert plus == minus  # The actual R814 rules are symmetric in the two ordered arms.
    return plus, minus


def direct_right(law, rows, base, bins, lock_bin):
    groups = group_right(rows, bins, lock_bin)
    plus, minus = right_density(law, base, bins, lock_bin)
    result = defaultdict(F)
    pair_cycle = defaultdict(F)
    for (y, D), entries in groups.items():
        mass = total(w for _, _, w in entries)
        assert mass == base[y] * plus[y, D] == base[y] * minus[y, D]
        for t, x, old in entries:
            normalizer = F(0)
            hit_mass = F(0)
            for s, xx, new in entries:
                oriented = old * new / mass
                normalizer += oriented
                crosses_bin = bins[t] != bins[s]
                first = (s, x, y) in law
                second = (t, xx, y) in law
                hits = int(first) + int(second)
                result['total'] += oriented
                result['different_bin'] += oriented * crosses_bin
                result[f'cross_{hits}'] += oriented
                if first and second:
                    hit_mass += oriented
                    pair_cycle[t, s] += oriented
                    result['cross_both_different_bin'] += oriented * crosses_bin
            assert normalizer == old
            result['conditional_cycle_second_moment'] += hit_mass**2 / old
    assert result['total'] == total(rows.values()) == total(result[f'cross_{k}'] for k in range(3))
    assert result['cross_2'] == total(pair_cycle.values())
    assert result['cross_2']**2 / result['total'] <= result['conditional_cycle_second_moment'] <= result['cross_2']
    return plus, minus, result, pair_cycle


def contracted_right(middle, base, bins, coeff, permitted, cross_only, plus, lock_bin):
    ordinary_B = {
        (t, s): total(base[x] for x in permitted[t] & permitted[s])
        for t, s in product(middle, repeat=2)
    }
    answer = defaultdict(F)
    for (y, D), denominator in plus.items():
        assert denominator > 0
        available = [t for t in middle if y in permitted[t] and (D is None or bins[t] == D)]
        cut = {x for x in base if bins[x[0]] != bins[y[0]]} if cross_only else set(base)
        left = {t: total(base[x] for x in permitted[t] & cut) for t in available}
        assert denominator == total(coeff[t] * left[t] for t in available)
        for t, s in product(available, repeat=2):
            if lock_bin:
                assert bins[t] == bins[s]
            B = total(base[x] for x in permitted[t] & permitted[s] & cut)
            if not cross_only:
                assert B == ordinary_B[t, s]
            answer[t, s] += coeff[t] * coeff[s] * B**2 * base[y] / denominator
    return {k: v for k, v in answer.items() if v}


def full_arm(law, rows, base, bins):
    physical = defaultdict(list)
    h = defaultdict(F)
    for (t, x, y), strength in law.items():
        h[x, y] += strength
    for (t, x, y), w in rows.items():
        physical[x, y].append((t, w))
    direct, contracted = defaultdict(F), defaultdict(F)
    for (x, y), entries in physical.items():
        marginal = total(w for _, w in entries)
        measure = base[x] * base[y]
        denominator = h[x, y]
        assert denominator > 0 and marginal == denominator * measure
        for t, old in entries:
            recovered = F(0)
            for s, new in entries:
                pair_mass = old * new / marginal
                direct[t, s] += pair_mass
                recovered += pair_mass
            assert recovered == old
        for (t, _), (s, _) in product(entries, repeat=2):
            contracted[t, s] += law[t, x, y] * law[s, x, y] * measure / denominator
    assert direct == contracted
    mass = total(rows.values())
    different_bin = total(w for (t, s), w in direct.items() if bins[t] != bins[s])
    assert total(direct.values()) == mass
    return h, different_bin, direct


def normalized(result):
    mass = result['total']
    rates = {k: value / mass for k, value in result.items() if k != 'total'}
    rates['cross_given_different_bin'] = (result['cross_both_different_bin'] / result['different_bin']
                                          if result['different_bin'] > 0 else F(0))
    return rates


def case(name, stage, exact):
    middle, bins, base, c, cd, permitted, R, Qd, Q = build(stage)
    print('FIXTURE', name, 'dimension', stage['dimension'], 'active arm cells', len(base),
          'original roots', 34, 'original positive cell pairs', 230)
    for label, law, coeff, cross_only in (('R_cross', R, cd, True), ('Q_d_product', Qd, cd, False),
                                          ('Q_1_product', Q, c, False)):
        rows = {(t, x, y): strength * base[x] * base[y] for (t, x, y), strength in law.items()}
        mass = total(rows.values())
        print('LAW', label, 'positive cell pairs', len(rows))
        output('RAW arm masses', {
            'mother': mass,
            'u_equal_g': total(w for (_, x, y), w in rows.items() if x[0] == y[0]),
            'same_old_bin_distinct_u_g': total(w for (_, x, y), w in rows.items()
                                               if x[0] != y[0] and bins[x[0]] == bins[y[0]]),
        }, exact)
        plus, minus, free, event = direct_right(law, rows, base, bins, False)
        assert event == contracted_right(middle, base, bins, coeff, permitted, cross_only, plus, False)
        assert total(base[y] * density for (y, _), density in plus.items()) == mass
        assert total(base[x] * density for (x, _), density in minus.items()) == mass
        output('g_+ and g_- exact denominator range', {'minimum': min(plus.values()), 'maximum': max(plus.values())}, exact)
        output('RAW same right', {k: free[k] for k in ('cross_2', 'cross_both_different_bin', 'conditional_cycle_second_moment')}, exact)
        output('RATES same right, unlocked middle bin', normalized(free), exact)
        locked_plus, _, locked, locked_event = direct_right(law, rows, base, bins, True)
        assert locked_event == contracted_right(middle, base, bins, coeff, permitted, cross_only, locked_plus, True)
        assert not locked['different_bin']
        output('RATES same right, locked middle bin', normalized(locked), exact)
        h, diff, full = full_arm(law, rows, base, bins)
        output('complete-arm h denominator range', {'minimum': min(h.values()), 'maximum': max(h.values())}, exact)
        output('complete-arm resample', {'different_bin_raw': diff, 'different_bin_fraction': diff / mass,
                                        'both_cross_fraction': total(full.values()) / mass}, exact)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--archive', type=Path, default=ARCHIVE)
    parser.add_argument('--exact', action='store_true', help='show all computed exact fractions')
    args = parser.parse_args()
    assert sha256(args.archive.read_bytes()).hexdigest() == PIN
    with ZipFile(args.archive) as archive:
        archived = {'__name__': 'archived_comb811'}
        exec(compile(archive.read('comb811.py'), 'comb811.py', 'exec'), archived)
        original = archived['fixture'](*archived['FIXTURES'][-1])
        rebuilt = json.loads(archive.read('comb814-rebuilt.json'))['stages'][0]
    case('original', original, args.exact)
    case('rebuilt', rebuilt, args.exact)
    print('SCOPE positive 4D fixtures only; distinct left/right old bins are part of actual R, and not of Q_d or Q_1.')
    print('PASS exact mother, correct g_+/g_-/h, row marginals, product and truncated four-cycle identities, and second-moment bounds')


if __name__ == '__main__':
    main()
