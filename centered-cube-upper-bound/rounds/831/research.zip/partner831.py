"""R831. Exact actual-left partner pools, calibrated examples, original R814 rows.

Lambda_(u,z,D) sums each original right-small-parent reference (j_g/m_g)
mu(dq) Un(E_g)(dW) precisely where some admissible middle parent in D links
it to the fixed left mark, once per (g,q), even if several middles link it.
Projection to q is used in K_partner. C is specified for each case below.

Run: python3 -B partner831.py [--archive /path/to/R814/research.zip]
All numerical enclosures use rational arithmetic and outward rounding.
"""

import argparse
from collections import defaultdict
from dataclasses import dataclass
from fractions import Fraction as F
from hashlib import sha256
from itertools import combinations, product
from pathlib import Path
import json
from zipfile import ZipFile


ARCHIVE = Path('/Volumes/data/CodexProjects/T/Math-Research-cube-sqrt-20261114/'
               'centered-cube-upper-bound/rounds/814/research.zip')
PIN = '891d8cbcbd35537e6abc18c938e53b1b4f300327357c24c8d14a51a46ad5e190'
ROUND = 10**13


def bracket(lo, hi, places=10):
    assert 0 <= lo <= hi
    denominator = 10**places
    integers = [(lo.numerator * denominator) // lo.denominator,
                -((-hi.numerator * denominator) // hi.denominator)]
    return '[' + ', '.join(f'{value // denominator}.{value % denominator:0{places}d}'
                           for value in integers) + ']'


def decimal(x, places=10):
    return bracket(x, x, places)


def interval(center, side):
    return center - side / 2, center + side / 2


def intersect(one, two):
    return max(one[0], two[0]), min(one[1], two[1])


def length(box):
    return max(F(0), box[1] - box[0])


def source_mass(box, source):
    return sum((density * length(intersect(box, support)) for support, density in source), F(0))


def dyadic_bin(x):
    assert x > 0
    d = F(1)
    while x < d:
        d /= 2
    while x >= 2 * d:
        d *= 2
    return d


def kernel_1d(z, q, d, source):
    w = F(33, 32) * 2 * d
    a, b = intersect(interval(z, w), interval(q, w))
    assert a < b
    cuts = {a, b}
    for support, _ in source:
        for t in support:
            for x in (t - w / 2, t + w / 2):
                if a < x < b:
                    cuts.add(x)
    ordered = sorted(cuts)
    fine = [x + (y - x) * k / 64
            for x, y in zip(ordered, ordered[1:]) for k in range(64)] + [b]
    masses = [source_mass(interval(x, w), source) for x in fine]
    lo = hi = 0
    for x, y, m1, m2 in zip(fine, fine[1:], masses, masses[1:]):
        # The source mass is affine on each center subinterval.
        lower = ROUND * (y - x) / (d + max(m1, m2))
        upper = ROUND * (y - x) / (d + min(m1, m2))
        lo += lower.numerator // lower.denominator
        hi += -((-upper.numerator) // upper.denominator)
    return F(lo, ROUND), F(hi, ROUND)


@dataclass(frozen=True)
class Label:
    name: str
    box: tuple

    @property
    def m(self):
        return length(self.box)

    @property
    def owner(self):
        return interval(sum(self.box) / 2, self.m / 32)


def marked_example(spike_fraction):
    low = Label('t0', (-F(3, 8), F(3, 8)))
    high = Label('t1', (-F(1, 2), F(3, 4)))
    left = Label('u', (-F(3, 4), -F(1, 4)))
    central = Label('g0', (-F(1, 32), F(3, 32)))
    external = Label('g1', (F(5, 8), F(7, 8)))
    labels = (low, high, left, central, external)
    z, q, q_peak = -F(5, 16), F(0), F(45, 64)
    left_inside = F(1, 16) * left.m
    spike = spike_fraction * external.m
    packets = (
        ((-F(11, 32), -F(9, 32)), left_inside),
        ((-F(19, 32), -F(17, 32)), left.m - left_inside),
        (central.box, central.m),
        ((F(1, 8), F(1, 4)), low.m - left_inside - central.m),
        ((F(7, 16), F(9, 16)), high.m - low.m - spike),
        ((F(11, 16), F(23, 32)), spike),
        ((F(13, 16), F(27, 32)), external.m - spike),
    )
    assert all(mass > 0 for _, mass in packets)
    assert all(length(intersect(a, b)) == 0 for (a, _), (b, _) in combinations(packets, 2))
    source = tuple((box, mass / length(box)) for box, mass in packets)
    assert all(source_mass(p.box, source) == p.m for p in labels)
    assert all(length(intersect(a.owner, b.owner)) == 0 for a, b in combinations(labels, 2))
    assert all(length(p.owner) / p.m == F(1, 32) for p in labels)
    assert all(density <= 8 for _, density in source)
    assert packets[-2][0][0] < q_peak < packets[-2][0][1]
    assert all(t.box[0] < z < t.box[1] for t in (left, low, high))
    print('\nCALIBRATED two-bin companion; spike contact fraction at larger t =', spike_fraction)
    print('  all five actual source-mass calibrations and all owners disjoint')
    print('  both left contact fractions = 1/16; larger side ratios u/t=2/5,g1/t=1/5')
    print('  total source mass =', sum(mass for _, mass in packets), 'maximal cap <= 8')
    for t in (low, high):
        d = dyadic_bin(t.m)
        assert source_mass(intersect(left.box, t.box), source) == left_inside
        assert all(g.m < t.m and dyadic_bin(g.m) != dyadic_bin(left.m)
                   for g in (central, external))
        # All source price sets are the actual source in their label cube.
        # The density cap C=j_g/m_g=1/32 works since right label cubes are disjoint.
        c = F(1, 32)
        partner = []
        partner_stats = {}
        for g in (central, external):
            contact_box = intersect(g.box, t.box)
            pieces = [(intersect(box, contact_box), density) for box, density in source
                      if length(intersect(box, contact_box))]
            partner.extend(pieces)  # this is Lambda / C
            partner_stats[g.name] = source_mass(contact_box, source)
        assert partner_stats['g1'] == (spike if t == high else 0)
        normalized_total = sum(partner_stats.values())
        central_only = ((central.box, F(1)),)
        full_kernel = kernel_1d(z, q, d, source)
        partner_kernel = kernel_1d(z, q, d, partner)
        no_peak_kernel = kernel_1d(z, q, d, central_only)
        if t == low:
            assert partner_kernel == no_peak_kernel
            assert length(intersect(interval(z, F(33, 32)), interval(q_peak, F(33, 32)))) > 0
            assert not any(lo < q_peak < hi for (lo, hi), _ in partner)
        else:
            assert any(lo < q_peak < hi for (lo, hi), _ in partner)
            assert partner_kernel[1] < no_peak_kernel[0]
            print('  spike can be the actual right endpoint: K_partner(z,q_peak)=',
                  bracket(*kernel_1d(z, q_peak, d, partner)))
        assert full_kernel[1] < partner_kernel[0]
        print('  D=', d, 'Lambda/C right contact masses', partner_stats,
              'Lambda total =', c * normalized_total)
        print('    fixed z,q_core: K_physical=', bracket(*full_kernel),
              'K_partner=', bracket(*partner_kernel),
              'K_partner central-only=', bracket(*no_peak_kernel))
    print('  Both labels have genuine positive G contact where displayed; the 1/16 '
          'case meets the stated thin-contact test, not the full R813 gates.')


def prior_family(n):
    # Same positive-L1 source as R830: density 1 on [-2,2]^n plus
    # 2n boxes around +/-3/4 e_j (near), or +/-3/2 e_j (far).
    # Small arm labels are specified afresh and do not include exterior peaks.
    d = F(1, 2)
    w = 1 + F(1, 32 * n)
    b = 1 - F(1, 4 * n)
    delta = F(1, 2**(2 * n + 8))
    spike_mass = F(7, 5)**n / (2 * n)
    father_labels = ((F(0), b), (-b / (16 * n), b), (b / (16 * n), b))
    u, g = (-b / 32, b / 8), (b / 64, b / 16)
    labels = (*father_labels, u, g)
    owners = [interval(center, side / (32 * n)) for center, side in labels]
    assert all(length(intersect(a, v)) == 0 for a, v in combinations(owners, 2))
    assert all(F(3, 4) - delta > abs(center) + side / 2 for center, side in labels)
    assert all(2 * (F(3, 4) - delta - abs(center)) >= F(7, 5)
               for center, _ in labels)
    assert all(abs(small_center - center) + small_side / 2 < side / 2
               for center, side in father_labels for small_center, small_side in (u, g))
    assert all(abs(center) + delta < side / 2 for center, side in (u, g))
    assert dyadic_bin(b**n) == d and dyadic_bin(u[1]**n) != dyadic_bin(g[1]**n)
    # Either source supplies all calibrated label masses, and every declared
    # t allows the actual fixed left arm and the full right label g.
    c = F(1, 32 * n)**n
    pg = g[1]**n
    side_overlap = w - 2 * delta
    kp = side_overlap**n / (d + pg), w**n / d
    physical_near_upper = ((w + 2 * delta)**n - side_overlap**n
                           + (F(3, 2) - w + 2 * delta)**n) / d + w**n / (d + spike_mass)
    physical_far_low = side_overlap**n / (d + w**n)
    assert 0 < physical_near_upper < physical_far_low < kp[0]
    print('\nR830 same near/far sources with actual new arm labels n=', n, 'D=', d)
    print('  all label calibrations and physical owners checked; eligible right label g is nonthin')
    print('  This is the stated geometric/cross-bin model without the full R813 gate.')
    print(f'  Lambda/C total = ({g[1]})^{n}, C=(32n)^(-n), exterior Lambda mass=0')
    print('  near and far K_partner identical at every fixed z,q, interval uniformly',
          bracket(*kp, 12))
    print('  K_physical near <=', decimal(physical_near_upper, 12),
          'K_physical far >=', decimal(physical_far_low, 12))


def archived_stage(name, stage):
    parents = {p['id']: p for p in stage['parents']}
    masses = {row['mask']: F(row['mass']) for row in stage['cells']}
    old = {label: p for label, p in parents.items() if p['role'] == 'old'}
    weights = {g: F(p['j']) / F(p['m']) for g, p in old.items()}
    all_density = {q: sum((w for g, w in weights.items() if q & old[g]['bit']), F(0))
                   for q in masses}
    c = max(all_density.values())
    all_mass = sum((all_density[q] * mass for q, mass in masses.items()), F(0))
    assert all_mass == sum((F(p['j']) for p in old.values()), F(0))
    contexts = defaultdict(set)
    original = defaultdict(F)
    children = 0
    for root in stage['roots_cross']:
        t, u, g = (root[k] for k in ('t', 'u', 'g'))
        d = F(parents[t]['volume_bin'])
        assert F(parents[u]['radius']) < F(parents[t]['radius'])
        assert F(parents[g]['radius']) < F(parents[t]['radius'])
        assert F(parents[u]['volume_bin']) != F(parents[g]['volume_bin'])
        assert d <= F(parents[t]['m']) < 2 * d
        for zmask, qmask in product(root['z_masks'], root['q_masks']):
            for tag, mask in ((t, zmask), (u, zmask), (t, qmask), (g, qmask)):
                assert mask & parents[tag]['bit']
            children += 1
            key = (u, zmask, d)
            contexts[key].add((g, qmask))
            original[key] += F(root['coefficient']) * masses[zmask] * masses[qmask]
    mother = sum(original.values(), F(0))
    assert children == 230 and mother == F(stage['benchmarks']['cross']['mother'])
    any_bin = defaultdict(set)
    for (u, zmask, _d), pairs in contexts.items():
        any_bin[u, zmask].update(pairs)

    def pool_mass(pairs):
        return sum((weights[g] * masses[qmask] for g, qmask in pairs), F(0))

    stats = defaultdict(list)
    bigger_mass_rows = F(0)
    peak = F(0)
    for (u, zmask, d), pairs in contexts.items():
        union = any_bin[u, zmask]
        fixed_mass, mixed_mass = pool_mass(pairs), pool_mass(union)
        row_weight = original[u, zmask, d]
        assert 0 < fixed_mass <= mixed_mass <= all_mass
        if fixed_mass < mixed_mass:
            bigger_mass_rows += row_weight
        for qmask in {q for _, q in pairs}:
            assert sum(weights[g] for g, qq in pairs if qq == qmask) <= c
        stats[d].append((fixed_mass / (d * c), mixed_mass / (d * c), row_weight))
        peak = max(peak, fixed_mass / (d * c))
    print('\nR814', name, '34 cross roots, 230 positive rows, exact mother', mother)
    distinct = sum(map(len, contexts.values()))
    assert 0 < distinct <= children
    print('  distinct (u,z-cell,D) contexts', len(contexts),
          'distinct compatible (u,z-cell,D,g,q-cell) references', distinct)
    print('  unrestricted Lambda mass', all_mass, 'C exact', c,
          'unrestricted Lambda/C', all_mass / c)
    print('  original row mass with strict pool enlargement when mixing D:',
          decimal(bigger_mass_rows / mother))
    for d, rows in sorted(stats.items()):
        total_weight = sum((row[2] for row in rows), F(0))
        own_mean = sum((x * j for x, _, j in rows), F(0)) / total_weight
        union_mean = sum((y * j for _, y, j in rows), F(0)) / total_weight
        low, high = min(row[0] for row in rows), max(row[0] for row in rows)
        print('  D=', d, 'contexts=', len(rows), 'fixed Lambda/(C*D) range=', bracket(low, high),
              'weighted means fixed/mixed', decimal(own_mean), decimal(union_mean))
        print('    exact range and weighted means', low, high, own_mean, union_mean)
    lower = 1 / (1 + peak)
    lower_outward = bracket(lower, lower)[1:].split(',')[0]
    print(f'  All original rows: K_partner/geometric kernel in [{lower_outward}, 1] '
          'using total pool mass.')
    print('  Context is the archived common window; 4D has empty original high-J gate.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--archive', type=Path, default=ARCHIVE)
    args = parser.parse_args()
    for n in (16, 64):
        prior_family(n)
    for theta in (F(1, 16), F(3, 4)):
        marked_example(theta)
    assert sha256(args.archive.read_bytes()).hexdigest() == PIN
    with ZipFile(args.archive) as archive:
        rebuilt = json.loads(archive.read('comb814-rebuilt.json'))['stages'][0]
        code = {'__name__': 'archived_comb811'}
        exec(compile(archive.read('comb811.py'), 'comb811.py', 'exec'), code)
    original = code['fixture'](*code['FIXTURES'][-1])
    for name, stage in (('original', original), ('rebuilt', rebuilt)):
        archived_stage(name, stage)


if __name__ == '__main__':
    main()

