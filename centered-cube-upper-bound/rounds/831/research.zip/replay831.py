"""Recompute the four round-831 checks and keep the complete machine transcript."""

import argparse
from concurrent.futures import ThreadPoolExecutor
from hashlib import file_digest, sha256
from importlib.metadata import version
import json
import os
from pathlib import Path
import subprocess
import sys


ARCHIVE_SHA256 = "891d8cbcbd35537e6abc18c938e53b1b4f300327357c24c8d14a51a46ad5e190"
CHECKS = (
    ("partner831.py", ("--archive",)),
    ("cycle831.py", ("--archive",)),
    ("direction831.py", ()),
    ("root831.py", ()),
)
DEPENDENCIES = ("sympy", "mpmath")
SETTINGS = {"PYTHONHASHSEED": "0", "PYTHONIOENCODING": "utf-8"}
LOG_HEADER = b"Round 831 computational verification\n"


def digest(path):
    with path.open("rb") as source:
        return file_digest(source, "sha256").hexdigest()


def run_check(directory, archive, check):
    script, options = check
    arguments = (*options, str(archive)) if options else ()
    return subprocess.run(
        [sys.executable, "-B", script, *arguments],
        cwd=directory,
        env={**os.environ, **SETTINGS},
        capture_output=True,
        check=False,
    )


def heading(script):
    return f"\n===== {script} =====\n".encode()


def write_transcript(evidence, results):
    metadata = json.dumps(evidence, ensure_ascii=False, sort_keys=True).encode()
    sections = [LOG_HEADER, b"Evidence JSON: ", metadata, b"\n"]
    for (script, _), result in zip(CHECKS, results, strict=True):
        sections.extend(
            (
                heading(script),
                b"----- stdout -----\n",
                result.stdout,
                b"\n----- stderr -----\n",
                result.stderr,
                b"\n",
            )
        )
    sections.append(f"\nReplay status: {evidence['status']}\n".encode())
    return b"".join(sections)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive", type=Path, required=True, help="Path to the original R814 research.zip")
    parser.add_argument("--jobs", type=int, choices=range(1, len(CHECKS) + 1), default=len(CHECKS))
    parser.add_argument("--output", type=Path, help="Save the full transcript here; default is stdout")
    args = parser.parse_args()

    replay = Path(__file__).resolve()
    directory = replay.parent
    archive = args.archive.resolve(strict=True)
    archive_hash = digest(archive)
    if archive_hash != ARCHIVE_SHA256:
        parser.error(f"unexpected round-814 archive SHA-256: {archive_hash}")
    script_hashes = {script: digest(directory / script) for script, _ in CHECKS}
    replay_hash = digest(replay)
    protected_paths = {replay, archive, *((directory / script) for script in script_hashes)}
    if args.output and args.output.resolve() in protected_paths:
        parser.error("the output must be distinct from all input files")

    versions = {dependency: version(dependency) for dependency in DEPENDENCIES}
    with ThreadPoolExecutor(max_workers=args.jobs) as workers:
        pending = [workers.submit(run_check, directory, archive, check) for check in CHECKS]
        results = [job.result() for job in pending]

    if digest(archive) != archive_hash or digest(replay) != replay_hash:
        parser.error("the archive or replay script changed during replay")
    for script, script_hash in script_hashes.items():
        if digest(directory / script) != script_hash:
            parser.error(f"{script} changed during replay")

    runs = {}
    for (script, options), result in zip(CHECKS, results, strict=True):
        arguments = [*options, "<R814 research.zip>"] if options else []
        runs[script] = {
            "arguments": arguments,
            "script_sha256": script_hashes[script],
            "exit": result.returncode,
            "stdout_bytes": len(result.stdout),
            "stdout_sha256": sha256(result.stdout).hexdigest(),
            "stderr_bytes": len(result.stderr),
            "stderr_sha256": sha256(result.stderr).hexdigest(),
        }
    passed = all(result.returncode == 0 for result in results)
    evidence = {
        "round": 831,
        "status": "PASS" if passed else "FAIL",
        "python": sys.executable,
        "python_version": sys.version,
        "dependencies": versions,
        "settings": SETTINGS,
        "jobs": args.jobs,
        "input_r814": str(archive),
        "input_r814_sha256": archive_hash,
        "replay_sha256": replay_hash,
        "individual_runs": runs,
    }
    transcript = write_transcript(evidence, results)
    if args.output:
        args.output.write_bytes(transcript)
    else:
        sys.stdout.buffer.write(transcript)
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
