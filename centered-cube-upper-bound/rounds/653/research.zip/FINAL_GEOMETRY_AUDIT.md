# R653 final independent geometry and numerical-scope audit

**Verdict: PASS within the stated partial-result scope.** No decisive geometric, conditional-law, or numerical-scope error was found in the frozen `REPORT.tex` and `NEXT_TARGET.md`. This is not certification of the general centered-cube bound, a full physical branching estimate, or a closed successor recursion. Both documents correctly leave those targets unproved.

## Frozen artifact binding

The following SHA-256 values were actually computed from the final local files and match the freeze supplied by the coordinator:

| File | SHA-256 |
|---|---|
| `/tmp/ccu_r653/REPORT.tex` | `828be61239417250bdfe4c62d5c50a2675df4e571bd86545839c5fbd67d23798` |
| `/tmp/ccu_r653/NEXT_TARGET.md` | `b436ce3a7b1e4d0edb875b3fd263979e1bfd5bb8daa52b303c6a59cbfad4aea9` |

This audit covers the final report's norm-nesting/window sections, finite-model claims and their limitations, and corresponding next-target instructions. Earlier passed portions were not wholesale re-audited. `TARGET.md` and the API `PRE_AUDIT.md` supplied the obligation and veto criteria; the author geometry file and prior geometry review were supporting material, not substitutes for checking the key deductions.

## Independent geometric check

At one realized physical point `x in E_j intersect E_k`, moderate parameters give `||y_i-x|| <= d s_i`, where `d=(T-1)/2+T/(32n)` and `T=(1+U)^(1/n)`. Hence

`||y_j-y_k||+s_j <= (1+d)s_j+d s_k <= s_k`

provided `s_k/s_j >= (1+d)/(1-d)`. The true row-mass conversion `s_k/s_j=(m_k/m_j)^(1/n)t_j/t_k` then proves the stated threshold `[T(1+d)/(1-d)]^n`. Equality yields closed-cube containment and is allowed. This uses true old cubes and source masses, without replacing source measure by volume.

The uniform `u<=16, n>=3` threshold `m_k/m_j>=32768` is valid. Independently executed the installed mathematical Python with exact `Fraction` arithmetic: `(18/7)^3-17=1/343`, the resulting upper bound for `d_16(3)` is `13/16`, and the resulting upper bound for `K_16(3)` is `414613/27<16384<32768`. The same bounded run checked `(53/48)^106>32768`. The report's analytic monotonicity argument supplies all dimensions in the stated range; no finite-table extrapolation is used. This short exact check does not repeat the numerical jobs.

The report retains all necessary restrictions: common physical receiver point, moderate endpoints, and the stated dimensions. Its norm-triangle proof extends to corresponding norm balls, so it correctly disclaims a specifically cube-product saving or a dimension improvement. High-u and other dimensions remain in the full ledger.

For bands `[m_ref K_*^r,m_ref K_*^(r+1))`, a gap of at least two indices gives every higher/lower mass ratio greater than `K_*`. Thus the nested union/annulus telescope is valid within a parity. Adjacent opposite-parity bands have no such implication. The final report and next target explicitly retain this qualification and restrict the telescope to fixed physical x and action. They do not turn it into one source partition over all receiver points or anchor histories. The old-lambda containment capacities retain their source weights and are not reinterpreted as physical lost-copy bounds.

## Actual loss and conditional ownership

Solving `x=t_k i-b_k(y_k+X_k)` gives the exact source window `W_k(x)=(t_k/b_k)I_k-y_k-x/b_k`. With x fixed and the other anchors frozen, the stated incoming probability is the old-source window mass divided by `m_k`. A bound by `m_j/m_k` concerns the joint incoming/inside-child event; it is not a collision-conditioned anchor law.

The final `lostsplit` retains `h_k(x,z;Z_-k)`, the indicator that the actual owner after recomputing the whole joint program differs from k. This is essential: the chosen owner, actual alpha and prices depend on every anchor, including z. The two integrals partition the actual lost event inside/outside an independently frozen lower union. Containment of that union additionally requires the same-parity/gap restriction; the partition identity itself does not. The final text states all of these facts. Its Fubini expression keeps the indicator inside the integrals and does not assume independent adaptive ownership.

The unresolved repeated-sibling sampling remains explicit. Disjoint old I does not make row-dependent affine source windows disjoint. Dropping the loss indicator yields only a full-incoming upper bound. Neither the annuli nor the one-unit owner cuts pay the physical multiplicity; the report and next target preserve actual `chi_j`, `u'/epsilon`, deleted rows and the single source/slack budget.

## Finite numerical claims and acceptance boundaries

Checked the report against `NUMERIC_REVIEW.md` and `REPLAY_AUDIT.md`; did not rerun the already passed source/action/owner/future calculations or their isolated replay. The report correctly states the following distinctions:

- The genuine n=1 old model has `R=15/272<1`, `kappa=63/17` and positive-width AC sources approaching the old-source H infimum. This establishes persistent blocking near that source infimum, without supplying a critical near-score state.
- For k=1, both continuous central-anchor mixture components are included; `D=0` is therefore the full independent-Euler expectation, with deleted old loss retained.
- For k=2,3, the owner certificate alone is a conditional center-right result. The separate action certificate retains the other half-event, fill and exact rational Darboux bounds, and supplies the complete expectations. The displayed outward decimal enclosures match the accepted ranges.
- True label splitting partitions old I and its weights, preserves total physical image volume, and does not create k simultaneous copies at every point. The raw child-mass sum is not a new source allowance.
- The original four-script replay establishes exact reproduction of those implemented certificates; the later 15/64 support-aware identity has its own separately executed symbolic/rational certificate. Neither establishes an actual further trajectory or pays subsequent overlap.

The report keeps the strong-invasion result at disjoint owner-volume price and says that any physical comparison coefficient must multiply both its RS and future-growth terms. It does not replace old-source near-optimality by near-score maximality, or owner area by lost multiplicity. The final next target retains all these boundaries and requires the full physical price or a genuinely closed whole-state recursion.

## Remaining obligation and stop

The decisive missing result is still a uniform, actual multiplicity-weighted window/column estimate paying `O-F-RS` with the same old growth and one global `CLM` account, or a complete score recursion retaining all next losses, fill, slack, low-kappa/high-R successors and terminal terms. The final texts make no claim to have supplied it. Coordinate clarification for the next carried graph keeps the old source in pre-normalization coordinates and avoids applying it to normalized state-2 cubes.

Audit complete for the two hashes above. No report edits, numerical expansion, PDF compilation, Git operation, API consultation, or subdelegation was performed by this reviewer. Any change to either bound file requires rebinding before this verdict is reused.
