"""R653 integrity and optional bounded replay. No TeX compilation."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile

root = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--replay', action='store_true')
args = parser.parse_args()
manifest = json.loads((root / 'MANIFEST.json').read_text())
actual_files = {p.relative_to(root).as_posix() for p in root.rglob('*')
                if p.is_file() and '__pycache__' not in p.parts}
assert actual_files == set(manifest) | {'MANIFEST.json'}, 'Unexpected/missing files'
for name, digest in manifest.items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == digest, name
tex = (root / 'REPORT.tex').read_text()
labels = re.findall(r'\\label\{([^}]+)\}', tex)
assert len(labels) == len(set(labels)), 'Duplicate labels'
assert set(re.findall(r'\\(?:eqref|ref)\{([^}]+)\}', tex)) <= set(labels)
for name in ['FINAL_GEOMETRY_AUDIT.md', 'FINAL_LEDGER_AUDIT.md']:
    assert manifest['REPORT.tex'] in (root / name).read_text(), name
review = (root / 'NUMERIC_REVIEW.md').read_text()
bindings = re.findall(r'^\| ([^|]+?) \| ([a-f0-9]{64}) \|$', review, re.M)
assert len(bindings) == 12, len(bindings)
for name, digest in bindings:
    assert hashlib.sha256((root / 'numeric' / name).read_bytes()).hexdigest() == digest, name
result = {'manifest_files': len(manifest), 'latex_labels': len(labels),
          'numeric_bindings': len(bindings), 'tex_compiled': False, 'replay': []}
if args.replay:
    env = dict(os.environ, OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1', MKL_NUM_THREADS='1')
    with tempfile.TemporaryDirectory(prefix='r653-replay-') as tmp:
        scratch = Path(tmp)
        shutil.copytree(root / 'numeric', scratch / 'numeric')
        for stem in ['source_certificate', 'action_budget', 'owner_certificate',
                     'future_certificate', 'f34_independent']:
            cp = subprocess.run([sys.executable, str(scratch / 'numeric' / (stem + '.py'))],
                                cwd=scratch, env=env, capture_output=True, text=True,
                                check=True, timeout=120)
            assert not cp.stderr, (stem, cp.stderr)
            output = ((scratch / 'numeric' / (stem + '.json')).read_text()
                      if stem == 'action_budget' else cp.stdout)
            assert json.loads(output) == json.loads((root / 'numeric' / (stem + '.json')).read_text()), stem
            result['replay'].append(stem + ': JSON matched')
print(json.dumps(result, indent=2))
