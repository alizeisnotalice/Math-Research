# R653 reproduction and evidence boundary

General centered-cube root-order weak type remains unproved. REPORT.tex contains the mathematical statements; the two final audits bind its SHA-256. No PDF was compiled.

Run after unpacking with the installed independent environment:

```sh
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python verify.py
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python verify.py --replay
```

The first command checks the exact archive file set, all manifest hashes, TeX labels/references, the two report-audit bindings and twelve original numeric-review bindings. These checks certify integrity, not mathematical truth. The second command executes five bounded scripts in a temporary copy and compares JSON to the archived results. No source output is overwritten. Python 3.12.14, SymPy 1.14.0 and python-flint 0.9.0 were used; version fields are deliberately not ignored, so another runtime may require a separately reviewed comparison.

The source, owner, future and supplemental F3–F4 scripts print JSON. The action script writes JSON beside its copied script. Exact Fraction and symbolic calculations prove only their specified finite-model or algebraic claims. Four Arb evaluations use 256-bit outward intervals and do not establish a general geometrical estimate. The inherited MATLAB R2026a Update 4 check is one floating endpoint computation, documented in numeric/README_future.md; this replay does not rerun MATLAB.

NUMERIC_PLAN.md and NUMERIC_REVIEW.md document the original four scripts and their twelve evidence files. REPLAY_AUDIT.md independently records their byte-identical replay and, separately, the later f34_independent.py certificate for the support-aware 15/64 coefficient. The later certificate is not retroactively attributed to the original four scripts. In the numerical model R=15/272<1; source-near-minimality is not near-score extremality. The owner clone records cover one conditional branch; the action records combine both branches for full expectations.

The archive keeps one integrated mathematical report, its final audits, the numeric plan/review/replay record, and only necessary code and results. Intermediate author notes and unsuccessful API requests remain outside the repository. The API attempts returned RemoteDisconnected without text or usage and provide no mathematical evidence.
