# R653 frozen actual-old-state branching experiment

Root model is frozen and all three Terra owners were released before this document was finalized. No other geometry, old minimizing-gamma source, arbitrary incidence matrix, cone table or independent scan is authorized. The earlier balanced-chain idea is retired; it must not be used to claim that old-source near-optimality generally removes blocking.

## Actual old contract

Use n=1,a=32, old halfsides all 1, centers `(-127/64,0,127/64)`, labels L,C,R. Old I_j are their full disjoint centered receivers of length 1/16. Fix
\[
\epsilon=336/5,\quad\lambda=(7/10,3/10,7/10),\quad
m=(8,16,8),\quad M=16,\ Q=17/5,\ V=3/16,
\quad R=15/272,\quad\kappa=63/17.
\]
The two positive-volume saturated old cells are LC and CR. Source mu has mass 8 uniformly on each `[-1,-1+w]` and `[1-w,1]`. Widths are frozen to initial 1/1024, pressure 1/4096, expanded 1/65536; all are strictly positive. Check source support, row moments, old packing saturation and `m=d+epsilon v/lambda` exactly.

The true H cost includes the factor `1+kappa=80/17`. On the left old source cell,
\[
G_H(x)=(21/17)[2(x+127/64)^2+x^2].
\]
Its constrained minimum is at the boundary -1; right is reflected. Thus
\[
\Phi_{old,H}=126357/2176,\quad
H-\Phi_{old,H}=651w/34+336w^2/17.
\]
This is a genuine AC near-minimizing family, with the positive gap kept. No atom is substituted for an actual source. Old critical kappa is retained, but old R<1 and N is small; the general hard-state/supremum premises are absent.

Euler anchor laws are exactly `X_L~mu_left/8`, `X_R~mu_right/8`, and X_C independently samples the two sources with probabilities 1/2 each. This is the Euler law, not a split minimizing assignment. Growth factors are t=(4,8,4), b=(3/2,7/2,3/2), and new radii are (4,8,4).

## Main full-support decision: k=1

For every anchor in the positive-width supports, when C samples the right component its receiver/image strictly contains L's, while R's receiver/image is far away. C_L fails to contain old A_C, so L is genuinely ineligible on its image and there is a real blocking edge L->C with m_C/m_L=2. C is eligible and L is unavailable as a NEW owner. The opposite component gives the reflected R->C edge. This persists as w decreases to zero despite the old H gap decreasing to zero.

The anticipated actual result, to be independently checked rather than assumed, is that retained owner masses are `(p_C,p_other)=(1/2,1/4)`, actual alpha is `(7/10,3/10)`, and
\[
W=3/4,\quad Q'=68/5,\quad S=12/5,\quad
\kappa'=63/17,\quad E_{old}=2/17,\quad D=0.
\]
Both central mixture branches must be checked on their entire continuous anchor support. If verified, this is a complete Euler anchor expectation, not a fixed-tuple observation. Real lost copies and deleted old labels remain in O and E_old. The test decides that source near-optimality alone does not forbid blocking, while nonempty blocking alone does not give an unpaid D deficit.

## Actual branching stress: duplicate only LEFT labels

For k=2,3, duplicate old A_L exactly k times, split its genuine I_L into k consecutive positive intervals, and set each `v_Li=1/(16k),lambda_Li=7/(10k)`. Then each m_Li remains 8, the same AC source and old KKT remain valid, and Q,V,M,kappa,H are unchanged. The total physical left image volume remains 1/4 and total old source weight `sum a_Li=28/5`; neither grows with k. Unweighted `sum m_Li=8k` does grow. No per-child or per-path copy of source mass is allowed.

At least the event “central anchor samples right” must be certified: it has probability 1/2, all L images/receivers lie inside the central image/receiver, all L labels are capture-ineligible/unavailable, and the star has k incoming blocking edges to C. Its exact D is expected to remain zero. This is a conditional-event certificate only.

**Do not silently discard the other event.** If the central anchor samples left, R is deleted and multiple left labels may remain available with jittered centers. A full expectation claim requires actual ownership/union/fill and entropy KKT for that event too. Otherwise leave that half of the expectation explicitly unpaid. No Monte Carlo or high-dimensional quadrature is needed merely to certify stable support incidences.

Candidate reduction for independent examination, not an assumed result: on the central-left branch let `r=range(c_Li)`. Then the left receiver union may have length `1/4+r`; its image copies still sum to 1/4. If this exact geometry is verified, aggregate leaf owner mass is `P=1/4+r`, central mass is 1/2, and the aggregate leaf alpha beta solves
\[
8+\epsilon P/\beta=16+\epsilon(1/2)/(1-\beta).
\]
Any use of this reduction must keep the actual capture-eligible baseline/free partition and all remaining left labels. The reviewer does not certify it in advance.

## Three nonoverlapping Terra responsibilities

1. `/root/r647_far_certificate`: `numeric/source_certificate.py/json` plus source note. Exact old cubes/I/lambda/AC KKT, the correct H factor, boundary LP optimum/gap, Euler law and symbolic k-split invariance. Do not compute new owners.
2. `/root/r650_entropy_terra`: actual half-action support bounds, E/B intersections, blocking graph and source capture eligibility; full k=1 two-branch D ledger. For k=2/3 retain both events or clearly mark conditional results. No independent source optimization or parameter search.
3. `/root/r650_certificate_terra`: independent joint owner/program and strict KKT certificate with delta=.01, actual p0/availability/deletion, fixed-p actual alpha, and min-price free flow. Certify the full k=1 result and any claimed branching event. Existing future-growth coefficient files remain a separate conditional algebra certificate; no invented two-step dynamics are allowed.

All three share the same widths and old data above. The source owner may record all three widths and symbolic k exactly. Action/program owners should prove support inequalities and certify only the frozen cases, not multiply the workload by independent scans. Exact Fraction/SymPy and outward Arb are preferred; CVXPY/MATLAB may corroborate but never certify an exact sign, zero or actual KKT merely by solver status.

## Acceptance and stop

Required evidence: real old I and AC supports; positive-volume old/new cells; exact KKT or a rigorous algebraic witness; actual Euler conditional laws; actual capture-eligible owners; all old/deleted rows in E/O/fill; and the full D identity with the same Q',S. Store actual commands, versions, errors and final hashes. State whether an output is conditional on one central component or a complete anchor expectation.

The decision is local and exact: can genuine branching coexist with arbitrarily small old-source gap, and which actual source/physical weights prevent fictitious multiplication by child count? Even a positive answer does not establish a Hall capacity inequality, general positive Gamma, critical-R theorem or dimension bound. Stop after these models and hand results to the independent reviewer; do not expand stages or add geometry.
