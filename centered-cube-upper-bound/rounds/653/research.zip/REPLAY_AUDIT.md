# R653 independent isolated replay audit

## Result and scope

All four frozen scripts were copied, executed independently with the designated Python, and their generated JSONs were compared byte-for-byte to the existing artifacts. All four match exactly. This is a reproducibility check of the implemented certificates, not an independent proof of every geometric premise or a global theorem. The model has old R=15/272<1; the small old-source gap is not a near-score critical hard-state certificate.

Before execution I inspected all four scripts for filesystem writes and paths (`rg -n 'open\(|write|Path|__file__|/tmp|json.dump|print\(|time|platform' ...`). Source, owner and future print JSON to stdout; action writes `Path(__file__).with_name('action_budget.json')` and prints a compact summary. No absolute original output path was found. The four scripts were copied unchanged to `/tmp/ccu_r653_replay/`; no path adaptation or diff was needed. Action therefore wrote only beside the copy. All stderr streams were empty and exit statuses were 0.

## Commands and environment

Copy: `mkdir -p /tmp/ccu_r653_replay && cp /tmp/ccu_r653/numeric/{source_certificate.py,action_budget.py,owner_certificate.py,future_certificate.py} /tmp/ccu_r653_replay/`.

A Python `subprocess.run` wrapper invoked the following in order, with cwd `/tmp/ccu_r653_replay`, `OPENBLAS_NUM_THREADS=1` and `OMP_NUM_THREADS=1`. It recorded stdout and stderr in `<name>.stdout` and `<name>.stderr`; stdout was also saved as `<name>.json` for the three stdout-emitting scripts. Elapsed wall times measured by `time.monotonic()` are from this actual run:

| Command (prefix `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r653_replay/`) | Exit | Wall seconds |
|---|---:|---:|
| `source_certificate.py` | 0 | 0.539871 |
| `action_budget.py` | 0 | 0.675508 |
| `owner_certificate.py` | 0 | 0.140329 |
| `future_certificate.py` | 0 | 0.237537 |

Environment: CPython 3.12.14, SymPy 1.14.0, python-flint 0.9.0, `macOS-27.2-arm64-arm-64bit`; future uses Arb precision 256 bits. The action calculation uses Fraction. Times are measurements from this run and differ from earlier approximate reports; they are not stored in the JSON. JSON `python`, `sympy` and `python_flint` version fields match exactly; no platform, version, time, or other fields needed exclusion. JSONs match as bytes, including formatting and all rational endpoints.

## Reproduced findings

- Source: actual AC source masses 8+8, old row masses (8,16,8), H factor 80/17, and LP infimum 126357/2176. For widths 1/1024, 1/4096, 1/65536 the exact H gaps are respectively 20853/1114112, 83349/17825792, 1333269/4563402752, given by `21*w*(32*w+31)/34` and strictly positive. The split model retains total left weighted source mass 28/5 and physical image volume 1/4.
- n=1 k=1: six action records cover all three widths and both central-anchor components; owner certificate has nine rows and its k=1 opposite component is by reflection. Reproduced actual eligible p=(1/2,1/4), alpha=(7/10,3/10), both entropy gradients and overlap multiplier 64, Q'=68/5, S=12/5, W=3/4, E_old=2/17, O=1/4, F=0, RS=9/68, and D=0. Thus the reported k=1 expectation includes both components.
- k=2,3: owner JSON alone is conditional on center-right (probability 1/2); the action JSON explicitly retains center-right D=0 and integrates the center-left branch with fill, giving complete two-branch expectations. Its 256-bin exact rational Darboux bounds (with 64 rational bisections per beta endpoint) reproduce all six entries. Below are the generated decimal displays; exact rational bounds are in the identical action JSON.

| k | w | Complete E[D] lower | Complete E[D] upper |
|---:|---:|---:|---:|
| 2 | 1/1024 | 0.00033660856145982244 | 0.00034057610700584005 |
| 2 | 1/4096 | 0.00008416658589179258 | 0.00008515869969925067 |
| 2 | 1/65536 | 0.000005260693999060142 | 0.0000053227055586064315 |
| 3 | 1/1024 | 0.0005058778715129842 | 0.0005098448108481497 |
| 3 | 1/4096 | 0.0001264955004605148 | 0.0001274875763302455 |
| 3 | 1/65536 | 0.000007906477711343309 | 0.000007968489122634792 |

- Future: exact coefficient `(1+p)/[4(2k-p)]` and supremum 5/12 reproduce along with four Arb point outputs; this remains conditional on the separately supplied geometric/source inequality and any actual next-step ledger.
- The original four-script replay does not cover the 15/64 coefficient: it was not stated in the initially supplied PLAN, REVIEW, four READMEs, four scripts, or JSONs. The later independent F3–F4 verification below uses the separately supplied FUTURE_GROWTH.md; it does not conflate 15/64 with 5/12 or k=1 RS=9/68.

## SHA-256 binding

Copied script hashes match the hashes in NUMERIC_REVIEW. Every original/replay JSON pair has the same SHA-256 and was additionally compared directly as bytes.

| Artifact | Original and replay SHA-256 |
|---|---|
| source_certificate.py | afe617cf99638d4db5f3a9a83c0c2af674cec51e15ff437b9e10f25032665050 |
| source_certificate.json | 511f8d783a5db8b8ee20db243fee1954a5d868444450c0d53f8668a7f5482016 |
| action_budget.py | 13ddc6349bcd5166bd81b482c8c86a279fa847e2be9c30e22db476123f93f37e |
| action_budget.json | 281d89238a8a2360ac8de6f7816d74d688fd15f4bbc10b1390fbfb65f1312ee6 |
| owner_certificate.py | 7cf021c317da4ab516f3c9d611cd9f7ae77ef16289fc5eba98142bcd676ff567 |
| owner_certificate.json | a4fc433ae87a4858a8f4d3e6d268fee5b4fd8edbc6c85bfbf45618dec50e6242 |
| future_certificate.py | df13e0aed1d4adfe65dcf24fd71ce5ecf48a6e6c4c926afe5957eac5b7eb2bef |
| future_certificate.json | 3da14d74af85836bdbc52596dff84981e5d107639f0c363778cf98a30c63d0c7 |

## Supplemental independent F3–F4 check

After the original replay, `/tmp/ccu_r653/FUTURE_GROWTH.md` §§2, F3–F4 was supplied as a new source. The separate script and result `/tmp/ccu_r653_replay/f34_independent.py` and `/tmp/ccu_r653_replay/f34_independent.json` were newly created for this check; the original four numeric scripts do not establish this 15/64 result. Actual command:

```sh
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r653_replay/f34_independent.py > /tmp/ccu_r653_replay/f34_independent.json
```

It completed with exit 0 using Python 3.12.14 and SymPy 1.14.0. The initial candidate gap decomposition failed an assertion; its coefficients were corrected before the successful run. This failure did not affect the four prior identical replay files.

Set `A=8k/3`, `p=kappa'`. On `7/2<=k<=4`, `0<p<=4`, `A-p>=16/3>0`. Exact algebra verifies

`15/64 - (1+p)/[4(A-p)] = [120(k-7/2)+93(4-p)]/[64(8k-3p)] >= 0`,

with equality at `(k,p)=(7/2,4)`, so the maximum is exactly 15/64. Symbolic derivatives also have the expected strict signs. The support square is the exact identity

`A+(u-p)^2/[4(A-p)]-u = [u-(2A-p)]^2/[4(A-p)] >= 0`.

For `u<=A`, `u<=A` needs no quadratic charge; for `u>A`, the square bounds `u-A`. Thus only `u>8k/3>=28/3` carries the quadratic term. Summing with nonnegative weights and assuming the separate source-capacity premise `A_B<=S/4`, `k=epsilon R`, and normalization `E'_Bhi=(1+p)E_next,Bhi` gives `V_B <= (2/3) R S + beta E_next,Bhi`, and then the 15/64 bound. This is conditional arithmetic: it does not prove the source-capacity premise, construct a successor trajectory, or pay overlap and loss.

SHA-256: `f34_independent.py` `9a2687c79f6c3c2ee2dbb2e13de8c4560e3c91b4c2cf708c280b03a2ca9340c7`; `f34_independent.json` `3c7f58af24f6c8feda5f9cd6b1014d6a0352653d5df4f911cc2bbdcfe55e48f9`.
