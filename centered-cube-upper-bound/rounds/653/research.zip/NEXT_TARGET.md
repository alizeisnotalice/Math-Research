# Next target: the complete actual physical branch budget

The general centered-cube n^(1/2+o(1)) weak (1,1) bound remains unproved. Continue the same fixed-epsilon Eulerian route and the R652 fixed-delta=.01 capture/minimum-actual-price owner policy, with the actual recomputed alpha. Keep the genuine old AC KKT source, actual disjoint old I, true independent Euler anchor laws, real receiver Lebesgue measure, and every old/deleted incoming row. Do not replace the task by an abstract graph or a new owner-existence problem.

The complete direct target is E D >= c V - C L M, where D=E_growth-O+F+RS and L=C0 sqrt(n) polylog(n). Equivalently prove E[O-F-RS] <= E_growth-cV+CLM, on all required actual near-score/source-near-optimal states with uniform constants. The single global next-potential allowance is at most 4LM. A partial positive resource or a bound on the outer positive term alone does not prove this net target.

At old kappa>=7/2 define Delta_low=E_low/12-O_low>=0. The exact full ledger is D=11E_low/12+E_high-O_high+F+RS+Delta_low. For actual available owner j let L_j be all high lost copies assigned to it, chi_j=L_j/p_j, a'_j=alpha_j m_j, z_j=mu(C_j\A_j)/m_j, and s0=int(1-sum alpha_j 1_Cj)dmu. Then S=s0+sum a'_j z_j and exactly

O_high-RS = epsilon^(-1) sum_j a'_j[u'_j chi_j-kappa z_j]-R s0.

Thus a proposed capacity theorem must jointly bound this actual weighted branch price using the SINGLE current old growth/fill/slack resources and CLM while leaving a leading cV. The actual dual/cuts count p_j or receiver area once; they do not count p_j chi_j, do not remove u'/epsilon, and do not compare alpha with old lambda. The source columns are unions, not sums of child source masses. Baseline owners still capture, but their delta W area does not erase their multiplicity.

Retain the exact conditional actual-loss formulation. At physical x and frozen other anchors, x in E_k iff X_k in W_k(x)=(t_k/b_k)I_k-y_k-x/b_k. The conditional lost integral must contain h_k(x,z;Z_-k)=1_{actual owner after recomputation is not k}; split that integral inside/outside a frozen lower source union. Dropping h_k only gives a fullincoming upper bound. It must never become an identity for loss. Conditioning on a collision does not preserve the unconditioned Euler row law. There is no source intensity/density cap.

The new norm-nesting scaffold permits true old A containment at a common physical point for moderate rows u<=16,n>=3 once masses differ by K*=32768. Within a parity of mass bands, or at least a two-index gap, all lower cubes lie in all higher cubes. Adjacent opposite-parity bands do not have that conclusion. The per-parity/per-x source annuli are not a single global independently sampled partition. Same-band siblings can repeatedly sample overlapping row-dependent affine source windows. A complete estimate must retain these sibling and all-layer loads; it cannot spend one M per physical x, scale, parity, path or threshold. This norm argument is not a cube-specific dimension saving. Any genuinely cube-specific use of rectangular minimum sets/signed-coordinate contacts must be proved at the full physical price with all high-u, low-dimensional, low-radius and near-active residuals retained.

The exact strong-invasion result may be used only at its proved owner-volume price. For B={z>=4}, on old kappa>=7/2 and 0<kappa'<=4,

V_B <= (2/3)RS + beta E_next,C,
C=B intersect {u'>8kappa/3},
beta=(1+kappa')/[4(8kappa/3-kappa')]<=15/64.

The exact ratio R'/R=kappa'/kappa cancels the artificial inverse-kappa' singularity. C lies in genuinely high successor rows (u'>=28/3 strictly at the support cutoff); no successor lower-kappa bound or mass drop is needed for beta. This is one allocation of one disjoint owner-volume obligation. If a proved geometric reduction costs K times that volume, multiply BOTH terms by K. Do not call this a loss-multiplicity payment or spend its alternative half-RS bound in addition.

If successor growth is used, retain the COMPLETE two-step account. For q=M2/M1<=1 and a separately proved first-step D0>=A0-V_B,

qD0+D1 >= q(A0-(2/3)R0S0)+(1-q beta)E1,C+E1,Ccomplement-O1+F1+R1S1.

The endpoint score subtracts only L[H2-(M2/M0)H0], at most 4LM2, once. In the next carried loss graph, I^2,C^2,alpha^2 are the pre-normalization owners/expanded cubes/weights of the action from state 1, in the coordinates of mu1 and A1; mu1 is not applied to normalized state-2 geometry. The next carried loss graph is capture-high and has genuine alpha-weighted union source capacity, but O1,C AND O1,Ccomplement remain unpaid. Preserve all next overlaps/deletions and the actual entire successor state. An invaded owner alone need not be a KKT state and must not be assigned an independent source allowance.

For finite whole-state continuations, Fscore_T-Fscore_0=sum_{t<T}D_t/M_(t+1)-L[H_T/M_T-H_0/M_0]. The real M_T/M_(t+1) weights cannot be dropped from signed gains. Uniform invasion coefficients apply only when the OLD state lies in their stated domain. A high-R, small-kappa successor is not automatically terminal and does not inherit the old low-copy theorem. If R_next<=K L, the ORIGINAL SINGLE owner-volume obligation can instead be capped by W<=K L M_next; this is neither payment of every future loss nor permission for one terminal source charge per branch. Infinite continuation requires an actual termination/integrability/summability proof.

The actual one-dimensional diagnostic has R=15/272<1 and kappa=63/17. It proves that blocking persists as the old-source H gap tends to zero, and that true label duplication must split old I and its weights. It does not certify near-score critical states. k=1 D=0 is certified on full continuous anchor support in BOTH mixture components. k=2,3 full expectations are certified in action_budget.py by retaining both components and fill; owner_certificate.py by itself supplies only the central-right conditional event. Do not confuse these scopes or run another unrelated fixture/table instead of proving the full joint target.

The next decisive output must therefore be an actual multiplicity-weighted geometric/window/column estimate closing O-F-RS jointly with growth, or a complete score/controlled recursion with all these residual and terminal terms. Stronger path nesting, another Hall reformulation, a fixed-alpha variation, a positive-term external cap, or coefficient headroom alone is insufficient. Any theorem author should hand the concrete proof to an independent reviewer before integration; no self-certification of general improvement.
