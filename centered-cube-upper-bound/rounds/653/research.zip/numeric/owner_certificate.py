"""Exact endpoint and conditional replicated-owner checks; no numerical solver."""
from fractions import Fraction as F
import json,platform
import sympy as sp
D=F; eps=D(336,5); delta=D(1,100); y=D(127,64); r=D(15,272)
results=[]
for w in (D(1,1024),D(1,4096),D(1,65536)):
 # center anchors: C right [-7/2, -7/2+(7/2)w]; L/R anchors in their own source boxes
 C=(-D(7,2),-D(7,2)+D(7,2)*w)
 L=(-D(443,128)-D(3,2)*w,-D(443,128))
 R=(D(443,128),D(443,128)+D(3,2)*w)
 max_CL=max(abs(a-b) for a in C for b in L)
 min_CR=min(abs(a-b) for a in C for b in R)
 max_CR=max(abs(a-b) for a in C for b in R)
 assert max_CL+D(1,8)<D(1,4) # every shifted left E is inside center receiver/image
 assert min_CR>D(1,4)+D(1,8) # right receiver disjoint
 assert max_CR<12 # retained C cubes overlap positively
 assert min(C)-8<=-y-1 and max(C)+8>=y+1 # check stronger below for all centers
 assert max(C)-8<=-y-1 and min(C)+8>=y+1
 assert max(abs(a+y) for a in L)+1<4 # left C contains own old A
 assert max(abs(a-y) for a in R)+1<4 # right C contains own old A
 assert max(L)+4<1 # left C fails to contain the high center A
 assert sum([D(7,10),D(3,10)])==1
 for k in (1,2,3):
  # center-right anchor event: each copy's E subset center; left never eligible.
  p=[D(1,2),D(1,4)]; alpha=[D(7,10),D(3,10)]; m=[16,8]
  gradient=[m[i]+eps*p[i]/alpha[i] for i in range(2)]
  assert gradient==[64,64] and all(a>0 for a in alpha)
  Q=sum(alpha[i]*m[i] for i in range(2)); S=16-Q; W=sum(p)
  assert (Q,S,W,eps*W/Q,W-r*Q)==(D(68,5),D(12,5),D(3,4),D(63,17),0)
  # All old left k copies retained in overlap loss despite deletion from new owners.
  old_left_ell=sum([D(1,4*k)]*k,D(0)); assert old_left_ell==D(1,4)
  results.append({'w':str(w),'k':k,'event':'center anchor in right source box, conditional probability 1/2','max_center_left_distance':str(max_CL),'min_center_right_distance':str(min_CR),'max_center_right_distance':str(max_CR),'left_new_owners_deleted':k,'old_left_lost_copy_volume':str(old_left_ell),'retained_labels':['center','right'],'p':list(map(str,p)),'p0':list(map(str,p)),'alpha':list(map(str,alpha)),'entropy_stationarity':list(map(str,gradient)),'entropy_overlap_multiplier':'64','delta':str(delta),'Qprime':str(Q),'S':str(S),'W':str(W),'kappa_prime':str(eps*W/Q),'D':str(W-r*Q)})
print(json.dumps({'python':platform.python_version(),'sympy':sp.__version__,'status':'exact rational inequalities valid for all continuous anchors in stated boxes','scope':'k=1 complete via reflection; k=2,3 center-right conditional branch only; no near-maximal or critical R assertion','rows':results},indent=2))
