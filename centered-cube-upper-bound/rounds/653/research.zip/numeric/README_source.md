# R653 old-source certificate

Run `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r653/numeric/source_certificate.py > /tmp/ccu_r653/numeric/source_certificate.json`. Actual environment: CPython 3.12.14, SymPy 1.14.0; execution took approximately 0.3 seconds. All certificate identities and three widths use exact SymPy rational/symbolic arithmetic; the JSON decimals are display only.

The fixed old intervals have radius 1, centers −127/64, 0, 127/64; their positive-volume saturated cells are [−1,−63/64] and [63/64,1], with loads 7/10+3/10=1. The actual disjoint old receiver/owner intervals have radius 1/32. With v=1/16 and ε=336/5, d+εv/λ gives (8,16,8), with μ(A)=(8,16,8). Each actual source is uniform of mass 8 on each of [−1,−1+w], [1−w,1], with w positive and less than 1/64; density is 8/w. Total mass is 16 and saturation holds μ-almost everywhere. Thus μ witnesses the old entropy KKT condition; no source atom is used.

For the left saturated cell, the **unscaled** source density is Graw=(21/40)(x+127/64)²+(21/80)x². The actual old potential density is G_H=(1+κ)Graw=(80/17)Graw. Its stationary point −127/96 is outside the cell, so its cell infimum is attained at −1; the right cell is symmetric. LP source masses (8,8) and dual (c,0,c), c=126357/34816, prove Φold,H=126357/2176. Positive-width integration gives exactly

 H−Φold,H = 651w/34 + 336w²/17.

The unscaled gap, retained separately to prevent normalization errors, is 651w/160 + 21w²/5. The three JSON stages give exact positive H gaps and actual H values. This is a near-old-source infimum as w decreases, not a near-score certificate: R=15/272<1 and the full critical hard-state premise is absent.

For left row duplication into k identical cube labels, λ=7/(10k), v=1/(16k), and the original left receiver is partitioned by edges −129/64+j/(16k), j=0,…,k. Every copy has the same μ(A)=8; they share the same physical μ, rather than acquiring k separate source capacities. The summed weighted price ∑λm remains 28/5, and ∑εv/m times the common squared-radius term remains unchanged. Concrete k=2 and k=3 partitions are in JSON, with the general symbolic identities in the script. Euler conditional anchor laws are uniform on the left box for each left copy, a half-and-half mixture of both boxes for the center row, and uniform on the right box for the right row.

SHA-256: source_certificate.py `afe617cf99638d4db5f3a9a83c0c2af674cec51e15ff437b9e10f25032665050`; source_certificate.json `511f8d783a5db8b8ee20db243fee1954a5d868444450c0d53f8668a7f5482016`.
