"""R653 pre-registered 3-width exact old KKT and AC source certificate."""
from fractions import Fraction as F
import json, platform
import sympy as sp

w=sp.symbols('w',positive=True)
z=sp.symbols('z',real=True)
k=sp.symbols('k',integer=True,positive=True)
j=sp.symbols('j',integer=True,positive=True)
r=sp.Rational
s=r(1); a=r(32); eps=r(336,5); v=r(1,16)
y=r(127,64); dl=r(2); lam=(r(7,10),r(3,10),r(7,10))
m=tuple(sp.factor(dl+eps*v/l) for l in lam)
assert m==(8,16,8)
assert sum(lam[i]*m[i] for i in range(3))==16
Q=sum(l*dl for l in lam); V=3*v; R=V/Q; kap=eps*R
assert (Q,V,R,kap)==(r(17,5),r(3,16),r(15,272),r(63,17))
# Old packing has two positive-volume saturated cells, all other loads below 1.
assert lam[0]+lam[1]==1 and lam[1]+lam[2]==1
assert max(lam)<1 and 2*y>2 and y<2
left=(-1,1-y); right=(y-1,1)
assert left==(-1,-r(63,64)) and right==(r(63,64),1)
# Old actual owner intervals B_i, each of length 1/16, are disjoint.
assert y>2/a and 2/a==v
# On the left cell the self-source weighting is eps * sum_j v_j/m_j * normalized radius².
Graw=r(21,40)*(z+y)**2+r(21,80)*z**2
G=(1+kap)*Graw
stationary=sp.solve(sp.diff(G,z),z)[0]
assert stationary==-r(127,96) and stationary<-1
cellmin=sp.factor(G.subs(z,-1)); phi=16*cellmin
HA=sp.factor(16*sp.integrate(G.subs(z,-1+w*sp.Symbol('q')),(sp.Symbol('q'),0,1)))
gap=sp.factor(HA-phi)
assert phi==r(126357,2176)
assert sp.simplify(gap-(r(651,34)*w+r(336,17)*w*w))==0
# k identical left labels: alpha and owned pieces each split, sources remain SAME mu.
assert sp.simplify(k*(lam[0]/k)-lam[0])==0
assert sp.simplify(k*(v/k)-v)==0
assert sp.simplify(dl+eps*(v/k)/(lam[0]/k)-m[0])==0
assert sp.simplify(k*(eps*(v/k)/m[0])-eps*v/m[0])==0
assert sp.simplify(k*(lam[0]/k*m[0])-lam[0]*m[0])==0
# Contiguous actual owned pieces partition the full left receiver, up to endpoints.
edge=lambda j: -y-1/a+j/(16*k)
assert sp.simplify(edge(0)-(-y-1/a))==0
assert sp.simplify(edge(k)-(-y+1/a))==0
assert sp.simplify(edge(j)-edge(j-1)-1/(16*k))==0
# LP primal source masses (8,8), dual (cellmin,0,cellmin) match.
assert 8*cellmin+8*cellmin==phi
splits=[]
for count in (2,3):
 edges=[sp.factor(edge(q).subs(k,count)) for q in range(count+1)]
 pieces=[[str(edges[i]),str(edges[i+1])] for i in range(count)]
 assert sum((edges[i+1]-edges[i] for i in range(count)),sp.Rational(0))==v
 assert edges[0]==-y-1/a and edges[-1]==-y+1/a
 assert all(edges[i]<edges[i+1] for i in range(count))
 assert count*(lam[0]/count)==lam[0] and count*(v/count)==v
 assert count*(lam[0]/count)*m[0]==lam[0]*m[0]
 splits.append({'k':count,'left_owned_pieces':pieces,'lambda_each':str(lam[0]/count),'v_each':str(v/count),'mu_each_row':'8','weighted_source_mass_all_copies':'28/5','source_mu_total':'16'})
cases=[]
for den in (1024,4096,65536):
 W=r(1,den)
 assert 0<W<r(1,64)
 H=sp.factor(HA.subs(w,W)); g=sp.factor(gap.subs(w,W))
 assert H-phi==g and g>0
 cases.append({'w':str(W),'left_box':[str(-1),str(-1+W)],'right_box':[str(1-W),'1'],
  'density_each':str(8/W),'left_mass':'8','right_mass':'8','m_rows':[str(x) for x in m],
  'H':str(H),'old_source_infimum':str(phi),'gap':str(g),'gap_decimal':str(sp.N(g,18))})
result={'python':platform.python_version(),'sympy':sp.__version__,
 'scope':'actual old n=1 packing, entropy KKT and AC source; R<1, not near-score',
 'old_centers':[str(-y),'0',str(y)],'old_radii':'1','receiver_radii':'1/32',
 'lambda':list(map(str,lam)),'v':'1/16','epsilon':str(eps),'m':list(map(str,m)),
 'M':'16','Q':str(Q),'V':str(V),'R':str(R),'kappa':str(kap),
 'cells':{'left':list(map(str,left)),'right':list(map(str,right))},
 'G_raw_left':str(sp.expand(Graw)),'H_factor':str(1+kap),'G_H_left':str(sp.expand(G)),'G_stationary':str(stationary),'G_min':str(cellmin),'Phi_old':str(phi),
 'lp_primal':['8','8'],'lp_dual':[str(cellmin),'0',str(cellmin)],
 'gap_raw_formula':str(sp.factor(gap/(1+kap))),'gap_H_formula':str(gap),'split_edge_formula':str(edge(j)),'split_statement':'k copies of left row have weight 7/(10k), volume 1/(16k), same source row mass 8, and equal consecutive parts of its original receiver; total weighted source price remains 28/5',
 'anchor_laws':'left uniform on left box, center independent half-mixture of both boxes, right uniform on right box; duplicate left rows condition on same mu, not independent source capacities',
 'split_cases':splits,'stages':cases}
print(json.dumps(result,indent=2))
