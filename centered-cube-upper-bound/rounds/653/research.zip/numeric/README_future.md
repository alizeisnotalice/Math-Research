# R653 future-growth coefficient audit

**Conditional result.** Given the independently reviewed strong-invasion estimate

`V_bad <= R*S/2 + E'_bad/[4(2*kappa-kappa')]`,

and the same-successor scaling `E'_bad=(1+kappa') E_next,bad`, the coefficient charged to normalized next growth is

`c(kappa,kappa')=(1+kappa')/[4(2*kappa-kappa')]`.

Here `kappa=epsilon R`, `kappa'=epsilon R'`, `kappa>=7/2`, `0<kappa'<=4`, so the denominator is positive. This document certifies the arithmetic and normalization **conditional on** the geometry/source inequality and its label subset being valid. It does not establish that inequality or bound lost-copy multiplicity by the disjoint bad-owner volume.

The following exact identity proves the advertised bound without a grid:

`5/12-c = [10(kappa-7/2)+8(4-kappa')]/[12(2*kappa-kappa')] >= 0`.

Equality occurs at `(kappa,kappa')=(7/2,4)`. The partial derivatives with respect to old kappa and next kappa are respectively `-(1+kappa')/[2(2*kappa-kappa')²]` and `(2*kappa+1)/[4(2*kappa-kappa')²]`. As `kappa'` decreases to zero, `c -> 1/(8 kappa) <= 1/28`. This continuous coefficient limit is not a claim that a successor with `kappa'=0` satisfies the nondegenerate new-entropy definitions or is realizable. No artificial `1/kappa'` divergence is present in this improved coefficient.

In the two-step endpoint-score ledger, if the earlier action's charge is multiplied by `theta=M_(t+2)/M_(t+1)`, its coefficient becomes `theta*c`. The actual packing/slack relation `Q'<=M` gives `theta<=1` for the relevant valid successor action, hence `theta*c<=5/12`. The availability of actual next growth after other charges must be verified in the complete ledger; the numerical headroom alone neither pays next overlap/fill/slack nor provides a terminal estimate. A successor below the critical band cannot be declared harmless without its own valid stopping and remainder argument.

The actual algebra behind the source estimate can be checked pointwise. Let `A=2*kappa>kappa'`. For every `v>=0`,

`A+(v-kappa')²/[4(A-kappa')]-v = [v-(2A-kappa')]²/[4(A-kappa')] >= 0`.

For retained bad labels, write `a'_j=alpha_j m_j` and `v=u'_j`, so `p_j=a'_j u'_j/epsilon`, `E'_bad=sum_bad a'_j (u'_j-kappa')²/epsilon`. The independent source-capacity input `sum_bad a'_j<=S/4` then yields the displayed `V_bad` bound, since `(2*kappa/epsilon)*(S/4)=R*S/2`. The square identity and this summation are independently checked; the source-capacity premise and its geometry require the separate proof audit. In particular the conclusion remains a bound for bad **owner volume**, not lost-copy multiplicity.

Equivalently, the pre-cancellation coefficient `r/[4(2-r)]` multiplying `E'_bad/kappa'` is exactly `1/[4(2*kappa-kappa')]` after `r=kappa'/kappa`; the script checks the identity symbolically.

The dependency that must not be frozen is `r=R'/R=kappa'/kappa`. SymPy checks `R-rR/2=R(2kappa-kappa')/(2kappa)`. This check alone is not a proof of the strong-invasion inequality; it records the algebraic link needed in an independent derivation.

Reproduce the arithmetic and fixed rational-parameter Arb examples with `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r653/numeric/future_certificate.py > /tmp/ccu_r653/numeric/future_certificate.json`. Actual environment Python 3.12.14, SymPy 1.14.0, python-flint 0.9.0, Arb 256 bits, with outward radii in the JSON. The four evaluations merely illustrate the exact proof. Initial use of structural equality between differently factored SymPy expressions raised an assertion; after replacing it by exact simplified zero, the recorded run passed.

One independently executed MATLAB floating check:

`MATLAB 26.1.0.3312084 (R2026a) Update 4; coefficient 0.41666666666666669; residual from 5/12 0`

This checks `(kappa,kappa')=(7/2,4)` in floating arithmetic and is not a proof. The general full D/Gamma budget, source/copy multiplicity, and termination remain open.
