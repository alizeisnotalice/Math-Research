"""Exact whole-support Euler action budget, R653 frozen k=1 model."""
from fractions import Fraction as F
from itertools import product
import json,platform
from pathlib import Path

y=[-F(127,64),F(0),F(127,64)]; t=[F(4),F(8),F(4)]; b=[F(3,2),F(7,2),F(3,2)]
oldA=[(c-1,c+1) for c in y]; oldI=[(c-F(1,32),c+F(1,32)) for c in y]
lam=[F(7,10),F(3,10),F(7,10)]; masses=[F(8),F(16),F(8)]; eps=F(336,5)
Q=sum(2*x for x in lam); V=F(3,16); M=F(16); R=V/Q
assert oldI[0][1]<oldI[1][0]<oldI[1][1]<oldI[2][0]
assert Q==F(17,5) and R==F(15,272)

def run(w,branch):
    # Euler laws: each outer source mass lives in one box; central independent law is the equal mixture.
    left=(-F(1),-F(1)+w); right=(F(1)-w,F(1))
    ranges=[left,left if branch=='left' else right,right]
    deleted=2 if branch=='left' else 0; own=0 if branch=='left' else 2
    margins={'capture_C_contains_all_oldA':[], 'B_deleted_inside_B_center':[],
             'B_center_disjoint_B_outer_owner':[], 'deleted_C_fails_capture_center':[],
             'retained_C_intersection':[], 'old_source_boxes_in_correct_A':[]}
    for X in product(*[(lo,hi) for lo,hi in ranges]):
        c=[(1+b[j])*y[j]-b[j]*X[j] for j in range(3)]
        C=[(c[j]-t[j],c[j]+t[j]) for j in range(3)]
        B=[(c[j]-t[j]/32,c[j]+t[j]/32) for j in range(3)]
        margins['capture_C_contains_all_oldA'].extend([min(oldA[j][0]-C[1][0],C[1][1]-oldA[j][1]) for j in range(3)])
        margins['B_deleted_inside_B_center'].append(min(B[deleted][0]-B[1][0],B[1][1]-B[deleted][1]))
        margins['B_center_disjoint_B_outer_owner'].append((B[1][0]-B[own][1] if own==0 else B[own][0]-B[1][1]))
        margins['deleted_C_fails_capture_center'].append((oldA[1][1]-C[deleted][1] if deleted==0 else C[deleted][0]-oldA[1][0]))
        margins['retained_C_intersection'].append(min(C[1][1],C[own][1])-max(C[1][0],C[own][0]))
    margins['old_source_boxes_in_correct_A']=[min(left[0]-oldA[0][0],oldA[0][1]-left[1], left[0]-oldA[1][0],oldA[1][1]-left[1],right[0]-oldA[2][0],oldA[2][1]-right[1],right[0]-oldA[1][0],oldA[1][1]-right[1])]
    margins={k:min(v) for k,v in margins.items()}; assert margins['old_source_boxes_in_correct_A']>=0 and all(v>0 for k,v in margins.items() if k!='old_source_boxes_in_correct_A'), margins
    # Only center is eligible on its receiver; the other retained row owns its disjoint receiver.
    p=[F(0),F(1,2),F(0)];p[own]=F(1,4)
    alpha=[F(0),F(7,10),F(0)];alpha[own]=F(3,10)
    gradient=[masses[i]+eps*p[i]/alpha[i] for i in (1,own)]
    assert gradient==[F(64),F(64)] and alpha[1]+alpha[own]==1
    Qnew=sum(alpha[i]*masses[i] for i in range(3)); S=M-Qnew; W=sum(p)
    ell=sum((t[j]/16 for j in range(3)),F(0)); growth=ell-R*M; lost=F(1,4); fill=F(0)
    assert W==ell-lost+fill
    D=growth-lost+fill+R*S
    assert D==W-R*Qnew==0
    return {'w':w,'central_anchor_branch':branch,'anchor_probability':F(1,2),'anchor_ranges':ranges,
      'strict_whole_support_margins':margins,'deleted_row':deleted,'retained_rows':[1,own],
      'blocking_edge_ineligible_to_witness':[deleted,1], 'ell':ell,'old_R':R,'growth_E':growth,'lost_O':lost,'fill':fill,
      'p':p,'alpha':alpha,'entropy_gradients':gradient,'packing_dual':F(64),
      'Q_prime':Qnew,'S':S,'R_times_S':R*S,'W':W,'D':D,'kappa_prime':eps*W/Qnew,
      'baseline_delta':'1/100','baseline_and_free':'same forced owner on each positive-volume atom'}

def clone_support(k,w,branch):
    # Vertices cover all independent Euler anchor boxes, one for each clone.
    left=(-F(1),-F(1)+w); right=(F(1)-w,F(1))
    ranges=[left]*k+[left if branch=='left' else right,right]
    margins={'central_captures_all_oldA':[], 'captured_outer_B_inside_central_B':[],
             'noncaptured_B_disjoint_central_B':[], 'blocked_C_misses_center_A':[],
             'all_available_C_joint_overlap':[], 'clone_E_exclusive_core':[]}
    for X in product(*[(lo,hi) for lo,hi in ranges]):
        cL=[(1+b[0])*y[0]-b[0]*X[j] for j in range(k)]
        cC=-b[1]*X[k]; cR=(1+b[2])*y[2]-b[2]*X[k+1]
        Cc=(cC-8,cC+8); Cright=(cR-4,cR+4); CL=[(z-4,z+4) for z in cL]
        Bc=(cC-F(1,4),cC+F(1,4)); Br=(cR-F(1,8),cR+F(1,8)); BL=[(z-F(1,8),z+F(1,8)) for z in cL]
        margins['central_captures_all_oldA'].extend(min(A[0]-Cc[0],Cc[1]-A[1]) for A in oldA)
        if branch=='right':
            margins['captured_outer_B_inside_central_B'].extend(min(B[0]-Bc[0],Bc[1]-B[1]) for B in BL)
            margins['noncaptured_B_disjoint_central_B'].append(Br[0]-Bc[1])
            margins['blocked_C_misses_center_A'].extend(1-C[1] for C in CL)
            cs=[Cc,Cright]
        else:
            margins['captured_outer_B_inside_central_B'].append(min(Br[0]-Bc[0],Bc[1]-Br[1]))
            margins['noncaptured_B_disjoint_central_B'].extend(Bc[0]-B[1] for B in BL)
            margins['blocked_C_misses_center_A'].append(Cright[0]+1)
            cs=[Cc]+CL
        margins['all_available_C_joint_overlap'].append(min(z[1] for z in cs)-max(z[0] for z in cs))
        margins['clone_E_exclusive_core'].append(F(1,4*k)-(max(cL)-min(cL)))
    mins={key:min(v) for key,v in margins.items()};assert all(v>0 for v in mins.values()),mins
    return mins

def beta_bracket(P):
    lo,hi=F(0),F(1)
    for _ in range(64):
        x=(lo+hi)/2
        derivative=8-16+eps*P/x-eps*F(1,2)/(1-x)
        if derivative>0:lo=x
        else:hi=x
    return lo,hi

def range_cdf(k,z):
    return k*z**(k-1)-(k-1)*z**k

def clone_integral(k,w,N=256):
    Pmax=F(1,4)+F(3,2)*w
    def derivative(beta,P):return 8-16+eps*P/beta-eps*F(1,2)/(1-beta)
    assert derivative(F(3,10),F(1,4))==0 and derivative(F(31,100),Pmax)<0
    Qlower=16-8*F(31,100); Wupper=F(1,2)+Pmax
    assert eps*Wupper/Qlower<4
    def D_bounds(z):
        P=F(1,4)+F(3,2)*w*z
        lo,hi=beta_bracket(P)
        return P-F(13,34)+F(15,34)*lo,P-F(13,34)+F(15,34)*hi
    lo=hi=F(0)
    # D is increasing in r because P and the KKT root beta both increase.
    for j in range(N):
        z0=F(j,N);z1=F(j+1,N); mass=range_cdf(k,z1)-range_cdf(k,z0)
        lo+=mass*D_bounds(z0)[0]/2;hi+=mass*D_bounds(z1)[1]/2
    range_mean=w*F(k-1,k+1)
    Wmean=F(3,4)+F(3,4)*range_mean
    # Full mean includes center-left probability 1/2. Each clone image is an ordered subinterval.
    fillmean=F(3,4)*w*(k-1)*(F(1,k+1)+F(1,6))
    Omean=1-Wmean+fillmean
    return {'k':k,'w':w,'partition_count':N,'beta_bisection_iterations':64,
       'beta_all_support_bounds':[F(3,10),F(31,100)],'Q_prime_lower_bound':Qlower, 'kappa_prime_upper_bound':eps*Wupper/Qlower,
       'source_range_mean':range_mean,'expected_W':Wmean,'expected_fill':fillmean,
       'expected_O':Omean,'growth_E':F(2,17),'ED_lower':lo,'ED_upper':hi,
       'ED_float_enclosure':[float(lo),float(hi)],'ED_width':hi-lo,
       'support_left':clone_support(k,w,'left'),'support_right':clone_support(k,w,'right'),
       'center_right':'D=0; all left incoming clone images retained in O, zero ownership',
       'center_left':'P=1/4+3 range/2; alpha_i=beta p_i/P; p_center=1/2',
       'expected_RS_bounds':[lo-F(2,17)+Omean-fillmean,hi-F(2,17)+Omean-fillmean]}

def stringify(x):
    if isinstance(x,F):return str(x)
    if isinstance(x,dict):return {str(k):stringify(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)):return [stringify(v) for v in x]
    return x

if __name__=='__main__':
    records=[run(w,branch) for w in (F(1,1024),F(1,4096),F(1,65536)) for branch in ('left','right')]
    result={'python':platform.python_version(),'k':1,'cases':records,'expected_D_per_width':[F(0)]*3,'clone_cases':[clone_integral(k,w) for k in (2,3) for w in (F(1,1024),F(1,4096),F(1,65536))],
       'reason':'geometry checks at every box vertex; each margin is min of affine differences; D and optimizer independent of anchors','scope':'fixed genuine old model, old R=15/272<1; no near-score or general global bound'}
    Path(__file__).with_name('action_budget.json').write_text(json.dumps(stringify(result),indent=2)+'\n')
    print(json.dumps(stringify({'k':1,'cases':len(records),'expected_D_per_width':result['expected_D_per_width'],'margins_first':records[0]['strict_whole_support_margins'],'D':records[0]['D'],'clone_ED':[{'k':z['k'],'w':z['w'],'enclosure':z['ED_float_enclosure']} for z in result['clone_cases']]})))
