#!/usr/bin/env python3
import json, platform
from fractions import Fraction as F
import sympy as s
k,p,u=s.symbols('k p u', real=True)
A=s.Rational(8,3)*k
beta=(1+p)/(4*(A-p))
square=s.factor(A+(u-p)**2/(4*(A-p))-u-(u-(2*A-p))**2/(4*(A-p)))
assert square==0
# Decompose the gap using nonnegative coordinates k-7/2 and 4-p.
gap=s.factor(s.Rational(15,64)-beta)
certificate=(120*(k-s.Rational(7,2))+93*(4-p))/(64*(8*k-3*p))
assert s.simplify(gap-certificate)==0
assert s.simplify(s.diff(beta,k)+s.Rational(2,3)*(1+p)/(A-p)**2)==0
assert s.simplify(s.diff(beta,p)-(A+1)/(4*(A-p)**2))==0
assert beta.subs({k:s.Rational(7,2),p:4})==s.Rational(15,64)
assert F(8,3)*F(7,2)-4==F(16,3)
assert F(8,3)*F(7,2)==F(28,3)
# A/epsilon = (8/3) R; A*(S/4)/epsilon = (2/3) R S.
R,eps,S=s.symbols('R eps S', positive=True)
assert s.simplify((s.Rational(8,3)*eps*R)*(S/4)/eps-s.Rational(2,3)*R*S)==0
out={
 'python':platform.python_version(),'sympy':s.__version__,
 'domain':'7/2 <= k <= 4, 0 < p <= 4',
 'denominator_lower_bound':'A-p >= 16/3 > 0',
 'A':str(A),'beta':str(beta),'square_residual':str(square),
 'square_identity':'A+(u-p)^2/[4(A-p)]-u=(u-(2A-p))^2/[4(A-p)]',
 'gap_certificate':'15/64-beta=[120(k-7/2)+93(4-p)]/[64(8k-3p)] >= 0',
 'maximum':'15/64 at k=7/2,p=4',
 'derivatives':'d beta/dk=-(2/3)(1+p)/(A-p)^2 < 0; d beta/dp=(A+1)/[4(A-p)^2] > 0',
 'support':'u>A=8k/3 >= 28/3',
 'support_argument':'u <= A+(u-A)_+; on u>A the square gives u-A <= (u-p)^2/[4(A-p)]; on u<=A no quadratic charge',
 'summed_budget':'assuming A_B<=S/4, k=eps R, a_j>=0, u_j>=0, V_B=sum a_j*u_j/eps, Eprime_Bhi=sum_Bhi a_j*(u_j-p)^2/eps, Eprime_Bhi=(1+p)*E_next_Bhi: V_B <= (2/3) R S + beta E_next_Bhi',
 'scope':'conditional arithmetic; does not establish source capacity, actual trajectory or payment of overlap/loss'
}
print(json.dumps(out,indent=2))
