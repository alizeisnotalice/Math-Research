"""Exact R653 coefficient algebra and fixed Arb end-point checks.
Conditional on the actual-geometry strong-invasion inequality; this file does not prove it.
"""
import json,platform
import sympy as S
from flint import arb,ctx
import flint
ctx.prec=256
k,p,theta,ep,R=S.symbols('k p theta eps R',positive=True)
c=(1+p)/(4*(2*k-p))
v=S.symbols('v',real=True); A=2*k
assert S.simplify(A+(v-p)**2/(4*(A-p))-v-(v-(2*A-p))**2/(4*(A-p)))==0
assert S.simplify((p/k)/(4*(2-p/k))/p-1/(4*(2*k-p)))==0
assert S.simplify(S.diff(c,k)+(p+1)/(2*(2*k-p)**2))==0
assert S.simplify(S.diff(c,p)-(2*k+1)/(4*(2*k-p)**2))==0
assert S.simplify(S.Rational(5,12)-c-(10*(k-S.Rational(7,2))+8*(4-p))/(12*(2*k-p)))==0
assert S.limit(c,p,0,dir='+')==1/(8*k)
# Exact cancellation kappa'=eps R' and kappa=eps R.
r=p/k
assert S.simplify((R-r*R/2)-(2*k-p)*R/(2*k))==0
# Next growth scaling is E'_bad=(1+p) E_next,bad, conditional on E_next definition.
# two-step endpoint account multiplies previous charge by theta=M_(t+2)/M_(t+1).
assert S.simplify(theta*c-theta*(1+p)/(4*(2*k-p)))==0
points=[]
for kt,pt in [('7/2','4'),('7/2','1/1000000'),('4','4'),('4','1')]:
 ka,pa=arb(kt),arb(pt)
 val=(1+pa)/(4*(2*ka-pa))
 points.append({'old_kappa':kt,'next_kappa':pt,'coefficient':val.str(35,more=True),'two_step_max_theta_1':val.str(35,more=True)})
out={'python':platform.python_version(),'sympy':S.__version__,'python_flint':flint.__version__,'precision_bits':ctx.prec,'domain':'k>=7/2, 0<p<=4; p<2k; theta in [0,1] if actual normalization gives it','coefficient':str(c),'exact_supremum':'5/12 attained at (k,p)=(7/2,4)','p_to_zero_limit':'1/(8*k)','endpoint_limit_sup':'1/28','two_step_coefficient':'theta*(1+p)/(4*(2*k-p))','two_step_bound':'5/12 (conditional theta<=1)','unpaid':'source proof; actual geometric assumptions; next overlap/slack and terminal ledger; lower bound if future uncalibrated','fixed_points':points}
print(json.dumps(out,indent=2))
