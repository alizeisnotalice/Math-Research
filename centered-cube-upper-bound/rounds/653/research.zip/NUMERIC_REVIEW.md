# R653 independent numerical acceptance: genuine old-state blocking

**Verdict: accepted within the frozen finite model.** Unlike a new-C-only toy, this family supplies actual old geometry, disjoint owned I, actual old entropy lambda, an AC KKT source, Euler anchor laws, and true new capture-eligible ownership with reoptimized alpha. It has old kappa=63/17 in the intended band and arbitrarily small old-source optimality gap. It still has **old R=15/272<1 and is not a near-score critical hard state**. No global theorem or dimension improvement follows.

The earlier balanced-chain source idea was retired before execution. Root's stronger endpoint-source chain is the sole accepted old geometry. I independently derived the scalar identities and geometry before reading the final author scripts, inspected the three independent source/action/owner certificates, and performed one bounded local symbolic/Fraction postcheck. I did not rerun old tables, author action quadrature, a large scan, CVXPY or MATLAB. Only PLAN/REVIEW were written by this reviewer.

## 1. Actual old contract and the correct H objective

The old halfsides are 1 and centers are `(-127/64,0,127/64)`. The three full old receivers, each length 1/16, are genuinely disjoint. Exact values are
\[
\epsilon=336/5,\quad\lambda=(7/10,3/10,7/10),\quad
m=(8,16,8),\quad Q=17/5,\ V=3/16,\ M=16,
\quad R=15/272,\ \kappa=63/17.
\]
The actual old saturated cells are LC=`[-1,-63/64]` and CR=`[63/64,1]`, not one common old cell. Their source masses are 8 each. All other positive-volume old cells have load below one, so the proposed source satisfies saturation exactly. These masses give every row moment `mu(A_j)=m_j`, and `d_j+epsilon v_j/lambda_j=m_j`. This is a complete supporting-gradient witness for the old entropy optimum; m is not a freely chosen new-C input.

For each positive width w in {1/1024,1/4096,1/65536}, source density is 8/w on each `[-1,-1+w]` and `[1-w,1]`. The endpoint coincidence with old A_C is harmless for AC measure; actual source points are inside the appropriate closed cubes and a.e. in their interiors. No atom is substituted as actual input.

The H density includes the factor `1+kappa=80/17`. On LC,
\[
G_H(x)=(21/17)[2(x+127/64)^2+x^2].
\]
Its unconstrained minimum -127/96 lies outside LC, so its constrained minimum is at -1. The right cell is reflected. Source LP masses `(8,8)` and dual `(G_H(-1),0,G_H(-1))` certify
\[
\Phi_{old,H}=126357/2176,\qquad
H-\Phi_{old,H}=651w/34+336w^2/17.
\]
The three positive gaps are approximately 0.0187171,0.00467575,0.000292166 and tend to zero with w. The source certificate explicitly distinguishes its unscaled raw price from H. A preliminary raw-price calculation missing 80/17 was corrected **before** the recorded run; only the corrected H objective is accepted.

For k duplicate left labels, actual old I_L is partitioned into k consecutive positive intervals, with each `v=1/(16k),lambda=7/(10k)`. The old row mass remains 8; the same mu and old KKT remain valid. This is a real ownership split, not k copies of old receiver volume. Total left weighted source mass is 28/5 and total left image volume is 1/4 for every k.

## 2. Euler laws and persistent real blocking

Every left anchor has law mu_L/8, every right anchor mu_R/8, and the independent central anchor samples those two distributions with probabilities 1/2. Duplicate left anchors are independent draws from the same conditional source law; this does **not** create independent copies of source capacity. No minimizing-gamma assignment or nearest-center substitution is used.

The true half action has t=(4,8,4), b=(3/2,7/2,3/2), new radii (4,8,4). If the center anchor is in the right source component, its center lies in `[-7/2,-7/2+(7/2)w]`, left centers in `[-443/128-(3/2)w,-443/128]`, and right center in `[443/128,443/128+(3/2)w]`.

Throughout these continuous support boxes, every left E/B is strictly inside the central E/B, while the right receiver is disjoint. The central C contains every old A. Each left C has right endpoint at most 69/128<1 and therefore fails to contain the high central old A. Thus the **ineligible-to-witness** edge is L->C, with m ratio 16/8=2. This is genuine capture ineligibility under true m, not a graph imposed on unrelated cubes. The other central component gives the reflected edge for k=1.

The final action metadata was corrected to name the edge `blocking_edge_ineligible_to_witness=[deleted,center]`. A prior field listed blocker first; it must not be read as the mass-increasing graph direction. The bound/certificate data are otherwise unchanged.

The whole-support verification is valid: every geometric margin is a minimum of finitely many affine expressions, hence concave on the anchor box; positivity at all its vertices gives positivity throughout. The old source containment margin may equal zero at the source endpoints only, as allowed by AC measure. This is not a finite sampled-anchor assertion.

**Decision:** old-source near-optimality alone does not remove blocking in genuine finite old states. It does not follow that these states are globally near-score, critical-R examples; those hypotheses are absent and cannot be inferred from their small H gap.

## 3. Complete k=1 owner and D certificate

On the central-right component, every left new owner is unavailable: the center covers their images and is the only capture-eligible row there. The available owners are center/right, with forced volumes
\[
p_0=p=(1/2,1/4).
\]
The delta=.01 baseline and free portions use this same forced eligibility. A baseline floor is required only on available rows; it does not revive an ineligible deleted row. All deleted old images remain in the old loss account.

The retained C intervals overlap with positive length. At actual alpha=(7/10,3/10), the two entropy gradients equal 64, and that positive overlap multiplier certifies the strictly concave entropy optimum. Thus this is also the alpha optimum of the joint owner program. The free min-price condition is automatic because ownership is forced; no fixed trial-alpha advantage is claimed.

For every anchor tuple in either component, k=1 has
\[
Q'=68/5,\quad W=3/4,\quad S=12/5,\quad\kappa'=63/17,
\]
\[
E_{old}=2/17,\quad O=1/4,\quad F=0,\quad RS=9/68,
\]
and exactly
\[
D=E_{old}-O+F+RS=W-RQ'=0.
\]
Both mixture components were certified, so **E D=0 is the complete independent-Euler expectation**, not a conditional half-event or representative tuple. The loss 1/4 is paid by the same E_old+RS; source near-optimality or a label-count allowance is not declared to pay it.

The local reviewer additionally checked exact next-growth arithmetic: E'=8/17 and E_next=E'/(1+kappa')=1/10; M_next=Q'=68/5. These are one-step identities only, not a constructed two-step orbit or a free next-growth payment.

## 4. Actual cloned branching: conditional and complete results kept separate

The independent owner certificate has nine rows (k=1,2,3 times three widths). For k=2,3 it certifies **only** the central-right event, probability 1/2: all left new owners are deleted, their total incoming loss remains 1/4, and D=0 there. It expressly leaves the other half-event unevaluated. These conditional rows alone cannot certify a full expectation.

The separate action certificate evaluates that missing central-left branch. There R is deleted, the left image pieces/receivers may leave multiple available owners, and all those labels remain. If r is the range of the k source-anchor offsets, the actual left receiver-center range is 3r/2, giving aggregate left owned volume `P=1/4+3r/2` and W=1/2+P. Each available left label has m=8; the actual aggregate left alpha beta satisfies
\[
8+\epsilon P/\beta=16+\epsilon(1/2)/(1-\beta),
\quad Q'=16-8\beta,
\]
\[
D=P-13/34+(15/34)\beta
=3r/2+(15/34)(\beta-3/10).
\]
The root is unique, increases with P and is 3/10 at P=1/4. Exact endpoint checks give beta in [3/10,31/100] and kappa'<4 on all six supported clone cases. The free price among available left labels is a genuine tie, since their m and common KKT multiplier agree. A capture-eligible baseline partition, with that same tie-preserving free allocation, is a true joint-program minimizer; no old unavailable row is restored.

The action file correctly retains fill. In old-piece order its conditional left-cluster fill is the two receiver-union tails plus `sum (c_(i+1)-c_i)_+`. For k<=3 and the fixed widths, center range is smaller than each positive image piece, so no nonadjacent gaps intervene. Independent uniform centers give
\[
\mathbb E W=3/4+(3/4)w(k-1)/(k+1),
\]
\[
\mathbb E F=(3/4)w(k-1)[1/(k+1)+1/6],
\quad\mathbb E O=1-\mathbb E W+\mathbb E F.
\]
I independently derived these tail/gap formulas; the half-event factor is present. In particular fill is not assumed zero or spent twice.

The range distribution has density `k(k-1)r^(k-2)(w-r)/w^k`. The full E D is one-half its left-branch integral, with right-branch D=0. The action code uses monotonicity of D and beta to form exact lower/upper Darboux sums over 256 bins; each endpoint beta has a 64-step rational bracket. These are rigorous model-specific enclosures, not Monte Carlo confidence intervals. Accepted examples include:

| k | w | Complete E D enclosure, rounded outward display |
|---|---|---|
| 2 | 1/1024 | [0.00033660856,0.00034057611] |
| 3 | 1/1024 | [0.00050587787,0.00050984482] |
| 2 | 1/65536 | [0.00000526069,0.00000532271] |
| 3 | 1/65536 | [0.00000790647,0.00000796850] |

The exact rational bounds for all six cases are in the JSON; those rational endpoints, not rounded decimals, are the certificate.

**Branching interpretation:** k edges are collected from the actual different E_i regions into one owner. They do not assert that k old copies are active at the same physical point. As w decreases, the images approach a tiling and total left image volume stays 1/4; only seams produce extra multiplicity. The graph's raw sum of child m grows as 8k, but its true physical/source weights do not. These results reject a per-child source-count shortcut, not a precise pointwise branching inequality under all hard-state assumptions. Complete net O-F-RS is what must be priced.

## 5. Separate future coefficient certificate

`future_certificate.py/json` and `README_future.md` certify conditional arithmetic, not an additional physical payment. Given the separately proved strong-invasion owner-volume bound and the same-state scaling E'_bad=(1+kappa')E_next,bad, the coefficient is
\[
c(\kappa,\kappa')=(1+\kappa')/[4(2\kappa-\kappa')].
\]
The exact identity
\[
5/12-c=[10(\kappa-7/2)+8(4-\kappa')]/[12(2\kappa-\kappa')]
\]
proves its supremum 5/12 on the stated domain; the kappa'->0 limit is 1/(8kappa), with no artificial inverse-kappa' divergence. The completed-square owner-volume estimate and cancellation are correctly recorded. They do not bound lost-copy multiplicity by owner volume.

If an actual two-step endpoint account multiplies the prior charge by theta=M_(t+2)/M_(t+1), then the valid next packing gives theta<=1 and theta*c<=5/12. This condition is not a construction of the next action, a proof that next growth is unspent, or a payment of overlap/fill/slack/termination. The four Arb evaluations illustrate exact algebra; no unprovided two-step trajectory is certified. The current branching example is not used to pretend otherwise.

## 6. Actual tools, reproduction and independent check

Execution owners used the installed Python 3.12.14, SymPy 1.14.0 and Fraction; the future arithmetic used python-flint 0.9.0 / Arb 256 bits. Reproduction commands are:

```sh
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r653/numeric/source_certificate.py
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r653/numeric/action_budget.py
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r653/numeric/owner_certificate.py
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r653/numeric/future_certificate.py
```

The source/owner/future scripts emit JSON on stdout; action writes its JSON beside the script. Reported source data cover three positive widths and symbolic left splitting; action has six k=1 branch records and six complete cloned expectation enclosures; owner has nine conditional/event records with its narrower scope explicit; future has four fixed Arb points. No independent exploration scan or CPU filler was executed.

The reviewer actually ran one bounded inline Fraction/SymPy postcheck of old KKT, the true H integral/gap, complete k=1 D, next-growth normalization and clone D rearrangement. It returned:

```text
PASS independent old-KKT/H-gap, whole k1 D,
next-growth normalization and clone D identities
old_R 15/272 kappa 63/17 Phi_old 126357/2176
Hgap 21*w*(32*w+31)/34
k1_D 0 Eprime 8/17 E_next 1/10
```

This checked the same new model rather than rerunning an old table or the author's 256-bin integration. In addition, scripts and final JSON were inspected, counts/scopes inventoried, and final hashes computed. All mathematical assertions here are bounded by their stated model or proof argument; installing a tool or a solver status is not counted as evidence.

## 7. Final numeric artifact binding and stop

| Artifact in numeric/ | SHA-256 |
|---|---|
| source_certificate.py | afe617cf99638d4db5f3a9a83c0c2af674cec51e15ff437b9e10f25032665050 |
| source_certificate.json | 511f8d783a5db8b8ee20db243fee1954a5d868444450c0d53f8668a7f5482016 |
| README_source.md | 2bb14cebe62925295bfd04360c5b1b4726cae30f94a2244b2b7b66974f21b246 |
| action_budget.py | 13ddc6349bcd5166bd81b482c8c86a279fa847e2be9c30e22db476123f93f37e |
| action_budget.json | 281d89238a8a2360ac8de6f7816d74d688fd15f4bbc10b1390fbfb65f1312ee6 |
| README_action.md | 7febfc54525057d7804c0ce586792a13955f46e5bc38965b414032e7f9c371f4 |
| owner_certificate.py | 7cf021c317da4ab516f3c9d611cd9f7ae77ef16289fc5eba98142bcd676ff567 |
| owner_certificate.json | a4fc433ae87a4858a8f4d3e6d268fee5b4fd8edbc6c85bfbf45618dec50e6242 |
| README_owner.md | e4e460b0be5c1cedce624373d25fcf0b8f767920fe411de8f158811a8980d340 |
| future_certificate.py | df13e0aed1d4adfe65dcf24fd71ce5ecf48a6e6c4c926afe5957eac5b7eb2bef |
| future_certificate.json | 3da14d74af85836bdbc52596dff84981e5d107639f0c363778cf98a30c63d0c7 |
| README_future.md | ae84181a29f5c6ecf513de9ca749441d7c6b44c6880525c574cb88d4a294ea36 |

The finite evidence is decisive about these input and bookkeeping questions: genuine blocking can persist near the old-source infimum; true replication must split old I and weights; deleted old images remain charged; and conditional-event records cannot replace the other half of the Euler expectation. A uniform branching capacity/payment for all actual critical near-score states remains unproved. No further numerical expansion is authorized by this review.
