# R653 最终总账独立审计

**结论：PASS（限于下述部分结果、精确总账及未证范围的陈述）；无必须修订项。一般中心立方体 `n^(1/2+o(1))` 弱 `(1,1)` 上界仍未证明。此 PASS 不认证完整几何付款、正的完整期望增量或受控递推。**

## 冻结版本绑定

本次实际读取并以本机 `shasum -a 256` 核对：

| 文件 | SHA-256 |
| --- | --- |
| `/tmp/ccu_r653/REPORT.tex` | `828be61239417250bdfe4c62d5c50a2675df4e571bd86545839c5fbd67d23798` |
| `/tmp/ccu_r653/NEXT_TARGET.md` | `b436ce3a7b1e4d0edb875b3fd263979e1bfd5bb8daa52b303c6a59cbfad4aea9` |

审核者先独立形成命题预审，再审成形前半；冻结后补审坐标说明、`chi_j` 改名及后半新增内容。与 `FUTURE_GROWTH.md`、`PRICE_CAPACITY.md`、`LEDGER_AUDIT.md` 交叉核对，但以下判断依据公式本身。没有 API 模型证明可审。本次未调用 API、未读凭据、未编 PDF、未写 Git、未启动子代理，且只修改本审计文件。

## 已核验的总账与支持系数 — PASS

- 同一 Eulerian 动作、真实旧 AC KKT 源、真实旧 disjoint owners、全 tuple 适应的实际 `p,alpha` 和全部旧／删除 incoming 行均保留。目标为 `E D >= cV-CLM`，`D=E-O+F+RS=W-RQ'`；常数必须对所需实际 near-score 状态一致。删除新 owner 不删除旧损失或增长。
- `g=1+kappa'` 归一化给 `M1=Q'`、`v1=p/g`、`u1=u'`，故 `E'_J=g E1,J`、`H1=epsilon sum p h'`。后势能只付一次 `4LQ'`。旧低行分解保留 `Delta_low=E_low/12-O_low>=0`；丢弃它只给更强充分条件，不能称为精确等价。
- 对 `B={z>=4}`，`A_B<=S/4`。令 `A=4 sigma kappa>kappa'`，在 `u'>A` 使用
  `A+(u'-kappa')^2/[4(A-kappa')]-u'=[u'-(2A-kappa')]^2/[4(A-kappa')]`，其余行仅用 `u'<=A`。这确实只收费在 `C=B intersect {u'>4 sigma kappa}`：
  `V_B<=sigma RS+[(1+kappa')/(4(4 sigma kappa-kappa'))]E1,C`。
  在旧 `kappa>=7/2`、`0<kappa'<=4` 上，`sigma=2/3` 的系数至多 `15/64`，且 `u1>8kappa/3>=28/3`。严格支持集不会占用下一步 `u<=1/2` 增长。精确比值先消去表面的 `1/kappa'`，无须后继下界或质量下降。`2RS/3` 与半 `RS` 是同一 owner 费用的替代分配；重数若为 K，两项均须乘 K。
- 前半独审已用本机 Python 标准库 Fraction 的精确 Laurent／多项式系数运算核验支持平方、`15/64` gap、两步望远镜零残差及 `13/48` 保留系数；冻结后没有无故重跑数值。解析推导而非有限点测试负责一般参数结论。

## 两步、whole-state 与终端 — PASS，仅条件兼容

若另有真正证明的 `D0>=A0-V_B`，以 `q=M2/M1<=1` 相乘后与完整 `D1` 合并，恰得报告的

`q(A0-sigma R0S0)+(1-q beta)E1,C+E1,Ccomplement-O1+F1+R1S1`。

因此 `49/64` 是可用下一代增长余量，并非已经支付下一代损失。`A0` 仍是明确的条件占位符。精确端点为

`M2(Fscore2-Fscore0)=qD0+D1-L[H2-(M2/M0)H0]`。

有限全状态望远镜保留真实 `M_T/M_(t+1)` 权重和单一最终势能费用。后继可为高 R、低 kappa，不能自动继承 `kappa>=7/2` 的旧低行吸收定理；一般系数也不能跨出旧参数域沿用。`R_next<=KL` 只直接支付原始单个 owner-volume 义务；不是支付所有未来 O 或终端 score 成功。无限继续仍须实际停止／可积性／可和性证明。

上一轮提出的坐标歧义已修：图中 `I^2,C^2,alpha^2` 明定为从 state 1 动作后、state 2 归一化前的 owner／expanded cubes／权重，和 `mu1,A1,E1` 同坐标。故所写 source union 容量没有漏掉坐标缩放。子 owner 不能独立领取整个源预算。

## 实际对偶与完整 branch expression — PASS

行 perspective 的共轭给 `nu(C_j)>=m_j[epsilon^(-1)+exp(ell_j-1)]`。实际 `ell_j=1+log(u'_j/epsilon)`、`nu=mu'/epsilon` 给等式需求和 primal／dual 同值；域限定为实际正体积 packing cells／AC 代表，未把零测 contact 原子当作可用旧源。新对偶源 `mu'` 与旧源 `mu` 没有混同。

改名后的 `chi_j=L_j/p_j` 与半动作 `b_j` 已区分。完整恒等式为

`O_high=epsilon^(-1)sum a'_j u'_j chi_j`,

`S=s0+sum a'_j z_j`,

`D=11E_low/12+E_high+F+R s0-epsilon^(-1)sum a'_j[u'_j chi_j-kappa z_j]+Delta_low`。

这保留全部旧高行、baseline 副本和被删除 incoming 行。阈值 cuts 只计 owned area；旧 source column 是并集，不是逐孩子质量之和。实际 `alpha` 与 `u'/epsilon` 价格均未省略，也没有新、旧 optimizer 的未证比较。

## 后半新增 nesting／window 与有限模型范围 — PASS 于所述范围

1. `d<1`、质量比阈值 `K_U(n)=[T(1+d)/(1-d)]^n` 确给真实旧 `A_j subset A_k`。单调性证明及 `17^(1/3)<18/7` 的有理比较支持 `U<=16,n>=3` 的保守 `32768` 阈值。两 band gap／同 parity 的限制、逐物理 x／逐 action 的 annuli 范围、高 u 及低维残项均保留。该三角不等式论证适用于一般固定对称凸体，报告未将它称作 cube-specific 维数改善。
2. affine source window 来自实际可测 `I_k`。冻结其他 anchors 后，lostsplit 的两项均保留完整重算 owner 的 `h_k`。删去 h 只得 incoming 上界；独立性只适用于不含当前 row 的冻结历史。同 band siblings 的窗口仍可反复使用同源，per-x annuli 未被错误当成一次全局 M 预算。
3. 有限一维模型的旧 KKT 质量、`R=15/272<1`、H 源下确界差、单 label 的 `D=0`、clone 的 aggregate beta 方程及完整 D／fill 账式在代数和范围上相容。k=1 的两 mixture components、k=2,3 的 owner-only 条件事件与 action 中完整期望明确区分。它们属于近旧源下确界诊断，不是 near-score 临界状态证据；true label split 也未被冒称为同点 k 重副本。

本审计没有重新运行或逐字节独立认证脚本／JSON、Darboux 表格、Arb 包围或 MATLAB 输出；这些数值证书及 replay 声明的真实性属于另行数值审计范围。本处 PASS 只涵盖其数学账式与报告明确限定的用途，绝不把有限模型转化为一般定理。

## 仍未支付的完整缺口与交付判断

冻结两文件一致保留决定性缺口：从实际旧几何、联合源窗口和真实自适应 owner 负载，推出 multiplicity-weighted `sum a'[u' chi-kappa z]/epsilon` 的统一估计，联合使用一次当前增长／fill／slack、一次 `CLM` 并留下 `cV`。现有对偶只约束 receiver 一次需求；nesting 只约束若干源并集；强侵入系数只兼容一项未来增长费用。三者均未支付同 band siblings、所有层／源历史、baseline 重数、弱侵入及下一步完整 `O1`。

因此也未建立高 R／低 kappa 后继的全状态闭合递推、合法终端／无限继续控制或一般维数改善。`NEXT_TARGET.md` 对严格支持集、坐标、条件损失、全期望与未证义务的表述与冻结报告一致。**无必须修订项；可以按明确的“部分结果及剩余完整目标”范围交付，不能按一般上界已证交付。**
