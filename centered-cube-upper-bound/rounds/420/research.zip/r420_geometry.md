# R420：原双见证的大几何交叠分支付款

2026-10-20。本轮在 R419 的同一原双见证空间中支付较大的几何交叠。来源仍是完整 f，中心仍为真实 Lebesgue dw,dt；几何体积从未代替来源质量。新增无 W 费用，完整补集仍未支付。

## 1. 准确事件及原场

所有原字段、Γ_i、b_i、首次删除、实际时钟、旧新来源、原 R414 正门及后续路径保持。R419 已付互中心包含，剩余初始 w,t 满足
\[
w\notin\alpha_*Q_t,\quad t\notin\alpha_*Q_w,
\qquad\alpha_*=e^{1/\sqrt n}.
\]
它们仍各自捕获相应来源并排斥另一来源，且 m_w,m_t<m_A/K，K=e^(√n)。m_v=f(Q_v)=q_vR_v^n，q_v≥q_-，这里 R 始终为边长。

对 0<θ<1 定义实际事件
\[
\mathsf O_\theta
 =\left\{\frac{|Q_w\cap Q_t|}{\max(R_w^n,R_t^n)}\ge\theta\right\}.
                                                               \tag{1}
\]
该事件对称，本身不是两个方向事件的 union。令
\[
P_{420}(\theta)=R419[\mathsf O_\theta],\qquad
R420(\theta)=R419[\mathsf O_\theta^c].
\]
二者为同一实际正测度的限制，精确相加等于 R419，不重新归一化或抽样。

为避免与 B_L 中原冻结秩参数 L≥4 混淆，以下写
\[
L_{\rm ov}=-\log\theta,\qquad
\nu=e^{L_{\rm ov}/n},\qquad d_\theta=(\nu-1)/2.
\]
本轮不更改原 L、h、ε_0 或阶段表。

## 2. 从真实交叠推出 selector-uniform 中心域

固定 t。由 |Q_w∩Q_t|≤min(R_w^n,R_t^n)，事件 (1) 强制
\[
\nu^{-1}\le R_w/R_t\le\nu.                              \tag{2}
\]
只为构造中心域，将 w 处的几何盒放大至边长 νR_t；这是包含原 Q_w 的辅助盒，不修改实际选择器、m_w 或后续来源积分。

令 a_j=|w_j-t_j|/R_t。放大盒与 Q_t 的各坐标交叠长度除以 R_t 为
\[
\left[1-(a_j-d_\theta)_+\right]_+.
\]
原交叠≥θmax(R_w^n,R_t^n)≥θR_t^n，因此
\[
\prod_{j=1}^n\left[1-(a_j-d_\theta)_+\right]_+\ge e^{-L_{\rm ov}}.
\]
每个 excess 小于1。用 −log(1-x)≥x，得到
\[
\sum_{j=1}^n(a_j-d_\theta)_+\le L_{\rm ov}.              \tag{3}
\]
所以固定实际 t 时，所有可行实际 w 中心位于
\[
t+R_t\big([-d_\theta,d_\theta]^n+L_{\rm ov}B_1^n\big).
\]
这同时包络全部可测实际 R_w；不是逐边长分别积分再免费取并集。

归一化域的精确 Lebesgue 体积为
\[
V_n(L_{\rm ov})
 =2^n\sum_{k=0}^n\binom nk d_\theta^{\,n-k}
                                      \frac{L_{\rm ov}^k}{k!}. \tag{4}
\]
证明是在每个正交象限选择 k 个超出基础盒的坐标；其 excess 组成总和≤L_ov 的 k 维 simplex，其余坐标各长 d_θ。边界为零体积。于是 (4) 是该包络域的体积，而非原实际可行 w 集合体积的恒等式。

还可使用更简单的包络
\[
V_n(L_{\rm ov})\le\frac{[2(L_{\rm ov}+nd_\theta)]^n}{n!},       \tag{5}
\]
因为 (3) 蕴含 ∑a_j≤L_ov+nd_θ。

## 3. 完整来源匹配给双见证矩，无额外方向因子

固定父 A，记 E_A={v:m_v<m_A/K}，I_Av=f(Q_A∩Q_v)。原未归一双源矩为
\[
\mathcal M_A(\theta)=\int\pi_A(dy)\pi_A(dz)
 \int_{E_A^2}c_w(y)c_t(z)1_{\mathsf O_\theta}\mu(dw)\mu(dt).
\]
保持实际两份来源和实际两个边长，Tonelli 给
\[
\mathcal M_A(\theta)
 =m_A^{-2}\int_{E_A}\frac{I_{At}}{m_t}
           \int_{E_A}\frac{I_{Aw}}{m_w}
                        1_{\mathsf O_\theta}\,dw\,dt.
\]
先用 I_Aw≤m_w，再用 §2 的固定 t 中心域容量，得到
\[
\mathcal M_A(\theta)
 \le\frac{V_n(L_{\rm ov})}{m_A^2}
                   \int_{E_A}\frac{I_{At}}{q_t}dt.
\]
如 R419 的原匹配结算，严格 m_t<m_A/K 给
R_t<r_*=(m_A/(Kq_-))^(1/n)，固定来源 z 的所有捕获 t 中心体积≤r_*^n。故
\[
\int_{E_A}I_{At}dt\le\frac{m_A^2}{Kq_-},\qquad
\boxed{\mathcal M_A(\theta)\le
                  \frac{V_n(L_{\rm ov})}{Kq_-^2}.}       \tag{6}
\]
若 r_*≤a，则实际小质量集合为空。严格质量原子不被误纳入。每一步在实际中心的正积分上成立；没有对 f 使用体积帽，没有引入不存在的实际接收者。由于 (1) 已是一个对称事件，(6) 不再乘2。

## 4. 原阶段、原 soft 与收费

原 exclusive 因子、R419 的互中心外侧及所有后续门只在正上界中删去。R411 已审分母界给大端1/(2Lh²)、小端1/[(2−ε_0)(L−ε_0)h²]。先按同一个原边标签及新来源 z 用 early≤b_i、Σ_i b_i(z)≤1 累计，再用原逐旧来源 β、C_col，得到同一冻结常数
\[
B_L=\frac\beta{2L}
 +\frac{C_{\rm col}}{(2-\varepsilon_0)(L-\varepsilon_0)}.
\]
这里已含两个父端，不再乘 S。实际费用因此满足
\[
\boxed{P_{420}(\theta)
 \le\frac{B_L V_n(L_{\rm ov})}{Kq_-^2h^2}X_q.}            \tag{7}
\]
原新见证不获得历史资格，所有概率路径仍是同一正扩充；没有重复使用旧负平方或付过的 R419 分支。按占用层分拆后，所有层合计只收 (7) 一次。

## 5. 主选择的全高维显式价格

取
\[
L_{\rm ov}=\sqrt n/4,\qquad\theta_n=e^{-\sqrt n/4}.
\]
对全部 n≥9，x=L_ov/n≤1/12。由 e^x−1≤x/(1−x)≤12x/11，
\[
L_{\rm ov}+nd_\theta\le\frac{17\sqrt n}{44}.
\]
结合 n!≥(n/e)^n、e<3，(5) 给
\[
V_n(\sqrt n/4)
 \le\left(\frac{51}{22\sqrt n}\right)^n<1.               \tag{8}
\]
n! 下界可由 ∑log j≥∫_1^n log x dx 得到，不依赖数值拟合。

令 D_n=(51/(22√n))^n。为与主稿使用同一显示系数，保留 (8) 的 D_n，使用价格
\[
\boxed{P_{420}\le\Delta_{420}X_q,\qquad
\Delta_{420}=\frac{B_LD_n}{Kq_-^2h^2}
 =\frac{\varepsilon_0^2B_LD_n e^{-\sqrt n}}{(1+\sqrt n)^2}.} \tag{9}
\]
更锐 (7) 可保留，但正式账只需解析 D_n 上界，无需精确 V 的数值。也可丢弃 D_n<1 得到更粗的安全价格，但不与主稿另计一份费用。n<9 仍用原低维完整路线，不叠加高维账。

完整补集 R420 除 R419 全部标记外，还满足
\[
|Q_w\cap Q_t|< e^{-\sqrt n/4}\max(|Q_w|,|Q_t|).          \tag{10}
\]
这只是几何体积结论，不推出 f(Q_w∩Q_t) 小，亦不意味着来源独立或共享质量小。

记原 Δ419=2ε_0²B_L/s²，Fhat=(1−32δ−16η)^(-1)。新母式为
\[
G_0\le16\widehat F\{R420+
          (C413+\Delta419+\Delta420)X_q+V413W\}.
\]
BH 同槽系数32Fhat，原入口新增64ΛFhat Δ420 X_q；原其他 X/W 槽不变，无新增 W 价格。未宣称全局吸收余额或整个 P 已闭合。

## 6. 新支与 R419 补集相容，证据范围明确

等边长 r 的两见证中心只在一个坐标相距3r/4时，交叠比为1/4。对 n≥36，1/4>e^(−√n/4)，且3/4>e^(1/√n)/2，所以两个中心同时在对方 R419 扩张盒外，但 (1) 成立。

为保留真实父外及来源捕获，可取完整 f=1_{[-4,4]^n}、父边长2、子边长 r=3/2，两个子中心围绕(1.1,−9/16,0,…)和(1.1,9/16,0,…)的小块；每块半宽 r/(32n)。来源第二坐标取−0.9、0.9，第一坐标同为1.1−r/2+r/(8n)。这些严格条件在正体积中心块和足够小的来源邻域上保持：双父外、双 exclusive、原 child collar、来源远域、互中心扩张外侧、大几何交叠。完整匹配 q=1；n=36、64、100时 (4/3)^n>3^(√n)>e^(√n) 给原严格质量门。

本例只认证上述实际几何及 full-f 匹配，不认证 own-past、原 rank/clock/history、当前 D、重尾或完整 R419 正费用。不存在“每个输入都删去正比例”的结论。

本机实际执行 `/tmp/r420_geometry_check.py`，Fraction 三阶段：

- 73项交叠到有理放宽中心域的证书，含不同边长；脚本对指数端点和对数均取有理外包，不单独认证精确 V_n；
- 7项混合体积、ℓ1包络和 factorial 证书，维数9至256；
- 3项正体积中心块相容性证书，维数36、64、100。

全部83项通过。非整数指数使用解析有理上下界，未把浮点输出当证明。一般收费来自 (2)–(7) 的实际中心与完整匹配推导；有限几何证书不代替原历史资格。完成本轮并停止。
