import math,json
from fractions import Fraction as F
from pathlib import Path

def logvol(n,c=0.25):
    L=c*math.sqrt(n); d0=math.expm1(L/n)/2
    logterm=n*math.log(d0); terms=[logterm]
    for k in range(n):
        logterm+=math.log(n-k)+math.log(L/d0)-2*math.log(k+1)
        terms.append(logterm)
    top=max(terms)
    lv=n*math.log(2)+top+math.log(math.fsum(math.exp(t-top) for t in terms))
    lb=n*math.log(2*(L+n*d0))-math.lgamma(n+1)
    assert lv<=lb+1e-7*max(1,abs(lb))
    return {'n':n,'c':c,'L':L,'d0':d0,'logV':lv,'logV_over_K':lv-math.sqrt(n),
            'log10V_over_K':(lv-math.sqrt(n))/math.log(10),
            'log_ball_over_K':lb-math.sqrt(n)}
def exp_lower(x,N=32):
    t=F(1);ans=t
    for k in range(1,N+1):t*=x/k;ans+=t
    return ans
def log_interval(x,N=256):
    assert x>=1
    t=(x-1)/(x+1)
    lo=2*sum(t**(2*j+1)/F(2*j+1) for j in range(N))
    err=2*t**(2*N+1)/(F(2*N+1)*(1-t*t))
    return lo,lo+err

def variable_center_exact(n,r):
    # Rt=1, Rw=1 on x1>=0, Rw=r on x1<0; theta=r^-n.
    # Genuine continuous-center volume is half of the two symmetric bodies.
    theta=r**(-n); loglo,loghi=log_interval(r)
    Llo,Lhi=n*loglo,n*loghi
    def cdf(L):return 1-theta*sum(L**j/F(math.factorial(j)) for j in range(n))
    equal_lo=2**n*cdf(Lhi); equal_hi=2**n*cdf(Llo)
    actual_lo=(equal_lo+(r-1)**n)/2
    actual_hi=(equal_hi+(r-1)**n)/2
    d=(r-1)/2
    def outer(L):return 2**n*sum(F(math.comb(n,k))*d**(n-k)*L**k/F(math.factorial(k)) for k in range(n+1))
    Vlo,Vhi=outer(Llo),outer(Lhi)
    balllo=(2*(Llo+n*d))**n/F(math.factorial(n))
    assert 0<=actual_lo<=actual_hi<=Vlo
    assert Vhi<=balllo or n==1 # n=1 identical formula; separate interval rounding.
    return {'n':n,'r':str(r),'theta':str(theta),'actual_volume_interval':[float(actual_lo),float(actual_hi)],
            'V_interval':[float(Vlo),float(Vhi)],'scope':'exact rational enclosure of continuous variable-selector volume; diagnostic parameters'}

low=[logvol(n) for n in range(9,65)]
continuous=[variable_center_exact(n,r) for n in [1,2,3] for r in [F(3,2),F(2)]]
pressure=[]
for n,k in [(36,6),(64,8),(144,12)]:
    L=F(k,4); eps=F(1,32*n)
    overlaplo=(F(1,4)-eps)*(1-eps)**(n-1)
    assert overlaplo*exp_lower(L)>1 # overlap > e^-L
    alphahi=1/(1-F(1,k)) # e^(1/k)<1/(1-1/k)
    assert F(3,4)-eps>alphahi/2 # both centers outside alpha expansion
    d0lo=L/(2*n)
    assert eps<d0lo and F(3,4)+eps-d0lo<=L
    vol=(2*eps)**n
    pressure.append({'n':n,'L':str(L),'center_halfwidth':str(eps),'overlap_lower':str(overlaplo),
                     'overlap_lower_float':float(overlaplo),'center_volume':str(vol),
                     'log10_center_volume':n*math.log10(float(2*eps)),
                     'certificate':'Fraction + positive exponential Taylor; not point sampling'})
expanded=[logvol(n) for n in [81,100,144,256,512,1024,4096,10000,100000]]
# Pure diagnostics: c at which this envelope V/K reaches 1 for fixed n.
boundaries=[]
for n in [9,16,25,64,256,1024]:
    lo,hi=0.01,1.0
    while logvol(n,hi)['logV_over_K']<0:hi*=2
    for _ in range(55):
        mid=(lo+hi)/2
        if logvol(n,mid)['logV_over_K']<0:lo=mid
        else:hi=mid
    boundaries.append({'n':n,'c_crossing_float':[lo,hi],'not_interval_certificate':True})
stability=[]
for n in [9,64,1024,100000]:
    L=0.25*math.sqrt(n); d=math.expm1(L/n)/2
    terms=[math.lgamma(n+1)-math.lgamma(n-k+1)-2*math.lgamma(k+1)+(n-k)*math.log(d)+k*math.log(L) for k in range(n+1)]
    m=max(terms)
    independent=n*math.log(2)+m+math.log(math.fsum(math.exp(t-m) for t in terms))
    error=abs(independent-logvol(n)['logV'])
    assert error<1e-5
    stability.append({'n':n,'absolute_log_difference':error,'method':'independent lgamma vs recurrence, diagnostic not rigorous interval'})
worst=max(low+expanded,key=lambda x:x['logV_over_K'])
result={'method':'float log-sum-exp for volume table; Fraction certificates explicitly identified',
        'c':0.25,'stage1_n9_to64':low,'continuous_selector_certificates':continuous,
        'stage2_outside_positive_blocks':pressure,'stage3_expanded':expanded,
        'sampled_maximum':worst,'floating_stability':stability,'c_boundary_diagnostics':boundaries,
        'counts':{'low_n':len(low),'continuous_certificates':len(continuous),'outside_certificates':len(pressure),'expanded_n':len(expanded),'c_boundaries':len(boundaries)}}
Path(__file__).with_name('r420_aux_result.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS',result['counts'])
print('sampled max V/K',math.exp(worst['logV_over_K']),'n',worst['n'])
print('sampled max ball/K',math.exp(max(x['log_ball_over_K'] for x in low+expanded)))
for x in [low[0],low[7],low[16],low[-1],expanded[-1]]:
    print('n',x['n'],'log(V/K)',x['logV_over_K'],'log10(V/K)',x['log10V_over_K'])
print('log stability',stability)
print('fixed-n c crossing diagnostics',[(x['n'],x['c_crossing_float'][0]) for x in boundaries])
print('Output r420_aux_result.json; no asymptotic inference or original-history certification.')
