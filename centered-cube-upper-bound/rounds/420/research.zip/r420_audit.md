# R420 independent audit — frozen

FINAL PASS within the stated R420 scope: native selected-side overlap envelope, its once-only same-lift positive-branch payment, and full displayed accounting. Independent derivation preceded author reading. Final main/README, both proofs and code reviewed; both scripts independently rerun. Formal Δ420 retains D_n. No P, general root closure, complete-history nonempty fixture or fixed covered fraction is certified. Only this audit file edited.

Fix t and normalize R_t=1. Let η=R_w/R_t. Positive overlap≥e^(-L_g)max(1,η^n) implies e^(-L_g/n)≤η≤e^(L_g/n). Enlarge the actual Q_w only as an upper-envelope to selected side e^(L_g/n)R_t. Its normalized overlap with Q_t is ∏[1−(|w_j−t_j|/R_t−d0)_+]_+, d0=(e^(L_g/n)−1)/2. This product is≥e^(-L_g); all factors are positive, and log(1−x)≤−x yields Σ(|w_j−t_j|/R_t−d0)_+≤L_g.

Hence the variable-selector center domain is contained in t+R_t([-d0,d0]^n+L_g B1). Its exact volume is V_n R_t^n, V_n=2^nΣ_{k=0}^n binom(n,k)d0^(n−k)L_g^k/k!. The cube-plus-crosspolytope decomposition counts the coordinates outside the central cube. It is also contained in the l1 ball of radius L_g+nd0, giving V_n≤Vbar_n=[2(L_g+nd0)]^n/n!. No chosen-side independence or source-density assumption is made.

For true matched masses, the raw fixed-parent moment is m_A^-2∫_{far t}(I_At/m_t)dt ∫_{far w}(I_Aw/m_w)1_overlap dw. Use I_Aw≤m_w BEFORE applying the center volume envelope. Then use R_t^n=m_t/q_t≤m_t/q_- and strict far R_t<(m_A/(Kq_-))^(1/n). Exactly as in R419, fixed-z t-center volume is≤m_A/(Kq_-), so the raw moment is≤Vbar_n/(Kq_-²), or with the smaller exact V_n. This is a volume of actual centers after real source-mass cancellation; it does not bound arbitrary f(Q_w∩Q_t) by volume.

The event is symmetric and is treated ONCE, not as a sum of directional events. Original R411 soft/rank constants and common early/stage summation yield B_{L_rank}/h² times this raw moment on the original R419 positive restriction. Thus P420≤B_L Vbar_n/(Kq_-²h²)X_q. No union2, extra S, τ^-1 or λ/q_- is needed; B_L already contains β and C_col. L_g is distinct from the original rank parameter L≥4. No witness resampling or renormalization occurs.

For n≥9, L_g=√n/4 and x=L_g/n≤1/12. e^x−1≤x/(1−x) implies nd0≤3√n/22, hence2(L_g+nd0)≤17√n/22. From log n!≥∫_1^n log t dt≥n log n−n and e<3,

Vbar_n≤D_n=(51/(22√n))^n<1,
Δ420=ε0² B_L D_n/(K(1+√n)²).

The current mother retains Δ419 as a previous once-only price and adds Δ420 to C413+Δ419. V413 and Fhat=(1−32δ−16η)^−1 stay unchanged. New coefficients are16Fhat,32Fhat and64ΛFhat times Δ420 at G0/BH/entrance respectively; outside old terms are unchanged. No low-dimensional complete-core alternative is added to this high-dimensional bill.

The new event can overlap the already paid419 family geometrically, but the ACTUAL payment is defined only inside its complement R419. It need not be nonempty for all n: with both centers strictly outside each other's α_* boxes, overlap/maxvolume<1−α_*/2 (when α_*<2). If e^(-L_g)≥1−α_*/2, the proposed current branch is empty; n9 and16 are examples. At larger n the conditions are geometrically compatible. For n64, equal side1.5 witness centers separated by.92 in one coordinate have normalized overlap29/75>e^-2 and distance>.75 e^(1/8), so the419 mutual-center event does not contain the entire new overlap event. This is only partial geometry and gives no complete original-history nonempty guarantee.

Before R420 author reading, executed6 exact Fraction volume-envelope configurations at n9,16,25,64,256,1024 using rational d0 upper bound x/[2(1−x)]; all passed V≤Vbar≤D_n<1. This is reviewer temporary arithmetic, no archived standalone script and not an original marked-flow realization or extra delivered experiment count.

## Final proof and original-fee review

Final author geometry and main agree on D_n=(51/(22√n))^n and Δ420=ε0²B_LD_n/(Ks²). The earlier weaker same-name coefficient in the geometry note was disambiguated before freeze; discarding D_n is only an optional coarser bound, not an additional receipt. The source normalization and all R values are actual selected side lengths. L_g/L_ov is distinct from frozen rank L≥4.

On the actual soft-positive original double-exclusive lift, ψ divided by its two exclusive denominators has the same external/small-end constants as R411. The event Oθ depends only on frozen A,y,z,w,t and is independent of a reconstructed stage schedule. Original common early/first-deletion summation, followed by outgoing β / incoming C_col, therefore gives B_L/h² times the raw full-π_A² moment. The other R419 gates and later conditional path probabilities may be dropped for this positive upper bound without changing their actual support or assigning witness history. No τ^-1, extra S, λ/q_- or directional union factor2 is introduced. The complete stage/occupation-layer family is one positive partition; the price is not repeated for each layer.

The final original-fee partition is inside R419, after the419 mutual-center event has already been removed. Its complement retains that double-center separation plus overlap<θmax(volume), all old sources/clock/history/current/high-rank/cubic/early/path labels, and the same terminal kernels. No resampling or renormalization occurs. A smaller geometric intersection gives no bound on f of that intersection. The formal substitution adds Δ420 to C413+Δ419, keeps Fhat and V413 unchanged, and multiplies it by16Fhat/32Fhat/64ΛFhat at G0/BH/entrance respectively. All outside E387,S390,H,A_entrance terms and the low-dimensional alternative remain unchanged. Old prices are not refunded and total absorption has not been certified.

## Actual post-author computation and evidence limits

Independent rerun of final r420_geometry_check.py passed83 Fraction records and matched its standard delivered stdout byte-for-byte. The categories are:

-73 rational overlap-to-center certificates. These use a rational upper endpoint a≥θ^(-1/n), enlarged d0 and a rational log_upper. They verify that rational OUTER inclusion only; they do not by themselves test the exact exponential center body or certify its exact V_n.
-7 rational mixed-volume/factorial certificates through n256. d0bar=x/[2(1−x)] is an upper bound for the exponential d0. The general all-n proof is analytic, not extrapolated from these seven cases.
-3 positive-volume full-f matched center-block geometry certificates in n36/64/100. The worst-coordinate overlap lower product accounts for independent perturbations of both center blocks. Rational Taylor bounds ensure overlap>e^(-√n/4), mutual expanded-center exclusion and strict original far mass. Source exclusivity, parent-outside and collar conditions are compatible. These are PARTIAL geometric examples, omitting own-past, dynamic D, original clock/history, heavy-tail and final-terminal qualifications; they are not complete nonzero R419-flow certificates.

The auxiliary script was independently run from an isolated temporary directory, preserving author files. Its regenerated stdout and JSON both matched the delivered bytes. Evidence types remain separate:

-56 n9..64 plus9 expanded-dimension values through n100000 are ordinary floating log-sum-exp/lgamma diagnostics; the reported sampled maximum and logarithmic tables match the delivered output. The recurrence ratio(n−k)(L_g/d0)/(k+1)^2 correctly evaluates the finite V_n polynomial. The six fixed-n threshold bisections and four alternative-log comparisons are also floating diagnostics, not interval root enclosures or uniform dimension claims.
-6 continuous-variable-selector volume certificates use Fraction log enclosures. For Rt=1 and Rw=1 on one half-space / r on the other, θ=r^-n, the exact center volume is half the equal-side product-capture domain volume plus half(r−1)^n. The equal-side formula2^n[1−θΣ_{j=0}^{n−1}L^j/j!] and its log-interval monotonic directions are correct. These are geometric selector tests in n1/2/3, not original full-f/flow instances. n1 equality of ball and mixed-volume formulas is treated analytically rather than relying on overlapping numerical intervals.
-3 further Fraction outside-center-box certificates in n36/64/144 establish only the stated partial geometric compatibility, not full original history or a positive paid proportion.

Atanh log tails and positive exponential Taylor sums are used in the exact certificate parts with the correct bound direction. The JSON explicitly identifies floating fields; no floating max/critical constant is used in the formal Δ420. Counts of floating diagnostics, exact record categories, fields, and reviewer executions are not pooled as a number of native full-contract samples. All manuscript/README evidence scopes are consistent after the finite-test clarification.

No substantive correction remains to the frozen bounded claims. General P/root closure, full residual payment and universal nonempty/covered-fraction assertions remain unproved. No external theorem is supplied by the workflow-skill labels.

## SHA-256 bindings

Final reviewed bytes follow; later generated TeX/manifest/package bytes are not covered by this audit.

- `r420_main.md`: `b2700b4186ff53dfd5df571e5c6e6b05497e9022c0ab3d8ba0a3d536033687e4`
- `r420_readme.md`: `26781c3d16d4f66375ad780753a059e3b3cc704efabc5703d3788d7ab1e34aa9`
- `r420_geometry.md`: `9c3faf31288f8bb814737769be60fd05e3a9e28e17643fb595ebce0a9ff846aa`
- `r420_aux.md`: `f5e6c64dd2ffecb5944831e7d70a1eacd309ce74a462a52fbaa885437d0d9e5f`
- `r420_geometry_check.py`: `a84f657edde226d1ab1560cb4f0e8ed5c5fd75ed62a585a9c52a63c995aefbbd`
- `r420_aux_check.py`: `5e030cc2e7c73be7c9290297c4eedf67d6f6330af112d6c29a419d22eb7bec15`
- `r420_geometry.result.txt`: `c2edd989ff9da0c818c2e26c96fc6387f889c39a4e55ae0c592162826d8aea14`
- `r420_aux.result.txt`: `923bca97acf06f6aac2d15e84d54f86a29c1375990f9fbccb25aee18690b8116`
- `r420_aux_result.json`: `a3a4dc4e85ef319bf6c2125e3b098f3bf401874281fdeca5f34e6cef5f967cab`
- `r419_main.md`: `5c7655b9bb430c5e2c473434664490f4c4d2db8de4201b5705d88c00b08ea04a`
- `r411_aux.md`: `08877dd6346771a4711a454fbf7704db27d0fd3a05f2dfbab45d69e0ac2c3823`
- `r414_main.md`: `4b22ddb135ac2f13eb1f282b7e5c965b293f2ea4ec259d5efa8a6f961e390ddc`

Frozen bounded result: one original-current-lift high-overlap branch paid at the stated X_q price; no new W charge and no full remaining root budget.
