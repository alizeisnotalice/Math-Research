from fractions import Fraction as F
from math import comb, factorial
from itertools import product

def log_upper(x,N=32):
    z=(x-1)/(x+1)
    main=2*sum((z**(2*k+1)/F(2*k+1) for k in range(N)),F(0))
    return main+2*z**(2*N+1)/(F(2*N+1)*(1-z*z))

count=positive=0
for n,theta,r,j in product((2,3,4,6),(F(1,2),F(1,4),F(1,8)),(F(3,4),F(1),F(5,4)),range(5)):
    ds=[F(j,4) if k==0 else F((j+k)%3,8) for k in range(n)]
    lengths=[max(F(0),min(F(1),r,(1+r)/2-d)) for d in ds]
    inter=F(1)
    for v in lengths: inter*=v
    overlap=inter/max(F(1),r**n)
    if overlap<theta: continue
    # Rational upper endpoint for theta^(-1/n), chosen without floating roots.
    numerator=100
    while F(numerator,100)**n<1/theta: numerator+=1
    a=F(numerator,100); d0=(a-1)/2
    assert 1/a<=r<=a
    excess=sum((max(F(0),d-d0) for d in ds),F(0))
    assert excess<=log_upper(1/theta)
    count+=1
    positive+=any(ds)
print('Stage 1 PASS:',count,'exact overlap-to-center certificates;',positive,'nonzero displacements')

count2=0
for root in (3,4,5,6,8,10,16):
    n=root*root; L=F(root,4); x=F(1,4*root)
    # e^x-1 <= x/(1-x); all subsequent arithmetic is rational.
    d0bar=x/(2*(1-x))
    Vbar=2**n*sum((F(comb(n,k))*d0bar**(n-k)*L**k/F(factorial(k)) for k in range(n+1)),F(0))
    ball=2**n*(L+n*d0bar)**n/F(factorial(n))
    assert Vbar<=ball
    assert L+n*d0bar<=F(17*root,44)
    assert 3**n*factorial(n)>=n**n
    safe=F(51,22*root)**n
    assert ball<=safe<1
    count2+=1
print('Stage 2 PASS:',count2,'rational mixed-volume and factorial certificates, n through 256')

count3=0
for n,root in ((36,6),(64,8),(100,10)):
    r=F(3,2); half=r/(32*n); separation=F(9,8)
    # e^(1/root)<=1/(1-1/root)<=6/5, so the R419 expanded centers stay outside.
    assert separation-2*half>F(6,5)*r/2
    ratio_low=(F(1,4)-F(1,16*n))*(1-F(1,16*n))**(n-1)
    # e^(3/2)>sum_{j=0}^4(3/2)^j/j! = 563/128.
    assert sum((F(3,2)**j/F(factorial(j)) for j in range(5)),F(0))==F(563,128)
    assert ratio_low>F(128,563)
    assert (F(4,3))**n>F(3)**root # original strict mass-far, since e<3
    assert F(11,10)-half>1 # both centers outside the parent
    assert F(27,80)+half<r/2 and F(117,80)-half>r/2 # exclusive source capture
    collar_ratio=1-F(5,16*n)
    assert collar_ratio**(2*n)>F(1,n+2)
    count3+=1
print('Stage 3 PASS:',count3,'positive-center-block large-overlap certificates outside R419')
print('Scope: exact geometric implication/volume bounds and native positive-block compatibility. No full own-past/current-D/clock/history R419 instance or positive universal paid fraction is certified.')
