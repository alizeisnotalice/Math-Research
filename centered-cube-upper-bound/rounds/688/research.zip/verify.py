from pathlib import Path
from fractions import Fraction as F
from itertools import combinations,product
from flint import arb,ctx
import json,hashlib
P=Path(__file__).resolve().parent;j=json.loads((P/'RESULT.json').read_text())
assert hashlib.sha256((P/'NUMERIC.py').read_bytes()).hexdigest()==j['script_sha256']
def box(x):return [tuple(map(F,t)) for t in x]
def hit(A,B):return all(max(l,a)<min(u,b) for (l,u),(a,b) in zip(A,B))
def inside(A,x):return all(l<t<u for (l,u),t in zip(A,x))
def volume(A):
 out=F(1)
 for l,u in A:out*=u-l
 return out
def mids(boxes):
 ax=[]
 for t in range(len(boxes[0])):
  z=sorted({v for B in boxes for v in B[t]});ax.append([(a+b)/2 for a,b in zip(z,z[1:])])
 return product(*ax)
subsetcount=0;graphcount=0
fixtures=[j['two_group_fixture']]+j['complete_conflict_fixtures']+j['three_square_exchange']['per_old_source_refund_graphs']
for row in fixtures:
 A=box(row['source']);Hs=list(map(box,row['targets']));w=list(map(F,row['weights']));n=len(w)
 assert all(hit(A,H) for H in Hs)
 edges=[(u,v) for u,v in combinations(range(n),2) if not hit(Hs[u],Hs[v])]
 assert edges==list(map(tuple,row['conflict_edges']))
 covers=[]
 for mask in range(1<<n):
  subsetcount+=1
  if all(mask>>u&1 or mask>>v&1 for u,v in edges):covers.append(sum((w[u] for u in range(n) if mask>>u&1),F(0)))
 R=min(covers);assert R==F(row['refund_R_exact'])
 beta=max((sum((v for v,H in zip(w,Hs) if inside(H,x)),F(0)) for x in mids([A]+Hs) if inside(A,x)),default=F(0))
 assert beta==sum(w,F(0))-R==F(row['beta_essential'])
 edgeweights={tuple(e['edge']):F(e['weight']) for e in row['fractional_matching_edges']}
 assert all(e in edges and v>=0 for e,v in edgeweights.items())
 assert all(sum((v for e,v in edgeweights.items() if u in e),F(0))<=w[u] for u in range(n))
 dual=list(map(F,row['fractional_cover_vertex_values']));assert all(x>=0 for x in dual)
 assert all(dual[u]+dual[v]>=1 for u,v in edges)
 M=sum(edgeweights.values(),F(0));assert M==sum(a*b for a,b in zip(w,dual))==F(row['fractional_matching_M_exact'])
 assert M<=R<=2*M;graphcount+=1
star=j['two_group_fixture'];assert F(star['beta_essential'])==F(37,60) and F(star['beta_closed'])==F(61,60)
e=j['three_square_exchange'];cost=list(map(F,e['baseline_costs_d_i_theta_i']));beta=list(map(F,e['beta_per_old_source']));R=list(map(F,e['refund_R_per_old_source']));value=F(e['proposal_value'])
assert value-sum(a*b for a,b in zip(cost,beta))==F(1,2)==F(e['batch_gain'])
assert sum(a*b for a,b in zip(cost,R))==F(1,2)==F(e['weighted_refund_sum'])
assert F(e['naive_multiplicity_charge'])-F(e['weighted_refund_sum'])==F(e['true_beta_charge'])
ctx.prec=256
for row in j['actual_full_pool_entropy_scalar_check']['checks']:
 n=row['n'];x=arb(16384)*arb(n).sqrt()*31/32
 assert x.contains(F(row['x_tau_over_c_exact']).numerator)
 y=x-1-x.log();assert y.overlaps(arb(row['log_K'])) and y>arb(2).log() and y>x/2
assert F(16384*16)*31/32==253952
if (P/'MANIFEST.json').exists():
 for name,digest in json.loads((P/'MANIFEST.json').read_text()).items():assert hashlib.sha256((P/name).read_bytes()).hexdigest()==digest,name
print(json.dumps({'status':'PASS','independent_local_graphs':graphcount,'enumerated_vertex_subsets':subsetcount,'exact_matching_dual_certificates':graphcount,'Arb_scalar_cases':3,'scope':'frozen exact geometry/refund and scalar checks; no original-history global bound'}))
