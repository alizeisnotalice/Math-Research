# R688 exact cross-group refund certificates

## Decision

The frozen geometric examples verify `beta=sum(psi)-R`, where R is the exact weighted vertex-cover cost of the positive-hit conflict graph. Fractional matching gives `M<=R<=2M`; complete conflict examples distinguish M from the exact refund.

The actual full-pool entropy input changes the proposed use of this approximation: its matching-based lower-gain certificate is negative under the actual-baseline cost bound. The positive finite three-square batch exchange remains valid, but does not establish an actual high-threshold positive gain. A factor-two refund bound is not a factor-two netgain guarantee.

Only the supplied fixtures were computed. No parameter search, original high-tau owner history, or complete maximal-operator conclusion is claimed.

## Definitions and exact geometry

Fix a source cube A and retain targets with positive-volume intersection with A. Two retained targets are adjacent in the conflict graph when their interiors are disjoint; a face contact therefore is a conflict. For proposal weights psi, let

`beta=esssup_A sum_h psi_h 1_Hh`.

A conflict-free target subset, together with A, is a finite pairwise positive-overlap family of axis-aligned boxes. Coordinatewise interval Helly implies their common intersection has positive volume. Conversely every positive-volume arrangement atom supports a conflict-free subset. Thus beta is the maximum independent-set weight, giving

`beta=sum_h psi_h-R`,

where R is the minimum weighted vertex-cover cost. The code computes beta from a Fraction arrangement and independently enumerates every vertex subset to find R. Closed maxima and contact-only edges are recorded separately.

The fractional matching LP assigns nonnegative edge weights x with incident sums at most psi at every vertex. Its dual has vertex prices y>=0 with y_u+y_v>=1 on each conflict edge, minimizing sum_h psi_h y_h. Matching and dual certificates are checked exactly. SciPy/HiGHS supplies only a floating cross-check. The inequalities `M<=R<=2M` follow from relaxation and rounding dual vertex values at1/2; the finite examples independently satisfy them.

## Stage1: frozen two-group actual-cube fixture

Source: Q((0,0),4). Targets:

| target | center | radius | psi |
|---|---|---:|---:|
| H1 | (-1,0) | 2 | 1/5 |
| H2 | (-3/2,0) | 2 | 2/5 |
| H3 | (3/2,0) | 1 | 1/4 |
| H4 | (3/2,1/2) | 1 | 1/6 |

The exact conflict edges are H2-H3 and H2-H4. Both are face contacts at x=1/2, hence zero-volume overlaps. The source contains all targets.

The arrangement and graph give

`sum psi=61/60`, `beta_essential=37/60`, `R=2/5`.

An exact matching assigns1/4 to H2-H3 and3/20 to H2-H4, totaling2/5. The H2 vertex capacity2/5 is saturated; leaf capacities are respected. Dual vertex value one at H2 and zero elsewhere has the same cost2/5. Therefore `M=R=2/5` exactly.

The global proposal is feasible **a.e.**, with essential maximum37/60<1. Its closed maximum is61/60>1 on the common face contact. It is therefore incorrect to assert closed pointwise load<=1 for this fixture. The essential-load and conflict conventions agree precisely because face-only overlaps are excluded.

The early witness(-1,0) belongs to H1,H2; the late witness(1,1/2) belongs to H3,H4; late targets avoid the early witness; and radii are nonincreasing across the two groups. Only these stated local conditions are verified. Actual owners, saturation thresholds, complete original chronology and original high-tau recursion are not supplied.

## Stages2–3: odd cycles and bounded complete conflicts

The frozen K3 consists of radius1/2 targets centered at(-2,0),(0,0),(2,0), all weights one, inside Q((0,0),4). Each is a singleton group. K4 and K8 use radius1/4 targets centered at `(2i-(m-1),0)`, i=0,...,m-1, inside Q((0,0),m). These are strictly separated equal tiny cubes, with no contact ambiguity.

| graph | exact refund R | fractional matching M | beta | R/M |
|---|---:|---:|---:|---:|
| K3 | 2 | 3/2 | 1 | 4/3 |
| K4 | 3 | 2 | 1 | 3/2 |
| K8 | 7 | 4 | 1 | 7/4 |

All 2^m vertex subsets are enumerated. Exact matching value m/2 is certified by assigning1/(m-1) to every edge, so every vertex has total incident weight one. Dual vertex values1/2 have weighted cost m/2. The exact integral cover has m-1 vertices. These examples show an approach toward the factor-two refund gap; no netgain is assigned to them.

## Frozen R687 three-square exchange, independently recomputed

Old radius-one squares have centers(0,0),(-3/2,0),(3/2,0), parent volumes d_i=4 and baseline

`theta=(1/8,7/8,7/8)`.

The old charges are **d_i theta_i**:

`(1/2,7/2,7/2)`, totaling15/2.

The proposal selects the left and right squares with weights one. For the central old square, the two positive-hit targets form a K2 conflict: total proposal weight2, beta1, refundR=M=1. Each side old square hits only its own target and has beta1,refund0. Thus

`naive multiplicity hit charge=8`,

`true beta charge=15/2`,

`weighted refund=sum_i d_i theta_i R_i=1/2`.

The proposal value is8, giving exact batch gain1/2 and new coefficients(0,1,1). Each single proposal has old neighbor charge4 and value4, so both single deficits and single gains are zero. The shared central expense is refunded only once in the batch. All old/new arrangement loads are checked; this fixture has no difference between closed and positive-hit neighbors.

These charges are not mu_i/tau and are not imported into the original baseline without its separate definitions. This is an actual finite square packing exchange, not a high-tau historical construction.

## Actual full-pool entropy: why fractional matching cannot certify positive gain

The following is a separately supplied analytic input, not a conclusion of the toy fixtures:

`c_h>=K_n d_h`,

`K_n=(c/tau)exp(tau/c-1)`, `c=c0^n<=32/31`, `tau=16384sqrt(n)`.

For a proposal of value `Dpsi=sum_h d_h psi_h`, its full multiplicity hit charge N is then at least K_n Dpsi. Fractional matching refunds at most half the full hit charge, because twice its edge sum is at most the sum of vertex capacities. Therefore the matching-based **lower-gain certificate** is bounded above by

`Dpsi-N+matching_refund <=Dpsi-N/2 <=(1-K_n/2)Dpsi`.

For a nonzero proposal and K_n>2, this certificate is negative. This does **not** prove that the true exact-refund gain is negative. It proves that this matching lower certificate cannot establish positive gain under the entropy hypothesis. The finite three-square positive exchange has not been shown to satisfy those actual full-pool hypotheses.

Only the requested scalar sanity checks are computed, using c=32/31 and 256-bit Arb in the logarithmic domain:

`logK=tau/c-1-log(tau/c)`.

| n | exact tau/c | logK (approx.) | logK>log2 |
|---|---:|---:|---|
| 256 | 253952 | 253938.555099 | yes |
| 65536 | 4063232 | 4063215.782511 | yes |
| 1000000 | 15872000 | 15871982.419933 | yes |

The full certified intervals and margins are in RESULT.json. No huge exponential K is constructed. These three checks are finite verification, not a proof for every n. The general analytic route is `x>=8 => x-1-logx>=x/2>log2`, once the full-pool input applies.

The next useful refund criterion must retain near-total exact cover refunds or another comparably precise cancellation. A constant relative approximation to refund R cannot be promoted to a relative approximation of `Dpsi-N+R`: subtracting N can destroy that guarantee.

## Reproducibility

Executed frozen-geometry command:

```text
/Users/zzh/.local/share/math-research-tools/venv/bin/python /Volumes/data/CodexTemp/centered-cube-r688-20261116/NUMERIC.py
```

The later entropy check was appended without rerunning those fixtures:

```text
/Users/zzh/.local/share/math-research-tools/venv/bin/python /Volumes/data/CodexTemp/centered-cube-r688-20261116/NUMERIC.py --entropy-only
```

All geometry, atom masses, beta values, cover enumerations, matching capacities, fractional duals, refund charges and gains use exact Fraction arithmetic. SciPy1.18.1/HiGHS only cross-checks the matching objectives. Python/platform/NumPy/SciPy and python-flint versions, commands, exact witnesses, intervals and errors are retained in RESULT.json.

The frozen graph/geometry run body took about0.025seconds and the entropy append about0.007seconds. All exact assertions and Arb comparisons passed, errors are empty, and both processes exited with code zero. Source SHA-256: `f203023f0ac8a1141c33db0186cbe87e5aa4c0af84e262efacd6fe24da72a4cd`. Result SHA-256: `0eb0d6aafbcd7e65c9eea2a9bbee63e64a17b30a45c8bf7ff8c3031a5cccecb7`.

Only the three owned R688 files were written. No arbitrary scan, MATLAB, package installation, PDF, Git or child agent was used. Computation is stopped.
