#!/usr/bin/env python3
"""R688 frozen cross-group refund graph and actual-cube arrangement certificates."""
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import hashlib,json,sys,time,platform
import numpy as np
import scipy
from scipy.optimize import linprog
ROOT=Path(__file__).resolve().parent;start=time.time()
def cube(y,s):return [(v-s,v+s) for v in y]
def inside(p,B):return all(lo<=v<=hi for v,(lo,hi) in zip(p,B))
def positive(A,B):return all(max(a0,b0)<min(a1,b1) for (a0,a1),(b0,b1) in zip(A,B))
def contact(A,B):return all(max(a0,b0)<=min(a1,b1) for (a0,a1),(b0,b1) in zip(A,B))
def vol(B):
 out=F(1)
 for lo,hi in B:out*=hi-lo
 return out
def atoms(boxes):
 axes=[]
 for t in range(len(boxes[0])):
  ends=sorted(set(v for B in boxes for v in B[t]));aa=[]
  for j,e in enumerate(ends):
   aa.append((e,F(0),0))
   if j+1<len(ends):aa.append(((e+ends[j+1])/2,ends[j+1]-e,1))
  axes.append(aa)
 for xs in product(*axes):
  mass=F(1)
  for v in xs:mass*=v[1]
  yield [v[0] for v in xs],mass,sum(v[2] for v in xs)
def serial(v):
 if isinstance(v,F):return str(v)
 if isinstance(v,(list,tuple)):return [serial(x) for x in v]
 if isinstance(v,dict):return {k:serial(x) for k,x in v.items()}
 return v

def refund_graph(source,targets,weights,cert_matching=None,cert_fractional_cover=None):
 N=[i for i,T in enumerate(targets) if positive(source,T)];assert N==list(range(len(targets)))
 m=len(N);edges=[(i,j) for i in range(m) for j in range(i+1,m) if not positive(targets[i],targets[j])]
 total=sum(weights,F(0));R=None;cover=None;coverchecks=[]
 for mask in range(1<<m):
  if all(mask>>i&1 or mask>>j&1 for i,j in edges):
   cost=sum((weights[i] for i in range(m) if mask>>i&1),F(0));coverchecks.append((mask,cost))
   if R is None or cost<R:R=cost;cover=mask
 beta=F(0);closedbeta=F(0);globaless=F(0);globalclosed=F(0);arr=[]
 for p,mass,dim in atoms([source]+targets):
  load=sum((w for w,T in zip(weights,targets) if inside(p,T)),F(0))
  globalclosed=max(globalclosed,load)
  if mass>0:globaless=max(globaless,load)
  if inside(p,source):
   closedbeta=max(closedbeta,load)
   if mass>0:beta=max(beta,load)
  arr.append({'point':p,'mass':mass,'dimension':dim,'load':load,'inside_source':inside(p,source)})
 assert beta==total-R
 result={'source':source,'targets':targets,'weights':weights,'positive_hit_target_indices':N,'conflict_edges':edges,'closed_contact_conflict_edges':[(i,j) for i,j in edges if contact(targets[i],targets[j])],'total_proposal_weight':total,'beta_essential':beta,'beta_closed':closedbeta,'global_essential_load':globaless,'global_closed_load':globalclosed,'refund_R_exact':R,'minimum_vertex_cover_indices':[i for i in range(m) if cover>>i&1],'vertex_cover_masks_checked':1<<m,'valid_covers':coverchecks,'beta_equals_total_minus_R':True,'arrangement':arr}
 if cert_matching is not None:
  xx=[cert_matching.get((i,j),F(0)) for i,j in edges];yy=cert_fractional_cover
  assert all(x>=0 for x in xx) and all(y>=0 for y in yy)
  vertexloads=[sum((xx[e] for e,(a,b) in enumerate(edges) if i in (a,b)),F(0)) for i in range(m)]
  assert all(vertexloads[i]<=weights[i] for i in range(m))
  assert all(yy[i]+yy[j]>=1 for i,j in edges)
  M=sum(xx,F(0));dual=sum((weights[i]*yy[i] for i in range(m)),F(0));assert M==dual
  assert M<=R<=2*M
  if edges:
   A=np.array([[int(i in e) for e in edges] for i in range(m)],dtype=float)
   lp=linprog(-np.ones(len(edges)),A_ub=A,b_ub=np.array([float(w) for w in weights]),bounds=(0,None),method='highs')
   assert lp.success and abs(-lp.fun-float(M))<1e-10
   cross={'success':bool(lp.success),'objective':float(-lp.fun),'exact_objective':M,'objective_error':abs(-lp.fun-float(M))}
  else:cross={'status':'empty graph; fractional matching0 exactly'}
  result.update({'fractional_matching_edges':[{'edge':e,'weight':x} for e,x in zip(edges,xx)],'fractional_matching_vertex_loads':vertexloads,'fractional_cover_vertex_values':yy,'fractional_matching_M_exact':M,'fractional_cover_dual_exact':dual,'R_between_M_and_2M':True,'R_over_M':R/M if M else None,'HiGHS_crosscheck':cross})
 return result
def append_entropy_certificate():
    from flint import arb,ctx
    import flint
    from math import isqrt
    ctx.prec=256;tick=time.time();dst=ROOT/'RESULT.json';old=json.loads(dst.read_text());checks=[]
    for n in (256,65536,10**6):
        rr=isqrt(n);assert rr*rr==n
        x=F(16384*rr)*F(31,32)
        ax=arb(x.numerator)/x.denominator
        logK=ax-1-ax.log()
        assert logK>arb(2).log() and logK>ax/2 and x>=8
        checks.append({'n':n,'c_worst':'32/31','tau':'16384*sqrt(n)','x_tau_over_c_exact':str(x),'log_K':str(logK),'log_K_minus_log2':str(logK-arb(2).log()),'log_K_greater_than_log2':True,'K_greater_than2':True,'log_K_greater_than_x_over2':True})
    old['actual_full_pool_entropy_scalar_check']={'scope':'Finite scalar sanity checks only. The actual-baseline inequality c_h>=K_n*d_h is an external analytic full-pool entropy input, not certified by the toy conflict graphs or this arithmetic.','python_flint_version':flint.__version__,'precision_bits':ctx.prec,'formula':'logK=tau/c-1-log(tau/c), c<=32/31','checks':checks,'general_analytic_route':'For x>=8, x-1-log(x)>=x/2>log2. This analytic argument, not the3 finite checks, proves the full-range implication once the entropy input applies.','conditional_gain_decision':'Fractional matching refund<=one half of the full hitcost. If fullhitcost>=K_n*Dpsi, the matching-based lower-gain certificate is at most(1-K_n/2)*Dpsi<0 for Dpsi>0. It cannot certify a positive actual-baseline gain.','provenance_separation':'Finite3-square positive batch gain does not satisfy or establish the actual full-pool entropy hypotheses. R in[M,2M] is not a netgain approximation; near-total exact-cover refund may be necessary.','no_huge_exponentiation':True,'command':[sys.executable,str(Path(__file__).resolve()),'--entropy-only'],'elapsed_seconds':time.time()-tick}
    old['script_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest();dst.write_text(json.dumps(old,indent=2)+'\n')
    print(json.dumps({'entropy_checks':checks,'elapsed_seconds':time.time()-tick,'source_sha256':old['script_sha256'],'RESULT_sha256':hashlib.sha256(dst.read_bytes()).hexdigest()},indent=2))

if '--entropy-only' in sys.argv:
    append_entropy_certificate()
    raise SystemExit(0)

# Stage1 frozen Astra two-group fixture.
source=cube([F(0),F(0)],F(4));targets=[cube([F(-1),F(0)],F(2)),cube([F(-3,2),F(0)],F(2)),cube([F(3,2),F(0)],F(1)),cube([F(3,2),F(1,2)],F(1))];weights=[F(1,5),F(2,5),F(1,4),F(1,6)]
star=refund_graph(source,targets,weights,{(1,2):F(1,4),(1,3):F(3,20)},[F(0),F(1),F(0),F(0)])
assert star['total_proposal_weight']==F(61,60) and star['beta_essential']==F(37,60) and star['refund_R_exact']==star['fractional_matching_M_exact']==F(2,5)
assert star['global_essential_load']<=1 and star['global_closed_load']==F(61,60)>1
w0=[F(-1),F(0)];w1=[F(1),F(1,2)]
assert all(inside(w0,T) for T in targets[:2]) and all(inside(w1,T) for T in targets[2:]) and all(not inside(w0,T) for T in targets[2:])
star['group_contract_checks']={'early_witness':w0,'late_witness':w1,'each_group_common_witness_verified':True,'late_targets_avoid_early_witness':True,'radii_nonincreasing_by_group':True,'scope':'Only these radius/witness conditions checked; no owners, high-tau saturation or complete historical recursion is supplied.'}
# Stage2 frozen odd-cycle pressure; Stage3 bounded complete conflicts K4,K8.
complete=[]
for m in (3,4,8):
 if m==3:src=source;Ts=[cube([F(c),F(0)],F(1,2)) for c in (-2,0,2)]
 else:src=cube([F(0),F(0)],F(m));Ts=[cube([F(2*i-(m-1)),F(0)],F(1,4)) for i in range(m)]
 E={(i,j):F(1,m-1) for i in range(m) for j in range(i+1,m)}
 row=refund_graph(src,Ts,[F(1)]*m,E,[F(1,2)]*m)
 assert len(row['conflict_edges'])==m*(m-1)//2 and row['refund_R_exact']==m-1 and row['fractional_matching_M_exact']==F(m,2) and row['beta_essential']==1
 row['singleton_group_indices']=list(range(m));row['stage']='boundary/oddcycle' if m==3 else 'bounded expansion';complete.append(row)
# Recompute R687 actual3-square packing exchange with geometric refunds.
old=[cube([F(0),F(0)],F(1)),cube([F(-3,2),F(0)],F(1)),cube([F(3,2),F(0)],F(1))];theta=[F(1,8),F(7,8),F(7,8)];psi_targets=old[1:];psi_weights=[F(1),F(1)];di=[vol(B) for B in old];cost=[di[i]*theta[i] for i in range(3)];baseline=sum(cost,F(0));assert baseline==F(15,2)
perold=[]
for i,B in enumerate(old):
 N=[j for j,T in enumerate(psi_targets) if positive(B,T)];Ts=[psi_targets[j] for j in N];ww=[psi_weights[j] for j in N]
 if len(N)==2:r=refund_graph(B,Ts,ww,{(0,1):F(1)},[F(1),F(0)])
 else:r=refund_graph(B,Ts,ww,{},[F(0)])
 perold.append(r)
beta=[r['beta_essential'] for r in perold];totalweights=[r['total_proposal_weight'] for r in perold];refunds=[r['refund_R_exact'] for r in perold]
naive=sum((cost[i]*totalweights[i] for i in range(3)),F(0));truecharge=sum((cost[i]*beta[i] for i in range(3)),F(0));refundvalue=sum((cost[i]*refunds[i] for i in range(3)),F(0));proposalvalue=sum((vol(T)*w for T,w in zip(psi_targets,psi_weights)),F(0));gain=proposalvalue-truecharge
assert naive==8 and truecharge==F(15,2) and refundvalue==F(1,2) and gain==F(1,2)
singles=[]
for j,T in enumerate(psi_targets):
 neigh=[i for i,B in enumerate(old) if positive(B,T)];charge=sum((cost[i] for i in neigh),F(0));deficit=charge-vol(T);assert deficit==0
 singles.append({'target':j,'positive_hit_old_indices':neigh,'old_charge':charge,'target_value':vol(T),'single_deficit':deficit,'single_gain':-deficit})
newtheta=[F(0),F(1),F(1)];maxafter=F(0)
for p,mass,dim in atoms(old):
 before=sum((w for w,B in zip(theta,old) if inside(p,B)),F(0));after=sum((w for w,B in zip(newtheta,old) if inside(p,B)),F(0));assert before<=1 and after<=1;maxafter=max(maxafter,after)
exchange={'old_squares':old,'old_theta':theta,'d_i':di,'baseline_costs_d_i_theta_i':cost,'baseline_objective':baseline,'proposal_targets':psi_targets,'proposal_weights':psi_weights,'per_old_source_refund_graphs':perold,'beta_per_old_source':beta,'refund_R_per_old_source':refunds,'naive_multiplicity_charge':naive,'true_beta_charge':truecharge,'weighted_refund_sum':refundvalue,'proposal_value':proposalvalue,'single_deficits':singles,'new_theta':newtheta,'batch_gain':gain,'new_objective':baseline+gain,'scope':'Actual finite3-square exchange; charges are d_i*theta_i, not mu_i/tau. No high-tau history or maximal-operator conclusion.'}
out={'scope':'Only frozen actual rational cubes and their abstract conflict graph optimization. No high-tau owner/history realization, global maximal-operator theorem, or netgain approximation theorem is claimed.','python':sys.version,'platform':platform.platform(),'numpy_version':np.__version__,'scipy_version':scipy.__version__,'command':[sys.executable,str(Path(__file__).resolve())],'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'arithmetic':'Fraction exact arrangements, cover enumeration and matching/cover primal-dual; SciPy HiGHS floating cross-check only','two_group_fixture':serial(star),'complete_conflict_fixtures':serial(complete),'three_square_exchange':serial(exchange),'summary':{'frozen_group_fixture_count':1,'complete_graph_sizes':[3,4,8],'three_square_exchange_verified':True,'all_beta_total_minus_cover_checks_passed':True,'all_fractional_matching_duality_checks_passed':True,'contact_convention':'Conflict means disjoint interiors; face contact is a conflict for essential loads. Closed load is recorded separately and may exceed1.','refund_bound_only':'R in[M,2M] is a refund bound, not a multiplicative netgain guarantee after subtracting single deficits.'},'elapsed_seconds':time.time()-start,'errors':[]}
(ROOT/'RESULT.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'summary':out['summary'],'elapsed_seconds':out['elapsed_seconds'],'source_sha256':out['script_sha256'],'RESULT_sha256':hashlib.sha256((ROOT/'RESULT.json').read_bytes()).hexdigest(),'star':{'total':str(star['total_proposal_weight']),'beta':str(star['beta_essential']),'closed':str(star['beta_closed']),'R':str(star['refund_R_exact']),'M':str(star['fractional_matching_M_exact'])},'exchange_gain':str(gain)},indent=2))

append_entropy_certificate()
