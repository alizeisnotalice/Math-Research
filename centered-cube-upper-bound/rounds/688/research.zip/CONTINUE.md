# R688 continuation: exact selective deletion, not a factor-two refund approximation

Original arbitraryL1/allscales/Lebesgue C_n<=Ksqrt(n) remains open. R688 no new unconditional uniformbound. Keep user cap1Astra+3GPT6.1Sol. All4currentagents reused. Original P0 includesALLoriginalparents,noqcap. Preserve R684 correct receiver normalization/full entrance fees. Round689 is next completed round after this archive.

## Actual new decision and exact formulas

Positive-volume pairwise intersections of finite axisalignedboxes imply positive-volume commonintersection. For sourceAi and proposalψ(feasiblecommonpacking), retain onlypositivehit targetparents. Conflictgraph edge means pair has ZERO overlapvolume, including boundary-onlycontact. Then beta_i=esssup_Ai fψ=max independentweight=totalhitweight S_i−weightedvertexcover R_i. Eachactualhistorygroup hasstrictcommonwitness soallconflictedges crossgroups.

Proportionalexchange θ'=(1−beta)θ+ψ has FULL gain
G=−Σ_hψ_h ε_h+Σ_i diθ_i R_i,
ε_h=Σ_positivehit_i diθ_i−dh.
Foractualθ0=q/τ,diθ_i=μ_i/τ. Independent localmatchings are allowed since sourcecosts differ, butsameglobalψ andallnegativeε charges MUST remain. Fractionalmatching M_i is safe LOWERrefund, M_i<=R_i<=2M_i viafiniteVCduality andthresholdrounding. Roundedcover UPPERrefund cannotbe subtracted asprovensaving.

## Actual entropy changes usefulness of this approximation

ForFULLhistoricalpoolPb ofrateτ and minradiusseed r_b, d0=(2r_b)^n,
H(u)=Σ_{Pb:di<=u}μ_i<=min(cu,U_b),c=(1+1/a)^n<=32/31.
τ=∫_{d0}∞H(u)/u²du<=c[1+log(U_b/(cd0))], so U_b>=cd0 exp(τ/c−1).
ForEVERYactualresidualtargeth inb, positivehits includePb,di>=d0>=dh. Thus singlecharge c_h=(1/τ)Σhit μ_i>=K_n dh,
K_n=(c/τ)exp(τ/c−1),logK=x−1−logx,x=τ/c>=253952 for n>=256.

Matching lowergain<=Dψ−.5Σψc_h<=(1−K_n/2)Dψ<0 forEVERYnonzeroψ supportedACTUALresidualtargets. It CANNOTcertifypositivegain. This is NOT truegainno-go: exactcover canrefund near-totalcharges. A2approximation torefund isNOT a2approximation toNETgain.
Ifψ uses≤Bactualgroups,beta_i>=S_i/B,soTRUEproportionalgain<=(1−K_n/B)Dψ. Scope isθ0andproportionalβ deletion,NOTallfeasibledeletion/otherbaselines/alloriginaldebits.

The same regime is actually paid: |Y_b|<=cdseed<=exp(1−τ/c)U_b,
V<=exp(1−τ/c)Σ_i μ_i N_i<=Bexp(1−τ/c)U.
ForB<=K_n,wholeV<=cU/τ. Thus noexchangegain inthisrange doesNOTmean hardunpaidvolume. In general N_i=#fullpoolsusingsource mayhuge; NEVERdelete N_i or claimuniformclosure. Source reuse remains thehardbranch.

## Exact next contract; don't overstrengthen its goal

Forfeasibleψ,choose NONPROPORTIONALremovalδ by
C(ψ)=min d·δ, 0<=δ<=θ0=q/τ,
Aδ >=(Aθ0+Aψ−1)_+ onALLpositive-volumeoriginalarrangementcells.
Feasibleδ=θ0 exists; compactbox givesattainment. θ0−δ+ψ islegal; δβ=θ0beta isonlyonecandidate,so C(ψ)<=oldβcost. K/Bandmatchingno-go DONOTtransfertoC. No need polynomial complexity; exactjointdeletion allowed.
Single-group no-positivegain DOEStransfer: atitsstrictcommonhistoricalsatcell,ΣPbδ>=Σgroupψ, anddi>=dseed>=dh,so dδ>=Dψ. A genuinelypositive move mustuse2+histories orchangebaseline, but noexponentialB lowerbound isproved forselectivedeletion. No uniformchoiceofψ linkedtowholeactualVhasbeenconstructed.

## Prevent a circular optimization

Old J(p)=Σμ_i esssup_Ai Fp+Δ||Fp||∞,Δ=τP0−U obeysJ>=τDp. Anyoriginaloptimalθ*hasesssup_Ai fθ*=1 foreveryoriginalparent (else addlabel). SoJ(θ*)=τP0 andmin_{Dp=V}J(p)=τV exactly, withp=(V/P0)θ*. Unconstrainednormoptimization isthereforeONLYtheoriginalgoal again; doNOTcountitasgeometryprogress. Needactualreceiver-directedconstructivecontrol.

## Actual calculations

Frozen two-history4cube star:essentialβ37/60,closedload61/60 (allowed onlya.e!),R=M2/5. K3,K4,K8 all-disjointtargetconflicts:R=m−1,M=m/2,properdirection. R6873square fixture generalpackinggain.5,notactualhighτhistory. Arb256bitlogKchecks atn256,65536,10^6 useconservativec32/31,nohugeexponentiation. Analyticproofforalln separate.
Mainverify independentlyrebuilds7source-localgraphs,enumerates304vertexsubsets,checks7exactmatching-dualcertificatesand3Arbcases;PASS. NUMERICcontainsversions/commands/results. NoMATLAB/PDF/packageinstall. Firstverifyoriginalmanifest;rerunNUMERICinseparatecopy becauseelapsedtimechangesJSONhash.

Nextwork: actual2+historyselective deletion orchangedbaseline withcompleteobjectivegain/receiverpayment. Do notcontinuefractionalmatching-onlylowerrefund orfew-groupβoptimization. A validfiniteLPcontractisnotitselfasolution; retainallcells,radii,sourcecaps,realreceiversandfullfees.
