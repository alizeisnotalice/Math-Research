from pathlib import Path
import sympy as s,json,sys
m,a,U,b,t=s.symbols('m a U b t',positive=True)
mid=(m-a)+b*(m*s.log(m/a)-m+a)
upper=mid.subs(m,U)+s.diff(mid,m).subs(m,U)*(m-U)
checks={
'mid_matches_hinge_integral':s.simplify(mid-((m-a)+b*s.integrate((m-t)/t,(t,a,m)))),
'upper_matches_hinge_integral':s.simplify(upper-((m-a)+b*s.integrate((m-t)/t,(t,a,U)))),
'upper_slope':s.simplify(s.diff(upper,m)-(1+b*s.log(U/a))),
'upper_gap_to_mass_budget':s.simplify(m*(1+b*s.log(U/a))-upper-(b*U+(1-b)*a)),
}
assert all(x==0 for x in checks.values())
# Four exact ordering regimes for h_t; zero case m<=t is by all hinges zero.
x,y=s.symbols('x y',positive=True)
regimes={
'both_children_at_least_t':s.expand((x+y-t)-(x-t)-(y-t)-t),
'x_below_t_y_at_least_t':s.expand((x+y-t)-(y-t)-x),
'y_below_t_x_at_least_t':s.expand((x+y-t)-(x-t)-y),
'both_children_below_t_parent_above_t':s.expand((x+y-t)-(x+y-t)),
}
assert all(v==0 for v in regimes.values())
d={'status':'PASS_PIECEWISE_SYMBOLIC_IDENTITIES_ONLY','interpreter':sys.executable,'python':sys.version.split()[0],'sympy':s.__version__,'potential_checks':{k:str(v) for k,v in checks.items()},'hinge_cases':{k:str(v) for k,v in regimes.items()},'scope':'Analytic branch assumptions required; does not prove any geometric cut inequality, arbitrary dimension bound, or numeric feasibility.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))
