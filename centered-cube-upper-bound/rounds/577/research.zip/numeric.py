"""R577 signed coordinate-cut/potential diagnostic; three bands, all 63 components."""
from fractions import Fraction as F
from math import isqrt,gcd
from pathlib import Path
import argparse,json,sys,platform,time,resource,shlex
import sympy as S
import flint
from flint import arb,ctx
ctx.prec=192
parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=Path(__file__).resolve().parent/'numeric.json');args=parser.parse_args()
START=time.perf_counter();PREC=192;DEN=2**PREC;ROOT={};DECISIONS=0
INHERITED_PREFLIGHT_SHA256='11b5731688ec7f87bf46da65dcde6126023e8c72daa9bf08393c1092393b58a6'
MINIMAL_INPUT=json.loads('{"source_positions":[["-3/2","-3/4"],["-3/2","3/4"],["0","-3/4"],["0","3/4"],["3/2","-3/4"],["3/2","3/4"]],"cells":[{"cell_indices":[8,10],"witness_masks":[15],"area_coefficients":{"3":"-3/4","6":"1/2","1":"3/2","2":"-1"}},{"cell_indices":[9,10],"witness_masks":[7,11,13,14,15],"area_coefficients":{"1":"-13/4","2":"9/4","3":"3/4","6":"-1/2"}},{"cell_indices":[10,8],"witness_masks":[15],"area_coefficients":{"2":"-1","6":"1/2","1":"3/2","3":"-3/4"}},{"cell_indices":[10,9],"witness_masks":[7,11,13,14,15],"area_coefficients":{"2":"9/4","1":"-13/4","6":"-1/2","3":"3/4"}},{"cell_indices":[10,10],"witness_masks":[7,11,13,14,15],"area_coefficients":{"2":"-3","1":"17/4"}},{"cell_indices":[10,11],"witness_masks":[7,11,13,14,15],"area_coefficients":{"2":"9/4","6":"-1/2","1":"-13/4","3":"3/4"}},{"cell_indices":[10,12],"witness_masks":[15],"area_coefficients":{"2":"-1","6":"1/2","1":"3/2","3":"-3/4"}},{"cell_indices":[11,10],"witness_masks":[7,11,13,14,15],"area_coefficients":{"1":"-13/4","2":"9/4","3":"3/4","6":"-1/2"}},{"cell_indices":[12,10],"witness_masks":[15],"area_coefficients":{"1":"3/2","2":"-1","3":"-3/4","6":"1/2"}},{"cell_indices":[18,10],"witness_masks":[60],"area_coefficients":{"1":"3/2","2":"-1","3":"-3/4","6":"1/2"}},{"cell_indices":[19,10],"witness_masks":[28,44,52,56,60],"area_coefficients":{"2":"9/4","1":"-13/4","3":"3/4","6":"-1/2"}},{"cell_indices":[20,8],"witness_masks":[60],"area_coefficients":{"1":"3/2","3":"-3/4","2":"-1","6":"1/2"}},{"cell_indices":[20,9],"witness_masks":[28,44,52,56,60],"area_coefficients":{"1":"-13/4","2":"9/4","3":"3/4","6":"-1/2"}},{"cell_indices":[20,10],"witness_masks":[28,44,52,56,60],"area_coefficients":{"1":"17/4","2":"-3"}},{"cell_indices":[20,11],"witness_masks":[28,44,52,56,60],"area_coefficients":{"1":"-13/4","3":"3/4","2":"9/4","6":"-1/2"}},{"cell_indices":[20,12],"witness_masks":[60],"area_coefficients":{"1":"3/2","3":"-3/4","2":"-1","6":"1/2"}},{"cell_indices":[21,10],"witness_masks":[28,44,52,56,60],"area_coefficients":{"3":"3/4","6":"-1/2","1":"-13/4","2":"9/4"}},{"cell_indices":[22,10],"witness_masks":[60],"area_coefficients":{"1":"3/2","2":"-1","3":"-3/4","6":"1/2"}}]}')
def rootbounds(d):
    if d not in ROOT:
        v = isqrt(d * DEN * DEN)
        ROOT[d] = (F(v, DEN), F(v, DEN) if v * v == d * DEN * DEN else F(v + 1, DEN))
    return ROOT[d]

def clean(v):
    return {d: c for d, c in v.items() if c}

def add(a, b):
    z = a.copy()
    for d, c in b.items():
        z[d] = z.get(d, F(0)) + c
    return clean(z)

def neg(a):
    return {d: -c for d, c in a.items()}

def sub(a, b):
    return add(a, neg(b))

def mul(a, b):
    z = {}
    for d, c in a.items():
        for e, f in b.items():
            g = gcd(d, e)
            q = d * e // (g * g)
            z[q] = z.get(q, F(0)) + c * f * g
    return clean(z)

def rat(x):
    return clean({1: F(x)})

def sqrtr(k, c=F(1)):
    q = 1
    d = k
    p = 2
    while p * p <= d:
        while d % (p * p) == 0:
            q *= p
            d //= p * p
        p += 1
    return rat(c * q) if d == 1 else clean({d: c * q})

def bounds(v):
    lo = F(0)
    hi = F(0)
    for d, c in v.items():
        a, b = rootbounds(d)
        lo += c * (a if c >= 0 else b)
        hi += c * (b if c >= 0 else a)
    return (lo, hi)

def sign(v):
    global DECISIONS
    if not v:
        return 0
    lo, hi = bounds(v)
    DECISIONS += 1
    if lo > 0:
        return 1
    if hi < 0:
        return -1
    raise AssertionError('Unresolved exact algebraic sign: ' + str(v))

def expr(v):
    return str(sum((S.Rational(c.numerator, c.denominator) * S.sqrt(d) for d, c in sorted(v.items()))))

def exactout(v):
    lo, hi = bounds(v)
    return {'radical_coefficients': {str(d): str(c) for d, c in sorted(v.items())}, 'expression': expr(v), 'isolating_interval': [str(lo), str(hi)], 'display': str(S.N(sum((S.Rational(c.numerator, c.denominator) * S.sqrt(d) for d, c in v.items())), 20))}
def aq(q):
 q=F(q);return arb(q.numerator)/q.denominator
def av(v):
 out=arb(0)
 for d,c in v.items():out+=aq(c)*arb(d).sqrt()
 return out
def phi(m,L,U):
 a=F(L,2)
 if m<=a:return arb(0)
 if m<=U:return m*(aq(F(m)/a)).log()
 return m*(1+aq(F(U)/a).log())-U
def phisym(m,L,U):
 a=S.Rational(L,2)
 if m<=a:return S.Integer(0)
 if m<=U:return m*S.log(m/a)
 return m*(1+S.log(U/a))-U
z=[list(map(F,p)) for p in MINIMAL_INPUT['source_positions']];N=len(z);assert N==6
cells=MINIMAL_INPUT['cells'];assert len(cells)==18
assert sorted(set().union(*(set(c['witness_masks']) for c in cells)))==[7,11,13,14,15,28,44,52,56,60]
areas=[{int(d):F(a) for d,a in c['area_coefficients'].items()} for c in cells]
for area in areas:assert sign(area)>0
allv={}
for area in areas:allv=add(allv,area)
assert allv=={1:F(-11,2),2:F(4)}
b=arb(1)/arb(2).sqrt();bands=[]
def hinge(m,L):return max(F(m)-F(L,2),F(0))
def psi(m,L,U):return b*phi(m,L,U)+(1-b)*aq(hinge(m,L))
sm,sa,sU,sb=S.symbols('m a U b',positive=True)
mid=(sm-sa)+sb*(sm*S.log(sm/sa)-sm+sa)
assert S.simplify(mid-(sb*sm*S.log(sm/sa)+(1-sb)*(sm-sa)))==0
tangent=mid.subs(sm,sU)+(sm-sU)*S.diff(mid,sm).subs(sm,sU)
assert S.simplify(tangent-(sb*(sm*(1+S.log(sU/sa))-sU)+(1-sb)*(sm-sa)))==0
for L,U in [(1,6),(3,4),(4,4)]:
 v={};v_cells={}
 for mask in range(1,1<<N):
  covered=[i for i,c in enumerate(cells) if any(w&mask==w and L<=w.bit_count()<=U for w in c['witness_masks'])]
  total={}
  for i in covered:total=add(total,areas[i])
  v[mask]=total;v_cells[mask]=set(covered)
 assert all(not v[1<<i] for i in range(N))
 assert v[63]==allv
 # Initial mechanism sanity: both actual four-source corner components have residual.
 assert sign(v[15])>0 and sign(v[60])>0
 components=[];ratios_for_global=[];psi_ratios_for_global=[];cutcount=0;negative=zero=positive=0
 for mask in range(1,1<<N):
  ids=[i for i in range(N) if mask>>i&1];m=len(ids);cuts=[]
  for axis in range(2):
   coords=sorted({z[i][axis] for i in ids})
   for c0,c1 in zip(coords,coords[1:]):
    left=sum(1<<i for i in ids if z[i][axis]<=c0);right=mask^left
    assert left and right and not left&right and left|right==mask
    assert v_cells[left]<=v_cells[mask] and v_cells[right]<=v_cells[mask]
    ml=left.bit_count();mr=right.bit_count()
    D=sub(sub(v[mask],v[left]),v[right]);ds=sign(D)
    negative+=ds<0;zero+=ds==0;positive+=ds>0;cutcount+=1
    dp=phi(m,L,U)-phi(ml,L,U)-phi(mr,L,U)
    dps=S.expand_log(phisym(m,L,U)-phisym(ml,L,U)-phisym(mr,L,U),force=True)
    dh=hinge(m,L)-hinge(ml,L)-hinge(mr,L)
    assert dh>=0
    dpsi=psi(m,L,U)-psi(ml,L,U)-psi(mr,L,U)
    if m<=F(L,2):
     psi_ratio=None;psi_ratio_string=None
     assert not D and dps==0;ratio=None;ratio_string=None
    else:
     assert dp>0
     ratio=av(D)/(b*dp);ratio_string=ratio.str(45)
     assert dpsi>0
     psi_ratio=av(D)/dpsi;psi_ratio_string=psi_ratio.str(45)
    cuts.append({'axis':axis,'threshold_between':[str(c0),str(c1)],'representative_threshold':str((c0+c1)/2),'left_mask':left,'right_mask':right,'child_masses':[ml,mr],'D':exactout(D),'D_sign':ds,'DeltaPhi_symbolic':str(dps),'DeltaPhi_Arb':dp.str(45),'ratio_Arb':ratio_string,'Delta_hinge_exact':str(dh),'DeltaPsi_identity':'b*DeltaPhi+(1-b)*Delta_hinge','DeltaPsi_Arb':dpsi.str(45),'Psi_ratio_Arb':psi_ratio_string,'_psi_ratio':psi_ratio,'_D':D,'_ratio':ratio,'_mass_pair':tuple(sorted((ml,mr)))})
  best=[];psi_best=[]
  if sign(v[mask])>0:
   assert cuts and all(c['_ratio'] is not None for c in cuts)
   best=[0]
   for i in range(1,len(cuts)):
    cand=cuts[i];old=cuts[best[0]]
    if cand['_D']==old['_D'] and (not cand['_D'] or cand['_mass_pair']==old['_mass_pair']):best.append(i)
    elif cand['_ratio']<old['_ratio']:best=[i]
    elif old['_ratio']<cand['_ratio']:pass
    else:raise AssertionError('Unresolved optimal-cut comparison')
   ratios_for_global.append((mask,cuts[best[0]]['_ratio']))
   psi_best=[0]
   for i in range(1,len(cuts)):
    cand=cuts[i];old=cuts[psi_best[0]]
    if cand['_D']==old['_D'] and (not cand['_D'] or cand['_mass_pair']==old['_mass_pair']):psi_best.append(i)
    elif cand['_psi_ratio']<old['_psi_ratio']:psi_best=[i]
    elif old['_psi_ratio']<cand['_psi_ratio']:pass
    else:raise AssertionError('Unresolved Psi optimal-cut comparison')
   psi_ratios_for_global.append((mask,cuts[psi_best[0]]['_psi_ratio']))
  components.append({'mask':mask,'mass':m,'mass_above_band_U':m>U,'v':exactout(v[mask]),'positive_residual':sign(v[mask])>0,'covered_residual_cell_indices':sorted(v_cells[mask]),'cuts':[{k:x for k,x in c.items() if not k.startswith('_')} for c in cuts],'optimal_cut_indices_certified':best,'best_ratio_Arb':cuts[best[0]]['ratio_Arb'] if best else None,'Psi_optimal_cut_indices_certified':psi_best,'Psi_best_ratio_Arb':cuts[psi_best[0]]['Psi_ratio_Arb'] if psi_best else None,'Phi_Psi_best_cut_indices_differ':bool(best and best!=psi_best)})
 # Certified enclosing interval for largest component-wise minimum; no dimension inference.
 # Ratios may tie by symmetry; compare strict when balls separate, otherwise keep co-max candidates.
 maxratio=ratios_for_global[0][1];maxmasks=[ratios_for_global[0][0]]
 for mask,r in ratios_for_global[1:]:
  if r>maxratio:maxratio=r;maxmasks=[mask]
  elif maxratio>r:pass
  else:maxratio=maxratio.union(r);maxmasks.append(mask)
 psi_maxratio=psi_ratios_for_global[0][1];psi_maxmasks=[psi_ratios_for_global[0][0]]
 for mask,r in psi_ratios_for_global[1:]:
  if r>psi_maxratio:psi_maxratio=r;psi_maxmasks=[mask]
  elif psi_maxratio>r:pass
  else:psi_maxratio=psi_maxratio.union(r);psi_maxmasks.append(mask)
 bands.append({'Psi_max_of_best_ratio_Arb':psi_maxratio.str(45),'Psi_co_maximal_component_candidates':psi_maxmasks,'Phi_Psi_best_cuts_differ_component_count':sum(c['Phi_Psi_best_cut_indices_differ'] for c in components),'L':L,'U':U,'a':str(F(L,2)),'component_count':63,'positive_residual_components':sum(c['positive_residual'] for c in components),'coordinate_cut_count':cutcount,'negative_D_count':negative,'zero_D_count':zero,'positive_D_count':positive,'terminal_singleton_v_zero':True,'full_component_v_matches_original_residual':True,'mass_above_U_components_retained':sum(c['mass_above_band_U'] for c in components),'max_of_best_ratio_Arb':maxratio.str(45),'co_maximal_component_candidates':maxmasks,'components':components})
result={'status':'PASS_SIGNED_CUT_POTENTIAL_THREE_BANDS_ALL_63_COMPONENTS','n':2,'bands':bands,'inherited_preflight_sha256':INHERITED_PREFLIGHT_SHA256,'minimal_input':MINIMAL_INPUT,'input_scope':'Extracted exact R576 residual cell geometry; no independent source geometry reconstruction. Each band filters ALL true witness subsets contained in actual I. Original H2 unchanged on children.','algebraic_v_D_error':'0; exact squarefree-radical Fraction arithmetic','log_ratio_certificate':'python-flint Arb192 natural logs, 45-digit ball displays; no floats used in decisions','optimal_cut_comparison':'strict disjoint Arb comparisons, or exact identical D and child mass multiset (zero D also exact ties)','Psi_middle_and_tangent_symbolic_identity_residual':'0','Psi_definition':'b*Phi(m)+(1-b)*(m-a)_+, exactly equivalent to proposed middle formula and U-tangent continuation; target ratio D/DeltaPsi has no outer b','Arb_precision_bits':192,'interpreter':sys.executable,'python_version':platform.python_version(),'sympy_version':S.__version__,'python_flint_version':flint.__version__,'command':'OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 '+shlex.join([sys.executable]+sys.argv),'runtime_seconds':time.perf_counter()-START,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'processes':1,'scope':'Finite signed-cut discrimination only; no LP, n-order extrapolation or general cut-existence theorem.'}
args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps([{k:v for k,v in band.items() if k!='components'} for band in bands],ensure_ascii=False,indent=2))
print(json.dumps({k:v for k,v in result.items() if k not in ['bands','minimal_input']},ensure_ascii=False,indent=2))
