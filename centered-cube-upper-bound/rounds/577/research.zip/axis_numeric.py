"""Six frozen scalar axis-family certificates, no source enumeration.
Analytic geometric implications are supplied by root; this checks finite n only.
"""
from fractions import Fraction as Q
from pathlib import Path
import argparse,json,sys,platform,time,resource,shlex
import flint
from flint import arb,ctx
ctx.prec=512
parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=Path(__file__).resolve().parent/'axis_numeric.json');args=parser.parse_args();start=time.perf_counter()
def aq(x):
 x=Q(x);return arb(x.numerator)/arb(x.denominator)
def disp(x):return x.str(60)
rows=[]
for n in [256,1024,2**16,2**32,2**64,2**128]:
 klo=39*n//100;khi=2*n//5;q=Q(1,n)
 ln=arb(n).log();rho=aq(Q(5,4*n))*ln;b=1/arb(n).sqrt()
 rk=(aq(Q(klo,n)).log()/n).exp()
 beta=(klo*(-rho/rk).log1p()).exp()
 # Never subtract two nearly equal rounded numbers: use expm1/log1p.
 log_Rhi=aq(Q(2*khi,n)).log()/n
 one_minus_Rhi=-log_Rhi.expm1()
 Rhi=log_Rhi.exp()
 p=one_minus_Rhi/(2*(1-rho))
 log_vupper=n*(-rho).log1p()
 vupper=log_vupper.exp()
 bracket=-(klo*(-p).log1p()).expm1()
 vlow=vupper*bracket**2
 dphi=aq(q)*arb(2).log()-(1-aq(q))*(-aq(q)).log1p()
 dpsi=b*dphi+(1-b)*aq(q)
 assert dphi>0 and dpsi>0 and vlow>0 and vupper>vlow and p>0 and p<1
 original_lower=vlow/(b*dphi)
 new_upper=vupper/dpsi
 checks={'rho_positive':bool(rho>0),'rho_lt_one':bool(rho<1),'klo_ge_two':klo>=2,'two_khi_lt_n':2*khi<n,'klo_le_khi':klo<=khi,'klo_beta_gt_b_certified':bool(beta>b),'beta_argument_positive':bool(1-rho/rk>0),'Rhi_lt_one_certified':bool(Rhi<1),'p_between_zero_and_one':bool(p>0 and p<1)}
 rows.append({'n':str(n),'klo':str(klo),'khi':str(khi),'q_exact':str(q),'rho_Arb':disp(rho),'b_Arb':disp(b),'r_klo_Arb':disp(rk),'beta_klo_Arb':disp(beta),'beta_klo_minus_b_Arb':disp(beta-b),'Rhi_Arb':disp(Rhi),'one_minus_Rhi_Arb':disp(one_minus_Rhi),'p_Arb':disp(p),'one_minus_one_minus_p_power_klo_Arb':disp(bracket),'vlow_Arb':disp(vlow),'vupper_Arb':disp(vupper),'DeltaPhi_Arb':disp(dphi),'DeltaPsi_Arb':disp(dpsi),'original_ratio_lower_Arb':disp(original_lower),'Psi_ratio_upper_Arb':disp(new_upper),'original_ratio_lower_gt_one_certified':bool(original_lower>1),'checks':checks,'all_finite_checks_pass':all(checks.values())})
result={'status':'PASS_ALL_SIX_FINITE_AXIS_SCALAR_CERTIFICATES' if all(r['all_finite_checks_pass'] for r in rows) else 'FINITE_AXIS_CHECK_FAILURE_RETAINED','rows':rows,'precision_bits':512,'formulas':{'rho':'(5/4)*log(n)/n','beta_k':'[1-rho/(k/n)^(1/n)]^k for k>=2','klo':'floor(39*n/100)','khi':'floor(2*n/5)','Rhi':'(2*khi/n)^(1/n)','p':'(1-Rhi)/(2*(1-rho))','vlow':'(1-rho)^n*[1-(1-p)^klo]^2','vupper':'(1-rho)^n','band':'[1,1], a=1/2','DeltaPhi':'q*log(2)-(1-q)*log1p(-q), q=1/n','DeltaPsi':'b*DeltaPhi+(1-b)*q, b=1/sqrt(n)','old_bound':'vlow/(b*DeltaPhi): lower bound conditional on supplied geometry','new_bound':'vupper/DeltaPsi: upper bound, NOT exact D/DeltaPsi'},'stable_evaluation':'512-bit Arb log1p/expm1 for 1-Rhi, binomial complement, v powers, and DeltaPhi; integer n/k floors and rational arguments exact','analytic_input_boundary':'No general asymptotic or geometric proof here. Root supplies high-beta upper cutoff and residual-box lower-bound construction. Only six frozen n scalar premises/formulas certified, no huge atom enumeration.','Astra_file_at_start':'/tmp/ccu_r577_astra.md absent; root message parameters used as explicitly authorized frozen definition','interpreter':sys.executable,'python_version':platform.python_version(),'python_flint_version':flint.__version__,'command':'OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 '+shlex.join([sys.executable]+sys.argv),'runtime_seconds':time.perf_counter()-start,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'processes':1}
args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(result['status'])
for r in rows:print(json.dumps({k:r[k] for k in ['n','klo','khi','all_finite_checks_pass','original_ratio_lower_Arb','Psi_ratio_upper_Arb']},ensure_ascii=False))
print(json.dumps({k:result[k] for k in ['runtime_seconds','peak_rss_bytes','precision_bits']},indent=2))
