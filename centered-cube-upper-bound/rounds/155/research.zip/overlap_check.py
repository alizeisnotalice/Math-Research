#!/usr/bin/env python3
"""R155 finite rational hard-overlap/log-interval checks, no kernel scan."""
from fractions import Fraction as F
from functools import lru_cache
from pathlib import Path
import argparse,hashlib,json,math,sys
sys.set_int_max_str_digits(0)
ROOT=Path(__file__).resolve().parent

def enc(x):
    if isinstance(x,F):return str(x.numerator)+'/'+str(x.denominator)
    if isinstance(x,dict):return {k:enc(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)):return [enc(v) for v in x]
    return x

def box(q,N):
    s=1<<(4*N);k=q.numerator*s//q.denominator
    return F(k,s),F(k+1,s)
@lru_cache(None)
def log_box(x,N):
    assert x>0
    if x==1:return F(0),F(0)
    if x<1:
        l,u=log_box(1/x,N);return -u,-l
    j=0;y=x
    while y>=2:y/=2;j+=1
    def series(v):
        term=v;s=F(0)
        for i in range(N):s+=term/(2*i+1);term*=v*v
        lo=2*s;hi=lo+2*term/((2*N+1)*(1-v*v));return lo,hi
    l,u=series((y-1)/(y+1));l2,u2=series(F(1,3));l+=j*l2;u+=j*u2
    lo=box(l,N)[0];hi=box(u,N)[1];assert lo<=hi
    return lo,hi

def add_log(lo,hi,c,x,N):
    l,u=log_box(x,N)
    return (lo+c*l,hi+c*u) if c>=0 else (lo+c*u,hi+c*l)

def polynomial(d):
    p=[F(1)]
    for x in d:
        q=[F(0)]*(len(p)+1)
        for j,v in enumerate(p):q[j]-=x*v;q[j+1]+=v
        p=q
    return p

def geometry(d,z,k,label):
    n=len(d);assert n>=1 and 0<z<=1 and 0<=k<=n and min(d)>=0
    count=sum(x>=1-z for x in d)
    if count<k:return dict(label=label,status='REJECTED_DOMAIN',n=n,z=z,k=k,d=d,threshold_count=count)
    ell=z*z
    if max(d)>=1:
        return dict(label=label,status='PASS_ZERO_SUPPORT',n=n,z=z,k=k,d=d,threshold_count=count,E=[F(0),F(0)],difference_nonnegative=True)
    p=polynomial(d);a=max(ell,max(d));vol1=math.prod((1-x for x in d),start=F(1))
    rational=vol1+n*sum((p[j]*(a**(j-n)-1)/(n-j) for j in range(n)),F(0))
    boundary=math.prod((max(F(0),ell-x) for x in d),start=F(1))/ell**n
    alternative=boundary+sum((j*p[j]*(a**(j-n)-1)/(n-j) for j in range(1,n)),F(0))
    assert rational==alternative # Both expressions also have +n log(1/a).
    if not any(d):
        assert k==0 or z==1
        assert rational==1 and a==ell
        return dict(label=label,status='PASS_SYMBOLIC_EQUALITY',n=n,z=z,k=k,d=d,threshold_count=count,exact_E='1+2n*log(1/z)',difference=[F(0),F(0)],N=0)
    if z==1:
        assert rational==vol1 and vol1<=1
        return dict(label=label,status='PASS_ENDPOINT',n=n,z=z,k=k,d=d,threshold_count=count,E=[vol1,vol1],difference=[1-vol1,1-vol1],N=0)
    for N in [64,128,256,512,1024,2048,4096]:
        el,eu=add_log(rational,rational,F(n),1/a,N)
        rl,ru=add_log(z**k,z**k,2*n*z**k,1/z,N)
        dl,du=rl-eu,ru-el
        if dl>=0:
            return dict(label=label,status='PASS',n=n,z=z,k=k,d=d,threshold_count=count,a=a,polynomial_coefficients=p,rational_part=rational,log_coefficient=n,log_argument=1/a,E=[el,eu],upper_bound=[rl,ru],difference=[dl,du],N=N,independent_layer_formula_equal=True)
    return dict(label=label,status='UNRESOLVED',n=n,z=z,k=k,d=d,difference=[dl,du],N=N)

@lru_cache(None)
def e_box(N=64):
    s=sum((F(1,math.factorial(i)) for i in range(N+1)),F(0));return s,s+F(2,math.factorial(N+1))
def continuous_cap(n,m,N=64):
    R=F(n,m)
    if n==m:return F(3),F(3)
    ll,lu=log_box(R,N);el,eu=e_box()
    return 3+(ll+6*(R-1))/eu,3+(lu+6*(R-1))/el

def time_cap(n,m):
    assert 1<=m<=n
    if n==m:return dict(n=n,m=m,status='PASS_DIAGONAL',C=[F(3),F(3)],continuous=[F(3),F(3)],simple_bound=F(3),N=0,intervals=1)
    rational=F(3);terms=[]
    for k in range(m,n):
        z=F(k,k+1)
        # F_k(z)-F_(k+1)(z), all powers exact.
        rational+=z**k*(1+F(2*n,k))-z**(k+1)*(1+F(2*n,k+1))
        terms.append((-2*n*(z**k-z**(k+1)),z))
        assert F(k-1,k)<=z<=F(k+1,k+2)
    for N in [64,128,256,512]:
        l=u=rational
        for c,x in terms:l,u=add_log(l,u,c,x,N)
        cl,cu=continuous_cap(n,m,N)
        if u<=cl and cu<=F(3*n,m):
            return dict(n=n,m=m,status='PASS',C=[l,u],continuous=[cl,cu],simple_bound=F(3*n,m),integer_to_continuous_gap=[cl-u,cu-l],continuous_to_simple_gap=[F(3*n,m)-cu,F(3*n,m)-cl],N=N,intervals=n-m+1,switches=[F(k,k+1) for k in range(m,n)],rational_part=rational,log_terms=terms)
    return dict(n=n,m=m,status='UNRESOLVED',C=[l,u],continuous=[cl,cu],N=N)

# Synthetic even monotone step F: jumps at radii 1/2,3/2,3.
STEP=[(F(1,2),F(1,2)),(F(3,2),F(3,8)),(F(3),F(1,8))]
def clipped(d,H):
    return sum(c*min(H,max(F(0),(rad+F(1,2))*H-d)) for rad,c in STEP)
def step_case(d,z,k,label):
    n=len(d);ell=z*z;C=[clipped(x,F(1)) for x in d]
    assert sum(x<=z for x in C)>=k
    breaks={ell,F(1)}
    for x in d:
        for rad,c in STEP:
            for den in [rad+F(1,2),rad-F(1,2)]:
                if den>0 and ell<x/den<1:breaks.add(x/den)
    breaks=sorted(breaks);rat=math.prod(C,start=F(1));terms=[];segments=[]
    for l,r in zip(breaks,breaks[1:]):
        mid=(l+r)/2;pol=[F(1)];aff=[]
        for x,ctop in zip(d,C):
            slope=intercept=F(0)
            for rad,c in STEP:
                val=(rad+F(1,2))*mid-x
                if val<=0:continue
                if val>=mid:slope+=c
                else:slope+=c*(rad+F(1,2));intercept-=c*x
            assert slope>=0 and intercept<=0
            assert slope*l+intercept==clipped(x,l) and slope*r+intercept==clipped(x,r)
            assert 0<=clipped(x,l)/l<=clipped(x,r)/r<=ctop
            aff.append([intercept,slope]);q=[F(0)]*(len(pol)+1)
            for j,v in enumerate(pol):q[j]+=v*intercept;q[j+1]+=v*slope
            pol=q
        rat+=n*sum((pol[j]*(l**(j-n)-r**(j-n))/(n-j) for j in range(n)),F(0))
        if pol[n]:terms.append((n*pol[n],r/l))
        segments.append(dict(left=l,right=r,affine_I=aff,polynomial=pol))
    for N in [64,128,256,512,1024]:
        lo=hi=rat
        for c,arg in terms:lo,hi=add_log(lo,hi,c,arg,N)
        rl,ru=add_log(z**k,z**k,2*n*z**k,1/z,N)
        if hi<=rl:return dict(label=label,status='PASS',n=n,k=k,z=z,d=d,C=C,clip_segments=segments,rational_part=rat,log_terms=terms,monotone_envelope_upper=[lo,hi],score_upper=[rl,ru],gap=[rl-hi,ru-lo],N=N)
    raise AssertionError('step interval unresolved')

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',default=str(ROOT/'overlap_check.json'));args=ap.parse_args()
    stages={};rows=[]
    for stage,ns,zs in [('general',[1,2,4],[F(1,4),F(1,2),F(3,4)]),('expanded',[8,32,128],[F(1,16),F(1,2),F(15,16)])]:
        out=[]
        for n in ns:
            ks=range(1,n+1) if stage=='general' else sorted({1,math.isqrt(n)+(math.isqrt(n)**2<n),n//2,n})
            for z in zs:
                for k in ks:
                    for mode,off in enumerate([F(0),F(1,16),F(1,2),F(15,16)]):
                        d=[1-z+z*off if i<k else (F(0) if (i+mode)%2 else (1-z)/2) for i in range(n)]
                        out.append(geometry(d,z,k,f'{stage}:{n}:{z}:{k}:{mode}'))
        stages[stage]=out;rows+=out
    out=[]
    for n in [1,4,16]:
        for k in sorted({1,n}):
            for q in [2,8,32]:
                for z in [F(1,2**q),1-F(1,2**q)]:
                    for off in [F(0),F(1,2**q),1-F(1,2**q)]:
                        d=[1-z+z*off if i<k else F(0) for i in range(n)]
                        out.append(geometry(d,z,k,f'near:{n}:{k}:{q}:{z}:{off}'))
    stages['threshold']=out;rows+=out
    out=[]
    for n in [2,4]:
        for z in [F(1,4),F(3,4)]:
            for k in [1,n]:
                d=[1-z+z*F(i+1,n+2) if i<k else (1-z)*F(i+1,n+2) for i in range(n)]
                out.append(geometry(d,z,k,f'heterogeneous:{n}:{z}:{k}'))
    stages['heterogeneous']=out;rows+=out
    boundary=[([F(0),F(1,2)],F(1),1,'z1'),([F(1),F(0)],F(1,2),1,'touch'),([F(3,2),F(0)],F(1,2),1,'disjoint'),([F(0)]*4,F(1,2),0,'all_zero_k0'),([F(1,4),F(0)],F(1,2),0,'ell_equals_dmax'),([F(1,4),F(0)],F(1,2),1,'invalid_score'),([F(1,2),F(3,4),F(0)],F(1,2),2,'permutation_a'),([F(0),F(3,4),F(1,2)],F(1,2),2,'permutation_b')]
    out=[geometry(*v) for v in boundary];stages['boundary']=out;rows+=out
    assert out[-1]['E']==out[-2]['E']
    rejected=[x for x in rows if x['status']=='REJECTED_DOMAIN'];assert len(rejected)==1
    assert all(x['status'].startswith('PASS') or x in rejected for x in rows)
    times=[]
    for n in [1,2,4,8,16,32,64,128,256]:
        for m in sorted(x for x in {1,2,math.isqrt(n)+(math.isqrt(n)**2<n),(n+1)//2,n} if x<=n):times.append(time_cap(n,m))
    assert len(times)==36 and all(x['status'].startswith('PASS') for x in times)
    big=[]
    for n in [10**4,10**6]:
        for m in sorted({1,math.isqrt(n),n-1,n}):
            lo,hi=continuous_cap(n,m);assert hi<=F(3*n,m)
            big.append(dict(n=n,m=m,continuous=[lo,hi],simple_bound=F(3*n,m),status='PASS_CONTINUOUS_ONLY',integer_k_enumerated=False))
    soft=[]
    for n in [1,2,4]:
        for k in range(1,n+1):
            for z in [F(1,64),F(1,16),F(1,8)]:
                d=[F(7,2)-8*z+4*z*F(i,k+1) if i<k else F(i,2*n) for i in range(n)]
                soft.append(step_case(d,z,k,f'step:{n}:{k}:{z}'))
    result=dict(status='PASS',scope='Finite hard nested-overlap/log certificates only; not original full traffic or kernel certification',seed=None,execution=dict(full_producer_invocations=2,prior_full_failures=1,diagnostic_invocations=1,new_kernel_evaluations=0,new_receiver_points=0,space_grid_points=0),source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),plan_sha256=hashlib.sha256((ROOT/'overlap_numeric_plan.md').read_bytes()).hexdigest(),stage_counts={k:len(v) for k,v in stages.items()},geometry_total=len(rows),geometry_pass=len(rows)-len(rejected),geometry_expected_domain_rejections=len(rejected),log_interval_method='Exact Fraction atanh sum, explicit tail, dyadic outward rounding; no float acceptance',geometry=stages,synthetic_step_F=dict(radii_and_jumps=STEP,actual_phi=False,rows=soft,count=len(soft),note='Monotone numerator majorant, not equality to integral of supremum; no receiver grid'),time_integer=times,time_large_continuous=big,limitations=['No actual C or Q kernel evaluation','Original j/Pi commonization, soft/Q interfaces and receiver selectors unpaid','z=0 is a limiting branch only; not a log0 evaluation','eta inverse candidate only: remove auxiliary u posterior first using delta<=k_v; no eta^-2 claim'])
    Path(args.output).write_text(json.dumps(enc(result),ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ['status','stage_counts','geometry_total','geometry_pass','geometry_expected_domain_rejections']}))
if __name__=='__main__':main()
