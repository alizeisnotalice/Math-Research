# R155：真实产品核捕获与来源 score 联动的接收付款

状态：本稿证明一个原共同来源、全时间、全部实际 soft/尺度选择器下的根阶接收子支。默认分支为：good 来源 v∈Q_L(x)、k_t(v)≥⌈√n⌉、实际删源后加权保留质量至少 1/2；费用为 64Λ√n Wβ。原 good/bad、ρ、共同 α、history 和既有未付域均保持，不改输入类别。低保留质量、v 不在 Q_L(x)、低 score 三个互斥补集尚未由本稿支付；不称 FULL 闭合。

## JR1. 原来源的共同时间变量与删源质量

固定 (ω,V,y) 及原共同尺度带 [a,b]，b/a≤2。原 c_j≤1，实际窗口满足

    τ_j≤t≤h≤g=√(LR)，L,R∈[a,b]，g≤b c_j。

原文 Z_{j,t}=D_V(y)∩(T0(y)\A_{j,t}(y)) 中，底集

\[
 \mathcal D(y):=D_V(y)\cap T_0(y)
\]

与 j 无关，而被删块 A_{j,t} 一般依 j。此原定义由本轮来源合同核对；不假设删源在变元后共同化。ν_V 也不依 j。设

\[
 z=\frac{c_jt}{b},\quad
 C_i(v)=C(|y_i-v_i|/b),\quad
 w_z(v)=\prod_i\min\{1,C_i(v)/z\},\quad
 k_z(v)=\#\{i:C_i(v)<z\}.
 \tag{JR1}
\]

则原 w_t=w_z、k_t=k_z，dt/t=dz/z；实际窗口内 0<z≤c_j²≤1。定义共同未删权重和概率

\[
 E_z=\int_{\mathcal D(y)}w_z\,d\nu_V,\qquad
 d\widehat\Pi_z=E_z^{-1}1_{\mathcal D(y)}w_z\,d\nu_V.
\]

当 E_z=0 时该行无原交通。E_z>0 时，令 t_j(z)=bz/c_j，

\[
 \eta_j(z)=\widehat\Pi_z(Z_{j,t_j(z)})
          =e_{j,t_j(z)}/E_z\in[0,1].
\]

在原 Π 有定义的行上，准确有

\[
 d\Pi_{j,t_j(z)}=
 \frac{1_{Z_{j,t_j(z)}}}{\eta_j(z)}d\widehat\Pi_z.
 \tag{JR2}
\]

η_j 只需在原 Z_{j,t} 合法的时间上定义：先保留原窗口指示，完成比较后才扩展 z；非法时间的原行取零，不重造删源集。因此 η_j≥η0>0 时 Π_j≤η0^{-1}widehatΠ_z。此条件使用原 e 与同一 ν 的实际保留比例，不从 high 或 FIRST 推导；不把原后验坐标当独立。原 Z_t 的独立 j 依赖已明确支付为 η0^{-1}。

## JR2. 准确待支付子支与定理

任选整数 1≤m≤n、0<η0≤1。在原当前未付正交通中，取条件

\[
 \mathcal B_{m,\eta_0}:
 \quad v\in Q_{L(x)}(x),\qquad k_t(v)\ge m,
 \qquad\eta_j(c_jt/b)\ge\eta_0.
 \tag{JR3}
\]

Q_L(x) 是边长 L、中心 x 的坐标方盒。v 仍为原 terminal good，u 仍为原 terminal bad，G_t 仍含实际相反三核检验、窗口、所有原剩余历史和来源资格。Q*、K0、J、ρ 与 α 均不重定义。新增 Q_L 捕获是该实际来源的几何条件，不是给内来源虚构外 hard 资格。

本稿要证且以下证明

\[
 \boxed{2\Lambda P(\mathcal B_{m,\eta_0})
 \le32\Lambda\eta_0^{-1}\frac nm W_\beta.}
 \tag{JR4}
\]

特别 m=⌈√n⌉、η0=1/2 时

\[
 \boxed{2\Lambda P(\mathcal B_{\lceil\sqrt n\rceil,1/2})
 \le64\Lambda\sqrt n\,W_\beta.}
 \tag{JR5}
\]

此结论对全部实际 p=P_{s,L} 成立，未限制 s=0，也未只取 p 的全硬展开项。

## JR3. 一维真核的关键捕获锚点

原 w(u)=∫_0^1 exp(−|u|/r)dr 为非负偶函数，径向非增，并有 ∫w=∫_0^1 2r dr=1。故 φ=h1*w 满足 0≤φ≤1，且偶、径向非增；例如在正半轴其导数为 w(x+1/2)−w(x−1/2)≤0（可按绝对连续或分布意义处理）。因此

\[
 F=\max(h_1,\phi)\le1
\]

为偶、径向非增函数，在 [−1/2,1/2] 上等于1。其核心区平移积分

\[
 C(d)=\int_{-1/2}^{1/2}F(u-d)du
\]

也偶、径向非增，且 C(0)=1、0≤C≤1。这些性质来自真实核；没有用 Gaussian 替换。

固定来源 v 和接收 x，定义未归一捕获包络

\[
 G_H(x;y,v)=
 \prod_{i=1}^n F((x_i-y_i)/H)\;1_{Q_H(v)}(x).
 \tag{JR6}
\]

H 增大时 G_H 逐点非减：F 的输入半径缩小，且 Q_H(v) 嵌套扩大。对所有 s∈[0,1]，

\[
 P_{s,H}(x-y)1_{Q_H(v)}(x)\le H^{-n}G_H(x;y,v).
 \tag{JR7}
\]

这里没有在全空间积分裸 ∏F：它可能有指数维数质量。必须保留同一 good 来源的捕获方盒 Q_H(v)。该捕获恰给张量身份

\[
 \int H^{-n}G_H(x;y,v)dx
 =\prod_i C(|y_i-v_i|/H).
 \tag{JR8}
\]

对 H≤b，C 的径向单调性与 JR1 给

\[
 \prod_i C(|y_i-v_i|/H)
 \le\prod_i C_i(v)\le z^{k_z(v)}.
 \tag{JR9}
\]

最后一步中，每个已激活 score 坐标 C_i<z，其余 C_i≤1。此处产品核位移 x−y、捕获位移 x−v、来源 score 位移 y−v 确实在同一积分中相遇，不是三个分别取最有利值的核。

## JR4. 支付实际 soft/尺度选择器的联合接收包络

由 t≤√(LR)、R≤b，实际 L≥t²/b。在 JR1 变元后

\[
 L\ge b z^2/c_j^2\ge bz^2.
\]

因此在固定 z，全部实际 j 行的 L 都落在

\[
 [\ell_z,b],\qquad \ell_z=\max\{a,bz^2\}.
\]

对任何逐点非减的 G_H≥0，有简单但完整的尺度 majorant：

\[
 \sup_{\ell_z\le H\le b}H^{-n}G_H
 \le b^{-n}G_b+n\int_{\ell_z}^b H^{-n-1}G_H\,dH.
 \tag{JR10}
\]

证明：固定 L∈[ell_z,b]，右侧至少为
G_L[b^{-n}+n∫_L^b H^{-n-1}dH]=L^{-n}G_L；再取 sup。无需微分硬面或任何 selector/history，不遗漏其跳变。

用 JR8–JR9 积分 JR10，并用 log(b/ell_z)≤2log(1/z)，得到

\[
 \boxed{\int\sup_{s\in[0,1],\ L\in[\ell_z,b]}
 P_{s,L}(x-y)1_{Q_L(v)}(x)dx
 \le z^{k_z(v)}\{1+2n\log(1/z)\}.}
 \tag{JR11}
\]

这是本稿新增的可积几何增益。soft 的全部选择由 F 捕获锚点同时控制；scale 的费用被真实 t≤g 约束成临近端点的 log(1/z)。没有乘 JT13 的 (2n+3)D_n，也不需要先冻结 s,L 再声称选择器免费。

## JR5. 原来源、time、唯一 j 与全部常数

只在原合法 hard 合同下使用一次 q^{-1}∫h_R a_ωdν≤16/3。其余正门若依外 hard 来源，则按原允许方式放松。保持实际 good 来源条件 JR3，利用 δ_t(v,u)≤k_t(v) 和原 bad 后验总质量≤1，先对 u 积分。因此

\[
\begin{split}
 2\Lambda P(\mathcal B_{m,\eta_0})
 \le{}&\frac{32\Lambda}{3}
 \mathbb E\sum_{V,j}\int d\beta_V(y)\frac{dt}{t}\int dx\,
 1_{j(x)=j}p(x-y)\\
 &\times\int k_t(v)\rho_v G'_t(x;v)
 1_{Q_L(x)}(v)1_{k_t(v)\ge m}1_{\eta_j\ge\eta_0}
 d\Pi_{j,t}(v).
\end{split}
 \tag{JR12}
\]

G'_t∈[0,1] 仍可保留所有不依 u 的原门和实际窗口；删除 bad 检验只作正上界。此顺序仅需要一份 Π_j→widehatΠ_z 的比较，费用为 η0^{-1}，不是 η0^{-2}。原 α 仅通过其真实 0≤ρ≤1 被保留后放松；不领取额外储备余额，也不重新选择 α。

逐 j 变元 z=c_jt/b，使用 JR2，然后才将所有行写成同一 widehatΠ_z、k_z。原 1_{j(x)=j} 保持；各 j 的实际窗口可扩大到 0<z≤1。于是同一 x 上仍有 Σ_j1_{j(x)=j}≤1。对全部实际 s,L、ρG' 作合法正上界并用 JR11，得到

\[
 \frac{32\Lambda}{3\eta_0}
 \mathbb E\sum_V\int d\beta_V(y)
 \int_0^1\frac{dz}{z}\int
 1_{k_z(v)\ge m}k_z(v)z^{k_z(v)}
 \{1+2n\log(1/z)\}\,d\widehat\Pi_z(v).
 \tag{JR13}
\]

这一步同时保留了原 β、ν 的区别及唯一 j；没有在原 Π_j 仍依 j 时提前丢掉 j。widehatΠ_z 虽随 z 变化，始终只是一个概率，因此 JR13≤(32Λ/(3η0))I_{n,m}Wβ，其中

\[
 I_{n,m}:=\int_0^1
 \sup_{m\le k\le n}k z^k\{1+2n\log(1/z)\}\frac{dz}{z}.
\]

可将 k 的整数上确界扩大为连续区间。令 u=log(1/z)，连续最大值为

\[
 \sup_{m\le k\le n}ke^{-ku}
 =\begin{cases}
 ne^{-nu},&0\le u\le1/n,\\
 (eu)^{-1},&1/n\le u\le1/m,\\
 me^{-mu},&u\ge1/m.
 \end{cases}
\]

直接积分给

\[
 \boxed{I_{n,m}\le
 3+\frac1e\log(n/m)+\frac6e(n/m-1)
 \le3n/m.}
 \tag{JR14}
\]

最后用 log q≤q−1、7/e<3（q=n/m≥1）；m=n 时连续积分准确为3。代入 JR13 即 JR4。这里时间已经全部积分，包括扩大到 z∈(0,1) 的费用；不能另乘 log2 或漏算 endpoint 因子。

## JR6. 实际覆盖、互斥补集与共同 α 的边界

主支 JR3 是原 Ω 未付域的子支。原相反三核门仍使用同一个 full p=P_{s,L} 和同一个 Q*；没有将 Q* 的 good 条件替换为硬捕获，也没有声称每个 good v 必在 Q_L(x)。来源捕获条件是额外可核验的子支，费用已按原接收 measure 支付。

相对于本稿，原余部按以下顺序划为互斥补集：

1. η_j(z)<η0 的低保留质量部分；
2. η_j(z)≥η0，但 v∉Q_L(x) 的非捕获部分；
3. η_j(z)≥η0、v∈Q_L(x)，但 k_t(v)<m 的低 score 部分。

这三部分连同既有独立负账、futurebad、Ndel 等按原合同保留；本稿不把它们吸收到 JR4。k=0 的正 score 差自然为零。若取 m=1，可覆盖全部正 score 捕获项，但价退为32Λη0^{-1}nWβ，不能据此声称一般根阶。

一般 ν、实际 L1 外 β、全部时间与选择器均在已证明分支内；没有特殊输入函数假设。共同 α 的额外正收益未被本稿使用，因此本稿不解决低η、非捕获来源尾与 α 余额的下一步联动。若要取消 JR3 的任一条件，必须另行支付上述准确补集，而不能用固定参数分数矩或 FIRST 归一化代替。

### 捕获支的资格限制及现有压力覆盖

本轮 `legacy_capture_scope.md` 的独立旧数据核对报告：8376 个已保存的 good 且 ρ>0 接收/来源点全部在 Q_L(x) 外。因此 JR5 对这些关键压力点没有覆盖，不能称已解决其主要费用；这不是对一般输入的空支证明。

还可从原公式精确指出一个空支区域。令 m_s=1−s+sφ(1/2)，则原 H0、T 满足 T=(m_s/H0)^n。若 H0≥a，则 Hhat=min(b,H0)≤H0；对 v∈Q_Hhat(x)，

\[
 K_0(v)\ge(m_s/\widehat H)^n\ge T.
\]

故在同一来源还满足 D≥Δ_v=wτ(v)−wh(v) 时，DK0≥TΔ_v，原 ρ_v>0 不可能。于是 **H0≥a、D≥Δ_v、Hhat≥L** 的实际行上，本稿 Q_L 捕获支为空；若 Hhat<L，ρ>0 的捕获来源至多在 Q_L\Q_Hhat 的壳内。这里保留精确条件 D≥Δ_v，不默认未经本轮核准的 D≥1。

若 H0<a，则 Hhat=a，核心区仅有 K0/T≥(H0/a)^n，以上排空推论不适用。仅凭公式未排除不能推出存在合法非空 FULL 实例。本轮未证本捕获支一般为空，也未构造非空 FULL 实例；本稿证明的是严格条件付款。下一重点仍是实际 v∉Q_L(x) 的产品核/来源机制，而不是扩大一个未覆盖现有压力的子支。

本轮没有新增核评估或浮点诊断，证明是 JR6–JR14 的解析不等式。固定原 ν 与全部 e、gate、ρ、α 做非负积分截断；不截断 ν 后重算后验声称单调。仅写本文件，完成后等待独审，不扩大路线。
