# R155 finite capture-scope check

## Result

On the saved R151 I1 receiver grid, there is no sampled source-point pair satisfying all three conditions `good`, saved `rho>0`, and `v in Q_L(x)` for the R136 template's `L=0.9` (four dimensions; half-side `0.45`). Thus the proposed source-box payment branch is empty on these pressure samples. This is a finite-grid finding only; it does not say the branch is empty on the continuous receiver domain.

The geometric test used the exact rational `xq` coordinates in `receiver_probe_points.json` and exact decimal-rational R136 source positions. Among all six sources, regardless of good/rho role, 646 of 3,600 source-point pairs are inside `Q_L(x)` on the m=4 grid and 7,926 of 46,656 pairs on m=8. But none are in the saved good, positive-rho subset. There are 1,884 active good/rho source-point pairs over 600 m=4 points and 25,272 over 7,776 m=8 points; captured counts are 0 on both grids. The nearest source-box boundary distance among tested rational coordinates is 1/40 for m=4 and 1/80 for m=8, so no coordinate lies on a cube face.

| Source | m=4 active good/rho pairs | m=8 active good/rho pairs | captured pairs, both grids |
|---|---:|---:|---:|
| G1 | 229 | 3,096 | 0 |
| G2 | 232 | 3,158 | 0 |
| G3 | 227 | 3,100 | 0 |
| G4 | 412 | 5,489 | 0 |
| B | 344 | 4,741 | 0 |
| CORE | 440 | 5,688 | 0 |

The saved `pair_terms` contain 344 rows at m=4 and 4,998 at m=8, with summed stored `I` values about 3.560602949 and 61.303803235, respectively. Every pair-term `v` source is outside `Q_L(x)` at its corresponding sample; the captured pair-term count and captured stored-I sum are both zero. These are sums of the saved finite diagnostic fields, not estimates of the continuous `C_t` traffic integral.

## Score-threshold intervals

Here `n=4`, hence `m=ceil(sqrt(n))=2`. For this I1 template, `b=c_j=1`, and the stored R136 thresholds are the four coordinate crossing times for `k_t(v)=#{i: threshold_i(v)<t}`. On `[tau,h]`, `tau=0.5` and `h≈0.9463145519717078`. Each listed coordinate threshold repeats four times except G3, which has two of each of its two values.

| Source | Coordinate thresholds (approximately) | `k_t>=2` on `[tau,h]` |
|---|---|---|
| G1 | 0.1583240247 × 4 | entire `[tau,h]` (k=4) |
| G2 | 0.0499613069 × 4 | entire `[tau,h]` (k=4) |
| G3 | 0.1583240247 × 2; 0.0499613069 × 2 | entire `[tau,h]` (k=4) |
| G4 | 0.6280349911 × 4 | `(0.6280349911,h]` (k=4 after the crossing) |
| B | 0.0051559369 × 4 | entire `[tau,h]` (k=4) |
| CORE | 0.7892964896 × 4 | `(0.7892964896,h]` (k=4 after the crossing) |

At a crossing time the strict test `threshold<t` excludes that coordinate; endpoints do not affect interval length. Thus four sources meet the threshold condition for the whole time window, and two meet it only after their crossing. This score fact does not change the zero captured good/rho-positive source count above: `v in Q_L(x)` already fails for every such sampled source-point pair.

## What these files establish

The saved pair terms allow source-`v` attribution of their finite `I` diagnostics, and the exact coordinates allow an exact sampled cube-membership test. They do not encode the continuous receiver integral or a certificate for it. In particular, they do not provide an outward enclosure for the pointwise float64 `rho`/good decisions, sourcewise kernels over a region of `x`, the complete fixed-`(omega,V,j,y,t)` opposite-test and history factors needed in `G_t`, or a spatial integral of the captured subset. No kernel was recomputed here, and no traffic fraction or general coverage claim is made.

The R155 capture envelope is a conditional bound on the captured part. These data give no sampled nonempty example of that part among old good, positive-rho sources. They also do not prove the continuous part is empty. With no FULL tree or blocking proof, a template-level `eta` condition cannot be promoted to a general payment. All other receiver sources and unpaid terms remain outside this check.

## Inputs and method

- R151 point file: `/Users/zhengzhihao/Desktop/T/output/centered_cube_round151_20261015/receiver_probe_points.json`, SHA-256 `6c2180637b013ccfb255b25de7af9070c62a8077c8716e91aa0574b5bfa07df9`.
- R136 template file: `/Users/zhengzhihao/Desktop/T/output/centered_cube_round136_20261014/active_traffic_v2.json`, SHA-256 `1090fb2356abe035a997eb851a2f0252a3abe3edbeaf978e99900a38906392de`.
- Membership used exact `Fraction` comparisons on saved rational receiver coordinates and decimal-rational source coordinates; `good` and `rho>0` are the saved R151 float64 diagnostic masks.
- No additional kernel evaluation, receiver point, grid, or dimension was introduced.
