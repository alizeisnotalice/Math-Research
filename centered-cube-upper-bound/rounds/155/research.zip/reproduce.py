#!/usr/bin/env python3
"""Replay R155 exact finite geometry and saved-grid coverage; no new kernels."""
from pathlib import Path
import argparse,subprocess,sys,zipfile,shutil,json
p=argparse.ArgumentParser();p.add_argument('--rounds',type=Path,required=True);p.add_argument('--detail',type=Path,required=True);p.add_argument('--destination',type=Path,required=True);a=p.parse_args()
src=Path(__file__).resolve().parent;dst=a.destination.resolve()
if dst.exists():raise SystemExit('Use a new destination')
dst.mkdir(parents=True)
for n in ['overlap_check.py','scope_verify.py','overlap_numeric_plan.md']:shutil.copy2(src/n,dst/n)
with zipfile.ZipFile(a.rounds/'139/research.zip') as z:
 matches=[n for n in z.namelist() if Path(n).name=='active_traffic_v2.json'];assert len(matches)==1
 (dst/'active_traffic_v2.json').write_bytes(z.read(matches[0]))
def run(args):
 r=subprocess.run([sys.executable,*map(str,args)],capture_output=True,text=True,cwd=dst)
 if r.returncode:raise RuntimeError(r.stderr+r.stdout)
 return r.stdout
print(run(['overlap_check.py','--output',dst/'overlap_check.json']).strip())
assert (dst/'overlap_check.json').read_bytes()==(src/'overlap_check.json').read_bytes()
s=run(['scope_verify.py','--detail',a.detail,'--template',dst/'active_traffic_v2.json']);(dst/'scope_result.json').write_text(s)
assert json.loads(s)['status']=='PASS';print(s.strip());print('REPLAY_PASS; archived geometry JSON byte-identical; no kernel reevaluation')
