#!/usr/bin/env python3
"""Saved-mask coverage audit, not continuous traffic certification."""
import argparse,json,hashlib
from fractions import Fraction as F
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--detail',type=Path,required=True);p.add_argument('--template',type=Path,required=True);a=p.parse_args()
assert hashlib.sha256(a.detail.read_bytes()).hexdigest()=='6c2180637b013ccfb255b25de7af9070c62a8077c8716e91aa0574b5bfa07df9'
assert hashlib.sha256(a.template.read_bytes()).hexdigest()=='1090fb2356abe035a997eb851a2f0252a3abe3edbeaf978e99900a38906392de'
c=next(c for c in json.loads(a.template.read_text())['cases'] if c['id']=='I1');pos=[list(map(F,v['position'])) for v in c['atoms']];half=F(c['parameters']['L'])/2
out={}
for grid,rows in json.loads(a.detail.read_text())['point_records'].items():
 counts=dict(points=len(rows),all_inside=0,active=0,captured_active=0,pair_rows=0,captured_pairs=0)
 for row in rows:
  x=list(map(F,row['xq']));inside=[all(abs(xi-vi)<=half for xi,vi in zip(x,v)) for v in pos]
  counts['all_inside']+=sum(inside)
  for i in range(len(pos)):
   active=bool(row['good'][i] and row['rho'][i]>0);counts['active']+=active;counts['captured_active']+=active and inside[i]
  for pair in row['pair_terms']:
   counts['pair_rows']+=1;counts['captured_pairs']+=inside[pair['v']]
 expected={'4':(600,646,1884,344),'8':(7776,7926,25272,4998)}[grid]
 assert tuple(counts[k] for k in ['points','all_inside','active','pair_rows'])==expected
 assert counts['captured_active']==counts['captured_pairs']==0
 out[grid]=counts
print(json.dumps({'status':'PASS','scope':'finite saved float masks; exact coordinate membership; no kernel reevaluation','grids':out},ensure_ascii=False))
