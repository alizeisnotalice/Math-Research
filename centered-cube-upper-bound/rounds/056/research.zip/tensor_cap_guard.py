#!/usr/bin/env python3
"""Finite tensor-grid mass-one sources, exact distance/cap comparisons.
Energy event integration uses binary floats; sampling SE is not a certificate.
Singular source-atom receivers have M=infinity and zero capped integrand.
No time grid and no enumeration of m**n source atoms in principal experiments.
"""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
from decimal import Decimal, localcontext
import bisect
import random
import math
import json
import time

D=2**24
Q=math.exp(-1)
C=1-Q
CAPS=(F(1,2),F(1),F(4))

def tensor_events(x,n,m):
    """Return integer radius and new tensor-count increments, equal ties batched."""
    coords=[(2*j+1-m)*(D//(2*m)) for j in range(m)]
    raw=sorted((abs(x[i]-y),i) for i in range(n) for y in coords)
    counts=[0]*n; previous=0; out=[]; k=0
    while k<len(raw):
        r=raw[k][0]
        while k<len(raw) and raw[k][0]==r:
            counts[raw[k][1]]+=1; k+=1
        count=math.prod(counts)
        if count>previous:
            out.append((r,count-previous,count))
            previous=count
    assert previous==m**n
    return out

def exact_cap_and_max(events,n,m):
    if events[0][0]==0:return (False,)*len(CAPS),None
    N=m**n; denpower=D**n; bestcount=0; bestvol=1
    for r,inc,count in events:
        vol=(2*r)**n
        if count*bestvol>bestcount*vol: bestcount,bestvol=count,vol
    M=F(bestcount*denpower,N*bestvol)
    return tuple(M<=H for H in CAPS),M

def event_energy(events,n,m,with_band=False):
    N=m**n
    ev=[]
    for r,inc,count in events:
        v=(2*r/D)**n; p=inc/N
        ev.extend(((1/(Q*v),-Q*p,p/v),(1/v,p,-p/v)))
    ev.sort(reverse=True)
    coef=0.; A=0.; pieces=[]; bandpieces=[]; k=0
    while k<len(ev):
        zhi=ev[k][0]; delta=[]; adelta=[]
        while k<len(ev) and ev[k][0]==zhi:
            delta.append(ev[k][1]); adelta.append(ev[k][2]); k+=1
        coef=math.fsum((coef,*delta)); A=math.fsum((A,*adelta))
        zlo=ev[k][0] if k<len(ev) else 0.
        ratio=zlo/zhi
        pieces.append(.5*(coef*zhi)**2*(1-ratio)*(1+ratio))
        if with_band and coef:
            low,high=sorted(((.25-A)/coef,(.5-A)/coef))
            low=max(zlo,low); high=min(zhi,high)
            if high>low:
                bandpieces.append(.5*(coef*high)**2*(1-low/high)*(1+low/high))
    ans=math.fsum(pieces)
    assert ans>=0 and math.isfinite(ans)
    return (ans,math.fsum(bandpieces)) if with_band else ans

def independent_midpoint_coeff(events,n,m):
    """Independently query actual cumulative cube masses between exact time events."""
    vs=[(2*r/D)**n for r,inc,count in events]
    masses=[count/m**n for r,inc,count in events]
    times=sorted(set([math.log(v)-1 for v in vs]+[math.log(v) for v in vs]))
    def mass_at(u):
        i=bisect.bisect_right(vs,math.exp(u))-1
        return masses[i] if i>=0 else 0.
    pieces=[]
    for left,right in zip(times,times[1:]):
        mid=(left+right)/2
        c=Q*mass_at(mid+1)-mass_at(mid)
        pieces.append(.5*c*c*math.exp(-2*left)*(-math.expm1(-2*(right-left))))
    pieces.append(.5*C*C*math.exp(-2*times[-1]))
    return math.fsum(pieces)

def stats(values,volume):
    mean=math.fsum(values)/len(values)
    var=math.fsum((v-mean)**2 for v in values)/(len(values)-1)
    return dict(estimate=volume*mean,sample_standard_error=volume*math.sqrt(var/len(values)))

def crosschecks():
    checks=[]; rng=random.Random(560019)
    for n,m in ((1,2),(1,4),(2,2),(2,4),(3,2),(3,4)):
        coords=[F(2*j+1-m,2*m) for j in range(m)]
        source=[(point,F(1,m**n)) for point in product(coords,repeat=n)]
        for trial in range(3):
            x=tuple(rng.randrange(-D,D) for i in range(n))
            events=tensor_events(x,n,m); cap,M=exact_cap_and_max(events,n,m)
            vp=[((2*max(abs(F(x[i],D)-y[i]) for i in range(n)))**n,p) for y,p in source]
            batch={}
            for v,p in vp:batch[v]=batch.get(v,F(0))+p
            mass=F(0); trueM=F(0)
            for v in sorted(batch):
                mass+=batch[v];trueM=max(trueM,mass/v)
            assert M==trueM
            numeric=event_energy(events,n,m)
            with localcontext() as ctx:
                ctx.prec=80; q=(-Decimal(1)).exp(); c=1-q; decimal=Decimal(0)
                data=[(Decimal(v.numerator)/Decimal(v.denominator),Decimal(p.numerator)/Decimal(p.denominator)) for v,p in vp]
                for vi,pi in data:
                    for vj,pj in data:
                        small,big=sorted((vi,vj)); ratio=big/small
                        kernel=(2-q-q*ratio*ratio)/(2*big*big) if ratio<=1/q else -c*c/(2*q*big*big)
                        decimal+=pi*pj*kernel
            err=abs(numeric-float(decimal))/max(float(decimal),1e-100)
            independent=independent_midpoint_coeff(events,n,m)
            err2=abs(numeric-independent)/max(numeric,1e-100)
            assert err<5e-12 and err2<5e-12
            checks.append(dict(n=n,m=m,trial=trial,explicit_N=m**n,M_exact=str(M),energy=numeric,decimal80_relative_error=err,independent_difference_relative_error=err2))
    for n,m in ((1,256),(2,256),(4,128),(8,256)):
        x=tuple(rng.randrange(-D,D) for i in range(n)); events=tensor_events(x,n,m)
        a=event_energy(events,n,m); b=independent_midpoint_coeff(events,n,m)
        err=abs(a-b)/max(a,1e-100);assert err<1e-9
        checks.append(dict(n=n,m=m,explicit_N=None,energy=a,independent_difference_relative_error=err))
    # Ties: receiver origin gives exact equal coordinate-distance batching.
    for n in (1,2,4,8):
        events=tensor_events((0,)*n,n,2)
        assert events==[(D//4,2**n,2**n)]
        cap,M=exact_cap_and_max(events,n,2)
        assert M==2**n
        a=event_energy(events,n,2)
        target=C*(2**n)**2
        assert abs(a-target)/target<5e-15
        checks.append(dict(n=n,m=2,receiver='origin',M_exact=str(M),same_distance_batches=len(events),single_batch_energy_relative_error=abs(a-target)/target))
    for n in (1,2):
        events=tensor_events((-D//4,)*n,n,2)
        cap,M=exact_cap_and_max(events,n,2)
        assert M is None and not any(cap)
        checks.append(dict(n=n,m=2,receiver="source atom",M_exact="infinity",all_caps_rejected=True,capped_integrand=0))
    return checks

def probes():
    jobs=[(n,F(3,4),2048) for n in (1,2,4,8)] + [(n,F(1),2048) for n in (1,2,4,8)]
    allrows=[]; paired=[]
    for n,half,samples in jobs:
        seed=560000+100*n+int(half*100)
        rng=random.Random(seed)
        half_int=int(half*D)
        xs=[tuple(rng.randrange(-half_int,half_int) for i in range(n)) for j in range(samples)]
        volume=float(2*half)**n
        prior=None
        for m in (2,8,32,128,256):
            arrays=[[] for H in CAPS]; bandarrays=[[] for H in CAPS]; bandnonzero=[0]*len(CAPS); accepted=[0]*len(CAPS); max_events=0; midpoint_error=0.
            for j,x in enumerate(xs):
                events=tensor_events(x,n,m); max_events=max(max_events,len(events))
                keeps,M=exact_cap_and_max(events,n,m)
                energy,bandenergy=event_energy(events,n,m,with_band=True) if M is not None else (0.,0.)
                assert bandenergy<=energy*(1+1e-10)
                if j<3 and M is not None:
                    independent=independent_midpoint_coeff(events,n,m)
                    err=abs(energy-independent)/max(energy,1e-100)
                    midpoint_error=max(midpoint_error,err);assert err<2e-9
                for k,H in enumerate(CAPS):
                    arrays[k].append(energy/float(H) if keeps[k] else 0.)
                    accepted[k]+=int(keeps[k])
                    bandarrays[k].append(bandenergy/.25 if keeps[k] else 0.)
                    bandnonzero[k]+=int(keeps[k] and bandenergy>0)
            for k,H in enumerate(CAPS):
                row=dict(n=n,m=m,N=str(m**n),source_entropy=n*math.log(m),source_mass=1,H=str(H),halfwidth=str(half),box_volume=volume,receiver_samples=samples,receiver_seed=seed,accepted=accepted[k],maximum_positive_mass_events=max_events,independent_max_relative_error=midpoint_error,fullspace_entropy_bound=2*C*(1+n*math.log(m)),**stats(arrays[k],volume))
                bs=stats(bandarrays[k],volume)
                row.update(band_lambda="1/4",bandcap_over_lambda_estimate=bs["estimate"],bandcap_over_lambda_sample_standard_error=bs["sample_standard_error"],band_nonzero_receivers=bandnonzero[k])
                allrows.append(row)
                if prior:
                    pm,pa=prior
                    paired.append(dict(n=n,halfwidth=str(half),H=str(H),m_from=pm,m_to=m,**stats([a-b for a,b in zip(arrays[k],pa[k])],volume)))
            prior=(m,arrays)
            print('done',n,str(half),m,'N',m**n,'H1',stats(arrays[1],volume),flush=True)
    return allrows,paired

def gate_intersections(N,precision):
    with localcontext() as ctx:
        ctx.prec=precision; e=Decimal(1).exp(); R=Decimal(N)/(8*e)
        left=Decimal(1); right=R; quarter=Decimal(1)/4
        intervals=[]; lengths=[]
        for k in range(1,int(R)+1):
            gleft=max(left,Decimal(k)+quarter); gright=min(right,Decimal(k)+3*quarter)
            if gright<=gleft:continue
            witness=[]
            for l in range(int(e*gleft)-1,int(e*gright)+2):
                for bleft,bright in ((Decimal(l),Decimal(l)+quarter),(Decimal(l)+3*quarter,Decimal(l)+1)):
                    a=max(gleft,bleft/e); b=min(gright,bright/e)
                    if b>a:witness.append((a,b))
            intervals.extend(witness)
            if gright==Decimal(k)+3*quarter:
                length=sum((b-a for a,b in witness),Decimal(0)); lengths.append(length)
                assert length>=1/(2*e)-Decimal(10)**(-precision+10)
        logs=sum(((b/a).ln() for a,b in intervals),Decimal(0))
        bulk=(N//2)-((N+2)//3)+1
        normalized=Decimal(bulk)/N*logs/2
        K=int(R-3*quarter)
        harmonic=Decimal(bulk)/(4*e*N)*sum((1/(Decimal(k)+3*quarter) for k in range(1,K+1)),Decimal(0))
        loglower=Decimal(bulk)/(4*e*N)*((Decimal(K)+Decimal('1.75'))/Decimal('1.75')).ln()
        assert normalized>=harmonic>=loglower
        return dict(N=N,W=N,H=2,lambda_exact='1/8',bulk_source_min=(N+2)//3,bulk_source_max=N//2,bulk_source_count=bulk,r_min=1,r_max_decimal=str(R),intersection_count=len(intervals),complete_good_intervals=K,minimum_complete_interval_witness_length=str(min(lengths)),per_unit_interval_length_lower=str(1/(2*e)),normalized_gate_positive_witness=str(normalized),normalized_harmonic_lower=str(harmonic),normalized_log_lower=str(loglower),precision=precision),intervals

def float_gate_integral(N):
    e=math.e;R=N/(8*e);pieces=[]
    for k in range(1,int(R)+1):
        gl=k+.25;gr=min(R,k+.75)
        if gr<=gl:continue
        for l in range(int(e*gl)-1,int(e*gr)+2):
            for a,b in ((l/e,(l+.25)/e),((l+.75)/e,(l+1)/e)):
                left=max(gl,a);right=min(gr,b)
                if right>left:pieces.append(math.log(right/left))
    bulk=N//2-(N+2)//3+1
    return bulk/N*math.fsum(pieces)/2

def lattice_B_and_M(N,x,r):
    # Actual finite source, no proxy; B is the sliding unit-u average of a.
    values=[];q=Q;c=C;z=1/(2*r)
    Bparts=[]
    for j in range(N):
        v=2*abs(x-j);assert v>0
        values.append(v)
        if v<=2*r:Bparts.append(c*z)
        elif v<=2*math.e*r:Bparts.append(1/v-q*z)
    values.sort();M=max((k+1)/v for k,v in enumerate(values))
    return math.fsum(Bparts),M

def gate_guards():
    rows=[]; saturation=[]
    for N in (256,1024,4096,16384):
        coarse,intervals=gate_intersections(N,80);fine,_=gate_intersections(N,120)
        a=Decimal(coarse['normalized_gate_positive_witness']);b=Decimal(fine['normalized_gate_positive_witness'])
        err=abs(a-b)/b;assert err<Decimal('1e-65')
        f=float_gate_integral(N);ferr=abs(f-float(b))/float(b);assert ferr<1e-10
        fine.update(decimal80_vs120_relative_error=str(err),independent_float_relative_error=ferr)
        rows.append(fine)
        chosen=[intervals[t] for t in (0,len(intervals)//2,len(intervals)-1)]
        for aa,bb in chosen:
            r=float((aa+bb)/2)
            for i in ((N+2)//3,(N+2)//3+(N//2-(N+2)//3)//2,N//2):
                B,M=lattice_B_and_M(N,i+r,r)
                shiftedB,shiftedM=lattice_B_and_M(N,i+math.e*r,r)
                assert B>=.5 and shiftedB>=.5 and M<=2+1e-10 and shiftedM>2
                saturation.append(dict(N=N,i=i,r=r,receiver_B=B,shifted_B=shiftedB,receiver_M=M,shifted_M=shiftedM,psi_receiver='1/8',psi_shifted='1/8',signed_translation_difference=0))
    return dict(definition='Unit mass per integer site, mu_N=sum_(j=0)^(N-1) delta_j, W=N,H=2,lambda=1/8; selected bulk i and r in[1,N/(8e)]. Gate-positive integrand lambda/(2r) on r mod1 in[1/4,3/4] and (er)mod1 outside that interval.',normalization='gate-positive witness / (lambda W) = (bulk_count/N)/2 times exact sum log(b/a) over intersections; endpoints are rational or rational/e. Decimal values only evaluate this finite log sum.',interpretation='Numerical guard for logarithmic gate-positive-loss obstruction. Not an energy-growth or weak-type counterexample; the actual psi translation difference is zero at saturation guards. Saturation is analytically justified separately, these checks are finite guards.',arithmetic='Decimal exp/log at80 and120digits and independent float intersections; no outward rounding certificate.',rows=rows,saturation_guards=saturation)

def microenergy_values(m,precision):
    with localcontext() as ctx:
        ctx.prec=precision;e=Decimal(1).exp();q=1/e
        factor=1-q*q
        limit=3*factor
        lower=(1-Decimal(2)/m)*limit
        uniform_upper=(e-q)/2
        pointvalues={str(r):str(factor/(8*(Decimal(r.numerator)/Decimal(r.denominator))**2)) for r in (F(1,16),F(1,8),F(1,4))}
        return dict(m=m,H=8,microenergy_lower=str(lower),limiting_lower=str(limit),continuous_uniform_energy_upper=str(uniform_upper),gap_lower_minus_uniform_upper=str(lower-uniform_upper),r_point_contributions=pointvalues,precision=precision)

def microenergy_guards():
    rows=[];checks=[]
    for m in (8,32,128,256):
        coarse=microenergy_values(m,80);fine=microenergy_values(m,120)
        relative=abs(Decimal(coarse['microenergy_lower'])-Decimal(fine['microenergy_lower']))/Decimal(fine['microenergy_lower'])
        assert relative<Decimal('1e-70')
        fine['decimal80_vs120_lower_relative_error']=str(relative)
        assert Decimal(fine['microenergy_lower'])>Decimal(fine['continuous_uniform_energy_upper'])
        rows.append(fine)
        source=[F(2*j+1-m,2*m) for j in range(m)]
        for i in range(1,m-1):
            for sign in (-1,1):
                for r in (F(1,16),F(1,8),F(1,4)):
                    x=source[i]+sign*r/m
                    volumes=sorted(2*abs(x-y) for y in source)
                    assert volumes[0]==2*r/m
                    assert volumes[1]==2*(1-r)/m
                    M=max(F(k+1,m)/v for k,v in enumerate(volumes))
                    assert M==1/(2*r) and M<=8
                    with localcontext() as ctx:
                        ctx.prec=120;e=Decimal(1).exp();q=1/e
                        rd=Decimal(r.numerator)/Decimal(r.denominator)
                        v=Decimal(volumes[0].numerator)/Decimal(volumes[0].denominator)
                        nextv=Decimal(volumes[1].numerator)/Decimal(volumes[1].denominator)
                        assert e*v<nextv
                        # Actual event coefficient -q/m, on z in[1/v,e/v].
                        actual=(q/Decimal(m))**2*((e/v)**2-(1/v)**2)/2
                        formula=(1-q*q)/(8*rd*rd)
                        relative=abs(actual-formula)/formula
                        assert relative<Decimal('1e-110')
                        gap=nextv-e*v
                    checks.append(dict(m=m,i=i,side=sign,r=str(r),receiver_exact=str(x),M_exact=str(M),first_volume_exact=str(volumes[0]),next_volume_exact=str(volumes[1]),first_rising_forward_window_gap=str(gap),rising_interval_energy=str(actual),formula_relative_error=str(relative)))
    return dict(definition='n=1 midpoint uniform atomic source of mass1. H=8. For every interior atom yi, x=yi +/- r/m, r in[1/16,1/4], the first atom contributes on u in[log(2r/m)-1,log(2r/m)].',analytic_lower='Both receiver sides and all m-2 interior atoms give Ecap>= (1-2/m)*3*(1-exp(-2)); each rising interval contributes (1-exp(-2))/(8*r^2). The finite numerical checks use r=1/16,1/8,1/4; the whole-r interval and uniform-density upper are analytic arguments supplied separately.',continuous_uniform_comparison='Uniform density on[-1/2,1/2] has Ecap=E for H8 since M<=1. Its analytic upper C1=(e-exp(-1))/2<1.5 is compared with the atom microenergy lower tending3(1-exp(-2))>2.5.',interpretation='Capped-energy noncontinuity under weak convergence of midpoint atomic grids to uniform density; does not disprove a source-independent upper or the weak-type target.',arithmetic='Exact Fraction source distances and actual-source M at all selected points; Decimal120 actual first-event integration and Decimal80/120 lower comparisons. Numerical precision guards, not outward-rounded certificates.',rows=rows,actual_source_event_check_count=len(checks),maximum_event_formula_relative_error=str(max(Decimal(t['formula_relative_error']) for t in checks)),actual_source_event_checks=[t for t in checks if t['i'] in (1,t['m']//2,t['m']-2)])

def main():
    start=time.monotonic(); checks=crosschecks(); rows,paired=probes(); gates=gate_guards(); micro=microenergy_guards()
    result=dict(round=56,status='PASS',counts=dict(tensor_source_box_jobs=40,tensor_receiver_event_integrations=81920,tensor_cap_summary_rows=len(rows),tensor_arithmetic_guards=len(checks),gate_intersection_cases=len(gates['rows']),finite_lattice_saturation_guards=len(gates['saturation_guards']),microenergy_parameter_cases=len(micro['rows']),microenergy_actual_source_event_checks=micro['actual_source_event_check_count']),scope='Finite receiver boxes and dyadic-grid iid sampling; full scale event integration; arithmetic guards only, no outward-rounded energy certificate, no omitted-tail control, no fullspace bound, no source-independent theorem.',source_definition='Uniform atomic measure on Cartesian product of m midpoint sites (2j+1-m)/(2m), each atom weight m^-n; mass one. All m powers of two.',energy_definition='Integral over sampled receiver box with M_mu(x)<=H, then all real u of |a_x(u+1)-a_x(u)|^2, a_x(u)=exp(-u) mu(Q(x,exp(u/n))) with Q full side length.',cap_definition='M at exact dyadic integer-radius equal-distance batches; cumulative mass product of coordinate counts; integer/Fraction comparison with H.',sampling='Independent integer coordinates uniformly sampled from [-halfwidth*2^24, halfwidth*2^24); same receiver points across m provide paired comparisons. SE describes iid sampling variation on this finite dyadic grid, not spatial bias or omitted box tails.',source_count_axis='m varied at each fixed n; N=m^n and entropy=n log m separately reported. No exponent fits.',microenergy_noncontinuity=micro,gate_positive_loss=gates,crosschecks=checks,rows=rows,paired_differences=paired)
    out=Path(__file__).with_name('results.json');out.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print('PASS',len(rows),'rows',len(checks),'guards','seconds',time.monotonic()-start)

if __name__=='__main__':main()
