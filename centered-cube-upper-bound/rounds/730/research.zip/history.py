"""Exact coordinate slice widths on a compressed original first-hit family."""
import json, sys, platform, math
from fractions import Fraction as F
from flint import arb, ctx, __version__ as flint_version
ctx.prec=256
def ball(r): return arb(r.numerator)/r.denominator
def example(n, k, pinched):
    a=32*n
    eta=F(1,a*a) if pinched else F(1,8)
    u=(1+F(1,a))/16
    x=F(3,50)
    sizes=[F(3),F(2),F(3,2),F(1)]
    log_room=arb(0)
    for marked, count in [(True,k),(False,n-k)]:
        for sign in [-1,1]:
            # Each block of selected coordinates has equally many signs.
            centers=[3-eta if marked else 0,-2+eta if marked else 0,0,-sign*F(63,64)]
            I=[(y-s,y+s) for y,s in zip(centers,sizes)]
            assert all(l<0<h for l,h in I)
            width=(min(h for l,h in I)-max(l for l,h in I))/2
            assert width==(min(eta,F(1,64))+eta)/2 if marked else width==F(97,128)
            assert (width<=F(1,n))==(marked and pinched)
            assert min((min(I[i][1],I[j][1])-max(I[i][0],I[j][0])) for i in (0,1) for j in (2,3))>=F(1,64)
            log_room+=count//2*ball(width+u).log()
            # Constant choices on the first three parents; last has opposing signs.
            for j,shift in enumerate([1,-1,0]):
                assert I[j][0]<=sign*x-F(1,16*a)+shift*u and sign*x+F(1,16*a)+shift*u<=I[j][1]
            assert x-F(1,16*a)+F(63,64)>1+F(6,n)
            assert x+F(1,16*a)+F(63,64)-u<1
    K=4096*math.isqrt(n)*a**n
    ell=arb(2).log()/K
    vt=arb(1)/(8*a)**n
    high=vt*ell.expm1()/2
    assert high>0 and high<vt/4
    # Largest baseline source; the sum of all baseline terms is <= 2 times this.
    log_largest=n*arb(32*n).log()+(K-5)*n*arb(4).log()+(-(-ell).expm1()).log()
    assert log_largest>(4*arb(6)**n+1).log()
    return dict(n=n,k=k,marked_width=str((min(eta,F(1,64))+eta)/2),eta=str(eta),r_thick='97/128',log_room_over_root=str(log_room),
                log_ratio_to_unscaled_R729_endpoint_floor=str(log_room+3*n*arb(2).log()),
                high=str(high),V_T=str(vt),D_log_div_K_bounds=[str(log_largest/K),str((log_largest+arb(3).log())/K)],
                excess_ratio_at_owner_allowance_quarter='0')
def account(n):
    # Uniform rational bounds lambda<=1+1/n, outer<=1+2/n, inner>=1-1/n.
    # At eps=1/n, H_plus(0)-H_minus(eps) <= 64/n for n>=32 (see report).
    # Use k upper bound 2n/log n+2, lower 2n/log n, binomial <= (en/k)^k.
    N=arb(n); l=N.log(); k=2*N/l
    U=5*(1+2/N)**3
    logB=k*(1+(N/k).log())+(k*(arb(128)/N).log())+N*U.log()
    return dict(n=str(n),log_upper_per_axis=(logB/N).str(22))
def profile(n, ratios, center):
    # Rational OUTER shell rounding; lambda <= 1+1/n.
    q=[F(1,j) for j in ratios]
    def tail(u,scale):
        if min(F(1), *(scale*j for j in ratios))<=u:return F(0)
        a=[scale-u*t for t in q]
        return math.prod(a)+(1-u)*sum(q[i]*math.prod(a[:i]+a[i+1:]) for i in range(3))
    plus=1+F(2,n); minus=1-F(1,n); w=F(2,n)
    bin_weight=(1+center+w)*(tail(center,plus)-tail(center+w,minus))
    bulk=tail(0,plus)+plus**3
    assert 0<bin_weight<=F(128,n) and bulk<=5*plus**3
    # Exact unblurred integral on (l,b] from the tail and its polynomial primitive.
    def primitive(u):
        return (1-u)*math.prod(1-u*t for t in q)
    def weighted_bin(l,b):
        return (1+l)*tail(l,F(1))-(1+b)*tail(b,F(1))+primitive(l)-primitive(b)
    exact=weighted_bin(center,center+w)
    assert 0<=exact<=bin_weight
    cuts=[F(0),F(1,8),F(3,4),1-F(1,n),F(1)]
    actual=[weighted_bin(l,b) for l,b in zip(cuts,cuts[1:])]
    env=[(1+b)*(tail(l,plus)-tail(b,minus)) for l,b in zip(cuts,cuts[1:])]
    assert sum(actual)==2+sum(q) and all(F(0)<=x<=y for x,y in zip(actual,env))
    # Fixed-shell finite bill for a single window touching the true common width.
    k=2*math.ceil(n/math.log(n))
    bill=math.comb(n,k)*bin_weight**k*bulk**(n-k)
    return dict(n=n,side_ratios=ratios,left=str(center),k=k,window_weight=str(bin_weight),
                exact_weight=str(exact),last_bin_actual=str(actual[-1]),last_bin_envelope=str(env[-1]),full_weight=str(bulk),log_upper_per_axis=(ball(bill).log()/n).str(16))
data={'python':sys.executable,'version':platform.python_version(),'python_flint':flint_version,'prec':256,
      'history':[example(n,2*math.ceil(n/math.log(n)),flag) for n in (256,1024,4096) for flag in (True,False)],
      'single_window':[profile(n,e,u) for n in (256,1024,4096) for e in ((1,1,1),(2,4,8),(1,3,64)) for u in (F(0),F(1,8),F(3,4),1-F(4,n))],
      'bounds':[account(2**k) for k in (10,20,40,80,160,320,640,1280)]}
print(json.dumps(data,indent=2))
