#!/usr/bin/env python3
"""Bounded exact slice/cap and four-interval translation-volume audit."""
from fractions import Fraction as F
from decimal import Decimal as D,localcontext
from itertools import combinations,product
from math import comb,atan2,ceil
from pathlib import Path
import hashlib,json,platform,socket,subprocess,sys
sys.set_int_max_str_digits(1000000)
BASE=Path(__file__).resolve().parent
DIMS=(4,16,64,256,1024,4096,65536)

def rv(v,R,s):return max(F(0),min(F(1),(R+s-abs(v))/(2*s)))
def slice_integral(S,s,low=F(0)):
    hi=S+s
    if low>=hi:return F(0)
    knots=sorted({low,hi}|{p for p in (S-s,) if low<p<hi})
    return 2*sum(((b-a)*(2+rv(a,S,s)+rv(b,S,s))/2 for a,b in zip(knots,knots[1:])),F(0))
def exact_slices():
    rows=[]
    for n in (4,16,64,256):
        a=32*n;lam=1+F(1,n) # exact rational upper lambda, because(1+1/n)^n>=2
        h0=1+F(1,a);sigma=lam/a;S=h0*lam+sigma;c=S-1
        assert c==lam-1+2*lam/a and lam**n>=2
        zs=[F(1),F(63,64),F(1,2),F(1,n),F(1,16*n),2*c/3]
        for z in zs:
            full=slice_integral(S,z)/2;assert full==2*S+z
            # Check true original-radius thin set, not an unrestricted proxy-level cap.
            for A in (F(1),lam):
                q=F(1,4)+(S-A)/(2*z);cut=A+z/2
                cap=slice_integral(S,z,cut)/2
                ghost=slice_integral(S,z,A+z)/2
                positive_cap=cap-ghost
                assert 0<=positive_cap<=cap and positive_cap<=z
                formula=z*(2*q+q*q) if q<=1 else z*(4*q-1)
                assert cap==formula and cap<=full
                bound_old=z*F(9,16) # c=0 thin q1/4
                point_checks=[]
                for v in sorted({F(0),cut,S-z,S+z}|{(S+z)*F(i,8) for i in range(9)}):
                    env=max(rv(v-sigma,h0*lam,z),rv(v+sigma,h0*lam,z),rv(F(0),h0*lam,z) if abs(v)<=sigma else F(0))
                    assert env==rv(v,S,z)
                    assert rv(v,A,z)<=env
                    point_checks.append({'v':str(v),'actual_r':str(rv(v,A,z)),'proxy_owner_envelope_r':str(env)})
                tail=sum((comb(n,k)*cap**k*(full-cap)**(n-k) for k in range((9*n+9)//10,n+1)),F(0))
                rows.append({'n':n,'z':str(z),'actual_radius_over_R':str(A),'lambda_rational_upper':str(lam),
                             'a':a,'h0':str(h0),'owner_drift_over_R':str(sigma),'effective_proxy_radius_over_R':str(S),'c_upper':str(c),
                             'q_proxy_at_actual_thin_cutoff':str(q),'platform_branch':bool(q>1),
                             'full_normalized_slice_exact':str(full),'outer_actual_thin_proxy_slice_exact':str(cap),
                             'actual_positive_overlap_thin_slice_exact':str(positive_cap),
                             'new_proxy_only_overlap_slice_exact':str(ghost),
                             'zero_margin_edge_cap_exact':str(bound_old),'proxy_edge_formula_extended_invalid_exact':str(z*(2*q+q*q)),
                             'point_checks':point_checks,'binary_90pct_tail_power_exact':str(tail),
                             'ninety_percent_count':(9*n+9)//10})
    # r_proxy<=1 includes a whole positive-length platform; edge formula misses it.
    z=F(1,2);S=F(1);edge_limit=3*z;full=2*S+z
    return {'rows':rows,'proxy_level_one_platform_control':{
        'small_radius':str(z),'large_radius':str(S),'edge_cap_limit_as_q_up_to_one':str(edge_limit),
        'cap_at_q_equals_one_including_platform':str(full),'missed_platform_mass':str(full-edge_limit),
        'edge_formula_invalid_at_q_one':True}}

def det3(M):return M[0][0]*(M[1][1]*M[2][2]-M[1][2]*M[2][1])-M[0][1]*(M[1][0]*M[2][2]-M[1][2]*M[2][0])+M[0][2]*(M[1][0]*M[2][1]-M[1][1]*M[2][0])
def solve3(M,b):
    d=det3(M)
    if not d:return None
    return tuple(det3([[b[r] if c==j else M[r][c] for c in range(3)] for r in range(3)])/d for j in range(3))
def dot(a,b):return sum((x*y for x,y in zip(a,b)),F(0))
def sub(a,b):return tuple(x-y for x,y in zip(a,b))
def poly_volume(e,u):
    # L>=u iff shortened intervals[t_i,t_i+e_i-u] meet root[0,1-u].
    constraints=[]
    for i in range(3):
        normal=[F(0)]*3;normal[i]=1;constraints.append((tuple(normal),1-u))
        normal=[F(0)]*3;normal[i]=-1;constraints.append((tuple(normal),e[i]-u))
    for i in range(3):
        for j in range(3):
            if i==j:continue
            normal=[F(0)]*3;normal[i]=1;normal[j]=-1;constraints.append((tuple(normal),e[j]-u))
    vertices=set()
    for ids in combinations(range(len(constraints)),3):
        v=solve3([constraints[i][0] for i in ids],[constraints[i][1] for i in ids])
        if v is not None and all(dot(a,v)<=b for a,b in constraints):vertices.add(v)
    vertices=sorted(vertices);assert len(vertices)>=4
    center=tuple(sum((v[j] for v in vertices),F(0))/len(vertices) for j in range(3))
    faces={};volume=F(0)
    for normal,bound in constraints:
        face=tuple(i for i,v in enumerate(vertices) if dot(normal,v)==bound)
        if len(face)<3 or face in faces:continue
        axis=max(range(3),key=lambda j:abs(normal[j]));proj=[j for j in range(3) if j!=axis]
        fc=tuple(sum((vertices[i][j] for i in face),F(0))/len(face) for j in range(3))
        order=sorted(face,key=lambda i:atan2(float(vertices[i][proj[1]]-fc[proj[1]]),float(vertices[i][proj[0]]-fc[proj[0]])))
        # Verify convex cyclic order using exact rational cross products; float is only a proposed permutation.
        orientation=None
        for ii in range(len(order)):
            a=vertices[order[ii]];b=vertices[order[(ii+1)%len(order)]]
            for jj in order:
                p=vertices[jj]
                cross=(b[proj[0]]-a[proj[0]])*(p[proj[1]]-a[proj[1]])-(b[proj[1]]-a[proj[1]])*(p[proj[0]]-a[proj[0]])
                if cross:
                    sign=1 if cross>0 else -1
                    if orientation is None:orientation=sign
                    assert sign==orientation
        if orientation is None:continue
        faces[face]=True
        for ii in range(len(order)):
            a=vertices[order[ii]];b=vertices[order[(ii+1)%len(order)]]
            volume+=abs(det3([sub(fc,center),sub(a,center),sub(b,center)]))/6
    for v in vertices:
        length=min([F(1)]+[v[i]+e[i] for i in range(3)])-max([F(0)]+list(v))
        assert length>=u
    return volume,vertices,len(faces)

def four_data(geometric=False,certificates=None):
    rows=[]
    for e in ((F(1),F(1),F(1)),(F(1),F(3,2),F(2)),(F(5,4),F(3),F(4))):
        denom=e[0]*e[1]*e[2]
        # Polynomial P(u)=(1-u)product(1-u/e_i), H=-Pprime.
        coeff=[F(1)]
        for length in (F(1),)+e:
            new=[F(0)]*(len(coeff)+1)
            for j,v in enumerate(coeff):new[j]+=v;new[j+1]-=v/length
            coeff=new
        for u in (F(1,8),F(1,2),F(7,8)):
            H=-sum((j*coeff[j]*u**(j-1) for j in range(1,len(coeff))),F(0))
            maxleft=__import__('functools').reduce(lambda x,y:x*y,(v-u for v in e),F(1))+(1-u)*sum(((e[(i+1)%3]-u)*(e[(i+2)%3]-u) for i in range(3)),F(0))
            assert H==maxleft/denom
            volume,vertices,faces=poly_volume(e,u) if geometric else (maxleft,None,None)
            assert volume==maxleft
            if geometric and certificates is not None:
                certificates.append({'e':[str(x) for x in e],'u':str(u),'volume':str(volume),
                                     'vertices':[[str(x) for x in v] for v in vertices],'faces':faces})
            rows.append({'e':[str(x) for x in e],'u':str(u),'H_derivative_exact':str(H),
                         'translation_volume_exact':str(volume),'normalized_translation_volume_exact':str(volume/denom)})
        at0=1+sum((1/v for v in e),F(0));atom=__import__('functools').reduce(lambda x,y:x*y,(1-1/v for v in e),F(1))
        rows.append({'e':[str(x) for x in e],'cutoff_record':True,'H_at_zero_right':str(at0),
                     'H_at_one_left_and_exact':str(atom),'H_above_one':'0','plateau_atom_at_common_length_one':str(atom),
                     'H_is_normalized_volume_not_probability':True})
    return rows

def decimal_tails():
    out=[]
    with localcontext() as ctx:
        ctx.prec=110
        for n in DIMS:
            lam=(D(2).ln()/n).exp();c=lam-1+2*lam/(32*n)
            for zf in (F(1),F(63,64),F(1,2),F(1,n),F(1,16*n)):
                z=D(zf.numerator)/zf.denominator;full=2*(1+c)+z;q=D(1)/4+c/(2*z)
                cap=z*(2*q+q*q) if q<=1 else z*(4*q-1)
                k=(9*n+9)//10
                logterm=D(comb(n,k)).ln()+k*cap.ln()+(n-k)*(full-cap).ln()
                rel=D(1);total=D(1)
                for j in range(k,n):
                    rel*=D(n-j)/(j+1)*cap/(full-cap);total+=rel
                out.append({'n':n,'z':str(zf),'log_tail':str(logterm+total.ln())})
    return out

if '--remote' in sys.argv:
    d={'slices':exact_slices(),'four_intervals':four_data(False)}
    print(json.dumps({'host':socket.gethostname(),'python':platform.python_version(),
                      'exact_digest':hashlib.sha256(json.dumps(d,sort_keys=True,separators=(',',':')).encode()).hexdigest(),
                      'method':'closed-form maximum-left-endpoint integration for four intervals','actual_lambda_decimal110_tails':decimal_tails()}));sys.exit(0)

from flint import arb,ctx

def st(v):return v.str(36)
def tail_arb(n,T,FULL):
    k=(9*n+9)//10
    logterm=arb(comb(n,k)).log()+k*T.log()+(n-k)*(FULL-T).log()
    rel=arb(1);total=arb(1)
    for j in range(k,n):
        rel*=arb(n-j)/(j+1)*T/(FULL-T);total+=rel
    return logterm+total.log()
def arb_data():
    rows=[]
    for n in DIMS:
        for zf in (F(1),F(63,64),F(1,2),F(1,n),F(1,16*n)):
            precisions=[]
            for bits in (256,384):
                ctx.prec=bits;z=arb(zf.numerator)/zf.denominator;lam=(arb(2).log()/n).exp();a=32*n;c=lam-1+2*lam/a;S=1+c
                full=2*S+z;q=arb(1)/4+c/(2*z)
                assert q<1 or q>1
                cap=z*(2*q+q*q) if q<1 else z*(4*q-1)
                assert 0<cap<full
                p=cap/full;alpha=arb(9)/10
                chernoff=-(alpha*(alpha/p).log()+(1-alpha)*((1-alpha)/(1-p)).log())*n+full.log()*n
                actual=tail_arb(n,cap,full);assert actual<=chernoff
                precisions.append(actual)
            assert precisions[0].overlaps(precisions[1])
            rows.append({'n':n,'z_exact':str(zf),'lambda':st(lam),'c_n':st(c),'proxy_thin_level':st(q),
                         'platform_branch':bool(q>1),'full_slice':st(full),'thin_slice':st(cap),
                         'thin_fraction_under_full_slice':st(p),'log_binary_90pct_tail_power':st(actual),
                         'log_chernoff_90pct_power_bound':st(chernoff),'tail_power_below_one':bool(actual<0),
                         'precisions':[256,384]})
    # n->infinity,z=1: c->0,full3,thin9/16.
    ctx.prec=384;alpha=arb(9)/10;T=arb(9)/16;rest=3-T
    rate=-alpha*alpha.log()-(1-alpha)*(1-alpha).log()+alpha*T.log()+(1-alpha)*rest.log()
    assert rate<0
    first=None
    for nn in range(1,65):
        cc=(arb(2).log()/nn).exp()*(1+arb(1)/(16*nn))-1
        tt=arb(9)/16+5*cc/4+cc*cc/4;ff=3+2*cc
        rr=-alpha*alpha.log()-(1-alpha)*(1-alpha).log()+alpha*tt.log()+(1-alpha)*(ff-tt).log()
        assert rr<0 or rr>0
        if rr<0:first=nn;first_rate=rr;break
    assert first is not None
    return {'rows':rows,'limiting_n_log_tail_rate_at_z_one':st(rate),
            'uniform_z_tail_envelope_certificate':{
                'first_passing_integer_n_for_chernoff_rate':first,'rate_at_first':st(first_rate),
                'algebra':'For A=1, T(z)=2c on0<z<=2c/3 and9z/16+5c/4+c²/(4z) otherwise. BothT(z)andF(z)-T(z)are nondecreasing inz; Tprime=9/16-c²/(4z²)>=0 in the edge branch,while(F-T)prime=7/16+c²/(4z²)>0. Thus every binomial term is largest atz1. Both factors also increase inc, andc_n=2^(1/n)(1+1/(16n))-1 decreases inn. The negative Chernoff rate therefore persists for every integern at least the recorded threshold and everyz in(0,1].'}}

def main():
    polycerts=[]
    exact={'slices':exact_slices(),'four_intervals':four_data(True,polycerts)}
    digest=hashlib.sha256(json.dumps(exact,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    approx=arb_data()
    cmd=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=5','macbook-math','/Users/zhengzhihao/.venv/bin/python -B - --remote']
    try:
        run=subprocess.run(cmd,input=Path(__file__).read_text(),text=True,capture_output=True,timeout=45)
        remote={'command':cmd,'exit_code':run.returncode,'stderr':run.stderr}
        if run.returncode==0:
            remote['result']=json.loads(run.stdout);assert remote['result']['exact_digest']==digest;remote['all_exact_data_match']=True
            independent=remote['result']['actual_lambda_decimal110_tails']
            assert len(independent)==len(approx['rows'])
            for aa,bb in zip(approx['rows'],independent):
                assert (aa['n'],aa['z_exact'])==(bb['n'],bb['z'])
                x=float(aa['log_binary_90pct_tail_power'].split(' +/-')[0].lstrip('['));y=float(bb['log_tail'])
                assert abs(x-y)<=max(1e-12,abs(x)*1e-12)
            remote['actual_lambda_arb_decimal_crosscheck']=True
    except subprocess.TimeoutExpired:remote={'command':cmd,'timeout_seconds':45}
    result={'host':socket.gethostname(),'python':sys.executable,'python_version':platform.python_version(),
            'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'exact_data_digest':digest,
            **exact,'four_interval_polytope_certificates':polycerts,'arb':approx,'remote':remote,
            'definitions':['NormalizeR=1,smallh=[-z,z],actual large interval[v-A,v+A],A in[1,lambda],r_A=intersection length/(2z). a=32n,h0=1+1/a,proxy radiush0lambda and owner center drift<=lambda/a.',
                           'The true proxy envelope isr_S(v) withS=h0lambda+lambda/a=1+c_n,c_n=lambda-1+2lambda/a. Integral over its overlap of(1+r_S),normalized by2R,isF=2S+z.',
                           'Restricting the actual source tor_A<=1/4 means|v|>=A+z/2. The proxy-supported outer cap includes actualr_A=0 points, and an additional exact field subtracts this ghost support to record the actual-positive-overlap thin integral. Its outer cap hasQ=1/4+(S-A)/(2z):T=z(2Q+Q²) forQ<=1,T=z(4Q-1) forQ>=1. This is not the same as an unrestricted proxy-level cutoffr_S<=Q.',
                           'For a proxy-level cutoff0<Q<1,the edge-only integral isz(2Q+Q²); atQ>=1 the whole positive-volume plateau must be included and the answer isF. The exact boundary control records the jump.',
                           'The binary90%tail is sum_{j>=ceil(.9n)}binom(n,j)T^j(F-T)^(n-j)=F^n P(Bin(n,T/F)>=ceil(.9n)). This is a finite tensor model, not a history theorem.',
                           'For root interval[0,1]and other lengths e_i>=1,H(u)=translation volume{common length>=u}/producte_i=-d/du[(1-u)product(1-u/e_i)] for0<u<1. H(0+)can exceed1; it is not a probability until further normalized. Atu=1 an atomproduct(1-1/e_i) can remain; above1 the volume iszero.'],
            'scope':['Exact one-dimensional piecewise-linear integration, actual endpoint positions and pointwise owner-drift envelope checks. Rational upperlambda=1+1/n is used only for exact finite powers;n<=256. The actual lambda=2^(1/n) is separately computed with Arb256/384.',
                     'Four-interval translation volumes are independently computed locally by exact rational3Dpolytope vertices/facet tetrahedra, with exact convex-order verification. MacBook uses the maximum-left-endpoint integral formula. Both exact outputs agree.',
                     'Actual-lambda binary tails are computed atn4..65536 andz1,63/64,1/2,1/n,1/(16n). Exact binomial powers and true cutoff branches are retained, including failures at smalln.',
                     'No new chronological history is asserted. Onlynumerical.py/json are written; no Git, remote files,GPU use or background jobs.']}
    (BASE/'numerical.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'remote_exit':remote.get('exit_code'),'exact_match':remote.get('all_exact_data_match'),
                      'exact_slice_rows':len(exact['slices']['rows']),'actual_lambda_tail_rows':len(approx['rows']),
                      'limiting_rate':approx['limiting_n_log_tail_rate_at_z_one'],
                      'nondecaying_tail_rows':[(r['n'],r['z_exact']) for r in approx['rows'] if not r['tail_power_below_one']]},indent=2))
if __name__=='__main__':main()
