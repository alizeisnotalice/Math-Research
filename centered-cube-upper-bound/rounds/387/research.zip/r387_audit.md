# R387 independent audit — FINAL PASS

Scope: only this file; no author/repository changes. This screen was derived before reading the R387 author proof. Final author proofs, scripts, true-du example/result/notes and integrated main/ledger/readme have now been reviewed. PASS applies to the exact two-branch receipts and accounting below. General root closure is not established.

## 1. Frozen original field and exact measure

Fix the original full f, finite actual Lebesgue receiver field E, m_u=f(Q_u)=q_uR_u^n with q_-<=q_u<=lambda and positive radius bounds, the same source-exact plan and all original masks. Write rho_y(du)=c_u(y)du/m_u and closed CDF T_y(t)=rho_y{m_u<=t}. It is a finite measurable kernel. The original strict far gate m_u>K m_v with K>lambda/q_- implies R_v<R_u and m_v<m_u/K. On each active physical clock r>=R_u,

    J_y(r)>=Z_y(m_u/K-)>=T_y(m_v).

The second comparison is inclusive at m_v because that mass is strictly below m_u/K. No receiver qualification is transferred to v; these are sourcewise comparisons in the same original full field.

The actual positive marked source/receiver cost is dominated by

    ell(dr) f(y)dy c_u(y)c_v(y)(m_u-m_v)
       [du/m_u][dv/m_v]/J_y(r).

Residual plan, high-source, outside/dense/deep, history or fractional-payment marks are bounded by one and may be retained as positive restrictions. No product target/source assumption is needed for this upper domination.

## 2. Closed-rank capacity, including atoms

For fixed source y and small endpoint v set t=T_y(m_v). For any d>0,

    rho_y{u:m_u>m_v, T_y(m_u)<=(1+d)t}<=d t.

Indeed the mass range strictly above m_v starts after the entire closed rank t. The allowed endpoints have their entire RIGHT closed rank at most (1+d)t, so their occupied rank intervals lie in (t,(1+d)t]. An atom jumping across the upper bound is excluded rather than partially paid; an atom ending at the bound is included. This gives the whole-atom inequality without a crossing fee. Continuous and singular parts obey the same quantile-rank argument. The strict original far restriction is a subset of this allowed set.

For rho_y-almost every capturing v, T_y(m_v)>0. This follows from the usual rank pushforward or directly from the zero measure of {m:T_y(m)=0}. Such zero-rank source/small-endpoint pairs therefore have zero f(y)rho_y(dv)dy mass by Tonelli. Alternatively, if t=0, the displayed allowed-u occupation is zero, so that contribution may be set to zero without division. Original zero-J conventions are unchanged.

## 3. Original physical clock and genuine column payment

Use m_u-m_v<=m_u, and retain the original far/rank-close masks. Since J_y(r)>=t, integration of the complete physical clock tail, including b's terminal atom, yields

    integral_[R_u,b] ell(dr)/J_y(r)<=R_u^-n/t.

Consequently for fixed (y,v) of positive t the large-u column is bounded by

    integral_allowed c_u(y)du/[R_u^n t]
      <=lambda rho_y(allowed)/t
      <=lambda d.

The real exit measure is f(y)c_v(y)dv/m_v dy, not dv, not m_v dv, and not an uncharged source probability. Integrating it uses the actual SAME full-f matching:

    integral f(y)rho_y(dv)dy
      =integral_E [integral f(y)c_v(y)dy]/m_v dv
      =|E|.

Thus the original marked rank-close branch satisfies

    G_rankclose <=lambda d |E|
                <=lambda d X_q/q_-.

This is a genuine new receiver-budget subbranch with no source-W fee, valid for any d>0. To allocate epsilon X_q one may take d=epsilon q_-/lambda. There is no first-atom +1, no extra radius-bin factor, and no dependence on R386's regular rank condition. The statement applies directly to any same-field positive restriction, in particular the exact G_next.

## 4. Accounting and limitations to retain

The rank-close gate must split the actual current cost into this paid branch and its rank-separated complement, with all old masks/clock present. Its new hard-slot X_q coefficient is lambda d/q_- and its entrance coefficient is 2Lambda lambda d/q_-. If combined with the R386 route, this cost is removed from that route's exact G_next once; it is not a new independent estimate for reusing an already paid branch. Existing h, H, C, template and plan are not changed merely by introducing d.

The remaining branch has T_y(m_u)>(1+d)T_y(m_v), in addition to the actual prior constraints when starting from G_next. This is a closed-rank separation, not proof of a legal next transition, endpoint alpha/Y qualification, source disjointness, or a global root estimate. All inherited H-entry, soft/crossing, source/history/scale aggregation and limit obligations remain open. Final accounting and the additional author construction are reviewed below.

## 5. Actual bounded tool evidence

Reviewer actually ran 4096 Python Fraction closed-rank capacity cases, including zero weights, positive atoms, exact upper-endpoint equality and skipped crossing atoms. This verifies the bounded rank-measure inequality only, not a continuous native cube/history realization or the general estimate. It is separate from any later author/parent execution counts; no parent pipeline was repeated.

Result: PASS for the stated original-flow rank-close receipt and constants. Final integration is recorded below.


## 6. Author close-rank proof and checks: reviewed

After the independent screen, read r387_aux.md and r387_aux_check.py in full. The proof retains the correct source/exit measure, uses closed small-end rank inside the strict far past, and handles T_v=0 even more directly: its close-rank gate contradicts Z_u>h and Z_u<=T_u. Its atom-capacity and exact matching settlement agree with Sections 1--3. The proof does not use the R386 regular/small-past restrictions for the receipt, while retaining them in the actual current flow.

The script reports 19860 Fraction assertions, including 1066 nonempty atomic cases and 37 positive full-clock diagnostic cases. Source masses/cube intersections and q-band checks are actual finite constructions; RECEIVER integration is positive quadrature, not continuous du. The high-dimensional concentric cases include rational K values exceeding the original exponential value, as explicitly stated; not every diagnostic K is claimed to equal it. Exact continuous-clock interval weights include the terminal atom. The notes expressly do not certify all prior acceptance/history masks or a covered fraction. No full author pipeline was rerun by this reviewer.

## 7. Independent screen of the additional low-rank row receipt

For any tau>0, fix original (u,y) and retain strict far/past. The small-v subset with T_y(m_v)<=tau Z_u has actual rho_y occupation at most tau Z_u: this is the same whole-atom closed-CDF sublevel capacity, intersected with the original far gate. In the original layer the loss m_u-m_v<=m_u and J_y(r)>=Z_u, hence the selected layer row is at most tau m_u. The original strict Z_u>h excludes zero denominators. Integrating mu(du)=du/m_u, the full physical clock tail, and f(y)c_u(y)dy gives exactly at most

    tau integral_E m_u R_u^-n du=tau X_q.

This is a RECEIVER-budget receipt, not a source-W fee or a silently discarded source marginal. It is valid for any same-field positive restriction, so it may follow the close-rank removal without overlap or resampling. The new pair/source threshold does not change h, H, the target plan or matching.

On the exact remaining R386 flow, T_u<2Z_u persists. After the two removals T_v>tau Z_u and T_u>(1+d)T_v, and therefore

    tau/2<T_v/T_u<1/(1+d).

This is a same-source one-edge rank statement only. It is not a construction of future eligible traffic, and neither endpoint row density nor history qualification is inferred. If the ratio interval is empty for chosen parameters, the corresponding residual is empty, rather than requiring a new convention.

## 8. Unified parameter allocation: scope and bounded checks

If these allocations are made FROM THE ORIGINAL ENTRANCE before all synchronized quantities and masks are fixed, set

    eta=kappa/(12Lambda), sigma_n<=eta/2,
    epsilon383=kappa/(8Lambda),
    lambda d/q_-=kappa/(8Lambda), tau=kappa/(8Lambda).

Then 2Lambda(eta+sigma_n+epsilon383+lambda d/q_-+tau)<=kappa, with equality at the upper sigma bound. Thus the new two branches add precisely lambda d/q_-+tau to the hard-slot X coefficient, with no new W, template, h/t or square fee. The earlier eta allocation changes when using this new complete parameter version; its epsilon0/h and original gates must be recomputed consistently at the start. One may not reuse a fixed old field's numeric acceptance masks after silently replacing its h. For a field already fixed, the receipt is instead stated with the corresponding explicitly additional X coefficient.

Reviewer actually ran 6144 further Fraction atomic low-rank capacity cases, plus one exact scalar equality for this allocation. These are separate from the earlier 4096 bounded tests and from parent/author counts. No native continuum or general coverage conclusion is inferred. The low-rank author proof and final integrated files are now reviewed below.


## 9. Final low-rank author proof and numerical scope

Read r387_geometry.md and r387_geometry_check.py completely. Its closed-CDF sublevel lemma, whole-atom upper-bound convention and full-clock row cancellation agree with the independent proof in Section 7. The near then low branch order is a disjoint restriction of the same original positive cost. Its ratio bounds use R386 regularity only to describe the surviving support; neither receipt requires that regularity to obtain its price. Zero-J/positive-past conventions and the noninheritance of endpoint qualification are stated correctly.

The 7396 Fraction diagnostics include finite CDF atoms, exact finite matching and physical clock integration, and fixed-source ratio/path comparisons. The finite incidence systems are explicitly NOT claimed to be native cubes or octave/historical fields. The fixed-source path-depth statement is kept separate from source resampling and does not supply conservative flow or terminal payment. No complete parent script was rerun in this independent file review.

## 10. Independent native-center example audit

Read the complete n=16 continuum script and explanation, then checked its saved result and scope. The centers are actual side-eta boxes, not assigned quadrature weights: 2^16 sign-tile boxes with side-1/2 receiver cubes, one mid box centered at (.7,.25,...,.25) with side 3/4, and one big box centered at zero with side 1. Their disjointness, source support Q4 and packet D=[.47,.48]x[.10,.11]^15 are consistent with the analytic inequalities in the script.

All actual cubes lie inside Q4. Precisely the all-positive tile, mid family and big family contain the entire packet. Any other tile has a negative coordinate whose receiver-cube upper endpoint is below the packet. Thus the SAME full source gives m0=(3/4)2^-16, ms=m0+P, mv=(3/4)(3/4)^16+P, and mu=3/4+P, with q in[3/4,1]. The final high-source threshold is T=1+ceil(log2(18))=6, not the earlier n=4 threshold 4. The final code, note and saved result consistently use 6. Rational Taylor bounds 54<exp(4)<55 together with mu>55mv and mv>55ms correctly certify both native exponential mass gaps.

For every actual big center, the small tiles' positive-occupation capture union contains its whole Q1, modulo null boundary: each coordinate has the overlapping union [-(1+eta)/2,(1+eta)/2], and all sign choices give its Cartesian product. Therefore Ubig=1 under full f and R385 truly pays zero. On the packet, original ranks are Tsmall=eta^16/ms, Tmid=Tsmall+eta^16/mv and Tbig=Tmid+eta^16/mu. Both small and mid captures remain in the ORIGINAL J=Tbig. The small tiles fail the big-to-small outside gate but are not deleted from these occupations. The designated big-to-mid cost includes only its own factor eta^16/mv.

All big-to-mid pair-coordinate distances stay within eta of (.7,.25,...,.25). The explicit outside, dense/deep and not-Bplus margins hold on the whole pair boxes. Using the allowance evaluated at Rv (rather than a smaller lower-bin side) is conservative for demonstrating failure of the old Bplus gate. Every coordinate is on the partial affine overlap segment: first-coordinate mean capture is (7/8-.7)/(3/4)=7/30, and each other coordinate has mean (7/8-.25)/(3/4)=5/6. Fubini over the actual product CENTER domains proves pmean=(7/30)(5/6)^15, without assuming product structure of f. The pairwise capture upper bound is conservative and verifies alpha and A lower bounds for each continuous big center, rather than only a block mean.

All positive designated far costs begin at Ru=b=1 and use the true terminal clock atom. The two source/posterior expressions for G agree algebraically, with full receiver volumes and surplus normalization retained. The script verifies active dyadic levels fall in the ms atom (including the hden=8 endpoint equality). Hence R386 large-end windows miss mu, the low-rank cutoff misses Tmid, and its level-2h small window misses mv; both endpoints nevertheless have the actual required strict past. The selected big-to-mid positive branch is genuinely in the literal R386 G_next. The new close-rank ratio (Tbig/Tmid)-1 is positive and below 1/1000, and its original cost is bounded by d|E| and dX_q/q_- using complete E and X_q.

This is an exact positive-du local mechanism example. h=H=eta^16/(hden ms) and the core screening threshold are diagnostic, not synchronized R379/global entrance choices or complete historical qualifications. No strict fraction of full hard traffic, near-extremizer or general bound is certified. The saved scope states these limits, retains full huge W and tiny G/X_q, and reports 1/27/81 executions with repetition rather than 109 independent models. The final source-threshold correction was rerun successfully and is not counted a second time.

## 11. Final ledger, parameter initialization and freeze

Read final main/ledger/readme. The ledger prefix through R386 is byte-for-byte unchanged from the already bound R386 ledger; its appended R387 formula is

    BH<=G_mid+(eta+sigma_n+epsilon383+lambda d/q_-+tau)X_q
              +(C338+S386)W.

The original entrance retains 8lambda H W and 2d_eff A_n W_nu/H, plus twice G_mid, twice the hard-slot receiver coefficient and twice C338+S386, then multiplication by Lambda. There is no new W fee, target-cap/template inflation, h/t change on a fixed field, reused square, or repeated R386 source payment. A fixed field must have budget room for the new receiver coefficient; an exhausted old kappa is not reused.

The alternative unified kappa allocation is explicitly made at the ORIGINAL initialization: eta=kappa/(12Lambda), epsilon383=lambda d/q_-=tau=kappa/(8Lambda), sigma_n<=eta/2. The prior epsilon0/h/t, plan and synchronized gates are then defined using those parameters, and all prior estimates are reapplied consistently. At the upper sigma bound the new total hard-slot coefficient times 2Lambda equals kappa. This is a local slot allocation, not a full-global absorption claim. The old source-price parameter dependence remains, and its asymptotic root-logarithmic expression excludes other unpaid slots.

G_mid retains all old marks, actual near-full-U row support, both same-source strict past conditions and the intermediate closed-rank ratio. No transfer of alpha_v/Y_v, next spatial/target admissibility, future source order or history is asserted. The general budget for G_mid, H entry/choice, soft/crossing/entry, tail/scale complements, initial/deleted/future-deleted history atoms, aggregation, truncation and limits remains open.

Parent reports successful actual executions 19860+7396+15588=42844 Fraction assertions, without double-counting reruns or reviewer work. Reviewer bounded evidence is separately 4096 close-rank cases, 6144 low-rank cases and one scalar budget equality. Scripts and results were read rather than rerunning already passed parent pipelines. This audit does not certify LaTeX layout or compilation and does not freshly re-prove the whole historical reduction.

FINAL PASS: no outstanding correction found in the stated R387 receipts, final native-center diagnostic, or complete same-slot accounting. General centered-cube root closure is NOT established.

## 12. Final byte bindings

| File | SHA256 |
| --- | --- |
| `/tmp/r387_main.md` | `2a5e82187a18e01dea14b6cced846ec658b735567135b5afe6c312cad884a7da` |
| `/tmp/r387_ledger.md` | `c5057600d97b0fb391715cc46d52e8894e9bf55d1f2146cbb080e91c5cc8ead0` |
| `/tmp/r387_readme.md` | `9d4ed77511648cae37bfe25c053d13342c21803cacab65925e95b91334dd08ce` |
| `/tmp/r387_aux.md` | `a95c573b4914276040de4b69a65a313fa9d5949a63002b508cb205bf095dba40` |
| `/tmp/r387_aux_check.py` | `b643ca73e79d8ed1b9c5f646d1890adb5a2c59bb4eaa448bb8837fdc598b4c95` |
| `/tmp/r387_geometry.md` | `683e9f7886d1e893b0923c5268840c5e696f8c94e55f1ecdb92050c4cfb14458` |
| `/tmp/r387_geometry_check.py` | `ee797876e15d2c1227f4b975bdf182334d4db30da9f3ee2dc6adc31a0e717a5a` |
| `/tmp/r387_continuum.md` | `f622959ee54d3a167fff0fdaa7a272b6e6e55a6b99d37563d21c998d260f6b30` |
| `/tmp/r387_continuum.py` | `43c28b745b8c37e2c696f4c02445ba0706e18ad2e144d3842e8116315950bccd` |
| `/tmp/r387_continuum.result.json` | `49874a049c77f4b7cf6630c9b1fccd0a44fe3aaa5e92d3c008fcbca739f445bd` |
| `/tmp/r386_geometry.md` | `fe839792aff6ca2b1fcb6787a8073fe71d8ca3dd28b8d46585d350d2c5851bca` |
| `/tmp/r386_ledger.md` | `151e01d43263b4572a9299e0964d91c46e72ea4fd951315b72673caf6be9a64f` |
| `/tmp/r385_geometry.md` | `f39ec03b200b8954695da179d5d24183a1420081a96aaee61f34fb09c353c8eb` |
| `/tmp/r383_flow.md` | `3870009b3c82a3a051e379ea6636940ff583ca945f645d371d0a813e9880c4cd` |
