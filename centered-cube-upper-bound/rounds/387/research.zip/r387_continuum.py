"""R387 real-Lebesgue shell/tile rank-close witness; standard library only."""
from fractions import Fraction as F
from itertools import product
from pathlib import Path
from math import factorial
import hashlib,json
COUNT=0

def ck(x):
 global COUNT
 assert x
 COUNT+=1

def ebound(x,N=40):
 lo=sum((F(x**j,factorial(j)) for j in range(N+1)),F(0))
 return lo,lo+F(x**(N+1),factorial(N+1))/(1-F(x,N+2))

LO,HI=ebound(4)
ck(54<LO<HI<55)

def case(eta,P,delta,hden):
 n=16;bg=F(3,4);ru=F(1);rv=F(3,4);rs=F(1,2);w=eta**n
 Dlo=[F(47,100)]+[F(1,10)]*(n-1)
 Dhi=[F(12,25)]+[F(11,100)]*(n-1)
 volumeD=F(1,100)**n
 us=[F(0)]*n;vs=[F(7,10)]+[F(1,4)]*(n-1)
 small=[F(1,4)]*n
 m0=bg*rs**n;ms=m0+P;mv=bg*rv**n+P;mu=bg+P
 qs=ms/rs**n;qv=mv/rv**n;qu=mu
 fD=bg+P/volumeD
 for q in [bg,qs,qv,qu]:ck(bg<=q<=1)
 ck(mu>55*mv and mv>55*ms and ms<2*m0)
 # Complete source/cube geometry on every positive-volume receiver box.
 for center,R in [(us,ru),(vs,rv),(small,rs)]:
  for i in range(n):
   ck(center[i]+eta/2-R/2<=Dlo[i] and center[i]-eta/2+R/2>=Dhi[i])
   ck(abs(center[i])+eta/2+R/2<2)
 # Every non-all-positive sign tile has a negative coordinate. That coordinate
 # excludes D for all points of that receiver box; no 2^n enumeration needed.
 ck(-F(1,4)+eta/2+rs/2<min(Dlo))
 # The union over BOTH one-dimensional sign receiver intervals covers the
 # entire big capture interval, with overlap. Tensor products give Ubig=1.
 ck(F(1,4)+eta/2+rs/2==eta/2+ru/2)
 ck(-F(1,4)+eta/2+rs/2>=F(1,4)-eta/2-rs/2)
 # All receiver boxes are disjoint. Small sign boxes separated by >=1/2;
 # mid vs all-positive tile first coordinate separation=.45.
 ck(eta<F(1,2) and eta<F(9,20) and eta<F(1,4))
 # Original geometry inequalities, in the same normalization as R386.
 distances=[abs(v-u) for u,v in zip(us,vs)]
 dmin=[d-eta for d in distances];dmax=[d+eta for d in distances]
 ck((2*max(dmin)/ru)**n>1+4) # alpha^n=1+sqrt(n)
 excess=[max(F(0),2*d-(ru-rv)) for d in dmin]
 ck(all(x>0 for x in excess) and n>F(n,8))
 ck(sum(excess)>F(n,20))
 beta=1+F(1,n)
 allowance=n*((1+beta)*rv-ru)**2/(4*beta*rv)
 ck(sum(excess)>allowance)
 # Small tiling pairs have no original outside contribution against big.
 ck((2*(F(1,4)+eta)/ru)**n<1+4)
 Tsource=1+(n+1).bit_length() # 1+ceil(log2(n+2))
 ck(Tsource==6 and fD>Tsource*max(qs,qv,qu))
 # Literal diagnostic H/h, not a synchronized global absorption choice.
 h=w/(hden*ms);H=h
 Tsmall=w/ms;Tmid=Tsmall+w/mv;Tbig=Tmid+w/mu;Zbig=Tmid;Zmid=Tsmall
 ck(Zbig>h and Zmid>h and Tsmall>=2*h and Tmid>2*h)
 ck(Tbig<2*Zbig and Tbig>H)
 levels=[];level=2*h
 while level<=Tbig:
  # Every active dyadic level is inside the small+ mass atom, including ties.
  ck(level<=Tsmall)
  levels.append(level);level*=2
 ck(len(levels)>0 and level>Tbig)
 # Both endpoints lie beyond K times the shared quantile small mass.
 ck(mu>55*ms and mv>55*ms)
 # Hence R385 U-witness=0, all R386 remainder payments=0 on big->mid:
 # rankjump misses big; low closed rank fails; target has strict past>h,
 # and lies outside the level2h mass window [ms,Kms].
 ck(Tmid>2*h and Zmid>h and mv>55*ms)
 # Physical clock: ell intervals [1/2,3/4),[3/4,1), terminal atom{1}.
 ell=[rs**(-n)-rv**(-n),rv**(-n)-ru**(-n),ru**(-n)]
 ck(sum(ell)==rs**(-n) and ell[-1]==1)
 omega=h/Tbig
 ck(0<omega<1)
 # All target overlaps stay on their partial affine segment for every pair.
 for d in distances:ck((ru-rv)/2<d-eta and d+eta<(ru+rv)/2)
 # Exact tensor center integral: affine factors' means equal center values.
 pmean=F(7,30)*F(5,6)**(n-1)
 pmax=F(4,3)*(F(7,40)+eta)*(F(5,6)+F(4,3)*eta)**(n-1)
 ck(0<pmean<=pmax<1)
 lossmin=1-pmax
 c=(w/mv)/Tbig*(1-mv/mu)*(1-qv/fD)
 piD=fD*volumeD/mu
 Amin=piD*c*lossmin
 ck(c*lossmin>delta and Amin>2*delta)
 G=w*w*(1-mv/mu)*(fD-qv)*volumeD/(mv*Tbig)*(1-pmean)
 Gposterior=qu*w*piD*c*(1-pmean)
 ck(G==Gposterior and G>0)
 # New source-rank-close criterion holds on the whole original pair boxes.
 rankratio=Tbig/Tmid-1;d=F(1,1000)
 ck(0<rankratio<d)
 E=(2**n+2)*w
 X=w*((2**n-1)*bg+qs+qv+qu)
 W=bg*4**n+P
 ck(bg*E<=X<=E)
 ck(G<=d*E and d*E<=d*X/bg)
 return {'eta':str(eta),'P':str(P),'delta_core':str(delta),'h_denominator':hden,
  'G_next_big_to_mid':str(G),'new_rankclose_paid':str(G),'R385_paid':'0',
  'R386_rankjump_paid':'0','R386_lowrank_paid':'0','R386_small_window_paid':'0',
  'rankclose_excess_ratio':str(rankratio),'rankclose_d':str(d),'A_lower':str(Amin),
  'capture_mean':str(pmean),'capture_upper_every_pair':str(pmax),
  'h_H_diagnostic':str(h),'Tsmall':str(Tsmall),'Tmid':str(Tmid),'Tbig':str(Tbig),
  'Zbig':str(Zbig),'Zmid':str(Zmid),'active_dyadic_count':len(levels),
  'lowest_quantile_mass':str(ms),'qsmall_capture':str(qs),'qmid':str(qv),'qbig':str(qu),
  'msmall_capture':str(ms),'mmid':str(mv),'mbig':str(mu),
  'W_full_f':str(W),'E_volume':str(E),'Xq':str(X),'G_over_Xq':str(G/X),
  'new_global_payment_bound_dE':str(d*E),'sourcepacket_volume':str(volumeD),
  'min_dense_excess':str(min(excess)),'deep_excess_sum':str(sum(excess)),
  'not_Bplus_allowance':str(allowance)}

def summary(cases):
 keys=['G_next_big_to_mid','rankclose_excess_ratio','A_lower','G_over_Xq']
 out={'executed_parameter_fields':len(cases),'digest_of_full_exact_cases':hashlib.sha256(json.dumps(cases,sort_keys=True).encode()).hexdigest()}
 for key in keys:
  vals=[F(c[key]) for c in cases];out[key+'_min']=str(min(vals));out[key+'_max']=str(max(vals))
 return out

def main():
 global COUNT
 base=case(F(1,1000),F(1,2**20),F(1,10**14),10)
 initial=[base]
 pressure=[case(e,p,F(1,10**14),hd) for e,p,hd in product([F(1,2000),F(1,1000),F(1,500)],[F(1,2**22),F(1,2**20),F(1,2**18)],[8,10,12])]
 expanded=[case(e,p,de,hd) for e,p,de,hd in product([F(1,2000),F(1,1000),F(1,500)],[F(1,2**22),F(1,2**20),F(1,2**18)],[F(1,10**15),F(1,10**14),F(1,10**13)],[8,10,12])]
 result={'scope':'Actual full-f L1 geometry, actual Lebesgue receiver boxes, q-band and same-full-f caps; diagnostic h=H only, not synchronized native history or general closure. Complete positive big->mid G_next subbranch; not a lower bound on total fraction of full G. R386 spatial/core gates checked in their inherited scalar normalization.',
  'n':16,'original_source_threshold_T':6,'small_tile_count':2**16,'mid_center':['7/10']+['1/4']*15,
  'exact_fraction_assertions':COUNT,'baseline':base,
  'stages':{'initial':summary(initial),'boundary_pressure':summary(pressure),'expanded_core_margin':summary(expanded)},
  'strict_exponential_certificate':{'exp4_lower':str(LO),'exp4_upper':str(HI),'simple_bracket':'54<exp(4)<55'}}
 out=Path(__file__).with_suffix('.result.json');out.write_text(json.dumps(result,indent=2)+'\n')
 print('PASS',COUNT,'exact Fraction assertions; stage fields 1/27/81')
 print('baseline G=',base['G_next_big_to_mid'],'rankclose=',base['rankclose_excess_ratio'],'A_lower=',base['A_lower'])
if __name__=='__main__':main()
