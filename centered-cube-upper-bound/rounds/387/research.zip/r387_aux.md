# R387 — Paid close-endpoint-rank edges inside the strict far-mass remainder

**Result.** A further positive branch of the actual G_next is paid by εX_q, with no new source-W fee. The branch is close in cumulative source rank, while remaining strictly far in receiver mass. The proof retains the original physical clock until the legitimate column domination; it does not use an L² resolvent or infer a source budget from an operator norm. The complementary rank-separated flow is not closed.

## 1. Frozen contract and the additional gate

Use exactly the R386 field and remainder: full f≥0 in L¹, actual Lebesgue du,dv, actual cubes Q_u with a≤R_u≤b≤2a,

m_u=∫f c_u=q_uR_u^n,  q_-≤q_u≤λ,  μ(du)=du/m_u,

J_y(r)=∫_{R_w≤r}c_w(y)μ(dw),
T_y(t)=∫_E c_w(y)1_{m_w≤t}μ(dw),
Z_u(y)=∫_E c_w(y)1_{m_w<m_u/K}μ(dw),

where K=exp(√n)>λ/q_- and c_u=1_{Q_u}. The original H,h>0, all surplus/target/history/window/outside/dense/deep marks and the complete clock

ell(dr)=n r^(−n−1)1_(a,b)dr+b^(−n)δ_b

are unchanged. For concision write T_u(y)=T_y(m_u). The exact current positive flow has the R386 form

dΓ=ell(dr)f(y)dy [1_{J_y(r)≥H}/J_y(r)]
       θ(r,y,u,v)c_u(y)c_v(y)(m_u−m_v) μ(du)μ(dv),              (1)

with u,v∈E_r, 0≤θ≤1. Its support retains all of R386(4), including

m_u>K m_v,  Z_u>h,  T_u<2Z_u,  T_v>2h,  Z_v>h.

If θ was obtained by disintegrating original target marks, those marks remain in θ; no new target plan or conditional independence is introduced.

For any δ>0, define the additional close-rank gate

N_δ(y,u,v)={T_u(y)≤(1+δ)T_v(y)}.

Let G_close be (1) on this gate and G_sep its exact positive complement. Then

G_next=G_close+G_sep,
G_close≤λδ |E|≤(λδ/q_-)X_q.                                  (2)

In particular δ=εq_-/λ pays G_close≤εX_q for any ε>0. This auxiliary δ does not change the old h, H, plan or other synchronized parameters. No claim is made that every far-mass edge is close in rank.

The estimate is actually valid for any positive subflow (1) on m_u>K m_v and Z_u>h. Neither the regular gate T_u<2Z_u nor the small-endpoint-past condition is needed for its proof; those stronger existing restrictions are nevertheless retained in both new pieces.

## 2. Exact atomic endpoint-capacity lemma

Let γ be a finite measure on positive masses, with inclusive CDF T(t)=γ((0,t]). Fix t>0, τ=T(t), and δ>0. Then

γ{s>t:T(s)≤(1+δ)τ}≤δτ.                                      (3)

For τ=0 the left side is zero. For τ>0, every retained mass-rank interval lies above τ and ends at or below (1+δ)τ. An atom ending at the upper cutoff is included; an atom crossing it is excluded. The union of these disjoint rank intervals has length at most δτ. Equivalently, use the generalized inverse of T to push Lebesgue measure on (0,T(∞)) to γ: a retained point has rank in (τ,(1+δ)τ] almost everywhere. This proves (3) for atoms, continuous and singular parts without any regularity assumption.

Apply this to γ_y(dt)=∫c_u(y)μ(du)δ_{m_u}(dt), at t=m_v. All allowed u have m_u>K m_v>m_v, so

∫c_u(y)μ(du)1_{m_u>K m_v}1_{T_u≤(1+δ)T_v}≤δT_v.             (4)

This is an occupation bound for actual receivers containing the same source y. It is not a replacement of source mass by center volume.

## 3. Keep the original clock, then bound the true column

Fix the actual marked source y and small receiver v. Since m_u>K m_v, matching and K>λ/q_- give R_v<R_u. More generally every w with m_w<m_u/K satisfies R_w<R_u. Hence, for every physical r≥R_u,

T_v(y)≤Z_u(y)≤J_y(r).                                        (5)

The first inequality includes the entire mass atom at m_v, because m_v<m_u/K is strict. All these quantities refer to full E and full f.

In the actual integral (1), use (m_u−m_v)μ(du)≤du, discard only positive restrictions for an upper bound, and use the same complete clock tail ell([R_u,b])=R_u^(−n). The close-rank column is at most

B_v^δ(y)=∫ c_u(y)du/R_u^n ·
  1_{m_u>K m_v}1_{Z_u>h}1_{T_u≤(1+δ)T_v}/Z_u.                (6)

Its exit measure remains exactly f(y)c_v(y)dy μ(dv). It is not removed during the column estimate.

When T_v>0, q_u≤λ, (5), and (4) imply

B_v^δ(y)≤(λ/T_v)∫c_u(y)μ(du)
             1_{m_u>K m_v}1_{T_u≤(1+δ)T_v}
         ≤λδ.                                                (7)

If T_v=0, the gate T_u≤(1+δ)T_v cannot coexist with Z_u>h and Z_u≤T_u; hence (6) is zero. There is no zero denominator to be assigned an artificial value.

Finally use the actual full-f matching only after (7):

G_close≤∫f(y)∫c_v(y)μ(dv) B_v^δ(y)dy
≤λδ∫_E dv [∫f(y)c_v(y)dy/m_v]
=λδ |E|≤(λδ/q_-)X_q.

This proves (2). The intermediate ∫fJ_b is used in its exact matched value |E| and receives the arbitrarily small coefficient λδ. It is not assigned a root source-W price or bounded by a linear-n source envelope. The same argument preserves any additional original history or source marks, since they were only positively dominated by 1.

## 4. What changes in the actual ledger and what remains

Starting from the already certified same-field ledger

BH≤G_next+E_old X_q+S_old,

one may now write

BH≤G_sep+(E_old+ε)X_q+S_old.                                  (8)

No old R386 jump/terminal/window price is charged again. The same outer entrance multiplier 2Λ gives the sole new cost 2ΛεX_q. Source-W fees, target capacities, old physical-scale costs and the frozen full field remain unchanged. No original negative square is reused.

Every retained edge has, in addition to all old R386 conditions,

T_y(m_u)>(1+δ)T_y(m_v),

so its source rank decreases by a definite factor when oriented from the larger receiver to the smaller one. This is a legitimate one-edge fact. If a finite sequence happens to keep the same source y and every edge satisfies the new gate, then its rank decreases geometrically; with the existing lower-end past>h and J_b≤A_n/q_-, its number of edges k obeys

(1+δ)^k h<J_b(y)≤A_n/q_-.

This conditional path-count statement does not construct such a sequence, does not keep a source fixed after a source resampling, and does not give a conservative arrival flow. An endpoint can still fail the next original row/target/spatial eligibility test. Its incoming traffic cannot be discarded or assigned the low-row payment of a fresh process. Establishing that transfer and its failed-transfer budget remains necessary.

The new receipt is therefore the explicit close-rank branch (2), not a full estimate of G_sep. It uses source-conditioned rank capacity and the real matched clock rather than an additional center-volume estimate. A genuinely joint spatial/rank bound on the remaining separated edges has not been proved in this task.

## 5. Exact local checks

`/tmp/r387_aux_check.py` was actually executed with Python Fraction arithmetic:

`PASS {'atomic_capacity': 14580, 'matched_clock': 5160, 'budget': 120} total 19860 positive_atomic_cases 1066 positive_clock_cases 37`.

Stage 1 checks inclusive rank endpoints, strict far cutoffs, (4) and (7), including 1,066 nonempty paid atomic cases. Stages 2–3 use actual cube/source intersections and exact q matching, the original continuous-clock interval weights plus terminal atom, the R386 regular and both strict-past gates, and verify the original marked column before every relaxation in (6)–(7). Low-dimensional fixtures use piecewise-constant positive full f on cube arrangement cells. Dimensions 16 and 64 use actual nested concentric cubes and three positive source shells, permitting exact source integration without enumerating exponentially many coordinate cells. The latter include rational K larger than exp(√n), so their strict far subbranches lie inside the original exponential far-mass domain. All fixtures satisfy q∈[3λ/4,λ], λ=9/8.

Receiver integration in the finite checks is positive quadrature, not a native real-du field, and the fixtures do not claim to realize all earlier R385 acceptance marks. Omitting those marks is legitimate for checking this positive upper-bound theorem; the analytic statement covers arbitrary marks in [0,1]. The 37 positive full-clock cases rule out an entirely empty algebraic test, but do not prove a general geometric coverage fraction. The real-du and general-measure theorem is proved in §§2–3.
