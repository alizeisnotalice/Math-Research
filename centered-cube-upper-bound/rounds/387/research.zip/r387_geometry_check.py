from fractions import Fraction as F
from itertools import product
from random import Random

counts = {'cdf_atoms': 0, 'clock_matching': 0, 'joint_support': 0}
positive = {'near': 0, 'low_after_near': 0, 'middle': 0}

# Stage 1: inclusive ranks, repeated mass values, equality and crossing atoms.
for weights in product(range(1, 4), repeat=4):
    for masses in ((1, 1, 2, 4), (1, 2, 2, 4), (1, 2, 4, 8)):
        T = [sum(F(weights[j], 5) for j in range(4) if masses[j] <= masses[i]) for i in range(4)]
        total = sum(F(w, 5) for w in weights)
        levels = {F(0), total, total / 2, *T}
        levels |= {t - F(1, 10) for t in T if t >= F(1, 10)}
        for level in levels:
            occ = sum((F(weights[i], 5) for i in range(4) if T[i] <= level), F(0))
            assert occ <= level
            counts['cdf_atoms'] += 1

# Stage 2: exact full-clock finite incidence diagnostics.
# Full source matching is enforced. These are not claimed to be actual cubes
# or octave fields. n=1, q_i=1, R_i=m_i; physical clock is integrated exactly.
rng = Random(387)
for case in range(120):
    ns, nr = 5, 7
    f = [F(rng.randrange(1, 8), rng.randrange(1, 5)) for _ in range(ns)]
    cap = [[rng.randrange(2) for _ in range(ns)] for _ in range(nr)]
    for i in range(nr):
        if not any(cap[i]): cap[i][i % ns] = 1
    volume = [F(rng.randrange(1, 6), rng.randrange(1, 5)) for _ in range(nr)]
    mass = [sum(f[y] * cap[i][y] for y in range(ns)) for i in range(nr)]
    R = mass[:]
    mu = [volume[i] / mass[i] for i in range(nr)]
    K = F(2)
    T = [[sum(mu[w] * cap[w][y] for w in range(nr) if mass[w] <= mass[i]) for i in range(nr)] for y in range(ns)]
    Z = [[sum(mu[w] * cap[w][y] for w in range(nr) if mass[w] < mass[i] / K) for i in range(nr)] for y in range(ns)]
    levels = sorted(set(R))
    clock = [(levels[k], 1 / levels[k] - 1 / levels[k + 1]) for k in range(len(levels) - 1)]
    clock += [(levels[-1], 1 / levels[-1])]
    for i in range(nr):
        assert sum(w for r, w in clock if R[i] <= r) == 1 / R[i]
    h = F(1, 20)
    for tau, d in product((F(1, 10), F(1, 3), F(2, 3)), (F(1, 10), F(1, 2))):
        near = low = middle = F(0)
        for r, cw in clock:
            for y in range(ns):
                J = sum(mu[i] * cap[i][y] for i in range(nr) if R[i] <= r)
                if not J: continue
                for u in range(nr):
                    if R[u] > r or not cap[u][y] or Z[y][u] <= h: continue
                    # Keep the R386 regular support, without asserting other history.
                    if T[y][u] >= 2 * Z[y][u]: continue
                    for v in range(nr):
                        if not cap[v][y] or mass[u] <= K * mass[v]: continue
                        assert R[v] < R[u] and T[y][v] <= Z[y][u] <= J
                        mark = F((u + 2 * v + y + case) % 5, 4)
                        cost = cw * f[y] / J * (mass[u] - mass[v]) * mu[u] * mu[v] * mark
                        if T[y][u] <= (1 + d) * T[y][v]:
                            near += cost
                        elif T[y][v] <= tau * Z[y][u]:
                            low += cost
                        else:
                            middle += cost
                            assert tau * T[y][u] / 2 < T[y][v]
                            assert (1 + d) * T[y][v] < T[y][u]
                            counts['joint_support'] += 1
        X = sum(volume)
        assert near <= d * X
        assert low <= tau * X
        assert near + low <= (d + tau) * X
        assert near + low + middle <= X
        counts['clock_matching'] += 1
        positive['near'] += bool(near)
        positive['low_after_near'] += bool(low)
        positive['middle'] += bool(middle)

# Stage 3: fixed-source path rank ratios only, no flow or endpoint assertion.
path_checks = 0
for d, tau in product((F(1, 10), F(1, 3), F(1, 2)), (F(1, 10), F(1, 4))):
    ranks = [F(1024)]
    while ranks[-1] / (1 + 2 * d) > 2:
        ranks.append(ranks[-1] / (1 + 2 * d))
    for x, y in zip(ranks, ranks[1:]):
        assert tau * x / 2 < y < x / (1 + d)
        path_checks += 1
    length = len(ranks) - 1
    assert (1 + d) ** length < ranks[0] / ranks[-1] if length else True
print('PASS', counts, 'path_checks', path_checks, 'total', sum(counts.values()) + path_checks)
print('positive_cases', positive)
