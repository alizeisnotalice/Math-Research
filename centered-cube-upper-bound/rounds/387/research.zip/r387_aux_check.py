from fractions import Fraction as F
from itertools import product
from math import prod
count={'atomic_capacity':0,'matched_clock':0,'budget':0};positive=0;positive_clock=0
# Inclusive CDF, strict mass past, and no crossing-atom error.
for weights in product((F(1,32),F(1,4),F(1)),repeat=4):
 masses=[F(1),F(4),F(16),F(64)]
 T=[sum(weights[:i+1]) for i in range(4)]
 for K in (F(2),F(4),F(8)):
  Z=[sum(weights[j] for j in range(4) if masses[j]<m/K) for m in masses]
  for d in (F(1,32),F(1,8),F(1,2),F(1),F(2)):
   for v in range(4):
    ids=[u for u in range(4) if masses[u]>K*masses[v] and T[u]<=(1+d)*T[v]]
    occ=sum(weights[u] for u in ids)
    column=sum(weights[u]/Z[u] for u in ids)
    assert occ<=d*T[v] and column<=d
    assert all(Z[u]>=T[v] for u in ids)
    count['atomic_capacity']+=3
    positive+=bool(ids)
# Actual cubes, positive full source, exact q band; finite receiver quadrature.
for n in (2,3,4,16,64):
 R=[F(1),F(3,2),F(2)]
 if n>4:
  cells=[(F(1),F(9,8),[1,1,1]),(R[1]**n-1,F(1),[0,1,1]),(R[2]**n-R[1]**n,F(7,8),[0,0,1])]
 else:
  centers=[[F((u*(i+1))%5,4)-F(1,2) for i in range(n)] for u in range(3)]
  cubes=[[(centers[u][i]-R[u]/2,centers[u][i]+R[u]/2) for i in range(n)] for u in range(3)]
  axes=[]
  for i in range(n):
   b=sorted({x for Q in cubes for x in Q[i]});axes.append(list(zip(b,b[1:])))
  cells=[]
  for idx,box in enumerate(product(*axes)):
   mid=[(a+b)/2 for a,b in box]
   c=[int(all(a<mid[i]<b for i,(a,b) in enumerate(Q))) for Q in cubes]
   if any(c):cells.append((prod(b-a for a,b in box),F(1)+F(idx%3-1,8),c))
 m=[sum(vol*f*c[u] for vol,f,c in cells) for u in range(3)]
 q=[m[u]/R[u]**n for u in range(3)];lam=F(9,8);qm=3*lam/4
 assert all(qm<=a<=lam for a in q)
 du=[F(1,2),F(2,3),F(3,4)];mu=[du[u]/m[u] for u in range(3)]
 ell=[R[j]**(-n)-(R[j+1]**(-n) if j<2 else 0) for j in range(3)]
 X=sum(q[u]*du[u] for u in range(3));E=sum(du)
 for K in ((F(2),F(8),F(64) if n==16 else F(4096)) if n>4 else (F(2),F(8))):
  for d in (F(1,32),F(1,8),F(1,2),F(1),F(2)):
   G=F(0)
   for vol,f,c in cells:
    T=[sum(mu[w]*c[w] for w in range(3) if m[w]<=m[u]) for u in range(3)]
    Z=[sum(mu[w]*c[w] for w in range(3) if m[w]<m[u]/K) for u in range(3)]
    for v in range(3):
     if not c[v]:continue
     B=actual=F(0)
     for u in range(3):
      if not c[u] or not m[u]>K*m[v] or not T[u]<=(1+d)*T[v]:continue
      # Keep R386 high past, rank-regular and the small endpoint's past.
      if not Z[u]>F(1,10000) or not T[u]<2*Z[u] or not Z[v]>F(1,10000):continue
      B+=du[u]/R[u]**n/Z[u]
      for j in range(u,3):
       J=sum(mu[w]*c[w] for w in range(j+1))
       if J>=F(1,10000):actual+=du[u]*ell[j]*(1-m[v]/m[u])/J
     assert actual<=B<=lam*d
     G+=vol*f*mu[v]*actual
     count['matched_clock']+=2
   assert G<=lam*d*E<=lam*d*X/qm
   count['budget']+=2
   positive_clock+=G>0
print('PASS',count,'total',sum(count.values()),'positive_atomic_cases',positive,'positive_clock_cases',positive_clock)
