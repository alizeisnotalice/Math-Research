# R387: a genuine positive-dx next branch paid by rank closeness

The new payment has a nonempty, strictly positive original-clock subbranch on actual Lebesgue receiver boxes and one fixed complete positive-L1 source. It is beyond the literal R385/R386 payments tested here. This is a diagnostic h/H input, not the synchronized global absorption parameters, a historical first-crossing/selector certificate, a near-extremizer, or a general closure result. No fraction of the complete hard remainder is asserted.

## Full source, actual receivers and matching

Set n=16, a=1/2,b=1,lambda=1 and

f=(3/4)1_Q4 + (P/|D|)1_D,
D=[.47,.48] times [.10,.11]^15, |D|=10^(-32).

There are 2^16 positive-volume receiver boxes of side eta centered at all sign choices (+/-1/4)^16, each with actual R=L=1/2, hard softness zero. Also use a mid receiver box centered at (.7,.25,...,.25), actual R=L=3/4, and a big receiver box centered at zero, actual R=L=1. All receiver boxes have their actual volume w=eta^16, are disjoint, and all selected cubes lie in Q4. The original proposal's .125 coordinates were replaced by .25, as directed, so full pair boxes have strict protrusion margins in every coordinate; no receiver subbox restriction is needed.

Exactly the all-positive small tile, the mid receiver, and the big receiver capture D, uniformly over their complete receiver boxes. Every other small tile has a negative coordinate whose entire capturing cube misses D. Consequently actual matching gives

m0=(3/4)2^(-16), ms=m0+P,
mv=(3/4)(3/4)^16+P, mu=3/4+P.

q0=3/4, qs=ms/(1/2)^16, qv=mv/(3/4)^16, qu=mu are all in [3/4,1]. Thus actual q<=lambda and same-full-f matching/cap hold. Neither q nor source mass is reset. Full source mass W=(3/4)4^16+P is retained. All original source surplus (f-qv)+ for the designated pair is on D; the branch is integrated over its whole positive-volume source support, not an isolated source point.

The sign tiles are not enumerated as a fake receiver quadrature: the one-dimensional union of their genuine capture intervals is [-(1+eta)/2,(1+eta)/2], with overlap of positive width. Taking products proves that their capture union contains every big receiver's whole Q1. The full-f joint union capture is therefore Ubig=1, up to null boundaries. The R385 minimum witness and its corresponding literal payment are zero.

## Original spatial and core gates

The tested big→mid center differences lie within eta of (.7,.25,...,.25). In the inherited R386 scalar normalizations the script verifies, throughout the complete pair boxes:

- Outside: (2 max distance_min)^16>1+sqrt(16)=5.
- Dense: every coordinate has strictly positive excess 2 distance_min-(Ru-Rv), so j=16>16/8.
- Deep: their summed excess is >16/20; at baseline it is 4.868.
- Not-Bplus: the same sum exceeds 16[((1+beta)Rv-Ru)^2]/(4 beta Rv), beta=1+1/16; the baseline allowance is 1.50122549.
- D lies in the high-source part f_D>T max(q), where the original n16 threshold is T=1+ceil(log2(18))=6, and the full row/point core lower bounds satisfy A_u>2 delta and alpha_u(D)>delta, for the whole big receiver box.

The small tiling receivers do not satisfy the big→small outside gate; their capture-union role must not be confused with contributing positive outside traffic. A rational Taylor certificate gives 54<exp(4)<55. Both mu>55mv and mv>55ms, so the two strict mass-far directions are certified for the actual native mass multiplier exp(sqrt(16)), not a favorable smaller multiplier.

These are the explicit literal spatial/core tests inherited from R386. Full original historical low/e/m or first-selection qualifications are not implemented. In particular literal diagnostic gates do not certify the synchronized native hard entrance.

## Common source ranks, clock and the formerly unpaid branch

For every y in D,

Tsmall=w/ms,
Tmid=w/ms+w/mv,
Tbig=Tmid+w/mu,
Zmid=Tsmall, Zbig=Tmid.

Take h=H=w/(hden ms), with hden=10 at baseline. Actual strict past is >h for both endpoints. The physical clock has its continuous [1/2,3/4) and [3/4,1) weights and the genuine terminal atom at b=1. Positive big→mid traffic uses only that terminal atom, J=Tbig and omega_big=h/Tbig. Small/mid contributions to J are retained, not deleted after payment.

At baseline the active dyadic levels are 2h,4h,8h, all in the small mass ms atom. The same statement holds in every pressure field; hden=8 expressly tests the equality level 8h=Tsmall with the closed quantile rule. Therefore:

1. Large-u rank-jump windows miss mu, since mu>55ms.
2. Small-v closed-low-rank payment fails, since Tmid>2h.
3. The small-v own strict past exceeds h, and its level-2h quantile is ms; mv>55ms, so the small-endpoint window also misses it.

The literal R386 three-payment sum is zero on this entire big→mid subbranch. Together with Ubig=1, this gives a real, positive G_next witness for the newly added rank-close payment, rather than only an unpriced algebraic envelope.

## Exact continuous integration and the new payment

Every overlap coordinate stays in the partial affine regime for all big/mid center pairs. The mean target-uniform geometric capture is exactly

pmean=(7/30)(5/6)^15.

This follows by integrating each affine factor over its two actual center intervals, then Fubini over the product center boxes. It assumes neither independence of the full source f nor a source density cap. An everywhere-pair capture upper is also computed and used for the core lower bound.

The exact positive cost is

G=w^2(1-mv/mu)(f_D-qv)|D|(1-pmean)/(mv Tbig)>0.

An independent posterior expression qu*w*pi_big(D)*[(w/mv)/Tbig]*(1-mv/mu)*(1-qv/f_D)*(1-pmean) agrees exactly. All outer receiver weights and the physical clock normalization remain present.

The new condition holds on all the original pair boxes and source D:

Tbig/Tmid-1 = (1/mu)/(1/ms+1/mv) < d=1/1000.

Hence this whole positive formerly unpaid subbranch is rank-close paid. The executable also checks the actual fee G<=lambda*d*|E|<=lambda*d*Xq/q_- with complete E=(2^16+2)w and q_-=3/4. This last comparison is only for the exhibited subbranch, not a computation of every other original flow or a numerical proof of the general theorem.

Baseline eta=.001, P=2^(-20), delta=10^(-14), hden=10:

| quantity | ordinary display of exact rational value |
|---|---:|
| G_next(big→mid), all newly paid | 1.530810303e-57 |
| Tbig/Tmid-1 | 1.650311851e-5 |
| complete-box A lower | 2.040132328e-9 |
| pmean | .0151446100 |
| h=H | 8.065969231e-45 |
| full W | 3221225472.000000954 |
| full Xq | 4.915356260e-44 |
| G/Xq | 3.114342526e-14 |

The actual fee is tiny. The point is strict nonempty coverage by the new mechanism, not that the old budget fails or that a large fraction of general G is represented.

## Three stages, exact evidence and reproduction

The script uses Python standard library Fraction only, not floating comparisons, point sampling, an optimizer, or a precomputed old /tmp dependency. Stage 1 is the baseline. Stage 2 executes 27 fields with eta in {.0005,.001,.002}, P in {2^-22,2^-20,2^-18}, and hden in {8,10,12}; it includes q=1 and closed-rank equality stress. Stage 3 executes these with delta in {10^-15,10^-14,10^-13}, 81 fields. Repeated parameter fields are counted as executions, not independent examples. Across all fields the rank excess is between 1.55525e-5 and 2.03038e-5, strictly below d; core A lower is at least 4.80472e-10. All designated costs are positive and all literal old/new branches have the claimed statuses.

Run `python3 r387_continuum.py` from any directory. It writes `r387_continuum.result.json` beside itself; standard Python versions need no packages. The output keeps one complete rational baseline plus exact stage extrema and reproducible full-case digests rather than a large redundant case dump. **15,588 exact Fraction assertions** passed. A second fresh process reproduced the JSON byte for byte. Only the owned R387 files were changed; no repository/Git action or other-agent file modification.
