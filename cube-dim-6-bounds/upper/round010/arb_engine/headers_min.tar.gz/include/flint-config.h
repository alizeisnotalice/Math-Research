/*
    Copyright (C) 2023, 2024 Albin Ahlbäck

    This file is part of FLINT.

    FLINT is free software: you can redistribute it and/or modify it under
    the terms of the GNU Lesser General Public License (LGPL) as published
    by the Free Software Foundation; either version 3 of the License, or
    (at your option) any later version.  See <https://www.gnu.org/licenses/>.
*/

/* Define if system is big endian. */
#define FLINT_BIG_ENDIAN 0

/* Define according to the ABI FLINT was compiled with */
#define FLINT_BITS 64

/* Define if Arm v8 assembly is available */
#define FLINT_HAVE_ASSEMBLY_armv8 0

/* Define if x86_64 ADX assembly is available */
#define FLINT_HAVE_ASSEMBLY_x86_64_adx 0

/* Define to use the fft_small module */
#define FLINT_HAVE_FFT_SMALL 0

/* Define if GMP has mpn_add_n_sub_n */
#define FLINT_HAVE_NATIVE_mpn_add_n_sub_n 0

/* Define if GMP has mpn_add_nc */
#define FLINT_HAVE_NATIVE_mpn_add_nc 0

/* Define if GMP has mpn_addlsh1_n */
#define FLINT_HAVE_NATIVE_mpn_addlsh1_n 0

/* Define if GMP has mpn_addlsh1_n_ip1 */
#define FLINT_HAVE_NATIVE_mpn_addlsh1_n_ip1 0

/* Define if GMP has mpn_addmul_2 */
#define FLINT_HAVE_NATIVE_mpn_addmul_2 0

/* Define if system has mpn_modexact_1_odd */
#define FLINT_HAVE_NATIVE_mpn_modexact_1_odd 0

/* Define if GMP has mpn_rsh1add_n */
#define FLINT_HAVE_NATIVE_mpn_rsh1add_n 0

/* Define if GMP has mpn_rsh1sub_n */
#define FLINT_HAVE_NATIVE_mpn_rsh1sub_n 0

/* Define if GMP has mpn_sub_nc */
#define FLINT_HAVE_NATIVE_mpn_sub_nc 0

/* Define if system is strongly ordered */
#define FLINT_KNOW_STRONG_ORDER 0

/* Define to use long long limbs */
#define FLINT_LONG_LONG 0

/* Define to enable reentrant. */
#define FLINT_REENTRANT 1

/* Define to locally unroll some loops */
#define FLINT_UNROLL_LOOPS 0

/* Define to enable BLAS. */
#define FLINT_USES_BLAS 0

/* Define if system has cpu_set_t */
#define FLINT_USES_CPUSET 0

/* Define to enable the Boehm-Demers-Weise garbage collector. */
#define FLINT_USES_GC 0

/* Define to enable the use of pthread. */
#define FLINT_USES_PTHREAD 1

/* Define to enable thread-local storage. */
#define FLINT_USES_TLS 1

/* Define to enable use of asserts. */
#define FLINT_WANT_ASSERT 0

/* Define to enable use of GMP internals. */
#define FLINT_WANT_GMP_INTERNALS 0

/* Define to enable inline assembly. */
#define FLINT_WANT_ASSEMBLY 0

/* Define to enable pretty printing for tests. */
#define FLINT_WANT_PRETTY_TESTS 0
